Перейти в папку src и запустить clone.bat

100khz_gen.uvprojx

adc_F103.uvprojx                     - тесты АЦП на Discovery
adc_F405.uvprojx

bit_set.uvprojx

dac_F303.uvprojx                     - тесты ЦАП на Discovery
dac_F405.uvprojx

hot_end_test1.uvprojx                - тесты разной периферии для использования в hot-end'е вершины
hot_end_test2.uvprojx
hot_end_test3.uvprojx

impeller_F103.uvprojx                - тесты импеллера - задается ШИМ, который подается на 
impeller_F405.uvprojx                  драйвер коптерного мотора
impeller_F405_disc.uvprojx
impeller_psensor_F405.uvprojx        - тоже самое, только с использованием датчика давления и ПИД регулятора
impeller_psensor2_F103.uvprojx
impeller_psensor2_F405.uvprojx

kbd.uvprojx                          - сканер клавиатуры

led_toggle_virtual_port.uvprojx      - тесты Virtual GPIO - мигание светодиодом
led_toggle.uvprojx                   - тесты Virtual GPIO - мигание светодиодом. Используется
                                       не вируальный, а аппаратный порт с тем же интерфейсм.
                                       VGPIO сейчас устарело

gpio_led_F405.uvprojx                  Тест GPIO из модуля periph



press_sensor_F103.uvprojx            - Honeywell I2C Pressure Sensor tests
press_sensor_F405.uvprojx            

spi_F103_lsm9ds1_HSE8.uvprojx        - 9-D LSM9DS1 SPI sensor test discovery projects
spi_F303_lsm9ds1_HSE8.uvprojx
spi_F407_lsm9ds1_HSE8.uvprojx


spi_F303_bldc_HSE12.uvprojx          - Тесты отладочной платы драйвера мотора
spi_F303_bldc_HSE8.uvprojx
spi_F303_bldc_periph_HSE12.uvprojx
spi_F303_bldc_periph_HSE8.uvprojx

spi_F303_disc.uvprojx

spi_F405.uvprojx

spi_test_master_D100.uvprojx         - Тесты SPI master/slave на различных Discovery
spi_test_master_D103.uvprojx           см. src/main/spi_test_master_slave.h
spi_test_master_D303.uvprojx
spi_test_master_D407.uvprojx
spi_test_slave_D100.uvprojx
spi_test_slave_D103.uvprojx
spi_test_slave_D303.uvprojx
spi_test_slave_D407.uvprojx

spi_test_2_D100.uvprojx              - Простой SPI тест - отправляем счетчик, принимаем число,
spi_test_2_D103.uvprojx                выводим отправленное и принятое в отладочный UART,
spi_test_2_D303.uvprojx                инкрементируем счетчик
spi_test_2_D407.uvprojx

esc_pwm_test_D100.uvprojx            ESC на соточке - покрутили импеллером
esc_pwm_test_D103.uvprojx
esc_pwm_test_F103T8.uvprojx


dma_mem2mem_1_D103.uvoptx            Тест пересылки mem2mem
dma_mem2mem_1_D303.uvoptx
dma_mem2mem_1_D407.uvoptx

dma_mem2mem_2_D103.uvoptx            Тест пересылки mem2mem по всем доступным каналам
dma_mem2mem_2_D303.uvoptx
dma_mem2mem_2_D407.uvoptx



static_list.uvprojx
time_service.uvprojx
tvko_test.uvprojx
vgpio.uvprojx
vtx2_cams.uvprojx
