#pragma once


namespace scalcus
{

//-----------------------------------------------------------------------------
inline
uint64_t calcCanSamplePointFit( uint64_t v1, uint64_t v2 )
{
    int64_t i = (int64_t)v1 - (int64_t)v2;
    if (i<0)
        return (uint64_t)(-i);
    return (uint64_t)i;
}

//-----------------------------------------------------------------------------
inline
bool calcCanTimings( uint64_t freq, uint64_t baudRate, unsigned takenPermille, uint16_t &prescaler, uint16_t &bs1, uint16_t &bs2)
{
    uint16_t maxBs1   = 16; 
    uint16_t maxBs2   = 8; 

    bool bestFound           = false;
    uint16_t bestPrescaler   = 0;
    uint16_t bestBs1         = 0;
    uint16_t bestBs2         = 0;
    unsigned bestPermilleErr = 0;

    int16_t curPrescaler = 1;
    for(; true; ++curPrescaler)
    {
        uint64_t sfreq = freq / curPrescaler;
        uint64_t nTQ = sfreq / baudRate;

        if (curPrescaler > 1024)
            break;

        if ( nTQ > (uint64_t)(1 + maxBs1 + maxBs2) )
           continue;

        if ( nTQ <= 3 )
            break;

        if (nTQ*baudRate != sfreq)
           continue;

        for (uint16_t bs1 = maxBs1; bs1 > 1 ; --bs1)
            for(uint16_t bs2 = maxBs2; bs2 > 0 ; --bs2)
            {
                if ((1+bs1+bs2)!=nTQ)
                    continue;

                unsigned curPermille = 1000*(1+bs1) / (1+bs1+bs2);
                unsigned curPermilleErr = (unsigned)calcCanSamplePointFit( curPermille, takenPermille );
                if (!bestFound)
                {
                    bestFound        = true;
                    bestPrescaler    = curPrescaler;
                    bestBs1          = bs1;
                    bestBs2          = bs2;
                    bestPermilleErr  = curPermilleErr;
                }
                else
                {
                    if (bestPermilleErr > curPermilleErr)
                    {
                        bestPrescaler    = curPrescaler;
                        bestBs1          = bs1;
                        bestBs2          = bs2;
                        bestPermilleErr  = curPermilleErr;
                    }
                }
            }
    }

    if (!bestFound)
        return bestFound;

    prescaler = bestPrescaler;
    bs1 = bestBs1;
    bs2 = bestBs2;
    return true;

}






} // namespace scalcus


