#pragma once

namespace scalcus
{

inline
uint32_t calcTimerPwmTickFreq( uint32_t timerBusFreq, uint16_t prescaler )
{
    return timerBusFreq / (((uint32_t)prescaler) + 1);
}

inline
uint32_t calcTimerPwmPrescalerAndPeriod( uint32_t timerBusFreq
                                        , uint32_t requiredTimerFreqHz
                                        , uint16_t &prescaler
                                        , uint16_t &period
                                        )
{
    uint32_t curPrescaler = 0;
    uint32_t tickFreq     = calcTimerPwmTickFreq( timerBusFreq, curPrescaler );
    uint32_t curPeriod    = tickFreq / requiredTimerFreqHz - 1;
    while(curPeriod>65535)
       {
        curPrescaler = !curPrescaler ? 1 : (curPrescaler+1)*2-1;
        //UMBA_ASSERT(curPrescaler<65536);
        tickFreq     = calcTimerPwmTickFreq( timerBusFreq, curPrescaler );
        curPeriod    = tickFreq / requiredTimerFreqHz - 1;
       }

    prescaler = (uint16_t)curPrescaler;
    period    = (uint16_t)curPeriod;
    return tickFreq;

}







} // namespace scalcus


