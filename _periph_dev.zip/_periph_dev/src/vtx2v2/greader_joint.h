#define ro_min 0x00

//$ROBEGIN
#define ro_current_angle_u16_0     0x00 // Текущий угол
#define ro_current_angle_u16_1     0x01
#define ro_state_counter_u8        0x02 // Счетчик выполнения, инкрементируется на 1 после начала выполнения команды, и еще на 1 при окончании, т.о. если нечёт - то в процессе выполнения
#define ro_negative_angle_limit_u16_0 0x03 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define ro_negative_angle_limit_u16_1 0x04
#define ro_positive_angle_limit_u16_0 0x05 // Ограничение угла для движения с положительной скоростью, 0-1024
#define ro_positive_angle_limit_u16_1 0x06
#define ro_no_movement_flag_u8     0x07 // Флаг отсутствия движения - шарнир не смог
//$ROEND
#define ro_max 0x07

#define rw_min 0x80

//$RWBEGIN
#define rw_target_angle_u16_0      0x80 // Целевой угол, 0-1024
#define rw_target_angle_u16_1      0x81
#define rw_speed_s8                0x82 // Скорость движения, в попугаях/процентах от макс возможной, знак задает направление
#define rw_mode_ctrl_u8            0x83 // Режим движения - 0 - Неподвижность, 1 - Скорость, 2 - Позиция, 3 - Движение в 0 (см. тип JointMode в vertex_types.rdl)
#define rw_current_limit_u8        0x84 // Ограничение по току, в 0.1А
#define rw_negative_angle_limit_u16_0 0x85 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define rw_negative_angle_limit_u16_1 0x86
#define rw_positive_angle_limit_u16_0 0x87 // Ограничение угла для движения с положительной скоростью, 0-1024
#define rw_positive_angle_limit_u16_1 0x88
#define rw_save_data_to_flash_u8   0x89 // true - инициировать сохранение во флеш
#define rw_clear_flash_u8          0x8A // true - очистить записанные во флеш данные
#define rw_no_movement_period_u8   0x8B // Период стояния на месте в десятках мс, прежде чем будет подан флаг неуспеха достижения позиции
//$RWEND
#define rw_max 0x8B

