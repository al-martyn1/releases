#ifndef RDLC_SUPPORT_HEADER__58F2AA91_CC98_4E4C_A448_789A164A7EC0__INCLUDED__
#define RDLC_SUPPORT_HEADER__58F2AA91_CC98_4E4C_A448_789A164A7EC0__INCLUDED__


#include <stdint.h>
#include <string.h>

#define RDLC_REGTYPE_FLOAT         -1
#define RDLC_REGTYPE_INT            1
#define RDLC_REGTYPE_UNSIGNED       0


namespace rdlc
{




//-----------------------------------------------------------------------------
struct regtype_float {};

struct regtype_signed{};  typedef regtype_signed regtype_int;

struct regtype_unsigned{};

struct regsize_8{};

struct regsize_16{};

struct regsize_32{};

//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
template< typename TMetaType, typename TRegType >
struct TypedIndex
{
    typedef TMetaType     MetaType;
    size_t  indexValue;

/*
    const char* regGetNsName( )
    bool regTypeCheck( uint8_t regNo, int regType, unsigned regSize )
    const char* regGetName( uint8_t regNo )
    int regGetType( uint8_t regNo )
    int regGetSize( uint8_t regNo )
    int regGetNext( uint8_t regNo )
    int regGetPrev( uint8_t regNo )
    int regGetFirst()
    int regGetLast()
*/

};

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template< typename RegTableType, typename MetaType, typename RegType >
struct IndexedTableRegisterProxy
{
    IndexedTableRegisterProxy( RegTableType &tbl, const TypedIndex<MetaType,RegType> idx )
    : regTable(tbl), regIndex( idx )
    {}

    IndexedTableRegisterProxy( const IndexedTableRegisterProxy &p ) = default;
    IndexedTableRegisterProxy( IndexedTableRegisterProxy && )       = default;

    operator RegType() const
    {
        return regTable.getRegVal( regIndex );
    }

    void operator=( const RegType r ) const
    {
        regTable.setRegVal( regIndex, r );
    }

protected:

    RegTableType        &regTable;
    TypedIndex<MetaType,RegType>  regIndex;

}; // struct IndexedTableRegisterProxy

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template< typename RegTableType, typename TMetaType, typename RegType >
struct IndexedTableRegisterConstProxy
{

    typedef TMetaType     MetaType;


    IndexedTableRegisterConstProxy( RegTableType &tbl, const TypedIndex<MetaType,RegType> idx )
    : regTable(tbl), regIndex( idx )
    {}

    IndexedTableRegisterConstProxy( const IndexedTableRegisterConstProxy &p ) = default;
    IndexedTableRegisterConstProxy( IndexedTableRegisterConstProxy && )       = default;

    operator RegType() const
    {
        return regTable.getRegVal( regIndex.indexValue );
    }

protected:

    RegTableType        &regTable;
    TypedIndex<MetaType,RegType>  regIndex;

}; // struct IndexedTableRegisterConstProxy

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
template< typename RawRegTable, typename MetaType >
class RegTablePrivate
{

public:

    RegTablePrivate(RawRegTable *pRawTable = 0) : m_pRawTable(pRawTable) {}
    RegTablePrivate( const RegTablePrivate &rt ) = default;
    RegTablePrivate( RegTablePrivate && )        = default;

              
    RawRegTable* getRawTable() const
    {
        return m_pRawTable;
    }

    void setRawTable( RawRegTable* pRawTable)
    {
        m_pRawTable = pRawTable;
    }

    void setRegVal_u8 ( uint8_t regNo, uint8_t val )   const { m_pRawTable->setRegVal( regNo, val );    }
    void setRegVal_s8 ( uint8_t regNo, int8_t val )    const { setRegVal_u8( regNo, (uint8_t)val );   }
    void setRegVal_u16( uint8_t regNo, uint16_t val )  const { m_pRawTable->setReg16Val( regNo, val );  }
    void setRegVal_s16( uint8_t regNo, int16_t val )   const { setRegVal_u16( regNo, (uint16_t)val );  }
    void setRegVal_u32( uint8_t regNo, uint32_t val )  const { m_pRawTable->setReg32Val( regNo, val ); }
    void setRegVal_s32( uint8_t regNo, int32_t val )   const { setRegVal_u32( regNo, (uint32_t)val ); }
    void setRegVal_f32( uint8_t regNo, float val )     const 
    {
        UMBA_ASSERT( sizeof(float)==sizeof(uint32_t) );
        uint32_t u;
        memcpy( &u, &val, sizeof(val) );
        setRegVal_u32( regNo, u );
    }
    
    uint8_t  getRegVal_u8 ( uint8_t regNo )            const { return m_pRawTable->getRegVal( regNo ); }
    int8_t   getRegVal_s8 ( uint8_t regNo )            const { return (int8_t)getRegVal_u8( regNo ); }
    uint16_t getRegVal_u16( uint8_t regNo )            const { return m_pRawTable->getReg16Val( regNo ); }
    int16_t  getRegVal_s16( uint8_t regNo )            const { return (int16_t)getRegVal_u16( regNo );  }
    uint32_t getRegVal_u32( uint8_t regNo )            const { return m_pRawTable->getReg32Val( regNo ); }
    int32_t  getRegVal_s32( uint8_t regNo )            const { return (int32_t)getRegVal_u32( regNo ); }
    float    getRegVal_f32( uint8_t regNo )            const 
    {
        UMBA_ASSERT( sizeof(float)==sizeof(uint32_t) );
        uint32_t u = getRegVal_u32( regNo );
        float f;
        memcpy( &f, &u, sizeof(f) );
        return f;
    }

    uint8_t  getRegValNonResetting_u8 ( uint8_t regNo )            const { uint8_t res = m_pRawTable->getRegVal( regNo ); setRegVal_u8( regNo, res ); return res; }
    int8_t   getRegValNonResetting_s8 ( uint8_t regNo )            const { return (int8_t)getRegVal_u8( regNo ); }
    uint16_t getRegValNonResetting_u16( uint8_t regNo )            const { uint16_t res = m_pRawTable->getReg16Val( regNo ); setRegVal_u16( regNo, res );  return res; }
    int16_t  getRegValNonResetting_s16( uint8_t regNo )            const { return (int16_t)getRegVal_u16( regNo );  }
    uint32_t getRegValNonResetting_u32( uint8_t regNo )            const { uint32_t res = m_pRawTable->getReg32Val( regNo ); setRegVal_u32( regNo, res ); return res; }
    int32_t  getRegValNonResetting_s32( uint8_t regNo )            const { return (int32_t)getRegVal_u32( regNo ); }
    float    getRegValNonResetting_f32( uint8_t regNo )            const 
    {
        UMBA_ASSERT( sizeof(float)==sizeof(uint32_t) );
        uint32_t u = getRegVal_u32( regNo );
        float f;
        memcpy( &f, &u, sizeof(f) );
        return f;
    }
    
    bool isRegNonResettingChanged_u8 ( uint8_t regNo ) const { bool res = m_pRawTable->checkRegUpdate( regNo ); if (res) setRegVal_u8( regNo, getRegVal_u8( regNo ) );  return res; }
    bool isRegNonResettingChanged_s8 ( uint8_t regNo ) const { return isRegNonResettingChanged_u8( regNo ); }
    bool isRegNonResettingChanged_u16( uint8_t regNo ) const { bool res = m_pRawTable->checkReg16Update( regNo ); if (res) setRegVal_u16( regNo, getRegVal_u16( regNo ) ); return res; }
    bool isRegNonResettingChanged_s16( uint8_t regNo ) const { return isRegNonResettingChanged_u16( regNo ); }
    bool isRegNonResettingChanged_u32( uint8_t regNo ) const { bool res = m_pRawTable->checkReg32Update( regNo ); if (res) setRegVal_u32( regNo, getRegVal_u32( regNo ) );  return res; }
    bool isRegNonResettingChanged_s32( uint8_t regNo ) const { return isRegNonResettingChanged_u32( regNo ); }
    bool isRegNonResettingChanged_f32( uint8_t regNo ) const { return isRegNonResettingChanged_u32( regNo ); }

    bool isRegResettingChanged_u8 ( uint8_t regNo )    const { return m_pRawTable->checkRegUpdate( regNo ); }
    bool isRegResettingChanged_s8 ( uint8_t regNo )    const { return isRegResettingChanged_u8( regNo ); }
    bool isRegResettingChanged_u16( uint8_t regNo )    const { return m_pRawTable->checkReg16Update( regNo ); }
    bool isRegResettingChanged_s16( uint8_t regNo )    const { return isRegResettingChanged_u16( regNo ); }
    bool isRegResettingChanged_u32( uint8_t regNo )    const { return m_pRawTable->checkReg32Update( regNo ); }
    bool isRegResettingChanged_s32( uint8_t regNo )    const { return isRegResettingChanged_u32( regNo ); }
    bool isRegResettingChanged_f32( uint8_t regNo )    const { return isRegResettingChanged_u32( regNo ); }
    
    void clearRegChanged_u8 ( uint8_t regNo )          const { m_pRawTable->checkRegUpdate( regNo );   }
    void clearRegChanged_s8 ( uint8_t regNo )          const { m_pRawTable->checkRegUpdate( regNo );   }
    void clearRegChanged_u16( uint8_t regNo )          const { m_pRawTable->checkReg16Update( regNo ); }
    void clearRegChanged_s16( uint8_t regNo )          const { m_pRawTable->checkReg16Update( regNo ); }
    void clearRegChanged_u32( uint8_t regNo )          const { m_pRawTable->checkReg32Update( regNo ); }
    void clearRegChanged_s32( uint8_t regNo )          const { m_pRawTable->checkReg32Update( regNo ); }
    void clearRegChanged_f32( uint8_t regNo )          const { m_pRawTable->checkReg32Update( regNo ); }

public: // This functions we need to hide in derived table

    void setRegVal      ( uint8_t regNo,  uint8_t   val ) const { setRegVal_u8 (regNo, val); }
    void setRegVal      ( uint8_t regNo,   int8_t   val ) const { setRegVal_s8 (regNo, val); }
    void setRegVal      ( uint8_t regNo, uint16_t   val ) const { setRegVal_u16(regNo, val); }
    void setRegVal      ( uint8_t regNo,  int16_t   val ) const { setRegVal_s16(regNo, val); }
    void setRegVal      ( uint8_t regNo, uint32_t   val ) const { setRegVal_u32(regNo, val); }
    void setRegVal      ( uint8_t regNo,  int32_t   val ) const { setRegVal_s32(regNo, val); }
    void setRegVal      ( uint8_t regNo,    float   val ) const { setRegVal_f32(regNo, val); }

    void getRegVal      ( uint8_t regNo,  uint8_t  &val ) const { val = getRegVal_u8 (regNo); }
    void getRegVal      ( uint8_t regNo,   int8_t  &val ) const { val = getRegVal_s8 (regNo); }
    void getRegVal      ( uint8_t regNo, uint16_t  &val ) const { val = getRegVal_u16(regNo); }
    void getRegVal      ( uint8_t regNo,  int16_t  &val ) const { val = getRegVal_s16(regNo); }
    void getRegVal      ( uint8_t regNo, uint32_t  &val ) const { val = getRegVal_u32(regNo); }
    void getRegVal      ( uint8_t regNo,  int32_t  &val ) const { val = getRegVal_s32(regNo); }
    void getRegVal      ( uint8_t regNo,    float  &val ) const { val = getRegVal_f32(regNo); }

    bool getRegIfChanged( uint8_t regNo,  uint8_t  &val ) const { if (!isRegResettingChanged_u8 (regNo)) return false; getRegVal(regNo, val); return true; }
    bool getRegIfChanged( uint8_t regNo,   int8_t  &val ) const { if (!isRegResettingChanged_s8 (regNo)) return false; getRegVal(regNo, val); return true; }
    bool getRegIfChanged( uint8_t regNo, uint16_t  &val ) const { if (!isRegResettingChanged_u16(regNo)) return false; getRegVal(regNo, val); return true; }
    bool getRegIfChanged( uint8_t regNo,  int16_t  &val ) const { if (!isRegResettingChanged_s16(regNo)) return false; getRegVal(regNo, val); return true; }
    bool getRegIfChanged( uint8_t regNo, uint32_t  &val ) const { if (!isRegResettingChanged_u32(regNo)) return false; getRegVal(regNo, val); return true; }
    bool getRegIfChanged( uint8_t regNo,  int32_t  &val ) const { if (!isRegResettingChanged_s32(regNo)) return false; getRegVal(regNo, val); return true; }
    bool getRegIfChanged( uint8_t regNo,    float  &val ) const { if (!isRegResettingChanged_f32(regNo)) return false; getRegVal(regNo, val); return true; }

    void clearRegChanged( uint8_t regNo,  uint8_t dummy ) const { clearRegChanged_u8 (regNo); }
    void clearRegChanged( uint8_t regNo,   int8_t dummy ) const { clearRegChanged_s8 (regNo); }
    void clearRegChanged( uint8_t regNo, uint16_t dummy ) const { clearRegChanged_u16(regNo); }
    void clearRegChanged( uint8_t regNo,  int16_t dummy ) const { clearRegChanged_s16(regNo); }
    void clearRegChanged( uint8_t regNo, uint32_t dummy ) const { clearRegChanged_u32(regNo); }
    void clearRegChanged( uint8_t regNo,  int32_t dummy ) const { clearRegChanged_s32(regNo); }
    void clearRegChanged( uint8_t regNo,    float dummy ) const { clearRegChanged_f32(regNo); }

protected:

    bool isRegRw( uint8_t regNo )
    {
        return regNo >= 0x80;
    }

    template<typename RegType>
    bool isRegRw( TypedIndex<MetaType,RegType> regNo )
    {
        return regNo.indexValue >= 0x80;
    }


    RawRegTable *m_pRawTable;

}; // class RegTablePrivate

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
//! Предоставляет безопасный доступ к регистрам
/*! Доступ к регистрам производится либо через совсем "сырые" методы,
    которые неудобны для использования, либо через типизированный индекс, 
    который предохраняет от ошибок
 */
template< typename RawRegTable, typename MetaType >
class RegTableSafe : protected RegTablePrivate< RawRegTable, MetaType >
{

public:

    typedef RegTablePrivate< RawRegTable, MetaType > RegTableBase;

    using RegTableBase::getRawTable;
    using RegTableBase::setRawTable;

    using RegTableBase::setRegVal_u8 ;
    using RegTableBase::setRegVal_s8 ;
    using RegTableBase::setRegVal_u16;
    using RegTableBase::setRegVal_s16;
    using RegTableBase::setRegVal_u32;
    using RegTableBase::setRegVal_s32;
    using RegTableBase::setRegVal_f32;

    using RegTableBase::getRegVal_u8 ;
    using RegTableBase::getRegVal_s8 ;
    using RegTableBase::getRegVal_u16;
    using RegTableBase::getRegVal_s16;
    using RegTableBase::getRegVal_u32;
    using RegTableBase::getRegVal_s32;
    using RegTableBase::getRegVal_f32;
    
    using RegTableBase::isRegNonResettingChanged_u8 ;
    using RegTableBase::isRegNonResettingChanged_s8 ;
    using RegTableBase::isRegNonResettingChanged_u16;
    using RegTableBase::isRegNonResettingChanged_s16;
    using RegTableBase::isRegNonResettingChanged_u32;
    using RegTableBase::isRegNonResettingChanged_s32;
    using RegTableBase::isRegNonResettingChanged_f32;

    using RegTableBase::isRegResettingChanged_u8 ;
    using RegTableBase::isRegResettingChanged_s8 ;
    using RegTableBase::isRegResettingChanged_u16;
    using RegTableBase::isRegResettingChanged_s16;
    using RegTableBase::isRegResettingChanged_u32;
    using RegTableBase::isRegResettingChanged_s32;
    using RegTableBase::isRegResettingChanged_f32;
    
    using RegTableBase::clearRegChanged_u8 ;
    using RegTableBase::clearRegChanged_s8 ;
    using RegTableBase::clearRegChanged_u16;
    using RegTableBase::clearRegChanged_s16;
    using RegTableBase::clearRegChanged_u32;
    using RegTableBase::clearRegChanged_s32;
    using RegTableBase::clearRegChanged_f32;


    RegTableSafe(RawRegTable *pRawTable = 0) : RegTableBase(pRawTable) {}
    RegTableSafe( const RegTableSafe &rt ) = default;
    RegTableSafe( RegTableSafe && )        = default;


    void setRegVal      ( TypedIndex<MetaType, uint8_t> regNo,  uint8_t   val ) const { setRegVal_u8 (regNo.indexValue, val); }
    void setRegVal      ( TypedIndex<MetaType,  int8_t> regNo,   int8_t   val ) const { setRegVal_s8 (regNo.indexValue, val); }
    void setRegVal      ( TypedIndex<MetaType,uint16_t> regNo, uint16_t   val ) const { setRegVal_u16(regNo.indexValue, val); }
    void setRegVal      ( TypedIndex<MetaType, int16_t> regNo,  int16_t   val ) const { setRegVal_s16(regNo.indexValue, val); }
    void setRegVal      ( TypedIndex<MetaType,uint32_t> regNo, uint32_t   val ) const { setRegVal_u32(regNo.indexValue, val); }
    void setRegVal      ( TypedIndex<MetaType, int32_t> regNo,  int32_t   val ) const { setRegVal_s32(regNo.indexValue, val); }
    void setRegVal      ( TypedIndex<MetaType,   float> regNo,    float   val ) const { setRegVal_f32(regNo.indexValue, val); }
                                             
    void getRegVal      ( TypedIndex<MetaType, uint8_t> regNo,  uint8_t  &val ) const { val = getRegVal_u8 (regNo.indexValue); }
    void getRegVal      ( TypedIndex<MetaType,  int8_t> regNo,   int8_t  &val ) const { val = getRegVal_s8 (regNo.indexValue); }
    void getRegVal      ( TypedIndex<MetaType,uint16_t> regNo, uint16_t  &val ) const { val = getRegVal_u16(regNo.indexValue); }
    void getRegVal      ( TypedIndex<MetaType, int16_t> regNo,  int16_t  &val ) const { val = getRegVal_s16(regNo.indexValue); }
    void getRegVal      ( TypedIndex<MetaType,uint32_t> regNo, uint32_t  &val ) const { val = getRegVal_u32(regNo.indexValue); }
    void getRegVal      ( TypedIndex<MetaType, int32_t> regNo,  int32_t  &val ) const { val = getRegVal_s32(regNo.indexValue); }
    void getRegVal      ( TypedIndex<MetaType,   float> regNo,    float  &val ) const { val = getRegVal_f32(regNo.indexValue); }
                                             
     uint8_t getRegVal  ( TypedIndex<MetaType, uint8_t> regNo                 ) const { return getRegVal_u8 (regNo.indexValue); }
      int8_t getRegVal  ( TypedIndex<MetaType,  int8_t> regNo                 ) const { return getRegVal_s8 (regNo.indexValue); }
    uint16_t getRegVal  ( TypedIndex<MetaType,uint16_t> regNo                 ) const { return getRegVal_u16(regNo.indexValue); }
     int16_t getRegVal  ( TypedIndex<MetaType, int16_t> regNo                 ) const { return getRegVal_s16(regNo.indexValue); }
    uint32_t getRegVal  ( TypedIndex<MetaType,uint32_t> regNo                 ) const { return getRegVal_u32(regNo.indexValue); }
     int32_t getRegVal  ( TypedIndex<MetaType, int32_t> regNo                 ) const { return getRegVal_s32(regNo.indexValue); }
       float getRegVal  ( TypedIndex<MetaType,   float> regNo                 ) const { return getRegVal_f32(regNo.indexValue); }
                                             
    bool getRegIfChanged( TypedIndex<MetaType, uint8_t> regNo,  uint8_t  &val ) const { if (!isRegResettingChanged_u8 (regNo.indexValue)) return false; val = getRegVal_u8 (regNo.indexValue); return true; }
    bool getRegIfChanged( TypedIndex<MetaType,  int8_t> regNo,   int8_t  &val ) const { if (!isRegResettingChanged_s8 (regNo.indexValue)) return false; val = getRegVal_s8 (regNo.indexValue); return true; }
    bool getRegIfChanged( TypedIndex<MetaType,uint16_t> regNo, uint16_t  &val ) const { if (!isRegResettingChanged_u16(regNo.indexValue)) return false; val = getRegVal_u16(regNo.indexValue); return true; }
    bool getRegIfChanged( TypedIndex<MetaType, int16_t> regNo,  int16_t  &val ) const { if (!isRegResettingChanged_s16(regNo.indexValue)) return false; val = getRegVal_s16(regNo.indexValue); return true; }
    bool getRegIfChanged( TypedIndex<MetaType,uint32_t> regNo, uint32_t  &val ) const { if (!isRegResettingChanged_u32(regNo.indexValue)) return false; val = getRegVal_u32(regNo.indexValue); return true; }
    bool getRegIfChanged( TypedIndex<MetaType, int32_t> regNo,  int32_t  &val ) const { if (!isRegResettingChanged_s32(regNo.indexValue)) return false; val = getRegVal_s32(regNo.indexValue); return true; }
    bool getRegIfChanged( TypedIndex<MetaType,   float> regNo,    float  &val ) const { if (!isRegResettingChanged_f32(regNo.indexValue)) return false; val = getRegVal_f32(regNo.indexValue); return true; }
                                             
    void clearRegChanged( TypedIndex<MetaType, uint8_t> regNo                 ) const { clearRegChanged_u8 (regNo.indexValue); }
    void clearRegChanged( TypedIndex<MetaType,  int8_t> regNo                 ) const { clearRegChanged_s8 (regNo.indexValue); }
    void clearRegChanged( TypedIndex<MetaType,uint16_t> regNo                 ) const { clearRegChanged_u16(regNo.indexValue); }
    void clearRegChanged( TypedIndex<MetaType, int16_t> regNo                 ) const { clearRegChanged_s16(regNo.indexValue); }
    void clearRegChanged( TypedIndex<MetaType,uint32_t> regNo                 ) const { clearRegChanged_u32(regNo.indexValue); }
    void clearRegChanged( TypedIndex<MetaType, int32_t> regNo                 ) const { clearRegChanged_s32(regNo.indexValue); }
    void clearRegChanged( TypedIndex<MetaType,   float> regNo                 ) const { clearRegChanged_f32(regNo.indexValue); }


    template< typename RegType >
    IndexedTableRegisterProxy< RegTableSafe, MetaType, RegType >  operator[]( TypedIndex<MetaType,RegType> idx )
    {
        return IndexedTableRegisterProxy< RegTableSafe, MetaType, RegType >(*this, idx );
    }

    template< typename RegType >
    IndexedTableRegisterConstProxy< RegTableSafe, MetaType, RegType >  operator[]( TypedIndex<MetaType,RegType> idx ) const
    {
        return IndexedTableRegisterConstProxy< RegTableSafe, MetaType, RegType >(*this, idx );
    }


}; // class RegTableSafe



//-----------------------------------------------------------------------------
//! Предоставляет достаточно удобный, но менее безопасный доступ к регистрам
/*! Регистры индексируются числами, но с размерами ошибок не будет.
 */
template< typename RawRegTable, typename MetaType >
class RegTablePublic : public RegTablePrivate< RawRegTable, MetaType >
{

public:

    typedef RegTablePrivate< RawRegTable, MetaType > RegTableBase;


    RegTablePublic(RawRegTable *pRawTable = 0) : RegTableBase(pRawTable) {}
    RegTablePublic( const RegTablePublic &rt ) = default;
    RegTablePublic( RegTablePublic && )        = default;



}; // class RegTable




template<typename RawRegTable, typename MetaType >
inline
RegTableSafe<RawRegTable, MetaType> makeRegTableSafe( RawRegTable &rawTable, const MetaType &dummyMeta )
{
    return RegTableSafe<RawRegTable, MetaType>( &rawTable );
}

template<typename RawRegTable, typename MetaType >
inline
RegTableSafe<RawRegTable, MetaType> makeRegTableSafe( RawRegTable *pRawTable, const MetaType &dummyMeta )
{
    return RegTableSafe<RawRegTable, MetaType>( pRawTable );
}


template<typename RawRegTable, typename MetaType >
inline
RegTablePublic<RawRegTable, MetaType> makeRegTablePublic( RawRegTable &rawTable, const MetaType &dummyMeta )
{
    return RegTablePublic<RawRegTable, MetaType>( &rawTable );
}

template<typename RawRegTable, typename MetaType >
inline
RegTablePublic<RawRegTable, MetaType> makeRegTablePublic( RawRegTable *pRawTable, const MetaType &dummyMeta )
{
    return RegTablePublic<RawRegTable, MetaType>( pRawTable );
}


    
    
template<typename CmpType>
inline
bool isRegValEqual( CmpType c1, CmpType c2 )
{
    return c1==c2;
}
    

} // namespace rdlc


#define RDLC_CONTAINING_RECORD_WITH_ID(address, type, field) ((type *)( \
                                                  1+(char*)(address) - \
                                                  (uintptr_t)(&((type *)1)->field)))


#define RDLC_DECLARE_REG_PROPERTY(OWNERNAME, TYPE, RAWTYPE, RDLC_TYPE, NAME)        \
class propclass_##NAME {                                                 \
    TYPE value;                                                          \
public:                                                                  \
    typedef TYPE property_type;                                          \
    propclass_##NAME() : value() {}                                      \
    inline operator property_type()                                      \
    {                                                                    \
        if (!isUpdated())                                                \
            return value;                                                \
        value = (property_type)(RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> getRegVal_##RDLC_TYPE( NAME##_id )); \
        /* non-reset extracting */                                                                                   \
        /*RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> setRegVal_##RDLC_TYPE( NAME##_id, (RAWTYPE)(value) );*/    \
        return value;                                                    \
    }                                                                    \
    inline void operator=(const property_type &src)                      \
    {                                                                    \
        value = src;                                                     \
        RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> setRegVal_##RDLC_TYPE( NAME##_id, (RAWTYPE)(value) ); \
    }                                                                    \
    inline bool isUpdated()                                              \
    {                                                                    \
        return RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> isRegNonResettingChanged_##RDLC_TYPE( NAME##_id );\
    }                                                                    \
    inline bool isChanged()                                              \
    {                                                                    \
        if (!isUpdated())                                                \
            return false;                                                \
        property_type tmp = (property_type)(RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> getRegVal_##RDLC_TYPE( NAME##_id ));\
        return rdlc::isRegValEqual( value, tmp );                        \
    }                                                                    \
    void clearUpdated()                                                  \
    {                                                                    \
        RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)->clearRegChanged_##RDLC_TYPE(NAME##_id);\
    }                                                                    \
    const char* name()                                                   \
    {                                                                    \
        return OWNERNAME :: meta :: regGetName(NAME##_id);               \
    }                                                                    \
} NAME




#define RDLC_DECLARE_REG_PROPERTY_WITH_RAW_ID(OWNERNAME, TYPE, RAWTYPE, RDLC_TYPE, NAME)        \
class propclass_##NAME {                                                 \
    TYPE value;                                                          \
public:                                                                  \
    typedef TYPE property_type;                                          \
    propclass_##NAME() : value() {}                                      \
    inline operator property_type()                                      \
    {                                                                    \
        if (!isUpdated())                                                \
            return value;                                                \
        value = (property_type)(RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> getRegVal_##RDLC_TYPE( NAME##_raw_id )); \
        /* non-reset extracting */                                                                                   \
        /*RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> setRegVal_##RDLC_TYPE( NAME##_raw_id, (RAWTYPE)(value) );*/    \
        return value;                                                    \
    }                                                                    \
    inline void operator=(const property_type &src)                      \
    {                                                                    \
        value = src;                                                     \
        RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> setRegVal_##RDLC_TYPE( NAME##_raw_id, (RAWTYPE)(value) ); \
    }                                                                    \
    inline bool isUpdated()                                              \
    {                                                                    \
        return RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> isRegNonResettingChanged_##RDLC_TYPE( NAME##_raw_id );\
    }                                                                    \
    inline bool isChanged()                                              \
    {                                                                    \
        if (!isUpdated())                                                \
            return false;                                                \
        property_type tmp = (property_type)(RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)-> getRegVal_##RDLC_TYPE( NAME##_raw_id ));\
        return rdlc::isRegValEqual( value, tmp );                        \
    }                                                                    \
    void clearUpdated()                                                  \
    {                                                                    \
        RDLC_CONTAINING_RECORD(this, OWNERNAME, NAME)->clearRegChanged_##RDLC_TYPE(NAME##_raw_id);\
    }                                                                    \
    const char* name()                                                   \
    {                                                                    \
        return OWNERNAME :: meta :: regGetName(NAME##_raw_id);           \
    }                                                                    \
} NAME



#ifdef RDLC_CONTRIB_USE_MILLIREGTABLE_SLAVE_BASE

namespace rdlc
{


class MilliganjubusSlaveBase : public milliganjubus::Slave
{

public:

    void resetConnectionFailures()
    {
        m_connectionFailuresCount = 0;
    }

    void enableRoSync( bool fEnable )
    {
        m_roSyncEnabled = fEnable;
    }

    void enableRwSync( bool fEnable )
    {
        m_rwSyncEnabled = fEnable;
    }

    void enableSync( bool fEnable )
    {
        m_roSyncEnabled = fEnable;
        m_rwSyncEnabled = fEnable;
    }

    bool isRoSyncEnabled() const
    {
        return m_roSyncEnabled;
    }

    bool isRwSyncEnabled() const
    {
        return m_rwSyncEnabled;
    }

protected:
/*
    void setMasterTable( milliganjubus::IMilliRegTable *pMasterTable )
    {
        m_masterTable = pMasterTable;
    }
*/
    // RO регистры идут со слейва в мастер
    void syncReg_ro( const regtype_unsigned dummy1, const regsize_8  dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        auto pSlave = getSlaveTable();
        if (!pSlave->checkRegUpdate(idxSlave))
            return;

        auto val = pSlave->getRegVal(idxSlave);
        m_masterTable->setRegVal( idxMaster, val );
    }

    void syncReg_ro( const regtype_unsigned dummy1, const regsize_16 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        auto pSlave = getSlaveTable();
        if (!pSlave->checkReg16Update(idxSlave))
            return;

        auto val = pSlave->getReg16Val(idxSlave);
        m_masterTable->setReg16Val( idxMaster, val );
    }

    void syncReg_ro( const regtype_unsigned dummy1, const regsize_32 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        auto pSlave = getSlaveTable();
        if (!pSlave->checkReg32Update(idxSlave))
            return;

        auto val = pSlave->getReg32Val(idxSlave);
        m_masterTable->setReg32Val( idxMaster, val );
    }

    void syncReg_ro( const regtype_signed dummy1, const regsize_8 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        syncReg_ro( regtype_unsigned(), dummy2, idxMaster, idxSlave );
    }

    void syncReg_ro( const regtype_signed dummy1, const regsize_16 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        syncReg_ro( regtype_unsigned(), dummy2, idxMaster, idxSlave );
    }

    void syncReg_ro( const regtype_signed dummy1, const regsize_32 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        syncReg_ro( regtype_unsigned(), dummy2, idxMaster, idxSlave );
    }

    void syncReg_ro( const regtype_float dummy1, const regsize_32 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        syncReg_ro( regtype_unsigned(), dummy2, idxMaster, idxSlave );
    }


    // RW регистры идут с мастера на слейв
    void syncReg_rw( const regtype_unsigned dummy1, const regsize_8  dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        if (!m_masterTable->checkRegUpdate(idxMaster))
            return;

        auto val = m_masterTable->getRegVal(idxMaster);

        auto pSlave = getSlaveTable();
        pSlave->setRegVal( idxSlave, val );
    }

    void syncReg_rw( const regtype_unsigned dummy1, const regsize_16 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        if (!m_masterTable->checkReg16Update(idxMaster))
            return;

        auto val = m_masterTable->getReg16Val(idxMaster);

        auto pSlave = getSlaveTable();
        pSlave->setReg16Val( idxSlave, val );
    }

    void syncReg_rw( const regtype_unsigned dummy1, const regsize_32 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        if (!m_masterTable->checkReg32Update(idxMaster))
            return;

        auto val = m_masterTable->getReg32Val(idxMaster);

        auto pSlave = getSlaveTable();
        pSlave->setReg32Val( idxSlave, val );
    }

    void syncReg_rw( const regtype_signed dummy1, const regsize_8 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        syncReg_rw( regtype_unsigned(), dummy2, idxMaster, idxSlave );
    }

    void syncReg_rw( const regtype_signed dummy1, const regsize_16 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        syncReg_rw( regtype_unsigned(), dummy2, idxMaster, idxSlave );
    }

    void syncReg_rw( const regtype_signed dummy1, const regsize_32 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        syncReg_rw( regtype_unsigned(), dummy2, idxMaster, idxSlave );
    }

    void syncReg_rw( const regtype_float dummy1, const regsize_32 dummy2, uint8_t idxMaster, uint8_t idxSlave )
    {
        syncReg_rw( regtype_unsigned(), dummy2, idxMaster, idxSlave );
    }


protected:

    virtual milliganjubus::IMilliRegTable * getSlaveTable() = 0;

    volatile bool m_roSyncEnabled = true;
    volatile bool m_rwSyncEnabled = true;


    //milliganjubus::IMilliRegTable *m_masterTable;
};


} // namespace rdlc



#endif // RDLC_CONTRIB_USE_MILLIREGTABLE_SLAVE_BASE


#endif /* RDLC_SUPPORT_HEADER__58F2AA91_CC98_4E4C_A448_789A164A7EC0__INCLUDED__ */
