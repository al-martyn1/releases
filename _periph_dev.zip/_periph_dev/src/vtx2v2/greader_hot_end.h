#define ro_min 0x00

//$ROBEGIN
#define ro_heater_mode_s8         0x00 // Состояние нагревателя
#define ro_motor_current_u8       0x01 // Ток мотора, в 0.1 А
#define ro_heater_temp_s16_0      0x02 // Температура нагревателя
#define ro_heater_temp_s16_1      0x03
//$ROEND
#define ro_max 0x03

#define rw_min 0x80

//$RWBEGIN
#define rw_extruder_speed_ctrl_s8 0x80 // Мотор экструдера туда-сюда, -100 - 100, 0 - ничего не делать
#define rw_heater_ctrl_s8         0x81 // Управление нагревателем
//$RWEND
#define rw_max 0x81

