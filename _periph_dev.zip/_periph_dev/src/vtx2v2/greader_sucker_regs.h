#define ro_min 0x00

//$ROBEGIN
#define ro_sucker_mode_u8                          0x00 // Текущий режим работы импеллера, и признаки ошибки - SuckerMode | SuckerErrorFlags
#define ro_pressure_diff_u8                        0x01 // Текущая разница давлений, в 1/10 миллибар
#define ro_esc_current_u8                          0x02 // Ток импеллера, в 0.01 А
#define ro_esc_pwm_u8                              0x03 // Длина импульса PWM, деленная на 10
#define ro_surface_sensors_u8                      0x04 // Датчики поверхности - младшие 4 бита
#define ro_sucker_pid_scale_proportional_current_f32_0 0x05 // Кп
#define ro_sucker_pid_scale_proportional_current_f32_1 0x06
#define ro_sucker_pid_scale_proportional_current_f32_2 0x07
#define ro_sucker_pid_scale_proportional_current_f32_3 0x08
#define ro_sucker_pid_scale_integral_current_f32_0 0x09 // Ки
#define ro_sucker_pid_scale_integral_current_f32_1 0x0A
#define ro_sucker_pid_scale_integral_current_f32_2 0x0B
#define ro_sucker_pid_scale_integral_current_f32_3 0x0C
#define ro_sucker_pid_scale_differential_current_f32_0 0x0D // Кд
#define ro_sucker_pid_scale_differential_current_f32_1 0x0E
#define ro_sucker_pid_scale_differential_current_f32_2 0x0F
#define ro_sucker_pid_scale_differential_current_f32_3 0x10
//$ROEND
#define ro_max 0x10

#define rw_min 0x80

//$RWBEGIN
#define rw_sucker_ctrl_u8                          0x80 // Установка режима работы импеллера
#define rw_pressure_diff_ctrl_u8                   0x81 // Требуемая разница давлений, в 1/10 миллибар
#define rw_psensor_emergency_mode_ctrl_u8          0x82 // Поведение при отказе датчика давления: 0 - работать на средних оборотах, 1 - выключиться
#define rw_sucker_pid_scale_proportional_f32_0     0x83 // Кп
#define rw_sucker_pid_scale_proportional_f32_1     0x84
#define rw_sucker_pid_scale_proportional_f32_2     0x85
#define rw_sucker_pid_scale_proportional_f32_3     0x86
#define rw_sucker_pid_scale_integral_f32_0         0x87 // Ки
#define rw_sucker_pid_scale_integral_f32_1         0x88
#define rw_sucker_pid_scale_integral_f32_2         0x89
#define rw_sucker_pid_scale_integral_f32_3         0x8A
#define rw_sucker_pid_scale_differential_f32_0     0x8B // Кд
#define rw_sucker_pid_scale_differential_f32_1     0x8C
#define rw_sucker_pid_scale_differential_f32_2     0x8D
#define rw_sucker_pid_scale_differential_f32_3     0x8E
#define rw_impeller_esc_current_limit_u8           0x8F // Максимально допустимый ток импеллера, в 0.1 А
#define rw_impeller_esc_pwm_interval_off_u16_0     0x90 // Время импульса, мс, при котором ESC гарантированно останавливает импеллер
#define rw_impeller_esc_pwm_interval_off_u16_1     0x91
#define rw_impeller_esc_pwm_interval_idle_u16_0    0x92 // Время импульса, мс, для режима холостого хода
#define rw_impeller_esc_pwm_interval_idle_u16_1    0x93
#define rw_impeller_esc_pwm_interval_max_u16_0     0x94 // Время импульса, мс, для максимально допустимой скорости импеллера
#define rw_impeller_esc_pwm_interval_max_u16_1     0x95
//$RWEND
#define rw_max 0x95

