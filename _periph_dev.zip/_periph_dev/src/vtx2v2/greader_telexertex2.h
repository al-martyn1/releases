#define ro_min 0x00

//$ROBEGIN
#define ro_robot_id_u8                                0x00 // идентификатор робота (он же - ganjubus-адрес)
#define ro_slaves_left_u8                             0x01 // Слейвы на левой ноге
#define ro_slaves_right_u8                            0x02 // Слейвы на правой ноге
#define ro_battery_voltage_millivolts_u16_0           0x03 // общее напряжение на выходе
#define ro_battery_voltage_millivolts_u16_1           0x04
#define ro_battery_charge_percent_u8                  0x05 // заряд в процентах
#define ro_battery_run_time_to_empty_minutes_u16_0    0x06 // предполагаемое время работы на основе текущих данных
#define ro_battery_run_time_to_empty_minutes_u16_1    0x07
#define ro_battery_average_time_to_empty_minutes_u16_0 0x08 // предполагаемое время работы на основе среднего тока
#define ro_battery_average_time_to_empty_minutes_u16_1 0x09
#define ro_battery_safety_status_u32_0                0x0A // битовое поле, см. SafetyStatusBits
#define ro_battery_safety_status_u32_1                0x0B
#define ro_battery_safety_status_u32_2                0x0C
#define ro_battery_safety_status_u32_3                0x0D
#define ro_battery_pf_status_u32_0                    0x0E // битовое поле, см. PfStatusBits
#define ro_battery_pf_status_u32_1                    0x0F
#define ro_battery_pf_status_u32_2                    0x10
#define ro_battery_pf_status_u32_3                    0x11
#define ro_battery_temperature_decikelvin_u16_0       0x12 // это 0.1 Кельвина
#define ro_battery_temperature_decikelvin_u16_1       0x13
#define ro_battery_current_milliamp_s16_0             0x14 // ток в мА
#define ro_battery_current_milliamp_s16_1             0x15
#define ro_battery_is_voltage_ok_u8                   0x16 // если true, то напряжение находится в допустимом интервале
#define ro_link_channels_u8                           0x17 // Текущие номера каналов управления и видео
#define ro_video_transmitter_power_u8                 0x18 // Текущая мощность передатчика видеосигнала. Значение от 0 до 255
#define ro_link_activity_u8                           0x19 // Состояние on/off аудио/видео/шифрования
#define ro_video_scrambling_key_ctrl_u16_0            0x1A // Текущий ключ шифрования видеопотока
#define ro_video_scrambling_key_ctrl_u16_1            0x1B
#define ro_active_camera_no_u8                        0x1C // Активная камера
#define ro_tvko_azimuth_motor_current_s8              0x1D // Текущий ток мотора азимута в попугаях
#define ro_tvko_elevation_motor_current_s8            0x1E // Текущий ток мотора возвышения в попугаях
#define ro_tvko_temperature_u8                        0x1F // температура
#define ro_tvko_status_u8                             0x20 // статус платы
#define ro_gyro_pitch_angle_s16_0                     0x21 // Тангаж
#define ro_gyro_pitch_angle_s16_1                     0x22
#define ro_gyro_roll_angle_s16_0                      0x23 // Крен
#define ro_gyro_roll_angle_s16_1                      0x24
#define ro_gyro_yaw_angle_s16_0                       0x25 // Рыскание/Курсовой угол/Азимут
#define ro_gyro_yaw_angle_s16_1                       0x26
#define ro_accel_x_s16_0                              0x27 // Ускорение по X
#define ro_accel_x_s16_1                              0x28
#define ro_accel_y_s16_0                              0x29 // Ускорение по Y
#define ro_accel_y_s16_1                              0x2A
#define ro_accel_z_s16_0                              0x2B // Ускорение по Z
#define ro_accel_z_s16_1                              0x2C
#define ro_hot_end_left_heater_mode_s8                0x2D // Состояние нагревателя
#define ro_hot_end_left_motor_current_u8              0x2E // Ток мотора, в 0.1 А
#define ro_hot_end_left_heater_temp_s16_0             0x2F // Температура нагревателя
#define ro_hot_end_left_heater_temp_s16_1             0x30
#define ro_hot_end_right_heater_mode_s8               0x31 // Состояние нагревателя
#define ro_hot_end_right_motor_current_u8             0x32 // Ток мотора, в 0.1 А
#define ro_hot_end_right_heater_temp_s16_0            0x33 // Температура нагревателя
#define ro_hot_end_right_heater_temp_s16_1            0x34
#define ro_sucker_pid_scale_proportional_current_f32_0 0x35 // Кп
#define ro_sucker_pid_scale_proportional_current_f32_1 0x36
#define ro_sucker_pid_scale_proportional_current_f32_2 0x37
#define ro_sucker_pid_scale_proportional_current_f32_3 0x38
#define ro_sucker_pid_scale_integral_current_f32_0    0x39 // Ки
#define ro_sucker_pid_scale_integral_current_f32_1    0x3A
#define ro_sucker_pid_scale_integral_current_f32_2    0x3B
#define ro_sucker_pid_scale_integral_current_f32_3    0x3C
#define ro_sucker_pid_scale_differential_current_f32_0 0x3D // Кд
#define ro_sucker_pid_scale_differential_current_f32_1 0x3E
#define ro_sucker_pid_scale_differential_current_f32_2 0x3F
#define ro_sucker_pid_scale_differential_current_f32_3 0x40
#define ro_foot_left1_sucker_mode_u8                  0x41 // Текущий режим работы импеллера, и признаки ошибки - SuckerMode | SuckerErrorFlags
#define ro_foot_left1_pressure_diff_u8                0x42 // Текущая разница давлений, в 1/10 миллибар
#define ro_foot_left1_esc_current_u8                  0x43 // Ток импеллера, в 0.01 А
#define ro_foot_left1_esc_pwm_u8                      0x44 // Длина импульса PWM, деленная на 10
#define ro_foot_left1_surface_sensors_u8              0x45 // Датчики поверхности - младшие 4 бита
#define ro_foot_left2_sucker_mode_u8                  0x46 // Текущий режим работы импеллера, и признаки ошибки - SuckerMode | SuckerErrorFlags
#define ro_foot_left2_pressure_diff_u8                0x47 // Текущая разница давлений, в 1/10 миллибар
#define ro_foot_left2_esc_current_u8                  0x48 // Ток импеллера, в 0.01 А
#define ro_foot_left2_esc_pwm_u8                      0x49 // Длина импульса PWM, деленная на 10
#define ro_foot_left2_surface_sensors_u8              0x4A // Датчики поверхности - младшие 4 бита
#define ro_foot_right1_sucker_mode_u8                 0x4B // Текущий режим работы импеллера, и признаки ошибки - SuckerMode | SuckerErrorFlags
#define ro_foot_right1_pressure_diff_u8               0x4C // Текущая разница давлений, в 1/10 миллибар
#define ro_foot_right1_esc_current_u8                 0x4D // Ток импеллера, в 0.01 А
#define ro_foot_right1_esc_pwm_u8                     0x4E // Длина импульса PWM, деленная на 10
#define ro_foot_right1_surface_sensors_u8             0x4F // Датчики поверхности - младшие 4 бита
#define ro_foot_right2_sucker_mode_u8                 0x50 // Текущий режим работы импеллера, и признаки ошибки - SuckerMode | SuckerErrorFlags
#define ro_foot_right2_pressure_diff_u8               0x51 // Текущая разница давлений, в 1/10 миллибар
#define ro_foot_right2_esc_current_u8                 0x52 // Ток импеллера, в 0.01 А
#define ro_foot_right2_esc_pwm_u8                     0x53 // Длина импульса PWM, деленная на 10
#define ro_foot_right2_surface_sensors_u8             0x54 // Датчики поверхности - младшие 4 бита
#define ro_joint_left1_current_angle_u16_0            0x55 // Текущий угол
#define ro_joint_left1_current_angle_u16_1            0x56
#define ro_joint_left1_state_counter_u8               0x57 // Счетчик выполнения, инкрементируется на 1 после начала выполнения команды, и еще на 1 при окончании, т.о. если нечёт - то в процессе выполнения
#define ro_joint_left1_negative_angle_limit_u16_0     0x58 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define ro_joint_left1_negative_angle_limit_u16_1     0x59
#define ro_joint_left1_positive_angle_limit_u16_0     0x5A // Ограничение угла для движения с положительной скоростью, 0-1024
#define ro_joint_left1_positive_angle_limit_u16_1     0x5B
#define ro_joint_left1_no_movement_flag_u8            0x5C // Флаг отсутствия движения - шарнир не смог
#define ro_joint_left2_current_angle_u16_0            0x5D // Текущий угол
#define ro_joint_left2_current_angle_u16_1            0x5E
#define ro_joint_left2_state_counter_u8               0x5F // Счетчик выполнения, инкрементируется на 1 после начала выполнения команды, и еще на 1 при окончании, т.о. если нечёт - то в процессе выполнения
#define ro_joint_left2_negative_angle_limit_u16_0     0x60 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define ro_joint_left2_negative_angle_limit_u16_1     0x61
#define ro_joint_left2_positive_angle_limit_u16_0     0x62 // Ограничение угла для движения с положительной скоростью, 0-1024
#define ro_joint_left2_positive_angle_limit_u16_1     0x63
#define ro_joint_left2_no_movement_flag_u8            0x64 // Флаг отсутствия движения - шарнир не смог
#define ro_joint_right1_current_angle_u16_0           0x65 // Текущий угол
#define ro_joint_right1_current_angle_u16_1           0x66
#define ro_joint_right1_state_counter_u8              0x67 // Счетчик выполнения, инкрементируется на 1 после начала выполнения команды, и еще на 1 при окончании, т.о. если нечёт - то в процессе выполнения
#define ro_joint_right1_negative_angle_limit_u16_0    0x68 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define ro_joint_right1_negative_angle_limit_u16_1    0x69
#define ro_joint_right1_positive_angle_limit_u16_0    0x6A // Ограничение угла для движения с положительной скоростью, 0-1024
#define ro_joint_right1_positive_angle_limit_u16_1    0x6B
#define ro_joint_right1_no_movement_flag_u8           0x6C // Флаг отсутствия движения - шарнир не смог
#define ro_joint_right2_current_angle_u16_0           0x6D // Текущий угол
#define ro_joint_right2_current_angle_u16_1           0x6E
#define ro_joint_right2_state_counter_u8              0x6F // Счетчик выполнения, инкрементируется на 1 после начала выполнения команды, и еще на 1 при окончании, т.о. если нечёт - то в процессе выполнения
#define ro_joint_right2_negative_angle_limit_u16_0    0x70 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define ro_joint_right2_negative_angle_limit_u16_1    0x71
#define ro_joint_right2_positive_angle_limit_u16_0    0x72 // Ограничение угла для движения с положительной скоростью, 0-1024
#define ro_joint_right2_positive_angle_limit_u16_1    0x73
#define ro_joint_right2_no_movement_flag_u8           0x74 // Флаг отсутствия движения - шарнир не смог
#define ro_step_state_counter_u8                      0x75 // Счетчик работы
#define ro_step_status_u8                             0x76 // Результат шага
//$ROEND
#define ro_max 0x76

#define rw_min 0x80

//$RWBEGIN
#define rw_battery_power_off_u8                       0x80 // программное выключение
#define rw_control_channel_ctrl_u8                    0x81 // Установка номера канала управления
#define rw_video_channel_ctrl_u8                      0x82 // Установка номера канала видео
#define rw_video_transmitter_power_ctrl_u8            0x83 // Мощность передатчика видеосигнала. Значение от 0 до 255
#define rw_video_activity_ctrl_u8                     0x84 // Включение/выключение видео
#define rw_scrambling_activity_ctrl_u8                0x85 // Включение/выключение шифрования
#define rw_video_scrambling_key_ctrl_u16_0            0x86 // Установка ключа шифрования видеопотока
#define rw_video_scrambling_key_ctrl_u16_1            0x87
#define rw_active_camera_no_ctrl_u8                   0x88 // Установка активной камеры
#define rw_tvko_azimuth_speed_ctrl_s8                 0x89 // Управление поворотом по азимуту, скорость и направление, -100 - 100
#define rw_tvko_elevation_speed_ctrl_s8               0x8A // Управление поворотом по возвышению, скорость и направление, -100 - 100
#define rw_tvko_camera_power_u8                       0x8B // on = 1/off = 0
#define rw_tvko_digital_zoom_u8                       0x8C // on = 1/off = 0
#define rw_tvko_auto_focus_u8                         0x8D // on = 1/off = 0
#define rw_tvko_zoom_speed_s8                         0x8E // от -8 до 8
#define rw_tvko_focus_speed_s8                        0x8F // от -8 до 8
#define rw_tvko_infrared_correction_u8                0x90 // standart = 0, ir_light = 0x01
#define rw_tvko_white_balance_u8                      0x91 // auto = 0, manual = 0x05, sodium lamp = 0x07
#define rw_tvko_red_gain_u8                           0x92 // от 0 до 255
#define rw_tvko_blue_gain_u8                          0x93 // от 0 до 255
#define rw_tvko_automatic_exposure_u8                 0x94 // full auto = 0, manual = 0x03, shutter_priority = 0x0a, iris_priority = 0x0b, bright = 0x0d
#define rw_tvko_shutter_u8                            0x95 // от 0x0 до 0x15, '0x0' - 1/1sec; '0x15' - 1/10000sec
#define rw_tvko_iris_u8                               0x96 // от 0x0 до 0x11, '0x0' - close; '0x01' - f28; '0x11' - f1.6
#define rw_tvko_gain_u8                               0x97 // от 0x0 до 0x0f
#define rw_tvko_bright_u8                             0x98 // от 0x0 до 0x1f
#define rw_tvko_backlight_compensation_u8             0x99 // on = 1/off = 0
#define rw_tvko_defog_u8                              0x9A // on = 1/off = 0
#define rw_tvko_high_resolution_mode_u8               0x9B // on = 1/off = 0
#define rw_tvko_mirror_u8                             0x9C // on = 1/off = 0
#define rw_tvko_black_white_u8                        0x9D // on = 1/off = 0
#define rw_tvko_flip_u8                               0x9E // on = 1/off = 0
#define rw_tvko_infrared_mode_u8                      0x9F // on = 1/off = 0
#define rw_tvko_auto_infrared_mode_u8                 0xA0 // on = 1/off = 0
#define rw_tvko_auto_infrared_mode_threshold_u8       0xA1 // тут пределы не нашёл в даташите
#define rw_tvko_stabilizer_u8                         0xA2 // on = 1/off = 0/hold = 2
#define rw_tvko_zoom_direct_position_u16_0            0xA3 // от 0 до не знаю
#define rw_tvko_zoom_direct_position_u16_1            0xA4
#define rw_hot_end_left_extruder_speed_ctrl_s8        0xA5 // Мотор экструдера туда-сюда, -100 - 100, 0 - ничего не делать
#define rw_hot_end_left_heater_ctrl_s8                0xA6 // Управление нагревателем
#define rw_hot_end_right_extruder_speed_ctrl_s8       0xA7 // Мотор экструдера туда-сюда, -100 - 100, 0 - ничего не делать
#define rw_hot_end_right_heater_ctrl_s8               0xA8 // Управление нагревателем
#define rw_pressure_diff_left_ctrl_u8                 0xA9 // Требуемая разница давлений для левой стопы, 1/10 миллибар
#define rw_pressure_diff_right_ctrl_u8                0xAA // Требуемая разница давлений для правой стопы, 1/10 миллибар
#define rw_psensor_emergency_mode_ctrl_u8             0xAB // Поведение при отказе датчика давления: 0 - работать на средних оборотах, 1 - выключиться
#define rw_sucker_pid_scale_proportional_f32_0        0xAC // Кп
#define rw_sucker_pid_scale_proportional_f32_1        0xAD
#define rw_sucker_pid_scale_proportional_f32_2        0xAE
#define rw_sucker_pid_scale_proportional_f32_3        0xAF
#define rw_sucker_pid_scale_integral_f32_0            0xB0 // Ки
#define rw_sucker_pid_scale_integral_f32_1            0xB1
#define rw_sucker_pid_scale_integral_f32_2            0xB2
#define rw_sucker_pid_scale_integral_f32_3            0xB3
#define rw_sucker_pid_scale_differential_f32_0        0xB4 // Кд
#define rw_sucker_pid_scale_differential_f32_1        0xB5
#define rw_sucker_pid_scale_differential_f32_2        0xB6
#define rw_sucker_pid_scale_differential_f32_3        0xB7
#define rw_impeller_esc_current_limit_u8              0xB8 // Максимально допустимый ток импеллера, в 0.1 А
#define rw_impeller_esc_pwm_interval_off_u16_0        0xB9 // Время импульса, мс, при котором ESC гарантированно останавливает импеллер
#define rw_impeller_esc_pwm_interval_off_u16_1        0xBA
#define rw_impeller_esc_pwm_interval_idle_u16_0       0xBB // Время импульса, мс, для режима холостого хода
#define rw_impeller_esc_pwm_interval_idle_u16_1       0xBC
#define rw_impeller_esc_pwm_interval_max_u16_0        0xBD // Время импульса, мс, для максимально допустимой скорости импеллера
#define rw_impeller_esc_pwm_interval_max_u16_1        0xBE
#define rw_foot_left1_sucker_ctrl_u8                  0xBF // Установка режима работы импеллера
#define rw_foot_left2_sucker_ctrl_u8                  0xC0 // Установка режима работы импеллера
#define rw_foot_right1_sucker_ctrl_u8                 0xC1 // Установка режима работы импеллера
#define rw_foot_right2_sucker_ctrl_u8                 0xC2 // Установка режима работы импеллера
#define rw_joint_left1_target_angle_u16_0             0xC3 // Целевой угол, 0-1024
#define rw_joint_left1_target_angle_u16_1             0xC4
#define rw_joint_left1_speed_s8                       0xC5 // Скорость движения, в попугаях/процентах от макс возможной, знак задает направление
#define rw_joint_left1_mode_ctrl_u8                   0xC6 // Режим движения - 0 - Неподвижность, 1 - Скорость, 2 - Позиция, 3 - Движение в 0 (см. тип JointMode в vertex_types.rdl)
#define rw_joint_left1_current_limit_u8               0xC7 // Ограничение по току, в 0.1А
#define rw_joint_left1_negative_angle_limit_u16_0     0xC8 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define rw_joint_left1_negative_angle_limit_u16_1     0xC9
#define rw_joint_left1_positive_angle_limit_u16_0     0xCA // Ограничение угла для движения с положительной скоростью, 0-1024
#define rw_joint_left1_positive_angle_limit_u16_1     0xCB
#define rw_joint_left1_save_data_to_flash_u8          0xCC // true - инициировать сохранение во флеш
#define rw_joint_left1_clear_flash_u8                 0xCD // true - очистить записанные во флеш данные
#define rw_joint_left1_no_movement_period_u8          0xCE // Период стояния на месте в десятках мс, прежде чем будет подан флаг неуспеха достижения позиции
#define rw_joint_left2_target_angle_u16_0             0xCF // Целевой угол, 0-1024
#define rw_joint_left2_target_angle_u16_1             0xD0
#define rw_joint_left2_speed_s8                       0xD1 // Скорость движения, в попугаях/процентах от макс возможной, знак задает направление
#define rw_joint_left2_mode_ctrl_u8                   0xD2 // Режим движения - 0 - Неподвижность, 1 - Скорость, 2 - Позиция, 3 - Движение в 0 (см. тип JointMode в vertex_types.rdl)
#define rw_joint_left2_current_limit_u8               0xD3 // Ограничение по току, в 0.1А
#define rw_joint_left2_negative_angle_limit_u16_0     0xD4 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define rw_joint_left2_negative_angle_limit_u16_1     0xD5
#define rw_joint_left2_positive_angle_limit_u16_0     0xD6 // Ограничение угла для движения с положительной скоростью, 0-1024
#define rw_joint_left2_positive_angle_limit_u16_1     0xD7
#define rw_joint_left2_save_data_to_flash_u8          0xD8 // true - инициировать сохранение во флеш
#define rw_joint_left2_clear_flash_u8                 0xD9 // true - очистить записанные во флеш данные
#define rw_joint_left2_no_movement_period_u8          0xDA // Период стояния на месте в десятках мс, прежде чем будет подан флаг неуспеха достижения позиции
#define rw_joint_right1_target_angle_u16_0            0xDB // Целевой угол, 0-1024
#define rw_joint_right1_target_angle_u16_1            0xDC
#define rw_joint_right1_speed_s8                      0xDD // Скорость движения, в попугаях/процентах от макс возможной, знак задает направление
#define rw_joint_right1_mode_ctrl_u8                  0xDE // Режим движения - 0 - Неподвижность, 1 - Скорость, 2 - Позиция, 3 - Движение в 0 (см. тип JointMode в vertex_types.rdl)
#define rw_joint_right1_current_limit_u8              0xDF // Ограничение по току, в 0.1А
#define rw_joint_right1_negative_angle_limit_u16_0    0xE0 // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define rw_joint_right1_negative_angle_limit_u16_1    0xE1
#define rw_joint_right1_positive_angle_limit_u16_0    0xE2 // Ограничение угла для движения с положительной скоростью, 0-1024
#define rw_joint_right1_positive_angle_limit_u16_1    0xE3
#define rw_joint_right1_save_data_to_flash_u8         0xE4 // true - инициировать сохранение во флеш
#define rw_joint_right1_clear_flash_u8                0xE5 // true - очистить записанные во флеш данные
#define rw_joint_right1_no_movement_period_u8         0xE6 // Период стояния на месте в десятках мс, прежде чем будет подан флаг неуспеха достижения позиции
#define rw_joint_right2_target_angle_u16_0            0xE7 // Целевой угол, 0-1024
#define rw_joint_right2_target_angle_u16_1            0xE8
#define rw_joint_right2_speed_s8                      0xE9 // Скорость движения, в попугаях/процентах от макс возможной, знак задает направление
#define rw_joint_right2_mode_ctrl_u8                  0xEA // Режим движения - 0 - Неподвижность, 1 - Скорость, 2 - Позиция, 3 - Движение в 0 (см. тип JointMode в vertex_types.rdl)
#define rw_joint_right2_current_limit_u8              0xEB // Ограничение по току, в 0.1А
#define rw_joint_right2_negative_angle_limit_u16_0    0xEC // Ограничение угла для движения с отрицательной скоростью, 0-1024
#define rw_joint_right2_negative_angle_limit_u16_1    0xED
#define rw_joint_right2_positive_angle_limit_u16_0    0xEE // Ограничение угла для движения с положительной скоростью, 0-1024
#define rw_joint_right2_positive_angle_limit_u16_1    0xEF
#define rw_joint_right2_save_data_to_flash_u8         0xF0 // true - инициировать сохранение во флеш
#define rw_joint_right2_clear_flash_u8                0xF1 // true - очистить записанные во флеш данные
#define rw_joint_right2_no_movement_period_u8         0xF2 // Период стояния на месте в десятках мс, прежде чем будет подан флаг неуспеха достижения позиции
#define rw_step_command_u8                            0xF3 // Команда шагания
#define rw_step_angle_or_distance_u16_0               0xF4 // Длина шага или угол, см StepCommand::distanceFlag
#define rw_step_angle_or_distance_u16_1               0xF5
#define rw_step_height_u16_0                          0xF6 // Высота шага или угол, см. StepCommand::heightFlag
#define rw_step_height_u16_1                          0xF7
//$RWEND
#define rw_max 0xF7

