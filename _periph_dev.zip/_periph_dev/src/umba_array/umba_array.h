#pragma once

#include "project_config.h"

#include <iterator>
#include <cstddef>
#include <string.h>

namespace umba
{
    //Интерфейс-обёртка над Си-массивом,
    //позволяет абстрагироваться от размера массива
    //реализует следующее:
    // - доступ к элементу по индексу с run-time проверкой выхода за границу []
    // - метод size для получения длины массива
    // - метод data для получения сырого указателя
    // - определяет типы итераторов, ссылки и указателя на параметр шаблона
    // - создание массива на основе перемещенных (moved) временных объектов Array<A, 2> arr( A(1,2,3), A(4,5,6) );
    // - создание массива на основе скопированных объектов

    // - методы для получения итераторов и реверсивных итераторов:
    //   - begin     - итератор на начало umba_array
    //   - cbegin    - константный итератор на начало umba_array
    //   - rbegin    - реверсивный итератор на последний элемент umba_array
    //   - crbegin   - константный реверсивный итератор на последний элемент umba_array

    //   - end       - итератор на элемент, следующий за последним umba_array
    //   - cend      - константный итератор на элемент, следующий за последним umba_array
    //   - rend      - реверсивный итератор на элемент, следующий за первым umba_array
    //   - crend     - константный реверсивный итератор на элемент, следующий за первым umba_array

    template< typename ValueType, typename PointerType = ValueType *, typename ReferenceType = ValueType& >
    class ProtectedIterator;

    //Интерфейс для umba-array, привязан только к типу данных
    template<typename T>
    class IArray
    {

    public:

        using ValueType                     = T;
        using SizeType                      = std::size_t;
        using difference_type               = std::ptrdiff_t;
        using Reference                     = ValueType&;
        using ConstReference                = const ValueType&;
        using Pointer                       = ValueType*;
        using ConstPointer                  = const ValueType*;

#ifndef UMBA_ARRAY_NO_DEBUG

        using Iterator                      = ProtectedIterator<T>;
        using ConstIterator                 = ProtectedIterator<T, const T*, const T&>;
#else

        using Iterator                      = Pointer;
        using ConstIterator                 = ConstPointer;
#endif
        using ReverseIterator               = std::reverse_iterator<Iterator>;
        using ConstReverseIterator          = std::reverse_iterator<ConstIterator>;

        virtual Iterator begin() = 0; //итератор на первый элемент
        virtual Iterator end() = 0;   //итератор на элемент, следующий за последним
        virtual Iterator getIterator( SizeType num ) = 0; //итератор на произвольный элемент

        virtual ConstIterator begin() const = 0; //константный итератор на первый элемент
        virtual ConstIterator end() const = 0;   //константный итератор на элемент, следующий за последним
        virtual ConstIterator getIterator( SizeType num ) const = 0; //константный итератор на произвольный элемент

        virtual ConstIterator cbegin() const = 0;  //константный итератор на первый элемент
        virtual ConstIterator cend() const = 0;    //константный итератор на элемент, следующий за последним

        virtual ReverseIterator rbegin() = 0;    //реверсивный итератор на первый с конца элемент
        virtual ReverseIterator rend() = 0;      //реверсивный итератор на элемент, следующий за первым
        virtual ReverseIterator getReverseIterator( SizeType num ) = 0; //реверсивный итератор на произвольный элемент

        virtual ConstReverseIterator rbegin() const = 0;  //константный реверсивный итератор на первый с конца элемент
        virtual ConstReverseIterator rend() const = 0;    //константный реверсивный итератор на элемент, следующий за первым
        virtual ConstReverseIterator getReverseIterator( SizeType num ) const = 0; //константный реверсивный итератор на произвольный элемент

        virtual ConstReverseIterator crbegin() const = 0;   //константный реверсивный итератор на первый с конца элемент
        virtual ConstReverseIterator crend() const = 0;     //константный реверсивный итератор на элемент, следующий за первым

        virtual SizeType size() const = 0; // длина массива

        // используемая длина - просто выставляется вручную
        virtual SizeType usedSize() const = 0;
        virtual void setUsedSize( SizeType s) = 0;

        virtual Reference operator[]( SizeType ) = 0; // доступ к элементам по индексу с проверкой в run-time на выход за границы

        virtual ConstReference operator[]( SizeType ) const = 0; // доступ к элементам по индексу с проверкой в run-time на выход за границы

        virtual Pointer data() = 0; // сырой указатель на данные

        virtual ConstPointer data() const = 0; // сырой константный указатель на данные

        virtual ~IArray(){};
    };


    namespace additional
    {
        template<typename T1>
        struct IsCharPointer
        {
        };

        template<>
        struct IsCharPointer<const char>
        {
            using type = bool;
        };

        template<>
        struct IsCharPointer<char>
        {
            using type = bool;
        };
    }


    //класс-обёртка над указателем на Си-массив. Хранит указатель и длину
    template<typename T>
    class ArrayView : public IArray<T>
    {
    public:

        using Iterator              = typename IArray<T>::Iterator;
        using ConstIterator         = typename IArray<T>::ConstIterator;
        using ReverseIterator       = typename IArray<T>::ReverseIterator;
        using ConstReverseIterator  = typename IArray<T>::ConstReverseIterator;
        using SizeType              = typename IArray<T>::SizeType;
        using Reference             = typename IArray<T>::Reference;
        using ConstReference        = typename IArray<T>::ConstReference;
        using Pointer               = typename IArray<T>::Pointer;
        using ConstPointer          = typename IArray<T>::ConstPointer;


        ArrayView( T * data, SizeType len ) : m_data( data ), m_len( len )
        {

        }

        // некопируемо
        ArrayView( const ArrayView & ) = delete;
        ArrayView & operator=( const ArrayView & ) = delete;

        //только для тех, кто умеет каститься к чар и констчар
        template< typename T2, typename = typename additional::IsCharPointer<T2>::type >
        explicit ArrayView( T2 * data ) : m_data( data ),
                                         m_len( strlen( data ) )
        {

        }

        virtual Iterator begin() override
        {
            return makeIterator<Iterator>( m_data, m_data, &m_data[m_len] );
        }

        virtual Iterator end() override
        {
            return makeIterator<Iterator>( &m_data[m_len], m_data, &m_data[m_len] );
        }
        virtual Iterator getIterator( SizeType num ) override
        {
            return makeIterator<Iterator>( &m_data[num], m_data, &m_data[m_len] );
        }

        virtual ConstIterator begin() const override
        {
            return makeIterator<ConstIterator>( m_data, m_data, &m_data[m_len] );
        }

        virtual ConstIterator end() const override
        {
            return makeIterator<ConstIterator>( &m_data[m_len], m_data, &m_data[m_len] );
        }
        virtual ConstIterator getIterator( SizeType num ) const override
        {
            return makeIterator<ConstIterator>( &m_data[num], m_data, &m_data[m_len] );
        }


        virtual ConstIterator cbegin() const override
        {
            return makeIterator<ConstIterator>( m_data, m_data, &m_data[m_len] );
        }

        virtual ConstIterator cend() const override
        {
            return makeIterator<ConstIterator>( &m_data[m_len], m_data, &m_data[m_len] );
        }

        virtual ReverseIterator rbegin() override
        {
            return ReverseIterator( begin() );
        }
        virtual ReverseIterator rend() override
        {
            return ReverseIterator( end() );
        }
        virtual ReverseIterator getReverseIterator( SizeType num ) override
        {
            return ReverseIterator( getIterator( num ) );
        }

        virtual ConstReverseIterator rbegin() const override
        {
            return ConstReverseIterator( begin() );
        }
        virtual ConstReverseIterator rend() const override
        {
            return ConstReverseIterator( end() );
        }
        virtual ConstReverseIterator getReverseIterator( SizeType num ) const override
        {
            return ConstReverseIterator( getIterator( num ) );
        }

        virtual ConstReverseIterator crbegin() const override
        {
            return ConstReverseIterator( cbegin() );
        }
        virtual ConstReverseIterator crend() const override
        {
            return ConstReverseIterator( cend() );
        }


        virtual SizeType size() const override
        {
            return m_len;
        }

        virtual SizeType usedSize() const override
        {
            return m_usedSize;
        }

        virtual void setUsedSize( SizeType s ) override
        {
            UMBA_ASSERT( s < m_len );
            m_usedSize = s;
        }

        virtual Reference operator[]( SizeType n ) override
        {
            UMBA_ASSERT( n < m_len );
            return m_data[n];
        }

        virtual ConstReference operator[]( SizeType n ) const override
        {
            UMBA_ASSERT( n < m_len );
            return m_data[n];
        }


        virtual Pointer data() override
        {
            return Pointer( m_data );
        }

        virtual ConstPointer data() const override
        {
            return ConstPointer( m_data );
        }

        virtual ~ArrayView(){};

    protected:


#ifndef UMBA_ARRAY_NO_DEBUG
        template<typename TIterType, typename TPointer>
        static TIterType makeIterator( TPointer self, TPointer begin, TPointer end )
        {
            return TIterType( self, begin, end );
        }
#else

        template<typename TIterType, typename TPointer>
        static TIterType makeIterator( TPointer self, TPointer begin, TPointer end )
        {
            ( void )begin;
            ( void )end;
            return TIterType( self );
        }
#endif

        T * m_data = nullptr;
        SizeType m_len = 0;

        SizeType m_usedSize = 0;
    };


    //Класс-обёртка над Си-массивом
    //реализует интерфейс IArray
    //параметрами шаблона имеет тип и длину
    template<typename T, std::size_t N>
    class Array : public ArrayView<T>
    {

    public:

        using Iterator              = typename IArray<T>::Iterator;
        using ConstIterator         = typename IArray<T>::ConstIterator;
        using ReverseIterator       = typename IArray<T>::ReverseIterator;
        using ConstReverseIterator  = typename IArray<T>::ConstReverseIterator;
        using SizeType              = typename IArray<T>::SizeType;
        using Reference             = typename IArray<T>::Reference;
        using ConstReference        = typename IArray<T>::ConstReference;
        using Pointer               = typename IArray<T>::Pointer;
        using ConstPointer          = typename IArray<T>::ConstPointer;

        Array() : ArrayView<T>( realType, N ),
                m_place()
        {
            Creator<N>::create( *this);
        }

        //конструктор с параметрами
        template<typename ... TCon>
        Array( TCon && ... t ) : ArrayView<T>( realType, N ),
            realType{t...}
        {
            const int32_t siz = N - sizeof ...( TCon );

            static_assert( (siz >= 0), "wrong nubmer of arguments passed to array" );

            //Creator<siz>::create( *this, 0, static_cast<TCon &&>( t )... );
        }


        //конструктор с параметрами с копированием
        template<typename ... TCon>
        Array( TCon & ... t ) : ArrayView<T>( realType, N ),
            realType{t...}
        {
            const int32_t siz = N - sizeof ...( TCon );

            static_assert( (siz >= 0), "wrong nubmer of arguments passed to array" );

            //Creator<siz>::create( *this, 0, static_cast<TCon &&>( t )... );
        }

        virtual ~Array(){};

    private:

        template<int32_t TNumToFull, typename TFake = void>
        class Creator
        {
        public:
            static void create( Array & a )
            {
                for( auto i = N - TNumToFull; i < N; i++ )
                {
                    a.ArrayView<T>::m_data[i] = T();
                }
            }
            static void create( Array & a, uint32_t n, T && first )
            {
                a.ArrayView<T>::m_data[n] = first;
                for( auto i = N - TNumToFull; i < N; i++ )
                {
                    a.ArrayView<T>::m_data[i] = T();
                }
            }
            template<typename ... TCon>
            static void create( Array & a, uint32_t n, T && first, TCon && ... t )
            {
                a.ArrayView<T>::m_data[n] = first;
                create( a, n + 1, static_cast<TCon &&>( t )... );
            }
        };
        template<typename TFake>
        class Creator<0, TFake>
        {
        public:
            static void create( Array & a, uint32_t n, T && first )
            {
                a.ArrayView<T>::m_data[n] = first;
            }
            template<typename ... TCon>
            static void create( Array & a, uint32_t n, T && first, TCon && ... t )
            {
                a.ArrayView<T>::m_data[n] = first;
                create( a, n + 1, static_cast<TCon &&>( t )... );
            }
        };


        union
        {
            char m_place[sizeof(T) * N];
            T realType[N];
        };
    };

    //Чтобы gcc выдавал ошибку на массив нулевой длины пришлось делать так
    //внезапно gcc нулевая длина массива нравится
    template<typename T>
    class Array<T, 0>
    {
        Array() = delete;

        template<class ... TParams>
        Array( TParams ... t ) = delete;
    };



    template< class T >
    ProtectedIterator<unsigned char, unsigned char *, unsigned char &> toByte( T that );

    template< class ValueType, class PointerType, class ReferenceType >
    class ProtectedIterator
    {

    public:

        typedef std::random_access_iterator_tag     iterator_category;
        typedef ValueType                           value_type;
        typedef std::ptrdiff_t                      difference_type;
        typedef PointerType                         pointer;
        typedef ReferenceType                       reference;

        explicit ProtectedIterator( pointer ptr, pointer begin, pointer end )  :
            m_ptr( ptr ),
            m_begin( begin ),
            m_end( end )
        {}

        ProtectedIterator(){}


        pointer get_ptr() const
        {
            assertArrayOk();
            assertPtrOk( m_ptr );

            return   m_ptr;
        }


        //Безопасные операторы
        const reference operator*()   const
        {
            assertArrayOk();
            assertPtrOk( m_ptr );

            return *m_ptr;
        }

        reference operator*()
        {
            assertArrayOk();
            assertPtrOk( m_ptr );

            return *m_ptr;
        }

        const value_type * operator->()  const
        {
            assertArrayOk();
            assertPtrOk( m_ptr );

            return  m_ptr;
        }

        value_type * operator->()
        {
            assertArrayOk();
            assertPtrOk( m_ptr );

            return  m_ptr;
        }

        const reference operator[]( difference_type off ) const
        {
            assertArrayOk();
            assertPtrOk( m_ptr + off );

            return m_ptr[off];
        }

        reference operator[]( difference_type off )
        {
            assertArrayOk();
            assertPtrOk( m_ptr + off );

            return m_ptr[off];
        }

        //Increment / Decrement
        ProtectedIterator & operator++()
        {
            assertArrayOk();

            ++m_ptr;
            return *this;
        }

        ProtectedIterator operator++(int)
        {
            assertArrayOk();

            pointer tmp = m_ptr;
            ++m_ptr;
            return ProtectedIterator( tmp, m_begin, m_end );
        }

        ProtectedIterator & operator--()
        {
            assertArrayOk();

            --m_ptr;
            return *this;
        }

        ProtectedIterator operator--( int )
        {
            assertArrayOk();

            pointer tmp = m_ptr;
            --m_ptr;
            return ProtectedIterator( tmp, m_begin, m_end );
        }

        //Arithmetic
        ProtectedIterator & operator+=( difference_type off )
        {
            m_ptr += off;
            return *this;
        }

        ProtectedIterator operator+( difference_type off ) const
        {
            return ProtectedIterator( m_ptr + off, m_begin, m_end );
        }

        friend ProtectedIterator operator+( difference_type off, const ProtectedIterator & right )
        {
            return ProtectedIterator( off + right.m_ptr, right.m_begin, right.m_end );
        }

        ProtectedIterator & operator-=( difference_type off )
        {
            m_ptr -= off;
            return *this;
        }

        ProtectedIterator operator-( difference_type off ) const
        {
            return ProtectedIterator( m_ptr - off, m_begin, m_end );
        }

        difference_type operator-( const ProtectedIterator & right ) const
        {
            return m_ptr - right.m_ptr;
        }

        //Comparison operators
        bool operator==   ( const ProtectedIterator & r )  const
        {
            return m_ptr == r.m_ptr;
        }

        bool operator!=   ( const ProtectedIterator & r )  const
        {
            return !( operator==( r ) );
        }

        bool operator<    ( const ProtectedIterator & r )  const
        {
            return m_ptr < r.m_ptr;
        }

        bool operator<=   ( const ProtectedIterator & r )  const
        {
            return m_ptr <= r.m_ptr;
        }

        bool operator>    ( const ProtectedIterator & r )  const
        {
            return r.operator<( *this );
        }

        bool operator>=   ( const ProtectedIterator & r )  const
        {
            return r.operator<=( *this );
        }

        template<class T1, class T2, class T3>
        difference_type operator-(const ProtectedIterator<T1, T2, T3> & right) const
        {
            return m_ptr - right.get_ptr();
        }

        friend ProtectedIterator< unsigned char, unsigned char *, unsigned char & >
        toByte<ProtectedIterator< ValueType, PointerType, ReferenceType >>( ProtectedIterator that );

        template<class T>
        friend T fromByte( ProtectedIterator that );

    private:

        pointer m_ptr = nullptr;
        pointer m_begin = nullptr;
        pointer m_end = nullptr;

        void assertArrayOk() const
        {
            UMBA_ASSERT( m_ptr != nullptr );
            UMBA_ASSERT( m_begin != nullptr );
            UMBA_ASSERT( m_end != nullptr );
            UMBA_ASSERT( m_begin != m_end );
        }

        void assertPtrOk( pointer p ) const
        {
            UMBA_ASSERT( p >= m_begin );
            UMBA_ASSERT( p < m_end );
        }
    };

    template<class T >
    ProtectedIterator<unsigned char,unsigned char *,unsigned char &> toByte( T that )
    {
        return ProtectedIterator<unsigned char, unsigned char *, unsigned char &>(  ( unsigned char * ) that.m_ptr,
                                                                                    ( unsigned char * ) that.m_begin,
                                                                                    ( unsigned char * ) that.m_end    );
    }

    template<class T>
    T fromByte( ProtectedIterator<unsigned char, unsigned char *, unsigned char &> that )
    {
        return T( ( typename T::pointer ) that.m_ptr,
                  ( typename T::pointer ) that.m_begin,
                  ( typename T::pointer ) that.m_end   );
    }

    template<class T >
    unsigned char * toByte( T * that )
    {
        return ( unsigned char * ) that;
    }

    template<class T>
    T fromByte( unsigned char * that )
    {
        return (T)that;
    }

}

