/*! \file
\brief Интерфейс
*/

#pragma once

#include "umba/basic_interfaces.h"

#include "i_packet_composer.h"
#include "i_packet_parser.h"

#include "umba/time_service.h"



namespace umba
{
namespace protocols
{

//! Обобщенный интерфейс потокового протокола 
interface IStreamProtocol : inherits umba::IUnknown 
                          //, public umba::IPollCapable
                          //, public umba::ICompletionHandler
                          //, protected IComposedPacketHandler
                          //, protected IParsedPacketHandler
{

    UMBA_DECLARE_INTERFACE_ID(0xC91E9618);

    typedef umba::ihc::StreamSize       StreamSize;
    typedef umba::ihc::StreamDiff       StreamDiff;
    typedef umba::ihc::StreamOctetType  StreamOctetType;
   
    const StreamSize StreamSizeNPos = umba::ihc::StreamSizeNPos;

    //! Устанавливает поток данных
    virtual
    umba::ihc::IOctetIOStream* setStream(umba::ihc::IOctetIOStream *pStream) = 0;

    //! Возвращает ранее установленный канальный поток
    virtual
    umba::ihc::IOctetIOStream* getStream() = 0;


    //! Устанавливает собирателя пакетов
    virtual
    IPacketComposer* setPacketComposer(IPacketComposer *pComposer) = 0;

    //! Возвращает ранее установленный собиратель пакетов
    virtual
    IPacketComposer* getPacketComposer() = 0;

    //! Устанавливает разбирателя пакетов
    virtual
    IPacketParser* setPacketParser(IPacketParser *pParser) = 0;

    //! Возвращает ранее установленный разбиратель пакетов
    virtual
    IPacketParser* getPacketParser() = 0;


    //! Принимает данные из буфера. Не вызывает onRawReceived
    virtual
    void receiveData( StreamOctetType *pData, StreamSize dataLen ) = 0;

    //! Принимает данные из установленного потока
    /*! Принимает данные из установленного потока и возвращает 
        количество принятых октетов.
     */
    virtual
    StreamSize receive( ) = 0;

    //! Формирует канальный пакет и отправляет его
    virtual
    void sendPacket( const StreamOctetType *pkt, StreamSize pktSize ) = 0;

    virtual
    bool canSend() = 0;

    //! Сброс - установка состояния парсера в начальное
    virtual
    void resetParser() = 0;

    //! Полный сброс протокола
    virtual
    void reset() = 0;


}; // interface IStreamProtocol



//! Used for bus streams
interface IStreamMultiAddrProtocol : public IStreamProtocol
{

    UMBA_DECLARE_INTERFACE_ID(0x9C3C541C);

    virtual 
    unsigned getAddrFrom( ) = 0;

    virtual 
    bool setAddrTo( unsigned addr ) = 0; // return false if addr is invalid for protocol bus

    virtual 
    unsigned getAddrTo( ) = 0;

};




} // namespace protocols
} // namespace umba











