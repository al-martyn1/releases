/*! \file
\brief Интерфейс
*/

#pragma once

#include "protocols_base.h"


namespace umba
{
namespace protocols
{

//! Обработчики событий интерфейса IDatalink
interface IRawDataEvents : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xCB1EB34A);

    //! Вызывается при приеме порции данных, следует использовать для нужд логгирования.
    virtual
    void onRawReceived( const StreamOctetType *pData, StreamSize dataSize ) = 0;
    
    //! Вызывается при отправке порции данных (перед), следует использовать для нужд логгирования.
    virtual
    void onRawSend( const StreamOctetType *pData, StreamSize dataSize ) = 0;


}; // interface IRawDataEvents


} // namespace protocols
} // namespace umba


