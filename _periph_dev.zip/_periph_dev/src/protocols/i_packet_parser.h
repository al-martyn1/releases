/*! \file
\brief Интерфейс
*/

#pragma once

#include "protocols_base.h"

namespace umba
{
namespace protocols
{


//! Интерфейс обработчика входящих пакетов
interface IParsedPacketHandler : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xC39F7618);

    //! Принимает пакет протокола, очищеный от контрольных сумм, символов экранирования и тп.
    virtual
    void handleParsedPacket( const StreamOctetType *pkt, StreamSize pktSize ) = 0;

    //! Вызывается при ошибке разбора канального пакета
    /*! Вызывается при ошибке разбора канального пакета, возможные коды ошибок:
        umba::errors::crc       - ошибка crc
        umba::errors::fail      - неизвестная ошибка
        umba::errors::too_much  - данные не помещаются во внутренний буфер

        Данные пакета приводятся для ознакомления, их нельзя использовать в работе
     */
    virtual
    void handleParseError  ( const StreamOctetType *pkt, StreamSize pktSize, umba::Error parseRes ) = 0;

}; // interface IParsedPacketHandler



//! Интерфейс разборщика пакетов канального уровня
/*! Объекты, реализующие данный интерфейс

 */
interface IPacketParser : inherits umba::IUnknown // , inherits umba::ICompletionHandler
{

    UMBA_DECLARE_INTERFACE_ID(0x8640D7E0);

    //! Устанавливает обработчик пакетов
    /*! Возвращает предыдущий обработчик, или 0.
     */
    virtual
    IParsedPacketHandler* setHandler( IParsedPacketHandler *pktHandler ) = 0;

    //! Возвращает установленный обработчик пакетов
    virtual
    IParsedPacketHandler* getHandler( ) = 0;

    //! Буферизирует и обрабатывает данные канального уровня
    /*! Буферизирует данные канального уровня, убирает артефакты канального уровня,
        формирует пакет уровня протокола и вызывает обработчик пакета или ошибки.
     */
    virtual
    void receiveData( StreamOctetType *pData, StreamSize dataLen ) = 0;

    //! Сброс - установка состояния парсера в начальное
    virtual
    void reset() = 0;

}; // interface IPacketParser






} // namespace protocols
} // namespace umba

