/*! \file
\brief Реализация 
*/

#pragma once

#include "i_datalink.h"

#include <utility>

#include "umba/time_service.h"


namespace umba
{
namespace protocols
{

struct DatalinkImplBase : implements IDatalinkEvents
                        , implements IDatalinkPrivate
                        , implements IDatalink
{

    //! Таймаут несущей
    virtual
    umba::time_service::TimeTick setCarrierTimeout( umba::time_service::TimeTick t ) override
    {
        std::swap( m_carrierTimeout, t );
        checkCarrier( );
        return t;
    }

    //! Возвращает текущее значение таймаута наличия соедениния (наличие "несущей") в милисекундах
    virtual
    umba::time_service::TimeTick getCarrierTimeout( ) override
    {
        return m_carrierTimeout;
    }

    //! Проверяет наличие нессущей
    virtual
    bool isCarrierGood( ) override // а просто carrierDetect не вариант?
    {
        return checkCarrier( );
    }


    //! Установка таймаута на получение данных - осмысленных, не битых не крашенных
    virtual
    umba::time_service::TimeTick setDatalinkTimeout( umba::time_service::TimeTick t ) override
    {
        std::swap( m_datalinkTimeout, t );
        checkDatalink( );
        return t;
    }

    //! Возвращает текущее значение таймаута данных
    virtual
    umba::time_service::TimeTick getDatalinkTimeout( ) override
    {
        return m_datalinkTimeout;
    }

    //! Проверяет наличие логической связи, хорошие байтики туда-сюда (Walking Bytes)
    virtual
    bool isDatalinkGood( ) override // а просто datalinkDetect не вариант?
    {
        return checkDatalink( );
    }

    //! Проверка истечения произвольного таймаута
    virtual
    bool isDatalinkCustomPeriodTimedout( umba::time_service::TimeTick p )
    {
        auto tickNow = umba::time_service::getCurTimeMs();
        if ( (tickNow-m_datalinkLastTick)>=p )
            return true;
        return false;
    }

    //! Проверка истечения половины таймаута
    virtual
    bool isDatalinkHalfPeriodTimedout( )
    {
        return isDatalinkCustomPeriodTimedout(m_datalinkTimeout/2);
    }



protected: // IDatalinkPrivate methods

    //! Обновление метки времени для несущей
    virtual
    bool updateCarrierStamp() override
    {
        m_carrierLastTick = umba::time_service::getCurTimeMs();
        return checkCarrier( );
    }

    //! Обновление метки времени для данных
    virtual
    bool updateDatalinkStamp() override
    {
        m_datalinkLastTick = umba::time_service::getCurTimeMs();
        return checkDatalink( );
    }


protected: // IDatalinkEvents


    //! Вызывается при изменении состояния несущей
    /*! newState - то же значение, которое можно получить
        вызовом isCarrierGood( )
     */
    virtual
    void onCarrierStateChanged( bool newState ) override
    {
        // Затычка для переопределения
    }

    //! Вызывается при изменении состояния Datalink
    /*! newState - то же значение, которое можно получить
        вызовом isDatalinkGood( )
     */
    virtual
    void onDatalinkStateChanged( bool newState ) override
    {
        // Затычка для переопределения
    }


protected: // Реализация


    //! Обновление флага несущей
    bool setCarrierState( bool newState )
    {
        bool bChanged = m_carrierState!=newState;
        m_carrierState = newState;
        if (bChanged)
            onCarrierStateChanged(m_carrierState);

        return m_carrierState;
    }

    //! Обновление флага данных
    bool setDatalinkState( bool newState )
    {
        bool bChanged = m_datalinkState!=newState;
        m_datalinkState = newState;
        if (bChanged)
            onDatalinkStateChanged(m_datalinkState);

        return m_datalinkState;
    }

    //! Проверка и обновление (при необходимости) статуса таймаута
    bool checkCarrier( )
    {
        auto tickNow = umba::time_service::getCurTimeMs();
        if ( (tickNow-m_carrierLastTick)>=m_carrierTimeout )
            return setCarrierState( false );
        else
            return setCarrierState( true );
    }

    //! Проверка и обновление (при необходимости) статуса таймаута
    bool checkDatalink( )
    {
        auto tickNow = umba::time_service::getCurTimeMs();
        if ( (tickNow-m_datalinkLastTick)>=m_datalinkTimeout )
            return setDatalinkState( false );
        else
            return setDatalinkState( true );
    }


protected:

    umba::time_service::TimeTick  m_carrierLastTick  = 0;
    umba::time_service::TimeTick  m_datalinkLastTick = 0;

    umba::time_service::TimeTick  m_carrierTimeout  = 500;
    umba::time_service::TimeTick  m_datalinkTimeout = 1000;

    bool                          m_carrierState  = false;
    bool                          m_datalinkState = false;

}; // struct DatalinkImplBase



} // namespace protocols
} // namespace umba


