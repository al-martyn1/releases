/*! \file
\brief Реализация 
*/

#pragma once

#include "i_stream_protocol.h"
#include "datalink_impl_base.h"
#include "i_raw_data_events.h"

#include "umba/basic_interfaces_impl.h"



#include <utility>

namespace umba
{
namespace protocols
{

// Работает так : http://ideone.com/qFiwbU
// Не работает так: http://ideone.com/u0NEAz
// Хочется, как не работает
// Что примерно хочется: http://ideone.com/beCbyn

//! Обобщенный интерфейс потокового протокола 
template< typename BaseProtocol = IStreamProtocol > // or use IStreamMultiAddrProtocol
struct IStreamProtocolImplBase : implements BaseProtocol
                               , implements umba::IPollCapable
                               , implements umba::ICompletionHandler
                               , implements IComposedPacketHandler
                               , implements IParsedPacketHandler
                               , implements IRawDataEvents
                               , implements IPingRequestHandler
                               , public     DatalinkImplBase
                               , public     umba::PingRequestGeneratorImplBase


{

    UMBA_BEGIN_INTERFACE_MAP_EX( BaseProtocol )

         //UMBA_IMPLEMENT_INTERFACE( BaseProtocol )
         UMBA_IMPLEMENT_INTERFACE( umba::IPollCapable )
         UMBA_IMPLEMENT_INTERFACE( umba::ICompletionHandler )
         UMBA_IMPLEMENT_INTERFACE( IComposedPacketHandler )
         UMBA_IMPLEMENT_INTERFACE( IParsedPacketHandler )
         UMBA_IMPLEMENT_INTERFACE( IRawDataEvents )
         UMBA_IMPLEMENT_INTERFACE( IPingRequestGenerator )
         // UMBA_IMPLEMENT_INTERFACE( IPingRequestHandler ) - а вот его - не публикуем, ибо нефик -  унаследовались от него только ради onPing, причем сугубо для внутреннего потребления

         // From DatalinkImplBase
         UMBA_IMPLEMENT_INTERFACE( IDatalinkEvents  )
         UMBA_IMPLEMENT_INTERFACE( IDatalinkPrivate )
         UMBA_IMPLEMENT_INTERFACE( IDatalink        )
         //UMBA_IMPLEMENT_INTERFACE( )

    UMBA_END_INTERFACE_MAP()


    virtual
    void poll() override
    {
        if (isReadyForPoll())
        {
            auto recvRes = receive();
            if (!recvRes)
            {
                onComplete( (unsigned)CompletionEvents::receiveCompleted );
            }
            else
            {
                // что-то приняли
                onComplete( (unsigned)CompletionEvents::receiveStarted );
            }

        }

        checkCarrier();
        checkDatalink();

        if (m_pingPeriod)
        {
            // если кто-то ведет обмен данными и штамп данных обновляется, то пинги не нужны
            if (isDatalinkCustomPeriodTimedout( m_pingPeriod ) ) 
            {
                if (isReadyForPing()) // если занят, то пинг не генериться
                    onPing();
            }
        }
    }

    //! Устанавливает канальный поток
    virtual
    umba::ihc::IOctetIOStream* setStream(umba::ihc::IOctetIOStream *pStream) override
    {
        std::swap(m_pStream, pStream);
        return pStream;
    }

    //! Возвращает ранее установленный канальный поток
    virtual
    umba::ihc::IOctetIOStream* getStream() override
    {
        return m_pStream;
    }

    //! Устанавливает собирателя пакетов
    virtual
    IPacketComposer* setPacketComposer(IPacketComposer *pComposer) override
    {
        std::swap(m_pComposer, pComposer);
        if (pComposer)
            pComposer->setHandler(0);
        if (m_pComposer)
            m_pComposer->setHandler(this);
        return pComposer;
    }

    //! Возвращает ранее установленный собиратель пакетов
    virtual
    IPacketComposer* getPacketComposer() override
    {
        return m_pComposer;
    }

    //! Устанавливает разбирателя пакетов
    virtual
    IPacketParser* setPacketParser(IPacketParser *pParser) override
    {
        std::swap(m_pParser, pParser);
        if (pParser)
            pParser->setHandler(0);
        if (m_pParser)
            m_pParser->setHandler(this);
        return pParser;
    }

    //! Возвращает ранее установленный разбиратель пакетов
    virtual
    IPacketParser* getPacketParser() override
    {
        return m_pParser;
    }



    //! Принимает данные из буфера. Не вызывает onRawReceived
    virtual
    void receiveData( StreamOctetType *pData, StreamSize dataLen ) override
    {
        if (!m_pParser)
            return;

        m_pParser->receiveData(pData, dataLen);
    }

    //! Принимает данные из установленного потока
    virtual
    StreamSize receive( ) override
    {
        UMBA_ASSERT(m_pStream);

        if (!m_pStream->canRead())
            return 0;

        StreamOctetType buf[32];
        StreamSize numReaded = m_pStream->read( buf, UMBA_COUNT_OF(buf) );
        if (numReaded)
        {
            updateCarrierStamp();
            onRawReceived( buf, numReaded );
            m_pParser->receiveData(buf, numReaded);
        }

        return numReaded;
    }

    //! Формирует канальный пакет и отправляет его
    virtual
    void sendPacket( const StreamOctetType *pkt, StreamSize pktSize ) override
    {
        m_pComposer->compose(pkt, pktSize);
    }

    virtual
    void resetParser() override
    {
        if (!m_pParser)
            return;

        m_pParser->reset();
    }

    virtual
    void reset() override
    {
        resetParser();
    }

    virtual
    bool isReadyForPing() override
    {
        // По умолчанию - готов к пингам
        return true;
    }

protected:

    virtual
    void onComplete( unsigned customEventId ) override
    {
        if (customEventId==(unsigned)CompletionEvents::receiveCompleted)
        {
            if (auto res = m_pParser->queryInterface<umba::ICompletionHandler>())
            {
                res.value->onComplete(customEventId);
            }
            //m_pParser->onComplete(customEventId);
        }
    }


    //! Принимает пакет протокола, подготовленный для канального уровня, и отправляе его в поток
    /*! Не следует вызывать этот метод напрямую.
     */
    virtual
    void handleComposedPacket( const StreamOctetType *pkt, StreamSize pktSize ) override
    {
        UMBA_ASSERT(m_pStream);
        onRawSend( pkt, pktSize );
        m_pStream->write( pkt, pktSize );
    }


    //! Вызывается при приеме порции данных, следует использовать для нужд логгирования.
    virtual
    void onRawReceived( const StreamOctetType *pData, StreamSize dataSize ) override
    {
        // Затычка, можно не переопределять в наследниках, если протоколирование не нужно
    }
    
    //! Вызывается при отправке порции данных (перед), следует использовать для нужд логгирования.
    virtual
    void onRawSend( const StreamOctetType *pData, StreamSize dataSize ) override
    {
        // Затычка, можно не переопределять в наследниках, если протоколирование не нужно
    }



    //----------------------

    //! Вызывается при ошибке формирования канального пакета
    /*! Не следует вызывать этот метод напрямую.
        Переопределяется в конкретной реализации.
     */
    virtual
    void handleComposeError( const StreamOctetType *pkt, StreamSize pktSize, umba::Error parseRes ) override
    {
        UMBA_ASSERT(parseRes!=umba::errors::too_much); // данные не помещаются во внутренний буфер - нужно увеличить буфер композера
    }

    //! Вызывается при ошибке разбора канального пакета
    /*! Не следует вызывать этот метод напрямую.
        Переопределяется в конкретной реализации.
     */
    virtual
    void handleParseError  ( const StreamOctetType *pkt, StreamSize pktSize, umba::Error parseRes ) override
    {
        // Хорошо бы сделать ассерт, но если этот метод забыть переопределить, то при слишком длинном сообщении
        // прошивка упадет. А так как предполагается, что это будет происходить редко - ведь размер буфер будет
        // выбираться изначально достаточным.
    }

    virtual
    void onPing( ) override
    {
    }


protected:

    umba::ihc::IOctetIOStream    *m_pStream   = 0;
    IPacketComposer              *m_pComposer = 0;
    IPacketParser                *m_pParser   = 0;




}; // IStreamProtocolImplBase


} // namespace protocols
} // namespace umba

