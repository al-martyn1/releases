/*! \file
\brief Интерфейс
*/

#pragma once

#include "protocols_base.h"

namespace umba
{
namespace protocols
{


//! Интерфейс обработчика входящих пакетов
interface IComposedPacketHandler : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xAB2C80F7);

    //! Принимает пакет протокола, подготовленный для канального уровня
    virtual
    void handleComposedPacket( const StreamOctetType *pkt, StreamSize pktSize ) = 0;

    //! Вызывается при ошибке формирования канального пакета
    /*! Вызывается при ошибке формирования канального пакета, возможные коды ошибок:
        umba::errors::fail      - неизвестная ошибка
        umba::errors::too_much  - данные не помещаются во внутренний буфер
     */
    virtual
    void handleComposeError( const StreamOctetType *pkt, StreamSize pktSize, umba::Error parseRes ) = 0;



}; // interface IComposedPacketHandler




//! Интерфейс композитора пакетов канального уровня
interface IPacketComposer : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x8844C1CA);

    //! Устанавливает обработчик пакетов
    /*! Возвращает предыдущий обработчик, или 0.
     */
    virtual
    IComposedPacketHandler* setHandler( IComposedPacketHandler *pktHandler ) = 0;

    //! Возвращает установленный обработчик пакетов
    virtual
    IComposedPacketHandler* getHandler( ) = 0;


    //! Собирает пакет канального уровня 
    /*! Собирает пакет канального уровня - вычисляет/добавляет контрольные суммы,
        экранирует и тп
        Помещает результат во внутренниый буфер. Если длины буфера недостаточно для выходного пакета,
        лишнее обрезается и вызывается обработчик ошибки. 

        При успешном формировании пакета вызывает обработчик, если тот установлен.
     */
    virtual
    void compose( const StreamOctetType * pkt, StreamSize pktSize ) = 0;

    //! Формирует пакет в заданный буфер. Не вызывает обработчик
    virtual
    StreamSize composeTo( const StreamOctetType * pkt, StreamSize pktSize, StreamOctetType * buf, StreamSize bufSize ) = 0;

}; // interface IPacketComposer


} // namespace protocols
} // namespace umba


