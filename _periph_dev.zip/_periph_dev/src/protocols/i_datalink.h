/*! \file
\brief Интерфейс
*/

#pragma once

#include "protocols_base.h"


namespace umba
{
namespace protocols
{

//! Обработчики событий интерфейса IDatalink
interface IDatalinkEvents : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x689F997E);

    //! Вызывается при изменении состояния несущей
    /*! newState - то же значение, которое можно получить
        вызовом isCarrierGood( )
     */
    virtual
    void onCarrierStateChanged( bool newState ) = 0;

    //! Вызывается при изменении состояния Datalink
    /*! newState - то же значение, которое можно получить
        вызовом isDatalinkGood( )
     */
    virtual
    void onDatalinkStateChanged( bool newState ) = 0;

}; // interface IDatalinkEvents


//! Приватная часть интерфейса IDatalink
interface IDatalinkPrivate : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x3E297912);

    //! Обновление метки времени для несущей
    virtual
    bool updateCarrierStamp() = 0;

    //! Обновление метки времени для данных
    virtual
    bool updateDatalinkStamp() = 0;

}; // interface IDatalinkPrivate



//! Управление таймаутами канала связи
interface IDatalink : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x43A23533);

    //! Установка таймаута на проверку наличия соединения (наличие "несущей") в милисекундах
    /*! Наличие соединения означает, что устройства как-то отвечает,
        физически связь есть, и там что-то бегает.
        Наличие связи ничего не говорит о том, может ли удаленное устройство
        осысленно отвечать.
        Возвращает предыдущее значение таймаута.

        Внимание: важно понимать, что "несущая" в большинстве случаев не существует сама по себе,
        а возникает только в момент передачи данных. Если соединение висит в ожидающем режиме, и
        данные бегают не периодически, то оба таймаута не будут корректно работать
     */
    virtual
    umba::time_service::TimeTick setCarrierTimeout( umba::time_service::TimeTick ) = 0;

    //! Возвращает текущее значение таймаута наличия соедениния (наличие "несущей") в милисекундах
    virtual
    umba::time_service::TimeTick getCarrierTimeout( ) = 0;

    //! Проверяет наличие нессущей
    virtual
    bool isCarrierGood( ) = 0; // а просто carrierDetect не вариант?


    //! Установка таймаута на получение данных - осмысленных, не битых не крашенных
    virtual
    umba::time_service::TimeTick setDatalinkTimeout( umba::time_service::TimeTick ) = 0;

    //! Возвращает текущее значение таймаута данных
    virtual
    umba::time_service::TimeTick getDatalinkTimeout( ) = 0;

    //! Проверяет наличие логической связи, хорошие байтики туда-сюда (Walking Bytes)
    virtual
    bool isDatalinkGood( ) = 0; // а просто datalinkDetect не вариант?

    //! Проверка истечения произвольного таймаута
    virtual
    bool isDatalinkCustomPeriodTimedout( umba::time_service::TimeTick p ) = 0;

    //! Проверка истечения половины таймаута
    virtual
    bool isDatalinkHalfPeriodTimedout( ) = 0;



}; // interface IDatalink



} // namespace protocols
} // namespace umba


