/*! \file
\brief Реализация 
*/

#pragma once

#include "umba/umba.h"
#include "umba/errors.h"
#include "umba/basic_interfaces.h"
#include "ihc/i_octet_stream.h"

namespace umba
{
namespace protocols
{

typedef umba::ihc::StreamSize       StreamSize;
typedef umba::ihc::StreamDiff       StreamDiff;
typedef umba::ihc::StreamOctetType  StreamOctetType;

const StreamSize StreamSizeNPos = umba::ihc::StreamSizeNPos;


enum class CompletionEvents
{
    receiveStarted,
    receiveCompleted
};



} // namespace protocols
} // namespace umba



