var menudata={children:[
{text:"Титульная страница",url:"index.html"},
{text:"Классы",url:"annotated.html",children:[
{text:"Классы",url:"annotated.html"},
{text:"Алфавитный указатель классов",url:"classes.html"},
{text:"Иерархия классов",url:"inherits.html"},
{text:"Члены классов",url:"functions.html",children:[
{text:"Указатель",url:"functions.html",children:[
{text:"c",url:"functions.html#index_c"},
{text:"g",url:"functions.html#index_g"},
{text:"h",url:"functions.html#index_h"},
{text:"i",url:"functions.html#index_i"},
{text:"o",url:"functions.html#index_o"},
{text:"r",url:"functions.html#index_r"},
{text:"s",url:"functions.html#index_s"},
{text:"u",url:"functions.html#index_u"}]},
{text:"Функции",url:"functions_func.html",children:[
{text:"c",url:"functions_func.html#index_c"},
{text:"g",url:"functions_func.html#index_g"},
{text:"h",url:"functions_func.html#index_h"},
{text:"i",url:"functions_func.html#index_i"},
{text:"o",url:"functions_func.html#index_o"},
{text:"r",url:"functions_func.html#index_r"},
{text:"s",url:"functions_func.html#index_s"},
{text:"u",url:"functions_func.html#index_u"}]}]}]},
{text:"Файлы",url:"files.html",children:[
{text:"Файлы",url:"files.html"}]}]}
