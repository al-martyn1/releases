var searchData=
[
  ['receive',['receive',['../structumba_1_1protocols_1_1_i_stream_protocol_impl_base.html#a0338f2953533f650947669234016e7ad',1,'umba::protocols::IStreamProtocolImplBase']]],
  ['receivedata',['receiveData',['../structumba_1_1protocols_1_1_i_stream_protocol_impl_base.html#aac1fdf28ece6d77583b0d60e83fd981a',1,'umba::protocols::IStreamProtocolImplBase']]]
];
