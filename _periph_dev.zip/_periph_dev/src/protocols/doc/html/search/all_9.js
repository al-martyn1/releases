var searchData=
[
  ['updatecarrierstamp',['updateCarrierStamp',['../structumba_1_1protocols_1_1_datalink_impl_base.html#aaf6e007577200b01ec7475ebdb74b96b',1,'umba::protocols::DatalinkImplBase']]],
  ['updatedatalinkstamp',['updateDatalinkStamp',['../structumba_1_1protocols_1_1_datalink_impl_base.html#ada67c6726d22a3ed1c27939b9fb75fa3',1,'umba::protocols::DatalinkImplBase']]]
];
