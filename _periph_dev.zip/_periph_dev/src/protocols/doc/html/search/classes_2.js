var searchData=
[
  ['istreamprotocolimplbase',['IStreamProtocolImplBase',['../structumba_1_1protocols_1_1_i_stream_protocol_impl_base.html',1,'umba::protocols']]],
  ['istreamprotocolimplbase_3c_20umba_3a_3aprotocols_3a_3aistreamprotocol_20_3e',['IStreamProtocolImplBase&lt; umba::protocols::IStreamProtocol &gt;',['../structumba_1_1protocols_1_1_i_stream_protocol_impl_base.html',1,'umba::protocols']]]
];
