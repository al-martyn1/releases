var searchData=
[
  ['datalinkimplbase',['DatalinkImplBase',['../structumba_1_1protocols_1_1_datalink_impl_base.html',1,'umba::protocols']]]
];
