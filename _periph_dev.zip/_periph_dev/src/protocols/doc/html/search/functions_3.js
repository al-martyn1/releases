var searchData=
[
  ['iscarriergood',['isCarrierGood',['../structumba_1_1protocols_1_1_datalink_impl_base.html#a9853292282da543683844d7579a9cec8',1,'umba::protocols::DatalinkImplBase']]],
  ['isdatalinkcustomperiodtimedout',['isDatalinkCustomPeriodTimedout',['../structumba_1_1protocols_1_1_datalink_impl_base.html#a5f3fb513cd16d1dbf6ebbb7eb45c92ad',1,'umba::protocols::DatalinkImplBase']]],
  ['isdatalinkgood',['isDatalinkGood',['../structumba_1_1protocols_1_1_datalink_impl_base.html#a28a0f406dfcd12ed6ccde9f84e82e70a',1,'umba::protocols::DatalinkImplBase']]],
  ['isdatalinkhalfperiodtimedout',['isDatalinkHalfPeriodTimedout',['../structumba_1_1protocols_1_1_datalink_impl_base.html#af6a22b7ed7eeec00a12d9ee92a249aec',1,'umba::protocols::DatalinkImplBase']]]
];
