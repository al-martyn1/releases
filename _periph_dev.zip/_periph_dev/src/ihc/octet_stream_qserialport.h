/*! \file
\brief Реализация потока для QSerialPort
*/

#pragma once

#include "i_octet_stream.h"
#include <exception>
#include <stdexcept>
#include <QSerialPort>
#include <QTest>


namespace umba{

namespace ihc{


struct IOctetIOStreamImplQSerialPort : implements IOctetIOStream
{

    UMBA_BEGIN_INTERFACE_MAP_EX( IOctetOStream )
         UMBA_IMPLEMENT_INTERFACE( IOctetIOStream )
         UMBA_IMPLEMENT_INTERFACE( IOctetIStream )
    UMBA_END_INTERFACE_MAP()

    IOctetIOStreamImplQSerialPort( QSerialPort &qsp ) 
    : m_serialPort( qsp )
    {
    }

    virtual
    bool canRead() override
    {
        char data;
        if (m_serialPort.peek( &data, 1 )==1)
            return true;
        return false;
    }

    virtual
    StreamSize read( StreamOctetType *pBuf, StreamSize bufSize ) override
    {
        QTest::qWait(0); // allow Qt to run some internal code
        // If in main loop (console app, as sample) no calls to 
        // QCoreApplication::processEvents();
        // the serial port always read zero count bytes

        auto bytesReaded = m_serialPort.read( (char*)pBuf, bufSize );
        if (bytesReaded==(qint64)-1)
        {
            throw std::runtime_error("Serial port read failed");
            return 0;
        }

        return (StreamSize)bytesReaded;
    }

    virtual
    void fetch( StreamSize bufSize ) override
    {
    }


    virtual
    bool canWrite(StreamSize nOctets) override
    {
        return true; // Любой разумный объем можно отправить
    }

    virtual
    void write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        auto bytesWritten = m_serialPort.write( (const char*)pData, nOctets );
        if (bytesWritten==(qint64)-1)
        {
            throw std::runtime_error("Serial port write failed");
            return;
        }

        if (nOctets!=(StreamSize)bytesWritten)
        {
            throw std::runtime_error("Serial port write failed - not all data written");
        }
    }

    virtual
    void write( const char *pData, size_t dataSize ) override
    {
        UMBA_ASSERT( dataSize >= 0 );
        write( (const StreamOctetType *)pData, (StreamSize)dataSize);
    }

    virtual
    void flush( ) override
    {
    }


protected:

    QSerialPort &m_serialPort;

}; // struct IOctetIOStreamImplLegacyUart

} // namespace ihc 

} // namespace umba

