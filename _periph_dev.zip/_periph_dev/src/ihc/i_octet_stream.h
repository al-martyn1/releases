/*! \file
\brief Интерфейс потока
*/

#pragma once

#include "umba/umba.h"
#include "umba/interface.h"

#define IHC_OCTET_STREAM_H


namespace umba{

namespace ihc{


#ifndef UMBA_MCU_USED
    typedef uint64_t  StreamSize;
    typedef int64_t   StreamDiff;
#else
    // На контроллере за 4Гб вряд ли выйдем
    typedef uint32_t  StreamSize;
    typedef int32_t   StreamDiff;
#endif

const StreamSize StreamSizeNPos = (StreamSize)-1;

typedef uint8_t StreamOctetType ;



//! Интерфейс потока ввода
interface IOctetIStream : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x97FEB927);

    typedef umba::ihc::StreamSize      StreamSize;
    typedef umba::ihc::StreamDiff      StreamDiff;
    typedef umba::ihc::StreamOctetType StreamOctetType;
    static const StreamSize StreamSizeNPos = umba::ihc::StreamSizeNPos;


    //! Проверка, будет ли последующее чтение блокирующим
    virtual
    bool canRead() = 0;

    //! Чтение из потока
    /*! Прочитано может быть меньше, чем запрошено.
        Если данных нет вообще, выполнение може заблокироваться.
        При ошибках записи на взрослой системе будет брошено исключение.
        На микроконтроллере ошибок быть не может.
     */
    virtual
    StreamSize read( StreamOctetType *pBuf, StreamSize bufSize ) = 0;

    //! Запрос на последующее чтение
    /*! Можно попросить поток постараться обеспечить требуемое количество
        данных к последующему чтению. Никого ни к чему не обязывает.
     */
    virtual
    void fetch( StreamSize bufSize ) = 0;



}; // interface IIStream


//! Интерфейс потока вывода
interface IOctetOStream : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xE13A2883);

    typedef umba::ihc::StreamSize      StreamSize;
    typedef umba::ihc::StreamDiff      StreamDiff;
    typedef umba::ihc::StreamOctetType StreamOctetType;
    static const StreamSize StreamSizeNPos = umba::ihc::StreamSizeNPos;


    //! Проверка, будет ли последующая запись nOctets октетов блокирующей
    virtual
    bool canWrite(StreamSize nOctets) = 0;

    //! Запись в поток
    /*! Данные отправлены в поток (ушли в драйвер устройства etc)
        Гарантии, что они отправлены/записаны куда следует - нет.
        При ошибках записи на взрослой системе будет брошено исключение.
        На микроконтроллере ошибок быть не может.
        Если данные не лезут в буфер, то запись заблокирует поток выполнения,
        пока не протолкнет всё.
        Между canWrite и write другой поток может что-то записать, поэтому можно 
        нарваться на проблемы: помните - писать из разных потоков выполнения в один stream -
        плохая идея.
    */
    virtual
    void write( const StreamOctetType *pData, StreamSize nOctets) = 0;

    //! Перегрузка для упрощения записи char'ов
    virtual
    void write( const char *pData, size_t dataSize ) = 0;

    //! Запрос на сброс буферов.
    /*! Никого ни к чему не обязывает.
     */
    virtual
    void flush( ) = 0;


}; // interface IOStream


//! Интерфейс потока ввода-вывода
interface IOctetIOStream : inherits IOctetIStream, inherits IOctetOStream
{
    UMBA_DECLARE_INTERFACE_ID(0x36D5FCBD);

    typedef umba::ihc::StreamSize      StreamSize;
    typedef umba::ihc::StreamDiff      StreamDiff;
    typedef umba::ihc::StreamOctetType StreamOctetType;
    static const StreamSize StreamSizeNPos = umba::ihc::StreamSizeNPos;

}; // interface IIOStream


template< typename StreamType, typename TOctetHandler>
void streamReadHelper( StreamType *pStream, const TOctetHandler handler )
{
    if (!pStream || !pStream->canRead())
        return;

    StreamOctetType buf[8];
    StreamSize readed = pStream->read(buf, 8);
    for( StreamSize i=0; i!=readed; ++i)
        handler(buf[i]);
}


} // namespace ihc 

} // namespace umba

