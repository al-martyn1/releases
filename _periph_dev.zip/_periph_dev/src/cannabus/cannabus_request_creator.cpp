#include "cannabus_request_creator.h"

namespace cannabus
{
    void RequestCreator :: createWriteRange( can::CanMessage & request, uint8_t startReg, uint8_t endReg, const uint8_t * values)
    {
        //идентификатор собираю
        request.id = m_ID | FCode::WRITE_REGS_RANGE;

        UMBA_ASSERT( endReg >= startReg );

        uint8_t regsNum = endReg - startReg + 1;
        // в сообщении может лежать 6 значений, а диапазон от начала до конца включительно
        UMBA_ASSERT( regsNum <= max_regs_in_range);

        request.length = regsNum + 2;
        request.data[0] = startReg;
        request.data[1] = endReg;

        for( uint8_t i = 0; i < regsNum; i++ )
        {
            request.data[2 + i] = values[i];
        }
    }

    void RequestCreator :: createWriteSeries( can::CanMessage & request, const Register * series, uint8_t len )
    {
        //идентификатор собираю
        request.id = m_ID | FCode::WRITE_REGS_SERIES;

        // в cannabus сообщение влезает серия из четырех регистров максимум
        UMBA_ASSERT(len <= max_regs_in_series);

        request.length = len * 2;

        for( uint8_t i=0; i < len; ++i )
        {
            request.data[i * 2] = series[i].num;
            request.data[i * 2 + 1] = series[i].val;
        }
    }

    void RequestCreator :: createReadRange( can::CanMessage & request, uint8_t regNumBegin, uint8_t regNumEnd )
    {
        //идентификатор собираю
        request.id = m_ID | FCode::READ_REGS_RANGE;

        UMBA_ASSERT( regNumEnd >= regNumBegin );


        uint8_t regsNum = regNumEnd - regNumBegin + 1;

        // в сообщении может лежать 6 значений, а диапазон от начала до конца включительно
        UMBA_ASSERT( regsNum <= max_regs_in_range );

        request.length = 2;

        request.data[0] = regNumBegin;
        request.data[1] = regNumEnd;
    }

    void RequestCreator :: createReadSeries( can::CanMessage & request, const Register * series, uint8_t len )
    {
        //идентификатор собираю
        request.id = m_ID | FCode::READ_REGS_SERIES;

        // в cannabus сообщение влезает серия из четырех регистров максимум
        UMBA_ASSERT(len <= max_regs_in_series);

        request.length = len;

        for( uint8_t i=0; i < len; i++ )
        {
            request.data[i] = series[i].num;
        }

    }


}
