#include "cannabus_synchronizer.h"

namespace cannabus
{
    void Synchronizer :: init(SendRequest sendRequest)
    {
        m_sendRequest = sendRequest;
    }

    void Synchronizer :: addSlave(cannabus::Slave & slave)
    {
        for(uint8_t i=0; i<CANNABUS_SLAVES_MAX; i++)
        {
            if( m_slaves[i] == &slave)
            {
                // этот слейв уже есть!
                UMBA_ASSERT_FAIL();
            }

            if(m_slaves[i] == 0)
            {
                m_slaves[i] = &slave;
                return;
            }
            else
            {
                // такой адрес уже есть
                UMBA_ASSERT( m_slaves[i]->getAddress() != slave.getAddress() );
            }
        }

        // TOO MUCH SLAVES
        UMBA_ASSERT_FAIL();
    }

    void Synchronizer :: work(uint32_t curTime)
    {
        UMBA_ASSERT( m_sendRequest );

        m_curCallTime = curTime;

        switch( m_state )
        {
        case States::SEARCH:

            // синхронизируем мастер-таблицу и слейв-таблицы
            for( uint8_t i = 0; i < CANNABUS_SLAVES_MAX; i++ )
            {
                // пустое место в таблице
                if( m_slaves[i] == 0 )
                {
                    break;
                }

                // этот слейв пропал с линии
                if( m_slaves[i]->getConnectionFailures() > m_connectionFailuresMax )
                {
                    continue;
                }

                m_slaves[i]->synchronize();
            }

            if( isRequestRequired() )
            {
                m_state = States::WAIT_ANSWER;
                // синхронизация продолжится, когда придет ответ или пройдет таймаут в сессии

                m_sendRequest( m_curRequest );
            }

            break;

        // просто ждем ответ
        case States::WAIT_ANSWER:
            break;

        default:
            UMBA_ASSERT_FAIL();
            break;
        }
    }

    bool Synchronizer::isRequestRequired(void)
    {
        static uint8_t lastRwSlave = 0;

        uint8_t j = lastRwSlave + 1;
        j %= CANNABUS_SLAVES_MAX;

        // есть ли у кого чо?
        for(uint8_t i=0; i<CANNABUS_SLAVES_MAX; i++)
        {
            // пустое место в таблице
            if( m_slaves[j] == 0)
            {
                j++;
                j %= CANNABUS_SLAVES_MAX;
                continue;
            }

            // этот слейв пропал с линии
            if( m_slaves[j]->getConnectionFailures() > m_connectionFailuresMax )
            {
                j++;
                j %= CANNABUS_SLAVES_MAX;
                continue;
            }

            if( m_slaves[j]->isRwUpdateRequired() )
            {
                m_curSlave = j;
                lastRwSlave = j;
                m_slaves[j]->getRwRequest(m_curRequest);
                return true;
            }

            if( m_slaves[j]->isRoUpdateRequired( m_curCallTime ) )
            {
                m_curSlave = j;
                lastRwSlave = j;
                m_slaves[j]->getRoRequest(m_curRequest, m_curCallTime);
                return true;
            }

            j++;
            j %= CANNABUS_SLAVES_MAX;

        }


        return false;
    }

    void Synchronizer :: onRelevantAnswerReceived( const can::CanMessage & answer)
    {
        UMBA_ASSERT(m_state == States::WAIT_ANSWER);

        // ответ получен - отдаем его на парс и продолжаем синхронизацию

        m_slaves[ m_curSlave ]->setConnectionState(true);
        m_slaves[ m_curSlave ]->processAnswer( answer );

        m_state = States::SEARCH;
    }


    void Synchronizer :: panicOnIrrelevantAnswerReceived( const can::CanMessage & answer)
    {
        (void)answer;
        UMBA_ASSERT(m_state == States::WAIT_ANSWER);

        // этого не должно происходить, если только в сети нет других мастеров
        UMBA_ASSERT_FAIL();
    }

    void Synchronizer :: ignoreIrrelevantAnswer( const can::CanMessage & answer)
    {
        (void)answer;
    }

    void Synchronizer :: onConnectionFailure(void)
    {
        UMBA_ASSERT(m_state == States::WAIT_ANSWER);

        // связи нет - забиваем на этого слейва и синхронизируем дальше
        m_slaves[ m_curSlave ]->setConnectionState(false);

        m_state = States::SEARCH;
    }

} // namespace milliganjubus
