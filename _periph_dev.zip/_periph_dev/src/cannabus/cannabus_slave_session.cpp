
/***********************************************************************************************************************************
Файл-реализация процессора протокола cannabus+ для ведомого устройства

Разработчик: Иван Бубников, лаборатория 5215

Разработано в рамках проекта "Курс-ЛИ", взято из прошивки драйвера ДПТ

Модифицировано Александром Сафоновым:
    - В Курс-ЛИ этот модуль вертелся во FreeRTOS, здесь он работает напрямую из мейна, в связи с этим из файла выброшены вызовы
      ртосовской функции "osTaskYIELD", а вызовы системного времени реализованы через службу времени, а не через РТОС
    - Под руководством И. Б. добавлен вызов коллбэка по восстановлению связи, в обработку потери связи добавлена запись флага потери,
      а коллбэк по восстановлению переименован в "m_onConnectionRestored"
***********************************************************************************************************************************/


#include "cannabus_slave_session.h"

namespace cannabus
{

    /**************************************************************************************************
    Описание:  Воркер для слейва каннабуса
    Аргументы: Время
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    void SlaveSession::work( uint32_t curTime )
    {
        UMBA_ASSERT( m_can->isInited() == true );

        auto result = m_can->tryToReceive( m_req );

        //пришло что-то годное
        if( result )
        {
            m_lastCallTime = curTime;
            process();

            //если не бродкаст - шлём ответ
            if( isAnswerNeeded() == true )
            {
                while( m_can->isReadyToTransmit() != true ) {;}
               
                auto sendState = m_can->transmitMessage( m_ans );
                
                if( sendState != can::ReturnState::OK )
                {
                    UMBA_ASSERT_FAIL();
                }
            }
            
            // а связь была потеряна
            if( m_isConnected == false )
            {
                m_isConnected = true;
 
                if( m_onConnectionRestored )
                {
                    m_onConnectionRestored();
                }
            }
        }
        else
        {
            if( curTime - m_lastCallTime > m_request_timeout_max )
            {
                if( m_isConnected )
                {
                    if( m_onConnectionLost )
                    {
                        m_onConnectionLost();
                        m_isConnected = false;
                    }
                }
            }

            // Проверка статуса ошибки CAN
            // Если контроллер устал от ошибок и отключился от линии, перезапустить его, переинициализировать буфера
            if( m_can->getErrorState() == can::CanErr::BUS_OFF )
            {
                //переинициализирую can и перераспределяю буферы
                //m_can->reset();
                #warning No reset yet!
                UMBA_ASSERT_FAIL(); 
            }
        }
    }


    /**************************************************************************************************
    Описание:  Отправка высокоприоритетного сообщения
    Аргументы: Массив номеров регистров
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    void SlaveSession::sendHighPrioMessage( umba::IArray<uint8_t> & roRegNum )
    {
        auto cnt = roRegNum.size();
            
        for( uint8_t i = 0; i < cnt ; i++ )
        {
            m_ans.data[2 * i] = roRegNum[i];
            m_ans.data[2 * i + 1] = m_table->getRegVal( roRegNum[i] );
        }
        
        //размер в 2 раза больше количества регистров
        m_ans.length = cnt * 2;

        m_ans.id = id_filter_msg_type_high_prio_from_slave | ( m_slaveAdr << id_offset_addr ) | FCode::READ_REGS_SERIES;
        
        //посылать, пока не смогу
        can::ReturnState result = can::ReturnState::OK;
        while( ( m_can->isReadyToTransmit() != true ) && ( result != can::ReturnState::OK ) )
        {
            result = m_can->transmitMessage( m_ans );
        }
    }
    
    /**************************************************************************************************
    Описание:  Обработка принятого запроса
    Аргументы: Указатель на запрос, указатель на ответ
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    void SlaveSession::process()
    {
        FCode fCode = FCode::READ_REGS_RANGE;
        fCode.fromInt( m_req.id & id_mask_fcode );

        //если что-то пойдёт не так, то надо будет отвечать сообщением с длиной 0
        m_ans.length = 0;

        switch ( fCode )
        {
            //стандартные
            case FCode::WRITE_REGS_RANGE:
                writeRegsRange();
                break;
            case FCode::WRITE_REGS_SERIES:
                writeRegsSeries();
                break;
            case FCode::READ_REGS_RANGE:
                readRegsRange();
                break;
            case FCode::READ_REGS_SERIES:
                readRegsSeries();
                break;
            //специальные
            case FCode::SPECIAL_FUNCTION1:
                specialFunction( 0 );
                break;
            case FCode::SPECIAL_FUNCTION2:
                specialFunction( 1 );
                break;
            case FCode::SPECIAL_FUNCTION3:
                specialFunction( 2 );
                break;
            case FCode::SPECIAL_FUNCTION4:
                specialFunction( 3 );
                break;

            default:
                UMBA_ASSERT_FAIL();
        }

        //вытащил адрес из запроса
        uint8_t adr = ( m_req.id & id_mask_addr ) >> id_offset_addr;

        //прямое обращение
        if( adr == addr_direct_access )
        {
            adr = m_slaveAdr;
        }

        //заполнил поле id ответа
        m_ans.id = id_filter_msg_type_answer | ( adr << id_offset_addr ) | fCode.toInt();
    }

    /**************************************************************************************************
    Описание:  Функция записи диапазона регистров
    Аргументы: Нет
    Возврат:   Нет
    Замечания:

        Структура обрабатываемого запроса:
        -------------------------------------------------
        | StartRegAdr | EndRegAdr | Data0 | ... | DataN |
        -------------------------------------------------
               0            1         2            2+N

        Структура подготавливаемого ответа:
        ---------------------------
        | StartRegAdr | EndRegAdr |
        ---------------------------
              0             1

    **************************************************************************************************/
    bool SlaveSession::writeRegsRange()
    {
        uint8_t regAdrStart = m_req.data[0];
        uint8_t regAdrEnd = m_req.data[1];
        uint8_t regsTotal = regAdrEnd - regAdrStart + 1;

        if( m_req.length != regsTotal + 2 )
            return false;

        if( regAdrEnd < regAdrStart )
            return false;

        if( regsTotal > max_regs_in_range )
            return false;

        //проверяем, что регистры RW
        for( uint8_t i = 0; i < regsTotal; i++ )
        {            
            if( !m_table->isRegNumRw( regAdrStart + i ) )
                return false;
        }

        for( uint8_t i = 0; i < regsTotal; i++ )
        {
            m_table->setRegVal( regAdrStart + i, m_req.data[2 + i] );
        }
        m_ans.data[0] = regAdrStart;
        m_ans.data[1] = regAdrEnd;
        m_ans.length = 2;

        return true;
    }

    /**************************************************************************************************
    Описание:  Функция записи серии регистров
    Аргументы: Нет
    Возврат:   Нет
    Замечания:

        Структура обрабатываемого запроса:
        --------------------------------------------
        |  RegAdr0 | Data0 | ... | RegAdrN | DataN |
        --------------------------------------------
             0         1             N*2     N*2+1

        Структура подготавливаемого ответа:
        ---------------------------
        | RegAdr0 | ... | RegAdrN |
        ---------------------------
             1               N

    **************************************************************************************************/
    bool SlaveSession::writeRegsSeries()
    {
        if( m_req.length % 2 != 0 )
            return false;

        for( uint8_t i = 0; i < m_req.length; i += 2 )
        {
            if( !m_table->isRegNumRw( m_req.data[i] ) )
                return false;
        }

        uint8_t cnt = 0;
        for( uint8_t i = 0; i < m_req.length; i += 2 )
        {
            m_table->setRegVal( m_req.data[i], m_req.data[i + 1] );
            m_ans.data[cnt] = m_req.data[i];
            cnt++;
        }
        m_ans.length = cnt;

        return true;
    }


    /**************************************************************************************************
    Описание:  Функция чтения диапазона регистров
    Аргументы: Нет
    Возврат:   Нет
    Замечания:

        Структура обрабатываемого запроса:
        ---------------------------
        | StartRegAdr | EndRegAdr |
        ---------------------------
               0           1

        Структура подготавливаемого ответа:
        -------------------------------------------------
        | StartRegAdr | EndRegAdr | Data0 | ... | DataN |
        -------------------------------------------------
               0           1          2            2+N

    **************************************************************************************************/
    bool SlaveSession::readRegsRange()
    {
        uint8_t regAdrStart = m_req.data[0];
        uint8_t regAdrEnd = m_req.data[1];
        uint8_t regsTotal = regAdrEnd - regAdrStart + 1;

        if( m_req.length != 2 )
            return false;

        if( regAdrEnd < regAdrStart )
            return false;

        if( regsTotal > max_regs_in_range )
            return false;


        for( uint8_t i = 0; i < regsTotal; i++ )
        {
            if( !m_table->isRegNumValid( regAdrStart + i ) )
                return false;
        }

        m_ans.data[0] = regAdrStart;
        m_ans.data[1] = regAdrEnd;

        for( uint8_t i = 0; i < regsTotal; i++ )
        {
            m_ans.data[2 + i] = m_table->getRegVal( regAdrStart + i );
        }

        m_ans.length = 2 + regsTotal;

        return true;
    }

    /**************************************************************************************************
    Описание:  Функция чтения серии регистров
    Аргументы: Нет
    Возврат:   Нет
    Замечания:

        Структура обрабатываемого запроса:
        -----------------------------
        | RegAddr0 | ... | RegAddrN |
        -----------------------------
             0                N

        Структура подготавливаемого ответа:
        ----------------------------------------------
        |  RegAddr0 | Data0 | ... | RegAddrN | DataN |
        ----------------------------------------------
              0         1            N*2       N*2+1

    **************************************************************************************************/
    bool SlaveSession::readRegsSeries()
    {
        if( m_req.length > max_regs_in_series )
            return false;

        if( m_req.length <= 0 )
            return false;

        for( uint8_t i = 0; i < m_req.length; i++ )
        {
            if( !m_table->isRegNumValid( m_req.data[i] ) )
                return false;
        }

        uint8_t cnt = 0;
        for( uint8_t i = 0; i < m_req.length; i++ )
        {
            m_ans.data[cnt] = m_req.data[i];
            m_ans.data[cnt + 1] = m_table->getRegVal( m_req.data[i] );
            cnt += 2;
        }
        m_ans.length = cnt;

        return true;
    }


    /**************************************************************************************************
    Описание:  Специальная функция
    Аргументы: Номер функции
    Возврат:   Успех\не успех
    Замечания:
    **************************************************************************************************/
    bool SlaveSession::specialFunction( uint8_t num )
    {
        UMBA_ASSERT( num <= 4 );
        UMBA_ASSERT( num > 0 );

        if( m_req.length != m_spec[num].regRxLength )
            return false;

        //записали себе
        for( uint8_t i = 0; i < m_spec[num].regRxLength; i++ )
        {
            m_table->setRegVal( m_spec[num].regRx[i], m_req.data[i] );
        }

        //записали мастеру
        for( uint8_t i = 0; i < m_spec[num].regTxLength; i++ )
        {
            m_ans.data[i] = m_table->getRegVal( m_spec[num].regTx[i] );
        }
        m_ans.length = m_spec[num].regTxLength;

        return true;
    }

    /**************************************************************************************************
    Описание:  Создание ответа на ошибочный запрос
    Аргументы: Указатель на ответ
    Возврат:   -
    Замечания: -
    **************************************************************************************************/
    void SlaveSession::generateNack()
    {
        m_ans.length = 0;
    }

    /**************************************************************************************************
    Описание:  Проверка, нужен ли ответ на принятый запрос
    Аргументы: ID сообщения-запроса
    Возврат:   True, если придется отвечать
    Замечания: -
    **************************************************************************************************/
    bool SlaveSession::isAnswerNeeded()
    {
        return ( ( m_req.id & id_mask_addr ) != filter_broadcast );
    }
}

