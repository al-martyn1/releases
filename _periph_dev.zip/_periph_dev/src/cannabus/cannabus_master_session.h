#pragma once

#include "project_config.h"
#include "cannabus_common.h"
#include "can/i_can.h"
#include "callbacks/callbacks.h"

namespace cannabus
{
    class MasterSession
    {

    public:

        explicit MasterSession(uint32_t answer_timeout_max, uint32_t request_sending_timeout_max = 10) :
            m_answer_timeout_max( answer_timeout_max ),
            m_request_sending_timeout_max( request_sending_timeout_max )
        {

        }

        typedef callback::Callback<void ( const can::CanMessage &)> OnAnswerReceived;

        void init(can::ICan & can,
                  OnAnswerReceived onAnswerReceived,
                  callback::VoidCallback onConnectionFailure,
                  OnAnswerReceived onIrrelevantAnswerReceived = OnAnswerReceived() ); // этот параметр можно не задавать

        void sendRequest(can::CanMessage & request);

        void work(uint32_t curTime);

    protected:

        STRONG_ENUM(SessionStates, WAITING_REQUEST, SENDING_REQUEST, WAITING_FOR_SENDING_COMPLETE, WAITING_ANSWER);

        static const uint8_t m_repeats_max = 3;

        // копировать запрещено
        MasterSession( const MasterSession & rhs );
        MasterSession & operator=( MasterSession & s);

        bool isAnswerRelevant(void) const;

        bool isAnswerAdressValid(void) const;

        bool isWriteRegsRangeValid() const;
        bool isWriteRegsSeriesValid() const;
        bool isReadRegsRangeValid() const;
        bool isReadRegsSeriesValid() const;

        //специальные функции пока не проверяю
        bool specialFunction( uint8_t num) const
        {
            (void)num;
            return true;
        }

        uint32_t m_curCallTime = 0;

        can::ICan * m_can = nullptr;

        can::CanMessage m_request = {};
        can::CanMessage m_answer = {};

        uint32_t m_lastRequestTime = 0;

        const uint32_t m_answer_timeout_max;
        const uint32_t m_request_sending_timeout_max;

        uint8_t m_repeatsCount = 0;

        SessionStates m_state = SessionStates::WAITING_REQUEST;

        callback::VoidCallback m_onConnectionFailure = {};
        OnAnswerReceived m_onAnswerReceived = {};
        OnAnswerReceived m_onIrrelevantAnswer = {};

    };

} // namespace cannabus
