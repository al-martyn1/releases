#pragma once

namespace cannabus
{


    STRONG_ENUM( FCode, WRITE_REGS_RANGE  = 0,
                        WRITE_REGS_SERIES = 1,
                        READ_REGS_RANGE   = 2,
                        READ_REGS_SERIES  = 3,
                        SPECIAL_FUNCTION1 = 4,
                        SPECIAL_FUNCTION2 = 5,
                        SPECIAL_FUNCTION3 = 6,
                        SPECIAL_FUNCTION4 = 7 );

    //структура для передачи в функцию регистров device-specific функций
    template< uint32_t TSizeRx, uint32_t TSizeTx >
    struct SpecialRegNames
    {
        uint8_t rxRegs[TSizeRx];
        uint8_t txRegs[TSizeTx];
    };


    //параметры каннабуса общие

    // Смешения полей в ID сообщения
    static const uint8_t id_offset_fcode = 0;
    static const uint8_t id_offset_addr = 3;
    static const uint8_t id_offset_msg_type = 9;

    // Адрес, используемый мастером для широковещательной передачи команд
    static const uint8_t addr_broadcast = 0;
    // Фильтр для широковещательного адреса
    static const uint8_t filter_broadcast = 0;

    // Адрес прямого обращения
    static const uint32_t addr_direct_access = 61;

    // Фильтр для адреса прямого обращения
    static const uint32_t id_filter_direct_access = (addr_direct_access << id_offset_addr);


    // Маска для выделения адреса в ID
    static const uint32_t id_mask_addr = 0x01F8;
    // Маска для выделения кода функции в ID
    static const uint32_t id_mask_fcode = 0x0007;
    // Маска для выделения типа сообщения в ID
    static const uint32_t id_mask_msg_type = 0x0600;

    // Фильтр для кода типа сообщения "запрос ведущего"
    static const uint32_t id_filter_msg_type_request = 0x0400;
    // Фильтр для кода типа сообщения "ответ ведомого"
    static const uint32_t id_filter_msg_type_answer = 0x0600;
    // Фильтр для кода типа сообщения "высокоприоритетное сообщение ведущего"
    static const uint32_t id_filter_msg_type_high_prio_from_master = 0x0000;
    // Фильтр для кода типа сообщения "высокоприоритетное сообщение ведомого"
    static const uint32_t id_filter_msg_type_high_prio_from_slave = 0x0200;

    // Маска для неиспользуемых буферов
    static const uint32_t id_mask_no_addr = 0x0000;
    // Фильтр для неиспользуемых буферов
    static const uint32_t id_filter_no_addr = 0x01F8;

    // Максимальные количества регистров для функций
    static const uint8_t max_regs_in_range = 6;
    static const uint8_t max_regs_in_series = 4;

    static const uint8_t max_regs_in_specific = 8;
}

