#pragma once

#include "cannabus_common.h"
#include "i_reg_table.h"
#include "can/i_can.h"
#include "cannabus_request_creator.h"

namespace cannabus
{

    class Slave
    {

    public:

        Slave() :
            m_masterTable(0),
            m_reqCreator(),
            m_slaveAdr(0),
            m_roUpdateInterval(500),
            m_lastRoUpdateTime(0),
            m_isConnected(false),
            m_roPart(0),
            m_connectionFailuresCount(0),
            // чтобы первое обновление было корректным
            m_roBeginReg(0xFF),
            m_roEndreg(0xFF)
        {

        }

        virtual ~Slave()
        {}

        // что именно с чем синхронизировать - определит потомок
        virtual void synchronize() = 0;

        // таблицу тоже создает потомок
        virtual IRegTable * getSlaveTable() = 0;

        virtual void init( IRegTable & masterTable, uint8_t devAddr, uint32_t roUpdateInterval )
        {
            m_masterTable = &masterTable;
            m_reqCreator.init(devAddr);

            m_slaveAdr = devAddr;
            m_roUpdateInterval = roUpdateInterval;
        }

        //тут только общие функции проверю, device-specific пока не поддерживаются
        void processAnswer( const can::CanMessage & answer )
        {
            uint8_t ansFcode = ( answer.id & id_mask_fcode );

            switch ( ansFcode )
            {
                //стандартные
                case FCode::WRITE_REGS_RANGE: // запись ничего в таблицу не пишет
                    break;
                case FCode::WRITE_REGS_SERIES: // запись ничего в таблицу не пишет
                    break;
                case FCode::READ_REGS_RANGE:
                    readRegsRange( answer );
                    break;
                case FCode::READ_REGS_SERIES:
                    readRegsSeries( answer );
                    break;
                //специальные
                case FCode::SPECIAL_FUNCTION1:
                    specialFunction( 0, answer );
                    break;
                case FCode::SPECIAL_FUNCTION2:
                    specialFunction( 1, answer );
                    break;
                case FCode::SPECIAL_FUNCTION3:
                    specialFunction( 2, answer );
                    break;
                case FCode::SPECIAL_FUNCTION4:
                    specialFunction( 3, answer );
                    break;

                default:
                    UMBA_ASSERT_FAIL();
            }

        }

        bool isRwUpdateRequired(void)
        {
            if( getSlaveTable()->getReadyToSendRwRegsTotal() != 0)
                return true;
            else
                return false;
        }

        bool isRoUpdateRequired(uint32_t curTime) const
        {
            if(curTime - m_lastRoUpdateTime > m_roUpdateInterval)
                return true;
            else
                return false;
        }

        void getRwRequest(can::CanMessage & req)
        {
            uint32_t readyToSendNum = getSlaveTable()->getReadyToSendRwRegsTotal();

            if (readyToSendNum == 0)
            {
                UMBA_ASSERT_FAIL();
            }

            // надо набрать серию
            cannabus::RequestCreator::Register series[max_regs_in_range];

            // максимальная длина сообщения ограничена
            if (readyToSendNum > max_regs_in_range)
                readyToSendNum = max_regs_in_range;

            for (uint8_t i = 0; i < readyToSendNum; ++i)
            {
                uint8_t regNum = getSlaveTable()->getReadyToSendRwReg();

                series[i].num = regNum;
                series[i].val = getSlaveTable()->getRegVal(regNum);
            }

            m_reqCreator.createWriteSeries(req, series, readyToSendNum );
        }

        void getRoRequest(can::CanMessage & req, uint32_t curTime)
        {
            m_lastRoUpdateTime = curTime;

            // нужно обновить все регистры
            // они могут не влезть в один пакет миллиганджубуса, поэтому их нужно разбить на диапазоны

            // эти переменные разные для разных объектов этого класса
            // поэтому их  нельзя делать static
            const uint16_t min = getSlaveTable()->getRoMinRegNum();
            const uint16_t max = getSlaveTable()->getRoMaxRegNum();

            // типа шагаем диапазонами максимальной длины по всей таблице
            if( m_roEndreg >= max )
                m_roBeginReg = (uint8_t)min;
            else
                m_roBeginReg = m_roEndreg + 1;

            m_roEndreg = m_roBeginReg + max_regs_in_range - 1;

            // uint16 вроде не должен переполниться
            if( m_roEndreg > max)
                m_roEndreg = (uint8_t)max;

            for(uint16_t i=m_roBeginReg; i <= m_roEndreg; i++)
            {
                uint8_t len = getSlaveTable()->getRegLength( (uint8_t)i );
            }

            UMBA_ASSERT( m_roBeginReg >= min && m_roBeginReg <= max );
            UMBA_ASSERT( m_roEndreg >= min && m_roEndreg <= max );

            m_reqCreator.createReadRange(req, m_roBeginReg, m_roEndreg);
        }

        void setConnectionState(bool state)
        {
            m_isConnected = state;

            if( state == false )
            {
                m_connectionFailuresCount++;
            }
        }

        virtual bool isConnected(void) const
        {
            return m_isConnected;
        }

        virtual uint32_t getConnectionFailures(void) const
        {
            return m_connectionFailuresCount;
        }

        uint8_t getAddress(void) const
        {
            return m_slaveAdr;
        }


    protected:

        // проброс значения из регистра мастера в регистр слейва
        // если мастерный регистр изменился
        void syncRwReg8( uint8_t masterReg, uint8_t slaveReg )
        {
            if( ! m_masterTable->checkRegUpdate( masterReg ) )
            {
                return;
            }

            uint8_t rwVal = m_masterTable->getRegVal(masterReg);

            getSlaveTable()->setRegVal( slaveReg, rwVal);
        }

        // проброс двухбайтного регистра, делает лок
        void syncRwReg16(uint8_t lowMasterReg, uint8_t lowSlaveReg)
        {
            if( ! m_masterTable->checkReg16Update(lowMasterReg) )
                return;

            uint16_t rwVal = m_masterTable->getReg16Val(lowMasterReg);
            getSlaveTable()->setReg16Val( lowSlaveReg, rwVal );
        }

        // проброс четырехбайтного регистра
        void syncRwReg32(uint8_t lowMasterReg, uint8_t lowSlaveReg)
        {
            if( ! m_masterTable->checkReg32Update(lowMasterReg) )
                return;

            uint32_t rwVal = m_masterTable->getReg32Val(lowMasterReg);
            getSlaveTable()->setReg32Val( lowSlaveReg, rwVal );
        }

        // проброс регистра из слейва в мастер
        void syncRoReg8(uint8_t masterReg, uint8_t slaveReg)
        {
            uint8_t roVal = getSlaveTable()->getRegVal(slaveReg);

            m_masterTable->setRegVal( masterReg, roVal );
        }

        // проброс 16-битного регистра из слейва в мастер, делает лок
        void syncRoReg16(uint8_t lowMasterReg, uint8_t lowSlaveReg)
        {
            if( ! getSlaveTable()->checkReg16Update(lowSlaveReg) )
                return;

            uint16_t roVal = getSlaveTable()->getReg16Val(lowSlaveReg);

            m_masterTable->setReg16Val( lowMasterReg, roVal );
        }

        // проброс 32-битного регистра из слейва в мастер, делает лок
        void syncRoReg32(uint8_t lowMasterReg, uint8_t lowSlaveReg)
        {
            if( ! getSlaveTable()->checkReg32Update(lowSlaveReg) )
                return;

            uint32_t roVal = getSlaveTable()->getReg32Val(lowSlaveReg);

            m_masterTable->setReg32Val( lowMasterReg, roVal );
        }

        IRegTable * m_masterTable;

        RequestCreator m_reqCreator;

        uint8_t m_slaveAdr;

        uint32_t m_roUpdateInterval;
        uint32_t m_lastRoUpdateTime;

        bool m_isConnected;

        uint16_t m_roPart;

        uint32_t m_connectionFailuresCount;

        uint8_t m_roBeginReg;
        uint8_t m_roEndreg;

    private:

        /**************************************************************************************************
        Описание:  Функция чтения диапазона регистров
        Аргументы: Нет
        Возврат:   Верный ответ или нет
        Замечания:

            Структура запроса:
            ---------------------------
            | StartRegAdr | EndRegAdr |
            ---------------------------
                   0           1

            Структура ответа:
            -------------------------------------------------
            | StartRegAdr | EndRegAdr | Data0 | ... | DataN |
            -------------------------------------------------
                   0           1          2            2+N

        **************************************************************************************************/
        void readRegsRange( const can::CanMessage & answer )
        {
            uint8_t regAdrStart = answer.data[0];
            uint8_t regAdrEnd = answer.data[1];
            uint8_t regsTotal = regAdrEnd - regAdrStart + 1;

            for( uint8_t i = 0; i < regsTotal; i++ )
            {
                getSlaveTable()->setRegVal( regAdrStart + i, answer.data[2 + i] );
            }
        }

        /**************************************************************************************************
        Описание:  Функция чтения серии регистров
        Аргументы: Нет
        Возврат:   Верный ответ или нет
        Замечания:

            Структура запроса:
            -----------------------------
            | RegAddr0 | ... | RegAddrN |
            -----------------------------
                 0                N

            Структура ответа:
            ----------------------------------------------
            |  RegAddr0 | Data0 | ... | RegAddrN | DataN |
            ----------------------------------------------
                  0         1            N*2       N*2+1

        **************************************************************************************************/
        void readRegsSeries( const can::CanMessage & answer )
        {
            for( uint8_t i = 1; i < answer.length; i += 2 )
            {
                getSlaveTable()->setRegVal( answer.data[i], answer.data[i + 1] );
            }
        }

        //специальные функции пока не реализовал
        void specialFunction( uint8_t num, const can::CanMessage & answer )
        {
            (void)num;
        }

        // копировать запрещено
        Slave( const Slave & rhs);
        Slave & operator=( Slave & s);

    };

} // namespace milliganjubus
