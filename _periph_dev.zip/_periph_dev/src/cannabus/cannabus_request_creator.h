#pragma once

#include <stdint.h>

#include "project_config.h"
#include "cannabus_common.h"
#include "can/i_can.h"

namespace cannabus
{

    class RequestCreator
    {

    public:

        inline void init( uint8_t deviceAdr )
        {
            UMBA_ASSERT( deviceAdr < 62 ); // по спецификации can неположено 7 единиц в ID

            m_deviceAddress = deviceAdr;
            m_ID = ( m_deviceAddress << id_offset_addr ) | ( id_filter_msg_type_request );
        }

        struct Register
        {
            Register(void): num(0), val(0)
            {
                ;
            }

            uint8_t num;
            uint8_t val;
        };

        void createWriteRange( can::CanMessage & request, uint8_t startReg, uint8_t endReg, const uint8_t * values );

        void createWriteSeries( can::CanMessage & request, const Register * series, uint8_t len );

        void createReadRange( can::CanMessage & request, uint8_t regNumBegin, uint8_t regNumEnd );

        void createReadSeries( can::CanMessage & request, const Register * series, uint8_t len );

    protected:

        uint8_t m_deviceAddress = 0;
        uint32_t m_ID = ( 0 << id_offset_addr ) | ( id_filter_msg_type_request );

    };

}
