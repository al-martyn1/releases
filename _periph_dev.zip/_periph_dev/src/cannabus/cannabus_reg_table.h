#pragma once

#include <stdint.h>
#include "i_cannabus_reg_table.h"
#include "common_functions/common_functions.h"
#include "umba_array/umba_array.h"

namespace cannabus
{

    template <uint8_t TRoRegMin, uint8_t TRoRegMax,
              uint8_t TRwRegMin, uint8_t TRwRegMax>
    class CannabusRegTable : public ICannabusRegTable
    {

    public:

        CannabusRegTable(void) : m_roTable(),
            m_rwTable(),
            m_isLocked(false)
        {
            UMBA_STATIC_ASSERT( TRwRegMax >= TRwRegMin);
            UMBA_STATIC_ASSERT( TRoRegMax >= TRoRegMin);

            UMBA_STATIC_ASSERT( TRwRegMin > TRoRegMax);

        }

        PRAGMA_SUPPRESS_POINTLESS_COMPARISON_BEGIN

        //проверка
        //проверка
        virtual bool isRegNumValid(uint8_t regNum) const
        {
            return ( isRegNumRw(regNum) || isRegNumRo(regNum) );
        }
        virtual bool isRegNumRw(uint8_t regNum) const
        {
            return ( (regNum >= TRwRegMin) && (regNum <= TRwRegMax) );
        }
        virtual bool isRegNumRo(uint8_t regNum) const
        {
            return ( (regNum >= TRoRegMin) && (regNum <= TRoRegMax) );
        }

        // просто записать значение регистра
        virtual void setRegVal(uint8_t regNum, uint8_t val)
        {
            // rw-регистр
            if( regNum >= TRwRegMin && regNum <= TRwRegMax )
            {
                m_rwTable.setRegVal(regNum, val);
            }
            // ro-регистр
            else if(regNum >= TRoRegMin && regNum <= TRoRegMax )
            {
                m_roTable.setRegVal(regNum, val);
            }
            else
            {
                UMBA_ASSERT_FAIL();
            }
        }

        virtual uint8_t getRegVal(uint8_t regNum)
        {
            // rw-регистр
            if( regNum >= TRwRegMin && regNum <= TRwRegMax )
            {
                return m_rwTable.getRegVal(regNum);
            }
            // ro-регистр
            else if(regNum >= TRoRegMin && regNum <= TRoRegMax )
            {
                return m_roTable.getRegVal(regNum);
            }
            else
            {
                UMBA_ASSERT_FAIL();
                return 0;
            }
        }

        virtual bool checkRegUpdate(uint8_t regNum)
        {
            if( isRegChanged(regNum) )
            {
                markRegUnchanged(regNum);
                return true;
            }
            else
            {
                return false;
            }
        }

        // сдвоенные регистры и двухбайтные значения

        virtual void setReg16Val(uint8_t lowRegNum, uint16_t val)
        {
            uint8_t low;
            uint8_t high;

            common_functions::uint16ToBytes(val, low, high);

            {
                Lock lock(this);

                setRegVal( lowRegNum,   low );
                setRegVal( lowRegNum+1, high );

                setRegLength( lowRegNum, 2 );
            }
        }

        virtual uint16_t getReg16Val( uint8_t lowRegNum )
        {
            Lock lock(this);
            setRegLength( lowRegNum, 2);
            return common_functions::bytesToUint16( getRegVal( lowRegNum ), getRegVal( lowRegNum+1) );
        }

        // регистр считается обновленным только если все его части обновлялись одинаковое (положительное) количество раз
        // если это так, то флаг обновленности будет сброшен
        virtual bool checkReg16Update( uint8_t lowRegNum)
        {
            Lock lock(this);

            setRegLength( lowRegNum, 2 );

            uint8_t low = getChangeCount( lowRegNum);
            uint8_t high = getChangeCount( lowRegNum+1);

            bool result = (low == high) && low != 0;

            if( result )
            {
                markRegUnchanged( lowRegNum );
                markRegUnchanged( lowRegNum+1 );
            }

            return result;
        }

        // счетверенные регистры и четырехбайтные значения
        virtual void setReg32Val( uint8_t lowRegNum, uint32_t val )
        {
            uint8_t buf[4];
            common_functions::uint32ToBytes(val, buf[0], buf[1], buf[2], buf[3]);

            Lock lock(this);

            setRegLength(lowRegNum, 4 );

            setRegVal( lowRegNum + 0, buf[0] );
            setRegVal( lowRegNum + 1, buf[1] );
            setRegVal( lowRegNum + 2, buf[2] );
            setRegVal( lowRegNum + 3, buf[3] );
        }
        virtual uint32_t getReg32Val( uint8_t lowRegNum )
        {
            Lock lock(this);

            setRegLength( lowRegNum, 4 );

            return common_functions::bytesToUint32( getRegVal( lowRegNum   ),
                                                    getRegVal( lowRegNum+1 ),
                                                    getRegVal( lowRegNum+2 ),
                                                    getRegVal( lowRegNum+3 ) );
        }

        // регистр считается обновленным только если все его части обновлялись одинаковое (положительное) количество раз
        // если это так, то флаг обновленности будет сброшен
        virtual bool checkReg32Update( uint8_t lowRegNum )
        {
            uint8_t check[4];

            Lock lock(this);

            setRegLength( lowRegNum, 4 );

            check[0] = getChangeCount(lowRegNum + 0);
            check[1] = getChangeCount(lowRegNum + 1);
            check[2] = getChangeCount(lowRegNum + 2);
            check[3] = getChangeCount(lowRegNum + 3);

            bool result = (check[0] == check[1]) &&
                          (check[1] == check[2]) &&
                          (check[2] == check[3]) &&
                          check[0] != 0;

            if( result )
            {
                markRegUnchanged(lowRegNum + 0);
                markRegUnchanged(lowRegNum + 1);
                markRegUnchanged(lowRegNum + 2);
                markRegUnchanged(lowRegNum + 3);
            }

            return result;
        }

        virtual uint8_t getRegLength( uint8_t lowRegNum )
        {
            // rw-регистр
            if( lowRegNum >= TRwRegMin && lowRegNum <= TRwRegMax )
            {
                return m_rwTable.getRegLength(lowRegNum);
            }
            // ro-регистр
            else if(lowRegNum >= TRoRegMin && lowRegNum <= TRoRegMax )
            {
                return m_roTable.getRegLength(lowRegNum);
            }
            else
            {
                UMBA_ASSERT_FAIL();
                return 0;
            }
        }

        virtual void setRegLength( uint8_t lowRegNum, uint8_t length )
        {
            // rw-регистр
            if( lowRegNum >= TRwRegMin && lowRegNum <= TRwRegMax )
            {
                m_rwTable.setRegLength(lowRegNum, length);
            }
            // ro-регистр
            else if(lowRegNum >= TRoRegMin && lowRegNum <= TRoRegMax )
            {
                m_roTable.setRegLength(lowRegNum, length);
            }
            else
            {
                UMBA_ASSERT_FAIL();
            }
        }

        PRAGMA_END


        virtual uint8_t getReadyToSendRwReg(void)
        {
            return m_rwTable.getReadyToSendReg8();
        }

        virtual uint32_t getReadyToSendRwRegsTotal(void)
        {
            Lock lock(this);
            return m_rwTable.getReadyToSendRegsTotal();
        }

        virtual uint8_t getRwMinRegNum(void)
        {
            return TRwRegMin;
        }

        virtual uint8_t getRwMaxRegNum(void)
        {
            return TRwRegMax;
        }

        virtual uint8_t getRwRegsTotal(void)
        {
            return (TRwRegMax - TRwRegMin + 1);
        }

        virtual uint8_t getRoMinRegNum(void)
        {
            return TRoRegMin;
        }

        virtual uint8_t getRoMaxRegNum(void)
        {
            return TRoRegMax;
        }

        virtual uint8_t getRoRegsTotal(void)
        {
            return (TRoRegMax - TRoRegMin + 1);
        }


        // локи для всей таблицы
        virtual bool isTableLocked(void)
        {
            return m_isLocked;
        }

        virtual void lockTable(void)
        {
            UMBA_ASSERT(m_isLocked == false);
            m_isLocked = true;
        }

        virtual void unlockTable(void)
        {
            UMBA_ASSERT(m_isLocked == true);
            m_isLocked = false;
        }



    protected:

        template < uint8_t TStart_Offset, uint8_t TRegsMax >
        class InnerTable
        {

        public:

            /***************************************************************************************************
                                                МЕТОДЫ
            ***************************************************************************************************/

            InnerTable() :
                registers()
            {
                ;
            }

            void setRegVal(uint8_t regNum, uint8_t val)
            {
                uint8_t relRegNum = regNum_abs2rel(regNum);

                registers[relRegNum].changeVal(val);
            }

            uint8_t getReadyToSendReg8(void)
            {
                for(uint8_t i=0; i<TRegsMax; )
                {
//                     if( registers[i].getLength() != 1 )
//                     {
//                         i += registers[i].getLength();
//                         continue;
//                     }

                    if( registers[i].isChanged())
                    {
                        registers[i].markUnchanged();
                        return regNum_rel2abs(i);
                    }

                    i++;
                }

                UMBA_ASSERT_FAIL();
                return 0;
            }

            uint8_t getRegVal(uint8_t regNum)
            {
                regNum = regNum_abs2rel(regNum);

                return registers[regNum].getVal();
            }

            bool isRegChanged(uint8_t regNum)
            {
                uint8_t relRegNum = regNum_abs2rel(regNum);
                return registers[relRegNum].isChanged();
            }

            void markRegUnchanged(uint8_t regNum)
            {
                uint8_t relRegNum = regNum_abs2rel(regNum);
                registers[relRegNum].markUnchanged();
            }

            uint32_t getReadyToSendRegsTotal(void)
            {
                uint32_t q = 0;
                for(uint8_t i=0; i<TRegsMax; i++)
                {
                    if( registers[i].isChanged() )
                    {
                        q++;
                    }
                }

                return q;
            }

            uint8_t getChangeCount(uint8_t regNum)
            {
                uint8_t relRegNum = regNum_abs2rel(regNum);
                return registers[relRegNum].getChangeCount();
            }

            uint8_t getRegLength( uint8_t regNum )
            {
                uint8_t relRegNum = regNum_abs2rel(regNum);
                return registers[relRegNum].getLength();
            }

            void setRegLength( uint8_t regNum, uint8_t length )
            {
                uint8_t relRegNum = regNum_abs2rel(regNum);

                UMBA_ASSERT( relRegNum + length - 1 < TRegsMax );

                // многобайтные регистры не должны идти внахлест
                for( uint8_t i=1; i<length; i++)
                {
                    UMBA_ASSERT( registers[relRegNum + i].getLength() == 1 );
                }

                registers[relRegNum].setLength(length);
            }

        private:

            class Register
            {

            public:
                // забиваем дефолтные значения, которые не нужно отправлять, но доверять им тоже нельзя
                Register() :
                    val(0x00),
                    changeCount(0),
                    length( 1 )
                {
                    ;
                }

                uint8_t getVal(void) const
                {
                    return val;
                }

                uint8_t readVal(void)
                {
                    changeCount = 0;
                    return val;
                }

                void setVal(uint8_t v)
                {
                    val = v;
                }

                void changeVal(uint8_t v)
                {
                    static const uint8_t max = std::numeric_limits<uint8_t>::max();

                    val = v;

                    DATA_SYNCHRONIZATION_BARRIER();

                    changeCount++;

                    if( changeCount == max )
                    {
                        changeCount = 1;
                    }
                }

                uint8_t getChangeCount(void) const
                {
                    return changeCount;
                }

                bool isChanged(void) const
                {
                    return changeCount != 0;
                }

                void markUnchanged(void)
                {
                    changeCount = 0;
                }

                uint8_t getLength() const
                {
                    return length;
                }

                void setLength( uint8_t len )
                {
                    this->length = len;
                }


            private:

                uint8_t val;
                uint8_t changeCount;

                uint8_t length;
            };

            PRAGMA_SUPPRESS_POINTLESS_COMPARISON_BEGIN

            uint8_t regNum_abs2rel(uint8_t absRegNum)
            {

                absRegNum -= TStart_Offset;

                UMBA_ASSERT(absRegNum < TRegsMax);

                return absRegNum;
            }

            uint8_t regNum_rel2abs(uint8_t relRegNum)
            {

                relRegNum += TStart_Offset;

                UMBA_ASSERT(relRegNum < (TStart_Offset + TRegsMax) );

                return relRegNum;
            }

            PRAGMA_END


            Register registers[TRegsMax];

        }; //class InnerTable

        PRAGMA_SUPPRESS_POINTLESS_COMPARISON_BEGIN

        bool isRegChanged(uint8_t regNum)
        {
            // rw-регистр
            if( regNum >= TRwRegMin && regNum <= TRwRegMax )
            {
                bool t = m_rwTable.isRegChanged(regNum);
                return t;
            }
            // ro-регистр
            else if( regNum >= TRoRegMin && regNum <= TRoRegMax)
            {
                bool t = m_roTable.isRegChanged(regNum);
                return t;
            }
            else
            {
                UMBA_ASSERT_FAIL();
                return false;
            }
        }

        uint8_t getChangeCount(uint8_t regNum)
        {
            // rw-регистр
            if( regNum >= TRwRegMin && regNum <= TRwRegMax )
            {
                return m_rwTable.getChangeCount(regNum);
            }
            // ro-регистр
            else if( regNum >= TRoRegMin && regNum <= TRoRegMax)
            {
                return m_roTable.getChangeCount(regNum);
            }
            else
            {
                UMBA_ASSERT_FAIL();
                return 0;
            }
        }

        void markRegUnchanged(uint8_t regNum)
        {
            // rw-регистр
            if( regNum >= TRwRegMin && regNum <= TRwRegMax )
            {
                m_rwTable.markRegUnchanged(regNum);
            }
            // ro-регистр
            else if( regNum >= TRoRegMin && regNum <= TRoRegMax)
            {
                m_roTable.markRegUnchanged(regNum);
            }
            else
            {
                UMBA_ASSERT_FAIL();
            }
        }

        PRAGMA_END


        UMBA_STATIC_ASSERT_MSG( (TRoRegMax >= TRoRegMin) && (TRwRegMax >= TRwRegMin), max_should_not_be_less_than_min);

        // инкапсулируемые таблицы
        InnerTable<TRoRegMin, (TRoRegMax-TRoRegMin+1)> m_roTable;

        InnerTable<TRwRegMin, (TRwRegMax-TRwRegMin+1)> m_rwTable;

        bool m_isLocked;

    };
          
}

