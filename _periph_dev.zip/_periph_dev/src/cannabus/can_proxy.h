#pragma once

#include "project_config.h"
#include "Can/can.h"
#include "cannabus_common.h"
#include "FreeRTOS/freertos_wrapper.h"
#include "cannabus_reg_table.h"

namespace can
{
    /**************************************************************************************************
    Описание:   Класс-подмена исключительно для случая с богомазом
                когда надо несколько каннабусов в одном устройстве на одном кане
                классы умеют отправлять сообщения и работать каждый со своей приёмной очередью
    **************************************************************************************************/
    class CanProxy : public ICan
    {
    public:

        CanProxy( QueueHandle_t rxQueueFreertos ) :
            m_rxQueueFreertos( rxQueueFreertos ),
            m_mutex( NULL )
        {

        }
        virtual void setFilter(uint8_t bufN, uint32_t mask, uint32_t filter)
        {
            (void)bufN;
            (void)mask;
            (void)filter;
        }
        virtual CanErrStatus getErrStatus()
        {
            return can2.getErrStatus();
        }
        virtual bool isRxQueueOverflow()
        {
            return can2.isRxQueueOverflow();
        }
        virtual bool isTxQueueFull()
        {
            return can2.isTxQueueFull();
        }
        virtual uint32_t getBaudrate()
        {
            return can2.getBaudrate();
        }
        virtual bool isRxIdTypeErr()
        {
            return can2.isRxIdTypeErr();
        }
        virtual void clearRxIdTypeErr()
        {
            can2.clearRxIdTypeErr();
        }

        //прихардкодил отправку к can2
        virtual CanSendMsgResult sendMsg(CanMsg msg)
        {
            return can2.sendMsg(msg);
        }
        virtual void forceSendMsg(CanMsg msg)
        {
            can2.forceSendMsg(msg);
        }


        virtual QueueHandle_t getQueueHandle()
        {
            return m_rxQueueFreertos;
        }
        virtual SemaphoreHandle_t getMutexHandle()
        {
            return NULL;
        }

        virtual void reset( void )
        {
            can2.reset();
        }

        virtual bool isInited()
        {
            return true;
        }

    private:

        QueueHandle_t m_rxQueueFreertos;
        SemaphoreHandle_t m_mutex;

    };
}
