#include "cannabus/cannabus_master_session.h"

namespace cannabus
{

    void MasterSession :: init( can::ICan & can,
                                OnAnswerReceived onAnswerReceived,
                                callback::VoidCallback onConnectionFailure,
                                OnAnswerReceived onIrrelevantAnswerReceived )
    {
        m_can = &can;

        // порт наш навечно
        //UMBA_ASSERT( ! m_can->isLocked() );
        m_can->lock();

        // для тестов
        m_state = SessionStates::WAITING_REQUEST;

        m_onAnswerReceived = onAnswerReceived;
        m_onConnectionFailure = onConnectionFailure;
        m_onIrrelevantAnswer = onIrrelevantAnswerReceived;


    }

    void MasterSession :: sendRequest( can::CanMessage & request )
    {
        UMBA_ASSERT(m_state == SessionStates::WAITING_REQUEST);

        // реквест копируется
        m_request = request;

        m_state = SessionStates::SENDING_REQUEST;
    }


    void MasterSession :: work( uint32_t curTime )
    {
        UMBA_ASSERT(m_can);

        m_curCallTime = curTime;

        switch(m_state)
        {
        // просто ждем
        case SessionStates::WAITING_REQUEST:

            break;

        case SessionStates::SENDING_REQUEST:
        {
            if( m_can->isReadyToTransmit() == false )
            {
                break;
            }
            auto sendState = m_can->transmitMessage( m_request );

            if( sendState != can::ReturnState::OK )
            {
                UMBA_ASSERT_FAIL();
            }

            m_lastRequestTime = m_curCallTime;

            m_state = SessionStates::WAITING_ANSWER;


            break;
        }


        case SessionStates::WAITING_ANSWER:


            if( m_can->tryToReceive( m_answer ) == false )
            {
                // не слишком ли долго мы ждем
                if( m_curCallTime - m_lastRequestTime >= m_answer_timeout_max )
                {
                    // повторы не помогают - связь потеряна
                    if( m_repeatsCount >= m_repeats_max )
                    {
                        m_repeatsCount = 0;

                        m_onConnectionFailure();

                        // дальше можно слать новое сообщение
                        m_state = SessionStates::WAITING_REQUEST;

                        return;
                    }

                    // попробуем повторить текущее сообщение еще раз
                    m_repeatsCount++;

                    m_state = SessionStates::SENDING_REQUEST;
                    return;
                }
            }
            // проверяем, то ли это или не то

            // что-то не то
            if( ! isAnswerRelevant() )
            {
                if(m_onIrrelevantAnswer != 0)
                {
                    m_onIrrelevantAnswer(m_answer);
                    break;
                }

            }
            // то, что надо
            else
            {
                m_onAnswerReceived(m_answer);
            }


            m_repeatsCount = 0;
            m_state = SessionStates::WAITING_REQUEST;

            break;

        default:

            UMBA_ASSERT_FAIL();
            break;
        }
    }

    bool MasterSession :: isAnswerAdressValid(void) const
    {
        uint8_t reqAdr = ( m_request.id & id_mask_addr ) >> id_offset_addr;
        uint8_t ansAdr = ( m_answer.id & id_mask_addr ) >> id_offset_addr;

        if( reqAdr == addr_direct_access )
        {
            return true;
        }

        // на броадкаст не должно быть ответа и вообще броадкасты и посылать-то никто не должен
        if( reqAdr == addr_broadcast )
        {
            UMBA_ASSERT_FAIL();
        }

        if( reqAdr == ansAdr )
            return true;
        else
            return false;
    }

    bool MasterSession :: isAnswerRelevant(void) const
    {
        // адрес должен быть правильным
        if( ! isAnswerAdressValid() )
            return false;

        // ф-код должен совпадать
        uint8_t reqFcode = ( m_request.id & id_mask_fcode );
        uint8_t ansFcode = ( m_answer.id & id_mask_fcode );

        if( reqFcode != ansFcode )
            return false;


        // ответ об ошибке тоже валидный
        if( m_answer.length == 0 )
        {
            return true;
        }

        bool result = false;
        //проверяю только обычные функции, без device-specific пока
        switch ( reqFcode )
        {
            //стандартные
            case FCode::WRITE_REGS_RANGE:
                result = isWriteRegsRangeValid();
                break;
            case FCode::WRITE_REGS_SERIES:
                result = isWriteRegsSeriesValid();
                break;
            case FCode::READ_REGS_RANGE:
                result = isReadRegsRangeValid();
                break;
            case FCode::READ_REGS_SERIES:
                result = isReadRegsSeriesValid();
                break;
            //специальные
            case FCode::SPECIAL_FUNCTION1:
                result = specialFunction( 0 );
                break;
            case FCode::SPECIAL_FUNCTION2:
                result = specialFunction( 1 );
                break;
            case FCode::SPECIAL_FUNCTION3:
                result = specialFunction( 2 );
                break;
            case FCode::SPECIAL_FUNCTION4:
                result = specialFunction( 3 );
                break;

            default:
                UMBA_ASSERT_FAIL();
        }

        return result;
    }

    /**************************************************************************************************
    Описание:  Функция записи диапазона регистров
    Аргументы: Нет
    Возврат:   Верный ответ или нет
    Замечания:

        Структура запроса:
        -------------------------------------------------
        | StartRegAdr | EndRegAdr | Data0 | ... | DataN |
        -------------------------------------------------
               0            1         2            2+N

        Структура ответа:
        ---------------------------
        | StartRegAdr | EndRegAdr |
        ---------------------------
              0             1

    **************************************************************************************************/
    bool MasterSession::isWriteRegsRangeValid() const
    {
        //если длина не подходят, то ответ кривой
        if( m_answer.length != 2 )
            return false;

        if( m_request.data[0] != m_answer.data[0] )
            return false;

        if( m_request.data[1] != m_answer.data[1] )
            return false;

        return true;
    }

    /**************************************************************************************************
    Описание:  Функция записи серии регистров
    Аргументы: Нет
    Возврат:   Верный ответ или нет
    Замечания:

        Структура запроса:
        --------------------------------------------
        |  RegAdr0 | Data0 | ... | RegAdrN | DataN |
        --------------------------------------------
             0         1             N*2     N*2+1

        Структура ответа:
        ---------------------------
        | RegAdr0 | ... | RegAdrN |
        ---------------------------
             1               N

    **************************************************************************************************/
    bool MasterSession::isWriteRegsSeriesValid() const
    {
        //если длины не подходят, то ответ кривой
        if( m_request.length  != ( m_answer.length * 2 ) )
            return false;

        //если номера регистров разные, то ответ кривой
        for( uint8_t i = 0; i < m_request.length / 2; i++ )
        {
            if( m_request.data[i * 2] != m_answer.data[i] )
                return false;
        }

        return true;
    }


    /**************************************************************************************************
    Описание:  Функция чтения диапазона регистров
    Аргументы: Нет
    Возврат:   Верный ответ или нет
    Замечания:

        Структура запроса:
        ---------------------------
        | StartRegAdr | EndRegAdr |
        ---------------------------
               0           1

        Структура ответа:
        -------------------------------------------------
        | StartRegAdr | EndRegAdr | Data0 | ... | DataN |
        -------------------------------------------------
               0           1          2            2+N

    **************************************************************************************************/
    bool MasterSession::isReadRegsRangeValid() const
    {
        int16_t delta = m_request.data[1] - m_request.data[0] + 1;

        // в ответе должен быть начало диапазона, конец диапазона + данные
        if( m_answer.length != ( m_request.length + delta ) )
            return false;

        if( m_request.data[0] != m_answer.data[0] )
            return false;

        if( m_request.data[1] != m_answer.data[1] )
            return false;

        return true;
    }

    /**************************************************************************************************
    Описание:  Функция чтения серии регистров
    Аргументы: Нет
    Возврат:   Верный ответ или нет
    Замечания:

        Структура запроса:
        -----------------------------
        | RegAddr0 | ... | RegAddrN |
        -----------------------------
             0                N

        Структура ответа:
        ----------------------------------------------
        |  RegAddr0 | Data0 | ... | RegAddrN | DataN |
        ----------------------------------------------
              0         1            N*2       N*2+1

    **************************************************************************************************/
    bool MasterSession::isReadRegsSeriesValid() const
    {
        //если длины не подходят, то ответ кривой
        if( ( m_request.length * 2 )  != m_answer.length )
            return false;

        //если номера регистров разные, то ответ кривой
        for( uint8_t i = 0; i < m_request.length; i++ )
        {
            if( m_request.data[i] != m_answer.data[i * 2] )
                return false;
        }

        return true;
    }

} // namespace cannabus
