#pragma once

#include "Can/can.h"
#include "Cannabus_cpp/cannabus_common.h"
#include "FreeRTOS/freertos_wrapper.h"

namespace can
{
    //это класс-подмена для теста
    class CanMock : public ICan
    {
    public:

        //присовываю муляжу нормальную очередь и проинициализированный can
        void setRxQueueHandler(QueueHandle_t rxQueueFreertos)
        {
            m_rxQueueFreertos = rxQueueFreertos;
        }
        //тырю сообщение
        virtual CanSendMsgResult sendMsg(CanMsg msg)
        {
            m_isNewMsg = true;
            m_lastSendMessage= msg;
            return CanSendMsgResult::SENT;
        }
        //тырю сообщение
        virtual void forceSendMsg(CanMsg msg)
        {
            m_isNewMsg = true;
            m_lastSendMessage= msg;
        }

        //присовываю муляжу нормальную очередь и проинициализированный can
        void setRxQueueHandler(QueueHandle_t rxQueueFreertos)
        {
            m_rxQueueFreertos = rxQueueFreertos;
        }

        CanMsg getLastSentMessage()
        {
            m_isNewMsg = false;
            return m_lastSendMessage;
        }

        bool isNewMsgSent()
        {
            return m_isNewMsg;
        }

        //на всё это просто заглушки
        virtual void setFilter(uint8_t bufN, uint32_t mask, uint32_t filter)
        {
            (void)bufN;
            (void)mask;
            (void)filter;
        }
        virtual CanErrStatus getErrStatus()
        {
            return CanErrStatus::CAN_STATUS_ERROR_ACTIVE;
        }
        virtual bool isRxQueueOverflow()
        {
            return false;
        }
        virtual bool isTxQueueFull()
        {
            return false;
        }

        virtual uint32_t getBaudrate()
        {
            return 0;
        }
        virtual bool isRxIdTypeErr()
        {
            return false;
        }
        virtual void clearRxIdTypeErr()
        {
        }

        virtual QueueHandle_t getQueueHandle()
        {
            return m_rxQueueFreertos;
        }
        virtual SemaphoreHandle_t getMutexHandle()
        {
            return m_mutex;
        }

        virtual bool isInited( void )
        {
            return true;
        }
        
    private:
        
        QueueHandle_t m_rxQueueFreertos;
        SemaphoreHandle_t m_mutex;

        CanMsg m_lastSendMessage;
        bool m_isNewMsg;
    };


}
