#pragma once

#include "project_config.h"
#include "Can/can.h"
#include "cannabus_common.h"
#include "FreeRTOS/freertos_wrapper.h"
#include "cannabus_reg_table.h"
#include "freertos/i_freertos_task.h"
#include "can_proxy.h"
#include "cannabus_slave_freertos_session.h"
//#include "logic/logic.h"
#include "template_array.h"

namespace can
{
    //граничные адреса буферов для слейвов
    struct BufferLimits
    {
        BufferLimits( uint8_t _min, uint8_t _max ) : min(_min), max(_max)
        {}

        BufferLimits() : min(0), max(0)
        {}
        uint8_t min;
        uint8_t max;
    };

    //структура для переприсовывателя
    struct SplitterParams
    {
        SplitterParams( uint8_t a, BufferLimits & l, QueueHandle_t & q ) :
            addr( a ),
            limits( l ),
            queue( q )
        {}
        uint8_t addr;
        BufferLimits & limits;
        QueueHandle_t & queue;
    };

    const uint8_t max_slaves = 3;

    //переприсовыватель между очередями
    class CanSplitterTask : public IFreeRtosTask
    {
    public:
        CanSplitterTask( logic::ParamArray<SplitterParams, max_slaves> params ) : m_params( params )
        {
            for( uint8_t i = 0; i < m_params.getLength(); i++ )
            {
                m_can_addr_filter[i] = m_params[i]->addr << cannabus::SlaveSession::m_addr_offset;
            }

            //если пришла пустота, то что-то всё в говне
            UMBA_ASSERT( m_params.getLength() );
        };

    private:

        virtual void run( void )
        {
            //захватили мьютекс на can2
            SemaphoreHandle_t mutex2 = can::can2.getMutexHandle();
            BaseType_t mutexResult2 = osSemaphoreTake(mutex2, 0);
            UMBA_ASSERT(mutexResult2 == pdTRUE);

            //проинициализирую буферы, после ресета кана они сами смогут проинициализироваться по старым значениям
            initBuffers();

            //вечное перекладывание
            while(OS_IS_RUNNING)
            {
                osTaskYIELD();//сначала илдимся, так как есть континью
                CanMsg msg;
                // Проверка статуса ошибки CAN
                // Если контроллер устал от ошибок и отключился от линии, перезапустить его
                if( can2.getErrStatus() == CanErrStatus::CAN_STATUS_BUS_OFF )
                {
                    //переинициализирую can и перераспределяю буферы
                    can2.reset();
                }

                BaseType_t result = osQueueReceive( can2.getQueueHandle(), &msg, 500 );
                if(result == pdFALSE)
                {
                    continue;
                }

                //тут мы зависим всяко от способа адресации каннабуса
                uint16_t addr = (msg.id & cannabus::SlaveSession::m_addr_mask) >> cannabus::SlaveSession::m_addr_offset;


                for(uint8_t i = 0; i < m_params.getLength(); i++)
                {
                    if( ( addr == cannabus::SlaveSession::m_brodcast_addr ) ||
                        ( addr == cannabus::SlaveSession::m_direct_access_addr ) ||
                        ( addr == m_params[i]->addr ) )
                    {
                        result = osQueueSend(m_params[i]->queue, &msg, 0);
                        if (result == errQUEUE_FULL)
                        {
                            //всё равно не знаю, что делать, значит канус чей-то повис
                        }
                    }
                }
            }
        }
        
        void initBuffers( void )
        {
            //2 буфера для бродкаста
            const uint8_t can_rx_buf_broadcast_min = 0;
            const uint8_t can_rx_buf_broadcast_max = 0;

            //2 буфера для прямого обращения
            const uint8_t can_rx_buf_direct_min = 1;
            const uint8_t can_rx_buf_direct_max = 1;

            //настраиваю бродкаст
            for(uint8_t i = can_rx_buf_broadcast_min; i <= can_rx_buf_broadcast_max; i++)
            {
                can2.setFilter( i, cannabus::SlaveSession::m_addr_mask, cannabus::SlaveSession::m_brodcast_filter );
            }

            //настраиваю прямое обращение
            for(uint8_t i = can_rx_buf_direct_min; i <= can_rx_buf_direct_max; i++)
            {
                can2.setFilter( i, cannabus::SlaveSession::m_addr_mask, cannabus::SlaveSession::m_direct_access_filter );
            }

            //настраиваю всем буфера
            for(uint8_t j = 0; j < m_params.getLength(); j++)
            {
                for(uint8_t i = m_params[j]->limits.min; i < m_params[j]->limits.max; i++)
                {
                    can2.setFilter( i, cannabus::SlaveSession::m_addr_mask, m_can_addr_filter[j] );
                }
            }

        }

        logic::ParamArray<SplitterParams, max_slaves> m_params;
        uint16_t m_can_addr_filter[max_slaves];
    };
}
