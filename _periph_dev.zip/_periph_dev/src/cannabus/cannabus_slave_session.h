
/***********************************************************************************************************************************
Заголовочный файл процессора протокола cannabus+ для ведомого устройства

Разработчик: Иван Бубников, лаборатория 5215

Разработано в рамках проекта "Курс-ЛИ", взято из прошивки драйвера ДПТ
***********************************************************************************************************************************/


#pragma once

#include "project_config.h"
#include "callbacks/callbacks.h"
#include "can/i_can.h"
#include "cannabus/i_cannabus_reg_table.h"
#include "cannabus_common.h"
#include <algorithm>
#include "umba_array/umba_array.h"

// Структура ID сообщения CANNABUS PLUS:
//  ----------------------------------------------------------------------------------------------
//  |  Бит 10  |  Бит 9  | Бит 8 | Бит 7 | Бит 6 | Бит 5 | Бит 4 | Бит 3 | Бит 2 | Бит 1 | Бит 0 |
//  ----------------------------------------------------------------------------------------------
//  | Код типа сообщения |                   Адрес slave-узла                    |  Код функции  |
//  ----------------------------------------------------------------------------------------------
namespace cannabus
{    
    class SlaveSession
    {
        public:

            SlaveSession( const SlaveSession & ) = delete;
            void operator=( const SlaveSession & ) = delete;

            //классический конструктор
            SlaveSession( can::ICan * can,
                          uint8_t slaveAdr,
                          cannabus::ICannabusRegTable * table,
                          callback::VoidCallback lostLinkHandler = callback::NullCallback(),
                          uint32_t lostLinkTimeout = 1000,
                          callback::VoidCallback restoreLinkHandler = callback::NullCallback() ) :
                m_request_timeout_max( lostLinkTimeout ),
                m_can( can ),
                m_slaveAdr( slaveAdr ),
                m_table( table ),
                m_isRequestComposed( false ),
                m_isConnected( false ),
                m_lastRequestTimestamp( 0 ),
                m_lastCallTime( 0 ),
                m_onConnectionLost( lostLinkHandler ),
                m_onConnectionRestored( restoreLinkHandler )
            {
                m_can->lock();
            }


            void work(uint32_t curTime);
            
            
            void sendHighPrioMessage( umba::IArray<uint8_t> & roRegNum );

            void setTimeout(uint32_t lostLinkTimeout)
            {
                m_request_timeout_max = lostLinkTimeout;
            }
            
            //шаблонная функция для раздачи специальным функциям своих регистров
            //последнее пришедшее считать единственно верным
            template<uint32_t TSizeRx, uint32_t TSizeTx>
            void setDeviceSpecific( uint8_t num, SpecialRegNames<TSizeRx, TSizeTx> registers )
            {
                UMBA_ASSERT( num <= 4 );
                UMBA_ASSERT( num > 0 );

                m_spec[num-1].regRxLength = TSizeRx;
                m_spec[num-1].regTxLength = TSizeTx;

                std::copy( registers.rxRegs, registers.rxRegs[TSizeRx],  m_spec[num-1].regRx );
                std::copy( registers.txRegs, registers.txRegs[TSizeTx],  m_spec[num-1].regTx );
            }


        private:

            //структура, описывающая регистры device-specific функции
            struct SpecialRegArray
            {
                uint8_t regRx[max_regs_in_specific];
                uint8_t regRxLength;

                uint8_t regTx[max_regs_in_specific];
                uint8_t regTxLength;
            };
            void process();
            bool writeRegsRange();
            bool writeRegsSeries();
            bool readRegsRange();
            bool readRegsSeries();
            void generateNack();

            //специальные функции
            bool specialFunction( uint8_t num);

            bool isAnswerNeeded();

            uint32_t m_request_timeout_max;

            can::ICan * m_can;
            uint8_t m_slaveAdr;

            cannabus::ICannabusRegTable * m_table;

            bool m_isRequestComposed;

            bool m_isConnected;
            uint32_t m_lastRequestTimestamp;
            uint32_t m_lastCallTime;

            callback::VoidCallback m_onConnectionLost;
            callback::VoidCallback m_onConnectionRestored;
            
            can::CanMessage m_req = {};
            can::CanMessage m_ans = {};

            SpecialRegArray m_spec[4] = {};
    };

} // namespace

