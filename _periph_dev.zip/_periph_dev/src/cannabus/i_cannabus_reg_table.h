#pragma once

#include "project_config.h"
#include "i_reg_table.h"


namespace cannabus
{
	class ICannabusRegTable : public IRegTable
	{

	public:
    
        //проверка
		virtual bool isRegNumValid(uint8_t regNum) const = 0;
		virtual bool isRegNumRw(uint8_t regNum) const = 0;
		virtual bool isRegNumRo(uint8_t regNum) const = 0;

		// запись и чтение

		// одиночные регистры и однобайтовые значения
		virtual void setRegVal(uint8_t regNum, uint8_t val) = 0;
		virtual uint8_t getRegVal(uint8_t regNum) = 0;
		virtual bool checkRegUpdate(uint8_t rwRegNum) = 0; // эта функция сбрасывает флаг обновления

		// сдвоенные регистры и двухбайтные значения
		virtual void setReg16Val(uint8_t lowRegNum, uint16_t val) = 0;
		virtual uint16_t getReg16Val(uint8_t lowRegNum) = 0;
		virtual bool checkReg16Update(uint8_t lowRegNum) = 0;

		// счетверенные регистры и четырехбайтные значения
		virtual void setReg32Val(uint8_t lowRegNum, uint32_t val) = 0;
        virtual uint32_t getReg32Val(uint8_t lowRegNum) = 0;
        virtual bool checkReg32Update(uint8_t lowRegNum) = 0;

        // только для RW
        virtual uint8_t getReadyToSendRwReg(void) = 0;
        virtual uint32_t getReadyToSendRwRegsTotal(void) = 0; // общее количество изменившихся регистров

        // длина регистра в байтах
        virtual uint8_t getRegLength( uint8_t lowRegNum ) = 0;

        // границы
        virtual uint8_t getRwMinRegNum(void) = 0;
        virtual uint8_t getRwMaxRegNum(void) = 0;
        virtual uint8_t getRwRegsTotal(void) = 0; // общее количество рв-регистров

        virtual uint8_t getRoMinRegNum(void) = 0;
        virtual uint8_t getRoMaxRegNum(void) = 0;
        virtual uint8_t getRoRegsTotal(void) = 0; // общее количество ро-регистров

		// локи для всей таблицы
		virtual bool isTableLocked(void) = 0;
		virtual void lockTable(void) = 0;
		virtual void unlockTable(void) = 0;

		virtual ~ICannabusRegTable(){}

        class Lock
        {
        public:

            Lock(ICannabusRegTable & table) : m_table(table)
            {
                table.lockTable();
            }

            Lock(ICannabusRegTable * table) : m_table(*table)
            {
                table->lockTable();
            }

            ~Lock()
            {
                m_table.unlockTable();
            }

        private:

            ICannabusRegTable & m_table;
        };
	};

}


