#include "virtual_gpio.h"
#include "umba/bits.h"
#include "umba/stl.h"
#include "umba/alloca.h"


#ifndef UMBA_VGPIO_MAX_DIFFERENT_VIRTUAL_PORTS
    #define UMBA_VGPIO_MAX_DIFFERENT_VIRTUAL_PORTS  16
#endif

namespace umba
{

namespace virtual_gpio
{


namespace util
{


//-----------------------------------------------------------------------------
//! Простой "set" для небольшого набора значений. За неимением нормального set'а используем говно и палки.
/*! При конструировании получает память, где будет хранить значения.
    
    Используется тупой перебор:
     а) при малом количестве элементов тупой перебор сравним по скорости с двоичным поиском, а то и выигрывает - это известный факт
     б) банально тупо лень писать что-то более сложное.

    Так как будем хранить PODы, то не паримся с конструированием и разрушением элементов.

    Реализуем минимальный совместимый с STL интерфейс/
     
*/
template<typename T>
class crutch_set // not a crotch
{
public:

    typedef T         key_type;
    typedef T         value_type;
    typedef T*        iterator;
    typedef const T*  const_iterator;

    crutch_set( value_type *b, value_type *e ) : m_begin(b), m_end(b), m_bufEnd(e) {}

    iterator       begin()       { return m_begin; }
    const_iterator begin() const { return m_begin; }
    iterator       end()         { return m_end;   }
    const_iterator end() const   { return m_end;   }

    std::pair<iterator,bool> insert( const value_type& value )
    {
        iterator it = m_begin;
        for(; it!=m_end; ++it)
        {
            if (*it == value)
            {
                return std::make_pair( it, false );
            }
        }

        // not found
        if (m_end>=m_bufEnd)
        {
            UMBA_ASSERT_FAIL(); // no room for new item
        }

        *m_end = value;
        m_end++;
        return std::make_pair( it, true );
    }

    iterator find( const key_type& key )
    {
        iterator it = m_begin;
        for(; it!=m_end; ++it)
        {
            if (*it == key)
                return it;
        }
        return m_end;
    }

    const_iterator find( const key_type& key ) const
    {
        const_iterator it = m_begin;
        for(; it!=m_end; ++it)
        {
            if (*it == key)
                return it;
        }
        return m_end;
    }

    bool empty() const
    {
        return m_begin==m_end;
    }

    size_t size() const
    {
        return (size_t)(m_end - m_begin);
    }

protected:

    value_type * m_begin;
    value_type * m_end;
    value_type * m_bufEnd;

}; // class crutch_set

} // namespace util

//-----------------------------------------------------------------------------

#define DECLARE_SET_VAR( ValType, setName, sz )          \
                              ValType setName##buf [sz]; \
                              util::crutch_set< ValType > setName( & setName##buf [0], & setName##buf [sz] )





//-----------------------------------------------------------------------------
VirtualInputPort::VirtualInputPort( VirtualInputPin *pVirtualPins )
    : m_pVirtualPins(pVirtualPins)
    , m_pins(0)
    , m_pinCount(0)
{
    VirtualInputPin *pPin = m_pVirtualPins;

    PinType pin = 1;

    for(; pPin->pPort; ++pPin, ++m_pinCount)
    {
        m_pins |= pin;
        pin <<= 1;
    }

    UMBA_ASSERT( (m_pinCount <= umba::bits::getTypeBitsCount<PinType, PinType>()) );
}

//-----------------------------------------------------------------------------
void VirtualInputPort::initPort()
{
}

//-----------------------------------------------------------------------------
PinType VirtualInputPort::getPins()
{
    return m_pins;
}

//-----------------------------------------------------------------------------
void VirtualInputPort::readLockPins()
{
    DECLARE_SET_VAR( IInputPort*, readLockedPorts,  UMBA_VGPIO_MAX_DIFFERENT_VIRTUAL_PORTS );

    PinType pinNo = 0;
    for(; pinNo!=m_pinCount; ++pinNo)
    {
        auto pPort = m_pVirtualPins[pinNo].pPort;
        if (readLockedPorts.find(pPort) == readLockedPorts.end())
        {
            // not read locked
            pPort->readLockPins();
            if (readLockedPorts.size() >= UMBA_VGPIO_MAX_DIFFERENT_VIRTUAL_PORTS)
            {
                // не можем предотвратить повторное защелкивание значения порта.
                // для аппаратных портов - ничего не произойдет,
                // для последовательных портов - возможно потеряем время 
                // на повторное чтение из I2C/SPI/последовательного регистра и тп
            }
            else
            {
                readLockedPorts.insert(pPort); // помечаем как защелкнутый
            }
        } // if
    } // for
}

//-----------------------------------------------------------------------------
PinType VirtualInputPort::readInput( PinType mask )
{
    PinType resPins = 0;

    mask &= m_pins;

    PinType pin = 1;

    PinType pinNo = 0;
    for(; pinNo!=m_pinCount; ++pinNo, pin<<=1)
    {
        if ((pin&mask)==0)
           continue; // пин не установлен для чтения

        if (!m_pVirtualPins[pinNo].portPin)
            continue; // пин не задан, пропускаем

        auto pPort = m_pVirtualPins[pinNo].pPort;

        PinType portPinVal = pPort->readInput( m_pVirtualPins[pinNo].portPin ); // читаем все пины
        // Если задано несколько пинов, то если хоть один в единице, то результат виртуального пина тоже единица
        if (portPinVal)
            resPins |= pin; 

    } // for

    return resPins;
}

//-----------------------------------------------------------------------------
bool VirtualInputPort::readInputBit( PinType bitNo )
{
    UMBA_ASSERT(bitNo<m_pinCount);

    auto pPort = m_pVirtualPins[bitNo].pPort;
    PinType portPinVal = pPort->readInput( m_pVirtualPins[bitNo].portPin );
    return portPinVal ? true : false;
}

//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
VirtualOutputPort::VirtualOutputPort( VirtualOutputPin *pVirtualPins )
    : m_pVirtualPins(pVirtualPins)
    , m_pins(0)
    , m_pinCount(0)
{
    VirtualOutputPin *pPin = m_pVirtualPins;

    PinType pin = 1;

    for(; pPin->pPort; ++pPin, ++m_pinCount)
    {
        m_pins |= pin;
        pin <<= 1;
    }

    UMBA_ASSERT( (m_pinCount <= umba::bits::getTypeBitsCount<PinType, PinType>()) );
}

//-----------------------------------------------------------------------------
void VirtualOutputPort::initPort()
{
}

//-----------------------------------------------------------------------------
PinType VirtualOutputPort::getPins()
{
    return m_pins;
}

//-----------------------------------------------------------------------------
void VirtualOutputPort::writeFlushPins()
{
    DECLARE_SET_VAR( IOutputPort*, writeFlushedPorts, UMBA_VGPIO_MAX_DIFFERENT_VIRTUAL_PORTS );

    PinType pinNo = 0;
    for(; pinNo!=m_pinCount; ++pinNo)
    {
        auto pPort = m_pVirtualPins[pinNo].pPort;
        if (writeFlushedPorts.find(pPort) == writeFlushedPorts.end())
        {
            pPort->writeFlushPins();
            if (writeFlushedPorts.size() >= UMBA_VGPIO_MAX_DIFFERENT_VIRTUAL_PORTS)
            {
                // не можем предотвратить повторную запись значения порта.
                // для аппаратных портов - ничего не произойдет,
                // для последовательных портов - возможно потеряем время 
                // на повторную запись в I2C/SPI/последовательный регистр и тп
            }
            else
            {
                writeFlushedPorts.insert(pPort); // помечаем как защелкнутый
            }
        } // if
    } // for
}

//-----------------------------------------------------------------------------
PinType VirtualOutputPort::readOutput( PinType mask )
{
    PinType resPins = 0;

    mask &= m_pins;

    PinType pin = 1;

    PinType pinNo = 0;
    for(; pinNo!=m_pinCount; ++pinNo, pin<<=1)
    {
        if ((pin&mask)==0)
           continue; // пин не установлен для чтения

        if (!m_pVirtualPins[pinNo].portPin)
            continue; // пин не задан, пропускаем

        auto pPort = m_pVirtualPins[pinNo].pPort;

        PinType portPinVal = pPort->readOutput( m_pVirtualPins[pinNo].portPin ); // читаем все пины
        // Если задано несколько пинов, то если хоть один в единице, то результат виртуального пина тоже единица
        if (portPinVal)
            resPins |= pin; 

    } // for

    return resPins;

}

//-----------------------------------------------------------------------------
//void VirtualOutputPort::writeOutput( PinType bits )
//{
//}

//-----------------------------------------------------------------------------
void VirtualOutputPort::setOutput( PinType bits )
{
    bits &= m_pins;

    PinType pin = 1;

    PinType pinNo = 0;
    for(; pinNo!=m_pinCount; ++pinNo, pin<<=1)
    {
        if ((pin&bits)==0)
           continue; // пин не установлен для установки

        if (!m_pVirtualPins[pinNo].portPin)
            continue; // пин не задан, пропускаем

        auto pPort = m_pVirtualPins[pinNo].pPort;

        pPort->setOutput( m_pVirtualPins[pinNo].portPin );
    }
}

//-----------------------------------------------------------------------------
void VirtualOutputPort::setOutput( PinType bitsMask, PinType values )
{
    bitsMask &= m_pins;

    PinType pin = 1;

    PinType pinNo = 0;
    for(; pinNo!=m_pinCount; ++pinNo, pin<<=1)
    {
        if ((pin&bitsMask)==0)
           continue; // пин не установлен для обработки

        if (!m_pVirtualPins[pinNo].portPin)
            continue; // пин не задан, пропускаем

        auto pPort = m_pVirtualPins[pinNo].pPort;

        if (values&pin)
           pPort->setOutput( m_pVirtualPins[pinNo].portPin );
        else
           pPort->clrOutput( m_pVirtualPins[pinNo].portPin );
    }
}

//-----------------------------------------------------------------------------
void VirtualOutputPort::clrOutput( PinType bits )
{
    bits &= m_pins;

    PinType pin = 1;

    PinType pinNo = 0;
    for(; pinNo!=m_pinCount; ++pinNo, pin<<=1)
    {
        if ((pin&bits)==0)
           continue; // пин не установлен для сброса

        if (!m_pVirtualPins[pinNo].portPin)
            continue; // пин не задан, пропускаем

        auto pPort = m_pVirtualPins[pinNo].pPort;

        pPort->clrOutput( m_pVirtualPins[pinNo].portPin );
    }
}

//-----------------------------------------------------------------------------
void VirtualOutputPort::toggleOutput( PinType bits )
{
    bits &= m_pins;

    PinType curOutput = readOutput( bits );
    PinType newBits   = (~curOutput) & bits;
    setOutput( bits, newBits );
}

//-----------------------------------------------------------------------------
void VirtualOutputPort::writeOutputBit( PinType bitNo, bool val )
{
    UMBA_ASSERT(bitNo<m_pinCount);

    if (val)
        setOutput( umba::bits::makeBit<PinType,PinType>(bitNo) );
    else
        clrOutput( umba::bits::makeBit<PinType,PinType>(bitNo) );
}

//-----------------------------------------------------------------------------

/*
protected:

    IOutputPort **m_pOutputPorts;

    PinType     m_pins;
    PinType     m_pinCount;
*/




} // namespace virtual_gpio

} // namespace umba

