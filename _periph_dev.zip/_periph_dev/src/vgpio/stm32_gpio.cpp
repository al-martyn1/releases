#pragma once

#include "stm32_gpio.h"
#include "umba/assert.h"
#include "stm32_gpio_helpers.h"
#include "umba/bits.h"


namespace umba
{

namespace stm32_gpio
{

/*
    #if defined(STM32F1_SERIES)
    #elif defined(STM32F3_SERIES)
    #elif defined(STM32F4_SERIES)
    #elif defined(STM32L1_SERIES)
    #endif
*/


//-----------------------------------------------------------------------------
inline
GPIOSpeed_TypeDef pinSpeedToNative( umba::virtual_gpio::PinSpeed pinSpeed )
{
    #if defined(STM32F1_SERIES)
    switch(pinSpeed)
    {
        case umba::virtual_gpio::PinSpeed::verySlow: return GPIO_Speed_2MHz;
        case umba::virtual_gpio::PinSpeed::slow    : return GPIO_Speed_2MHz;
        case umba::virtual_gpio::PinSpeed::medium  : return GPIO_Speed_10MHz;
        case umba::virtual_gpio::PinSpeed::high    : return GPIO_Speed_50MHz;
        case umba::virtual_gpio::PinSpeed::veryHigh: return GPIO_Speed_50MHz;
        default                                    : return GPIO_Speed_10MHz;
    };
    #elif defined(STM32F3_SERIES)
    switch(pinSpeed)
    {
        case umba::virtual_gpio::PinSpeed::verySlow: return GPIO_Speed_Level_1;
        case umba::virtual_gpio::PinSpeed::slow    : return GPIO_Speed_Level_1;
        case umba::virtual_gpio::PinSpeed::medium  : return GPIO_Speed_Level_2;
        case umba::virtual_gpio::PinSpeed::high    : return GPIO_Speed_Level_3;
        case umba::virtual_gpio::PinSpeed::veryHigh: return GPIO_Speed_Level_3;
        default                                    : return GPIO_Speed_Level_2;
    };
    #elif defined(STM32F4_SERIES)
    switch(pinSpeed)
    {
        case umba::virtual_gpio::PinSpeed::verySlow: return GPIO_Low_Speed;
        case umba::virtual_gpio::PinSpeed::slow    : return GPIO_Low_Speed;
        case umba::virtual_gpio::PinSpeed::medium  : return GPIO_Medium_Speed;
        case umba::virtual_gpio::PinSpeed::high    : return GPIO_Fast_Speed;
        case umba::virtual_gpio::PinSpeed::veryHigh: return GPIO_High_Speed;
        default                                    : return GPIO_Medium_Speed;
    };
    #elif defined(STM32L1_SERIES)
    switch(pinSpeed)
    {
        case umba::virtual_gpio::PinSpeed::verySlow: return GPIO_Speed_400KHz;
        case umba::virtual_gpio::PinSpeed::slow    : return GPIO_Speed_2MHz;
        case umba::virtual_gpio::PinSpeed::medium  : return GPIO_Speed_10MHz;
        case umba::virtual_gpio::PinSpeed::high    : return GPIO_Speed_40MHz;
        case umba::virtual_gpio::PinSpeed::veryHigh: return GPIO_Speed_40MHz;
        default                                    : return GPIO_Speed_10MHz;
    };
    #endif
}

//-----------------------------------------------------------------------------
inline
void pinModeConfigureNative( umba::virtual_gpio::PinDirection pinDirection, umba::virtual_gpio::PinPushPullMode pinPushPullMode, GPIO_InitTypeDef &initStruct )
{
    using namespace umba::virtual_gpio;
    #if defined(STM32F1_SERIES)
    if (pinDirection==PinDirection::input)
    {
        if (pinPushPullMode==PinPushPullMode::floating)
            initStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        else if (pinPushPullMode==PinPushPullMode::pullUp)
            initStruct.GPIO_Mode = GPIO_Mode_IPU;
        else if (pinPushPullMode==PinPushPullMode::pullDown)
            initStruct.GPIO_Mode = GPIO_Mode_IPD;
        else
        {
            UMBA_ASSERT_FAIL();
        }
    }
    else
    {
        if (pinPushPullMode==PinPushPullMode::openDrain)
            initStruct.GPIO_Mode = GPIO_Mode_Out_OD;
        else if (pinPushPullMode==PinPushPullMode::pushPull)
            initStruct.GPIO_Mode = GPIO_Mode_Out_PP;
        else
        {
            UMBA_ASSERT_FAIL();
        }
    }    
    #elif defined(STM32F3_SERIES) || defined(STM32F4_SERIES) || defined(STM32L1_SERIES)
    if (pinDirection==PinDirection::input)
    {
        initStruct.GPIO_Mode  = GPIO_Mode_IN;
        if (pinPushPullMode==PinPushPullMode::floating)
        {
            initStruct.GPIO_OType = GPIO_OType_OD;
            initStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL;
        }
        else if (pinPushPullMode==PinPushPullMode::pullUp)
        {
            initStruct.GPIO_OType = GPIO_OType_PP;
            initStruct.GPIO_PuPd  = GPIO_PuPd_UP;
        }
        else if (pinPushPullMode==PinPushPullMode::pullDown)
        {
            initStruct.GPIO_OType = GPIO_OType_PP;
            initStruct.GPIO_PuPd  = GPIO_PuPd_DOWN;
        }
        else
        {
            UMBA_ASSERT_FAIL();
        }
    }
    else
    {
        initStruct.GPIO_Mode  = GPIO_Mode_OUT;
        if (pinPushPullMode==PinPushPullMode::openDrain)
        {
            initStruct.GPIO_OType = GPIO_OType_OD;
            initStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL;
        }
        else if (pinPushPullMode==PinPushPullMode::pushPull)
        {
            initStruct.GPIO_OType = GPIO_OType_PP;
            initStruct.GPIO_PuPd  = GPIO_PuPd_UP;
        }
        else
        {
            UMBA_ASSERT_FAIL();
        }
    }    
    #endif
}

//-----------------------------------------------------------------------------

using vgpio::PinType;



//-----------------------------------------------------------------------------
Stm32IoPort::Stm32IoPort( vgpio::Port            port
           , vgpio::PinSpeed        pinSpeed
           , vgpio::PinDirection    pinDirection
           , vgpio::PinPushPullMode pinPushPullMode
           , PinType                pins
           )
    : m_port           (port           )
    , m_pinSpeed       (pinSpeed       )
    , m_pinDirection   (pinDirection   )
    , m_pinPushPullMode(pinPushPullMode)
    , m_pins           (pins           )
{
    UMBA_ASSERT( pins <= 0xFFFF ); // stm32 ports are 16 bit wide
}

//-----------------------------------------------------------------------------
void Stm32IoPort::initPort()
{
    GPIO_InitTypeDef initTypeDef;
    GPIO_StructInit(&initTypeDef);

    initTypeDef.GPIO_Pin   = m_pins;
    initTypeDef.GPIO_Speed = pinSpeedToNative(m_pinSpeed);
    pinModeConfigureNative( m_pinDirection, m_pinPushPullMode, initTypeDef );

    GPIO_TypeDef* GPIOx = portToGpio( m_port );
    
    #if defined(STM32F1_SERIES)
    RCC_APB2PeriphClockCmd( gpioToRcc( GPIOx ), ENABLE);
    #elif defined(STM32F3_SERIES)
    RCC_AHBPeriphClockCmd(gpioToRcc(GPIOx), ENABLE);
    #elif defined(STM32F4_SERIES)
    RCC_AHB1PeriphClockCmd(gpioToRcc(GPIOx), ENABLE);
    #elif defined(STM32L1_SERIES)
    RCC_AHBPeriphClockCmd(gpioToRcc(GPIOx), ENABLE);
    #endif

    GPIO_Init(GPIOx, &initTypeDef);
}

//-----------------------------------------------------------------------------
Stm32IoPort::~Stm32IoPort()
{
}

//-----------------------------------------------------------------------------
PinType Stm32IoPort::getPins()
{
    return m_pins;
}

//-----------------------------------------------------------------------------
void Stm32IoPort::readLockPins() // for serial input ports, not used for native
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::input );
}

//-----------------------------------------------------------------------------
void Stm32IoPort::writeFlushPins() // for serial output ports, not used for native
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::output );
}

//-----------------------------------------------------------------------------
PinType Stm32IoPort::readInput( PinType mask )
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::input );
    UMBA_ASSERT( (m_pins & mask) != 0 );

    PinType bits = GPIO_ReadInputData( portToGpio( m_port ) );
    return (bits & m_pins) & mask;
}

//-----------------------------------------------------------------------------
bool Stm32IoPort::readInputBit( PinType bitNo )
{
    UMBA_ASSERT(bitNo<16);
    return readInput( umba::bits::makeBit<PinType,PinType>(bitNo) ) ? true : false;
}

//-----------------------------------------------------------------------------
PinType Stm32IoPort::readOutput( PinType mask )
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::output );
    PinType bits = GPIO_ReadOutputData( portToGpio( m_port ) );
    return (bits & m_pins) & mask;
}

//-----------------------------------------------------------------------------
/*
void Stm32IoPort::writeOutput( PinType bits )
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::output );

    GPIO_Write( portToGpio( m_port ), (uint16_t)(bits & m_pins));
    //portToGpio( m_port )->BSRR = setBits | (clrBits<<16);
}
*/
//-----------------------------------------------------------------------------
void Stm32IoPort::setOutput( PinType bits )
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::output );
    bits &= m_pins;
    GPIO_SetBits( portToGpio( m_port ), (uint16_t)(bits & m_pins) );
}

//-----------------------------------------------------------------------------
void Stm32IoPort::setOutput( PinType bitsMask, PinType values )
{

    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::output );

    bitsMask &= m_pins;

    PinType setBits =   values  & bitsMask;
    PinType clrBits = (~values) & bitsMask;
/*
    PinType setBits = 0;
    PinType clrBits = 0;

    while(bits)
    {
        PinType nextMask = bits & (bits-1);
        PinType maskBit  = bits ^ nextMask;
        bits = nextMask;

        if (values&maskBit)
            setBits |= maskBit;
        else
            clrBits |= maskBit;
    }
*/

    #if defined(STM32F4_SERIES)
    //int32_t *pBssr = 
    *((uint32_t*)&(portToGpio( m_port )->BSRRL)) = setBits | (clrBits<<16);
    #else
    portToGpio( m_port )->BSRR = setBits | (clrBits<<16);
    #endif
    
 //__IO uint16_t BSRRL;    /*!< GPIO port bit set/reset low register,  Address offset: 0x18      */
  //__IO uint16_t BSRRH;    /*!< GPIO port bit set/reset high register, Address offset: 0x1A      */    
}

//-----------------------------------------------------------------------------
void Stm32IoPort::clrOutput( PinType bits )
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::output );
    bits &= m_pins;
    GPIO_ResetBits( portToGpio( m_port ), (uint16_t)bits );
}

//-----------------------------------------------------------------------------
void Stm32IoPort::toggleOutput( PinType bits )
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::output );

    bits &= m_pins;

    PinType curOutput = readOutput( bits );
    PinType newBits   = (~curOutput) & bits;
    setOutput( bits, newBits );
}

//-----------------------------------------------------------------------------
void Stm32IoPort::writeOutputBit( PinType bitNo, bool val )
{
    UMBA_ASSERT( m_pinDirection == vgpio::PinDirection::output );

    if (val)
        setOutput( umba::bits::makeBit<PinType,PinType>(bitNo) );
    else
        clrOutput( umba::bits::makeBit<PinType,PinType>(bitNo) );
    
}

//-----------------------------------------------------------------------------


} // namespace stm32_gpio

} // namespace umba


#if 0

// F1



void GPIO_DeInit(GPIO_TypeDef* GPIOx);
void GPIO_AFIODeInit(void);
void GPIO_Init(GPIO_TypeDef* GPIOx, GPIO_InitTypeDef* GPIO_InitStruct);
void GPIO_StructInit(GPIO_InitTypeDef* GPIO_InitStruct);

uint8_t GPIO_ReadInputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
uint16_t GPIO_ReadInputData(GPIO_TypeDef* GPIOx);
uint8_t GPIO_ReadOutputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
uint16_t GPIO_ReadOutputData(GPIO_TypeDef* GPIOx);

void GPIO_SetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
void GPIO_ResetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
void GPIO_WriteBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, BitAction BitVal);
void GPIO_Write(GPIO_TypeDef* GPIOx, uint16_t PortVal);

void GPIO_PinLockConfig(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
void GPIO_EventOutputConfig(uint8_t GPIO_PortSource, uint8_t GPIO_PinSource);
void GPIO_EventOutputCmd(FunctionalState NewState);
void GPIO_PinRemapConfig(uint32_t GPIO_Remap, FunctionalState NewState);
void GPIO_EXTILineConfig(uint8_t GPIO_PortSource, uint8_t GPIO_PinSource);
void GPIO_ETH_MediaInterfaceConfig(uint32_t GPIO_ETH_MediaInterface);


    GPIO_InitTypeDef GPIO_InitStruct_LedPins = { GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15
                                               , GPIO_Mode_OUT, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_DOWN
                                              };
    GPIO_Init(GPIOD, &GPIO_InitStruct_LedPins);


inline
void gpioBitMaskSet(unsigned portNo, uint16_t bits)
{
    gpioGetGpio(portNo)->BSRR = bits;
}

inline
void gpioBitSet(unsigned portNo, unsigned bitNo) { gpioBitMaskSet(portNo, getBitMask(bitNo)); }

inline
void gpioBitMaskReset(unsigned portNo, uint16_t bits)
{
    gpioGetGpio(portNo)->BRR = bits;
}

inline
void gpioBitReset(unsigned portNo, unsigned bitNo) { gpioBitMaskReset(portNo, getBitMask(bitNo)); }

inline
void gpioBitMaskSetReset(unsigned portNo, uint16_t bitsSet, uint16_t bitsReset)
{
    gpioGetGpio(portNo)->BSRR = bitsSet | (bitsReset<<16);
}

inline
void gpioBitSetReset(unsigned portNo, unsigned bitNoSet, unsigned bitNoReset) { gpioBitMaskSetReset(portNo, getBitMask(bitNoSet), getBitMask(bitNoReset)); }

inline
void gpioBitToggle(unsigned portNo, unsigned bitNo)
{
    unsigned mask = getBitMask(bitNo);
    uint16_t odr = gpioGetGpio(portNo)->ODR;
    if (odr & mask)
        gpioBitReset(portNo, bitNo);
    else
        gpioBitSet(portNo, bitNo);
}
#endif


