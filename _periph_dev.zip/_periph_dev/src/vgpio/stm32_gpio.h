#pragma once

#include "i_virtual_gpio.h"


namespace umba
{

namespace stm32_gpio
{

namespace vgpio = umba::virtual_gpio;

class Stm32IoPort : implements vgpio::IInputPort
                  , implements vgpio::IOutputPort
{

public:

    using PinType = vgpio::PinType;

    Stm32IoPort( vgpio::Port            port
               , vgpio::PinSpeed        pinSpeed
               , vgpio::PinDirection    pinDirection
               , vgpio::PinPushPullMode pinPushPullMode
               , PinType                pins
               );

    ~Stm32IoPort();

    virtual
    void initPort() override;

    virtual
    PinType getPins() override;

    virtual
    void readLockPins() override; // for serial input ports, not used for native

    virtual
    PinType readInput( PinType mask ) override;

    virtual
    bool readInputBit( PinType bitNo ) override;

    virtual
    void writeFlushPins() override; // for serial output ports, not used for native

    virtual
    PinType readOutput( PinType mask ) override;

    //virtual
    //void writeOutput( PinType bits ) override;

    virtual
    void setOutput( PinType bits ) override;

    virtual
    void setOutput( PinType bitsMask, PinType values ) override;

    virtual
    void clrOutput( PinType bits ) override;

    virtual
    void toggleOutput( PinType bits ) override;

    virtual
    void writeOutputBit( PinType bitNo, bool val ) override;

protected:

    vgpio::Port            m_port;
    vgpio::PinSpeed        m_pinSpeed;
    vgpio::PinDirection    m_pinDirection;
    vgpio::PinPushPullMode m_pinPushPullMode;
    PinType                m_pins;


}; // class Stm32IoPort

} // namespace stm32_gpio

} // namespace umba




