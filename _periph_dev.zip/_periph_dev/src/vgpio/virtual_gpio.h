#pragma once

#include "i_virtual_gpio.h"


namespace umba
{

namespace virtual_gpio
{


struct VirtualInputPin
{
    IInputPort    *pPort;
    PinType        portPin;

}; // struct VirtualInputPin



struct VirtualOutputPin
{
    IOutputPort   *pPort;
    PinType        portPin;

}; // struct VirtualOutputPin




struct VirtualInputPort : implements IInputPort
{
    VirtualInputPort( VirtualInputPin *pVirtualPins );

    virtual
    void initPort() override;

    virtual
    PinType getPins() override;

    virtual
    void readLockPins() override; // for serial input ports, not used for native

    virtual
    PinType readInput( PinType mask ) override;

    virtual
    bool readInputBit( PinType bitNo ) override;

protected:

    VirtualInputPin *m_pVirtualPins;

    PinType          m_pins;
    PinType          m_pinCount;

}; // struct VirtualInputPort




struct VirtualOutputPort : implements IOutputPort
{
    VirtualOutputPort( VirtualOutputPin *pVirtualPins );

    virtual
    void initPort() override;

    virtual
    PinType getPins() override;

    virtual
    void writeFlushPins() override; // for serial output ports, not used for native

    virtual
    PinType readOutput( PinType mask ) override;

    //virtual
    //void writeOutput( PinType bits ) override;

    virtual
    void setOutput( PinType bits ) override;

    virtual
    void setOutput( PinType bitsMask, PinType values ) override;

    virtual
    void clrOutput( PinType bits ) override;

    virtual
    void toggleOutput( PinType bits ) override;

    virtual
    void writeOutputBit( PinType bitNo, bool val ) override;

protected:

    VirtualOutputPin *m_pVirtualPins;

    PinType           m_pins;
    PinType           m_pinCount;

}; // interface IOutputPort




} // namespace virtual_gpio

} // namespace umba

