#pragma once

#include "umba/umba.h"
#include "umba/assert.h"
#include "stm32.h"
#include "stm32_drivers.h"
#include "virtual_gpio.h"




namespace umba
{

namespace stm32_gpio
{

inline
GPIO_TypeDef* portToGpio( umba::virtual_gpio::Port p )
{
    if (p==umba::virtual_gpio::Port::A) return GPIOA;

    #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 16
    if (p==umba::virtual_gpio::Port::B) return GPIOB;
    #endif

    #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 32
    if (p==umba::virtual_gpio::Port::C) return GPIOC;
    #endif

    #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 48
    if (p==umba::virtual_gpio::Port::D) return GPIOD;
    #endif

    #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 64
    if (p==umba::virtual_gpio::Port::E) return GPIOE;
    #endif

    #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 80
    if (p==umba::virtual_gpio::Port::F) return GPIOF;
    #endif

    #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 96
    if (p==umba::virtual_gpio::Port::G) return GPIOG;
    #endif

    UMBA_ASSERT_FAIL();
    return 0;
}



#if defined(STM32F1_SERIES)

    inline 
    uint32_t gpioToRcc( GPIO_TypeDef * pGpio )
    {
        if (pGpio==GPIOA) return RCC_APB2Periph_GPIOA;

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 16
        if (pGpio==GPIOB) return RCC_APB2Periph_GPIOB;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 32
        if (pGpio==GPIOC) return RCC_APB2Periph_GPIOC;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 48
        if (pGpio==GPIOD) return RCC_APB2Periph_GPIOD;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 64
        if (pGpio==GPIOE) return RCC_APB2Periph_GPIOE;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 80
        if (pGpio==GPIOF) return RCC_APB2Periph_GPIOF;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 96
        if (pGpio==GPIOG) return RCC_APB2Periph_GPIOG;
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

#elif defined(STM32F3_SERIES)

    inline 
    uint32_t gpioToRcc( GPIO_TypeDef * pGpio )
    {
        if (pGpio==GPIOA) return RCC_AHBPeriph_GPIOA;

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 16
        if (pGpio==GPIOB) return RCC_AHBPeriph_GPIOB;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 32
        if (pGpio==GPIOC) return RCC_AHBPeriph_GPIOC;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 48
        if (pGpio==GPIOD) return RCC_AHBPeriph_GPIOD;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 64
        if (pGpio==GPIOE) return RCC_AHBPeriph_GPIOE;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 80
        if (pGpio==GPIOF) return RCC_AHBPeriph_GPIOF;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 96
        if (pGpio==GPIOG) return RCC_AHBPeriph_GPIOG;
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

#elif defined(STM32F4_SERIES)

    inline 
    uint32_t gpioToRcc( GPIO_TypeDef * pGpio )
    {
        if (pGpio==GPIOA) return RCC_AHB1Periph_GPIOA;

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 16
        if (pGpio==GPIOB) return RCC_AHB1Periph_GPIOB;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 32
        if (pGpio==GPIOC) return RCC_AHB1Periph_GPIOC;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 48
        if (pGpio==GPIOD) return RCC_AHB1Periph_GPIOD;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 64
        if (pGpio==GPIOE) return RCC_AHB1Periph_GPIOE;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 80
        if (pGpio==GPIOF) return RCC_AHB1Periph_GPIOF;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 96
        if (pGpio==GPIOG) return RCC_AHB1Periph_GPIOG;
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

#elif defined(STM32L1_SERIES)

    inline 
    uint32_t gpioToRcc( GPIO_TypeDef * pGpio )
    {
        if (pGpio==GPIOA) return RCC_AHBPeriph_GPIOA;

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 16
        if (pGpio==GPIOB) return RCC_AHBPeriph_GPIOB;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 32
        if (pGpio==GPIOC) return RCC_AHBPeriph_GPIOC;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 48
        if (pGpio==GPIOD) return RCC_AHBPeriph_GPIOD;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 64
        if (pGpio==GPIOE) return RCC_AHBPeriph_GPIOE;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 80
        if (pGpio==GPIOF) return RCC_AHBPeriph_GPIOF;
        #endif

        #if defined(STM32_FEATURE_NUM_IOS) && STM32_FEATURE_NUM_IOS > 96
        if (pGpio==GPIOG) return RCC_AHBPeriph_GPIOG;
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

#endif

} // namespace stm32_gpio


} // namespace umba



