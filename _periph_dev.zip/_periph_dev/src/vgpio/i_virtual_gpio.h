#pragma once

#include "umba/umba.h"
#include "umba/interface.h"
#include <stdint.h>



namespace umba
{

namespace virtual_gpio
{


// Базовые определения для аппаратных портов
enum class Port
{
    A, B, C, D, E, F, G
};


enum class PinSpeed
{
    verySlow,
    slow,
    medium,
    high,
    veryHigh
};

enum class PinDirection
{
    input,
    output
};

enum class PinPushPullMode
{
    // for input
    floating , 
    pullUp,
    pullDown,
    // for output
    openDrain, 
    pushPull
};


typedef uint32_t PinType;

const PinType pin_0  = 0x00000001;
const PinType pin_1  = 0x00000002;
const PinType pin_2  = 0x00000004;
const PinType pin_3  = 0x00000008;
const PinType pin_4  = 0x00000010;
const PinType pin_5  = 0x00000020;
const PinType pin_6  = 0x00000040;
const PinType pin_7  = 0x00000080;
const PinType pin_8  = 0x00000100;
const PinType pin_9  = 0x00000200;
const PinType pin_10 = 0x00000400;
const PinType pin_11 = 0x00000800;
const PinType pin_12 = 0x00001000;
const PinType pin_13 = 0x00002000;
const PinType pin_14 = 0x00004000;
const PinType pin_15 = 0x00008000;
const PinType pin_16 = 0x00010000;
const PinType pin_17 = 0x00020000;
const PinType pin_18 = 0x00040000;
const PinType pin_19 = 0x00080000;
const PinType pin_20 = 0x00100000;
const PinType pin_21 = 0x00200000;
const PinType pin_22 = 0x00400000;
const PinType pin_23 = 0x00800000;
const PinType pin_24 = 0x01000000;
const PinType pin_25 = 0x02000000;
const PinType pin_26 = 0x04000000;
const PinType pin_27 = 0x08000000;
const PinType pin_28 = 0x10000000;
const PinType pin_29 = 0x20000000;
const PinType pin_30 = 0x40000000;
const PinType pin_31 = 0x80000000;



interface IInputPort
{
    virtual
    void initPort() = 0;

    virtual
    PinType getPins() = 0;

    virtual
    void readLockPins() = 0; // for serial input ports, not used for native

    virtual
    PinType readInput( PinType mask ) = 0;

    virtual
    bool readInputBit( PinType bitNo ) = 0;

}; // interface IInputPort



interface IOutputPort
{
    virtual
    void initPort() = 0;

    virtual
    PinType getPins() = 0;

    virtual
    void writeFlushPins() = 0; // for serial output ports, not used for native

    virtual
    PinType readOutput( PinType mask ) = 0;

    //virtual
    //void writeOutput( PinType bits ) = 0;

    virtual
    void setOutput( PinType bits ) = 0;

    virtual
    void setOutput( PinType bitsMask, PinType values ) = 0;

    virtual
    void clrOutput( PinType bits ) = 0;

    virtual
    void toggleOutput( PinType bits ) = 0;

    virtual
    void writeOutputBit( PinType bitNo, bool val ) = 0;

}; // interface IOutputPort


} // namespace virtual_gpio

} // namespace umba


