#pragma once

#include <cstddef>

namespace umba
{







// BufSize должен быть степенью двойки
//! Клас циклического буфера  со статическим буфером, размер которого определяется на этапе компиляции
/*!
    // UNDONE: Итераторы сделаем потом, если будет нужно

    // UNDONE: Возможно, стоит сделать специализацию для интегральных типов

    // NOTE: Является потокобезопасным контейнером, если только один поток читает с одного конца очереди, а другой пишет 
       в другой конец очереди, при это читающий должен проверять наличие доступного элемента для чтения,
       а пишуший - доступность свободного места перед записью элемента
 */
template< typename T, size_t BufSize = 256 >
class StaticCycleBuffer
{

public:

    typedef    T                      value_type;

    typedef    size_t                 size_type;
    typedef    std::ptrdiff_t         difference_type;

    typedef    value_type&            reference;
    typedef    const value_type&      const_reference;
    typedef    value_type*            pointer;
    typedef    const value_type*      const_pointer;

    // UNDONE: allocator_type

    //typedef    XXX iterator
    //typedef    XXX const_iterator
    //reverse_iterator          std::reverse_iterator<iterator>
    //const_reverse_iterator    std::reverse_iterator<const_iterator>

    StaticCycleBuffer()
    {
        UMBA_ASSERT( (BufSize>1) && (BufSize & (BufSize-1))==0 );
    }


protected:

    value_type          m_buf[BufSize];
    size_type           m_headIdx = 0;
    size_type           m_tailIdx = 0; // points to the empty cell after last filled

    constexpr           SizeMask = BufSize - 1;

    void destructHelper( value_type *p )
    {
        p->~value_type();
    }

    void constructHelper( value_type *p )
    {
        new (p) T();
    }

    void constructHelper( value_type *p, const value_type &v )
    {
        new (p) T( v );
    }

    void moveHelper( value_type *to, const value_type *from )
    {
        constructHelper( to, *from );
        destructHelper( from );
    }


public:

    bool empty() const
    {
        return m_headIdx==m_tailIdx;
    }

    size_type size() const
    {
        return (m_tailIdx - m_headIdx) & SizeMask;
    }

    size_type max_size() const
    {
        return BufSize - 1;
    }

    // NOTE: В deque такого нет, это из vector'а. Пусть будет? Или в итоге код получится несовместимым с std контейнерами?
    /*
    size_type capacity() const
    {
        return BufSize - 1;
    }
    */

    void shrink_to_fit()
    {
    }

    void clear()
    {
        for( ; m_headIdx!=m_tailIdx; m_headIdx = (m_headIdx+1)&SizeMask )
        {
            destructHelper( &m_buf[m_headIdx] );
        }

        m_headIdx = m_tailIdx = 0;
    }

    // NOTE: при добавлении везде меняем соответствующий индекс, а затем вызываем конструктор
    // При удалении сначала разрушаем, а потом меняем индекс.
    // Т.е. резервируем место сразу, а отдаем в последний момент.
    // Это необходимо для потокобезопасности случая одного писателя в хвост и одного читателя в гриву
    // Читатель должен проверять empty() перед чтением
    // Писатель должен проверять size()!=max_size() перед записью

    // Не стандартная версия insert'а
    // Вставляет value перед элементом, на который указывает pos.
    // Возвращает индекс вставленного элемента
    size_type insert( size_type pos, const T& value )
    {
        if (!pos)
        {
            push_front( value );
            return pos;
        }
        else if ( pos >= size() )
        {
            push_back( value );
            return size()-1;
        }

        // UMBA_ASSERT( m_headIdx!=m_tailIdx );

        // Теперь нам нужно переместить всё на один шаг дальше.

        m_tailIdx = (m_tailIdx+1)&SizeMask;  // сразу - на следующую пустую

        size_type indexPutTo = (m_headIdx+pos)&SizeMask;

        size_type idx = m_tailIdx;
        for(; idx!=indexPutTo; idx = (idx-1)&SizeMask)
        {
            moveHelper( &m_buf[idx], &m_buf[(idx-1)&SizeMask] );
        }

        constructHelper( &m_buf[indexPutTo], value );

        return pos;
    }

    // Не стандартная версия erase'а
    // Удаляет элемент на заданной индексом pos позиции
    // Возвращает индекс элемента, следующего за удаленным
    size_type erase( size_type pos )
    {
        if (!pos)
        {
            pop_front( );
            return pos;
        }
        else if ( pos >= size() )
        {
            pop_back( );
            return size()-1;
        }

        UMBA_ASSERT( m_headIdx!=m_tailIdx ); // не должен быть пустым

        size_type indexEraseWhere = (m_headIdx+pos)&SizeMask;

        // Теперь нам нужно переместить всё на один шаг ближе.

        // Но перед этим - разрушить элемент
        destructHelper( &m_buf[indexEraseWhere] );

        for( ; indexEraseWhere!=m_tailIdx; indexEraseWhere = (indexEraseWhere+1)&SizeMask )
        {
            moveHelper( &m_buf[indexEraseWhere], &m_buf[(indexEraseWhere+1)&SizeMask] );
        }

        m_tailIdx = (m_tailIdx-1)&SizeMask;  // на предыдущую пустую

        return pos;
    }


    // UNDONE: void push_back( T&& value ); (начиная с C++11)
    void push_back( const T& value )
    {
        size_type oldTaleIdx = m_tailIdx;
        m_tailIdx = (m_tailIdx+1)&SizeMask;  // на следующую пустую
        UMBA_ASSERT( m_headIdx!=m_tailIdx );

        constructHelper( &m_buf[oldTaleIdx], value );
    }

    // UNDONE: template< class... Args > void emplace_back( Args&&... args );

    void pop_back()
    {
        UMBA_ASSERT( m_tailIdx!=m_headIdx );
        size_t newTailIdx = (m_tailIdx-1)&SizeMask; // На предыдущую заполненную

        destructHelper( &m_buf[newTailIdx] );

        m_tailIdx = newTailIdx;
    }

    // UNDONE: void push_front( T&& value ); (начиная с C++11)
    void push_front( const T& value )
    {
        m_headIdx = (m_headIdx-1)&SizeMask;  // На предыдущую пустую
        UMBA_ASSERT( m_tailIdx!=m_headIdx );

        constructHelper( &m_buf[m_headIdx], value );
    }

    // UNDONE: template< class... Args > void emplace_front( Args&&... args ); (начиная с C++11)

    void pop_front()
    {
        size_type newHeadIdx = (m_headIdx+1)&SizeMask;  // На следующую заполненную
        destructHelper( &m_buf[m_headIdx] );
        m_headIdx = newHeadIdx;
    }

    void resize( size_type count ); // (начиная с C++11)
    {
         if ( newSize > size() )
         {
             while( newSize > size() )
             {
                 push_back( T() );
             }
         }
         else
         {
             while( newSize < size() )
             {
                 pop_back( );
             }
         }

    }

    void resize( size_type count, const value_type& value) // (начиная с C++11)
    {
         if ( newSize > size() )
         {
             while( newSize > size() )
             {
                 push_back( value );
             }
         }
         else
         {
             while( newSize < size() )
             {
                 pop_back( );
             }
         }
    }

    // UNDONE: void swap( StaticCycleBuffer &other )


    reference       at( size_type pos )
    {
        UMBA_ASSERT( pos < size() );
        return m_buf[ (m_headIdx + pos) & SizeMask ];
    }

    const_reference at( size_type pos ) const;
    {
        UMBA_ASSERT( pos < size() );
        return m_buf[ (m_headIdx + pos) & SizeMask ];
    }

    reference       operator[]( size_type pos )
    {
        UMBA_ASSERT( pos < size() ); //  мы всех обманем, индекс тоже с проверкой
        return m_buf[ (m_headIdx + pos) & SizeMask ];
    }

    const_reference operator[]( size_type pos ) const
    {
        UMBA_ASSERT( pos < size() ); //  мы всех обманем, индекс тоже с проверкой
        return m_buf[ (m_headIdx + pos) & SizeMask ];
    }

    reference front()
    {
        UMBA_ASSERT( !empty() );
        return m_buf[ m_headIdx ];
    }

    const_reference front() const
    {
        UMBA_ASSERT( !empty() );
        return m_buf[ m_headIdx ];
    }

    reference back()
    {
        UMBA_ASSERT( !empty() );
        return m_buf[ m_tailIdx ];
    }

    const_reference back() const
    {
        UMBA_ASSERT( !empty() );
        return m_buf[ m_tailIdx ];
    }


}; // class StaticCycleBuffer







} // namespace umba

