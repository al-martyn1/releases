#pragma once

#include <cstddef>


namespace umba
{


//! Используется для задания размера памяти, резервируемого при инициализации какого-либо контейнера
/*!
 Многие контейнеры, если им задать при создании что-то, похожее на size_t, создадут один элемент с заданным значением.
 Во избежание такого случайного создания вводится специальный тип, через который можно передать размер резервирования.
 */
struct reserve_size
{
    typedef std::size_t   size_type;

    reserve_size( size_type s = 0 ) : m_reserve_size(s) {}

    reserve_size( const reserve_size &rs ) : m_reserve_size(rs.m_reserve_size) {}

    reserve_size& operator=( size_type s )
    {
        m_reserve_size = s;
        return *this;
    }

    reserve_size& operator=( const reserve_size &rs )
    {
        m_reserve_size = rs.m_reserve_size;
        return *this;
    }

    size_type get_reserve_size() const
    {
        return m_reserve_size;
    }


protected:

    template< typename T >
    operator T() const;

    size_type m_reserve_size;

}; // struct reserve_size


} // namespace umba

