#pragma once

#include "umba/stl.h"
#include "umba/assert.h"
#include "umba/allocator.h"
#include "containers/reserve_size.h"

#include <iterator>

#ifdef WIN32
    #include <string>
    #include <sstream>
#endif

namespace umba
{

namespace containers_impl
{


// Все элементы лежат в одном chunk'е
// Можно подумать, и потом доделать реализацию, когда список состоит не из одного списка, а списка чанков
// Для этого выносим реализацию базовых алгоритмов.


//-----------------------------------------------------------------------------
#include "umba/pushpack1.h"
template <typename ListItemIndex>
struct list_item_header
{
    typedef ListItemIndex        item_index_type;

    
    item_index_type              next; //!< Указывает на следующий элемент (если состоит в списке свободных - на следующий свободный элемент)
    item_index_type              prev; //!< Указывает на предыдущий элемент или хранит свой индекс (если состоит в списке свободных)

    /*! next == npos, если элемент - последний
        prev == npos, если элемент - первый
    */
    static const item_index_type npos      = (~((item_index_type)(0)));
    static const item_index_type max_index = (item_index_type)((~((item_index_type)(0))) - (item_index_type)1);

    #if defined(WIN32) || defined(_WIN32)
    std::string dump() const
    {
        std::ostringstream oss;
        oss<<"next: "<<(size_t)next<<", prev: "<<(size_t)prev;
        return oss.str();
    }
    #endif

    
}; // struct list_item_header
#include "umba/packpop.h"



//-----------------------------------------------------------------------------
template < typename ListItemType, typename ListItemIndex >
struct list_item
{
    typedef list_item_header<ListItemIndex>                   list_item_header_type;
    typedef typename list_item_header_type::item_index_type   item_index_type;

    typedef ListItemType                    value_type;
    typedef ListItemType*                   pointer;
    typedef const ListItemType*             const_pointer;
    typedef ListItemType&                   reference;
    typedef const ListItemType&             const_reference;


    list_item_header_type                   header;
    value_type                              value;


    #if defined(WIN32) || defined(_WIN32)
    std::string dump() const
    {
        std::ostringstream oss;
        oss<<header.dump();

        if (is_first())
            oss<<"; first";
        if (is_last())
            oss<<"; last";
        if (is_alone())
            oss<<"; alone";
        return oss.str();
    }
    #endif

    //! Вставляет элемент перед заданным - производит настройку себя и переданного элемента
    /*! !!! Элемент, перед которым вставляем, должен существовать 
    */
    void insert_before( list_item *pChunk, item_index_type idxInsertBefore )
    {
        // текущий (this/self) - только что из списка свободных, prev - хранит свой индекс

        std::swap( header.prev, pChunk[idxInsertBefore].header.prev ); // теперь beforeThat.prev содержит индекс нашего элемента, а наш prev - индекс предыдущего

        header.next = idxInsertBefore;

        if ( header.prev != list_item_header_type::npos ) // настраиваем тот, что перед нами
            pChunk[header.prev].header.next = pChunk[idxInsertBefore].header.prev;
    }

    //! Вставляет элемент после заданного - производит настройку себя и переданного элемента
    /*! !!! Элемент, после которого вставляем, должен существовать 
    */
    void insert_after( list_item *pChunk, item_index_type idxInsertAfter )
    {
        // текущий (this/self) - только что из списка свободных, prev - хранит свой индекс

        std::swap( header.prev, header.next );
        std::swap( header.next, pChunk[idxInsertAfter].header.next ); // теперь afterThat.next содержит индекс нашего элемента, а наш next - индекс следующего

        header.prev = idxInsertAfter;

        if ( header.next != list_item_header_type::npos ) // настраиваем тот, что после нас
            pChunk[header.next].header.prev = pChunk[idxInsertAfter].header.next;
    }

    item_index_type erase( list_item *pChunk )
    {
        item_index_type myNext = header.next;
        item_index_type myPrev = header.prev;
        if ( header.next != list_item_header_type::npos ) // настраиваем тот, что после нас
           pChunk[myNext].header.prev = myPrev; //std::swap( header.prev, pChunk[header.next].header.prev );
        if ( header.prev != list_item_header_type::npos ) // настраиваем тот, что после нас
           pChunk[myPrev].header.next = myNext; //std::swap( header.next, pChunk[header.prev].header.next );
        return myNext;
    }

    void make_alone( )
    {
        header.prev = header.next = list_item_header_type::npos;
    }

    bool is_last() const
    {
        return (header.next == list_item_header_type::npos);
    }

    bool is_first() const
    {
        return (header.prev == list_item_header_type::npos);
    }

    bool is_alone() const
    {
        return (header.prev == header.next) && (header.prev == list_item_header_type::npos);
    }

    template< typename TAllocator >
    void construct( TAllocator& a, const_reference val)
    {
        a.construct( &value, val );
    }

    template< typename TAllocator >
    void destroy(TAllocator& a)
    {
        a.destroy( &value );
    }

    item_index_type get_next() const
    {
        return header.next;
    }

    item_index_type get_prev() const
    {
        return header.prev;
    }


}; // struct list_item


} // namespace containers_impl




//std::iterator_traits<It> содержит typedef-члены value_type, difference_type, reference, pointer, iterator_category, и

//-----------------------------------------------------------------------------
template<typename ItemType, typename IndexType = uint8_t, typename AllocatorType = umba::static_allocator<ItemType> >
struct static_list
{

    typedef std::size_t                                         size_type;
    typedef std::ptrdiff_t                                      difference_type;

    typedef containers_impl::list_item< ItemType, IndexType >   list_item_type;
    typedef typename list_item_type::item_index_type            item_index_type;

    typedef AllocatorType                                                       allocator_type;
    typedef typename allocator_type::template rebind< list_item_type >::other   list_item_allocator_type;

    typedef typename list_item_type::value_type                 value_type;
    typedef value_type*                                         pointer;
    typedef const value_type*                                   const_pointer;
    typedef value_type&                                         reference;
    typedef const value_type&                                   const_reference;

    typedef list_item_type*                                     list_item_pointer;
    typedef const list_item_type*                               const_list_item_pointer;
    typedef list_item_type&                                     list_item_reference;
    typedef const list_item_type&                               const_list_item_reference;


    size_t total_allocated_size() const
    {
        return m_capacity * sizeof(list_item_type);
    }


    //-----------------------------------------------------
    template <typename ReferenceType, typename PointerType>
    struct iterator_base
    {
        friend struct static_list;

        typedef typename static_list::difference_type     difference_type;
        typedef typename static_list::value_type          value_type;
        typedef typename static_list::pointer             pointer;
        typedef typename static_list::const_pointer       const_pointer;
        typedef typename static_list::reference           reference;
        typedef typename static_list::const_reference     const_reference;
        typedef std::bidirectional_iterator_tag  iterator_category;

        iterator_base( const iterator_base &it ) : m_pIteratorList(it.m_pIteratorList), m_itemIndex(it.m_itemIndex) {}

        iterator_base& operator=( const iterator_base &it )
        {
            m_pIteratorList = it.m_pIteratorList;
            m_itemIndex     = it.m_itemIndex;
            return *this;
        }

        bool operator==( const iterator_base &it ) const
        {
            UMBA_ASSERT(m_pIteratorList==it.m_pIteratorList);
            return ( m_itemIndex==it.m_itemIndex );
        }

        bool operator!=( const iterator_base &it ) const
        {
            UMBA_ASSERT(m_pIteratorList==it.m_pIteratorList);
            return ( m_itemIndex!=it.m_itemIndex );
        }

        // https://en.cppreference.com/w/cpp/language/operator_incdec

        iterator_base& operator++() // pre-increment
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            m_pIteratorList->iterForward( *this );
            return *this;
        }

        iterator_base operator++(int) // post-increment
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            iterator_base tmp = *this;
            m_pIteratorList->iterForward( *this );
            return tmp;
        }

        iterator_base& operator--() // pre-decrement
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            m_pIteratorList->iterBackward( *this );
            return *this;
        }

        iterator_base operator--(int) // post-decrement
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            iterator_base tmp = *this;
            m_pIteratorList->iterBackward( *this );
            return tmp;
        }

        // https://en.cppreference.com/w/cpp/language/operator_member_access

        ReferenceType operator*() const
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            return m_pIteratorList->getItem( *this );
        }

        PointerType operator->() const
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            return & m_pIteratorList->getItem( *this );
        }

        typename static_list::list_item_type& getListItem()
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            return m_pIteratorList->getListItem( *this );
        }

        const typename static_list::list_item_type& getListItem() const
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            return m_pIteratorList->getListItem( *this );
        }

        typename list_item_type::list_item_header_type& getListItemInfo()
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            //return m_pIteratorList->getListItem( *this ).header;
            return getListItem().header;
        }

        const typename list_item_type::list_item_header_type& getListItemInfo() const
        {
            UMBA_ASSERT(m_pIteratorList!=0);
            //return m_pIteratorList->getListItem( *this ).header;
            return getListItem().header;
        }

        item_index_type getSelfNo() const
        {
            return m_itemIndex;
        }

        #if defined(WIN32) || defined(_WIN32)
        std::string dump() const
        {
            std::ostringstream oss;
            oss<<"self: "<<(size_t)m_itemIndex<<", "<<getListItem().dump();
            return oss.str();
        }
        #endif

    private:

        iterator_base();

    protected:
    public:

        iterator_base( const static_list* pList, typename static_list::item_index_type itemIndex) : m_pIteratorList((static_list*)pList), m_itemIndex(itemIndex) {}

    protected:

        static_list                             *m_pIteratorList;
        typename static_list::item_index_type    m_itemIndex;

    }; // struct iterator_base


    //-----------------------------------------------------
    struct const_iterator;

    struct iterator : iterator_base< reference, pointer >
    {
        friend struct const_iterator;
        friend struct static_list;

        typedef iterator_base< reference, pointer > iterator_base_type;
        iterator( const iterator &it ) : iterator_base_type( it.m_pIteratorList, it.m_itemIndex ) {}
/*
        bool operator==( const iterator &it ) const
        {
            return iterator_base_type::operator==(it);
        }

        bool operator!=( const iterator &it ) const
        {
            return iterator_base_type::operator!=(it);
        }
*/
    protected:
    public:
        iterator( const iterator_base_type &it ) : iterator_base_type( it ) {}
        iterator( static_list* pList, typename static_list::item_index_type itemIndex) : iterator_base_type(pList, itemIndex) {}

    }; // struct iterator

    //-----------------------------------------------------
    struct const_iterator : iterator_base< const_reference, const_pointer >
    {
        friend struct static_list;

        typedef iterator_base< const_reference, const_pointer > iterator_base_type;
        const_iterator( const const_iterator &it ) : iterator_base_type( it.m_pIteratorList, it.m_itemIndex ) {}
        const_iterator( const iterator &it ) : iterator_base_type(  it.m_pIteratorList, it.m_itemIndex  ) {}
/*
        bool operator==( const const_iterator &it ) const
        {
            return iterator_base_type::operator==(it);
        }

        bool operator!=( const const_iterator &it ) const
        {
            return iterator_base_type::operator!=(it);
        }

        bool operator!=( const iterator &it ) const
        {
            return iterator_base_type::operator!=(it);
        }
*/
    protected:
    public:
        const_iterator( const iterator_base_type &it ) : iterator_base_type( it ) {}
        const_iterator( static_list* pList, typename static_list::item_index_type itemIndex) : iterator_base_type(pList, itemIndex) {}

    }; // struct iterator


protected:
public:

    typedef typename iterator::iterator_base_type           iterator_base_type;
    typedef typename const_iterator::iterator_base_type     const_iterator_base_type;

public:

    typedef std::reverse_iterator<iterator>                     reverse_iterator;
    typedef std::reverse_iterator<const_iterator>               const_reverse_iterator;


    allocator_type get_allocator() const
    {
        return m_allocator();
    }

    ~static_list()
    {
        list_item_allocator_type( m_allocator ).deallocate( m_pItemsStorage, m_capacity );
        //m_allocator.deallocate( m_pItemsStorage, m_capacity );

/*
#  define _RWSTD_REBIND(from, to)
          _TYPENAME from::template rebind < to >::other
*/
    }

    // Конструкторы не совместимы со стандартными
    static_list( umba::reserve_size rs )
        : m_allocator()
        , m_head( list_item_type::list_item_header_type::npos )
        , m_tail( list_item_type::list_item_header_type::npos )
        , m_capacity( rs.get_reserve_size() )
        , m_size(0)
        , m_headFree(0)
        , m_pItemsStorage(0)
    {
        initStorage();
    }

    static_list( umba::reserve_size rs, size_type cnt, const value_type &val = value_type() )
        : m_allocator()
        , m_head( list_item_type::list_item_header_type::npos )
        , m_tail( list_item_type::list_item_header_type::npos )
        , m_capacity( rs.get_reserve_size() )
        , m_size(0)
        , m_headFree(0)
        , m_pItemsStorage(0)
    {
        initStorage();
        assign( cnt, val );
    }

    template< class InputIt >
    static_list( umba::reserve_size rs, InputIt first, InputIt last )
        : m_allocator()
        , m_head( list_item_type::list_item_header_type::npos )
        , m_tail( list_item_type::list_item_header_type::npos )
        , m_capacity( rs.get_reserve_size() )
        , m_size(0)
        , m_headFree(0)
        , m_pItemsStorage(0)
    {
        initStorage();
        assign( first, last );
    }

    static_list( umba::reserve_size rs, const static_list &other )
        : m_allocator()
        , m_head( list_item_type::list_item_header_type::npos )
        , m_tail( list_item_type::list_item_header_type::npos )
        , m_capacity( rs.get_reserve_size() )
        , m_size(0)
        , m_headFree(0)
        , m_pItemsStorage(0)
    {
        initStorage();
        assign( other.begin(), other.end() );
    }


    static_list& operator=( const static_list& other )
    {
        if (&other != this )
            assign( other.begin(), other.end() );
        return *this;
    }

    reference front()
    {
        UMBA_ASSERT( m_size != 0 );
        UMBA_ASSERT( m_head != list_item_type::list_item_header_type::npos );
        return m_pItemsStorage[ m_head ].value;
    }

    const_reference front() const
    {
        UMBA_ASSERT( m_size != 0 );
        UMBA_ASSERT( m_head != list_item_type::list_item_header_type::npos );
        return m_pItemsStorage[ m_head ].value;
    }

    reference back()
    {
        UMBA_ASSERT( m_size != 0 );
        UMBA_ASSERT( m_tail != list_item_type::list_item_header_type::npos );
        return m_pItemsStorage[ m_tail ].value;
    }

    const_reference back() const
    {
        UMBA_ASSERT( m_size != 0 );
        UMBA_ASSERT( m_tail != list_item_type::list_item_header_type::npos );
        return m_pItemsStorage[ m_tail ].value;
    }

    iterator begin()
    {
        return iterator(beginImpl());
    }

    const_iterator begin() const
    {
        return const_iterator(beginImpl());
    }

    const_iterator cbegin() const
    {
        return const_iterator(beginImpl());
    }

    iterator end()
    {
        return iterator(endImpl());
    }

    const_iterator end() const
    {
        return const_iterator(endImpl());
    }

    const_iterator cend() const
    {
        return const_iterator(endImpl());
    }

    reverse_iterator rbegin()
    {
        return reverse_iterator( begin() );
    }

    const_reverse_iterator rbegin() const
    {
        return const_reverse_iterator( begin());
    }

    const_reverse_iterator crbegin() const
    {
        return const_reverse_iterator( begin());
    }

    reverse_iterator rend()
    {
        return reverse_iterator( end() );
    }

    const_reverse_iterator rend() const
    {
        return const_reverse_iterator( end());
    }

    const_reverse_iterator crend() const
    {
        return const_reverse_iterator( end());
    }

    bool empty() const
    {
        return m_size==0;
    }

    size_type size() const
    {
        return m_size;
    }

    size_type max_size() const
    {
        return m_capacity;
    }

    void clear()
    {
        erase( begin(), end() );
    }

    iterator erase( const_iterator pos )
    {
        UMBA_ASSERT( pos.m_pIteratorList == this ); // тот же контейнер?
        UMBA_ASSERT( pos.m_itemIndex != list_item_type::list_item_header_type::npos );
        UMBA_ASSERT( pos.m_itemIndex < m_capacity );
        UMBA_ASSERT( m_size != 0 ); // что-то пошло не так

        list_item_type & erItem = m_pItemsStorage[pos.m_itemIndex];

        bool isLast = erItem.is_last();

        // Настраиваем m_head и m_tail
        if (erItem.is_first())
            m_head = erItem.header.next;

        if (isLast)
            m_tail = erItem.header.prev;

        // Разрушаем хранящийся объект
        erItem.destroy( m_allocator );

        // Удаляем элемент из списка
        item_index_type idxNext = erItem.erase( m_pItemsStorage );

        // Помещаем в список свободных
        erItem.header.next = m_headFree;
        m_headFree = pos.m_itemIndex;

        // Поле prev для свободного элемента должно хранить собственный индекс
        erItem.header.prev = pos.m_itemIndex;

        --m_size;

        if (isLast) // удаляли последний
        {
            return endImpl();
        }

        return iterator( this, idxNext );
    }

    iterator erase( const_iterator first, const_iterator last )
    {
        for( ; first!=last; )
        {
            first = erase(first);
        }

        return last;
    }

    iterator insert( const_iterator pos, const value_type& value )
    {
        UMBA_ASSERT( pos.m_pIteratorList == this ); // тот же контейнер?
        UMBA_ASSERT( pos.m_itemIndex != list_item_type::list_item_header_type::npos ); // нельзя вставлять перед пред-первым

        if (!m_size)
        {
            UMBA_ASSERT( pos==const_iterator(end()) ); // если список пуст, то вставлять можно только перед end
        }

        UMBA_ASSERT( m_size != m_capacity ); // некуда добавлять

        // Получаем свободный элемент

        item_index_type itemIdx = m_headFree;

        UMBA_ASSERT( itemIdx != list_item_type::list_item_header_type::npos );

        list_item_type & newItem = m_pItemsStorage[itemIdx];

        m_headFree = newItem.header.next; // удалили из списка пустых

        // Элемент готов, добавляем в список
        if (!m_size)
        {
            newItem.make_alone();
            m_head = m_tail = itemIdx;
            m_size = 1;
        }
        else
        {
            if (pos==cend())
            {
                newItem.insert_after( m_pItemsStorage, m_tail );
                m_tail = itemIdx;
            }
            else
            {
                newItem.insert_before( m_pItemsStorage, pos.m_itemIndex );
                if (newItem.is_first())
                    m_head = itemIdx;
            }

            ++m_size;
        }

        // Элемент добавлен
        // Самое время сконструировать полезную нагрузку
        newItem.construct( m_allocator, value );

        // Возвращаемое значение: итератор, указывающий на вставленный value.
        return iterator( this, itemIdx );
    }

    // Возвращаемое значение: Итератор, указывающий на первый вставленный элемент, или pos если count==0.
    iterator insert( const_iterator pos, size_type count, const value_type& value )
    {
        if ( count==0 )
            return iterator( pos.m_pIteratorList, pos.m_itemIndex);

        item_index_type firstItemIdx = m_headFree;

        for( size_type i =0; i!=count; ++i )
        {
            insert( pos, value );
        }

        return iterator( this, firstItemIdx );
    }

    // Возвращаемое значение: итератор, указывающий на первый вставленный элемент, или pos если first==last.
    template< class InputIt >
    iterator insert( const_iterator pos, InputIt first, InputIt last )
    {
        if ( first == last )
            return iterator( pos.m_pIteratorList, pos.m_itemIndex);
    
        item_index_type firstItemIdx = m_headFree;

        for(; first!=last; ++first)
        {
            insert( pos, *first );
        }
    
        return iterator( this, firstItemIdx );
    }

    void assign( size_type count, const value_type& value )
    {
        clear();
        insert( cend(), count, value );
    }

    template< class InputIt >
    void assign( InputIt first, InputIt last )
    {
        clear();
        insert( cend(), first, last );
    }

    void push_back( const value_type& value )
    {
        insert( cend(), value );
    }

    void pop_back()
    {
        UMBA_ASSERT( m_size != 0 ); // что-то пошло не так

        const_iterator it = cend(); 
        --it;

        erase( it );
    }

    void push_front( const value_type& value )
    {
        UMBA_ASSERT( m_size != m_capacity ); // некуда добавлять

        // Получаем свободный элемент

        item_index_type itemIdx = m_headFree;

        UMBA_ASSERT( itemIdx != list_item_type::list_item_header_type::npos );

        list_item_type & newItem = m_pItemsStorage[itemIdx];

        m_headFree = newItem.header.next; // удалили из списка пустых

        // Элемент готов, добавляем в список
        if (!m_size)
        {
            newItem.make_alone();
            m_head = m_tail = itemIdx;
            m_size = 1;
        }
        else
        {
            newItem.insert_before( m_pItemsStorage, m_head );
            m_head = itemIdx;
            ++m_size;
        }

        // Элемент добавлен
        // Самое время сконструировать полезную нагрузку
        newItem.construct( m_allocator, value );
    }

    void pop_front()
    {
        erase( cbegin() );
    }

    void resize( size_type count, const value_type &value = value_type() )
    {
        while( size() < count )
            push_back(value);

        while( size() > count )
            pop_back();
    }

    void swap( static_list& other )
    {
        std::swap( m_allocator    , other.m_allocator     );
        std::swap( m_head         , other.m_head          );
        std::swap( m_tail         , other.m_tail          );
        std::swap( m_capacity     , other.m_capacity      );
        std::swap( m_size         , other.m_size          );
        std::swap( m_headFree     , other.m_headFree      );
        std::swap( m_pItemsStorage, other.m_pItemsStorage );
    }

    void reverse()
    {
        if (m_size < 2)
           return;

        item_index_type idx = m_head;

        while( idx != list_item_type::list_item_header_type::npos )
        {
            item_index_type nextIdx = m_pItemsStorage[idx].header.next;
            std::swap( m_pItemsStorage[idx].header.next, m_pItemsStorage[idx].header.prev );
            idx = nextIdx;
        }

        std::swap(m_head, m_tail);
    }


/*
    allocator_type    m_allocator;

    item_index_type   m_head;
    item_index_type   m_tail;

    size_type         m_capacity;
    size_type         m_size;

    item_index_type   m_headFree;

    list_item_type   *m_pItemsStorage;
*/




/*
    void insert_before( list_item *pChunk, item_index_type idxInsertBefore )
    void insert_after( list_item *pChunk, item_index_type idxInsertAfter )
    item_index_type erase( list_item *pChunk )
    void make_alone( )
    bool is_last() const
    bool is_first() const
    bool is_alone() const
    void construct( TAllocator& a, const_reference val)
    void destroy(TAllocator& a)
    item_index_type get_next() const
    item_index_type get_prev() const
*/

protected:

    void initStorage()
    {
        UMBA_ASSERT( m_capacity != 0 );

        UMBA_ASSERT( m_capacity <= ((size_type)(list_item_type::list_item_header_type::max_index)) );

        m_pItemsStorage = list_item_allocator_type( m_allocator ).allocate( m_capacity );
        //m_pItemsStorage = m_allocator.allocate( m_capacity );
        UMBA_ASSERT( m_pItemsStorage != 0 );

        for( size_type i = 0; i!=m_capacity; ++i )
        {
            m_pItemsStorage[i].header.prev = (item_index_type)i; // prev хранит свой индекс
            m_pItemsStorage[i].header.next = (item_index_type)(i + 1); // номер следующего свободного элемента - в новом списке идут по порядку
        }

        m_pItemsStorage[m_capacity-1].header.next = list_item_type::list_item_header_type::npos; // после последнего ничего нет
    }

    template<typename IterType>
    void iterCheckGet( const IterType &it ) const
    {
        if ( it.m_itemIndex == list_item_type::list_item_header_type::npos ) // before begin iterator
           UMBA_ASSERT_FAIL();

        if ( (size_type)(it.m_itemIndex) == m_capacity ) // end iterator
           UMBA_ASSERT_FAIL();
    }
    
    template<typename IterType>
    void iterCheck( const IterType &it ) const
    {
        if ( it.m_itemIndex == list_item_type::list_item_header_type::npos ) // before begin iterator
           UMBA_ASSERT_FAIL();
    }
    
    template<typename IterType>
    reference getItem( const IterType &it ) const
    {
        iterCheckGet(it);
        static_list *pNonConstThis = (static_list*)this;
        size_type idx = (size_type)it.m_itemIndex;
        return pNonConstThis->m_pItemsStorage[ idx ].value;
        //return pNonConstThis->m_pItemsStorage[ it.m_itemIndex ];
        //return m_pItemsStorage[ it.m_itemIndex ];
    }

    template<typename IterType>
    list_item_reference getListItem( const IterType &it ) const
    {
        iterCheck(it);
        static_list *pNonConstThis = (static_list*)this;
        size_type idx = (size_type)it.m_itemIndex;
        return pNonConstThis->m_pItemsStorage[ idx ];
        //return pNonConstThis->m_pItemsStorage[ it.m_itemIndex ];
        //return m_pItemsStorage[ it.m_itemIndex ];
    }

    template<typename IterType>
    void iterForward( IterType &it ) const
    {
        iterCheck(it);

        if (it.m_itemIndex == (item_index_type)m_capacity)
        {
            UMBA_ASSERT_FAIL();
        }

        list_item_type &iterItem = getListItem( it );

        if (iterItem.is_last())
           it.m_itemIndex = (item_index_type)m_capacity;
        else
           it.m_itemIndex = iterItem.get_next();
    }

    template<typename IterType>
    void iterBackward( IterType &it ) const
    {
        iterCheck(it);

        if (it.m_itemIndex == (item_index_type)m_capacity)
        {
            it.m_itemIndex = m_tail;
            return;
        }

        list_item_type &iterItem = getListItem( it );

        if (iterItem.is_first())
            UMBA_ASSERT_FAIL();

        it.m_itemIndex = iterItem.get_prev();
    }

    iterator_base_type beginImpl() const
    {
        //UMBA_ASSERT( m_size != 0 );
        //UMBA_ASSERT( m_head != list_item_type::list_item_header_type::npos );
        if (m_head == list_item_type::list_item_header_type::npos)
            return endImpl();
        return iterator_base_type( this, m_head );
    }

    iterator_base_type endImpl() const
    {
        //return iterator::iterator_base_type( this, m_tail );
        return iterator_base_type( this, (item_index_type)m_capacity );
    }



    allocator_type    m_allocator;

    item_index_type   m_head;
    item_index_type   m_tail;

    size_type         m_capacity;
    size_type         m_size;

    item_index_type   m_headFree;

    list_item_type   *m_pItemsStorage;
    
    //list_item_type    m_tmpItem;





}; // struct static_list






} // namespace umba



