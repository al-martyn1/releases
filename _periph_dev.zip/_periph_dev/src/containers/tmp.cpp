
bool umba::static_list<umba::IMemoryPool::ByteMemPtr,uint16_t,umba::static_allocator<ItemType>>::iterator_base<unsigned char *const &,unsigned char *const *>
::operator !=(
const umba::static_list<                     ItemType,uint16_t,umba::static_allocator<ItemType>>::iterator_base<unsigned char *const &,unsigned char *const *> &
) const 
cannot convert argument 1 from 
const umba::static_list<umba::IMemoryPool::ByteMemPtr,uint16_t,umba::static_allocator<ItemType>>::iterator
const umba::static_list<umba::IMemoryPool::ByteMemPtr,uint16_t,umba::static_allocator<ItemType>>::iterator_base<unsigned char *const &,unsigned char *const *> &
