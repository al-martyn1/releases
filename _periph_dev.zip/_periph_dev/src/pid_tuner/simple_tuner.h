#pragma once

#include "pid_regulator.h"
#include "estimators.h"


PidTuner<SquareErrorTimeEstimator, VarSizeEstimator> getSimpleTuner( PidController controller, float reqOutput )
{
    PidTuner<SquareErrorTimeEstimator, VarSizeEstimator> tuner;

    tuner.init( controller, 1000, reqOutput );

    tuner.initPointEstimator( 1.f, 0.01f, 0.1f, 5 );

    return tuner;
}

