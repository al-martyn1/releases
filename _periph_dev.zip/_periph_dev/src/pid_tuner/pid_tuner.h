/***********************************************************************************************************************************
Это файл класса настройщика ПИД-регулятора
Описывает шаблонный класс настройщика регулятора
 
***********************************************************************************************************
Если хочется просто и быстро, то можно воспользоваться функцией из файла simple_tuner.h
getSimpleTuner
В которую надо передать готовый к работе класс ПИД-регулятора и заданное значение, и получить экземпляр настройщика
 
точек будет 1000
начальные шаги по параметрам регулятора будут такими:
kP = 1
kI = 0.01
kD = 0.1
 
конечные шаги:
kP = 1 / 2^5
kI = 0.01 / 2^5
kD = 0.1 / 2^5
***********************************************************************************************************
 
 
Настройщик наследуется от ПИД-регулятора, для настройки класс настройщика необходимо внедрять в код вместо ПИД-регулятора
Настройщик работает в методе run
 
Также настройщику надо указать классы-вычислители следующего набора параметров и критерия оценки текущего набора параметров
Делается это вот так:
PidTuner<ErrorTimeEstimator, VarSizeEstimator> tuner;
классы-вычислители лежат в файлах estimators.cpp и estimators.h
 
Настройка классов-вычислителей происходит через методы
initCriteriaEstimator     - для настройки вычислителя критерия
initPointEstimator        - для настройки вычислителя следующего набора значений
 
Параметры, переданные в эти методы, транслируются без изменений в методы init классов-вычислителей
 
Начальные значения параметров передаются в настройщика через класс-ПИД-контроллер, который подвергается настройке
Этот класс ПИД-контроллера должен быть проинициализирован
Параметры ПИДа, которые содержатся в классе настраимового ПИД-контроллера, будут использованы в качестве начальной точки
 
В метод init передаётся контроллер для настройки, количество точек в переходном процессе и заданное значение для отработки
 
Результат настройки будет лежать в
***********************************************************************************************************************************/
#pragma once
 
#include "project_config.h"
#include "callbacks/callbacks.h"
#include "common_functions/common_functions.h"
#include "pid_regulator.h"
 
using namespace callback;
 
 
template< class TCriteria, class TPoint >
class PidTuner : public PidController, public TCriteria, public TPoint
{
public:
    
    void init( PidController & controller, 
               size_t pointsToRun,
               float reqVal )
    {
        *(PidController *)this = controller;
        m_controller = controller;
 
        callback::Callback<float (void)> getInput = CALLBACK_BIND( *this, PidTuner::catchInput );
        callback::Callback<void (float)> setOutput = CALLBACK_BIND( *this, PidTuner::catchOutput );
 
        m_controller.init( getInput, setOutput );
 
        m_pointsCount = pointsToRun;
        m_pointsToRelease = pointsToRun;
 
        m_reqVal = reqVal;
        
        m_isReady = false;
    }
  
    template< typename ... T >
    void initCriteriaEstimator( T ... t )
    {
        TCriteria::init( t ... );
    }
    
    template< typename ... T >
    void initPointEstimator( T ... t )
    {
        TPoint::init( t ... );
    }
        
    float catchInput( void )
    {
        m_in = m_getInput();
        TCriteria::countCriteria( *this );
        return m_in;
    }
    void catchOutput( float value )
    {
        m_out = value;
        m_setOutput( value );
    }
 
    virtual void run( uint32_t tim ) override
    {
        if( m_isReady )
        {
            return;
        }
        
        if( m_actPoint == 0 )
        {
            m_controller.flush();
            m_controller.setReq( m_reqVal );
            m_timeBegin = tim;
            TCriteria::getSummaryValue();
            
        }        
        else if( m_actPoint == m_pointsCount )
        {            
            auto result = TCriteria::getSummaryValue();
            
            auto params = TPoint::getNextStepParams( result, m_params );
            if( TPoint::isFinished() )
            {
                m_isReady = true;
                TPoint::flush();
                TCriteria::flush();
            }
            else
            {
                m_params = params;
            }
            
            m_controller.setParams( m_params );
            
            m_controller.flush();
            
            m_setOutput( 0 );
        }
        else if( m_actPoint < m_pointsCount )
        {
            m_controller.run( tim - m_timeBegin );
            m_timeActual = tim - m_timeBegin;
        }
        m_actPoint++;
        m_actPoint %= m_pointsCount + m_pointsToRelease;
    }
 
    PidController getResult( void )
    {
        if( m_isReady )
        {
            return m_controller;
        }
        return PidController();
    }
 
private:
    
    PidController m_controller;
 
    size_t m_actPoint = 0;
 
    size_t m_pointsCount;
 
    size_t m_pointsToRelease;
 
    size_t m_timeBegin = 0;    
    size_t m_timeActual = 0;    
 
    float m_reqVal;
 
    float m_in;
    float m_out;
 
    bool m_isReady = false;
    
    friend TCriteria;
 
};