/***********************************************************************************************************************************
Это файл класса ПИД-регулятора
Описывает класс регулятора с Float-параметрами и структуру параметров ПИДа
 
ПИД работает в методе run
прием входных параметров и выдача выхода регулятора происходит через коллбеки
getInput - прочитать значение с обратной связи
setOutput - подать управляющее воздействие
 
Задание требуемого значения регулируемой величины через метод setReq
 
Для быстрого сброса всех параметров регулятора можно использовать метод flush
 
Для задания параметров ПИДа - метод setParams
 
Регуляторы можно приравнивать один другому(оператор =)
***********************************************************************************************************************************/
#pragma once
 
 
#include "project_config.h"
#include "callbacks/callbacks.h"
using namespace callback;
 
 
struct PidParams
{
    float proportional;
    float integral;
    float differential;
 
    float maxIntegralPart;
 
    float maxOutputValue;
 
    bool operator==( const PidParams & that )
    {
        return ( (proportional == that.proportional) && (integral == that.integral) && (differential == that.differential) );
    }
};
 
class PidController
{
public:
 
    void setParams( PidParams params )
    {
        m_params = params;
    }
 
    void init( Callback<float (void)> getInput, Callback<void (float)> setOutput )
    {
        m_getInput = getInput;
        m_setOutput = setOutput;
    }
 
    void setReq( float req )
    {
        m_reqValue = req;
    }
 
    virtual void run( uint32_t time );
 
    PidController & operator=( const PidController & that )
    {
        m_getInput = that.m_getInput;
        m_setOutput = that.m_setOutput;
 
        m_params = that.m_params;
 
        return *this;
    }
 
    void flush( void )
    {
        m_prevError = 0;
        m_sum = 0;
        m_reqValue = 0;
        m_prevTime = 0;
        m_isStopped = true;
    }
 
    virtual ~PidController(){}
 
protected:
 
    Callback<float (void)> m_getInput;
    Callback<void (float)> m_setOutput;
 
    PidParams m_params;
 
private:
 
    float m_prevError;
    float m_sum;
    float m_reqValue;
 
    size_t m_prevTime = 0;
 
    bool m_isStopped = true;
};