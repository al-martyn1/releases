#include "estimators.h"
 
 
PidParams ConstSizeEstimator::getNextStepParams( float actualCriteria, PidParams actualStep )
{
    PidParams result = m_actualStep;
    switch( stepCnt )
    {
        case 0:
        {
            //first step, need to remember it as a base
            m_actualStep = actualStep; 
            stepCnt++;
            result = m_actualStep;
            
            result.proportional += m_sizeP;
            break;
        }
        case 1:
        {
            m_possibleStepsCriteria[0] = actualCriteria;
            stepCnt++;
            result.proportional -= m_sizeP;
            break;
        }
        case 2:
        {
            m_possibleStepsCriteria[1] = actualCriteria;
            stepCnt++;
            result.integral += m_sizeI;
            break;
        }
        case 3:
        {
            m_possibleStepsCriteria[2] = actualCriteria;
            stepCnt++;
            result.integral -= m_sizeI;
            break;
        }
        case 4:
        {
            m_possibleStepsCriteria[3] = actualCriteria;
            stepCnt++;
            result.differential += m_sizeD;
            break;
        }
        case 5:
        {
            m_possibleStepsCriteria[4] = actualCriteria;
            stepCnt++;
            result.differential -= m_sizeD;
            break;
        }
        case 6:
        {
            m_possibleStepsCriteria[5] = actualCriteria;
            
            float min = m_possibleStepsCriteria[0];
            int32_t minIndex = 0;
            
            for( int32_t i = 1; i < 6; i++ )
            {
                if( m_possibleStepsCriteria[i] < min )
                {
                    min = m_possibleStepsCriteria[i];
                    minIndex = i;
                }
            }
            if( ( m_minCriteria > min ) || ( m_minCriteria == 0 ) )
            {
                m_minCriteria = min;
                recount( result, minIndex );
                stepCnt = 0;
            }
            else if( m_minCriteria <= min )
            {
                m_isFinished = true;
            }
        }
    }
    return result;
}
 
void ConstSizeEstimator::recount( PidParams & base, int32_t step )
{
    switch( step )
    {
        case 0:
            base.proportional += m_sizeP;
            return;
        case 1:
            base.proportional -= m_sizeP;
            return;
        case 2:
            base.integral += m_sizeI;
            return;
        case 3:
            base.integral -= m_sizeI;
            return;
        case 4:
            base.differential += m_sizeD;
            return;
        case 5:
            base.differential -= m_sizeD;
            return;
            
    }
}
 