/***********************************************************************************************************************************
Здесь покоятся классы-вычислители для автонастройщика ПИД-регулятора
 
вычислители критерия:
ErrorTimeEstimator - интеграл от модуля ошибки, умноженного на время
SquareErrorTimeEstimator - интеграл от квадрата ошибки, умноженного на время
SquareErrorSquareTimeEstimator - интеграл от квадрата ошибки на квадрат времени
 
вычислители следующего шага:
ConstSizeEstimator - покоординатный спуск с фиксированным шагом
VarSizeEstimator - покоординатный спуск с убывающим шагом (глубина убывания передаётся в методе init)
***********************************************************************************************************************************/
 
#pragma once
 
#include "project_config.h"
#include "pid_tuner.h"
 
class ErrorTimeEstimator
{
public:
    
    template<class TTuner>
    void countCriteria( TTuner & tuner )
    {
        float error = tuner.m_reqVal - tuner.m_in;
        float time = tuner.m_timeActual;
        
        if( error < 0 )
        {
            error =-error;
        }
        m_sum += error * time;
    }
    
    float getSummaryValue( void )
    {
        auto ret = m_sum;
        m_sum = 0;
        return ret;
    }
    
    void flush( void )
    {
        m_sum = 0;
    }
    
private:
    
    float m_sum = 0;
};
 
class SquareErrorTimeEstimator
{
public:
    
    template<class TTuner>
    void countCriteria( TTuner & tuner )
    {
        float error = tuner.m_reqVal - tuner.m_in;
        float time = tuner.m_timeActual;
        m_sum += error * error * time;
    }
    
    float getSummaryValue( void )
    {
        auto ret = m_sum;
        m_sum = 0;
        return ret;
    }
    
    void flush( void )
    {
        m_sum = 0;
    }
    
private:
    
    float m_sum = 0;
};
 
class SquareErrorSquareTimeEstimator
{
public:
    
    template<class TTuner>
    void countCriteria( TTuner & tuner )
    {
        float error = tuner.m_reqVal - tuner.m_in;
        float time = tuner.m_timeActual;
        m_sum += error * error * time * time;
    }
    
    float getSummaryValue( void )
    {
        auto ret = m_sum;
        m_sum = 0;
        return ret;
    }
    
    void flush( void )
    {
        m_sum = 0;
    }
    
private:
    
    float m_sum = 0;
};
 
 
class ConstSizeEstimator
{
public:
        
    void init( float sizeP, float sizeI, float sizeD )
    {
        m_sizeP = sizeP;
        m_sizeI = sizeI;
        m_sizeD = sizeD;
        m_isFinished = false;
        stepCnt = 0;
    }
        
    PidParams getNextStepParams( float actualCriteria, PidParams actualStep );
    
    void recount( PidParams & base, int32_t step );
    
    void flush( void )
    {
        for( auto & i : m_possibleStepsCriteria )
        {
            i = 0;
        }
        stepCnt = 0;
        m_minCriteria = 0;
    }
    
    bool isFinished( void )
    {
        return m_isFinished;
    }
    
private:
        
    float m_possibleStepsCriteria[6];
    PidParams m_actualStep;
    
    size_t stepCnt = 0;
    
    float m_sizeP = 0;
    float m_sizeI = 0;
    float m_sizeD = 0;
 
    float m_minCriteria = 0;
 
    bool m_isFinished = false;
};
 
 
class VarSizeEstimator
{
public:
        
    void init(  float initialSizeP, 
                float initialSizeI, 
                float initialSizeD, 
                int32_t depth )
    {
        m_startSizeP = initialSizeP;
        m_startSizeI = initialSizeI;
        m_startSizeD = initialSizeD;
        m_sizeP = m_startSizeP;
        m_sizeI = m_startSizeI;
        m_sizeD = m_startSizeD;
        
        m_maxDepth = depth;
        m_actDepth = 0;
        
        m_simpleEstimator.init( m_sizeP, m_sizeI, m_sizeD );
        m_isFinished = false;
    }
 
    PidParams getNextStepParams( float actualCriteria, PidParams actualStep )
    {
        
        PidParams res = m_simpleEstimator.getNextStepParams( actualCriteria, actualStep );
        
        if( m_simpleEstimator.isFinished() )
        {
            m_sizeP /= 2;
            m_sizeI /= 2;
            m_sizeD /= 2;
            
            m_actDepth++;
            
            if( m_actDepth > m_maxDepth )
            {
                m_isFinished = true;
                
                return actualStep;
            }
            m_simpleEstimator.init( m_sizeP, m_sizeI, m_sizeD );
        }
     
        return res;
        
    }
    
    void flush( void )
    {
        m_simpleEstimator.flush();
        
        m_sizeP = m_startSizeP;
        m_sizeI = m_startSizeI;
        m_sizeD = m_startSizeD;
        
    }
    
    bool isFinished( void )
    {
        return m_isFinished;
    }
    
private:
    
    ConstSizeEstimator m_simpleEstimator;
 
    float m_sizeP = 0;
    float m_sizeI = 0;
    float m_sizeD = 0;
 
    float m_startSizeP = 0;
    float m_startSizeI = 0;
    float m_startSizeD = 0;
 
    int32_t m_maxDepth;
    int32_t m_actDepth;
 
 
    bool m_isFinished = false;
};
 
