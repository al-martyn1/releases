#include "pid_regulator.h"
 
#include "common_functions/common_functions.h"
 
void PidController::run( uint32_t time )
{
    float input = m_getInput();
 
    float delta = m_reqValue - input;
 
    float derivate = 0;
    if( !m_isStopped )
    {
        derivate = ( delta - m_prevError ) / ( time - m_prevTime );
 
        m_sum += m_params.integral * delta * ( time - m_prevTime );
    }
    else
    {
        m_isStopped = false;
    }
 
    common_functions::clamp( m_sum, -m_params.maxIntegralPart, m_params.maxIntegralPart );
 
    float result = m_params.proportional * delta + m_sum + m_params.differential * derivate;
 
    common_functions::clamp( result, -m_params.maxOutputValue, m_params.maxOutputValue );
 
    m_setOutput( result );
 
    m_prevTime = time;
}

