#pragma once

namespace tvko
{
    namespace ro
    {
        const uint8_t min = 0x00;

        //$ROBEGIN

        const uint8_t current_x_s8                                                = 0x00; // текущий ток мотора оси X в попугаях
        const uint8_t current_y_s8                                                = 0x01; // текущий ток мотора оси X в попугаях
        const uint8_t temperature_u8                                              = 0x02; // температура
        const uint8_t status_u8                                                   = 0x03; // статус платы

        //$ROEND

        const uint8_t max = 0x03;
    }

    namespace rw
    {
        const uint8_t min = 0x80;

        //$RWBEGIN

        const uint8_t voltage_x_s8                                                = 0x80; // скорость мотора оси X в % от -100 до 100
        const uint8_t voltage_y_s8                                                = 0x81; // скорость мотора оси Y в % от -100 до 100
        const uint8_t camera_power_u8                                             = 0x82; // on = 1/off = 0
        const uint8_t digital_zoom_u8                                             = 0x83; // on = 1/off = 0
        const uint8_t auto_focus_u8                                               = 0x84; // on = 1/off = 0
        const uint8_t zoom_speed_s8                                               = 0x85; // от -8 до 8
        const uint8_t focus_speed_s8                                              = 0x86; // от -8 до 8
        const uint8_t infrared_correction_u8                                      = 0x87; // standart = 0, ir_light = 0x01
        const uint8_t white_balance_u8                                            = 0x88; // auto = 0, manual = 0x05, sodium lamp = 0x07
        const uint8_t red_gain_u8                                                 = 0x89; // от 0 до 255
        const uint8_t blue_gain_u8                                                = 0x8A; // от 0 до 255
        const uint8_t automatic_exposure_u8                                       = 0x8B; // full auto = 0, manual = 0x03, shutter_priority = 0x0a, iris_priority = 0x0b, bright = 0x0d
        const uint8_t shutter_u8                                                  = 0x8C; // от 0x0 до 0x15, '0x0' - 1/1sec; '0x15' - 1/10000sec
        const uint8_t iris_u8                                                     = 0x8D; // от 0x0 до 0x11, '0x0' - close; '0x01' - f28; '0x11' - f1.6
        const uint8_t gain_u8                                                     = 0x8E; // от 0x0 до 0x0f
        const uint8_t bright_u8                                                   = 0x8F; // от 0x0 до 0x1f
        const uint8_t backlight_compensation_u8                                   = 0x90; // on = 1/off = 0
        const uint8_t defog_u8                                                    = 0x91; // on = 1/off = 0
        const uint8_t high_resolution_mode_u8                                     = 0x92; // on = 1/off = 0
        const uint8_t mirror_u8                                                   = 0x93; // on = 1/off = 0
        const uint8_t black_white_u8                                              = 0x94; // on = 1/off = 0
        const uint8_t flip_u8                                                     = 0x95; // on = 1/off = 0
        const uint8_t infrared_mode_u8                                            = 0x96; // on = 1/off = 0
        const uint8_t auto_infrared_mode_u8                                       = 0x97; // on = 1/off = 0
        const uint8_t auto_infrared_mode_threshold_u8                             = 0x98; // тут пределы не нашёл в даташите
        const uint8_t stabilizer_u8                                               = 0x99; // on = 1/off = 0/hold = 2
        const uint8_t color_enhance_u8                                            = 0x9A; // on = 1/off = 0
        const uint8_t color_enhance_threshold_level_u8                            = 0x9B; // значения от 0 до 0x7f
        const uint8_t color_enhance_hysteresis_width_u8                           = 0x9C; // значения от 0 до 0x7f
        const uint8_t color_enhance_fixed_color_y_of_high_intensity_side_u8       = 0x9D; // значения от 0 до 0x7f
        const uint8_t color_enhance_fixed_color_cr_of_high_intensity_side_u8      = 0x9E; // значения от 0 до 0x7f
        const uint8_t color_enhance_fixed_color_cb_of_high_intensity_side_u8      = 0x9F; // значения от 0 до 0x7f
        const uint8_t color_enhance_fixed_color_y_of_low_intensity_side_u8        = 0xA0; // значения от 0 до 0x7f
        const uint8_t color_enhance_fixed_color_cr_of_low_intensity_side_u8       = 0xA1; // значения от 0 до 0x7f
        const uint8_t color_enhance_fixed_color_cb_of_low_intensity_side_u8       = 0xA2; // значения от 0 до 0x7f
        const uint8_t zoom_direct_position_s16                                    = 0xA3; // от 0 до не знаю

        //$RWEND

        const uint8_t max = 0xA4;
    }

}
