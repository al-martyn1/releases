/**************************************************************************************************
 Это файл с настройками для проекта

 Помещайте сюда инклуды, которые будут нужны везде 
**************************************************************************************************/

#pragma once

#include "stm32.h"
#include "umba/umba.h"
#include "global_macros/global_macros.h"

#include "global_macros/stm32f3xx_global_macros.h"

//#include "registers/tvko.h"

#define UMBA_USE_RETARGET

/*
namespace cannabus
{
    template<uint8_t, uint8_t, uint8_t, uint8_t>
    class CannabusRegTable;
}

using RegTable = cannabus::CannabusRegTable<tvko::ro::min, tvko::ro::max, tvko::rw::min, tvko::rw::max >;

*/


