#pragma once

#include "project_config.h"
#include "luart/i_serial_port.h"
#include "milliganjubus_common.h"
#include "milliganjubus_request_processor.h"
#include "milliganjubus_msg_composer.h"
#include "milliganjubus_ans_creator.h"

namespace milliganjubus
{

    class SlaveSession
    {
    public:

        SlaveSession() :
            m_request_timeout_max(0),
            m_port(0),
            m_slaveAdr(),
            m_composer(),
            m_reqProcessor(),
            m_ansCreator(),
            m_request(),
            m_answer(),
            m_isRequestComposed(false),
            m_isConnected(false),
            m_lastRequestTimestamp(0 - m_request_timeout_max - 1),
            m_lastCallTime(0),
            m_onMessageReceived(0),
            m_onConnectionLost(0),
            m_onConnectionRestored(0),
            m_state( State::RECEIVE_REQUEST )
        {

        }

        void init(ISerialPort & port,
                  uint8_t slaveAdr,
                  milliganjubus::IMilliRegTable & table,
                  callback::VoidCallback lostLinkHandler = callback::NullCallback(),
                  callback::VoidCallback restoredLinkHandler = callback::NullCallback(),
                  uint32_t lostLinkTimeout = 1000,
                  callback::VoidCallback onMessageReceived = callback::NullCallback());

        void work(uint32_t curTime);

        bool isConnected(void) const
        {
            return m_isConnected;
        }

    protected:

        STRONG_ENUM(State, RECEIVE_REQUEST, SEND_ANSWER );

        // копирование запрещено
        SlaveSession( const SlaveSession & rhs);
        SlaveSession & operator=( SlaveSession s);

        void onRequestComposed( const milliganjubus::MilliMessage & msg );

        uint32_t m_request_timeout_max;

        ISerialPort * m_port;
        uint8_t m_slaveAdr;

        milliganjubus::MsgComposer m_composer;
        milliganjubus::RequestProcessor m_reqProcessor;
        milliganjubus::AnswerCreator m_ansCreator;

        milliganjubus::MilliMessage m_request;
        milliganjubus::MilliMessage m_answer;

        bool m_isRequestComposed;

        bool m_isConnected;
        uint32_t m_lastRequestTimestamp;
        uint32_t m_lastCallTime;

        callback::VoidCallback m_onMessageReceived;

        callback::VoidCallback m_onConnectionLost;
        callback::VoidCallback m_onConnectionRestored;

        State m_state;

        static const uint32_t request_send_time_max = 1000;

    };

} // namespace

