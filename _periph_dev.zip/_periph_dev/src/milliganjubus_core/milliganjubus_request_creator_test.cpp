#include "project_config.h"


#ifdef USE_TESTS


#include "umba_cpp_test/umba_cpp_tests.h"

#include "milliganjubus_request_creator.h"
#include "milliganjubus_msg_composer.h"
#include "milliganjubus_message_format.h"

#include "common_functions/common_functions.h"
#include "callbacks/callbacks.h"

using namespace milliganjubus;

UMBA_TEST_GROUP( "Milliganjubus Request Creator")


/***************************************************************************************************
                                       Тестовые данные
***************************************************************************************************/

static MilliMessage request;

static uint8_t testAddr = 0x88;



/***************************************************************************************************
                                       Объекты для тестов
***************************************************************************************************/

static milliganjubus::RequestCreator testCreator;


/***************************************************************************************************
                                       Моки
***************************************************************************************************/

/***************************************************************************************************
                                       Вспомогательные функции
***************************************************************************************************/


UMBA_TEST_SETUP()
{
    testCreator.init(testAddr);
}

UMBA_TEST_TEARDOWN()
{
    for(uint8_t i=0; i<MILLI_GANJUBUS_MESSAGE_SIZE_MAX; i++)
    {
        request.buf[i] = 0;
    }
}

void checkIfRequestValid(uint8_t * buf)
{
    MsgComposer composer;

    composer.initSlave( callback::NullCallback(), testAddr);

    for(uint8_t i=0; i<MILLI_GANJUBUS_RX_MSG_HEADER_SIZE; ++i)
    {
        // адрес проверять не надо
        if(i== MILLI_GANJUBUS_TX_MSG_ADR_OFFSET)
            continue;

        UMBA_ASSERT( composer.isHeaderValid( buf, i ) == true  );
    }

    UMBA_ASSERT( rx_messages::isMsgCrcValid(buf) == true);
}


/***************************************************************************************************
                                       Тесты
***************************************************************************************************/


UMBA_TEST( "Create write single" )
{
    testCreator.createWriteReg(request, 123, 18);

    checkIfRequestValid( request.buf );

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );
    UMBA_CHECK( buf[1] == 123 );
    UMBA_CHECK( buf[2] == 18);

    return 0;
}

UMBA_TEST( "Create write range" )
{
    uint8_t values[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};

    testCreator.createWriteRange(request, 0x80, 0x83, values);

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE );

    UMBA_CHECK( buf[1] == 0x80 );
    UMBA_CHECK( buf[2] == 0x83 );

    UMBA_CHECK( buf[3] == 0 );
    UMBA_CHECK( buf[4] == 1 );
    UMBA_CHECK( buf[5] == 2 );
    UMBA_CHECK( buf[6] == 3 );


    return 0;
}

PRAGMA_SUPPRESS_STATEMENT_UNREACHABLE_BEGIN

UMBA_TEST( "Create write range - Range too long - Should assert" )
{
    uint8_t values[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};

    // тест игнорируется
    return 0;

    testCreator.createWriteRange(request, 0x80, 0x87, values);

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE );

    UMBA_CHECK( buf[1] == 0x80 );
    UMBA_CHECK( buf[2] == 0x83 );

    UMBA_CHECK( buf[3] == 0 );
    UMBA_CHECK( buf[4] == 1 );
    UMBA_CHECK( buf[5] == 2 );
    UMBA_CHECK( buf[6] == 3 );


    return 0;
}

UMBA_TEST( "Create write range - Range invalid - Should assert" )
{
    uint8_t values[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};

    // тест игнорируется
    return 0;

    // начало больше конца
    testCreator.createWriteRange(request, 0x87, 0x80, values);

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE );

    UMBA_CHECK( buf[1] == 0x80 );
    UMBA_CHECK( buf[2] == 0x83 );

    UMBA_CHECK( buf[3] == 0 );
    UMBA_CHECK( buf[4] == 1 );
    UMBA_CHECK( buf[5] == 2 );
    UMBA_CHECK( buf[6] == 3 );


    return 0;
}

UMBA_TEST( "Create read range - Range too long - Should assert" )
{
    // тест игнорируется
    return 0;

    testCreator.createReadRange(request, 0x0, 0x8);

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

    UMBA_CHECK( buf[1] == 0x0 );
    UMBA_CHECK( buf[2] == 0x3 );

    return 0;
}

UMBA_TEST( "Create read range - Range invalid - Should assert" )
{
    // тест игнорируется
    return 0;

    // начало больше конца
    testCreator.createReadRange(request, 0x8, 0x0);

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

    UMBA_CHECK( buf[1] == 0x0 );
    UMBA_CHECK( buf[2] == 0x3 );

    return 0;
}

PRAGMA_END

UMBA_TEST( "Create Write Series" )
{
    RequestCreator::Register series[4];

    series[0].num = 15;
    series[0].val = 115;

    series[1].num = 16;
    series[1].val = 116;

    series[2].num = 17;
    series[2].val = 117;

    series[3].num = 18;
    series[3].val = 118;


    testCreator.createWriteSeries(request, series, sizeof(series)/sizeof(RequestCreator::Register) );

    checkIfRequestValid( request.buf );

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES );

    UMBA_CHECK( buf[1] == 15 );
    UMBA_CHECK( buf[2] == 115 );

    UMBA_CHECK( buf[3] == 16 );
    UMBA_CHECK( buf[4] == 116 );

    UMBA_CHECK( buf[5] == 17 );
    UMBA_CHECK( buf[6] == 117 );

    UMBA_CHECK( buf[7] == 18 );
    UMBA_CHECK( buf[8] == 118 );

    return 0;

}

UMBA_TEST( "Create Read Single" )
{
    testCreator.createReadReg(request, 154);

    checkIfRequestValid( request.buf );

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG );
    UMBA_CHECK( buf[1] == 154 );

    return 0;

}


UMBA_TEST( "Create Read Range" )
{
    testCreator.createReadRange(request, 123, 130);

    checkIfRequestValid( request.buf );

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );
    UMBA_CHECK( buf[1] == 123 );
    UMBA_CHECK( buf[2] == 130 );

    return 0;
}


UMBA_TEST( "Create Read Series" )
{
    RequestCreator::Register series[4];

    series[0].num = 15;

    series[1].num = 29;

    series[2].num = 1;

    series[3].num = 129;

    testCreator.createReadSeries(request, series, NUM_ELEM(series) );

    checkIfRequestValid( request.buf );

    uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;

    UMBA_CHECK( buf[0] == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES );

    buf++;

    for(uint8_t i=0; i<NUM_ELEM(series); i++)
    {
        UMBA_CHECK(buf[i] == series[i].num);
    }

    UMBA_CHECK( request.buf[MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET] == MILLI_GANJUBUS_TX_MSG_SERVICE_FIELDS_SIZE + 1 + 4, "Size should be gbyte + series");

    return 0;
}




#endif
