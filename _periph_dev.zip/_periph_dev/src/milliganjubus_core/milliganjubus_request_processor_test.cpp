#include "project_config.h"

#ifdef USE_TESTS

#include "umba_cpp_test/umba_cpp_tests.h"


#include "milliganjubus_request_processor.h"
#include "milliganjubus_msg_composer.h"
#include "milliganjubus_common.h"
#include "common_functions/common_functions.h"
#include "milliganjubus_simple_reg_table.h"

using namespace milliganjubus;

namespace
{

    UMBA_TEST_GROUP( "MilliGanjubus Request Processor" )


    /***************************************************************************************************
                                           Тестовые данные
    ***************************************************************************************************/

    const uint8_t testAddress = 0x88;

    /***************************************************************************************************
                                           Объекты для тестов
    ***************************************************************************************************/


    RequestProcessor testProcessor;


    /***************************************************************************************************
                                           Моки
    ***************************************************************************************************/

    static SimpleRegTable<0, 0x50, 0x80, 0xFF> mockTable;


    static AnswerCreator ansCreator;


    /***************************************************************************************************
                                           Вспомогательные функции
    ***************************************************************************************************/


    UMBA_TEST_SETUP()
    {
        ansCreator.init( testAddress );

        testProcessor.init(mockTable, ansCreator);
    }

    UMBA_TEST_TEARDOWN()
    {

    }

    static void checkIfAnswerValid(uint8_t * buf)
    {
        MsgComposer composer;

        for(uint8_t i=0; i<MILLI_GANJUBUS_TX_MSG_HEADER_SIZE; ++i)
        {

            if(i== MILLI_GANJUBUS_TX_MSG_ADR_OFFSET)
            {
                UMBA_ASSERT( buf[i] == testAddress );
                continue;
            }

        }

        UMBA_ASSERT( rx_messages::isMsgCrcValid(buf) == true);
    }


    /***************************************************************************************************
                                           ТЕСТЫ
    ***************************************************************************************************/



    UMBA_TEST("Invalid Fcode - should nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = 0x09;

        MilliMessage answer;

        testProcessor.parseRequest(request, answer);


        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == 0x09, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_FCODE, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;
    }

    /*
    ====================================================================================================
                                              Тесты чтения
    ====================================================================================================
    */


    /*
    ----------------------------------------------------------------------------------------------------
                                         Чтение одного регистра
    ----------------------------------------------------------------------------------------------------
    */


    UMBA_TEST( "Parse read single - should be parsed correctly" )
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();

        mockTable.setRegVal(0, 0x77);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 1);



        MilliMessage answer;

        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == mockTable.getRoMinRegNum(), "Reg number should be right");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1 + 1] == 0x77, "Reg value should be read");

        checkIfAnswerValid(ansBuf);

        return 0;

    }

    UMBA_TEST("Parse read single - invalid regNum - should nack" )
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMaxRegNum() + 1;

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 1);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);



        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;

    }

    UMBA_TEST( "Parse read single - invalid data size - should nack" )
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();

        // ставим размер на единицу больше правильного
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);



        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;

    }

    /*
    ----------------------------------------------------------------------------------------------------
                                         Чтение диапазона
    ----------------------------------------------------------------------------------------------------
    */

    UMBA_TEST( "Parse correct read range - should be parsed" )
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum() + 3;

        mockTable.setRegVal(0, 0x11);
        mockTable.setRegVal(1, 0x22);
        mockTable.setRegVal(2, 0x33);
        mockTable.setRegVal(3, 0x44);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == mockTable.getRoMinRegNum(), "Reg number should be right");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 2] == mockTable.getRoMinRegNum()+3, "Reg number should be right");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 3] == 0x11, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 4] == 0x22, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 5] == 0x33, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 6] == 0x44, "Value should be right");

        checkIfAnswerValid(ansBuf);

        return 0;

    }

    UMBA_TEST( "Parse read range - Invalid regNum - Should nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMaxRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum() + 2;


        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;

    }

    UMBA_TEST( "Parse read range - invalid data size - Should nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum() + 1;


        // ставим неправильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 3 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;
    }

    UMBA_TEST( "Parse read range - range is too big - Should nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum() + MILLI_GANJUBUS_RANGE_LENGTH_MAX;


        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;
    }



    UMBA_TEST( "Parse read range - 1 reg range - Should ack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        mockTable.setRegVal(mockTable.getRoMinRegNum() + 0, 0x33);

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum();

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, "Fcode should be right");
        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == mockTable.getRoMinRegNum(), "Reg number should be right");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 2] == mockTable.getRoMinRegNum(), "Reg number should be right");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 3] == 0x33, "Value should be right");

        checkIfAnswerValid(ansBuf);

        return 0;

    }

    UMBA_TEST( "Parse read range - Maximal reg num - Should ack")
    {
        static SimpleRegTable<0, 0x50, 0x80, 0xFF> table;

        testProcessor.init(table, ansCreator);


        table.setRegVal( 0xF8, 0x01);
        table.setRegVal( 0xF9, 0x02);
        table.setRegVal( 0xFA, 0x03);
        table.setRegVal( 0xFB, 0x04);
        table.setRegVal( 0xFC, 0x05);
        table.setRegVal( 0xFD, 0x06);
        table.setRegVal( 0xFE, 0x07);
        table.setRegVal( 0xFF, 0x08);

        MilliMessage request;

        uint8_t buf[] = {0xbb, 0x01, 0x08, 0x96, 0x05, 0xf8, 0xff, 0xec};

        std::copy( buf, buf + NUM_ELEM(buf), request.buf );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, "Fcode should be right");
        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == 0xf8, "Reg number should be right");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 2] == 0xff, "Reg number should be right");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 3]  == 0x01, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 4]  == 0x02, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 5]  == 0x03, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 6]  == 0x04, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 7]  == 0x05, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 8]  == 0x06, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 9]  == 0x07, "Value should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 10] == 0x08, "Value should be right");

        checkIfAnswerValid(ansBuf);

        return 0;

    }


    /*
    ----------------------------------------------------------------------------------------------------
                                           Чтение серий
    ----------------------------------------------------------------------------------------------------
    */


    UMBA_TEST("Correct read series should be parsed")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum() + 1;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3] = mockTable.getRoMinRegNum() + 2;


        mockTable.setRegVal(0, 0x99);
        mockTable.setRegVal(1, 0x88);
        mockTable.setRegVal(2, 0x77);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 3 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        for(uint8_t i=MILLI_GANJUBUS_TX_MSG_DATA_OFFSET+1, j=0; j<3; j++, i+=2)
        {
            UMBA_CHECK( ansBuf[i] == mockTable.getRoMinRegNum()+j , "Regnum should be right");
            UMBA_CHECK( ansBuf[i+1] == mockTable.getRegVal(j) , "Value should be right");
        }

        checkIfAnswerValid(ansBuf);

        return 0;
    }


    UMBA_TEST("Parse read series - Invalid regNum - Should nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum() + 1;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3] = mockTable.getRoMaxRegNum() + 2;

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 3 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);


        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;

    }

    UMBA_TEST("Parse read series - Invalid Size - Should nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum() + 1;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3] = mockTable.getRoMaxRegNum() + 2;

        // ставим неправильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);


        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;
    }

    UMBA_TEST("Parse read series - Series is too big - Should nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum() + 1;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3] = mockTable.getRoMinRegNum() + 2;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 4] = mockTable.getRoMinRegNum() + 3;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 5] = mockTable.getRoMinRegNum() + 4;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 6] = mockTable.getRoMinRegNum() + 5;

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 6 );

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);


        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;

    }

    /*
    ====================================================================================================
                                            Тесты записи
    ====================================================================================================
    */

    /*
    ----------------------------------------------------------------------------------------------------
                                         Запись одного регистра
    ----------------------------------------------------------------------------------------------------
    */

    UMBA_TEST("Parse correct single write -  should be ack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMinRegNum();

        uint8_t byte = common_functions::xorshiftRandomByte();

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = byte;

        mockTable.setRegVal(0x80, 0x00);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == mockTable.getRwMinRegNum(), "Reg number should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0x80) == byte, "Value should be written");

        return 0;
    }

    UMBA_TEST( "Parse write single - Writing ro register - Should nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;

        // пытаемся записать в РО-регистр
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();

        uint8_t byte = common_functions::xorshiftRandomByte();

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = byte;

        mockTable.setRegVal(0, 0x00);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0) == 0x00, "Value should not be written");

        return 0;

    }

    UMBA_TEST("Parse write single - Invalid RegNum  - Should Nack" )
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMaxRegNum()+5;

        uint8_t byte = common_functions::xorshiftRandomByte();

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = byte;

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");

        checkIfAnswerValid(ansBuf);

        return 0;
    }

    UMBA_TEST( "Parse Write Single - Invalid DataSize - Should Nack" )
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMinRegNum();

        uint8_t byte = common_functions::xorshiftRandomByte()+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = byte;

        mockTable.setRegVal(0x80, 0x00);

        // ставим неправильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 20);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, "Errcode should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0x80) == 0, "Table should not be changed");

        return 0;
    }

    /*
    ----------------------------------------------------------------------------------------------------
                                           Запись диапазона
    ----------------------------------------------------------------------------------------------------
    */

    UMBA_TEST("Parse correct write range - should ACK")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMinRegNum();

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRwMinRegNum()+2;

        uint8_t rndData[4] = {0x54, 0x6b, 0x19, 0x63};

        for(uint8_t i=0; i<3; i++)
        {
            buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3 + i] = rndData[i];
        }

        mockTable.setRegVal(0x80, 0x00);
        mockTable.setRegVal(0x81, 0x00);
        mockTable.setRegVal(0x82, 0x00);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2 + 3);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == mockTable.getRwMinRegNum(), "Regnum should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 2] == mockTable.getRwMinRegNum()+2, "Regnum should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0x80) == rndData[0], "Table should be changed");
        UMBA_CHECK(mockTable.getRegVal(0x81) == rndData[1], "Table should be changed");
        UMBA_CHECK(mockTable.getRegVal(0x82) == rndData[2], "Table should be changed");


        return 0;
    }


    UMBA_TEST("Parse correct write range with maximal registers - should ACK")
    {
        static SimpleRegTable<0, 0x50, 0x80, 0xFF> table;

        testProcessor.init(table, ansCreator);

        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = 0xF8;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = 0xFF;

        uint8_t rndData[8] = {1,2,3,4,5,6,7,8};

        for(uint8_t i=0; i<8; i++)
        {
            buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3 + i] = rndData[i];
        }

        table.setRegVal(0xF8, 0x00);
        table.setRegVal(0xF9, 0x00);
        table.setRegVal(0xFA, 0x00);
        table.setRegVal(0xFB, 0x00);
        table.setRegVal(0xFC, 0x00);
        table.setRegVal(0xFD, 0x00);
        table.setRegVal(0xFE, 0x00);
        table.setRegVal(0xFF, 0x00);


        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = MILLI_GANJUBUS_RX_MSG_SIZE_MAX;

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == 0xF8, "Regnum should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 2] == 0xFF, "Regnum should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(table.getRegVal(0xF8) == rndData[0], "Table should be changed");
        UMBA_CHECK(table.getRegVal(0xF9) == rndData[1], "Table should be changed");
        UMBA_CHECK(table.getRegVal(0xFA) == rndData[2], "Table should be changed");
        UMBA_CHECK(table.getRegVal(0xFB) == rndData[3], "Table should be changed");
        UMBA_CHECK(table.getRegVal(0xFC) == rndData[4], "Table should be changed");
        UMBA_CHECK(table.getRegVal(0xFD) == rndData[5], "Table should be changed");
        UMBA_CHECK(table.getRegVal(0xFE) == rndData[6], "Table should be changed");
        UMBA_CHECK(table.getRegVal(0xFF) == rndData[7], "Table should be changed");


        return 0;
    }


    UMBA_TEST("Parse write range - Writing Ro Register - Should Nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMinRegNum();

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMinRegNum()+2;

        uint8_t rndData[4] = {0x27, 0x79, 0x30, 0xA1};

        for(uint8_t i=0; i<3; i++)
        {
            buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3 + i] = rndData[i]+1; // no zeros
        }

        mockTable.setRegVal(0, 0x00);
        mockTable.setRegVal(1, 0x00);
        mockTable.setRegVal(2, 0x00);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2 + 3);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(1) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(2) == 0x00, "Table should not be changed");


        return 0;
    }


    UMBA_TEST("Parse write range - Invalid Regnum - ShouldNack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRoMaxRegNum();

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRoMaxRegNum()+2;

        uint8_t rndData[4] = {194, 15, 250, 0};

        for(uint8_t i=0; i<3; i++)
        {
            buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3 + i] = rndData[i]+1; // no zeros
        }

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2 + 3);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;

    }

    UMBA_TEST("Parse Write Range - Invalid Data Size - Should Nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMinRegNum();

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = mockTable.getRwMinRegNum()+2;

        uint8_t rndData[4] = {36, 158, 71, 12};

        for(uint8_t i=0; i<3; i++)
        {
            buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3 + i] = rndData[i]+1; // no zeros
        }

        // ставим неправильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 2 + 1);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, "Errcode should be right");


        checkIfAnswerValid(ansBuf);

        return 0;

    }


    /*
    ----------------------------------------------------------------------------------------------------
                                         Запись серии
    ----------------------------------------------------------------------------------------------------
    */

    UMBA_TEST("Parse correct write series - should ack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        uint8_t rndData[4] = {194, 12, 28, 3};

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = rndData[0]+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3] = mockTable.getRwMinRegNum()+2;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 4] = rndData[1]+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 5] = mockTable.getRwMinRegNum()+4;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 6] = rndData[2]+1;


        mockTable.setRegVal(0x80, 0x00);
        mockTable.setRegVal(0x81, 0x00);
        mockTable.setRegVal(0x82, 0x00);
        mockTable.setRegVal(0x83, 0x00);
        mockTable.setRegVal(0x84, 0x00);
        mockTable.setRegVal(0x85, 0x00);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 6);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == true, "Should be ACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == mockTable.getRwMinRegNum(), "Regnum should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 2] == mockTable.getRwMinRegNum()+2, "Regnum should be right");
        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 3] == mockTable.getRwMinRegNum()+4, "Regnum should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0x80) == rndData[0]+1, "Table should be changed");
        UMBA_CHECK(mockTable.getRegVal(0x81) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x82) == rndData[1]+1, "Table should be changed");
        UMBA_CHECK(mockTable.getRegVal(0x83) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x84) == rndData[2]+1, "Table should be changed");
        UMBA_CHECK(mockTable.getRegVal(0x85) == 0x00, "Table should not be changed");

        return 0;

    }

    UMBA_TEST("Parse Write Series - Writing Ro Register - ShouldNack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        uint8_t rndData[4] = {18,68,31,147};

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = rndData[0]+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3] = mockTable.getRwMinRegNum()+2;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 4] = rndData[1]+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 5] = mockTable.getRoMinRegNum()+4;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 6] = rndData[2]+1;


        mockTable.setRegVal(0x80, 0x00);
        mockTable.setRegVal(0x81, 0x00);
        mockTable.setRegVal(0x82, 0x00);
        mockTable.setRegVal(0x83, 0x00);
        mockTable.setRegVal(0x84, 0x00);
        mockTable.setRegVal(0x85, 0x00);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 6;

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0x80) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x81) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x82) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x83) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x84) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x85) == 0x00, "Table should not be changed");

        return 0;
    }

    UMBA_TEST("Parse Write Series - Writing Invalid Register - Should Nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        uint8_t rndData[4] = {45, 59, 163, 210};

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = rndData[0]+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3] = mockTable.getRwMaxRegNum()+2;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 4] = rndData[1]+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 5] = mockTable.getRoMinRegNum()+4;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 6] = rndData[2]+1;


        mockTable.setRegVal(0x80, 0x00);
        mockTable.setRegVal(0x81, 0x00);
        mockTable.setRegVal(0x82, 0x00);
        mockTable.setRegVal(0x83, 0x00);
        mockTable.setRegVal(0x84, 0x00);
        mockTable.setRegVal(0x85, 0x00);

        // ставим правильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 6);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, "Errcode should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0x80) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x81) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x82) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x83) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x84) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x85) == 0x00, "Table should not be changed");

        return 0;

    }

    UMBA_TEST("Parse Write Series - Invalid Size - Should Nack")
    {
        MilliMessage request;

        uint8_t * buf = request.buf;

        uint8_t rndData[4] = {31, 7, 93, 84};

        buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1] = mockTable.getRwMinRegNum();
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 2] = rndData[0]+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 3] = mockTable.getRwMinRegNum()+2;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 4] = rndData[1]+1;

        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 5] = mockTable.getRwMinRegNum()+4;
        buf[MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 6] = rndData[2]+1;


        mockTable.setRegVal(0x80, 0x00);
        mockTable.setRegVal(0x81, 0x00);
        mockTable.setRegVal(0x82, 0x00);
        mockTable.setRegVal(0x83, 0x00);
        mockTable.setRegVal(0x84, 0x00);
        mockTable.setRegVal(0x85, 0x00);

        // ставим неправильный размер
        buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = (MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE + 1 + 1);

        MilliMessage answer;
        testProcessor.parseRequest(request, answer);

        uint8_t * ansBuf = answer.buf;

        UMBA_CHECK( getFcode(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES, "Fcode should be right");

        UMBA_CHECK( isGbyteAck(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET]) == false, "Should be NACK");

        UMBA_CHECK(ansBuf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + 1] == MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, "Errcode should be right");

        checkIfAnswerValid(ansBuf);

        UMBA_CHECK(mockTable.getRegVal(0x80) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x81) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x82) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x83) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x84) == 0x00, "Table should not be changed");
        UMBA_CHECK(mockTable.getRegVal(0x85) == 0x00, "Table should not be changed");


        return 0;
    }


} // anonymous namespace

#endif
