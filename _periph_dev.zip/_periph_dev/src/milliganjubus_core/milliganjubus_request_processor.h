#pragma once

#include "project_config.h"
#include "milliganjubus_i_milli_reg_table.h"
#include "milliganjubus_message_format.h"
#include "milliganjubus_ans_creator.h"
#include "milliganjubus_common.h"

namespace milliganjubus
{

    class RequestProcessor
    {

    public:

        RequestProcessor() :
            m_table(0),
            m_answerCreator(0)
        {

        }

        void init(IMilliRegTable & table, AnswerCreator & ansCreator)
        {
            m_table = &table;
            m_answerCreator = &ansCreator;
        }

        void parseRequest( const MilliMessage & request, MilliMessage & answer );

    protected:

        uint8_t getMsgFcode( const MilliMessage & request) const
        {
            return getFcode( request.buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] );
        }


        // возвращает указатель на данные после эф-кода
        const uint8_t * getDataBuf( const MilliMessage & request) const
        {
            const uint8_t * buf = request.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET;
            return (buf + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE);
        }


        bool isSingleRegValid(uint8_t regNum) const ;
        bool isRangeValid(uint8_t start, uint8_t end) const;
        bool isReadSeriesValid(const MilliMessage & request) const;
        bool isWriteSeriesValid(const MilliMessage & request) const;

        bool isRegisterRo( uint8_t regNum ) const;


        uint8_t getDataSize(const MilliMessage & request) const;


        void parseReadSingleReq(const MilliMessage & request, MilliMessage & answer);
        void parseReadRangeReq(const MilliMessage & request, MilliMessage & answer);
        void parseReadSeriesReq(const MilliMessage & request, MilliMessage & answer);

        void parseWriteSingleReq(const MilliMessage & request, MilliMessage & answer);
        void parseWriteRangeReq(const MilliMessage & request, MilliMessage & answer);
        void parseWriteSeriesReq(const MilliMessage & request, MilliMessage & answer);

        IMilliRegTable * m_table;

        AnswerCreator * m_answerCreator;



    };

} /* namespace milliganjubus */
