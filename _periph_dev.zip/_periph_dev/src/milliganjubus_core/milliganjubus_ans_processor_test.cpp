#include "project_config.h"


#ifdef USE_TESTS

#include "umba_cpp_test/umba_cpp_tests.h"

#include "milliganjubus_ans_processor.h"
#include "milliganjubus_simple_reg_table.h"
#include "milliganjubus_message_format.h"
#include "common_functions/common_functions.h"

using namespace milliganjubus;

namespace
{

    UMBA_TEST_GROUP( "MilliGanjubus Answer Processor" )

    /***************************************************************************************************
                                           Тестовые данные
    ***************************************************************************************************/

    const uint8_t testRoMin = 5;
    const uint8_t testRoRegsMax = 40;

    const uint8_t testRwMin = 120;
    const uint8_t testRwRegsMax = 134;

    SimpleRegTable <testRoMin, testRoRegsMax, testRwMin, testRwRegsMax> testTable;


    MilliMessage correctWriteSingle123Hand;
    MilliMessage correctWriteSingle125Hand;
    MilliMessage correctReadSingle34_96Hand;
    MilliMessage correctReadRange34_37Hand;
    MilliMessage correctWriteRange121_124Hand;
    MilliMessage correctWriteSeries121_122_123Hand;
    MilliMessage correctReadSeries121_122_124_125Hand;

    /***************************************************************************************************
                                           Объекты для тестов
    ***************************************************************************************************/

    AnswerProcessor testAnsProc;

    /***************************************************************************************************
                                           Моки
    ***************************************************************************************************/

    class MockCallbacks
    {
    public:

        void onMsgProcessed(void)
        {
            m_msgProcessed = true;
        }

        bool m_msgProcessed;
    };

    MockCallbacks mockCallbacks;

    /***************************************************************************************************
                                           Вспомогательные функции
    ***************************************************************************************************/

    UMBA_TEST_SETUP()
    {
        callback::VoidCallback onAnswerProcessed_cb = CALLBACK_BIND( mockCallbacks, MockCallbacks::onMsgProcessed );

        mockCallbacks.m_msgProcessed = false;

        testAnsProc.init(testTable, onAnswerProcessed_cb);

        {

            uint8_t * buf = correctWriteSingle123Hand.buf;

            uint8_t gByte = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
            gByte = addAck(gByte);

            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET] = gByte;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 1] = 123;
        }

        {

            uint8_t * buf = correctWriteSingle125Hand.buf;

            uint8_t gByte = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
            gByte = addAck(gByte);

            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET] = gByte;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 1] = 125;
        }
        {

            uint8_t * buf = correctReadSingle34_96Hand.buf;

            uint8_t gByte = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;
            gByte = addAck(gByte);

            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET] = gByte;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 1] = 34;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 2] = 96;
        }

        {

            uint8_t * buf = correctReadRange34_37Hand.buf;

            uint8_t gByte = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;
            gByte = addAck(gByte);

            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET] = gByte;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 1] = 34;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 2] = 37;

            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 3] = 66;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 4] = 66;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 5] = 66;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 6] = 66;
        }
        {

            uint8_t * buf = correctWriteRange121_124Hand.buf;

            uint8_t gByte = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;
            gByte = addAck(gByte);

            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET] = gByte;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 1] = 121;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 2] = 124;
        }

        {

            uint8_t * buf = correctWriteSeries121_122_123Hand.buf;

            uint8_t gByte = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;
            gByte = addAck(gByte);

            // три регистра + гБайт
            buf[MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = 4 + MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE;

            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET] = gByte;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 1] = 121;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 2] = 122;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 3] = 123;
        }

        {

            uint8_t * buf = correctReadSeries121_122_124_125Hand.buf;

            uint8_t gByte = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;
            gByte = addAck(gByte);

            // четыре регистра + четыре значения + гБайт
            buf[MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] = 9 + MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE;

            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET] = gByte;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 1] = 121;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 2] = 66;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 3] = 122;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 4] = 66;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 5] = 124;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 6] = 66;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 7] = 125;
            buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + 8] = 66;
        }

    }

    UMBA_TEST_TEARDOWN()
    {
        // обнуляем все регистры
        for(uint8_t i = testRwMin; i <= testRwRegsMax; i++)
        {
            testTable.setRegVal(i, 0);
            // чек сбрасывает флаг изменения
            testTable.checkRwRegUpdate(i);
        }

    }


    /***************************************************************************************************
                                           Тесты
    ***************************************************************************************************/


    UMBA_TEST( "Correct Write Single" )
    {
        testTable.setRegVal(123, 88);

        testAnsProc.processAnswer( correctWriteSingle123Hand );

        UMBA_CHECK( mockCallbacks.m_msgProcessed == true );

        mockCallbacks.m_msgProcessed = false;

        testTable.setRegVal(125, 88);

        testAnsProc.processAnswer( correctWriteSingle125Hand );

        UMBA_CHECK( mockCallbacks.m_msgProcessed == true );

        return 0;
    }

    UMBA_TEST( "Correct Read Single" )
    {
        testTable.setRegVal(34, 88);

        testAnsProc.processAnswer( correctReadSingle34_96Hand );

        UMBA_CHECK( testTable.getRegVal(34) == 96 );

        return 0;
    }

    UMBA_TEST( "Correct Read Range" )
    {
        testTable.setRegVal(33, 88);
        testTable.setRegVal(34, 88);
        testTable.setRegVal(35, 88);
        testTable.setRegVal(36, 88);
        testTable.setRegVal(37, 88);
        testTable.setRegVal(38, 88);

        testAnsProc.processAnswer( correctReadRange34_37Hand );

        UMBA_CHECK( testTable.getRegVal(33) == 88 );

        UMBA_CHECK( testTable.getRegVal(34) == 66 );
        UMBA_CHECK( testTable.getRegVal(35) == 66 );
        UMBA_CHECK( testTable.getRegVal(36) == 66 );
        UMBA_CHECK( testTable.getRegVal(37) == 66 );

        UMBA_CHECK( testTable.getRegVal(38) == 88 );

        return 0;
    }

    UMBA_TEST( "Correct Write Range" )
    {
        testTable.setRegVal(120, 1);
        testTable.setRegVal(121, 2);
        testTable.setRegVal(122, 3);
        testTable.setRegVal(123, 4);
        testTable.setRegVal(124, 5);
        testTable.setRegVal(125, 6);

        testAnsProc.processAnswer( correctWriteRange121_124Hand );

        UMBA_CHECK( mockCallbacks.m_msgProcessed == true );

        return 0;
    }

    UMBA_TEST( "Correct Write Series" )
    {
        testTable.setRegVal(120, 88);
        testTable.setRegVal(121, 88);
        testTable.setRegVal(122, 88);
        testTable.setRegVal(123, 88);
        testTable.setRegVal(124, 88);

        testAnsProc.processAnswer( correctWriteSeries121_122_123Hand );

        UMBA_CHECK( mockCallbacks.m_msgProcessed == true );

        return 0;

    }

    UMBA_TEST( "Correct Read Series" )
    {
        testTable.setRegVal(120, 88);
        testTable.setRegVal(121, 88);
        testTable.setRegVal(122, 88);
        testTable.setRegVal(123, 88);
        testTable.setRegVal(124, 88);
        testTable.setRegVal(125, 88);
        testTable.setRegVal(126, 88);

        testAnsProc.processAnswer( correctReadSeries121_122_124_125Hand );

        UMBA_CHECK( testTable.getRegVal(120) == 88 );

        UMBA_CHECK( testTable.getRegVal(121) == 66 );
        UMBA_CHECK( testTable.getRegVal(122) == 66 );

        UMBA_CHECK( testTable.getRegVal(123) == 88 );

        UMBA_CHECK( testTable.getRegVal(124) == 66 );
        UMBA_CHECK( testTable.getRegVal(125) == 66 );

        UMBA_CHECK( testTable.getRegVal(126) == 88 );

        return 0;

    }

} // anonymous namespace

#endif
