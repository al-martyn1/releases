#pragma once

#include "project_config.h"

#ifdef USE_FREERTOS

#include "milliganjubus_slave_session.h"

namespace milliganjubus
{
    void freeRtosSlaveTask(void * params);
}

#endif
