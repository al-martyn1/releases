#include "project_config.h"

#ifdef USE_TESTS

#include "umba_cpp_test/umba_cpp_tests.h"
#include "common_functions/common_functions.h"
#include "milliganjubus_ans_creator.h"
#include "milliganjubus_msg_composer.h"

using namespace milliganjubus;

namespace
{

    /***************************************************************************************************
                                           Тестовые данные
    ***************************************************************************************************/

    static const uint8_t testAddress = 0x89;


    UMBA_TEST_GROUP( "MilliGanjubus Answer Creator" )


    /***************************************************************************************************
                                       Объекты для тестов
    ***************************************************************************************************/


    static AnswerCreator testAnsCreator;


    UMBA_TEST_SETUP()
    {
        testAnsCreator.init(testAddress);
    }

    UMBA_TEST_TEARDOWN()
    {

    }

    static void checkIfAnswerValid(uint8_t * buf)
    {
        MsgComposer composer;

        MsgComposer::OnMsgComposed_cb cb;

        composer.initSlave(cb, testAddress);

        for(uint8_t i=0; i<MILLI_GANJUBUS_TX_MSG_HEADER_SIZE; ++i)
        {

            if(i== MILLI_GANJUBUS_TX_MSG_ADR_OFFSET)
            {
                UMBA_ASSERT( buf[i] == testAddress );
                continue;
            }

            UMBA_ASSERT( composer.isHeaderValid( buf, i ) == true  );
        }

        UMBA_ASSERT( rx_messages::isMsgCrcValid(buf) == true);
    }




    UMBA_TEST("Create nack answer")
    {
        MilliMessage answer;

        testAnsCreator.createNackAnswer(0x08, 0x06, answer);

        uint8_t * buf = answer.buf;

        uint8_t gByte = buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ];

        UMBA_CHECK( isGbyteAck(gByte) == false, "Should be NACK" );

        UMBA_CHECK( gByte == 0xE8, "Should be Error + fake fcode 8" );

        checkIfAnswerValid(buf);

        return 0;
    }


    UMBA_TEST("Create read single answer")
    {
        uint8_t testRegNum = common_functions::xorshiftRandomByte();
        uint8_t testVal = common_functions::xorshiftRandomByte();

        MilliMessage answer;

        testAnsCreator.createReadSingleAnswer(testRegNum, testVal, answer);

        uint8_t * buf = answer.buf;

        uint8_t gByte = buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ];

        UMBA_CHECK( isGbyteAck(gByte) == true, "Should be ACK" );
        UMBA_CHECK( getFcode(gByte) == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG, "Fcode should be correct");

        uint8_t reg = buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE ];

        UMBA_CHECK( reg == testRegNum, "Reg number should be correct" );

        uint8_t val = buf[MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE  + 1];

        UMBA_CHECK( val == testVal, "Value should be correct" );


        checkIfAnswerValid(buf);


        return 0;
    }

    UMBA_TEST("Ceate read range answer")
    {
        uint8_t testRegStart = 0x01;
        uint8_t testRegEnd = MILLI_GANJUBUS_RANGE_LENGTH_MAX;

        AnswerCreator::Register range[MILLI_GANJUBUS_RANGE_LENGTH_MAX];

        for(uint8_t i=0; i<MILLI_GANJUBUS_RANGE_LENGTH_MAX; i++)
        {
            range[i].value = common_functions::xorshiftRandomByte();
        }

        MilliMessage answer;

        testAnsCreator.createReadRangeAnswer(testRegStart, testRegEnd, range, answer);

        uint8_t * buf = answer.buf;

        uint8_t gByte = buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ];

        UMBA_CHECK( isGbyteAck(gByte) == true, "Should be ACK" );
        UMBA_CHECK( getFcode(gByte) == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, "Fcode should be correct");

        uint8_t regStart = buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE ];
        uint8_t regEnd =   buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE  + 1 ];

        UMBA_CHECK( regStart == testRegStart, "Reg start should be correct" );
        UMBA_CHECK( regEnd == testRegEnd, "Reg end should be correct" );


        checkIfAnswerValid(buf);

        return 0;
    }

    UMBA_TEST("Create read series answer")
    {

        AnswerCreator::Register series[MILLI_GANJUBUS_SERIES_LENGTH_MAX];

        for(uint8_t i=0; i<MILLI_GANJUBUS_SERIES_LENGTH_MAX; i++)
        {
            series[i].regNum = common_functions::xorshiftRandomByte();
            series[i].value = common_functions::xorshiftRandomByte();
        }

        MilliMessage answer;
        testAnsCreator.createReadSeriesAnswer(series, MILLI_GANJUBUS_SERIES_LENGTH_MAX, answer);

        uint8_t * buf = answer.buf;

        uint8_t gByte = buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ];

        UMBA_CHECK( isGbyteAck(gByte) == true, "Should be ACK" );
        UMBA_CHECK( getFcode(gByte) == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES, "Fcode should be correct");

        uint8_t * p = buf + MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

        for(uint8_t i=0, j=0; i<MILLI_GANJUBUS_SERIES_LENGTH_MAX; i++, j+=2)
        {
            UMBA_CHECK(series[i].regNum == p[j], "Regs should match");
            UMBA_CHECK(series[i].value == p[j+1], "Values should match");
        }



        checkIfAnswerValid(buf);


        return 0;
    }


    UMBA_TEST("Create write single answer")
    {
        uint8_t testRegNum = 0x08;

        MilliMessage answer;
        testAnsCreator.createWriteSingleAnswer(testRegNum, answer);

        uint8_t * buf = answer.buf;

        uint8_t gByte = buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ];

        UMBA_CHECK( isGbyteAck(gByte) == true, "Should be ACK" );
        UMBA_CHECK( getFcode(gByte) == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Fcode should be correct");

        uint8_t reg = buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE ];

        UMBA_CHECK( reg == testRegNum, "Reg number should be correct" );


        checkIfAnswerValid(buf);

        return 0;
    }

    UMBA_TEST("Create write range answer")
    {
        uint8_t testRegStart = 0x08;
        uint8_t testRegEnd = 0x99;

        MilliMessage answer;
        testAnsCreator.createWriteRangeAnswer(testRegStart, testRegEnd, answer);

        uint8_t * buf = answer.buf;

        uint8_t gByte = buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ];

        UMBA_CHECK( isGbyteAck(gByte) == true, "Should be ACK" );
        UMBA_CHECK( getFcode(gByte) == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, "Fcode should be correct");

        uint8_t regStart = buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE ];
        uint8_t regEnd =   buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE  + 1 ];

        UMBA_CHECK( regStart == testRegStart, "Reg start should be correct" );
        UMBA_CHECK( regEnd == testRegEnd, "Reg end should be correct" );


        checkIfAnswerValid(buf);

        return 0;
    }


    UMBA_TEST( "Create write series answer")
    {

        AnswerCreator::Register series[ MILLI_GANJUBUS_SERIES_LENGTH_MAX ];

        uint8_t size = sizeof(series)/sizeof(series[0]);

        for(uint8_t i=0; i<size; i++)
        {
            series[i].regNum = common_functions::xorshiftRandomByte()+1;
            series[i].value = common_functions::xorshiftRandomByte();
        }

        MilliMessage answer;
        testAnsCreator.createWriteSeriesAnswer(series, size, answer);

        uint8_t * buf = answer.buf;

        uint8_t gByte = buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ];

        UMBA_CHECK( isGbyteAck(gByte) == true, "Should be ACK" );
        UMBA_CHECK( getFcode(gByte) == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES, "Fcode should be correct");


        for(uint8_t i=MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1, j=0; j<size; i++, j++)
        {
            UMBA_CHECK(buf[i] == series[j].regNum, "Registers should be right");
        }


        checkIfAnswerValid(buf);

        return 0;
    }

} // anonymous namespace

#endif
