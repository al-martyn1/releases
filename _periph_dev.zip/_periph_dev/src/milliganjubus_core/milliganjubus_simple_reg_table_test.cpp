#include "project_config.h"

#ifdef USE_TESTS

#include "umba_cpp_test/umba_cpp_tests.h"
#include "milliganjubus_simple_reg_table.h"

namespace
{

    using namespace milliganjubus;

    UMBA_TEST_GROUP("MilliGanjubus RegTable")

    const uint8_t roMin = 5;
    const uint8_t roMax = 19;

    const uint8_t rwMin = 0x94;
    const uint8_t rwMax = 0xA0;

    SimpleRegTable <roMin, roMax, rwMin, rwMax> testTable;

    UMBA_TEST_SETUP()
    {
        for(uint8_t i=roMin; i<=roMax; i++ )
        {
            testTable.setRegVal(i, 0);
            testTable.checkRegUpdate(i);
        }

        for(uint8_t i=rwMin; i<=rwMax; i++ )
        {
            testTable.setRegVal(i, 0);
            testTable.checkRegUpdate(i);
        }
    }

    UMBA_TEST_TEARDOWN()
    {

    }

    UMBA_TEST("Write 8-bit ro value - Should be updated")
    {
        testTable.setRegVal( roMin, 0x77 );

        UMBA_CHECK( testTable.checkRegUpdate( roMin ) == true );
        UMBA_CHECK( testTable.getRegVal(roMin) == 0x77 );

        return 0;
    }

    UMBA_TEST("Write 8-bit ro value - Update should be cleared")
    {
        testTable.setRegVal( roMin, 0x77 );

        testTable.checkRegUpdate( roMin );

        UMBA_CHECK( testTable.checkRegUpdate( roMin ) == false );

        return 0;
    }

    UMBA_TEST("Write 8-bit rw value - Should be updated")
    {
        testTable.setRegVal( rwMin, 0x77 );

        UMBA_CHECK( testTable.checkRegUpdate( rwMin ) == true );
        UMBA_CHECK( testTable.getRegVal(rwMin) == 0x77 );

        return 0;
    }

    UMBA_TEST("Write 8-bit rw value - Update should be cleared")
    {
        testTable.setRegVal( rwMin, 0x77 );

        testTable.checkRegUpdate( rwMin );

        UMBA_CHECK( testTable.checkRegUpdate( rwMin ) == false );

        return 0;
    }

    UMBA_TEST("Write 8-bit rw value multiple times - Update should be set and then cleared")
    {
        for(uint16_t i=0; i<300; i++)
        {
            testTable.setRegVal( rwMin, 0x77 );
            UMBA_CHECK( testTable.checkRegUpdate( rwMin ) == true );
            UMBA_CHECK( testTable.checkRegUpdate( rwMin ) == false );
        }

        return 0;
    }

    UMBA_TEST("Write 16-bit ro value - Should be correct")
    {
        testTable.setReg16Val( roMin, 0x1234 );

        UMBA_CHECK( testTable.getReg16Val(roMin) == 0x1234 );

        UMBA_CHECK( testTable.checkReg16Update(roMin) == true );
        UMBA_CHECK( testTable.checkReg16Update(roMin) == false, "Update should be cleared" );

        UMBA_CHECK( testTable.getRegVal( roMin + 0) == 0x34 );
        UMBA_CHECK( testTable.getRegVal( roMin + 1) == 0x12 );

        return 0;
    }

    UMBA_TEST("Write 32-bit ro value - Should be correct")
    {
        testTable.setReg32Val( roMin, 0x12345678 );

        UMBA_CHECK( testTable.getReg32Val(roMin) == 0x12345678 );

        UMBA_CHECK( testTable.checkReg32Update(roMin) == true );
        UMBA_CHECK( testTable.checkReg32Update(roMin) == false, "Update should be cleared" );

        UMBA_CHECK( testTable.getRegVal( roMin + 0) == 0x78 );
        UMBA_CHECK( testTable.getRegVal( roMin + 1) == 0x56 );
        UMBA_CHECK( testTable.getRegVal( roMin + 2) == 0x34 );
        UMBA_CHECK( testTable.getRegVal( roMin + 3) == 0x12 );

        return 0;
    }

    UMBA_TEST("Write 16-bit rw value - Should be correct")
    {
        testTable.setReg16Val( rwMin, 0x1234 );

        UMBA_CHECK( testTable.checkReg16Update(rwMin) == true );
        UMBA_CHECK( testTable.checkReg16Update(rwMin) == false, "Update should be cleared" );

        UMBA_CHECK( testTable.getReg16Val(rwMin) == 0x1234 );

        UMBA_CHECK( testTable.getRegVal( rwMin + 0) == 0x34 );
        UMBA_CHECK( testTable.getRegVal( rwMin + 1) == 0x12 );

        return 0;
    }

    UMBA_TEST("Write 32-bit rw value - Should be correct")
    {
        testTable.setReg32Val( rwMin, 0x12345678 );

        UMBA_CHECK( testTable.getReg32Val(rwMin) == 0x12345678 );

        UMBA_CHECK( testTable.checkReg32Update(rwMin) == true );
        UMBA_CHECK( testTable.checkReg32Update(rwMin) == false, "Update should be cleared" );

        UMBA_CHECK( testTable.getRegVal( rwMin + 0) == 0x78 );
        UMBA_CHECK( testTable.getRegVal( rwMin + 1) == 0x56 );
        UMBA_CHECK( testTable.getRegVal( rwMin + 2) == 0x34 );
        UMBA_CHECK( testTable.getRegVal( rwMin + 3) == 0x12 );

        return 0;
    }

    UMBA_TEST("Write single byte in 16bit rw reg - should not be updated")
    {
        testTable.setRegVal( rwMin, 0x77 );

        UMBA_CHECK( testTable.checkReg16Update(rwMin) == false );

        return 0;
    }

    UMBA_TEST("Write single byte in 16bit ro reg - should not be updated")
    {
        testTable.setRegVal( roMin, 0x77 );

        UMBA_CHECK( testTable.checkReg16Update(rwMin) == false );

        return 0;
    }


    UMBA_TEST("Write single byte in 32bit rw reg - should not be updated")
    {
        testTable.setRegVal( roMin, 0x77 );

        UMBA_CHECK( testTable.checkReg32Update(rwMin) == false );

        return 0;

    }

    UMBA_TEST("Write 16bit rw reg in two steps - should be updated")
    {
        testTable.setRegVal( rwMin, 0x77 );

        UMBA_CHECK( testTable.checkReg16Update(rwMin) == false );

        testTable.setRegVal( rwMin+1, 0x88 );

        UMBA_CHECK( testTable.checkReg16Update(rwMin) == true );

        UMBA_CHECK( testTable.getReg16Val(rwMin) == 0x8877 );

        return 0;
    }

    UMBA_TEST("Check 16bit rw reg - updateness should be cleared")
    {
        testTable.setReg16Val( rwMin, 0xAABB );

        UMBA_CHECK( testTable.checkReg16Update(rwMin) == true );

        UMBA_CHECK( testTable.checkReg16Update(rwMin) == false );

        UMBA_CHECK( testTable.getReg16Val(rwMin) == 0xAABB );

        return 0;
    }

    UMBA_TEST("Check 32bit rw reg - updateness should be cleared")
    {
        testTable.setReg32Val( rwMin, 0x12345678 );

        UMBA_CHECK( testTable.checkReg32Update(rwMin) == true );

        UMBA_CHECK( testTable.checkReg32Update(rwMin) == false );

        UMBA_CHECK( testTable.getReg32Val(rwMin) == 0x12345678 );

        return 0;
    }

    UMBA_TEST("Write 32bit rw value in four steps - should be updated")
    {
        testTable.setRegVal( rwMin, 0x77 );

        UMBA_CHECK( testTable.checkReg32Update(rwMin) == false );

        testTable.setRegVal( rwMin+1, 0x88 );

        UMBA_CHECK( testTable.checkReg32Update(rwMin) == false );

        testTable.setRegVal( rwMin+2, 0x99 );

        UMBA_CHECK( testTable.checkReg32Update(rwMin) == false );

        testTable.setRegVal( rwMin+3, 0xAA );

        UMBA_CHECK( testTable.checkReg32Update(rwMin) == true );

        UMBA_CHECK( testTable.getReg32Val(rwMin) == 0xAA998877 );

        return 0;
    }

} // anonymous namespace

#endif
