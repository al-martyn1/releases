#include "project_config.h"

#ifdef USE_TESTS

#include "umba_cpp_test/umba_cpp_tests.h"
#include "milliganjubus_slave_session.h"
#include "uart/uart_handle_mock.h"
#include "milliganjubus_simple_reg_table.h"
#include "registers/milli_reg_numbers.h"



namespace
{

    using namespace milliganjubus;

    UMBA_TEST_GROUP("Milliganjubus Slave Session")


    /***************************************************************************************************
                                           Объекты для тестов
    ***************************************************************************************************/

    SlaveSession testSlaveSession;

    /***************************************************************************************************
                                                 Моки
    ***************************************************************************************************/

    const uint32_t mock_ro_min = 10;
    const uint32_t mock_ro_max = 25;

    const uint32_t mock_rw_min = 0x90;
    const uint32_t mock_rw_max = 0xA0;

    SimpleRegTable< mock_ro_min, mock_ro_max, mock_rw_min, mock_rw_max > mockRegTable;


    const uint8_t testSlaveAdr = 0x66;

    const uint32_t connection_lost_timeout = 10;

    struct MockCallbacks
    {
        MockCallbacks() :
            m_connectionLost(false),
            m_connectionRestored(false),
            m_msgReceived(false)
        {}

        void onConnectionLost(void)
        {
            m_connectionLost = true;
        }

        void onConnectionRestored(void)
        {
            m_connectionRestored = true;
        }

        void onMsgReceived(void)
        {
            m_msgReceived = true;
        }

        bool m_connectionLost;
        bool m_connectionRestored;
        bool m_msgReceived;

    };

    MockCallbacks mockCallbacks;

    uart::UartHandleMock uartMock;


    /***************************************************************************************************
                                           Тестовые данные
    ***************************************************************************************************/

    static uint8_t correct_request_write_series[] = { 0xBB, testSlaveAdr, 0x0A, 0x0F, 0x03, 0x90, 0x01, 0x91, 0x02, 0x10 };

    static uint8_t correct_request_universal_adr_write_series[] =
    { 0xBB, MILLI_GANJUBUS_MSG_ADR_UNIVERSAL, 0x0A, 0x81, 0x03, 0x90, 0x01, 0x91, 0x02, 0x10 };

    static uint8_t correct_request_broadcast_write_series[] =
    { 0xBB, MILLI_GANJUBUS_MSG_ADR_BROADCAST, 0x0A, 0x00, 0x03, 0x90, 0x01, 0x91, 0x02, 0x10 };

    /***************************************************************************************************
                                          Вспомогательные функции
    ***************************************************************************************************/

    UMBA_TEST_SETUP()
    {
        #ifdef UART_USE_FREERTOS
            osSemaphoreGive( uartMock.getOwnerMutex() );
        #endif

        testSlaveSession.init( uartMock,
                               testSlaveAdr,
                               mockRegTable,
                               CALLBACK_BIND(mockCallbacks, MockCallbacks::onConnectionLost),
                               CALLBACK_BIND(mockCallbacks, MockCallbacks::onConnectionRestored),
                               connection_lost_timeout,
                               CALLBACK_BIND(mockCallbacks, MockCallbacks::onMsgReceived) );
    }

    UMBA_TEST_TEARDOWN()
    {
        uartMock.flush();

        // сбрасываем состояния объектов с помощью явного вызова конструктора
        {
            MockCallbacks * p = &mockCallbacks;
            p = new (p) MockCallbacks;
        }

        {
            SimpleRegTable< mock_ro_min, mock_ro_max, mock_rw_min, mock_rw_max > * p = &mockRegTable;
            p = new (p) SimpleRegTable< mock_ro_min, mock_ro_max, mock_rw_min, mock_rw_max >;
        }

        {
            SlaveSession * p = &testSlaveSession;
            p = new (p) SlaveSession;

        }
    }

    static void work( uint32_t time )
    {
        #ifdef UART_USE_FREERTOS
            osSemaphoreGive( uartMock.m_transmitCompleteSem );
        #endif
        testSlaveSession.work(time);
    }


    /***************************************************************************************************
                                                    Тесты
    ***************************************************************************************************/

    UMBA_TEST("Send correct request - get correct answer")
    {
        uartMock.receiveData( correct_request_write_series, NUM_ELEM(correct_request_write_series) );

        work(0);
        work(0);
        work(0);
        work(0);

        UMBA_CHECK( mockCallbacks.m_msgReceived == true, "Msg should be received" );

        uint8_t * ans = uartMock.m_txLocalArray;

        static const uint8_t expected_answer[] = {0xbb, testSlaveAdr, 0x08, 0x6D, 0xA3, 0x90, 0x91, 0x23 };

        UMBA_CHECK( std::equal(expected_answer, expected_answer + NUM_ELEM(expected_answer), ans),
                    "Answer should be correct" );

        UMBA_CHECK( mockCallbacks.m_connectionRestored == true, "Connection should be restored" );

        return 0;

    }

    UMBA_TEST("Send correct broadcast address request - get no answer")
    {
        uartMock.receiveData( correct_request_broadcast_write_series,
                              NUM_ELEM(correct_request_broadcast_write_series) );

        work(0);
        work(0);
        work(0);
        work(0);

        UMBA_CHECK( mockCallbacks.m_msgReceived == true, "Msg should be received" );

        UMBA_CHECK( uartMock.m_txLocalArrayUsedSize == 0, "No answer should be sent");

        UMBA_CHECK( mockCallbacks.m_connectionRestored == true, "Connection should be restored" );

        return 0;
    }

    UMBA_TEST("Send correct universal address request - get correct answer")
    {
        uartMock.receiveData( correct_request_universal_adr_write_series,
                              NUM_ELEM(correct_request_universal_adr_write_series) );

        work(0);
        work(0);
        work(0);
        work(0);

        UMBA_CHECK( mockCallbacks.m_msgReceived == true, "Msg should be received" );

        uint8_t * ans = uartMock.m_txLocalArray;

        static const uint8_t expected_answer[] = {0xbb, testSlaveAdr, 0x08, 0x6D, 0xA3, 0x90, 0x91, 0x23 };

        UMBA_CHECK( std::equal(expected_answer, expected_answer + NUM_ELEM(expected_answer), ans),
                    "Answer should be correct" );

        UMBA_CHECK( mockCallbacks.m_connectionRestored == true, "Connection should be restored" );

        return 0;
    }



    UMBA_TEST("Send nothing - onConnectionLost is called eventually")
    {
        mockCallbacks.m_connectionLost = false;

        uartMock.receiveData( correct_request_write_series, NUM_ELEM(correct_request_write_series) );
        work(0);
        
        UMBA_CHECK( mockCallbacks.m_connectionRestored == true, "Connection should be restored" );
        
        work(connection_lost_timeout);
        work(connection_lost_timeout+1);
        work(connection_lost_timeout+2);

        UMBA_CHECK( mockCallbacks.m_connectionLost == true, "Connection should be lost" );

        return 0;
    }

    UMBA_TEST("Send garbage - onConnectionLost is called eventually")
    {
        mockCallbacks.m_connectionLost = false;

        // сначала связь появилась
        uartMock.receiveData( correct_request_write_series, NUM_ELEM(correct_request_write_series) );
        work(0);
        
        UMBA_CHECK( mockCallbacks.m_connectionRestored == true, "Connection should be restored" );

        // а потом пошел мусор
        uint8_t buf[10] = {0};
        for( uint8_t i=0; i<NUM_ELEM(buf); i++)
        {
            buf[i] = common_functions::xorshiftRandomByte();
        }

        uartMock.receiveData( buf, NUM_ELEM(buf) );

        work(0);
        work(connection_lost_timeout);
        work(connection_lost_timeout+1);
        work(connection_lost_timeout+2);

        UMBA_CHECK( mockCallbacks.m_connectionLost == true, "Connection should be lost" );

        return 0;
    }

} // anonymous namespace

#endif
