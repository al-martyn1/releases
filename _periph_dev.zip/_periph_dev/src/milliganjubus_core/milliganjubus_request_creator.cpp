#include "milliganjubus_request_creator.h"

namespace milliganjubus
{
    void RequestCreator :: createWriteReg(MilliMessage & request, uint8_t regNum, uint8_t val)
    {
        uint8_t * buf = request.buf + MILLI_GANJUBUS_TX_MSG_DATA_OFFSET;

        // положим в сообщение гбайт, номер регистра и значение
        buf[0] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        buf[1] = regNum;
        buf[2] = val;

        // размер данных - gByte, регистр и значение
        uint8_t dataSize = 3;

        tx_messages::wrapMsg( request.buf, dataSize, m_deviceAddress );
    }

    void RequestCreator :: createWriteRange(MilliMessage & request, uint8_t startReg, uint8_t endReg, const uint8_t * values)
    {
        uint8_t * buf = request.buf + MILLI_GANJUBUS_TX_MSG_DATA_OFFSET;

        UMBA_ASSERT( endReg >= startReg );

        // в сообщении может лежать 8 значений, а диапазон от начала до конца включительно
        UMBA_ASSERT( endReg - startReg < MILLI_GANJUBUS_RANGE_LENGTH_MAX);

        // положим в сообщение гбайт, номер регистра и значение
        buf[0] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;
        buf[1] = startReg;
        buf[2] = endReg;

        uint8_t regsNum = endReg-startReg + 1;

        for(uint8_t i=0; i< regsNum; i++)
        {
            buf[3+i] = values[i];
        }

        // размер данных - gByte, два регистра и диапазон
        uint8_t dataSize = 1+2+regsNum;

        tx_messages::wrapMsg( request.buf, dataSize, m_deviceAddress );
    }

    void RequestCreator :: createWriteSeries(MilliMessage & request, const Register * series, uint8_t len)
    {
        // в миллиганджубусное сообщение влезает серия из четырех регистров максимум
        UMBA_ASSERT(len <= MILLI_GANJUBUS_SERIES_LENGTH_MAX);

        UMBA_ASSERT( (len*2 + MILLI_GANJUBUS_TX_MSG_SERVICE_FIELDS_SIZE ) <= MILLI_GANJUBUS_MESSAGE_SIZE_MAX );

        uint8_t * buf = request.buf + MILLI_GANJUBUS_TX_MSG_DATA_OFFSET;

        // положим в сообщение гбайт, номер регистра и значение
        buf[0] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;

        uint8_t j = 1;
        for(uint8_t i=0; i<len; ++i, j+=2)
        {
            buf[j] = series[i].num;
            buf[j+1] = series[i].val;
        }

        // размер данных - gByte и len пар "регистр-значение"
        uint8_t dataSize = 1+len*2;

        tx_messages::wrapMsg( request.buf, dataSize, m_deviceAddress );
    }

    void RequestCreator :: createReadReg(MilliMessage & request, uint8_t regNum)
    {
        uint8_t * buf = request.buf + MILLI_GANJUBUS_TX_MSG_DATA_OFFSET;

        // положим в сообщение гбайт и номер регистра
        buf[0] = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;
        buf[1] = regNum;

        // размер данных - gByte и регистр
        uint8_t dataSize = 2;

        tx_messages::wrapMsg( request.buf, dataSize, m_deviceAddress );
    }

    void RequestCreator :: createReadRange(MilliMessage & request, uint8_t regNumBegin, uint8_t regNumEnd)
    {
        // в сообщении может лежать 8 значений, а диапазон от начала до конца включительно
        UMBA_ASSERT( regNumEnd - regNumBegin < MILLI_GANJUBUS_RANGE_LENGTH_MAX);

        UMBA_ASSERT( regNumEnd >= regNumBegin );

        uint8_t * buf = request.buf + MILLI_GANJUBUS_TX_MSG_DATA_OFFSET;

        // положим в сообщение гбайт, номер начала диапазона, номер конца диапазона
        buf[0] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;
        buf[1] = regNumBegin;
        buf[2] = regNumEnd;

        // размер данных - gByte и два регистра
        uint8_t dataSize = 3;

        tx_messages::wrapMsg( request.buf, dataSize, m_deviceAddress );
    }

    void RequestCreator :: createReadSeries(MilliMessage & request, const Register * series, uint8_t len)
    {
        // в миллиганджубусное сообщение влезает серия из четырех регистров максимум
        UMBA_ASSERT(len <= MILLI_GANJUBUS_SERIES_LENGTH_MAX);

        UMBA_ASSERT( (len*2 + MILLI_GANJUBUS_TX_MSG_SERVICE_FIELDS_SIZE ) <= MILLI_GANJUBUS_MESSAGE_SIZE_MAX );

        uint8_t * buf = request.buf + MILLI_GANJUBUS_TX_MSG_DATA_OFFSET;

        // положим в сообщение гбайт, номер регистра и значение
        buf[0] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;

        buf++;

        for(uint8_t i=0; i<len; i++)
        {
            buf[i] = series[i].num;
        }

        // размер данных - gByte и len номеров регистров
        uint8_t dataSize = 1+len;

        tx_messages::wrapMsg( request.buf, dataSize, m_deviceAddress );
    }


} // namespace milliganjubus
