#include "milliganjubus_freertos_synchronizer_task.h"


#ifdef USE_FREERTOS

namespace milliganjubus
{
    void freeRtosSynchronizerTask(void * p)
    {
        SynchronizerParams * params = (SynchronizerParams *)(p);

        Synchronizer & synchronizer = *params->synchronizer;

        ISerialPort & port = *params->port;

        // создаем мастер-сессию
        MasterSession masterSession(params->answerTimeoutMs);

        // соединяем ее с синхронизатором

        MasterSession::OnAnswerReceived onValidAnswerReceived = CALLBACK_BIND( synchronizer, Synchronizer::onRelevantAnswerReceived );
        MasterSession::OnAnswerReceived onIrrelevantAnswerReceived = CALLBACK_BIND( synchronizer, Synchronizer::ignoreIrrelevantAnswer );
        callback::VoidCallback onConnectionFailure = CALLBACK_BIND( synchronizer, Synchronizer::onConnectionFailure );

        masterSession.init(port, onValidAnswerReceived, onConnectionFailure, onIrrelevantAnswerReceived);

        // соединяем синхронизатор с сессией
        Synchronizer::SendRequest sendRequest = CALLBACK_BIND( masterSession, MasterSession::sendRequest );
        synchronizer.init(sendRequest);

        while( OS_IS_RUNNING )
        {
            masterSession.work( osTaskGetTickCount() );
            synchronizer.work( osTaskGetTickCount() );

            osTaskYIELD();
        }


    }
}

#endif
