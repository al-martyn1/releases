#include "milliganjubus_slave_session.h"

namespace milliganjubus
{

    void SlaveSession :: init(ISerialPort & port,
                              uint8_t slaveAdr,
                              milliganjubus::IMilliRegTable & table,
                              callback::VoidCallback lostLinkHandler,
                              callback::VoidCallback restoredLinkHandler,
                              uint32_t lostLinkTimeout,
                              callback::VoidCallback onMessageReceived)
    {
        m_port = &port;

        // порт наш навечно
#ifdef UART_USE_FREERTOS
        BaseType_t result;
        result = osSemaphoreTake( m_port->getOwnerMutex(), 0 );

        // никто не смеет занимать порт ганджубуса!
        UMBA_ASSERT( result == pdTRUE );

#else
        UMBA_ASSERT( ! m_port->isLocked() );
        m_port->lock();
#endif

        m_request_timeout_max = lostLinkTimeout;

        m_onConnectionLost = lostLinkHandler;
        m_onConnectionRestored = restoredLinkHandler;

        m_onMessageReceived = onMessageReceived;

        UMBA_ASSERT(slaveAdr != MILLI_GANJUBUS_MSG_ADR_BROADCAST);
        UMBA_ASSERT(slaveAdr != MILLI_GANJUBUS_MSG_ADR_UNIVERSAL);

        m_slaveAdr = slaveAdr;

        // когда сообщение собрано - оно прилетит в сессию
        milliganjubus::MsgComposer::OnMsgComposed_cb onMsgComposed = CALLBACK_BIND( *this, SlaveSession::onRequestComposed );

        m_composer.initSlave( onMsgComposed, slaveAdr );

        m_ansCreator.init(slaveAdr);

        // привяжем таблицу к процессору
        m_reqProcessor.init(table, m_ansCreator);

    }


#ifndef UART_USE_FREERTOS

    void SlaveSession :: work(uint32_t curTime)
    {
        UMBA_ASSERT(m_port);

        switch( m_state )
        {
        case State::RECEIVE_REQUEST:

            m_lastCallTime = curTime;

            // собираем реквест
            while( m_port->isNewByte() )
            {
                m_composer.compose( m_port->getByte(), m_request );
            }

            // не потерялась ли связь?
            if(( m_lastCallTime - m_lastRequestTimestamp ) >= m_request_timeout_max )
            {
                if( m_isConnected )
                {
                    m_isConnected = false;

                    if( m_onConnectionLost )
                    {
                        m_onConnectionLost();
                    }
                }
            }

            if(! m_isRequestComposed )
            {
                return;
            }

            // нам что-то пришло

            if( m_onMessageReceived )
            {
                m_onMessageReceived();
            }

            // а связь была потеряна
            if( m_isConnected == false )
            {
                m_isConnected = true;

                if( m_onConnectionRestored )
                {
                    m_onConnectionRestored();
                }
            }

            m_isRequestComposed = false;

            // обрабатываем запрос и получаем ответ
            m_reqProcessor.parseRequest( m_request, m_answer );

            // на броадкасты ответ не нужен
            if( m_request.buf[ MILLI_GANJUBUS_RX_MSG_ADR_OFFSET] != MILLI_GANJUBUS_MSG_ADR_BROADCAST )
            {
                m_state = State::SEND_ANSWER;
            }

            break;

        case State::SEND_ANSWER:

            if( !m_port->isTransmitComplete() )
                break;

            // отправляем ответ
            bool result = m_port->sendLocalArray( m_answer.buf, milliganjubus::tx_messages::getMsgSize(m_answer.buf) );

            // ну воще невозможно чтобы не отправилось
            UMBA_ASSERT(result);

            m_state = State::RECEIVE_REQUEST;
            break;

        } // switch
    } // work

#endif

#ifdef UART_USE_FREERTOS


    // время костылей!
    static bool isNewByte( QueueHandle_t queue )
    {
        uint8_t byte = 0;

        // неблокирующе подглядываем
        BaseType_t result = osQueuePeek( queue, (void *)&byte, 0);

        return (result == pdTRUE);
    }

    void SlaveSession :: work(uint32_t curTime)
    {
        UMBA_ASSERT(m_port);

        m_lastCallTime = curTime;

        while( isNewByte(m_port->getQueue()) )
        {
            BaseType_t result;
            uint8_t byte;

            result = osQueueReceive( m_port->getQueue(), (void *)&byte, 0 );

            if( result == pdTRUE )
            {
                m_composer.compose( byte, m_request );
            }
            else
            {
                break;
            }
        }
            
        // не потерялась ли связь?
        if(( m_lastCallTime - m_lastRequestTimestamp ) >= m_request_timeout_max )
        {
            if( m_isConnected )
            {
                m_isConnected = false;

                if( m_onConnectionLost )
                {
                    m_onConnectionLost();
                }
            }
        }

        if(! m_isRequestComposed )
        {
            return;
        }

        // нам что-то пришло

        if( m_onMessageReceived )
        {
            m_onMessageReceived();
        }

        // а связь была потеряна
        if( m_isConnected == false )
        {
            m_isConnected = true;

            if( m_onConnectionRestored )
            {
                m_onConnectionRestored();
            }
        }

        m_isRequestComposed = false;

        // получаем ответ на реквест
        m_reqProcessor.parseRequest( m_request, m_answer );
        
        // на броадкасты ответ не нужен
        if( m_request.buf[ MILLI_GANJUBUS_RX_MSG_ADR_OFFSET] == MILLI_GANJUBUS_MSG_ADR_BROADCAST )
        {
            return;
        }

        BaseType_t res = osSemaphoreTake( m_port->getTransmitCompleteSem(), request_send_time_max/portTICK_PERIOD_MS );

        // ну уж за секунду-то должен был ответ отправиться!
        UMBA_ASSERT( res == pdTRUE );

        // отправляем ответ
        bool result = m_port->sendLocalArray( m_answer.buf, milliganjubus::tx_messages::getMsgSize(m_answer.buf) );

        // сейчас уарт совершенно железобетонно должен быть свободен от передачи
        UMBA_ASSERT(result);

    }

#endif

    void SlaveSession :: onRequestComposed( const milliganjubus::MilliMessage & msg )
    {
        // убираем ворнинг
        (void)msg;

        m_isRequestComposed = true;

        m_lastRequestTimestamp = m_lastCallTime;
    }

} // namespace
