#pragma once

#include "project_config.h"
#include "milliganjubus_common.h"
#include "milliganjubus_msg_composer.h"
#include "luart/i_serial_port.h"

namespace milliganjubus
{
    class MasterSession
    {

    public:

        explicit MasterSession(uint32_t answer_timeout_max, uint32_t request_sending_timeout_max = 10) :
            m_curCallTime(0),
            m_composer(),
            m_port(0),
            m_request(),
            m_answer(),
            m_lastRequestTime(0),
            m_answer_timeout_max( answer_timeout_max ),
            m_request_sending_timeout_max( request_sending_timeout_max ),
            m_repeatsCount(0),
            m_state(SessionStates::WAITING_REQUEST),
            m_onConnectionFailure(0),
            m_onAnswerReceived(0),
            m_onIrrelevantAnswer(0),
            m_isNewAnswer(false)
        {

        }

        typedef callback::Callback<void ( const milliganjubus::MilliMessage &)> OnAnswerReceived;

        void init(ISerialPort & port,
                  OnAnswerReceived onAnswerReceived,
                  callback::VoidCallback onConnectionFailure,
                  OnAnswerReceived onIrrelevantAnswerReceived = OnAnswerReceived() ); // этот параметр можно не задавать

        void sendRequest(milliganjubus::MilliMessage & request);

        void work(uint32_t curTime);

    protected:

        STRONG_ENUM(SessionStates, WAITING_REQUEST, SENDING_REQUEST, WAITING_FOR_SENDING_COMPLETE, WAITING_ANSWER);

        static const uint8_t m_repeats_max = 3;

        // копировать запрещено
        MasterSession( const MasterSession & rhs );
        MasterSession & operator=( MasterSession & s);

        bool isAnswerRelevant(void) const;

        bool isAnswerAdressValid(void) const;

        void onAnswerComposed( const milliganjubus::MilliMessage & answer);

        uint32_t m_curCallTime;

        milliganjubus::MsgComposer m_composer;

        ISerialPort * m_port;

        milliganjubus::MilliMessage m_request;
        milliganjubus::MilliMessage m_answer;

        uint32_t m_lastRequestTime;

        const uint32_t m_answer_timeout_max;
        const uint32_t m_request_sending_timeout_max;

        uint8_t m_repeatsCount;

        SessionStates m_state;

        callback::VoidCallback m_onConnectionFailure;
        OnAnswerReceived m_onAnswerReceived;
        OnAnswerReceived m_onIrrelevantAnswer;


        bool m_isNewAnswer;
    };

} // namespace milliganjubus
