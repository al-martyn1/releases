#include "milliganjubus_library_export.h"
#include "uart/i_serial_port.h"
#include "milliganjubus_dynamic_reg_table.h"
#include "milliganjubus_slave_session.h"

using namespace milliganjubus;


class Connector : public ISerialPort
{
public:

    Connector() : 
        isNewByteCallback(0),
        getByteCallback(0),
        sendArrayCallback(0)
    {}

    void init
    (
        MilliGanjubusSlave_isNewByte_cb isNewByte_cb,
        MilliGanjubusSlave_getByte_cb getByte_cb,
        MilliGanjubusSlave_sendArray_cb sendArray_cb
    )
    {
        isNewByteCallback = isNewByte_cb;
        getByteCallback = getByte_cb;
        sendArrayCallback = sendArray_cb;
    }

    virtual void changeBaudrate(uint32_t baudrate) { }

    virtual void reset(void) { }

    virtual void enableReceiver(void) { }
    virtual void disableReceiver(void) { }

    // методы для приема без использования freeRTOS
    virtual bool isNewByte(void) 
    { 
        UMBA_ASSERT(isNewByteCallback);

        return isNewByteCallback();
    }

    virtual uint8_t getByte(void) 
    { 
        UMBA_ASSERT(getByteCallback);

        return getByteCallback();
    }

    // "мьютекс" на владение
    virtual bool isLocked(void) { return false; }
    virtual void lock(void) { }
    virtual void unLock(void) { }

    virtual bool sendStaticArray(const volatile uint8_t * staticArr, uint32_t size) 
    { 
        UMBA_ASSERT(sendArrayCallback);
        sendArrayCallback( (uint8_t *)staticArr, size);
        return true;

    }

    virtual bool sendLocalArray(const uint8_t * localArr, uint32_t size) 
    {
        UMBA_ASSERT(sendArrayCallback);
        sendArrayCallback((uint8_t *)localArr, size);
        return true;

    }

    virtual bool isTransmitComplete(void) { return true; }

    // произошло ли переполнение приемного буфера
    virtual bool isReceiverOverrun(void) { return false; }

    // получить код ошибки - возвращает cpu-specific набор флагов ошибок
    virtual uint32_t getError(void) { return 0;  }

private:

    MilliGanjubusSlave_isNewByte_cb isNewByteCallback;
    MilliGanjubusSlave_getByte_cb getByteCallback;
    MilliGanjubusSlave_sendArray_cb sendArrayCallback;
};

struct MilliGanjubusSlave
{
    MilliGanjubusSlave
    ( 
        uint8_t roRegMin,
        uint8_t roRegMax,
        uint8_t rwRegMin,
        uint8_t rwRegMax 
    ) :
        connector(),
        table
        (
            roRegMin,
            roRegMax,
            rwRegMin,
            rwRegMax
        ),
        session(),
        lostLinkHandler_cb(0),
        restoredLinkHandler_cb(0),
        onMessageReceived_cb(0)
    {}

    // эти обертки нужны из-за особенностей создания коллбэков
    // адрес функции должен быть constant expression
    void lostLinkHandler(void)
    {
        lostLinkHandler_cb();
    }

    void restoredLinkHandler(void)
    {
        restoredLinkHandler_cb();
    }

    void onMessageReceived(void)
    {
        onMessageReceived_cb();
    }

    Connector connector;

    DynamicRegTable table;

    SlaveSession session;

    MilliGanjubusSlave_voidCallback lostLinkHandler_cb;
    MilliGanjubusSlave_voidCallback restoredLinkHandler_cb;
    MilliGanjubusSlave_voidCallback onMessageReceived_cb;
};



extern "C"
{
    MilliGanjubusSlave * MilliGanjubusSlave_createInstance
    (
        MilliGanjubusSlave_TableParams * tableParams,

        uint8_t slaveAdr,
        uint32_t lostLinkTimeout,

        MilliGanjubusSlave_RequiredCallbacks * requiredCallbacks,
        MilliGanjubusSlave_OptionalCallbacks * optionalCallbacks
    )
    {
        MilliGanjubusSlave * instance = new MilliGanjubusSlave
        (
            tableParams->roRegMin, 
            tableParams->roRegMax,
            tableParams->rwRegMin,
            tableParams->rwRegMax
        );

        instance->lostLinkHandler_cb = optionalCallbacks->lostLinkHandler;
        instance->restoredLinkHandler_cb = optionalCallbacks->restoredLinkHandler;
        instance->onMessageReceived_cb = optionalCallbacks->onMessageReceived;

        instance->connector.init(requiredCallbacks->isNewByte_cb, requiredCallbacks->getByte_cb, requiredCallbacks->sendArray_cb);

        instance->session.init
        (
            instance->connector,
            slaveAdr,
            instance->table,

            CALLBACK_BIND(*instance, MilliGanjubusSlave::lostLinkHandler ),
            CALLBACK_BIND(*instance, MilliGanjubusSlave::restoredLinkHandler),

            lostLinkTimeout,

            CALLBACK_BIND(*instance, MilliGanjubusSlave::onMessageReceived)

        );


        return instance;
    }

    void MilliGanjubusSlave_deleteInstance(MilliGanjubusSlave * self)
    {
        delete self;
    }

    void MilliGanjubusSlave_work(MilliGanjubusSlave * self, uint32_t curTime)
    {
        self->session.work(curTime);
    }

    void MilliGanjubusSlave_setRegVal(MilliGanjubusSlave * self, uint8_t regNum, uint8_t val)
    {
        self->table.setRegVal(regNum, val);

    }

    uint8_t MilliGanjubusSlave_getRegVal(MilliGanjubusSlave * self, uint8_t regNum)
    {
        return self->table.getRegVal(regNum);
    }

    bool MilliGanjubusSlave_checkRegUpdate(MilliGanjubusSlave * self, uint8_t regNum)
    {
        return self->table.checkRegUpdate(regNum);
    }
     
    void MilliGanjubusSlave_setReg16Val(MilliGanjubusSlave * self, uint8_t lowRegNum, uint16_t val)
    {
        self->table.setReg16Val(lowRegNum, val);
    }

    uint16_t MilliGanjubusSlave_getReg16Val(MilliGanjubusSlave * self, uint8_t lowRegNum)
    {
        return self->table.getReg16Val(lowRegNum);
    }

    bool MilliGanjubusSlave_checkReg16Update(MilliGanjubusSlave * self, uint8_t lowRegNum)
    {
        return self->table.checkReg16Update(lowRegNum);
    }

    // счетверенные регистры и четырехбайтные значения
    void MilliGanjubusSlave_setReg32Val(MilliGanjubusSlave * self, uint8_t lowRegNum, uint32_t val)
    {
        self->table.setReg32Val(lowRegNum, val);
    }

    uint32_t MilliGanjubusSlave_getReg32Val(MilliGanjubusSlave * self, uint8_t lowRegNum)
    {
        return self->table.getReg16Val(lowRegNum);
    }

    bool MilliGanjubusSlave_checkReg32Update(MilliGanjubusSlave * self, uint8_t lowRegNum)
    {
        return self->table.checkReg32Update(lowRegNum);
    }

}
