#pragma once

#include "milliganjubus_common.h"
#include "milliganjubus_i_milli_reg_table.h"
#include "milliganjubus_ans_processor.h"
#include "milliganjubus_request_creator.h"

namespace milliganjubus
{

    class Slave
    {

    public:

        Slave() :
            m_masterTable(0),
            m_ansProc(),
            m_reqCreator(),
            m_slaveAdr(0),
            m_roUpdateInterval(500),
            m_lastRoUpdateTime(0),
            m_isConnected(false),
            m_roPart(0),
            m_connectionFailuresCount(0),
            // чтобы первое обновление было корректным
            m_roBeginReg(0xFF),
            m_roEndreg(0xFF)
        {

        }

        virtual ~Slave()
        {}

        // что именно с чем синхронизировать - определит потомок
        virtual void synchronize() = 0;

        // таблицу тоже создает потомок
        virtual IMilliRegTable * getSlaveTable() = 0;

        virtual void init(IMilliRegTable & masterTable, uint8_t devAddr, uint32_t roUpdateInterval)
        {
            m_masterTable = &masterTable;
            m_ansProc.init( *getSlaveTable() );
            m_reqCreator.init(devAddr);

            m_slaveAdr = devAddr;
            m_roUpdateInterval = roUpdateInterval;
        }

        void processAnswer( const MilliMessage & answer)
        {
            m_ansProc.processAnswer(answer);
        }

        bool isRwUpdateRequired(void)
        {
            if( getSlaveTable()->getReadyToSendRwRegsTotal() != 0)
                return true;
            else
                return false;
        }

        bool isRoUpdateRequired(uint32_t curTime) const
        {
            if(curTime - m_lastRoUpdateTime > m_roUpdateInterval)
                return true;
            else
                return false;
        }

        void getRwRequest(MilliMessage & req)
        {
            uint32_t readyToSendNum = getSlaveTable()->getReadyToSendRwRegsTotal();

            if (readyToSendNum == 0)
            {
                UMBA_ASSERT_FAIL();
            }

            // изменился один регистр
            if (readyToSendNum == 1)
            {
                // отправляем один регистр
                uint8_t regNum = getSlaveTable()->getReadyToSendRwReg();

                m_reqCreator.createWriteReg(req, regNum, getSlaveTable()->getRegVal(regNum) );

                return;
            }

            // надо набрать серию
            milliganjubus::RequestCreator::Register series[MILLI_GANJUBUS_SERIES_LENGTH_MAX];

            // максимальная длина сообщения ограничена
            if (readyToSendNum > MILLI_GANJUBUS_SERIES_LENGTH_MAX)
                readyToSendNum = MILLI_GANJUBUS_SERIES_LENGTH_MAX;

            for (uint8_t i = 0; i < readyToSendNum; ++i)
            {
                uint8_t regNum = getSlaveTable()->getReadyToSendRwReg();

                series[i].num = regNum;
                series[i].val = getSlaveTable()->getRegVal(regNum);
            }

            m_reqCreator.createWriteSeries(req, series, readyToSendNum );
        }

        void getRoRequest(MilliMessage & req, uint32_t curTime)
        {
            m_lastRoUpdateTime = curTime;

            // нужно обновить все регистры
            // они могут не влезть в один пакет миллиганджубуса, поэтому их нужно разбить на диапазоны

            // эти переменные разные для разных объектов этого класса
            // поэтому их  нельзя делать static
            const uint16_t min = getSlaveTable()->getRoMinRegNum();
            const uint16_t max = getSlaveTable()->getRoMaxRegNum();

            // типа шагаем диапазонами максимальной длины по всей таблице
            if( m_roEndreg >= max )
                m_roBeginReg = (uint8_t)min;
            else
                m_roBeginReg = m_roEndreg + 1;

            m_roEndreg = m_roBeginReg +  MILLI_GANJUBUS_RANGE_LENGTH_MAX - 1;

            // uint16 вроде не должен переполниться
            if( m_roEndreg > max)
                m_roEndreg = (uint8_t)max;

            for(uint16_t i=m_roBeginReg; i <= m_roEndreg; i++)
            {
                uint8_t len = getSlaveTable()->getRegLength( (uint8_t)i );

                if( len == 1)
                    continue;

                // многобайтный регистр должен помещаться в диапазон целиком
                if( m_roEndreg >= i + len - 1 )
                    continue;

                // или не входить туда вообще
                m_roEndreg = i-1;
                break;
            }

            UMBA_ASSERT( m_roBeginReg >= min && m_roBeginReg <= max );
            UMBA_ASSERT( m_roEndreg >= min && m_roEndreg <= max );

            m_reqCreator.createReadRange(req, m_roBeginReg, m_roEndreg);
        }

        void setConnectionState(bool state)
        {
            m_isConnected = state;

            if( state == false )
            {
                m_connectionFailuresCount++;
            }
            else
            {
                m_connectionFailuresCount = 0;
            }
        }

        virtual bool isConnected(void) const
        {
            return m_isConnected;
        }

        virtual uint32_t getConnectionFailures(void) const
        {
            return m_connectionFailuresCount;
        }

        uint8_t getAddress(void) const
        {
            return m_slaveAdr;
        }


    protected:

        // проброс значения из регистра мастера в регистр слейва
        // если мастерный регистр изменился
        void syncRwReg8(uint8_t masterReg, uint8_t slaveReg)
        {
            if( ! m_masterTable->checkRegUpdate( masterReg ) )
            {
                return;
            }

            uint8_t rwVal = m_masterTable->getRegVal(masterReg);

            getSlaveTable()->setRegVal( slaveReg, rwVal);
        }

        // проброс двухбайтного регистра, делает лок
        void syncRwReg16(uint8_t lowMasterReg, uint8_t lowSlaveReg)
        {
            if( ! m_masterTable->checkReg16Update(lowMasterReg) )
                return;

            uint16_t rwVal = m_masterTable->getReg16Val(lowMasterReg);
            getSlaveTable()->setReg16Val( lowSlaveReg, rwVal );
        }

        // проброс четырехбайтного регистра
        void syncRwReg32(uint8_t lowMasterReg, uint8_t lowSlaveReg)
        {
            if( ! m_masterTable->checkReg32Update(lowMasterReg) )
                return;

            uint32_t rwVal = m_masterTable->getReg32Val(lowMasterReg);
            getSlaveTable()->setReg32Val( lowSlaveReg, rwVal );
        }

        // проброс регистра из слейва в мастер
        void syncRoReg8(uint8_t masterReg, uint8_t slaveReg)
        {
            uint8_t roVal = getSlaveTable()->getRegVal(slaveReg);

            m_masterTable->setRegVal( masterReg, roVal );
        }

        // проброс 16-битного регистра из слейва в мастер, делает лок
        void syncRoReg16(uint8_t lowMasterReg, uint8_t lowSlaveReg)
        {
            if( ! getSlaveTable()->checkReg16Update(lowSlaveReg) )
                return;

            uint16_t roVal = getSlaveTable()->getReg16Val(lowSlaveReg);

            m_masterTable->setReg16Val( lowMasterReg, roVal );
        }

        // проброс 32-битного регистра из слейва в мастер, делает лок
        void syncRoReg32(uint8_t lowMasterReg, uint8_t lowSlaveReg)
        {
            if( ! getSlaveTable()->checkReg32Update(lowSlaveReg) )
                return;

            uint32_t roVal = getSlaveTable()->getReg32Val(lowSlaveReg);

            m_masterTable->setReg32Val( lowMasterReg, roVal );
        }

        IMilliRegTable * m_masterTable;

        AnswerProcessor m_ansProc;
        RequestCreator m_reqCreator;

        uint8_t m_slaveAdr;

        uint32_t m_roUpdateInterval;
        uint32_t m_lastRoUpdateTime;

        bool m_isConnected;

        uint16_t m_roPart;

        uint32_t m_connectionFailuresCount;

        uint8_t m_roBeginReg;
        uint8_t m_roEndreg;

    private:

        // копировать запрещено
        Slave( const Slave & rhs);
        Slave & operator=( Slave & s);

    };

} // namespace milliganjubus
