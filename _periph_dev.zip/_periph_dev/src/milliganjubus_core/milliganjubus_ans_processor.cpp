#include "milliganjubus_ans_processor.h"

namespace milliganjubus
{

    void AnswerProcessor :: init(IMilliRegTable & table, callback::VoidCallback onAnswerProcessed)
    {
        m_table = &table;
        this->m_onAnswerProcessed = onAnswerProcessed;

    }

    void AnswerProcessor :: processAnswer( const MilliMessage & answer )
    {
        uint8_t gByte = getMsgGbyte(answer);

        UMBA_ASSERT(m_table != 0);

        if( ! isGbyteAck(gByte) )
        {
            //UMBA_ASSERT_FAIL(); //NOTE: Какая-то беда случилась, пакетик побился
            return;
        }

        {
            // лочим таблицу, сейчас могут быть записи в потенциально многобайтные регистры
            IMilliRegTable::Lock lock(m_table);

            switch( getFcode(gByte) )
            {
            case MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG:
                writeSingleRegAns(answer);
                break;

            case MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE:
                writeRegsRangeAns(answer);
                break;

            case MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES:
                writeRegsSeriesAns(answer);
                break;

            case MILLI_GANJUBUS_FCODE_READ_SINGLE_REG:
                readSingleRegAns(answer);
                break;

            case MILLI_GANJUBUS_FCODE_READ_REGS_RANGE:
                readRegsRangeAns(answer);
                break;

            case MILLI_GANJUBUS_FCODE_READ_REGS_SERIES:
                readRegsSeriesAns(answer);
                break;

            default:
                UMBA_ASSERT_FAIL();
                break;
            }
        }

        if(m_onAnswerProcessed != 0)
        {
            m_onAnswerProcessed();
        }

    }


    void AnswerProcessor :: readSingleRegAns( const MilliMessage & answer )
    {
        const uint8_t * buf = getDataBuf(answer);

        // в буфере лежат номер регистра и его значение
        uint8_t regNum = buf[0];
        uint8_t val = buf[1];

        m_table->setRegVal(regNum, val);

    }

    void AnswerProcessor :: readRegsRangeAns( const MilliMessage & answer)
    {
        const uint8_t * buf = getDataBuf(answer);

        // в буфере лежат границы диапазона, а потом значения
        uint8_t rangeBegin = buf[0];
        uint8_t rangeEnd = buf[1];

        buf += 2;
        uint8_t i=0;

        for(uint8_t num=rangeBegin; num<=rangeEnd; ++num, ++i)
        {
            m_table->setRegVal(num, buf[i]);
        }

    }

    void AnswerProcessor ::readRegsSeriesAns( const MilliMessage & answer)
    {
        const uint8_t * buf = getDataBuf(answer);

        // в буфере лежат пары "номер регистра - значение"
        // соответственно регистров вдвое меньше, чем данных
        uint8_t size = getDataSize(answer);

        uint8_t regNum = 0;
        uint8_t val = 0;

        for(uint8_t i=0; i<size; i+=2)
        {
            regNum = buf[i];
            val = buf[i+1];
            m_table->setRegVal(regNum, val);
        }
    }

    void AnswerProcessor :: writeSingleRegAns( const MilliMessage & answer)
    {
        // внезапно ничего делать не надо
        (void)answer;
    }


    void AnswerProcessor :: writeRegsRangeAns( const MilliMessage & answer)
    {
        // внезапно ничего делать не надо
        (void)answer;
    }

    void AnswerProcessor:: writeRegsSeriesAns( const MilliMessage & answer)
    {
        // внезапно ничего делать не надо
        (void)answer;
    }

} // namespace milliganjubus

