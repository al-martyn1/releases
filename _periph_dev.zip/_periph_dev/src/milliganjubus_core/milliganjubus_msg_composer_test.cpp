#include "project_config.h"


#ifdef USE_TESTS

#include "umba_cpp_test/umba_cpp_tests.h"
#include "callbacks/callbacks.h"
#include "milliganjubus_msg_composer.h"
#include "common_functions/common_functions.h"



using namespace milliganjubus;

namespace
{

    UMBA_TEST_GROUP( "MilliGanjuComposer" )

    /***************************************************************************************************
                                           Тестовые данные
    ***************************************************************************************************/


    uint8_t correctMsgSize10[ 10 ] = {0xBB, 0x88, 0x0A, 0x14, 0x11, 0x22, 0x33, 0x77, 0x55, 0xD1};
    uint8_t correctMsgSize8[ 8 ] = {0xBB, 0x88, 0x08, 0x76, 0x11, 0x22, 0x33, 0x71};

    uint8_t correctMsgSize12[12] = { 0xBB, 0x88, 0x0C, 0xB2, 0xAB, 0xBA, 0xCC, 0xDD, 0xEE, 0xFF, 0x1A, 0x23};
    uint8_t correctMsgSize11_withStartInside[11] = {0xBB, 0x88, 0x0B, 0x25, 0xBB, 0xCC, 0xBB, 0x00, 0x01, 0x12, 0xCE};

    uint8_t correctMsgSize16_withCorrectHeadCrcInside[16] = {0xBB, 0x88, 0x10, 0x8C, 0xBB, 0xCC, 0xBB, 0x04, 0x08, 0xE1, 0x00, 0xBB, 0x88, 0x08, 0x76, 0xED};

    uint8_t msgSize10_wrongHeaderCrc[ 10 ] = {0xBB, 0x88, 0x0A, 0x13, 0x11, 0x22, 0x33, 0x77, 0x55, 0xD1};
    uint8_t msgSize10_wrongMsgCrc[ 10 ] = {0xBB, 0x88, 0x0A, 0x14, 0x11, 0x22, 0x33, 0x77, 0x55, 0x01};

    uint8_t correctMsgUniversalAddr[] = {0xBB, 0xFF, 0x0B, 0xB0, 0x66, 0x33, 0x99, 0x44, 0x55, 0x11, 0x39};
    uint8_t correctMsgBroadcastAddr[] = {0xBB, 0x00, 0x08, 0x62, 0x01, 0x83, 0x01, 0x79};
    uint8_t correctMsgIncorrectAddr[] = {0xBB, 0x99, 0x09, 0xDD, 0x11, 0x66, 0x00, 0x55, 0x06};


    /***************************************************************************************************
                                           Объекты для тестов
    ***************************************************************************************************/


    MsgComposer testSlaveComposer;
    MsgComposer testMasterComposer;


    /***************************************************************************************************
                                           Моки
    ***************************************************************************************************/


    struct MockComposing
    {
    public:

        MockComposing() :
            isComposedFlag(false),
            outMsg()
        {
            ;
        }


        bool isComposed(void)
        {
            // сбрасывает флаг при опросе, потому что задолбало его руками сбрасывать
            if( isComposedFlag == true)
            {
                isComposedFlag = false;
                return true;
            }

            return false;
        }

        void onMsgComposed( const MilliMessage & msg )
        {
            (void)msg;
            isComposedFlag = true;
        }

        bool isComposedFlag;

        MilliMessage outMsg;

    };

    static MockComposing mockComposing;


    /***************************************************************************************************
                                           Вспомогательные функции
    ***************************************************************************************************/

    UMBA_TEST_SETUP()
    {

        // коллбэк - сообщение собрано
        MsgComposer::OnMsgComposed_cb onMsgComposed_cb;

        onMsgComposed_cb = CALLBACK_BIND( mockComposing, MockComposing::onMsgComposed );

        // такой адрес для тестовых сообщений, от фонаря
        testSlaveComposer.initSlave(onMsgComposed_cb, 0x88);

        mockComposing.isComposedFlag = false;

    }

    UMBA_TEST_TEARDOWN()
    {
        std::fill(mockComposing.outMsg.buf, mockComposing.outMsg.buf + MILLI_GANJUBUS_MESSAGE_SIZE_MAX - 1, 0);
    }



    static void sendBufferToComposer(MsgComposer & composer, uint8_t * buf, uint8_t size)
    {
        for(uint8_t i=0; i<size; ++i)
        {
            composer.compose( buf[i], mockComposing.outMsg );
        }
    }

    static void sendMsgToComposer( MsgComposer & composer, uint8_t * msg)
    {
        sendBufferToComposer(composer, msg, rx_messages::getMsgSize(msg) );
    }

    static void sendGarbage(MsgComposer & composer, uint8_t size)
    {
        for(uint8_t i=0; i<size; ++i)
        {
            UMBA_ASSERT( mockComposing.isComposed() == false );

            composer.compose( common_functions::xorshiftRandomByte(), mockComposing.outMsg );
        }
    }



    /***************************************************************************************************
                                           ТЕСТЫ
    ***************************************************************************************************/



    UMBA_TEST("getMsgSize should get size from correct offset")
    {
        UMBA_CHECK( rx_messages::getMsgSize( correctMsgSize10 ) == 10, "Size should be equal to 10" );

        return 0;
    }

    UMBA_TEST( "Header CRC should be checked" )
    {
        UMBA_CHECK( rx_messages::isHeaderCrcValid( correctMsgSize10 ) == true, "Header crc should be valid");

        UMBA_CHECK( rx_messages::isHeaderCrcValid( msgSize10_wrongHeaderCrc ) == false, "Header crc should be invalid");

        return 0;
    }

    UMBA_TEST( "Message CRC should be checked" )
    {
        UMBA_CHECK(rx_messages::isMsgCrcValid( correctMsgSize10 ) == true, "Msg CRC should be valid");

        UMBA_CHECK( rx_messages::isMsgCrcValid( msgSize10_wrongMsgCrc ) == false, "Msg CRC should be invalid");

        return 0;
    }

    UMBA_TEST( "Valid message should be composed")
    {
        sendMsgToComposer(testSlaveComposer, correctMsgSize10);
        UMBA_CHECK( mockComposing.isComposed() == true, "Valid message should be composed");

        return 0;
    }

    UMBA_TEST( "Message with wrong CRC should not be composed" )
    {
        sendMsgToComposer(testSlaveComposer, msgSize10_wrongMsgCrc);
        UMBA_CHECK( mockComposing.isComposed() == false, "Msg crc is invalid, msg should not be composed");

        return 0;

    }

    UMBA_TEST( "Valid message after invalid should be composed" )
    {
        sendMsgToComposer(testSlaveComposer, msgSize10_wrongMsgCrc);
        UMBA_CHECK( mockComposing.isComposed() == false, "Msg crc is invalid, msg should not be composed");

        sendMsgToComposer(testSlaveComposer, correctMsgSize10);
        UMBA_CHECK( mockComposing.isComposed() == true, "Valid message should be composed");

        return 0;
    }

    UMBA_TEST( "Two valid messages should be composed" )
    {
        sendMsgToComposer(testSlaveComposer, correctMsgSize10);
        UMBA_CHECK( mockComposing.isComposed() == true, "Message is valid, should be composed");

        sendMsgToComposer(testSlaveComposer, correctMsgSize8);
        UMBA_CHECK( mockComposing.isComposed() == true, "Second message is valid, should be composed");

        return 0;
    }

    UMBA_TEST( "Three valid messages should be composed" )
    {
        sendMsgToComposer(testSlaveComposer, correctMsgSize10);
        UMBA_CHECK( mockComposing.isComposed() == true);

        sendMsgToComposer(testSlaveComposer, correctMsgSize8);
        UMBA_CHECK( mockComposing.isComposed() == true);

        sendMsgToComposer(testSlaveComposer, correctMsgSize10);
        UMBA_CHECK( mockComposing.isComposed() == true);

        return 0;
    }

    UMBA_TEST("Message with invalid header crc should not be composed")
    {
        sendMsgToComposer(testSlaveComposer, msgSize10_wrongHeaderCrc);
        UMBA_CHECK( mockComposing.isComposed() == false);

        return 0;
    }

    UMBA_TEST( "Valid message after msg with invalid header crc should be composed")
    {
        sendMsgToComposer(testSlaveComposer, msgSize10_wrongHeaderCrc);
        UMBA_CHECK( mockComposing.isComposed() == false);

        sendMsgToComposer(testSlaveComposer, correctMsgSize8);
        UMBA_CHECK( mockComposing.isComposed() == true);

        return 0;
    }

    UMBA_TEST("Valid message after a sequence of random bytes should be composed")
    {
        sendGarbage(testSlaveComposer, 246);
        UMBA_CHECK( mockComposing.isComposed() == false);

        sendMsgToComposer(testSlaveComposer, correctMsgSize8);
        UMBA_CHECK( mockComposing.isComposed() == true);

        return 0;

    }

    UMBA_TEST( "Random bytes between two valid message - valid messages should be composed")
    {
        sendMsgToComposer(testSlaveComposer, correctMsgSize10);
        UMBA_CHECK( mockComposing.isComposed() == true);

        sendGarbage(testSlaveComposer, 143);
        UMBA_CHECK( mockComposing.isComposed() == false);

        sendMsgToComposer(testSlaveComposer, correctMsgSize8);
        UMBA_CHECK( mockComposing.isComposed() == true);


        return 0;
    }

    UMBA_TEST( "Sequence of zeros is not composed" )
    {
        uint8_t zeroBuf[10] = {0};

        sendBufferToComposer(testSlaveComposer, zeroBuf, sizeof(zeroBuf) );
        UMBA_CHECK( mockComposing.isComposed() == false);

        return 0;
    }

    UMBA_TEST("Correct msg with universal address should be composed")
    {
        sendMsgToComposer(testSlaveComposer, correctMsgUniversalAddr );
        UMBA_CHECK( mockComposing.isComposed() == true);

        return 0;
    }

    UMBA_TEST("Correct msg with broadcast address should be composed")
    {
        sendMsgToComposer(testSlaveComposer, correctMsgBroadcastAddr );
        UMBA_CHECK( mockComposing.isComposed() == true);

        return 0;
    }

    UMBA_TEST("Correct msg with incorrect address should not be composed")
    {
        sendMsgToComposer(testSlaveComposer, correctMsgIncorrectAddr );
        UMBA_CHECK( mockComposing.isComposed() == false);

        return 0;
    }

    UMBA_TEST("Master composer should compose messages with any address")
    {
        {
            // коллбэк - сообщение собрано
            MsgComposer::OnMsgComposed_cb onMsgComposed_cb;

            onMsgComposed_cb = CALLBACK_BIND( mockComposing, MockComposing::onMsgComposed );

            testMasterComposer.initMaster( onMsgComposed_cb );
        }

        sendMsgToComposer(testMasterComposer, correctMsgSize10);
        UMBA_CHECK( mockComposing.isComposed() == true, "Address 0x88 should be fine");

        sendMsgToComposer(testMasterComposer, correctMsgSize8);
        UMBA_CHECK( mockComposing.isComposed() == true, "Size should not matter");

        sendMsgToComposer(testMasterComposer, correctMsgIncorrectAddr );
        UMBA_CHECK( mockComposing.isComposed() == true, "Address 0x99 should be fine too");

        sendMsgToComposer(testMasterComposer, correctMsgBroadcastAddr );
        UMBA_CHECK( mockComposing.isComposed() == true, "Broadcast should be fine");

        sendMsgToComposer(testMasterComposer, correctMsgUniversalAddr );
        UMBA_CHECK( mockComposing.isComposed() == true, "Universal address should be fine");

        return 0;
    }


    UMBA_TEST("Using different milliMessage doesn't affect correct composing")
    {
        // тут потребуется не стандартная отправка
        uint8_t size = sizeof(correctMsgSize10);

        for(uint8_t i=0; i<size; ++i)
        {
            testSlaveComposer.compose( correctMsgSize10[i], mockComposing.outMsg );
        }

        UMBA_CHECK( mockComposing.isComposed() == true);

        size = sizeof(correctMsgSize8);

        MilliMessage outMsg;

        for(uint8_t i=0; i<size; ++i)
        {
            testSlaveComposer.compose( correctMsgSize8[i], outMsg );
        }

        UMBA_CHECK( mockComposing.isComposed() == true, "Change of the milliMsg should not affect composing");

        return 0;
    }

    UMBA_TEST("Correct message after correct fragment should be composed")
    {
        // отправляем кусок правильного сообщения - хедер и пару байт
        sendBufferToComposer(testSlaveComposer, correctMsgSize10, MILLI_GANJUBUS_RX_MSG_HEADER_SIZE + 1);



        UMBA_CHECK( mockComposing.isComposed() == false);

        sendMsgToComposer(testSlaveComposer, correctMsgSize12);
        UMBA_CHECK( mockComposing.isComposed() == true, "Valid message should be composed no matter what!");

        return 0;
    }

    UMBA_TEST("Correct message after sequence of start-bytes should be composed")
    {
        for(uint8_t i=0; i<5; ++i)
        {
            testSlaveComposer.compose( rx_messages::correctStartByte, mockComposing.outMsg );
        }

        UMBA_CHECK( mockComposing.isComposed() == false);

        sendMsgToComposer(testSlaveComposer, correctMsgSize12);
        UMBA_CHECK( mockComposing.isComposed() == true, "Valid message should be composed no matter what!");

        return 0;
    }

    UMBA_TEST("Message with start-byte in data should be composed")
    {
        sendMsgToComposer(testSlaveComposer, correctMsgSize11_withStartInside);
        UMBA_CHECK( mockComposing.isComposed() == true, "Valid message should be composed no matter what!");

        return 0;
    }

    UMBA_TEST("Correct message after message with start-byte in data; should be composed")
    {
        sendBufferToComposer(testSlaveComposer, correctMsgSize11_withStartInside, 10);

        UMBA_CHECK( mockComposing.isComposed() == false);


        sendMsgToComposer(testSlaveComposer, correctMsgSize12);

        UMBA_CHECK( mockComposing.isComposed() == true, "Valid message should be composed no matter what!");

        return 0;
    }

    UMBA_TEST("Message with correct header crc in data; should be composed")
    {
        for(uint8_t i=0; i<16; ++i)
        {
            UMBA_CHECK( mockComposing.isComposed() == false);
            testSlaveComposer.compose( correctMsgSize16_withCorrectHeadCrcInside[i], mockComposing.outMsg );
        }

        UMBA_CHECK( mockComposing.isComposed() == true, "Valid message should be composed no matter what!");

        return 0;
    }

    UMBA_TEST("Message with correct header crc in data after fragment; should be composed")
    {
        sendBufferToComposer(testSlaveComposer, correctMsgSize11_withStartInside, 10);

        UMBA_CHECK( mockComposing.isComposed() == false);

        sendMsgToComposer(testSlaveComposer, correctMsgSize16_withCorrectHeadCrcInside);

        UMBA_CHECK( mockComposing.isComposed() == true, "Valid message should be composed no matter what!");

        return 0;
    }


} // anonymous namespace

#endif
