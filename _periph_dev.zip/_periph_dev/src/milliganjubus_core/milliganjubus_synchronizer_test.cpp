#include "project_config.h"

#ifdef USE_TESTS

#include "umba_cpp_test/umba_cpp_tests.h"

#include <limits>
#include "milliganjubus_synchronizer.h"
#include "milliganjubus_simple_reg_table.h"
#include "uart/uart_handle_mock.h"
#include "milliganjubus_slave_session.h"

using namespace milliganjubus;

namespace
{

    /***************************************************************************************************
                                           Тестовые данные
    ***************************************************************************************************/

    uint8_t testAdr = 0x22;
    uint32_t testRoInterval = 100;
    
    const uint32_t connection_failures_max = 3;

    /***************************************************************************************************
                                           Объекты для тестов
    ***************************************************************************************************/

// небольшой костылик, чтобы заюзать placement new и не мучится с деинициализацией

    milliganjubus::Synchronizer testSynchronizer_;
    milliganjubus::Synchronizer * testSynchronizer;

    /***************************************************************************************************
                                           Моки
    ***************************************************************************************************/

    const uint32_t mock_slave_ro_min = 0;
    const uint32_t mock_slave_ro_max = 25;

    const uint32_t mock_slave_rw_min = 0x80;
    const uint32_t mock_slave_rw_max = 0x90;


    const uint32_t mock_master_ro_min = 10;
    const uint32_t mock_master_ro_max = 35;

    const uint32_t mock_master_rw_min = 0x90;
    const uint32_t mock_master_rw_max = 0xA0;

    SimpleRegTable< mock_master_ro_min, mock_master_ro_max, mock_master_rw_min, mock_master_rw_max > mockMasterTable_;
    SimpleRegTable< mock_master_ro_min, mock_master_ro_max, mock_master_rw_min, mock_master_rw_max > * mockMasterTable;

    class MockSlave : public Slave
    {
    public:

        MockSlave() :
            m_shouldSync(false),
            deviceTable()
        {}

        virtual ~MockSlave() {}

        virtual void init(IMilliRegTable & masterTable, uint8_t devAddr, uint32_t roUpdateInterval)
        {
            Slave::init(masterTable, devAddr, roUpdateInterval);
        }

        virtual void synchronize(void)
        {
            if( m_shouldSync )
            {
                syncRwReg8( mock_master_rw_min,  mock_slave_rw_min);

                syncRwReg8( mock_master_rw_min + 1,  mock_slave_rw_min + 1);

                syncRwReg16( mock_master_rw_min + 2,  mock_slave_rw_min + 2);

                syncRwReg32( mock_master_rw_min + 4,  mock_slave_rw_min + 4);

                syncRoReg8( mock_master_ro_min, mock_slave_ro_min);

                syncRoReg16( mock_master_ro_min + 2, mock_slave_ro_min + 2);

                syncRoReg32( mock_master_ro_min + 4, mock_slave_ro_min + 4);
            }
        }

        virtual IMilliRegTable * getSlaveTable(void)
        {
            return &deviceTable;
        }

        void setShouldSync(bool state)
        {
            m_shouldSync = state;
        }

        bool m_shouldSync;

        SimpleRegTable< mock_slave_ro_min, mock_slave_ro_max,
                        mock_slave_rw_min, mock_slave_rw_max > deviceTable;
    };

    MockSlave mockSlave_;
    MockSlave * mockSlave;

    class MockCallbacks
    {
    public:

        MockCallbacks() :
            m_request(),
            m_wasSent(false)
        {}

        void sendRequest(MilliMessage & req)
        {
            m_request = req;
            m_wasSent = true;
        }

        void sendRequestAndFailConnection( MilliMessage & req )
        {
            m_request = req;
            m_wasSent = true;

            testSynchronizer->onConnectionFailure();

        }

        MilliMessage m_request;

        bool m_wasSent;
    };

    MockCallbacks mockCallbacks;









    /***************************************************************************************************
                                           Вспомогательные функции
    ***************************************************************************************************/


    UMBA_TEST_GROUP("Synchronizer")

    UMBA_TEST_SETUP()
    {
        testSynchronizer = &testSynchronizer_;
        mockSlave = &mockSlave_;
        mockMasterTable = &mockMasterTable_;

        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( mockCallbacks, MockCallbacks::sendRequest );
        testSynchronizer->init(sendRequest);

        mockSlave->init(*mockMasterTable, testAdr, std::numeric_limits<uint32_t>::max());
        mockSlave->setShouldSync(true);

        testSynchronizer->addSlave(*mockSlave);

        mockCallbacks.m_wasSent = 0;

    }

    UMBA_TEST_TEARDOWN()
    {
        // сбрасываем состояние объектов с помощью явного вызова конструктора

        testSynchronizer = new(testSynchronizer) milliganjubus::Synchronizer( connection_failures_max );

        mockMasterTable = new(mockMasterTable) SimpleRegTable< mock_master_ro_min, mock_master_ro_max, mock_master_rw_min, mock_master_rw_max >;

        mockSlave = new(mockSlave) MockSlave;

    }

// void printBuffer( uint8_t * buf, uint8_t size )
// {
//     printf("\n");
//     for(uint8_t i=0; i<size; i++)
//     {
//         printf("%02x ", buf[i]);
//     }
// }




    /***************************************************************************************************
                                           Тесты
    ***************************************************************************************************/



    /*
    ====================================================================================================
                                       Тесты про RW
    ====================================================================================================
    */



    UMBA_TEST("Single Rw Update Required - Request should be sent")
    {
        mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        // реквест должен писать нужное число в нужный регистр
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE] == mock_slave_rw_min);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 1] == 0x66);

        return 0;
    }

    UMBA_TEST("Multiple Rw Update Required - Request should be sent")
    {
        mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );
        mockMasterTable->setRegVal( mock_master_rw_min + 1, 0x77 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        // реквест должен писать нужное число в нужный регистр
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE] == mock_slave_rw_min);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 1] == 0x66);

        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 2] == mock_slave_rw_min+1);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 3] == 0x77);

        return 0;
    }

    UMBA_TEST("Single 16 bit Rw Update Required - Request should be sent")
    {
        mockMasterTable->setReg16Val( mock_master_rw_min + 2, 0x1234 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        // реквест должен писать нужное число в нужный регистр
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 0] == mock_slave_rw_min + 2);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 1] == 0x34);

        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 2] == mock_slave_rw_min + 3);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 3] == 0x12);

        return 0;
    }

    UMBA_TEST("One byte of 16 bit rw reg was updated - nothing should be sent")
    {
        mockMasterTable->setRegVal( mock_master_rw_min + 2, 0x34 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == false);

        return 0;
    }



    UMBA_TEST("Single 32 bit Rw Update Required - Request should be sent")
    {
        mockMasterTable->setReg32Val( mock_master_rw_min + 4, 0x11223344 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        // реквест должен писать нужное число в нужный регистр
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 0] == mock_slave_rw_min + 4);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 1] == 0x44);

        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 2] == mock_slave_rw_min + 5);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 3] == 0x33);

        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 4] == mock_slave_rw_min + 6);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 5] == 0x22);

        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 6] == mock_slave_rw_min + 7);
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 7] == 0x11);

        return 0;
    }

    UMBA_TEST("One byte of 32 bit rw reg was updated - nothing should be sent")
    {
        mockMasterTable->setRegVal( mock_master_rw_min + 4, 0x76 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == false);

        return 0;
    }


    UMBA_TEST("32 bit rw reg should be updated atomically")
    {

        // делаем вид, что ро-регистры надо обновлять почаще
        mockSlave->init(*mockMasterTable, testAdr, testRoInterval);

        // создаем полноценного поддельного слейва со своей личной таблицей

        SimpleRegTable< mock_slave_ro_min, mock_slave_ro_max,
                        mock_slave_rw_min, mock_slave_rw_max > deviceTable;

        milliganjubus::SlaveSession mockSlaveSession;
        uart::UartHandleMock uartMockSlave;
        mockSlaveSession.init(uartMockSlave, testAdr, deviceTable );


        milliganjubus::MasterSession masterSession(testRoInterval*10);
        uart::UartHandleMock uartMockMaster;

        {
            MasterSession::OnAnswerReceived onRelevantAnswerReceived =
                CALLBACK_BIND( *testSynchronizer, Synchronizer::onRelevantAnswerReceived );

            // при неверном ответе будет ассерт - вариант для проводных сетей
            MasterSession::OnAnswerReceived onIrrelevantAnswerReceived =
                CALLBACK_BIND( *testSynchronizer, Synchronizer::panicOnIrrelevantAnswerReceived );

            callback::VoidCallback onConnectionFailure = CALLBACK_BIND( *testSynchronizer, Synchronizer::onConnectionFailure );

            masterSession.init(uartMockMaster, onRelevantAnswerReceived, onConnectionFailure, onIrrelevantAnswerReceived);
        }

        Synchronizer::SendRequest sendRequest = CALLBACK_BIND( masterSession, MasterSession::sendRequest );

        testSynchronizer->init(sendRequest);


        // в серии максимум MILLI_GANJUBUS_SERIES_LENGTH_MAX регистров

        for( uint8_t i=0; i < MILLI_GANJUBUS_SERIES_LENGTH_MAX; i++ )
        {
            mockSlave->deviceTable.setRegVal( mock_slave_rw_min + i, 0x55 );
        }

        uint8_t testReg = mock_slave_rw_min + 3;

        // впихнем 32-битный регистр так, чтобы он заходил за эту границу
        mockSlave->deviceTable.setReg32Val( testReg, 0x11223344 );

        mockSlave->m_shouldSync = false;

        for( uint8_t i=1; i<4; i++)
        {
            testSynchronizer->work(testRoInterval*i + 1);
            testSynchronizer->work(testRoInterval*i + 1);
            testSynchronizer->work(testRoInterval*i + 1);

            masterSession.work(testRoInterval*i + 1);
            masterSession.work(testRoInterval*i + 1);
            masterSession.work(testRoInterval*i + 1);
            masterSession.work(testRoInterval*i + 1);

            // и вот пока запрос кидался - регистр типа успел измениться
            mockSlave->deviceTable.setReg32Val( testReg, 0x55667788 );


            // перекидываем запрос от мастера к слейву
            uartMockSlave.receiveData( (uint8_t *)uartMockMaster.m_txStaticArray, uartMockMaster.m_txStaticArraySize );

            //printBuffer( (uint8_t *)uartMockMaster.m_txStaticArray, uartMockMaster.m_txStaticArraySize );

            uartMockMaster.m_txStaticArraySize = 0;

            mockSlaveSession.work( testRoInterval*i + 1);
            mockSlaveSession.work( testRoInterval*i + 1);
            mockSlaveSession.work( testRoInterval*i + 1);
            mockSlaveSession.work( testRoInterval*i + 1);

            // перекидываем ответ от слейва к мастеру
            uartMockMaster.receiveData( uartMockSlave.m_txLocalArray, uartMockSlave.m_txLocalArrayUsedSize );

            //printBuffer( uartMockSlave.m_txLocalArray, uartMockSlave.m_txLocalArrayUsedSize );

            uartMockSlave.m_txLocalArrayUsedSize = 0;

            // обрабатываем ответ
            masterSession.work(testRoInterval*i + 1);

            if( deviceTable.checkReg32Update(testReg) )
            {
                UMBA_CHECK( mockSlave->getSlaveTable()->getReg32Val(testReg) == deviceTable.getReg32Val(testReg) );
            }

        }

        return 0;
    }




    /*
    ====================================================================================================
                                           Тесты про RO
    ====================================================================================================
    */





    UMBA_TEST("Single Ro Update - Should be equal")
    {
        mockMasterTable->setRegVal( mock_master_ro_min, 0x66 );
        mockSlave->getSlaveTable()->setRegVal( mock_slave_ro_min, 0x88 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getRegVal( mock_master_ro_min ) == 0x88 );

        return 0;
    }



    /*
    ----------------------------------------------------------------------------------------------------
                                          16 битные RO
    ----------------------------------------------------------------------------------------------------
    */




    UMBA_TEST("One byte of 16 bit ro reg was updated - nothing should happen")
    {
        mockMasterTable->setRegVal( mock_master_ro_min + 2, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 3, 0x77 );

        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 2, 0x34 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getReg16Val(mock_master_ro_min + 2) == 0x7777);

        return 0;
    }

    UMBA_TEST("All bytes of 16 bit ro reg were updated - should be synced")
    {
        mockMasterTable->setRegVal( mock_master_ro_min + 2, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 3, 0x77 );

        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 2, 0x34 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 3, 0x12 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getReg16Val(mock_master_ro_min + 2) == 0x1234);

        return 0;
    }

    UMBA_TEST("16 bit Ro Updated - Should be equal")
    {
        mockMasterTable->setReg16Val( mock_master_ro_min+2, 0x1122 );
        mockSlave->getSlaveTable()->setReg16Val( mock_slave_ro_min+2, 0x7788 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getReg16Val( mock_master_ro_min+2 ) == 0x7788 );

        return 0;
    }

    UMBA_TEST("16 bit Ro Updated 1.5 times - Nothing should happen")
    {
        mockMasterTable->setRegVal( mock_master_ro_min + 2, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 3, 0x77 );

        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 2, 0x34 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 3, 0x12 );

        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 2, 0x56 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getReg16Val( mock_master_ro_min+2 ) == 0x7777 );

        return 0;
    }

    PRAGMA_SUPPRESS_STATEMENT_UNREACHABLE_BEGIN

    UMBA_TEST("Called setReg16Val, 16 bit Ro update should be in the one request")
    {
        // пусть слейв обновляется почаще
        mockSlave->init(*mockMasterTable, testAdr, 100);

        // связь тип сразу рвется
        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( mockCallbacks, MockCallbacks::sendRequestAndFailConnection );
        testSynchronizer->init(sendRequest);

        // обращаемся к регистру на границе двух диапазонов как к 16-битному
        const uint8_t test_reg_num = mock_slave_ro_min + 2*MILLI_GANJUBUS_RANGE_LENGTH_MAX - 1;

        mockSlave->deviceTable.setReg16Val( test_reg_num , 0x1234 );

        for( uint16_t i=1; i<1000; i++ )
        {
            testSynchronizer->work(i*1000);


            if( mockCallbacks.m_wasSent )
            {
                mockCallbacks.m_wasSent = false;

                const uint8_t range_start_offset = MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

                UMBA_ASSERT( getFcode( mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] )
                             == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

                // наш регистр попадает в нужный диапазон
                if( mockCallbacks.m_request.buf[ range_start_offset ] <= test_reg_num &&
                        mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num )
                {
                    UMBA_CHECK( mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num + 1,
                                "16 bit reg should be updated atomically");

                    return 0;
                }
            }
        }

        UMBA_CHECK(false, "Test reg should be updated one way or another");
        return 0;
    }

    UMBA_TEST("Called getReg16Val, 16 bit Ro update should be in the one request")
    {
        // пусть слейв обновляется почаще
        mockSlave->init(*mockMasterTable, testAdr, 100);

        // связь тип сразу рвется
        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( mockCallbacks, MockCallbacks::sendRequestAndFailConnection );
        testSynchronizer->init(sendRequest);

        // обращаемся к регистру на границе двух диапазонов как к 16-битному
        const uint8_t test_reg_num = mock_slave_ro_min + 2*MILLI_GANJUBUS_RANGE_LENGTH_MAX - 1;

        mockSlave->deviceTable.getReg16Val( test_reg_num );

        for( uint16_t i=1; i<1000; i++ )
        {
            testSynchronizer->work(i*1000);


            if( mockCallbacks.m_wasSent )
            {
                mockCallbacks.m_wasSent = false;

                const uint8_t range_start_offset = MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

                UMBA_ASSERT( getFcode( mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] )
                             == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

                // наш регистр попадает в нужный диапазон
                if( mockCallbacks.m_request.buf[ range_start_offset ] <= test_reg_num &&
                        mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num )
                {
                    UMBA_CHECK( mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num + 1,
                                "16 bit reg should be updated atomically");

                    return 0;
                }
            }
        }

        UMBA_CHECK(false, "Test reg should be updated one way or another");
        return 0;
    }

    UMBA_TEST("Called checkReg16Update, 16 bit Ro update should be in the one request")
    {
        // пусть слейв обновляется почаще
        mockSlave->init(*mockMasterTable, testAdr, 100);

        // связь тип сразу рвется
        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( mockCallbacks, MockCallbacks::sendRequestAndFailConnection );
        testSynchronizer->init(sendRequest);

        // обращаемся к регистру на границе двух диапазонов как к 16-битному
        const uint8_t test_reg_num = mock_slave_ro_min + 2*MILLI_GANJUBUS_RANGE_LENGTH_MAX - 1;

        mockSlave->deviceTable.checkReg16Update( test_reg_num );

        for( uint16_t i=1; i<1000; i++ )
        {
            testSynchronizer->work(i*1000);


            if( mockCallbacks.m_wasSent )
            {
                mockCallbacks.m_wasSent = false;

                const uint8_t range_start_offset = MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

                UMBA_ASSERT( getFcode( mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] )
                             == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

                // наш регистр попадает в нужный диапазон
                if( mockCallbacks.m_request.buf[ range_start_offset ] <= test_reg_num &&
                        mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num )
                {
                    UMBA_CHECK( mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num + 1,
                                "16 bit reg should be updated atomically");

                    return 0;
                }
            }
        }

        UMBA_CHECK(false, "Test reg should be updated one way or another");
        return 0;
    }

    PRAGMA_END

    /*
    ----------------------------------------------------------------------------------------------------
                                          32 битные RO
    ----------------------------------------------------------------------------------------------------
    */

    PRAGMA_SUPPRESS_STATEMENT_UNREACHABLE_BEGIN

    UMBA_TEST("Called setReg32, 32 bit Ro update should be in the one request")
    {
        // пусть слейв обновляется почаще
        mockSlave->init(*mockMasterTable, testAdr, 100);

        // связь тип сразу рвется
        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( mockCallbacks, MockCallbacks::sendRequestAndFailConnection );
        testSynchronizer->init(sendRequest);

        // обращаемся к регистру на границе двух диапазонов как к 32-битному
        const uint8_t test_reg_num = mock_slave_ro_min + 2*MILLI_GANJUBUS_RANGE_LENGTH_MAX - 2;

        mockSlave->deviceTable.setReg32Val( test_reg_num , 0x12345678 );

        for( uint16_t i=1; i<1000; i++ )
        {
            testSynchronizer->work(i*1000);


            if( mockCallbacks.m_wasSent )
            {
                mockCallbacks.m_wasSent = false;

                const uint8_t range_start_offset = MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

                UMBA_ASSERT( getFcode( mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] )
                             == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

                // наш регистр попадает в нужный диапазон
                if( mockCallbacks.m_request.buf[ range_start_offset ] <= test_reg_num &&
                        mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num )
                {
                    UMBA_CHECK( mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num + 3,
                                "32 bit reg should be updated atomically");

                    return 0;
                }
            }
        }

        UMBA_CHECK(false, "Test reg should be updated one way or another");
        return 0;
    }

    UMBA_TEST("Called checkReg32Update, 32 bit Ro update should be in the one request")
    {
        // пусть слейв обновляется почаще
        mockSlave->init(*mockMasterTable, testAdr, 100);

        // связь тип сразу рвется
        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( mockCallbacks, MockCallbacks::sendRequestAndFailConnection );
        testSynchronizer->init(sendRequest);

        // обращаемся к регистру на границе двух диапазонов как к 32-битному
        const uint8_t test_reg_num = mock_slave_ro_min + 2*MILLI_GANJUBUS_RANGE_LENGTH_MAX - 2;

        mockSlave->deviceTable.checkReg32Update( test_reg_num );

        for( uint16_t i=1; i<1000; i++ )
        {
            testSynchronizer->work(i*1000);


            if( mockCallbacks.m_wasSent )
            {
                mockCallbacks.m_wasSent = false;

                const uint8_t range_start_offset = MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

                UMBA_ASSERT( getFcode( mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] )
                             == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

                // наш регистр попадает в нужный диапазон
                if( mockCallbacks.m_request.buf[ range_start_offset ] <= test_reg_num &&
                        mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num )
                {
                    UMBA_CHECK( mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num + 3,
                                "32 bit reg should be updated atomically");

                    return 0;
                }
            }
        }

        UMBA_CHECK(false, "Test reg should be updated one way or another");
        return 0;
    }

    UMBA_TEST("Called getReg32Val, 32 bit Ro update should be in the one request")
    {
        // пусть слейв обновляется почаще
        mockSlave->init(*mockMasterTable, testAdr, 100);

        // связь тип сразу рвется
        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( mockCallbacks, MockCallbacks::sendRequestAndFailConnection );
        testSynchronizer->init(sendRequest);

        // обращаемся к регистру на границе двух диапазонов как к 32-битному
        const uint8_t test_reg_num = mock_slave_ro_min + 2*MILLI_GANJUBUS_RANGE_LENGTH_MAX - 2;

        mockSlave->deviceTable.getReg32Val( test_reg_num );

        for( uint16_t i=1; i<1000; i++ )
        {
            testSynchronizer->work(i*1000);


            if( mockCallbacks.m_wasSent )
            {
                mockCallbacks.m_wasSent = false;

                const uint8_t range_start_offset = MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

                UMBA_ASSERT( getFcode( mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] )
                             == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

                // наш регистр попадает в нужный диапазон
                if( mockCallbacks.m_request.buf[ range_start_offset ] <= test_reg_num &&
                        mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num )
                {
                    UMBA_CHECK( mockCallbacks.m_request.buf[ range_start_offset+1 ] >= test_reg_num + 3,
                                "32 bit reg should be updated atomically");

                    return 0;
                }
            }
        }

        UMBA_CHECK(false, "Test reg should be updated one way or another");
        return 0;
    }

    PRAGMA_END


    UMBA_TEST("One byte of 32 bit ro reg was updated - nothing should happen")
    {
        mockMasterTable->setRegVal( mock_master_ro_min + 4, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 5, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 6, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 7, 0x77 );

        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 4, 0x34 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getReg32Val(mock_master_ro_min + 4) == 0x77777777);

        return 0;
    }


    UMBA_TEST("All bytes of 32 bit ro reg were updated - should be synced")
    {
        mockMasterTable->setRegVal( mock_master_ro_min + 4, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 5, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 6, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 7, 0x77 );

        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 4, 0x78 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 5, 0x56 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 6, 0x34 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 7, 0x12 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getReg32Val(mock_master_ro_min + 4) == 0x12345678);

        return 0;
    }

    UMBA_TEST("32 bit ro reg was partially updated many times - nothing should happen")
    {
        mockMasterTable->setRegVal( mock_master_ro_min + 4, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 5, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 6, 0x77 );
        mockMasterTable->setRegVal( mock_master_ro_min + 7, 0x77 );

        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 4, 0x78 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 5, 0x56 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 6, 0x34 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 7, 0x12 );

        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 6, 0x34 );
        mockSlave->deviceTable.setRegVal( mock_slave_ro_min + 7, 0x12 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getReg32Val(mock_master_ro_min + 4) == 0x77777777);

        return 0;
    }

    UMBA_TEST("32 bit Ro Update - Should be equal")
    {
        mockMasterTable->setReg32Val( mock_master_ro_min+4, 0x12345678 );
        mockSlave->getSlaveTable()->setReg32Val( mock_slave_ro_min+4, 0x55667788 );

        testSynchronizer->work(0);

        UMBA_CHECK( mockMasterTable->getReg32Val( mock_master_ro_min+4 ) == 0x55667788 );

        return 0;
    }






    /*
    ====================================================================================================
                                         Sanity checks
    ====================================================================================================
    */





    UMBA_TEST("Correct answer on request was received - Connection should be present")
    {
        mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        // имитируем правильный ответ на запись одного регистра
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = mock_slave_rw_min;

        tx_messages::wrapMsg(answer.buf, 2, testAdr);

        testSynchronizer->onRelevantAnswerReceived(answer);

        UMBA_CHECK( mockSlave->isConnected() == true, "Connection should be present");

        return 0;
    }

    UMBA_TEST("Nothing to update - should do nothing")
    {
        // выключаем синхронизацию
        mockSlave->setShouldSync(false);

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == false);

        return 0;
    }

    UMBA_TEST("No rw regs to update - should update ro")
    {
        // выключаем синхронизацию
        mockSlave->setShouldSync(false);

        // делаем вид, что ро-регистры надо обновлять почаще
        mockSlave->init(*mockMasterTable, testAdr, testRoInterval);

        testSynchronizer->work(testRoInterval + 1);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        // реквест должен быть запросом на чтение диапазона
        UMBA_CHECK(mockCallbacks.m_request.buf[ MILLI_GANJUBUS_TX_MSG_DATA_OFFSET] == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE);


        return 0;
    }


    UMBA_TEST("No answer on request was received - Connection should be lost")
    {
        mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        mockCallbacks.m_wasSent = false;
        // делаем вид, что ответа не последовало

        // делаем вид, что связь была
        mockSlave->setConnectionState(true);

        testSynchronizer->onConnectionFailure();

        UMBA_CHECK( mockSlave->isConnected() == false, "Connection should be lost");

        return 0;
    }
    
    UMBA_TEST("Too many connection failures - no request should be send")
    {
        // делаем вид, что связь была
        mockSlave->setConnectionState(true);
        
        // делаем вид, что ответы никак не приходят
        for( uint32_t i=0; i<=connection_failures_max; i++ )
        {
            mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );
            
            mockCallbacks.m_wasSent = false;
            
            testSynchronizer->work(0);
            testSynchronizer->onConnectionFailure();

            UMBA_CHECK(mockCallbacks.m_wasSent == true);
        }
        
        UMBA_CHECK( mockSlave->isConnected() == false, "Connection should be lost");
        UMBA_CHECK( mockSlave->getConnectionFailures() == connection_failures_max+1, "Connection failures should max out");

        // попробуем еще разок
        mockCallbacks.m_wasSent = false;
        mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

        for( uint8_t i=0; i< MILLIGANJUBUS_SLAVES_MAX*2; i++ )
        {
            testSynchronizer->work(0);
        }

        UMBA_CHECK( mockCallbacks.m_wasSent == false, "After too many failures, no connection attempt should be done");

        return 0;
    }

    UMBA_TEST("If connection is sometimes present - failures should not max out")
    {
        // делаем вид, что связь была
        mockSlave->setConnectionState(true);

        // делаем вид, что ответы никак не приходят
        // на один раз меньше чем нужно, чтобы слейва совсем отключило
        for( uint32_t i=0; i<connection_failures_max-1; i++ )
        {
            mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

            mockCallbacks.m_wasSent = false;

            testSynchronizer->work(0);
            testSynchronizer->onConnectionFailure();

            UMBA_CHECK(mockCallbacks.m_wasSent == true);
        }

        UMBA_CHECK( mockSlave->isConnected() == false, "Connection should be lost");
        UMBA_CHECK( mockSlave->getConnectionFailures() == connection_failures_max-1, "Connection failures should match");

        // теперь, внезапно, связь восстанавливается
        mockSlave->setConnectionState( true );

        // а потом ответы опять не приходят
        for( uint32_t i=0; i<connection_failures_max; i++ )
        {
            mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

            mockCallbacks.m_wasSent = false;

            testSynchronizer->work(0);
            testSynchronizer->onConnectionFailure();

            UMBA_CHECK(mockCallbacks.m_wasSent == true, "Connection was restored, so attempts must be made");
        }


        return 0;
    }

    UMBA_TEST("Multiple updates with answers - Should be ok")
    {
        mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        mockCallbacks.m_wasSent = false;

        // имитируем правильный ответ на запись одного регистра
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = mock_slave_rw_min;

        tx_messages::wrapMsg(answer.buf, 2, testAdr);

        for(uint8_t i=0; i<MILLIGANJUBUS_SLAVES_MAX*2; i++)
        {
            // делаем вид, что связи не было
            mockSlave->setConnectionState(false);

            testSynchronizer->onRelevantAnswerReceived(answer);

            UMBA_CHECK( mockSlave->isConnected() == true, "Connection should be present");

            mockCallbacks.m_wasSent = false;

            mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

            testSynchronizer->work(0);

            UMBA_CHECK(mockCallbacks.m_wasSent == true, "New request should be sent");
        }

        // делаем вид, что ответа не последовало

        return 0;
    }


    UMBA_TEST("Ignoring irrelevant answer - should sent request to the next slave")
    {
        // добавим в синхронизатор еще одного слейва
        MockSlave mockSlave_2;
        uint8_t testAdr_2 = ( (testAdr + 1) % 255 ) + 1;

        mockSlave_2.init(*mockMasterTable, testAdr_2, std::numeric_limits<uint32_t>::max());
        mockSlave_2.setShouldSync(true);

        testSynchronizer->addSlave( mockSlave_2 );

        mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );

        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        mockCallbacks.m_wasSent = false;

        // делаем вид, что связь была
        mockSlave->setConnectionState(true);

        MilliMessage answer;

        // делаем вид, что прилетал кривой ответ
        testSynchronizer->ignoreIrrelevantAnswer(answer);

        testSynchronizer->work(0);

        UMBA_CHECK( mockSlave->isConnected() == true, "Connection should not be lost yet");

        testSynchronizer->onConnectionFailure();

        UMBA_CHECK( mockSlave->isConnected() == false, "Connection should be lost");

        // должен полететь запрос к другому регистру
        mockMasterTable->setRegVal( mock_master_rw_min, 0x66 );
        testSynchronizer->work(0);

        UMBA_CHECK(mockCallbacks.m_wasSent == true);

        return 0;
    }



    /*
    ====================================================================================================
                                         Тесты с полноценным слейвоимитатором
    ====================================================================================================
    */




    UMBA_TEST("All ro regs should be updated, whatever their length may be")
    {
        // выключаем синхронизацию
        mockSlave->setShouldSync(false);

        // делаем вид, что ро-регистры надо обновлять почаще
        mockSlave->init(*mockMasterTable, testAdr, testRoInterval);

        // создаем полноценного поддельного слейва со своей личной таблицей

        SimpleRegTable< mock_slave_ro_min, mock_slave_ro_max,
                        mock_slave_rw_min, mock_slave_rw_max > deviceTable;

        milliganjubus::SlaveSession mockSlaveSession;
        uart::UartHandleMock uartMockSlave;
        mockSlaveSession.init(uartMockSlave, testAdr, deviceTable );


        milliganjubus::MasterSession masterSession(testRoInterval*10);
        uart::UartHandleMock uartMockMaster;

        {
            MasterSession::OnAnswerReceived onRelevantAnswerReceived =
                CALLBACK_BIND( *testSynchronizer, Synchronizer::onRelevantAnswerReceived );

            // при неверном ответе будет ассерт - вариант для проводных сетей
            MasterSession::OnAnswerReceived onIrrelevantAnswerReceived =
                CALLBACK_BIND( *testSynchronizer, Synchronizer::panicOnIrrelevantAnswerReceived );

            callback::VoidCallback onConnectionFailure = CALLBACK_BIND( *testSynchronizer, Synchronizer::onConnectionFailure );

            masterSession.init(uartMockMaster, onRelevantAnswerReceived, onConnectionFailure, onIrrelevantAnswerReceived);
        }

        Synchronizer::SendRequest sendRequest = CALLBACK_BIND( masterSession, MasterSession::sendRequest );

        testSynchronizer->init(sendRequest);


        for( uint8_t i = 0; i<100; i++ )
        {
            // придадим нескольким рандомным регистрам рандомную длину

            // сперва сбросим текущие длины
            for( uint8_t j = deviceTable.getRoMinRegNum(); j<deviceTable.getRoMaxRegNum(); j++)
            {
                mockSlave->getSlaveTable()->setRegLength( j, 1);
            }

            {
                uint8_t j=deviceTable.getRoMinRegNum();
                j += common_functions::xorshiftRandomByte() % deviceTable.getRoMaxRegNum();

                while( j < deviceTable.getRoMaxRegNum() )
                {
                    // рандомная длина - 1,2,4
                    uint8_t t = common_functions::xorshiftRandomByte() % 2 + 1;
                    uint8_t len = 1 << t;

                    if( j + len - 1 > deviceTable.getRoMaxRegNum() )
                        break;

                    mockSlave->getSlaveTable()->setRegLength( j, len);

                    j += len;
                }
            }

            // обнулим слейвовую таблицу и забьем рандомные числа в девайсовую таблицу
            for( uint8_t j = deviceTable.getRoMinRegNum(); j<deviceTable.getRoMaxRegNum(); j++)
            {
                mockSlave->getSlaveTable()->setRegVal( j, 0 );
                deviceTable.setRegVal( j, common_functions::xorshiftRandomByte() );
            }

            for( size_t j=0; j<deviceTable.getRoRegsTotal()*2 ; j++)
            {
                testSynchronizer->work(testRoInterval*j);
                testSynchronizer->work(testRoInterval*j);
                testSynchronizer->work(testRoInterval*j);

                masterSession.work(testRoInterval*j);
                masterSession.work(testRoInterval*j);
                masterSession.work(testRoInterval*j);
                masterSession.work(testRoInterval*j);

                // перекидываем запрос от мастера к слейву
                uartMockSlave.receiveData( (uint8_t *)uartMockMaster.m_txStaticArray, uartMockMaster.m_txStaticArraySize );
                uartMockMaster.m_txStaticArraySize = 0;

                mockSlaveSession.work( testRoInterval*j );
                mockSlaveSession.work( testRoInterval*j );
                mockSlaveSession.work( testRoInterval*j );
                mockSlaveSession.work( testRoInterval*j );

                // перекидываем ответ от слейва к мастеру
                uartMockMaster.receiveData( uartMockSlave.m_txLocalArray, uartMockSlave.m_txLocalArrayUsedSize );
                uartMockSlave.m_txLocalArrayUsedSize = 0;

            }

            for( uint8_t j = deviceTable.getRoMinRegNum(); j<deviceTable.getRoMaxRegNum(); j++)
            {
                UMBA_CHECK( mockSlave->getSlaveTable()->getRegVal(j) == deviceTable.getRegVal(j),
                            "Tables should be synced" );
            }

        }

        return 0;
    }



    UMBA_TEST("All ro regs should be updated, whatever their length may be. And multibyte regs should be updated atomically")
    {
        // выключаем синхронизацию
        mockSlave->setShouldSync(false);

        // делаем вид, что ро-регистры надо обновлять почаще
        mockSlave->init(*mockMasterTable, testAdr, testRoInterval);

        // создаем полноценного поддельного слейва со своей личной таблицей

        SimpleRegTable< mock_slave_ro_min, mock_slave_ro_max,
                        mock_slave_rw_min, mock_slave_rw_max > deviceTable;

        milliganjubus::SlaveSession mockSlaveSession;
        uart::UartHandleMock uartMockSlave;
        mockSlaveSession.init(uartMockSlave, testAdr, deviceTable );


        milliganjubus::MasterSession masterSession(testRoInterval*10);
        uart::UartHandleMock uartMockMaster;

        {
            MasterSession::OnAnswerReceived onRelevantAnswerReceived =
                CALLBACK_BIND( *testSynchronizer, Synchronizer::onRelevantAnswerReceived );

            // при неверном ответе будет ассерт - вариант для проводных сетей
            MasterSession::OnAnswerReceived onIrrelevantAnswerReceived =
                CALLBACK_BIND( *testSynchronizer, Synchronizer::panicOnIrrelevantAnswerReceived );

            callback::VoidCallback onConnectionFailure = CALLBACK_BIND( *testSynchronizer, Synchronizer::onConnectionFailure );

            masterSession.init(uartMockMaster, onRelevantAnswerReceived, onConnectionFailure, onIrrelevantAnswerReceived);
        }

        Synchronizer::SendRequest sendRequest = CALLBACK_BIND( masterSession, MasterSession::sendRequest );

        testSynchronizer->init(sendRequest);


        for( uint8_t i = 0; i<100; i++ )
        {
            // придадим нескольким рандомным регистрам рандомную длину

            // сперва сбросим текущие длины
            for( uint8_t j = deviceTable.getRoMinRegNum(); j<deviceTable.getRoMaxRegNum(); j++)
            {
                mockSlave->getSlaveTable()->setRegLength( j, 1);
                deviceTable.setRegLength( j, 1);
            }

            {
                uint8_t j=deviceTable.getRoMinRegNum();
                j += common_functions::xorshiftRandomByte() % deviceTable.getRoMaxRegNum();

                while( j < deviceTable.getRoMaxRegNum() )
                {
                    // рандомная длина - 1,2,4
                    uint8_t t = common_functions::xorshiftRandomByte() % 2 + 1;
                    uint8_t len = 1 << t;

                    if( j + len - 1 > deviceTable.getRoMaxRegNum() )
                        break;

                    mockSlave->getSlaveTable()->setRegLength( j, len);

                    j += len;
                }
            }

            // обнулим слейвовую таблицу и забьем рандомные числа в девайсовую таблицу
            for( uint8_t j = deviceTable.getRoMinRegNum(); j<deviceTable.getRoMaxRegNum(); j++)
            {
                mockSlave->getSlaveTable()->setRegVal( j, 0 );

                // сбрасываем обновленность
                while( mockSlave->getSlaveTable()->checkRegUpdate(j) )
                {
                    ;
                }

                deviceTable.setRegVal( j, common_functions::xorshiftRandomByte() );
            }

            for( size_t j=1; j<deviceTable.getRoRegsTotal()*2 ; j++)
            {

                testSynchronizer->work(testRoInterval*j + 1);
                testSynchronizer->work(testRoInterval*j + 1);
                testSynchronizer->work(testRoInterval*j + 1);

                masterSession.work(testRoInterval*j + 1);
                masterSession.work(testRoInterval*j + 1);
                masterSession.work(testRoInterval*j + 1);
                masterSession.work(testRoInterval*j + 1);

                // забьем рандомные числа в девайсовую таблицу - типа она успевает измениться между разными запросами
                for( uint8_t k = deviceTable.getRoMinRegNum(); k<deviceTable.getRoMaxRegNum(); k++)
                {
                    deviceTable.setRegVal( k, common_functions::xorshiftRandomByte() );
                }

                // перекидываем запрос от мастера к слейву
                uartMockSlave.receiveData( (uint8_t *)uartMockMaster.m_txStaticArray, uartMockMaster.m_txStaticArraySize );

                //printBuffer( (uint8_t *)uartMockMaster.m_txStaticArray, uartMockMaster.m_txStaticArraySize );

                uartMockMaster.m_txStaticArraySize = 0;

                mockSlaveSession.work( testRoInterval*j + 1);
                mockSlaveSession.work( testRoInterval*j + 1);
                mockSlaveSession.work( testRoInterval*j + 1);
                mockSlaveSession.work( testRoInterval*j + 1);

                // перекидываем ответ от слейва к мастеру
                uartMockMaster.receiveData( uartMockSlave.m_txLocalArray, uartMockSlave.m_txLocalArrayUsedSize );

                //printBuffer( uartMockSlave.m_txLocalArray, uartMockSlave.m_txLocalArrayUsedSize );

                uartMockSlave.m_txLocalArrayUsedSize = 0;

                // обрабатываем ответ
                masterSession.work(testRoInterval*j + 1);

                // если были обновления в регистрах - они должны были быть атомарными!

                for( uint8_t k = deviceTable.getRoMinRegNum(); k<deviceTable.getRoMaxRegNum(); k++)
                {
                    uint8_t len = mockSlave->getSlaveTable()->getRegLength(k);

                    switch(len)
                    {
                    case 1:

                        if( mockSlave->getSlaveTable()->checkRegUpdate(k) )
                        {
                            UMBA_CHECK( mockSlave->getSlaveTable()->getRegVal(k) == deviceTable.getRegVal(k),
                                        "Tables should be synced atomically" );
                        }
                        break;
                    case 2:
                        if( mockSlave->getSlaveTable()->checkReg16Update(k) )
                        {
                            UMBA_CHECK( mockSlave->getSlaveTable()->getReg16Val(k) == deviceTable.getReg16Val(k),
                                        "Tables should be synced atomically" );
                        }
                        break;
                    case 4:
                        if( mockSlave->getSlaveTable()->checkReg32Update(k) )
                        {
                            UMBA_CHECK( mockSlave->getSlaveTable()->getReg32Val(k) == deviceTable.getReg32Val(k),
                                        "Tables should be synced atomically" );
                        }
                        break;
                    default:
                        UMBA_ASSERT_FAIL();
                        break;
                    }
                }
            }
        }

        return 0;
    }




}

#endif
