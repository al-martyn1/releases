#include "project_config.h"


#ifdef USE_TESTS

#include "umba_cpp_test/umba_cpp_tests.h"
#include "uart/uart_handle_mock.h"

#include "milliganjubus_master_session.h"
#include "callbacks/callbacks.h"
#include "milliganjubus_message_format.h"
#include "common_functions/common_functions.h"


using namespace milliganjubus;

namespace
{


    UMBA_TEST_GROUP("Milliganjubus Master Session")

    /***************************************************************************************************
                                           Тестовые данные
    ***************************************************************************************************/


    const uint32_t ansTimeLimit = 500;
    const uint8_t testAdr = 0x55;

    /***************************************************************************************************
                                           Объекты для тестов
    ***************************************************************************************************/

    MasterSession testSession(ansTimeLimit);





    /***************************************************************************************************
                                           Моки
    ***************************************************************************************************/

    uart::UartHandleMock uartMock;


    class MockCallbacks
    {
    public:

        MockCallbacks(void) :
            answer(),
            isConnectionPresent(false),
            isAnswerIrrelevant(false)
        {
            ;
        }

        void processAnswer( const MilliMessage & ans)
        {
            answer = ans;
            isConnectionPresent = true;
        }

        void onConnectionLost(void)
        {
            isConnectionPresent = false;
        }

        void onIrrelevantAnswerReceived( const MilliMessage & ans)
        {
            answer = ans;
            isAnswerIrrelevant = true;
        }

        MilliMessage answer;

        bool isConnectionPresent;
        bool isAnswerIrrelevant;
    };

    MockCallbacks mockCallbacks;


    /***************************************************************************************************
                                           Вспомогательные функции
    ***************************************************************************************************/



    UMBA_TEST_SETUP()
    {
        MasterSession::OnAnswerReceived processAnswer_cb = CALLBACK_BIND( mockCallbacks, MockCallbacks::processAnswer );

        callback::VoidCallback onConnectionLost_cb = CALLBACK_BIND( mockCallbacks, MockCallbacks::onConnectionLost );
        MasterSession::OnAnswerReceived onIrrelevantAnswerReceived_cb = CALLBACK_BIND( mockCallbacks, MockCallbacks::onIrrelevantAnswerReceived );

        // явный вызов конструктора
        MasterSession * sessionPtr = &testSession;
        sessionPtr = new(sessionPtr) MasterSession(ansTimeLimit);


        testSession.init(uartMock,
                         processAnswer_cb,
                         onConnectionLost_cb,
                         onIrrelevantAnswerReceived_cb);
    }

    UMBA_TEST_TEARDOWN()
    {
        mockCallbacks.isAnswerIrrelevant = false;
        mockCallbacks.isConnectionPresent = false;

        std::memset(mockCallbacks.answer.buf, 0, MILLI_GANJUBUS_TX_MSG_SIZE_MAX);

        uartMock.flush();

#ifdef UART_USE_FREERTOS

        osSemaphoreGive( uartMock.getOwnerMutex() );

#endif
    }


    static void sendWriteSingle(uint8_t regNum, uint8_t val)
    {
        // пошлем корректный запрос на запись одного регистра
        MilliMessage request;
        uint8_t * reqBuf = request.buf;

        reqBuf[MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        reqBuf += MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

        // типа адрес и данные
        reqBuf[0] = regNum;
        reqBuf[1] = val;
        tx_messages::wrapMsg(request.buf, 2+1, testAdr);

        // отправим вот такой запрос
        testSession.sendRequest(request);
    }

    static void sendWriteRange(uint8_t begin, uint8_t end)
    {
        MilliMessage request;
        uint8_t * reqBuf = request.buf;

        reqBuf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;

        reqBuf += MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

        // типа начало и конец
        reqBuf[0] = begin;
        reqBuf[1] = end;

        // и какая-нибудь лажа в буфере сойдет за value
        uint8_t size = MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE + 2 + (end-begin+1);
        tx_messages::wrapMsg(request.buf, size, testAdr);

        // отправим вот такой запрос
        testSession.sendRequest(request);
    }

    static void sendWriteSeries(uint8_t * regs, uint8_t size)
    {
        MilliMessage request;
        uint8_t * reqBuf = request.buf;

        reqBuf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;

        reqBuf += MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

        // типа адрес и данные
        for(uint8_t i=0, j=0; j<size; j++, i+=2)
        {
            reqBuf[i] = regs[j];
            reqBuf[i+1] = common_functions::xorshiftRandomByte();
        }

        tx_messages::wrapMsg(request.buf, size*2+1, testAdr);

        // отправим вот такой запрос
        testSession.sendRequest(request);
    }

    static void sendReadSingle(uint8_t regNum)
    {

        MilliMessage request;
        uint8_t * reqBuf = request.buf;

        reqBuf[MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET] = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;
        reqBuf += MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

        // только адрес
        reqBuf[0] = regNum;
        tx_messages::wrapMsg(request.buf, 2, testAdr);

        // отправим вот такой запрос
        testSession.sendRequest(request);
    }

    static void sendReadRange(uint8_t begin, uint8_t end)
    {
        MilliMessage request;
        uint8_t * reqBuf = request.buf;

        reqBuf[MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;
        reqBuf += MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

        reqBuf[0] = begin;
        reqBuf[1] = end;
        tx_messages::wrapMsg(request.buf, 2+1, testAdr);

        // отправим вот такой запрос
        testSession.sendRequest(request);

    }

    static void sendReadSeries(uint8_t * regs, uint8_t size)
    {
        MilliMessage request;
        uint8_t * reqBuf = request.buf;

        reqBuf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;

        reqBuf += MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET + 1;

        // просто набор адресов
        for(uint8_t i=0; i<size; i++)
        {
            reqBuf[i] = regs[i];
        }

        tx_messages::wrapMsg(request.buf, size+1, testAdr);

        // отправим вот такой запрос
        testSession.sendRequest(request);

    }


// для проверки на равенство правильных ганджубусных сообщений
    static bool isEqual(MilliMessage & one, MilliMessage & another)
    {
        uint8_t size = tx_messages::getMsgSize(one.buf);

        if( std::memcmp(one.buf, another.buf, size) == 0)
            return true;
        else
            return false;
    }


    /***************************************************************************************************
                                           Тесты
    ***************************************************************************************************/


    /*
    ====================================================================================================
                                           NACK'и и таймауты и т.п.
    ====================================================================================================
    */

    UMBA_TEST("Single Reg Write - Answer fcode incorrect - Should call onIrrelevanAnswer")
    {
        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendReadSingle(regNum);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        // только вот эф-код кладем другой
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regNum;

        tx_messages::wrapMsg(answer.buf, 2, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        testSession.work(0);


        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }

    UMBA_TEST("Single Reg Write - Answer NACK - Should call back")
    {
        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        // ответим NACK'ом
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addNack(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS;

        tx_messages::wrapMsg(answer.buf, 2, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }

    UMBA_TEST("Single Reg Write - Answer timeout - Should repeat, connection should be lost")
    {
        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        uartMock.flush();

        // передача была завершена
        uartMock.m_isTransmitComplete = true;


        // делаем вид, что связь была
        mockCallbacks.isConnectionPresent = true;

        // делаем вид, что прошло мнооого времени

        for(uint8_t i=0; i<3; i++)
        {

#ifdef UART_USE_FREERTOS

            osSemaphoreGive( uartMock.m_transmitCompleteSem );
            testSession.work( ansTimeLimit*(i+1));

            osSemaphoreGive( uartMock.m_transmitCompleteSem );
            testSession.work( ansTimeLimit*(i+1));

#else

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

#endif

            UMBA_CHECK( mockCallbacks.isConnectionPresent == true, "Connection should not be lost yet" );
            UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

            UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Request should be repeated" );

            uartMock.flush();
        }

        testSession.work( ansTimeLimit*4);
        uartMock.m_isTransmitComplete = true;

        testSession.work( ansTimeLimit*4);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( mockCallbacks.isConnectionPresent == false, "Connection should be lost" );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);



        // теперь делаем вид, что ответ все же пришел

        // подготовим ответ
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regNum;

        tx_messages::wrapMsg(answer.buf, 2, testAdr);
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work( ansTimeLimit*4);

        UMBA_CHECK( mockCallbacks.isConnectionPresent == false, "Connection should be still lost" );

        return 0;

    }

    UMBA_TEST("Single Reg Write - Send after connection lost - Should be ok")
    {
        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        uartMock.flush();

        uartMock.m_isTransmitComplete = true;

        // делаем вид, что прошло мнооого времени

        for(uint8_t i=0; i<3; i++)
        {
#ifdef UART_USE_FREERTOS
            osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

#ifdef UART_USE_FREERTOS
            osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

#ifdef UART_USE_FREERTOS
            osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            uartMock.flush();
        }

        testSession.work( ansTimeLimit*4);
        uartMock.m_isTransmitComplete = true;

        testSession.work( ansTimeLimit*4);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( mockCallbacks.isConnectionPresent == false, "Connection should be lost" );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        uartMock.flush();

        // теперь отправим новый запрос и ответим на него
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        // подготовим ответ
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regNum;

        tx_messages::wrapMsg(answer.buf, 2, testAdr);
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( mockCallbacks.isConnectionPresent == true, "Connection should be present" );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }



    UMBA_TEST("Single Reg Write - Answer timeout - Should be three repeats")
    {
        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        uartMock.flush();
        uartMock.m_isTransmitComplete = true;


        // делаем вид, что связь была
        mockCallbacks.isConnectionPresent = true;

        // делаем вид, что прошло мнооого времени

        for(uint8_t i=0; i<3; i++)
        {
            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;
            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;
            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            UMBA_CHECK( mockCallbacks.isConnectionPresent == true, "Connection should not be lost yet" );
            UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

            UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Request should be repeated" );

            uartMock.flush();
            uartMock.m_isTransmitComplete = true;
        }

        testSession.work( ansTimeLimit*4);
        uartMock.m_isTransmitComplete = true;

        testSession.work( ansTimeLimit*4);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( mockCallbacks.isConnectionPresent == false, "Connection should be lost" );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        uartMock.flush();

        testSession.work( ansTimeLimit*5);
        uartMock.m_isTransmitComplete = true;

        testSession.work( ansTimeLimit*5);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( uartMock.m_txStaticArray == 0, "Request should not be repeated" );


        return 0;

    }


    UMBA_TEST("Message sent after 3 repeats - Should be repeated three times aswell")
    {
        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        uartMock.flush();
        uartMock.m_isTransmitComplete = true;

        // делаем вид, что связь была
        mockCallbacks.isConnectionPresent = true;

        // делаем вид, что прошло мнооого времени

        for(uint8_t i=0; i<3; i++)
        {
            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            UMBA_CHECK( mockCallbacks.isConnectionPresent == true, "Connection should not be lost yet" );
            UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

            UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Request should be repeated" );

            uartMock.flush();
            uartMock.m_isTransmitComplete = true;
        }

        testSession.work( ansTimeLimit*4);
        uartMock.m_isTransmitComplete = true;

        testSession.work( ansTimeLimit*4);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( mockCallbacks.isConnectionPresent == false, "Connection should be lost" );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        uartMock.flush();

        testSession.work( ansTimeLimit*5);
        uartMock.m_isTransmitComplete = true;

        testSession.work( ansTimeLimit*5);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( uartMock.m_txStaticArray == 0, "Request should not be repeated" );

        // теперь пошлем еще одно сообщение и убедимся, что оно повторяется три раза
        sendWriteSingle(regNum, 66);

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Message should be sent" );


        uartMock.flush();

        uartMock.m_isTransmitComplete = true;

        // делаем вид, что связь была
        mockCallbacks.isConnectionPresent = true;

        // делаем вид, что прошло мнооого времени

        for(uint8_t i=0; i<3; i++)
        {
            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            testSession.work( ansTimeLimit*(i+1));
            uartMock.m_isTransmitComplete = true;

            UMBA_CHECK( mockCallbacks.isConnectionPresent == true, "Connection should not be lost yet" );
            UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

            UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, "Request should be repeated" );

            uartMock.flush();

            uartMock.m_isTransmitComplete = true;
        }

        return 0;

    }


    UMBA_TEST("Answer incorrect - Should call onIrrelevantAnswer - Then should call onConnectionFailure")
    {
        mockCallbacks.isConnectionPresent = true;

        uint8_t regs[] = {0x11, 0x22};
        sendReadSeries(regs, NUM_ELEM(regs));

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        // отправляем запрос
        testSession.work(0);

        // дожидаемся конца отправления запроса
        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regs[0];
        ansBuf[2] = regs[1]+1; // портим один регистр

        // за value сойдет мусор в буфере


        tx_messages::wrapMsg(answer.buf, 2*2+1, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));


        // принимаем кривой ответ
        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        // ждем нормального ответа, не дожидаемся
        testSession.work( ansTimeLimit);
        uartMock.m_isTransmitComplete = true;

//        // отправляем первый повтор
//        testSession.work( ansTimeLimit);
//        uartMock.m_isTransmitComplete = true;

        for( uint8_t i=0; i<3; i++)
        {
            // отправляем повтор
            testSession.work( ansTimeLimit*(2+i) );
            uartMock.m_isTransmitComplete = true;

            // ждем конца отправления
            testSession.work( ansTimeLimit*(2+i) );
            uartMock.m_isTransmitComplete = true;

            // ждем ответ
            testSession.work( ansTimeLimit*(2+i+1) );
            uartMock.m_isTransmitComplete = true;
        }

        UMBA_CHECK( mockCallbacks.isConnectionPresent == false, "Connection should be lost" );

        return 0;

    }


    /*
    ====================================================================================================
                                           Запись одного регистра
    ====================================================================================================
    */


    UMBA_TEST("Single Reg Write - Answer Correct - Should call back")
    {
        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regNum;

        tx_messages::wrapMsg(answer.buf, 2, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }

    UMBA_TEST("Send single write - answer incorrect, wrong reg - should call onIrrelevantAnswer" )
    {

        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;

        // портим номер регистра
        ansBuf[0] = regNum + 1;

        tx_messages::wrapMsg(answer.buf, 2, testAdr);
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;
    }

    UMBA_TEST("Send single write - answer incorrect, wrong size - should call onIrrelevantAnswer" )
    {
        // пошлем корректный запрос на запись одного регистра
        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendWriteSingle(regNum, 66);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;


        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;

        // портим номер регистра
        ansBuf[0] = regNum;

        // делаем вид, что в ответе есть еще какие-то данные
        tx_messages::wrapMsg(answer.buf, 2+1, testAdr);
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;


        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;
    }

    /*
    ====================================================================================================
                                           Запись диапазона
    ====================================================================================================
    */

    UMBA_TEST("Write range - Answer correct - Should call back")
    {
        // пошлем корректный запрос на запись диапазона
        uint8_t regBegin = 0x55;
        uint8_t regEnd = regBegin + 3;

        sendWriteRange(regBegin, regEnd);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE);

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regBegin;
        ansBuf[1] = regEnd;
        tx_messages::wrapMsg(answer.buf, 3, testAdr);

        // отправляем ответ
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }

    UMBA_TEST("Write range - Answer incorrect, wrong regs - Should call onIrrelevantAnswer")
    {
        // пошлем корректный запрос на запись диапазона
        uint8_t regBegin = 0x77;
        uint8_t regEnd = regBegin + 3;

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        sendWriteRange(regBegin, regEnd);

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;


        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE);

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regBegin;

        // портим один регистр в ответе
        ansBuf[1] = regEnd + 1;
        tx_messages::wrapMsg(answer.buf, 3, testAdr);

        // отправляем ответ
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }

    UMBA_TEST("Write range - Answer incorrect, wrong size - Should call onIrrelevantAnswer")
    {
        // пошлем корректный запрос на запись диапазона
        uint8_t regBegin = 0x77;
        uint8_t regEnd = regBegin + 3;

        sendWriteRange(regBegin, regEnd);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE);

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regBegin;

        ansBuf[1] = regEnd;

        // сделаем вид что в ответе есть еще какие-то данные
        // которых быть не должно
        tx_messages::wrapMsg(answer.buf, 3+1, testAdr);

        // отправляем ответ
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }


    /*
    ====================================================================================================
                                           Запись серии
    ====================================================================================================
    */

    UMBA_TEST("Send write series - answer correct - should call back")
    {
        // пошлем корректный запрос на запись серии
        uint8_t regs[] = {0x23, 0x79, 0x61};

        sendWriteSeries(regs, NUM_ELEM(regs));

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES);


        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regs[0];
        ansBuf[1] = regs[1];
        ansBuf[2] = regs[2];

        // тут важно указать размер правильно
        tx_messages::wrapMsg(answer.buf, 4, testAdr);

        // отправляем ответ
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }

    UMBA_TEST("Send write series - answer incorrect, wrong regs - should call onIrrelevantAnswer")
    {
        // пошлем корректный запрос на запись серии
        uint8_t regs[] = {0x23, 0x79, 0x61};

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        sendWriteSeries(regs, NUM_ELEM(regs));
        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES);


        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regs[0];
        ansBuf[1] = regs[1]+1; // испортим один регистр
        ansBuf[2] = regs[2];

        // тут важно указать размер правильно
        tx_messages::wrapMsg(answer.buf, 4, testAdr);

        // отправляем ответ
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }

    UMBA_TEST("Send write series - answer length incorrect - should call onIrrelevantAnswer")
    {
        // пошлем корректный запрос на запись серии
        uint8_t regs[] = {0x11, 0x22};

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        sendWriteSeries(regs, NUM_ELEM(regs));
        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES);


        // теперь надо ответить ответом - и пусть в ответе регистров будет больше, чем в запросе
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regs[0];
        ansBuf[1] = regs[1];
        ansBuf[2] = 3;

        tx_messages::wrapMsg(answer.buf, 3+1, testAdr);

        // отправляем ответ
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }


    UMBA_TEST("Send write series - answer incorrect regnum - should call onIrrelevantAnswer")
    {
        // пошлем корректный запрос на запись серии
        uint8_t regs[] = {0x11, 0x22};

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        sendWriteSeries(regs, NUM_ELEM(regs));
        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES);


        // теперь надо ответить ответом - и пусть в ответе регистров будет больше, чем в запросе
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regs[0];
        ansBuf[1] = regs[1]+1;

        tx_messages::wrapMsg(answer.buf, 2+1, testAdr);

        // отправляем ответ
        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }


    /*
    ====================================================================================================
                                           Чтение одного регистра
    ====================================================================================================
    */


    UMBA_TEST("Single Reg Read - Answer Correct - Should call back")
    {

        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendReadSingle(regNum);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regNum;
        ansBuf[1] = 0x11; // типа value

        tx_messages::wrapMsg(answer.buf, 2+1, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }

    UMBA_TEST("Single Reg Read - Answer incorrect, wrong size - Should call onIrrelevantAnswer")
    {

        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendReadSingle(regNum);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regNum;
        ansBuf[1] = 0x11; // типа value

        // сделаем вид, что в ответе есть еще какие-то данные
        tx_messages::wrapMsg(answer.buf, 2+2, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }

    UMBA_TEST("Single Reg Read - Answer incorrect, wrong regnum - Should call onIrrelevantAnswer")
    {

        uint8_t regNum = common_functions::xorshiftRandomByte();
        sendReadSingle(regNum);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regNum +1; // портим номер регистра
        ansBuf[1] = 0x11; // типа value

        tx_messages::wrapMsg(answer.buf, 2+1, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }

    /*
    ====================================================================================================
                                           Чтение диапазона
    ====================================================================================================
    */


    UMBA_TEST("Range Read - Answer Correct - Should call back")
    {

        uint8_t begin = common_functions::xorshiftRandomByte();
        uint8_t end = begin+3;
        sendReadRange(begin, end);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = begin;
        ansBuf[1] = end;

        // за value сойдет мусор в буфере

        tx_messages::wrapMsg(answer.buf, 2+1 + (end-begin+1), testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }

    UMBA_TEST("Range Read - Answer incorrect, wrong regnum - Should call onIrrelevantAnswer")
    {

        uint8_t begin = common_functions::xorshiftRandomByte();
        uint8_t end = begin+3;
        sendReadRange(begin, end);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = begin;
        ansBuf[1] = end;

        // за value сойдет мусор в буфере

        tx_messages::wrapMsg(answer.buf, 2+1 + (end-begin+1), testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }

    UMBA_TEST("Range Read - Answer incorrect, wrong size - Should call onIrrelevantAnswer")
    {
        uint8_t begin = common_functions::xorshiftRandomByte();
        uint8_t end = begin+3;
        sendReadRange(begin, end);

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = begin;
        ansBuf[1] = end;

        // за value сойдет мусор в буфере
        // сделаем размер по-больше
        tx_messages::wrapMsg(answer.buf, 5 + (end-begin+1), testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }


    /*
    ====================================================================================================
                                           Чтение серий
    ====================================================================================================
    */


    UMBA_TEST("Read series - Answer Correct - Should call back")
    {
        uint8_t regs[] = {0x11, 0x22, 0x33};
        sendReadSeries(regs, NUM_ELEM(regs));

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regs[0];
        ansBuf[2] = regs[1];
        ansBuf[4] = regs[2];

        // за value сойдет мусор в буфере

        tx_messages::wrapMsg(answer.buf, 3*2+1, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == false);

        return 0;

    }



    UMBA_TEST("Read series - Answer incorrect, wrong size - Should call onIrrelevantAnswer")
    {
        uint8_t regs[] = {0x11, 0x22};
        sendReadSeries(regs, NUM_ELEM(regs));

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regs[0];
        ansBuf[2] = regs[1];

        // за value сойдет мусор в буфере

        // ставим размер больше чем должно быть
        tx_messages::wrapMsg(answer.buf, 3*2+1, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }

    UMBA_TEST("Read series - Answer incorrect, wrong regs - Should call onIrrelevantAnswer")
    {
        uint8_t regs[] = {0x11, 0x22};
        sendReadSeries(regs, NUM_ELEM(regs));

#ifdef UART_USE_FREERTOS
        osSemaphoreGive( uartMock.m_transmitCompleteSem );
#endif

        testSession.work(0);

        // убедимся, что он отправился
        UMBA_CHECK( uartMock.m_txStaticArray[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES );

        // теперь надо ответить ответом
        MilliMessage answer;
        uint8_t * ansBuf = answer.buf;

        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;
        ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] = addAck(ansBuf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]);

        ansBuf += MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET + 1;
        ansBuf[0] = regs[0];
        ansBuf[2] = regs[1]+1; // портим один регистр

        // за value сойдет мусор в буфере


        tx_messages::wrapMsg(answer.buf, 2*2+1, testAdr);

        uartMock.receiveData(answer.buf, tx_messages::getMsgSize(answer.buf));

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        testSession.work(0);
        uartMock.m_isTransmitComplete = true;

        UMBA_CHECK( isEqual(mockCallbacks.answer, answer) );
        UMBA_CHECK( mockCallbacks.isAnswerIrrelevant == true);

        return 0;

    }

} // anonymous namespace

#endif
