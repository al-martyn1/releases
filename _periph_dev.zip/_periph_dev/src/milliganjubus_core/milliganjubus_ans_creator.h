#pragma once

#include "project_config.h"

#include "milliganjubus_i_milli_reg_table.h"
#include "milliganjubus_message_format.h"
#include "milliganjubus_common.h"


namespace milliganjubus
{

    class AnswerCreator
    {

    public:

        AnswerCreator() : m_answerAdr(0)
        {

        }

        struct Register
        {
            Register() :
                regNum(0),
                value(0)
            {}

            uint8_t regNum;
            uint8_t value;
        };

        void init(uint8_t answerAddress)
        {
            this->m_answerAdr = answerAddress;
        }

        void createNackAnswer(uint8_t fcode, uint8_t errcode, MilliMessage & answer);

        void createReadSingleAnswer(uint8_t regNum, uint8_t val, MilliMessage & answer);
        void createReadRangeAnswer(uint8_t startRegNum, uint8_t endRegNum, Register * range, MilliMessage & answer);
        void createReadSeriesAnswer(Register * series, uint8_t size, MilliMessage & answer);


        void createWriteSingleAnswer(uint8_t regNum, MilliMessage & answer);
        void createWriteRangeAnswer(uint8_t startRegNum, uint8_t endRegNum, MilliMessage & answer);
        void createWriteSeriesAnswer(Register * series, uint8_t size, MilliMessage & answer);

    protected:

        static uint8_t * getDataBuf(MilliMessage & answer);

        void wrapAnswer(MilliMessage & answer);

        uint8_t m_answerAdr;
    };

} /* namespace milliganjubus */
