#pragma once

#include "project_config.h"
#include "callbacks/callbacks.h"
#include "milliganjubus_i_milli_reg_table.h"
#include "milliganjubus_message_format.h"
#include "milliganjubus_common.h"


namespace milliganjubus
{

    class AnswerProcessor
    {

    public:

        AnswerProcessor() :
            m_table(0),
            m_onAnswerProcessed(0)
        {
            ;
        }

        void init(IMilliRegTable & table, callback::VoidCallback onAnswerProcessed = callback::VoidCallback() );

        void processAnswer( const MilliMessage & answer);

    protected:

        // копировать запрещено
        AnswerProcessor( const AnswerProcessor & rhs);
        AnswerProcessor & operator=( AnswerProcessor s);

        uint8_t getMsgGbyte( const MilliMessage & answer) const
        {
            const uint8_t * buf = answer.buf;
            return buf[MILLI_GANJUBUS_RX_MSG_DATA_OFFSET];
        }

        const uint8_t * getDataBuf(const MilliMessage & answer) const
        {
            return (answer.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE);
        }

        uint8_t getDataSize(const MilliMessage & answer) const
        {
            const uint8_t * buf = answer.buf;
            return buf[MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET] - MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE - MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE;
        }

        // обработчики ф-кодов
        void readSingleRegAns( const MilliMessage & answer);
        void readRegsRangeAns( const MilliMessage & answer);
        void readRegsSeriesAns( const MilliMessage & answer);

        void writeSingleRegAns( const MilliMessage & answer);
        void writeRegsRangeAns( const MilliMessage & answer);
        void writeRegsSeriesAns( const MilliMessage & answer);

        IMilliRegTable * m_table;
        callback::VoidCallback m_onAnswerProcessed;

    };

} /* namespace milliganjubus */
