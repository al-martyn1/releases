#pragma once

#include "project_config.h"

struct MilliGanjubusSlave;

typedef bool(*MilliGanjubusSlave_isNewByte_cb)(void);
typedef uint8_t(*MilliGanjubusSlave_getByte_cb)(void);

// эта функция не должна расчитывать, что массив статический
typedef void(*MilliGanjubusSlave_sendArray_cb)(const uint8_t * array, uint32_t size);

typedef void(*MilliGanjubusSlave_voidCallback)(void);

struct MilliGanjubusSlave_TableParams
{
    uint8_t roRegMin;
    uint8_t roRegMax;
    uint8_t rwRegMin;
    uint8_t rwRegMax;
};

struct MilliGanjubusSlave_RequiredCallbacks
{
    MilliGanjubusSlave_isNewByte_cb isNewByte_cb;
    MilliGanjubusSlave_getByte_cb getByte_cb;
    MilliGanjubusSlave_sendArray_cb sendArray_cb;
};

struct MilliGanjubusSlave_OptionalCallbacks
{
    MilliGanjubusSlave_voidCallback lostLinkHandler;
    MilliGanjubusSlave_voidCallback restoredLinkHandler;
    MilliGanjubusSlave_voidCallback onMessageReceived;
};

extern "C"
{


    DLL_PUBLIC MilliGanjubusSlave * MilliGanjubusSlave_createInstance
    (
        MilliGanjubusSlave_TableParams * tableParams,

        uint8_t slaveAdr,
        uint32_t lostLinkTimeout,

        MilliGanjubusSlave_RequiredCallbacks * requiredCallbacks,
        MilliGanjubusSlave_OptionalCallbacks * optionalCallbacks
    );

    DLL_PUBLIC void MilliGanjubusSlave_deleteInstance(MilliGanjubusSlave* self);

    DLL_PUBLIC void MilliGanjubusSlave_work(MilliGanjubusSlave * self, uint32_t curTime);

    DLL_PUBLIC void MilliGanjubusSlave_setRegVal(MilliGanjubusSlave* self, uint8_t regNum, uint8_t val);
    DLL_PUBLIC uint8_t MilliGanjubusSlave_getRegVal(MilliGanjubusSlave* self, uint8_t regNum);

    DLL_PUBLIC bool MilliGanjubusSlave_checkRegUpdate(MilliGanjubusSlave* self, uint8_t regNum); // эта функция сбрасывает флаг обновления

    // сдвоенные регистры и двухбайтные значения
    DLL_PUBLIC void MilliGanjubusSlave_setReg16Val(MilliGanjubusSlave* self, uint8_t lowRegNum, uint16_t val);
    DLL_PUBLIC uint16_t MilliGanjubusSlave_getReg16Val(MilliGanjubusSlave* self, uint8_t lowRegNum);

    DLL_PUBLIC bool MilliGanjubusSlave_checkReg16Update(MilliGanjubusSlave* self, uint8_t lowRegNum);

    // счетверенные регистры и четырехбайтные значения
    DLL_PUBLIC void MilliGanjubusSlave_setReg32Val(MilliGanjubusSlave* self, uint8_t lowRegNum, uint32_t val);
    DLL_PUBLIC uint32_t MilliGanjubusSlave_getReg32Val(MilliGanjubusSlave* self, uint8_t lowRegNum);

    DLL_PUBLIC bool MilliGanjubusSlave_checkReg32Update(MilliGanjubusSlave* self, uint8_t lowRegNum);

}
