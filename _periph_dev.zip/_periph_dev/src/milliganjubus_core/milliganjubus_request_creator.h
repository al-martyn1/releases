#pragma once

#include <stdint.h>

#include "project_config.h"
#include "milliganjubus_message_format.h"
#include "milliganjubus_common.h"

namespace milliganjubus
{

    class RequestCreator
    {

    public:

        RequestCreator() :
            m_deviceAddress(0)
        {
            ;
        }

        inline void init(uint8_t deviceAdr)
        {
            m_deviceAddress = deviceAdr;
        }

        struct Register
        {
            Register(void): num(0), val(0)
            {
                ;
            }

            uint8_t num;
            uint8_t val;
        };


        void createWriteReg(MilliMessage & request, uint8_t regNum, uint8_t val);

        void createWriteRange(MilliMessage & request, uint8_t startReg, uint8_t endReg, const uint8_t * values);

        void createWriteSeries(MilliMessage & request, const Register * series, uint8_t len);

        void createReadReg(MilliMessage & request, uint8_t regNum);

        void createReadRange(MilliMessage & request, uint8_t regNumBegin, uint8_t regNumEnd);

        void createReadSeries(MilliMessage & request, const Register * series, uint8_t len);

    protected:

        uint8_t m_deviceAddress;

    };

} /* namespace milliganjubus */
