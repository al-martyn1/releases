#include "milliganjubus_ans_creator.h"

namespace milliganjubus
{

    /***************************************************************************************************
                                         Вспомогательные операции
    ***************************************************************************************************/

    // возвращает указатель на место для ack/nack в ответе
    uint8_t * AnswerCreator :: getDataBuf(MilliMessage & answer)
    {
        uint8_t * buf = answer.buf;

        return ( buf + MILLI_GANJUBUS_TX_MSG_DATA_OFFSET );
    }

    void AnswerCreator :: wrapAnswer( MilliMessage & answer )
    {
        tx_messages::wrapMsg( answer.buf, tx_messages::getMsgSize(answer.buf), m_answerAdr );
    }



    /***************************************************************************************************
                                           Генераторы ответов
    ***************************************************************************************************/


    /*
    ====================================================================================================
                                              NACK
    ====================================================================================================
    */


    void AnswerCreator :: createNackAnswer(uint8_t fcode, uint8_t errcode, MilliMessage & answer)
    {
        uint8_t * buf = getDataBuf(answer);

        uint8_t gByte = fcode;

        gByte = addNack(gByte);

        buf[0] = gByte;
        buf[1] = errcode;

        answer.buf[MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET] = (1+1);

        wrapAnswer(answer);
    }

    void AnswerCreator :: createReadSingleAnswer(uint8_t regNum, uint8_t val, MilliMessage & answer)
    {
        uint8_t * buf = getDataBuf(answer);

        uint8_t gByte = MILLI_GANJUBUS_FCODE_READ_SINGLE_REG;

        gByte = addAck(gByte);

        buf[0] = gByte;
        buf[1] = regNum;
        buf[2] = val;

        answer.buf[MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET] = (1+1+1);

        wrapAnswer(answer);
    }

    void AnswerCreator :: createReadRangeAnswer(uint8_t startRegNum, uint8_t endRegNum, Register * range, MilliMessage & answer)
    {
        UMBA_ASSERT(endRegNum - startRegNum <= MILLI_GANJUBUS_RANGE_LENGTH_MAX);

        uint8_t * buf = getDataBuf(answer);

        uint8_t gByte = MILLI_GANJUBUS_FCODE_READ_REGS_RANGE;

        gByte = addAck(gByte);

        buf[0] = gByte;
        buf[1] = startRegNum;
        buf[2] = endRegNum;

        buf+=3;

        uint8_t size = endRegNum - startRegNum + 1;

        for(uint8_t i=0; i<size; i++)
        {
            buf[i] = range[i].value;
        }

        answer.buf[MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET] = (1+1+1+size);

        wrapAnswer(answer);
    }

    void AnswerCreator :: createReadSeriesAnswer(Register * series, uint8_t size, MilliMessage & answer)
    {
        UMBA_ASSERT(size <= MILLI_GANJUBUS_SERIES_LENGTH_MAX);

        uint8_t * buf = getDataBuf(answer);

        uint8_t gByte = MILLI_GANJUBUS_FCODE_READ_REGS_SERIES;

        gByte = addAck(gByte);

        buf[0] = gByte;

        buf++;

        for(uint8_t i=0, j=0; i<size; i++, j+=2)
        {
            buf[j] = series[i].regNum;
            buf[j+1] = series[i].value;
        }

        answer.buf[MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET] = (1+2*size);

        wrapAnswer(answer);
    }


    void AnswerCreator :: createWriteSingleAnswer(uint8_t regNum, MilliMessage & answer)
    {
        uint8_t * buf = getDataBuf(answer);

        uint8_t gByte = MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG;

        gByte = addAck(gByte);

        buf[0] = gByte;
        buf[1] = regNum;

        answer.buf[MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET] = (1+1);

        wrapAnswer(answer);
    }

    void AnswerCreator :: createWriteRangeAnswer(uint8_t startRegNum, uint8_t endRegNum, MilliMessage & answer)
    {
        uint8_t * buf = getDataBuf(answer);

        uint8_t gByte = MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE;

        gByte = addAck(gByte);

        buf[0] = gByte;
        buf[1] = startRegNum;
        buf[2] = endRegNum;

        answer.buf[MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET] = (1+1+1);

        wrapAnswer(answer);

    }

    void AnswerCreator :: createWriteSeriesAnswer(Register * series, uint8_t size, MilliMessage & answer)
    {
        UMBA_ASSERT(size <= MILLI_GANJUBUS_SERIES_LENGTH_MAX);

        uint8_t * buf = getDataBuf(answer);

        uint8_t gByte = MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES;

        gByte = addAck(gByte);

        buf[0] = gByte;

        buf++;

        for(uint8_t i=0; i<size; i++)
        {
            buf[i] = series[i].regNum;
        }

        answer.buf[MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET] = (1+size);

        wrapAnswer(answer);
    }






} /* namespace milliganjubus */
