#include "milliganjubus_master_session.h"

namespace milliganjubus
{

    void MasterSession :: init( ISerialPort & port,
                                OnAnswerReceived onAnswerReceived,
                                callback::VoidCallback onConnectionFailure,
                                OnAnswerReceived onIrrelevantAnswerReceived )
    {
        m_port = &port;

        // порт наш навечно
#ifdef UART_USE_FREERTOS
        BaseType_t result;
        result = osSemaphoreTake( m_port->getOwnerMutex(), 0 );

        // никто не смеет занимать порт ганджубуса!
        UMBA_ASSERT( result == pdTRUE );

#else
        UMBA_ASSERT( ! m_port->isLocked() );
        m_port->lock();
#endif

        // для тестов
        m_state = SessionStates::WAITING_REQUEST;

        // собранное входящее сообщение добавляется в сессию
        MsgComposer::OnMsgComposed_cb onMsgComposed = CALLBACK_BIND( *this, MasterSession::onAnswerComposed);
        m_composer.initMaster(onMsgComposed);

        m_onAnswerReceived = onAnswerReceived;
        m_onConnectionFailure = onConnectionFailure;
        m_onIrrelevantAnswer = onIrrelevantAnswerReceived;


    }

    void MasterSession :: onAnswerComposed( const milliganjubus::MilliMessage & answer)
    {
        (void)answer;
        UMBA_ASSERT(m_state == SessionStates::WAITING_ANSWER);

        m_isNewAnswer = true;
    }

    void MasterSession :: sendRequest( milliganjubus::MilliMessage & request )
    {
        UMBA_ASSERT(m_state == SessionStates::WAITING_REQUEST);

        // реквест копируется
        m_request = request;

        m_state = SessionStates::SENDING_REQUEST;
    }


    void MasterSession :: work( uint32_t curTime )
    {
        UMBA_ASSERT(m_port);

        m_curCallTime = curTime;

        switch(m_state)
        {
        // просто ждем
        case SessionStates::WAITING_REQUEST:

            break;

        case SessionStates::SENDING_REQUEST:
        {
            bool result = m_port->sendStaticArray( m_request.buf, tx_messages::getMsgSize(m_request.buf) );

            UMBA_ASSERT(result);

            m_lastRequestTime = m_curCallTime;

            m_state = SessionStates::WAITING_FOR_SENDING_COMPLETE;

            // ждем, пока сообщение отправляется - либо с помощью состояния, либо семафором
#ifdef UART_USE_FREERTOS

            BaseType_t res = osSemaphoreTake( m_port->getTransmitCompleteSem(), m_request_sending_timeout_max / portTICK_RATE_MS );

            UMBA_ASSERT(res == pdTRUE);

            m_state = SessionStates::WAITING_ANSWER;

#endif

            break;
        }

        case SessionStates::WAITING_FOR_SENDING_COMPLETE:

            if( m_port->isTransmitComplete() )
            {
                m_state = SessionStates::WAITING_ANSWER;
                return;
            }

            // запрос никак не отсылается
            if( curTime - m_lastRequestTime > m_request_sending_timeout_max )
            {
                UMBA_ASSERT_FAIL();
            }

            break;

        case SessionStates::WAITING_ANSWER:

#ifdef UART_USE_FREERTOS

            while(1)
            {
                BaseType_t result;
                uint8_t byte;

                result = osQueueReceive( m_port->getQueue(), (void *)&byte, m_answer_timeout_max / portTICK_RATE_MS );

                // TODO: это уж совсем костыль какой-то
                m_curCallTime = osTaskGetTickCount();

                if( result == pdTRUE )
                {
                    m_composer.compose( byte, m_answer );

                    if(m_isNewAnswer)
                    {
                        break;
                    }
                }
                else
                {
                    // таймаут превышен
                    break;
                }
            }

#else
            while( m_port->isNewByte() )
            {
                m_composer.compose( m_port->getByte(), m_answer );
            }
#endif

            // не слишком ли долго мы ждем
            if( m_curCallTime - m_lastRequestTime >= m_answer_timeout_max )
            {
                // повторы не помогают - связь потеряна
                if( m_repeatsCount >= m_repeats_max )
                {
                    m_repeatsCount = 0;

                    m_onConnectionFailure();

                    // дальше можно слать новое сообщение
                    m_state = SessionStates::WAITING_REQUEST;

                    return;
                }

                // попробуем повторить текущее сообщение еще раз
                m_repeatsCount++;

                m_state = SessionStates::SENDING_REQUEST;
                return;
            }

            // что-то пришло?
            if(! m_isNewAnswer )
            {
                return;
            }

            // что-то пришло!
            m_isNewAnswer = false;

            // проверяем, то ли это или не то

            // что-то не то
            if( ! isAnswerRelevant() )
            {
                if(m_onIrrelevantAnswer != 0)
                {
                    m_onIrrelevantAnswer(m_answer);
                    break;
                }

            }
            // то, что надо
            else
            {
                m_onAnswerReceived(m_answer);
            }


            m_repeatsCount = 0;
            m_state = SessionStates::WAITING_REQUEST;

            break;

        default:

            UMBA_ASSERT_FAIL();
            break;
        }
    }

    bool MasterSession :: isAnswerAdressValid(void) const
    {
        uint8_t reqAdr = m_request.buf[ MILLI_GANJUBUS_TX_MSG_ADR_OFFSET ];
        uint8_t ansAdr = m_answer.buf[ MILLI_GANJUBUS_RX_MSG_ADR_OFFSET ];

        if( reqAdr == MILLI_GANJUBUS_MSG_ADR_UNIVERSAL )
        {
            return true;
        }

        // на броадкаст не должно быть ответа и вообще броадкасты и посылать-то никто не должен
        if( reqAdr == MILLI_GANJUBUS_MSG_ADR_BROADCAST )
        {
            UMBA_ASSERT_FAIL();
        }

        if( reqAdr == ansAdr )
            return true;
        else
            return false;
    }

    bool MasterSession :: isAnswerRelevant(void) const
    {
        // адрес должен быть правильным
        if( ! isAnswerAdressValid() )
            return false;

        // ф-код должен совпадать

        uint8_t reqFcode = getFcode( m_request.buf[ MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET ] );
        uint8_t ansFcode = getFcode( m_answer.buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ] );

        if( reqFcode != ansFcode )
            return false;


        // ответ об ошибке тоже валидный
        // но он отличается от нормального
        if( ! isGbyteAck(m_answer.buf[ MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET ]) )
        {
            return true;
        }

        // правильный ответ должен содержать те же номера регистров, что и запрос
        const uint8_t * reqDataBuf = m_request.buf + MILLI_GANJUBUS_TX_MSG_DATA_OFFSET + MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE;
        const uint8_t * ansDataBuf = m_answer.buf + MILLI_GANJUBUS_RX_MSG_DATA_OFFSET + MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE;

        uint8_t reqDataSize = tx_messages::getMsgSize( m_request.buf ) - MILLI_GANJUBUS_TX_MSG_SERVICE_FIELDS_SIZE - MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE;
        uint8_t ansDataSize = rx_messages::getMsgSize( m_answer.buf ) - MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE - MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE;

        // проверка размера
        switch(reqFcode)
        {
        case MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG:
            // в ответе должен быть только регистр
            if( ansDataSize != 1)
                return false;
            break;

        case MILLI_GANJUBUS_FCODE_READ_SINGLE_REG:
            // в ответе должен быть только регистр и его значение
            if( ansDataSize != 2)
                return false;
            break;

        case MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE:
            // в ответе должны быть только два номера регистров
            if( ansDataSize != 2)
                return false;
            break;

        case MILLI_GANJUBUS_FCODE_READ_REGS_RANGE:
            break;

        case MILLI_GANJUBUS_FCODE_READ_REGS_SERIES:
            // на каждый регистр приходится по два байта (адрес и значение)
            //  - значит регистров должно быть вдвое меньше чем данных в ответе
            if(ansDataSize != reqDataSize*2)
                return false;
            break;

        case MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES:
            // на каждый регистр в запросе уходит по два байта
            // в ответе данных должно быть вдвое меньше
            if(ansDataSize != reqDataSize/2)
                return false;
            break;

        default:

            UMBA_ASSERT_FAIL();
            break;
        }

        if( reqFcode == MILLI_GANJUBUS_FCODE_READ_REGS_RANGE || reqFcode == MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE)
        {
            // всего два регистра - начало и конец диапазона

            if( reqDataBuf[0] != ansDataBuf[0] )
                return false;

            if( reqDataBuf[1] != ansDataBuf[1] )
                return false;

            return true;

        }
        else if(reqFcode == MILLI_GANJUBUS_FCODE_READ_SINGLE_REG || reqFcode == MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG)
        {
            // всего один регистр
            if( reqDataBuf[0] != ansDataBuf[0] )
                return false;

            return true;

        }

        // ответ на чтение серий cодержит еще данные
        else if( reqFcode == MILLI_GANJUBUS_FCODE_READ_REGS_SERIES )
        {
            // в ответе номера регистров чередуются с данными
            for(uint8_t i=0, j=0; i<reqDataSize; ++i, j+=2)
            {
                if( reqDataBuf[i] != ansDataBuf[j] )
                    return false;
            }

            return true;

        }

        // ответ на запись  - данных не содержит
        else if( reqFcode == MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES )
        {
            uint8_t regs = reqDataSize/2;

            // в запросе номера регистров чередуются с данными
            for(uint8_t i=0, j=0; i<regs; ++i, j+=2)
            {
                if( reqDataBuf[j] != ansDataBuf[i] )
                    return false;
            }

            return true;

        }

        UMBA_ASSERT_FAIL();
        return false;
    }

} // namespace milliganjubus
