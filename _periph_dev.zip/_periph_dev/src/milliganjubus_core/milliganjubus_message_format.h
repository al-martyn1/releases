#pragma once

#include <stdint.h>
#include "project_config.h"


#include "crc/umba_crc_table.h"


/***************************************************************************************************
****************************************************************************************************

            В этом файле будет полное описание формата сообщений для MILLI_GANJU

****************************************************************************************************
***************************************************************************************************/

// максимальное число регистров в серии
#define MILLI_GANJUBUS_SERIES_LENGTH_MAX       5

// максимальная длина диапазона
#define MILLI_GANJUBUS_RANGE_LENGTH_MAX        8

// максимальная длина сообщения в байтах
#define MILLI_GANJUBUS_MESSAGE_SIZE_MAX        16

/*
====================================================================================================
                                      СМЕЩЕНИЯ И РАЗМЕРЫ ПОЛЕЙ
====================================================================================================
*/

/***************************************************************************************************
                                      ПРИЕМ

 | 1 байт | 1 байт | 1 байт  | 1 байт    |  1 байт  |      N байт      | 1 байт  |
 |  BB    |  ADR   |   SIZE  |  HEAD_CRC |  G-byte  | DATADATADATADATA | MSG_CRC |


***************************************************************************************************/

// размеры
#define MILLI_GANJUBUS_RX_MSG_START_SIZE          1
#define MILLI_GANJUBUS_RX_MSG_ADR_SIZE            1
#define MILLI_GANJUBUS_RX_MSG_SIZE_SIZE           1
#define MILLI_GANJUBUS_RX_MSG_HEAD_CRC_SIZE       1

#define MILLI_GANJUBUS_RX_MSG_G_BYTE_SIZE         1

#define MILLI_GANJUBUS_RX_MSG_MSG_CRC_SIZE        1

#define MILLI_GANJUBUS_RX_MSG_HEADER_SIZE         (MILLI_GANJUBUS_RX_MSG_START_SIZE +\
                                                   MILLI_GANJUBUS_RX_MSG_ADR_SIZE   +\
                                                   MILLI_GANJUBUS_RX_MSG_SIZE_SIZE  +\
                                                   MILLI_GANJUBUS_RX_MSG_HEAD_CRC_SIZE)

// смещения
#define MILLI_GANJUBUS_RX_MSG_START_OFFSET        0
#define MILLI_GANJUBUS_RX_MSG_ADR_OFFSET          (MILLI_GANJUBUS_RX_MSG_START_OFFSET    + MILLI_GANJUBUS_RX_MSG_START_SIZE)
#define MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET         (MILLI_GANJUBUS_RX_MSG_ADR_OFFSET      + MILLI_GANJUBUS_RX_MSG_ADR_SIZE)
#define MILLI_GANJUBUS_RX_MSG_HEAD_CRC_OFFSET     (MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET     + MILLI_GANJUBUS_RX_MSG_SIZE_SIZE)


#define MILLI_GANJUBUS_RX_MSG_DATA_OFFSET         (MILLI_GANJUBUS_RX_MSG_HEAD_CRC_OFFSET + MILLI_GANJUBUS_RX_MSG_HEAD_CRC_SIZE)


#define MILLI_GANJUBUS_RX_MSG_G_BYTE_OFFSET       MILLI_GANJUBUS_RX_MSG_DATA_OFFSET


// размер всех служебных полей
#define MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE    (MILLI_GANJUBUS_RX_MSG_HEADER_SIZE + MILLI_GANJUBUS_RX_MSG_MSG_CRC_SIZE)


// допустимые размеры
#define MILLI_GANJUBUS_RX_MSG_SIZE_MIN (MILLI_GANJUBUS_RX_MSG_START_SIZE    + \
                                        MILLI_GANJUBUS_RX_MSG_ADR_SIZE      + \
                                        MILLI_GANJUBUS_RX_MSG_SIZE_SIZE     + \
                                        MILLI_GANJUBUS_RX_MSG_HEAD_CRC_SIZE + \
                                        MILLI_GANJUBUS_RX_MSG_MSG_CRC_SIZE   )


#define MILLI_GANJUBUS_RX_MSG_SIZE_MAX    MILLI_GANJUBUS_MESSAGE_SIZE_MAX


#define MILLI_GANJUBUS_MSG_ADR_UNIVERSAL  0xFF
#define MILLI_GANJUBUS_MSG_ADR_BROADCAST  0x00

namespace milliganjubus
{

    namespace rx_messages
    {

        const uint8_t correctStartByte = 0xBB;

        inline bool isHeaderCrcValid( const uint8_t * buf )
        {
            uint8_t trueCrc = umba_crc8_table(buf, MILLI_GANJUBUS_RX_MSG_START_SIZE + MILLI_GANJUBUS_RX_MSG_ADR_SIZE + MILLI_GANJUBUS_RX_MSG_SIZE_SIZE);

            uint8_t receivedCrc = buf[ MILLI_GANJUBUS_RX_MSG_HEAD_CRC_OFFSET ];

            return trueCrc == receivedCrc;
        }

        inline uint8_t getMsgSize( const uint8_t * buf)
        {
            return buf[ MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET ];
        }

        inline uint8_t getMsgCrc( const uint8_t * buf)
        {
            return buf[ getMsgSize(buf) - MILLI_GANJUBUS_RX_MSG_MSG_CRC_SIZE];
        }

        inline bool isMsgCrcValid( const uint8_t * buf)
        {
            UMBA_ASSERT( getMsgSize(buf) >= MILLI_GANJUBUS_RX_MSG_SIZE_MIN );
            UMBA_ASSERT( getMsgSize(buf) <= MILLI_GANJUBUS_RX_MSG_SIZE_MAX );

            uint8_t trueCrc = umba_crc8_table(buf, getMsgSize(buf) - MILLI_GANJUBUS_RX_MSG_MSG_CRC_SIZE);

            uint8_t receivedCrc = getMsgCrc(buf);

            return trueCrc == receivedCrc;
        }


    }

}



/***************************************************************************************************
                                      ОТПРАВЛЕНИЕ

 | 1 байт | 1 байт | 1 байт  | 1 байт    |  1 байт  |      N байт      | 1 байт  |
 |  BB    |  ADR   |   SIZE  |  HEAD_CRC |  G-byte  | DATADATADATADATA | MSG_CRC |


***************************************************************************************************/

// размеры
#define MILLI_GANJUBUS_TX_MSG_START_SIZE          MILLI_GANJUBUS_RX_MSG_START_SIZE
#define MILLI_GANJUBUS_TX_MSG_ADR_SIZE            MILLI_GANJUBUS_RX_MSG_ADR_SIZE
#define MILLI_GANJUBUS_TX_MSG_SIZE_SIZE           MILLI_GANJUBUS_RX_MSG_SIZE_SIZE
#define MILLI_GANJUBUS_TX_MSG_HEAD_CRC_SIZE       MILLI_GANJUBUS_RX_MSG_HEAD_CRC_SIZE

#define MILLI_GANJUBUS_TX_MSG_G_BYTE_SIZE         1

#define MILLI_GANJUBUS_TX_MSG_MSG_CRC_SIZE        1

#define MILLI_GANJUBUS_TX_MSG_HEADER_SIZE         (MILLI_GANJUBUS_TX_MSG_START_SIZE +\
                                                   MILLI_GANJUBUS_TX_MSG_ADR_SIZE   +\
                                                   MILLI_GANJUBUS_TX_MSG_SIZE_SIZE  +\
                                                   MILLI_GANJUBUS_TX_MSG_HEAD_CRC_SIZE)

// смещения
#define MILLI_GANJUBUS_TX_MSG_START_OFFSET        0
#define MILLI_GANJUBUS_TX_MSG_ADR_OFFSET          (MILLI_GANJUBUS_TX_MSG_START_OFFSET    + MILLI_GANJUBUS_TX_MSG_START_SIZE)
#define MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET         (MILLI_GANJUBUS_TX_MSG_ADR_OFFSET      + MILLI_GANJUBUS_TX_MSG_ADR_SIZE)
#define MILLI_GANJUBUS_TX_MSG_HEAD_CRC_OFFSET     (MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET     + MILLI_GANJUBUS_TX_MSG_SIZE_SIZE)


#define MILLI_GANJUBUS_TX_MSG_DATA_OFFSET         (MILLI_GANJUBUS_TX_MSG_HEAD_CRC_OFFSET + MILLI_GANJUBUS_TX_MSG_HEAD_CRC_SIZE)


#define MILLI_GANJUBUS_TX_MSG_G_BYTE_OFFSET       MILLI_GANJUBUS_TX_MSG_DATA_OFFSET


// размер всех служебных полей
#define MILLI_GANJUBUS_TX_MSG_SERVICE_FIELDS_SIZE    (MILLI_GANJUBUS_TX_MSG_HEADER_SIZE + MILLI_GANJUBUS_TX_MSG_MSG_CRC_SIZE)


// допустимые размеры
#define MILLI_GANJUBUS_TX_MSG_SIZE_MIN (MILLI_GANJUBUS_TX_MSG_START_SIZE    + \
                                        MILLI_GANJUBUS_TX_MSG_ADR_SIZE      + \
                                        MILLI_GANJUBUS_TX_MSG_SIZE_SIZE     + \
                                        MILLI_GANJUBUS_TX_MSG_HEAD_CRC_SIZE + \
                                        MILLI_GANJUBUS_TX_MSG_MSG_CRC_SIZE   )


#define MILLI_GANJUBUS_TX_MSG_SIZE_MAX   MILLI_GANJUBUS_MESSAGE_SIZE_MAX


namespace milliganjubus
{

    namespace tx_messages
    {
        const uint8_t correctStartByte = 0xBB;

        inline void setMsgFullSize(uint8_t * buf, uint8_t size)
        {
            buf[ MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET ] = size;
        }

        inline uint8_t getMsgSize(const uint8_t * buf)
        {
            return buf[ MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET ];
        }

        inline uint8_t getMsgCrcOffset(const uint8_t size)
        {
            return size - MILLI_GANJUBUS_TX_MSG_MSG_CRC_SIZE;
        }

        inline void wrapMsg(uint8_t * buf, uint8_t dataSize, uint8_t adr)
        {
            UMBA_ASSERT(dataSize + MILLI_GANJUBUS_TX_MSG_SERVICE_FIELDS_SIZE <= MILLI_GANJUBUS_TX_MSG_SIZE_MAX );

            buf[ MILLI_GANJUBUS_TX_MSG_START_OFFSET ] =  correctStartByte;
            buf[ MILLI_GANJUBUS_TX_MSG_ADR_OFFSET ] = adr;
            buf[ MILLI_GANJUBUS_TX_MSG_SIZE_OFFSET ] = dataSize + MILLI_GANJUBUS_TX_MSG_SERVICE_FIELDS_SIZE;

            buf[ MILLI_GANJUBUS_TX_MSG_HEAD_CRC_OFFSET ] = umba_crc8_table(buf, MILLI_GANJUBUS_TX_MSG_HEADER_SIZE - MILLI_GANJUBUS_TX_MSG_HEAD_CRC_SIZE);

            buf[ getMsgCrcOffset( getMsgSize(buf) ) ] = umba_crc8_table( buf, getMsgSize(buf) - MILLI_GANJUBUS_TX_MSG_MSG_CRC_SIZE);
        }

    }


} // namespace milliganjubus
