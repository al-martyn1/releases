#pragma once

#include "project_config.h"

#ifdef USE_FREERTOS

#include "milliganjubus_synchronizer.h"
#include "milliganjubus_master_session.h"

namespace milliganjubus
{
    struct SynchronizerParams
    {
        SynchronizerParams() :
            port(0),
            synchronizer(0),
            answerTimeoutMs(100)
        {}


        ISerialPort * port;
        Synchronizer * synchronizer;
        uint32_t answerTimeoutMs;
    };

    void freeRtosSynchronizerTask(void * syncParams);
}

#endif

