/***************************************************************************************************
 Общий файл для библиотеки
***************************************************************************************************/

#pragma once

#include "milliganjubus_message_format.h"

#include <cstring>

/***************************************************************************************************
                            Глобальные дефайны
***************************************************************************************************/

// ACK-NACK
#define MILLI_GANJUBUS_ACK     0x0A
#define MILLI_GANJUBUS_NACK    0x0E

// F-Codes
#define MILLI_GANJUBUS_FCODE_MIN                           1

#define MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG              1     //Записать одиночный регистр
#define MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE              2     //Записать диапазон регистров
#define MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES             3     //Записать серию разрозненных регистров
#define MILLI_GANJUBUS_FCODE_READ_SINGLE_REG               4     //Считать одиночный регистр
#define MILLI_GANJUBUS_FCODE_READ_REGS_RANGE               5     //Считать диапазон регистров
#define MILLI_GANJUBUS_FCODE_READ_REGS_SERIES              6     //Считать разрозненные регистры

#define MILLI_GANJUBUS_FCODE_MAX                           6

// коды ошибок
#define  MILLI_GANJUBUS_ERRCODE_WRONG_FCODE             1   // Неверный код функции
#define  MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS           2   // Неверный адрес регистра
#define  MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM         3   // Ошибочное количество данных


/***************************************************************************************************
                            Глобальные типы данных
***************************************************************************************************/

namespace milliganjubus
{

    // структура, в которую гарантированно влезет любое сообщение для миллиганджубуса
    struct MilliMessage
    {
        uint8_t buf[ MILLI_GANJUBUS_MESSAGE_SIZE_MAX ];

        bool operator==( const MilliMessage & other) const
        {
            if( std::memcmp(buf, other.buf, MILLI_GANJUBUS_MESSAGE_SIZE_MAX) == 0)
                return true;
            else
                return false;
        }

        bool operator!=( const MilliMessage & other) const
        {
            return !(*this == other);
        }
    };
}

/***************************************************************************************************
                            Глобальные inline функции
***************************************************************************************************/
namespace milliganjubus
{
    /*
    ====================================================================================================
                                           G-Byte:

    | Старшая тетрада | Младшая тетрада |
    |     ACK         |   F-Code        |
    ====================================================================================================
    */

    inline bool isGbyteAck( uint8_t gByte)
    {
        gByte = gByte >> 4;
        return gByte == MILLI_GANJUBUS_ACK;
    }

    inline uint8_t addAck( uint8_t gByte)
    {
        gByte |= MILLI_GANJUBUS_ACK << 4;
        return gByte;
    }

    inline uint8_t addNack( uint8_t gByte)
    {
        gByte |= MILLI_GANJUBUS_NACK << 4;
        return gByte;
    }

    inline uint8_t getFcode( uint8_t gByte)
    {
        return gByte & 0x0F; // отрезается старшая тетрада
    }

    inline bool isFcodeValid( uint8_t fCode )
    {
        if ( ( fCode >= MILLI_GANJUBUS_FCODE_MIN ) && ( fCode <= MILLI_GANJUBUS_FCODE_MAX ) )
            return true;
        else
            return false;
    }

}

/***************************************************************************************************
                            Глобальные прототипы функций
***************************************************************************************************/



