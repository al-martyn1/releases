#include "milliganjubus_request_processor.h"
#include "milliganjubus_common.h"

namespace milliganjubus
{

    void RequestProcessor :: parseRequest( const MilliMessage & request, MilliMessage & answer  )
    {

        UMBA_ASSERT(this->m_table);
        UMBA_ASSERT(this->m_answerCreator);

        uint8_t fCode = getMsgFcode(request);

        if(! isFcodeValid( fCode ) )
        {
            m_answerCreator->createNackAnswer(fCode, MILLI_GANJUBUS_ERRCODE_WRONG_FCODE, answer);
            return;
        }

        // лочим таблицу, ибо дальше будут записи и чтения потенциально многобайтных значений
        IMilliRegTable::Lock lock( m_table );

        switch(fCode)
        {

        case MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG:
            parseWriteSingleReq(request, answer);
            break;
        case MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE:
            parseWriteRangeReq(request, answer);
            break;
        case MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES:
            parseWriteSeriesReq(request, answer);
            break;

        case MILLI_GANJUBUS_FCODE_READ_SINGLE_REG:
            parseReadSingleReq(request, answer);
            break;
        case MILLI_GANJUBUS_FCODE_READ_REGS_RANGE:
            parseReadRangeReq(request, answer);
            break;
        case MILLI_GANJUBUS_FCODE_READ_REGS_SERIES:
            parseReadSeriesReq(request, answer);
            break;

        default:
            UMBA_ASSERT_FAIL();
            break;
        }

        return;
    }


    uint8_t RequestProcessor :: getDataSize( const MilliMessage & request ) const
    {
        return rx_messages::getMsgSize(request.buf) - MILLI_GANJUBUS_RX_MSG_SERVICE_FIELDS_SIZE;
    }


    /*
    ====================================================================================================
                                          Валидаторы
    ====================================================================================================
    */

    bool RequestProcessor :: isSingleRegValid(uint8_t regNum) const
    {
        if( regNum > m_table->getRwMaxRegNum() )
            return false;
        else if( regNum < m_table->getRoMinRegNum() )
            return false;


        else if( regNum > m_table->getRoMaxRegNum() && regNum < m_table->getRwMinRegNum() )
            return false;
        else
            return true;
    }

    bool RequestProcessor :: isRangeValid(uint8_t start, uint8_t end) const
    {
        if( ! isSingleRegValid(start) )
            return false;

        if( ! isSingleRegValid(end) )
            return false;

        if( start < m_table->getRwMinRegNum() && end > m_table->getRwMinRegNum())
            return false;

        if( start > end)
            return false;

        if( end - start >= MILLI_GANJUBUS_RANGE_LENGTH_MAX )
            return false;

        return true;
    }

    bool RequestProcessor :: isReadSeriesValid( const MilliMessage & request ) const
    {
        const uint8_t * buf = this->getDataBuf(request);

        // в этом реквесте лежат подряд номера регистров
        // а других данных нет
        uint8_t size = this->getDataSize(request);

        size--; // gbyte не в счет

        for(uint8_t i = 0; i < size; ++i)
        {
            if(! isSingleRegValid( buf[i] ) )
                return false;
        }

        return true;
    }

    bool RequestProcessor :: isWriteSeriesValid( const MilliMessage & request ) const
    {
        const uint8_t * buf = this->getDataBuf(request);
        uint8_t size = this->getDataSize(request);

        size--; //gbyte is ignored

        // в этом реквесте лежат подряд пары "номер регистра - значение"
        for(uint8_t i = 0; i < size; i+=2)
        {
            if(! isSingleRegValid( buf[i] ) )
                return false;

            if( isRegisterRo( buf[i] ) )
                return false;
        }

        return true;
    }


    bool RequestProcessor :: isRegisterRo( uint8_t regNum ) const
    {
        if( regNum >= m_table->getRoMinRegNum() && regNum <= m_table->getRoMaxRegNum() )
            return true;
        else
            return false;
    }


    /***************************************************************************************************
                                          Парсеры Чтения
    ***************************************************************************************************/



    void RequestProcessor :: parseReadSingleReq( const MilliMessage & request, MilliMessage & answer )
    {
        // в сообщении лежит номер регистра, который нужно прочесть
        const uint8_t * buf = getDataBuf(request);

        // в сообщении должен быть только gByte и номер регистра
        if( getDataSize(request) != 1+1 )
        {
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_READ_SINGLE_REG, MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, answer );
            return;
        }

        uint8_t regNum = buf[0];


        if(! isSingleRegValid(regNum))
        {
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_READ_SINGLE_REG, MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, answer );
            return;
        }


        uint8_t value = m_table->getRegVal(regNum);

        m_answerCreator->createReadSingleAnswer(regNum, value, answer);


    }

    void RequestProcessor :: parseReadRangeReq( const MilliMessage & request, MilliMessage & answer )
    {

        // в сообщении должен быть только gByte и диапазон
        if( getDataSize(request) != 1+2 )
        {
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, answer );
            return;
        }

        // в реквесте лежат начало и конец диапазона
        const uint8_t * buf = getDataBuf(request);
        uint8_t startReg = buf[0];
        uint8_t endReg = buf[1];


        if(! isRangeValid(startReg, endReg) )
        {
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_READ_REGS_RANGE, MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, answer );
            return;
        }

        AnswerCreator::Register range[ MILLI_GANJUBUS_RANGE_LENGTH_MAX ];

        for(uint16_t i=startReg, j=0; i<=endReg; i++, j++)
        {
            range[j].regNum = (uint8_t)i;
            range[j].value = m_table->getRegVal( (uint8_t)i );
        }

        m_answerCreator->createReadRangeAnswer(startReg, endReg, range, answer);

    }

    void RequestProcessor :: parseReadSeriesReq( const MilliMessage & request, MilliMessage & answer )
    {

        // правильные ли там номера регистров?
        if( ! isReadSeriesValid(request) )
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_READ_REGS_SERIES, MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, answer );
            return;
        }


        // в реквесте лежат только номера регистров, которые нужно читать
        const uint8_t * buf = getDataBuf(request);

        uint8_t size = this->getDataSize(request);

        // gByte нас не интересует
        size--;

        // серии из нуля регистров не бывает
        if(size == 0 || size > MILLI_GANJUBUS_SERIES_LENGTH_MAX)
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_READ_REGS_SERIES, MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, answer );
            return;
        }

        AnswerCreator::Register series[ MILLI_GANJUBUS_SERIES_LENGTH_MAX ];


        for(uint8_t i=0; i<size; ++i)
        {
            series[i].regNum = buf[i];
            series[i].value = m_table->getRegVal( buf[i] );
        }


        m_answerCreator->createReadSeriesAnswer(series, size, answer);
        return;
    }



    /***************************************************************************************************
                                           Парсеры Записи
    ***************************************************************************************************/



    void RequestProcessor :: parseWriteSingleReq( const MilliMessage & request, MilliMessage & answer )
    {

        // в сообщении лежит номер регистра и значение
        uint8_t dataSize = getDataSize(request);

        // правильное ли количество данных? Должно быть gByte + regNum + value
        if( dataSize != 1+1+1)
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, answer );
            return;
        }

        const uint8_t * buf = getDataBuf( request );

        uint8_t regNum = buf[0];

        // правильный ли номер регистра?
        if( ! isSingleRegValid(regNum) )
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, answer );
            return;
        }

        // попытка записи в RO-регистр
        if( isRegisterRo(regNum) )
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_WRITE_SINGLE_REG, MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, answer );
            return;
        }

        uint8_t val = buf[1];
        m_table->setRegVal(regNum, val);

        // реквест больше не нужен

        m_answerCreator->createWriteSingleAnswer(regNum, answer);
        return;
    }

    void RequestProcessor :: parseWriteRangeReq( const MilliMessage & request, MilliMessage & answer )
    {
        // в сообщении лежит номер начала, номер конца и значения

        const uint8_t * buf = getDataBuf(request);
        uint8_t startReg = buf[0];
        uint8_t endReg = buf[1];

        // допустимый ли диапазон?
        if( ! isRangeValid(startReg, endReg) )
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, answer );
            return;
        }

        // не ридонли ли он?
        if( isRegisterRo(startReg) || isRegisterRo(endReg) )
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, answer );
            return;
        }


        // дальше идут значения
        buf+=2;

        uint8_t numberOfRegs = endReg - startReg + 1; // c первого по последний

        // правильное ли количество данных?
        uint8_t dataSize = getDataSize(request);

        dataSize--; // gByte is ignored

        // правильное ли количество данных? (должно быть два номера и соответствующее количество значений)
        if( dataSize != 1+1+numberOfRegs)
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_WRITE_REGS_RANGE, MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, answer );
            return;
        }


        for(uint8_t i=0; i<numberOfRegs; ++i)
        {
            m_table->setRegVal( startReg+i, buf[i] );
        }


        m_answerCreator->createWriteRangeAnswer(startReg, endReg, answer);

    }

    void RequestProcessor :: parseWriteSeriesReq( const MilliMessage & request, MilliMessage & answer )
    {
        // правильные ли номера регистров? нет ли среди них RO-регистров?
        if( ! isWriteSeriesValid(request) )
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES, MILLI_GANJUBUS_ERRCODE_WRONG_ADDRESS, answer );
            return;
        }


        // в сообщении лежат пары "номер регистра" - "значение"

        const uint8_t * buf = getDataBuf(request);

        // размер данных без ф-кода
        uint8_t dataSize = getDataSize(request);

        dataSize--; // gByte ignored

        // к каждому регистру должно быть значение и все по 1 байт
        if( dataSize % 2 || dataSize == 0 )
        {
            // NACK
            m_answerCreator->createNackAnswer( MILLI_GANJUBUS_FCODE_WRITE_REGS_SERIES, MILLI_GANJUBUS_ERRCODE_WRONG_BYTES_NUM, answer );
            return;
        }

        uint8_t curRegNum = 0;
        uint8_t curVal = 0;

        AnswerCreator::Register series[ MILLI_GANJUBUS_SERIES_LENGTH_MAX ];

        for(uint8_t i=0; i<dataSize; i+=2)
        {
            curRegNum = buf[i];
            curVal = buf[i+1];
            m_table->setRegVal( curRegNum, curVal );

            series[i/2].regNum = curRegNum;
        }


        m_answerCreator->createWriteSeriesAnswer(series, dataSize/2, answer);
    }


} /* namespace milliganjubus */
