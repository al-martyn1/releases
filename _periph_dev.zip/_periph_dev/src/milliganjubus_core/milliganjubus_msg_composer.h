#pragma once

#include "project_config.h"
#include <algorithm>
#include "milliganjubus_message_format.h"
#include "callbacks/callbacks.h"
#include "milliganjubus_common.h"

namespace milliganjubus
{

    class MsgComposer
    {

    public:

        typedef callback::Callback< void ( const MilliMessage & ) > OnMsgComposed_cb;

        MsgComposer() :
            m_onMsgComposed(),
            m_counter(0),
            m_unread(0),
            m_curState(States::HEADER),
            m_SlaveAdr(MILLI_GANJUBUS_MSG_ADR_UNIVERSAL),
            m_isMaster(false)
        {
            ;
        }

        void compose(uint8_t byte, MilliMessage & outMsg);

        void initSlave( OnMsgComposed_cb onMessageComposed, uint8_t slaveAdr)
        {
            this->m_onMsgComposed = onMessageComposed;

            m_SlaveAdr = slaveAdr;

            m_isMaster = false;
        }

        void initMaster( OnMsgComposed_cb onMessageComposed )
        {
            this->m_onMsgComposed = onMessageComposed;

            m_isMaster = true;
        }

        bool isHeaderValid( const uint8_t * buf, uint8_t count) const;


    protected:

        void resetOnHeaderError(uint8_t * buf);

        void resetOnCrcError(uint8_t * buf);

        // обнуляет все
        void resetOnComplete(void)
        {
            m_counter = 0;
            m_curState = States::HEADER;

        }

        STRONG_ENUM(States, HEADER, DATA);

        OnMsgComposed_cb m_onMsgComposed;
        uint8_t m_counter;
        uint8_t m_unread;

        States m_curState;

        uint8_t m_SlaveAdr;

        // не хочется усложнять иерархию ради такой мелочи
        bool m_isMaster;

    };


} // namespace milliganjubus
