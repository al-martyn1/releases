#pragma once

#include "project_config.h"
#include "milliganjubus_slave.h"
#include "milliganjubus_master_session.h"

namespace milliganjubus
{

    class Synchronizer
    {

    public:

        explicit Synchronizer( uint32_t connectionFailuresMax = 20 ) :
            m_connectionFailuresMax(connectionFailuresMax),
            m_curCallTime(0),
            m_slaves(),
            m_curSlave(0),
            m_curRequest(),
            m_curAnswer(),
            m_sendRequest(0),
            m_state(States::SEARCH)
        {

        }

        typedef callback::Callback<void (milliganjubus::MilliMessage &)> SendRequest;

        void init(SendRequest sendRequest);

        void addSlave(milliganjubus::Slave & slave);

        void work(uint32_t curTime);

        // исключительно для тестов, обнуляет массив слейвов
        void deInit(void);

        // эти трое публичные чисто для простоты тестирования
        void onRelevantAnswerReceived( const milliganjubus::MilliMessage & answer);
        void onConnectionFailure(void);

        void panicOnIrrelevantAnswerReceived( const milliganjubus::MilliMessage & answer);
        void ignoreIrrelevantAnswer( const milliganjubus::MilliMessage & answer);

    protected:

        const uint32_t m_connectionFailuresMax;

        STRONG_ENUM(States, SEARCH, WAIT_ANSWER);


        // копирование запрещено
        Synchronizer( const Synchronizer & );
        Synchronizer & operator=( Synchronizer s );

        bool isRequestRequired(void);

        uint32_t m_curCallTime;

        milliganjubus::Slave * m_slaves[ MILLIGANJUBUS_SLAVES_MAX ];

        uint8_t m_curSlave;
        milliganjubus::MilliMessage m_curRequest;
        milliganjubus::MilliMessage m_curAnswer;

        SendRequest m_sendRequest;

        States m_state;

        uint8_t m_lastRwSlave;


    };

}// namespace
