#include "milliganjubus_msg_composer.h"

namespace milliganjubus
{

    void MsgComposer :: compose( uint8_t byte, MilliMessage & outMsg)
    {
        uint8_t * buf = outMsg.buf;
        buf[m_counter] = byte;

        m_unread = 1;

        while(m_unread > 0)
        {
            m_unread--;

            switch(m_curState)
            {
            case States::HEADER:

                if(! isHeaderValid(buf, m_counter) )
                {
                    resetOnHeaderError(buf);
                    break;
                }

                m_counter++;

                if( m_counter == MILLI_GANJUBUS_RX_MSG_HEADER_SIZE )
                {
                    m_curState = States::DATA;
                }

                break;

            case States::DATA:

                if( m_counter < (rx_messages::getMsgSize(buf) - MILLI_GANJUBUS_RX_MSG_MSG_CRC_SIZE) )
                {
                    m_counter++;
                    break;
                }

                if(! rx_messages::isMsgCrcValid(buf) )
                {
                    resetOnCrcError(buf);
                    break;
                }

                UMBA_ASSERT(m_onMsgComposed != 0);

                m_onMsgComposed(outMsg);
                resetOnComplete();

                break;

            default:

                UMBA_ASSERT_FAIL();
                break;
            }

        }
    }

    bool MsgComposer :: isHeaderValid( const uint8_t * buf, uint8_t count) const
    {
        switch(count)
        {

        case MILLI_GANJUBUS_RX_MSG_START_OFFSET:
            if(buf[count] == rx_messages::correctStartByte)
                return true;
            else
                return false;

        case MILLI_GANJUBUS_RX_MSG_ADR_OFFSET:

            // мастер должен слышать всех
            if( m_isMaster )
            {
                return true;
            }

            if( buf[count] == MILLI_GANJUBUS_MSG_ADR_BROADCAST ||
                    buf[count] == MILLI_GANJUBUS_MSG_ADR_UNIVERSAL ||
                    buf[count] == m_SlaveAdr )
            {
                return true;
            }

            return false;

        case MILLI_GANJUBUS_RX_MSG_SIZE_OFFSET:
            if( buf[count] > MILLI_GANJUBUS_RX_MSG_SIZE_MAX || buf[count] < MILLI_GANJUBUS_RX_MSG_SIZE_MIN )
                return false;
            else
                return true;

        case MILLI_GANJUBUS_RX_MSG_HEAD_CRC_OFFSET:
            return rx_messages::isHeaderCrcValid(buf);

        default:
            UMBA_ASSERT_FAIL();
            return false;

        }
    }

    void MsgComposer :: resetOnHeaderError( uint8_t * buf)
    {
        if(m_counter != 0)
        {
            resetOnCrcError(buf);
        }
    }

    // ищет в буфере старт-байт и сдвигает буфер на нужное кол-во элементов влево
    void MsgComposer :: resetOnCrcError( uint8_t * buf)
    {
        m_curState = States::HEADER;

        uint8_t max = m_counter + m_unread;

        for(uint8_t i = MILLI_GANJUBUS_RX_MSG_START_OFFSET + 1; i <= max; i++)
        {
            // ищем старт-байт
            if( buf[i] == rx_messages::correctStartByte )
            {
                //нашли - сдвигаем этот кусок буфера в начало
                std::copy(buf + i, buf + max + 1, buf);

                m_unread = max - i;
                m_counter = 1;
                return;
            }
        }

        // не нашли
        m_counter = 0;
        m_unread = 0;
    }


}// namespace milliganjubus
