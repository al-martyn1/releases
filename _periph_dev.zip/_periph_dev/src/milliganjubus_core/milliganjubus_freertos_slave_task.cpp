#include "milliganjubus_freertos_slave_task.h"

#ifdef USE_FREERTOS

namespace milliganjubus
{
    void freeRtosSlaveTask( void * slaveSession )
    {
        SlaveSession * session = (SlaveSession *)slaveSession;

        while( OS_IS_RUNNING )
        {
            session->work( osTaskGetTickCount() );

            osTaskYIELD();
        }
    }
}

#endif

