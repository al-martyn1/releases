#pragma once

#include "visca/camera.h"
//#include "registers/tvko.h"
#include "visca/camera.h"
#include <utility>

namespace camera
{
    class Worker
    {
        public:
            
        Worker( milliganjubus::IMilliRegTable * t, ISerialPort * p ) : m_table( t ),
                                                   m_port( p )
        {
        }
         
        void init( void )
        {
            m_camera.init( m_port );
        }
    
        void work( uint32_t time );

        private:
        
        enum class States{ON_OFF, U8, U16, MULTI};
            
        const std::pair<uint8_t, Codes> m_on_off_reg_nums[11] = { // 12
            { tvko::rw::camera_power_u8           , Codes::POWER                    }, // on = 1/off = 0
            { tvko::rw::digital_zoom_u8           , Codes::D_ZOOM                   }, // on = 1/off = 0
            { tvko::rw::auto_focus_u8             , Codes::AUTO_FOCUS               }, // on = 1/off = 0
            { tvko::rw::backlight_compensation_u8 , Codes::BACKLIGHT_COMPENSATION   }, // on = 1/off = 0
            { tvko::rw::defog_u8                  , Codes::DEFOG                    }, // on = 1/off = 0
            { tvko::rw::high_resolution_mode_u8   , Codes::HIGH_RESOLUTION_MODE     }, // on = 1/off = 0
            { tvko::rw::mirror_u8                 , Codes::MIRROR                   }, // on = 1/off = 0
            { tvko::rw::black_white_u8            , Codes::BLACK_WHITE              }, // on = 1/off = 0
            { tvko::rw::flip_u8                   , Codes::FLIP                     }, // on = 1/off = 0
            { tvko::rw::infrared_mode_u8          , Codes::INFRARED_MODE            }, // on = 1/off = 0
            { tvko::rw::auto_infrared_mode_u8     , Codes::AUTO_INFRARED_MODE       }//, // on = 1/off = 0
            //{ tvko::rw::color_enhance_u8          , Codes::COLOR_ENHANCE            } // on = 1/off = 0
        };
            
        const std::pair<uint8_t, Codes> m_u8_reg_nums[13] = {
            { tvko::rw::zoom_speed_s8                  , Codes::ZOOM                },// от -8 до 8
            { tvko::rw::focus_speed_s8                 , Codes::FOCUS               },// от -8 до 8
            { tvko::rw::infrared_correction_u8         , Codes::INFRARED_CORRECTION },// standart = 0, ir_light = 0x01
            { tvko::rw::white_balance_u8               , Codes::WHITE_BALANCE       },// auto = 0, manual = 0x05, sodium lamp = 0x07
            { tvko::rw::red_gain_u8                    , Codes::RED_GAIN            },// от 0 до 255
            { tvko::rw::blue_gain_u8                   , Codes::BLUE_GAIN           },// от 0 до 255
            { tvko::rw::automatic_exposure_u8          , Codes::AUTOMATIC_EXPOSURE  },// full auto = 0, manual = 0x03, shutter_priority = 0x0a, iris_priority = 0x0b, bright = 0x0d
            { tvko::rw::shutter_u8                     , Codes::SHUTTER             },// от 0x0 до 0x15, '0x0' - 1/1sec; '0x15' - 1/10000sec
            { tvko::rw::iris_u8                        , Codes::IRIS                },// от 0x0 до 0x11, '0x0' - close; '0x01' - f28; '0x11' - f1.6
            { tvko::rw::gain_u8                        , Codes::GAIN                },// от 0x0 до 0x0f
            { tvko::rw::bright_u8                      , Codes::BRIGHT              },// от 0x0 до 0x1f
            { tvko::rw::auto_infrared_mode_threshold_u8, Codes::AUTO_INFRARED_MODE  }, // тут пределы не нашёл в даташите
            { tvko::rw::stabilizer_u8                  , Codes::STABILIZER          }// on = 1/off = 0/hold = 2
        };
        
        States m_state = States::ON_OFF;
        
        std::pair<uint8_t, Codes> m_activeRegNum{0, Codes::POWER};
        
        milliganjubus::IMilliRegTable * m_table;
        ISerialPort * m_port;
        Camera m_camera;
        
        //значения для записи в камеру
        Variant m_v = Variant::OFF;
        uint8_t m_u8 = 0;
        uint16_t m_u16 = 0;
        uint8_t m_multi[8] = {0};
    };
}

