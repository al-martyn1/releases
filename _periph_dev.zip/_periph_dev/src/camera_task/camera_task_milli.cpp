#include "camera_task_milli.h"

namespace camera
{
    
    void Worker::work( uint32_t time )
    {
        m_camera.work( time );
        
        switch ( m_state )
        {
            case States::ON_OFF:
            {
                //если мы ничего не ждём, то ищем обновившийся регистр
                if( m_activeRegNum.first == 0 )
                {
                    //первый обновившийся будет записываться
                    for( auto regNum : m_on_off_reg_nums )
                    {
                        if( m_table->checkRegUpdate( regNum.first ) )
                        {
                            m_activeRegNum = regNum;
                            break;
                        }
                    }
                    //если всё обновлено - переключаемся на следующий тип команд
                    if( m_activeRegNum.first == 0 )
                    {
                        m_state = States::U8;
                        break;
                    }
                    
                    //берём значение из таблицы
                    if( m_table->getRegVal( m_activeRegNum.first ) == 1 )
                    {
                        m_v = Variant::ON;
                    }
                    else
                    {
                        m_v = Variant::OFF;
                    }
                }
                
                //дочитываем регистр
                if( m_camera.sendCommand( m_activeRegNum.second, m_v ))
                {
                    m_activeRegNum.first = 0;
                }
                
                
                break;
            }
            case States::U8:
            {
                //если мы ничего не ждём, то ищем обновившийся регистр
                if( m_activeRegNum.first == 0 )
                {
                    //первый обновившийся будет записываться
                    for( auto regNum : m_u8_reg_nums )
                    {
                        if( m_table->checkRegUpdate( regNum.first ) )
                        {
                            m_activeRegNum = regNum;
                            break;
                        }
                    }
                    //если всё обновлено - переключаемся на следующий тип команд
                    if( m_activeRegNum.first == 0 )
                    {
                        m_state = States::U16;
                        break;
                    }
                    
                    //берём значение из таблицы
                    m_u8 = m_table->getRegVal( m_activeRegNum.first );
                }
                
                //дочитываем регистр
                if( m_camera.sendCommand( m_activeRegNum.second, m_u8 ))
                {
                    m_activeRegNum.first = 0;
                }
                
                break;
            }
            case States::U16:
            {
                //если мы ничего не ждём, то проверим регистр зума
                if( m_activeRegNum.first == 0 )
                {
                    if( m_table->checkRegUpdate( tvko::rw::zoom_direct_position_s16 ) )
                    {
                        m_activeRegNum.first = tvko::rw::zoom_direct_position_s16;
                    }
                    else
                    {
                        m_state = States::MULTI;
                        break;
                    }
                    
                    //берём значение из таблицы
                    m_u16 = m_table->getReg16Val( m_activeRegNum.first );
                }
                
                //дочитываем регистр
                if( m_camera.sendCommandZoomDirect( m_u16 ) )
                {
                    m_activeRegNum.first = 0;
                }
                
                break;
            }
            case States::MULTI:
            {
                //если мы ничего не ждём, то проверим регистр зума
                if( m_activeRegNum.first == 0 )
                {
                
//                    if( m_table->checkRegUpdate( tvko::rw::color_enhance_fixed_color_cb_of_high_intensity_side_u8 ) &&
//                        m_table->checkRegUpdate( tvko::rw::color_enhance_fixed_color_cb_of_low_intensity_side_u8 )  &&
//                        m_table->checkRegUpdate( tvko::rw::color_enhance_fixed_color_cr_of_high_intensity_side_u8 ) &&
//                        m_table->checkRegUpdate( tvko::rw::color_enhance_fixed_color_cr_of_low_intensity_side_u8 )  &&
//                        m_table->checkRegUpdate( tvko::rw::color_enhance_fixed_color_y_of_high_intensity_side_u8 )  &&
//                        m_table->checkRegUpdate( tvko::rw::color_enhance_fixed_color_y_of_low_intensity_side_u8 )   && 
//                        m_table->checkRegUpdate( tvko::rw::color_enhance_hysteresis_width_u8 )                      &&
//                        m_table->checkRegUpdate( tvko::rw::color_enhance_threshold_level_u8 )  )
//                    {
//                        m_activeRegNum.first = tvko::rw::color_enhance_threshold_level_u8;
//                    }
//                    else
                    {
                        m_state = States::ON_OFF;
                        break;
                    }
                        Answer sendCommandColorEnhance( uint8_t thresholdLevel, uint8_t HysteresisWidth,
                                    uint8_t High_Y, uint8_t High_Cr, uint8_t High_Cb,
                                    uint8_t Low_Y, uint8_t Low_Cr, uint8_t Low_Cb );
                    //берём значение из таблицы
//                    m_multi[0] = m_table->getRegVal( tvko::rw::color_enhance_threshold_level_u8 );
//                    m_multi[1] = m_table->getRegVal( tvko::rw::color_enhance_hysteresis_width_u8 );
//                    m_multi[2] = m_table->getRegVal( tvko::rw::color_enhance_fixed_color_y_of_high_intensity_side_u8 );
//                    m_multi[3] = m_table->getRegVal( tvko::rw::color_enhance_fixed_color_cr_of_high_intensity_side_u8 );
//                    m_multi[4] = m_table->getRegVal( tvko::rw::color_enhance_fixed_color_cb_of_high_intensity_side_u8 );
//                    m_multi[5] = m_table->getRegVal( tvko::rw::color_enhance_fixed_color_y_of_low_intensity_side_u8 );
//                    m_multi[6] = m_table->getRegVal( tvko::rw::color_enhance_fixed_color_cr_of_low_intensity_side_u8 );
//                    m_multi[7] = m_table->getRegVal( tvko::rw::color_enhance_fixed_color_cb_of_low_intensity_side_u8 );
                }
                
                //дочитываем регистр
                /*
                if( m_camera.sendCommandColorEnhance(   m_multi[0], 
                                                        m_multi[1], 
                                                        m_multi[2], 
                                                        m_multi[3], 
                                                        m_multi[4],
                                                        m_multi[5],
                                                        m_multi[6],
                                                        m_multi[7] ) );
                {
                    m_activeRegNum.first = 0;
                }
                */
                
                break;
            }
        }
    }
}