#pragma once

#include "i_can.h"

namespace can
{
    class CanMock : public ICan
    {
        // затычка can
        public:
        
        // предельное кол-во фильтров при использовании 32 бит
        const static uint8_t max_num_of_rx_filters = 14;       
     
     
     
        virtual void deInit( void ) override
        {
            m_isInitDone = false;
            m_baudRate = 0;
            m_lastErrCode = 0;
            m_errState = CanErr::NO_ERROR;
        }



        // проверка - инициализирован ли?
        virtual bool isInited( void ) override
        {
            return m_isInitDone;
        }        

        
        
        // отправка
        virtual ReturnState transmitMessage( const CanMessage & msg ) override
        {
            if( ( isInited() == false ) ||
                ( msg.length > msg_len_max ) ||
                ( getErrorState() == CanErr::BUS_OFF ) )
            {
                // не инициализирован can или размер неправильный или шина упала
                return ReturnState::ERROR;
            }
            m_currTx = msg;
            return ReturnState::OK;
        }

       
       
        // прием
        virtual bool tryToReceive( CanMessage & msg ) override
        {
            if( ( isInited() == false ) ||
                ( getErrorState() == CanErr::BUS_OFF) )
            {
                return false;
            }
            
            if( m_rxBuffer.isEmpty() == true )
            {
                // буфер пустой
                return false;
            }
            else
            {
                // в буфере чот есть, забрать
                msg = m_rxBuffer.readTail();
                return true;
            }
        }
        
        
        
        // проверка на ошибку
        virtual CanErr getErrorState( void ) override
        {
            m_errState = CanErr::NO_ERROR;
            return m_errState;
        }
        
        
        
        // мьютекс
        virtual bool isLocked( void ) override
        {
            UMBA_ASSERT(m_isInitDone);

            return m_isLocked;
        }

        virtual void lock( void ) override
        {
            UMBA_ASSERT(m_isInitDone);

            m_isLocked = true;
        }

        virtual void unLock( void ) override
        {
            UMBA_ASSERT(m_isInitDone);

            m_isLocked = false;
        }
        
        
        
        // проверка на готовность передавать
        virtual bool isReadyToTransmit( void ) override
        {
            if( isInited() == false )
            {
                return false;
            }

            return true;

        }
        


        // проверка на завершенность передач
        virtual bool areAllTransmitsComplete( void ) override
        {
            if( isInited() == false )
            {
                return false;
            }

            return true;

        }

               
        
        // типа инициализация
        ReturnState init( uint32_t baudRate )
        {
            if( ( baudRate > max_baud_rate ) ||
                ( baudRate < min_baud_rate ) )
            {
                m_isInitDone = false;
                return ReturnState::ERROR;
            }
            
            m_baudRate = baudRate;
            m_isInitDone = true;
            
            return ReturnState::OK;
        }
        
            
        // подставное место для передачи
        CanMessage m_currTx;
        
        // буфер приема. публичен, чтоб туда можно было что-то кинуть извне
        BlockingCircularBuffer< CanMessage, rx_buffer_size > m_rxBuffer;        
   
        // все публичное, чтоб можно было потрогать
        
        // вспомогательные шняги
        bool m_isInitDone = false; 

        // текущий бодрейт
        uint32_t m_baudRate = 0;
    
        // код последней ошибки 
        uint8_t m_lastErrCode = CAN_ErrorCode_NoErr;
    
        // наличие ошибки
        CanErr m_errState = CanErr::NO_ERROR;
    
        // для потокобезопасности типа
        bool m_isLocked = false;
    };
}

