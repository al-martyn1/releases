#pragma once

#include "project_config.h"
#include "circular_buffer/blocking_circular_buffer.h"
#include "i_can.h"
#include "can_config.h"




namespace can
{       
    const uint32_t max_baud_rate = 500000;      // бит в сек - предельный бодрейт can
    
    const uint32_t min_baud_rate = 3000;        // бит в сек - предельный бодрейт can

    const uint8_t num_of_rx_fifo = 2;           // кол-во фифо приемных

    const uint8_t max_num_of_rx_filters = 14;   // предельное кол-во фильтров при использовании 32 бит    


    
    // выбор GPIO
    STRONG_ENUM(    CanPins,
                    A11_A12,   // есть у всех STM32F103x8 и STM32F103xB
                    D0_D1,     // есть у qfpn36 lqfp100 tfbga64 ufbg100
                    B8_B9     // все кроме qfn36
                );   
    
    
    
    enum CanNumbers
    {
    #ifdef CAN1_ENABLE 
        CAN_N1,
    #endif
        CAN_NUMBER
    };
    
    
    
    // структурищще для инициализации can
    struct CanInitStruct
    {
        uint32_t            baudRate = 0;               // бодрейт бит в сек 125000...500000
        CanPins             pinCan = CanPins::A11_A12;  // выводы для CAN
        CanMode             canMode = CanMode::NORMAL;    // режим CAN
        uint8_t             irqPriority = 0;            // приоритет прерываний 0-15
        uint8_t             sjw = 0;                    // коррекция длины бита 0-3
        FunctionalState     ttcim = DISABLE;            // вкл - 2 байта сообщения отражают время отправки
        FunctionalState     abom = DISABLE;             // вкл - автовыход из bus-off
        FunctionalState     awum = DISABLE;             // вкл - автовыход из sleep
        FunctionalState     nart = DISABLE;             // выкл - отправлять сообщение, пока не примется успешно 
        FunctionalState     rflm = DISABLE;             // вкл - перезапись сообщения при заполненных ФИФО приема. выкл - пропуск
        FunctionalState     txfp = DISABLE;             // приоритет отправки. вкл - по ID, выкл - по времени
    };
    
    

    class CanHandle : public ICan
    {
        public:
            
            // коньструктор
            CanHandle( CAN_TypeDef * hardwareCan ):
                m_rxBuffer( ),
                m_canPointer( hardwareCan )
            {
                m_rxBuffer.reset();
                
                if( ++counter() > CAN_NUMBER )
                {
                    // капец, слишком много хэндлов
                    UMBA_ASSERT_FAIL();
                }
            }


            virtual ~CanHandle() override
            {
                UMBA_ASSERT_FAIL();
            }


            // деактивация
            virtual void deInit(void) override;
            
            // инициализация простая
            ReturnState init( uint32_t baudRate, CanPins pinCan );
            
            // инициализация полная (вся структура в деле)
            ReturnState initExtended( CanInitStruct & initStruct );
            
            // установка фильтра - маска - простая
            ReturnState setFilterMaskNormal( uint8_t filterNum, uint16_t filterId, uint16_t filterMask );
            ReturnState setFilterMaskExt( uint8_t filterNum, uint32_t filterId, uint32_t filterMask );
            
            // установка фильтра - список - простая
            ReturnState setFilterTwoIdsNormal( uint8_t filterNum, uint16_t filterId1, uint16_t filterId2 );
            ReturnState setFilterTwoIdsExt( uint8_t filterNum, uint32_t filterId1, uint32_t filterId2 );
            
            // установка фильтра расширенная
            ReturnState setFilterExtended( CAN_FilterInitTypeDef & filterStruct );
            
            // передача
            virtual ReturnState transmitMessage( const CanMessage & msg ) override;
            
            // прием            
            virtual bool tryToReceive( CanMessage & msg ) override;
            
            // проверка инициализации
            virtual bool isInited(void) override;
        
            // обработчик прерываний - прием в фифо
            void canRxIrq( uint8_t canFifo, uint32_t canItFf, uint32_t canItFov, uint32_t canItFmp );
            
            // обработчик прерываний - передача свершилась
            void canTxIrq( void );
            
            // обработчик прерываний - какая-то ошибка
            void canErrIrq( void );
            
            // проверка на ошибку - не упало ли все
            virtual CanErr getErrorState( void ) override;
            
            virtual bool isReadyToTransmit( void ) override;
            virtual bool areAllTransmitsComplete( void ) override;
            
            // мьютекс
            virtual bool isLocked( void ) override;            
            virtual void lock( void ) override;
            virtual void unLock( void ) override;
               
        private:
            // константы, типы 
            
            // методы

            // копировать нельзя
            CanHandle(const CanHandle & that) = delete;

            // присваивать тоже нельзя
            CanHandle & operator=( CanHandle & that) = delete;
                  
            // отдельно вынесенный инит пинов
            void initGpio( CanPins pinCan);
        
            // отдельно вынесенный инит прерываний
            ReturnState initIrq( uint8_t priority );
            
            // служебная функция для пересыпания данных из spl-структуры в единую для всех-всех-всех
            void copyMsg( CanMessage & destMsg, CanRxMsg & srcMsg );
            
            // для подсчета кол-ва экземпляров
            static uint8_t & counter(void)
            {
                static uint8_t count = 0; 
                return count; 
            }
            
            //  члены класса 
            
            // буфер рх
            BlockingCircularBuffer< CanMessage, rx_buffer_size > m_rxBuffer;
        
            // указатель на сам интерфейс
            CAN_TypeDef * m_canPointer;
        
            // вспомогательные шняги
            bool m_isInitDone = false; 

            // текущий бодрейт
            uint32_t m_baudRate = 0;
            
            // код последней ошибки для внутреннего пользования (соответствует кодам из spl) :
            //  CAN_ErrorCode_NoErr            /*!< No Error */ 
            //  CAN_ErrorCode_StuffErr         /*!< Stuff Error */ 
            //  CAN_ErrorCode_FormErr          /*!< Form Error */ 
            //  CAN_ErrorCode_ACKErr           /*!< Acknowledgment Error */ 
            //  CAN_ErrorCode_BitRecessiveErr  /*!< Bit Recessive Error */ 
            //  CAN_ErrorCode_BitDominantErr  /*!< Bit Dominant Error */ 
            //  CAN_ErrorCode_CRCErr           /*!< CRC Error  */ 
            //  CAN_ErrorCode_SoftwareSetErr   /*!< Software Set Error */
            uint8_t m_lastErrCode = CAN_ErrorCode_NoErr;
        
            // наличие ошибки
            CanErr m_errState = CanErr::NO_ERROR;
        
            // для потокобезопасности типа
            bool m_isLocked = false;
    };


    #ifdef CAN1_ENABLE
        extern CanHandle can1;
    #endif
    
    #ifdef CAN2_ENABLE
        extern CanHandle can2;
    #endif
    
}
