#pragma once

// никаких spl, только базовый вид
#include "project_config.h"

namespace can
{
    // макс длина сообщения
    // оно нужно тут, ибо используется в структуре, проверяется в классе, пользующем структуру
    const uint8_t msg_len_max = 8;

    // для возвращаемых значений
    STRONG_ENUM(    ReturnState,     
                    OK, 
                    ERROR,
                    TX_BUSY );

    // для длины ID сообщения (11 или 29 бит)
    STRONG_ENUM(    FrameFormat,
                    STANDART,
                    EXTENDED );    

    // для типа сообщения - данные или запрос
    STRONG_ENUM(    MsgType, 
                    DATA, 
                    REQ );
        
    // режимы работы
    STRONG_ENUM(    CanMode,
                    NORMAL,
                    LOOPBACK,
                    SILENT,
                    SILENT_LOOPBACK );
    
    // режимы работы
    STRONG_ENUM(    CanErr,
                    NO_ERROR,       // все прекрасно
                    RX_OVERFLOW,    // обнаружен завал буфера приема
                    PASSIVE,    // ошибки на шине
                    BUS_OFF,      // ошибок на шине слишком много, все упало
                    BAUDRATE );     // ошибка бодрейта


    // сообщение, все полезные данные из него
    struct CanMessage
    {
        uint32_t        id = 0;
        FrameFormat     frameFormat = FrameFormat::STANDART;
        uint8_t         data[ msg_len_max ] = {0};
        uint8_t         length = 0;
        MsgType         type = MsgType::DATA;
    };

    
    // класс-база для can    
    class ICan
    {
    public:
            
        // куча виртуальностей
        virtual ~ICan()
        {
        }
        
        // сброс
        virtual void deInit(void) = 0;
        
        // проверка на инициализацию
        virtual bool isInited(void) = 0;        
        
        // отправка
        virtual ReturnState transmitMessage( const CanMessage & msg ) = 0; 
        
        // прием
        virtual bool tryToReceive( CanMessage & msg ) = 0;
        
        // проверка на ошибку - не упало ли все
        virtual CanErr getErrorState( void ) = 0;
        
        // мьютекс
        virtual bool isLocked( void ) = 0;
            
        virtual void lock( void ) = 0;

        virtual void unLock( void ) = 0;
        
        virtual bool isReadyToTransmit( void ) = 0;

        virtual bool areAllTransmitsComplete( void ) = 0;
    };
}
