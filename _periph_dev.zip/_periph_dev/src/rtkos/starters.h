#pragma once


#include "rtkos/rtkos.h"
#include "rtkos/rtkos_protothread.h"


namespace umba
{
namespace rtkos
{


template< OsInfoLogLevel osInfoLevel >
struct StarterThreadOsInfo : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel0> // StarterThreadBase // umba::rtkos::Protothread
{
    unsigned i  = 0;

    virtual bool run() override
    {
         using namespace umba::omanip;
         PT_BEGIN();

         PT_YIELD(); // simply remove never used warning

         for (i=0; i<=(unsigned)osInfoLevel; ++i)
         {
             UMBA_RTKOS_OS->logOsInfo( (umba::rtkos::OsInfoLogLevel)i );

             timer.start(5);
             PT_WAIT_UNTIL(timer.expired());
         }

         PT_END();
    }

}; // struct StarterThreadOsInfo



struct StarterThreadHardwareInfo : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel1> // StarterThreadBase // umba::rtkos::Protothread
{
    size_t drvNo    = 0;
    size_t drvTotal = 0;

    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning

         UMBA_RTKOS_LOG<<"\n----------\nRunlevel "<<thread_runlevel<<umba::omanip::endl;
         UMBA_RTKOS_LOG<<"Hardware configuration"<<umba::omanip::endl;

         drvTotal = UMBA_RTKOS_OS->getTotalDrivers();
         for( ; drvNo!=drvTotal; ++drvNo)
         {
             UMBA_RTKOS_LOG_DRIVER_INFO( drvNo );
             timer.start( 5 );
             PT_WAIT_UNTIL(timer.expired());

         }

         PT_END();
    }

}; // struct StarterThreadHardwareInfo




template< typename PwrOptionToTimeout >
struct StarterThreadHardwareInitializer : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel2>
{
    size_t                              drvNo    = 0;
    size_t                              drvTotal = 0;
    umba::rtkos::DriverAddress          drvAddr;
    umba::ihc::IOctetOStreamImplBuf<32> strTo;
    umba::Error initRes;

    PwrOptionToTimeout                  pwrOptionToTimeoutConverter; //  = PwrOptionToTimeout();

    umba::drivers::PowerConsumptionClass pwrClass;

    StarterThreadHardwareInitializer( const PwrOptionToTimeout &converter )
    : umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel2>()
    , pwrOptionToTimeoutConverter(converter)
    {}


    virtual bool run() override
    {
         using namespace umba::omanip;
         
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning

         UMBA_RTKOS_LOG<<"\n----------\nRunlevel "<<thread_runlevel<<umba::omanip::endl;
         UMBA_RTKOS_LOG<<"Initializing hardware..."<<umba::omanip::endl;

         drvTotal = UMBA_RTKOS_OS->getTotalDrivers();
         for( ; drvNo!=drvTotal; ++drvNo)
         {
             drvAddr = UMBA_RTKOS_OS->driverGetAddress( drvNo ) = 0;

             pwrClass = UMBA_RTKOS_OS->driverGet( drvNo )->getPowerClass(drvAddr);

             UMBA_RTKOS_LOG<<"#"<<width(2)<<(drvNo+1)<<" ";
             //UMBA_RTKOS_LOG<<""
             initRes = UMBA_RTKOS_OS->driverHardwareInit( drvNo );
             //auto res = UMBA_RTKOS_OS->driverSoftwareStart( drvNo );
             if (initRes.isFail())
             {
                 UMBA_RTKOS_LOG<<" - "<<initRes.what();
             }
             else
             {
                 UMBA_RTKOS_LOG<<" - Ok";
             }
             UMBA_RTKOS_LOG<<endl;
             UMBA_RTKOS_OS->driverHardwareSetStarted(drvNo);

             timer.start( pwrOptionToTimeoutConverter(pwrClass) );
             PT_WAIT_UNTIL(timer.expired());

             UMBA_RTKOS_LOG<<flush;

         }

         PT_END();
    }

}; // struct StarterThreadHardwareInitializer



template< typename PwrOptionToTimeout/*, umba::rtkos::RunLevel starterRunLevel = umba::rtkos::RunLevel5*/>
struct StarterThreadSoftwareInitializer : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel5/*starterRunLevel*/>
{
    size_t        drvNo    = 0;
    size_t        drvTotal = 0;
    umba::rtkos::DriverAddress drvAddr;
    umba::Error initRes;

    PwrOptionToTimeout                  pwrOptionToTimeoutConverter; //  = PwrOptionToTimeout();

    umba::drivers::PowerConsumptionClass pwrClass;

    StarterThreadSoftwareInitializer( const PwrOptionToTimeout &converter )
    : umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel5/*starterRunLevel*/>()
    , pwrOptionToTimeoutConverter(converter)
    {}



    virtual bool run() override
    {
         using namespace umba::omanip;
         
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning

         UMBA_RTKOS_LOG<<"\n----------\nRunlevel "<<thread_runlevel<<umba::omanip::endl;
         UMBA_RTKOS_LOG<<"Starting software"<<umba::omanip::endl;


         drvTotal = UMBA_RTKOS_OS->getTotalDrivers();
         for( ; drvNo!=drvTotal; ++drvNo)
         {
             drvAddr = UMBA_RTKOS_OS->driverGetAddress( drvNo );
             pwrClass = UMBA_RTKOS_OS->driverGet( drvNo )->getPowerClass(drvAddr);

             UMBA_RTKOS_LOG<<"#"<<width(2)<<(drvNo+1)<<" ";
             //UMBA_RTKOS_LOG<<""
             initRes = UMBA_RTKOS_OS->driverSoftwareStart( drvNo );
             //auto res = UMBA_RTKOS_OS->driverSoftwareStart( drvNo );
             if (initRes.isFail())
             {
                 UMBA_RTKOS_LOG<<" - "<<initRes.what();
             }
             else
             {
                 UMBA_RTKOS_LOG<<" - Ok";
             }
             UMBA_RTKOS_LOG<<endl;
             UMBA_RTKOS_OS->driverSoftwareSetStarted(drvNo);

             timer.start( pwrOptionToTimeoutConverter(pwrClass) );
             PT_WAIT_UNTIL(timer.expired());

         }

         UMBA_RTKOS_LOG<<flush;

         PT_END();
    }

}; // struct StarterThreadSoftwareInitializer



} // namespace rtkos
} // namespace umba
