#pragma once

#define RTKOS_RTKOS_H

// umba::rtkos::


#include "umba/umba.h"

#ifdef UMBA_MCU_USED
    #include "luart/uart_handle.h"
#else
    #include <iostream>
#endif

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"
#include "umba/basic_interfaces_impl.h"

#include "basic_types.h"
#include "messages.h"
#include "config.h"

#ifndef UMBA_RTKOS_NO_DRIVERS

    #include "drivers/i_driver.h"

#endif



//#define UMBA_RTKOS_TRACE_YIELD_STACK_PTR




#define UMBA_RTKOS_OS                   umba::rtkos::os()
#define UMBA_RTKOS_IS_OS_STARTED()      UMBA_RTKOS_OS->isOsStarted()
#define UMBA_RTKOS_LOG                  UMBA_RTKOS_OS->getLogStream()
#define UMBA_RTKOS_PANIC()              UMBA_RTKOS_OS->kernelPanic(0)
#define UMBA_RTKOS_PANIC_MSG(msg)       UMBA_RTKOS_OS->kernelPanic( msg )




namespace umba
{
namespace rtkos
{



#ifndef UMBA_RTKOS_NO_DRIVERS

interface IDriverClientHandler : inherits umba::IUnknown
{
    UMBA_DECLARE_INTERFACE_ID(0x5CD106D5);

    virtual
    bool onMessageDriverClient( const umba::drivers::MessageDriver &msg ) = 0;

}; // interface IDriverClientHandler

enum class ValueConvertMode
{
    panic, warning, implicit_cast
};

#endif


//-----------------------------------------------------------------------------
enum class MessageFilterInstallOrder 
{
    before,
    after
};

//-----------------------------------------------------------------------------
interface IMessageFilter : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xCE509227);

    virtual
    bool onFilterMessage( Message &msg ) = 0;

}; // interface IPollCapable

interface IMessageHandler : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xCE509227);

    virtual
    void onHandleMessage( Message &msg ) = 0;

}; // interface IPollCapable

//-----------------------------------------------------------------------------

typedef umba::IPollCapable IPollCapable;

enum class PollPriority 
{
    normal,
    high
};




//-----------------------------------------------------------------------------
constexpr size_t invalid_driver_index = (size_t)-1;




//-----------------------------------------------------------------------------
enum class OsInfoLogLevel
{
    osVersion,
    osStarting, // Starting on Win32/Win64/MCU [under debugger]
    osClocks,
    osSize,
    osSizeDetails,
    osSizeDetailsMore
};




//-----------------------------------------------------------------------------
interface IOs : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0x3779A5DD);

    virtual
    int run( RunLevel runLevel ) = 0;
/*
    virtual
    int run( IIdleCapable *pIdle ) = 0;
*/
    // По умолчанию возвращает Stream& на дефолтный нулевой стрим
    // Нужно вызвать UMBA_RTKOS_INSTALL_LOG_STREAM_*() как можно раньше
    // Возможные варианты
    // UMBA_RTKOS_INSTALL_LOG_STREAM_SWD()
    // UMBA_RTKOS_INSTALL_LOG_STREAM_CONSOLE(...) // Отладочный UART или виндовая консоль - детектится само. 
    virtual
    umba::SimpleFormatter& getLogStream() = 0;

    virtual
    umba::SimpleFormatter& getUnsafeStream(umba::ICharWriter *pWritter) = 0;

    virtual
    umba::SimpleFormatter& getUnsafeStream(umba::ihc::IOctetOStream *pStreamTo) = 0;

    virtual
    void getOsName( umba::ihc::IOctetOStream *pStreamTo ) = 0;

    virtual
    unsigned getOsVersionMajor( ) = 0;

    virtual
    unsigned getOsVersionMinir( ) = 0;

    virtual
    size_t getOsSize( ) = 0;

    virtual
    void logOsInfo( OsInfoLogLevel osInfoLogLevel ) = 0;


    // Timers
    // Для таймеров реально нужен список, потому что они могут создаваться и удаляться весьма активно

    virtual
    TimerId timerSet( ITimerHandler *pHandler, TimerEventId eventId, TimeTick period ) = 0;

    virtual
    TimerId timerSet( TimerId, TimeTick period ) = 0;

    // TODO: 
    /*
    
    virtual
    bool timerIsSet( ITimerHandler *pHandler, TimerEventId eventId ) = 0;

    virtual
    bool timerIsSet( TimerId ) = 0;
    */

    virtual
    TimerId timerFind( ITimerHandler *pHandler, TimerEventId eventId ) = 0;

    virtual
    bool timerKill( TimerId timerId ) = 0;

    virtual
    bool timerKill( ITimerHandler *pHandler, TimerEventId eventId ) = 0;



    // Фильтры сообщений - храним в тупом статическом массиве, во время работы главного цикла - не меняем
    // Если кому-то надо динамически фильтровать сообщения - сорян, ребята, извращайтесь сами

    virtual
    bool messageFilterAdd( IMessageFilter *pFilter ) = 0; // кладет взад списка фильтров
    
    virtual
    bool messageFilterAdd( IMessageFilter *pFilter, IMessageFilter *pRefFilter, MessageFilterInstallOrder ) = 0; // кладет перед/после, или в зад, если не находит pRefFilter

    //virtual
    //void messageFilterRemove( IMessageFilter *pFilter ) = 0;

    // Установка обработчиков сообщений
    virtual
    IMessageHandler* messagesSetHandler( MessageId msgTypeId, IMessageHandler *pHandler ) = 0;

    // Зашедуленные полировки с низким приоритетом - храним в тупом статическом массиве, во время работы главного цикла - не меняем
    // Высокоприоритетные полировки храним в списке, они могу динамически добавляться/удаляться
    // Высокоприоритетных полировок не должно быть много 8 или 16 - вполне достаточно
    // Полировки не должны вызывать полировку с тем же уровнем приоритета. Или может?
    // Обработчик полировки с низким уровнем приоритета может вызывать полировку высокоприоритетных полировок. Иное - не допустимо
    // Вызов полировки во время полировки того же уровня должен что делать? Просто возврат или ассерт?

    virtual
    bool pollScheduleAdd( IPollCapable * p, PollPriority priority ) = 0;

    //virtual
    //bool pollScheduleAdd( PollPriority priority, IPollCapable * p, IPollCapable * pRef, PollInstallOrder pollInstallOrder ) = 0;

    // А вот тут мы ассертимся для Low приоритета или пытаемся выдать каким-либо образом что-то осмысленное?
    virtual
    bool pollScheduleRemove( IPollCapable * p, PollPriority priority ) = 0;

    /* Yield - это костыль.
       Более поздно заелженные задачи будут также елдить ранее заелженные
       Расход стека на каждый елд:
          Wi64 - 0x0850 байт (2128)
          STM  - 0x00C0 байт (192)
       Костыль сделан для упрощения портирования на скорую руку отдельных кусков 
       кода из-под FreeRTOS, в дальнейшем их всё равно надо нормально переписать.

       При елде продолжают работать сообщения, незаелженные полировки, а также высокоприоритетные полировки.

     */
    #ifdef UMBA_RTKOS_ENABLE_YIELD
    virtual
    bool pollScheduleYield( TimeTick yieldPeriod ) = 0;

    virtual
    bool pollScheduleYield( TimeTick yieldPeriod, IIdleCapable *pIdle ) = 0;
    #endif

    virtual
    IIdleCapable* setIdleHandler(IIdleCapable* h) = 0;


    virtual
    bool messagePost( const Message &msg ) = 0;

    virtual
    bool messagePostHighPriority( const Message &msg ) = 0;

    virtual
    void messagePostDebugBreak( const Message &msg ) = 0;

    virtual
    void messagePostDebugBreakCtrl( bool allowBreak ) = 0;


    // Нужно вызывать в блокирующих циклах
    virtual
    bool messagesDispatch() = 0;

    virtual
    bool isDebuggerPresent() = 0;

    virtual
    void kernelPanic( const char *msgDetails ) = 0;


    #ifndef UMBA_RTKOS_NO_DRIVERS

    // Генерирует DriverId
    virtual
    DriverId driverInstall( IDriver *pDriver ) = 0;

    // Генерирует DriverId
    virtual
    DriverId driverInstall( const DriverAddress &driverAddress, DriverSubclassId subclassId, IDriver *pDriver ) = 0;

    //! Возвращает полученный driverId, сгенерированный новый или invalid_driver_id
    virtual
    DriverId driverInstall(DriverClassId classId, DriverId driverId, DriverSubclassId subclassId, IDriver *pDriver ) = 0;

    virtual
    size_t getTotalDrivers() = 0;

    virtual
    umba::drivers::IDriver* driverGet( size_t idx ) = 0;

    virtual
    DriverAddress driverGetAddress( size_t idx ) = 0;

    virtual
    DriverSubclassId driverGetSubclass( size_t idx ) = 0;

    virtual
    umba::drivers::IDriver* driverGet( const DriverAddress &driverAddress ) = 0;

    //! Возвращает индекс следующего подходящего драйвера начиная с nextIdx.
    /*! Если ничего не найдено, то возвращает invalid_driver_index.
        Для поиска с начала нужно задать nextIdx равным 0.
        Если задать subclassId = subclass_id_any, то будет искаться только 
        по классу драйвера.
     */
    virtual
    size_t driverFindCompatible(DriverClassId classId, DriverSubclassId subclassId, size_t nextIdx ) = 0;

    virtual
    bool driverHandlerAdd( const DriverAddress &driverAddress, IDriverClientHandler *pHandler ) = 0;

    virtual
    umba::Error driverHardwareInit( size_t idx ) = 0;

    virtual
    umba::Error driverSoftwareStart( size_t idx ) = 0;

    virtual
    umba::Error driverSoftwareSetStarted( size_t idx ) = 0;

    virtual
    umba::Error driverHardwareSetStarted( size_t idx ) = 0;

    virtual
    void setDriverValueConvertMode( ValueConvertMode vcm ) = 0;

    virtual
    void handleDriverValueConvertFailed( umba::drivers::ValueInfoFlags expected, umba::drivers::ValueInfoFlags got ) = 0;

    //virtual
    //void driverHandlerRemove( const DriverAddress &driverAddress, IDriverClientHandler *pHandler ) = 0;

    #endif

    virtual
    bool isOsStarted( ) = 0;


protected:

    virtual
    bool pollScheduleDoPoll( PollPriority priority ) = 0;

    #ifndef UMBA_RTKOS_NO_DRIVERS

    //virtual
    //DriverId findDriverIdMax(DriverClassId classId ) = 0;

    #endif


}; // struct IOs

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
IOs* os();

//-----------------------------------------------------------------------------








//-----------------------------------------------------------------------------
// Copy some helpers from umba to umba::rtkos
//-----------------------------------------------------------------------------

template< typename THandler >
inline
SimplePollCapable<THandler> makeSimplePollCapable( const THandler &handler )
{
    return umba::makeSimplePollCapable<THandler>(handler);
}

template< typename THandler >
inline
SimpleIdleCapable<THandler> makeSimpleIdleCapable( const THandler &handler )
{
    return umba::makeSimpleIdleCapable<THandler>(handler);
}

template< typename THandler >
inline
SimpleTimerHandler<THandler> makeSimpleTimerHandler( const THandler &handler )
{
    return umba::makeSimpleTimerHandler<THandler>(handler);
}



//-----------------------------------------------------------------------------
















//-----------------------------------------------------------------------------
template<typename Object>
inline
bool driverHandlerAdd( const DriverAddress &driverAddress, Object *pObj )
{
    if (auto res = pObj-> template queryInterface<IDriverClientHandler>())
    {
        return os()->driverHandlerAdd( driverAddress, res.value );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
bool driverHandlerAdd<IDriverClientHandler>( const DriverAddress &driverAddress, IDriverClientHandler *pObj )
{
    return os()->driverHandlerAdd( driverAddress, pObj );
}




//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
template<typename Object>
inline
DriverId driverInstall( Object *pObj )
{
    if (auto res = pObj-> template queryInterface<IDriver>())
    {
        return os()->driverInstall( res.value );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
DriverId driverInstall<IDriver>( IDriver *pObj )
{
    return os()->driverInstall( pObj );
}

//-----
template<typename Object>
inline
DriverId driverInstall( const DriverAddress &driverAddress, DriverSubclassId subclassId, Object *pObj )
{
    if (auto res = pObj-> template queryInterface<IDriver>())
    {
        return os()->driverInstall( driverAddress, subclassId, res.value );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
DriverId driverInstall<IDriver>( const DriverAddress &driverAddress, DriverSubclassId subclassId, IDriver *pObj )
{
    return os()->driverInstall( driverAddress, subclassId, pObj );
}

//-----
template<typename Object>
inline
DriverId driverInstall(DriverClassId classId, DriverId driverId, DriverSubclassId subclassId, Object *pObj )
{
    if (auto res = pObj-> template queryInterface<IDriver>())
    {
        return os()->driverInstall( classId, driverId, subclassId, res.value );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
DriverId driverInstall<IDriver>(DriverClassId classId, DriverId driverId, DriverSubclassId subclassId, IDriver *pObj )
{
    return os()->driverInstall( classId, driverId, subclassId, pObj );
}

//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
template<typename Object>
inline
TimerId timerSet ( Object *pObj, TimerEventId eventId, TimeTick period )
{
    if (auto res = pObj-> template queryInterface<ITimerHandler>())
    {
        return os()->timerSet( res.value, eventId, period );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return timer_id_invalid;
    }
}

template<>
inline
TimerId timerSet<ITimerHandler>( ITimerHandler *pObj, TimerEventId eventId, TimeTick period )
{
    return os()->timerSet( pObj, eventId, period );
}

//-----------------------------------------------------------------------------
template<typename Object>
inline
TimerId timerFind ( Object *pObj, TimerEventId eventId )
{
    if (auto res = pObj-> template queryInterface<ITimerHandler>())
    {
        return os()->timerFind( res.value, eventId );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return timer_id_invalid;
    }
}

template<>
inline
TimerId timerFind<ITimerHandler>( ITimerHandler *pObj, TimerEventId eventId )
{
    return os()->timerFind( pObj, eventId );
}

//-----------------------------------------------------------------------------
template<typename Object>
inline
bool timerKill ( Object *pObj, TimerEventId eventId )
{
    if (auto res = pObj-> template queryInterface<ITimerHandler>())
    {
        return os()->timerKill( res.value, eventId );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return timer_id_invalid;
    }
}

template<>
inline
bool timerKill<ITimerHandler>( ITimerHandler *pObj, TimerEventId eventId )
{
    return os()->timerKill( pObj, eventId );
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
inline
bool messagePost( const Message &msg )
{
    return os()->messagePost( msg );
}

inline
bool messagePost( const MessageKeyboard &msgData )
{
    Message msg;
    msg.id = message_keyboard_id;
    msg.messageKeyboard = msgData;
    return os()->messagePost( msg );
}

inline
bool messagePost( const MessageInputChar &msgData )
{
    Message msg;
    msg.id = message_input_char_id;
    msg.messageInputChar = msgData;
    return os()->messagePost( msg );
}

inline
bool messagePost( const MessageTimer &msgData )
{
    Message msg;
    msg.id = message_timer_id;
    msg.messageTimer = msgData;
    return os()->messagePost( msg );
}

#ifndef UMBA_RTKOS_NO_DRIVERS
inline
bool messagePost( const umba::drivers::MessageDriver &msgData )
{
    Message msg;
    msg.id = message_driver_id;
    msg.messageDriver = msgData;
    return os()->messagePost( msg );
}
#endif

inline
bool messagesDispatch()
{
    return os()->messagesDispatch();
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template<typename Object>
inline
bool messageFilterAdd ( Object *pObj )
{
    if (auto res = pObj-> template queryInterface<IMessageFilter>())
    {
        return os()->messageFilterAdd( res.value );
    }
    else
    {
        //UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
bool messageFilterAdd<IMessageFilter>( IMessageFilter *pObj )
{
    return os()->messageFilterAdd( pObj );
}

//-----------------------------------------------------------------------------
template<typename ObjectA, typename ObjectB>
inline
bool messageFilterAdd ( ObjectA *pObjA, ObjectB *pObjB, MessageFilterInstallOrder order)
{
    if (auto resA = pObjA-> template queryInterface<IMessageFilter>())
    {
        if (auto resB = pObjB-> template queryInterface<IMessageFilter>())
        {
            return os()->messageFilterAdd( resA.value, resB.value, order );
        }
        else
        {
            //UMBA_ASSERT_FAIL();
            return false;
        }
        //return impl::messageFilterInstall( res.value );
    }
    else
    {
        //UMBA_ASSERT_FAIL();
        return false;
    }
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template<typename Object>
inline
bool pollScheduleAdd ( Object *pObj, PollPriority priority)
{
    if (auto res = pObj-> template queryInterface<IPollCapable>())
    {
        return os()->pollScheduleAdd( res.value, priority );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
bool pollScheduleAdd<IPollCapable>( IPollCapable *pObj, PollPriority priority)
{
    return os()->pollScheduleAdd( pObj, priority );
}


//-----------------------------------------------------------------------------
template<typename Object>
inline
bool pollScheduleAdd ( Object *pObj )
{
    if (auto res = pObj-> template queryInterface<IPollCapable>())
    {
        return os()->pollScheduleAdd( res.value, PollPriority::normal );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
bool pollScheduleAdd<IPollCapable>( IPollCapable *pObj )
{
    return os()->pollScheduleAdd( pObj, PollPriority::normal );
}


//-----------------------------------------------------------------------------
template<typename Object>
inline
bool pollScheduleRemove ( Object *pObj, PollPriority priority)
{
    if (auto res = pObj-> template queryInterface<IPollCapable>())
    {
        return os()->pollScheduleRemove( res.value, priority );
    }
    else
    {
        UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
bool pollScheduleRemove<IPollCapable>( IPollCapable *pObj, PollPriority priority)
{
    return os()->pollScheduleRemove( pObj, priority );
}


#ifdef UMBA_RTKOS_ENABLE_YIELD
template<typename Object>
inline
bool pollScheduleYield ( TimeTick yieldPeriod, Object *pObj )
{
    #ifdef UMBA_RTKOS_TRACE_YIELD_STACK_PTR
        using namespace umba::omanip;
        auto a = 0u;
        UMBA_RTKOS_LOG<<"Stack (bool pollScheduleYield ( TimeTick yieldPeriod, Object *pObj )): "<<hex<<(size_t)&a<<endl;
    #endif
    if (auto res = pObj-> template queryInterface<IIdleCapable>())
    {
        return os()->pollScheduleYield( res.value );
    }
    else
    {
        //UMBA_ASSERT_FAIL();
        return false;
    }
}

template<>
inline
bool pollScheduleYield<IIdleCapable>( TimeTick yieldPeriod, IIdleCapable *pObj )
{
    #ifdef UMBA_RTKOS_TRACE_YIELD_STACK_PTR
        using namespace umba::omanip;
        auto a = 0u;
        UMBA_RTKOS_LOG<<"Stack (pollScheduleYield<IIdleCapable>( TimeTick yieldPeriod, IIdleCapable *pObj )): "<<hex<<(size_t)&a<<endl;
    #endif
    return os()->pollScheduleYield( yieldPeriod, pObj );
}

inline
bool pollScheduleYield( TimeTick yieldPeriod )
{
    #ifdef UMBA_RTKOS_TRACE_YIELD_STACK_PTR
        using namespace umba::omanip;
        auto a = 0u;
        UMBA_RTKOS_LOG<<"Stack (bool pollScheduleYield( TimeTick yieldPeriod )): "<<hex<<(size_t)&a<<endl;
    #endif
    return os()->pollScheduleYield( yieldPeriod );
}

#endif // UMBA_RTKOS_ENABLE_YIELD



//-----------------------------------------------------------------------------
struct SimpleMessageFilterImplBase : public IMessageFilter
{
    UMBA_BEGIN_INTERFACE_MAP( )
         UMBA_IMPLEMENT_INTERFACE( IMessageFilter )
    UMBA_END_INTERFACE_MAP()

}; // struct SimpleMessageFilterImplBase

template< typename THandler >
struct SimpleMessageFilter : public SimpleMessageFilterImplBase
{
    SimpleMessageFilter( const THandler &h ) : m_handler(h) {}

    virtual
    bool onFilterMessage( Message &msg ) override
    {
        return m_handler( msg );
    }

protected:

    THandler m_handler;

}; // struct SimpleIdleCapable

template< typename THandler >
inline
SimpleMessageFilter<THandler> makeSimpleMessageFilter( const THandler &handler )
{
    return SimpleMessageFilter<THandler>(handler);
}

//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
#ifndef UMBA_RTKOS_NO_DRIVERS

struct SimpleDriverClientHandlerImplBase : public IDriverClientHandler
{
    UMBA_BEGIN_INTERFACE_MAP( )
         UMBA_IMPLEMENT_INTERFACE( IDriverClientHandler )
    UMBA_END_INTERFACE_MAP()

}; // struct SimpleTimerHandlerImplBase

template< typename THandler >
struct SimpleDriverClientHandler : public SimpleDriverClientHandlerImplBase
{
    SimpleDriverClientHandler( const THandler &h ) : m_handler(h) {}

    void handleFrom( DriverAddress addrFrom )
    {
        umba::rtkos::driverHandlerAdd( addrFrom, this );
    }

    virtual
    bool onMessageDriverClient( const umba::drivers::MessageDriver &msg ) override
    {
        m_handler( msg );
        return true;
    }

protected:

    THandler m_handler;

}; // struct SimpleTimerHandlerImplBase

template< typename THandler >
inline
SimpleDriverClientHandler<THandler> makeSimpleDriverClientHandler( const THandler &handler )
{
    return SimpleDriverClientHandler<THandler>(handler);
}
#endif
//-----------------------------------------------------------------------------







//-----------------------------------------------------------------------------
namespace priv
{

//void setLogStream( umba::SimpleFormatter &s );
void setLogCharWriter( umba::ICharWriter *pWritter );

/*
struct LogStreamSetter
{
    LogStreamSetter(umba::SimpleFormatter &s)
    {
        setLogStream( s );
    }
}; // struct LogStreamSetter
*/

struct LogCharWritterSetter
{
    LogCharWritterSetter(umba::ICharWriter *pWritter)
    {
        setLogCharWriter( pWritter );
    }
}; // struct LogStreamSetter


#ifdef UMBA_MCU_USED
struct UartInitializer
{
    UartInitializer( uart::Handle &uart
                   , GPIO_TypeDef *portRx, uint16_t rxPinNo
                   , GPIO_TypeDef *portTx, uint16_t txPinNo
                   , uint32_t baudrate
                   )
    {
        uart.init( portRx, rxPinNo, portTx, txPinNo, baudrate );
    }

    umba::ICharWriter* passthrough( umba::ICharWriter *p ) { return p ; }

}; // struct UartInitializer

inline
umba::rtkos::priv::UartInitializer& getInitializer( uart::Handle &uart
                                , GPIO_TypeDef *portRx, uint16_t rxPinNo
                                , GPIO_TypeDef *portTx, uint16_t txPinNo
                                , uint32_t baudrate
                                )
{
    static umba::rtkos::priv::UartInitializer i( uart, portRx, rxPinNo, portTx, txPinNo, baudrate);
    return i;
}



#endif

} // namespace priv

//-----------------------------------------------------------------------------



} // namespace rtkos
} // namespace umba




#define UMBA_RTKOS_USE_LOG_STREAM_NUL()                                                         \
               /* namespace */                                                                          \
               /* { */                                                                                  \
                   /* umba::NulCharWriter                    logCharWritter; */                         \
                   /* umba::SimpleFormatter                  logStreamFormatter( &logCharWritter ); */  \
                   /* umba::rtkos::priv::LogStreamSetter     logStreamSetter( logStreamFormatter ); */  \
                   umba::rtkos::priv::LogCharWritterSetter   logCharWritterSetter( 0 );  \
               /* } */ 

#if defined(UMBA_MCU_USED)

    // Correct name
    #define UMBA_RTKOS_USE_LOG_STREAM_SWV()                                                         \
                   /* namespace */                                                                          \
                   /* { */                                                                                  \
                      umba::SwvCharWritter                   logCharWritter;                        \
                       /* umba::SimpleFormatter                  logStreamFormatter( &logCharWritter ); */  \
                       /* umba::rtkos::priv::LogStreamSetter     logStreamSetter( logStreamFormatter ); */  \
                      umba::rtkos::priv::LogCharWritterSetter logCharWritterSetter( &logCharWritter ); \
                   /* } */ 

    // Simple alias
    #define UMBA_RTKOS_USE_LOG_STREAM_SWD()  UMBA_RTKOS_USE_LOG_STREAM_SWV()


    // UART_SPEED is often 460800
    #define UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( UART_NAME, UART_CONF, UART_SPEED )                   \
                   /* namespace */                                                                          \
                   /* { */                                                                                  \
                                                                                                                             \
                                                                                                                             \
                      umba::LegacyUartCharWriter<UMBA_RTKOS_LOG_STREAM_BUF_SIZE>      logCharWritter = umba::LegacyUartCharWriter<UMBA_RTKOS_LOG_STREAM_BUF_SIZE>( UART_NAME ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false )/**/; \
                       /* umba::SimpleFormatter                                           logStreamFormatter( &logCharWritter ); */  \
                                                                                                                             \
                                                                                                                             \
                       /* umba::rtkos::priv::LogStreamSetter                              logStreamSetter( umba::rtkos::priv::getInitializer( UART_NAME, UART_CONF##_RX_GPIO,  UART_CONF##_RX_GPIO_PIN_NO, UART_CONF##_TX_GPIO, UART_CONF##_TX_GPIO_PIN_NO, UART_SPEED ).passthrough(logStreamFormatter) ); */  \
                      umba::rtkos::priv::LogCharWritterSetter                         logCharWritterSetter( umba::rtkos::priv::getInitializer( UART_NAME, UART_CONF##_RX_GPIO,  UART_CONF##_RX_GPIO_PIN_NO, UART_CONF##_TX_GPIO, UART_CONF##_TX_GPIO_PIN_NO, UART_SPEED ).passthrough(&logCharWritter) ); \
                      /* logCharWritter.setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false ) */ \
                   /* } */ 


                      /*                                                                            
                      struct UartInitializer                                                                                 
                      {                                                                                                      
                          UartInitializer()                                                                                  
                          {                                                                                                  
                              UART_NAME.init( UART_CONF##_RX_GPIO,  UART_CONF##_RX_GPIO_PIN_NO, UART_CONF##_TX_GPIO, UART_CONF##_TX_GPIO_PIN_NO, UART_SPEED );
                          }                                                                                                  
                                                                                                                             
                          umba::SimpleFormatter& passthrough( umba::SimpleFormatter &s ) { return s ; }                      
                                                                                                                             
                                                                                                                             
                      }; */                                                                                                    


#else

    #define UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( UART_NAME, UART_CONF, UART_SPEED )                   \
                   /* namespace */                                                                          \
                   /* { */                                                                                  \
                      umba::StdStreamCharWriter              logCharWritter( std::cout );           \
                       /* umba::SimpleFormatter                  logStreamFormatter( &logCharWritter ); */  \
                       /* umba::rtkos::priv::LogStreamSetter     logStreamSetter( logStreamFormatter ); */  \
                       umba::rtkos::priv::LogCharWritterSetter  logCharWritterSetter( &logCharWritter );  \
                   /* } */ 

#endif



#ifdef UMBA_RTKOS_NO_DRIVERS

    #define UMBA_RTKOS_LOG_DRIVER_INFO( drvNo ) do{} while(0)

#else

    namespace umba
    {
    namespace rtkos
    {
        inline
        void logDriverInfo( size_t drvNo )
        {
            using namespace umba::omanip;
    
            umba::ihc::IOctetOStreamImplBuf<48> strTo;
    
            UMBA_RTKOS_LOG<<"---"<<endl<<"#"<<width(2)<<setfill('0')<<(drvNo+1)<<" ";
    
            umba::drivers::IDriver *pDriver = UMBA_RTKOS_OS->driverGet(drvNo);
            if (!pDriver)
            {
                UMBA_RTKOS_LOG<<"- No driver found!!!"<<endl;
                return;
            }
    
            DriverAddress     addr       = UMBA_RTKOS_OS->driverGetAddress( drvNo );
            DriverSubclassId  subclassId = UMBA_RTKOS_OS->driverGetSubclass( drvNo );
            if (addr.classId==0)
            {
                UMBA_RTKOS_LOG<<"- Invalid driver class!!!"<<endl;
                return;
            }

            UMBA_RTKOS_LOG<<"("<<good<<groupsize(8)<<width(8)<<hex<<noshowbase<<addr.classId<<normal<<",#"<<good<<addr.driverId<<normal<<") ";
    
            pDriver->getDriverClassName( addr.classId, strTo.clearEx() );
            //UMBA_RTKOS_LOG<<strTo.c_str();
    
            //pDriver->getDriverSubclassName( addr, strTo.clearEx() );
            //UMBA_RTKOS_LOG<<"/"<<strTo.c_str();
            strTo.write("/",1);
            pDriver->getDriverSubclassName( addr.classId, subclassId, &strTo );
            
            UMBA_RTKOS_LOG<<width(24)<<left<<strTo.c_str();
    
            pDriver->getDriverDescription( addr, strTo.clearEx() );
            UMBA_RTKOS_LOG<<" - "<<width(4)<<left<<strTo.c_str();

            UMBA_RTKOS_LOG<<" - ";

            bool isConfValid = pDriver->getDriverConfigInfo( addr, strTo.clearEx() );
            if (isConfValid)
                UMBA_RTKOS_LOG<<width(4)<<left<<strTo.c_str();
            else
            {
                UMBA_RTKOS_LOG<<error<<width(4)<<left<<strTo.c_str()<<normal<<flush;
                UMBA_RTKOS_OS->kernelPanic( "misconfiguration detected" );
            }

            UMBA_RTKOS_LOG<<endl;
            UMBA_RTKOS_LOG<<"Driver parameters:";

            size_t i=0;
            for(; pDriver->getDriverParamName(addr, i, strTo.clearEx()); ++i)
            {
                UMBA_RTKOS_LOG<<"\n  "<<width(2)<<i<<": "<<width(36)<<left<<strTo.c_str()<<" - ";
                pDriver->getDriverParamInfo(addr, i, strTo.clearEx());
                UMBA_RTKOS_LOG<<strTo.c_str()<<flush;
            }

            if (!i)
            {
                UMBA_RTKOS_LOG<<" no parameters";
            }
            UMBA_RTKOS_LOG<<endl;

            UMBA_RTKOS_LOG<<"Device parameters:";
            i=0;
            for(; pDriver->getDeviceParamName(addr, i, strTo.clearEx()); ++i)
            {
                UMBA_RTKOS_LOG<<"\n  "<<width(2)<<i<<": "<<width(36)<<left<<strTo.c_str()<<" - ";
                pDriver->getDeviceParamInfo(addr, i, strTo.clearEx());
                UMBA_RTKOS_LOG<<strTo.c_str()<<flush;
            }

            if (!i)
            {
                UMBA_RTKOS_LOG<<" no parameters";
            }
            UMBA_RTKOS_LOG<<endl;
    
        }

    } // namespace rtkos
    } // namespace umba


    #define UMBA_RTKOS_LOG_DRIVER_INFO( drvNo ) umba::rtkos::logDriverInfo(drvNo)

#endif


//umba::ihc::IOctetOStreamImplBuf
//clearEx()

//UMBA_RTKOS_LOG

/*

    virtual
    void getDriverDescription( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //---------

    virtual
    bool getDriverParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    virtual
    bool getDriverParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //---------

    virtual
    bool getDeviceParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    virtual
    bool getDeviceParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //---------

    virtual
    PowerConsumptionClass getPowerClass(const DriverAddress &driverAddress) = 0;
*/
