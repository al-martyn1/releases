#pragma once

// https://github.com/benhoyt/protothreads-cpp
namespace benhoyt
{
    #include "protothread.h"
}


#include "rtkos.h"
#include "umba/time_service.h"
#include "umba/basic_interfaces_impl.h"

#include "basic_types.h"

namespace umba
{
namespace rtkos
{


class ProtothreadTimer
{

public:

    void start(umba::time_service::TimeTick p)
    {
        m_startTick = umba::time_service::getCurTimeMs();
        m_period    = p;
    }

    bool expired() const
    {
        return (umba::time_service::getCurTimeMs() - m_startTick) >= m_period;
    }


protected:

    umba::time_service::TimeTick m_startTick = 0;
    umba::time_service::TimeTick m_period = 0;

};


struct Protothread : protected benhoyt::Protothread, public umba::SimplePollCapableImplBase
{

protected:

    virtual bool run() = 0;

    virtual bool Run() override
    {
        return run();
    }

    virtual
    bool isReadyForPoll() override
    {
         return IsRunning();
    }

    virtual
    void poll() override
    {
        Run();
    }

    ProtothreadTimer timer;

}; // struct Protothread


template< RunLevel runLevel >
struct StarterThreadBase : protected IStarterTask
                         , protected Protothread
{

    RunLevel thread_runlevel = runLevel;

    UMBA_BEGIN_INTERFACE_MAP_EX( IStarterTask )
         UMBA_IMPLEMENT_INTERFACE_EX( umba::IPollCapable, IStarterTask )
         //UMBA_IMPLEMENT_INTERFACE( IStarterTask )
    UMBA_END_INTERFACE_MAP()

    UMBA_DELEGATE_QUERY_INTERFACE(IStarterTask)

    virtual
    RunLevel getTaskRunLevel() override
    {
        return runLevel;
    }

    virtual
    bool isReadyForPoll() override
    {
         return Protothread::isReadyForPoll();
    }

    virtual
    void poll() override
    {
        Protothread::Run();
    }


}; // struct StarterThreadBase



/*
struct StarterThreadBase : public Protothread
{
protected:

    virtual bool run() = 0;

    virtual bool Run() override
    {
        if (!run())
        {
            umba::rtkos::os()->setStarted();
            return false;
        }
        return true;
    }

    virtual
    bool isReadyForPoll() override
    {
         return IsRunning();
         // umba::rtkos::os()->isStarted();
    }

}; // struct StarterThreadBase
*/


} // namespace rtkos
} // namespace umba


