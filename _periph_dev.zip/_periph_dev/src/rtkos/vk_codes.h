#pragma once

// Replaces periph\vk_codes.h

// umba::rtkos::

#include "umba/umba.h"
#include "basic_types.h"


// umba::rtkos::VirtualKeyCode::

namespace umba
{
namespace rtkos
{


//typedef unsigned VirtualKeyCode;


// http://ideone.com/fk4KB1

//-----------------------------------------------------------------------------
enum class VirtualKeyState: GenericId
{
    released = 0,
    pressed  = 1
};

//-----------------------------------------------------------------------------
enum class VirtualKeyCode : GenericId
{
    #ifdef UMBA_RTKOS_DONT_COMPACT
        virtual_code_flag = 0x80000000u,
    #else
        virtual_code_flag =     0x8000u,
    #endif

    virtual_code_any      = (GenericId)-1,
                                     
    enter                 = virtual_code_flag | 0x000D,
    tab                   = virtual_code_flag | 0x0009,
    pause                 = virtual_code_flag | 0x001A,
    escape                = virtual_code_flag | 0x001B,
                                       
    f1                    = virtual_code_flag | 0x0020,
    f2                    = virtual_code_flag | 0x0021,
    f3                    = virtual_code_flag | 0x0022,
    f4                    = virtual_code_flag | 0x0023,
    f5                    = virtual_code_flag | 0x0024,
    f6                    = virtual_code_flag | 0x0025,
    f7                    = virtual_code_flag | 0x0026,
    f8                    = virtual_code_flag | 0x0027,
    f9                    = virtual_code_flag | 0x0028,
    f10                   = virtual_code_flag | 0x0029,
    f11                   = virtual_code_flag | 0x002A,
    f12                   = virtual_code_flag | 0x002B,
    f13                   = virtual_code_flag | 0x002C,
    f14                   = virtual_code_flag | 0x002D,
    f15                   = virtual_code_flag | 0x002E,
    f16                   = virtual_code_flag | 0x002F,
    f17                   = virtual_code_flag | 0x0030,
    f18                   = virtual_code_flag | 0x0031,
    f19                   = virtual_code_flag | 0x0032,
    f20                   = virtual_code_flag | 0x0033,
    f21                   = virtual_code_flag | 0x0034,
    f22                   = virtual_code_flag | 0x0035,
    f23                   = virtual_code_flag | 0x0036,
    f24                   = virtual_code_flag | 0x0037,
    f25                   = virtual_code_flag | 0x0038,
    f26                   = virtual_code_flag | 0x0039,
    f27                   = virtual_code_flag | 0x003A,
    f28                   = virtual_code_flag | 0x003B,
    f29                   = virtual_code_flag | 0x003C,
    f30                   = virtual_code_flag | 0x003D,
    f31                   = virtual_code_flag | 0x003E,
    f32                   = virtual_code_flag | 0x003F,
                                       
    up                    = virtual_code_flag | 0x0041,
    down                  = virtual_code_flag | 0x0042,
    right                 = virtual_code_flag | 0x0043,
    left                  = virtual_code_flag | 0x0044,
                                       
    home                  = virtual_code_flag | 0x0051,
    ins                   = virtual_code_flag | 0x0052,
    del                   = virtual_code_flag | 0x0053,
    end                   = virtual_code_flag | 0x0054,
    page_up               = virtual_code_flag | 0x0055,
    page_down             = virtual_code_flag | 0x0056,
                                       
    menu                  = virtual_code_flag | 0x0060,
    telemetry             = virtual_code_flag | 0x0061,
    volume_up             = virtual_code_flag | 0x0062,
    volume_down           = virtual_code_flag | 0x0063,
                                       
    backspace             = virtual_code_flag | 0x007F,

    #ifdef UMBA_RTKOS_DONT_COMPACT
        unknown           = 0xFFFFFFFFu
    #else
        unknown           =     0xFFFFu
    #endif

};

//-----------------------------------------------------------------------------
inline
const char* getKeyCodeName( VirtualKeyCode vkc )
{
    switch(vkc)
    {
     case VirtualKeyCode::f1              : return "F1";
     case VirtualKeyCode::f2              : return "F2";
     case VirtualKeyCode::f3              : return "F3";
     case VirtualKeyCode::f4              : return "F4";
     case VirtualKeyCode::f5              : return "F5";
     case VirtualKeyCode::f6              : return "F6";
     case VirtualKeyCode::f7              : return "F7";
     case VirtualKeyCode::f8              : return "F8";
     case VirtualKeyCode::f9              : return "F9";
     case VirtualKeyCode::f10             : return "F10";
     case VirtualKeyCode::f11             : return "F11";
     case VirtualKeyCode::f12             : return "F12";
     case VirtualKeyCode::f13             : return "F13";
     case VirtualKeyCode::f14             : return "F14";
     case VirtualKeyCode::f15             : return "F15";
     case VirtualKeyCode::f16             : return "F16";
     case VirtualKeyCode::f17             : return "F17";
     case VirtualKeyCode::f18             : return "F18";
     case VirtualKeyCode::f19             : return "F19";
     case VirtualKeyCode::f20             : return "F20";
     case VirtualKeyCode::f21             : return "F21";
     case VirtualKeyCode::f22             : return "F22";
     case VirtualKeyCode::f23             : return "F23";
     case VirtualKeyCode::f24             : return "F24";
     case VirtualKeyCode::f25             : return "F25";
     case VirtualKeyCode::f26             : return "F26";
     case VirtualKeyCode::f27             : return "F27";
     case VirtualKeyCode::f28             : return "F28";
     case VirtualKeyCode::f29             : return "F29";
     case VirtualKeyCode::f30             : return "F30";
     case VirtualKeyCode::f31             : return "F31";
     case VirtualKeyCode::f32             : return "F32";
     case VirtualKeyCode::enter           : return "Enter";
     case VirtualKeyCode::tab             : return "Tab";
     case VirtualKeyCode::escape          : return "Escape";
     case VirtualKeyCode::backspace       : return "Backspace";
     case VirtualKeyCode::pause           : return "Pause";
     case VirtualKeyCode::ins             : return "Ins";
     case VirtualKeyCode::del             : return "Del";
     case VirtualKeyCode::home            : return "Home";
     case VirtualKeyCode::end             : return "End";
     case VirtualKeyCode::page_up         : return "Page Up";
     case VirtualKeyCode::page_down       : return "Page Down";
     case VirtualKeyCode::left            : return "Left";
     case VirtualKeyCode::right           : return "Right";
     case VirtualKeyCode::up              : return "Up";
     case VirtualKeyCode::down            : return "Down";
     case VirtualKeyCode::menu            : return "Menu";
     case VirtualKeyCode::telemetry       : return "Telemetry";
     case VirtualKeyCode::volume_up       : return "VolumeUp";
     case VirtualKeyCode::volume_down     : return "VolumeDown";
     default                              : 
           {
               static char buf[2] = { 0, 0 };
               if ( (GenericId)vkc & (GenericId)VirtualKeyCode::virtual_code_flag )
               {
                   return "<Unknown>";
               }
               else
               {
                   buf[0] = (char)(uint8_t)( (GenericId)vkc & 0xFF );
                   return &buf[0];
               }
           }
           
    }
}


} // namespace rtkos

} // namespace umba

