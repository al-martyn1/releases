#include "../rtkos.h"
#include "umba/assert.h"
#include "umba/debug_helpers.h"
#include "umba/basic_interfaces_impl.h"

#if !defined(UMBA_MCU_USED)
    #if !defined(UMBA_RTKOS_NO_PERIPH)
        #define UMBA_RTKOS_NO_PERIPH
    #endif
#endif

#ifndef UMBA_RTKOS_NO_PERIPH
    #include "periph/periph.h"
#endif

#include "containers/static_list.h"

#include <string.h>
#include <algorithm>


//#define UMBA_RTKOS_DEBUG_YIELD


#define RTKOS_NUM_HANDLED_MESSAGE_TYPES 16


#ifndef UMBA_MCU_USED
    #include <signal.h>
#endif

namespace
{
volatile int stopSignal = 0; // never shoots on MCU
}


#ifndef UMBA_MCU_USED
void __cdecl handleControlC(int);
void __cdecl handleControlC(int)
   {
    stopSignal = 1;
   }
#endif

struct StopSignalInitializer
{
    StopSignalInitializer()
    {
        #ifndef UMBA_MCU_USED
        signal(SIGINT, handleControlC);
        #endif
    }
};

#ifndef UMBA_RTKOS_NO_DRIVERS
    #include "drivers/basic_types_dump.h"
    #include "drivers/messages_dump.h"
#endif


namespace umba
{
namespace rtkos
{


//-----------------------------------------------------------------------------
namespace
{
    //umba::SimpleFormatter *pLogFormatter = 0;
    umba::NulCharWriter   nulCharWritter;
    umba::SimpleFormatter formatter( &nulCharWritter );
    umba::SimpleFormatter localFormatter( &nulCharWritter );
    umba::ihc::IhcOctetStreamCharWriter octetStreamCharWriter = umba::ihc::IhcOctetStreamCharWriter();
}
//-----------------------------------------------------------------------------



struct TimerInfo
{
    TimerId             timerId;   // Выдано при создании таймера. Лучше использовать 32ух битный тип (или 16 бит будет достаточно?)
    TimerEventId        eventId;   // Параметр
    ITimerHandler       *pHandler;  // Параметр
    TimeTick            period;    // Параметр
    TimeTick            lastShotTick; // время последнего срабатывания
}; // 2+2+4+4+4


#ifndef UMBA_RTKOS_NO_DRIVERS


struct DriverInfo
{
    DriverAddress          driverAddress    = {};
    DriverSubclassId       driverSubclassId =  0;
    size_t                 driverTableIndex =  0;
    IDriverPrivate*        pDriverPrivate   =  0;

    DriverInfo( const  DriverAddress &addr   = DriverAddress()
              , DriverSubclassId  subcls = 0
              , size_t            idx    = 0
              , IDriverPrivate*   pPriv = 0
              )
        : driverAddress   (addr)
        , driverSubclassId(subcls)
        , driverTableIndex(idx)
        , pDriverPrivate  (pPriv)
        {
        }

    int compareTo( const DriverInfo &other, bool allowMask = false ) const
    {
        return driverAddress.compareTo( other.driverAddress, allowMask );
    }

}; // struct DriverInfo


inline
void dumpDriverInfo( const DriverInfo &info )
{
    using namespace umba::omanip;

    dumpDriverAddress( info.driverAddress );

    UMBA_RTKOS_LOG<<", subclassId: "<<hex<<groupsize(8)<<info.driverSubclassId;
    UMBA_RTKOS_LOG<<", index in driver table: "<<hex<<groupsize(8)<<info.driverTableIndex;
    UMBA_RTKOS_LOG<<", ptr priv: "<<hex<<groupsize(8)<<(uintptr_t)info.pDriverPrivate;
    UMBA_RTKOS_LOG<<endl;
}



struct DriverInfoLessByClassOnly
{
    bool operator()( const DriverInfo &d1, const DriverInfo &d2 ) const
    {
        return d1.driverAddress.classId < d2.driverAddress.classId;
    }
};

struct DriverInfoStrictLess
{
    bool operator()( const DriverInfo &d1, const DriverInfo &d2 ) const
    {
        if ( 0 > d1.compareTo( d2,  /* allowMask */ false ))
            return true;
        return false;
    }
};

struct DriverInfoMaskedLess
{
    bool operator()( const DriverInfo &d1, const DriverInfo &d2 ) const
    {
        if ( 0 > d1.compareTo( d2,  /* allowMask */ true ))
            return true;
        return false;
    }
};




struct DriverClientInfo
{
    DriverAddress             driverAddress        = {};
    IDriverClientHandler*     pDriverClientHandler =  0;

    DriverClientInfo( )
        : driverAddress(DriverAddress())
        , pDriverClientHandler(0)
    {
    }

    DriverClientInfo( const DriverAddress &addr)
        : driverAddress(addr)
        , pDriverClientHandler(0)
    {
    }

    DriverClientInfo( const DriverAddress &addr, IDriverClientHandler* pHandler)
        : driverAddress(addr)
        , pDriverClientHandler(pHandler)
    {}

    int compareTo( const DriverClientInfo &other, bool allowMask = false ) const
    {
        return driverAddress.compareTo( other.driverAddress, allowMask );
    }

}; // struct DriverClientInfo


inline
void dumpDriverClientInfo( const DriverClientInfo &info )
{
    using namespace umba::omanip;

    dumpDriverAddress( info.driverAddress );

    UMBA_RTKOS_LOG<<", ptr handler: "<<hex<<groupsize(8)<<(uintptr_t)info.pDriverClientHandler;
    UMBA_RTKOS_LOG<<endl;
}



struct DriverClientInfoStrictLess
{
    bool operator()( const DriverClientInfo &d1, const DriverClientInfo &d2 ) const
    {
        if ( 0 > d1.compareTo( d2,  /* allowMask */ false ))
            return true;
        return false;
    }
};

struct DriverClientInfoMaskedLess
{
    bool operator()( const DriverClientInfo &d1, const DriverClientInfo &d2 ) const
    {
        if ( 0 > d1.compareTo( d2,  /* allowMask */ true ))
            return true;
        return false;
    }
};

struct DriverClientInfoLessByClassOnly
{
    bool operator()( const DriverClientInfo &d1, const DriverClientInfo &d2 ) const
    {
        return d1.driverAddress.classId < d2.driverAddress.classId;
    }
};



#endif






// UMBA_TOO_LOW_MEM
#ifdef UMBA_TOO_LOW_MEM
    #define LIST_ITEM_INDEX_TYPE   uint8_t
#else
    #define LIST_ITEM_INDEX_TYPE   uint16_t
#endif

typedef umba::static_list< TimerInfo, LIST_ITEM_INDEX_TYPE > TimersList; // ( umba::reserve_size(32) );
typedef umba::static_list< Message  , LIST_ITEM_INDEX_TYPE > MessagesList; // ( umba::reserve_size(32) );
typedef IPollCapable* IPollCapablePtr;
typedef umba::static_list< IPollCapablePtr, LIST_ITEM_INDEX_TYPE > PollSchedulerList; // ( umba::reserve_size(32) );


typedef IMessageFilter* IMessageFilterPtr;


struct IOsImpl : implements IOs
{

    UMBA_BEGIN_INTERFACE_MAP( )
         UMBA_IMPLEMENT_INTERFACE( IOs )
    UMBA_END_INTERFACE_MAP()

    IOsImpl()
    : highPollsSchedulerList( umba::reserve_size(UMBA_RTKOS_MAX_HIGH_POLLS) )
    , timersList( umba::reserve_size(UMBA_RTKOS_MAX_TIMERS) )
    , messagesList( umba::reserve_size(UMBA_RTKOS_MESSAGE_QUEUE_SIZE) )
    {
        StopSignalInitializer stopSignalInitializer;
        umba::time_service::init();
        umba::time_service::start();
    }


    virtual
    void getOsName( umba::ihc::IOctetOStream *pStreamTo ) override
    {
        static const char* osName = "RTK OS";
        pStreamTo->write( osName, strlen(osName) );
    }

    virtual
    unsigned getOsVersionMajor( ) override
    {
        return 1;
    }

    virtual
    unsigned getOsVersionMinir( ) override
    {
        return 0;
    }

    virtual
    size_t getOsSize( ) override
    {
        return sizeof(*this)
             + highPollsSchedulerList.total_allocated_size()
             + timersList.total_allocated_size()
             + messagesList.total_allocated_size()
             ;
    }

    virtual
    void logOsInfo( OsInfoLogLevel osInfoLogLevel ) override
    {
        using namespace umba::omanip;
        umba::ihc::IOctetOStreamImplBuf<32> strTo;

        switch(osInfoLogLevel)
        {
            case OsInfoLogLevel::osVersion:
                                   {
                                       getOsName( &strTo );
                                       UMBA_RTKOS_LOG<<strTo.c_str()<<" v"<<getOsVersionMajor()<<"."<<getOsVersionMinir()<<endl;
                                   }
                                   break;

            case OsInfoLogLevel::osStarting: 
                                   {
                                       UMBA_RTKOS_LOG<<"Staring on ";
                                       #if defined(WIN32) || defined(_WIN32)
                                           #if defined(WIN64) || defined(_WIN64)
                                               static const char *host = "Win64";
                                           #else
                                               static const char *host = "Win32";
                                           #endif
                                       #elif defined(UMBA_MCU_USED)
                                           static const char *host = "MCU";
                                       #else
                                           static const char *host = "Unknown host platform";
                                       #endif

                                       #if defined(UMBA_QT_USED)
                                           static const char *hostExtra = "Qt";
                                       #elif defined(UMBA_MCU_USED)
                                           #if defined(STM32F0_SERIES)
                                               static const char *hostExtra = "STM32F0 Series";
                                           #elif defined(STM32F1_SERIES)
                                               static const char *hostExtra = "STM32F1 Series";
                                           #elif defined(STM32F2_SERIES)
                                               static const char *hostExtra = "STM32F2 Series";
                                           #elif defined(STM32F3_SERIES)
                                               static const char *hostExtra = "STM32F3 Series";
                                           #elif defined(STM32F4_SERIES)
                                               static const char *hostExtra = "STM32F4 Series";
                                           #elif defined(STM32F7_SERIES)
                                               static const char *hostExtra = "STM32F7 Series";
                                           #elif defined(STM32L0_SERIES)
                                               static const char *hostExtra = "STM32L0 Series";
                                           #elif defined(STM32L1_SERIES)
                                               static const char *hostExtra = "STM32L1 Series";
                                           #elif defined(STM32L4_SERIES)
                                               static const char *hostExtra = "STM32L4 Series";
                                           #else
                                               static const char *hostExtra = 0;
                                           #endif
                                       #else
                                           static const char *hostExtra = 0;
                                       #endif

                                       UMBA_RTKOS_LOG<<host;
                                       if (hostExtra)
                                           UMBA_RTKOS_LOG<<"/"<<hostExtra;

                                       if (UMBA_RTKOS_OS->isDebuggerPresent())
                                       {
                                           UMBA_RTKOS_LOG<<" under debugger";
                                       }

                                       UMBA_RTKOS_LOG<<endl;
                                   }
                                   break;

            case OsInfoLogLevel::osClocks: 
                                   {
                                       #ifndef UMBA_RTKOS_NO_PERIPH
                                           #ifndef UMBA_MCU_USED
                                               UMBA_RTKOS_LOG<<"Clock: System default"<<endl;
                                           #else
                                               UMBA_RTKOS_LOG<<umba::periph::getClockBusName(umba::periph::ClockBus::OSCCLK) <<": "  <<umba::periph::clockGetFreq(umba::periph::ClockBus::OSCCLK)  <<" Hz"<<endl;
                                               UMBA_RTKOS_LOG<<umba::periph::getClockBusName(umba::periph::ClockBus::CORECLK)<<": "  <<umba::periph::clockGetFreq(umba::periph::ClockBus::CORECLK) <<" Hz"<<endl;
                                               UMBA_RTKOS_LOG<<umba::periph::getClockBusName(umba::periph::ClockBus::SYSCLK) <<": "  <<umba::periph::clockGetFreq(umba::periph::ClockBus::SYSCLK)  <<" Hz"<<endl;
                                               UMBA_RTKOS_LOG<<endl;
                                           #endif
                                       #endif
                                   }
                                   break;

            case OsInfoLogLevel::osSize: 
                                   {
                                       UMBA_RTKOS_LOG<<"OS size (RAM): "<<UMBA_RTKOS_OS->getOsSize( )<<endl;

                                       #if defined(UMBA_MCU_USED)
                                           UMBA_RTKOS_LOG<<"Stack size: ";
                                           #if defined(Stack_Size)
                                               UMBA_RTKOS_LOG<<Stack_Size<<" ("<<hex<<(uint16_t)Stack_Size<<")\n";
                                           #else
                                               UMBA_RTKOS_LOG<<"unknown, may be default (0x0800), please check project ASM defines"<<"\n";
                                           #endif
                                          
                                           UMBA_RTKOS_LOG<<"Heap size: ";
                                           #if defined(Heap_Size)
                                               UMBA_RTKOS_LOG<<Heap_Size<<" ("<<hex<<(uint16_t)Stack_Size<<")\n";
                                           #else
                                               UMBA_RTKOS_LOG<<"unknown, may be default (0x0800), please check project ASM defines"<<"\n";
                                           #endif
                                       #endif
                                       UMBA_RTKOS_LOG<<endl;
                                   }
                                   break;

            case OsInfoLogLevel::osSizeDetails: 
                                   {
                                   UMBA_RTKOS_LOG<<"sizeof self: "<<sizeof(*this)<<"\n"
                                                 <<"sizeof hp list: "<<highPollsSchedulerList.total_allocated_size()<<" bytes of total "<<highPollsSchedulerList.max_size()<<" items, "<<(highPollsSchedulerList.total_allocated_size()/highPollsSchedulerList.max_size())<<" bytes per item\n"
                                                 <<"sizeof timers list: "<<timersList.total_allocated_size()<<" bytes of total "<<timersList.max_size()<<" items, "<<(timersList.total_allocated_size()/timersList.max_size())<<" bytes per item\n"
                                                 <<"sizeof messages queue: "<<messagesList.total_allocated_size()<<" bytes of total "<<messagesList.max_size()<<" items, "<<(messagesList.total_allocated_size()/messagesList.max_size())<<" bytes per item"<<endl;
                                   UMBA_RTKOS_LOG<<endl;
                                   }
                                   break;

            case OsInfoLogLevel::osSizeDetailsMore: 
                                   {
                                   UMBA_RTKOS_LOG<<"sizeof TimerInfo: "<< sizeof(TimerInfo)<<"\n"
                                                 //<<"sizeof Message: "<< sizeof(Message)<<"\n"
                                                 <<"sizeof Message: "<< sizeof(Message)<<"\n"
                                                 <<"sizeof MessageTimer: "<< sizeof(MessageTimer)<<"\n"
                                                 <<"sizeof MessageKeyboard: "<< sizeof(MessageKeyboard)<<"\n"
                                                 <<"sizeof umba::drivers::MessageDriver: "<< sizeof(umba::drivers::MessageDriver)<<"\n"
                                                 <<"sizeof nulCharWritter: "<< sizeof(nulCharWritter)<<endl;
                                   UMBA_RTKOS_LOG<<endl;
                                   }
                                   break;
                                   
/*
            case OsInfoLogLevel::: 
                                   {
                                   }
                                   break;

            case OsInfoLogLevel::: 
                                   {
                                   }
                                   break;
*/        

        }
    }

    //struct TimerInfo
    //struct DriverClientInfo

    virtual
    bool isOsStarted( ) override
    {
        return m_isStarted;
    }

    //------------------------
    virtual
    int run( RunLevel a_runLevel ) override
    {
        runLevel = a_runLevel;

        using namespace umba::omanip;

        //m_isRunning = true;
        //auto idle = umba::makeSimpleIdleCapable( []{ return true; } );
        //return run( &idle );
        m_isRunning = true;

        while(!stopSignal)
        {
            if (!processTimers())
            {
                if ( currentRunLevel >= runLevel )
                {
                    // idle handler called only on normal work
                    if (pIdleHandler)
                        pIdleHandler->onIdle();
                }
            }

            // Выгребаем все сообщения
            messagesDispatch();

            if ( currentRunLevel >= runLevel )
            {
                m_isStarted = true;
                pollScheduleDoPollNormal();
            }
            else
            {
                //UMBA_RTKOS_LOG<<"Run startups - currentRunLevel: "<<currentRunLevel<<endl;
                size_t callCount = 0;
                for( size_t i = 0; i!=normalPollsCount; ++i )
                {
                    auto pPoll = normalPollsSchedulerList[i];

                    //UMBA_RTKOS_LOG<<"Task "<<hex<<(size_t)pPoll<<": "

                    if (auto res = pPoll-> queryInterface< IStarterTask >())
                    {
                        RunLevel taskRunLevel = res.value->getTaskRunLevel();
                        //UMBA_RTKOS_LOG<<" RunLevel - "<<taskRunLevel<<endl;

                        if (taskRunLevel!=currentRunLevel)
                        {
                            continue;
                        }

                        if (!pPoll->isReadyForPoll())
                            continue;

                        pPoll->poll();
                        callCount++;
                    }
                    else
                    {
                        //UMBA_RTKOS_LOG<<" not a startup task"<<endl;
                    }

                    /*
                    if (normalPollsSchedulerList[i]->isReadyForPoll())
                    {
                        auto pPoll = normalPollsSchedulerList[i];
                        if (isPollYielded(pPoll))
                           continue;
                        normalPollsStack[normalPollInProgess] = pPoll; // save task pointer in stack
                        pPoll->poll();
                        normalPollsStack[normalPollInProgess] = 0;
                        pollScheduleDoPollHigh();
                    }
                    */
                }

                if (!callCount)
                    ++currentRunLevel;
            }
        }

        return 0;
    }


/*
    virtual
    int run( IIdleCapable *pIdle ) override
    {
        pIdleHandler = pIdle;
        return run();
    }
*/

    //------------------------
    virtual
    umba::SimpleFormatter& getLogStream() override
    {
        //if (pLogFormatter)
        //    return *pLogFormatter;

        return formatter;
    }

    virtual
    umba::SimpleFormatter& getUnsafeStream(umba::ICharWriter *pWritter) override
    {
        UMBA_ASSERT(pWritter);
        localFormatter.setCharWritter( pWritter );
        return localFormatter;
        //formatter.setCharWritter( pWritter );
    }

    virtual
    umba::SimpleFormatter& getUnsafeStream(umba::ihc::IOctetOStream *pStreamTo) override
    {
        UMBA_ASSERT(pStreamTo);
        octetStreamCharWriter.setStream(pStreamTo);
        localFormatter.setCharWritter( &octetStreamCharWriter );
        return localFormatter;
    }

    //------------------------
    virtual
    bool pollScheduleAdd( IPollCapable * p, PollPriority priority ) override
    {
        UMBA_ASSERT(p);

        if (priority==PollPriority::normal)
        {
            UMBA_ASSERT(m_isRunning==false); // don't allow to add normal polls during app cycle
            UMBA_ASSERT( normalPollsCount < UMBA_RTKOS_MAX_NORMAL_POLLS );
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            normalPollsSchedulerList[ normalPollsCount++ ] = p;
            return true;
        }
        else
        {
            //UMBA_ASSERT( highPollsSchedulerList.size() < highPollsSchedulerList.max_size() );
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

            if (highPollsSchedulerList.size() >= highPollsSchedulerList.max_size())
            {
                UMBA_DEBUG_SESSION_ASSERT_FAIL(); // Stops only if under debugger
                return false; // Can't add poll, limping further
            }

            highPollsSchedulerList.push_back( p );
            return true;
        }

    }

    //------------------------
    // А вот тут мы ассертимся для Low приоритета или пытаемся выдать каким-либо образом что-то осмысленное?
    virtual
    bool pollScheduleRemove( IPollCapable * p, PollPriority priority ) override
    {
        //UMBA_ASSERT(p);

        UMBA_ASSERT(priority!=PollPriority::normal); // низкоприоритетные задачи не могут быть удалены

        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

        auto iter = highPollsSchedulerList.begin();

        for( ; iter != highPollsSchedulerList.end(); ++iter )
        {
            if (*iter==p)
            {
                highPollsSchedulerList.erase(iter);
                return true;
            }
        }
        return false;
    }

    //------------------------
    virtual
    bool pollScheduleDoPoll( PollPriority priority ) override
    {
        if (priority==PollPriority::normal)
            return pollScheduleDoPollNormal();
        else
            return pollScheduleDoPollHigh();
    }

    //------------------------
    #ifdef UMBA_RTKOS_ENABLE_YIELD


    void dumpYieldedPolls( const char* label, IPollCapablePtr asquireFor)
    {
        #ifdef UMBA_RTKOS_DEBUG_YIELD
            using namespace umba::omanip;
            UMBA_RTKOS_LOG<<"  "<<label<<": yielded polls:  ";
            for( size_t i=0; i!=yieldedPollsCount; ++i)
            {
                UMBA_RTKOS_LOG<<""<<hex<<(size_t)yieldedPolls[i]<<", ";
            }
            UMBA_RTKOS_LOG<<" - asqired: "<<hex<<(size_t)asquireFor;
            UMBA_RTKOS_LOG<<endl;
        #endif
    }

    //------------------------
    virtual
    bool pollScheduleYield( TimeTick yieldPeriod ) override
    {
        return pollScheduleYieldImpl( yieldPeriod, 0 );
    }

    virtual
    bool pollScheduleYield( TimeTick yieldPeriod, IIdleCapable *pIdle ) override
    {
        return pollScheduleYieldImpl( yieldPeriod, pIdle );
    }

    UMBA_FORCE_INLINE_MEMBER( bool pollScheduleYieldImpl( TimeTick yieldPeriod, IIdleCapable *pIdle ) )
    {
        #if defined(UMBA_MCU_USED)
        if (UMBA_IS_IN_ISR()) // Yielding not allowed in interrupts
            return false;
        #endif

        if ( currentRunLevel < runLevel )
        {
            UMBA_ASSERT_FAIL();
        }


        using namespace umba::omanip;

        IPollCapablePtr pYieldedPoll = 0;

        /* Win64 
           0x001DEB18-0x001DE2C8 = 0x850 (2128)
           0x002CE8E8-0x002CE098 = 0x850 (2128)

           Stack - this           - 8  param
                   yieldPeriod    - 8  param (or 4)?
                   pIdle          - 8  param
                   pYieldedPoll   - 8  local
                   startTick      - 4  local
                   stoppedByIdle  - 4  local
                   umba_autoLock_3	??? local

                   40 + ???

        */
        #ifdef UMBA_RTKOS_TRACE_YIELD_STACK_PTR
            UMBA_RTKOS_LOG<<"Stack (pollScheduleYield): "<<hex<<(size_t)&pYieldedPoll<<endl;
        #endif

        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            UMBA_ASSERT(normalPollInProgess!=0); // called not from polled object
            UMBA_ASSERT(normalPollsStack[normalPollInProgess]!=0); // something goes wrong
            pYieldedPoll = normalPollsStack[normalPollInProgess];

            if (yieldedFindIndex( pYieldedPoll ) < yieldedPollsCount)
            {
                #ifdef UMBA_RTKOS_DEBUG_YIELD
                    dumpYieldedPolls("Check is yielded", pYieldedPoll);
                    UMBA_RTKOS_LOG<<"    Poll "<<yieldPeriod<<"ms, id: "<<hex<<(size_t)pYieldedPoll<<" - allready yielded"<<endl<<endl;
                #endif
                return false;
            }

            #ifdef UMBA_RTKOS_DEBUG_YIELD
                dumpYieldedPolls("Before add", pYieldedPoll);
            #endif
            if (!yieldAdd( pYieldedPoll ))
            {
                #ifdef UMBA_RTKOS_DEBUG_YIELD
                    UMBA_RTKOS_LOG<<"    Poll "<<yieldPeriod<<"ms, id: "<<hex<<(size_t)pYieldedPoll<<" - adding failed"<<endl;
                    dumpYieldedPolls("After add", pYieldedPoll);
                    UMBA_RTKOS_LOG<<endl;
                #endif
                return false;
            }
            #ifdef UMBA_RTKOS_DEBUG_YIELD
                UMBA_RTKOS_LOG<<"    Poll "<<yieldPeriod<<"ms, id: "<<hex<<(size_t)pYieldedPoll<<" - added"<<endl;
                dumpYieldedPolls("After add", pYieldedPoll);
                UMBA_RTKOS_LOG<<endl;
            #endif

        }

        normalPollsStack[normalPollInProgess] = 0;

        auto startTick = umba::time_service::getCurTimeMs();
        bool stoppedByIdle = false;

        while( (umba::time_service::getCurTimeMs()-startTick)<yieldPeriod )
        {
            // Генерируем таймерные сообщения
            if (!processTimers())
            {
                if (pIdleHandler)
                    pIdleHandler->onIdle();
            }

            // Выгребаем все сообщения
            messagesDispatch();

            pollScheduleDoPollNormal();


            if (pIdle) // Елдовская фишка - в главном run'е такого нет
            {
                bool idleRes = pIdle->onIdle();
                if (!idleRes)
                {
                    stoppedByIdle = true;
                }
            }

        }

        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            #ifdef UMBA_RTKOS_DEBUG_YIELD
                dumpYieldedPolls("Before remove", pYieldedPoll);
            #endif
            if (!yieldRemove( pYieldedPoll ))
            {
                #ifdef UMBA_RTKOS_DEBUG_YIELD
                    UMBA_RTKOS_LOG<<"    Poll "<<yieldPeriod<<"ms, id: "<<hex<<(size_t)pYieldedPoll<<" - remove failed"<<endl;
                    dumpYieldedPolls("After remove", pYieldedPoll);
                #endif
            }
            else
            {
                #ifdef UMBA_RTKOS_DEBUG_YIELD
                    UMBA_RTKOS_LOG<<"    Poll "<<yieldPeriod<<"ms, id: "<<hex<<(size_t)pYieldedPoll<<" - removed"<<endl;
                    dumpYieldedPolls("After remove", pYieldedPoll);
                #endif
            }
            #ifdef UMBA_RTKOS_DEBUG_YIELD
                UMBA_RTKOS_LOG<<endl;
            #endif

            if (stoppedByIdle) // not full interval waited
                return false;
        }

        return true; // exiting by timeout
    
    }

    //IPollCapablePtr                  normalPollsStack[UMBA_RTKOS_MAX_YIELDS];
    //IPollCapablePtr                  yieldedPolls[UMBA_RTKOS_MAX_YIELDS];
    //size_t                           yieldedPollsCount = 0;
        // 

    //IPollCapablePtr                  normalPollsSchedulerList[UMBA_RTKOS_MAX_NORMAL_POLLS];
    //volatile size_t                  normalPollsCount    = 0;


protected:

    // !!! thread unsafe
    bool yieldRemove( IPollCapablePtr pPoll )
    {
        using namespace umba::omanip;

        size_t idx = yieldedFindIndex( pPoll, false /* true */ );
        #ifdef UMBA_RTKOS_DEBUG_YIELD
            UMBA_RTKOS_LOG<<"  yieldRemove, idx: "<<idx<<endl;
        #endif
        if (idx>=yieldedPollsCount)
        {
            #ifdef UMBA_RTKOS_DEBUG_YIELD
                UMBA_RTKOS_LOG<<"  yieldRemove, idx out of range"<<endl;
            #endif
            return false;
        }

        if (yieldedPolls[idx]!=pPoll)
        {
            #ifdef UMBA_RTKOS_DEBUG_YIELD
                UMBA_RTKOS_LOG<<"  yieldRemove, found, but not equal to pPoll"<<endl;
            #endif
            return false;
        }

        size_t numToMove = yieldedPollsCount - (idx+1) ;
        #ifdef UMBA_RTKOS_DEBUG_YIELD
            UMBA_RTKOS_LOG<<"  yieldRemove, numToMove: "<<numToMove<<endl;
        #endif
        if (!numToMove)
        {
            --yieldedPollsCount;
            #ifdef UMBA_RTKOS_DEBUG_YIELD
                UMBA_RTKOS_LOG<<"  yieldRemove, nothing to move"<<endl;
            #endif
            return true;
        }

        memmove( &yieldedPolls[idx], &yieldedPolls[idx+1], numToMove*sizeof(IPollCapablePtr) );
        --yieldedPollsCount;

        return true;
    }

    bool isPollYielded( IPollCapablePtr pPoll ) 
    {
        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
        return yieldedFindIndex( pPoll ) < yieldedPollsCount;
    }

    // !!! thread unsafe
    size_t yieldedFindIndex( IPollCapablePtr pPoll, bool showLog = false)
    {
        //UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
        using namespace umba::omanip;

        if (!yieldedPollsCount)
            return 0;

        auto B = &yieldedPolls[0];
        auto E = &yieldedPolls[yieldedPollsCount];

        if (showLog)
        {
            #ifdef UMBA_RTKOS_DEBUG_YIELD
                UMBA_RTKOS_LOG<<"    Find yielded, B: "<<hex<<(size_t)B<<", E: "<<hex<<(size_t)E<<", yielded size: "<<yieldedPollsCount<<", look for: "<<hex<<(size_t)pPoll<<endl;
            #endif
        }

        auto lwr = std::lower_bound( B, E, pPoll );
        //auto upr = std::upper_bound( B, E, pPoll );

        //_First = std::lower_bound(_First, _Last, _Val);
        //return _First == _Last ? _Last : (       _Val < *_First   ? _Last : _First);

        //return lwr==E ? yieldedPollsCount : ( *lwr!=pPoll ? yieldedPollsCount : (lwr-B) );
        if (lwr==E)
        {
            if (showLog)
            {
                #ifdef UMBA_RTKOS_DEBUG_YIELD
                    UMBA_RTKOS_LOG<<"    Find yielded, lwr==E - not found"<<endl;
                #endif
            }
            return yieldedPollsCount;
        }
        if (*lwr!=pPoll)
        {
            if (showLog)
            {
                #ifdef UMBA_RTKOS_DEBUG_YIELD
                    UMBA_RTKOS_LOG<<"    Find yielded, *lwr!=pPoll - not found"<<endl;
                #endif
            }
            return yieldedPollsCount;
        }

        if (showLog)
        {
            #ifdef UMBA_RTKOS_DEBUG_YIELD
                UMBA_RTKOS_LOG<<"    Find yielded, found, return lwr-B"<<endl;
            #endif
        }
        return lwr-B;
    }

    // !!! thread unsafe
    bool yieldAdd( IPollCapablePtr pPoll )
    {
        //#if defined(UMBA_MCU_USED)
        //if (UMBA_IS_IN_ISR()) // Yielding not allowed in interrupts
        //    return false;
        //#endif

        //UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
        if ( yieldedPollsCount>=UMBA_RTKOS_MAX_YIELDS )
        {
            UMBA_DEBUG_SESSION_ASSERT_FAIL(); // Stops only if under debugger
            return false;
        }
        size_t idxFound = 0;
        for( ; idxFound!=normalPollsCount; ++idxFound)
        {
            if (normalPollsSchedulerList[idxFound]==pPoll)
                break;
        }

        if (idxFound>=normalPollsCount)
        {
            // pPoll is not a regular, yield not allowed in high priority tasks
            //UMBA_DEBUG_SESSION_ASSERT_FAIL(); // Stops only if under debugger
            UMBA_ASSERT_FAIL();
            return false;
        }

        yieldedPolls[yieldedPollsCount++] = pPoll;
        // make it sorted for faster search
        std::sort( &yieldedPolls[0], &yieldedPolls[yieldedPollsCount]);
        
        return true;
    }

public:


    #endif // UMBA_RTKOS_ENABLE_YIELD


    bool pollScheduleDoPollNormal()
    {
        #if defined(UMBA_MCU_USED)
        if (UMBA_IS_IN_ISR()) // Polling not allowed in interrupts
            return false;
        #endif

        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            //if (normalPollInProgess)
            //    return false;

            normalPollInProgess++;

            #ifdef UMBA_RTKOS_ENABLE_YIELD
            if (normalPollInProgess>=UMBA_RTKOS_MAX_YIELDS)
            {
                UMBA_DEBUG_SESSION_ASSERT_FAIL(); // Stops only if under debugger
                normalPollInProgess--;
                return false;
            }
            #endif
        }

        for( size_t i = 0; i!=normalPollsCount; ++i )
        {
            if (normalPollsSchedulerList[i]->isReadyForPoll())
            {
                auto pPoll = normalPollsSchedulerList[i];
                #ifdef UMBA_RTKOS_ENABLE_YIELD
                if (isPollYielded(pPoll))
                   continue;
                #endif
                normalPollsStack[normalPollInProgess] = pPoll; // save task pointer in stack
                pPoll->poll();
                normalPollsStack[normalPollInProgess] = 0;
                pollScheduleDoPollHigh();
            }
        }

        normalPollsStack[normalPollInProgess] = 0;

        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            normalPollInProgess--;
        }

        return true;
    }

    //------------------------
    bool pollScheduleDoPollHigh()
    {
        #if defined(UMBA_MCU_USED)
        if (UMBA_IS_IN_ISR()) // Polling not allowed in interrupts
            return false;
        #endif

        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            if (highPollInProgess)
                return false;

            highPollInProgess++;
        }

        // Copy to temporary buf
        IPollCapablePtr polls[UMBA_RTKOS_MAX_HIGH_POLLS];
        size_t numPolls = 0;
        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

            auto iter = highPollsSchedulerList.begin();           
            for( ; iter != highPollsSchedulerList.end(); ++iter, ++numPolls )
            {
                polls[numPolls] = *iter;
            }
        }

        for( size_t i = 0; i!=numPolls; ++i )
        {
            if (polls[i]->isReadyForPoll())
            {
                polls[i]->poll();
            }
        }

        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            highPollInProgess--;
        }

        return true;
    }

    //------------------------
    virtual
    TimerId timerSet( TimerId timerId, TimeTick period ) override
    {
        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

        auto iter = timersList.begin();           
        for( ; iter != timersList.end(); ++iter )
        {
            if (iter->timerId== timerId)
            {
                // Просто переустанавливаем время у существующего таймера
                iter->period = period;
                iter->lastShotTick = umba::time_service::getCurTimeMs();
                return iter->timerId;
            }
        }

        return timer_id_invalid;
    }

    //------------------------
    virtual
    TimerId timerSet( ITimerHandler *pHandler, TimerEventId eventId, TimeTick period ) override
    {
        //UMBA_ASSERT(pHandler); // null handle allowed
        //UMBA_ASSERT(period); // zero period allowed

        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

        auto iter = timersList.begin();           
        for( ; iter != timersList.end(); ++iter )
        {
            if (iter->pHandler==pHandler && iter->eventId==eventId )
            {
                // Просто переустанавливаем время у существующего таймера
                iter->period = period;
                iter->lastShotTick = umba::time_service::getCurTimeMs();
                return iter->timerId;
            }
        }

        if (timersList.size() >= timersList.max_size())
        {
            UMBA_DEBUG_SESSION_ASSERT_FAIL(); // Stops only if under debugger
            return false; // Can't add timer, limping further
        }

        // Надо создать таймер
        if (nextTimerId==0)
        {
            // У нас закончились IDшники
            // Нужно стартовать от уже существующих
            auto iter = timersList.begin();           
            for( ; iter != timersList.end(); ++iter )
            {
                if (iter->timerId > nextTimerId)
                    nextTimerId = iter->timerId;
            }

            nextTimerId++; // На 1 больше существующего
        }

        auto res = nextTimerId;
        timersList.push_back( TimerInfo{ nextTimerId++, eventId, pHandler, period, umba::time_service::getCurTimeMs() } );
        return res;
    }

    virtual
    TimerId timerFind( ITimerHandler *pHandler, TimerEventId eventId ) override
    {
        UMBA_ASSERT(pHandler);

        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

        auto iter = timersList.begin();           
        for( ; iter != timersList.end(); ++iter )
        {
            if (iter->pHandler==pHandler && iter->eventId==eventId )
            {
                return iter->timerId;
            }
        }
        return timer_id_invalid;
    }

    virtual
    bool timerKill( TimerId timerId ) override
    {
        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

        auto iter = timersList.begin();           
        for( ; iter != timersList.end(); ++iter )
        {
            if (iter->timerId==timerId )
            {
                timersList.erase(iter);
                return true;
            }
        }
        return false;
    }

    virtual
    bool timerKill( ITimerHandler *pHandler, TimerEventId eventId ) override
    {
        UMBA_ASSERT(pHandler);

        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

        auto iter = timersList.begin();           
        for( ; iter != timersList.end(); ++iter )
        {
            if (iter->pHandler==pHandler && iter->eventId==eventId )
            {
                timersList.erase(iter);
                return true;
            }
        }
        return false;
    }

    bool processTimers()
    {
        #if defined(UMBA_MCU_USED)
        if (UMBA_IS_IN_ISR()) // Timers processing not allowed in interrupts
            return false;
        #endif

        pollScheduleDoPollHigh();

        Message shotMessages[UMBA_RTKOS_MAX_SHOOTED_TIMERS] = { };
        size_t shotCount = 0;

        TimeTick tickNow = umba::time_service::getCurTimeMs();


        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
           
            if ( (tickNow-timersProcessedTick) < UMBA_RTKOS_TIMERS_PREC)
            {
                return false;
            }

            timersProcessedTick = tickNow;
           
            auto iter = timersList.begin();           
            for( ; iter != timersList.end() && shotCount<UMBA_RTKOS_MAX_SHOOTED_TIMERS; ++iter )
            {
                if (!iter->period) // period 0 means that timer is stopped, but not removed from queue
                    continue;

                if ( (tickNow - iter->lastShotTick) < iter->period )
                    continue;
           
                shotMessages[shotCount].id = message_timer_id;
                shotMessages[shotCount].messageTimer.eventId      = iter->eventId;
                shotMessages[shotCount].messageTimer.timerHandler = iter->pHandler;

                iter->lastShotTick = tickNow;
           
                ++shotCount;
            }
        } // end of critical section

        pollScheduleDoPollHigh();

        for( size_t i = 0; i!=shotCount; ++i )
        {
            messagePost(shotMessages[i]);
            pollScheduleDoPollHigh();
        }

        return true;

    }

    bool messagePostImpl( Message msg, bool hiPriorityMessage = false )
    {
        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

        if (messagesList.size() >= messagesList.max_size())
        {
            UMBA_DEBUG_SESSION_ASSERT_FAIL(); // Stops only if under debugger
            return false; // Can't add message, limping further
        }

        msg.tick = umba::time_service::getCurTimeMs();

        if (m_debugBreakAllowed)
        {
            bool msgIsSame = m_debugBreakMessage.id==msg.id;
            bool bBreak = false;

            if (m_debugBreakMessage.id==message_id_any)
            {
                msgIsSame = true;
            }

            if (msgIsSame)
            {
                switch(msg.id)
                {
                    case message_id_keyboard:
                         {
                             bool kbdIsSame = m_debugBreakMessage.messageKeyboard.keyboardId == msg.messageKeyboard.keyboardId;
                             if (m_debugBreakMessage.messageKeyboard.keyboardId==keyboard_id_any)
                             {
                                 kbdIsSame = true;
                             }

                             bool keyCodeIsSame = m_debugBreakMessage.messageKeyboard.keyCode == msg.messageKeyboard.keyCode;
                             if (m_debugBreakMessage.messageKeyboard.keyCode==VirtualKeyCode::virtual_code_any)
                             {
                                 keyCodeIsSame = true;
                             }

                             bBreak = kbdIsSame && keyCodeIsSame;
                         }
                         break;

                    case message_id_input_char:
                         {
                             bool kbdIsSame = m_debugBreakMessage.messageInputChar.keyboardId == msg.messageInputChar.keyboardId;
                             if (m_debugBreakMessage.messageInputChar.keyboardId==keyboard_id_any)
                             {
                                 kbdIsSame = true;
                             }

                             bool charCodeIsSame = m_debugBreakMessage.messageInputChar.charCode == msg.messageInputChar.charCode;
                             if (m_debugBreakMessage.messageInputChar.charCode==0)
                             {
                                 charCodeIsSame = true;
                             }

                             bBreak = kbdIsSame && charCodeIsSame;
                         }
                         break;

                    case message_id_timer:
                         {
                             //bool IsSame = m_debugBreakMessage. == msg.
                             bool eventIdIsSame = m_debugBreakMessage.messageTimer.eventId == msg.messageTimer.eventId;
                             if (m_debugBreakMessage.messageTimer.eventId==timer_id_any)
                             {
                                 eventIdIsSame = true;
                             }

                             bBreak = eventIdIsSame;
                         }
                         break;

                    #ifndef UMBA_RTKOS_NO_DRIVERS
                    case message_id_driver:
                         {
                             //bool IsSame = m_debugBreakMessage.messageDriver.header. == msg.messageDriver.header.
                             //if (m_debugBreakMessage.messageDriver.header.==)
                             using namespace umba::drivers;
                             
                             bool drvAddrIsSame = m_debugBreakMessage.messageDriver.header.pDriver == msg.messageDriver.header.pDriver;
                             if (m_debugBreakMessage.messageDriver.header.pDriver==driver_addr_any)
                             {
                                 drvAddrIsSame = true;
                             }

                             bool classIdIsSame = m_debugBreakMessage.messageDriver.header.classId == msg.messageDriver.header.classId;
                             if (m_debugBreakMessage.messageDriver.header.classId==class_id_any)
                             {
                                 classIdIsSame = true;
                             }

                             bool driverIdIsSame = m_debugBreakMessage.messageDriver.header.driverId == msg.messageDriver.header.driverId;
                             if (m_debugBreakMessage.messageDriver.header.driverId==driver_id_any)
                             {
                                 driverIdIsSame = true;
                             }


                             bool driverMessageIdIsSame = m_debugBreakMessage.messageDriver.header.driverMessageId == msg.messageDriver.header.driverMessageId;
                             if (m_debugBreakMessage.messageDriver.header.driverMessageId==umba::drivers::MessageId::driver_message_any)
                             {
                                 driverMessageIdIsSame = true;
                             }

                             if (msg.messageDriver.header.driverMessageId==umba::drivers::MessageId::driver_raw_data || msg.messageDriver.header.driverMessageId==umba::drivers::MessageId::driver_raw_data_request)
                             {
                                 //msg.messageDriver.rawData.deviceBusAddress
                                 bBreak = drvAddrIsSame && classIdIsSame && driverIdIsSame && driverMessageIdIsSame;
                             }
                             else if ( ((uint16_t)(msg.messageDriver.header.driverMessageId) & ~((uint16_t)(umba::drivers::MessageId::param_mask))) == 0 ) // переделать в isParam
                             {
                                 bool valueIdIsSame = m_debugBreakMessage.messageDriver.value.id == msg.messageDriver.value.id;
                                 if (m_debugBreakMessage.messageDriver.value.id==value_id_any)
                                 {
                                     valueIdIsSame = true;
                                 }
                                
                                 bBreak = drvAddrIsSame && classIdIsSame && driverIdIsSame && driverMessageIdIsSame && valueIdIsSame;
                             }
                             else
                             {
                                 bBreak = drvAddrIsSame && classIdIsSame && driverIdIsSame && driverMessageIdIsSame;
                             }
/*
                             bool valueIdIsSame = false;m_debugBreakMessage.messageDriver.header.valueId == msg.messageDriver.header.valueId;
                             if (m_debugBreakMessage.messageDriver.header.valueId==value_id_any)
                             {
                                 valueIdIsSame = true;
                             }

                             bBreak = drvAddrIsSame && classIdIsSame && driverIdIsSame && driverMessageIdIsSame && valueIdIsSame;
*/

                         }
                         break;
                    #endif

                } // switch(msg.id)

                if (bBreak)
                {
                    umba::debugBreak();
                }

            } // if (msgIsSame)

        } // if (m_debugBreakAllowed)

        //Message                          m_debugBreakMessage;
        //bool                             m_debugBreakAllowed = false;
/*
struct Message
{
    MessageId              id;
    TimeTick               tick;

    union
    {
        MessageTimer                      messageTimer;
        MessageKeyboard                   messageKeyboard;
        MessageInputChar                  messageInputChar;
        #ifndef UMBA_RTKOS_NO_DRIVERS
            umba::drivers::MessageDriver  messageDriver;
        #endif

    };
};

*/


        if (hiPriorityMessage)
            messagesList.push_front( msg );
        else
            messagesList.push_back( msg );

        return true;
    }

    virtual
    bool messagePost( const Message &msg ) override
    {
        return messagePostImpl( msg, false );
    }

    virtual
    bool messagePostHighPriority( const Message &msg ) override
    {
        return messagePostImpl( msg, true );
    }

    virtual
    void messagePostDebugBreak( const Message &msg ) override
    {
        m_debugBreakMessage = msg; 
        m_debugBreakAllowed = true; 
    }

    virtual
    void messagePostDebugBreakCtrl( bool allowBreak ) override
    {
        m_debugBreakAllowed = allowBreak; 
    }

    virtual
    bool messageFilterAdd( IMessageFilter *pFilter ) override
    {
        UMBA_ASSERT(m_isRunning==false); // don't allow to add normal polls during app cycle
        UMBA_ASSERT(pFilter!=0);
        UMBA_ASSERT( messageFiltersCount < UMBA_RTKOS_MAX_MESSAGE_FILTERS );
        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
        messageFilters[ messageFiltersCount++ ] = pFilter;
        return true;
    }
    
    virtual
    bool messageFilterAdd( IMessageFilter *pFilter, IMessageFilter *pRefFilter, MessageFilterInstallOrder order) override
    {
        UMBA_ASSERT(m_isRunning==false); // don't allow to add normal polls during app cycle
        UMBA_ASSERT(pFilter!=0);
        UMBA_ASSERT(pRefFilter!=0);
        UMBA_ASSERT( messageFiltersCount < UMBA_RTKOS_MAX_MESSAGE_FILTERS );
        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

        size_t refFilterIndex = 0;
        for( ; refFilterIndex!=messageFiltersCount; ++refFilterIndex )
        {
            if (messageFilters[refFilterIndex]==pRefFilter)
                break;
        }

        if (refFilterIndex>=messageFiltersCount)
        {
            messageFilters[ messageFiltersCount++ ] = pFilter;
            return true;
        }

        // Нужно подвинуть оставшуюся часть
        size_t indexMoveFirst = 0;

        if (order==MessageFilterInstallOrder::before)
        {
            indexMoveFirst = refFilterIndex;
        }
        else
        {
            indexMoveFirst = refFilterIndex+1;
        }

        if (indexMoveFirst>=messageFiltersCount) // nothing to move
        {
            messageFilters[ messageFiltersCount++ ] = pFilter;
            return true;
        }

        size_t numItemsToMove = messageFiltersCount - indexMoveFirst;
        if (!numItemsToMove)
        {
            messageFilters[ messageFiltersCount++ ] = pFilter;
            return true;
        }

        memmove ( &messageFilters[indexMoveFirst+1], &messageFilters[indexMoveFirst], numItemsToMove*sizeof(IMessageFilterPtr) );
        messageFilters[indexMoveFirst] = pFilter;
        messageFiltersCount++;
        return true;
    }

    virtual
    bool messagesDispatch() override
    {
        // Выгребаем все сообщения
        size_t numMessages = 0;
        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            numMessages = messagesList.size();
        }

        pollScheduleDoPollHigh();
        for( size_t i=0; i!=numMessages; ++i)
        {
            if (!messageDispatch())
                return false;
            //pollScheduleDoPollHigh();
        }
        return true;
    }


    bool messageDispatch()
    {
        #if defined(UMBA_MCU_USED)
        if (UMBA_IS_IN_ISR()) // Messages processing not allowed in interrupts
            return false;
        #endif

        pollScheduleDoPollHigh();

        if (!m_isRunning)
            return false;

        Message msg;

        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
           
            if (messagesList.empty())
                return false;
           
            msg = messagesList.front();
            messagesList.pop_front();
        }

        using namespace umba::omanip;

/*
    IDriver*                         drivers[UMBA_RTKOS_MAX_DRIVERS];
    DriverInfo                       driversInfo[UMBA_RTKOS_MAX_DRIVERS];
    size_t                           driversCount = 0;

    DriverClientInfo                 driverHandlers[UMBA_RTKOS_MAX_DRIVER_HANDLERS];
    size_t                           driverHandlersCount = 0;
*/

        // Сообщения от таймера мы сами знаем как процессить
        if (msg.id==message_timer_id)
        {
            // Алсо таймерные сообщения не фильтруются
            if (msg.messageTimer.timerHandler)
            {
                msg.messageTimer.timerHandler->onTimer( (unsigned)msg.messageTimer.eventId );
                return true;
            } // else processed in default handler
        }
        else
        {
            for( size_t i=0; i!=messageFiltersCount; ++i )
            {
                if (messageFilters[i]->onFilterMessage( msg ))
                    return true; // processed
                pollScheduleDoPollHigh();
            }
        }


        #ifndef UMBA_RTKOS_NO_DRIVERS
        if (msg.id==message_driver_id)
        {
            //msg.messageDriver.header.classId 
            //msg.messageDriver.header.driverId
            //invalid_driver_id
            m_currentMessageDriver = msg.messageDriver;

            if (msg.messageDriver.header.pDriver==0)
            {
                // message from client to driver.
                // Are broadcasts supported?
                auto B = &driversInfo[0];
                auto E = &driversInfo[driversCount];
                auto cmpVal = DriverInfo(DriverAddress(msg.messageDriver.header.classId));
                auto b = std::lower_bound( B, E, cmpVal, DriverInfoLessByClassOnly() );
                auto e = std::upper_bound( B, E, cmpVal, DriverInfoLessByClassOnly() );

                bool bHandled = false;

                for( auto it = b; it!=e; ++it)
                {
                    umba::drivers::MessageDriver msgDriver = msg.messageDriver;
                    if (msg.messageDriver.header.driverId==broadcast_driver_id)
                    {
                        msgDriver.header.driverId = it->driverAddress.driverId; // 
                    }
                    if (msgDriver.header.driverId==it->driverAddress.driverId)
                    {
                        if (it->pDriverPrivate->onMessageDriver( msgDriver ))
                            bHandled = true;
                    }
                }

                if (!bHandled)
                {
                    UMBA_RTKOS_LOG<<notice<<"Message to driver not handled yet:"<<normal<<"\n";
                    umba::drivers::dumpMessageDriver( msg.messageDriver, 0 );
                    UMBA_RTKOS_LOG<<flush;
                }
            }
            else
            {
                // message from driver to client
                umba::drivers::MessageDriver msgDriver = msg.messageDriver;

                using namespace umba::omanip;

                //UMBA_RTKOS_LOG<<"---\nLooking for driver handlers\nMessage is:\n";
                //umba::drivers::dumpMessageDriver( msgDriver );
                //UMBA_RTKOS_LOG<<"\n";

                auto B = &driverHandlers[0];
                auto E = &driverHandlers[driverHandlersCount];

                //UMBA_RTKOS_LOG<<"All handlers:\n";
                //dumpDriverHandlers( B, E );
                //UMBA_RTKOS_LOG<<"\n";

                auto cmpVal = DriverClientInfo(DriverAddress(msg.messageDriver.header.classId));
                auto b = std::lower_bound( B, E, cmpVal, DriverClientInfoLessByClassOnly() );
                auto e = std::upper_bound( B, E, cmpVal, DriverClientInfoLessByClassOnly());

                bool bHandled = false;

                //UMBA_RTKOS_LOG<<"Prechecked handlers:\n";
                //dumpDriverHandlers( b, e );
                //UMBA_RTKOS_LOG<<"\n";

                for( auto it = b; it!=e; ++it)
                {
                    // у нас может быть как подписка на широковещательное сообщение, тогда любое сойдет,
                    // так и само сообщение может быть широковещательным
                    // Или от драйвера не должно быть широковещательных сообщений?
                    if (/*msg.messageDriver.header.driverId==broadcast_driver_id ||*/ // зарубил широковещательные от драйвера
                        it->driverAddress.driverId==broadcast_driver_id ||
                        it->driverAddress.driverId==msg.messageDriver.header.driverId
                       )
                    {
                        //UMBA_RTKOS_LOG<<"Calling handler: "<<groupsize(8)<<hex<<(uintptr_t)it->pDriverClientHandler<<"\n";
                        if (it->pDriverClientHandler->onMessageDriverClient( msgDriver ))
                            bHandled = true;
                    }
                }

                //UMBA_RTKOS_LOG<<"Looking ends!!!"<<endl;

                if (!bHandled)
                {
                    UMBA_RTKOS_LOG<<notice<<"Message from driver not handled yet:"<<normal<<"\n";
                    umba::drivers::dumpMessageDriver( msg.messageDriver, 0 );
                    UMBA_RTKOS_LOG<<flush;
                }

            }

        }
        #endif

/*
        IMessageFilterPtr  pDefHandler = 0;
        {
            UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
            pDefHandler = defaultMessageHandler;
        }

        if (pDefHandler)
        {
            pDefHandler->onFilterMessage( msg );
        }
*/
        /*
         Тут нужно отправить сообщения драйверам. Они не должны заниматься фильтрованием, чтобы поймать свои сообщения
         */

        MessageId handlerIdx = msg.id;
        if ( handlerIdx >= message_first_handable_id ) // 0 is for default global handler
        {
            handlerIdx = handlerIdx - message_first_handable_id + 1;
            if (handlerIdx>=RTKOS_NUM_HANDLED_MESSAGE_TYPES)
                handlerIdx = 0; // to default handler
        }

        IMessageHandler* pHandler = (IMessageHandler*)messageHandlers[handlerIdx];
        if (!pHandler)
            pHandler = (IMessageHandler*)messageHandlers[0];

        if (pHandler)
            pHandler->onHandleMessage( msg );

        return true;
    }


    virtual
    IIdleCapable* setIdleHandler( IIdleCapable* h ) override
    {
        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
        IIdleCapable* prev = pIdleHandler;
        pIdleHandler = h;
        return prev;
    }
    
    virtual
    bool isDebuggerPresent() override
    {
        return umba::isDebuggerPresent();
    }

    virtual
    void kernelPanic( const char *msgDetails )
    {
        using namespace umba::omanip;
        auto &oss = getLogStream();

        oss<<wflush; // flush'нули всё, что там уже было, и дождались окончания отправления

        oss<<"\n"<<error<<"Kernel panic";
        if (msgDetails)
            oss<<" - "<<msgDetails;
        oss<<" - system halted!!!"<<endl;

        oss<<wflush;

        volatile size_t i = 0;
        for( ; i!=10000000; ++i) {} // типа делаем что-то осмысленное, пока передается сообщение
        UMBA_ASSERT_FAIL( ); 
    }


    virtual
    IMessageHandler* messagesSetHandler( MessageId msgTypeId, IMessageHandler *pHandler ) override
    {
        if (msgTypeId!=0) // 0 is for default global handler
        {
            msgTypeId = msgTypeId - message_first_handable_id + 1;
        }

        if (msgTypeId>=RTKOS_NUM_HANDLED_MESSAGE_TYPES)
            return 0;

        UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
        IMessageHandler* res = (IMessageHandler*)messageHandlers[msgTypeId];
        messageHandlers[msgTypeId] = pHandler;
        return res;
    }

    #ifndef UMBA_RTKOS_NO_DRIVERS

    DriverId findDriverIdMax(DriverClassId classId )
    {
        DriverId res = 0;
        auto B = &driversInfo[0];
        auto E = &driversInfo[driversCount];
        for (auto it = B; it!=E; ++it)
        {
            if (it->driverAddress.classId != classId)
                continue;
            res = std::max( res, it->driverAddress.driverId );
        }

        return res;
    }

    DriverId isDriverAlreadyExist( const DriverAddress &driverAddress )
    {
        auto B = &driversInfo[0];
        auto E = &driversInfo[driversCount];
        auto cmpVal = DriverInfo(DriverAddress(driverAddress));
        auto it = std::lower_bound( B, E, cmpVal, DriverInfoStrictLess() );
        if (it==E)
            return false;
        if ( it->driverAddress.compareTo(driverAddress, false)!=0 )
            return false;
        return true;
    }

    virtual
    DriverId driverInstall( IDriver *pDriver ) override
    {
        UMBA_ASSERT(pDriver !=0);
        if ( auto res = pDriver->queryInterface<IDriverPrivate>() )
        {
            DriverClassId classId = res.value->getDriverClass();
            UMBA_ASSERT(classId!=0);

            DriverSubclassId subclassId = res.value->getDriverSubclass();

            DriverId driverId = findDriverIdMax( classId ) + 1;

            return driverInstall( classId, driverId, subclassId, pDriver );
        }

        return invalid_driver_id;
    }

    virtual
    DriverId driverInstall( const DriverAddress &driverAddress, DriverSubclassId subclassId, IDriver *pDriver ) override
    {
        return driverInstall( driverAddress.classId, driverAddress.driverId, subclassId, pDriver );
    }

    virtual
    DriverId driverInstall(DriverClassId classId, DriverId driverId, DriverSubclassId subclassId, IDriver *pDriver ) override
    {
        //if (!m_isRunning)
        //    return false;
        UMBA_ASSERT(!m_isRunning);
        UMBA_ASSERT(driversCount<UMBA_RTKOS_MAX_DRIVERS);

        UMBA_ASSERT(classId!=0);

        if (auto res = pDriver->queryInterface<IDriverPrivate>())
        {
            
            //UMBA_ASSERT(pDriverPrivate!=0);

            if (driverId==invalid_driver_id) 
                driverId = findDriverIdMax(classId) + 1;
           
            driversInfo[driversCount].driverAddress = DriverAddress( classId, driverId );
            UMBA_ASSERT( !isDriverAlreadyExist(driversInfo[driversCount].driverAddress) );
           
            driversInfo[driversCount].driverSubclassId = subclassId;
            driversInfo[driversCount].driverTableIndex = driversCount;
            driversInfo[driversCount].pDriverPrivate   = res.value; // pDriverPrivate;
           
            drivers[driversCount++] = pDriver;

            if (auto drvPrivRes = pDriver->queryInterface<IDriverPrivate>())
            {
                drvPrivRes.value->setDriverId( classId, subclassId, driverId );
            }
           
            std::sort( &driversInfo[0]
                     , &driversInfo[driversCount]
                     , DriverInfoStrictLess()
                     );
        
        }
        else
        {
            UMBA_ASSERT_FAIL();
        }

        return driverId;
    }

    virtual
    size_t getTotalDrivers() override
    {
        return driversCount;
    }

    virtual
    umba::drivers::IDriver* driverGet( size_t idx ) override
    {
        if (idx>=driversCount)
            return 0;
        return drivers[idx];
    }

    DriverInfo driverGetInfo( size_t idx ) // override
    {
        // Только перебор. Или завести еще несортированный массив Info?
        auto B = &driversInfo[0];
        auto E = &driversInfo[driversCount];

        for (auto it=B; it!=E; ++it)
        {
            if (it->driverTableIndex == idx)
                return *it;
        }

        return DriverInfo { { class_id_unknown, 0 }, 0, 0, 0 };
    }

    virtual
    DriverSubclassId driverGetSubclass( size_t idx ) override
    {
        return driverGetInfo(idx).driverSubclassId;
    }

    virtual
    DriverAddress driverGetAddress( size_t idx ) override
    {
        return driverGetInfo(idx).driverAddress;
        /*
        // Только перебор. Или завести еще массив адресов?
        auto B = &driversInfo[0];
        auto E = &driversInfo[driversCount];

        for (auto it=B; it!=e; ++it)
        {
            if (it->driverTableIndex == idx)
                return it->driverAddress;
        }

        return DriverAddress{ class_id_unknown, 0 };
        */
    }

    virtual
    umba::drivers::IDriver* driverGet( const DriverAddress &driverAddress ) override
    {
        auto B = &driversInfo[0];
        auto E = &driversInfo[driversCount];
        auto cmpVal = DriverInfo(DriverAddress(driverAddress));
        auto it = std::lower_bound( B, E,cmpVal, DriverInfoStrictLess() );
        if (it==E)
            return 0;
        if ( it->driverAddress.compareTo(driverAddress)!=0 )
            return 0;
        
        return drivers[it->driverTableIndex];
    }

    //! Возвращает индекс следующего подходящего драйвера после prevIdx.
    /*! Если ничего не найдено, то возвращает invalid_driver_index.
        Для поиска с начала нужно задать prevIdx равным invalid_driver_index .
        Если задать subclassId = subclass_id_any, то будет искаться только 
        по классу драйвера.
     */
    virtual
    size_t driverFindCompatible(DriverClassId classId, DriverSubclassId subclassId, size_t nextIdx ) override
    {
        if (nextIdx>=driversCount)
            return invalid_driver_index;

        for(; nextIdx!=driversCount; ++nextIdx )
        {
            DriverInfo info = driverGetInfo( nextIdx );
            if (info.driverAddress.classId!=classId)
                continue;
            if (subclassId==subclass_id_any)
                return nextIdx;
            if (info.driverSubclassId !=subclassId)
                continue;
            return nextIdx;
        }
        return invalid_driver_index;
    }

    void dumpDriverHandlers( const DriverClientInfo *B, const DriverClientInfo *E )
    {
        for(; B!=E; ++B )
        {
            dumpDriverClientInfo( *B );
        }
    }

    //DriverClientInfo                 driverHandlers[UMBA_RTKOS_MAX_DRIVER_HANDLERS];
    //size_t                           driverHandlersCount = 0;

    //void dumpDriverClientInfo( const DriverClientInfo &info )

    virtual
    bool driverHandlerAdd( const DriverAddress &driverAddress, IDriverClientHandler *pHandler ) override
    {
        using namespace umba::omanip;

        UMBA_ASSERT(!m_isRunning);
        UMBA_ASSERT(driverHandlersCount<UMBA_RTKOS_MAX_DRIVER_HANDLERS);

        //UMBA_RTKOS_LOG<<"driverHandlerAdd, arg - ";
        //umba::drivers::dumpDriverAddress( driverAddress );
        //UMBA_RTKOS_LOG<<", handler: "<<groupsize(8)<<hex<<(uintptr_t)pHandler<<"\n";

        //UMBA_RTKOS_LOG<<"driverHandlerAdd, handlers before add:\n";
        //dumpDriverHandlers( &driverHandlers[0], &driverHandlers[driverHandlersCount] );

        driverHandlers[driverHandlersCount++] = DriverClientInfo(driverAddress, pHandler);

        std::sort( &driverHandlers[0]
                 , &driverHandlers[driverHandlersCount]
                 , DriverClientInfoLessByClassOnly()
                 );

        //UMBA_RTKOS_LOG<<"driverHandlerAdd, handlers after add:\n";
        //dumpDriverHandlers( &driverHandlers[0], &driverHandlers[driverHandlersCount] );

        return true;
    }

    virtual
    umba::Error driverHardwareInit( size_t idx ) override
    {
        DriverInfo di = driverGetInfo( idx );
        if (di.driverAddress.classId == 0)
        {
            return umba::errors::invalid_param;
        }

        if (di.pDriverPrivate==0)
        {
            return umba::errors::not_implemented;
        }

        return di.pDriverPrivate->driverHardwareInit(di.driverAddress);
    }

    virtual
    umba::Error driverSoftwareStart( size_t idx ) override
    {
        DriverInfo di = driverGetInfo( idx );
        if (di.driverAddress.classId == 0)
        {
            return umba::errors::invalid_param;
        }

        if (di.pDriverPrivate==0)
        {
            return umba::errors::not_implemented;
        }

        return di.pDriverPrivate->driverSoftwareStart(di.driverAddress);
    }


    virtual
    umba::Error driverSoftwareSetStarted( size_t idx ) override
    {
        DriverInfo di = driverGetInfo( idx );
        if (di.driverAddress.classId == 0)
        {
            return umba::errors::invalid_param;
        }

        if (di.pDriverPrivate==0)
        {
            return umba::errors::not_implemented;
        }

        di.pDriverPrivate->driverSoftwareSetStarted(di.driverAddress);
        return 0;
    }

    virtual
    umba::Error driverHardwareSetStarted( size_t idx ) override
    {
        DriverInfo di = driverGetInfo( idx );
        if (di.driverAddress.classId == 0)
        {
            return umba::errors::invalid_param;
        }

        if (di.pDriverPrivate==0)
        {
            return umba::errors::not_implemented;
        }

        di.pDriverPrivate->driverHardwareSetStarted(di.driverAddress);
        return 0;
    }


    virtual
    void setDriverValueConvertMode( ValueConvertMode vcm ) override
    {
        m_valueConvertMode = vcm;
    }

    virtual
    void handleDriverValueConvertFailed( umba::drivers::ValueInfoFlags expected, umba::drivers::ValueInfoFlags got ) override
    {
        if (m_valueConvertMode == ValueConvertMode::implicit_cast)
            return;

        using namespace umba::omanip;
        auto &oss = getLogStream();
        oss<<warning<<"Value convert error."<<normal<<" Expected '"<<umba::drivers::getValueInfoName(expected)<<"', but got '"<<umba::drivers::getValueInfoName(got)<<"'\n";
        umba::drivers::dumpMessageDriver( m_currentMessageDriver, 0 );
        if (m_valueConvertMode == ValueConvertMode::panic)
            kernelPanic( "Value convert error" );
    }

    


/*

    void kernelPanic( const char *msgDetails )
    {
        using namespace umba::omanip;
        auto &oss = getLogStream();

        oss<<wflush; // flush'нули всё, что там уже было, и дождались окончания отправления

        oss<<"\n"<<error<<"Kernel panic";
        if (msgDetails)
            oss<<" - "<<msgDetails;
        oss<<" - system halted!!!"<<endl;

        oss<<wflush;

        volatile size_t i = 0;
        for( ; i!=10000000; ++i) {} // типа делаем что-то осмысленное, пока передается сообщение
        UMBA_ASSERT_FAIL( ); 
    }


struct DriverClientInfoStrictLess
struct DriverClientInfoMaskedLess

struct DriverInfoStrictLess
struct DriverInfoMaskedLess

struct DriverInfo
{
    DriverAddress          driverAddress    = {};
    DriverSubclassId       driverSubclassId =  0;
    size_t                 driverTableIndex =  0;
    IDriverPrivate         pDriverPrivate   =  0;

    IDriver*                         drivers[UMBA_RTKOS_MAX_DRIVERS];
    DriverInfo                       driversInfo[UMBA_RTKOS_MAX_DRIVERS];
    size_t                           driversCount = 0;


*/



//struct DriverClientInfo


    #endif


protected:


    PollSchedulerList                highPollsSchedulerList;
    TimersList                       timersList;
    MessagesList                     messagesList;

    volatile bool                    m_isRunning         = false;

    IPollCapablePtr                  normalPollsSchedulerList[UMBA_RTKOS_MAX_NORMAL_POLLS];
    volatile size_t                  normalPollsCount    = 0;
    volatile size_t                  normalPollInProgess = 0;
    volatile size_t                  highPollInProgess   = 0;

    TimerId                          nextTimerId         = 0;
    volatile TimeTick                timersProcessedTick = 0;

    IMessageFilterPtr                messageFilters[UMBA_RTKOS_MAX_MESSAGE_FILTERS];
    volatile size_t                  messageFiltersCount = 0;

    volatile IMessageHandler*        messageHandlers[RTKOS_NUM_HANDLED_MESSAGE_TYPES] = {0}; // only 16 types of messages can be handled

    IPollCapablePtr                  normalPollsStack[UMBA_RTKOS_MAX_YIELDS];

    #ifdef UMBA_RTKOS_ENABLE_YIELD
    IPollCapablePtr                  yieldedPolls[UMBA_RTKOS_MAX_YIELDS];
    size_t                           yieldedPollsCount = 0;
    #endif

    IIdleCapable                    *pIdleHandler = 0;

    volatile bool                    m_isStarted = false;

    volatile RunLevel                currentRunLevel;
    volatile RunLevel                runLevel;

    IDriver*                         drivers[UMBA_RTKOS_MAX_DRIVERS];
    DriverInfo                       driversInfo[UMBA_RTKOS_MAX_DRIVERS];
    size_t                           driversCount = 0;

    DriverClientInfo                 driverHandlers[UMBA_RTKOS_MAX_DRIVER_HANDLERS];
    size_t                           driverHandlersCount = 0;

    Message                          m_debugBreakMessage;
    bool                             m_debugBreakAllowed = false;

    ValueConvertMode                 m_valueConvertMode = ValueConvertMode::warning; // ValueConvertMode::panic;
    umba::drivers::MessageDriver     m_currentMessageDriver;

    


}; // struct IOsImpl



//-----------------------------------------------------------------------------
IOs* os()
{
    static IOsImpl _os;
    return &_os;
}

//-----------------------------------------------------------------------------
namespace priv
{

/*
void setLogStream( umba::SimpleFormatter &s )
{
    pLogFormatter = &s;
}
*/

void setLogCharWriter( umba::ICharWriter *pWritter )
{
    if (!pWritter)
        formatter.setCharWritter( &nulCharWritter );
    else
        formatter.setCharWritter( pWritter );
}

} // namespace priv
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------




} // namespace rtkos
} // namespace umba

