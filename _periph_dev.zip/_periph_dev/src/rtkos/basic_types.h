#pragma once

#include "umba/umba.h"
#include "umba/time_service.h"
#include "umba/basic_interfaces.h"



namespace umba
{
namespace rtkos
{

typedef uint16_t        SmallId;
typedef uint32_t        StandardId;

#ifdef UMBA_RTKOS_DONT_COMPACT

    typedef StandardId  GenericId;

#else

    typedef SmallId     GenericId;

#endif


//-----------------------------------------------------------------------------
//typedef GenericId                       TimerId;
typedef StandardId                      TimerId;


constexpr TimerId  timer_id_invalid  =  (TimerId)-1;
constexpr TimerId  timer_id_any      =  (TimerId)-1;

//-----------------------------------------------------------------------------
//typedef GenericId                       TimerEventId;
typedef SmallId                         TimerEventId;



//-----------------------------------------------------------------------------
typedef umba::time_service::TimeTick    TimeTick;
typedef umba::ITimerHandler             ITimerHandler;

//-----------------------------------------------------------------------------

typedef uint32_t                        RunLevel;

constexpr RunLevel RunLevel0 = 0;
constexpr RunLevel RunLevel1 = 1;
constexpr RunLevel RunLevel2 = 2;
constexpr RunLevel RunLevel3 = 3;
constexpr RunLevel RunLevel4 = 4;
constexpr RunLevel RunLevel5 = 5;
constexpr RunLevel RunLevel6 = 6;
constexpr RunLevel RunLevel7 = 7;


interface IStarterTask : inherits umba::IPollCapable
{
    UMBA_DECLARE_INTERFACE_ID(0xCBE27764);

    virtual
    RunLevel getTaskRunLevel() = 0;
};


} // namespace rtkos
} // namespace umba



#ifndef UMBA_RTKOS_NO_DRIVERS
    #include "drivers/i_driver.h"
#endif



namespace umba
{
namespace rtkos
{

#ifndef UMBA_RTKOS_NO_DRIVERS

    typedef  umba::drivers::IDriver         IDriver;
    typedef  umba::drivers::IDriverPrivate  IDriverPrivate;

    typedef  umba::drivers::ClassId         DriverClassId;
    typedef  umba::drivers::SubclassId      DriverSubclassId;
    typedef  umba::drivers::DriverId        DriverId;
    typedef  umba::drivers::DriverAddress   DriverAddress;

    constexpr DriverClassId class_id_unknown      = umba::drivers::class_id_unknown;
    constexpr DriverSubclassId subclass_id_any    = umba::drivers::subclass_id_any;
    constexpr DriverId invalid_driver_id          = umba::drivers::invalid_driver_id;
    constexpr DriverId broadcast_driver_id        = umba::drivers::broadcast_driver_id;


#endif



} // namespace rtkos
} // namespace umba

