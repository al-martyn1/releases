#pragma once

#include "umba/umba.h"
#include "basic_types.h"
#include "vk_codes.h"


// umba::rtkos::

namespace umba
{
namespace rtkos
{

//-----------------------------------------------------------------------------
typedef SmallId     KeyboardId; // ??? 
//typedef GenericId   KeyboardId;

constexpr KeyboardId keyboard_id_any             = (KeyboardId)-1;
constexpr KeyboardId keyboard_id_terminal        = 1;
constexpr KeyboardId keyboard_id_device          = 2; // main device keyboard
constexpr KeyboardId keyboard_id_device_cursor   = 3; // extra device keyboard with cursor buttons
constexpr KeyboardId keyboard_id_device_extra    = 4; // extra device keyboard with some additional buttons
constexpr KeyboardId keyboard_id_user            = 5; // first user id for custom keyboards

constexpr KeyboardId terminal_keyboard_id        = keyboard_id_terminal     ;
constexpr KeyboardId device_keyboard_id          = keyboard_id_device       ; // main device keyboard
constexpr KeyboardId device_cursor_keyboard_id   = keyboard_id_device_cursor; // extra device keyboard with cursor buttons
constexpr KeyboardId device_extra_keyboard_id    = keyboard_id_device_extra ; // extra device keyboard with some additional buttons
constexpr KeyboardId user_keyboard_id            = keyboard_id_user         ; // first user id for custom keyboards


struct MessageKeyboard
{
    KeyboardId       keyboardId;
    VirtualKeyCode   keyCode;
    VirtualKeyState  keyState;
    unsigned         repeatCount;
};

//-----------------------------------------------------------------------------
struct MessageInputChar
{
    KeyboardId       keyboardId;
    char             charCode;
};



//-----------------------------------------------------------------------------
struct MessageTimer
{
    TimerEventId      eventId;
    ITimerHandler    *timerHandler;
};

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
typedef GenericId    MessageId;

constexpr MessageId  message_id_any               = (MessageId)-1;

constexpr MessageId  message_id_timer             = 0;
constexpr MessageId  message_id_driver            = 1;
//constexpr MessageId  messageDefaultId   = 2; // Not used as message id

constexpr MessageId  message_id_first_handable    = 3; // First user handable message type

constexpr MessageId  message_id_keyboard          = 3;
constexpr MessageId  message_id_input_char        = 4; // Translated from keyboard messages

constexpr MessageId  message_id_user_custom       = 5; // User custom message types starts here. May be changed in future


constexpr MessageId  message_timer_id             = message_id_timer;
constexpr MessageId  message_driver_id            = message_id_driver;

constexpr MessageId  message_first_handable_id    = message_id_first_handable;

constexpr MessageId  message_keyboard_id          = message_id_keyboard;
constexpr MessageId  message_input_char_id        = message_id_input_char; // Translated from keyboard messages

constexpr MessageId  message_user_custom_id       = message_id_user_custom; // User custom message types starts here. May be changed in future



} // namespace rtkos
} // namespace umba



#ifndef UMBA_RTKOS_NO_DRIVERS
    #include "drivers/messages.h"
#endif



namespace umba
{
namespace rtkos
{


struct Message
{
    MessageId              id;
    TimeTick               tick;

    union
    {
        MessageTimer                      messageTimer;
        MessageKeyboard                   messageKeyboard;
        MessageInputChar                  messageInputChar;
        #ifndef UMBA_RTKOS_NO_DRIVERS
            umba::drivers::MessageDriver  messageDriver;
        #endif

    };
};

//-----------------------------------------------------------------------------


} // namespace rtkos
} // namespace umba

