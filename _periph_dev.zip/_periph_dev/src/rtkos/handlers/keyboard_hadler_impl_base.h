#pragma once

#include "rtkos/rtkos.h"

namespace umba
{
namespace rtkos
{

#ifndef UMBA_RTKOS_NO_DRIVERS



struct KeyboardHandlerImplBase : implements IMessageHandler
{

    //UMBA_BEGIN_INTERFACE_MAP_EX( IDriverClientHandler )
    UMBA_BEGIN_INTERFACE_MAP(  )
        UMBA_IMPLEMENT_INTERFACE( IMessageHandler )
    UMBA_END_INTERFACE_MAP()

    bool install()
    {
        //return driverHandlerAdd( DriverAddress() &driverAddress, Object *pObj )
         //UMBA_RTKOS_OS->
         UMBA_RTKOS_OS->messagesSetHandler( message_keyboard_id, this );
         return true;
    }
    //umba::rtkos::driverInstall( DriverAddress(class_id_value, umba::periph::periphGetNo( &m_uart )), subclass_id_value, this );

    //virtual
    //void onHandleMessage( Message &msg ) = 0;

};

/*
class KeyboardHandlerImplBase : implements IDriverClientHandler
{

    UMBA_BEGIN_INTERFACE_MAP_EX( IDriverClientHandler )

    UMBA_END_INTERFACE_MAP()

    //virtual
    //void onMessageDriverClient( const umba::drivers::MessageDriver &msg )
};
*/

#endif /* UMBA_RTKOS_NO_DRIVERS */


} // namespace rtkos
} // namespace umba

