#pragma once


/* Не рекомендуется изменять этот файл.

   Дефайны следует задавать в настройках компилятора

   Можно создайть файл <PROJECT_NAME>_rtkos_config.h в своём проекте,
   добавьте туда макросы, которые нужно, и в настройках компилятора указать
   дополнительную опцию:

     --preinclude=<PROJECT_NAME>_rtkos_config.h


*/

// #ifdef UMBA_MCU_USED

// List item - +6 bytes

#ifndef UMBA_RTKOS_TIMERS_PREC
    #define UMBA_RTKOS_TIMERS_PREC             10 /* ms */
#endif
    



#if defined(UMBA_TOO_LOW_MEM)

    // Total 3616 bytes, 1248 - OS data, other - in lists

    #ifndef UMBA_RTKOS_LOG_STREAM_BUF_SIZE
        #define UMBA_RTKOS_LOG_STREAM_BUF_SIZE     255
    #endif
    
    #ifndef UMBA_RTKOS_MAX_DRIVERS
        #define UMBA_RTKOS_MAX_DRIVERS              8
    #endif
    
    #ifndef UMBA_RTKOS_MAX_DRIVER_HANDLERS
        #define UMBA_RTKOS_MAX_DRIVER_HANDLERS     16
    #endif
    
    #ifndef UMBA_RTKOS_MAX_NORMAL_POLLS
        #define UMBA_RTKOS_MAX_NORMAL_POLLS        16
    #endif
    
    #ifndef UMBA_RTKOS_MAX_HIGH_POLLS
        #define UMBA_RTKOS_MAX_HIGH_POLLS           4
    #endif
    
    #ifndef UMBA_RTKOS_MAX_YIELDS
        #define UMBA_RTKOS_MAX_YIELDS               4
    #endif
    
    #ifndef UMBA_RTKOS_MAX_TIMERS
        #define UMBA_RTKOS_MAX_TIMERS              16 /* aprox 1400 bytes */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_SHOOTED_TIMERS
        #define UMBA_RTKOS_MAX_SHOOTED_TIMERS       4 /* max shooted at the same time */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_MESSAGE_FILTERS
        #define UMBA_RTKOS_MAX_MESSAGE_FILTERS     8 /* aprox 1024 bytes */
    #endif
    
    #ifndef UMBA_RTKOS_MESSAGE_QUEUE_SIZE
        #define UMBA_RTKOS_MESSAGE_QUEUE_SIZE     16 /* aprox 2Kb */
    #endif

#else

    // Total 5472 bytes

    #ifndef UMBA_RTKOS_LOG_STREAM_BUF_SIZE
        #define UMBA_RTKOS_LOG_STREAM_BUF_SIZE     255
    #endif
    
    #ifndef UMBA_RTKOS_MAX_DRIVERS
        #define UMBA_RTKOS_MAX_DRIVERS             32  /*  */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_DRIVER_HANDLERS
        #define UMBA_RTKOS_MAX_DRIVER_HANDLERS     32  /*  */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_NORMAL_POLLS
        #define UMBA_RTKOS_MAX_NORMAL_POLLS        32  /* aprox 256 bytes */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_HIGH_POLLS
        #define UMBA_RTKOS_MAX_HIGH_POLLS           8  /* aprox 80 */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_YIELDS
        #define UMBA_RTKOS_MAX_YIELDS              16  /* aprox 64 bytes */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_TIMERS
        #define UMBA_RTKOS_MAX_TIMERS              32 /* aprox 1400 bytes */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_SHOOTED_TIMERS
        #define UMBA_RTKOS_MAX_SHOOTED_TIMERS       8 /* max shooted at the same time */
    #endif
    
    #ifndef UMBA_RTKOS_MAX_MESSAGE_FILTERS
        #define UMBA_RTKOS_MAX_MESSAGE_FILTERS     32 /* aprox 1024 bytes */
    #endif
    
    #ifndef UMBA_RTKOS_MESSAGE_QUEUE_SIZE
        #define UMBA_RTKOS_MESSAGE_QUEUE_SIZE      32 /* aprox 2Kb */
    #endif

#endif
