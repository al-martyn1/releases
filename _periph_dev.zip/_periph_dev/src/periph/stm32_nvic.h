#pragma once

// http://easyelectronics.ru/arm-uchebnyj-kurs-preryvaniya-i-nvic-prioritetnyj-kontroller-preryvanij.html


// NVIC_InitTypeDef NVIC_InitStruct;

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif


namespace umba
{
namespace periph
{
namespace traits
{


// #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)


} // namespace traits
} // namespace periph
} // namespace umba
