#include "umba/umba.h"
#include "stm32.h"
#include "stm32_traits.h"


#if UMBA_PERIPH_SPI_NUM > 0

namespace umba
{
namespace periph
{
namespace traits
{



struct SpiIrqHandlerVectorEntry
{
    SpiIrqHandlerProcT proc;
    void*              param;
};


static
UMBA_PERIPH_DECLARE_SPI_IRQ_HANDLER_PROC( spiStubHandler )
{}

//volatile
static
SpiIrqHandlerVectorEntry spiIrqHandlersVector[ UMBA_PERIPH_SPI_NUM ] = 
{ 
  { spiStubHandler, 0 }
  #if UMBA_PERIPH_SPI_NUM == 2
    , { spiStubHandler, 0 }
  #elif UMBA_PERIPH_SPI_NUM == 3
    , { spiStubHandler, 0 }
  #elif UMBA_PERIPH_SPI_NUM == 4
    , { spiStubHandler, 0 }
  #elif UMBA_PERIPH_SPI_NUM == 5
    , { spiStubHandler, 0 }
  #elif UMBA_PERIPH_SPI_NUM == 6
    , { spiStubHandler, 0 }
  #endif
};



bool periphInstallIrqHandler( SPI_TypeDef* SPIx, SpiIrqHandlerProcT proc, void *pParam )
{
    UMBA_ASSERT(proc);
    uint16_t spiIdx = spiGetNo( SPIx ) - 1;
    UMBA_ASSERT( spiIdx<6 );

    bool res = false;

    UMBA_MEMORY_BARRIER();

    UMBA_DISABLE_IRQ();

    if (spiIrqHandlersVector[spiIdx].proc==spiStubHandler)
    {
        spiIrqHandlersVector[spiIdx].proc    = proc;
        spiIrqHandlersVector[spiIdx].param   = pParam;
        UMBA_MEMORY_BARRIER();
        res = true;
    }

    UMBA_ENABLE_IRQ();

    return res;
}

bool periphUninstallIrqHandler( SPI_TypeDef* SPIx )
{
    uint16_t spiIdx = spiGetNo( SPIx ) - 1;
    UMBA_ASSERT( spiIdx<6 );

    bool res = false;

    UMBA_MEMORY_BARRIER();

    UMBA_DISABLE_IRQ();

    if (spiIrqHandlersVector[spiIdx].proc!=spiStubHandler)
    {
        spiIrqHandlersVector[spiIdx].proc    = spiStubHandler;
        UMBA_MEMORY_BARRIER();
        res = true;
    }

    UMBA_ENABLE_IRQ();

    return res;
}



} // namespace traits
} // namespace periph
} // namespace umba


#define UMBA_SPI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING( SPIx )               \
    auto flags    = umba::periph::traits::spiGetEventFlags( SPIx );            \
    umba::periph::traits::spiClearEventFlags( SPIx, flags );                        \
    const auto &e = umba::periph::traits::spiIrqHandlersVector[umba::periph::traits::spiGetNo(SPIx)-1]; \
    e.proc( e.param, SPIx, flags )

#define UMBA_PERIPH_SPI_IRQ_HANDLER(SPIN)   \
UMBA_IRQ_HANDLER( SPI##SPIN##_IRQHandler )  \
{                                           \
    UMBA_SPI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING( SPI##SPIN ); \
}


#include "umba/optimize_speed.h"

    #if defined(SPI1)
        UMBA_PERIPH_SPI_IRQ_HANDLER(1)
    #endif
    #if defined(SPI2)
        UMBA_PERIPH_SPI_IRQ_HANDLER(2)
    #endif
    #if defined(SPI3)
        UMBA_PERIPH_SPI_IRQ_HANDLER(3)
    #endif
    #if defined(SPI4)
        UMBA_PERIPH_SPI_IRQ_HANDLER(4)
    #endif
    #if defined(SPI5)
        UMBA_PERIPH_SPI_IRQ_HANDLER(5)
    #endif
    #if defined(SPI6)
        UMBA_PERIPH_SPI_IRQ_HANDLER(6)
    #endif

#include "umba/optimize_pop.h"


#endif /* UMBA_PERIPH_SPI_NUM > 0 */

