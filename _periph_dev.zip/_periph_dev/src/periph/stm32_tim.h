#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

namespace umba
{
namespace periph
{
namespace traits
{


enum class TimerType
{
    unknown, basic, general, advanced
};


inline
uint16_t timGetNo( TIM_TypeDef* TIMx )
{
    #if defined(TIM1)
        if (TIMx==TIM1) return 1;
    #endif
    #if defined(TIM2)
        if (TIMx==TIM2) return 2;
    #endif
    #if defined(TIM3)
        if (TIMx==TIM3) return 3;
    #endif
    #if defined(TIM4)
        if (TIMx==TIM4) return 4;
    #endif
    #if defined(TIM5)
        if (TIMx==TIM5) return 5;
    #endif
    #if defined(TIM6)
        if (TIMx==TIM6) return 6;
    #endif
    #if defined(TIM7)
        if (TIMx==TIM7) return 7;
    #endif
    #if defined(TIM8)
        if (TIMx==TIM8) return 8;
    #endif
    #if defined(TIM9)
        if (TIMx==TIM9) return 9;
    #endif
    #if defined(TIM10)
        if (TIMx==TIM10) return 10;
    #endif
    #if defined(TIM11)
        if (TIMx==TIM11) return 11;
    #endif
    #if defined(TIM12)
        if (TIMx==TIM12) return 12;
    #endif
    #if defined(TIM13)
        if (TIMx==TIM13) return 13;
    #endif
    #if defined(TIM14)
        if (TIMx==TIM14) return 14;
    #endif
    #if defined(TIM15)
        if (TIMx==TIM15) return 15;
    #endif
    #if defined(TIM16)
        if (TIMx==TIM16) return 16;
    #endif
    #if defined(TIM17)
        if (TIMx==TIM17) return 17;
    #endif
    #if defined(TIM18)
        if (TIMx==TIM18) return 18;
    #endif
    #if defined(TIM19)
        if (TIMx==TIM19) return 19;
    #endif
    #if defined(TIM20)
        if (TIMx==TIM20) return 20;
    #endif

    UMBA_ASSERT_FAIL();

    return 0;
}

inline
uint16_t periphGetNo( TIM_TypeDef* TIMx )
{
    return timGetNo(TIMx);
}



#define UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( timNo, timerType )    \
                          if (pt==timNo) return timerType


// STM32F3xx
// Advanced-control timers (TIM1/TIM8/TIM20)
// General-purpose timers (TIM2/TIM3/TIM4)
// Basic timers (TIM6/TIM7)
// General-purpose timers (TIM15/TIM16/TIM17)

// STM32F1xx
// Advanced-control timers (TIM1 and TIM8)
// General-purpose timers (TIM2 to TIM5)
// General-purpose timers (TIM9 to TIM14)
// Basic timers (TIM6 and TIM7)

// STM32F4xx
// Advanced-control timers (TIM1 and TIM8)
// General-purpose timers (TIM2 to TIM5)
// General-purpose timers (TIM9 to TIM14)
// Basic timers (TIM6 and TIM7)
    
#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    inline
    TimerType timerGetType( TIM_TypeDef * pt )
    {
        // Basic timers (TIM6 and TIM7)
        #ifdef TIM6
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM6, TimerType::basic );
        #endif
       
        #ifdef TIM7
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM7, TimerType::basic );
        #endif
       
        // General-purpose timers (TIM2 to TIM5)
        #ifdef TIM2
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM2, TimerType::general );
        #endif
        #ifdef TIM3
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM3, TimerType::general );
        #endif
        #ifdef TIM4
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM4, TimerType::general );
        #endif
        #ifdef TIM5 /* STM32F1xx/STM32F4xx */
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM5, TimerType::general );
        #endif
       
        // General-purpose timers (TIM9 to TIM14) /* STM32F1xx/STM32F4xx */
        #ifdef TIM9
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM9, TimerType::general );
        #endif
        #ifdef TIM10
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM10, TimerType::general );
        #endif
        #ifdef TIM11
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM11, TimerType::general );
        #endif
        #ifdef TIM12
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM12, TimerType::general );
        #endif
        #ifdef TIM13
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM13, TimerType::general );
        #endif
        #ifdef TIM14
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM14, TimerType::general );
        #endif
       
        // General-purpose timers (TIM15/TIM16/TIM17) - STM32F3xx
        #ifdef TIM15
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM15, TimerType::general );
        #endif
        #ifdef TIM16
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM16, TimerType::general );
        #endif
        #ifdef TIM17
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM17, TimerType::general );
        #endif
       
       
        // Advanced-control timers (TIM1 and TIM8)
        #ifdef TIM1
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM1, TimerType::advanced );
        #endif
        #ifdef TIM8
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM8, TimerType::advanced );
        #endif
        #ifdef TIM20 /* STM32F3xx */
            UMBA_PERIPH_STM32_TIM_SPECIALIZE_TIMER_TYPE( TIM20, TimerType::advanced );
        #endif

        UMBA_ASSERT_FAIL();

        return TimerType::unknown;
    }

#endif


inline
bool timerIsBasic( TIM_TypeDef * pt )
{
    return timerGetType(pt)==TimerType::basic;
}

inline
bool timerIsGeneral( TIM_TypeDef * pt )
{
    return timerGetType(pt)==TimerType::general;
}

inline
bool timerIsAdvanced( TIM_TypeDef * pt )
{
    return timerGetType(pt)==TimerType::advanced;
}

inline
bool timerHasBdtrRegister( TIM_TypeDef * pt )
{
    // https://www.st.com/content/ccc/resource/technical/document/reference_manual/4a/19/6e/18/9d/92/43/32/DM00043574.pdf/files/DM00043574.pdf/jcr:content/translations/en.DM00043574.pdf
    // 20.3.11 PWM mode
    // BDTR
    // 1, 8, 15, 16, 17, 20
    //return timerGetType(pt)==TimerType::advanced;

    #ifdef TIM1
        if (pt==TIM1) return true;
    #endif

    #ifdef TIM8
        if (pt==TIM8) return true;
    #endif

    #ifdef TIM15
        if (pt==TIM15) return true;
    #endif

    #ifdef TIM16
        if (pt==TIM16) return true;
    #endif

    #ifdef TIM17
        if (pt==TIM17) return true;
    #endif

    #ifdef TIM20
        if (pt==TIM20) return true;
    #endif

    return false;

}





/* F1XX --------------------------
void RCC_AHBPeriphClockCmd(uint32_t RCC_AHBPeriph, FunctionalState NewState);
void RCC_APB1PeriphClockCmd(uint32_t RCC_APB1Periph, FunctionalState NewState);
void RCC_APB2PeriphClockCmd(uint32_t RCC_APB2Periph, FunctionalState NewState);

#define RCC_APB2Periph_TIM1              ((uint32_t)0x00000800)
#define RCC_APB2Periph_TIM8              ((uint32_t)0x00002000)
#define RCC_APB2Periph_TIM15             ((uint32_t)0x00010000)
#define RCC_APB2Periph_TIM16             ((uint32_t)0x00020000)
#define RCC_APB2Periph_TIM17             ((uint32_t)0x00040000)
#define RCC_APB2Periph_TIM9              ((uint32_t)0x00080000)
#define RCC_APB2Periph_TIM10             ((uint32_t)0x00100000)
#define RCC_APB2Periph_TIM11             ((uint32_t)0x00200000)

#define RCC_APB1Periph_TIM2              ((uint32_t)0x00000001)
#define RCC_APB1Periph_TIM3              ((uint32_t)0x00000002)
#define RCC_APB1Periph_TIM4              ((uint32_t)0x00000004)
#define RCC_APB1Periph_TIM5              ((uint32_t)0x00000008)
#define RCC_APB1Periph_TIM6              ((uint32_t)0x00000010)
#define RCC_APB1Periph_TIM7              ((uint32_t)0x00000020)
#define RCC_APB1Periph_TIM12             ((uint32_t)0x00000040)
#define RCC_APB1Periph_TIM13             ((uint32_t)0x00000080)
#define RCC_APB1Periph_TIM14             ((uint32_t)0x00000100)
*/

/* F3XX --------------------------
void RCC_AHBPeriphClockCmd(uint32_t RCC_AHBPeriph, FunctionalState NewState);
void RCC_APB1PeriphClockCmd(uint32_t RCC_APB1Periph, FunctionalState NewState);
void RCC_APB2PeriphClockCmd(uint32_t RCC_APB2Periph, FunctionalState NewState); 

#define RCC_APB2Periph_TIM1              RCC_APB2ENR_TIM1EN
#define RCC_APB2Periph_TIM8              RCC_APB2ENR_TIM8EN
#define RCC_APB2Periph_TIM15             RCC_APB2ENR_TIM15EN
#define RCC_APB2Periph_TIM16             RCC_APB2ENR_TIM16EN
#define RCC_APB2Periph_TIM17             RCC_APB2ENR_TIM17EN
#define RCC_APB2Periph_TIM20             RCC_APB2ENR_TIM20EN

#define RCC_APB1Periph_TIM2              RCC_APB1ENR_TIM2EN
#define RCC_APB1Periph_TIM3              RCC_APB1ENR_TIM3EN
#define RCC_APB1Periph_TIM4              RCC_APB1ENR_TIM4EN
#define RCC_APB1Periph_TIM6              RCC_APB1ENR_TIM6EN
#define RCC_APB1Periph_TIM7              RCC_APB1ENR_TIM7EN 
*/

/* F4XX --------------------------
void        RCC_AHB1PeriphClockCmd(uint32_t RCC_AHB1Periph, FunctionalState NewState);
void        RCC_AHB2PeriphClockCmd(uint32_t RCC_AHB2Periph, FunctionalState NewState);
void        RCC_AHB3PeriphClockCmd(uint32_t RCC_AHB3Periph, FunctionalState NewState);
void        RCC_APB1PeriphClockCmd(uint32_t RCC_APB1Periph, FunctionalState NewState);
void        RCC_APB2PeriphClockCmd(uint32_t RCC_APB2Periph, FunctionalState NewState);

#define RCC_APB1Periph_TIM2              ((uint32_t)0x00000001)
#define RCC_APB1Periph_TIM3              ((uint32_t)0x00000002)
#define RCC_APB1Periph_TIM4              ((uint32_t)0x00000004)
#define RCC_APB1Periph_TIM5              ((uint32_t)0x00000008)
#define RCC_APB1Periph_TIM6              ((uint32_t)0x00000010)
#define RCC_APB1Periph_TIM7              ((uint32_t)0x00000020)
#define RCC_APB1Periph_TIM12             ((uint32_t)0x00000040)
#define RCC_APB1Periph_TIM13             ((uint32_t)0x00000080)
#define RCC_APB1Periph_TIM14             ((uint32_t)0x00000100)
//? #define RCC_APB1Periph_LPTIM1            ((uint32_t)0x00000200)

#define RCC_APB2Periph_TIM1              ((uint32_t)0x00000001)
#define RCC_APB2Periph_TIM8              ((uint32_t)0x00000002)
#define RCC_APB2Periph_TIM9              ((uint32_t)0x00010000)
#define RCC_APB2Periph_TIM10             ((uint32_t)0x00020000)
#define RCC_APB2Periph_TIM11             ((uint32_t)0x00040000)
*/

/* В скобках - серия, в которой таймера нет вообще
 APB1 - 2, 3, 4, 5(3), 6, 7, 12(3), 13(3), 14(3)
 APB2 - 1, 8, 15(4), 16(4), 17(4), 20(1,4), 9(3), 10(3) 11(3)

*/

#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<TIM_TypeDef>( TIM_TypeDef * pt )
    {
        #ifdef TIM6
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM6, APB1 );
        #endif
       
        #ifdef TIM7
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM7, APB1 );
        #endif
       
        // General-purpose timers (TIM2 to TIM5)
        #ifdef TIM2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM2, APB1 );
        #endif
        #ifdef TIM3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM3, APB1 );
        #endif
        #ifdef TIM4
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM4, APB1 );
        #endif
        #ifdef TIM5 /* STM32F1xx/STM32F4xx */
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM5, APB1 );
        #endif
       
        // General-purpose timers (TIM9 to TIM14) /* STM32F1xx/STM32F4xx */
        #ifdef TIM9
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM9, APB2 );
        #endif
        #ifdef TIM10
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM10,APB2 );
        #endif
        #ifdef TIM11
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM11,APB2 );
        #endif
        #ifdef TIM12
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM12,APB1 );
        #endif
        #ifdef TIM13
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM13,APB1 );
        #endif
        #ifdef TIM14
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM14,APB1 );
        #endif
       
        // General-purpose timers (TIM15/TIM16/TIM17) - STM32F3xx
        #ifdef TIM15
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM15,APB2 );
        #endif
        #ifdef TIM16
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM16,APB2 );
        #endif
        #ifdef TIM17
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM17,APB2 );
        #endif
       
       
        // Advanced-control timers (TIM1 and TIM8)
        #ifdef TIM1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM1, APB2 );
        #endif
        #ifdef TIM8
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM8, APB2 );
        #endif
        #ifdef TIM20 /* STM32F3xx */
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKBUS( TIM20,APB2 );
        #endif

        UMBA_ASSERT_FAIL();

        return ClockBus::CORECLK; //!!!
    }
#endif




#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<TIM_TypeDef>( TIM_TypeDef * pt )
    {
        // Basic timers (TIM6 and TIM7)
        #ifdef TIM6
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM6, RCC_APB1PeriphClockCmd );
        #endif
       
        #ifdef TIM7
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM7, RCC_APB1PeriphClockCmd );
        #endif
       
        // General-purpose timers (TIM2 to TIM5)
        #ifdef TIM2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM2, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef TIM3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM3, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef TIM4
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM4, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef TIM5 /* STM32F1xx/STM32F4xx */
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM5, RCC_APB1PeriphClockCmd );
        #endif
       
        // General-purpose timers (TIM9 to TIM14) /* STM32F1xx/STM32F4xx */
        #ifdef TIM9
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM9, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef TIM10
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM10, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef TIM11
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM11, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef TIM12
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM12, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef TIM13
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM13, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef TIM14
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM14, RCC_APB1PeriphClockCmd );
        #endif
       
        // General-purpose timers (TIM15/TIM16/TIM17) - STM32F3xx
        #ifdef TIM15
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM15, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef TIM16
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM16, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef TIM17
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM17, RCC_APB2PeriphClockCmd );
        #endif
       
       
        // Advanced-control timers (TIM1 and TIM8)
        #ifdef TIM1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM1, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef TIM8
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM8, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef TIM20 /* STM32F3xx */
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( TIM20, RCC_APB2PeriphClockCmd );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#endif




#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template <>
    inline
    uint32_t periphClockGetFlag<TIM_TypeDef>( TIM_TypeDef * pt )
    {
        // Basic timers (TIM6 and TIM7)
        #ifdef TIM6
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM6, RCC_APB1Periph_TIM6 );
        #endif
       
        #ifdef TIM7
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM7, RCC_APB1Periph_TIM7 );
        #endif
       
        // General-purpose timers (TIM2 to TIM5)
        #ifdef TIM2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM2, RCC_APB1Periph_TIM2 );
        #endif
        #ifdef TIM3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM3, RCC_APB1Periph_TIM3 );
        #endif
        #ifdef TIM4
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM4, RCC_APB1Periph_TIM4 );
        #endif
        #ifdef TIM5 /* STM32F1xx/STM32F4xx */
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM5, RCC_APB1Periph_TIM5 );
        #endif
       
        // General-purpose timers (TIM9 to TIM14) /* STM32F1xx/STM32F4xx */
        #ifdef TIM9
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM9, RCC_APB2Periph_TIM9 );
        #endif
        #ifdef TIM10
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM10, RCC_APB2Periph_TIM10 );
        #endif
        #ifdef TIM11
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM11, RCC_APB2Periph_TIM11 );
        #endif
        #ifdef TIM12
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM12, RCC_APB1Periph_TIM12 );
        #endif
        #ifdef TIM13
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM13, RCC_APB1Periph_TIM13 );
        #endif
        #ifdef TIM14
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM14, RCC_APB1Periph_TIM14 );
        #endif
       
        // General-purpose timers (TIM15/TIM16/TIM17) - STM32F3xx
        #ifdef TIM15
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM15, RCC_APB2Periph_TIM15 );
        #endif
        #ifdef TIM16
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM16, RCC_APB2Periph_TIM16 );
        #endif
        #ifdef TIM17
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM17, RCC_APB2Periph_TIM17 );
        #endif
       
       
        // Advanced-control timers (TIM1 and TIM8)
        #ifdef TIM1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM1, RCC_APB2Periph_TIM1 );
        #endif
        #ifdef TIM8
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM8, RCC_APB2Periph_TIM8 );
        #endif
        #ifdef TIM20 /* STM32F3xx */
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( TIM20, RCC_APB2Periph_TIM20 );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#endif


#define UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( port, pin, chan, res ) \
                          if (pGpioPort==port && pinNo==pin && timChannel==chan)    \
                               return res

#define UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( portPin, chan, res ) \
                          if (pGpioPortAddr==portPin.port && pinNo==portPin.pinNo && timChannel==chan)    \
                               return res





#if defined(STM32F1_SERIES)


    template < >
    inline
    uint32_t periphAltFunctionGetFlags< TIM_TypeDef, int >( TIM_TypeDef *pt, int timChannel, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #ifdef TIM1
            if (pt==TIM1)
            {
                // Table 46. TIM1 alternate function remapping

                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PA8 , 1, 0 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PA9 , 2, 0 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PA10, 3, 0 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PA11, 4, 0 );

                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PA7 , -1, GPIO_PartialRemap_TIM1 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PB0 , -2, GPIO_PartialRemap_TIM1 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PB1 , -3, GPIO_PartialRemap_TIM1 );

                #if STM32_PACKAGE_PIN_NUMBER > 36
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PB13, -1, 0 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PB14, -2, 0 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PB15, -3, 0 );
                #endif

                #if STM32_PACKAGE_PIN_NUMBER >= 100
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PE9 , 1, GPIO_FullRemap_TIM1 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PE11, 2, GPIO_FullRemap_TIM1 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PE13, 3, GPIO_FullRemap_TIM1 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PE14, 4, GPIO_FullRemap_TIM1 );

                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PE8 , -1, GPIO_FullRemap_TIM1 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PE10, -2, GPIO_FullRemap_TIM1 );
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( UMBA_PINADDR_PE12, -3, GPIO_FullRemap_TIM1 );
                #endif

            }
        #endif

        UMBA_ASSERT_FAIL();

        return 0;

    }


#elif defined(STM32F3_SERIES)

    template < >
    inline
    uint32_t periphAltFunctionGetFlags< TIM_TypeDef, int >( TIM_TypeDef *pt, int timChannel, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #ifdef TIM1
            if (pt==TIM1)
            {
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  7, -1, GPIO_AF_1 ); // PA7
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  8,  1, GPIO_AF_1 ); // PA8
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  9,  2, GPIO_AF_1 ); // PA9
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA, 10,  3, GPIO_AF_1 ); // PA10
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA, 11,  4, GPIO_AF_1 ); // PA11

                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  0, -2, GPIO_AF_1 ); // PB0
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  1, -3, GPIO_AF_1 ); // PB1
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB, 13, -1, GPIO_AF_1 ); // PB13
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB, 14, -2, GPIO_AF_1 ); // PB14
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB, 15, -3, GPIO_AF_1 ); // PB15

                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE,  8, -1, GPIO_AF_1 ); // PE8
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE,  9,  1, GPIO_AF_1 ); // PE9
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE, 10, -2, GPIO_AF_1 ); // PE10
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE, 11,  2, GPIO_AF_1 ); // PE11
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE, 12, -3, GPIO_AF_1 ); // PE12
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE, 13,  3, GPIO_AF_1 ); // PE13
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE, 14,  4, GPIO_AF_1 ); // PE14
            }
        #endif
        #ifdef TIM2
            if (pt==TIM2)
            {
                //UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  0,  1, GPIO_AF_1 ); // PA0 - ETR????
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  1,  2, GPIO_AF_1 ); // PA1
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  2,  3, GPIO_AF_1 ); // PA2
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  3,  4, GPIO_AF_1 ); // PA3
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA, 15,  1, GPIO_AF_1 ); // PA15

                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  3,  2, GPIO_AF_1 ); // PB3
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB, 10,  3, GPIO_AF_1 ); // PB10
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB, 11,  4, GPIO_AF_1 ); // PB10
            }
        #endif

        // https://www.st.com/resource/en/datasheet/stm32f303k8.pdf
        #if defined(STM32F303x8)

            #ifdef TIM16
                if (pt==TIM16)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  6,  1,  GPIO_AF_1 ); // PA6
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA, 12,  1,  GPIO_AF_1 ); // PA12
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA, 13, -1,  GPIO_AF_1 ); // PA13
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  4,  1,  GPIO_AF_1 ); // PB4
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  6, -1,  GPIO_AF_1 ); // PB6
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  8,  1,  GPIO_AF_1 ); // PB8
                    //UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE,  0,  1,  GPIO_AF_1 ); // PE0
                }
            #endif

        #else

            #ifdef TIM16
                if (pt==TIM16)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  6,  1,  GPIO_AF_1 ); // PA6
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA, 12,  1,  GPIO_AF_1 ); // PA12
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA, 13, -1,  GPIO_AF_1 ); // PA13
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  4,  1,  GPIO_AF_1 ); // PB4
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  6, -1,  GPIO_AF_1 ); // PB6
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOB,  8,  1,  GPIO_AF_1 ); // PB8
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOE,  0,  1,  GPIO_AF_1 ); // PE0
                }
            #endif

        #endif

        UMBA_ASSERT_FAIL();

        return 0;

    }


#elif defined(STM32F4_SERIES)


    template < >
    inline
    uint32_t periphAltFunctionGetFlags< TIM_TypeDef, int >( TIM_TypeDef *pt, int timChannel, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #ifdef TIM1
            if (pt==TIM1)
            {
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA,  7, -1, GPIO_AF_1 ); // PA7
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA,  8,  1, GPIO_AF_1 ); // PA8
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA,  9,  2, GPIO_AF_1 ); // PA9
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA, 10,  3, GPIO_AF_1 ); // PA10
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA, 11,  4, GPIO_AF_1 ); // PA11
                                                                  _BY_ADDR
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOB,  0, -2, GPIO_AF_1 ); // PB0
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOB,  1, -3, GPIO_AF_1 ); // PB1
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOB, 13, -1, GPIO_AF_1 ); // PB13
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOB, 14, -2, GPIO_AF_1 ); // PB14
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOB, 15, -3, GPIO_AF_1 ); // PB15
                                                                  _BY_ADDR
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOE,  8, -1, GPIO_AF_1 ); // PE8
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOE,  9,  1, GPIO_AF_1 ); // PE9
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOE, 10, -2, GPIO_AF_1 ); // PE10
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOE, 11,  2, GPIO_AF_1 ); // PE11
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOE, 12, -3, GPIO_AF_1 ); // PE12
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOE, 13,  3, GPIO_AF_1 ); // PE13
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOE, 14,  4, GPIO_AF_1 ); // PE14
            }
        #endif
        #ifdef TIM2
            if (pt==TIM2)
            {
                //UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM( GPIOA,  0,  1, GPIO_AF_1 ); // PA0 - ETR????
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA,  1,  2, GPIO_AF_1 ); // PA1
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA,  2,  3, GPIO_AF_1 ); // PA2
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA,  3,  4, GPIO_AF_1 ); // PA3
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOA, 15,  1, GPIO_AF_1 ); // PA15

                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOB,  3,  2, GPIO_AF_1 ); // PB3
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOB, 10,  3, GPIO_AF_1 ); // PB10
                UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN_TIM_BY_ADDR( GPIOB, 11,  4, GPIO_AF_1 ); // PB10
            }
        #endif

        UMBA_ASSERT_FAIL();

        return 0;

    }


#endif


//-----------------------------------------------------------------------------

inline
void timerBaseInit( TIM_TypeDef* TIMx
                    , uint16_t prescaler
                    , uint32_t period
                    , uint16_t counterMode       = TIM_CounterMode_Up // _Down, _CenterAligned1-3
                    , uint16_t clockDivision     = TIM_CKD_DIV1                                  
                    , uint8_t  repetitionCounter = 0                                             
                    )
{
    initPeriphClock( TIMx, ENABLE );

    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);

    TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
    TIM_TimeBaseStructure.TIM_CounterMode = counterMode;
    TIM_TimeBaseStructure.TIM_Period = period;
    
    TIM_TimeBaseStructure.TIM_ClockDivision = clockDivision;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = repetitionCounter;

    TIM_TimeBaseInit(TIMx, &TIM_TimeBaseStructure);
}

//-----------------------------------------------------------------------------

inline
void timerInitChannelPwm( TIM_TypeDef* TIMx
                        , int          chNo
                        , GPIO_TypeDef*chPort
                        , uint16_t     chPinNo
                        , uint32_t     pulse
                        , uint16_t     pwmMode                // TIM_OCMode_PWM*                           
                        , uint16_t     outputCompareState     = TIM_OutputState_Enable // TIM_OutputState_*
                        , uint16_t     outputComparePolarity  = TIM_OCPolarity_Low // TIM_OCPolarity_*     
                        )
{
    umba::periph::traits::initPeriphClock( chPort, ENABLE, umba::periph::traits::getPeriphClockGpioAltFunctionFlag(chPort) );
    gpioInit( chPort, PinSpeed::high, PinMode::alt_mode_pp, 1 << chPinNo ); // GPIO_Pin_X

    TIM_OCInitTypeDef TIM_OCStruct;
    TIM_OCStructInit( &TIM_OCStruct );

    UMBA_ASSERT( pwmMode == TIM_OCMode_PWM1 || pwmMode == TIM_OCMode_PWM2 );
    TIM_OCStruct.TIM_OCMode = pwmMode;    // TIMx->CCMR1

    UMBA_ASSERT( outputCompareState == TIM_OutputState_Disable || outputCompareState == TIM_OutputState_Enable );
    

    UMBA_ASSERT( outputComparePolarity == TIM_OCPolarity_High || outputComparePolarity == TIM_OCPolarity_Low );
    TIM_OCStruct.TIM_OCPolarity = outputComparePolarity;

    int chNoAbs = chNo;
    if (chNoAbs<0)
    {
        // invert polarity
        chNoAbs = -chNoAbs;
        if (TIM_OCStruct.TIM_OCPolarity==TIM_OCPolarity_High)
            TIM_OCStruct.TIM_OCPolarity = TIM_OCPolarity_Low;
        else
            TIM_OCStruct.TIM_OCPolarity = TIM_OCPolarity_High;

        TIM_OCStruct.TIM_OutputNState = outputCompareState;

        TIM_OCStruct.TIM_OCNIdleState = TIM_OCIdleState_Reset;
        // https://community.arm.com/developer/tools-software/tools/f/keil-forum/25928/stm32-3-complementary-pwm-signals-problem
    }
    else // >0
    {
        TIM_OCStruct.TIM_OutputState = outputCompareState;
        TIM_OCStruct.TIM_OCIdleState = TIM_OCIdleState_Reset;
    }

    TIM_OCStruct.TIM_Pulse = pulse; // TIMx->CCR1 

/*
TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;
*/

    switch(chNoAbs)
       {
        case 1:  
                TIM_OC1Init(TIMx, &TIM_OCStruct);
                TIM_OC1PreloadConfig(TIMx, TIM_OCPreload_Enable); // mandatory for PWM
                break;
        case 2:  
                TIM_OC2Init(TIMx, &TIM_OCStruct);
                TIM_OC2PreloadConfig(TIMx, TIM_OCPreload_Enable); // mandatory for PWM
                break;
        case 3:  
                TIM_OC3Init(TIMx, &TIM_OCStruct);
                TIM_OC3PreloadConfig(TIMx, TIM_OCPreload_Enable); // mandatory for PWM
                break;
        case 4:  
                TIM_OC4Init(TIMx, &TIM_OCStruct);
                TIM_OC4PreloadConfig(TIMx, TIM_OCPreload_Enable); // mandatory for PWM
                break;
        default:            
                UMBA_ASSERT_FAIL();
       }


    //if (timerIsAdvanced(TIMx))
    if (timerHasBdtrRegister(TIMx))
        TIM_CtrlPWMOutputs( TIMx, ENABLE);

    periphAltFunctionConfigure( TIMx
                              , makePinAltFunctionInfo( chNo, chPort, chPinNo )
                              );

}

inline
void timerEnable( TIM_TypeDef* TIMx, FunctionalState NewState = ENABLE)
{
    TIM_Cmd( TIMx, NewState);
}

// see https://www.st.com/content/ccc/resource/technical/document/application_note/group0/91/01/84/3f/7c/67/41/3f/DM00236305/files/DM00236305.pdf/jcr:content/translations/en.DM00236305.pdf

inline
void timerSetCaptureCompareRegister( TIM_TypeDef* TIMx, int chNo, uint16_t ccrVal )
{
    if (chNo<0)
        chNo = -chNo;

    switch(chNo)
       {
        case 1: TIMx->CCR1 = ccrVal; return;
        case 2: TIMx->CCR2 = ccrVal; return;
        case 3: TIMx->CCR3 = ccrVal; return;
        case 4: TIMx->CCR4 = ccrVal; return;
        default:
                UMBA_ASSERT_FAIL();
       }
}











enum class TimerPwmControlType
{
    millisecs,
    microsecs,
    percent,
    permille,
    ppm        // 1000 ppm (пи-пи-эм) == 1 permille
};


inline
void timerPwmControl( TIM_TypeDef* TIMx, int chNo 
                    , uint32_t               pwmFreq
                    , uint32_t               pwmPeriodMaxValue
                    , TimerPwmControlType    ctrlType
                    , uint32_t               pwmValue
                    )
{
    if (ctrlType==TimerPwmControlType::millisecs)
    {
        pwmValue *= 1000;
        ctrlType = TimerPwmControlType::microsecs;
    }

    if (ctrlType==TimerPwmControlType::percent)
    {
        pwmValue *= 10*1000;
        ctrlType = TimerPwmControlType::ppm;
    }

    if (ctrlType==TimerPwmControlType::permille)
    {
        pwmValue *=    1000;
        ctrlType = TimerPwmControlType::ppm;
    }

    if (ctrlType==TimerPwmControlType::microsecs)
    {
        // pwmPeriodMaxValue
        /* F = pwmFreq
           10**6 / F = T (usec)
        
           t = pwmValue;
           t / T * 10**6 - ppm
           t / (10**6/F) * 10**6

           t * F == ppm
        */
        pwmValue *= pwmFreq;
        ctrlType = TimerPwmControlType::ppm;
    }

    // all types converted to ppm value

    if ( pwmValue > (1000*1000) )
        pwmValue = 1000*1000;

    // pwmPeriodMaxValue - max 65535 - 0.65 * 10**5
    // pwmValue max - 10**6
    // uint32_t max 0.42 * 10**10
    // 0.65 * 10**5 * 10**6 = 0.65 * 10**11 - не лезет в 32 бита на два десятичных порядка
    // Снижаем точность до 1/10000 - 1/10 промилле
    // 0.065 * 10**10 - влезает с запасом в 0.42 * 10**10

    pwmValue /= 100;

    uint16_t timerCounter = (uint16_t)(pwmPeriodMaxValue * pwmValue / 10000);

    //#ifdef STM32F4_SERIES
    timerSetCaptureCompareRegister( TIMx, chNo, timerCounter );
    //#endif

}





} // namespace traits
} // namespace periph
} // namespace umba

