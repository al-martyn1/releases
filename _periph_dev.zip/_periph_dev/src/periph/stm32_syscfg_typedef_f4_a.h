#pragma once


    // 0x4001 3800 - 0x4001 3BFF SYSCFG
    // Section 9.2.8: SYSCFG register maps for STM32F405xx/07xx and STM32F415xx/17xx on page 294 
    // Section 9.3.8: SYSCFG register maps for STM32F42xxx and STM32F43xxx on page 301
    
    typedef struct
    {                           // Offs
      __IO uint32_t MEMRMP  ;   // 0x00
      __IO uint32_t PMC     ;   // 0x04
      __IO uint32_t EXTICR[4];  // 0x08, 0x0C, 0x10, 0x14
           uint32_t RESERVED0;  // 0x18
           uint32_t RESERVED1;  // 0x1C
      __IO uint32_t CMPCR   ;   // 0x20
    } SYSCFG_TypeDef;
    
    #define SYSCFG ((SYSCFG_TypeDef*)0x40013800)
    SYSCFG_TypeDef * const SYSCFG = (SYSCFG_TypeDef*)0x40013800;
