#pragma once


    // 0x4001 0000 - 0x4001 03FF AFIO Section 9.5 on page 194

    typedef struct
    {                           // Offs
      __IO uint32_t EVCR    ;   // 0x00
      __IO uint32_t MAPR    ;   // 0x04
      __IO uint32_t EXTICR[4];  // 0x08, 0x0C, 0x10, 0x14
           uint32_t RESERVED0;  // 0x18
      __IO uint32_t MAPR2   ;   // 0x1C
    } SYSCFG_TypeDef;

    // Also Known As AFIO
    
    //#define SYSCFG ((SYSCFG_TypeDef*)0x40010000)
    SYSCFG_TypeDef * const SYSCFG = (SYSCFG_TypeDef*)0x40010000;
