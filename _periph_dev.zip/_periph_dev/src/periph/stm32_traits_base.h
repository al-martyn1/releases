#pragma once

#include "umba/umba.h"

#include "stm32.h"
#include "stm32_drivers.h"

#include <cstddef>
#include <stddef.h>

#ifndef NO_SHORT_PINS
    #include "stm32_pinaddrs_short.h"
#endif

#include "stm32_pinaddrs.h"


// umba::periph::traits

namespace umba
{
namespace periph
{
namespace traits
{


//-----------------------------------------------------------------------------
typedef GPIO_TypeDef*     RawGpioPortType;
typedef uint16_t          RawGpioPortBits;
static  const unsigned    maxGpioPortPins = 16;


#define UMBA_PINADDR_INVALID  umba::periph::traits::GpioPinAddr({ (RawGpioPortType)0, 0  })
#define UMBA_PINADDR_UNDEF    UMBA_PINADDR_INVALID


//-----------------------------------------------------------------------------
//#include "umba/pushpack2.h"
struct GpioPinAddr
{
    RawGpioPortType   port;
    unsigned          pinNo;

}; // struct GpioPinConfig

constexpr GpioPinAddr invalid_pin_addr = { 0, 0 };



inline
bool operator==( const GpioPinAddr &a, const GpioPinAddr &b )
{
    return a.port==b.port && a.pinNo==b.pinNo;
}

inline
bool operator!=( const GpioPinAddr &a, const GpioPinAddr &b )
{
    return a.port!=b.port || a.pinNo!=b.pinNo;
}

inline
bool isValidPinPort( RawGpioPortType port )
{
    return port != (RawGpioPortType)0;
}

inline
bool isValidPinNo( uint16_t pinNo )
{
    return pinNo < 16;
}

inline
bool isValidPinAddr( const GpioPinAddr &a )
{
    return isValidPinPort(a.port) && isValidPinNo(a.pinNo);
}


} // namespace traits
} // namespace periph
} // namespace umba



