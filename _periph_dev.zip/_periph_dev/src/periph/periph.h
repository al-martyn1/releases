#pragma once

#if defined(STM32F0_SERIES) || defined(STM32F1_SERIES) || defined(STM32F2_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES) || defined(STM32F7_SERIES)\
                             || defined(STM32L0_SERIES) || defined(STM32L1_SERIES) || defined(STM32L4_SERIES) \
                             || defined(MILANDR)

    #include "stm32_traits.h"
    
#endif

#include "adc.h"
#include "dac.h"
#include "gpio.h"
//#include ""


// umba::periph
namespace umba
{
namespace periph
{

using traits::ClockBus;

inline
const char* getClockBusName( ClockBus clockBus )
{
    return traits::getClockBusName( clockBus );
}

inline
unsigned clockGetFreq( ClockBus ebus )
{
    return traits::clockGetFreq( ebus );
}


template<typename TPeriph>
inline
uint16_t periphGetNo( TPeriph *pPeriph )
{
    return umba::periph::traits::periphGetNo(pPeriph);
}


} // namespace periph
} // namespace umba





