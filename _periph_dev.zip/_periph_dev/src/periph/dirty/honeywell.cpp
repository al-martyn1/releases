#include "honeywell.h"

// https://electronics.stackexchange.com/questions/181181/arduino-interface-with-i2c-pressure-sensor


HoneywellFloat honeywellPressureSensor_HSCSSNN001PD2a3_valueConversion( uint16_t sensorOutputVal )
{
    uint16_t outputMin = 1638;  // 10%
    uint16_t outputMax = 14745; // 90%
    uint16_t outputDelta = outputMax - outputMin;

    HoneywellFloat Pmin = -1.0;  // 10%
    HoneywellFloat Pmax =  1.0; // 90%
    HoneywellFloat deltaP = Pmax - Pmin;

    uint16_t outputValDeltaMin = sensorOutputVal - outputMin;

    HoneywellFloat deltasProduction = deltaP * outputValDeltaMin;
    HoneywellFloat deltasProductionNormed = deltasProduction / outputDelta;
    HoneywellFloat P = deltasProductionNormed + Pmin;
    return P;
}


