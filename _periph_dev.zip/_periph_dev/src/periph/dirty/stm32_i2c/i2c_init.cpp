#include "i2c_init.h"
#include "i2c_helpers.h"


namespace umba
{
namespace periph
{
namespace dirty
{

//-----------------------------------------------------------------------------
I2C_TypeDef* I2cInitializer::getRawPort()
{
    return m_I2Cx;
}

//-----------------------------------------------------------------------------
I2cInitializer::I2cInitializer( I2C_TypeDef* I2Cx
          , uint32_t i2cSpeed
          , uint8_t  i2cSelfAddr
          , GPIO_TypeDef *portScl, uint16_t sclPinNo
          , GPIO_TypeDef *portSda, uint16_t sdaPinNo
          )
  : m_I2Cx        (I2Cx        )
  , m_i2cSpeed    (i2cSpeed    )
  , m_i2cSelfAddr (i2cSelfAddr )
  , m_portScl     (portScl     )
  , m_sclPinNo    (sclPinNo    )
  , m_portSda     (portSda     )
  , m_sdaPinNo    (sdaPinNo    )
{
}

//-----------------------------------------------------------------------------
void I2cInitializer::initialize( )
{
    init_I2C2( m_I2Cx, m_i2cSpeed, m_i2cSelfAddr, m_portScl, m_sclPinNo, m_portSda, m_sdaPinNo );
}

//-----------------------------------------------------------------------------
void I2cInitializer::reset( )
{
    initialize( );
}



} // namespace dirty
} // namespace periph
} // namespace umba
