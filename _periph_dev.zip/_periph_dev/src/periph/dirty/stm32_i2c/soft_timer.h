#pragma once

#include "umba/time_service.h"
#include "umba/critical_section.h"

//#include "cpp11_stub.h"

   



//#define DEBUG_SOFT_TIMER

#ifdef DEBUG_SOFT_TIMER

    #define STIM_NONBLOCKING_PRINT(...)    UMBA_DEBUG_PRINT(__VA_ARGS__)
    #define STIM_BLOCKING_PRINT(...)       UMBA_DEBUG_WAIT_PRINT(__VA_ARGS__)
    #define STIM_BLOCKING_PUTS(s)          UMBA_DEBUG_WAIT_PUTS(s)

#else

    #define STIM_NONBLOCKING_PRINT(...)    do {} while(0) /*(void)*/
    #define STIM_BLOCKING_PRINT(...)       do {} while(0) /*(void)*/
    #define STIM_BLOCKING_PUTS(s)          do {} while(0) /*(void)*/

#endif

//#include "debug_print.h"



/*
http://easyelectronics.ru/arm-uchebnyj-kurs-systick-sistemnyj-tajmer.html
http://stm32.chrns.com/post/149112836514/systick
*/

//-----------------------------------------------------------------------------
struct TickSourceNative
{
    typedef umba::time_service::TimeTick TimeTick;

    static TimeTick getModule()
    {
        static TimeTick module = SysTick->LOAD + 1;
        return module;
    }

    static TimeTick getHighPart()
    {
        static TimeTick highPart = 0;

        UMBA_CRITICAL_SECTION_EX(umba::CriticalSection, umba::globalCriticalSection);

        if (SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk)
            highPart++; // была перезагрузка
        return highPart;
    }

    static TimeTick getCurTick()
    {
        TimeTick module = getModule();
        // трансформировали в человеческий вид - от 0 до SysTick->LOAD
        // и прибавили старшую часть
        getHighPart();
        TimeTick lowPart = module - SysTick->VAL;
        TimeTick highPartModuleScaled = module*getHighPart();

        return highPartModuleScaled + lowPart;
    }

    static TimeTick getTickMax()
    {
        UMBA_ASSERT( ((TimeTick)-1) > 0 );
        return ((TimeTick)-1) - 1;
    }

    static TimeTick calcElapsedTicks( TimeTick curTick, TimeTick prevTick )
    {
        return curTick - prevTick;
    }

}; // struct TickSourceNative






//-----------------------------------------------------------------------------
struct TickSourceMillisec
{
    typedef umba::time_service::TimeTick TimeTick;

    static TimeTick getCurTick()
    {
        return umba::time_service::getCurTimeMs();
    }

    static TimeTick getTickMax()
    {
        UMBA_ASSERT( ((TimeTick)-1) > 0 );
        return ((TimeTick)-1) - 1;
    }

    static TimeTick calcElapsedTicks( TimeTick curTick, TimeTick prevTick )
    {
        return curTick - prevTick;
    }

}; // struct TickSourceMillisec


//-----------------------------------------------------------------------------
template< umba::time_service::TimeTick scaleFactor = (umba::time_service::TimeTick)1 >
struct ScaleFactorConst
{

    //UMBA_CONSTEXPR
    umba::time_service::TimeTick getScaleFactor() const
    {
	    return scaleFactor;
    }
}; // struct ScaleFactorConst


//-----------------------------------------------------------------------------
template< uint32_t ScaleFactorValue>
struct ScaleFactorFromNative
{
    ScaleFactorFromNative()
    : m_scaleFactor(SystemCoreClock / ScaleFactorValue)
    {
                              // Next valid for 1^6 scale factor
        if (!m_scaleFactor)   // SystemCoreClock is less than 1MHz - too slow device
           m_scaleFactor = 1; // microsecs intervals will be wrong
    }

    umba::time_service::TimeTick getScaleFactor() const
    {
	    return m_scaleFactor;
    }

private:
    umba::time_service::TimeTick m_scaleFactor;

}; // struct ScaleFactorFromNative

//-----------------------------------------------------------------------------

typedef  ScaleFactorFromNative<   1000*1000>  ScaleFactorNativeToMicrosec;
typedef  ScaleFactorFromNative<10*1000*1000>  ScaleFactorNativeTo100Nanosec;
//-----------------------------------------------------------------------------







//-----------------------------------------------------------------------------
struct ISoftTimer
{
    typedef umba::time_service::TimeTick TimeTick;

    // перезапускает таймер с текущим интервалом
    virtual void reset( )                              = 0;
    
    // задает новый интервал и перезапускает таймер
    virtual void reset( TimeTick newTimeout )          = 0;

    // Устанавливает таймаут без перезапуска таймера
    virtual void setTimeout( TimeTick newTimeout )     = 0;
    virtual TimeTick getTimeout( ) const               = 0;

    virtual TimeTick getElapsedTicks( ) const          = 0;
    virtual bool isTimedOut() const                    = 0;
    virtual bool checkTimedOut()                       = 0; // also reset if autoreset option is enabled
    virtual bool isInfTimeout(TimeTick t) const        = 0;
    virtual bool getAutoreset( ) const                 = 0;
    virtual void setAutoreset( bool autoReset )        = 0;

    virtual TimeTick getStartTick() const              = 0;
    virtual TimeTick getTimedoutTick() const           = 0;
    virtual TimeTick getTimedoutElapsed() const        = 0;

}; // struct ISoftTimer



//-----------------------------------------------------------------------------
template< typename TickSourceImplT, typename ScaleFactorT >
struct SoftTimerImpl : public ISoftTimer
{

    typedef ISoftTimer::TimeTick TimeTick;
    static const TimeTick        infTimeout = (TimeTick)-1;

    SoftTimerImpl( TimeTick timeout = infTimeout, bool autoReset = false )
    : m_scaleFactor()
    , m_nativeStartTick()
    , m_timeout()
    , m_nativeTimeout()
    , m_autoReset(autoReset)
    {
        setTimeout(timeout);
        startTimer();
    }
    
    virtual void setTimeout( TimeTick newTimeout ) override
    {
        m_timeout = newTimeout;
        if (m_timeout==infTimeout)
           return;

        //m_nativeTimeout = m_timeout * m_scaleFactor.getScaleFactor();
        m_nativeTimeout = toNative(m_timeout);
        
        #ifndef UMBA_NDEBUG
            // Посмотреть при отладке, какое выскочило значение
	        TimeTick nativeTickMax = TickSourceImplT::getTickMax();
	        UMBA_ASSERT( m_nativeTimeout < nativeTickMax );
        #else
	        UMBA_ASSERT( m_nativeTimeout < TickSourceImplT::getTickMax() );
        #endif
    }

    virtual bool isInfTimeout(TimeTick t) const override
    {
        return t==infTimeout;
    }
    
    virtual TimeTick getTimeout( ) const override
    {
        return m_timeout;
    }

    virtual void reset( TimeTick newTimeout ) override
    {
        setTimeout( newTimeout );
        startTimer();
    }

    virtual void reset( ) override
    {
        startTimer();
    }

    virtual bool getAutoreset( ) const override
    {
        return m_autoReset;
    }

    virtual void setAutoreset( bool autoReset ) override
    {
        m_autoReset = autoReset;
    }

    virtual TimeTick getElapsedTicks( ) const override
    {
        TimeTick nativeNow  = getNativeCurTick();
        TimeTick nativeDiff = TickSourceImplT::calcElapsedTicks( nativeNow, m_nativeStartTick );
        //return nativeDiff / m_scaleFactor.getScaleFactor();
        return fromNative(nativeDiff);
    }


    virtual bool isTimedOut() const override
    {
        // Если нужно использовать код, который использует таймер, 
        // в блокирующем или в неждующем режиме,
        // проще использовать значения таймаута inf и 0,
        // вместо переписывания кода

        if (isInfTimeout(m_timeout))
        {
            STIM_BLOCKING_PRINT("STIM: INF\n");
            return false;
        }

        if (m_timeout==0)
        {
            if (!m_timedoutTick)
            {
                m_timedoutTick        = getElapsedTicks();
                STIM_BLOCKING_PRINT("STIM: ZERO, set tdTick: %d\n", m_timedoutTick);
            }
            m_timedoutElapsedTick = 0;
            STIM_BLOCKING_PRINT("STIM: ZERO, set elTick: %d\n", m_timedoutElapsedTick);
            return true;
        }

        TimeTick nativeNow  = getNativeCurTick();
        TimeTick nativeDiff = TickSourceImplT::calcElapsedTicks( nativeNow, m_nativeStartTick );

        TimeTick elapsedTicks = fromNative(nativeDiff); // getElapsedTicks( );
        if (elapsedTicks < m_timeout)
        {
            STIM_BLOCKING_PRINT("STIM: CONT, elTick: %d\n", elapsedTicks);
            return false;
        }
        m_timedoutTick = fromNative(nativeNow);
        m_timedoutElapsedTick = elapsedTicks;

        STIM_BLOCKING_PRINT("STIM: TIMEDOUT, stTick: %d, tdTick: %d, elTick: %d\n", getStartTick(), m_timedoutTick, m_timedoutElapsedTick);

        return true;
    }

    virtual TimeTick getStartTick() const override
    {
        return fromNative(m_nativeStartTick);
    }

    virtual TimeTick getTimedoutTick() const override
    {
        return m_timedoutTick;
    }

    virtual TimeTick getTimedoutElapsed() const override
    {
        return m_timedoutElapsedTick;
    }

    // also reset if autoreset option is enabled
    virtual bool checkTimedOut() override
    {
        bool timedOut = isTimedOut();
        if (!timedOut)
            return timedOut;

        if (m_autoReset)
            reset();

        return timedOut;
    }
    

private:


    TimeTick fromNative(TimeTick tick) const
    {
        return tick / m_scaleFactor.getScaleFactor();
    }

    TimeTick toNative(TimeTick tick) const
    {
        return tick * m_scaleFactor.getScaleFactor();
    }

    TimeTick getNativeCurTick() const
    {
        return TickSourceImplT::getCurTick();
    }

    void startTimer()
    {
        m_nativeStartTick = getNativeCurTick();
        m_timedoutTick = 0;
        m_timedoutElapsedTick = 0;
    }


    ScaleFactorT  m_scaleFactor;

    TimeTick      m_nativeStartTick;  // in native TickSourceImplT units
    TimeTick      m_timeout;          // not scaled to native
    TimeTick      m_nativeTimeout;

    mutable TimeTick      m_timedoutTick;
    mutable TimeTick      m_timedoutElapsedTick;

    bool          m_autoReset;

}; // struct SoftTimerImpl


//-----------------------------------------------------------------------------
typedef SoftTimerImpl< TickSourceNative, ScaleFactorConst<1> >              SoftTimerNativeTick;
typedef SoftTimerImpl< TickSourceNative, ScaleFactorNativeToMicrosec >      SoftTimerMicrosec;   // need at least 1MHz core clock
typedef SoftTimerImpl< TickSourceNative, ScaleFactorNativeTo100Nanosec >    SoftTimer100Nanosec; // need at least 10MHz core clock
typedef SoftTimerImpl< TickSourceMillisec, ScaleFactorConst<1> >            SoftTimerMillisec;






