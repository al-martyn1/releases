#pragma once


#include "umba.h"
#include "i2c_nonblocking.h"

namespace umba
{
namespace periph
{
namespace dirty
{



struct I2cInitializer : public II2cInitializer
{
    I2cInitializer( I2C_TypeDef* I2Cx
              , uint32_t i2cSpeed
              , uint8_t  i2cSelfAddr
              , GPIO_TypeDef *portScl, uint16_t sclPinNo
              , GPIO_TypeDef *portSda, uint16_t sdaPinNo
              );

    virtual void initialize( );
    virtual void reset( );
    I2C_TypeDef* getRawPort();

protected:

    I2C_TypeDef*  m_I2Cx;
    uint32_t      m_i2cSpeed;
    uint8_t       m_i2cSelfAddr;
    GPIO_TypeDef *m_portScl;
    uint16_t      m_sclPinNo;
    GPIO_TypeDef *m_portSda;
    uint16_t      m_sdaPinNo;

};



} // namespace dirty
} // namespace periph
} // namespace umba
