#pragma once

#include "soft_timer.h"

#include "vgpio/stm32_gpio_helpers.h"

//umba::stm32_gpio
//GPIO_TypeDef* portToGpio( umba::virtual_gpio::Port p )
//uint32_t gpioToRcc( GPIO_TypeDef * pGpio )


namespace umba
{
namespace periph
{
namespace dirty
{

/*
inline
uint32_t i2cToRcc( I2C_TypeDef* I2Cx )
{
    #ifdef I2C1
    if (I2Cx==I2C1)
        return RCC_APB1Periph_I2C1;
    #endif

    #ifdef I2C2
    if (I2Cx==I2C2)
        return RCC_APB1Periph_I2C2;
    #endif

    #ifdef I2C3
    if (I2Cx==I2C3)
        return RCC_APB1Periph_I2C3;
    #endif

    return 0;
}
*/


/*
inline
uint8_t i2cToAfConfig( I2C_TypeDef* I2Cx )
{
    #ifdef I2C1
    if (I2Cx==I2C1)
        return GPIO_AF_I2C1;
    #endif

    #ifdef I2C2
    if (I2Cx==I2C2)
        return GPIO_AF_I2C2;
    #endif

    #ifdef I2C3
    if (I2Cx==I2C3)
        return GPIO_AF_I2C3;
    #endif

    return 0;
}
*/

void init_I2C2( I2C_TypeDef* I2Cx
              , uint32_t i2cSpeed
              , uint8_t  i2cSelfAddr
              , GPIO_TypeDef *portScl, uint16_t sclPinNo
              , GPIO_TypeDef *portSda, uint16_t sdaPinNo
              );



} // namespace dirty
} // namespace periph
} // namespace umba



//#define USE_I2C1_PB6_PB7
//#define USE_I2C1_PB8_PB9
//#define USE_I2C2_PB10_PB11



/*
I2C soul scream - http://forum.easyelectronics.ru/viewtopic.php?f=35&t=8206
some impl - https://github.com/Catethysis/stm32_i2c/blob/master/I2C.c
http://catethysis.ru/i2c-restart-error-handling/

*/





unsigned I2C_StartTransmission(I2C_TypeDef* I2Cx, uint8_t transmissionDirection,  uint8_t slaveAddress, const ISoftTimer &asyncDelay);
void I2C_StartTransmission(I2C_TypeDef* I2Cx, uint8_t transmissionDirection,  uint8_t slaveAddress);
void I2C_WriteData(I2C_TypeDef* I2Cx, uint8_t data);
uint8_t I2C_ReadData(I2C_TypeDef* I2Cx);

bool I2C_IsMasterByteTransmitted(I2C_TypeDef* I2Cx);
bool I2C_IsMasterByteReceived(I2C_TypeDef* I2Cx);
bool I2C_TryWriteData(I2C_TypeDef* I2Cx, uint8_t data, const ISoftTimer &asyncDelay);
bool I2C_TryWriteData(I2C_TypeDef* I2Cx, uint8_t data, umba::time_service::TimeTick timeout);
bool I2C_TryReadData(I2C_TypeDef* I2Cx, uint8_t &data, const ISoftTimer &asyncDelay );
bool I2C_TryReadData(I2C_TypeDef* I2Cx, uint8_t &data, umba::time_service::TimeTick timeout);

bool I2C_IsBusy( I2C_TypeDef* I2Cx );
bool I2C_IsEventMasterNodeSelect(I2C_TypeDef* I2Cx);
bool I2C_IsEventMasterTransmitterModeSelected(I2C_TypeDef* I2Cx);
bool I2C_IsEventMasterReceiverModeSelected(I2C_TypeDef* I2Cx);
//bool I2C_IsEventMasterByteTransmitted(I2C_TypeDef* I2Cx);
bool I2C_IsMasterByteTransmitted(I2C_TypeDef* I2Cx);
bool I2C_IsMasterByteReceived(I2C_TypeDef* I2Cx);




