#pragma once

#include <stdint.h>

typedef float   HoneywellFloat;
//typedef double  HoneywellFloat;

HoneywellFloat honeywellPressureSensor_HSCSSNN001PD2a3_valueConversion( uint16_t sensorOutputVal );

