#pragma once


    /*
     0x4001 0000 - 0x4001 03FF   1K   SYSCFG + COMP + OPAMP
        Section 12.1.10 on page 261,
        Section 17.5.8 on page 464,
        Section 18.4.5 on page 486
    */
    
    typedef struct
    {                           // Offs
      __IO uint32_t CFGR1;      // 0x00
      __IO uint32_t RCR;        // 0x04
      __IO uint32_t EXTICR[4];  // 0x08, 0x0C, 0x10, 0x14
      __IO uint32_t CFGR2;      // 0x18
           uint32_t RESERVED0;  // 0x1C
           uint32_t RESERVED1;  // 0x20
           uint32_t RESERVED2;  // 0x24
           uint32_t RESERVED3;  // 0x28
           uint32_t RESERVED4;  // 0x2C
           uint32_t RESERVED5;  // 0x30
           uint32_t RESERVED6;  // 0x34
           uint32_t RESERVED7;  // 0x38
           uint32_t RESERVED8;  // 0x3C
           uint32_t RESERVED9;  // 0x40
           uint32_t RESERVED10; // 0x44
      __IO uint32_t CFGR4;      // 0x48
           uint32_t RESERVED11; // 0x4C
      __IO uint32_t CFGR3;      // 0x50
    } SYSCFG_TypeDef;

    //#define SYSCFG ((SYSCFG_TypeDef*)0x40010000)
    SYSCFG_TypeDef * const SYSCFG = (SYSCFG_TypeDef*)0x40010000;
