#pragma once

#if defined(STM32F0_SERIES) || defined(STM32F1_SERIES) || defined(STM32F2_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES) || defined(STM32F7_SERIES)\
                             || defined(STM32L0_SERIES) || defined(STM32L1_SERIES) || defined(STM32L4_SERIES) \
                             || defined(MILANDR)

    #include "stm32_traits.h"
    
#endif

// umba::periph
namespace umba
{
namespace periph
{
namespace flash
{


constexpr size_t page_size_256     = 256 ;
constexpr size_t page_size_512     = 512 ;
constexpr size_t page_size_1024    = 1024;
constexpr size_t page_size_2048    = 2048;
constexpr size_t page_size_4096    = 4096;
constexpr size_t page_size_8192    = 8192;
constexpr size_t page_size_1K      = page_size_1024;
constexpr size_t page_size_2K      = page_size_2048;
constexpr size_t page_size_4K      = page_size_4096;
constexpr size_t page_size_8K      = page_size_8192;

constexpr size_t flash_size_16K      = 16  * 1024;
constexpr size_t flash_size_32K      = 32  * 1024;
constexpr size_t flash_size_48K      = 48  * 1024;
constexpr size_t flash_size_64K      = 64  * 1024;
constexpr size_t flash_size_96K      = 96  * 1024;
constexpr size_t flash_size_128K     = 128 * 1024;
constexpr size_t flash_size_192K     = 192 * 1024;
constexpr size_t flash_size_256K     = 256 * 1024;
constexpr size_t flash_size_512K     = 512 * 1024;
constexpr size_t flash_size_1M       = 1024 * 1024;



template< typename TData, typename TCrcCalculator, size_t FlashSize, size_t PageSize, uintptr_t FlashAddr >
bool writeConfig( const TData &td )
{
    return traits::flashWriteConfig<TData, TCrcCalculator, FlashSize, PageSize, FlashAddr>(td);
}

template< typename TData, typename TCrcCalculator, size_t FlashSize, size_t PageSize, uintptr_t FlashAddr >
bool readConfig( TData &td )
{
    return traits::flashReadConfig<TData, TCrcCalculator, FlashSize, PageSize, FlashAddr>(td);
}

template< typename TData, typename TCrcCalculator, size_t FlashSize, size_t PageSize, uintptr_t FlashAddr >
bool invalidateConfig( )
{
    return traits::flashInvalidateConfig<TData, TCrcCalculator, FlashSize, PageSize, FlashAddr>();
}


} // namespace flash
} // namespace periph
} // namespace umba
