
class GpioPin
{

public:

    //GpioPin()                             = delete;
    GpioPin( const GpioPin &)        = delete;

    GpioPin( GpioPin &&)             = default;

    GpioPin()
    : m_pinAddr( GpioPinAddr{0,0} )
    , m_pinBit()
    , m_pinMode()
    , m_pinSpeed()
    , m_connected(false)
    {}

    GpioPin(GpioPinAddr pinAddr, PinMode pinMode = PinMode::gpio_out_pp, PinSpeed pinSpeed = PinSpeed::high) 
    : m_pinAddr(pinAddr)
    , m_pinBit(1<<m_pinAddr.pinNo)
    , m_pinMode(pinMode)
    , m_pinSpeed(pinSpeed)
    , m_connected(false)
    {
        //if (isAddrAssigned()) ???
        //    connect();
    }

    GpioPin(GpioPinAddr pinAddr, PinGetDirection pinDirection, PinSpeed pinSpeed = PinSpeed::high) 
    : m_pinAddr(pinAddr)
    , m_pinBit(1<<m_pinAddr.pinNo)
    , m_pinMode()
    , m_pinSpeed(pinSpeed)
    , m_connected(false)
    {
        UMBA_ASSERT( pinDirection != dir_auto );
        if (pinDirection==input)
            m_pinMode = PinMode::gpio_in_floating;
        else
            m_pinMode = PinMode::gpio_out_pp;
    }

    void assignAddrAndMode( GpioPinAddr pinAddr, PinMode pinMode = PinMode::gpio_out_pp, PinSpeed pinSpeed = PinSpeed::high )
    {
        UMBA_ASSERT(m_connected==false);

        m_pinAddr  = pinAddr;
        m_pinBit   = 1<<m_pinAddr.pinNo;
        m_pinMode  = pinMode;
        m_pinSpeed = pinSpeed;
    }

    void assignAddrAndMode( GpioPinAddr pinAddr, PinGetDirection pinDirection, PinSpeed pinSpeed = PinSpeed::high )
    {
        UMBA_ASSERT(m_connected==false);

        m_pinAddr  = pinAddr;
        m_pinBit   = 1<<m_pinAddr.pinNo;
        m_pinSpeed = pinSpeed;

        if (pinDirection==input)
            m_pinMode = PinMode::gpio_in_floating;
        else
            m_pinMode = PinMode::gpio_out_pp;
    }

    void connect() const
    {
        UMBA_ASSERT( m_pinAddr.port != 0 );
        UMBA_ASSERT( m_pinAddr.pinNo < maxGpioPortPins );

        initPeriphClock( m_pinAddr.port, ENABLE );
        gpioInit( m_pinAddr.port, m_pinSpeed, m_pinMode, m_pinBit );
        GpioPin *pThis = const_cast<GpioPin*>(this);
        pThis->m_connected = true;
    }

    void connect(PinGetDirection pinDirection, PinSpeed pinSpeed = PinSpeed::high)
    {
        UMBA_ASSERT( pinDirection != dir_auto );

        if (pinDirection==input)
            m_pinMode = PinMode::gpio_in_floating;
        else
            m_pinMode = PinMode::gpio_out_pp;

        m_pinSpeed = pinSpeed;

        connect();
    }

    void connect(PinMode pinMode, PinSpeed pinSpeed = PinSpeed::high)
    {
        m_pinMode  = pinMode;
        m_pinSpeed = pinSpeed;

        connect();
    }

    void shutdown()
    {
        //UMBA_ASSERT( m_connected != false );
        m_connected = false;
    }

    bool isConnected() const
    {
        return m_connected;
    }

    void checkConnect() const
    {
        if (!isConnected())
        {
            UMBA_ASSERT( isAddrAssigned() );
            GpioPin *pThis = const_cast<GpioPin*>(this);
            pThis->connect();
        }
    }

    GpioPinAddr getPinAddr() const
    {
        return m_pinAddr;
    }

    bool isAddrAssigned() const
    {
        return m_pinAddr.port != 0 && m_pinAddr.pinNo < maxGpioPortPins;
    }

    void set( ) const
    {
        UMBA_ASSERT(m_connected==true);
        UMBA_ASSERT( m_pinMode==PinMode::gpio_out_od || m_pinMode==PinMode::gpio_out_pp );
        rawGpioPortBitsSet( m_pinAddr.port, m_pinBit );
    }

    void set( bool newPinVal ) const
    {
        UMBA_ASSERT(m_connected==true);
        UMBA_ASSERT( m_pinMode==PinMode::gpio_out_od || m_pinMode==PinMode::gpio_out_pp );
        rawGpioPortBitsSetReset( m_pinAddr.port
                                       , newPinVal ? m_pinBit           : (RawGpioPortBits)0
                                       , newPinVal ? (RawGpioPortBits)0 : m_pinBit
                                       );
    }

    void reset( ) const
    {
        UMBA_ASSERT(m_connected==true);
        UMBA_ASSERT( m_pinMode==PinMode::gpio_out_od || m_pinMode==PinMode::gpio_out_pp );
        rawGpioPortBitsReset( m_pinAddr.port, m_pinBit );
    }

    #include "umba/optimize_speed.h"
    UMBA_FORCE_INLINE_MEMBER( void toggle() const )
    {
        //UMBA_ASSERT(m_connected==true);
        //UMBA_ASSERT( m_pinMode==PinMode::gpio_out_od || m_pinMode==PinMode::gpio_out_pp );
        rawGpioPortBitsToggle( m_pinAddr.port, m_pinBit );
    }
    #include "umba/optimize_pop.h"

    bool getOutput( ) const
    {
        UMBA_ASSERT(m_connected==true);
        UMBA_ASSERT( m_pinMode==PinMode::gpio_out_od || m_pinMode==PinMode::gpio_out_pp );
        return (rawGpioPortBitsOutputRead(m_pinAddr.port) & m_pinBit) ? true : false;
    }

    bool getInput( ) const
    {
        UMBA_ASSERT(m_connected==true);
        UMBA_ASSERT( m_pinMode==PinMode::gpio_in_floating || m_pinMode==PinMode::gpio_in_pulldown || m_pinMode==PinMode::gpio_in_pullup || m_pinMode==PinMode::gpio_out_od );
        return (rawGpioPortBitsRead(m_pinAddr.port) & m_pinBit) ? true : false;
    }

    bool get( PinGetDirection pinGetDirection = input ) const
    {
        if (pinGetDirection==dir_auto)
        {
            if (m_pinMode==PinMode::gpio_out_od || m_pinMode==PinMode::gpio_out_pp)
                return getOutput();
            else
                return getInput();
        }

        return (pinGetDirection==input)
             ? getInput( )
             : getOutput( )
             ;
    }

    void operator=( const GpioPin &otherPin )
    {
        // В операторах пытаемся автоматически законнектится.
        // Операторы сами по себе не быстры, и немного оверхеда их уже не спасет.
        // Для быстроты надо самому ручками коннектиться и использовать специальные методы

        checkConnect();
        set( otherPin.get(dir_auto) );
    }

    void operator=( bool bv )
    {
        checkConnect();
        set(bv);
    }

    operator bool() const
    {
        checkConnect();
        return get(dir_auto);
    }

    bool operator!() const
    {
        checkConnect();
        return !get(dir_auto);
    }


protected:

    GpioPinAddr         m_pinAddr;
    RawGpioPortBits     m_pinBit;
    PinMode             m_pinMode;
    PinSpeed            m_pinSpeed;
    bool                m_connected;

}; // class GpioPin


inline
bool operator==( const GpioPin &pin, bool bv )
{
    pin.checkConnect();
    return pin.get(PinGetDirection::dir_auto) == bv;
}

inline
bool operator==( bool bv, const GpioPin &pin )
{
    pin.checkConnect();
    return pin.get(PinGetDirection::dir_auto) == bv;
}

inline
bool operator!=( const GpioPin &pin, bool bv )
{
    pin.checkConnect();
    return pin.get(PinGetDirection::dir_auto) != bv;
}

inline
bool operator!=( bool bv, const GpioPin &pin )
{
    pin.checkConnect();
    return pin.get(PinGetDirection::dir_auto) != bv;
}

inline
bool operator==( const GpioPin &pin1, const GpioPin &pin2 )
{
    pin1.checkConnect();
    pin2.checkConnect();
    return pin1.get(PinGetDirection::dir_auto) == pin2.get(PinGetDirection::dir_auto);
}

inline
bool operator!=( const GpioPin &pin1, const GpioPin &pin2 )
{
    pin1.checkConnect();
    pin2.checkConnect();
    return pin1.get(PinGetDirection::dir_auto) != pin2.get(PinGetDirection::dir_auto);
}



inline
void gpioPinsConnect( GpioPin** pPins
                    , size_t    pinsCount
                    )
{
    UMBA_ASSERT(pPins!=0);

    for( size_t i = 0; i!=pinsCount; ++i, ++pPins )
    {
        GpioPin* pPin = *pPins;

        // "Начальству" сверху виднее, что оно делает
        if (!pPin)
            continue;
        
        if (!pPin->isConnected())
            pPin->connect();
    }
    
}


struct GpioPinValue
{
    GpioPin *pPin; // = 0;
    bool    value; // = false;
};


