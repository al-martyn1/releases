#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

namespace umba
{
namespace periph
{
namespace traits
{


#if defined(STM32F1_SERIES)

    typedef AFIO_TypeDef SYSCFG_TypeDef;
    #define SYSCFG                 AFIO
    #define RCC_APB2Periph_SYSCFG  RCC_APB2Periph_AFIO

#endif /* STM32F1_SERIES */



//    F3/F4/L1 RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template <>
    inline
    ClockBus periphClockGetBus<SYSCFG_TypeDef>( SYSCFG_TypeDef * pt )
    {
        return ClockBus::APB2;
    }

    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<SYSCFG_TypeDef>( SYSCFG_TypeDef * pt )
    {
        return RCC_APB2PeriphClockCmd;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<SYSCFG_TypeDef>( SYSCFG_TypeDef * pt )
    {
        #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
            return RCC_APB2Periph_SYSCFG; // For F1 used RCC_APB2Periph_AFIO (redefined RCC_APB2Periph_SYSCFG in above section )
        #endif
    }


#endif










} // namespace traits
} // namespace periph
} // namespace umba

