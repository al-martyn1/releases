#include "umba/umba.h"
#include "stm32.h"
#include "stm32_traits.h"


#ifdef STM32F303xC 

/*
    UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI2_IRQHandler );
    UMBA_IRQ_HANDLER( EXTI2_IRQHandler )
    {
    }
*/
    UMBA_IRQ_HANDLER( EXTI2_IRQHandler );

    UMBA_IRQ_HANDLER( EXTI2_TSC_IRQHandler )
    {
        if (umba::periph::traits::gpioExtiTestPendingIrq( (uint16_t)2 )) // PA2, PB2, and so on
        {
            EXTI2_IRQHandler();
            return;
        }

        // UNDONE: add TSC(???) handling
    }

#endif

/*
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI5_IRQHandler  );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI6_IRQHandler  );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI7_IRQHandler  );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI8_IRQHandler  );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI9_IRQHandler  );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI10_IRQHandler );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI11_IRQHandler );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI12_IRQHandler );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI13_IRQHandler );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI14_IRQHandler );
UMBA_DECLARE_WEAK_IRQ_HANDLER( EXTI15_IRQHandler );


UMBA_IRQ_HANDLER( EXTI5_IRQHandler  ) { }
UMBA_IRQ_HANDLER( EXTI6_IRQHandler  ) { }
UMBA_IRQ_HANDLER( EXTI7_IRQHandler  ) { }
UMBA_IRQ_HANDLER( EXTI8_IRQHandler  ) { }
UMBA_IRQ_HANDLER( EXTI9_IRQHandler  ) { }
UMBA_IRQ_HANDLER( EXTI10_IRQHandler ) { }
UMBA_IRQ_HANDLER( EXTI11_IRQHandler ) { }
UMBA_IRQ_HANDLER( EXTI12_IRQHandler ) { }
UMBA_IRQ_HANDLER( EXTI13_IRQHandler ) { }
UMBA_IRQ_HANDLER( EXTI14_IRQHandler ) { }
UMBA_IRQ_HANDLER( EXTI15_IRQHandler ) { }
*/

/*
UMBA_WEAK_IRQ_HANDLER( EXTI5_IRQHandler  ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI6_IRQHandler  ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI7_IRQHandler  ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI8_IRQHandler  ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI9_IRQHandler  ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI10_IRQHandler ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI11_IRQHandler ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI12_IRQHandler ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI13_IRQHandler ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI14_IRQHandler ) { }
UMBA_WEAK_IRQ_HANDLER( EXTI15_IRQHandler ) { }



#define UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN( pinNo )                       \
            do{                                                               \
            if (umba::periph::traits::gpioTestPendingEXTI( (uint16_t)pinNo )) \
            {                                                                 \
                EXTI##pinNo##_IRQHandler();                                   \
            }                                                                 \
            }                                                                 \
            while(0)



UMBA_IRQ_HANDLER( EXTI9_5_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(5);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(6);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(7);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(8);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(9);
}

UMBA_IRQ_HANDLER( EXTI15_10_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(10);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(11);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(12);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(13);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(14);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(15);
}
*/


namespace umba
{
namespace periph
{
namespace traits
{


static
UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( extiStubHandler )
{}

//volatile
static
ExtiHandlerVectorEntry extiHandlersVector[ 16 ] = 
{ { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
, { { 0, 0 }, extiStubHandler, 0 }
};



/*
struct ExtiHandlerVectorEntry
{
    GpioPinAddr        pinAddr;
    ExtiHandlerProcT   extiHandlerProc;
    void*              pParam;
};
*/



bool periphInstallIrqHandler  ( const GpioPinAddr &pinAddr, ExtiHandlerProcT proc, void *pParam )
{
    UMBA_ASSERT(isValidPinNo(pinAddr.pinNo));
    UMBA_ASSERT(isValidPinPort(pinAddr.port));
    UMBA_ASSERT(proc);

    bool res = false;

    UMBA_MEMORY_BARRIER();

    UMBA_DISABLE_IRQ();

    if (extiHandlersVector[pinAddr.pinNo].extiHandlerProc==extiStubHandler)
    {
        extiHandlersVector[pinAddr.pinNo].pinAddr.port    = pinAddr.port;
        extiHandlersVector[pinAddr.pinNo].pinAddr.pinNo   = pinAddr.pinNo;
        extiHandlersVector[pinAddr.pinNo].extiHandlerProc = proc;
        extiHandlersVector[pinAddr.pinNo].pParam          = pParam;
        UMBA_MEMORY_BARRIER();
        res = true;
    }

    UMBA_ENABLE_IRQ();

    return res;
}

bool periphUninstallIrqHandler( const GpioPinAddr &pinAddr )
{
    UMBA_ASSERT(isValidPinNo(pinAddr.pinNo));
    UMBA_ASSERT(isValidPinPort(pinAddr.port));

    bool res = false;

    UMBA_MEMORY_BARRIER();

    UMBA_DISABLE_IRQ();

    if (extiHandlersVector[pinAddr.pinNo].extiHandlerProc!=extiStubHandler)
    {
        extiHandlersVector[pinAddr.pinNo].extiHandlerProc = extiStubHandler;
        UMBA_MEMORY_BARRIER();
        res = true;
    }

    UMBA_ENABLE_IRQ();

    return res;
}



} // namespace traits
} // namespace periph
} // namespace umba


/*
    1) Выкинем do/while - может не оптимизироваться
    2) Вызов обработчика производим всегда - по дефолту у нас везде стабы
    3) Для линий, которые висят на отдельных обработчиках, не будем делать проверку пендинга
*/

#define UMBA_EXTI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING( pinNo_ ) \
             {                                                     \
                 /* umba::periph::traits::GpioPinAddr tmp = { umba::periph::traits::extiHandlersVector[pinNo_].pinAddr.port, umba::periph::traits::extiHandlersVector[pinNo_].pinAddr.pinNo }; */       \
                 /* umba::periph::traits::extiHandlersVector[pinNo_].extiHandlerProc( umba::periph::traits::extiHandlersVector[pinNo_].pParam, tmp );                                          */       \
                 umba::periph::traits::gpioExtiClearPendingIrq((uint16_t)pinNo_);                                                                                                                         \
                 umba::periph::traits::extiHandlersVector[pinNo_].extiHandlerProc( umba::periph::traits::extiHandlersVector[pinNo_].pParam, umba::periph::traits::extiHandlersVector[pinNo_].pinAddr ); \
             }

#define UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN( pinNo_ )                        \
             if (umba::periph::traits::gpioExtiTestPendingIrq( (uint16_t)pinNo_ )) \
                {                                                               \
                    UMBA_EXTI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING( pinNo_ )  \
                    return;                                                     \
                }

#if 0

#define UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN( pinNo_ )                            \
            do{                                                                     \
            if (umba::periph::traits::gpioTestPendingEXTI( (uint16_t)pinNo_ ))       \
            {                                                                       \
                /*auto e = umba::periph::traits::extiHandlersVector[pinNo_];*/          \
                /*if ( umba::periph::traits::isValidPinPort( e.pinAddr.port ) && e.extiHandlerProc )*/\
                if ( umba::periph::traits::isValidPinPort( umba::periph::traits::extiHandlersVector[pinNo_].pinAddr.port ) && umba::periph::traits::extiHandlersVector[pinNo_].extiHandlerProc )\
                {                                                                   \
                    umba::periph::traits::GpioPinAddr tmp = { umba::periph::traits::extiHandlersVector[pinNo_].pinAddr.port, umba::periph::traits::extiHandlersVector[pinNo_].pinAddr.pinNo }; \
                    /*e.extiHandlerProc( e.pParam, tmp );*/ \
                    umba::periph::traits::extiHandlersVector[pinNo_].extiHandlerProc( umba::periph::traits::extiHandlersVector[pinNo_].pParam, tmp ); \
                }                                                                   \
                umba::periph::traits::gpioClearPendingEXTI((uint16_t)pinNo_);       \
                return;                                                             \
            }                                                                       \
            }                                                                       \
            while(0)
#endif


//#define UMBA_PERIPH_EXTI_IRQ_HANDLER(h)   UMBA_WEAK_IRQ_HANDLER(h)
#define UMBA_PERIPH_EXTI_IRQ_HANDLER(h)   UMBA_IRQ_HANDLER(h)



#include "umba/optimize_speed.h"

UMBA_PERIPH_EXTI_IRQ_HANDLER( EXTI0_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING(0);
}

UMBA_PERIPH_EXTI_IRQ_HANDLER( EXTI1_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING(1);
}

UMBA_PERIPH_EXTI_IRQ_HANDLER( EXTI2_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING(2);
}

UMBA_PERIPH_EXTI_IRQ_HANDLER( EXTI3_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING(3);
}

UMBA_PERIPH_EXTI_IRQ_HANDLER( EXTI4_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING(4);
}

UMBA_PERIPH_EXTI_IRQ_HANDLER( EXTI9_5_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(5);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(6);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(7);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(8);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(9);
}

UMBA_PERIPH_EXTI_IRQ_HANDLER( EXTI15_10_IRQHandler )
{
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(10);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(11);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(12);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(13);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(14);
    UMBA_EXTI_IRQ_HANDLER_CHECK_PIN_RETURN(15);
}

#include "umba/optimize_pop.h"
