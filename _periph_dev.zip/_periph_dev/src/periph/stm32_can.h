#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif


namespace umba
{
namespace periph
{
namespace traits
{

#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<CAN_TypeDef>( CAN_TypeDef * pt )
    {
        return ClockBus::APB1;
    }
#endif


#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)


    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<CAN_TypeDef>( CAN_TypeDef * pt )
    {
        return RCC_APB1PeriphClockCmd;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<CAN_TypeDef>( CAN_TypeDef * pt )
    {
        #ifdef CAN1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( CAN1, RCC_APB1Periph_CAN1 );
        #endif
        #ifdef CAN2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( CAN2, RCC_APB1Periph_CAN2 );
        #endif
        #ifdef CAN3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( CAN3, RCC_APB1Periph_CAN3 );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#endif





} // namespace traits
} // namespace periph
} // namespace umba


