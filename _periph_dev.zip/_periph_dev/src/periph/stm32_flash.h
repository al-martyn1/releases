#pragma once

// https://habr.com/ru/post/213771/

//FLASH->ACR

#if 0
typedef struct
{
  __IO uint32_t ACR;          /*!< FLASH access control register,              Address offset: 0x00 */
  __IO uint32_t KEYR;         /*!< FLASH key register,                         Address offset: 0x04 */
  __IO uint32_t OPTKEYR;      /*!< FLASH option key register,                  Address offset: 0x08 */
  __IO uint32_t SR;           /*!< FLASH status register,                      Address offset: 0x0C */
  __IO uint32_t CR;           /*!< FLASH control register,                     Address offset: 0x10 */
  __IO uint32_t AR;           /*!< FLASH address register,                     Address offset: 0x14 */
  uint32_t      RESERVED;     /*!< Reserved, 0x18                                                   */
  __IO uint32_t OBR;          /*!< FLASH Option byte register,                 Address offset: 0x1C */
  __IO uint32_t WRPR;         /*!< FLASH Write register,                       Address offset: 0x20 */
  
} FLASH_TypeDef;

#endif





namespace umba  {
namespace periph{
namespace traits{

template< typename TCrc, typename TData >
struct ConfigDummy
{
    TCrc       dataCrc;
    TData      data;
    uint32_t   padding;
};



// Hm-m-m 0x08000000-0x07FE0800=129024
template< typename TDataToSave, size_t PageSize >
size_t calculateNumPagesForData()
{
    constexpr size_t dataSize = sizeof(TDataToSave);
    return (((dataSize / PageSize) * PageSize) < dataSize) ? dataSize / PageSize + 1 : dataSize / PageSize;
}

template< typename TDataToSave, size_t FlashSize, size_t PageSize, uintptr_t FlashAddr >
uintptr_t calculateFlashAddrresForData()
{
    UMBA_ASSERT( FlashSize>=PageSize );
    //uintptr_t res = FlashAddr;
    //res += (uintptr_t)FlashSize;
    //res -= calculateNumPagesForData<TDataToSave,PageSize>()*PageSize;
    //return res;
    return (FlashAddr + (uintptr_t)FlashSize) - calculateNumPagesForData<TDataToSave,PageSize>()*PageSize;
}


/*
typedef enum
{ 
  FLASH_BUSY = 1,
  FLASH_ERROR_PG,
  FLASH_ERROR_WRP,
  FLASH_COMPLETE,
  FLASH_TIMEOUT
}FLASH_Status;

// void FLASH_Unlock(void)
// void FLASH_Lock(void)
// FLASH_Status FLASH_ErasePage(uint32_t Page_Address)
// FLASH_Status FLASH_ProgramWord(uint32_t Address, uint32_t Data)


*/

//uint32_t constructUiny32FromBytes( )

struct FlashUnlocker
{
    FlashUnlocker()
    {
        FLASH_Unlock();
    }

    ~FlashUnlocker()
    {
        FLASH_Lock();
    }

};


template<typename TDataDummy >
bool flashWriteConfigImpl( const TDataDummy &d, uintptr_t flashAddr )
{
    constexpr size_t numBytesToWrite   = sizeof(TDataDummy);
    constexpr size_t numWords32ToWrite = numBytesToWrite/4;

    const uint32_t * pSrcData = (const uint32_t*)&d;
    for( size_t i=0; i!=numWords32ToWrite; ++i, ++pSrcData)
    {
        uint32_t dstAddr = (uint32_t)(flashAddr + i*4);
        if (FLASH_ProgramWord( dstAddr, *pSrcData )!=FLASH_COMPLETE)
            return false;

        if ( *((const uint32_t*)dstAddr) != *pSrcData)
            return false;

    }

    return true;
}

template<typename TDataDummy >
bool flashReadConfigImpl( TDataDummy &d, uintptr_t flashAddr )
{
    constexpr size_t numBytesToRead   = sizeof(TDataDummy);
    constexpr size_t numWords32ToRead = numBytesToRead/4;

    uint32_t * pDstData = (uint32_t*)&d;
    for( size_t i=0; i!=numWords32ToRead; ++i, ++pDstData)
    {
        uint32_t srcAddr = (uint32_t)(flashAddr + i*4);
        *pDstData = *((const uint32_t*)srcAddr);
    }

    return true;
}

// http://www.keil.com/support/man/docs/armcc/armcc_chr1359124966304.htm
// http://www.keil.com/support/man/docs/armcc/armcc_chr1359124981436.htm
//__attribute__((aligned (4))) 

template< typename TData, typename TCrcCalculator, size_t FlashSize, size_t PageSize, uintptr_t FlashAddr >
bool flashWriteConfig( const TData &td )
{
    auto crcVal = TCrcCalculator()( (const uint8_t *)&td, sizeof(td) );

    typedef ConfigDummy< decltype(crcVal), TData > TDummy;

    UMBA_ALIGNED(4)
    TDummy configDummy{ crcVal, td, 0u };

    const /* expr */  size_t    numPages  = calculateNumPagesForData<TDummy,PageSize>();
    const /* expr */  uintptr_t flashAddr = calculateFlashAddrresForData<TDummy,FlashSize,PageSize,FlashAddr>();

    FlashUnlocker flashUnlocker;
    
    UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
    for(size_t i=0; i!=numPages; ++i)
    {
        if (FLASH_ErasePage( flashAddr + i*PageSize )!=FLASH_COMPLETE)
            return false;
    }

    return flashWriteConfigImpl( configDummy, flashAddr );
}

template< typename TData, typename TCrcCalculator, size_t FlashSize, size_t PageSize, uintptr_t FlashAddr >
bool flashInvalidateConfig( )
{
    // Пишем дефолтный конфиг и делаем ему заведомо неверную контрольную сумму путем инверсии корректного значения

    TData td;
    auto crcVal = TCrcCalculator()( (const uint8_t *)&td, sizeof(td) );

    typedef ConfigDummy< decltype(crcVal), TData > TDummy;

    UMBA_ALIGNED(4)
    TDummy configDummy{ ~crcVal, td, 0u };

    const /* expr */  size_t    numPages  = calculateNumPagesForData<TDummy,PageSize>();
    const /* expr */  uintptr_t flashAddr = calculateFlashAddrresForData<TDummy,FlashSize,PageSize,FlashAddr>();

    FlashUnlocker flashUnlocker;
    
    UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
    for(size_t i=0; i!=numPages; ++i)
    {
        if (FLASH_ErasePage( flashAddr + i*PageSize )!=FLASH_COMPLETE)
            return false;
    }

    return flashWriteConfigImpl( configDummy, flashAddr );
}

template< typename TData, typename TCrcCalculator, size_t FlashSize, size_t PageSize, uintptr_t FlashAddr >
bool flashReadConfig( TData &td )
{
    auto crcVal = TCrcCalculator()( (const uint8_t *)&td, sizeof(td) );

    typedef ConfigDummy< decltype(crcVal), TData > TDummy;

    UMBA_ALIGNED(4)
    TDummy configDummy{ ~crcVal, td, 0u };

    const /* expr */  size_t    numPages  = calculateNumPagesForData<TDummy,PageSize>();
    const /* expr */  uintptr_t flashAddr = calculateFlashAddrresForData<TDummy,FlashSize,PageSize,FlashAddr>();

    if (!flashReadConfigImpl( configDummy, flashAddr ))
        return false;

    crcVal = TCrcCalculator()( (const uint8_t *)&configDummy.data, sizeof(td) );
    if (crcVal==configDummy.dataCrc)
    {
        td = configDummy.data;
        return true;
    }

    return false;
}







} // namespace traits
} // namespace periph
} // namespace umba

