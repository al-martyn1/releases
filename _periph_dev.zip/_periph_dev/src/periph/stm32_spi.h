#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif


#include "umba/hr_counter.h"

//
// SPIx_IRQHandler  - SPI4_IRQHandler max

// umba::periph::traits

namespace umba
{
namespace periph
{
namespace traits
{

#if defined(SPI6)
    #define UMBA_PERIPH_SPI_NUM  6
#elif defined(SPI5)
    #define UMBA_PERIPH_SPI_NUM  5
#elif defined(SPI4)
    #define UMBA_PERIPH_SPI_NUM  4
#elif defined(SPI3)
    #define UMBA_PERIPH_SPI_NUM  3
#elif defined(SPI2)
    #define UMBA_PERIPH_SPI_NUM  2
#elif defined(SPI1)
    #define UMBA_PERIPH_SPI_NUM  1
#else
    #define UMBA_PERIPH_SPI_NUM  0
#endif


enum SpiDataBits
{
    #if defined(STM32F3_SERIES)
    spiDataBits4  =  4,
    spiDataBits5  =  5,
    spiDataBits6  =  6,
    spiDataBits7  =  7,
    #endif

    spiDataBits8  =  8,

    #if defined(STM32F3_SERIES)
    spiDataBits9  =  9,
    spiDataBits10 = 10,
    spiDataBits11 = 11,
    spiDataBits13 = 13,
    spiDataBits14 = 14,
    spiDataBits15 = 15,
    #endif       
                 
    spiDataBits16 = 16
};

enum SpiPrescaler
{
    spiPrescaler2   = 0, // fastest SPI Freq
    spiPrescalerFastFreq = spiPrescaler2,

    spiPrescaler4   = 1,
    spiPrescaler8   = 2,
    spiPrescaler16  = 3,

    spiPrescaler32  = 4,
    spiPrescalerMidFreq = spiPrescaler32,

    spiPrescaler64  = 5,
    spiPrescaler128 = 6,

    spiPrescaler256 = 7,  // slowest SPI Freq
    spiPrescalerLowFreq = spiPrescaler256
};

enum SpiWaitNotBusy
{
     spiNoWaitNotBusy      = 0,
     spiDoWaitNotBusy      = 1, // wait for !bsy and make pause for toggle CS after CLK ends
     spiDoWaitNotBusyOnly  = 2  // wait for !bsy only, no pause
};

enum SpiModeMasterSlave
{
    spiModeSlave,
    spiModeMaster
};


#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    const uint16_t SpiEventMaskRxReady                = 1<<0; // Receive buffer not empty flag
    const uint16_t SpiEventMaskTxReady                = 1<<1; // Transmit TXFIFO ready to be loaded
    const uint16_t SpiEventMaskErrorCrc               = 1<<4;
    const uint16_t SpiEventMaskErrorMasterModeFault   = 1<<5;
    const uint16_t SpiEventMaskErrorOverrun           = 1<<6;
#endif

enum SpiEventType // actually these are flags
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    // bitwise compatible with SPI status register
    spiEventRxReady                = SpiEventMaskRxReady,
    spiEventTxReady                = SpiEventMaskTxReady,
    spiEventErrorCrc               = SpiEventMaskErrorCrc,
    spiEventErrorMasterModeFault   = SpiEventMaskErrorMasterModeFault,
    spiEventErrorOverrun           = SpiEventMaskErrorOverrun
    #endif
};

inline SpiEventType spiMakeEventMask( SpiEventType e1 )                                                                     { return e1; }
inline SpiEventType spiMakeEventMask( SpiEventType e1, SpiEventType e2 )                                                    { return (SpiEventType)( ((uint16_t)e1) | ((uint16_t)e2) ); }
inline SpiEventType spiMakeEventMask( SpiEventType e1, SpiEventType e2, SpiEventType e3 )                                   { return (SpiEventType)( ((uint16_t)e1) | ((uint16_t)e2) | ((uint16_t)e3) ); }
inline SpiEventType spiMakeEventMask( SpiEventType e1, SpiEventType e2, SpiEventType e3, SpiEventType e4 )                  { return (SpiEventType)( ((uint16_t)e1) | ((uint16_t)e2) | ((uint16_t)e3) | ((uint16_t)e4) ); }
inline SpiEventType spiMakeEventMask( SpiEventType e1, SpiEventType e2, SpiEventType e3, SpiEventType e4, SpiEventType e5 ) { return (SpiEventType)( ((uint16_t)e1) | ((uint16_t)e2) | ((uint16_t)e3) | ((uint16_t)e4) | ((uint16_t)e5) ); }


#include "umba/optimize_speed.h"
UMBA_FORCE_INLINE( bool spiTestEventFlags(SpiEventType flags, SpiEventType testFor) )
{
    if ( ((uint16_t)flags) & ((uint16_t)testFor))
        return true;
    return false;
}

#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
UMBA_FORCE_INLINE( SpiEventType spiGetEventFlags(SPI_TypeDef* SPIx) )
{
    return (SpiEventType)(SPIx->SR & ((uint16_t)spiEventRxReady | (uint16_t)spiEventTxReady | (uint16_t)spiEventErrorCrc | spiEventErrorMasterModeFault | (uint16_t)spiEventErrorOverrun));
}
#endif
#include "umba/optimize_pop.h"

/*
enum SpiError // actually these are flags
{
     spiErrorMasterFault = 1,
     spiErrorOverrun     = 2,
     spiErrorFrameFormat = 4, // TI frame format error
     spiErrorCrc         = 8
};
*/


inline
uint16_t spiGetNo( SPI_TypeDef *pt )
{
    #if defined(SPI1)
        if (pt==SPI1) return 1;
    #endif
    #if defined(SPI2)
        if (pt==SPI2) return 2;
    #endif
    #if defined(SPI3)
        if (pt==SPI3) return 3;
    #endif
    #if defined(SPI4)
        if (pt==SPI4) return 4;
    #endif
    #if defined(SPI5)
        if (pt==SPI5) return 5;
    #endif
    #if defined(SPI6)
        if (pt==SPI6) return 6;
    #endif

    UMBA_ASSERT_FAIL();

    return 0;
}

inline
uint16_t periphGetNo( SPI_TypeDef * pt )
{
    return spiGetNo(pt);
}

inline
SPI_TypeDef* spiGetSpi( uint16_t spiNo )
{
    switch(spiNo)
    {
        case 1:
             #if defined(SPI1)
             return SPI1;
             #else
             break;
             #endif
        case 2:
             #if defined(SPI2)
             return SPI2;
             #else
             break;
             #endif
        case 3:
             #if defined(SPI3)
             return SPI3;
             #else
             break;
             #endif
        case 4:
             #if defined(SPI4)
             return SPI4;
             #else
             break;
             #endif
        case 5:
             #if defined(SPI5)
             return SPI5;
             #else
             break;
             #endif
        case 6:
             #if defined(SPI6)
             return SPI6;
             #else
             break;
             #endif
    }

    UMBA_ASSERT_FAIL();
    
    return 0;

}


inline 
IRQn spiGetIRQn( SPI_TypeDef *pt )
{
    uint16_t spiNo = spiGetNo( pt );
    switch(spiNo)
    {
        #if defined(SPI1)
            case 1: return SPI1_IRQn;
        #endif
        #if defined(SPI2) && !defined(STM32F334x8 )
            case 2: return SPI2_IRQn;
        #endif
        #if defined(SPI3)
            case 3: return (IRQn)51; // SPI3_IRQn;
        #endif

        // Какая-то неконсистенция - для четверки (407VG) SPI4/5/6 определены, 
        // но почему-то номера прерываний не определены
        // Ставим их ручками, для всех четверок номера одинаковы
        // Для сотки та же фигня и с SPI3
        //#if defined(STM32F3_SERIES)
            #if defined(SPI4)
                case 4: return (IRQn)84; // SPI4_IRQn;
            #endif
            #if defined(SPI5)
                case 5: return (IRQn)85; // SPI5_IRQn;
            #endif
            #if defined(SPI6)
                case 6: return (IRQn)86; // SPI6_IRQn;
            #endif
        //#endif

        default:
                UMBA_ASSERT_FAIL();
    }

    return (IRQn)0;
}

inline
IRQn periphGetIRQn( SPI_TypeDef *pt )
{
    return spiGetIRQn(pt);
}



#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    //!!! Check for F1/F4 families
    template <>
    inline
    ClockBus periphClockGetBus<SPI_TypeDef>( SPI_TypeDef * pt )
    {
        #ifdef SPI1
            if (pt==SPI1) return ClockBus::APB2; 
        #endif                                 
        #ifdef SPI2                            
            if (pt==SPI2) return ClockBus::APB1; 
        #endif                                 
        #ifdef SPI3                            
            if (pt==SPI3) return ClockBus::APB1; 
        #endif                                 

        #ifdef SPI4                            
            if (pt==SPI4) return ClockBus::APB2; 
        #endif                                 
        #ifdef SPI5                            
            if (pt==SPI5) return ClockBus::APB2; 
        #endif                                 
        #ifdef SPI6                            
            if (pt==SPI6) return ClockBus::APB2; 
        #endif

        UMBA_ASSERT_FAIL();

        return ClockBus::SYSCLK;
    }
#endif

#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<SPI_TypeDef>( SPI_TypeDef * pt )
    {
        #ifdef SPI1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI1, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef SPI2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI2, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef SPI3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI3, RCC_APB1PeriphClockCmd );
        #endif
        #ifdef SPI4
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI4, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef SPI5
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI5, RCC_APB2PeriphClockCmd );
        #endif
        #ifdef SPI6
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFUNCTION( SPI6, RCC_APB2PeriphClockCmd );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<SPI_TypeDef>( SPI_TypeDef * pt )
    {
        #ifdef SPI1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( SPI1, RCC_APB2Periph_SPI1 );
        #endif
        #ifdef SPI2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( SPI2, RCC_APB1Periph_SPI2 );
        #endif
        #ifdef SPI3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( SPI3, RCC_APB1Periph_SPI3 );
        #endif
        #ifdef SPI4
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( SPI4, RCC_APB2Periph_SPI4 );
        #endif
        #ifdef SPI5
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( SPI5, RCC_APB2Periph_SPI5 );
        #endif
        #ifdef SPI6
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( SPI6, RCC_APB2Periph_SPI6 );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }


#endif



#if defined(STM32F1_SERIES)

//#define GPIO_Remap_SPI1             ((uint32_t)0x00000001)  /*!< SPI1 Alternate Function mapping */
//#define GPIO_Remap_SPI3             ((uint32_t)0x00201100)  /*!< SPI3/I2S3 Alternate Function mapping (only for Connectivity line devices) */
    template < >
    inline
    uint32_t periphAltFunctionGetFlags< SPI_TypeDef, PinFunctionSpi >( SPI_TypeDef *pt, PinFunctionSpi pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #ifdef SPI1
            if (pt==SPI1)
            {
                if (pinFn==PinFunctionSpi::nss)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  4, 0 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA, 15, GPIO_Remap_SPI1 );
                }
                else if (pinFn==PinFunctionSpi::sck)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  5, 0 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  3, GPIO_Remap_SPI1 );
                }
                else if (pinFn==PinFunctionSpi::miso)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  6, 0 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  4, GPIO_Remap_SPI1 );
                }
                else if (pinFn==PinFunctionSpi::mosi)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  7, 0 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  5, GPIO_Remap_SPI1 );
                }
            }
        #endif

        #ifdef SPI2
            if (pt==SPI2)
            {
                if (pinFn==PinFunctionSpi::nss)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 12, 0 );
                }
                else if (pinFn==PinFunctionSpi::sck)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 13, 0 );
                }
                else if (pinFn==PinFunctionSpi::miso)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 14, 0 );
                }
                else if (pinFn==PinFunctionSpi::mosi)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 15, 0 );
                }
            }
        #endif

        #ifdef SPI3
            if (pt==SPI3)
            {
                if (pinFn==PinFunctionSpi::nss)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA, 15, 0 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  4, GPIO_Remap_SPI3 );
                }
                else if (pinFn==PinFunctionSpi::sck)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  3, 0 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOC, 10, GPIO_Remap_SPI3 );
                }
                else if (pinFn==PinFunctionSpi::miso)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  4, 0 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOC, 11, GPIO_Remap_SPI3 );
                }
                else if (pinFn==PinFunctionSpi::mosi)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  5, 0 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOC, 12, GPIO_Remap_SPI3 );
                }
            }
        #endif

        UMBA_ASSERT_FAIL();

        return 0;

    }

#elif defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template < >
    inline
    uint32_t periphAltFunctionGetFlags< SPI_TypeDef, PinFunctionSpi >( SPI_TypeDef *pt, PinFunctionSpi pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #ifdef SPI1
            if (pt==SPI1)
            {
                if (pinFn==PinFunctionSpi::nss)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  4, GPIO_AF_5 ); // F4 also
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA, 15, GPIO_AF_5 ); // F4 also
                }
                else if (pinFn==PinFunctionSpi::sck)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  5, GPIO_AF_5 ); // F4 also
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  3, GPIO_AF_5 ); // F4 also
                }
                else if (pinFn==PinFunctionSpi::miso)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  6, GPIO_AF_5 ); // F4 also
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  4, GPIO_AF_5 ); // F4 also
                }
                else if (pinFn==PinFunctionSpi::mosi)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  7, GPIO_AF_5 ); // F4 also
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  5, GPIO_AF_5 ); // F4 also
                }
            }
        #endif

        #ifdef SPI2
            if (pt==SPI2)
            {
                if (pinFn==PinFunctionSpi::nss)
                {
                    #if defined(STM32F4_SERIES)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  9, GPIO_AF_5 );
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOI,  0, GPIO_AF_5 );
                    #endif
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 12, GPIO_AF_5 ); // F4 also
                    #if defined(STM32F3_SERIES)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOD, 15, GPIO_AF_6 );
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOF,  0, GPIO_AF_5 );
                    #endif
                }
                else if (pinFn==PinFunctionSpi::sck)
                {
                    #if defined(STM32F4_SERIES)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 10, GPIO_AF_5 );
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOI,  1, GPIO_AF_5 );
                    #endif
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 13, GPIO_AF_5 ); // F4 also
                    #if defined(STM32F3_SERIES)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOF,  1, GPIO_AF_5 );
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOF,  9, GPIO_AF_5 );
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOF, 10, GPIO_AF_5 );
                    #endif
                }
                else if (pinFn==PinFunctionSpi::miso)
                {
                    #if defined(STM32F4_SERIES)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOC,  2, GPIO_AF_5 );
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOI,  2, GPIO_AF_5 );
                    #endif
                    #if defined(STM32F3_SERIES)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA, 10, GPIO_AF_5 );
                    #endif
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 14, GPIO_AF_5 ); // F4 also
                }
                else if (pinFn==PinFunctionSpi::mosi)
                {
                    #if defined(STM32F4_SERIES)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOC,  3, GPIO_AF_5 );
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOI,  3, GPIO_AF_5 );
                    #endif
                    #if defined(STM32F3_SERIES)
                        UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA, 11, GPIO_AF_5 );
                    #endif
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB, 15, GPIO_AF_5 ); // F4 also
                }
            }
        #endif

        #ifdef SPI3
            if (pt==SPI3)
            {
                if (pinFn==PinFunctionSpi::nss)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA,  4, GPIO_AF_6 ); // F4 also
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOA, 15, GPIO_AF_6 ); // F4 also
                }
                else if (pinFn==PinFunctionSpi::sck)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  3, GPIO_AF_6 ); // F4 also
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOC, 10, GPIO_AF_6 ); // F4 also
                }
                else if (pinFn==PinFunctionSpi::miso)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  4, GPIO_AF_6 ); // F4 also
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOC, 11, GPIO_AF_6 ); // F4 also
                }
                else if (pinFn==PinFunctionSpi::mosi)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOB,  5, GPIO_AF_6 ); // F4 also
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOC, 12, GPIO_AF_6 ); // F4 also
                }
            }
        #endif

        #ifdef SPI4
            if (pt==SPI4)
            {
                if (pinFn==PinFunctionSpi::nss)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE,  3, GPIO_AF_5 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE,  4, GPIO_AF_5 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE, 11, GPIO_AF_5 );
                }
                else if (pinFn==PinFunctionSpi::sck)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE,  2, GPIO_AF_5 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE, 12, GPIO_AF_5 );
                }
                else if (pinFn==PinFunctionSpi::miso)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE,  5, GPIO_AF_5 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE, 13, GPIO_AF_5 );
                }
                else if (pinFn==PinFunctionSpi::mosi)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE,  6, GPIO_AF_5 );
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN( GPIOE, 14, GPIO_AF_5 );
                }
            }
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }




#endif



//-----------------------------------------------------------------------------
enum SpiOnOff
{
    spiOff = 0,
    spiOn  = 1
};

//-----------------------------------------------------------------------------
template<>
inline
void periphEnable< SPI_TypeDef, SpiOnOff >( SPI_TypeDef *SPIx, SpiOnOff onOff )
{
    if (onOff!=spiOff)
        SPIx->CR1 |= 1<<6;
    else
        SPIx->CR1 &= ~(1<<6);
}

template< >
inline
bool periphIsEnabled< SPI_TypeDef >( SPI_TypeDef * SPIx )
{
    return SPIx->CR1 & (1<<6) ? true : false;
}

template< >
inline
void periphWaitDisabled< SPI_TypeDef >( SPI_TypeDef * SPIx )
{
    while(SPIx->CR1 & (1<<6));
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template< >
inline
void periphDmaEnable< SPI_TypeDef >( SPI_TypeDef * SPIx, DmaDirection dmaDir, DmaOnOff onOff )
{
    const uint16_t dirBit = 1 << ( dmaDir==dmaRx ? 0 : 1 );
    if (onOff!=dmaOff)
        SPIx->CR2 |= dirBit;
    else
        SPIx->CR2 &= ~dirBit;
}

template< >
inline
bool periphDmaIsEnabled< SPI_TypeDef >( SPI_TypeDef * SPIx, DmaDirection dmaDir )
{
    const uint16_t dirBit = 1 << ( dmaDir==dmaRx ? 0 : 1 );
    return SPIx->CR2 & dirBit ? true : false;
}

template< >
inline
void periphDmaWaitDisabled< SPI_TypeDef >( SPI_TypeDef * SPIx, DmaDirection dmaDir )
{
    const uint16_t dirBit = 1 << ( dmaDir==dmaRx ? 0 : 1 );
    while(SPIx->CR1 & dirBit);
}

#if 0

Последовательность примерно такая должна быть

USART_Cmd(USART1, ENABLE);
DMA_Cmd(DMA1_Channel4, ENABLE);
Включаем USART и прямой доступ к памяти DMA

USART_DMACmd(USART1, USART_DMAReq_Tx, ENABLE);
Активируем передачу в последовательный порт по запросу DMA

#endif



//-----------------------------------------------------------------------------
inline
void periphInit( SPI_TypeDef* SPIx
               , GPIO_TypeDef *sckPort , uint16_t sckPinNo
               , GPIO_TypeDef *misoPort, uint16_t misoPinNo
               , GPIO_TypeDef *mosiPort, uint16_t mosiPinNo
               , SpiDataBits dataSize
               , BitsDirection bitsDirection
               , SpiMode spiMode
               , SpiPrescaler baudRatePrescalerPwr
               , PinSpeed pinSpeed  = PinSpeed::high
               , SpiModeMasterSlave spiModeMasterSlave = spiModeMaster
               , SpiOnOff  spiOnOff = spiOn
               )
{
    UMBA_ASSERT(isValidPinPort(sckPort));
    UMBA_ASSERT(isValidPinPort(misoPort) || isValidPinPort(mosiPort));
    //UMBA_ASSERT( pinMode==PinMode::alt_mode_pp || pinMode==PinMode::alt_mode_od );

    initPeriphClock( SPIx, ENABLE );

    periphEnable(SPIx, spiOff);
    periphWaitDisabled(SPIx);

    SPI_I2S_DeInit(SPIx);

    SPI_InitTypeDef initStruct;

    SPI_StructInit( &initStruct );

    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

        UMBA_ASSERT( ((uint16_t)(baudRatePrescalerPwr)) < 8 );
       
        initStruct.SPI_Mode = spiModeMasterSlave==spiModeSlave ? SPI_Mode_Slave : SPI_Mode_Master;
        initStruct.SPI_NSS  = SPI_NSS_Soft;

        #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
            UMBA_ASSERT( (uint16_t)dataSize==8 || (uint16_t)dataSize==16 );
            initStruct.SPI_DataSize = (uint16_t)dataSize==16 ? SPI_DataSize_16b : SPI_DataSize_8b;
        #elif defined(STM32F3_SERIES)
            UMBA_ASSERT( (uint16_t)dataSize >=4 && (uint16_t)dataSize<=16 );
            uint16_t dataSizeU16    = (uint16_t)(dataSize-1);
            initStruct.SPI_DataSize = dataSizeU16 << 8;
        #endif

        initStruct.SPI_Direction = SPI_Direction_2Lines_FullDuplex;

        if (bitsDirection==BitsDirection::msb)
            initStruct.SPI_FirstBit = SPI_FirstBit_MSB;
        else
            initStruct.SPI_FirstBit = SPI_FirstBit_LSB;

        switch(spiMode)
           {
            case SpiMode::nCPOL_nCPHA: // CPOL = 0, CPHA = 0
                 initStruct.SPI_CPOL = SPI_CPOL_Low;
                 initStruct.SPI_CPHA = SPI_CPHA_1Edge;
                 break;

            case SpiMode::nCPOL_CPHA : // CPOL = 0, CPHA = 1
                 initStruct.SPI_CPOL = SPI_CPOL_Low;
                 initStruct.SPI_CPHA = SPI_CPHA_2Edge;
                 break;

            case SpiMode::CPOL_nCPHA : // CPOL = 1, CPHA = 0
                 initStruct.SPI_CPOL = SPI_CPOL_High;
                 initStruct.SPI_CPHA = SPI_CPHA_1Edge;
                 break;

            case SpiMode::CPOL_CPHA  : // CPOL = 1, CPHA = 1
                 initStruct.SPI_CPOL = SPI_CPOL_High;
                 initStruct.SPI_CPHA = SPI_CPHA_2Edge;
                 break;

            default:

                 UMBA_ASSERT_FAIL();
           }

        initStruct.SPI_CRCPolynomial = 7; // default value

        // baudRatePrescalerPwr: 0-7
        if (spiModeMasterSlave!=spiModeSlave)
            initStruct.SPI_BaudRatePrescaler = ((uint16_t)baudRatePrescalerPwr) << 3;
        else
            initStruct.SPI_BaudRatePrescaler = 0;

    #endif


    SPI_Init(SPIx, &initStruct);


    #if defined(STM32F3_SERIES)

        SPIx->CR2 &= (uint16_t)~((uint16_t)SPI_CR2_FRXTH); // 1/2 of RX FIFO for RXNE event
        if (dataSize<=8)
            SPIx->CR2 |= SPI_CR2_FRXTH;                    // 1/4 of RX FIFO for RXNE event

    #endif

    #if defined(STM32F1_SERIES)
    //PinMode inputPinMode = PinMode::gpio_in_floating;
    #elif defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    //PinMode inputPinMode = PinMode::alt_mode_pp;
    #endif

    PinMode inputPinMode = PinMode::alt_mode_input_floating;

    // Possible GPIO init must be here
    {
        initPeriphClock( sckPort, ENABLE, getPeriphClockGpioAltFunctionFlag(sckPort) );
        PinMode pinMode = (spiModeMasterSlave==spiModeSlave) ? inputPinMode : PinMode::alt_mode_pp;
        gpioInit( sckPort, pinSpeed, pinMode, 1 << sckPinNo );
    }

    if (isValidPinPort(mosiPort))
    {
        initPeriphClock( mosiPort, ENABLE, getPeriphClockGpioAltFunctionFlag(mosiPort) );
        PinMode pinMode = (spiModeMasterSlave==spiModeSlave) ? inputPinMode : PinMode::alt_mode_pp;
        gpioInit( mosiPort, pinSpeed, pinMode, 1 << mosiPinNo );
    }

    if (isValidPinPort(misoPort))
    {
        initPeriphClock( misoPort, ENABLE, getPeriphClockGpioAltFunctionFlag(misoPort) );
        PinMode pinMode = (spiModeMasterSlave==spiModeSlave) ? PinMode::alt_mode_pp : inputPinMode;
        gpioInit( misoPort, pinSpeed, pinMode, 1 << misoPinNo );
    }

    // End of GPIO init

    if (spiModeMasterSlave==spiModeSlave)
        periphAltFunctionConfigure( SPIx
                                  , makePinAltFunctionInfo( PinFunctionSpi::sck , sckPort , sckPinNo  )
                                  , makePinAltFunctionInfo( PinFunctionSpi::miso, misoPort, misoPinNo )
                                  , makePinAltFunctionInfo( PinFunctionSpi::mosi, mosiPort, mosiPinNo )
                                  );
    else
        periphAltFunctionConfigure( SPIx
                                  , makePinAltFunctionInfo( PinFunctionSpi::sck , sckPort , sckPinNo  )
                                  , makePinAltFunctionInfo( PinFunctionSpi::miso, misoPort, misoPinNo )
                                  , makePinAltFunctionInfo( PinFunctionSpi::mosi, mosiPort, mosiPinNo )
                                  );

    SPI_CalculateCRC(SPIx, DISABLE);

    //SPI_Cmd(SPIx, ENABLE);
    periphEnable(SPIx, spiOnOff);

}


//-----------------------------------------------------------------------------
inline
void periphInit( SPI_TypeDef* SPIx
               , const GpioPinAddr sckPinAddr
               , const GpioPinAddr misoPinAddr
               , const GpioPinAddr mosiPinAddr
               , SpiDataBits dataSize
               , BitsDirection bitsDirection
               , SpiMode spiMode
               , SpiPrescaler baudRatePrescalerPwr // uint16_t baudRatePrescalerPwr = 7 // power of two
               , PinSpeed pinSpeed = PinSpeed::high
               , SpiModeMasterSlave spiModeMasterSlave = spiModeMaster
               , SpiOnOff  spiOnOff = spiOn
               )
{
    periphInit( SPIx
              , sckPinAddr.port, sckPinAddr.pinNo
              , misoPinAddr.port, misoPinAddr.pinNo
              , mosiPinAddr.port, mosiPinAddr.pinNo
              , dataSize, bitsDirection
              , spiMode, baudRatePrescalerPwr
              , pinSpeed
              , spiModeMasterSlave
              , spiOnOff
              );
}

//-----------------------------------------------------------------------------
inline
unsigned spiGetFreq( SPI_TypeDef* SPIx )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    uint16_t prescalerPwr = (SPIx->CR1 >> 3) & 0x7;
    uint32_t spiBusFreq = periphClockGetFreq(SPIx);
    return spiBusFreq / (1<<(prescalerPwr+1));
    #endif
}

inline
SpiPrescaler spiCalcPrescaler( SPI_TypeDef* SPIx, int requestedFreq )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    unsigned spiBusFreq = periphClockGetFreq(SPIx);
    int      bestDelta = 0;
    int      bestFreq  = 0;
    unsigned bestPsc = 0;

    for(unsigned psc = 0; psc!=8; ++psc)
    {
        int pscFreq = (int)(spiBusFreq / (1<<(psc+1)));
        int dF = requestedFreq - pscFreq;
        if (dF<0)
            dF = -dF;

        if (!bestFreq || dF<bestDelta)
        {
            bestDelta = dF;
            bestFreq  = pscFreq;
            bestPsc   = psc;
        }
    }

    return (SpiPrescaler)bestPsc;
    #endif
}


inline
uint16_t spiGetDataSize( SPI_TypeDef* SPIx )
{
    #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
    //Bit 11 DFF: Data frame format
    //0: 8-bit data frame format is selected for transmission/reception
    //1: 16-bit data frame format is selected for transmission/reception
    return ((SPIx->CR1>>11) & 1) ? 16 : 8;
    #elif defined(STM32F3_SERIES)
    assert_param(IS_SPI_ALL_PERIPH_EXT(SPIx));
    uint16_t dataSize = SPIx->CR2 >> 8;
    dataSize = 0x0F;
    return dataSize+1;
    #else
    #endif
}

//-----------------------------------------------------------------------------

// return (uint16_t)((SPIx->SR & SPI_SR_FTLVL));

//-----------------------------------------------------------------------------
template< typename THandler >
inline
void spiWaitTransmitFifoEmpty( SPI_TypeDef* SPIx, const THandler &waitHandler )
{
    #if defined(STM32F1_SERIES)
    while(! (SPIx->SR & SPI_I2S_FLAG_TXE) ) { waitHandler(); }
    #elif defined(STM32F3_SERIES)
    while(! (SPIx->SR & SPI_SR_FTLVL) ) { waitHandler(); }
    #endif
}

inline
void spiWaitTransmitFifoEmpty( SPI_TypeDef* SPIx )
{
    #if defined(STM32F1_SERIES)
    while(! (SPIx->SR & SPI_I2S_FLAG_TXE) ) { }
    #elif defined(STM32F3_SERIES)
    while(! (SPIx->SR & SPI_SR_FTLVL) ) { }
    #endif
}


//-----------------------------------------------------------------------------
// spiWaitTransmitComplete -> spiWaitCanTransmit
template< typename THandler >
inline
void spiWaitCanTransmit( SPI_TypeDef* SPIx, const THandler &waitHandler )
{
    #ifndef SPI_NOWAIT
    while(! (SPIx->SR & SPI_I2S_FLAG_TXE) ) { waitHandler(); }
    #endif
}

inline
void spiWaitCanTransmit( SPI_TypeDef* SPIx )
{
    #ifndef SPI_NOWAIT
    while(! (SPIx->SR & SPI_I2S_FLAG_TXE) ) { }
    #endif
}


template< typename THandler >
inline
void spiWaitTransmitComplete( SPI_TypeDef* SPIx, const THandler &waitHandler )
{
    #ifndef SPI_NOWAIT
    while(! (SPIx->SR & SPI_I2S_FLAG_TXE) ) { waitHandler(); }
    #endif
}

inline
void spiWaitTransmitComplete( SPI_TypeDef* SPIx )
{
    #ifndef SPI_NOWAIT
    while(! (SPIx->SR & SPI_I2S_FLAG_TXE) ) { }
    #endif
}


//-----------------------------------------------------------------------------
template< typename THandler >
inline
void spiWaitReceiveComplete( SPI_TypeDef* SPIx, const THandler &waitHandler )
{
    #ifndef SPI_NOWAIT
    while(! (SPIx->SR & SPI_I2S_FLAG_RXNE) ) { waitHandler(); }
    #endif
}

inline
void spiWaitReceiveComplete( SPI_TypeDef* SPIx )
{
    #ifndef SPI_NOWAIT
    while(! (SPIx->SR & SPI_I2S_FLAG_RXNE) ) { }
    #endif
}


//-----------------------------------------------------------------------------
template< typename THandler >
inline
void spiWaitNotBusy( SPI_TypeDef* SPIx, const THandler &waitHandler )
{
    #ifndef SPI_NOWAIT
        // On the F1 series BSY flag is always 0
        #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
        while(! (SPIx->SR & SPI_I2S_FLAG_TXE) ) { waitHandler(); }
        #endif
        while( (SPIx->SR & SPI_I2S_FLAG_BSY) ) { waitHandler(); }
    #endif
}

inline
void spiWaitNotBusy( SPI_TypeDef* SPIx )
{
    #ifndef SPI_NOWAIT
        // On the F1 series BSY flag is always 0
        #if defined(STM32F1_SERIES) || defined(STM32F4_SERIES)
        while(! (SPIx->SR & SPI_I2S_FLAG_TXE) ) { }
        #endif
        while( (SPIx->SR & SPI_I2S_FLAG_BSY) ) { }
    #endif
}

//-----------------------------------------------------------------------------
void spiWaitChipSelect( unsigned delayCount  = 25 );
void spiChipSelectPause( unsigned delayCount = 25 );

//-----------------------------------------------------------------------------
inline
unsigned getChipSelectDelayK( unsigned pwrClk )
{
    #if defined(STM32F4_SERIES)
                        //  2  4  8 16  32  64  128  256
    static unsigned k[] = { 1, 1, 1, 1,  2, 6,  30,  60 };

    #else

    static unsigned k[] = { 1, 1, 1, 1,  2, 6,  32,  82 };

    #endif
    //#if defined(STM32F3_SERIES)
    return k[pwrClk&7];
    //#endif
    //return 0;
}

//-----------------------------------------------------------------------------
#include "umba/optimize_speed.h"
template< typename THandler >
inline
void spiWaitNotBusy( SPI_TypeDef* SPIx, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler )
{
    if (waitNotBusy==spiNoWaitNotBusy)
        return;
    spiWaitNotBusy( SPIx, waitHandler );

    if (waitNotBusy==spiDoWaitNotBusy)
    {
        unsigned pwrClk = (SPIx->CR1 >> 3)&0x07;
        if (pwrClk<(unsigned)spiPrescaler32)
            return;
        else if (pwrClk==(unsigned)spiPrescaler32)
            spiChipSelectPause( 5 );
        else
            spiChipSelectPause( clockGetFreq(ClockBus::CORECLK) / 10000000 * getChipSelectDelayK(pwrClk) / 10 );
        //unsigned clk = clockGetFreq(ClockBus::CORECLK);
        //spiChipSelectPause( clk/ spiGetFreq( SPIx ) / 4 );
        // Чем выше частота SPI, тем меньше нужно ждать,
        // нужно уменьшать счетчик
    }
}

inline
void spiWaitNotBusy( SPI_TypeDef* SPIx, SpiWaitNotBusy waitNotBusy )
{
    if (waitNotBusy==spiNoWaitNotBusy)
        return;
    spiWaitNotBusy( SPIx );

    if (waitNotBusy==spiDoWaitNotBusy)
    {
        unsigned pwrClk = (SPIx->CR1 >> 3)&0x07;
        if (pwrClk<(unsigned)spiPrescaler32)
            return;
        else if (pwrClk==(unsigned)spiPrescaler32)
            spiChipSelectPause( 5 );
        else
            spiChipSelectPause( clockGetFreq(ClockBus::CORECLK) / 10000000 * getChipSelectDelayK(pwrClk) / 10 );
    }
}
#include "umba/optimize_pop.h"

//-----------------------------------------------------------------------------
inline
uint16_t spiReadGetValue( SPI_TypeDef* SPIx, SpiDataBits dataSize )
{

    if (((uint16_t)(dataSize))>8)
    {
        return SPIx->DR; 
    }
    else
    {
        uint8_t* pByteDR = (uint8_t*)&SPIx->DR;
        return (uint16_t)*pByteDR;
    }

}

inline
uint16_t spiReadGetValue( SPI_TypeDef* SPIx )
{
    return spiReadGetValue( SPIx, (SpiDataBits)spiGetDataSize(SPIx) );
}

inline
void spiWriteSetValue( SPI_TypeDef* SPIx, SpiDataBits dataSize, uint16_t data )
{
    if ((uint16_t)(dataSize)>8)
    {
        SPIx->DR = data;
    }
    else
    {
        uint8_t* pByteDR = (uint8_t*)&SPIx->DR;
        *pByteDR = (uint8_t)data;
    }
}

//-----------------------------------------------------------------------------
inline
void spiWriteSetValue( SPI_TypeDef* SPIx, uint16_t data )
{
    return spiWriteSetValue( SPIx, (SpiDataBits)spiGetDataSize(SPIx), data );
}

//-----------------------------------------------------------------------------
/*
SPI status register (SPI_SR)

BSY
    Section 28.3.7: Status flags
    Section 28.3.8: Disabling the SPI

OVR: Overrun flag
    0: No overrun occurred
    1: Overrun occurred
   
  F1/F4

    Section 28.4.8: Error flags
   
    In this case, the receive buffer contents are not updated with the newly received data from
    the transmitter device. A read operation to the SPI_DR register returns the previous
    correctly received data. All other subsequently transmitted half-words are lost.
   
    Clearing the OVR bit is done by a read operation on the SPI_DR register followed by a read
    access to the SPI_SR register

MODF: Mode fault
    0: No mode fault occurred
    1: Mode fault occurred
   
    Section 28.4.8: Error flags

UDR: Underrun flag
    0: No underrun occurred
    1: Underrun occurred

  F1/F4

    Section 28.4.8: Error flags
  
    In slave transmission mode this flag is set when the first clock for data transmission appears
    while the software has not yet loaded any value into SPI_DR.
  
    The UDR bit is cleared by a read operation on the SPI_SR register.

*/

#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

UMBA_FORCE_INLINE( void spiClearOverrunFlag( SPI_TypeDef* SPIx ) )
{
    unsigned res = 0;
    res = (unsigned)spiReadGetValue( SPIx ); // Clear OVR flag first step
    //UMBA_INSTRUCTION_BARRIER();
    res |= ((unsigned)SPIx->SR)<<16; // Clear UDR flag and clear OVR flag second step
}

UMBA_FORCE_INLINE(void spiClearModeFaultFlag( SPI_TypeDef* SPIx ) )
{
    SPIx->SR = SPIx->SR & ~((uint16_t)spiEventErrorMasterModeFault);
}

UMBA_FORCE_INLINE( void spiClearCrcFlag( SPI_TypeDef* SPIx ) )
{
    SPIx->SR &= ~((uint16_t)spiEventErrorCrc);
}

UMBA_FORCE_INLINE( void spiClearEventFlags( SPI_TypeDef* SPIx, SpiEventType flags ) )
{
    SPIx->SR &= ~((uint16_t)flags);
    if (((uint16_t)flags) & ((uint16_t)spiEventErrorMasterModeFault) )
        spiClearModeFaultFlag( SPIx );
    if (((uint16_t)flags) & ((uint16_t)spiEventErrorOverrun) )
        spiClearOverrunFlag( SPIx );
}

#endif


inline
void spiStartPrepare( SPI_TypeDef* SPIx )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    //spiClearOverrunFlag(SPIx);
    #endif
    spiClearEventFlags(SPIx, spiMakeEventMask(spiEventRxReady, spiEventTxReady, spiEventErrorCrc, spiEventErrorMasterModeFault, spiEventErrorOverrun) );
}

inline
void spiWriteStart( SPI_TypeDef* SPIx, uint16_t data, GpioPin *pCsPin = 0, umba::hr_counter::NanosecInterval csAfterPause = 0)
{
    //using namespace umba::omanip;
    //lout<<"spiWriteStart 1"<<endl;
    uint16_t dataSize = spiGetDataSize(SPIx);

    // 16 bit - dataSize==0x10`
    if (dataSize!=0x10)
    {
        //lout<<"spiWriteStart 2"<<endl;
        UMBA_ASSERT( data < (1<<dataSize) );
    }

    //lout<<"spiWriteStart 3"<<endl;
    spiWaitCanTransmit(SPIx);

    //lout<<"spiWriteStart 4"<<endl;
    spiStartPrepare( SPIx );

    //lout<<"spiWriteStart 5"<<endl;

    if (pCsPin)
    {
        //lout<<"spiWriteStart 6"<<endl;
        pCsPin->toggle();
        //lout<<"spiWriteStart 7"<<endl;
        if (csAfterPause)
        {
            //lout<<"spiWriteStart 8"<<endl;
            umba::hr_counter::delayNanosec(csAfterPause);
            //lout<<"spiWriteStart 9"<<endl;
        }
    }

    //lout<<"spiWriteStart 10"<<endl;
    spiWriteSetValue( SPIx, (SpiDataBits)dataSize, data );
    //lout<<"spiWriteStart 11"<<endl;
}

//-----------------------------------------------------------------------------
#include "umba/optimize_speed.h"
template< typename THandler >
inline
void spiWrite( SPI_TypeDef* SPIx, uint16_t data, GpioPin &csPin, umba::hr_counter::NanosecInterval csAfterPause, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler )
{
    //csPin.toggle();
    spiWriteStart( SPIx, data, &csPin, csAfterPause );
    //spiWaitTransmitComplete( SPIx, waitHandler );
    spiWaitNotBusy( SPIx, waitNotBusy, waitHandler );
    csPin.toggle();
}

inline
void spiWrite( SPI_TypeDef* SPIx, uint16_t data, GpioPin &csPin, umba::hr_counter::NanosecInterval csAfterPause, SpiWaitNotBusy waitNotBusy )
{
    //csPin.toggle();
    spiWriteStart( SPIx, data, &csPin, csAfterPause );
    //spiWaitTransmitComplete( SPIx );
    spiWaitNotBusy( SPIx, waitNotBusy );
    csPin.toggle();
}


template< typename THandler >
inline
void spiWrite( SPI_TypeDef* SPIx, uint16_t data, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler )
{
    spiWriteStart( SPIx, data );
    //spiWaitTransmitComplete( SPIx, waitHandler );
    spiWaitNotBusy( SPIx, waitNotBusy, waitHandler );
}

inline
void spiWrite( SPI_TypeDef* SPIx, uint16_t data, SpiWaitNotBusy waitNotBusy )
{
    spiWriteStart( SPIx, data );
    //spiWaitTransmitComplete( SPIx );
    spiWaitNotBusy( SPIx, waitNotBusy );
}


inline
void spiReadStart( SPI_TypeDef* SPIx, uint16_t dummyData, GpioPin *pCsPin = 0, umba::hr_counter::NanosecInterval csAfterPause = 0 )
{
    spiWriteStart( SPIx, dummyData, pCsPin, csAfterPause );
}

template< typename THandler >
inline
uint16_t spiRead( SPI_TypeDef* SPIx, uint16_t dummyData, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler )
{
    spiReadStart( SPIx, dummyData );
    //spiWaitTransmitComplete( SPIx, waitHandler );
    spiWaitReceiveComplete( SPIx, waitHandler );
    spiWaitNotBusy( SPIx, waitNotBusy, waitHandler );
    return spiReadGetValue( SPIx );
}

inline
uint16_t spiRead( SPI_TypeDef* SPIx, uint16_t dummyData, SpiWaitNotBusy waitNotBusy )
{
    spiReadStart( SPIx, dummyData );
    //spiWaitTransmitComplete( SPIx );
    spiWaitReceiveComplete( SPIx );
    spiWaitNotBusy( SPIx, waitNotBusy );
    return spiReadGetValue( SPIx );
}


template< typename THandler >
inline
uint16_t spiRead( SPI_TypeDef* SPIx, uint16_t dummyData, GpioPin &csPin, umba::hr_counter::NanosecInterval csAfterPause, SpiWaitNotBusy waitNotBusy, const THandler &waitHandler )
{
    spiReadStart( SPIx, dummyData, &csPin, csAfterPause );
    //spiWaitTransmitComplete( SPIx, waitHandler );
    spiWaitReceiveComplete( SPIx, waitHandler );
    auto res =  spiReadGetValue( SPIx );
    spiWaitNotBusy( SPIx, waitNotBusy, waitHandler );
    csPin.toggle();
    return res;
}

inline
uint16_t spiRead( SPI_TypeDef* SPIx, uint16_t dummyData, GpioPin &csPin, umba::hr_counter::NanosecInterval csAfterPause, SpiWaitNotBusy waitNotBusy )
{
    spiReadStart( SPIx, dummyData, &csPin, csAfterPause );
    //spiWaitTransmitComplete( SPIx );
    spiWaitReceiveComplete( SPIx );
    auto res =  spiReadGetValue( SPIx );
    spiWaitNotBusy( SPIx, waitNotBusy );
    csPin.toggle();
    return res;
}

#include "umba/optimize_pop.h"



#include "umba/optimize_speed.h"
// simple small pause
inline // obsolete
void spiWaitChipSelect( unsigned delayCount /*  = 25 */  )
{
    for( unsigned i=0; i!=delayCount; ++i ) ; // {}
}
#include "umba/optimize_pop.h"


#include "umba/optimize_speed.h"
inline
void spiChipSelectPause( unsigned delayCount  /* = 25 */  )
{
    for( unsigned i=0; i!=delayCount; ++i ) ; // {}
}



#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
inline
uint16_t spiMakeIrqEventFlags( SpiEventType events )
{
    uint16_t ieFlags = 0;
    
    if (spiTestEventFlags(events, spiEventTxReady)) 
        ieFlags |= 1<<7; // TXEIE

    if (spiTestEventFlags(events, spiEventRxReady)) 
        ieFlags |= 1<<6; // RXEIE
        
    if (spiTestEventFlags(events, (SpiEventType)(((uint16_t)spiEventErrorCrc | (uint16_t)spiEventErrorMasterModeFault | (uint16_t)spiEventErrorOverrun))) ) 
        ieFlags |= 1<<5; // ERRIE

    return ieFlags;
}

UMBA_FORCE_INLINE( void periphClearIrqEventFlags( SPI_TypeDef* SPIx ) )
{
    SPIx->CR2 &= 7 << 5;
}

UMBA_FORCE_INLINE( void periphSetIrqEventFlags( SPI_TypeDef* SPIx, SpiEventType events ) )
{
    periphClearIrqEventFlags(SPIx);
    SPIx->CR2 |= spiMakeIrqEventFlags(events);
}

#endif

#include "umba/optimize_pop.h"


inline
void periphInitIrq( SPI_TypeDef* SPIx, SpiEventType events )
{
    periphSetIrqEventFlags( SPIx, events );
    /*
    Это нужно?
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = SPI1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    
    */
    periphEnableIRQ( periphGetIRQn(SPIx), true );
    
}

// Sometimes you need to clear flags also. Use periphClearIrqEventFlags for that
inline
void periphDisableIrq( SPI_TypeDef* SPIx )
{
    periphEnableIRQ( periphGetIRQn(SPIx), false );
}



//#define UMBA_PERIPH_DECLARE_SPI_IRQ_HANDLER_PROC( name )   void name( void *pParam, const umba::periph::traits::GpioPinAddr &pinAddr )
#define UMBA_PERIPH_DECLARE_SPI_IRQ_HANDLER_PROC( name )   void name( void *pParam, SPI_TypeDef* SPIx, SpiEventType eventType )


typedef void (*SpiIrqHandlerProcT)( void *pParam, SPI_TypeDef* SPIx, SpiEventType eventType );

bool periphInstallIrqHandler( SPI_TypeDef* SPIx, SpiIrqHandlerProcT proc, void *pParam = 0 );
bool periphUninstallIrqHandler( SPI_TypeDef* SPIx );



// periphInstallIrqHandler
// periphUninstallIrqHandler
// periphTestPendingIrq
// periphClearPendingIrq
// periphGenerateSoftwareIrq

// void spiClearFlags( SPI_TypeDef* SPIx, SpiEventType flags )
//bool spiTestEventFlags(SpiEventType flags, SpiEventType testFor)
//spiGetEventFlags

/*
enum SpiEventType // actually these are flags
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    // bitwise compatible with SPI ststue register
    spiEventRxReady                = 1<<0, // Receive buffer not empty flag
    spiEventTxReady                = 1<<1, // Transmit TXFIFO ready to be loaded
    spiEventErrorCrc               = 1<<4,
    spiEventErrorMasterModeFault   = 1<<5,
    spiEventErrorOverrun           = 1<<6,
    #endif

};

UMBA_FORCE_INLINE( bool spiTestEventFlags(SpiEventType flags, SpiEventType testFor) )
UMBA_FORCE_INLINE( SpiEventType spiGetEventFlags(SPI_TypeDef* SPIx) )


// periphInitIrq
// periphDisableIrq
// periphInstallIrqHandler
// periphUninstallIrqHandler
// periphTestPendingIrq
// periphClearPendingIrq
// periphGenerateSoftwareIrq




*/

// umba::periph::traits

} // namespace traits
} // namespace periph
} // namespace umba


