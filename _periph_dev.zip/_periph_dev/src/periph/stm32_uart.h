#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif


namespace umba
{
namespace periph
{
namespace traits
{

//https://stm32f4-discovery.net/2017/07/stm32-tutorial-efficiently-receive-uart-data-using-dma/


// F1   - 27.5 USART mode configuration
// F3   - 29.4 USART implementation
// F4   - 30.5 USART mode configuration
// F4x3 - 28.3 USART implementation
// F401 - 19.5 USART mode configuration

// STM32F303xB STM32F303xC STM32F358CC STM32F358RC STM32F358VC
// 8-9 bits
//  

#ifdef USART1
    #define UART1 USART1
#endif

#ifdef USART2
    #define UART2 USART2
#endif

#ifdef USART3
    #define UART3 USART3
#endif

#ifdef USART6
    #define UART6 USART6
#endif

#ifdef USART7
    #define UART7 USART7
#endif

#ifdef USART8
    #define UART8 USART8
#endif

#ifdef USART9
    #define UART9 USART9
#endif

#ifdef USART10
    #define UART10 USART10
#endif


/*
// F1 - UART5 no DMA support

inline
bool uartIsSyncCompat()
bool uartIsHwfcCompat()
bool uartIsHalfStopsCompat()
bool uartIsDmaCompat()
*/

typedef  USART_TypeDef  UART_TypeDef;


inline
uint16_t uartGetNo( UART_TypeDef *pt )
{
    #if defined(UART1)
        if (pt==UART1) return 1;
    #endif
    #if defined(UART2)
        if (pt==UART2) return 2;
    #endif
    #if defined(UART3)
        if (pt==UART3) return 3;
    #endif
    #if defined(UART4)
        if (pt==UART4) return 4;
    #endif
    #if defined(UART5)
        if (pt==UART5) return 5;
    #endif
    #if defined(UART6)
        if (pt==UART6) return 6;
    #endif
    #if defined(UART7)
        if (pt==UART7) return 7;
    #endif
    #if defined(UART8)
        if (pt==UART8) return 8;
    #endif
    #if defined(UART9)
        if (pt==UART9) return 9;
    #endif
    #if defined(UART10)
        if (pt==UART10) return 10;
    #endif

    UMBA_ASSERT_FAIL();

    return 0;
}

inline
uint16_t periphGetNo( UART_TypeDef * pt )
{
    return uartGetNo(pt);
}

inline
bool isUsart( uint16_t uartNo )
{
    if (uartNo==4 || uartNo==5)
        return false;
    return true;
}

inline
bool isUsart( UART_TypeDef * pt )
{
    return isUsart( uartGetNo(pt) );
}

inline
UART_TypeDef* uartGetUart( uint16_t spiNo )
{
    switch(spiNo)
    {
        case 1:
             #if defined(UART1)
             return UART1;
             #else
             break;
             #endif
        case 2:
             #if defined(UART2)
             return UART2;
             #else
             break;
             #endif
        case 3:
             #if defined(UART3)
             return UART3;
             #else
             break;
             #endif
        case 4:
             #if defined(UART4)
             return UART4;
             #else
             break;
             #endif
        case 5:
             #if defined(UART5)
             return UART5;
             #else
             break;
             #endif
        case 6:
             #if defined(UART6)
             return UART6;
             #else
             break;
             #endif
        case 7:
             #if defined(UART7)
             return UART7;
             #else
             break;
             #endif
        case 8:
             #if defined(UART8)
             return UART8;
             #else
             break;
             #endif
        case 9:
             #if defined(UART9)
             return UART9;
             #else
             break;
             #endif
        case 10:
             #if defined(UART10)
             return UART10;
             #else
             break;
             #endif
    }

    UMBA_ASSERT_FAIL();
    
    return 0;

}


#if defined(LUART_UART_HANDLE_H)
inline
uint16_t periphGetNo( const uart::Handle *pHandle )
{
    #ifdef UART_N1_ENABLE
    if (pHandle == &uart::uart1) return 1;
    #endif
    #ifdef UART_N2_ENABLE
    if (pHandle == &uart::uart2) return 2;
    #endif
    #ifdef UART_N3_ENABLE
    if (pHandle == &uart::uart3) return 3;
    #endif
    #ifdef UART_N4_ENABLE
    if (pHandle == &uart::uart4) return 4;
    #endif
    #ifdef UART_N5_ENABLE
    if (pHandle == &uart::uart5) return 5;
    #endif
//    #ifdef UART_N6_ENABLE
//    if (pHandle == &uart::uart6) return 6;
//    #endif

    UMBA_ASSERT_FAIL();

    return 0;
}

inline
uint16_t periphGetNo( const uart::Handle &handle )
{
    return periphGetNo( &handle );
}

#endif

/*
bool isInited() const
uart::Handle
namespace uart
{
#ifdef UART_N1_ENABLE
    Handle uart1;
#endif

#ifdef UART_N2_ENABLE
    Handle uart2;
#endif

#ifdef UART_N3_ENABLE
    Handle uart3;
#endif

#ifdef UART_N4_ENABLE
    Handle uart4;
#endif

#ifdef UART_N5_ENABLE
    Handle uart5;
#endif
}

*/
} // namespace traits
} // namespace periph
} // namespace umba
