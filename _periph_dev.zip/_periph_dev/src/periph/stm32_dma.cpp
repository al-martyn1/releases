/*

F1

DMA1_Channel1_IRQHandler
DMA1_Channel2_IRQHandler
DMA1_Channel3_IRQHandler
DMA1_Channel4_IRQHandler
DMA1_Channel5_IRQHandler
DMA1_Channel6_IRQHandler
DMA1_Channel7_IRQHandler

DMA2_Channel1_IRQHandler  
DMA2_Channel2_IRQHandler  
DMA2_Channel3_IRQHandler  
DMA2_Channel4_5_IRQHandler // на некоторых сотках обрабатывает оба - 4 и 5 прерывания (101XE/XG,103XE/XG, HD) 
DMA2_Channel5_IRQHandler  

//105XC,107XC, CL, 

                DCD     DMA2_Channel1_IRQHandler   ; DMA2 Channel1
                DCD     DMA2_Channel2_IRQHandler   ; DMA2 Channel2
                DCD     DMA2_Channel3_IRQHandler   ; DMA2 Channel3
                DCD     DMA2_Channel4_IRQHandler   ; DMA2 Channel4
                DCD     DMA2_Channel5_IRQHandler   ; DMA2 Channel5




                          | DMA2_Channel4_IRQHandler | DMA2_Channel4_5_IRQHandler | DMA2_Channel5_IRQHandler | DMA2
                          |                          |                            |                          |
startup_stm32f100xe.s     |            _             |             X              |            X             |  X
startup_stm32f101xe.s     |            _             |             X              |            _             |  X
startup_stm32f101xg.s     |            _             |             X              |            _             |  X
startup_stm32f103xg.s     |            _             |             X              |            _             |  X
startup_stm32f103xe.s     |            _             |             X              |            _             |  X
startup_stm32f105xc.s     |            X             |             _              |            X             |  X
startup_stm32f107xc.s     |            X             |             _              |            X             |  X
startup_stm32f10x_cl.s    |            X             |             _              |            X             |  X
startup_stm32f10x_hd.s    |            _             |             X              |            _             |  X
startup_stm32f10x_hd_vl.s |            _             |             X              |            X             |  X
startup_stm32f10x_xl.s    |            _             |             X              |            _             |  X

Без DMA2
startup_stm32f100xb.s    
startup_stm32f101x6.s    
startup_stm32f101xb.s    
startup_stm32f102x6.s    
startup_stm32f102xb.s    
startup_stm32f103x6.s    
startup_stm32f103xb.s    
startup_stm32f10x_ld.s   
startup_stm32f10x_ld_vl.s
startup_stm32f10x_md.s   
startup_stm32f10x_md_vl.s

Есть пять каналов DMA2, но 5 канал обрабатывается вместе с 4ым в DMA2_Channel4_5_IRQHandler
STM32F10X_HD
STM32F10X_XL
startup_stm32f101xe.s     XZ
startup_stm32f101xg.s     XZ
startup_stm32f103xg.s     XZ
startup_stm32f103xe.s     XZ
startup_stm32f10x_hd.s
startup_stm32f10x_xl.s

Есть пять каналов DMA2, есть раздельная обработка прерываний 4 и 5ого каналов, но осталось дебильное имя DMA2_Channel4_5_IRQHandler
STM32F10X_HD_VL
startup_stm32f100xe.s     XZ
startup_stm32f10x_hd_vl.s

Есть пять каналов DMA2, есть раздельная обработка прерываний 4 и 5ого каналов, есть нормальное имя для 4ого канала - DMA2_Channel4_IRQHandler
STM32F10X_CL
startup_stm32f105xc.s  XZ |            X             |             _              |            X             |  X
startup_stm32f107xc.s  XZ |            X             |             _              |            X             |  X
startup_stm32f10x_cl.s    |            X             |             _              |            X             |  X


startup_stm32f10x_hd.s
 STM32F101RC STM32F101RD STM32F101RE STM32F101VC STM32F101VD STM32F101VE STM32F101ZC STM32F101ZD STM32F101ZE STM32F103RC
 STM32F103RD STM32F103RE STM32F103VC STM32F103VD STM32F103VE STM32F103ZC STM32F103ZD STM32F103ZE

startup_stm32f10x_xl.s
 STM32F101RF STM32F101RG STM32F101VF STM32F101VG STM32F101ZF STM32F101ZG STM32F103RF STM32F103RG STM32F103VF STM32F103VG STM32F103ZF STM32F103ZG


startup_stm32f10x_hd_vl.s

 STM32F100RC STM32F100RD STM32F100RE STM32F100VC STM32F100VD STM32F100VE STM32F100ZC STM32F100ZD STM32F100ZE

startup_stm32f10x_cl.s

 STM32F105R8 STM32F105RB STM32F105RC STM32F105V8 STM32F105VB STM32F105VC STM32F107RB STM32F107RC STM32F107VB STM32F107VC

STM32F10X_HD
STM32F10X_XL
STM32F10X_HD_VL
STM32F10X_CL

#if defined(STM32F10X_HD) || defined(STM32F10X_XL)
    STM32_DMA2_CHANNEL_4_5_SHARE
    STM32_DMA2_CHANNEL_4_NAME_4_5
#elif defined(STM32F10X_HD_VL)
    STM32_DMA2_CHANNEL_4_NAME_4_5
#endif




F3

DMA1_Channel1_IRQHandler
DMA1_Channel2_IRQHandler
DMA1_Channel3_IRQHandler
DMA1_Channel4_IRQHandler
DMA1_Channel5_IRQHandler
DMA1_Channel6_IRQHandler
DMA1_Channel7_IRQHandler

DMA2_Channel1_IRQHandler  
DMA2_Channel2_IRQHandler  
DMA2_Channel3_IRQHandler  
DMA2_Channel4_IRQHandler
DMA2_Channel5_IRQHandler  


F4

DMA2_Stream0_IRQHandler
DMA2_Stream1_IRQHandler
DMA2_Stream2_IRQHandler 
DMA2_Stream3_IRQHandler 
DMA2_Stream4_IRQHandler                                                                  
DMA2_Stream5_IRQHandler
DMA2_Stream6_IRQHandler
DMA2_Stream7_IRQHandler

DMA2_Stream0_IRQHandler                                         
DMA2_Stream1_IRQHandler                                          
DMA2_Stream2_IRQHandler                                           
DMA2_Stream3_IRQHandler                                           
DMA2_Stream4_IRQHandler                                                                                                                                  
DMA2_Stream5_IRQHandler                                          
DMA2_Stream6_IRQHandler                                          
DMA2_Stream7_IRQHandler                                          

*/


#if 0
// size_t dmaGetChannelIndex( DmaController dma, DmaChannel ch )

#if defined(STM32F10X_HD) || defined(STM32F10X_XL)
    #define STM32F1_DMA2_CHANNEL_4_5_SHARE
    #define STM32F1_DMA2_CHANNEL_4_NAME_4_5
#elif defined(STM32F10X_HD_VL)
    #define STM32F1_DMA2_CHANNEL_4_5_SHARE_OPTIONAL
    // Shared or not defined by AFIO_MAPR2 reg bit AFIO_MAPR2_MISC_REMAP ((uint32_t)0x00002000)
    #define STM32F1_DMA2_CHANNEL_4_NAME_4_5
#endif


typedef void (*DmaIrqHandlerProcT)( void *pParam, uint16_t eventType );

// use UMBA_ASSERT( dmaIsValidChannel( DMAx, ch ) );
bool periphInstallIrqHandler( DMA_TypeDef *DMAx, DmaChannel ch, DmaIrqHandlerProcT proc, void *pParam = 0 );
bool periphUninstallIrqHandler( DMA_TypeDef *DMAx, DmaChannel ch );

#endif


#include "umba/umba.h"
#include "stm32.h"
#include "stm32_traits.h"


namespace umba
{
namespace periph
{
namespace traits
{

struct DmaIrqHandlerVectorEntry
{
    DmaIrqHandlerProcT proc;
    void*              param;
};


static
UMBA_PERIPH_DECLARE_DMA_IRQ_HANDLER_PROC( dmaStubHandler )
{}

//volatile
static
#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
DmaIrqHandlerVectorEntry dmaIrqHandlersVector[ 12 ] = 
#elif defined(STM32F4_SERIES)
DmaIrqHandlerVectorEntry dmaIrqHandlersVector[ 16 ] = 
#endif
{ { dmaStubHandler, 0 } // 0
, { dmaStubHandler, 0 } // 1
, { dmaStubHandler, 0 } // 2
, { dmaStubHandler, 0 } // 3
, { dmaStubHandler, 0 } // 4
, { dmaStubHandler, 0 } // 5
, { dmaStubHandler, 0 } // 6
, { dmaStubHandler, 0 } // 7
, { dmaStubHandler, 0 } // 8
, { dmaStubHandler, 0 } // 9
, { dmaStubHandler, 0 } // 10
, { dmaStubHandler, 0 } // 11
#if defined(STM32F4_SERIES)
, { dmaStubHandler, 0 } // 12
, { dmaStubHandler, 0 } // 13
, { dmaStubHandler, 0 } // 14
, { dmaStubHandler, 0 } // 15
#endif
};

bool periphInstallIrqHandler( DMA_TypeDef *DMAx, DmaChannel ch, DmaIrqHandlerProcT proc, void *pParam )
{
    UMBA_ASSERT(proc);
    UMBA_ASSERT( dmaIsValidChannel( DMAx, ch ) );

    size_t dmaIdx = dmaGetChannelIndex( DMAx, ch );

    bool res = false;

    UMBA_MEMORY_BARRIER();

    UMBA_DISABLE_IRQ();

    if (dmaIrqHandlersVector[dmaIdx].proc==dmaStubHandler)
    {
        dmaIrqHandlersVector[dmaIdx].proc    = proc;
        dmaIrqHandlersVector[dmaIdx].param   = pParam;
        UMBA_MEMORY_BARRIER();
        res = true;
    }

    UMBA_ENABLE_IRQ();

    return res;
}

bool periphUninstallIrqHandler( DMA_TypeDef *DMAx, DmaChannel ch )
{
    UMBA_ASSERT( dmaIsValidChannel( DMAx, ch ) );

    size_t dmaIdx = dmaGetChannelIndex( DMAx, ch );

    bool res = false;

    UMBA_MEMORY_BARRIER();

    UMBA_DISABLE_IRQ();

    if (dmaIrqHandlersVector[dmaIdx].proc!=dmaStubHandler)
    {
        dmaIrqHandlersVector[dmaIdx].proc    = dmaStubHandler;
        UMBA_MEMORY_BARRIER();
        res = true;
    }

    UMBA_ENABLE_IRQ();

    return res;
}


} // namespace traits
} // namespace periph
} // namespace umba


#define UMBA_DMA_IRQ_HANDLER_EXTRACT_PENDING_FLAGS( DMAx, ch )                   \
    using namespace umba::periph::traits;                                        \
    uint32_t hwFlags   = *dmaGetEventsRegAddr( DMAx, ch ) & dmaMakeEventsHwMask( ch, dmaChannelEventMaskAll )


#define UMBA_DMA_IRQ_HANDLER_EXTRACT_PENDING_FLAGS_CALL_HANDLER_CLEAR_PENDING_IMPL( DMAx, ch )   \
    *dmaGetEventsClearRegAddr( DMAx, ch ) = hwFlags;                                    \
    const auto &e = dmaIrqHandlersVector[dmaGetChannelIndex( DMAx, ch )];                        \
    e.proc( e.param, dmaMakeEventsFromHwMask(ch, hwFlags) )


#define UMBA_DMA_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING( DMAx, ch )                                  \
             UMBA_DMA_IRQ_HANDLER_EXTRACT_PENDING_FLAGS( DMAx, ch );                                 \
             UMBA_DMA_IRQ_HANDLER_EXTRACT_PENDING_FLAGS_CALL_HANDLER_CLEAR_PENDING_IMPL( DMAx, ch )

#define UMBA_PERIPH_DMA_IRQ_HANDLER_EX(DMAN, CHN, HANDLER_NAME )                                                     \
             UMBA_IRQ_HANDLER(HANDLER_NAME)                                                                          \
             {                                                                                                       \
                 UMBA_DMA_IRQ_HANDLER_CALL_HANDLER_CLEAR_PENDING( DMA##DMAN, umba::periph::traits::dmaChannel##CHN );\
             }


#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)

    #define UMBA_PERIPH_DMA_IRQ_HANDLER( DMAN, CHN ) \
                 UMBA_PERIPH_DMA_IRQ_HANDLER_EX( DMAN, CHN, DMA##DMAN##_Channel##CHN##_IRQHandler )

#elif defined(STM32F4_SERIES)

    #define UMBA_PERIPH_DMA_IRQ_HANDLER( DMAN, CHN ) \
                 UMBA_PERIPH_DMA_IRQ_HANDLER_EX( DMAN, CHN, DMA##DMAN##_Stream##CHN##_IRQHandler )

#endif



///!!!
//#include "umba/optimize_speed.h"


#if defined(STM32F4_SERIES)

    UMBA_PERIPH_DMA_IRQ_HANDLER( 1, 0 )

#endif

    UMBA_PERIPH_DMA_IRQ_HANDLER( 1, 1 )

    /*
    UMBA_IRQ_HANDLER(DMA1_Channel1_IRQHandler)
    {
        using namespace umba::periph::traits;
        uint32_t hwFlags   = *dmaGetEventsRegAddr( DMA2, dmaChannel0 ) & dmaMakeEventsHwMask( dmaChannel0, dmaChannelEventMaskAll );
        *dmaGetEventsClearRegAddr( DMA2, dmaChannel0 ) = hwFlags;
        const auto &e = dmaIrqHandlersVector[dmaGetChannelIndex( DMA2, dmaChannel0 )];
        e.proc( e.param, dmaMakeEventsFromHwMask(dmaChannel0, hwFlags) );
    }
    */

/*
    extern "C"
    void DMA1_Channel1_IRQHandler()
    {
        volatile uint32_t* pReg 
          = umba::periph::traits::dmaGetEventsRegAddr( ((DMA_TypeDef *) ((((uint32_t)0x40000000) + 0x00020000) + 0x00000000))
                                                     , umba::periph::traits::dmaChannel1 
                                                     );
        uint32_t allFlags = *pReg;
        *pReg &= ~umba::periph::traits::dmaMakeEventsHwMask( umba::periph::traits::dmaChannel1, umba::periph::traits::dmaChannelEventMaskAll );
        const auto &e 
          = umba::periph::traits::dmaIrqHandlersVector[ 
                  umba::periph::traits::dmaGetChannelIndex( ((DMA_TypeDef *) ((((uint32_t)0x40000000) + 0x00020000) + 0x00000000)), umba::periph::traits::dmaChannel1 )
                                                      ];
        e . proc( e . param, umba::periph::traits::dmaMakeEventsFromHwMask(umba::periph::traits::dmaChannel1, allFlags) );
    }
*/

    UMBA_PERIPH_DMA_IRQ_HANDLER( 1, 2 )
    UMBA_PERIPH_DMA_IRQ_HANDLER( 1, 3 )
    UMBA_PERIPH_DMA_IRQ_HANDLER( 1, 4 )
    UMBA_PERIPH_DMA_IRQ_HANDLER( 1, 5 )
    UMBA_PERIPH_DMA_IRQ_HANDLER( 1, 6 )
    UMBA_PERIPH_DMA_IRQ_HANDLER( 1, 7 )

#if defined(DMA2)

    UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 0 )
    /*
    UMBA_IRQ_HANDLER(DMA2_Stream0_IRQHandler)
    {
        using namespace umba::periph::traits;
        uint32_t hwFlags   = *dmaGetEventsRegAddr( DMA2, dmaChannel0 ) & dmaMakeEventsHwMask( dmaChannel0, dmaChannelEventMaskAll );
        *dmaGetEventsClearRegAddr( DMA2, dmaChannel0 ) = hwFlags;
        const auto &e = dmaIrqHandlersVector[dmaGetChannelIndex( DMA2, dmaChannel0 )];
        e.proc( e.param, dmaMakeEventsFromHwMask(dmaChannel0, hwFlags) );
    }
    */

    UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 1 )
    UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 2 )
    
    /*
    UMBA_IRQ_HANDLER(DMA2_Stream2_IRQHandler)
    {
        using namespace umba::periph::traits;
        uint32_t hwFlags   = *dmaGetEventsRegAddr( DMA2, dmaChannel2 );
        uint32_t hwMask    = dmaMakeEventsHwMask( dmaChannel2, dmaChannelEventMaskAll );
        
        #if 0
        //uint32_t hwMask    = ((uint32_t)dmaChannelEventMaskAll) << (((((uint16_t)dmaChannel2))&3)*6);
        const uint32_t uch = (uint32_t)dmaChannel2;
        const uint32_t val =  dmaChannelEventMaskAll;
        const uint32_t v1  = (val<<((uch&1)*6));
        const uint32_t v2  = v1 <<  (uch&2?16:0);
        const uint32_t v3  = (val<<((uch&1)*6)) << (uch&2?16:0);
        uint32_t hwMask = v2;
        #endif
        hwFlags &= hwMask;

        //hwMask = v3;

        *dmaGetEventsClearRegAddr( DMA2, dmaChannel2 ) = hwFlags;
        const auto &e = dmaIrqHandlersVector[dmaGetChannelIndex( DMA2, dmaChannel2 )];
        e.proc( e.param, dmaMakeEventsFromHwMask(dmaChannel2, hwFlags) );
    }
    */
    

    UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 3 )

    #if defined(STM32F1_DMA2_CHANNEL_4_5_SHARE) || defined(STM32F1_DMA2_CHANNEL_4_5_SHARE_OPTIONAL)

        UMBA_IRQ_HANDLER(DMA2_Channel4_5_IRQHandler)
        {
            UMBA_DMA_IRQ_HANDLER_EXTRACT_PENDING_FLAGS( DMA2, umba::periph::traits::dmaChannel4 );

            if (hwFlags) // has flags for channel 4
            {
                UMBA_DMA_IRQ_HANDLER_EXTRACT_PENDING_FLAGS_CALL_HANDLER_CLEAR_PENDING_IMPL( DMA2, umba::periph::traits::dmaChannel4 );
            }
            else // call channel 5 handler
            {
                UMBA_DMA_IRQ_HANDLER_EXTRACT_PENDING_FLAGS( DMA2, umba::periph::traits::dmaChannel5 );
                UMBA_DMA_IRQ_HANDLER_EXTRACT_PENDING_FLAGS_CALL_HANDLER_CLEAR_PENDING_IMPL( DMA2, umba::periph::traits::dmaChannel5 );
            }
        }

        #if defined(STM32F1_DMA2_CHANNEL_4_5_SHARE_OPTIONAL)
            UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 5 );
        #endif

    #else /* Normal F1, or generic F3/F4 */

        UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 4 )
        UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 5 )

    #endif

    #if defined(STM32F4_SERIES)

        UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 6 )
        UMBA_PERIPH_DMA_IRQ_HANDLER( 2, 7 )

    #endif

#endif /* DMA2 */

//!!!
//#include "umba/optimize_pop.h"


