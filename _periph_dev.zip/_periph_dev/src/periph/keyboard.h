#pragma once

#include "i_keyboard.h"


namespace umba
{

namespace periph
{

class GpioKeyboardImplBase;

namespace impl
{

void updateKeyState(GpioKeyboardImplBase *pKbd, KeyPressState &keyPressState, size_t keyNo, bool bPressed, const KeyboardTimeouts &timeouts, IKeyboardHandler *pKeyPressHandler );

inline
unsigned remapKeyNoToVirtualCodeHelper( size_t keyNo, const unsigned *vkMap, size_t numKeys )
{
    if (keyNo>=numKeys)
        return 0xFFFFFFFF;
    return vkMap[keyNo];
}

inline
size_t remapVirtualCodeToKeyNoHelper( unsigned vkc, const unsigned *vkMap, size_t numKeys )
{
    for( size_t i = 0; i!=numKeys; ++i )
    {
        if (vkMap[i]==vkc)
            return i;
    }

    return (size_t)-1;
}



} // namespace impl



class GpioKeyboardImplBase : implements IGpioKeyboard
{

public:

    friend void impl::updateKeyState(GpioKeyboardImplBase *pKbd, KeyPressState &keyPressState, size_t keyNo, bool bPressed, const KeyboardTimeouts &timeouts, IKeyboardHandler *pKeyPressHandler );

    GpioKeyboardImplBase();
    GpioKeyboardImplBase( IKeyboardHandler *pHandler
                    , umba::virtual_gpio::IInputPort* pColInputPort
                    , umba::virtual_gpio::IOutputPort* pRowOutputPort = 0
                    , const KeyboardTimeouts &keyboardTimeouts = KeyboardTimeouts()
                    );

    virtual
    void setHandler( IKeyboardHandler *pHandler ) override;

    virtual
    IKeyboardHandler* getHandler( ) override;


    virtual 
    void setColInputPort( umba::virtual_gpio::IInputPort* pColInputPort ) override;

    virtual 
    umba::virtual_gpio::IInputPort* getColInputPort( ) override;


    virtual 
    void setRowOutputPort( umba::virtual_gpio::IOutputPort* pRowOutputPort ) override;

    virtual 
    umba::virtual_gpio::IOutputPort* getRowOutputPort( ) override;


	virtual 
    void setTimeouts( const KeyboardTimeouts &keyboardTimeouts) override;

	virtual 
    void setTimeouts( uint32_t antiBounceTimeout, uint32_t firstRepetitionTimeout, uint32_t repetitionTimeout ) override;

	virtual 
    KeyboardTimeouts getTimeouts( ) override;


	virtual 
    void scanKeyboard() override;


protected:

    virtual
    const unsigned* getKeyMap() const
    {
        return 0;
    }

    virtual
    size_t getKeyMapSize() const
    {
        return 0;
    }

    virtual
    unsigned remapKeyNoToVirtualCode( size_t keyNo )
    {
        const unsigned* m = getKeyMap();
        if (m)
            return umba::periph::impl::remapKeyNoToVirtualCodeHelper( keyNo, m, getKeyMapSize() );
        else
            return (unsigned)keyNo;
    }

    virtual
    size_t remapVirtualCodeToKeyNo( unsigned vkc )
    {
        const unsigned* m = getKeyMap();
        if (m)
            return umba::periph::impl::remapVirtualCodeToKeyNoHelper( vkc, m, getKeyMapSize() );
        else
            return (size_t)vkc;
    }

    virtual
    void updateKeyState( size_t keyNo, bool bPressed ) = 0;

    IKeyboardHandler                 *m_pHandler;
    umba::virtual_gpio::IInputPort   *m_pColInputPort;
    umba::virtual_gpio::IOutputPort  *m_pRowOutputPort;
    KeyboardTimeouts                  m_keyboardTimeouts;

    size_t                            m_keyNo;
    umba::virtual_gpio::PinType       m_rowPin;
    umba::virtual_gpio::PinType       m_colPin;


}; // class GpioKeyboardImplBase



template< size_t NumKeys >
class GpioKeyboard : public GpioKeyboardImplBase
{
    typedef GpioKeyboardImplBase BaseImpl;

public:

    GpioKeyboard() : GpioKeyboardImplBase() {}
    GpioKeyboard( IKeyboardHandler *pHandler
            , umba::virtual_gpio::IInputPort* pColInputPort
            , umba::virtual_gpio::IOutputPort* pRowOutputPort = 0
            , const KeyboardTimeouts &keyboardTimeouts = KeyboardTimeouts()
            )
        : BaseImpl( pHandler, pColInputPort, pRowOutputPort )
        {
        }

    virtual 
    bool getKeyState( unsigned vkc ) override
    {
        size_t keyNo = remapVirtualCodeToKeyNo( vkc );

        if ( keyNo >= NumKeys )
            return false;

        return m_keyPressState[keyNo].keyState == KeyState::pressed;
    }

protected:

    virtual
    size_t getKeyMapSize() const override
    {
        return NumKeys;
    }

    virtual
    void updateKeyState( size_t keyNo, bool bPressed ) override
    {
        if ( keyNo >= NumKeys )
            return;

        impl::updateKeyState( this, m_keyPressState[keyNo], keyNo, bPressed, BaseImpl::m_keyboardTimeouts, BaseImpl::m_pHandler );
    }

    KeyPressState  m_keyPressState[NumKeys];

}; // class GpioKeyboard



} // namespace periph

} // namespace umba

