#include "periph/stm32_traits.h"


namespace umba
{
namespace periph
{
namespace traits
{


template< TIM_TypeDef* T >
inline
bool timerIsBasic( T pT )
{
    return false;
}

template< TIM_TypeDef* T >
inline
bool timerIsGeneral( T pT )
{
    return false;
}

template< TIM_TypeDef* T >
inline
bool timerIsAdvanced( T pT )
{
    return false;
}

#define UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( timNo, isBasic, isGeneral, isAdvanced )    \
                                                                                            \
        template< >                                                                         \
        inline                                                                              \
        bool timerIsBasic<timNo>( T pT )                                                    \
        {                                                                                   \
            return (isBasic);                                                               \
        }                                                                                   \
                                                                                            \
        template< >                                                                         \
        inline                                                                              \
        bool timerIsGeneral<timNo>( T pT )                                                  \
        {                                                                                   \
            return (isGeneral);                                                             \
        }                                                                                   \
                                                                                            \
        template< >                                                                         \
        inline                                                                              \
        bool timerIsAdvanced<timNo>( T pT )                                                 \
        {                                                                                   \
            return (isAdvanced);                                                            \
        }


#define UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( timNo, timClockFunc )  \
            template< >                                                                     \
            inline                                                                          \
            PerifClockFunctionPtr getPeriphClockFunction< timNo >( TIM_TypeDef *t )         \
            {                                                                               \
                return timClockFunc;                                                        \
            }

#define UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( timNo, timFlag )           \
            template< >                                                                     \
            inline                                                                          \
            uint32_t getPeriphClockFlag< timNo >( TIM_TypeDef *t )                          \
            {                                                                               \
                return timFlag;                                                             \
            }


/* F1XX --------------------------
void RCC_AHBPeriphClockCmd(uint32_t RCC_AHBPeriph, FunctionalState NewState);
void RCC_APB1PeriphClockCmd(uint32_t RCC_APB1Periph, FunctionalState NewState);
void RCC_APB2PeriphClockCmd(uint32_t RCC_APB2Periph, FunctionalState NewState);

#define RCC_APB2Periph_TIM1              ((uint32_t)0x00000800)
#define RCC_APB2Periph_TIM8              ((uint32_t)0x00002000)
#define RCC_APB2Periph_TIM15             ((uint32_t)0x00010000)
#define RCC_APB2Periph_TIM16             ((uint32_t)0x00020000)
#define RCC_APB2Periph_TIM17             ((uint32_t)0x00040000)
#define RCC_APB2Periph_TIM9              ((uint32_t)0x00080000)
#define RCC_APB2Periph_TIM10             ((uint32_t)0x00100000)
#define RCC_APB2Periph_TIM11             ((uint32_t)0x00200000)

#define RCC_APB1Periph_TIM2              ((uint32_t)0x00000001)
#define RCC_APB1Periph_TIM3              ((uint32_t)0x00000002)
#define RCC_APB1Periph_TIM4              ((uint32_t)0x00000004)
#define RCC_APB1Periph_TIM5              ((uint32_t)0x00000008)
#define RCC_APB1Periph_TIM6              ((uint32_t)0x00000010)
#define RCC_APB1Periph_TIM7              ((uint32_t)0x00000020)
#define RCC_APB1Periph_TIM12             ((uint32_t)0x00000040)
#define RCC_APB1Periph_TIM13             ((uint32_t)0x00000080)
#define RCC_APB1Periph_TIM14             ((uint32_t)0x00000100)
*/

/* F3XX --------------------------
void RCC_AHBPeriphClockCmd(uint32_t RCC_AHBPeriph, FunctionalState NewState);
void RCC_APB1PeriphClockCmd(uint32_t RCC_APB1Periph, FunctionalState NewState);
void RCC_APB2PeriphClockCmd(uint32_t RCC_APB2Periph, FunctionalState NewState); 

#define RCC_APB2Periph_TIM1              RCC_APB2ENR_TIM1EN
#define RCC_APB2Periph_TIM8              RCC_APB2ENR_TIM8EN
#define RCC_APB2Periph_TIM15             RCC_APB2ENR_TIM15EN
#define RCC_APB2Periph_TIM16             RCC_APB2ENR_TIM16EN
#define RCC_APB2Periph_TIM17             RCC_APB2ENR_TIM17EN
#define RCC_APB2Periph_TIM20             RCC_APB2ENR_TIM20EN

#define RCC_APB1Periph_TIM2              RCC_APB1ENR_TIM2EN
#define RCC_APB1Periph_TIM3              RCC_APB1ENR_TIM3EN
#define RCC_APB1Periph_TIM4              RCC_APB1ENR_TIM4EN
#define RCC_APB1Periph_TIM6              RCC_APB1ENR_TIM6EN
#define RCC_APB1Periph_TIM7              RCC_APB1ENR_TIM7EN 
*/

/* F4XX --------------------------
void        RCC_AHB1PeriphClockCmd(uint32_t RCC_AHB1Periph, FunctionalState NewState);
void        RCC_AHB2PeriphClockCmd(uint32_t RCC_AHB2Periph, FunctionalState NewState);
void        RCC_AHB3PeriphClockCmd(uint32_t RCC_AHB3Periph, FunctionalState NewState);
void        RCC_APB1PeriphClockCmd(uint32_t RCC_APB1Periph, FunctionalState NewState);
void        RCC_APB2PeriphClockCmd(uint32_t RCC_APB2Periph, FunctionalState NewState);

#define RCC_APB1Periph_TIM2              ((uint32_t)0x00000001)
#define RCC_APB1Periph_TIM3              ((uint32_t)0x00000002)
#define RCC_APB1Periph_TIM4              ((uint32_t)0x00000004)
#define RCC_APB1Periph_TIM5              ((uint32_t)0x00000008)
#define RCC_APB1Periph_TIM6              ((uint32_t)0x00000010)
#define RCC_APB1Periph_TIM7              ((uint32_t)0x00000020)
#define RCC_APB1Periph_TIM12             ((uint32_t)0x00000040)
#define RCC_APB1Periph_TIM13             ((uint32_t)0x00000080)
#define RCC_APB1Periph_TIM14             ((uint32_t)0x00000100)
//? #define RCC_APB1Periph_LPTIM1            ((uint32_t)0x00000200)

#define RCC_APB2Periph_TIM1              ((uint32_t)0x00000001)
#define RCC_APB2Periph_TIM8              ((uint32_t)0x00000002)
#define RCC_APB2Periph_TIM9              ((uint32_t)0x00010000)
#define RCC_APB2Periph_TIM10             ((uint32_t)0x00020000)
#define RCC_APB2Periph_TIM11             ((uint32_t)0x00040000)
*/

/* В скобках - серия, в которой таймера нет вообще
 APB1 - 2, 3, 4, 5(3), 6, 7, 12(3), 13(3), 14(3)
 APB2 - 1, 8, 15(4), 16(4), 17(4), 20(1,4), 9(3), 10(3) 11(3)

*/



// STM32F3xx
// Advanced-control timers (TIM1/TIM8/TIM20)
// General-purpose timers (TIM2/TIM3/TIM4)
// Basic timers (TIM6/TIM7)
// General-purpose timers (TIM15/TIM16/TIM17)

// STM32F1xx
// Advanced-control timers (TIM1 and TIM8)
// General-purpose timers (TIM2 to TIM5)
// General-purpose timers (TIM9 to TIM14)
// Basic timers (TIM6 and TIM7)

// STM32F4xx
// Advanced-control timers (TIM1 and TIM8)
// General-purpose timers (TIM2 to TIM5)
// General-purpose timers (TIM9 to TIM14)
// Basic timers (TIM6 and TIM7)
    
#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    // Basic timers (TIM6 and TIM7)
    #ifdef TIM6
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM6, true, false, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM6, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM6, RCC_APB1Periph_TIM6 )
    #endif

    #ifdef TIM7
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM7, true, false, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM7, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM7, RCC_APB1Periph_TIM7 )
    #endif

    // General-purpose timers (TIM2 to TIM5)
    #ifdef TIM2
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM2, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM2, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM2, RCC_APB1Periph_TIM2 )
    #endif
    #ifdef TIM3
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM3, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM3, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM3, RCC_APB1Periph_TIM3 )
    #endif
    #ifdef TIM4
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM4, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM4, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM4, RCC_APB1Periph_TIM4 )
    #endif
    #ifdef TIM5 /* STM32F1xx/STM32F4xx */
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM5, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM5, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM5, RCC_APB1Periph_TIM5 )
    #endif

    // General-purpose timers (TIM9 to TIM14) /* STM32F1xx/STM32F4xx */
    #ifdef TIM9
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM9, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM9, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM9, RCC_APB2Periph_TIM9 )
    #endif
    #ifdef TIM10
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM10, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM10, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM10, RCC_APB2Periph_TIM10 )
    #endif
    #ifdef TIM11
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM11, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM11, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM11, RCC_APB2Periph_TIM11 )
    #endif
    #ifdef TIM12
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM12, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM12, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM12, RCC_APB1Periph_TIM12 )
    #endif
    #ifdef TIM13
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM13, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM13, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM13, RCC_APB1Periph_TIM13 )
    #endif
    #ifdef TIM14
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM14, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM14, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM14, RCC_APB1Periph_TIM14 )
    #endif

    // General-purpose timers (TIM15/TIM16/TIM17) - STM32F3xx
    #ifdef TIM15
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM15, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM15, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM15, RCC_APB2Periph_TIM15 )
    #endif
    #ifdef TIM16
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM16, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM16, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM16, RCC_APB2Periph_TIM16 )
    #endif
    #ifdef TIM17
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM17, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM17, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM17, RCC_APB2Periph_TIM17 )
    #endif


    // Advanced-control timers (TIM1 and TIM8)
    #ifdef TIM1
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM1, false, false, true)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM1, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM1, RCC_APB2Periph_TIM1 )
    #endif
    #ifdef TIM8
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM8, false, false, true)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM8, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM8, RCC_APB2Periph_TIM8 )
    #endif
    #ifdef TIM20 /* STM32F3xx */
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM20, false, false, true)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM20, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM20, RCC_APB2Periph_TIM20 )
    #endif

#endif







#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    // Basic timers (TIM6 and TIM7)
    #ifdef TIM6
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM6, true, false, false)
    #endif

    #ifdef TIM7
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM7, true, false, false)
    #endif

    // General-purpose timers (TIM2 to TIM5)
    #ifdef TIM2
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM2, false, true, false)
    #endif
    #ifdef TIM3
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM3, false, true, false)
    #endif
    #ifdef TIM4
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM4, false, true, false)
    #endif
    #ifdef TIM5 /* STM32F1xx/STM32F4xx */
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM5, false, true, false)
    #endif

    // General-purpose timers (TIM9 to TIM14) /* STM32F1xx/STM32F4xx */
    #ifdef TIM9
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM9, false, true, false)
    #endif
    #ifdef TIM10
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM10, false, true, false)
    #endif
    #ifdef TIM11
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM11, false, true, false)
    #endif
    #ifdef TIM12
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM12, false, true, false)
    #endif
    #ifdef TIM13
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM13, false, true, false)
    #endif
    #ifdef TIM14
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM14, false, true, false)
    #endif

    // General-purpose timers (TIM15/TIM16/TIM17) - STM32F3xx
    #ifdef TIM15
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM15, false, true, false)
    #endif
    #ifdef TIM16
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM16, false, true, false)
    #endif
    #ifdef TIM17
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM17, false, true, false)
    #endif


    // Advanced-control timers (TIM1 and TIM8)
    #ifdef TIM1
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM1, false, false, true)
    #endif
    #ifdef TIM8
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM8, false, false, true)
    #endif
    #ifdef TIM20 /* STM32F3xx */
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM20, false, false, true)
    #endif

#endif








#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    // Basic timers (TIM6 and TIM7)
    #ifdef TIM6
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM6, true, false, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM6, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM6, RCC_APB1Periph_TIM6 )
    #endif

    #ifdef TIM7
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM7, true, false, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM7, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM7, RCC_APB1Periph_TIM7 )
    #endif

    // General-purpose timers (TIM2 to TIM5)
    #ifdef TIM2
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM2, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM2, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM2, RCC_APB1Periph_TIM2 )
    #endif
    #ifdef TIM3
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM3, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM3, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM3, RCC_APB1Periph_TIM3 )
    #endif
    #ifdef TIM4
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM4, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM4, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM4, RCC_APB1Periph_TIM4 )
    #endif
    #ifdef TIM5 /* STM32F1xx/STM32F4xx */
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM5, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM5, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM5, RCC_APB1Periph_TIM5 )
    #endif

    // General-purpose timers (TIM9 to TIM14) /* STM32F1xx/STM32F4xx */
    #ifdef TIM9
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM9, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM9, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM9, RCC_APB2Periph_TIM9 )
    #endif
    #ifdef TIM10
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM10, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM10, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM10, RCC_APB2Periph_TIM10 )
    #endif
    #ifdef TIM11
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM11, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM11, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM11, RCC_APB2Periph_TIM11 )
    #endif
    #ifdef TIM12
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM12, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM12, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM12, RCC_APB1Periph_TIM12 )
    #endif
    #ifdef TIM13
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM13, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM13, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM13, RCC_APB1Periph_TIM13 )
    #endif
    #ifdef TIM14
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM14, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM14, RCC_APB1PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM14, RCC_APB1Periph_TIM14 )
    #endif

    // General-purpose timers (TIM15/TIM16/TIM17) - STM32F3xx
    #ifdef TIM15
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM15, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM15, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM15, RCC_APB2Periph_TIM15 )
    #endif
    #ifdef TIM16
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM16, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM16, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM16, RCC_APB2Periph_TIM16 )
    #endif
    #ifdef TIM17
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM17, false, true, false)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM17, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM17, RCC_APB2Periph_TIM17 )
    #endif


    // Advanced-control timers (TIM1 and TIM8)
    #ifdef TIM1
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM1, false, false, true)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM1, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM1, RCC_APB2Periph_TIM1 )
    #endif
    #ifdef TIM8
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM8, false, false, true)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM8, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM8, RCC_APB2Periph_TIM8 )
    #endif
    #ifdef TIM20 /* STM32F3xx */
        UMBA_PERIPH_STM32_TIM_SPECIALIZE_TRAITS( TIM20, false, false, true)
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFUNCTION_DECLARE_TIM( TIM20, RCC_APB2PeriphClockCmd )
        UMBA_PERIPH_STM32_TRAITS_GETPERIPHCLOCKFLAG_DECLARE_TIM( TIM20, RCC_APB2Periph_TIM20 )
    #endif

#endif



} // namespace traits
} // namespace periph
} // namespace umba






