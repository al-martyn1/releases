#include "keyboard.h"

#ifdef UMBA_PERIPH_DEBUG_LOG_KEYBORD
    #include "umba/simple_formatter.h"
    extern umba::SimpleFormatter    fmt;
#endif

namespace umba
{

namespace periph
{

namespace impl
{

void updateKeyState(GpioKeyboardImplBase *pKbd, KeyPressState &keyPressState, size_t keyNo, bool bPressed, const KeyboardTimeouts &keyboardTimeouts, IKeyboardHandler *pKeyPressHandler )
{
    KeyState newKeyState = bPressed ? KeyState::pressed : KeyState::released;

    if (keyPressState.keyState==newKeyState) // only pressed or released state are possible here
    { // state is the same
        if (keyPressState.keyState==KeyState::released)
            return; // nothing to do on released key

        // key is still pressed
        TimeTick  tick     = umba::time_service::getCurTimeMs();
        TimeTick  tickDiff = tick - keyPressState.keyTick;
        TimeTick  tickDiffCompareTo = keyPressState.repeatCount>1 ? keyboardTimeouts.repetitionTimeout : keyboardTimeouts.firstRepetitionTimeout;

        #ifdef UMBA_PERIPH_DEBUG_LOG_KEYBORD
            fmt<<"Tick: "<<tick<<", key tick: " << keyPressState.keyTick <<", timeout: "<<tickDiffCompareTo<<", diff: "<<tickDiff<<"\n";
        #endif

        if (tickDiff >= tickDiffCompareTo)
        {

            keyPressState.repeatCount++;
            if (pKeyPressHandler)
                pKeyPressHandler->onKeyPress( pKbd->remapKeyNoToVirtualCode(keyNo), keyPressState.keyState==KeyState::pressed, keyPressState.repeatCount);
            keyPressState.keyTick = tick;
            return;
        }
    }
    else // key state changed
    {
        TimeTick  curTick = umba::time_service::getCurTimeMs();

        // start changing key state
        if (keyPressState.keyState==KeyState::pressed || keyPressState.keyState==KeyState::released)
        {
            keyPressState.keyTick = curTick;
            keyPressState.repeatCount = 0;

            #ifdef UMBA_PERIPH_DEBUG_LOG_KEYBORD
                fmt<<"Tick: "<<curTick<<", key tick: " << keyPressState.keyTick <<", become : "<<(keyPressState.keyState==KeyState::released ? "pressing" : "releasing" )<<  "\n";
            #endif

            if (keyPressState.keyState==KeyState::released)
            {
                keyPressState.keyState = KeyState::pressing;
            }
            else
            {
                keyPressState.keyState = KeyState::releasing;
            }
            return;
        }

        // finalize changing key state
        TimeTick  tickDiff = curTick - keyPressState.keyTick;
        //fmt<<"Timeout: "<<keyboardTimeouts.antiBounceTimeout<<", diff: "<<tickDiff<<"\n";
        if (tickDiff < keyboardTimeouts.antiBounceTimeout)
        {
            #ifdef UMBA_PERIPH_DEBUG_LOG_KEYBORD
                fmt<<"Tick: "<<curTick<<", key tick: " << keyPressState.keyTick <<", diff: "<<tickDiff<< " - Antibounce exit\n";
            #endif
            return; // do nothing on antibounce period
        }
        // antibounce period ellapsed
        keyPressState.repeatCount = 0;
        keyPressState.keyTick = curTick;

        #ifdef UMBA_PERIPH_DEBUG_LOG_KEYBORD
            fmt<<"Tick: "<<curTick<<", key tick: " << keyPressState.keyTick <<" - Release or first press\n"; 
        #endif

        if (keyPressState.keyState==KeyState::releasing)
        {
            keyPressState.keyState = KeyState::released;
            if (pKeyPressHandler)
                pKeyPressHandler->onKeyPress( pKbd->remapKeyNoToVirtualCode(keyNo), false, keyPressState.repeatCount);
        }
        else
        {
            keyPressState.keyState = KeyState::pressed;
            if (pKeyPressHandler)
                pKeyPressHandler->onKeyPress( pKbd->remapKeyNoToVirtualCode(keyNo), true, ++keyPressState.repeatCount);
        }
    }
}

} // namespace impl




GpioKeyboardImplBase::GpioKeyboardImplBase()
     : m_pHandler(0)
     , m_pColInputPort(0)
     , m_pRowOutputPort(0)
     , m_keyboardTimeouts()
     , m_keyNo(0) 
     , m_rowPin(0)
     , m_colPin(0)
{
}

//-----------------------------------------------------------------------------
GpioKeyboardImplBase::GpioKeyboardImplBase( IKeyboardHandler *pHandler
        , umba::virtual_gpio::IInputPort* pColInputPort
        , umba::virtual_gpio::IOutputPort* pRowOutputPort
        , const KeyboardTimeouts &keyboardTimeouts
        )
     : m_pHandler(pHandler)
     , m_pColInputPort(pColInputPort)
     , m_pRowOutputPort(pRowOutputPort)
     , m_keyboardTimeouts(keyboardTimeouts)
     , m_keyNo(0) 
     , m_rowPin(0)
     , m_colPin(0)
{
}

//-----------------------------------------------------------------------------

void GpioKeyboardImplBase::setHandler( IKeyboardHandler *pHandler )
{
    m_pHandler = pHandler;
}

//-----------------------------------------------------------------------------
IKeyboardHandler* GpioKeyboardImplBase::getHandler( )
{
    return m_pHandler;
}

//-----------------------------------------------------------------------------
void GpioKeyboardImplBase::setRowOutputPort( umba::virtual_gpio::IOutputPort* pRowOutputPort )
{
    m_pRowOutputPort = pRowOutputPort;
}

//-----------------------------------------------------------------------------
umba::virtual_gpio::IOutputPort* GpioKeyboardImplBase::getRowOutputPort( )
{
    return m_pRowOutputPort;
}

//-----------------------------------------------------------------------------
void GpioKeyboardImplBase::setColInputPort( umba::virtual_gpio::IInputPort* pColInputPort )
{
    m_pColInputPort = pColInputPort;
}

//-----------------------------------------------------------------------------
umba::virtual_gpio::IInputPort* GpioKeyboardImplBase::getColInputPort( )
{
    return m_pColInputPort;
}

//-----------------------------------------------------------------------------
void GpioKeyboardImplBase::setTimeouts( const KeyboardTimeouts &keyboardTimeouts)
{
    m_keyboardTimeouts = keyboardTimeouts;
}

//-----------------------------------------------------------------------------
void GpioKeyboardImplBase::setTimeouts( uint32_t antiBounceTimeout, uint32_t firstRepetitionTimeout, uint32_t repetitionTimeout )
{
    m_keyboardTimeouts.antiBounceTimeout      = antiBounceTimeout;
    m_keyboardTimeouts.firstRepetitionTimeout = firstRepetitionTimeout;
    m_keyboardTimeouts.repetitionTimeout      = repetitionTimeout;
}

//-----------------------------------------------------------------------------
KeyboardTimeouts GpioKeyboardImplBase::getTimeouts( )
{
    return m_keyboardTimeouts;
}

//#define SCAN_ONE_COL_PER_TIME
//-----------------------------------------------------------------------------
void GpioKeyboardImplBase::scanKeyboard()
{
    UMBA_ASSERT(m_pColInputPort);

    if (!m_rowPin && !m_colPin)
        m_keyNo = 0;

    // Если у нас нет управления строками, значит, все кнопки уже подключены 
    // к какой-то линии и мы просто сканируем вход.
    // Если управление строками присутствует, то необходимо сначала установить 
    // единицу в одной из линий строки

    #if defined(SCAN_ONE_COL_PER_TIME)
    if (m_pRowOutputPort && !m_colPin)
    #else
    if (m_pRowOutputPort) // && !m_colPin
    #endif
    {
        umba::virtual_gpio::PinType rowPins = m_pRowOutputPort->getPins();
        umba::virtual_gpio::PinType prevRowPin = 0;

        if (!m_rowPin)
            m_rowPin = 1;
        else
        {
            prevRowPin = m_rowPin;
            m_rowPin <<= 1;
        }

        while(m_rowPin && (rowPins&m_rowPin)==0)
            m_rowPin <<= 1;

        umba::virtual_gpio::PinType pinsMask = m_rowPin | prevRowPin;
        if (pinsMask) // Хотя бы один пин (текущий или предыдущий) надо изменить
        {
            m_pRowOutputPort->setOutput( pinsMask, m_rowPin ); // set new and clear prev
            m_pRowOutputPort->writeFlushPins();
        }

        if (!m_rowPin)
            return;

        m_colPin = 1; // start scaning cols at next step

        #if defined(SCAN_ONE_COL_PER_TIME)
        return;
        #endif

    } // if (m_pRowOutputPort)

    if (!m_colPin)
        m_colPin = 1; // start scaning cols if not started

    if (m_colPin == 1) // lock input before start scaning cols
        m_pColInputPort->readLockPins();

    umba::virtual_gpio::PinType colPins = m_pColInputPort->getPins();

    #if !defined(SCAN_ONE_COL_PER_TIME)
    while(m_colPin)
    {
    #endif
        while(m_colPin && (m_colPin&colPins)==0)
            m_colPin <<= 1;
       
        if (!m_colPin)
        {
            return; // end of scan
        }
       
        umba::virtual_gpio::PinType colPinVal = m_pColInputPort->readInput( m_colPin );
       
        m_colPin <<= 1; // move to next pin at next step
       
        updateKeyState( m_keyNo, colPinVal ? true : false );
       
        ++m_keyNo;
    #if !defined(SCAN_ONE_COL_PER_TIME)
    }
    #endif

}

//-----------------------------------------------------------------------------
//void updateKeyState(KeyPressState &keyPressState, size_t keyNo, bool bPressed );





} // namespace periph


} // namespace umba

