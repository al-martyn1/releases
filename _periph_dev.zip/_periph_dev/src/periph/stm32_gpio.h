#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

namespace umba
{
namespace periph
{
namespace traits
{




//-----------------------------------------------------------------------------
#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)
    
    #define UMBA_PERIPH_STM32_TRAITS_RAW_PORT_BSSR( port )       ((port)->BSRR)

#elif defined(STM32F4_SERIES)
    
    #define UMBA_PERIPH_STM32_TRAITS_RAW_PORT_BSSR( port )       (*((uint32_t*)(&((port)->BSRRL))))

#endif



#include "umba/optimize_speed.h"
//-----------------------------------------------------------------------------
UMBA_FORCE_INLINE( void rawGpioPortBitsSetReset( RawGpioPortType port, RawGpioPortBits setBits, RawGpioPortBits resetBits ) )
{
    UMBA_PERIPH_STM32_TRAITS_RAW_PORT_BSSR( port ) = ((uint32_t)setBits) | (((uint32_t)resetBits)<<16);
}

//-----------------------------------------------------------------------------
UMBA_FORCE_INLINE( void rawGpioPortBitsSet( RawGpioPortType port, RawGpioPortBits setBits ) )
{
    UMBA_PERIPH_STM32_TRAITS_RAW_PORT_BSSR( port ) = ((uint32_t)setBits);
}

//-----------------------------------------------------------------------------
UMBA_FORCE_INLINE( void rawGpioPortBitsReset( RawGpioPortType port, RawGpioPortBits resetBits ) )
{
    UMBA_PERIPH_STM32_TRAITS_RAW_PORT_BSSR( port ) = (((uint32_t)resetBits)<<16);
}

//-----------------------------------------------------------------------------
UMBA_FORCE_INLINE( void rawGpioPortBitsToggle( RawGpioPortType port, RawGpioPortBits toggleBits ) )
{
    rawGpioPortBitsSetReset( port
                           , (( ~port->ODR ) & toggleBits) // берем биты, инвертируем, нолики превращаются в единички, маскируем и просим установить
                           , port->ODR & toggleBits        // просто маскируем нужные биты и просим сбросить
                           );
}

//-----------------------------------------------------------------------------
UMBA_FORCE_INLINE( RawGpioPortBits rawGpioPortBitsOutputRead( RawGpioPortType port ) )
{
    return port->ODR;
}

//-----------------------------------------------------------------------------
UMBA_FORCE_INLINE( RawGpioPortBits rawGpioPortBitsRead( RawGpioPortType port ) )
{
    return port->IDR;
}
#include "umba/optimize_pop.h"


/* STM32F1_SERIES
------------------

Input floating
Input pull-up
Input-pull-down
Analog
Output open-drain
Output push-pull
Alternate function push-pull
Alternate function open-drain
*/


/* STM32F3_SERIES
------------------
*/


/* STM32F4_SERIES
------------------

Input floating
Input pull-up
Input-pull-down
Analog
Output open-drain with pull-up or pull-down capability
Output push-pull with pull-up or pull-down capability
Alternate function push-pull with pull-up or pull-down capability
Alternate function open-drain with pull-up or pull-down capability

*/


//-----------------------------------------------------------------------------
/*

// STM32F1_SERIES                 STM32F3_SERIES                    STM32F4_SERIES

typedef struct                    typedef struct                    typedef struct
{                                 {                                 {                               
  uint16_t GPIO_Pin;                uint32_t GPIO_Pin;                uint32_t GPIO_Pin;
  GPIOSpeed_TypeDef GPIO_Speed;     GPIOMode_TypeDef GPIO_Mode;       GPIOMode_TypeDef GPIO_Mode;
  GPIOMode_TypeDef GPIO_Mode;       GPIOSpeed_TypeDef GPIO_Speed;     GPIOSpeed_TypeDef GPIO_Speed;
                                    GPIOOType_TypeDef GPIO_OType;     GPIOOType_TypeDef GPIO_OType;
                                    GPIOPuPd_TypeDef GPIO_PuPd;       GPIOPuPd_TypeDef GPIO_PuPd;
} GPIO_InitTypeDef;               } GPIO_InitTypeDef;               } GPIO_InitTypeDef;

// GPIO_Mode_AIN - analog in
typedef enum                      typedef enum                      typedef enum
{ GPIO_Mode_AIN = 0x0,            {                                 {
  GPIO_Mode_IN_FLOATING = 0x04,     GPIO_Mode_IN   = 0x00,            GPIO_Mode_IN   = 0x00, // GPIO Input Mode
  GPIO_Mode_IPD = 0x28,             GPIO_Mode_OUT  = 0x01,            GPIO_Mode_OUT  = 0x01, // GPIO Output Mode
  GPIO_Mode_IPU = 0x48,             GPIO_Mode_AF   = 0x02,            GPIO_Mode_AF   = 0x02, // GPIO Alternate function Mode
  GPIO_Mode_Out_OD = 0x14,          GPIO_Mode_AN   = 0x03             GPIO_Mode_AN   = 0x03  // GPIO Analog Mode
  GPIO_Mode_Out_PP = 0x10,                                          }GPIOMode_TypeDef;
  GPIO_Mode_AF_OD = 0x1C,         } GPIOMode_TypeDef;
  GPIO_Mode_AF_PP = 0x18
}GPIOMode_TypeDef;

typedef enum                      typedef enum                      typedef enum
{                                 {                                 {
  GPIO_Speed_10MHz = 1,             GPIO_Speed_Level_1  = 0x01,       GPIO_Low_Speed     = 0x00,
  GPIO_Speed_2MHz,                  GPIO_Speed_Level_2  = 0x02,       GPIO_Medium_Speed  = 0x01,
  GPIO_Speed_50MHz                  GPIO_Speed_Level_3  = 0x03        GPIO_Fast_Speed    = 0x02,
                                                                      GPIO_High_Speed    = 0x03
} GPIOSpeed_TypeDef;              } GPIOSpeed_TypeDef;              } GPIOSpeed_TypeDef;

                                  typedef enum                      typedef enum
                                  {                                 {
                                    GPIO_OType_PP = 0x00,             GPIO_OType_PP = 0x00,
                                    GPIO_OType_OD = 0x01              GPIO_OType_OD = 0x01
                                  } GPIOOType_TypeDef;              } GPIOOType_TypeDef;

                                  typedef enum                      typedef enum
                                  {                                 {
                                    GPIO_PuPd_NOPULL = 0x00,          GPIO_PuPd_NOPULL = 0x00,
                                    GPIO_PuPd_UP     = 0x01,          GPIO_PuPd_UP     = 0x01,
                                    GPIO_PuPd_DOWN   = 0x02           GPIO_PuPd_DOWN   = 0x02 
                                  } GPIOPuPd_TypeDef;               } GPIOPuPd_TypeDef;
*/

/* STM32F1_SERIES                 STM32F4_SERIES

Input floating                    Input floating                                                    
Input pull-up                     Input pull-up                                                     
Input-pull-down                   Input-pull-down                                                   
Analog                            Analog                                                            
Output open-drain                 Output open-drain with pull-up or pull-down capability            
Output push-pull                  Output push-pull with pull-up or pull-down capability             
Alternate function push-pull      Alternate function push-pull with pull-up or pull-down capability 
Alternate function open-drain     Alternate function open-drain with pull-up or pull-down capability

*/

//-----------------------------------------------------------------------------


enum class PinSpeed
{
    low, medium, fast, high
};

enum class PinMode
{
    analog_in,         //<! 0x00 Аналоговый вход
    gpio_in_floating,  //<! 0x01 Вход без подтяжки, болтающийся (англ. float) в воздухе
    gpio_in_pulldown,  //<! 0x02 Вход с подтяжкой к земле (англ. Pull-down)
    gpio_in_pullup,    //<! 0x03 Вход с подтяжкой к питанию (англ. Pull-up)
    gpio_out_od,       //<! 0x04 Выход с открытым стоком (англ. Open Drain)
    gpio_out_pp,       //<! 0x05 Выход двумя состояниями (англ. Push-Pull — туда-сюда)
    alt_mode_od,       //<! 0x06 Выход для альтернативных функций с открытым стоком
    alt_mode_pp,       //<! 0x07 Выход для альтернативных функций с двумя состояниями
    alt_mode_input_floating  //<! 0x07 Вход для альтернативных функций
};

enum PinGetDirection
{
    input, output, dir_auto
};


// 1) call GPIO_InitTypeDefInit
// 2) set  GPIO_InitStruct.GPIO_Pin
// 3) call GPIO_Init(GPIOx)

//-----------------------------------------------------------------------------
inline
void gpioInitTypeDefInit( GPIO_InitTypeDef &gpioInit, PinSpeed pinSpeed, PinMode pinMode, unsigned pinMask = 0 )
{
    #if defined(STM32F1_SERIES)

        gpioInit.GPIO_Pin = (uint16_t)pinMask;

        switch(pinSpeed)
        {
            case PinSpeed::low:
                 gpioInit.GPIO_Speed = GPIO_Speed_2MHz;
                 break;

            case PinSpeed::medium:
                 gpioInit.GPIO_Speed = GPIO_Speed_10MHz;
                 break;

            case PinSpeed::fast:
                 gpioInit.GPIO_Speed = GPIO_Speed_50MHz;
                 break;

            case PinSpeed::high:
                 gpioInit.GPIO_Speed = GPIO_Speed_50MHz;
                 break;

            default:
                 UMBA_ASSERT_FAIL();
                 return;
        }

        switch(pinMode)
        {
            case PinMode::analog_in:         // Аналоговый вход
                 gpioInit.GPIO_Mode  = GPIO_Mode_AIN;
                 break;

            case PinMode::gpio_in_floating:  // Вход без подтяжки, болтающийся (англ. float) в воздухе
                 gpioInit.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
                 break;

            case PinMode::gpio_in_pulldown:  // Вход с подтяжкой к земле (англ. Pull-down)
                 gpioInit.GPIO_Mode  = GPIO_Mode_IPD;
                 break;

            case PinMode::gpio_in_pullup:    // Вход с подтяжкой к питанию (англ. Pull-up)
                 gpioInit.GPIO_Mode  = GPIO_Mode_IPU;
                 break;

            case PinMode::gpio_out_od:       // Выход с открытым стоком (англ. Open Drain)
                 gpioInit.GPIO_Mode  = GPIO_Mode_Out_OD;
                 break;

            case PinMode::gpio_out_pp:       // Выход двумя состояниями (англ. Push-Pull — туда-сюда)
                 gpioInit.GPIO_Mode  = GPIO_Mode_Out_PP;
                 break;

            case PinMode::alt_mode_od:       // Выход для альтернативных функций с открытым стоком
                 gpioInit.GPIO_Mode  = GPIO_Mode_AF_OD;
                 break;

            case PinMode::alt_mode_pp:       // Выход для альтернативных функций с двумя состояниями
                 gpioInit.GPIO_Mode  = GPIO_Mode_AF_PP;
                 break;

            case PinMode::alt_mode_input_floating:
                 gpioInit.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
                 break;

            default:
                 UMBA_ASSERT_FAIL();
                 return;
        }

    #elif defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

        gpioInit.GPIO_Pin = (uint32_t)pinMask;

        #if defined(STM32F3_SERIES)

            //#define GPIO_Speed_10MHz GPIO_Speed_Level_1   // Fast Speed:10MHz 
            //#define GPIO_Speed_2MHz  GPIO_Speed_Level_2   // Medium Speed:2MHz
            //#define GPIO_Speed_50MHz GPIO_Speed_Level_3   // High Speed:50MHz 

            /*
            GPIO Speed ( from RM)
            x0: Low speed  00/10    0/2
            01: Medium speed        1
            11: High speed          3
           
            From SPL
            typedef enum
            { 
                GPIO_Speed_Level_1  = 0x01, //!< Fast Speed     /
                GPIO_Speed_Level_2  = 0x02, //!< Meduim Speed   / Not medium, but low
                GPIO_Speed_Level_3  = 0x03  //!< High Speed     /
            }GPIOSpeed_TypeDef;
            */

            switch(pinSpeed)
            {
                case PinSpeed::low:
                     gpioInit.GPIO_Speed = GPIO_Speed_2MHz; // GPIO_Speed_Level_2; // (GPIOSpeed_TypeDef)0; // GPIO_Speed_Level_2;
                     break;                                  
                                                             
                case PinSpeed::medium:                       
                     gpioInit.GPIO_Speed = GPIO_Speed_10MHz; // GPIO_Speed_Level_1; // (GPIOSpeed_TypeDef)1; // GPIO_Speed_Level_1;
                     break;                                  
                                                             
                case PinSpeed::fast:                         
                     gpioInit.GPIO_Speed = GPIO_Speed_50MHz; // GPIO_Speed_Level_3; // (GPIOSpeed_TypeDef)3; // GPIO_Speed_Level_3;
                     break;                                  
                                                             
                case PinSpeed::high:                         
                     gpioInit.GPIO_Speed = GPIO_Speed_50MHz; // GPIO_Speed_Level_3; // (GPIOSpeed_TypeDef)3; // GPIO_Speed_Level_3;
                     break;
           
                default:
                     UMBA_ASSERT_FAIL();
                     return;
            }

        #elif defined(STM32F4_SERIES)

            //#define  GPIO_Speed_2MHz    GPIO_Low_Speed    
            //#define  GPIO_Speed_25MHz   GPIO_Medium_Speed 
            //#define  GPIO_Speed_50MHz   GPIO_Fast_Speed 
            //#define  GPIO_Speed_100MHz  GPIO_High_Speed  

            switch(pinSpeed)
            {
                case PinSpeed::low:
                     gpioInit.GPIO_Speed = GPIO_Low_Speed;
                     break;
           
                case PinSpeed::medium:
                     gpioInit.GPIO_Speed = GPIO_Medium_Speed;
                     break;
           
                case PinSpeed::fast:
                     gpioInit.GPIO_Speed = GPIO_Fast_Speed;
                     break;
           
                case PinSpeed::high:
                     gpioInit.GPIO_Speed = GPIO_High_Speed;
                     break;
           
                default:
                     UMBA_ASSERT_FAIL();
                     return;
            }

        #else

            #error "MCU not supported"

        #endif

        //void GPIO_StructInit(GPIO_InitTypeDef* GPIO_InitStruct)
        //// Reset GPIO init structure parameters values
        //GPIO_InitStruct->GPIO_Mode  = GPIO_Mode_IN;
        //GPIO_InitStruct->GPIO_OType = GPIO_OType_PP;
        //GPIO_InitStruct->GPIO_PuPd  = GPIO_PuPd_NOPULL;

        switch(pinMode)
        {
            case PinMode::analog_in:         // Аналоговый вход
                 gpioInit.GPIO_Mode  = GPIO_Mode_AN;
                 gpioInit.GPIO_OType = GPIO_OType_PP;    // ?
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_NOPULL; // ?
                 break;

            case PinMode::gpio_in_floating:  // Вход без подтяжки, болтающийся (англ. float) в воздухе
                 gpioInit.GPIO_Mode  = GPIO_Mode_IN;
                 gpioInit.GPIO_OType = GPIO_OType_PP;    // ?
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_NOPULL; // ?
                 break;

            case PinMode::gpio_in_pulldown:  // Вход с подтяжкой к земле (англ. Pull-down)
                 gpioInit.GPIO_Mode  = GPIO_Mode_IN;
                 gpioInit.GPIO_OType = GPIO_OType_PP;    // ?
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_DOWN;
                 break;

            case PinMode::gpio_in_pullup:    // Вход с подтяжкой к питанию (англ. Pull-up)
                 gpioInit.GPIO_Mode  = GPIO_Mode_IN;
                 gpioInit.GPIO_OType = GPIO_OType_PP;    // ?
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_UP;
                 break;

            case PinMode::gpio_out_od:       // Выход с открытым стоком (англ. Open Drain)
                 gpioInit.GPIO_Mode  = GPIO_Mode_OUT;
                 gpioInit.GPIO_OType = GPIO_OType_OD;
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_UP;  // ? use internal pull-up? or set to GPIO_PuPd_NOPULL?
                 break;

            case PinMode::gpio_out_pp:       // Выход двумя состояниями (англ. Push-Pull — туда-сюда)
                 gpioInit.GPIO_Mode  = GPIO_Mode_OUT;
                 gpioInit.GPIO_OType = GPIO_OType_PP;
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_NOPULL;
                 break;

            case PinMode::alt_mode_od:       // Выход для альтернативных функций с открытым стоком
                 gpioInit.GPIO_Mode  = GPIO_Mode_AF;
                 gpioInit.GPIO_OType = GPIO_OType_OD;
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_UP;  // ? use internal pull-up? or set to GPIO_PuPd_NOPULL?
                 break;

            case PinMode::alt_mode_pp:       // Выход для альтернативных функций с двумя состояниями
                 gpioInit.GPIO_Mode  = GPIO_Mode_AF;
                 gpioInit.GPIO_OType = GPIO_OType_PP;
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_NOPULL;
                 break;

            case PinMode::alt_mode_input_floating:
                 gpioInit.GPIO_Mode  = GPIO_Mode_AF;
                 gpioInit.GPIO_OType = GPIO_OType_PP;
                 gpioInit.GPIO_PuPd  = GPIO_PuPd_NOPULL;
                 break;


            default:
                 UMBA_ASSERT_FAIL();
                 return;
        }

    #else 

        #error "MCU not supported"

    #endif
}




//-----------------------------------------------------------------------------
// GPIO_DeInit (GPIO_TypeDef *GPIOx) ???


inline
uint16_t gpioGetPortNo( GPIO_TypeDef * pt )
{
    #ifdef GPIOA
        if (pt==GPIOA) return 0;
    #endif
    #ifdef GPIOB
        if (pt==GPIOB) return 1;
    #endif
    #ifdef GPIOC
        if (pt==GPIOC) return 2;
    #endif
    #ifdef GPIOD
        if (pt==GPIOD) return 3;
    #endif
    #ifdef GPIOE
        if (pt==GPIOE) return 4;
    #endif
    #ifdef GPIOF
        if (pt==GPIOF) return 5;
    #endif
    #ifdef GPIOG
        if (pt==GPIOG) return 6;
    #endif
    #ifdef GPIOH
        if (pt==GPIOH) return 7;
    #endif
    #ifdef GPIOI
        if (pt==GPIOI) return 8;
    #endif
    #ifdef GPIOJ
        if (pt==GPIOJ) return 9;
    #endif
    #ifdef GPIOK
        if (pt==GPIOK) return 10;
    #endif
    #ifdef GPIOL
        if (pt==GPIOL) return 11;
    #endif
    #ifdef GPIOM
        if (pt==GPIOM) return 12;
    #endif
    #ifdef GPION
        if (pt==GPION) return 13;
    #endif
    #ifdef GPIOO
        if (pt==GPIOO) return 14;
    #endif
    #ifdef GPIOP
        if (pt==GPIOP) return 15;
    #endif

    UMBA_ASSERT_FAIL();

    return 0;
}

inline
GPIO_TypeDef* gpioNumberToPort( uint16_t n )
{
    switch(n)
    {
        case 0: 
                #ifdef GPIOA
                    return GPIOA;
                #else
                    break;
                #endif

        case 1: 
                #ifdef GPIOB
                    return GPIOB;
                #else
                    break;
                #endif

        case 2: 
                #ifdef GPIOC
                    return GPIOC;
                #else
                    break;
                #endif

        case 3: 
                #ifdef GPIOD
                    return GPIOD;
                #else
                    break;
                #endif

        case 4: 
                #ifdef GPIOE
                    return GPIOE;
                #else
                    break;
                #endif

        case 5: 
                #ifdef GPIOF
                    return GPIOF;
                #else
                    break;
                #endif

        case 6: 
                #ifdef GPIOG
                    return GPIOG;
                #else
                    break;
                #endif

        case 7: 
                #ifdef GPIOH
                    return GPIOH;
                #else
                    break;
                #endif

        case 8: 
                #ifdef GPIOI
                    return GPIOI;
                #else
                    break;
                #endif

        case 9: 
                #ifdef GPIOJ
                    return GPIOJ;
                #else
                    break;
                #endif

        case 10: 
                #ifdef GPIOK
                    return GPIOK;
                #else
                    break;
                #endif

        case 11: 
                #ifdef GPIOL
                    return GPIOL;
                #else
                    break;
                #endif

        case 12: 
                #ifdef GPIOM
                    return GPIOM;
                #else
                    break;
                #endif

        case 13: 
                #ifdef GPION
                    return GPION;
                #else
                    break;
                #endif

        case 14: 
                #ifdef GPIOO
                    return GPIOO;
                #else
                    break;
                #endif

        case 15: 
                #ifdef GPIOP
                    return GPIOP;
                #else
                    break;
                #endif

    };

    UMBA_ASSERT_FAIL();

    return 0;
}


inline
uint16_t periphGetNo( GPIO_TypeDef * pt )
{
    return gpioGetPortNo(pt);
}



//-----------------------------------------------------------------------------
#if defined(STM32F1_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<GPIO_TypeDef>( GPIO_TypeDef * pt )
    {
        return ClockBus::APB2;
    }
#elif defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<GPIO_TypeDef>( GPIO_TypeDef * pt )
    {
        // equal to STM32F4 AHB1
        return ClockBus::AHB; 
    }
#endif


#if defined(STM32F1_SERIES)


    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<GPIO_TypeDef>( GPIO_TypeDef * pt )
    {
        return RCC_APB2PeriphClockCmd;
    }

    inline
    uint32_t getPeriphClockGpioAltFunctionFlag( GPIO_TypeDef * pt )
    {
        return RCC_APB2Periph_AFIO;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<GPIO_TypeDef>( GPIO_TypeDef * pt )
    {
        #ifdef GPIOA
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOA, RCC_APB2Periph_GPIOA );
        #endif
        #ifdef GPIOB
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOB, RCC_APB2Periph_GPIOB );
        #endif
        #ifdef GPIOC
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOC, RCC_APB2Periph_GPIOC );
        #endif
        #ifdef GPIOD
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOD, RCC_APB2Periph_GPIOD );
        #endif
        #ifdef GPIOE
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOE, RCC_APB2Periph_GPIOE );
        #endif
        #ifdef GPIOF
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOF, RCC_APB2Periph_GPIOF );
        #endif
        #ifdef GPIOG
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOG, RCC_APB2Periph_GPIOG );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#elif defined(STM32F3_SERIES)

    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<GPIO_TypeDef>( GPIO_TypeDef * pt )
    {
        return RCC_AHBPeriphClockCmd;
    }

    inline
    uint32_t getPeriphClockGpioAltFunctionFlag( GPIO_TypeDef * pt )
    {
        return 0;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<GPIO_TypeDef>( GPIO_TypeDef * pt )
    {
        #ifdef GPIOA
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOA, RCC_AHBPeriph_GPIOA );
        #endif
        #ifdef GPIOB
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOB, RCC_AHBPeriph_GPIOB );
        #endif
        #ifdef GPIOC
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOC, RCC_AHBPeriph_GPIOC );
        #endif
        #ifdef GPIOD
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOD, RCC_AHBPeriph_GPIOD );
        #endif
        #ifdef GPIOE
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOE, RCC_AHBPeriph_GPIOE );
        #endif
        #ifdef GPIOF
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOF, RCC_AHBPeriph_GPIOF );
        #endif
        #ifdef GPIOG
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOG, RCC_AHBPeriph_GPIOG );
        #endif
        #ifdef GPIOH
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOH, RCC_AHBPeriph_GPIOH );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#elif defined(STM32F4_SERIES)

    #define GPIO_AF_0            ((uint8_t)0x00)
    #define GPIO_AF_1            ((uint8_t)0x01)
    #define GPIO_AF_2            ((uint8_t)0x02)
    #define GPIO_AF_3            ((uint8_t)0x03)
    #define GPIO_AF_4            ((uint8_t)0x04)
    #define GPIO_AF_5            ((uint8_t)0x05)
    #define GPIO_AF_6            ((uint8_t)0x06)
    #define GPIO_AF_7            ((uint8_t)0x07)
    #define GPIO_AF_8            ((uint8_t)0x08)
    #define GPIO_AF_9            ((uint8_t)0x09)
    #define GPIO_AF_10           ((uint8_t)0x0A)
    #define GPIO_AF_11           ((uint8_t)0x0B)
    #define GPIO_AF_12           ((uint8_t)0x0C)
    #define GPIO_AF_13           ((uint8_t)0x0D)
    #define GPIO_AF_14           ((uint8_t)0x0E)
    #define GPIO_AF_15           ((uint8_t)0x0F)


    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<GPIO_TypeDef>( GPIO_TypeDef * pt )
    {
        return RCC_AHB1PeriphClockCmd;
    }

    inline
    uint32_t getPeriphClockGpioAltFunctionFlag( GPIO_TypeDef * pt )
    {
        return 0;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<GPIO_TypeDef>( GPIO_TypeDef * pt )
    {
        #ifdef GPIOA
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOA, RCC_AHB1Periph_GPIOA );
        #endif
        #ifdef GPIOB
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOB, RCC_AHB1Periph_GPIOB );
        #endif
        #ifdef GPIOC
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOC, RCC_AHB1Periph_GPIOC );
        #endif
        #ifdef GPIOD
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOD, RCC_AHB1Periph_GPIOD );
        #endif
        #ifdef GPIOE
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOE, RCC_AHB1Periph_GPIOE );
        #endif
        #ifdef GPIOF
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOF, RCC_AHB1Periph_GPIOF );
        #endif
        #ifdef GPIOG
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOG, RCC_AHB1Periph_GPIOG );
        #endif
        #ifdef GPIOH
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOH, RCC_AHB1Periph_GPIOH );
        #endif
        #ifdef GPIOI
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOI, RCC_AHB1Periph_GPIOI );
        #endif
        #ifdef GPIOJ
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOJ, RCC_AHB1Periph_GPIOJ );
        #endif
        #ifdef GPIOK
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( GPIOK, RCC_AHB1Periph_GPIOK );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#endif


//-----------------------------------------------------------------------------
inline
void gpioInit( GPIO_TypeDef * pGpioPort, PinSpeed pinSpeed, PinMode pinMode, unsigned pinMask )
{
    initPeriphClock( pGpioPort, ENABLE );
    GPIO_InitTypeDef gpioInitStruct;
    gpioInitTypeDefInit( gpioInitStruct, pinSpeed, pinMode, pinMask );
    GPIO_Init(pGpioPort, &gpioInitStruct);
}

//-----------------------------------------------------------------------------
inline
void gpioInit( const GpioPinAddr &pinAddr, PinSpeed pinSpeed, PinMode pinMode )
{
    gpioInit( pinAddr.port, pinSpeed, pinMode, 1<<pinAddr.pinNo );
}

//-----------------------------------------------------------------------------

#include "gpio_pin_impl.h"









} // namespace traits
} // namespace periph
} // namespace umba

