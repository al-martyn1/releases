#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

//NOTE: the clock signal may have a small amplitude and may be close similar to noise




namespace umba
{
namespace periph
{
namespace traits
{


enum class McoMode
{
    disabled,

    #if defined(STM32F1_SERIES) 
        PA8_SYSCLK,
        SYSCLK = PA8_SYSCLK,
        PA8_HSI,
        PA8_HSE,
        PA8_PLL2,
        PLL2 = PA8_PLL2, // PLL divided by 2
    #elif defined(STM32F3_SERIES) 
        PA8_SYSCLK,
        SYSCLK = PA8_SYSCLK,
        PA8_HSI,
        PA8_HSE,
        PA8_PLL2,
        PLL2 = PA8_PLL2, // PLL divided by 2
    #elif defined(STM32F4_SERIES)
        // PA8 - MCO1  HSI/HSE/PLL, with prescaler
        // PC9 - MCO2  SYSCLK/PLL, with prescaler
        PC9_SYSCLK,
        SYSCLK = PC9_SYSCLK,
        PC9_HSE,
        PC9_PLL2,
        PA8_HSI,
        PA8_HSE,
        PA8_PLL2,
        PLL2 = PA8_PLL2, // PLL divided by 2
    #endif

    enabled = PLL2

};

// Not all working properly for F4
inline
void mcoConfigure( McoMode mode )
{
    #if defined(STM32F1_SERIES) 

        //*(__IO uint8_t *) CFGR_BYTE4_ADDRESS = RCC_MCO;

        gpioInit( UMBA_PINADDR_PA8, PinSpeed::high, PinMode::alt_mode_pp );
        RCC->CFGR &= ~(0xF << 24);

        switch(mode)
        {
            case McoMode::disabled:
                 break;
            case McoMode::PA8_SYSCLK:
                 RCC->CFGR |= (4<<24);
                 break;
            case McoMode::PA8_HSI:
                 RCC->CFGR |= (5<<24);
                 break;
            case McoMode::PA8_HSE:
                 RCC->CFGR |= (6<<24);
                 break;
            case McoMode::PA8_PLL2:
                 RCC->CFGR |= (7<<24);
                 break;
            default:
                 UMBA_ASSERT_FAIL();
        }

    #elif defined(STM32F3_SERIES) 

        //NOTE: STM32F303x6, STM32F398xE not defined automatically
        //NOTE: Affect on PLL/2 behavior, non-critical issue

        // STM32F303x6 STM32F303x8 STM32F328x8 STM32F303xD STM32F303xE STM32F398xE

        gpioInit( UMBA_PINADDR_PA8, PinSpeed::high, PinMode::alt_mode_pp );
        GPIO_PinAFConfig( GPIOA, 8, GPIO_AF_0 );
        RCC->CFGR &= ~(0x7 << 24);

        switch(mode)
        {
            case McoMode::disabled:
                 break;
            case McoMode::PA8_SYSCLK:
                 RCC->CFGR |= (4<<24);
                 break;
            case McoMode::PA8_HSI:
                 RCC->CFGR |= (5<<24);
                 break;
            case McoMode::PA8_HSE:
                 RCC->CFGR |= (6<<24);
                 break;
            case McoMode::PA8_PLL2:
                 #if defined(STM32F303x6) || defined(STM32F303x8) || defined(STM32F328x8) || defined(STM32F303xD) || defined(STM32F303xE) || defined(STM32F398xE)
                 RCC->CFGR &= ~(7<<28); // MCOPRE
                 RCC->CFGR |= 1<<28;
                 #else
                 RCC->CFGR &= ~(1u<<31); // PLLNODIV
                 #endif
                 RCC->CFGR |= (7<<24); // PLL
                 break;
            default:
                 UMBA_ASSERT_FAIL();
        }

    #elif defined(STM32F4_SERIES)

        RCC->CFGR &= ~(0x7u << 27); // MCO2 PRE - no division
        RCC->CFGR &= ~(0x3u << 30); // MCO2
        RCC->CFGR &= ~(0x7u << 24); // MCO1 PRE - no division
        RCC->CFGR &= ~(0x3u << 21); // MCO1

        // undocumented, found in spl
        RCC->CFGR &= ~(0x1u << 8); // clear MCO1 enable bit
        RCC->CFGR &= ~(0x1u << 9); // clear MCO2 enable bit

        // PA8 - MCO1  HSI/HSE/PLL, with prescaler
        // PC9 - MCO2  SYSCLK/PLL, with prescaler
        switch(mode)
        {
            case McoMode::disabled:
                 /*
                 if ( ((GPIOC->MODER >> 18) & x03) == 2 ) // is PC9 in alternate F mode?
                      GPIOC->MODER &= ~(3<<18); // clear mode to initial reset state (input)
                 if ( ((GPIOA->MODER >> 16) & x03) == 2 ) // is PA9 in alternate F mode?
                      GPIOA->MODER &= ~(3<<16); // clear mode to initial reset state (input)
                 */
                 break;
            case McoMode::PC9_SYSCLK:
                 gpioInit( UMBA_PINADDR_PC9, PinSpeed::high, PinMode::alt_mode_pp );
                 GPIO_PinAFConfig( GPIOC, 9, GPIO_AF_0 );
                 RCC->CFGR |= 0x1 << 9; // set MCO2 enable bit
                 //RCC->CFGR |= (4<<24);
                 break;
            case McoMode::PC9_HSE:
                 gpioInit( UMBA_PINADDR_PC9, PinSpeed::high, PinMode::alt_mode_pp );
                 GPIO_PinAFConfig( GPIOC, 9, GPIO_AF_0 );
                 RCC->CFGR |= (2u<<30); // MCO2
                 RCC->CFGR |= 0x1 << 9; // set MCO2 enable bit
                 break;
            case McoMode::PC9_PLL2:
                 RCC->CFGR |= (4u<<27); // set MCO2 PRE to 4 - div by 2
                 RCC->CFGR |= (3u<<30); // set MCO2 to 3
                 gpioInit( UMBA_PINADDR_PC9, PinSpeed::high, PinMode::alt_mode_pp );
                 GPIO_PinAFConfig( GPIOC, 9, GPIO_AF_0 );
                 RCC->CFGR |= 0x1 << 9; // set MCO2 enable bit
                 break;
            case McoMode::PA8_HSI:
                 gpioInit( UMBA_PINADDR_PA8, PinSpeed::high, PinMode::alt_mode_pp );
                 GPIO_PinAFConfig( GPIOA, 8, GPIO_AF_0 );
                 RCC->CFGR |= 0x1 << 8; // set MCO1 enable bit
                 break;
            case McoMode::PA8_HSE:
                 RCC->CFGR |= (2<<21);
                 gpioInit( UMBA_PINADDR_PA8, PinSpeed::high, PinMode::alt_mode_pp );
                 GPIO_PinAFConfig( GPIOA, 8, GPIO_AF_0 );
                 RCC->CFGR |= 0x1 << 8; // set MCO1 enable bit
                 break;
            case McoMode::PA8_PLL2:
                 RCC->CFGR |= (4u<<24); // set MCO1 PRE to 4 - div by 2
                 RCC->CFGR |= (3u<<21); // set MCO1 to 3
                 gpioInit( UMBA_PINADDR_PA8, PinSpeed::high, PinMode::alt_mode_pp );
                 GPIO_PinAFConfig( GPIOA, 8, GPIO_AF_0 );
                 RCC->CFGR |= 0x1 << 8; // set MCO1 enable bit
                 break;
            default:
                 UMBA_ASSERT_FAIL();

            //*(__IO uint32_t *) RCC_CFGR_MCO1EN_BB = (uint32_t)NewState;

        }
    #endif



}




} // namespace traits
} // namespace periph
} // namespace umba
