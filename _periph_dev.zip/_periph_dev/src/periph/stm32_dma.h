#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

// Periph/Channels mapping
// F4 10.3.3 Channel selection
// F3 13.4.7 DMA request mapping
// F1 13.3.7 DMA request mapping


// F3 http://mkprog.ru/mikrokontrollery-stm32/stm32-dlya-nachinayushhih-urok-6-dma-stm32.html
// F3 https://hubstub.ru/stm32/169-stm32-dma-mem2mem.html
// F1 http://easyelectronics.ru/kontroller-pryamogo-dostupa-k-pamyati-dma-kontrollera-stm32.html
// F1 https://hubstub.ru/stm32/79-stm32-sohranenie-dannyh-acp-s-pomoschyu-dma.html
// https://www.st.com/content/ccc/resource/technical/document/application_note/27/46/7c/ea/2d/91/40/a9/DM00046011.pdf/files/DM00046011.pdf/jcr:content/translations/en.DM00046011.pdf
// F1 UART https://microtechnics.ru/stm32-uchebnyj-kurs-dma/
// F1 http://blog.myelectronics.com.ua/stm32-%D0%BF%D1%80%D1%8F%D0%BC%D0%BE%D0%B9-%D0%B4%D0%BE%D1%81%D1%82%D1%83%D0%BF-%D0%BA-%D0%BF%D0%B0%D0%BC%D1%8F%D1%82%D0%B8-dma/
// F4 ADC http://ziblog.ru/2013/04/29/prostoy-primer-atsp-pdp-adc-dma-dlya-stm32f4-discovery.html



// See stm32_dma.cpp for details
#if defined(STM32F10X_HD) || defined(STM32F10X_XL)
    #define STM32F1_DMA2_CHANNEL_4_5_SHARE
    #define STM32F1_DMA2_CHANNEL_4_NAME_4_5
#elif defined(STM32F10X_HD_VL)
    #define STM32F1_DMA2_CHANNEL_4_5_SHARE_OPTIONAL
    // Shared or not defined by AFIO_MAPR2 reg bit AFIO_MAPR2_MISC_REMAP ((uint32_t)0x00002000)
    #define STM32F1_DMA2_CHANNEL_4_NAME_4_5
#endif



namespace umba
{
namespace periph
{
namespace traits
{


//---------------------------------------------------------
template <>
inline
ClockBus periphClockGetBus<DMA_TypeDef>( DMA_TypeDef * pt )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)
    return ClockBus::AHB;
    #elif defined(STM32F4_SERIES)
    return ClockBus::AHB1;
    #endif
}

//---------------------------------------------------------
template <>
inline
PerifClockFunctionPtr periphClockGetFunction<DMA_TypeDef>( DMA_TypeDef * pt )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)
    return RCC_AHBPeriphClockCmd;
    #elif defined(STM32F4_SERIES)
    return RCC_AHB1PeriphClockCmd;
    #endif
}

//---------------------------------------------------------
template <>
inline
uint32_t periphClockGetFlag<DMA_TypeDef>( DMA_TypeDef * pt )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)
        #if defined(DMA1) && defined(RCC_AHBPeriph_DMA1)
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( DMA1, RCC_AHBPeriph_DMA1 );
        #endif
        #if defined(DMA2) && defined(RCC_AHBPeriph_DMA2)
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( DMA2, RCC_AHBPeriph_DMA2 );
        #endif
    #elif defined(STM32F4_SERIES)
        #if defined(DMA1) && defined(RCC_AHB1Periph_DMA1)
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( DMA1, RCC_AHB1Periph_DMA1 );
        #endif
        #if defined(DMA2) && defined(RCC_AHB1Periph_DMA2)
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( DMA2, RCC_AHB1Periph_DMA2 );
        #endif
    #endif

    UMBA_ASSERT_FAIL();

    return 0;
}

//---------------------------------------------------------
#if defined(STM32F4_SERIES) || defined(DMA2D)

    // 11 Chrom-Art Accelerator™ controller (DMA2D)
    // https://www.st.com/content/ccc/resource/technical/document/application_note/group0/17/82/73/f8/b8/8a/47/c7/DM00338361/files/DM00338361.pdf/jcr:content/translations/en.DM00338361.pdf
    // https://www.compel.ru/wordpress/wp-content/uploads/2013/11/1_LTDC_ChromeART.pdf

    template <>
    inline
    ClockBus periphClockGetBus<DMA2D_TypeDef>( DMA2D_TypeDef * pt )
    {
        return ClockBus::AHB1;
    }

    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<DMA2D_TypeDef>( DMA2D_TypeDef * pt )
    {
        return RCC_AHB1PeriphClockCmd;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<DMA2D_TypeDef>( DMA2D_TypeDef * pt )
    {
        #if defined(DMA2D) && defined(RCC_AHB1Periph_DMA2D)
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( DMA2D, RCC_AHB1Periph_DMA2D );
        #endif

        UMBA_ASSERT_FAIL();
       
        return 0;
    }

#endif

//---------------------------------------------------------





#include "umba/optimize_speed.h"
// for copypaste both at one time
//#include "umba/optimize_pop.h"

//---------------------------------------------------------
UMBA_FORCE_INLINE( DMA_TypeDef* dmaGetAddr( DmaController dma ) )
{
    #ifdef DMA1
    if (dma==dma1) return DMA1;
    #endif
    #ifdef DMA2
    if (dma==dma2) return DMA2;
    #endif

    UMBA_ASSERT_FAIL();

    return (DMA_TypeDef*)0;
}

//---------------------------------------------------------
UMBA_FORCE_INLINE( DmaController dmaGetController( DMA_TypeDef* pDma ) )
{
    #ifdef DMA1
    if (pDma==DMA1) return dma1;
    #endif
    #ifdef DMA2
    if (pDma==DMA2) return dma2;
    #endif

    UMBA_ASSERT_FAIL();

    return dma1;
}

#include "umba/optimize_pop.h"

//---------------------------------------------------------
inline
DmaChannel dmaGetMinChannel( DmaController dma )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
    switch(dma)
    {
        case dma1: return dmaChannel1;
        case dma2: return dmaChannel1;
        default:   return dmaChannel7;
    }
    #elif defined(STM32F4_SERIES)
    return dmaChannel0;
    #endif
}

inline
DmaChannel dmaGetMaxChannel( DmaController dma )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
    switch(dma)
    {
        case dma1: return dmaChannel7;
        case dma2: return dmaChannel5;
        default:   return dmaChannel0;
    }
    #elif defined(STM32F4_SERIES)
    return dmaChannel7;
    #endif
}

inline
size_t dmaGetNumChannels( DmaController dma )
{
    return (size_t)dmaGetMaxChannel( dma ) - (size_t)dmaGetMinChannel( dma );
}

inline
bool dmaIsValidChannel( DmaController dma, DmaChannel ch )
{
    DmaChannel chMin = dmaGetMinChannel( dma );
    DmaChannel chMax = dmaGetMaxChannel( dma );
    return (ch>=dmaGetMinChannel( dma )) && (ch<=(dmaGetMaxChannel(dma)));
}

inline
bool dmaIsValidChannel( DMA_TypeDef* pDma, DmaChannel ch )
{
    return dmaIsValidChannel( dmaGetController(pDma), ch );
}

inline // for IRQ table
size_t dmaGetChannelIndex( DmaController dma, DmaChannel ch )
{
    size_t dmaN    = (size_t)dma;
    size_t dmaCur  = (size_t)dma1;
    size_t sch     = (size_t)ch;
    size_t res     = 0;

    for(; dmaCur<dmaN; ++dmaCur)
    {
        res += dmaGetNumChannels( (DmaController)dmaCur );
    }

    #if defined(STM32F10X_HD) || defined(STM32F10X_XL)
        // unconditional share 4th vector for 4th and 5th channels of DMA2
        if (dma==dma2 && sch>4)
            sch--;
    #elif defined(STM32F10X_HD_VL)
        // conditional share 4th vector for 4th and 5th channels
        if (dma==dma2 && sch>4)
        {
            if ( (AFIO->MAPR2 & AFIO_MAPR2_MISC_REMAP) == 0) // ((uint32_t)0x00002000)
                sch--;
        }
    #else
        // unconditional use all channels
    #endif

    return res + (sch - (size_t)dmaGetMinChannel( dma ));
}

inline // for IRQ table
size_t dmaGetChannelIndex( DMA_TypeDef* pDma, DmaChannel ch )
{
    return dmaGetChannelIndex( dmaGetController(pDma), ch );
    
}

//---------------------------------------------------------



//---------------------------------------------------------
// As declared in description of DMA IRQ status reg/clear reg
#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 

    // Same for channel ctrl flags
    constexpr uint16_t dmaChannelEventGlobal               = 0x01; // global interrupt flag
    constexpr uint16_t dmaChannelEventTransferComplete     = 0x02; // Channel x transfer complete flag
    constexpr uint16_t dmaChannelEventHalfComplete         = 0x04; // Channel x half transfer flag
    constexpr uint16_t dmaChannelEventTransferError        = 0x08; // Channel x transfer error flag

    constexpr uint16_t dmaChannelEventMaskAll              = 0x01 | 0x02 | 0x04 | 0x08;

#elif defined(STM32F4_SERIES)

    // Shift >>1 to make channel cfg flags
    constexpr uint16_t dmaChannelEventFifoError            = 0x01; // Stream x FIFO error interrupt flag
    constexpr uint16_t dmaChannelEventDirectError          = 0x04; // Stream x direct mode error interrupt flag
    constexpr uint16_t dmaChannelEventTransferError        = 0x08; // Stream x transfer error interrupt flag
    constexpr uint16_t dmaChannelEventHalfComplete         = 0x10; // Stream x half transfer interrupt flag
    constexpr uint16_t dmaChannelEventTransferComplete     = 0x20; // Stream x transfer complete interrupt flag

    constexpr uint16_t dmaChannelEventMaskAll              = 0x01 | 0x04 | 0x08 | 0x10 | 0x20;

#endif


#if defined(STM32F4_SERIES)

    typedef DMA_Stream_TypeDef DMA_Channel_TypeDef;

#endif


#include "umba/optimize_speed.h"

//---------------------------------------------------------
// convert to HW bits
UMBA_FORCE_INLINE( uint32_t dmaMakeEventsHwMask( DmaChannel ch, uint16_t dmaChannelEventFlags ) )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
        return ((uint32_t)dmaChannelEventFlags) << ((((uint16_t)ch) - 1)*4);
    #elif defined(STM32F4_SERIES)
        const uint32_t uch = (uint32_t)ch;
        const uint32_t val =  dmaChannelEventFlags;
        return (val<<((uch&1)*6)) << (uch&2?16:0);
    #else
    UMBA_ASSERT_FAIL();
    return 0;
    #endif
}
// convert from HW bits
UMBA_FORCE_INLINE( uint16_t dmaMakeEventsFromHwMask( DmaChannel ch, uint32_t regVal ) )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
        return (uint16_t)((regVal >> ((((uint16_t)ch) - 1)*4)) & dmaChannelEventMaskAll);
    #elif defined(STM32F4_SERIES)
        const uint32_t uch = (uint32_t)ch;
        //const uint32_t val =  dmaChannelEventFlags;
        regVal >>= (uch&2?16:0);
        regVal >>= ((uch&1)*6);
        return regVal;
        //return (uint16_t)((regVal >> (((((uint16_t)ch))&3)*6)) & dmaChannelEventMaskAll);
    #else
    UMBA_ASSERT_FAIL();
    return 0;
    #endif
}


inline
__IO uint32_t* dmaGetEventsRegAddr( DMA_TypeDef *DMAx, DmaChannel ch )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
    return & DMAx->ISR;
    #elif defined(STM32F4_SERIES)
    return ((__IO uint32_t*)DMAx + ((((uint16_t)ch)>>2)&1));
    #else
    UMBA_ASSERT_FAIL();
    return 0;
    #endif
}

inline
__IO uint32_t* dmaGetEventsClearRegAddr( DMA_TypeDef *DMAx, DmaChannel ch )
{
    
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
    return dmaGetEventsRegAddr(DMAx, ch) + 1;
    #elif defined(STM32F4_SERIES)
    return dmaGetEventsRegAddr(DMAx, ch) + 2;
    #else
    UMBA_ASSERT_FAIL();
    return 0;
    #endif
}

//---------------------------------------------------------

// return true if one of taken flags set
inline
bool dmaCheckEvents( DMA_TypeDef *DMAx, DmaChannel ch, uint16_t dmaChannelEventFlags )
{
    return (* dmaGetEventsRegAddr( DMAx, ch )) & dmaMakeEventsHwMask(ch, dmaChannelEventFlags) ? true : false;
}

inline
bool dmaCheckEvents( DmaController dma, DmaChannel ch, uint16_t dmaChannelEventFlags )
{
    return dmaCheckEvents( dmaGetAddr(dma), ch, dmaChannelEventFlags );
}

inline
bool dmaCheckEvents( DmaControllerChannel dmaX_ChannelY, uint16_t dmaChannelEventFlags )
{
    return dmaCheckEvents( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                         , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                         , dmaChannelEventFlags
                         );
}

inline
void dmaWaitEvents( DMA_TypeDef *DMAx, DmaChannel ch, uint16_t dmaChannelEventFlags )
{
    while( !(* dmaGetEventsRegAddr( DMAx, ch )) & dmaMakeEventsHwMask(ch, dmaChannelEventFlags) );
}

inline
void dmaWaitEvents( DmaController dma, DmaChannel ch, uint16_t dmaChannelEventFlags )
{
    dmaWaitEvents( dmaGetAddr(dma), ch, dmaChannelEventFlags );
}

inline
void dmaWaitEvents( DmaControllerChannel dmaX_ChannelY, uint16_t dmaChannelEventFlags )
{
    dmaWaitEvents( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                 , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                 , dmaChannelEventFlags
                 );
}

//---------------------------------------------------------
// Implementation will be later
void dmaEndWaitEvents( DMA_TypeDef *DMAx, DmaChannel ch);
void dmaEndWaitEvents( DmaController dma, DmaChannel ch );
void dmaEndWaitEvents( DmaControllerChannel dmaX_ChannelY );

//---------------------------------------------------------



//---------------------------------------------------------
// return true if all of taken flags set
inline
bool dmaCheckAllEvents( DMA_TypeDef *DMAx, DmaChannel ch, uint16_t dmaChannelEventFlags )
{
    const uint16_t mask = dmaMakeEventsHwMask(ch, dmaChannelEventFlags);
    return ( (* dmaGetEventsRegAddr( DMAx, ch )) & mask) == mask ? true : false;
}

inline
bool dmaCheckAllEvents( DmaController dma, DmaChannel ch, uint16_t dmaChannelEventFlags )
{
    return dmaCheckAllEvents( dmaGetAddr(dma), ch, dmaChannelEventFlags );
}

inline
bool dmaCheckAllEvents( DmaControllerChannel dmaX_ChannelY, uint16_t dmaChannelEventFlags )
{
    return dmaCheckAllEvents( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                            , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                            , dmaChannelEventFlags
                            );
}

//---------------------------------------------------------
inline
void dmaClearEvents( DMA_TypeDef *DMAx, DmaChannel ch, uint16_t dmaChannelEventFlags )
{
    * dmaGetEventsRegAddr( DMAx, ch ) = dmaMakeEventsHwMask(ch, dmaChannelEventFlags);
}

inline
void dmaClearEvents( DmaController dma, DmaChannel ch, uint16_t dmaChannelEventFlags )
{
    dmaClearEvents( dmaGetAddr(dma), ch, dmaChannelEventFlags );
}

inline
void dmaClearEvents( DmaControllerChannel dmaX_ChannelY, uint16_t dmaChannelEventFlags )
{
    dmaClearEvents( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                  , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                  , dmaChannelEventFlags
                  );
}

//---------------------------------------------------------
#if defined(STM32F4_SERIES)

    #ifdef CCR
        #error "CCR already defined"
    #endif
    #define  CCR     CR

    #ifdef CNDTR
        #error "CNDTR already defined"
    #endif
    #define  CNDTR   NDTR

    #ifdef CPAR
        #error "CPAR already defined"
    #endif
    #define  CPAR    PAR

    #ifdef CMAR
        #error "CMAR already defined"
    #endif
    #define  CMAR    M0AR

#endif



template<>
inline
void periphEnable< DMA_Channel_TypeDef, DmaOnOff >( DMA_Channel_TypeDef *DMACHx, DmaOnOff onOff )
{
    if (onOff!=dmaOff)
        DMACHx->CCR |= 1;
    else
        DMACHx->CCR &= ~1;
}

template< >
inline
bool periphIsEnabled< DMA_Channel_TypeDef >( DMA_Channel_TypeDef * DMACHx )
{
    return DMACHx->CCR & 1 ? true : false;
}

template< >
inline
void periphWaitDisabled< DMA_Channel_TypeDef >( DMA_Channel_TypeDef * DMACHx )
{
    while( DMACHx->CCR & 1);
}



#include "umba/optimize_pop.h"

//---------------------------------------------------------
inline
DMA_Channel_TypeDef* dmaGetChannelAddr( DMA_TypeDef *DMAx, DmaChannel ch )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
    //uint16_t chIdx = ( (uint16_t)ch ) - 1;
    return (DMA_Channel_TypeDef*)(( (__IO uint8_t*)DMAx ) + 0x08 + 20 * ( ( (uint16_t)ch ) - 1 ));
    //return (DMA_Channel_TypeDef*)(( (__IO uint32_t*)DMAx ) + 0x08 + 20 * ( ( (uint16_t)ch ) - 1 ));
    #elif defined(STM32F4_SERIES)
    return (DMA_Channel_TypeDef*)(((__IO uint8_t*)DMAx) + 0x10 + 0x18 * ((uint16_t)ch));
    #else
    UMBA_ASSERT_FAIL();
    return (DMA_Channel_TypeDef*)0;
    #endif
}

inline
DMA_Channel_TypeDef* dmaGetChannelAddr( DmaController dma, DmaChannel ch )
{
    return dmaGetChannelAddr( dmaGetAddr(dma), ch );
}

inline
DMA_Channel_TypeDef* dmaGetChannelAddr( DmaControllerChannel dmaX_ChannelY )
{
    return dmaGetChannelAddr( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                            , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                            );
}

//---------------------------------------------------------




//---------------------------------------------------------
UMBA_FORCE_INLINE( void dmaEndWaitEvents( DMA_TypeDef *DMAx, DmaChannel ch) )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
    #elif defined(STM32F4_SERIES)
    periphEnable( dmaGetChannelAddr( DMAx, ch ), dmaOff );
    #else
    UMBA_ASSERT_FAIL();
    #endif
}

UMBA_FORCE_INLINE( void dmaEndWaitEvents( DmaController dma, DmaChannel ch ) )
{
    dmaEndWaitEvents( dmaGetAddr(dma), ch );
}

UMBA_FORCE_INLINE( void dmaEndWaitEvents( DmaControllerChannel dmaX_ChannelY ) )
{
    dmaEndWaitEvents( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                    , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                    );
}

//---------------------------------------------------------





//---------------------------------------------------------
// burst - https://electronix.ru/forum/index.php?app=forums&module=forums&controller=topic&id=117643
// http://www.cyberforum.ru/arm/thread2090092.html

//---------------------------------------------------------
// This doesn't enable DMA Channel after its configuration
// F4 See 10.3.17 Stream configuration procedure
inline
void dmaInitBase( DMA_TypeDef *DMAx, DmaChannel ch
                , void *memAddr, void *periphAddr
                , DmaChannelPriorityLevel priorityLevel
                , uint32_t     hwChannel
                , DmaSize      itemSize
                , size_t       numOfDataItems
                , DmaDirection dirRxTx
                , DmaIncMode   incMem     = dmaIncOn
                , DmaIncMode   incPeriph  = dmaIncOff
                , DmaCircMode  circMode   = dmaCircOff
                )
{
    UMBA_ASSERT( isValidDmaSize( itemSize ) );
    UMBA_ASSERT( dmaIsValidChannel( DMAx, ch ) );

    initPeriphClock( DMAx, ENABLE );

    DMA_Channel_TypeDef* DMACHx = dmaGetChannelAddr( DMAx, ch );

    if ( periphIsEnabled(DMACHx) )
    {
        periphEnable( DMACHx, dmaOff );
        periphWaitDisabled(DMACHx);
    }

    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 

        //--------------------
        /*
            Bit 14 MEM2MEM: Memory to memory mode
            This bit is set and cleared by software.
            0: Memory to memory mode disabled
            1: Memory to memory mode enabled
           
            Bit 4 DIR: Data transfer direction
            This bit is set and cleared by software.
            0: Read from peripheral
            1: Read from memory

            enum DmaDirection
            {
                dmaRx               = 0, // from periph to mem
                dmaDirPeriphToMem   = 0,
            
                dmaTx               = 1,  // from mem to periph
                dmaDirMemToPeriph   = 1
            };
        */

        DMACHx->CCR &= ~( (1<<14) | (1<<4) );  // Clear Bit 14 MEM2MEM | Bit 4 DIR

        if (dirRxTx==dmaDirMemMemMode)
            DMACHx->CCR |= (1<<14);
        else
            DMACHx->CCR |= (((uint32_t)dirRxTx) & 1)<<4;
        //--------------------

        constexpr uint32_t PL_shift    = 12; // Bits 13:12 PL[1:0]: Channel priority level
        constexpr uint32_t MSIZE_shift = 10; // Bits 11:10 MSIZE[1:0]: Memory size
        constexpr uint32_t PSIZE_shift =  8; // Bits 9:8 PSIZE[1:0]: Peripheral size
        constexpr uint32_t MINC_shift  =  7; // Bit 7 MINC: Memory increment mode
        constexpr uint32_t PINC_shift  =  6; // Bit 6 PINC: Peripheral increment mode
        constexpr uint32_t CIRC_shift  =  5; // Bit 5 CIRC: Circular mode


    #elif defined(STM32F4_SERIES)

        UMBA_ASSERT( !( dirRxTx==dmaDirMemMemMode && dmaGetController(DMAx)!=dma2 ) );

        DMACHx->M1AR = 0;

        DMACHx->FCR &= ~( (1<<7) | (1<<2) | (3) );  // Clear Bit 7 FEIE | Bit 2 DMDIS | Bits 1:0 FTH[1:0]
        // FIFO or direct mode - Bit 2 DMDIS: Direct mode disable
        // 0: Direct mode enabled (FIFO enabled)
        // Auto set if mem to mem mode selected

        // set CHSEL
        DMACHx->CR &= ~(7<<25);
        DMACHx->CR |= (((uint32_t)hwChannel) & 0x07) << 25;


        //--------------------
        /*
            00: Peripheral-to-memory
            01: Memory-to-peripheral
            10: Memory-to-memory
            11: reserved        

            enum DmaDirection
            {
                dmaRx               = 0, // from periph to mem
                dmaDirPeriphToMem   = 0,
            
                dmaTx               = 1,  // from mem to periph
                dmaDirMemToPeriph   = 1
            };
        */

        DMACHx->CR &= ~(3<<6);  // Clear Bits 7:6 DIR[1:0]: Data transfer direction

        DMACHx->CR &= ~(2<<6);
        if (dirRxTx==dmaDirMemMemMode)
            DMACHx->CR |= 2<<6;
        else
            DMACHx->CR |= (((uint32_t)dirRxTx) & 1)<<6;
        //--------------------


        // Configure DMA channel max compatible with F1-F3 series DMA behavior

        DMACHx->CR &= ~(3<<23); // Clear Bits 24:23 MBURST: Memory burst transfer configuration - 00: single transfer

        DMACHx->CR &= ~(3<<21); // Clear Bits 22:22 PBURST[1:0]: Peripheral burst transfer configuration - 00: single transfer

        DMACHx->CR &= ~(1<<19); // Clear Bit 19 CT: Current target (only in double buffer mode) - 0: The current target memory is Memory 0

        DMACHx->CR &= ~(1<<18); // Clear Bit 18 DBM: Double buffer mode - 0: No buffer switching at the end of transfer

        DMACHx->CR &= ~(1<<15); // Clear Bit 15 PINCOS: Peripheral increment offset size - 0: The offset size for the peripheral address calculation is linked to the PSIZE

        DMACHx->CR &= ~(1<<5);  // Clear Bit 5 PFCTRL: Peripheral flow controller - 0: The DMA is the flow controller


        constexpr uint32_t PL_shift    = 16; // Bits 17:16 PL[1:0]: Priority level
        constexpr uint32_t MSIZE_shift = 13; // Bits 14:13 MSIZE[1:0]: Memory data size
        constexpr uint32_t PSIZE_shift = 11; // Bits 12:11 PSIZE[1:0]: Peripheral data size
        constexpr uint32_t MINC_shift  = 10; // Bit 10 MINC: Memory increment mode
        constexpr uint32_t PINC_shift  =  9; // Bit 9 PINC: Peripheral increment mode
        constexpr uint32_t CIRC_shift  =  8; // Bit 8 CIRC: Circular mode

    #endif

    DMACHx->CCR &= ~(3<<PL_shift);
    DMACHx->CCR |=  (((uint32_t)priorityLevel)&3)<<PL_shift;

    DMACHx->CCR &= ~( (3<<MSIZE_shift) | (3<<PSIZE_shift));
    DMACHx->CCR |=    ((((uint32_t)itemSize)&3)<<MSIZE_shift) | ((((uint32_t)itemSize)&3)<<PSIZE_shift);

    DMACHx->CCR &=~(       (1   <<MINC_shift) |            (1   <<PINC_shift) );
    DMACHx->CCR |= ((incMem?1:0)<<MINC_shift) | ((incPeriph?1:0)<<PINC_shift);

    DMACHx->CCR &= ~(         1   <<CIRC_shift);
    DMACHx->CCR |=  (circMode?1:0)<<CIRC_shift;


    DMACHx->CNDTR = (uint32_t)numOfDataItems;
    DMACHx->CPAR  = (uint32_t)periphAddr;
    DMACHx->CMAR  = (uint32_t)memAddr;

}

//---------------------------------------------------------
inline
void dmaInitBase( DmaController dma, DmaChannel ch
                , void *memAddr, void *periphAddr
                , DmaChannelPriorityLevel priorityLevel
                , uint32_t     hwChannel
                , DmaSize      itemSize
                , size_t       numOfDataItems
                , DmaDirection dirRxTx
                , DmaIncMode   incMem     = dmaIncOn
                , DmaIncMode   incPeriph  = dmaIncOff
                , DmaCircMode  circMode   = dmaCircOff
                )
{
    dmaInitBase( dmaGetAddr(dma), ch
               , memAddr, periphAddr
               , priorityLevel
               , hwChannel
               , itemSize
               , numOfDataItems
               , dirRxTx
               , incMem     
               , incPeriph  
               , circMode   
               );
}

//---------------------------------------------------------
inline
void dmaInitBase( DmaControllerChannel dmaX_ChannelY
                , void *memAddr, void *periphAddr
                , DmaChannelPriorityLevel priorityLevel
                , uint32_t     hwChannel
                , DmaSize      itemSize
                , size_t       numOfDataItems
                , DmaDirection dirRxTx
                , DmaIncMode   incMem     = dmaIncOn
                , DmaIncMode   incPeriph  = dmaIncOff
                , DmaCircMode  circMode   = dmaCircOff
                )
{
    dmaInitBase( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
               , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
               , memAddr, periphAddr
               , priorityLevel
               , hwChannel
               , itemSize
               , numOfDataItems
               , dirRxTx
               , incMem     
               , incPeriph  
               , circMode   
               );
}

//---------------------------------------------------------




//---------------------------------------------------------
#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 

inline 
IRQn dmaGetIRQn( DmaController dma, DmaChannel ch )
{
    switch(dma)
       {
        case dma1: return (IRQn)( (unsigned)DMA1_Channel1_IRQn + (((unsigned)ch) - 1) );

        case dma2:

            #if defined(STM32F1_DMA2_CHANNEL_4_5_SHARE)

                // unconditional share 4th vector for 4th and 5th channels
                if ((unsigned)ch >= (unsigned)dmaChannel4)
                    return (IRQn)(          56u                + 3);
                else
                    return (IRQn)(          56u                + (((unsigned)ch) - 1) );

            #elif defined(STM32F1_DMA2_CHANNEL_4_5_SHARE_OPTIONAL)

                // conditional share 4th vector for 4th and 5th channels
                if ((unsigned)ch >= (unsigned)dmaChannel4)
                {
                    if ( (AFIO->MAPR2 & AFIO_MAPR2_MISC_REMAP) != 0) // ((uint32_t)0x00002000)
                        return (IRQn)(      56u                + (((unsigned)ch) - 1) );
                    else
                        return (IRQn)(      56u                + 3);
                }
                else
                    return (IRQn)(          56u                + (((unsigned)ch) - 1) );

            #else

                // unconditional use all five channels
                return (IRQn)(              56u                + (((unsigned)ch) - 1) );

            #endif

        default:
                UMBA_ASSERT_FAIL();
                return (IRQn)0;
       }
}

#elif defined(STM32F4_SERIES)

inline 
IRQn dmaGetIRQn( DmaController dma, DmaChannel ch )
{
     switch( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma, ch ) )
     {
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma1, dmaChannel0 ): return (IRQn)11; // DMA1_Stream0_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma1, dmaChannel1 ): return (IRQn)12; // DMA1_Stream1_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma1, dmaChannel2 ): return (IRQn)13; // DMA1_Stream2_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma1, dmaChannel3 ): return (IRQn)14; // DMA1_Stream3_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma1, dmaChannel4 ): return (IRQn)15; // DMA1_Stream4_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma1, dmaChannel5 ): return (IRQn)16; // DMA1_Stream5_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma1, dmaChannel6 ): return (IRQn)17; // DMA1_Stream6_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma1, dmaChannel7 ): return (IRQn)47; // DMA1_Stream7_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma2, dmaChannel0 ): return (IRQn)56; // DMA2_Stream0_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma2, dmaChannel1 ): return (IRQn)57; // DMA2_Stream1_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma2, dmaChannel2 ): return (IRQn)58; // DMA2_Stream2_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma2, dmaChannel3 ): return (IRQn)59; // DMA2_Stream3_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma2, dmaChannel4 ): return (IRQn)60; // DMA2_Stream4_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma2, dmaChannel5 ): return (IRQn)68; // DMA2_Stream5_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma2, dmaChannel6 ): return (IRQn)69; // DMA2_Stream6_IRQn
         case UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma2, dmaChannel7 ): return (IRQn)70; // DMA2_Stream7_IRQn
         default:
                UMBA_ASSERT_FAIL();
                return (IRQn)0;
     };

}

#endif


inline 
IRQn dmaGetIRQn( DMA_TypeDef *DMAx, DmaChannel ch )
{
    return dmaGetIRQn( dmaGetController(DMAx), ch );
}

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
constexpr 
uint32_t dmaMakeEventsConfigMask()
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
        return (uint32_t)(dmaChannelEventTransferComplete | dmaChannelEventHalfComplete | dmaChannelEventTransferError);
    #elif defined(STM32F4_SERIES)
        return (uint32_t)(dmaChannelEventDirectError | dmaChannelEventTransferError | dmaChannelEventHalfComplete | dmaChannelEventTransferComplete);
    #else
        UMBA_ASSERT_FAIL();
        return 0;
    #endif
}

constexpr 
uint32_t dmaMakeEventsConfigValue( uint16_t dmaChannelEvents )
{
    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) 
        return ( ((uint32_t)dmaChannelEvents) & dmaMakeEventsConfigMask() )     ;
    #elif defined(STM32F4_SERIES)
        return ( ((uint32_t)dmaChannelEvents) & dmaMakeEventsConfigMask() ) >> 1;
    #else
        UMBA_ASSERT_FAIL();
        return 0;
    #endif

}

//-----------------------------------------------------------------------------
#include "umba/optimize_speed.h"
UMBA_FORCE_INLINE( void periphClearIrqEventFlags( DMA_Channel_TypeDef* DMACHx ) )
{
    DMACHx->CCR &= ~ dmaMakeEventsConfigValue( dmaMakeEventsConfigMask() );
}

UMBA_FORCE_INLINE( void periphSetIrqEventFlags( DMA_Channel_TypeDef* DMACHx, uint16_t dmaChannelEvents ) )
{
    periphClearIrqEventFlags(DMACHx);
    DMACHx->CCR |= dmaMakeEventsConfigValue( dmaChannelEvents );
}

UMBA_FORCE_INLINE( void periphClearIrqEventFlags( DMA_TypeDef *DMAx, DmaChannel ch ) )
{
    periphClearIrqEventFlags( dmaGetChannelAddr( DMAx, ch ) );
}

UMBA_FORCE_INLINE( void periphClearIrqEventFlags( DmaController dma, DmaChannel ch ) )
{
    periphClearIrqEventFlags(dmaGetAddr(dma), ch); 
}

UMBA_FORCE_INLINE( void periphClearIrqEventFlags( DmaControllerChannel dmaX_ChannelY ) )
{
    periphClearIrqEventFlags( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                            , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                            ); 
}
#include "umba/optimize_pop.h"


//-----------------------------------------------------------------------------
// IRQn dmaGetIRQn( DmaController dma, DmaChannel ch )
// IRQn dmaGetIRQn( DMA_TypeDef *DMAx, DmaChannel ch )

inline
void periphInitIrq( DMA_TypeDef *DMAx, DmaChannel ch, uint16_t dmaChannelEvents )
{
    UMBA_ASSERT( dmaIsValidChannel( DMAx, ch ) );

    DMA_Channel_TypeDef* DMACHx = dmaGetChannelAddr( DMAx, ch );
    periphSetIrqEventFlags( DMACHx, dmaChannelEvents );

    periphEnableIRQ( dmaGetIRQn(DMAx, ch), true );
}

inline
void periphDisableIrq( DMA_TypeDef *DMAx, DmaChannel ch )
{
    UMBA_ASSERT( dmaIsValidChannel( DMAx, ch ) );

    periphEnableIRQ( dmaGetIRQn(DMAx, ch), false );

    //DMA_Channel_TypeDef* DMACHx = dmaGetChannelAddr( DMAx, ch );
    //DMACHx->CCR &= ~ dmaMakeEventsConfigValue( dmaMakeEventsConfigMask() );
}

//-----------------------------------------------------------------------------
inline
void periphInitIrq( DmaController dma, DmaChannel ch, uint16_t dmaChannelEvents )
{
    periphInitIrq( dmaGetAddr(dma), ch, dmaChannelEvents );
}

inline
void periphDisableIrq( DmaController dma, DmaChannel ch )
{
    periphDisableIrq( dmaGetAddr(dma), ch );
}

//-----------------------------------------------------------------------------
inline
void periphInitIrq( DmaControllerChannel dmaX_ChannelY, uint16_t dmaChannelEvents )
{
    periphInitIrq( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                 , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                 , dmaChannelEvents
                 );
}

inline
void periphDisableIrq( DmaControllerChannel dmaX_ChannelY )
{
    periphDisableIrq( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                    , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                    );
}

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
#define UMBA_PERIPH_DECLARE_DMA_IRQ_HANDLER_PROC( name )   void name( void *pParam, uint16_t eventType )

typedef void (*DmaIrqHandlerProcT)( void *pParam, uint16_t eventType );

// use UMBA_ASSERT( dmaIsValidChannel( DMAx, ch ) );
bool periphInstallIrqHandler( DMA_TypeDef *DMAx, DmaChannel ch, DmaIrqHandlerProcT proc, void *pParam = 0 );
bool periphUninstallIrqHandler( DMA_TypeDef *DMAx, DmaChannel ch );

//-----------------------------------------------------------------------------
inline
bool periphInstallIrqHandler( DmaController dma, DmaChannel ch, DmaIrqHandlerProcT proc, void *pParam = 0 )
{
    return periphInstallIrqHandler( dmaGetAddr(dma), ch, proc, pParam );
}

inline
bool periphUninstallIrqHandler( DmaController dma, DmaChannel ch )
{
    return periphUninstallIrqHandler( dmaGetAddr(dma), ch );
}

//-----------------------------------------------------------------------------
inline
bool periphInstallIrqHandler( DmaControllerChannel dmaX_ChannelY, DmaIrqHandlerProcT proc, void *pParam = 0 )
{
    return periphInstallIrqHandler( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                                  , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                                  , proc, pParam
                                  );
}

inline
bool periphUninstallIrqHandler( DmaControllerChannel dmaX_ChannelY )
{
    return periphUninstallIrqHandler( UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL(dmaX_ChannelY)
                                    , UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH(dmaX_ChannelY)
                                    );
}

//-----------------------------------------------------------------------------





//---------------------------------------------------------

#if defined(STM32F4_SERIES)

    #undef  CCR
    #undef  CNDTR
    #undef  CPAR
    #undef  CMAR

#endif

//---------------------------------------------------------



} // namespace traits
} // namespace periph
} // namespace umba









