#pragma once

#if defined(STM32F0_SERIES) || defined(STM32F1_SERIES) || defined(STM32F2_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES) || defined(STM32F7_SERIES)\
                             || defined(STM32L0_SERIES) || defined(STM32L1_SERIES) || defined(STM32L4_SERIES) \
                             || defined(MILANDR)

    #include "stm32_traits.h"
    
#endif


#define UMBA_GPIO_DIRECTION_OUT      umba::periph::PinMode::gpio_out_pp
#define UMBA_GPIO_DIRECTION_IN       umba::periph::PinMode::gpio_in_pulldown


// Usage: UMBA_PERIPH_DECLARE_PIN_EX( batteryChargeDetectPin, UMBA_PINADDR_PD14, UMBA_GPIO_DIRECTION_OUT );
// Used mostly in ROBOCONF-generated files
#define UMBA_PERIPH_DECLARE_PIN_EX( pinName, pinAddr, pinDirection )  umba::periph::GpioPin  pinName( pinAddr, pinDirection )

// Usage: UMBA_PERIPH_DECLARE_PIN( termocouplesSckPin , HOTEND_TERMCPL_SPI_SCK  );
// where HOTEND_TERMCPL_SPI_SCK - constant from ROBOCONF-generated h_conf
#define UMBA_PERIPH_DECLARE_PIN( pinName, pinConfigName )             umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )

// Used mostly in ROBOCONF-generated files
#define UMBA_PERIPH_EXTERN_PIN( pinName )                             extern umba::periph::GpioPin  pinName



// umba::periph::
namespace umba
{
namespace periph
{

//-----------------------------------------------------------------------------
using traits::GpioPinAddr;
using traits::RawGpioPortType;
using traits::RawGpioPortBits;
using traits::PinMode;
using traits::PinSpeed;
using traits::PinGetDirection;
using traits::GpioPin;
using traits::GpioPinValue;

constexpr GpioPinAddr invalid_pin_addr = traits::invalid_pin_addr;


//-----------------------------------------------------------------------------

inline
uint16_t gpioGetPortNo( GPIO_TypeDef * pt )
{
    return traits::gpioGetPortNo( pt );
}

inline
GPIO_TypeDef* gpioNumberToPort( uint16_t n )
{
    return traits::gpioNumberToPort( n );
}


inline
bool isValidPinPort( RawGpioPortType port )
{
    return traits::isValidPinPort( port );
}

inline
bool isValidPinNo( uint16_t pinNo )
{
    return traits::isValidPinNo( pinNo );
}

inline
bool isValidPinAddr( const GpioPinAddr &a )
{
    return traits::isValidPinAddr( a );
}

//-----------------------------------------------------------------------------


inline
uint32_t packGpioPinAddr( GpioPinAddr pa )
{
    if (!traits::isValidPinAddr(pa))
        return 0xFFFFFFFFu;

    uint32_t packedPort = ((uint32_t)gpioGetPortNo(pa.port))<<16;
    uint32_t packedPin  = ((uint32_t)pa.pinNo)&0xFFFFu;
    return packedPort | packedPin;
}

inline
GpioPinAddr unpackGpioPinAddr( uint32_t pa )
{
    if (pa==0xFFFFFFFFu)
        return invalid_pin_addr;

    return GpioPinAddr { gpioNumberToPort((uint16_t)(pa>>16))
                       , (unsigned)(pa&0x0000FFFFu)
                       };
}

inline
uint16_t superpackGpioPinAddr( GpioPinAddr pa )
{
    if (!traits::isValidPinAddr(pa))
        return 0xFFFFu;

    uint16_t packedPort = ((uint32_t)gpioGetPortNo(pa.port))<<8;
    uint16_t packedPin  = ((uint32_t)pa.pinNo)&0xFFu;
    return packedPort | packedPin;
}

inline
GpioPinAddr superunpackGpioPinAddr( uint16_t pa )
{
    if (pa==0xFFFFu)
        return invalid_pin_addr;

    return GpioPinAddr { gpioNumberToPort((uint16_t)(pa>>8))
                       , (unsigned)(pa&0x00FFu)
                       };
}



} // namespace periph




#if defined(UMBA_SIMPLE_FORMATTER_H)

    inline
    umba::SimpleFormatter& operator<<( umba::SimpleFormatter &fmt, const periph::GpioPin &pin )
    {
        fmt << bool(pin);
        return fmt;
    }

    inline
    umba::SimpleFormatter& operator<<( umba::SimpleFormatter &fmt, const periph::GpioPinAddr &pa )
    {
        if (periph::isValidPinAddr(pa))
            fmt << "P" << (char)(periph::gpioGetPortNo(pa.port) + 'A') << pa.pinNo;
        else
            fmt << "<BADADDR>";
        return fmt;
    }

#endif









} // namespace umba
