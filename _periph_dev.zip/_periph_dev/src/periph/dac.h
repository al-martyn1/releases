#pragma once

#if defined(STM32F0_SERIES) || defined(STM32F1_SERIES) || defined(STM32F2_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES) || defined(STM32F7_SERIES)\
                             || defined(STM32L0_SERIES) || defined(STM32L1_SERIES) || defined(STM32L4_SERIES) \
                             || defined(MILANDR)

    #include "stm32_traits.h"
    
#endif

// umba::periph
namespace umba
{
namespace periph
{

using umba::periph::traits::DacBits;
using umba::periph::traits::DacChannel;
using umba::periph::traits::DacSimple;


} // namespace periph
} // namespace umba

