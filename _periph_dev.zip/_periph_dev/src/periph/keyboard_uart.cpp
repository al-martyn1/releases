#include "periph/keyboard_uart.h"


namespace umba
{

namespace periph
{

namespace legacy
{





//-----------------------------------------------------------------------------
void UartTerminalKeyboard::setHandler( IKeyboardHandler *pHandler )
{
    m_pHandler = pHandler;
}

//-----------------------------------------------------------------------------
IKeyboardHandler* UartTerminalKeyboard::getHandler( )
{
    return m_pHandler;
}

//-----------------------------------------------------------------------------
void UartTerminalKeyboard::setUart( uart::Handle *pUart )
{
    m_pUart = pUart;
}

//-----------------------------------------------------------------------------
uart::Handle* UartTerminalKeyboard::getUart()
{
    return m_pUart;
}

//-----------------------------------------------------------------------------
void UartTerminalKeyboard::uartReadByte( uint8_t *pByte )
{
    UMBA_ASSERT(m_pUart!=0);

    if (pByte)
        *pByte = m_pUart->getByte();
    else
        m_pUart->getByte();
}

//-----------------------------------------------------------------------------
bool UartTerminalKeyboard::uartWaitReadByte( umba::time_service::TimeTick waitPeriod, uint8_t *pByte )
{
    UMBA_ASSERT(m_pUart!=0);

    if (m_pUart->isNewByte())
    {
        //lout<<"u:read\n";
        uartReadByte( pByte );
        return true;
    }

    if (!waitPeriod)
    {
        //lout<<"u:timedout\n";
        return false;
    }

    using namespace umba::time_service;

    TimeTick tickStart = getCurTimeMs();
    while( (getCurTimeMs()-tickStart) < waitPeriod)
    {
        //lout<<"u:while\n";
        if (m_pUart->isNewByte())
        {
            //lout<<"u:read 2\n";
            uartReadByte( pByte );
            return true;
        }
    }

    //lout<<"u:no_data\n";

    return false;
}

//-----------------------------------------------------------------------------
void UartTerminalKeyboard::scanKeyboard()
{
    scanKeyboardImpl();
    checkReleasedKeys();
}

//-----------------------------------------------------------------------------
void UartTerminalKeyboard::scanKeyboardImpl()
{
    // Esc - start, '[' - second, '~' (tilde) - end of sequence
    uint8_t buf[16];
    size_t idx = 0;

    const umba::time_service::TimeTick zeroWaitPeriod = 0; // 10;
    const umba::time_service::TimeTick seqWaitPeriod  = 5; // 10;

    if ( !uartWaitReadByte( zeroWaitPeriod, &buf[idx]) )
        return;

    //using namespace umba::omanip;


    if (buf[idx]!=0x1B)
    {
        switch(buf[idx])
        {
            case 0x0D: internalHandleKey( umba::periph::VirtualKeyCode::enter     ); return;
            case 0x09: internalHandleKey( umba::periph::VirtualKeyCode::tab       ); return;
            case 0x1A: internalHandleKey( umba::periph::VirtualKeyCode::pause     ); return;
            case 0x7F: internalHandleKey( umba::periph::VirtualKeyCode::backspace ); return;
            default:   internalHandleKey( buf[idx] ); return;
        }
        //lout<<"Received char: '"<<(char)buf[idx]<<"' ("<<width(4)<<hex<<buf[idx]<<")"<<endl;
        return;
    }

    if ( !uartWaitReadByte( seqWaitPeriod, &buf[idx]) )
    {
        internalHandleKey( umba::periph::VirtualKeyCode::escape );
        //lout<<"Received ESCAPE"<<endl;
        return;
    }

    if (buf[idx]!='[')
    {
        internalHandleKey( umba::periph::VirtualKeyCode::escape );
        internalHandleKey( buf[idx] );
        //lout<<"Received ESCAPE"<<endl;
        //lout<<"Received char: '"<<(char)buf[idx]<<"' ("<<width(4)<<hex<<buf[idx]<<")"<<endl;
        return;
    }

    while( true )
    {
        if (idx==1)
        {
            switch(buf[0])
            {
                case 0x41: internalHandleKey(umba::periph::VirtualKeyCode::up   ); return;
                case 0x42: internalHandleKey(umba::periph::VirtualKeyCode::down ); return;
                case 0x43: internalHandleKey(umba::periph::VirtualKeyCode::right); return;
                case 0x44: internalHandleKey(umba::periph::VirtualKeyCode::left ); return;
            }
        }

        if ( !uartWaitReadByte(seqWaitPeriod, &buf[idx]) )
        {
            //
            //lout<<"Broken ESC sequence - timedout: "<<endl;
            //for( size_t i = 0; i!=idx; ++i )
            //{
            //    lout<<" "<<width(4)<<hex<<buf[i];
            //}
            //lout<<endl;
            //
            return;
        }

        if (buf[idx]=='~')
        {
            /*
            lout<<"Received ESC sequence:";
            for( size_t i = 0; i!=idx; ++i )
            {
                lout<<" "<<width(4)<<hex<<buf[i];
            }
            lout<<endl;
            */
            if (idx==1)
            {
                switch(buf[0])
                {
                    case 0x31: internalHandleKey(umba::periph::VirtualKeyCode::home     ); return;
                    case 0x32: internalHandleKey(umba::periph::VirtualKeyCode::ins      ); return;
                    case 0x33: internalHandleKey(umba::periph::VirtualKeyCode::del      ); return;
                    case 0x34: internalHandleKey(umba::periph::VirtualKeyCode::end      ); return;
                    case 0x35: internalHandleKey(umba::periph::VirtualKeyCode::pageUp   ); return;
                    case 0x36: internalHandleKey(umba::periph::VirtualKeyCode::pageDown ); return;
                    default  : internalHandleKey(umba::periph::VirtualKeyCode::unknown | buf[0] ); return;
                }
            }
            else if (idx==2)
            {
                switch(buf[0])
                   {
                    case 0x31:   if (buf[1]>=0x31 && buf[1] <= 0x35)
                                     { internalHandleKey( (buf[1] - 0x31) + umba::periph::VirtualKeyCode::f1 ); return; }
                                 if (buf[1]>=0x37 && buf[1] <= 0x39)
                                     { internalHandleKey( (buf[1] - 0x37) + umba::periph::VirtualKeyCode::f6 ); return; }
                                 internalHandleKey(umba::periph::VirtualKeyCode::unknown | ((unsigned)buf[0])<<8 | buf[1] ); return;
                                 
                    case 0x32:   if (buf[1]>=0x30 && buf[1] <= 0x31)
                                     { internalHandleKey( (buf[1] - 0x30) + umba::periph::VirtualKeyCode::f9 ); return; }
                                 if (buf[1]>=0x33 && buf[1] <= 0x34)
                                     { internalHandleKey( (buf[1] - 0x33) + umba::periph::VirtualKeyCode::f11 ); return; }

                    default  :   internalHandleKey(umba::periph::VirtualKeyCode::unknown | ((unsigned)buf[0])<<8 | buf[1] ); return;
                   }
            }
            return;
        }

        if ( (idx+1)!=(sizeof(buf)/sizeof(buf[0])) )
           ++idx;
    }

}

//-----------------------------------------------------------------------------
UartTerminalKeyboard::KeyState* UartTerminalKeyboard::findKeyState( unsigned vkc )
{
    size_t size = sizeof(keyStates) / sizeof(keyStates[0]);
    for( size_t i = 0; i!= size; ++i)
    {
        if (keyStates[i].vkc==vkc)
            return &keyStates[i];
    }

    return 0;
}

//-----------------------------------------------------------------------------
void UartTerminalKeyboard::callKeyPressHandler( unsigned vkc, bool bPressed, size_t repeatCount )
{
    if (!m_pHandler)
        return;

    m_pHandler->onKeyPress( vkc, bPressed, repeatCount);
}

//-----------------------------------------------------------------------------
void UartTerminalKeyboard::internalHandleKey( unsigned vkc )
{
    using namespace umba::time_service;

    if (!vkc)
        return; // bad virtual code

    umba::time_service::TimeTick tck = getCurTimeMs();

    KeyState* pKeyState = findKeyState( vkc );
    if (!pKeyState)
    {
        // new vkc, not saved before
        pKeyState = findKeyState( 0 );
        if (!pKeyState)
        {
            return; // no room for new key
        }

        pKeyState->vkc               = vkc;
        pKeyState->lastPressTime     = tck;
        pKeyState->lastPressInterval = 600;
        pKeyState->repeatCout        = 1;

        callKeyPressHandler( pKeyState->vkc, true, 1 );

        //checkReleasedKeys();

        return;
    }

    pKeyState->lastPressInterval = tck - pKeyState->lastPressTime;
    pKeyState->lastPressTime     = tck;
    pKeyState->repeatCout++;

    callKeyPressHandler( pKeyState->vkc, true, pKeyState->repeatCout );

    //checkReleasedKeys();

}

//-----------------------------------------------------------------------------
void UartTerminalKeyboard::checkReleasedKeys()
{
    using namespace umba::time_service;
    umba::time_service::TimeTick tck = getCurTimeMs();

    size_t size = sizeof(keyStates) / sizeof(keyStates[0]);
    for( size_t i = 0; i!= size; ++i)
    {
        if (!keyStates[i].vkc)
            continue;
        umba::time_service::TimeTick tickDiff = tck - keyStates[i].lastPressTime;
        umba::time_service::TimeTick tickDiffLim = 12*keyStates[i].lastPressInterval / 10; // add 20%
        if (tickDiff>=tickDiffLim)
        {
            callKeyPressHandler( keyStates[i].vkc, false, 0 );
            keyStates[i].vkc = 0;
            keyStates[i].lastPressInterval = 0;
            keyStates[i].lastPressTime     = 0;
            keyStates[i].repeatCout        = 0;
        }
    }
}

//-----------------------------------------------------------------------------
bool UartTerminalKeyboard::getKeyState( unsigned vkc )
{
    size_t size = sizeof(keyStates) / sizeof(keyStates[0]);
    for( size_t i = 0; i!= size; ++i)
    {
        if (keyStates[i].vkc==vkc)
            return true;
    }

    return false;
}


//-----------------------------------------------------------------------------


} // namespace legacy

} // namespace periph

} // namespace umba
