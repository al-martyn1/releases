#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif

/* F1
MCU lines - https://www.st.com/en/microcontrollers-microprocessors/stm32f103.html

https://github.com/jeelabs/embello/issues/76
https://github.com/jeelabs/embello/pull/87


*/


namespace umba
{
namespace periph
{
namespace traits
{

#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)
    template <>
    inline
    ClockBus periphClockGetBus<I2C_TypeDef>( I2C_TypeDef * pt )
    {
        return ClockBus::APB1; 
    }
#endif


#if defined(STM32F1_SERIES) || defined(STM32F3_SERIES) || defined(STM32F4_SERIES)

    template <>
    inline
    PerifClockFunctionPtr periphClockGetFunction<I2C_TypeDef>( I2C_TypeDef * pt )
    {
        return RCC_APB1PeriphClockCmd;
    }

    template <>
    inline
    uint32_t periphClockGetFlag<I2C_TypeDef>( I2C_TypeDef * pt )
    {
        #ifdef I2C1
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( I2C1, RCC_APB1Periph_I2C1 );
        #endif
        #ifdef I2C2
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( I2C2, RCC_APB1Periph_I2C2 );
        #endif
        #ifdef I2C3
            UMBA_PERIPH_STM32_TRAITS_DECLARE_PERIPH_GETPERIPHCLOCKFLAG( I2C3, RCC_APB1Periph_I2C3 );
        #endif

        UMBA_ASSERT_FAIL();

        return 0;
    }

#endif



#if defined(STM32F1_SERIES)

    /*
    High-density
    Connectivity line
    Medium-density
    Low-density
    Medium-density
    Low-density
    XL-density
    */

    template < >
    inline
    uint32_t periphAltFunctionGetFlags< I2C_TypeDef, PinFunctionI2c >( I2C_TypeDef *pt, PinFunctionI2c pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #ifdef I2C1
            if (pt==I2C1)
            {
                if (pinFn==PinFunctionI2c::scl)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 6, 0); // PB6 - no remap
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 8, GPIO_Remap_I2C1); // PB8 - use remap
                }
                else if (pinFn==PinFunctionI2c::sda)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 7, 0); // PB7 - no remap
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 9, GPIO_Remap_I2C1); // PB9 - use remap
                }
            }
        #endif
        #ifdef I2C2
            if (pt==I2C2)
            {
                if (pinFn==PinFunctionI2c::scl)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 10, 0); // PB10 - no remap
                }
                else if (pinFn==PinFunctionI2c::sda)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 11, 0); // PB11 - no remap
                }
            }
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

#elif defined(STM32F3_SERIES)

    template < >
    inline
    uint32_t periphAltFunctionGetFlags< I2C_TypeDef, PinFunctionI2c >( I2C_TypeDef *pt, PinFunctionI2c pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #ifdef I2C1
            if (pt==I2C1)
            {
                if (pinFn==PinFunctionI2c::scl)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA, 15, GPIO_AF_4); // PA15
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  6, GPIO_AF_4); // PB6
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  8, GPIO_AF_4); // PB8
                }
                else if (pinFn==PinFunctionI2c::sda)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA, 14, GPIO_AF_4); // PA15
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  7, GPIO_AF_4); // PB7
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  9, GPIO_AF_4); // PB9
                }
            }
        #endif
        #ifdef I2C2
            if (pt==I2C2)
            {
                if (pinFn==PinFunctionI2c::scl)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA,  9, GPIO_AF_4); // PA9
                    #ifdef GPIOF
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOF,  1, GPIO_AF_4); // PF1
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOF,  6, GPIO_AF_4); // PF6
                    #endif
                }
                else if (pinFn==PinFunctionI2c::sda)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA, 10, GPIO_AF_4); // PA10
                    #ifdef GPIOF
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOF,  0, GPIO_AF_4); // PF0
                    #endif
                }
            }
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

#elif defined(STM32F4_SERIES)

    template < >
    inline
    uint32_t periphAltFunctionGetFlags< I2C_TypeDef, PinFunctionI2c >( I2C_TypeDef *pt, PinFunctionI2c pinFn, GPIO_TypeDef* pGpioPort, unsigned pinNo )
    {
        #ifdef I2C1
            if (pt==I2C1)
            {
                if (pinFn==PinFunctionI2c::scl)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  6, GPIO_AF_4); // PB6
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  8, GPIO_AF_4); // PB8
                }
                else if (pinFn==PinFunctionI2c::sda)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  7, GPIO_AF_4); // PB7
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB,  9, GPIO_AF_4); // PB9
                }
            }
        #endif
        #ifdef I2C2
            if (pt==I2C2)
            {
                if (pinFn==PinFunctionI2c::scl)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 10, GPIO_AF_4); // PB10
                    #ifdef GPIOF
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOF,  1, GPIO_AF_4); // PF1
                    #endif
                    #ifdef GPIOH
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOH,  4, GPIO_AF_4); // PH4
                    #endif
                }
                else if (pinFn==PinFunctionI2c::sda)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOB, 11, GPIO_AF_4); // PB11
                    #ifdef GPIOF
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOF,  0, GPIO_AF_4); // PF0
                    #endif
                    #ifdef GPIOH
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOH,  5, GPIO_AF_4); // PH5
                    #endif
                }
            }
        #endif
        #ifdef I2C3
            if (pt==I2C3)
            {
                if (pinFn==PinFunctionI2c::scl)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOA,  8, GPIO_AF_4); // PA8
                    #ifdef GPIOH
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOH,  7, GPIO_AF_4); // PH7
                    #endif
                }
                else if (pinFn==PinFunctionI2c::sda)
                {
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOC,  9, GPIO_AF_4); // PC9
                    #ifdef GPIOH
                    UMBA_PERIPH_STM32_TRAITS_PINFUNCTION_CHECK_PIN(GPIOH,  8, GPIO_AF_4); // PH8
                    #endif
                }
            }
        #endif

        UMBA_ASSERT_FAIL();
        return 0;
    }

#endif


inline
void periphInit( I2C_TypeDef* I2Cx, I2C_InitTypeDef &initStruct
               , GPIO_TypeDef *portScl, uint16_t sclPinNo
               , GPIO_TypeDef *portSda, uint16_t sdaPinNo
               )
{
    initPeriphClock( portScl, ENABLE, getPeriphClockGpioAltFunctionFlag(portScl) );
    initPeriphClock( portSda, ENABLE, getPeriphClockGpioAltFunctionFlag(portSda) );

    initPeriphClock( I2Cx, ENABLE );

    gpioInit( portScl, PinSpeed::high, PinMode::gpio_out_pp, 1 << sclPinNo ); // GPIO_Pin_X
    gpioInit( portSda, PinSpeed::high, PinMode::gpio_out_pp, 1 << sdaPinNo ); // GPIO_Pin_X

    GPIO_ResetBits( portScl, 1 << sclPinNo ); // reset SCL

    I2C_DeInit(I2Cx); // shutdown I2C

    I2C_Init(I2Cx, &initStruct);

    gpioInit( portScl, PinSpeed::high, PinMode::alt_mode_od, 1 << sclPinNo ); // GPIO_Pin_X
    gpioInit( portSda, PinSpeed::high, PinMode::alt_mode_od, 1 << sdaPinNo ); // GPIO_Pin_X

    periphAltFunctionConfigure( I2Cx
                              , makePinAltFunctionInfo( PinFunctionI2c::scl, portScl, sclPinNo )
                              , makePinAltFunctionInfo( PinFunctionI2c::sda, portSda, sdaPinNo )
                              );

    I2C_Cmd(I2Cx, ENABLE);

}


inline
void periphInit( I2C_TypeDef* I2Cx, I2C_InitTypeDef &initStruct
               , const GpioPinAddr sclPinAddr
               , const GpioPinAddr sdaPinAddr
               )
{
    periphInit( I2Cx, initStruct, sclPinAddr.port, sclPinAddr.pinNo, sdaPinAddr.port, sdaPinAddr.pinNo );
}





} // namespace traits
} // namespace periph
} // namespace umba


