#pragma once

#ifndef UMBA_PERIPH_STM32_TRAITS_INCLUDED
    #error "Don't include this file directly, include periph/stm32_traits.h instead"
#endif


namespace umba
{
namespace periph
{
namespace traits
{


//-----------------------------------------------------------------------------
enum DmaChannelPriorityLevel
{
    dmaChannelPriorityLow      = 0, 
    dmaChannelPriorityMedium   = 1, 
    dmaChannelPriorityHigh     = 2, 
    dmaChannelPriorityVeryHigh = 3 
};

//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
enum DmaSize
{
    dmaSizeInvalid = -1,

    dmaBits8        = 0,
    dmaBytes1       = 0,
    dmaSizeBits8    = 0,
    dmaSizeBytes1   = 0,
                   
    dmaBits16       = 1,
    dmaBytes2       = 1,
    dmaSizeBits16   = 1,
    dmaSizeBytes2   = 1,
                   
    dmaBits32       = 2,
    dmaBytes4       = 2,
    dmaSizeBits32   = 2,
    dmaSizeBytes4   = 2,

    dmaSizeReserved = 3,

};

inline
DmaSize sizeofToDmaSize( size_t sz )
{
    switch( sz )
    {
        case 1: return dmaBytes1;
        case 2: return dmaBytes2;
        case 4: return dmaBytes4;
        default: return dmaSizeInvalid;
    }
}

inline
bool isValidDmaSize( DmaSize sz )
{
    return sz==dmaBytes1 || sz==dmaBytes2 || sz==dmaBytes4;
}

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
enum DmaIncMode
{
    dmaIncOff     = 0,
    dmaIncOn      = 1,
    dmaIncMem     = 1,
    dmaIncPeriph  = 1
};

//-----------------------------------------------------------------------------
enum DmaCircMode
{
    dmaCircOff    = 0,
    dmaCircOn     = 1
};

//-----------------------------------------------------------------------------
enum DmaOnOff
{
    dmaOff = 0,
    dmaOn  = 1
};

//-----------------------------------------------------------------------------
enum DmaDirection
{
    dmaRx               = 0, // from periph to mem
    dmaDirPeriphToMem   = 0,

    dmaTx               = 1,  // from mem to periph
    dmaDirMemToPeriph   = 1,

    dmaDirMemMemMode    = 2
};

//-----------------------------------------------------------------------------
enum DmaChannel
{
    dmaChannel0     = 0x00,
    dmaChannel1     = 0x01,
    dmaChannel2     = 0x02,
    dmaChannel3     = 0x03,
    dmaChannel4     = 0x04,
    dmaChannel5     = 0x05,
    dmaChannel6     = 0x06,
    dmaChannel7     = 0x07,

    dmaChannelEnd   = 0x08
};

inline
DmaChannel dmaEnumerateGetNextChannel( DmaChannel ch )
{
    if (ch!=dmaChannelEnd)
    {
        ch = (DmaChannel)(((unsigned)ch) + 1);
    }

    return ch;
}

inline
DmaChannel dmaEnumerateGetPrevChannel( DmaChannel ch )
{
    if (ch==dmaChannel0)
        return dmaChannelEnd;

    ch = (DmaChannel)(((unsigned)ch) - 1);

    return ch;
}


//-----------------------------------------------------------------------------
enum DmaController
{
    dma1            = 0x00,
    dma2            = 0x01,

    #if defined(DMA2)
        dmaControllerEnd = 0x02,
    #else
        dmaControllerEnd = 0x01,
    #endif

    dmaControllerInvalid = -1
};

inline
DmaController dmaEnumerateGetNextController( DmaController dma )
{
    if (dma!=dmaControllerEnd)
    {
        dma = (DmaController)(((unsigned)dma) + 1);
    }

    return dma;
}

inline
DmaController dmaEnumerateGetPrevController( DmaController dma )
{
    if (dma==dma1)
        return dmaControllerEnd;

    dma = (DmaController)(((unsigned)dma) - 1);

    return dma;
}

inline
bool dmaIsMemMemCompatible( DmaController dma, DmaChannel )
{
    #if defined(STM32F4_SERIES)
        #if defined(DMA2)
            if (dma==dma2)
                return true;
        #endif
        return false;
    #else
        return true;
    #endif
}

//-----------------------------------------------------------------------------




//---------------------------------------------------------

#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( ctrl, ch )         (((uint16_t)(ctrl))<<8) | ((uint16_t)(ch))
#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CTRL( ctrlCh )    ((DmaController)((((uint16_t)ctrlCh)>>8)&0xFF))
#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_UNPACK_CH( ctrlCh )      ((DmaChannel)((((uint16_t)ctrlCh))&0xFF))

#define UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( ctrlN, chN )  dma##ctrlN##_Channel##chN = UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_PACK( dma##ctrlN, dmaChannel##chN )

enum DmaControllerChannel
{
    // define values dmaX_ChannelY

    #if defined(STM32F1_SERIES) || defined(STM32F3_SERIES)

        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 1 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 2 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 3 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 4 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 5 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 6 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 7 ),

        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 1 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 2 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 3 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 4 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 5 )

    #elif defined(STM32F4_SERIES)

        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 0 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 1 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 2 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 3 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 4 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 5 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 6 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 1, 7 ),

        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 0 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 1 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 2 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 3 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 4 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 5 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 6 ),
        UMBA_PERIPH_STM32_TRAITS_DMA_CTRL_CH_MAKE_ENUM_VAL( 2, 7 )

    #endif

}; // enum DmaControllerChannel

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
template< typename TPeriph >
inline
void periphDmaEnable( TPeriph * pt, DmaDirection dmaDir, DmaOnOff onOff )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
}

template< typename TPeriph >
inline
bool periphDmaIsEnabled( TPeriph * pt, DmaDirection dmaDir )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
    return false;
}

template< typename TPeriph >
inline
void periphDmaWaitDisabled( TPeriph * pt, DmaDirection dmaDir )
{
    //static_assert( pt!=pt, "Must be specialized for specific peripherals" );
    UMBA_ASSERT_FAIL();
}

//-----------------------------------------------------------------------------


} // namespace traits
} // namespace periph
} // namespace umba
