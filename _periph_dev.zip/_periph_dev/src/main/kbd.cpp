#include "luart/uart_handle.h"
#include "vgpio/i_virtual_gpio.h"
#include "vgpio/stm32_gpio.h"
#include "vgpio/virtual_gpio.h"
#include "umba/time_service.h"

#include "periph/keyboard.h"

#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/allocator.h"
#include <vector>


#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif

namespace vgpio     = umba::virtual_gpio;
namespace stm32gpio = umba::stm32_gpio;


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<>   charWritter = umba::LegacyUartCharWriter<>(uart::uart3).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  fmt(&charWritter);




const vgpio::PinType ledPhisPin = vgpio::pin_12;

stm32gpio::Stm32IoPort ledPhisPort( vgpio::Port::C
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::output
                              , vgpio::PinPushPullMode::pushPull
                              , ledPhisPin | vgpio::pin_4 // PC4 - 500 Hz test meandr
                              );

//umba::virtual_gpio::

umba::virtual_gpio::VirtualOutputPin virtualPins[] = { { &ledPhisPort, ledPhisPin | vgpio::pin_4 }
                                                     , { 0, 0 }
                                                     };

umba::virtual_gpio::VirtualOutputPort ledPort( &virtualPins[0] );


//#define ledPort ledPhisPort

stm32gpio::Stm32IoPort rowOutputPort( vgpio::Port::B
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::output
                              , vgpio::PinPushPullMode::pushPull
                              , vgpio::pin_0 | vgpio::pin_1 | vgpio::pin_2 // | vgpio::pin_3
                              );

stm32gpio::Stm32IoPort colInputPort( vgpio::Port::C
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::input
                              , vgpio::PinPushPullMode::pullDown
                              , vgpio::pin_0 | vgpio::pin_1 | vgpio::pin_2 | vgpio::pin_3
                              );



class KeyboardHandler : implements umba::periph::IKeyboardHandler
{
    virtual
    void onKeyPress( size_t keyNo, bool fPressed, size_t repeatCout ) override
    {
        using namespace umba::omanip;
        using namespace umba::term::colors;

        umba::term::colors::SgrColor clrFg = color_default;
        umba::term::colors::SgrColor clrBg = color_default;
        bool fBright = false;
        bool fBlink  = false;

        if (keyNo==1) // first green button
        {
           if (fPressed && repeatCout==1)
           {
               fmt.popLock();
               fmt<<notice<<"Output unlocked"
                  << umba::omanip::cret<<umba::omanip::flush;
                  //<<umba::omanip::endl;
           }
           return;
        }

        if (keyNo==3) // first red button
        {
           if (fPressed && repeatCout==1)
           {
               fmt<<notice<<"Output locked"
                  << umba::omanip::cret<<umba::omanip::flush;
                  //<<umba::omanip::endl;
               fmt.pushLock(true);
           }
           return;
        }

        switch(keyNo)
        {
            case 0: case 4: case  8: case 12: // blue keys
                clrFg = blue;
                break;

            case 1: case 5: case  9: case 13: // green keys
                clrFg = green;
                break;

            case 2: case 6: case 10: case 14: // yellow keys
                clrFg = yellow;
                break;

            case 3: case 7: case 11: case 15: // red keys
                clrFg = red;
                break;

        }

        switch(keyNo)
        {
            case  0: case  1: case  2: case  3: 
                //clrBg = cyan;
                break;

            case  4: case  5: case  6: case  7: // выводит ярко
                //clrBg = magenta;
                fBright = true;
                break;

            case  8: case  9: case 10: case 11: // выводит ярко мигающе
                //clrBg = black;
                //fBright = true;
                fBlink  = true;
                break;

            case 12: case 13: case 14: case 15:
                //clrBg = white;
                //fBlink  = true;
                break;
        }

        //charWritter.setTermColors( makeComposite(clrFg, clrBg, fBright, fBlink) );

        //fmt<< umba::omanip::cret;
        fmt<<coloring(makeComposite(clrFg, clrBg, fBright, fBlink));
        fmt<< (fPressed ? "+" : "-") << " Key "<<width(2)<<keyNo<<" "<<width(8)<<(fPressed ? "pressed" : "released") << ", counter: " << width(3)<<repeatCout 
           //<< umba::omanip::endl;
           << umba::omanip::cret<<umba::omanip::flush; // тестируем возврат каретки
/*
        if (!fPressed)
            return;

        if (repeatCout>1)
            return;

        if (keyNo&1)
           ledPort.setOutput( ledPort.getPins() );
        else
           ledPort.clrOutput( ledPort.getPins() );

        ledPort.writeFlushPins();
*/
    }

}; // interface IKeyboardHandler


KeyboardHandler kbdHandler;
umba::periph::Keyboard<16>  kbd( &kbdHandler, &colInputPort, &rowOutputPort );



static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;
   
    
    uart::uart3.init( uart::Pins::UART3_PB10_PB11, 460800 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 307200 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 691200 );

    ledPhisPort.initPort();
    ledPort.initPort();
    rowOutputPort.initPort();
    colInputPort.initPort();

    //ledPort.clrOutput( ledPort.getPins() );
    ledPort.setOutput( ledPort.getPins() );

    //printf("printf test\n");
/*
    std::vector< int, umba::static_allocator<int> > intVec;
    //std::vector< int, std::allocator<int> > intVec;
    //std::vector< int > intVec;

    intVec.reserve(20);
    intVec.push_back(1);
    intVec.push_back(4);
    intVec.push_back(7);
    intVec.push_back(1243);
    
    for( auto it = intVec.begin(); it!=intVec.end(); ++it)
        fmt<<*it<<", ";
    fmt<<umba::omanip::endl;
*/


    charWritter.setTermColors( umba::term::colors::makeComposite(umba::term::colors::color_default, umba::term::colors::color_default, false, false) );

    {
        using namespace umba::term::colors;
        fmt<<umba::omanip::coloring(green)<<"coloring(green)"<<umba::omanip::endl;
        fmt<<umba::omanip::coloring(green|blink)<<"coloring(green|blink)"<<umba::omanip::endl;
        fmt<<umba::omanip::coloring(green|invert)<<"coloring(green|invert)"<<umba::omanip::endl;
        fmt<<umba::omanip::coloring(green|invert|bright)<<"coloring(green|invert|bright)"<<umba::omanip::endl;
        fmt<<umba::omanip::coloring(green|invert|bright|blink)<<"coloring(green|invert|bright|blink)"<<umba::omanip::endl;
        fmt<<umba::omanip::coloring(umba::ColoringLevel::emergency)<<"coloring(umba::ColoringLevel::emergency)"<<umba::omanip::endl;
        fmt<<umba::omanip::emergency<<"emergency"<<umba::omanip::endl;
        fmt<<umba::omanip::alert    <<"alert    "<<umba::omanip::endl;
        fmt<<umba::omanip::critical <<"critical "<<umba::omanip::endl;
        fmt<<umba::omanip::error    <<"error    "<<umba::omanip::endl;
        fmt<<umba::omanip::warning  <<"warning  "<<umba::omanip::endl;
        fmt<<umba::omanip::notice   <<"notice   "<<umba::omanip::endl;
        fmt<<umba::omanip::info     <<"info     "<<umba::omanip::endl;
        fmt<<umba::omanip::debug    <<"debug    "<<umba::omanip::endl;
        fmt<<umba::omanip::good     <<"good     "<<umba::omanip::endl;
        fmt<<umba::omanip::normal   <<"normal   "<<umba::omanip::endl;
    }

    fmt<<"\n\nKeyboard test started"<<umba::omanip::endl;
    //fmt<<"VT: \v"<<umba::omanip::endl;
    //fmt<<"FF: \f"<<umba::omanip::endl;

    while(1)
    {
        umba::time_service::delayMs(1);
        kbd.scanKeyboard();

        ledPort.toggleOutput( ledPort.getPins() );

        //uint16_t ledPins = GPIO_Pin_4 | GPIO_Pin_12;
        //uint16_t curVal  = GPIO_ReadOutputData( GPIOC );
        //GPIO_Write( GPIOC, (uint16_t)(curVal ^ ledPins));

    }

    return 0;
}



