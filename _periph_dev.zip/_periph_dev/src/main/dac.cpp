#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "periph/gpio.h"
#include "periph/dac.h"
#include "periph/power.h"


int main()
{

    umba::periph::DacSimple dac1( umba::periph::DacChannel::channel_1 ); // PA4
    umba::periph::DacSimple dac2( UMBA_PINADDR_PA5 );

    // Can use unsigned numbers
    //umba::periph::DacSimple dac1( 1 );
    //umba::periph::DacSimple dac2( 2, umba::periph::DacBits::bits_8 );

    uint8_t val = 0;

    dac1.connect();
    dac2.connect();

    while(1)
    {
        dac1 =  val; // dac1.write(  val );
        dac2 = ~val; // dac2.write( ~val );
        ++val;
    }
    //DAC_TypeDef *pDac;
    
    return 0;
}

#ifdef  USE_FULL_ASSERT
extern "C"
void assert_failed(uint8_t* file, uint32_t line)
{ 
  while (1)
  {
  }
}
#endif
