#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "periph/gpio.h"
#include "periph/power.h"
#include "periph/adc.h"

#include "scalcus/pwm.h"
#include "scalcus/percent.h"

#include "periph/periph.h"


#include "string.h"

#include "milliganjubus_core/milliganjubus_i_milli_reg_table.h"
#include "milliganjubus_core/milliganjubus_simple_reg_table.h"
#include "milliganjubus_core/milliganjubus_slave_session.h"

#include "boards_conf/tvtx2v2_Hot_End_conf.h"
#include "vtx2v2/telexertex2_hot_end_regs.h"


// -E option make preprocessor output


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  lout(&charWritter);

uint8_t     thisBoardGanjubusAddr = 0x20;
unsigned    ganjubusUartSpeed     = 57600;


typedef milliganjubus::SimpleRegTable< regs::HotEnd::ro::min, regs::HotEnd::ro::max, 
                                       regs::HotEnd::rw::min, regs::HotEnd::rw::max >
                             RawRegTable;

RawRegTable         rawRegTable;
rdlc::RegTableSafe< RawRegTable, regs::HotEnd::ro::meta > roRegs( &rawRegTable );
rdlc::RegTableSafe< RawRegTable, regs::HotEnd::rw::meta > rwRegs( &rawRegTable );

static milliganjubus::SlaveSession slaveSession;

using namespace regs::HotEnd;


UMBA_PERIPH_DECLARE_PIN_EX( cooler_en_Pin,	 UMBA_PINADDR_PB12,	UMBA_GPIO_DIRECTION_OUT );
//UMBA_PERIPH_DECLARE_PIN_EX( heater_en_Pin,	 UMBA_PINADDR_PB13,	UMBA_GPIO_DIRECTION_OUT );
//UMBA_PERIPH_DECLARE_PIN_EX( temperature_Pin,	 UMBA_PINADDR_PB15,	UMBA_GPIO_DIRECTION_OUT );

// EXTRUDER_MOTOR

//UMBA_PERIPH_DECLARE_PIN_EX( extruder_motor_current_Pin,	UMBA_PINADDR_PA0,	UMBA_GPIO_DIRECTION_IN );
//UMBA_PERIPH_DECLARE_PIN_EX( extruder_motor_amplif_shdn_Pin,	UMBA_PINADDR_PC13,	UMBA_GPIO_DIRECTION_IN );
//UMBA_PERIPH_DECLARE_PIN_EX( extruder_motor_speed_Pin,	 UMBA_PINADDR_PA4,	UMBA_GPIO_DIRECTION_OUT );
//UMBA_PERIPH_DECLARE_PIN_EX( extruder_motor_nfault_Pin,	UMBA_PINADDR_PA5,	UMBA_GPIO_DIRECTION_IN );
//UMBA_PERIPH_DECLARE_PIN_EX( extruder_motor_in1_Pin,	 UMBA_PINADDR_PA6,	UMBA_GPIO_DIRECTION_OUT );
//UMBA_PERIPH_DECLARE_PIN_EX( extruder_motor_in2_Pin,	 UMBA_PINADDR_PA7,	UMBA_GPIO_DIRECTION_OUT );

// RS485

//UMBA_PERIPH_DECLARE_PIN_EX( rs485_link_de_Pin,	 UMBA_PINADDR_PB2,	UMBA_GPIO_DIRECTION_OUT );

// STATE_LEDS

UMBA_PERIPH_DECLARE_PIN_EX( led_link_Pin,	 UMBA_PINADDR_PA2 ,	UMBA_GPIO_DIRECTION_OUT );
//UMBA_PERIPH_DECLARE_PIN_EX( heater_en_Pin,	 UMBA_PINADDR_PB13,	UMBA_GPIO_DIRECTION_OUT );


const uint32_t  pwmFreq  = 2; //100;
unsigned        pwmPulseOutputMax = 0;
TIM_TypeDef    *heater_TIM = TIM1;
int             heater_TIM_channel = -1; // negative channel

int8_t          heaterCtrlCur = 0;



void onDataReceived()
{
    static int val = 0;
    ++val;

}


int main(void)
{
    using namespace umba::time_service;
    using namespace umba::omanip;

    umba::time_service::init();
    umba::time_service::start();

    RS485_LEGACY_UART.init( RS485_UART_RX_GPIO, RS485_UART_RX_GPIO_PIN_NO
                      , RS485_UART_TX_GPIO, RS485_UART_TX_GPIO_PIN_NO
                      , ganjubusUartSpeed
                      , RS485_LINK_DE_GPIO, 1<<RS485_LINK_DE_GPIO_PIN_NO
                      );

    // Init PWM
    using namespace umba::periph::traits;


    uint16_t prescalerT1 = 0;
    uint16_t periodT1    = 0;
    
    scalcus::calcTimerPwmPrescalerAndPeriod( SystemCoreClock, pwmFreq, prescalerT1, periodT1 );
    pwmPulseOutputMax = periodT1;

    umba::periph::traits::timerBaseInit( heater_TIM, prescalerT1, periodT1 ); 
    


    
    //timerEnable( heater_TIM, DISABLE );                  

    //timerEnable( heater_TIM, ENABLE );
    //timerSetCaptureCompareRegister( heater_TIM, heater_TIM_channel, 1 );

                      
    // __enable_irq();
    //  
    // while(true)
    // {
    //     GANJUBUS_LEGACY_UART.sendByte('a');
    //     for( volatile uint32_t i=0; i<10000; i++);
    // }

    led_link_Pin  = true;

    cooler_en_Pin = false;

    
    static callback::Callback<void ( void )> linkLostCallback    ( []() {  /* deviceLogic.onGanjubusLinkLost();     */  } );
    static callback::Callback<void ( void )> linkRestoredCallback( []() {  /* deviceLogic.onGanjubusLinkRestored(); */  } );
    static callback::Callback<void ( void )> dataReceivedCallback( []() { onDataReceived(); /* deviceLogic.onGanjubusDataReceived(); */  } );

    
    slaveSession.init( RS485_LEGACY_UART
                     , thisBoardGanjubusAddr
                     , rawRegTable
                     , linkLostCallback
                     , linkRestoredCallback
                     , 5000 // lost link timeout
                     , dataReceivedCallback );         // коллбэки


    //RCC_AHBPeriphClockCmd(RCC_AHBPeriph_ADC12, ENABLE);
    //RCC_AHBPeriphClockCmd(RCC_AHBPeriph_ADC34, ENABLE);`

#if 0    
    auto pAdc2 = ADC2;
    //auto pAdc4 = ADC4;
    auto //umba::periph::traits::AdcInjected 
         adc2 = umba::periph::adcInitInject( pAdc2 /* ADC4 */ , umba::periph::AdcSamplingSpeed::low
                                           , umba::periph::AdcInitHwOption::init
                                           , TEMPERATURE_GPIO_PIN_ADDR // temperatureAdcIndex = 0
                                           );
    const size_t temperatureAdcIndex = 0;
    //heater_en_Pin = true;
    heater_en_Pin = false;

    //extruder_motor_current_Pin     = true; 
    // extruder_motor_amplif_shdn_Pin = false; // pin direction detection error
    //extruder_motor_speed_Pin = true; // max current
    extruder_motor_speed_Pin = false;
    // extruder_motor_nfault_Pin - input, must be Hi

    // initial state - stopped
    extruder_motor_in1_Pin = false;
    extruder_motor_in2_Pin = false;

    //extruder_motor_in1_Pin = true;
    //extruder_motor_in2_Pin = false;

    led_link_Pin = true;


    auto rsGpio = RS485_LINK_DE_GPIO;

    static uint16_t hotendTemperature = 0;

#endif

    while(1)
    {
        auto tickNow = umba::time_service::getCurTimeMs();
        slaveSession.work( tickNow );

        //RS485_LEGACY_UART.sendByte(0xAA);
        //umba::time_service::delayMs(20);

        //hotendTemperature = adc2[temperatureAdcIndex];

        static int8_t    i8;
        static uint8_t   u8;
        //static uint16_t  u16;
        //static float    f32;

        if (rwRegs.getRegIfChanged( rw::extruder_speed_ctrl_s8, i8))
        {
            //cooler_en_Pin = false;
            led_link_Pin = i8 ? true : false;
        }

        if (rwRegs.getRegIfChanged( rw::heater_ctrl_s8, i8))
        {
            if (i8 < -100)
                i8 = -100;

            if (i8 > 100)
                i8 = 100;

            if (i8==0)
            {
                // stop cooler/heater
                //cooler_en_Pin = false;
                if (heaterCtrlCur)
                {
                    if (heaterCtrlCur>0)
                    {
                        // stop heater
                        timerEnable( heater_TIM, DISABLE );
                    }
                    else
                    {
                        // stp cooler
                        cooler_en_Pin = false;
                    }
                }
                else
                {
                }

            }
            else if (i8>0)
            {
                // start heater
                umba::periph::traits::timerInitChannelPwm( heater_TIM, heater_TIM_channel, UMBA_PINADDR_PB13.port, UMBA_PINADDR_PB13.pinNo, (periodT1+1)/pwmFreq-1, TIM_OCMode_PWM2 );
                timerSetCaptureCompareRegister( heater_TIM, heater_TIM_channel, 1 );
                umba::periph::traits::timerPwmControl( heater_TIM , heater_TIM_channel
                                                     , pwmFreq, pwmPulseOutputMax
                                                     , umba::periph::traits::TimerPwmControlType::percent
                                                     , (uint32_t)i8
                                                     );
                timerEnable( heater_TIM, ENABLE );
            }
            else
            {
                // start cooler
                cooler_en_Pin = true;
            }

            heaterCtrlCur = i8;

        }

    }



}








