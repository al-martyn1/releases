
#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"


#if !defined(STM32F3_SERIES)
    #error "STM32F3_SERIES not defined"
#endif



//#define USE_LEGACY_SPI_INIT


void spiInit();
uint16_t spiRead(uint16_t data);

umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::SimpleFormatter  lout(&charWritter);


//#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )



umba::periph::GpioPin  pinLD3 ( PE9  );
umba::periph::GpioPin  pinLD4 ( PE8  );
umba::periph::GpioPin  pinLD5 ( PE10 );
umba::periph::GpioPin  pinLD6 ( PE15 );
umba::periph::GpioPin  pinLD7 ( PE11 );
umba::periph::GpioPin  pinLD8 ( PE14 );
umba::periph::GpioPin  pinLD9 ( PE12 );
umba::periph::GpioPin  pinLD10( PE13 );

umba::periph::GpioPin* ledPinPtrs[] = { &pinLD3 
                                      , &pinLD5 
                                      , &pinLD7 
                                      , &pinLD9 
                                      , &pinLD10
                                      , &pinLD8 
                                      , &pinLD6 
                                      , &pinLD4 
                                      };

umba::periph::GpioPin  pinCs( PE3 );


int main(void)
{

    umba::time_service::init();
    umba::time_service::start();


    using namespace umba::time_service;
    using namespace umba::periph::traits;
    using namespace umba::omanip;

    uart::uart1.init( GPIOC, 5, GPIOC, 4, 460800 );


    pinCs = true;
    spiInit();
/*    
    periphAltFunctionConfigure( SPI1
                              , makePinAltFunctionInfo( PinFunctionSpi::sck , PA5  )
                              , makePinAltFunctionInfo( PinFunctionSpi::miso, PA6 )
                              , makePinAltFunctionInfo( PinFunctionSpi::mosi, PA7 )
                              );
*/

    lout<<"Hello F303"<<endl;

    size_t numLeds = sizeof( ledPinPtrs ) / sizeof( ledPinPtrs[0] );
    for( size_t i = 0; i != numLeds*3; ++i )
    {
        size_t nextI = i+1;
        size_t idxOff = i     % numLeds;
        size_t idxOn  = nextI % numLeds;

        *ledPinPtrs[idxOff] = false;
        *ledPinPtrs[idxOn]  = true;
        delayMs(20);
    }



    while(true)
    {
        uint16_t sendVal = 0;
        sendVal |= 0x8000; // RW (read) bit
        //sendVal |= 0x4000; // MS bit

        sendVal |= 0x0F00; // WHO_AM_I addr

        pinCs = false;
        spiChipSelectPause();

        //uint16_t res = spiRead(sendVal);
        spiWrite( SPI1, sendVal );
        uint16_t res = spiReadGetValue( SPI1 );

        pinCs = true;

        lout<<"WHO_AM_I: "<<bin<<width(8)<<noshowbase<<(uint8_t)(res&0xFF)<<endl;

        delayMs(20);
    }




    return 0;
}






void spiInit()
{
/*
    // OSD ~RESET - поднимаем
    pins::osd_not_reset.initOutPP();
    pins::osd_not_reset.set();
*/

    using namespace umba::periph::traits;

    #ifndef USE_LEGACY_SPI_INIT

    periphInit( SPI1, PA5, PA6, PA7, 16, BitsDirection::msb, SpiMode::CPOL_CPHA );

    #else
/*
    initPeriphClock( GPIOA, ENABLE, getPeriphClockGpioAltFunctionFlag(GPIOA) );

    ///////////////////////////////////////// ноги для SPI
    //pins::osd_spi_clk.initClock();
    //pins::osd_spi_miso.initClock();
    //pins::osd_spi_mosi.initClock();


    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_StructInit(&GPIO_InitStructure);

    // CLK, MOSI, MISO - Alter Func
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;

    GPIO_InitStructure.GPIO_Pin = 1<<5;
    GPIO_Init( GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = 1<<6;
    GPIO_Init( GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = 1<<7;
    GPIO_Init( GPIOA, &GPIO_InitStructure);

    //auto pin2pinSource = []( uint32_t pin ) { return 31 - __CLZ(pin); };

    GPIO_PinAFConfig( GPIOA, 5, GPIO_AF_5 );
    GPIO_PinAFConfig( GPIOA, 6, GPIO_AF_5 );
    GPIO_PinAFConfig( GPIOA, 7, GPIO_AF_5 );


    // not CS - out pp
    //pins::osd_spi_not_cs.initOutPP();
    //pins::osd_spi_not_cs.set();


    ///////////////////////////////////////// сам SPI

    SPI_InitTypeDef SPI_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);

    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_16b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_256;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &SPI_InitStructure);

    // для восьмибитного режима на STM32F3 нужно установить еще FIFO Threshold
    // иначе бит RXNE не будет выставляться при приеме одного байта
    SPI_RxFIFOThresholdConfig( SPI1, SPI_RxFIFOThreshold_QF );

    SPI_Cmd(SPI1, ENABLE);
*/
    #endif

    // инициализируем микросхему
}


uint16_t spiRead(uint16_t data)
{
    // кинуть байт
    SPI_I2S_SendData16(SPI1, data);

    // ждем, пока байт уйдет
    while(! (SPI1->SR & SPI_I2S_FLAG_TXE) );

    // ждем ответа
    while(! (SPI1->SR & SPI_I2S_FLAG_RXNE) );

    // ждем пока совсем все уже закончится
    while( SPI1->SR & SPI_I2S_FLAG_BSY );

    // гарантируем чтение
    uint16_t dummy = SPI_I2S_ReceiveData16(SPI1);

    return dummy;
}


