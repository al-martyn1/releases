#pragma once


#define MAX31855_FAULT_BIT_MASK      0x00010000 /* bit 16 */
#define MAX31855_SCV_BIT_MASK        0x00000004 /* Short to VCC */
#define MAX31855_SCG_BIT_MASK        0x00000002 /* Short to ground */
#define MAX31855_OC_BIT_MASK         0x00000001 /* Open circuit */


inline
bool max31855_checkFaulFlags( uint32_t raw )
{
    return raw & (MAX31855_FAULT_BIT_MASK | MAX31855_SCV_BIT_MASK | MAX31855_SCG_BIT_MASK | MAX31855_OC_BIT_MASK) ? true : false;
}

inline
int max31855_getTempFromRaw( uint32_t raw )
{
    int32_t i = (int32_t)raw;
    return (int)(i>>20); // 14 старших бит и удаляем 2^-2 - 16 + 2 + 2
}

inline
int max31855_getInternalTempFromRaw( uint32_t raw )
{
    int32_t i = (int32_t)raw;
    i <<= 16; // вытеснили биты температуры
    i >>= 16; // вернули взад, теперь в старших разрядах - наш знак
    i >>=  4; // remove 3 faults & reserved
    i >>=  4; // remove 2^-4
    return (int)i;
}
