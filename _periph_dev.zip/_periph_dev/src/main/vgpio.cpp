#include "vgpio/i_virtual_gpio.h"
#include "vgpio/stm32_gpio.h"
#include "vgpio/virtual_gpio.h"
#include "umba/time_service.h"

#include "periph/keyboard.h"




namespace vgpio     = umba::virtual_gpio;
namespace stm32gpio = umba::stm32_gpio;


const vgpio::PinType ledPhisPin = vgpio::pin_12;

stm32gpio::Stm32IoPort ledPhisPort( vgpio::Port::C
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::output
                              , vgpio::PinPushPullMode::pushPull
                              , ledPhisPin
                              );

//umba::virtual_gpio::
umba::virtual_gpio::VirtualOutputPin virtualPins[] = { { &ledPhisPort, ledPhisPin }
                                                     , { 0, 0 }
                                                     };

umba::virtual_gpio::VirtualOutputPort ledPort( &virtualPins[0] );


stm32gpio::Stm32IoPort rowOutputPort( vgpio::Port::B
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::output
                              , vgpio::PinPushPullMode::pushPull
                              , vgpio::pin_0 | vgpio::pin_1 | vgpio::pin_2 // | vgpio::pin_3
                              );

stm32gpio::Stm32IoPort colInputPort( vgpio::Port::C
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::input
                              , vgpio::PinPushPullMode::pullDown
                              , vgpio::pin_0 | vgpio::pin_1 | vgpio::pin_2 | vgpio::pin_3
                              );



class KeyboardHandler : implements umba::periph::IKeyboardHandler
{
    virtual
    void onKeyPress( size_t keyNo, bool fPressed, size_t repeatCout ) override
    {
        if (!fPressed)
            return;

        if (repeatCout>1)
            return;

        if (keyNo&1)
           ledPort.setOutput( ledPort.getPins() );
        else
           ledPort.clrOutput( ledPort.getPins() );

        ledPort.writeFlushPins();
    }

}; // interface IKeyboardHandler


KeyboardHandler kbdHandler;
umba::periph::Keyboard<16>  kbd( &kbdHandler, &colInputPort, &rowOutputPort );



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    ledPhisPort.initPort();
    ledPort.initPort();
    rowOutputPort.initPort();
    colInputPort.initPort();

    ledPort.clrOutput( ledPort.getPins() );

    while(1)
    {
        umba::time_service::delayMs(1);
        kbd.scanKeyboard();
        //ledPort.toggleOutput( ledPort.getPins() );

    }

    return 0;
}
