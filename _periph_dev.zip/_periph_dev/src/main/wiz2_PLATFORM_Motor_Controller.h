// Generator: h_conf

//  - Netlist_1

// MCU DD1 STM32F303VD peripherals

// DD3

#define MCU1_SPI                                      SPI2
#define USE_SPI2                                      1
#define MCU1_SPI_SCK_GPIO                             GPIOF
#define MCU1_SPI_SCK_GPIO_PIN_NO                      9
#define MCU1_SPI_SCK_GPIO_PIN_ADDR                    UMBA_PINADDR_PF9
#define MCU1_SPI_SCK_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PF9, UMBA_GPIO_DIRECTION_OUT
#define MCU1_SPI_SCK_GPIO_PIN_SOURCE                  GPIO_PinSource9
#define MCU1_SPI_SCK_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define DRV1_INH_A_GPIO                               GPIOC
#define DRV1_INH_A_GPIO_PIN_NO                        0
#define DRV1_INH_A_GPIO_PIN_ADDR                      UMBA_PINADDR_PC0
#define DRV1_INH_A_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PC0, UMBA_GPIO_DIRECTION_IN
#define DRV1_INH_A_GPIO_PIN_SOURCE                    GPIO_PinSource0
#define DRV1_INH_A_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define DRV1_INH_B_GPIO                               GPIOC
#define DRV1_INH_B_GPIO_PIN_NO                        1
#define DRV1_INH_B_GPIO_PIN_ADDR                      UMBA_PINADDR_PC1
#define DRV1_INH_B_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PC1, UMBA_GPIO_DIRECTION_IN
#define DRV1_INH_B_GPIO_PIN_SOURCE                    GPIO_PinSource1
#define DRV1_INH_B_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define DRV1_INH_C_GPIO                               GPIOC
#define DRV1_INH_C_GPIO_PIN_NO                        2
#define DRV1_INH_C_GPIO_PIN_ADDR                      UMBA_PINADDR_PC2
#define DRV1_INH_C_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PC2, UMBA_GPIO_DIRECTION_IN
#define DRV1_INH_C_GPIO_PIN_SOURCE                    GPIO_PinSource2
#define DRV1_INH_C_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define DRV1_nFAULT_GPIO                              GPIOC
#define DRV1_nFAULT_GPIO_PIN_NO                       3
#define DRV1_nFAULT_GPIO_PIN_ADDR                     UMBA_PINADDR_PC3
#define DRV1_nFAULT_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PC3, UMBA_GPIO_DIRECTION_IN
#define DRV1_nFAULT_GPIO_PIN_SOURCE                   GPIO_PinSource3
#define DRV1_nFAULT_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_IN

#define DRV1_nOCTW_GPIO                               GPIOF
#define DRV1_nOCTW_GPIO_PIN_NO                        2
#define DRV1_nOCTW_GPIO_PIN_ADDR                      UMBA_PINADDR_PF2
#define DRV1_nOCTW_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PF2, UMBA_GPIO_DIRECTION_IN
#define DRV1_nOCTW_GPIO_PIN_SOURCE                    GPIO_PinSource2
#define DRV1_nOCTW_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define DRV1_INL_B_GPIO                               GPIOB
#define DRV1_INL_B_GPIO_PIN_NO                        0
#define DRV1_INL_B_GPIO_PIN_ADDR                      UMBA_PINADDR_PB0
#define DRV1_INL_B_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB0, UMBA_GPIO_DIRECTION_IN
#define DRV1_INL_B_GPIO_PIN_SOURCE                    GPIO_PinSource0
#define DRV1_INL_B_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define DRV1_INL_C_GPIO                               GPIOB
#define DRV1_INL_C_GPIO_PIN_NO                        1
#define DRV1_INL_C_GPIO_PIN_ADDR                      UMBA_PINADDR_PB1
#define DRV1_INL_C_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB1, UMBA_GPIO_DIRECTION_IN
#define DRV1_INL_C_GPIO_PIN_SOURCE                    GPIO_PinSource1
#define DRV1_INL_C_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define DRV1_DC_CAL_GPIO                              GPIOE
#define DRV1_DC_CAL_GPIO_PIN_NO                       8
#define DRV1_DC_CAL_GPIO_PIN_ADDR                     UMBA_PINADDR_PE8
#define DRV1_DC_CAL_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PE8, UMBA_GPIO_DIRECTION_IN
#define DRV1_DC_CAL_GPIO_PIN_SOURCE                   GPIO_PinSource8
#define DRV1_DC_CAL_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_IN

#define DRV1_PWRGD_GPIO                               GPIOE
#define DRV1_PWRGD_GPIO_PIN_NO                        9
#define DRV1_PWRGD_GPIO_PIN_ADDR                      UMBA_PINADDR_PE9
#define DRV1_PWRGD_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PE9, UMBA_GPIO_DIRECTION_IN
#define DRV1_PWRGD_GPIO_PIN_SOURCE                    GPIO_PinSource9
#define DRV1_PWRGD_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define MCU1_SPI_MOSI_GPIO                            GPIOB
#define MCU1_SPI_MOSI_GPIO_PIN_NO                     15
#define MCU1_SPI_MOSI_GPIO_PIN_ADDR                   UMBA_PINADDR_PB15
#define MCU1_SPI_MOSI_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PB15, UMBA_GPIO_DIRECTION_OUT
#define MCU1_SPI_MOSI_GPIO_PIN_SOURCE                 GPIO_PinSource15
#define MCU1_SPI_MOSI_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT

#define MCU1_DRV_CS_GPIO                              GPIOD
#define MCU1_DRV_CS_GPIO_PIN_NO                       11
#define MCU1_DRV_CS_GPIO_PIN_ADDR                     UMBA_PINADDR_PD11
#define MCU1_DRV_CS_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PD11, UMBA_GPIO_DIRECTION_IN
#define MCU1_DRV_CS_GPIO_PIN_SOURCE                   GPIO_PinSource11
#define MCU1_DRV_CS_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_IN

#define MCU1_SPI_MISO_GPIO                            GPIOA
#define MCU1_SPI_MISO_GPIO_PIN_NO                     10
#define MCU1_SPI_MISO_GPIO_PIN_ADDR                   UMBA_PINADDR_PA10
#define MCU1_SPI_MISO_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PA10, UMBA_GPIO_DIRECTION_IN
#define MCU1_SPI_MISO_GPIO_PIN_SOURCE                 GPIO_PinSource10
#define MCU1_SPI_MISO_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN

#define DRV1_INL_A_GPIO                               GPIOC
#define DRV1_INL_A_GPIO_PIN_NO                        13
#define DRV1_INL_A_GPIO_PIN_ADDR                      UMBA_PINADDR_PC13
#define DRV1_INL_A_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PC13, UMBA_GPIO_DIRECTION_IN
#define DRV1_INL_A_GPIO_PIN_SOURCE                    GPIO_PinSource13
#define DRV1_INL_A_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define DRV1_ENGATE_GPIO                              GPIOC
#define DRV1_ENGATE_GPIO_PIN_NO                       14
#define DRV1_ENGATE_GPIO_PIN_ADDR                     UMBA_PINADDR_PC14
#define DRV1_ENGATE_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PC14, UMBA_GPIO_DIRECTION_IN
#define DRV1_ENGATE_GPIO_PIN_SOURCE                   GPIO_PinSource14
#define DRV1_ENGATE_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_IN

#define DRV1_CUR1_GPIO                                GPIOA
#define DRV1_CUR1_GPIO_PIN_NO                         0
#define DRV1_CUR1_GPIO_PIN_ADDR                       UMBA_PINADDR_PA0
#define DRV1_CUR1_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PA0, UMBA_GPIO_DIRECTION_IN
#define DRV1_CUR1_GPIO_PIN_SOURCE                     GPIO_PinSource0
#define DRV1_CUR1_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_IN

#define DRV1_CUR2_GPIO                                GPIOA
#define DRV1_CUR2_GPIO_PIN_NO                         1
#define DRV1_CUR2_GPIO_PIN_ADDR                       UMBA_PINADDR_PA1
#define DRV1_CUR2_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PA1, UMBA_GPIO_DIRECTION_IN
#define DRV1_CUR2_GPIO_PIN_SOURCE                     GPIO_PinSource1
#define DRV1_CUR2_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_IN




// CAN

#define CAN_CAN                                       CAN
#define USE_CAN                                       1
#define CAN_CAN_RX_GPIO                               GPIOA
#define CAN_CAN_RX_GPIO_PIN_NO                        11
#define CAN_CAN_RX_GPIO_PIN_ADDR                      UMBA_PINADDR_PA11
#define CAN_CAN_RX_GPIO_PIN_SOURCE                    GPIO_PinSource11
#define CAN_CAN_RX_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define CAN_CAN_TX_GPIO                               GPIOA
#define CAN_CAN_TX_GPIO_PIN_NO                        12
#define CAN_CAN_TX_GPIO_PIN_ADDR                      UMBA_PINADDR_PA12
#define CAN_CAN_TX_GPIO_PIN_SOURCE                    GPIO_PinSource12
#define CAN_CAN_TX_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define CAN_LBK_GPIO                                  GPIOA
#define CAN_LBK_GPIO_PIN_NO                           15
#define CAN_LBK_GPIO_PIN_ADDR                         UMBA_PINADDR_PA15
#define CAN_LBK_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PA15, UMBA_GPIO_DIRECTION_OUT
#define CAN_LBK_GPIO_PIN_SOURCE                       GPIO_PinSource15
#define CAN_LBK_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAN_ID1_GPIO                                  GPIOB
#define CAN_ID1_GPIO_PIN_NO                           14
#define CAN_ID1_GPIO_PIN_ADDR                         UMBA_PINADDR_PB14
#define CAN_ID1_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB14, UMBA_GPIO_DIRECTION_OUT
#define CAN_ID1_GPIO_PIN_SOURCE                       GPIO_PinSource14
#define CAN_ID1_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAN_ID2_GPIO                                  GPIOB
#define CAN_ID2_GPIO_PIN_NO                           10
#define CAN_ID2_GPIO_PIN_ADDR                         UMBA_PINADDR_PB10
#define CAN_ID2_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB10, UMBA_GPIO_DIRECTION_OUT
#define CAN_ID2_GPIO_PIN_SOURCE                       GPIO_PinSource10
#define CAN_ID2_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAN_ID3_GPIO                                  GPIOB
#define CAN_ID3_GPIO_PIN_NO                           11
#define CAN_ID3_GPIO_PIN_ADDR                         UMBA_PINADDR_PB11
#define CAN_ID3_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB11, UMBA_GPIO_DIRECTION_OUT
#define CAN_ID3_GPIO_PIN_SOURCE                       GPIO_PinSource11
#define CAN_ID3_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAN_ID4_GPIO                                  GPIOB
#define CAN_ID4_GPIO_PIN_NO                           12
#define CAN_ID4_GPIO_PIN_ADDR                         UMBA_PINADDR_PB12
#define CAN_ID4_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT
#define CAN_ID4_GPIO_PIN_SOURCE                       GPIO_PinSource12
#define CAN_ID4_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAN_ID5_GPIO                                  GPIOB
#define CAN_ID5_GPIO_PIN_NO                           13
#define CAN_ID5_GPIO_PIN_ADDR                         UMBA_PINADDR_PB13
#define CAN_ID5_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT
#define CAN_ID5_GPIO_PIN_SOURCE                       GPIO_PinSource13
#define CAN_ID5_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT




// DIG

#define DIG_IN1_GPIO                                  GPIOA
#define DIG_IN1_GPIO_PIN_NO                           8
#define DIG_IN1_GPIO_PIN_ADDR                         UMBA_PINADDR_PA8
#define DIG_IN1_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PA8, UMBA_GPIO_DIRECTION_OUT
#define DIG_IN1_GPIO_PIN_SOURCE                       GPIO_PinSource8
#define DIG_IN1_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define DIG_IN2_GPIO                                  GPIOA
#define DIG_IN2_GPIO_PIN_NO                           9
#define DIG_IN2_GPIO_PIN_ADDR                         UMBA_PINADDR_PA9
#define DIG_IN2_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PA9, UMBA_GPIO_DIRECTION_OUT
#define DIG_IN2_GPIO_PIN_SOURCE                       GPIO_PinSource9
#define DIG_IN2_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define DIG_IN3_GPIO                                  GPIOD
#define DIG_IN3_GPIO_PIN_NO                           15
#define DIG_IN3_GPIO_PIN_ADDR                         UMBA_PINADDR_PD15
#define DIG_IN3_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PD15, UMBA_GPIO_DIRECTION_OUT
#define DIG_IN3_GPIO_PIN_SOURCE                       GPIO_PinSource15
#define DIG_IN3_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define DIG_IN4_GPIO                                  GPIOC
#define DIG_IN4_GPIO_PIN_NO                           6
#define DIG_IN4_GPIO_PIN_ADDR                         UMBA_PINADDR_PC6
#define DIG_IN4_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PC6, UMBA_GPIO_DIRECTION_OUT
#define DIG_IN4_GPIO_PIN_SOURCE                       GPIO_PinSource6
#define DIG_IN4_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT




// LIR

#define LIR_CLK_GPIO                                  GPIOE
#define LIR_CLK_GPIO_PIN_NO                           12
#define LIR_CLK_GPIO_PIN_ADDR                         UMBA_PINADDR_PE12
#define LIR_CLK_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PE12, UMBA_GPIO_DIRECTION_OUT
#define LIR_CLK_GPIO_PIN_SOURCE                       GPIO_PinSource12
#define LIR_CLK_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define LIR_DATA_GPIO                                 GPIOE
#define LIR_DATA_GPIO_PIN_NO                          13
#define LIR_DATA_GPIO_PIN_ADDR                        UMBA_PINADDR_PE13
#define LIR_DATA_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PE13, UMBA_GPIO_DIRECTION_OUT
#define LIR_DATA_GPIO_PIN_SOURCE                      GPIO_PinSource13
#define LIR_DATA_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT




// MCU2_ENC

#define MCU2_ENC_A_GPIO                               GPIOD
#define MCU2_ENC_A_GPIO_PIN_NO                        12
#define MCU2_ENC_A_GPIO_PIN_ADDR                      UMBA_PINADDR_PD12
#define MCU2_ENC_A_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PD12, UMBA_GPIO_DIRECTION_OUT
#define MCU2_ENC_A_GPIO_PIN_SOURCE                    GPIO_PinSource12
#define MCU2_ENC_A_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MCU2_ENC_B_GPIO                               GPIOD
#define MCU2_ENC_B_GPIO_PIN_NO                        13
#define MCU2_ENC_B_GPIO_PIN_ADDR                      UMBA_PINADDR_PD13
#define MCU2_ENC_B_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PD13, UMBA_GPIO_DIRECTION_OUT
#define MCU2_ENC_B_GPIO_PIN_SOURCE                    GPIO_PinSource13
#define MCU2_ENC_B_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MCU2_ENC_I_GPIO                               GPIOD
#define MCU2_ENC_I_GPIO_PIN_NO                        14
#define MCU2_ENC_I_GPIO_PIN_ADDR                      UMBA_PINADDR_PD14
#define MCU2_ENC_I_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PD14, UMBA_GPIO_DIRECTION_OUT
#define MCU2_ENC_I_GPIO_PIN_SOURCE                    GPIO_PinSource14
#define MCU2_ENC_I_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT




// SHUNT

#define SHUNT_CUR_GPIO                                GPIOA
#define SHUNT_CUR_GPIO_PIN_NO                         3
#define SHUNT_CUR_GPIO_PIN_ADDR                       UMBA_PINADDR_PA3
#define SHUNT_CUR_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PA3, UMBA_GPIO_DIRECTION_OUT
#define SHUNT_CUR_GPIO_PIN_SOURCE                     GPIO_PinSource3
#define SHUNT_CUR_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define SHUNT_SIGN_GPIO                               GPIOB
#define SHUNT_SIGN_GPIO_PIN_NO                        2
#define SHUNT_SIGN_GPIO_PIN_ADDR                      UMBA_PINADDR_PB2
#define SHUNT_SIGN_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB2, UMBA_GPIO_DIRECTION_OUT
#define SHUNT_SIGN_GPIO_PIN_SOURCE                    GPIO_PinSource2
#define SHUNT_SIGN_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT




// SPI

#define SPI_IRQ_GPIO                                  GPIOC
#define SPI_IRQ_GPIO_PIN_NO                           7
#define SPI_IRQ_GPIO_PIN_ADDR                         UMBA_PINADDR_PC7
#define SPI_IRQ_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PC7, UMBA_GPIO_DIRECTION_OUT
#define SPI_IRQ_GPIO_PIN_SOURCE                       GPIO_PinSource7
#define SPI_IRQ_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define SPI_SPI                                       SPI3
#define USE_SPI3                                      1
#define SPI_SPI_SCK_GPIO                              GPIOC
#define SPI_SPI_SCK_GPIO_PIN_NO                       10
#define SPI_SPI_SCK_GPIO_PIN_ADDR                     UMBA_PINADDR_PC10
#define SPI_SPI_SCK_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PC10, UMBA_GPIO_DIRECTION_OUT
#define SPI_SPI_SCK_GPIO_PIN_SOURCE                   GPIO_PinSource10
#define SPI_SPI_SCK_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT

#define SPI_SPI_MISO_GPIO                             GPIOC
#define SPI_SPI_MISO_GPIO_PIN_NO                      11
#define SPI_SPI_MISO_GPIO_PIN_ADDR                    UMBA_PINADDR_PC11
#define SPI_SPI_MISO_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PC11, UMBA_GPIO_DIRECTION_IN
#define SPI_SPI_MISO_GPIO_PIN_SOURCE                  GPIO_PinSource11
#define SPI_SPI_MISO_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_IN

#define SPI_SPI_MOSI_GPIO                             GPIOC
#define SPI_SPI_MOSI_GPIO_PIN_NO                      12
#define SPI_SPI_MOSI_GPIO_PIN_ADDR                    UMBA_PINADDR_PC12
#define SPI_SPI_MOSI_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PC12, UMBA_GPIO_DIRECTION_OUT
#define SPI_SPI_MOSI_GPIO_PIN_SOURCE                  GPIO_PinSource12
#define SPI_SPI_MOSI_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define SPI_CS1_GPIO                                  GPIOC
#define SPI_CS1_GPIO_PIN_NO                           9
#define SPI_CS1_GPIO_PIN_ADDR                         UMBA_PINADDR_PC9
#define SPI_CS1_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PC9, UMBA_GPIO_DIRECTION_OUT
#define SPI_CS1_GPIO_PIN_SOURCE                       GPIO_PinSource9
#define SPI_CS1_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define SPI_CS2_GPIO                                  GPIOC
#define SPI_CS2_GPIO_PIN_NO                           8
#define SPI_CS2_GPIO_PIN_ADDR                         UMBA_PINADDR_PC8
#define SPI_CS2_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PC8, UMBA_GPIO_DIRECTION_OUT
#define SPI_CS2_GPIO_PIN_SOURCE                       GPIO_PinSource8
#define SPI_CS2_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT




// UART

#define UART_UART                                     UART1
#define UART_LEGACY_UART                              uart::uart1
#define USE_UART1                                     1
#define UART_UART_TX_GPIO                             GPIOC
#define UART_UART_TX_GPIO_PIN_NO                      4
#define UART_UART_TX_GPIO_PIN_ADDR                    UMBA_PINADDR_PC4
#define UART_UART_TX_GPIO_PIN_SOURCE                  GPIO_PinSource4
#define UART_UART_TX_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define UART_UART_RX_GPIO                             GPIOC
#define UART_UART_RX_GPIO_PIN_NO                      5
#define UART_UART_RX_GPIO_PIN_ADDR                    UMBA_PINADDR_PC5
#define UART_UART_RX_GPIO_PIN_SOURCE                  GPIO_PinSource5
#define UART_UART_RX_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_IN




// Unclassified

#define VOLT_IN_GPIO                                  GPIOA
#define VOLT_IN_GPIO_PIN_NO                           2
#define VOLT_IN_GPIO_PIN_ADDR                         UMBA_PINADDR_PA2
#define VOLT_IN_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PA2, UMBA_GPIO_DIRECTION_OUT
#define VOLT_IN_GPIO_PIN_SOURCE                       GPIO_PinSource2
#define VOLT_IN_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define TEMP_GPIO                                     GPIOD
#define TEMP_GPIO_PIN_NO                              10
#define TEMP_GPIO_PIN_ADDR                            UMBA_PINADDR_PD10
#define TEMP_GPIO_PIN_ADDR_DIR                        UMBA_PINADDR_PD10, UMBA_GPIO_DIRECTION_OUT
#define TEMP_GPIO_PIN_SOURCE                          GPIO_PinSource10
#define TEMP_GPIO_PIN_DIRECTION                       UMBA_GPIO_DIRECTION_OUT

#define STO_OUT_GPIO                                  GPIOD
#define STO_OUT_GPIO_PIN_NO                           2
#define STO_OUT_GPIO_PIN_ADDR                         UMBA_PINADDR_PD2
#define STO_OUT_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PD2, UMBA_GPIO_DIRECTION_OUT
#define STO_OUT_GPIO_PIN_SOURCE                       GPIO_PinSource2
#define STO_OUT_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define AUTO_BIT_RATE_GPIO                            GPIOE
#define AUTO_BIT_RATE_GPIO_PIN_NO                     11
#define AUTO_BIT_RATE_GPIO_PIN_ADDR                   UMBA_PINADDR_PE11
#define AUTO_BIT_RATE_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PE11, UMBA_GPIO_DIRECTION_OUT
#define AUTO_BIT_RATE_GPIO_PIN_SOURCE                 GPIO_PinSource11
#define AUTO_BIT_RATE_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT

#define AN_IN1PLUS_GPIO                               GPIOA
#define AN_IN1PLUS_GPIO_PIN_NO                        6
#define AN_IN1PLUS_GPIO_PIN_ADDR                      UMBA_PINADDR_PA6
#define AN_IN1PLUS_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PA6, UMBA_GPIO_DIRECTION_OUT
#define AN_IN1PLUS_GPIO_PIN_SOURCE                    GPIO_PinSource6
#define AN_IN1PLUS_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define AN_IN1MINUS_GPIO                              GPIOA
#define AN_IN1MINUS_GPIO_PIN_NO                       7
#define AN_IN1MINUS_GPIO_PIN_ADDR                     UMBA_PINADDR_PA7
#define AN_IN1MINUS_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PA7, UMBA_GPIO_DIRECTION_OUT
#define AN_IN1MINUS_GPIO_PIN_SOURCE                   GPIO_PinSource7
#define AN_IN1MINUS_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT

#define AN_OUT1_GPIO                                  GPIOA
#define AN_OUT1_GPIO_PIN_NO                           4
#define AN_OUT1_GPIO_PIN_ADDR                         UMBA_PINADDR_PA4
#define AN_OUT1_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PA4, UMBA_GPIO_DIRECTION_OUT
#define AN_OUT1_GPIO_PIN_SOURCE                       GPIO_PinSource4
#define AN_OUT1_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define MCU1_LED_OK_GPIO                              GPIOD
#define MCU1_LED_OK_GPIO_PIN_NO                       8
#define MCU1_LED_OK_GPIO_PIN_ADDR                     UMBA_PINADDR_PD8
#define MCU1_LED_OK_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PD8, UMBA_GPIO_DIRECTION_OUT
#define MCU1_LED_OK_GPIO_PIN_SOURCE                   GPIO_PinSource8
#define MCU1_LED_OK_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT

#define MCU1_LED_FAIL_GPIO                            GPIOD
#define MCU1_LED_FAIL_GPIO_PIN_NO                     9
#define MCU1_LED_FAIL_GPIO_PIN_ADDR                   UMBA_PINADDR_PD9
#define MCU1_LED_FAIL_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PD9, UMBA_GPIO_DIRECTION_OUT
#define MCU1_LED_FAIL_GPIO_PIN_SOURCE                 GPIO_PinSource9
#define MCU1_LED_FAIL_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT


#define DIG_OUT1_GPIO                                 GPIOE
#define DIG_OUT1_GPIO_PIN_NO                          1
#define DIG_OUT1_GPIO_PIN_ADDR                        UMBA_PINADDR_PE1
#define DIG_OUT1_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PE1, UMBA_GPIO_DIRECTION_OUT
#define DIG_OUT1_GPIO_PIN_SOURCE                      GPIO_PinSource1
#define DIG_OUT1_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT



#define STO_IN1_GPIO                                  GPIOD
#define STO_IN1_GPIO_PIN_NO                           0
#define STO_IN1_GPIO_PIN_ADDR                         UMBA_PINADDR_PD0
#define STO_IN1_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PD0, UMBA_GPIO_DIRECTION_OUT
#define STO_IN1_GPIO_PIN_SOURCE                       GPIO_PinSource0
#define STO_IN1_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define HALL1_GPIO                                    GPIOE
#define HALL1_GPIO_PIN_NO                             2
#define HALL1_GPIO_PIN_ADDR                           UMBA_PINADDR_PE2
#define HALL1_GPIO_PIN_ADDR_DIR                       UMBA_PINADDR_PE2, UMBA_GPIO_DIRECTION_OUT
#define HALL1_GPIO_PIN_SOURCE                         GPIO_PinSource2
#define HALL1_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT

#define MCU1_ENC_A_GPIO                               GPIOD
#define MCU1_ENC_A_GPIO_PIN_NO                        3
#define MCU1_ENC_A_GPIO_PIN_ADDR                      UMBA_PINADDR_PD3
#define MCU1_ENC_A_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PD3, UMBA_GPIO_DIRECTION_OUT
#define MCU1_ENC_A_GPIO_PIN_SOURCE                    GPIO_PinSource3
#define MCU1_ENC_A_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MCU1_ENC_B_GPIO                               GPIOD
#define MCU1_ENC_B_GPIO_PIN_NO                        4
#define MCU1_ENC_B_GPIO_PIN_ADDR                      UMBA_PINADDR_PD4
#define MCU1_ENC_B_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PD4, UMBA_GPIO_DIRECTION_OUT
#define MCU1_ENC_B_GPIO_PIN_SOURCE                    GPIO_PinSource4
#define MCU1_ENC_B_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MCU1_ENC_EN_GPIO                              GPIOD
#define MCU1_ENC_EN_GPIO_PIN_NO                       5
#define MCU1_ENC_EN_GPIO_PIN_ADDR                     UMBA_PINADDR_PD5
#define MCU1_ENC_EN_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PD5, UMBA_GPIO_DIRECTION_OUT
#define MCU1_ENC_EN_GPIO_PIN_SOURCE                   GPIO_PinSource5
#define MCU1_ENC_EN_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT

#define AN_IN2PLUS_GPIO                               GPIOE
#define AN_IN2PLUS_GPIO_PIN_NO                        14
#define AN_IN2PLUS_GPIO_PIN_ADDR                      UMBA_PINADDR_PE14
#define AN_IN2PLUS_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PE14, UMBA_GPIO_DIRECTION_OUT
#define AN_IN2PLUS_GPIO_PIN_SOURCE                    GPIO_PinSource14
#define AN_IN2PLUS_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define AN_IN2MINUS_GPIO                              GPIOE
#define AN_IN2MINUS_GPIO_PIN_NO                       15
#define AN_IN2MINUS_GPIO_PIN_ADDR                     UMBA_PINADDR_PE15
#define AN_IN2MINUS_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PE15, UMBA_GPIO_DIRECTION_OUT
#define AN_IN2MINUS_GPIO_PIN_SOURCE                   GPIO_PinSource15
#define AN_IN2MINUS_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT

#define AN_OUT2_GPIO                                  GPIOA
#define AN_OUT2_GPIO_PIN_NO                           5
#define AN_OUT2_GPIO_PIN_ADDR                         UMBA_PINADDR_PA5
#define AN_OUT2_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PA5, UMBA_GPIO_DIRECTION_OUT
#define AN_OUT2_GPIO_PIN_SOURCE                       GPIO_PinSource5
#define AN_OUT2_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define DIG_OUT2_GPIO                                 GPIOE
#define DIG_OUT2_GPIO_PIN_NO                          0
#define DIG_OUT2_GPIO_PIN_ADDR                        UMBA_PINADDR_PE0
#define DIG_OUT2_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PE0, UMBA_GPIO_DIRECTION_OUT
#define DIG_OUT2_GPIO_PIN_SOURCE                      GPIO_PinSource0
#define DIG_OUT2_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define STO_IN2_GPIO                                  GPIOD
#define STO_IN2_GPIO_PIN_NO                           1
#define STO_IN2_GPIO_PIN_ADDR                         UMBA_PINADDR_PD1
#define STO_IN2_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PD1, UMBA_GPIO_DIRECTION_OUT
#define STO_IN2_GPIO_PIN_SOURCE                       GPIO_PinSource1
#define STO_IN2_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define HALL2_GPIO                                    GPIOE
#define HALL2_GPIO_PIN_NO                             3
#define HALL2_GPIO_PIN_ADDR                           UMBA_PINADDR_PE3
#define HALL2_GPIO_PIN_ADDR_DIR                       UMBA_PINADDR_PE3, UMBA_GPIO_DIRECTION_OUT
#define HALL2_GPIO_PIN_SOURCE                         GPIO_PinSource3
#define HALL2_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT

#define HALL3_GPIO                                    GPIOE
#define HALL3_GPIO_PIN_NO                             4
#define HALL3_GPIO_PIN_ADDR                           UMBA_PINADDR_PE4
#define HALL3_GPIO_PIN_ADDR_DIR                       UMBA_PINADDR_PE4, UMBA_GPIO_DIRECTION_OUT
#define HALL3_GPIO_PIN_SOURCE                         GPIO_PinSource4
#define HALL3_GPIO_PIN_DIRECTION                      UMBA_GPIO_DIRECTION_OUT




