#include "rtkos/rtkos.h"
#include "umba/debug_helpers.h"


#ifdef UMBA_MCU_USED
    // Will test on discavery
    #include "periph/stm32_discovery.h"
#endif

// Кроме Keil'а везде норм
#ifndef UMBA_MCU_USED
// First lines must configure log subsustem
//UMBA_RTKOS_USE_LOG_STREAM_SWD();
UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( STM32_DISCOVERY_LEGACY_UART, STM32_DISCOVERY_UART, 460800 );
#endif


/*
namespace
{
priv::UartInitializer& getInitializer( uart::Handle &uart
                                     , GPIO_TypeDef *portRx
                                     , uint16_t rxPinNo
                                     , GPIO_TypeDef *portTx
                                     , uint16_t txPinNo
                                     , uint32_t baudrate
                                     )
{
static priv::UartInitializer i( uart, portRx, rxPinNo, portTx, txPinNo, baudrate);
return i;
}
umba::LegacyUartCharWriter<255> logCharWritter = umba::LegacyUartCharWriter<255>( uart::uart1 ). setTextMode(true). setAnsiTerminalMode(true). setAtFastBlink( false ) ;
umba::SimpleFormatter logStreamFormatter( &logCharWritter ); umba::rtkos::priv::LogStreamSetter logStreamSetter( getInitializer( uart::uart1, ((GPIO_TypeDef *) ((((uint32_t)0x40000000) + 0x08000000) + 0x0800)), 5, ((GPIO_TypeDef *) ((((uint32_t)0x40000000) + 0x08000000) + 0x0800)), 4, 460800 ). passthrough(logStreamFormatter) );
};
*/

//#define TASK_REPORT(taskName)
#define TASK_REPORT(taskName)  UMBA_RTKOS_LOG<< #taskName << ", now: "<<umba::time_service::getCurTimeMs()<<umba::omanip::endl

#include "umba/stl.h"

//#include "prototest.h"

#include "rtkos/rtkos_protothread.h"


auto tim2 = umba::rtkos::makeSimpleTimerHandler( []( umba::ITimerHandler *pth, unsigned eventId )
                                                 {
                                                     UMBA_RTKOS_LOG<<"tim2: "<<umba::time_service::getCurTimeMs()<<umba::omanip::endl;
                                                 }
                                               );

auto tim1 = umba::rtkos::makeSimpleTimerHandler( [&]( umba::ITimerHandler *pth, unsigned eventId )
                                                 {
                                                     UMBA_RTKOS_LOG<<"tim1: "<<umba::time_service::getCurTimeMs()<<umba::omanip::endl;
                                                     umba::rtkos::timerSet( pth, 0, 0 ); // stop self
                                                     umba::rtkos::timerSet( &tim2, 1, 1000 ); // run next
                                                 }
                                               );


struct StarterThread0 : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel0> // StarterThreadBase // umba::rtkos::Protothread
{
    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove nerver used warning

         UMBA_RTKOS_LOG<<"Startup level 0 step 1"<<umba::omanip::endl;
         timer.start(750);
         PT_WAIT_UNTIL(timer.expired());

         UMBA_RTKOS_LOG<<"Startup level 0 step 2"<<umba::omanip::endl;
         timer.start(1000);
         PT_WAIT_UNTIL(timer.expired());

         //UMBA_RTKOS_LOG<<"Starting level 0 tim1"<<umba::omanip::endl;

         //umba::rtkos::timerSet( &tim1, 0, 3000 );

         UMBA_RTKOS_LOG<<"RunLevel 0 finished"<<umba::omanip::endl;

         PT_END();
    }

}; // struct StarterThread0

struct StarterThread1 : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel1> // StarterThreadBase // umba::rtkos::Protothread
{
    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove nerver used warning

         UMBA_RTKOS_LOG<<"Startup level 1 step 1"<<umba::omanip::endl;
         timer.start(750);
         PT_WAIT_UNTIL(timer.expired());

         UMBA_RTKOS_LOG<<"Startup level 1 step 2"<<umba::omanip::endl;
         timer.start(1000);
         PT_WAIT_UNTIL(timer.expired());

         //UMBA_RTKOS_LOG<<"Starting level 1 tim1"<<umba::omanip::endl;

         //umba::rtkos::timerSet( &tim1, 0, 3000 );

         UMBA_RTKOS_LOG<<"RunLevel 1 finished"<<umba::omanip::endl;

         PT_END();
    }

}; // struct StarterThread1


struct StarterThread2 : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel2> // StarterThreadBase // umba::rtkos::Protothread
{
    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove nerver used warning

         UMBA_RTKOS_LOG<<"Startup level 2 step 1"<<umba::omanip::endl;
         timer.start(750);
         PT_WAIT_UNTIL(timer.expired());

         UMBA_RTKOS_LOG<<"Startup level 2 step 2"<<umba::omanip::endl;
         timer.start(1000);
         PT_WAIT_UNTIL(timer.expired());

         UMBA_RTKOS_LOG<<"Starting level 2 tim1"<<umba::omanip::endl;

         umba::rtkos::timerSet( &tim1, 0, 3000 );

         UMBA_RTKOS_LOG<<"RunLevel 1 finished"<<umba::omanip::endl;

         PT_END();
    }

}; // struct StarterThread2


int main(void)
{
    // Keil проёбывается с порядком инициализации
    #ifdef UMBA_MCU_USED
    UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( STM32_DISCOVERY_LEGACY_UART, STM32_DISCOVERY_UART, 460800 );
    #endif
    
    using namespace umba::omanip;
    
/*
    //std::is_integral<int>::value
    LEDFlasher flasher;
    UMBA_RTKOS_LOG<<"Run flasher 1"<<endl;
    while(flasher.Run()){}
    UMBA_RTKOS_LOG<<"Run flasher 2"<<endl;
    while(flasher.Run()){}
*/
    UMBA_RTKOS_LOG<<"------------------"<<endl;
    UMBA_RTKOS_LOG<<"Starting"; //<<endl;
    if (UMBA_RTKOS_OS->isDebuggerPresent())
    {
        UMBA_RTKOS_LOG<<" under debugger";
    }
    UMBA_RTKOS_LOG<<"..."<<endl;

    #ifdef UMBA_RTKOS_TRACE_YIELD_STACK_PTR
    {
        using namespace umba::omanip;
        auto a = 0u;
        UMBA_RTKOS_LOG<<"Stack (main at enter): "<<hex<<(size_t)&a<<endl;
    }
    #endif

    UMBA_RTKOS_LOG<<"OS size (RAM): "<<UMBA_RTKOS_OS->getOsSize( )<<endl;
    UMBA_RTKOS_LOG<<"OS size detailed info: ";
    //UMBA_RTKOS_OS->logInternalInfo();
    umba::rtkos::OsInfoLogLevel osInfoLevel = umba::rtkos::OsInfoLogLevel::osSizeDetailsMore;
    for (unsigned i = 0; i <= (unsigned)osInfoLevel; ++i)
    {
        UMBA_RTKOS_OS->logOsInfo((umba::rtkos::OsInfoLogLevel)i);
    }

    UMBA_RTKOS_LOG<<endl;


    auto starter0 = StarterThread0();
    umba::rtkos::pollScheduleAdd( &starter0 );

    auto starter1 = StarterThread1();
    umba::rtkos::pollScheduleAdd( &starter1 );

    auto starter2 = StarterThread2();
    umba::rtkos::pollScheduleAdd( &starter2 );

    //auto restartable = RestartableThread();
    //umba::rtkos::pollScheduleAdd( &restartable );


    auto idle = umba::makeSimpleIdleCapable( []{ /*TASK_REPORT(idle);*/ return true; } );

    auto simpleFilter = umba::rtkos::makeSimpleMessageFilter( []( umba::rtkos::Message &msg ) -> bool { return false; } );
    umba::rtkos::messageFilterAdd( &simpleFilter );

    auto task1 = umba::rtkos::makeSimplePollCapable( []{ 
                                                         #ifdef UMBA_RTKOS_TRACE_YIELD_STACK_PTR
                                                             using namespace umba::omanip;
                                                             auto a = 0u;
                                                             UMBA_RTKOS_LOG<<"Stack (auto task1): "<<hex<<(size_t)&a<<endl;
                                                         #endif

                                                         TASK_REPORT(task1);
                                                         #ifdef UMBA_RTKOS_ENABLE_YIELD
                                                         umba::rtkos::pollScheduleYield(500);
                                                         #endif
                                                       } );

    auto task2 = umba::rtkos::makeSimplePollCapable( []{ 
                                                         #ifdef UMBA_RTKOS_TRACE_YIELD_STACK_PTR
                                                             using namespace umba::omanip;
                                                             auto a = 0u;
                                                             UMBA_RTKOS_LOG<<"Stack (auto task1): "<<hex<<(size_t)&a<<endl;
                                                         #endif
                                                         TASK_REPORT(task2);
                                                         #ifdef UMBA_RTKOS_ENABLE_YIELD
                                                         umba::rtkos::pollScheduleYield(1000);
                                                         #endif
    } );

    auto task3 = umba::rtkos::makeSimplePollCapable( []{ TASK_REPORT(task3); } );
    auto task4 = umba::rtkos::makeSimplePollCapable( []{ TASK_REPORT(task4); } );

    auto hpTask1 = umba::rtkos::makeSimplePollCapable( []{ TASK_REPORT(hpTask1); } );
    auto hpTask2 = umba::rtkos::makeSimplePollCapable( []{ TASK_REPORT(hpTask2); } );

    umba::rtkos::pollScheduleAdd( &task1   , umba::rtkos::PollPriority::normal );
    umba::rtkos::pollScheduleAdd( &task2   , umba::rtkos::PollPriority::normal );
    //umba::rtkos::pollScheduleAdd( &task3   , umba::rtkos::PollPriority::normal );
    //umba::rtkos::pollScheduleAdd( &task4   , umba::rtkos::PollPriority::normal );
    //umba::rtkos::pollScheduleAdd( &hpTask1 , umba::rtkos::PollPriority::high );
    //umba::rtkos::pollScheduleAdd( &hpTask2 , umba::rtkos::PollPriority::high );



    #ifdef UMBA_RTKOS_TRACE_YIELD_STACK_PTR
    {
        using namespace umba::omanip;
        auto a = 0u;
        UMBA_RTKOS_LOG<<"Stack (main exact before run): "<<hex<<(size_t)&a<<endl;
    }
    #endif

    return UMBA_RTKOS_OS->run( 5 );

}



