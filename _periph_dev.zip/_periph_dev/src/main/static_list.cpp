#ifndef _WIN32
    #include "luart/uart_handle.h"
#endif

#include "vgpio/i_virtual_gpio.h"
#include "vgpio/stm32_gpio.h"
#include "vgpio/virtual_gpio.h"
#include "umba/time_service.h"

#include "periph/keyboard.h"

#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/allocator.h"
#include <vector>

#include "containers/static_list.h"


#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
//#error "Not an MCU target"
#endif

namespace vgpio     = umba::virtual_gpio;
namespace stm32gpio = umba::stm32_gpio;


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<>   charWritter = umba::LegacyUartCharWriter<>(uart::uart3).setTextMode(true).setAnsiTerminalMode(true);
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  fmt(&charWritter);


#define SHOW_DETAILED


template<typename IterType>
void showRange( const char *pTitle, IterType first, IterType last )
{

    #if !defined(SHOW_DETAILED)

        if (pTitle)
            fmt<<pTitle<<": ";

        bool bFirst = true;
       
        for( ; first!=last; ++first)
        {
            if (!bFirst)
                fmt << ", ";
            fmt << *first;
       
            //auto info = first.getListItemInfo();
            //auto selfNo = first.getSelfNo();
            //fmt << "(#" << selfNo<<",p"<<info.prev << ",n" << info.next << ")";
            bFirst = false;
        }
       
        fmt<<umba::omanip::endl;

    #else

        fmt<<"-------"<<umba::omanip::endl;
        if (pTitle)
            fmt<<pTitle<<umba::omanip::endl;

        for( ; first!=last; ++first)
        {
            fmt<<umba::omanip::width(6)<<*first<<" - "<<first.dump()<<umba::omanip::endl;
        }

        fmt<<umba::omanip::endl;

    #endif
}

template<typename ContainerType>
void showContainer( const char *pTitle, const ContainerType &c )
{
    showRange( pTitle, c.begin(), c.end() );
}


int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
#ifndef _WIN32
    uart::uart3.init( uart::Pins::UART3_PB10_PB11, 460800 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 307200 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 691200 );
#endif

    

    /*
    fmt<<"\n\n";

    fmt<<umba::omanip::coloring(umba::term::colors::green)<<"coloring(umba::term::colors::green)"<<umba::omanip::endl;
    fmt<<umba::omanip::coloring(umba::ColoringLevel::emergency)<<"coloring(umba::ColoringLevel::emergency)"<<umba::omanip::endl;
    fmt<<umba::omanip::emergency<<"emergency"<<umba::omanip::endl;
    fmt<<umba::omanip::alert    <<"alert    "<<umba::omanip::endl;
    fmt<<umba::omanip::critical <<"critical "<<umba::omanip::endl;
    fmt<<umba::omanip::error    <<"error    "<<umba::omanip::endl;
    fmt<<umba::omanip::warning  <<"warning  "<<umba::omanip::endl;
    fmt<<umba::omanip::notice   <<"notice   "<<umba::omanip::endl;
    fmt<<umba::omanip::info     <<"info     "<<umba::omanip::endl;
    fmt<<umba::omanip::debug    <<"debug    "<<umba::omanip::endl;
    fmt<<umba::omanip::good     <<"good     "<<umba::omanip::endl;
    fmt<<umba::omanip::normal   <<"normal   "<<umba::omanip::endl;

    fmt<<"\n\n";
    */


    std::vector< int, umba::static_allocator<int> > intVec;
    //std::vector< int, std::allocator<int> > intVec;
    //std::vector< int > intVec;

    intVec.reserve(20);
    intVec.push_back(1);
    intVec.push_back(4);
    intVec.push_back(7);
    intVec.push_back(1243);


    //showContainer( "Vector", intVec ); // Vector: 1, 4, 7, 1243

    umba::static_list< int > lst( umba::reserve_size(32) );

    lst.push_back(16)   ; showContainer( "push_back(16)   ", lst ); // List: 16
    lst.push_front(1024); showContainer( "push_front(1024)", lst ); // List: 1024, 16

    auto lit1 = lst.begin();
    ++lit1;
    lst.insert( lit1, intVec.begin(), intVec.end()); showContainer( "insert vec at B+1", lst ); // List: 1024, 1, 4, 7, 1243, 16

    umba::static_list< int >::iterator lit = lst.begin();
    std::advance( lit, 3 );
    lst.insert( lit, 666 ); showContainer( "insert 666 at B+3", lst ); // List: 1024, 1, 4, 666, 7, 1243, 16

    lit = lst.begin();
    std::advance( lit, 2 );
    lst.erase(lit); 
    showContainer( "Erase at B+2", lst );

    lst.pop_front(); showContainer( "pop_front", lst ); // List: 1, 4, 666, 7, 1243
    lst.pop_back() ; showContainer( "pop_back", lst ); // List: 1, 4, 666, 7

    lst.erase(lst.begin()); showContainer( "erase B", lst ); // List: 1, 4, 666, 7, 1243
    lit = lst.end(); std::advance( lit, -1);
    lst.erase( lit ) ; showContainer( "erase E-1", lst ); // List: 1, 4, 666, 7

    //std::sort( lst.begin(), lst.end() ); showContainer( "Sort list", lst );


#ifndef _WIN32

    while(1)
    {
    }
#endif

    return 0;
}



