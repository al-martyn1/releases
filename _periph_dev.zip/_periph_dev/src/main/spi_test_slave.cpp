
#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
#include "umba/hr_counter.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"
#include "periph/stm32_discovery.h"


#include "spi_test_master_slave.h"




void spiInit();
//DECLARE_PIN( msTestCsPin , MS_TEST_SPI_CS  );
umba::periph::GpioPin  msTestCsPin( MS_TEST_SPI_CS_GPIO_PIN_ADDR, UMBA_GPIO_DIRECTION_IN );

DECLARE_PIN( btnPin , STM32_DISCOVERY_BTN_USER );

umba::periph::GpioPin &ledPin = led1_Pin;



using namespace umba::time_service;
using namespace umba::periph::traits;
using namespace umba::omanip;



//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::LegacyUartCharWriter<255>   charWritter = umba::LegacyUartCharWriter<255>( STM32_DISCOVERY_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);


umba::hr_counter::HiResTick  nanosecDelayVal = 0;


static bool btnPrevState = btnPin;


/*
    0x00-0x0D - RW, что записали, то и прочитали
    0x0E      - RO, регистр статуса - младший бит - состояние кнопки
    0x0F      - RO, регистр WHO_AM_I, там всегда SPI_WHO_AM_I_ID
*/
uint8_t slaveRegs[SPI_NUMBER_OF_REG] = { 0, 0, 0, 0
                                       , 0, 0, 0, 0
                                       , 0, 0, 0, 0
                                       , 0, 0, 0, SPI_WHO_AM_I_ID };

uint8_t curIdx = 0;
bool    bSlaveModeRead = false;

uint8_t spiSlaveFillingVal = 0xAA;

#include "umba/optimize_speed.h"
UMBA_PERIPH_DECLARE_SPI_IRQ_HANDLER_PROC( spiIrqHandler )
{
    // прочитали-записали 8 бит

    using namespace umba::periph::traits;
    bool ledsUpdated = false;
    //bool bFirst = false;

    uint8_t receivedByte = (uint8_t)spiReadGetValue( MS_TEST_SPI );
    
    if (curIdx == (uint8_t)0xFFu)
    {
        // first byte after start
        bSlaveModeRead = (receivedByte & (SPI_MS_TEST_CMD_READ >> 8)) ? true : false;
        curIdx = (receivedByte & ~(SPI_MS_TEST_CMD_READ >> 8) );
        if ( curIdx < SPI_NUMBER_OF_REG )
            spiWriteSetValue(MS_TEST_SPI, slaveRegs[curIdx]);
        #ifndef NO_IRQ_LOGS
        lout << "+ "<<hex<<width(2)<<noshowbase<<receivedByte<<"\n";
        lout<<"<-"<<hex<<width(2)<<noshowbase<<slaveRegs[curIdx]<<" at "<<curIdx<<"\n";
        #endif
        return;
        //bFirst = true;
    }

    if ( curIdx < SPI_NUMBER_OF_REG )
    {
        if (bSlaveModeRead)
        {
            //umba::periph::traits::spiWriteStart( MS_TEST_SPI, slaveRegs[curIdx++] );
            //spiStartPrepare( MS_TEST_SPI );
            spiWriteSetValue(MS_TEST_SPI, slaveRegs[curIdx]);
            #ifndef NO_IRQ_LOGS
            lout<<"->"<<hex<<width(2)<<noshowbase<<receivedByte<<"\n";
            lout<<"<-"<<hex<<width(2)<<noshowbase<<slaveRegs[curIdx]<<" at "<<curIdx<<"\n";
            #endif
            ++curIdx;
            // ??? spiWriteSetValue( SPIx, (SpiDataBits)dataSize, data );
        }
        else
        {

            if (curIdx==SPI_REG_CTRL_LEDS)
                ledsUpdated = true;

            if (SPI_REG_IS_RW(curIdx))
            {
                slaveRegs[curIdx] = receivedByte;
            }

            spiWriteSetValue(MS_TEST_SPI, slaveRegs[curIdx] );

            #ifndef NO_IRQ_LOGS
            lout<<"->"<<hex<<width(2)<<noshowbase<<receivedByte<<"\n";
            lout<<"T["<<curIdx<<"]="<<hex<<width(2)<<(unsigned)slaveRegs[curIdx]<<"\n";
            #endif
            
            #ifndef NO_IRQ_LOGS
            lout<<"<-"<<hex<<width(2)<<noshowbase<<slaveRegs[curIdx]<<"\n";
            #endif

            curIdx++;
        }
    }
    else // index out of range
    {
        spiWriteSetValue(MS_TEST_SPI, spiSlaveFillingVal );
        #ifndef NO_IRQ_LOGS
        lout << "Xidx: "<<curIdx<<"\n";
        #endif
    }

    if (ledsUpdated)
    {
        ledControl( false );
        ledControl( slaveRegs[SPI_REG_CTRL_LEDS], true );

        #ifndef NO_IRQ_LOGS
        lout << "LED: " <<slaveRegs[SPI_REG_CTRL_LEDS];
        lout<<"\n";
        #endif
    }

}

UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( chipSelectIrqHandlerProc )
{
    //https://stackoverflow.com/questions/20319801/spi-slave-setup-on-stm32f4-board
    spiStartPrepare( MS_TEST_SPI );
    spiReadGetValue( MS_TEST_SPI ); // очищаем буфер чтения
    spiWriteSetValue(MS_TEST_SPI, spiSlaveFillingVal ); // первый байт - нулевой
    curIdx = (uint8_t)0xFFu; // делаем невалидный индекс
    #ifndef NO_IRQ_LOGS
    lout<<"!!! - "<<hex<<width(2)<<noshowbase<<spiSlaveFillingVal<<endl;
    #endif
}
#include "umba/optimize_pop.h"


UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( btnIrqHandlerProc )
{
    // toggle logix
    #ifdef BTN_USE_TOGGLE_LOGIC

    if (btnPin.get())
    {
        #ifndef NO_IRQ_LOGS
        lout<<"BtnNewSt: ";
        #endif
        if (slaveRegs[ SPI_REG_STATUS ] & (uint8_t)SPI_STATUS_BTN1) // already set
            slaveRegs[ SPI_REG_STATUS ] &= ~((uint8_t)SPI_STATUS_BTN1);
        else
            slaveRegs[ SPI_REG_STATUS ] |=   (uint8_t)SPI_STATUS_BTN1;

        #ifndef NO_IRQ_LOGS
        lout << ( (slaveRegs[ SPI_REG_STATUS ] & (uint8_t)SPI_STATUS_BTN1 ) ? "Pressed" : "Released" ) << endl;
        #endif
    }

    #else

    if (btnPin.get())
        slaveRegs[ SPI_REG_STATUS ] |=   (uint8_t)SPI_STATUS_BTN1;
    else
        slaveRegs[ SPI_REG_STATUS ] &= ~((uint8_t)SPI_STATUS_BTN1);
    //ledPin = !ledPin;

    #endif

}



static volatile uint32_t hseVal   = 0;
static volatile uint32_t coreClk  = 0;
static volatile uint32_t sysClk   = 0;
static volatile uint32_t ahbClk   = 0;
static volatile uint32_t apb1Clk  = 0;
static volatile uint32_t apb2Clk  = 0;
static volatile uint32_t spiFreq  = 0;


int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    ledStartup();

        
    STM32_DISCOVERY_LEGACY_UART.init( STM32_DISCOVERY_UART_RX_GPIO,  STM32_DISCOVERY_UART_RX_GPIO_PIN_NO, STM32_DISCOVERY_UART_TX_GPIO, STM32_DISCOVERY_UART_TX_GPIO_PIN_NO, 460800 );

    spiInit();

    lout<<"-----------------\nHello from Slave on "<<STM32_DISCOVERY_NAME<<endl;
    umba::hr_counter::HiResTick deltaTick = umba::hr_counter::convertNanosecToTick( (umba::hr_counter::HiResTick)100 );
    lout<<"100 ns in ticks: "<<deltaTick<<"\n";

    lout<<"Cur delay: "<<nanosecDelayVal<<" ns\n";
    lout<<"HRC Freq : "<<umba::hr_counter::getTickFreqKHz()<<" KHz\n";

    hseVal  = clockGetFreq(ClockBus::OSCCLK);
    coreClk = clockGetFreq(ClockBus::CORECLK);
    sysClk  = clockGetFreq(ClockBus::SYSCLK);
    ahbClk  = clockGetFreq(ClockBus::AHB);
    apb1Clk = clockGetFreq(ClockBus::APB1);
    apb2Clk = clockGetFreq(ClockBus::APB2); 
    spiFreq = spiGetFreq( MS_TEST_SPI );

    lout<<"HSE : "<<width(9)<<left<<hseVal <<" Hz"<<endl;
    lout<<"CORE: "<<width(9)<<left<<coreClk<<" Hz"<<endl;
    lout<<"SYS : "<<width(9)<<left<<sysClk <<" Hz"<<endl;
    lout<<"AHB : "<<width(9)<<left<<ahbClk <<" Hz"<<endl;
    lout<<"APB1: "<<width(9)<<left<<apb1Clk<<" Hz"<<endl;
    lout<<"APB2: "<<width(9)<<left<<apb2Clk<<" Hz"<<endl;


    static umba::hr_counter::HiResTick nanosecOrTick = 60200;
    nanosecOrTick *= umba::hr_counter::getTickFreqKHz();
    nanosecOrTick /= 1000;
    nanosecOrTick /= 1000;

    //gpio_in_floating / gpio_in_pulldown
    
    auto btnPinMode = PinMode::gpio_in_pulldown; // gpio_in_floating; gpio_in_pullup;

    periphInitIrq( btnPin, extiTriggerBoth, btnPinMode );
    periphInstallIrqHandler( btnPin, btnIrqHandlerProc );    

    periphInitIrq( msTestCsPin, extiTriggerFalling, PinMode::gpio_in_pullup );
    periphInstallIrqHandler( msTestCsPin, chipSelectIrqHandlerProc );    


    while(true)
    {
        #if defined(BUTTON_LED_TEST)
        bool btnNewState = btnPin;
        if (btnPrevState!=btnNewState) // state changed
        {
            btnPrevState = btnNewState;
            //if (btnNewState)
            //    ledPin       = !ledPin;
        }
        #endif

        delayMs(2500);

        lout<<"regs:";
        for( size_t regIdx = 0; regIdx!=SPI_NUMBER_OF_REG; ++regIdx)
        {
            lout<<" "<<hex<<width(2)<<noshowbase<<slaveRegs[regIdx];
        }
        lout<<endl;

    }

}





void spiInit()
{

    // SPI hints
    // 8/16 - https://diymcblog.blogspot.com/2018/03/spi-stm32-2.html
    // Статусы - http://www.cyberforum.ru/arm/thread2091007.html
    // Полезная инфа - https://microtechnics.ru/stm32-s-nulya-interfejs-spi/
    //   Важное дополнение – инициализация GPIO должна происходить после инициализации SPI, иначе могут возникнуть сбои в работе Slave.

    using namespace umba::periph::traits;

    SpiPrescaler psc100   = spiCalcPrescaler( MS_TEST_SPI,   100000 );
    SpiPrescaler psc150   = spiCalcPrescaler( MS_TEST_SPI,   150000 );
    SpiPrescaler psc200   = spiCalcPrescaler( MS_TEST_SPI,   200000 );
    SpiPrescaler psc250   = spiCalcPrescaler( MS_TEST_SPI,   250000 );
    SpiPrescaler psc500   = spiCalcPrescaler( MS_TEST_SPI,   500000 );
    SpiPrescaler psc1000  = spiCalcPrescaler( MS_TEST_SPI,  1000000 );
    SpiPrescaler psc2000  = spiCalcPrescaler( MS_TEST_SPI,  2000000 );
    SpiPrescaler psc3000  = spiCalcPrescaler( MS_TEST_SPI,  3000000 );
    SpiPrescaler psc4000  = spiCalcPrescaler( MS_TEST_SPI,  4000000 );
    SpiPrescaler psc5000  = spiCalcPrescaler( MS_TEST_SPI,  5000000 );
    SpiPrescaler psc10000 = spiCalcPrescaler( MS_TEST_SPI, 10000000 );
    SpiPrescaler psc15000 = spiCalcPrescaler( MS_TEST_SPI, 15000000 );
    SpiPrescaler psc20000 = spiCalcPrescaler( MS_TEST_SPI, 20000000 );

    periphInit( MS_TEST_SPI                      
              , MS_TEST_SPI_SCK_GPIO_PIN_ADDR    
              , MS_TEST_SPI_MISO_GPIO_PIN_ADDR   
              , MS_TEST_SPI_MOSI_GPIO_PIN_ADDR   
              , umba::periph::traits::spiDataBits8
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              , umba::periph::traits::spiPrescaler256
              , PinSpeed::high // PinSpeed::low
              , spiModeSlave
              );

    //msTestCsPin = true;

    periphInitIrq( MS_TEST_SPI, spiMakeEventMask(spiEventRxReady) );
    periphInstallIrqHandler( MS_TEST_SPI, spiIrqHandler );

    

    
/*
    CPOL_CPHA   - clk - инверсный, данные - прямой
    nCPOL_CPHA  - Оба сигнала нормальная логика
    CPOL_nCPHA  - Оба сигнала инверсная логика
    nCPOL_nCPHA - clk - прямой, дата инверсная

    PinSpeed::low
    PinSpeed::medium
    PinSpeed::fast
    PinSpeed::high

*/

}


