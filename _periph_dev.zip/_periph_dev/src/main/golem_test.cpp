#include <QCoreApplication>
#include <QUuid>
#include <QTextStream>
#include <QSerialPort>
#include <QTest>

#include <iostream>

#include "umba/umba.h"
#include "ihc/i_octet_stream.h"
#include "ihc/octet_stream_qserialport.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"
#include "umba/parse_utils.h"

/*
    Как работает Голем на терминальном порту:
    1) Он сразу выплевывает обратно байт, который мы ему отослали - эхо.
    2) Принимает команду в обработку после получения символа 0x0D, 
       т.е. команды достаточно заканчивать символом 0x0D, а не последовательностью 0x0D 0x0A
    3) Если мы отправляем в конце 0x0A, то она тоже будет выплюнута обратно, но уже после результатов обработки команды

    Таким образом, либо мы отсылаем команду побайтно и ждем эха на каждый байт, затем читаем ответ на команду и парсим его,
    либо мы отправляем команду и принимаем ответ, и у последнего проверяем, чтобы префикс был равен отосланному

    4) В ответе Голем использует переводы строки и они всегда состоят из последовательности 0x0D 0x0A 
    5) Ответ Голема всегда заканчивается последовательностью 0x0D 0x0A 0x2A 0x20 - \r\n* - просто проверять и обрезать
       Ошибку выдавать, если не так? Или молча игнорировать?

    6) Вполне может быть ситуация, когда Голем выдает данные сам по себе, а не в ответ на
       запрос. 
    7) При включении питания Голем выдает следующее:

GOLEM V1A (C) SET-1 2015-2018
* Init SLAVE
Channel00 [0]
Calibrate [0]
Start
*



*/


//umba::NulCharWriter          charWritter;
umba::StdStreamCharWriter    charWritter(std::cout);
umba::SimpleFormatter  lout(&charWritter);

using namespace umba::omanip;


umba::SimpleFormatter& dump( const uint8_t *pData, size_t dataSize = 8 ) 
{
    for( size_t i = 0; i!=dataSize; ++i )
    {
        if (i)
           lout<<" ";
        lout<<noshowbase<<hex<<width(2)<<pData[i];
    }

    return lout;
}

umba::SimpleFormatter& dump( const char *pData, size_t dataSize = 8 ) 
{
    return dump( (const uint8_t *)pData, dataSize );
}




umba::ihc::IOctetIOStream::StreamSize readReplyHelper( umba::ihc::IOctetIOStream *pStream
                                                     , umba::ihc::IOctetIOStream::StreamOctetType *pBuf
                                                     , umba::ihc::IOctetIOStream::StreamSize bufSize
                                                     )
{
    umba::ihc::IOctetIOStream::StreamSize readedTotal = 0;
    for(auto i = 0u; i!=10u; ++i)
    {
        QTest::qWait(10);
        auto octetsToRead = bufSize - readedTotal;
        if (!octetsToRead)
            break;
        umba::ihc::IOctetIOStream::StreamSize readed = pStream->read( &pBuf[readedTotal], octetsToRead );
        if (readed)
        {
            lout<<"Readed["<<i<<"]: ";
            dump( &pBuf[readedTotal], readed);
            lout<<endl;
        }

        readedTotal += readed;
    }

    return readedTotal;
}

umba::ihc::IOctetIOStream::StreamSize writeQeuryReadReplyHelper( umba::ihc::IOctetIOStream *pStream
                                                      , const char *queryStr
                                                      , umba::ihc::IOctetIOStream::StreamOctetType *pBuf
                                                      , umba::ihc::IOctetIOStream::StreamSize bufSize
                                                      )
{
    using namespace umba::ihc;
    StreamSize readedTotal = 0;
    StreamSize queryLen = (StreamSize)strlen(queryStr);

    lout<<"\n\n-------\nQuery string: ["<<queryStr<<"]"<<endl;

    for(StreamSize i = 0; i!=queryLen; ++i)
    {
        lout<<"Writting query octet: ";
        dump(&queryStr[i], 1);
        if (queryStr[i]>=' ' && queryStr[i]<128u)
            lout<<" - '"<<(char)queryStr[i]<<"'";
        lout<<endl;

        pStream->write( (StreamOctetType*)&queryStr[i], 1 );

        auto octetsToRead = bufSize - readedTotal;
        if (!octetsToRead)
        {
            lout<<error<<"No space for reply, breaking"<<endl;
            break;
        }
        readedTotal += readReplyHelper( pStream, &pBuf[readedTotal], octetsToRead );
    }

    return readedTotal;

}


void fixedFloatParseTest( const char *str )
{
    lout<<"parse: ["<<str<<"] - ";

    int64_t res = 0;
    size_t charsParsed = 0;
    if (!umba::parse_utils::toDecimalFixedPoint( str, (size_t)strlen(str)+1, 3 /* prec */ , &res, &charsParsed ))
    {
       lout<<"Failed";
    }
    else
    {
        lout<<res<<", num of chars parsed: "<<charsParsed;
    }

    lout<<endl;
}



int main(int argc, char *argv[])
{
    std::cout << "At start of main"<<std::endl;
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("tenso-m");
    QCoreApplication::setApplicationVersion("1.0");

    // 19200, 1 stop, no parity
    // COM3

    std::cout << "Before lout" << std::endl;
    lout << "Starting"<<endl;
    std::cout << "After lout" << std::endl;


    typedef const char* QueryType;


    QueryType floatsStrs[] = { "0.2"
                             , " 0.2"
                             , " .2"
                             , "+ .2"
                             , "+0.2"
                             , "-0.2"
                             , "- .2"
                             , "0. "
                             , "0.22"
                             , "1.2345"
                             , 0
                             };

    for( auto i=0u; ; ++i)
    {
        QueryType fs = floatsStrs[i];
        if (!fs)
            break;
        fixedFloatParseTest( fs );
    }
    




    // COM46/47
    std::string portName = "COM46";
    if (argc>1)
        portName = argv[1];

    lout << "Try to open port "<<portName<<endl;

    QSerialPort            qSerialPort;
    qSerialPort.setPortName( QString(portName.c_str())); 
    qSerialPort.setDataBits(QSerialPort::Data8);
    qSerialPort.setBaudRate(QSerialPort::Baud115200, QSerialPort::AllDirections);
    qSerialPort.setFlowControl(QSerialPort::NoFlowControl);
    qSerialPort.setParity(QSerialPort::NoParity);
    qSerialPort.setStopBits(QSerialPort::OneStop);
    qSerialPort.setReadBufferSize(1024);

    if (!qSerialPort.open(QIODevice::ReadWrite)
     )
    {
        lout<<error<<"Failed to open serial device '"<<portName<<"'\n";
        return 0;
    }

    umba::ihc::IOctetIOStreamImplQSerialPort iPort(qSerialPort);


    using namespace umba::ihc;


    lout<<"Please turn on the Golem!!!"<<endl;
    StreamOctetType startMsgBuf[256];
    StreamSize startReaded = readReplyHelper( &iPort, startMsgBuf, 256 );
    while(!startReaded)
    {
        startReaded = readReplyHelper( &iPort, startMsgBuf, 256 );
    }

    lout<<"Full start dump  : ";
    dump(&startMsgBuf[0], startReaded );
    lout<<endl;

    lout<<"Full start string: ["<<(const char*)&startMsgBuf[0]<<"]"<<endl;




    QueryType queries[] = { 
                            "C\r\n"
                          , "C\r"
                          , "C01\r\n"
                          , "C01\r"
                          , "C00\r\n"
                          , "C00\r"
                          , "R\r\n"
                          , "R\r"
                          , "P\r\n"
                          , "P\r"
                          , "P50\r\n"
                          , "P50\r"
                          , "P100\r\n"
                          , "P100\r"
                          , "T\r\n"
                          , "T\r"
                          , "V\r\n"
                          , "V\r"
                          , "V0\r\n"
                          , "V0\r"
                          , "V1\r\n"
                          , "V1\r"
                          , "F\r\n"
                          , "F\r"
                          , "F1150000000\r\n"
                          , "F1150000000\r"
                          , "F1230000000\r\n"
                          , "F1230000000\r"
                          , "S\r\n"
                          , "S\r"
                          , "I\r\n"
                          , "I\r"

                          , "L\r\n"
                          , "L\r"
                          , "L0123\r\n"
                          , "L0123\r"
                          , "L0000\r\n"
                          , "L0000\r"

                          , "M\r\n"
                          , "M\r"
                          , "M1\r\n"
                          , "M1\r"
                          , "M0\r\n"
                          , "M0\r"

                          , "W\r\n"
                          , "W\r"

                          //, "\r"
                          , 0
                          };

    for( auto i=0u; ; ++i)
    {
        QueryType q = queries[i];
        if (!q)
            break;


        umba::ihc::IOctetIOStream::StreamOctetType rdBuf[256];
        auto readedTotal = writeQeuryReadReplyHelper( &iPort, q, rdBuf, 256u );
        auto numBytesToDump = readedTotal;
        if ((readedTotal+1) >= 256u)
        {
            lout<<warning<<"Tool large reply, size: "<<(unsigned)readedTotal<<normal<<endl;
            rdBuf[255] = 0;
            numBytesToDump = 255;
        }
        else
        {
            rdBuf[readedTotal] = 0;
        }

        lout<<"Full reply dump  : ";
        dump(&rdBuf[0], numBytesToDump);
        lout<<endl;

        lout<<"Full reply string: ["<<(const char*)&rdBuf[0]<<"]"<<endl;
    }
    



/*
    iPort.write( (umba::ihc::StreamOctetType*)"C0\r\n", 4 );

    QTest::qWait(3000);

    umba::ihc::StreamOctetType buf[256];

    auto nReaded = iPort.read( buf, 256 );

    // 43 0D 0D 0A 20 20 43 30
    // C                 C  0
    lout<<"Readed: "; 
    dump( buf, nReaded );
    lout<<endl;
*/



//    const uint32_t uart_beam_term_baudrate = 115200;    // управление лучом
//    const uint32_t uart_beam_baudrate = 115200;         // луч

    //
/*
GOLEM V1A
Commands:
C[<nn>]        - [Set] or read DU channel number, <nn>-number of channel
D<n>           - Display debug information, <n> - 0-off,1-Status,2-Status+Error
F[<xxxxxxxxxx>]- [Set] or read frequency of video transmitter,
                 <xxxxxxxxxx>-frequency in hertz (102000000..123000000)
I              - Display psramemers
K[<b>]         - [Set] or read camera keys, <b> 0-All keys release U-Up Press D-Down press
                 L-Left press R-Right press S-Set press
L<k3><k2><k1><k0> - Set scrambler key
M[<z>]         - [Set] or scrembler mode, <z> 0-off 1-on
P[<yyy>]       - [Set] or read power of video transmitter, <yyy>-power level (0..255)
R              - Reset
S              - Display status information
T              - Get volage and temperatures
V[<z>]         - [Set] or read video transmitter mode, <z> 0-off 1-on
W              - write settings in to flash memory
                                                000
    const uint32_t freqs[freqs_max] = {     1230000000,
                                            1190000000,
                                            1150000000,
                                            1110000000 };

 M
  Scrambler - OFF

* i
  C00
  F1230000000
  P100
  VideoTransmitter - ON
  Scrambler - ON
* t
  Vinp= 4.971 V12=12.033 T=43
* v
  VideoTransmitter - ON
  D0
  D0
  D0
* d1
* d1
* d1
* d1
* d1
* h

*/

    return 0;

}


