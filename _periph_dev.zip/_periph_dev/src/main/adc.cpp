#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "periph/gpio.h"
#include "periph/adc.h"
#include "periph/power.h"
#include "periph/stm32_discovery.h"


//#include "hot_end_dbg_uart_conf.h"


//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::LegacyUartCharWriter<255>   charWritter = umba::LegacyUartCharWriter<255>( STM32_DISCOVERY_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::SimpleFormatter  lout(&charWritter);




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    using namespace umba::time_service;
    using namespace umba::omanip;

/*
    auto //umba::periph::traits::AdcInjected 
         adc1 = umba::periph::adcInitInject( ADC1, umba::periph::AdcSamplingSpeed::high
                                           , umba::periph::AdcInitHwOption::init
                                           , PA1, PA2, PA3 );
*/
    /*
    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );
    */

    auto adcSC     = umba::periph::traits::AdcSingleChannel( ADC2, UMBA_PINADDR_PA6, umba::periph::AdcSamplingSpeed::low );

    STM32_DISCOVERY_LEGACY_UART.init( STM32_DISCOVERY_UART_RX_GPIO,  STM32_DISCOVERY_UART_RX_GPIO_PIN_NO, STM32_DISCOVERY_UART_TX_GPIO, STM32_DISCOVERY_UART_TX_GPIO_PIN_NO, 460800 );

    delayMs(300);

    lout<<"Starting"<<endl;

    unsigned cnt = 0;

    unsigned prevVal[3] = { 0 };

    while(1)
    {
        lout<<width(6)<<cnt<<"    "<<(uint16_t)adcSC<<endl;    
        
        /*
        lout<<width(6)<<cnt<<"    ";    
        for(size_t i = 0; i!=3; ++i )
        {
            unsigned newVal = adc1[i];
            //if (newVal!=prevVal[i])
            {
                lout<<"ADC["<<i<<"]: "<< width(4) << newVal <<"     ";
                prevVal[i] = newVal;
            }
        }
        lout<<endl;
        */

        delayMs(100);
        cnt++;

    }

    return 0;

}



