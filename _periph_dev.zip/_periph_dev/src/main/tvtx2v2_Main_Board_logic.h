#pragma once


//-----------------------------------------------------------------------------


#include <cstdlib>
#include <cmath>

#include "drivers/uplinks/golem_client.h"
#include "drivers/clients/dac.h"


//#include "vtx2v2/telexertex2_types.h"
//#include "vtx2v2/telexertex2_sucker_regs.h"

//-----------------------------------------------------------------------------




static umba::drivers::uplinks::GolemState     golemState;
static umba::rtkos::TimeTick                  ganjubusLastTick = 0;
static bool                                   ganjubusLink = false;

//-----------------------------------------------------------------------------
// Вся логика тут
class MainBoardLogic : public umba::ITimerHandler               // for timers
                     , public umba::rtkos::IMessageHandler      // for keyboard
                     , public umba::rtkos::IDriverClientHandler // for driver responses
                     , public umba::IIdleCapable                // полощем ганджубус тут
                     , public umba::IPollCapable                // для полировки
{

public:

    typedef umba::drivers::DriverAddress  DriverAddress;
    typedef umba::rtkos::TimerEventId     TimerEventId;
    typedef umba::rtkos::TimerId          TimerId;
    typedef umba::rtkos::TimeTick         TimeTick;

    typedef regs::types::SlavesLinkState::value_type  SlavesLinkStateType;


    static constexpr TimerEventId                 timer_event_golem_command             = 1;
    static constexpr TimeTick                     timer_interval_golem_command          = 500;

    static constexpr TimerEventId                 timer_event_switch_command_channel    = 2;
    static constexpr TimeTick                     timer_interval_switch_command_channel = 3000;

    static constexpr TimerEventId                 timer_event_tvko_power_on             = 3;
    static constexpr TimeTick                     timer_interval_tvko_power_on          = 300;

    static constexpr TimerEventId                 timer_event_dac                       = 4;
    static constexpr TimeTick                     timer_interval_dac                    = 5;


    SlavesLinkStateType                    m_leftSlavesState  = 0;
    SlavesLinkStateType                    m_rightSlavesState = 0;

    DriverAddress                          stateIndicatorDriverAddress;
    DriverAddress                          golemDriverAddress;
    //DriverAddress                          muxEnDriverAddress;
    DriverAddress                          muxDriverAddress;
    //DriverAddress                          camerasEnDriverAddress;

    umba::drivers::DacClient               tvkoMotor1Speed;
    umba::drivers::DacClient               tvkoMotor2Speed;

    bool                                   golemCommandPosted = false;
    bool                                   needSaveConfig = false;
    uint8_t                                prevDuChannel = 0;

    camera::Worker                         *pCameraWorker;

    uint32_t                               dacVal = 0; // for DAC test

    //umba::drivers::uplinks::GolemState     m_golemState;


    // Адреса драйверов используемой периферии
    //static constexpr DriverAddress driver_address_knobs    = DriverAddress( umba::drivers::class_id_gpio  , 1 );

    //static constexpr TimerEventId timer_event_knobs                      = 0; // таймер на опрос датчиков касания

    UMBA_BEGIN_INTERFACE_MAP_EX( umba::ITimerHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IMessageHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IDriverClientHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::IPollCapable )
    UMBA_END_INTERFACE_MAP()

    UMBA_DELEGATE_QUERY_INTERFACE(umba::ITimerHandler)


    MainBoardLogic()
    {
    }

    // хелпер для установки таймера
    umba::rtkos::TimerId timerSet( umba::rtkos::TimerEventId eventId, umba::rtkos::TimeTick period )
    {
        return umba::rtkos::timerSet( this, eventId, period );
    }

protected:

    // Хелпер для инсталляции логики в систему
    bool installDriverHandler( DriverAddress addrFrom )
    {
        return umba::rtkos::driverHandlerAdd( addrFrom, this );
    }

public:

    // Установка в систему
    bool install()
    {
        if (UMBA_RTKOS_OS->messagesSetHandler( umba::rtkos::message_keyboard_id, this )) // кто-то уже установил обработчик сообщений данного типа
            return false;
        installDriverHandler(golemDriverAddress);
        //installDriverHandler(muxEnDriverAddress);
        installDriverHandler(muxDriverAddress  );
        //installDriverHandler(driver_address_adc    );
        //installDriverHandler(driver_address_knobs  );

        umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::normal );

        auto prevIdleHandler = UMBA_RTKOS_OS->setIdleHandler( this );
        return prevIdleHandler==0; // Если кто-то уже занял обработчик идлы, то ошибка
    }

    //perfromGandjubusWork()

protected:


    //---------------------------------------

public: // чтобы были видны оттуда, где ставятся колбэки на ганджубус

    void onGanjubusLinkLost()
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<error<<"Ganjubus - Link Lost"<<normal<<"\n";
        #endif
        //doEmergencyStop( SuckerErrorFlags::ganjubus_failure );
        // UNDONE: need to indicate error

        ganjubusLink = false;
        postMessageDriverValue( stateIndicatorDriverAddress, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_device_state_value, (uint32_t)0 );
    }

    void onGanjubusLinkRestored()
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<notice<<"Ganjubus - Link Restored"<<normal<<"\n";
        #endif
        // Nothing to do - witing for new commands
        // UNDONE: need to indicate normal work
        //auto tickNow = umba::time_service::getCurTimeMs();

        ganjubusLink = true;
        postMessageDriverValue( stateIndicatorDriverAddress, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_device_state_value, (uint32_t)1 );
    }

    void onGanjubusDataReceived()
    {
        // UNDONE: need to indicate data transfering

        ganjubusLastTick = umba::time_service::getCurTimeMs();
        postMessageDriverValue( stateIndicatorDriverAddress, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_device_activity_value, (uint32_t)0 );
    }



protected:

    //---------------------------------------
    // Основная логика
    //---------------------------------------

    virtual
    void onTimer( unsigned eventId ) override
    {
        switch( eventId )
        {
            case timer_event_golem_command:
                 {
                     timerSet( timer_event_golem_command, 0 ); // stops the timer
                     golemCommandPosted = false;
                 }
                 break;

            case timer_event_switch_command_channel:
                 {
                     timerSet( timer_event_switch_command_channel, 0 ); // stops the timer
                     auto checkInterval = 3*timer_interval_switch_command_channel / 4;
                     auto tickNow = umba::time_service::getCurTimeMs();
                     auto tickDelta = tickNow - ganjubusLastTick;

                     if (tickDelta>checkInterval)
                     {
                         config.duChannel = prevDuChannel;
                         needSaveConfig = false;
                     }
                     else 
                     {
                         needSaveConfig = false;
                         writeConfig(config);
                     }
                 }
                 break;

            case timer_event_tvko_power_on:
                 {
                     //timerSet( timer_event_tvko_power_on, timer_interval_tvko_power_on );
                     //rwRegsMain[rw::tvko_camera_power_u8] = (uint8_t)1;
                     static uint8_t data[6] = { 0x81u, 0x01u, 0x04u, 0x66, 0x02, 0xFFu }; // что-то еще
                     //static uint8_t data[6] = { 0x81u, 0x01u, 0x04u, 0x00, 0x02, 0xFFu }; // питание
                     TVKO_LEGACY_UART.sendLocalArray( &data[0], sizeof(data));
                 }
                 break;

            case timer_event_dac:
                 {
                     /*
                     if (dacVal>100)
                         dacVal = 0;

                     unsigned parity = dacVal&1;
                     unsigned valToSend = parity ? 100 : 0;
                     tvkoMotor1Speed.setValuePercent( valToSend );
                     tvkoMotor2Speed.setValuePercent( valToSend );
                     */
                     //tvkoMotor1Speed.setValuePercent(dacVal);
                     //tvkoMotor2Speed.setValuePercent(dacVal);

                     //dacVal += 5;
                     //dacVal += 1;
                 }
                 break;
                 // uint32_t                               dacVal = 0; // for DAC test

            //default:
        };
        // postMessageDriverValueRequest( ClassId classId, DriverId driverId, ValueId valueId, IDriver *pDriver = 0 )
    }

    bool canPostGolemCommand()
    {
        if (!UMBA_RTKOS_IS_OS_STARTED())
            return false;

        /*
        >    764  Set videoPower, config: 50, golemState: 0
        >    767  Set videoPower, config: 50, golemState: 0
        >    768  Set videoPower, config: 50, golemState: 0
        >    770  Set videoPower, config: 50, golemState: 0
        >    771  Set videoPower, config: 50, golemState: 0
        >    772  Set videoPower, config: 50, golemState: 0

        >    846  Set videoPower, config: 50, golemState: 0
        >    850  Set videoPower, config: 50, golemState: 0
        >    850  Set videoPower, config: 50, golemState: 0

        */

        if (golemCommandPosted)
            return false;

        timerSet( timer_event_golem_command, timer_interval_golem_command );
        golemCommandPosted = true;
        return true;
    }

    //---------------------------------------
    virtual
    void onHandleMessage( umba::rtkos::Message &msg ) override
    {
        if (msg.id!=umba::rtkos::message_keyboard_id)
            return;

        umba::rtkos::MessageKeyboard &kbdMsg = msg.messageKeyboard;

        bool stateChanged = false;

        // Клавиатурные команды эмулируют установку значений по ганджубусу

        // Отпускания можно определять и по счетчику нажатий - там всегда 0

        using umba::rtkos::VirtualKeyCode;

        if (kbdMsg.repeatCount==1)
        {
            // Handle "Key pressed" here

        }

        if (!kbdMsg.repeatCount || kbdMsg.repeatCount==1)
        {
            // Handle "Key pressed/released" here
        }

        if (kbdMsg.repeatCount)
        {
            // Handle "Key pressed/repeated" here
        }

        if (stateChanged)
        {
        }

    }

    //---------------------------------------
    virtual
    bool onMessageDriverClient( const umba::drivers::MessageDriver &msg ) override
    {
        using namespace umba::drivers;
        using namespace umba::drivers::uplinks;

        bool bHandled    = false;

        auto tickNow = umba::time_service::getCurTimeMs();
        bool duChannelOk    = false;
        bool videoChannelOk = false;
        //bool videoStateOk   = false;
        bool videoPowerOk   = false;

        if (umba::drivers::uplinks::golemHandleMessage( msg, golemDriverAddress, golemState))
        {
            if ( golemState.duChannel != config.duChannel && canPostGolemCommand())
            {
                UMBA_RTKOS_LOG<<"> "<<width(6)<<tickNow<<"  Set duChannel, config: "<<config.duChannel<<", golemState: "<<golemState.duChannel<<endl;
                postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, value_id_golem_du_channel, config.duChannel );
            }
            else
            {
                duChannelOk = true;
            }

            roRegsMain[ro::link_channels_u8] = (golemState.duChannel & 0xF0) | (golemState.duChannel & 0x0F);


            if ( golemState.videoChannel != config.videoChannel && canPostGolemCommand())
            {
                UMBA_RTKOS_LOG<<"> "<<width(6)<<tickNow<<"  Set videoChannel, config: "<<config.videoChannel<<", golemState: "<<golemState.videoChannel<<endl;
                postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, value_id_golem_video_channel, config.videoChannel );
            }
            else
            {
                videoChannelOk = true;
            }

            roRegsMain[ro::link_channels_u8] = (golemState.videoChannel & 0x0F) | (golemState.videoChannel & 0x0F)<<4;


            if ( golemState.videoState != mainBoardLinkState.videoState && canPostGolemCommand())
            {
                UMBA_RTKOS_LOG<<"> "<<width(6)<<tickNow<<"  Set videoState, config: "<<mainBoardLinkState.videoState<<", golemState: "<<golemState.videoState<<endl;
                postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, value_id_golem_video_transmission_ctrl, mainBoardLinkState.videoState );
            }
            else
            {
                //videoStateOk = true;
            }

            uint8_t linkActivity = 0;
            //roRegsMain[ro::link_activity_u8] = roRegsMain[ro::link_activity_u8] & ~(uint8_t)regs::types::LinkActivityFlags::video_on;
            if (golemState.videoState)
                linkActivity |= (uint8_t)regs::types::LinkActivityFlags::video_on;
                //roRegsMain[ro::link_activity_u8] = roRegsMain[ro::link_activity_u8] | (uint8_t)regs::types::LinkActivityFlags::video_on;

            if ( golemState.videoPower != config.videoPower && canPostGolemCommand())
            {
                UMBA_RTKOS_LOG<<"> "<<width(6)<<tickNow<<"  Set videoPower, config: "<<config.videoPower<<", golemState: "<<golemState.videoPower<<endl;
                postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, value_id_golem_video_transmission_power, config.videoPower );
            }
            else
            {
                videoPowerOk = true;
            }

            if (duChannelOk && videoChannelOk && videoPowerOk)
            {
                if (needSaveConfig)
                {
                    postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, value_id_golem_store_to_flash, (uint8_t)1 );
                    needSaveConfig = false;
                    writeConfig(config);
                }
            }


            if ( golemState.scramblerState != mainBoardLinkState.scramblerState && canPostGolemCommand())
            {
                UMBA_RTKOS_LOG<<"> "<<width(6)<<tickNow<<"  Set scramblerState, config: "<<mainBoardLinkState.scramblerState<<", golemState: "<<golemState.scramblerState<<endl;
                postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, value_id_golem_scrambler_ctrl, mainBoardLinkState.scramblerState );
                //UNDONE: обновить регистр 
                //roRegs[ro::link_activity_u8] = (golemState.videoState ? )
            }

            //roRegsMain[ro::link_activity_u8] = roRegsMain[ro::link_activity_u8] & ~(uint8_t)regs::types::LinkActivityFlags::scrambling_on;
            if (golemState.scramblerState)
               linkActivity |= (uint8_t)regs::types::LinkActivityFlags::scrambling_on;
                //roRegsMain[ro::link_activity_u8] = roRegsMain[ro::link_activity_u8] | (uint8_t)regs::types::LinkActivityFlags::scrambling_on;

            roRegsMain[ro::link_activity_u8] = linkActivity;

            /* if ( golemState. != config. )
             * {
             * }
             */

            // do something
            return true;
        }

        #if 0
        bool valsNeedToShow = false;

        ValueInfoFlags valueInfoFlags;

        
        if (isMessageDriverMine( msg, driver_address_knobs ))
        {
            uint32_t putTo = 0;
            if (umba::drivers::extractFromMessageValue( msg.value, putTo, &valueInfoFlags ))
            {
                roRegs[ro::surface_sensors_u8] = (uint8_t)putTo;
                bHandled = true;
            }
        }
        else if (isMessageDriverMine( msg, driver_address_psensor ))
        {
            if (msg.header.driverMessageId == MessageId::driver_notify_datalink)
            {
                bHandled = true;
                valsNeedToShow |= onHwPSensorGood( msg.linkStatus ? true : false );
                //if (valsNeedToShow)
                //    UMBA_RTKOS_LOG<<"BAd sensor hits"<<endl;
            }

            if (!m_psensorGood)
            {} // dont extract data at all
            else
            {
                if ( isMessageDriverValue(msg, sensors::value_id_sensor_value) )
                {
                    //float prevVal = m_currentPressureValue;
                    float putTo = 0.0;
                    if (!umba::drivers::extractFromMessageValue( msg.value, putTo, &valueInfoFlags ))
                    {
                        valsNeedToShow |= onHwPSensorGood( false );  // failed to obtain value, mark it as bad
                        //m_psensorGood = false;
                    }
                }
            }
        }
        else if (isMessageDriverMine( msg, driver_address_adc ))
        {
            if ( isMessageDriverValue(msg, periph::value_id_adc_value) )
            {
                uint16_t putTo = 0;
                if (umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                {
                    //UMBA_RTKOS_LOG<<"LOGIC ADC: "<<putTo<<"\n";
                    valsNeedToShow |= onHwEscCurrentValue( ((float)putTo)/1000.0f / 0.8f, putTo ) ;
                    bHandled = true;
                    //if (valsNeedToShow)
                    //    UMBA_RTKOS_LOG<<"Current hits"<<endl;

                }
            }
        }

        if (valsNeedToShow)
            showState();
        #endif
        return bHandled;
    }

    //---------------------------------------
    //void ganjubusPoll();

    void onSlavesLinkStateChangedLeft( SlavesLinkStateType changesMask )
    {}

    void onSlavesLinkStateChangedRight( SlavesLinkStateType changesMask )
    {}


    void perfromGandjubusWork()
    {
        using namespace umba::omanip;

        auto tickNow = umba::time_service::getCurTimeMs();

        // Полируем ганджубус
        {
            slaveSession      .work( tickNow );
            
            #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)
                synchronizerLeft  .work( tickNow );
                masterSessionLeft .work( tickNow );
            #endif

            synchronizerRight .work( tickNow );
            masterSessionRight.work( tickNow );
        }

        if (pCameraWorker)
            pCameraWorker->work( tickNow );

        //jointControllerLeft1 .poll();
        //jointControllerLeft2 .poll();
        //jointControllerRight1.poll();
        //jointControllerRight2.poll();


        using namespace regs::types;
        using namespace umba::drivers;
        using namespace umba::drivers::uplinks;

        #define TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION_NO_FLAGS( slave )\
            do                                        \
            {                                         \
                if (!slave.isConnected())             \
                    slave.resetConnectionFailures();  \
                                                      \
            } while(0)

        #define TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( slave, flag, setVal ) \
            do                                        \
            {                                         \
                if (slave.isConnected())              \
                    setVal |= SlavesLinkState:: flag; \
                else                                  \
                    slave.resetConnectionFailures();  \
                                                      \
            } while(0)

        //TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION_NO_FLAGS(hotEndLeft);
        //TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION_NO_FLAGS(hotEndRight);
        //TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION_NO_FLAGS(battery);

        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION_NO_FLAGS(hotEndLeftFake1 );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION_NO_FLAGS(hotEndLeftFake2 );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION_NO_FLAGS(hotEndRightFake1);
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION_NO_FLAGS(hotEndRightFake2);
        

        SlavesLinkStateType   leftSlavesState  = 0;
        #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( suckingFootLeft1 , sucking_foot1, leftSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( suckingFootLeft2 , sucking_foot2, leftSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( hotEndLeft       , hot_end      , leftSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( jointLeft1       , joint1       , leftSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( jointLeft2       , joint2       , leftSlavesState );
        #endif
                                                                              
        SlavesLinkStateType   rightSlavesState = 0;
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( suckingFootRight1, sucking_foot1, rightSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( suckingFootRight2, sucking_foot2, rightSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( hotEndRight      , hot_end      , rightSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( jointRight1      , joint1       , rightSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( jointRight2      , joint2       , rightSlavesState );
        TVTX2V2_MAIN_BOARD_LOGIC_CHECK_SLAVE_CONNECTION( battery          , battery      , rightSlavesState );


        SlavesLinkStateType leftChanges = m_leftSlavesState ^ leftSlavesState;
        m_leftSlavesState = leftSlavesState; // обновляем

        if (leftChanges)
        {
            roRegsMain[ro::slaves_left_u8] = m_leftSlavesState;
            onSlavesLinkStateChangedLeft(leftChanges);
        }

        SlavesLinkStateType rightChanges = m_rightSlavesState ^ rightSlavesState;
        m_rightSlavesState = rightSlavesState; // обновляем

        if (rightChanges)
        {
            roRegsMain[ro::slaves_right_u8] = m_rightSlavesState;
            onSlavesLinkStateChangedRight(rightChanges);
        }



        uint8_t u8;

        if (rwRegsMain.getRegIfChanged( rw::active_camera_no_ctrl_u8, u8))
        {
            postMessageDriverValue( muxDriverAddress, MessageId::device_param_set, 0, (uint32_t)u8 );
            roRegsMain[ro::active_camera_no_u8] = u8;
        }

        if (rwRegsMain.getRegIfChanged( rw::video_activity_ctrl_u8, u8))
        {
            mainBoardLinkState.videoState = u8 ? 1 : 0;

            needSaveConfig = true;

            roRegsMain[ro::link_activity_u8] = roRegsMain[ro::link_activity_u8] & ~(uint8_t)regs::types::LinkActivityFlags::video_on;
            if (golemState.videoState)
                roRegsMain[ro::link_activity_u8] = roRegsMain[ro::link_activity_u8] | (uint8_t)regs::types::LinkActivityFlags::video_on;

            //postMessageDriverValue( muxDriverAddress, MessageId::device_param_set, 0, (uint32_t)u8 );
            //roRegsMain[ro::active_camera_no_u8] = u8;
        }

        if (rwRegsMain.getRegIfChanged( rw::video_channel_ctrl_u8, u8))
        {
            config.videoChannel = u8;
            needSaveConfig = true;
            // du channel and video channel packed in one byte
            //postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, 0, (uint32_t)u8 );
            //postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, value_id_golem_video_channel, config.videoChannel );
            //UNDONE: need to save to flash?
        }

        if (rwRegsMain.getRegIfChanged( rw::control_channel_ctrl_u8, u8))
        {
            prevDuChannel    = config.duChannel;
            config.duChannel = u8;
            postMessageDriverValue( golemDriverAddress, MessageId::device_param_set, value_id_golem_du_channel, config.duChannel );
            // заводим таймер на проверку связи
            timerSet( timer_event_switch_command_channel, timer_interval_switch_command_channel );
            needSaveConfig = true;
        }

        if (rwRegsMain.getRegIfChanged( rw::video_transmitter_power_ctrl_u8, u8))
        {
            config.videoPower = u8;
            needSaveConfig    = true;
        }


        

        #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)
        if (rwRegsMain.getRegIfChanged( rw::pressure_diff_left_ctrl_u8, u8))
        {
            suckingFootLeft1.rwRegs[ regs::SuckingFoot::rw::pressure_diff_ctrl_u8 ] = u8;
            suckingFootLeft2.rwRegs[ regs::SuckingFoot::rw::pressure_diff_ctrl_u8 ] = u8;
        }
        #endif

        if (rwRegsMain.getRegIfChanged( rw::pressure_diff_right_ctrl_u8, u8))
        {
            suckingFootRight1.rwRegs[ regs::SuckingFoot::rw::pressure_diff_ctrl_u8 ] = u8;
            suckingFootRight2.rwRegs[ regs::SuckingFoot::rw::pressure_diff_ctrl_u8 ] = u8;
        }

        #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)

            #define TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( regName, regType )                   \
                    do                                                                           \
                    {                                                                            \
                        if (rwRegsMain.getRegIfChanged( rw::regName, regType))                   \
                        {                                                                        \
                            suckingFootLeft1.rwRegs[ regs::SuckingFoot::rw::regName ] = regType; \
                            suckingFootLeft2.rwRegs[ regs::SuckingFoot::rw::regName ] = regType; \
                            suckingFootRight1.rwRegs[ regs::SuckingFoot::rw::regName ] = regType;\
                            suckingFootRight2.rwRegs[ regs::SuckingFoot::rw::regName ] = regType;\
                        }                                                                        \
                    }                                                                            \
                    while(0)
        #else

            #define TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( regName, regType )                   \
                    do                                                                           \
                    {                                                                            \
                        if (rwRegsMain.getRegIfChanged( rw::regName, regType))                   \
                        {                                                                        \
                            suckingFootRight1.rwRegs[ regs::SuckingFoot::rw::regName ] = regType;\
                            suckingFootRight2.rwRegs[ regs::SuckingFoot::rw::regName ] = regType;\
                        }                                                                        \
                    }                                                                            \
                    while(0)

        #endif


        // Раскидываем на четыре присоски их настройки
        float f32;

        TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( sucker_pid_scale_proportional_f32, f32 );
        TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( sucker_pid_scale_integral_f32    , f32 );
        TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( sucker_pid_scale_differential_f32, f32 );

        uint16_t u16;

        TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( psensor_emergency_mode_ctrl_u8, u8 );
        TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( impeller_esc_current_limit_u8, u8 );
        TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( impeller_esc_pwm_interval_off_u16 , u16 );
        TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( impeller_esc_pwm_interval_idle_u16, u16 );
        TELEVERTEX_2V2_MANULA_SUCKERS_RW_SYNC4( impeller_esc_pwm_interval_max_u16, u16 );
    
    }


    virtual
    bool isReadyForPoll() override 
    {
        return true;
    }

    virtual
    void poll() override
    {
        perfromGandjubusWork();
    }


    virtual
    bool onIdle() override
    {

        return true;
    }

    //-----------------------------------------------------------------------------

public:

}; // class MainBoardLogic

