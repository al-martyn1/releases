#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

extern umba::SimpleFormatter  lout;

#include "device_state_indicator.h"

#include "umba.h"
#include "periph/gpio.h"


extern umba::periph::GpioPin &pinErrorLed;
extern umba::periph::GpioPin &pinGoodLed ;


void DeviceStateIndicator::handleIndicatorAction( Indicator indicator, IndicatorAction action )
{
    umba::periph::GpioPin &pin = indicator==Indicator::work_indicator ? pinGoodLed : pinErrorLed;

    switch(action)
       {
        case IndicatorAction::indicator_set:
             pin = true;
             break;

        case IndicatorAction::indicator_clear:
             pin = false;
             break;

        default:
             pin = !pin; 
       }
}
