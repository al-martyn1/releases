// master options
//#define USE_BTN_FOR_SPI_PING

// slave options

#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
#include "umba/hr_counter.h"


extern umba::SimpleFormatter  lout;

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"

#include "scalcus/pwm.h"


#include "periph/stm32_discovery.h"


//#include "spi_test_master_slave.h"
//#include "device_state_indicator.h"

#include "vtl-periph.h"

/* Calibration - https://forum.openrov.com/t/esc-calibration-erratic-calibrated-correctly/5237/10

Step 1: ESC disconnected from power
Step 2: Ensure Arduino connected to USB with code running and set at 1860
Step 3: Connect power to ESC, wait for double beep saying that it has memorized wavelength for top speed pulse
Step 4: Enter in 1060, the bottom speed or stop and watch it turn green and BOOM! Done!
Step 5" Enter into serial any number 1200 - 1864 and watch it run. It ONLY moves forward. There is NO neutral at 1500.


Scenario that works:

push high signal to ESC without power connected to esc. Arduino’s on, applying the high pulse
I attach power to ESC, beeps confirm high pulse remembered
Send low pulse, beeps confirm it’s remembered
Motor works perfectly fine
Scenario that does NOT work:

Attach ESC to arduiino and battery.
Turn on power to ALL, arduino and esc at once
jitters, left, right, fast, flow

http://ardupilot.org/copter/docs/esc-calibration.html

*/


#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )

//DECLARE_PIN( btnPin , STM32_DISCOVERY_BTN_USER );


using namespace umba::time_service;
using namespace umba::periph::traits;
using namespace umba::omanip;


umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);

// ESC PWM - PA11 TIM1 CH4
// X4 UART6 debug, TX: PA9 (X4.2), RX: PA10 (X4.1), GND: X4.3

uint32_t escPwmStandby =  800;
uint32_t escPwmDelta   =    5;
uint32_t escPwmMin     =  escPwmStandby + escPwmDelta;
uint32_t escPwmMax     = 2300;

uint32_t pwmFreq = 100; // Hz

unsigned pwmPulseOutputMax = 0;

void initTimer( uint32_t pwmFreq );



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    STM32_DISCOVERY_LEGACY_UART.init( STM32_DISCOVERY_UART_RX_GPIO,  STM32_DISCOVERY_UART_RX_GPIO_PIN_NO, STM32_DISCOVERY_UART_TX_GPIO, STM32_DISCOVERY_UART_TX_GPIO_PIN_NO, 460800 );
    //STM32_DISCOVERY_LEGACY_UART.init( PA10, PA9, 460800 );

    initTimer(pwmFreq);

    uint32_t pwmCtrl = escPwmStandby; // mode - microsec

    lout<<"Hello ESC TIM1 CH4!"<<endl;

    umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                         , pwmFreq, pwmPulseOutputMax
                                         , umba::periph::traits::TimerPwmControlType::microsecs
                                         , pwmCtrl
                                         );



    auto kbdHandler = umba::periph::makeKeyboardHandler
                    ( 
                         [&]( unsigned vkc, bool fPressed, size_t repeatCout )
                         {
                             using namespace umba::omanip;

                             #ifndef KBD_TEST

                             #ifndef IMPELLER_SIMPLE_UP_DOWN
                             if (fPressed)
                             {
                                 uint32_t pwmCtrlPrev = pwmCtrl;

                                 if (vkc == umba::periph::VirtualKeyCode::up || vkc == umba::periph::VirtualKeyCode::pageUp )
                                 {
                                     if (pwmCtrl!=escPwmStandby)
                                     {
                                         pwmCtrl += escPwmDelta * ( vkc == umba::periph::VirtualKeyCode::up ? 1 : 5 );
                                         if (pwmCtrl>escPwmMax)
                                             pwmCtrl = escPwmMax;
                                     }
                                 }
                                 else if (vkc == umba::periph::VirtualKeyCode::down || vkc == umba::periph::VirtualKeyCode::pageDown )
                                 {
                                     if (pwmCtrl!=escPwmStandby)
                                     {
                                         pwmCtrl -= escPwmDelta * ( vkc == umba::periph::VirtualKeyCode::down ? 1 : 5 );
                                         if (pwmCtrl<escPwmMin)
                                             pwmCtrl = escPwmMin;
                                     }
                                 }
                                 else if (vkc == umba::periph::VirtualKeyCode::enter || vkc == umba::periph::VirtualKeyCode::ins )
                                 {
                                     if (repeatCout<2)
                                     {
                                         if (pwmCtrl==escPwmStandby)
                                             pwmCtrl = escPwmMin;
                                         else
                                             pwmCtrl = escPwmStandby;
                                     }
                                 }

                                 if (pwmCtrlPrev != pwmCtrl)
                                 {
                                     lout<<"Set PWM: "<<pwmCtrl<<" us"<<endl;
                                     umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                                                          , pwmFreq, pwmPulseOutputMax
                                                                          , umba::periph::traits::TimerPwmControlType::microsecs
                                                                          , pwmCtrl
                                                                          );
                                 }

                             }

                             #endif /* IMPELLER_SIMPLE_UP_DOWN */

                             #else
                             if (vkc & umba::periph::VirtualKeyCode::virtualCodeFlag)
                                lout<<umba::periph::VirtualKeyCode::getKeyCodeName(vkc); //<<endl;
                             else
                                lout<<(char)(uint8_t)(vkc); //<<endl;
                             if (fPressed)
                                lout<<" pressed, count: "<<repeatCout<<endl;
                             else
                                lout<<" released"<<endl;
                             #endif

                         }
                    );

    umba::periph::legacy::UartTerminalKeyboard kbd = umba::periph::legacy::UartTerminalKeyboard( &kbdHandler, &uart::uart1 );


    unsigned n = 0;
    bool directionDown = false;

    uint32_t pwmCtrlDx = 3;

    #if !defined(KBD_TEST) && !defined(IMPELLER_SIMPLE_UP_DOWN)

        umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                             , pwmFreq, pwmPulseOutputMax
                                             , umba::periph::traits::TimerPwmControlType::microsecs
                                             , pwmCtrl
                                             );

    #endif


    while(true)
    {
        // delayMs(250); lout<<"EHLO\n";
        
        #if defined(KBD_TEST) || !defined(IMPELLER_SIMPLE_UP_DOWN)

        kbd.scanKeyboard();

        #else

        umba::time_service::delayMs(25);
        //kbd.scanKeyboard();
        if (directionDown)
        {
            pwmCtrl -= pwmCtrlDx;
            if (pwmCtrl<escPwmMin)
            {
                directionDown = false;
            }
        }
        else
        {
            pwmCtrl += pwmCtrlDx;
            //if (pwmCtrl>10000) // 1/2 of 50Hz
            if (pwmCtrl>escPwmMax) // - ESC max
            {
                directionDown = true;
            }
        }

        umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                             , pwmFreq, pwmPulseOutputMax
                                             , umba::periph::traits::TimerPwmControlType::microsecs
                                             , pwmCtrl
                                             );

        #endif
    }
}

//-----------------------------------------------------------------------------
void initTimer( uint32_t pwmFreq )
{
    using namespace umba::periph::traits;


    uint16_t prescalerT1 = 0;
    uint16_t periodT1    = 0;

    scalcus::calcTimerPwmPrescalerAndPeriod( SystemCoreClock, pwmFreq, prescalerT1, periodT1 );
    pwmPulseOutputMax = periodT1;

    umba::periph::traits::timerBaseInit( ESC_PWM_TIM, prescalerT1, periodT1 ); 
    umba::periph::traits::timerInitChannelPwm( ESC_PWM_TIM, ESC_PWM_TIM_CHANNEL_NO, ESC_PWM_GPIO, ESC_PWM_GPIO_PIN_NO, (periodT1+1)/pwmFreq-1, TIM_OCMode_PWM2 );
    
    timerEnable( ESC_PWM_TIM );

    timerSetCaptureCompareRegister( ESC_PWM_TIM, ESC_PWM_TIM_CHANNEL_NO, 1 );
}
//-----------------------------------------------------------------------------
