/*
    DRV8301

    A valid frame must meet following conditions:
    • Clock must be low when nSCS goes low.
    • Should have 16 full clock cycles.
    • Clock must be low when nSCS goes high.

    Clock - normal low

*/

#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"


#if !defined(STM32F3_SERIES)
    #error "STM32F3_SERIES not defined"
#endif


//#define CHIP_SELECT_PAUSE_TIMING_TEST
//#define TOGGLE_TIMENG_TEST

/* Если делаем прошивку для платы драйвера, то используем те пины, которые определены для неё.
   Если делаем прошивку для Discovery F303, то используем пины от отладочной доски - они удобнее на Discovery.
   Discovery от драйвера отличается частотой кварца - HSE_VALUE
*/

#if HSE_VALUE != 12000000
    #define USE_BLDC_DEBUG_BOARD_SPI
#endif

#ifdef USE_BLDC_DEBUG_BOARD_SPI
    
    #include "wiz2_BLDC_debug_board.h"

    #define DRV8301_SPI                           MAX6954_SPI                      /* SPI2 */
    #define DRV8301_SPI_CS_GPIO_PIN_ADDR_DIR      MAX6954_CS_GPIO_PIN_ADDR_DIR     /* PB12 */
    #define DRV8301_SPI_SCK_GPIO_PIN_ADDR         MAX6954_SPI_SCK_GPIO_PIN_ADDR    /* PB13 */
    #define DRV8301_SPI_MISO_GPIO_PIN_ADDR        MAX6954_SPI_MISO_GPIO_PIN_ADDR   /* PB14 */
    #define DRV8301_SPI_MOSI_GPIO_PIN_ADDR        MAX6954_SPI_MOSI_GPIO_PIN_ADDR   /* PB15 */

#else
    
    #include "wiz2_PLATFORM_Motor_Controller.h"
    #undef MCU1_DRV_CS_GPIO_PIN_ADDR_DIR
    #define MCU1_DRV_CS_GPIO_PIN_ADDR_DIR     UMBA_PINADDR_PD11, UMBA_GPIO_DIRECTION_OUT

    #define DRV8301_SPI                           MCU1_SPI                         /* SPI2 */
    #define DRV8301_SPI_CS_GPIO_PIN_ADDR_DIR      MCU1_DRV_CS_GPIO_PIN_ADDR_DIR    /* PD11 */
    #define DRV8301_SPI_SCK_GPIO_PIN_ADDR         MCU1_SPI_SCK_GPIO_PIN_ADDR       /* PF9  PF9  */
    #define DRV8301_SPI_MISO_GPIO_PIN_ADDR        MCU1_SPI_MISO_GPIO_PIN_ADDR      /* PA9  PA10 */
    //#define DRV8301_SPI_MISO_GPIO_PIN_ADDR        PA9      /* PA9  PA10 */
    #define DRV8301_SPI_MOSI_GPIO_PIN_ADDR        MCU1_SPI_MOSI_GPIO_PIN_ADDR      /* PB15 PB15 */

#endif




//#define USE_LEGACY_SPI_INIT

#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )



// Прикопаю - настройка частоты - http://easyelectronics.ru/arm-uchebnyj-kurs-taktovyj-generator-stm32.html

void spiInit();

//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);


DECLARE_PIN( drv8301CsPin, DRV8301_SPI_CS ); // PD11

//static void* spi2Addr = (void*)MAX6954_SPI;

static volatile uint32_t hseVal   = 0;
static volatile uint32_t coreClk  = 0;
static volatile uint32_t sysClk   = 0;
static volatile uint32_t ahbClk   = 0;
static volatile uint32_t apb1Clk  = 0;
static volatile uint32_t apb2Clk  = 0;
static volatile uint32_t spiFreq  = 0;


inline
uint16_t max6954_composeQuery( bool R_nW, uint16_t regNo, uint16_t data )
{
    return (R_nW ? 0x8000 : 0x0000) | (regNo & 0x0F)<<11 | (data & 0x03FF);
}


int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::time_service;
    using namespace umba::periph::traits;
    using namespace umba::omanip;

    //hseVal = HSE_VALUE;
    //sysClk = SystemCoreClock;
    hseVal  = clockGetFreq(ClockBus::OSCCLK);
    coreClk = clockGetFreq(ClockBus::CORECLK);
    sysClk  = clockGetFreq(ClockBus::SYSCLK);
    ahbClk  = clockGetFreq(ClockBus::AHB);
    apb1Clk = clockGetFreq(ClockBus::APB1);
    apb2Clk = clockGetFreq(ClockBus::APB2); 


    //uart::uart1.init( GPIOC, 5, GPIOC, 4, 460800 );

    lout<<"Hello F303"<<endl;


                                     
    spiInit();
    
    spiFreq = spiGetFreq( DRV8301_SPI );


    #if defined(CHIP_SELECT_PAUSE_TIMING_TEST) || defined(TOGGLE_TIMENG_TEST)
        UMBA_DISABLE_IRQ();
    #endif

    while(true)
    {

        //  72000000 - 72 MHz       
        //  Pause   T           dT        F
        //  0       4,00 usec   0         250.0 KHz
        //  1       4,24 usec   0,24      235.8 KHz
        //  2       4,60 usec   0,36      217.0 KHz
        //  3       5,00 usec   0,40      200.0 KHz
        //  4       5,36 usec   0,36      186.0 KHz
        //  5       5,74 usec   0,38      174.0 KHz
        //  6       6,14 usec   0,40      162.0 KHz
        //  7       6,50 usec   0,36      153.0 KHz
        //  8       6,88 usec   0,38      145.0 KHz
        //  9       7,26 usec   0,38      137.0 KHz
        // 10       7,62 usec   0,36      131.0 KHz
        // 11       8,00 usec   0,38      125.0 KHz
        // 12       8,38 usec   0,38      119.0 KHz
        // 13       8,76 usec   0,38      114.0 KHz
        // 14       9,12 usec   0,36      109.0 KHz
        // 15       9,52 usec   0,40      105.0 KHz
        // 16       9,85 usec   0,33      101.0 KHz
        // 17      10,25 usec   0,40       97.5 KHz
        // 18      10,60 usec   0,35       94.3 KHz
        // 19      11,00 usec   0,40       90.9 KHz
        // 20      11,35 usec   0,35       88.1 KHz
        // 21      11,75 usec   0,40       85.1 KHz
        // 22      12,10 usec   0,35       82.6 KHz
        // 23      12,50 usec   0,40       80.0 KHz
        // 24      12,85 usec   0,35       77.8 KHz
        // 25      13,25 usec   0,40       75.4 KHz
        // 26      13,60 usec   0,35       73.5 KHz
        // 27      14,00 usec   0,40       71.4 KHz
        // 28      14,35 usec   0,35       69.6 KHz
        // 29      14,75 usec   0,40       67.7 KHz
        // 30      15,10 usec   0,35       66.2 KHz
        //
        

        // Среднее - 0,37
        //  36MHz - 0.74 usec
        //  72MHz - 0.37 usec
        // 144MHz - 0.185usec

        //  1MHz  - 25.92 usec (26)
        //  9MHz  - 2.88 usec
        //  18MHz - 1.44 usec
        //  36MHz - 0.72 usec
        //  72MHz - 0.36 usec
        // 144MHz - 0.18 usec

        // 72 / 2 = 0.36*2

        // 26/144 = 0.18

        // ~300 usec on 1MHz - call/fixed part
        // 288 usec on 1MHz - call/fixed part
        // 8 usec on 36MHz  - call/fixed part
        // 4 usec on 72MHz  - call/fixed part
        // 2 usec on 144MHz - call/fixed part

        // Prescaler 256
        // Если сбрасывать Chip Select сразу по флагу !BSY
        // то проходит 1.5 мксек от фронта SCK до смены CS.
        // А надо, чтобы прошло 5.35 мксек - пол-периода
        // ( T=10.7 мксек, F = 93457.94 Hz)

        // Prescaler 128
        // t toggle - 1.5 usec
        // ( T=5.35 мксек, F = 187 KHz)

        // Prescaler 64
        // t toggle - 1.33 usec
        // ( T=2.66 мксек, F = 375 KHz)

        // Prescaler 32
        // t toggle - 1.5 usec
        // ( T=1.33 мксек, F = 751 KHz)

        // Prescaler 16
        // t toggle - 1.335 usec
        // ( T=670 нс, F = 1.49 KHz)

        // Prescaler 8
        // t toggle - 1.335 usec
        // ( T=340 нс, F = 2.94 KHz)


        // http://easyelectronics.ru/arm-uchebnyj-kurs-taktovyj-generator-stm32.html

        #ifdef CHIP_SELECT_PAUSE_TIMING_TEST

            // On 72 MHz MCU

            //volatile unsigned numIterations = 100;

            // 100 iterations
            // 16.40 us - full time
            // 15.86 us - clear spiChipSelectPause time
            // 158.6 ns - per iteration

            // 200 iterations
            // 30.00 us - full time
            // 29.46 us - clear spiChipSelectPause time
            // 147.3 ns - per iteration

            // 1000 iterations
            // 146.00 us  - full time
            // 145.46 us  - clear spiChipSelectPause time
            // 145.46 ns - per iteration

            // 10000 iterations
            // 1455.00 us  - full time
            // 1454.46 us  - clear spiChipSelectPause time
            // 145.44 ns - per iteration

            // 144 ns per iteration
            // 36MHz - 288ns
            // 1MHz  - 10368ns


            drv8301CsPin.toggle();
            //spiChipSelectPause( numIterations );
            spiChipSelectPause( 10000 );

        #elif defined(TOGGLE_TIMENG_TEST)

            // 540 нс On 72MHz MCU 
            drv8301CsPin.toggle();

        #else

            //umba::periph::traits::spiWrite( DRV8301_SPI, 0xA55A, drv8301CsPin, spiDoWaitNotBusy );
            static uint16_t val = 0;
            //val = umba::periph::traits::spiRead( DRV8301_SPI, 0x8800, drv8301CsPin, spiDoWaitNotBusy );

            /*
            umba::periph::traits::spiWrite( DRV8301_SPI, 0x8800, drv8301CsPin, spiDoWaitNotBusy );
            spiWaitTransmitComplete( DRV8301_SPI );
            spiWaitReceiveComplete( DRV8301_SPI );
            val = umba::periph::traits::spiReadGetValue( DRV8301_SPI );
            */

            //umba::periph::traits::spiWrite( DRV8301_SPI, max6954_composeQuery( false, 2, 0x5A ), drv8301CsPin, spiDoWaitNotBusy );
            uint16_t q0 = max6954_composeQuery( true, 0, 0x00 );
            uint16_t q1 = max6954_composeQuery( true, 1, 0x00 );
            uint16_t q2 = max6954_composeQuery( true, 2, 0x00 );
            uint16_t q3 = max6954_composeQuery( true, 3, 0x00 );

            uint16_t reg0 = umba::periph::traits::spiRead( DRV8301_SPI, q0, drv8301CsPin, spiDoWaitNotBusy );
            uint16_t reg1 = umba::periph::traits::spiRead( DRV8301_SPI, q1, drv8301CsPin, spiDoWaitNotBusy );
            uint16_t reg2 = umba::periph::traits::spiRead( DRV8301_SPI, q2, drv8301CsPin, spiDoWaitNotBusy );
            uint16_t reg3 = umba::periph::traits::spiRead( DRV8301_SPI, q3, drv8301CsPin, spiDoWaitNotBusy );
            //umba::periph::traits::spiWrite( DRV8301_SPI, max6954_composeQuery( false, 2, 0x5A ), drv8301CsPin, spiDoWaitNotBusy );

            //max6954_composeQuery( bool R_nW, uint16_t regNo, uint16_t data )

            delayMs(10);

            // https://www.rcgroups.com/forums/showthread.php?200567-BLDC-controller/page189
            // 


        #endif



    }

    return 0;
}






void spiInit()
{

    // SPI hints
    // 8/16 - https://diymcblog.blogspot.com/2018/03/spi-stm32-2.html
    // Статусы - http://www.cyberforum.ru/arm/thread2091007.html
    // Полезная инфа - https://microtechnics.ru/stm32-s-nulya-interfejs-spi/
    //   Важное дополнение – инициализация GPIO должна происходить после инициализации SPI, иначе могут возникнуть сбои в работе Slave.

    using namespace umba::periph::traits;

    SpiPrescaler psc100   = spiCalcPrescaler( DRV8301_SPI,   100000 );
    SpiPrescaler psc150   = spiCalcPrescaler( DRV8301_SPI,   150000 );
    SpiPrescaler psc200   = spiCalcPrescaler( DRV8301_SPI,   200000 );
    SpiPrescaler psc250   = spiCalcPrescaler( DRV8301_SPI,   250000 );
    SpiPrescaler psc500   = spiCalcPrescaler( DRV8301_SPI,   500000 );
    SpiPrescaler psc1000  = spiCalcPrescaler( DRV8301_SPI,  1000000 );
    SpiPrescaler psc2000  = spiCalcPrescaler( DRV8301_SPI,  2000000 );
    SpiPrescaler psc3000  = spiCalcPrescaler( DRV8301_SPI,  3000000 );
    SpiPrescaler psc4000  = spiCalcPrescaler( DRV8301_SPI,  4000000 );
    SpiPrescaler psc5000  = spiCalcPrescaler( DRV8301_SPI,  5000000 );
    SpiPrescaler psc10000 = spiCalcPrescaler( DRV8301_SPI, 10000000 );
    SpiPrescaler psc15000 = spiCalcPrescaler( DRV8301_SPI, 15000000 );
    SpiPrescaler psc20000 = spiCalcPrescaler( DRV8301_SPI, 20000000 );

    periphInit( DRV8301_SPI                      // SPI2
              , DRV8301_SPI_SCK_GPIO_PIN_ADDR     // PF9
              , DRV8301_SPI_MISO_GPIO_PIN_ADDR   // PA10
              , DRV8301_SPI_MOSI_GPIO_PIN_ADDR   // PB15
              , umba::periph::traits::spiDataBits16
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              , spiCalcPrescaler( DRV8301_SPI,   100000 ) // umba::periph::traits::spiPrescaler64 //, umba::periph::traits::spiPrescalerLowFreq
              , PinSpeed::high // PinSpeed::low
              );

    drv8301CsPin = true;



/*
    CPOL_CPHA   - clk - инверсный, данные - прямой
    nCPOL_CPHA  - Оба сигнала нормальная логика
    CPOL_nCPHA  - Оба сигнала инверсная логика
    nCPOL_nCPHA - clk - прямой, дата инверсная

    PinSpeed::low
    PinSpeed::medium
    PinSpeed::fast
    PinSpeed::high

*/

}

