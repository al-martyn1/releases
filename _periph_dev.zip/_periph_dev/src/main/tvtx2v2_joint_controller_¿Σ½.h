#pragma once

#include "vtx2v2/telexertex2_slaves.h"
#include <utility>

//#define JOINT_MEMBERS_FOR_IGOR

//#define JOINT_CONTROLLER_USE_POSTION_MOVE_MODE

namespace Televertex2
{


struct JointControllerBase
{

    // Состояние
    uint16_t    ro_currentAngle      ; // ro::current_angle_u16
    uint8_t     ro_stateCounter      ; // ro::state_counter_u8
    uint16_t    ro_negativeAngleLimit; // ro::negative_angle_limit_u16
    uint16_t    ro_positiveAngleLimit; // ro::positive_angle_limit_u16
    uint8_t     ro_noMovementFlag    ; // ro::no_movement_flag_u8
    
    // управление
    uint16_t    rw_targetAngle       = 0; // rw::target_angle_u16
    int8_t      rw_speed             = 0; // rw::speed_s8
    uint8_t     rw_modeCtrl          = 0; // rw::mode_ctrl_u8
    uint8_t     rw_noMovementPeriod  = 0; // rw::no_movement_period_u8

    #ifdef JOINT_MEMBERS_FOR_IGOR
    // то что по шине пробегало - для Игоря
    uint16_t    master_targetAngle       = 0; // rw::target_angle_u16
    int8_t      master_speed             = 0; // rw::speed_s8
    uint8_t     master_modeCtrl          = 0; // rw::mode_ctrl_u8
    uint8_t     master_noMovementPeriod  = 0; // rw::no_movement_period_u8
    #endif

    int16_t     iMinAngle             = 0;
    int16_t     iMaxAngle             = 0;
    int16_t     iCurAngle             = 0;
    int16_t     rw_targetAngleInput   = 0; // нескорректированный угол от минус мина до плюс макса

    bool isBusy() const
    {
        return ro_stateCounter&1 ? true : false;
    }

    int16_t angleDiff( int16_t a1, int16_t a2 ) const
    {
        int16_t d = a1-a2;
        if (d<0)
            return -d;

        return d;
    }

    bool isTargetReached( int16_t targetAngle, int16_t currentAngle ) const
    {
        int16_t delta = angleDiff( currentAngle, targetAngle );
        return delta < 2;
    }

    bool isTargetReached( int16_t targetAngle ) const
    {
        return isTargetReached( targetAngle, iCurAngle );
    }



    bool isTargetReached( ) const
    {
        return isTargetReached( rw_targetAngleInput );
    }

    virtual void poll() = 0;

protected:

    uint16_t recalcTargetAngle( int16_t a )
    {
        if (m_needCorrection)
        {
            return (uint16_t)((int16_t)m_zeroPoint - rw_targetAngleInput);
            //return ro_positiveAngleLimit - a;
        }
        else
        {
            return (uint16_t)((int16_t)m_zeroPoint + rw_targetAngleInput);
            //return a + ro_negativeAngleLimit;
        }
    }


    uint16_t    m_shadow_rw_targetAngle       = 0;
    int8_t      m_shadow_rw_speed             = 0;
    uint8_t     m_shadow_rw_modeCtrl          = 0; // Режим движения - 0 - Неподвижность, 1 - Скорость, 2 - Позиция, 3 - Движение в 0 (см. тип JointMode в vertex_types.rdl)
    uint8_t     m_shadow_rw_noMovementPeriod  = 0;

    uint16_t    m_zeroPoint = 0; // нужно задать

    bool        m_needCorrection             = false;
    int16_t     m_shadow_rw_targetAngleInput = 0;

}; // JointControllerBase


template<typename JointType>
struct JointController : public JointControllerBase
{
    JointController(JointType *pJoint, uint16_t zeroPoint, bool needCorrection = false )
    : m_pJoint(pJoint)
    {
        m_needCorrection = needCorrection;
        m_zeroPoint      = zeroPoint;
    }

    virtual
    void poll() override
    {
        using namespace regs::Joint;

        ro_currentAngle       = m_pJoint->roRegs[ ro::current_angle_u16        ];
        ro_stateCounter       = m_pJoint->roRegs[ ro::state_counter_u8         ];
        ro_negativeAngleLimit = m_pJoint->roRegs[ ro::negative_angle_limit_u16 ];
        ro_positiveAngleLimit = m_pJoint->roRegs[ ro::positive_angle_limit_u16 ];
        ro_noMovementFlag     = m_pJoint->roRegs[ ro::no_movement_flag_u8      ];

        #ifdef JOINT_MEMBERS_FOR_IGOR
        master_targetAngle       = m_pJoint->rwRegs[ rw::target_angle_u16 ]; // rw::target_angle_u16
        master_speed             = m_pJoint->rwRegs[ rw::speed_s8 ]; // rw::speed_s8
        master_modeCtrl          = m_pJoint->rwRegs[ rw::mode_ctrl_u8 ]; // rw::mode_ctrl_u8
        master_noMovementPeriod  = m_pJoint->rwRegs[ rw::no_movement_period_u8 ]; // rw::no_movement_period_u8
        #endif

        iMinAngle                = (int16_t)ro_negativeAngleLimit - (int16_t)m_zeroPoint;
        iMaxAngle                = (int16_t)ro_positiveAngleLimit - (int16_t)m_zeroPoint;
        iCurAngle                = (int16_t)ro_currentAngle - (int16_t)m_zeroPoint;

        if (m_shadow_rw_targetAngleInput!=rw_targetAngleInput)
        {
            m_shadow_rw_targetAngleInput = rw_targetAngleInput;
            rw_targetAngle = recalcTargetAngle( rw_targetAngleInput );
        }
        

        if ( m_shadow_rw_targetAngle                != rw_targetAngle )
        {
            m_shadow_rw_targetAngle                  = rw_targetAngle;
            m_pJoint->rwRegs[ rw::target_angle_u16 ] = rw_targetAngle;
        }

        if ( m_shadow_rw_speed              != rw_speed )
        {
            m_shadow_rw_speed                = rw_speed;
            m_pJoint->rwRegs[ rw::speed_s8 ] = rw_speed;
        }

        if ( m_shadow_rw_modeCtrl               != rw_modeCtrl )
        {
            m_shadow_rw_modeCtrl                 = rw_modeCtrl;
            m_pJoint->rwRegs[ rw::mode_ctrl_u8 ] = rw_modeCtrl;
        }

        if ( m_shadow_rw_noMovementPeriod                != rw_noMovementPeriod )
        {
            m_shadow_rw_noMovementPeriod                  = rw_noMovementPeriod;
            m_pJoint->rwRegs[ rw::no_movement_period_u8 ] = rw_noMovementPeriod;
        }

    }

protected:

    JointType  *m_pJoint                   ;

}; // JointController


template<typename JointType>
inline
JointController<JointType> makeJointController( JointType *pJoint, uint16_t zeroPoint, bool needCorrection = false )
{
    return JointController<JointType>( pJoint, zeroPoint, needCorrection );
}


} // namespace Televertex2



//----------------------------------------------------------


class ActiveJointController : public umba::ITimerHandler               // for timers
                            , public umba::IPollCapable                // для полировки
{

    typedef umba::time_service::TimeTick TimeTick;


public:

    UMBA_BEGIN_INTERFACE_MAP_EX( umba::ITimerHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::IPollCapable )
    UMBA_END_INTERFACE_MAP()

    UMBA_DELEGATE_QUERY_INTERFACE(umba::ITimerHandler)


    ActiveJointController( Televertex2::JointControllerBase *pJointController )
    : m_pJointController(pJointController)
    {}

    // Установка в систему
    bool install()
    {
       //timerSet(  /* umba::rtkos::TimerEventId */ 0, 15 );
        return umba::rtkos::pollScheduleAdd( this, umba::rtkos::PollPriority::normal );
    }

    bool isBusy()
    {
        return m_isStarted;
    }

    bool isFailed()
    {
        return m_isFailed!=0;
    }

    // http://www.keil.com/support/man/docs/uv4/uv4_cm_breakset.htm?_ga=2.117787466.258239130.1565581302-1508115793.1541001193
    // http://www.keil.com/support/man/docs/uv4/uv4_db_expressions.htm
    // _break_=(_RWORD(0x3e78)==0x0010105B )
    // BS WRITE 0x20000DB6, 1, cnt , "cmd"
    void restart( )
    {
        int16_t intervalEnd   = m_phaseTargets[ 0 ];
        int16_t intervalStart = m_fixedStartAngle;
        size_t phaseNumber = findCurrentPhase( intervalStart, intervalEnd );

        UMBA_RTKOS_LOG<<"---\nrestart to: "<<m_phaseTargets[numPhases-1]<<"  CA: "<<m_curAngle<<"  Ph#: "<<phaseNumber<<"  PWR: "<<m_curPower<<"\n";
        start( m_phaseTargets[numPhases-1], true );
        //UMBA_RTKOS_LOG<<"IS: "<<intervalStart<<"  IE: "<<intervalEnd<<"  CA: "<<m_curAngle<<"  ";
        //UMBA_RTKOS_LOG<<"Ph#: "<<phaseNumber<<"  TAI: "<<m_pJointController->rw_targetAngleInput<<"\n";
    }

    void start( int16_t targetAngle, bool useMaxPower = false )
    {
        #if 0
        if (m_pJointController->isTargetReached( targetAngle ))
        {
            m_isStarted = false;
            m_isFailed  = 0;
            return;
        }

        m_pJointController->poll();
        //int 
        m_fixedStartAngle = m_curAngle;
        int delta = (int)targetAngle - (int)m_fixedStartAngle;
        int absDelta = delta<0 ? -delta : delta;

        //#if defined(JOINT_CONTROLLER_USE_POSTION_MOVE_MODE)

    // static constexpr size_t numPhasesMax = 32;
    // static constexpr size_t numStartStopPhasesMax = 16;
        numPhases          = (size_t)absDelta / 3;
        if (numPhases < 1)
            numPhases = 1;
        if (numPhases > numPhasesMax)
            numPhases = numPhasesMax;

        numStartStopPhases = numPhases / 3; // 2; // numStartStopPhasesMax;


        m_minPower  = 20;
        m_curPower  = m_minPower; // start with this power


        int8_t maxPower = 100;
        //if (absDelta>100)
        //    maxPower = 100;
        //else if (absDelta>90)
        //    maxPower =    90;
        //else if (absDelta>80)
        //    maxPower =    80;
        //else if (absDelta>70)
        //    maxPower =    70;
        //else if (absDelta>60)
        //    maxPower    = 60;
        //else if (absDelta>50)
        //    maxPower =    50;
        //else if (absDelta>40)
        //    maxPower =    40;


        for( int i = 0; i!=(int)numPhases; ++i )
        {
            int scaledDelta   = (i+1)*delta;
            int factoredDelta = scaledDelta / (int)numPhases;

            m_phaseTargets[i] = (int16_t)((int)m_fixedStartAngle + factoredDelta);
            //m_phaseTargets[i] = targetAngle;

            m_pJointController->rw_targetAngleInput = m_phaseTargets[i];
            m_pJointController->poll();
            m_phaseTargetsRaw[i] = m_pJointController->rw_targetAngle;

            int idxFromEnd = (int)numPhases - i;
            if ( i <= (int)numStartStopPhases )
            {
                if (useMaxPower)
                    m_phasePowers[i] = 100;
                else
                    m_phasePowers[i] = m_minPower + i*(maxPower-m_minPower) / ((int)numStartStopPhases-1);
            }
            else if ( idxFromEnd <= (int)numStartStopPhases )
            {
                //m_phasePowers[idxFromEnd-1] = (idxFromEnd)*(100-m_curPower) / ((int)numStartStopPhases-1);
                if (useMaxPower)
                    m_phasePowers[i] = 100;
                else
                    m_phasePowers[i] = m_minPower + (idxFromEnd)*(maxPower-m_curPower) / ((int)numStartStopPhases-1);
            }
            else
            {
                if (useMaxPower)
                    m_phasePowers[i] = 100;
                else
                    m_phasePowers[i] = maxPower; // средние фазы жарим на полной
            }
        }

        m_curPhase  = 0;
        m_prevPhase = (size_t)-1;
        m_curPhaseStartTick = umba::time_service::getCurTimeMs();
        m_isStarted = true;
        if (!useMaxPower)
            m_isFailed  = 0;

        // стартуем нулевую фазу
        m_pJointController->rw_targetAngleInput = m_phaseTargets[numPhases-1]; // m_phaseTargets[0];
        m_pJointController->rw_speed       = m_curPower;
        m_pJointController->rw_modeCtrl    = 2; // moveTo command
        m_curStateCounter = m_pJointController->ro_stateCounter;
        m_pJointController->poll();

        UMBA_RTKOS_LOG<<"---\nstart from "<<m_phaseTargets[0]<<" to "<<m_phaseTargets[numPhases-1]<<"  CA: "<<m_curAngle<<"  PWR: "<<m_curPower<<"\n";

        //#endif
        // master_noMovementPeriod

        #endif
    }


protected:

    template<typename T>
    bool isInRange( T val, T n, T x)
    {
        if (x < n)
           std::swap( x, n );

        return val >= n && val <= x ;
    }

    virtual
    bool isReadyForPoll() override 
    {
        return true;
    }

    umba::rtkos::TimerId timerSet( umba::rtkos::TimerEventId eventId, umba::rtkos::TimeTick period )
    {
        return umba::rtkos::timerSet( this, eventId, period );
    }

    size_t findCurrentPhase( int16_t &intervalStart, int16_t &intervalEnd )
    {
        size_t phaseNumber = numPhases;

        intervalEnd   = m_phaseTargets[ 0 ];

        intervalStart = m_fixedStartAngle;

        for( ; phaseNumber!=0; --phaseNumber )
        {
            intervalStart = phaseNumber > 1 ? m_phaseTargets[phaseNumber-2] : m_fixedStartAngle;
            intervalEnd   = m_phaseTargets[phaseNumber-1];
            if (isInRange( m_curAngle, intervalStart, intervalEnd))
            {
                phaseNumber--;
                break;
            }
        }

        return phaseNumber;
    }

    bool isPowerFail()
    {
        if (m_curPower>=100)
        {
            return true;
        }
        return false;
    }

    bool increaseCurPower( size_t phaseNumber, bool forceSend = true )
    {
        bool bFail = m_curPower>=100;
        if (m_curPower>=100)
        {
            bFail = true;
        }
            //return false;

        UMBA_RTKOS_LOG<<"INC: "<<m_curPower<<"\n";

        //if (forceSend)
        //{
        //m_curPhaseStartTick = umba::time_service::getCurTimeMs();

        m_curPower += 1; // 5; // 1; // 5;
        if (m_minPower<m_curPower)
            m_minPower = m_curPower;
        
        if (m_curPower>100)
            m_curPower = 100;

        m_pJointController->rw_modeCtrl = 0; // stop mode
        m_pJointController->poll();

        //m_phaseTargetsRaw[m_curPhase] = m_pJointController->rw_targetAngle;

        m_pJointController->rw_targetAngleInput = m_pJointController->rw_targetAngleInput==0 ? 1 : 0;
        m_pJointController->poll();
        m_pJointController->rw_targetAngleInput = m_phaseTargets[numPhases-1];

        m_pJointController->rw_speed    = m_curPower;
        m_pJointController->rw_modeCtrl = 2; // rerun
        m_pJointController->poll();

        if (bFail)
        {
            m_curPower = 30;
            m_curPhaseStartTick = umba::time_service::getCurTimeMs();
        }

        if ( m_pJointController->isTargetReached( m_phaseTargets[numPhases-1], m_curAngle ) )
        {
            goDone(true);
            return true;
        }

        return !bFail;
    }

    void goDone( bool bOk )
    {
        m_isStarted = false;
        if (!bOk)
            m_isFailed++;
        m_pJointController->rw_modeCtrl = 0;
        m_pJointController->poll();
    }

    void setNewCurPowerValue( size_t phaseNumber )
    {
        //m_phaseTargetsRaw[m_curPhase] = m_pJointController->rw_targetAngle;
        
        m_curPhaseStartTick = umba::time_service::getCurTimeMs();
        m_curPower = m_phasePowers[m_curPhase];
        
        //if (m_curPower<m_minPower)
        //    m_curPower = m_minPower;
        
        if (m_curPower>100)
            m_curPower = 100;
        
        m_pJointController->rw_speed       = m_curPower;
        m_pJointController->poll();
    }

    virtual
    void poll() override
    {
        m_pJointController->poll();

        m_curAngle = m_pJointController->iCurAngle;

        if (!m_isStarted)
        {
            if (m_targetAngleShadow != m_targetAngle)
            {
                m_targetAngleShadow = m_targetAngle;
                start( m_targetAngle );
            }
        }
    }


    int16_t getDistanceToEnd() const
    {
        int16_t d = m_phaseTargets[numPhases-1] - m_curAngle;
        return d<0 ? -d : d;
    }
    



    void doJob()
    {
        m_pJointController->poll();

        if (!m_isStarted)
            return;


        #if !defined(JOINT_CONTROLLER_USE_POSTION_MOVE_MODE)

        // m_pJointController->isBusy()

        /* 
            Нам нужно определять дистанцию до целевой точки.
            Если предыдущая равна или меньше текущей - то стоим или даже сдвинулись назад.
            Нужно увеличивать мощность
        
         */


        #if 0

        if ( m_pJointController->isTargetReached( m_phaseTargets[numPhases-1], m_curAngle ) )
        {
            goDone(true);
            return;
        }

        //-------------------

        //UMBA_RTKOS_LOG<<"---\n";

        //size_t phaseNumber = numPhases;

        int16_t intervalEnd   = m_phaseTargets[ 0 ];
        int16_t intervalStart = m_fixedStartAngle;
        size_t phaseNumber = findCurrentPhase( intervalStart, intervalEnd );


        if ( m_pJointController->isTargetReached( intervalEnd, m_curAngle ) )
        {
            // дополз до конца интервала
            //UMBA_RTKOS_LOG<<"CP1\n";

            //m_prevPhase = phaseNumber;
            ++phaseNumber;
            m_curPhase = phaseNumber;

            bool phaseChanged = m_prevPhase!=m_curPhase;
            m_prevPhase = m_curPhase;

            if (m_curPhase>=numPhases)
            {
                //UMBA_RTKOS_LOG<<"CP2\n";
                goDone(true);
                return; // дошел до конца
            }

            if (!phaseChanged)
            {
                //UMBA_RTKOS_LOG<<"CP3\n";
                // тупим в конце интервала
                auto tickNow = umba::time_service::getCurTimeMs();
                auto dt = tickNow - m_curPhaseStartTick;
                if (dt>=50) // тупим долго
                {
                    if (!m_isFailed)
                    {
                        m_failPos = m_curAngle;
                    }
                    if (!m_pJointController->isTargetReached( m_failPos, m_curAngle ))
                    {
                        m_curPhaseStartTick = umba::time_service::getCurTimeMs();
                        m_isFailed = 0;
                    }
                    else
                    {
                        if (!increaseCurPower(m_curPhase))
                            m_isFailed++;

                        if (m_isFailed>50)
                           restart();
                        return;
                        /*
                        if (!increaseCurPower(m_curPhase)) // нет больше мощи, фэйлимся
                        {
                            if (m_isFailed++>50)
                               restart();
                            return;
                        }
                        */
                    }
                }
            }
            else
            {
                //UMBA_RTKOS_LOG<<"CP7\n";
                setNewCurPowerValue(m_curPhase);
            }
        }
        else if ( m_pJointController->isTargetReached( intervalStart, m_curAngle ) )
        {
            //UMBA_RTKOS_LOG<<"CP8\n";

            bool phaseChanged = m_prevPhase!=m_curPhase;
            m_prevPhase = m_curPhase;
            
            if (!phaseChanged)
            {
                //UMBA_RTKOS_LOG<<"CP9\n";
                // тупим в начале интервала
                auto tickNow = umba::time_service::getCurTimeMs();
                auto dt = tickNow - m_curPhaseStartTick;
                if (dt>=50) // тупим долго
                {
                    if (!m_isFailed)
                    {
                        m_failPos = m_curAngle;
                    }
                    if (!m_pJointController->isTargetReached( m_failPos, m_curAngle ))
                    {
                        m_curPhaseStartTick = umba::time_service::getCurTimeMs();
                        m_isFailed = 0;
                    }
                    else
                    {
                        if (!increaseCurPower(m_curPhase))
                            m_isFailed++;

                        if (m_isFailed>50)
                           restart();
                        return;

                        /*
                        //UMBA_RTKOS_LOG<<"CP10\n";
                        if (!increaseCurPower(m_curPhase)) // нет больше мощи, фэйлимся
                        {
                            //UMBA_RTKOS_LOG<<"CP11\n";
                            //goDone(false);
                            //if (m_isFailed==1)
                            if (m_isFailed++>50)
                            {
                               //UMBA_RTKOS_LOG<<"CP12\n";
                               restart();
                            }
                            return;
                        }
                        */
                    }
                }
            }
            else
            {
                //UMBA_RTKOS_LOG<<"CP13\n";
                setNewCurPowerValue(m_curPhase);
            }

        }
        else
        {
            //UMBA_RTKOS_LOG<<"CP14\n";
            // еще едет
            //m_curPhaseStartTick = umba::time_service::getCurTimeMs();
            if (m_pJointController->isBusy())
            {
                //UMBA_RTKOS_LOG<<"CP15\n";
            }
            else
            {
                //UMBA_RTKOS_LOG<<"CP16\n";
                // m_curPhaseStartTick = umba::time_service::getCurTimeMs();
                auto tickNow = umba::time_service::getCurTimeMs();
                auto dt = tickNow - m_curPhaseStartTick;
                if (dt>=50) // уже давно едем
                {
                    //UMBA_RTKOS_LOG<<"CP17\n";
                    if (m_pJointController->isTargetReached())
                    {
                        //UMBA_RTKOS_LOG<<"CP18\n";
                        goDone(true);
                    }
                    else
                    {
                        if (!m_isFailed)
                        {
                            m_failPos = m_curAngle;
                        }
                        if (!m_pJointController->isTargetReached( m_failPos, m_curAngle ))
                        {
                            m_curPhaseStartTick = umba::time_service::getCurTimeMs();
                            m_isFailed = 0;
                        }
                        else
                        {
                            if (!increaseCurPower(m_curPhase))
                                m_isFailed++;

                            if (m_isFailed>50)
                               restart();
                            return;
                        }
                    }
                }
            }
        }
        
        // int16_t angleDiff( int16_t a1, int16_t a2 )

        #endif

        //-------------------


        #else
        if (m_pJointController->isBusy())
        {
            return; // motor is busy
        }

        if (m_pJointController->isTargetReached())
        {
            ++m_curPhase;
            m_curStateCounter = m_pJointController->ro_stateCounter; // засекаем счетчик для новой файзы

            m_pJointController->rw_modeCtrl = 0; // stop mode
            m_pJointController->poll();

            if (m_curPhase==numPhases)
            {
                m_isStarted = false;
                m_pJointController->rw_modeCtrl = 0;
                return;
            }

            m_curPower = m_phasePowers[m_curPhase];

            if (m_curPower<m_minPower)
                m_curPower = m_minPower;

            if (m_curPower>100)
                m_curPower = 100;

        }
        else // не доехали до цели
        {
            if (m_curStateCounter == (m_pJointController->ro_stateCounter&(~(uint8_t)1)))
            {
                return;
            }

            if (m_curPower>=100) // дальше - некуда
            {
                m_isStarted = false;
                m_isFailed++;
                m_pJointController->rw_modeCtrl = 0;
                return;
            }

            m_pJointController->rw_modeCtrl = 0; // stop mode
            m_pJointController->poll();

            m_curPower += 10; // Добавляем газку, если не осилили

            if (m_minPower<m_curPower)
                m_minPower = m_curPower;

            if (m_curPower>100)
                m_curPower = 100;

        }

        m_pJointController->rw_targetAngleInput = m_phaseTargets[m_curPhase];
        m_pJointController->rw_speed       = m_curPower;
        m_pJointController->rw_modeCtrl    = 2; // moveTo command
        m_pJointController->poll();

        #endif

    }

    virtual
    void onTimer( unsigned eventId ) override
    {
        doJob();
        /*
        switch( eventId )
        {
            case timer_event_golem_command:
                 {
                 }
                 break;


            //default:
        };
        */

    }


/*
        m_curPhase  = 0;
        m_isStarted = true;
        m_isFailed  = false;
        m_curPower  = 30; // start with this power
*/
    int16_t       m_targetAngle; // для управления из отладчика
    int16_t       m_curAngle;
    int16_t       m_fixedStartAngle;

    static constexpr size_t numPhasesMax = 32;
    static constexpr size_t numStartStopPhasesMax = 16;
    size_t numPhases = 32;
    size_t numStartStopPhases = 16;

    int16_t       m_failPos;

    int16_t       m_targetAngleShadow;

    volatile bool m_isStarted = false;
    size_t        m_isFailed  = 0;
    size_t        m_curPhase  = 0;
    size_t        m_prevPhase = 0;
    TimeTick      m_curPhaseStartTick = 0;
    int8_t        m_curPower  = 0;
    int8_t        m_minPower  = 0;
    int16_t       m_phaseTargets[numPhasesMax];
    int16_t       m_phasePowers[numPhasesMax];
    //int8_t        m_phasePower

    uint8_t       m_curStateCounter; // ro_stateCounter

    Televertex2::JointControllerBase *m_pJointController;

    int16_t       m_phaseTargetsRaw[numPhasesMax];
    // uint16_t    rw_targetAngle

};






/*

                if (isRwSyncEnabled())
                {
                    // Sync rw regs
                    syncReg_rw( regtype_unsigned(), regsize_16(), 0xE7, 0x80 ); // targetAngle
                    syncReg_rw( regtype_signed  (), regsize_8 (), 0xE9, 0x82 ); // speed
                    syncReg_rw( regtype_unsigned(), regsize_8 (), 0xEA, 0x83 ); // modeCtrl
                    syncReg_rw( regtype_unsigned(), regsize_8 (), 0xEB, 0x84 ); // currentLimit
                    syncReg_rw( regtype_unsigned(), regsize_16(), 0xEC, 0x85 ); // negativeAngleLimit
                    syncReg_rw( regtype_unsigned(), regsize_16(), 0xEE, 0x87 ); // positiveAngleLimit
                    syncReg_rw( regtype_unsigned(), regsize_8 (), 0xF0, 0x89 ); // saveDataToFlash
                    syncReg_rw( regtype_unsigned(), regsize_8 (), 0xF1, 0x8A ); // clearFlash
                    syncReg_rw( regtype_unsigned(), regsize_8 (), 0xF2, 0x8B ); // noMovementPeriod
                }
    
                if (isRoSyncEnabled())
                {
                    // Sync ro regs
                    syncReg_ro( regtype_unsigned(), regsize_16(), 0x6D, 0x00 ); // currentAngle
                    syncReg_ro( regtype_unsigned(), regsize_8 (), 0x6F, 0x02 ); // stateCounter
                    syncReg_ro( regtype_unsigned(), regsize_16(), 0x70, 0x03 ); // negativeAngleLimit
                    syncReg_ro( regtype_unsigned(), regsize_16(), 0x72, 0x05 ); // positiveAngleLimit
                    syncReg_ro( regtype_unsigned(), regsize_8 (), 0x74, 0x07 ); // noMovementFlag
                }


*/