#include "luart/uart_handle.h"
#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

//#include "stm32.h"

#include "periph/gpio.h"
#include "periph/power.h"
#include "periph/adc.h"
#include "periph/flash.h"

#include "rtkos/rtkos.h"
#include "rtkos/rtkos_protothread.h"
#include "rtkos/starters.h"

#include "drivers/messages_rtkos.h"
#include "drivers/periph/legacy_uart_driver.h"
#include "drivers/periph/soft_i2c_driver.h"
#include "drivers/periph/tim_pwm_driver_impl.h"
#include "drivers/periph/adc_driver_impl.h"
#include "drivers/periph/gpio_driver_impl.h"
#include "drivers/periph/power_switch_driver_impl.h"
#include "drivers/periph/device_state_indicator_driver_impl.h"



#include "drivers/uplinks/golem_driver_impl.h"

//#include "drivers/motors/esc_driver_impl.h"

#include "drivers/hid/keyboard_terminal_driver.h"

//#include "drivers/sensors/honeywell_psensor_driver.h"


#include "rtkos/handlers/keyboard_hadler_impl_base.h"


#include "callbacks/callbacks.h"
#include "milliganjubus_core/milliganjubus_simple_reg_table.h"
#include "milliganjubus_core/milliganjubus_slave_session.h"
#include "milliganjubus_core/milliganjubus_synchronizer.h"
#include "milliganjubus_core/milliganjubus_master_session.h"


//#include "boards_conf/tvtx2v2_Main_Board_pins.cpp"
#include "boards_conf/tvtx2v2_Main_Board_conf.h"


#include "vtx2v2/telexertex2_types.h"

#include "vtx2v2/telexertex2_regs.h"

#include "vtx2v2/telexertex2_hot_end_regs.h"
#include "vtx2v2/telexertex2_joint_regs.h"
#include "vtx2v2/telexertex2_sucker_regs.h"

#include "vtx2v2/telexertex2_accel_regs.h"
#include "vtx2v2/telexertex2_battery_regs.h"
#include "vtx2v2/telexertex2_esc_regs.h"
#include "vtx2v2/telexertex2_gyro_regs.h"
#include "vtx2v2/telexertex2_pid_regs.h"
#include "vtx2v2/telexertex2_tvko_regs.h"

#include "vtx2v2/telexertex2_slaves.h"


#include "crc/umba_crc.h"



//-----------------------------------------------------------------------------
// Configuration
//#define USE_LEFT_GANJUBUS_AS_DEBUG

// For C6 use UMBA_TOO_LOW_MEM macro

// -E option make preprocessor output


//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
#undef RS485_LEFT_UART
#undef RS485_LEFT_LEGACY_UART
#define RS485_LEFT_UART                               UART4
#define RS485_LEFT_LEGACY_UART                        uart::uart4

//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------


struct MainBoardConfig
{
    uint8_t duChannel      = 0;
    uint8_t videoChannel   = 0;
    uint8_t videoPower     = 50;
};

struct MainBoardLinkState
{
    uint8_t videoState     = 0;
    uint8_t scramblerState = 0;
};


struct FlashConfigCrcCalculator
{
    uint32_t operator()( const uint8_t * buf, size_t len)
    {
        return umba_crc32 (buf, (uint32_t)len);
    }
};

// VC - 256/48
// VD - 384/80
bool readConfig( MainBoardConfig &cfg )
{
    return
    umba::periph::flash::readConfig< MainBoardConfig
                                   , FlashConfigCrcCalculator
                                   , umba::periph::flash::flash_size_256K
                                   , umba::periph::flash::page_size_2048
                                   , 0x8000000
                                   >( cfg );
}

bool writeConfig( const MainBoardConfig &cfg )
{
    return
    umba::periph::flash::writeConfig< MainBoardConfig
                                    , FlashConfigCrcCalculator
                                    , umba::periph::flash::flash_size_256K
                                    , umba::periph::flash::page_size_2048
                                    , 0x8000000
                                    >( cfg );
}

bool invalidateConfig( const MainBoardConfig &cfg )
{
    return
    umba::periph::flash::invalidateConfig< MainBoardConfig
                                    , FlashConfigCrcCalculator
                                    , umba::periph::flash::flash_size_256K
                                    , umba::periph::flash::page_size_2048
                                    , 0x8000000
                                    >( );
}


MainBoardConfig     config;
MainBoardLinkState  mainBoardLinkState;
bool configGood = false;


//-----------------------------------------------------------------------------
// Конфигурация ганджубуса
uint8_t     thisBoardGanjubusAddr = 0x1;
/*
static milliganjubus::SlaveSession slaveSession;

bool writeConfigResult = false;
bool ganjubusAddrDetectionDetected = false;
*/
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Тип таблицы регистров, таблица регистров, и safe proxy для ro/rw
typedef milliganjubus::SimpleRegTable< regs::Televertex2::ro::min, regs::Televertex2::ro::max, 
                                       regs::Televertex2::rw::min, regs::Televertex2::rw::max >
                             RawRegTableMain;

RawRegTableMain     rawRegTableMain;
rdlc::RegTableSafe< RawRegTableMain, regs::Televertex2::ro::meta > roRegsMain( &rawRegTableMain );
rdlc::RegTableSafe< RawRegTableMain, regs::Televertex2::rw::meta > rwRegsMain( &rawRegTableMain );

static milliganjubus::SlaveSession slaveSession;

//-----------------------------------------------------------------------------

static milliganjubus::Synchronizer  synchronizerLeft  (50);
static milliganjubus::Synchronizer  synchronizerRight (50);
static milliganjubus::MasterSession masterSessionLeft ( 15 );
static milliganjubus::MasterSession masterSessionRight( 15 );


//static HotEndSlave hotEndSlave;

static Televertex2::SuckingFootLeft1    suckingFootLeft1;
static Televertex2::SuckingFootLeft2    suckingFootLeft2;
static Televertex2::SuckingFootRight1   suckingFootRight1;
static Televertex2::SuckingFootRight2   suckingFootRight2;

static Televertex2::HotEndLeft          hotEndLeft;
static Televertex2::HotEndRight         hotEndRight;

static Televertex2::JointLeft1          jointLeft1;
static Televertex2::JointLeft2          jointLeft2;
static Televertex2::JointRight1         jointRight1;
static Televertex2::JointRight2         jointRight2;





//-----------------------------------------------------------------------------
using namespace umba::omanip;
using namespace umba::periph;
using namespace regs::Televertex2;
using namespace regs::types;



//-----------------------------------------------------------------------------
#include "tvtx2v2_Main_Board_logic.h"
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
#if defined(USE_LEFT_GANJUBUS_AS_DEBUG)
auto debugUartDriver      = umba::drivers::periph::LegacyUartDriver( RS485_LEFT_LEGACY_UART
                                                                   , RS485_LEFT_UART_RX_GPIO_PIN_ADDR
                                                                   , RS485_LEFT_UART_TX_GPIO_PIN_ADDR
                                                                   , 460800
                                                                   // No pinAddrRs485
                                                                   );
#endif

auto stateIndicatorDriver = umba::drivers::periph::DeviceStateIndicator2LedsDriver( LED_ERROR_GPIO_PIN_ADDR, LED_LINK_GPIO_PIN_ADDR );

auto golemTermUartDriver  = umba::drivers::periph::LegacyUartDriver( GOLEM_TERM_LEGACY_UART
                                                                   , GOLEM_TERM_UART_RX_GPIO_PIN_ADDR
                                                                   , GOLEM_TERM_UART_TX_GPIO_PIN_ADDR
                                                                   , 115200
                                                                   // No pinAddrRs485
                                                                   );


auto golemDriver          = umba::drivers::uplinks::GolemDriver( umba::drivers::DriverAddress( umba::drivers::class_id_stream
                                                                                             , umba::periph::periphGetNo( & GOLEM_TERM_LEGACY_UART ) 
                                                                                             )
                                                               );



auto kbdTermDriver        = umba::drivers::hid::KeyboardTerminalDriver( 
                                                                        #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)
                                                                        umba::drivers::invalid_driver_address
                                                                        #else
                                                                        //umba::drivers::invalid_driver_address
                                                                        umba::drivers::DriverAddress( umba::drivers::class_id_stream
                                                                                                    , umba::periph::periphGetNo( & RS485_LEFT_LEGACY_UART ) 
                                                                                                    )
                                                                        #endif
                                                                      );

auto muxPowerDriver       = umba::drivers::periph::PowerSwitchDriver( MUX_EN_GPIO_PIN_ADDR, false );
/*
auto muxEnDriver          = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , MUX_EN_GPIO_PIN_ADDR
                                                             );
*/
auto muxDriver            = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , MUX_A1_GPIO_PIN_ADDR
                                                             , MUX_A0_GPIO_PIN_ADDR
                                                             );
/*
auto camerasEnDriver      = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , TVKO_EN_GPIO_PIN_ADDR
                                                             , CAMERA1_EN_GPIO_PIN_ADDR
                                                             , CAMERA2_EN_GPIO_PIN_ADDR
                                                             );
*/
auto tvkoPowerDriver      = umba::drivers::periph::PowerSwitchDriver( TVKO_EN_GPIO_PIN_ADDR   , false );
auto cam1PowerDriver      = umba::drivers::periph::PowerSwitchDriver( CAMERA1_EN_GPIO_PIN_ADDR, false );
auto cam2PowerDriver      = umba::drivers::periph::PowerSwitchDriver( CAMERA2_EN_GPIO_PIN_ADDR, false );

//-----------------------------------------------------------------------------







//-----------------------------------------------------------------------------
struct PredStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel4>
{
    //umba::drivers::DriverAddress escAddr = umba::drivers::DriverAddress( umba::drivers::class_id_esc, 1 );

    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning


         PT_YIELD();


         PT_END();
    }

};




auto deviceLogic = MainBoardLogic();


struct FunalStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel6>
{
    //umba::drivers::DriverAddress escAddr = umba::drivers::DriverAddress( umba::drivers::class_id_motor, 1 );
    //umba::drivers::DriverAddress timAddr = umba::drivers::DriverAddress( umba::drivers::class_id_tim_pwm, 1 );
    //uint8_t  escCtrl   = 0; // off
    //uint8_t  timCtrl   = 1;

    virtual bool run() override
    {
        using namespace regs::types;
        using namespace umba::drivers;
        using namespace umba::drivers::uplinks;

         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning

         PT_YIELD();

         //deviceLogic.timerSet( deviceLogic.timer_event_request_pressure, deviceLogic.timer_request_pressure_period ); // 10мс

         //timer.start( deviceLogic.timer_request_pressure_period/2 ); 
         //PT_WAIT_UNTIL(timer.expired());

         //deviceLogic.timerSet( deviceLogic.timer_event_requeste_esc_current, deviceLogic.timer_requeste_esc_current_period ); // 10 мс

         PT_YIELD();

         //deviceLogic.timerSet( deviceLogic.timer_event_knobs, deviceLogic.timer_knobs_period );

         PT_YIELD();

         /*
         UMBA_RTKOS_LOG<<info<<"Ganjubus Address detection: ";
         if (ganjubusAddrDetectionDetected)
         {
             UMBA_RTKOS_LOG<<good<<"used"<<normal<<endl;
             UMBA_RTKOS_LOG<<info<<"Writting configuration to flash: ";
             if (writeConfigResult)
                 UMBA_RTKOS_LOG<<good<<"Ok";
             else
                 UMBA_RTKOS_LOG<<error<<"Failed";
             UMBA_RTKOS_LOG<<normal<<endl;
         }
         else
         {
             UMBA_RTKOS_LOG<<notice<<"not used"<<normal<<endl;
             UMBA_RTKOS_LOG<<info<<"Reading device configuration from flash: ";
             if (!configGood)
             {
                 UMBA_RTKOS_LOG<<error<<"Failed"<<normal<<endl;
             }
             else
             {
                 UMBA_RTKOS_LOG<<good<<"Ok"<<normal<<endl;
             }

         }

         UMBA_RTKOS_LOG<<notice<<"Ganjubus Address: "<<good<<hex<<thisBoardGanjubusAddr<<" ("<<thisBoardGanjubusAddr<<")"<<normal<<endl;
         */

         //muxEnDriver
         // driver_address_knobs    = DriverAddress( umba::drivers::class_id_gpio  , 1 );

         //postMessageDriverValue( deviceLogic.muxEnDriverAddress    , MessageId::device_param_set, 0, (uint32_t)1 );
         //postMessageDriverValue( deviceLogic.camerasEnDriverAddress, MessageId::device_param_set, 0, (uint32_t)7 );
         

         PT_END();
    }

}; // struct FunalStarterThread


auto hwInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );
auto swInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );

auto starter0   =  umba::rtkos::StarterThreadOsInfo< umba::rtkos::OsInfoLogLevel::osSizeDetailsMore >(); 

auto starter1   =  umba::rtkos::StarterThreadHardwareInfo();

auto starter2   =  umba::rtkos::StarterThreadHardwareInitializer< decltype(hwInitDelays)>( hwInitDelays );

auto starter4   =  PredStarterThread();

auto starter5   =  umba::rtkos::StarterThreadSoftwareInitializer< decltype(swInitDelays)/*, umba::rtkos::RunLevel5*/>( swInitDelays );

auto starter6   =  FunalStarterThread();

#if 0
auto knobsDriver          = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_in_pulldown
                                                             , umba::periph::PinSpeed::low
                                                             , RANGEFINDER1_GPIO_PIN_ADDR
                                                             , RANGEFINDER2_GPIO_PIN_ADDR
                                                             , RANGEFINDER3_GPIO_PIN_ADDR
                                                             , RANGEFINDER4_GPIO_PIN_ADDR
                                                             );


auto timPwmDriver         = umba::drivers::periph::TimPwmDriver( TIM16, 1, UMBA_PINADDR_PB8 ); // TIM16_CH1 

auto adcSC     = umba::periph::traits::AdcSingleChannel( ADC2, UMBA_PINADDR_PA6, umba::periph::AdcSamplingSpeed::very_low );
auto adcDriver = umba::drivers::periph::makeAdcDriver( adcSC, scalcus::average_times_32, UMBA_PINADDR_PA6 );
#endif







int main(void)

{
/*
    GOLEM_DATA_LEGACY_UART.init( GOLEM_DATA_UART_RX_GPIO, GOLEM_DATA_UART_RX_GPIO_PIN_NO
                        , GOLEM_DATA_UART_TX_GPIO, GOLEM_DATA_UART_TX_GPIO_PIN_NO
                        , 115200 // 460800 // *3/2
                        );

    uart::uart3.init( GOLEM_TERM_UART_RX_GPIO, GOLEM_TERM_UART_RX_GPIO_PIN_NO
                        , GOLEM_TERM_UART_TX_GPIO, GOLEM_TERM_UART_TX_GPIO_PIN_NO
                        , 115200 // 460800 // *3/2
                        );

    uart::uart1.init( GPIOC, 5
                        , GPIOC, 4
                        , 115200 // 460800 // *3/2
                        );

    while(true)
    {
        //GOLEM_DATA_LEGACY_UART
        uart::uart1.sendByte(0xA5);
        //GOLEM_TERM_LEGACY_UART
        uart::uart3.sendByte(0xA5);
    }    
*/

    configGood = readConfig( config );


    if (configGood)
    {
        //thisBoardGanjubusAddr = config.ganjubusAddr;
    }


    #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)

        UMBA_RTKOS_USE_LOG_STREAM_SWD();

        RS485_LEFT_LEGACY_UART.init( RS485_LEFT_UART_RX_GPIO, RS485_LEFT_UART_RX_GPIO_PIN_NO
                          , RS485_LEFT_UART_TX_GPIO, RS485_LEFT_UART_TX_GPIO_PIN_NO
                          , 57600
                          , RS485_LEFT_LINK_DE_GPIO, 1<<RS485_LEFT_LINK_DE_GPIO_PIN_NO
                          );


    #else

        UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( RS485_LEFT_LEGACY_UART, RS485_LEFT_UART, 460800 );

    #endif

    //UMBA_RTKOS_LOG<<feed<<"------------------"<<endl;

    RS485_RIGHT_LEGACY_UART.init( RS485_RIGHT_UART_RX_GPIO, RS485_RIGHT_UART_RX_GPIO_PIN_NO
                      , RS485_RIGHT_UART_TX_GPIO, RS485_RIGHT_UART_TX_GPIO_PIN_NO
                      , 57600
                      , RS485_RIGHT_LINK_DE_GPIO, 1<<RS485_RIGHT_LINK_DE_GPIO_PIN_NO
                      );

//    GOLEM_DATA_LEGACY_UART.init( GOLEM_DATA_UART_RX_GPIO, GOLEM_DATA_UART_RX_GPIO_PIN_NO
//                        , GOLEM_DATA_UART_TX_GPIO, GOLEM_DATA_UART_TX_GPIO_PIN_NO
//                        , 115200 // 460800 //*3/2
//                        );
    uart::uart1.init( GPIOC, 5
                        , GPIOC, 4
                        , 115200 // 460800 //*3/2
                        );

    TVKO_LEGACY_UART.init( TVKO_UART_RX_GPIO, TVKO_UART_RX_GPIO_PIN_NO
                        , TVKO_UART_TX_GPIO, TVKO_UART_TX_GPIO_PIN_NO
                        , 57600 // 460800 //*3/2
                        );


    constexpr auto ro_regs_update_interval_ms = 50;

    suckingFootLeft1 .init( rawRegTableMain, 0x10, ro_regs_update_interval_ms );
    suckingFootLeft2 .init( rawRegTableMain, 0x11, ro_regs_update_interval_ms );
    suckingFootRight1.init( rawRegTableMain, 0x10, ro_regs_update_interval_ms );
    suckingFootRight2.init( rawRegTableMain, 0x11, ro_regs_update_interval_ms );

    hotEndLeft       .init( rawRegTableMain, 0x20, ro_regs_update_interval_ms );
    hotEndRight      .init( rawRegTableMain, 0x20, ro_regs_update_interval_ms );
                     
    jointLeft1       .init( rawRegTableMain, 0x01, ro_regs_update_interval_ms );
    jointLeft2       .init( rawRegTableMain, 0x02, ro_regs_update_interval_ms );
    jointRight1      .init( rawRegTableMain, 0x03, ro_regs_update_interval_ms );
    jointRight2      .init( rawRegTableMain, 0x04, ro_regs_update_interval_ms );

    synchronizerLeft .addSlave( suckingFootLeft1 );
    synchronizerLeft .addSlave( suckingFootLeft2 );
    synchronizerLeft .addSlave( hotEndLeft       );
    synchronizerLeft .addSlave( jointLeft1       );
    synchronizerLeft .addSlave( jointLeft2       );

    synchronizerRight.addSlave( suckingFootRight1);
    synchronizerRight.addSlave( suckingFootRight2);
    synchronizerRight.addSlave( hotEndRight      );
    synchronizerRight.addSlave( jointRight1      );
    synchronizerRight.addSlave( jointRight2      );

    {
        auto onValidAnswerReceived = CALLBACK_BIND( synchronizerLeft, milliganjubus::Synchronizer::onRelevantAnswerReceived );
        auto onIrrelevantAnswerReceived = CALLBACK_BIND( synchronizerLeft, milliganjubus::Synchronizer::ignoreIrrelevantAnswer );
        auto onConnectionFailure = CALLBACK_BIND( synchronizerLeft, milliganjubus::Synchronizer::onConnectionFailure );

        #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)

            masterSessionLeft.init( RS485_LEFT_LEGACY_UART, onValidAnswerReceived, onConnectionFailure, onIrrelevantAnswerReceived);
            milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( masterSessionLeft, milliganjubus::MasterSession::sendRequest );
            synchronizerLeft.init(sendRequest);

        #endif
    }

    {
        auto onValidAnswerReceived = CALLBACK_BIND( synchronizerRight, milliganjubus::Synchronizer::onRelevantAnswerReceived );
        auto onIrrelevantAnswerReceived = CALLBACK_BIND( synchronizerRight, milliganjubus::Synchronizer::ignoreIrrelevantAnswer );
        auto onConnectionFailure = CALLBACK_BIND( synchronizerRight, milliganjubus::Synchronizer::onConnectionFailure );

        masterSessionRight.init( RS485_RIGHT_LEGACY_UART, onValidAnswerReceived, onConnectionFailure, onIrrelevantAnswerReceived);
        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( masterSessionRight, milliganjubus::MasterSession::sendRequest );
        synchronizerRight.init(sendRequest);
    }
                     
    
    static callback::Callback<void ( void )> linkLostCallback    ( []() { deviceLogic.onGanjubusLinkLost();     } );
    static callback::Callback<void ( void )> linkRestoredCallback( []() { deviceLogic.onGanjubusLinkRestored(); } );
    static callback::Callback<void ( void )> dataReceivedCallback( []() { deviceLogic.onGanjubusDataReceived(); } );

    
    slaveSession.init( uart::uart1 // GOLEM_DATA_LEGACY_UART
                     , thisBoardGanjubusAddr
                     , rawRegTableMain
                     , linkLostCallback
                     , linkRestoredCallback
                     , 5000 // lost link timeout
                     , dataReceivedCallback );         // коллбэки


    roRegsMain[ro::robot_id_u8] = thisBoardGanjubusAddr;


    /*
    Полировать так
    auto tickNow = umba::time_service::getCurTimeMs();
    slaveSession.work( tickNow );
    masterSessionRight.work( tickNow );
    masterSessionLeft.work( tickNow );
    */



    #if defined(USE_LEFT_GANJUBUS_AS_DEBUG)
        UMBA_DRIVER_CHECKED_INSTALL( debugUartDriver, umba::drivers::driver_id_device_number );
        //debugUartDriver.install( umba::drivers::driver_id_device_number );
    #endif

    UMBA_DRIVER_CHECKED_INSTALL(stateIndicatorDriver);

    UMBA_DRIVER_CHECKED_INSTALL( golemTermUartDriver, umba::drivers::driver_id_device_number );
    UMBA_DRIVER_CHECKED_INSTALL( golemDriver );

    UMBA_DRIVER_CHECKED_INSTALL( muxPowerDriver  );
    UMBA_DRIVER_CHECKED_INSTALL( tvkoPowerDriver );
    UMBA_DRIVER_CHECKED_INSTALL( cam1PowerDriver );
    UMBA_DRIVER_CHECKED_INSTALL( cam2PowerDriver );

    //UMBA_DRIVER_CHECKED_INSTALL( muxEnDriver     );
    UMBA_DRIVER_CHECKED_INSTALL( muxDriver       );
    ///UMBA_DRIVER_CHECKED_INSTALL( camerasEnDriver );
    

    UMBA_DRIVER_CHECKED_INSTALL(kbdTermDriver);
    //kbdTermDriver  .install();

/*
    kbdTermDriver  .install();
    i2c            .install();
    psensor        .install();
    adcDriver      .install();
    timPwmDriver   .install();
    escDriver      .install();
    knobsDriver    .install();
*/

    deviceLogic.golemDriverAddress            = golemDriver          .getAssignedAddress();
    //deviceLogic.muxEnDriverAddress            = muxEnDriver    .getAssignedAddress();
    deviceLogic.muxDriverAddress              = muxDriver            .getAssignedAddress();
    //deviceLogic.camerasEnDriverAddress = camerasEnDriver.getAssignedAddress();
    deviceLogic.stateIndicatorDriverAddress   = stateIndicatorDriver .getAssignedAddress();
                                                

    UMBA_DRIVER_CHECKED_INSTALL(deviceLogic);
    //deviceLogic    .install();


    umba::rtkos::pollScheduleAdd( &starter0 );
    umba::rtkos::pollScheduleAdd( &starter1 );
    umba::rtkos::pollScheduleAdd( &starter2 );
    umba::rtkos::pollScheduleAdd( &starter4 );
    umba::rtkos::pollScheduleAdd( &starter5 );
    umba::rtkos::pollScheduleAdd( &starter6 );


    return UMBA_RTKOS_OS->run( umba::rtkos::RunLevel6 );

}





