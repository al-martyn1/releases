#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

extern umba::SimpleFormatter  lout;


#include "periph/stm32_exti.cpp"
#include "periph/stm32_spi.cpp"
#include "periph/stm32_dma.cpp"


