#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "periph/gpio.h"
#include "periph/power.h"

#include "vtx2_master.h"

// Compiler Command-line Options - http://www.keil.com/support/man/docs/armcc/armcc_chr1359124898004.htm
// -E - Executes the preprocessor step only - http://www.keil.com/support/man/docs/armcc/armcc_chr1359124916428.htm
// -C - Instructs the compiler to retain comments in preprocessor output.
//      Choosing this option implicitly selects the option -E
//      http://www.keil.com/support/man/docs/armcc/armcc_chr1360245894926.htm


//-----------------------------------------------------------------------------
#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )

//using namespace umba::periph;

DECLARE_PIN( pinPower5V           , POWER_5V_EN );
// umba::periph::GpioPin pinPower5V( { GPIOA, 4 }, umba::periph::PinMode::gpio_out_pp );


DECLARE_PIN( pinFrontCamPwr       , VIDEO1_FRONT_CAM_PWR_EN );
DECLARE_PIN( pinHotEndCamPwr      , VIDEO2_HOTEND_CAM_PWR_EN );
DECLARE_PIN( pinBackCamPwr        , VIDEO4_BACK_CAM_PWR_EN );
                                  
DECLARE_PIN( pinMuxEn             , MUX_EN );
DECLARE_PIN( pinMuxA0             , MUX_A0 );
DECLARE_PIN( pinMuxA1             , MUX_A1 );
                                  
DECLARE_PIN( pinFrontCamEn        , VIDEO1_FRONT_CAM_EN  );
DECLARE_PIN( pinHotEndCamEn       , VIDEO2_HOTEND_CAM_EN );
DECLARE_PIN( pinTvkoCamEn         , VIDEO3_TVKO_CAM_EN   );
DECLARE_PIN( pinBackCamEn         , VIDEO4_BACK_CAM_EN   );

DECLARE_PIN( pinBatteryPresentFlag, BATTERY_PRESENT_FLAG );


//-----------------------------------------------------------------------------
umba::periph::
GpioPin* camPinsPwr[] = { &pinFrontCamPwr 
                        , &pinHotEndCamPwr
                        , 0
                        , &pinBackCamPwr  
                        };

umba::periph::
GpioPin* camPinsEn[]  = { &pinFrontCamEn 
                        , &pinHotEndCamEn
                        , &pinTvkoCamEn  
                        , &pinBackCamEn  
                        };

umba::periph::
GpioPin* camPinsMux[] = { &pinMuxEn
                        , &pinMuxA0
                        , &pinMuxA1
                        };
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );

#endif

umba::SimpleFormatter  lout(&charWritter);


//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------

inline
void camControl( unsigned camChannel // 1-4
               , umba::periph::GpioPin** pPinsMux
               , umba::periph::GpioPin** pPinsPwr
               , umba::periph::GpioPin** pPinsEn
               , bool alwaysPwr = true
               , bool alwaysEn  = true
               )
{
    using namespace umba::periph;

    UMBA_ASSERT( camChannel>=1 && camChannel<=4 );
    --camChannel;

    umba::periph::GpioPin* pChannelPinPwr = pPinsPwr[camChannel];
    umba::periph::GpioPin* pChannelPinEn  = pPinsEn[camChannel];

    // мы ничего не предполагаем о предыдущем состоянии alwaysPwr и alwaysEn

    // pwrCtrl
    for(size_t i=0; i!=4; ++i)
    {
        umba::periph::GpioPin* pPin = pPinsPwr[i];
        if (!pPin)
            continue;

        if (alwaysPwr)
            *pPin = true;
        else if (pPin==pChannelPinPwr)
            *pPin = true;
        else
            *pPin = false;
    }

    // enCtrl
    for(size_t i=0; i!=4; ++i)
    {
        umba::periph::GpioPin* pPin = pPinsEn[i];
        if (!pPin)
            continue;

        if (alwaysPwr)
            *pPin = true;
        else if (pPin==pChannelPinEn)
            *pPin = true;
        else
            *pPin = false;
    }

    *pPinsMux[0] = true; // enable mux

    *pPinsMux[1] = ( camChannel    &1) ? true : false;
    *pPinsMux[2] = ((camChannel>>1)&1) ? true : false;
}

//-----------------------------------------------------------------------------


inline
void printMenu( unsigned curChannel
              , bool alwaysPwr
              , bool alwaysEn
              )
{
    using namespace umba::omanip;

    lout<<feed;
    lout<<flush;
    lout<<wflush;

    lout<<"\n\n\n\n\n";
    lout<<"Channel #: "<<curChannel<<"\n";
    lout<<"Power    : "<< (alwaysPwr ? "Always On" : "Auto") <<"\n";
    lout<<"Ch Enable: "<< (alwaysEn ? "Always On" : "Auto") <<"\n";

    lout<<"\n\n";
    lout<<"1 - Cam 1\n";
    lout<<"2 - Cam 2\n";
    lout<<"3 - Cam 3\n";
    lout<<"4 - Cam 4\n";
    lout<<"\n";
    lout<<"9 - Toggle 'Power always On'\n";
    lout<<"0 - Toggle 'Enable always On'\n";
    lout<<flush;
    lout<<wflush;
}





//-----------------------------------------------------------------------------
int main(void)
{
    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::periph;
    using namespace umba::omanip;


    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );

    lout<<"Starting\n";

    
    GpioPin* pwrPins[] = { &pinPower5V     
                         , &pinFrontCamPwr 
                         , &pinHotEndCamPwr
                         , &pinBackCamPwr  
                         };

    initPowerPins( 100 /* 100 ms delay */, &pwrPins[0], sizeof(pwrPins) / sizeof(pwrPins[0]) );

    gpioPinsConnect( &camPinsPwr[0], 4 );
    gpioPinsConnect( &camPinsEn[0], 4 );
    gpioPinsConnect( &camPinsMux[0], 3 );

    pinBatteryPresentFlag.connect();


    unsigned curChannel = 1; // 1-4
    bool alwaysPwr = true;
    bool alwaysEn  = true;


    // Video_Channel

    lout<<"Started\n";
    umba::time_service::delayMs(1000);

    camControl( curChannel, &camPinsMux[0], &camPinsPwr[0], &camPinsEn[0], alwaysPwr, alwaysEn );

    printMenu( curChannel, alwaysPwr, alwaysEn );
   

    auto kbdHandler = umba::periph::makeKeyboardHandler
                    ( 
                         [&]( unsigned vkc, bool fPressed, size_t repeatCout )
                         {
                             using namespace umba::omanip;
                             if (!fPressed || repeatCout>1)
                                 return;

                             unsigned newChannel = curChannel;
                             bool bUpdate = false;
                             if (vkc>='1' && vkc<='4')
                             {
                                 newChannel = (unsigned)(vkc - '0');
                                 if (newChannel!=curChannel)
                                 {
                                     curChannel = newChannel;
                                     bUpdate = true;
                                 }
                             }
                             else if (vkc=='9')
                             {
                                 alwaysPwr = !alwaysPwr;
                                 bUpdate = true;
                             }
                             else if (vkc=='0')
                             {
                                 alwaysEn = !alwaysEn;
                                 bUpdate = true;
                             }
                             else if (vkc==umba::periph::VirtualKeyCode::escape)
                             {
                                 printMenu( curChannel, alwaysPwr, alwaysEn );
                             }

                             if (bUpdate)
                             {
                                 lout<<"\n\n\n\n\nnewChannel: "<<newChannel<<"\n";
                                 lout<<"Switching to: "<<curChannel<<"\n";
                                 camControl( curChannel, &camPinsMux[0], &camPinsPwr[0], &camPinsEn[0], alwaysPwr, alwaysEn );
                                 printMenu( curChannel, alwaysPwr, alwaysEn );
                             }
                         }
                    );

    umba::periph::legacy::UartTerminalKeyboard kbd = umba::periph::legacy::UartTerminalKeyboard( &kbdHandler, &DEBUG_TERMINAL_LEGACY_UART );


    while(1)
    {
        kbd.scanKeyboard();
    }

}

