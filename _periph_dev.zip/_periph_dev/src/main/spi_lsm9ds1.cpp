/*
    LSM9DS1 SPI2
    A/G reading sample/test

    Clock - normal low
    CS    - normal high

    SPI Note: Freq over 5MHz is too dirty
    F1, F3 at 72 MHz - use prescalers not less than 8
    F4 at 168 MHz - use prescalers not less than 32


    F4 Discovery Note:
    PD13 - LD3: orange LED is a user LED connected to the I/O PD13 of the STM32F407VGT6.
    PD12 - LD4: green LED is a user LED connected to the I/O PD12 of the STM32F407VGT6.
    PD14 - LD5: red LED is a user LED connected to the I/O PD14 of the STM32F407VGT6.
    PD15 - LD6: blue LED is a user LED connected to the I/O PD15 of the STM32F407VGT6.
    PA9  - USB LD7: green LED indicates when VBUS is present on CN5 and is connected to PA9 of the STM32F407VGT6.
    PD5  - USB LD8: red LED indicates an overcurrent from VBUS of CN5 and is connected to the I/O PD5 of the STM32F407VGT6.


*/

#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"

#include "lsm9ds1.h"


//#define DISABLE_LOOP_OUTPUT
#define CHECK_ID_IN_LOOP




#if defined(STM32F1_SERIES)
    const char *stmFamily = "STM32F103";
#elif defined(STM32F3_SERIES)
    const char *stmFamily = "STM32F303";
#elif defined(STM32F4_SERIES)
    const char *stmFamily = "STM32F407";
#endif



// Good for F103/F303 Discovery boards
#define LSM9DS1_SPI                           SPI2
#define LSM9DS1_SPI_SCK_GPIO_PIN_ADDR         PB13
#define LSM9DS1_SPI_MISO_GPIO_PIN_ADDR        PB14
#define LSM9DS1_SPI_MOSI_GPIO_PIN_ADDR        PB15

#if defined(STM32F1_SERIES)

    #define LSM9DS1_SPI_CS_M_GPIO_PIN_ADDR_DIR    PB10
    #define LSM9DS1_SPI_CS_AG_GPIO_PIN_ADDR_DIR   PB11

#elif defined(STM32F3_SERIES) 

    #define LSM9DS1_SPI_CS_M_GPIO_PIN_ADDR_DIR    PD9
    #define LSM9DS1_SPI_CS_AG_GPIO_PIN_ADDR_DIR   PD11

#elif defined(STM32F4_SERIES)

    #define LSM9DS1_SPI_CS_AG_GPIO_PIN_ADDR_DIR   PD9
    #define LSM9DS1_SPI_CS_M_GPIO_PIN_ADDR_DIR    PD11

#endif


//#define USE_LEGACY_SPI_INIT

#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )



// Прикопаю - настройка частоты - http://easyelectronics.ru/arm-uchebnyj-kurs-taktovyj-generator-stm32.html

void spiInit();

//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::LegacyUartCharWriter<255>   charWritter = umba::LegacyUartCharWriter<255>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);


DECLARE_PIN( lsmCsM_Pin , LSM9DS1_SPI_CS_M  );  // PD9
DECLARE_PIN( lsmCsAG_Pin, LSM9DS1_SPI_CS_AG ); // PD11

//static void* spi2Addr = (void*)MAX6954_SPI;

static volatile uint32_t hseVal   = 0;
static volatile uint32_t coreClk  = 0;
static volatile uint32_t sysClk   = 0;
static volatile uint32_t ahbClk   = 0;
static volatile uint32_t apb1Clk  = 0;
static volatile uint32_t apb2Clk  = 0;
static volatile uint32_t spiFreq  = 0;




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::time_service;
    using namespace umba::periph::traits;
    using namespace umba::omanip;

    //hseVal = HSE_VALUE;
    //sysClk = SystemCoreClock;
    hseVal  = clockGetFreq(ClockBus::OSCCLK);
    coreClk = clockGetFreq(ClockBus::CORECLK);
    sysClk  = clockGetFreq(ClockBus::SYSCLK);
    ahbClk  = clockGetFreq(ClockBus::AHB);
    apb1Clk = clockGetFreq(ClockBus::APB1);
    apb2Clk = clockGetFreq(ClockBus::APB2); 


    #if defined(STM32F1_SERIES)
        uart::uart1.init( GPIOA, 10, GPIOA, 9, 460800 );
    #elif defined(STM32F3_SERIES)
        uart::uart1.init( GPIOC,  5, GPIOC, 4, 460800 );
    #elif defined(STM32F4_SERIES)
        uart::uart1.init( GPIOB,  7, GPIOB, 6, 460800 );
    #endif


    spiInit();
    
    spiFreq = spiGetFreq( LSM9DS1_SPI );


    delayMs(100);


    lout<<"-------------\n";
    lout<<"Hello "<<width(8)<<left<<stmFamily<<endl;
    lout<<"HSE : "<<width(8)<<left<<hseVal <<" Hz\n";
    lout<<"CORE: "<<width(8)<<left<<coreClk<<" Hz\n";
    lout<<"SYS : "<<width(8)<<left<<sysClk <<" Hz\n";
    lout<<"AHB : "<<width(8)<<left<<ahbClk <<" Hz\n";
    lout<<"APB1: "<<width(8)<<left<<apb1Clk<<" Hz\n";
    lout<<"APB2: "<<width(8)<<left<<apb2Clk<<" Hz\n";
    lout<<"SPI : "<<width(8)<<left<<spiFreq<<" Hz\n";
    lout<<"-------------"<<endl;

    umba::hr_counter::NanosecInterval spiCsAfterPause = umba::hr_counter::microsec(20);

    // 0x68 (0110 1000) Accelerometer and gyroscope Who I am ID
    uint16_t whoIsThat = umba::periph::traits::spiRead( LSM9DS1_SPI, (uint16_t)(lsm9ds1::CMD_READ | (lsm9ds1::WHO_AM_I_XG<<8)), lsmCsAG_Pin, spiCsAfterPause, spiDoWaitNotBusy ) & 0xFF;
    lout<<"A/G ID: "<<hex<<width(2)<<whoIsThat<<"\n";
    if (whoIsThat!=lsm9ds1::WHO_AM_I_AG_RSP)
        lout<<error<<"Unknown ID"<<normal<<endl;

    // 0x3D (0011 1101) Magnetic Who I am ID
    whoIsThat = umba::periph::traits::spiRead( LSM9DS1_SPI, (uint16_t)(lsm9ds1::CMD_READ | (lsm9ds1::WHO_AM_I_M<<8)), lsmCsM_Pin, spiCsAfterPause, spiDoWaitNotBusy ) & 0xFF;
    lout<<"M ID : "<<hex<<width(2)<<whoIsThat<<"\n";
    if (whoIsThat!=lsm9ds1::WHO_AM_I_M_RSP)
        lout<<error<<"Unknown ID"<<normal<<endl;

    // https://github.com/sparkfun/SparkFun_LSM9DS1_Arduino_Library/blob/master/examples/LSM9DS1_Settings/LSM9DS1_Settings.ino
    /*
    imu.settings.gyro.enabled = true;  // Enable the gyro
	imu.settings.gyro.enableX = true;
	imu.settings.gyro.enableY = true;
	imu.settings.gyro.enableZ = true;
    imu.settings.gyro.scale = 245; // Set scale to +/-245dps
    imu.settings.gyro.sampleRate = 3; // 59.5Hz ODR
    imu.settings.gyro.bandwidth = 0;
    imu.settings.gyro.lowPowerEnable = false; // LP mode off
    imu.settings.gyro.HPFEnable = true; // HPF disabled
    imu.settings.gyro.HPFCutoff = 1; // HPF cutoff = 4Hz
    imu.settings.gyro.flipX = false; // Don't flip X
    imu.settings.gyro.flipY = false; // Don't flip Y
    imu.settings.gyro.flipZ = false; // Don't flip Z
    */

    // CTRL_REG1_G (10h) Angular rate sensor Control Register 1                                 
    // ODR_G [2:0] Gyroscope output data rate selection. Default value: 000 (Refer to Table 46 and Table 47)
    // FS_G [1:0] Gyroscope full-scale selection. Default value: 00         (00: 245 dps; 01: 500 dps; 10: Not Available; 11: 2000 dps)
    // BW_G [1:0] Gyroscope bandwidth selection. Default value: 00

    // ODR   0x03 (011) - 119Hz
    //       0x06 (110) - 952Hz
    // FS_G  01: 500 dps
    // BW    3 400 Hz banwidth
    //

    double gRes = ((double) 500 ) / 32768.0;

    spiWrite( LSM9DS1_SPI, lsm9ds1::CMD_WRITE | (lsm9ds1::CTRL_REG1_G << 8) | ( ((uint16_t)lsm9ds1::XL_ODR_119) << 5) | ( ((uint16_t)lsm9ds1::G_SCALE_500DPS) << 3 ) | ((uint16_t)lsm9ds1::G_BANDWIDTH_400HZ), lsmCsAG_Pin, spiCsAfterPause, spiDoWaitNotBusy );

    spiWrite( LSM9DS1_SPI, lsm9ds1::CMD_WRITE | lsm9ds1::CTRL_REG2_G << 8, lsmCsAG_Pin, spiCsAfterPause, spiDoWaitNotBusy );

    // cutoff - 3 and HP en bit (6)
    spiWrite( LSM9DS1_SPI, lsm9ds1::CMD_WRITE | (lsm9ds1::CTRL_REG3_G << 8) | 0x43, lsmCsAG_Pin, spiCsAfterPause, spiDoWaitNotBusy );

    // Gyro XYZ enable, no flip axis
    spiWrite( LSM9DS1_SPI, lsm9ds1::CMD_WRITE | (lsm9ds1::CTRL_REG4   << 8) | 0x38, lsmCsAG_Pin, spiCsAfterPause, spiDoWaitNotBusy );


    /*
    imu.settings.accel.enabled = true; // Enable accelerometer
    imu.settings.accel.enableX = true; // Enable X
    imu.settings.accel.enableY = true; // Enable Y
    imu.settings.accel.enableZ = true; // Enable Z
    imu.settings.accel.scale = 8; // Set accel scale to +/-8g.
    imu.settings.accel.sampleRate = 1; // Set accel to 10Hz.
    imu.settings.accel.bandwidth = 0; // BW = 408Hz
    imu.settings.accel.highResEnable = false; // Disable HR
    imu.settings.accel.highResBandwidth = 0;  
    */

    /*
    imu.settings.mag.enabled = true; // Enable magnetometer
    imu.settings.mag.scale = 12; // Set mag scale to +/-12 Gs
    imu.settings.mag.sampleRate = 5; // Set OD rate to 20Hz
    imu.settings.mag.tempCompensationEnable = false;
    imu.settings.mag.XYPerformance = 3; // Ultra-high perform.
    imu.settings.mag.ZPerformance = 3; // Ultra-high perform.
    imu.settings.mag.lowPowerEnable = false;
    imu.settings.mag.operatingMode = 0; // Continuous mode    
    */

    /*
    imu.settings.temp.enabled = true;
    */

    unsigned globalCounter = 0;


    while(true)
    {


        // http://easyelectronics.ru/arm-uchebnyj-kurs-taktovyj-generator-stm32.html

/*
#define LSM9DS1_SPI                           SPI2
#define LSM9DS1_SPI_SCK_GPIO_PIN_ADDR         PB13
#define LSM9DS1_SPI_MISO_GPIO_PIN_ADDR        PB14
#define LSM9DS1_SPI_MOSI_GPIO_PIN_ADDR        PB15

#define LSM9DS1_SPI_CS_M_GPIO_PIN_ADDR_DIR    PD9
#define LSM9DS1_SPI_CS_AG_GPIO_PIN_ADDR_DIR   PD11

*/
            uint16_t agReg8 = 
            umba::periph::traits::spiRead ( LSM9DS1_SPI, lsm9ds1::CMD_READ | lsm9ds1::CTRL_REG8<<8, lsmCsAG_Pin, spiCsAfterPause, spiDoWaitNotBusy );
            agReg8 &= 0xFF;
            agReg8 |= lsm9ds1::IF_ADD_INC;
            umba::periph::traits::spiWrite( LSM9DS1_SPI, lsm9ds1::CMD_WRITE | lsm9ds1::CTRL_REG8<<8 | agReg8, lsmCsAG_Pin, spiCsAfterPause, spiDoWaitNotBusy );
            
            uint16_t gyroData[4] = { 0 };
            
            size_t i = 0;
            
            spiReadStart( LSM9DS1_SPI, lsm9ds1::CMD_READ | lsm9ds1::STATUS_REG_0<<8, &lsmCsAG_Pin );
            
            do
            {
                spiWaitReceiveComplete( LSM9DS1_SPI );
                spiWaitNotBusy( LSM9DS1_SPI, spiDoWaitNotBusy );
                gyroData[i] = spiReadGetValue( LSM9DS1_SPI );
                ++i;
                if (i==4)
                    break;
            
                spiWriteSetValue( LSM9DS1_SPI, 0x0000 ); // write dummy data to make more clocks
            
            } while( i!=4 );
            
            lsmCsAG_Pin.toggle();
            
            uint16_t &gyroStatus = gyroData[0];
            int16_t  &gyroX      = *(int16_t*)&gyroData[1];
            int16_t  &gyroY      = *(int16_t*)&gyroData[2];
            int16_t  &gyroZ      = *(int16_t*)&gyroData[3];

            //gRes
            
            
            #ifndef DISABLE_LOOP_OUTPUT
            lout<<width(6)<<globalCounter<<"   "<<"Status: "<<bin<<width(10)<<(uint8_t)(gyroStatus&0xFF)<<" - ";
            
            lout<<"X: "<<width(8)<<gRes*(double)gyroX<<", "
                <<"Y: "<<width(8)<<gRes*(double)gyroY<<", "
                <<"Z: "<<width(8)<<gRes*(double)gyroZ<<endl;
            
            //lout<<"Loop "<<stmFamily<<endl;
            #endif

            ++globalCounter;
            
            delayMs(200);

            // CHECK_ID_IN_LOOP
            #if 0

                uint16_t whoIsThat = umba::periph::traits::spiRead( LSM9DS1_SPI, lsm9ds1::CMD_READ | (lsm9ds1::WHO_AM_I_XG<<8), lsmCsAG_Pin, spiDoWaitNotBusy ) & 0xFF;
                whoIsThat = umba::periph::traits::spiRead( LSM9DS1_SPI, lsm9ds1::CMD_READ | (lsm9ds1::WHO_AM_I_M<<8), lsmCsM_Pin , spiDoWaitNotBusy ) & 0xFF;

                delayMs(200);

            #endif

    }

}






void spiInit()
{

    // SPI hints
    // 8/16 - https://diymcblog.blogspot.com/2018/03/spi-stm32-2.html
    // Статусы - http://www.cyberforum.ru/arm/thread2091007.html
    // Полезная инфа - https://microtechnics.ru/stm32-s-nulya-interfejs-spi/
    //   Важное дополнение – инициализация GPIO должна происходить после инициализации SPI, иначе могут возникнуть сбои в работе Slave.

    using namespace umba::periph::traits;

    SpiPrescaler psc100   = spiCalcPrescaler( LSM9DS1_SPI,   100000 );
    SpiPrescaler psc150   = spiCalcPrescaler( LSM9DS1_SPI,   150000 );
    SpiPrescaler psc200   = spiCalcPrescaler( LSM9DS1_SPI,   200000 );
    SpiPrescaler psc250   = spiCalcPrescaler( LSM9DS1_SPI,   250000 );
    SpiPrescaler psc500   = spiCalcPrescaler( LSM9DS1_SPI,   500000 );
    SpiPrescaler psc1000  = spiCalcPrescaler( LSM9DS1_SPI,  1000000 );
    SpiPrescaler psc2000  = spiCalcPrescaler( LSM9DS1_SPI,  2000000 );
    SpiPrescaler psc3000  = spiCalcPrescaler( LSM9DS1_SPI,  3000000 );
    SpiPrescaler psc4000  = spiCalcPrescaler( LSM9DS1_SPI,  4000000 );
    SpiPrescaler psc5000  = spiCalcPrescaler( LSM9DS1_SPI,  5000000 );
    SpiPrescaler psc10000 = spiCalcPrescaler( LSM9DS1_SPI, 10000000 );
    SpiPrescaler psc15000 = spiCalcPrescaler( LSM9DS1_SPI, 15000000 );
    SpiPrescaler psc20000 = spiCalcPrescaler( LSM9DS1_SPI, 20000000 );

    periphInit( LSM9DS1_SPI                      
              , LSM9DS1_SPI_SCK_GPIO_PIN_ADDR    
              , LSM9DS1_SPI_MISO_GPIO_PIN_ADDR   
              , LSM9DS1_SPI_MOSI_GPIO_PIN_ADDR   
              , umba::periph::traits::spiDataBits16
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              , spiCalcPrescaler( LSM9DS1_SPI,   1000000 )
              //, umba::periph::traits::spiPrescaler256
              , PinSpeed::high // PinSpeed::low
              );

    lsmCsM_Pin  = true;
    lsmCsAG_Pin = true;


/*
    CPOL_CPHA   - clk - инверсный, данные - прямой
    nCPOL_CPHA  - Оба сигнала нормальная логика
    CPOL_nCPHA  - Оба сигнала инверсная логика
    nCPOL_nCPHA - clk - прямой, дата инверсная

    PinSpeed::low
    PinSpeed::medium
    PinSpeed::fast
    PinSpeed::high

*/

}

