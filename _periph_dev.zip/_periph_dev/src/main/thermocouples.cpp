#include "thermocouples.h"

namespace temp_control
{
    void defaultWait( void )
    {}
    void defaultDelay( void )
    {
        for( volatile uint8_t i = 0; i < 50; i++ )
        {
            ;
        }
    }
   
    
    void Thermocouples::work(  )
    {   
        for( uint8_t i = 0; i < 2; i++ )
        {
            uint32_t data = sendSpiData( i );
            
            m_externalTemp[i] = (float)( ( data & 0x7ffc0000 ) >> 18 ) / 4.f;
            if( data & (1 << 31) )
            {
                m_externalTemp[i] = -m_externalTemp[i];
            }        
            
            m_internalTemp[i] = (float)( ( data & 0x00007ff0 ) >> 4 ) / 16.f;
            if( data & (1 << 15) )
            {
                m_internalTemp[i] = -m_internalTemp[i];
            }        
            
            m_fault[i] = data & ( 1 << 16 );
            
            m_scv[i] = data & ( 1 << 2 );
            m_scg[i] = data & ( 1 << 1 );
            m_oc[i]  = data & ( 1 << 0 );
        }
    }

    uint32_t Thermocouples::sendSpiData( uint8_t num )
    {
        if( num == 0 )
        {
            GPIO_ResetBits( cs_port, cs_1_pin );
        }
        else if( num == 1 )        
        {
            GPIO_ResetBits( cs_port, cs_2_pin );
        }
        else
        {
            UMBA_ASSERT_FAIL();
        }
        //m_delayer();
        // кинуть байт
        SPI_I2S_SendData(SPI1, 0xffff);

        // ждем, пока байт уйдет
        while(! (SPI1->SR & SPI_I2S_FLAG_TXE) )
        {
            //m_waiter();
        }

        // ждем ответа
        while(! (SPI1->SR & SPI_I2S_FLAG_RXNE) )
        {
            //m_waiter();
        }
        while( SPI1->SR & SPI_I2S_FLAG_BSY )
        {
            //m_waiter();
        }

        // гарантируем чтение
        uint32_t dummy = SPI_I2S_ReceiveData(SPI1) << 16;
        
        // кинуть байт
        SPI_I2S_SendData(SPI1, 0xffff);

        // ждем, пока байт уйдет
        while(! (SPI1->SR & SPI_I2S_FLAG_TXE) )
        {
            //m_waiter();
        }

        // ждем ответа
        while(! (SPI1->SR & SPI_I2S_FLAG_RXNE) )
        {
            //m_waiter();
        }
        while( SPI1->SR & SPI_I2S_FLAG_BSY )
        {
            //m_waiter();
        }

        // гарантируем чтение
        dummy |= SPI_I2S_ReceiveData(SPI1);
        
        if( num == 0 )
        {
            GPIO_SetBits( cs_port, cs_1_pin );
        }
        else if( num == 1 )        
        {
            GPIO_SetBits( cs_port, cs_2_pin );
        }
        else
        {
            UMBA_ASSERT_FAIL();
        }

        return dummy;
    }
    
    void Thermocouples:: initPin()
    {
        umba::periph::traits::initPeriphClock( HOTEND1_TERMCPL_CS_GPIO, ENABLE );
        umba::periph::traits::initPeriphClock( HOTEND_TERMCPL_SPI_SCK_GPIO, ENABLE );
        umba::periph::traits::initPeriphClock( HOTEND_TERMCPL_SPI_MISO_GPIO, ENABLE );

        //RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE );
        GPIO_InitTypeDef GPIO_InitStructure;
        
        GPIO_StructInit( &GPIO_InitStructure );

        //GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init( GPIOA, &GPIO_InitStructure );


        GPIO_InitStructure.GPIO_Pin = cs_1_pin | cs_2_pin;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;

        GPIO_Init( cs_port, &GPIO_InitStructure );

        
    }
    

    void Thermocouples::initSpi()
    {
        umba::periph::traits::initPeriphClock();
        //RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);

        SPI_InitTypeDef SPI_InitStructure;

        SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
        SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
        SPI_InitStructure.SPI_DataSize = SPI_DataSize_16b;
        SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
        SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
        SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
        SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_256;// максимум 1 МГц
        SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
        SPI_InitStructure.SPI_CRCPolynomial = 7; // not used
        SPI_Init(SPI1, &SPI_InitStructure);

        SPI_CalculateCRC(SPI1, DISABLE);

        SPI_Cmd(SPI1, ENABLE);
    }
 
}

