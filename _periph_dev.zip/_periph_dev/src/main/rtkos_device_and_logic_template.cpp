#include "luart/uart_handle.h"
#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

//#include "stm32.h"

#include "periph/gpio.h"
#include "periph/power.h"
#include "periph/adc.h"
#include "periph/flash.h"

#include "rtkos/rtkos.h"
#include "rtkos/rtkos_protothread.h"
#include "rtkos/starters.h"

#include "drivers/messages_rtkos.h"
#include "drivers/periph/legacy_uart_driver.h"
#include "drivers/periph/soft_i2c_driver.h"
#include "drivers/periph/tim_pwm_driver_impl.h"
#include "drivers/periph/adc_driver_impl.h"
#include "drivers/periph/gpio_driver_impl.h"
#include "drivers/periph/power_switch_driver_impl.h"
#include "drivers/periph/device_state_indicator_driver_impl.h"



#include "drivers/uplinks/golem_driver_impl.h"

//#include "drivers/motors/esc_driver_impl.h"

#include "drivers/hid/keyboard_terminal_driver.h"

//#include "drivers/sensors/honeywell_psensor_driver.h"


#include "rtkos/handlers/keyboard_hadler_impl_base.h"


#include "callbacks/callbacks.h"
#include "milliganjubus_core/milliganjubus_simple_reg_table.h"
#include "milliganjubus_core/milliganjubus_slave_session.h"
#include "milliganjubus_core/milliganjubus_synchronizer.h"
#include "milliganjubus_core/milliganjubus_master_session.h"


//#include "boards_conf/tvtx2v2_Main_Board_pins.cpp"
#include "boards_conf/tvtx2v2_Main_Board_conf.h"


#include "vtx2v2/telexertex2_types.h"

#include "vtx2v2/telexertex2_regs.h"

#include "vtx2v2/telexertex2_hot_end_regs.h"
#include "vtx2v2/telexertex2_joint_regs.h"
#include "vtx2v2/telexertex2_sucker_regs.h"

#include "vtx2v2/telexertex2_accel_regs.h"
#include "vtx2v2/telexertex2_battery_regs.h"
#include "vtx2v2/telexertex2_esc_regs.h"
#include "vtx2v2/telexertex2_gyro_regs.h"
#include "vtx2v2/telexertex2_pid_regs.h"
#include "vtx2v2/telexertex2_tvko_regs.h"

#include "vtx2v2/telexertex2_slaves.h"


#include "crc/umba_crc.h"
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
#undef RS485_LEFT_UART
#undef RS485_LEFT_LEGACY_UART
#define RS485_LEFT_UART                               UART4
#define RS485_LEFT_LEGACY_UART                        uart::uart4

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
using namespace umba::omanip;
using namespace umba::periph;
using namespace regs::Televertex2;
using namespace regs::types;
//-----------------------------------------------------------------------------




class TvkoTestLogic : public umba::ITimerHandler               // for timers
                     , public umba::rtkos::IMessageHandler      // for keyboard
                     , public umba::rtkos::IDriverClientHandler // for driver responses
                     , public umba::IIdleCapable                // полощем ганджубус тут
{

public:

    typedef umba::drivers::DriverAddress  DriverAddress;
    typedef umba::rtkos::TimerEventId     TimerEventId;
    typedef umba::rtkos::TimerId          TimerId;

    TvkoTestLogic()
    {}

    UMBA_BEGIN_INTERFACE_MAP_EX( umba::ITimerHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IMessageHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IDriverClientHandler )
    UMBA_END_INTERFACE_MAP()

    UMBA_DELEGATE_QUERY_INTERFACE(umba::ITimerHandler)

    // хелпер для установки таймера
    umba::rtkos::TimerId timerSet( umba::rtkos::TimerEventId eventId, umba::rtkos::TimeTick period )
    {
        return umba::rtkos::timerSet( this, eventId, period );
    }

protected:

    // Хелпер для инсталляции логики в систему
    void installDriverHandler( DriverAddress addrFrom )
    {
        umba::rtkos::driverHandlerAdd( addrFrom, this );
    }

public:

    // Установка в систему
    bool install()
    {
        UMBA_RTKOS_OS->messagesSetHandler( umba::rtkos::message_keyboard_id, this );
        //installDriverHandler(driver_address_psensor);
        //installDriverHandler(driver_address_adc    );
        //installDriverHandler(driver_address_knobs  );
        auto prevIdleHandler = UMBA_RTKOS_OS->setIdleHandler( this );
        return prevIdleHandler==0; // Если кто-то уже занял обработчик идлы, то ошибка
    }


    virtual
    void onTimer( unsigned eventId ) override
    {
    /*
        switch( eventId )
        {
        
            case timer_event_knobs:
                 postMessageDeviceValueRequest( driver_address_knobs, 0 );
                 break;
    */
    }


    virtual
    void onHandleMessage( umba::rtkos::Message &msg ) override
    {
        if (msg.id!=umba::rtkos::message_keyboard_id)
            return;

        umba::rtkos::MessageKeyboard &kbdMsg = msg.messageKeyboard;

        using umba::rtkos::VirtualKeyCode;

        if (kbdMsg.repeatCount==1)
        {
            // Handle "Key pressed" here
        }

        if (!kbdMsg.repeatCount || kbdMsg.repeatCount==1)
        {
            // Handle "Key pressed/released" here
        }

        if (kbdMsg.repeatCount)
        {
            // Handle "Key pressed/repeated" here
        }

    }

    //---------------------------------------
    virtual
    bool onMessageDriverClient( const umba::drivers::MessageDriver &msg ) override
    {
        using namespace umba::drivers;

        return false;
    }

    virtual
    bool onIdle() override
    {
        using namespace umba::omanip;

        return true;
    }

};




//-----------------------------------------------------------------------------
auto debugUartDriver      = umba::drivers::periph::LegacyUartDriver( RS485_LEFT_LEGACY_UART
                                                                   , RS485_LEFT_UART_RX_GPIO_PIN_ADDR
                                                                   , RS485_LEFT_UART_TX_GPIO_PIN_ADDR
                                                                   , 460800
                                                                   // No pinAddrRs485
                                                                   );

auto kbdTermDriver        = umba::drivers::hid::KeyboardTerminalDriver( 
                                                                        #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)
                                                                        umba::drivers::invalid_driver_address
                                                                        #else
                                                                        //umba::drivers::invalid_driver_address
                                                                        umba::drivers::DriverAddress( umba::drivers::class_id_stream
                                                                                                    , umba::periph::periphGetNo( & RS485_LEFT_LEGACY_UART ) 
                                                                                                    )
                                                                        #endif
                                                                      );

auto muxPowerDriver       = umba::drivers::periph::PowerSwitchDriver( MUX_EN_GPIO_PIN_ADDR, false );
auto muxDriver            = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , MUX_A1_GPIO_PIN_ADDR
                                                             , MUX_A0_GPIO_PIN_ADDR
                                                             );
auto tvkoPowerDriver      = umba::drivers::periph::PowerSwitchDriver( TVKO_EN_GPIO_PIN_ADDR   , false );


//-----------------------------------------------------------------------------
struct PredStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel4>
{
    //umba::drivers::DriverAddress escAddr = umba::drivers::DriverAddress( umba::drivers::class_id_motor, 1 );

    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning
         PT_END();
    }
};



//auto deviceLogic = MainBoardLogic();


struct FunalStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel6>
{
    virtual bool run() override
    {
        using namespace regs::types;
        using namespace umba::drivers;
        using namespace umba::drivers::uplinks;

         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning
         PT_END();
    }

}; // struct FunalStarterThread


auto hwInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );
auto swInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );

auto starter0   =  umba::rtkos::StarterThreadOsInfo< umba::rtkos::OsInfoLogLevel::osSizeDetailsMore >(); 

auto starter1   =  umba::rtkos::StarterThreadHardwareInfo();

auto starter2   =  umba::rtkos::StarterThreadHardwareInitializer< decltype(hwInitDelays)>( hwInitDelays );

auto starter4   =  PredStarterThread();

auto starter5   =  umba::rtkos::StarterThreadSoftwareInitializer< decltype(swInitDelays)/*, umba::rtkos::RunLevel5*/>( swInitDelays );

auto starter6   =  FunalStarterThread();


auto testLogic  =  TvkoTestLogic();


int main(void)

{

    UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( RS485_LEFT_LEGACY_UART, RS485_LEFT_UART, 460800 );

    TVKO_LEGACY_UART.init( TVKO_UART_RX_GPIO, TVKO_UART_RX_GPIO_PIN_NO
                        , TVKO_UART_TX_GPIO, TVKO_UART_TX_GPIO_PIN_NO
                        , 57600 // 460800 //*3/2
                        );

    UMBA_DRIVER_CHECKED_INSTALL( debugUartDriver, umba::drivers::driver_id_device_number );

    UMBA_DRIVER_CHECKED_INSTALL( muxPowerDriver  );
    UMBA_DRIVER_CHECKED_INSTALL( tvkoPowerDriver );

    UMBA_DRIVER_CHECKED_INSTALL( muxDriver       );

    UMBA_DRIVER_CHECKED_INSTALL(kbdTermDriver);

    UMBA_DRIVER_CHECKED_INSTALL(testLogic);

    umba::rtkos::pollScheduleAdd( &starter0 );
    umba::rtkos::pollScheduleAdd( &starter1 );
    umba::rtkos::pollScheduleAdd( &starter2 );
    umba::rtkos::pollScheduleAdd( &starter4 );
    umba::rtkos::pollScheduleAdd( &starter5 );
    umba::rtkos::pollScheduleAdd( &starter6 );


    return UMBA_RTKOS_OS->run( umba::rtkos::RunLevel6 );

}





