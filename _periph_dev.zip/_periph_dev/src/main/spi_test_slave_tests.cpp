
#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
#include "umba/hr_counter.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"
#include "periph/stm32_discovery.h"


#include "spi_test_master_slave.h"


//#define BUTTON_LED_TEST
//#define IRQ_SPEED_TEST
//#define DELAY_NANOSEC_TEST





void spiInit();
DECLARE_PIN( msTestCsPin , MS_TEST_SPI_CS  );

DECLARE_PIN( btnPin , STM32_DISCOVERY_BTN_USER );

umba::periph::GpioPin &ledPin = led1_Pin;



#if defined(IRQ_SPEED_TEST)
umba::periph::GpioPin  pa2(PA2);
umba::periph::GpioPin  pa3(PA3);
umba::periph::GpioPin  pa4(PA4);
umba::periph::GpioPin  pa5(PA5);
#endif

#if defined(DELAY_NANOSEC_TEST)
umba::periph::GpioPin  pa2(PA2);
#endif


using namespace umba::time_service;
using namespace umba::periph::traits;
using namespace umba::omanip;



//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::LegacyUartCharWriter<255>   charWritter = umba::LegacyUartCharWriter<255>( STM32_DISCOVERY_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);


umba::hr_counter::HiResTick  nanosecDelayVal = 0;


static bool btnPrevState = btnPin;

#if defined(BUTTON_LED_TEST)
    UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( btnIrqHandlerProc )
    {
        ledPin = !ledPin;
    }
#endif


#if defined(IRQ_SPEED_TEST)
    UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( pa4IrqHandlerProc )
    {
        pa5.toggle();
    }
#endif

#if defined(DELAY_NANOSEC_TEST)
    UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( btnIrqHandlerProc )
    {
        
        bool btnNewState = btnPin;
        if (btnPrevState!=btnNewState)
        {
            for(unsigned i=0; i!=20; ++i) {}
            btnNewState = btnPin;
            if (btnPrevState!=btnNewState)
            {
                btnPrevState = btnNewState;
                if (btnPrevState)
                {
                    if (nanosecDelayVal<50)
                        nanosecDelayVal += 10;
                    else if (nanosecDelayVal<300)
                        nanosecDelayVal += 50;
                    else if (nanosecDelayVal<1000)
                        nanosecDelayVal += 50; // 100;
                    else if (nanosecDelayVal<3000)
                        nanosecDelayVal += 50;
                    else if (nanosecDelayVal<10000)
                        nanosecDelayVal += 300;
                    else if (nanosecDelayVal<50000)
                        nanosecDelayVal += 5000;
                    else if (nanosecDelayVal<200000)
                        nanosecDelayVal += 10000;
                    else if (nanosecDelayVal<500000)
                        nanosecDelayVal += 20000;
                    lout<<"dT: "<<width(6)<<right<<nanosecDelayVal<<" ns, "<<width(6)<<right<< umba::hr_counter::convertNanosecToTick(nanosecDelayVal)<<endl;
                }
                lout<<flush;
            }
        }
    }
#endif


static volatile uint32_t hseVal   = 0;
static volatile uint32_t coreClk  = 0;
static volatile uint32_t sysClk   = 0;
static volatile uint32_t ahbClk   = 0;
static volatile uint32_t apb1Clk  = 0;
static volatile uint32_t apb2Clk  = 0;
static volatile uint32_t spiFreq  = 0;


int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    ledStartup();

    #if defined(IRQ_SPEED_TEST)
    pa2 = false;
    pa3 = false;
    pa4 = false;
    pa5 = false;
    #endif

    #if defined(DELAY_NANOSEC_TEST)
    pa2 = false;
    #endif

        
    STM32_DISCOVERY_LEGACY_UART.init( STM32_DISCOVERY_UART_RX_GPIO,  STM32_DISCOVERY_UART_RX_GPIO_PIN_NO, STM32_DISCOVERY_UART_TX_GPIO, STM32_DISCOVERY_UART_TX_GPIO_PIN_NO, 460800 );

    spiInit();

    lout<<"-----------------\nHello from Slave on "<<STM32_DISCOVERY_NAME<<endl;
    umba::hr_counter::HiResTick deltaTick = umba::hr_counter::convertNanosecToTick( (umba::hr_counter::HiResTick)100 );
    lout<<"100 ns in ticks: "<<deltaTick<<"\n";

    lout<<"Cur delay: "<<nanosecDelayVal<<" ns\n";
    lout<<"HRC Freq : "<<umba::hr_counter::getTickFreqKHz()<<" KHz\n";

    hseVal  = clockGetFreq(ClockBus::OSCCLK);
    coreClk = clockGetFreq(ClockBus::CORECLK);
    sysClk  = clockGetFreq(ClockBus::SYSCLK);
    ahbClk  = clockGetFreq(ClockBus::AHB);
    apb1Clk = clockGetFreq(ClockBus::APB1);
    apb2Clk = clockGetFreq(ClockBus::APB2); 
    spiFreq = spiGetFreq( MS_TEST_SPI );

    //             SYSCLK  PLL2
    // F100 24       24     ?
    // F303 72       48     24   // Strong interference on signal pins

    //mcoConfigure( McoMode::enabled );
    //mcoConfigure( McoMode::SYSCLK );
    //mcoConfigure( McoMode::PLL2 );

    //F4
    //mcoConfigure( McoMode::PA8_PLL2 );
    //mcoConfigure( McoMode::PC9_PLL2 );
    //mcoConfigure( McoMode::PC9_SYSCLK );

    // prepare PA8/PC9
    //mcoConfigure( McoMode::PC9_SYSCLK ); // работает на F4
    //mcoConfigure( McoMode::PA8_PLL2 );   // не работает на F4

    //RCC_MCO1Config( RCC_MCO1Source_HSE   , RCC_MCO1Div_1 );
    //RCC_MCO1Config( RCC_MCO1Source_PLLCLK, RCC_MCO1Div_2 );
    
    //RCC_MCO2Config( RCC_MCO2Source_SYSCLK, RCC_MCO1Div_1 );
    //RCC_MCO2Config( RCC_MCO2Source_HSE, RCC_MCO1Div_1 );
    //RCC_MCO2Config( RCC_MCO2Source_PLLCLK, RCC_MCO1Div_2 );
    
    
    
    lout<<"HSE : "<<width(9)<<left<<hseVal <<" Hz"<<endl;
    lout<<"CORE: "<<width(9)<<left<<coreClk<<" Hz"<<endl;
    lout<<"SYS : "<<width(9)<<left<<sysClk <<" Hz"<<endl;
    lout<<"AHB : "<<width(9)<<left<<ahbClk <<" Hz"<<endl;
    lout<<"APB1: "<<width(9)<<left<<apb1Clk<<" Hz"<<endl;
    lout<<"APB2: "<<width(9)<<left<<apb2Clk<<" Hz"<<endl;


    static umba::hr_counter::HiResTick nanosecOrTick = 60200;
    nanosecOrTick *= umba::hr_counter::getTickFreqKHz();
    nanosecOrTick /= 1000;
    nanosecOrTick /= 1000;

    //gpio_in_floating / gpio_in_pulldown
    
    auto btnPinMode = PinMode::gpio_in_pulldown; // gpio_in_floating; gpio_in_pullup;

    #if defined(BUTTON_LED_TEST)
    periphInitIrq( btnPin, extiTriggerRising, btnPinMode );
    periphInstallIrqHandler( btnPin, btnIrqHandlerProc );    
    //gpioGenerateSoftwareEXTI(btnPin);
    #endif

    #if defined(IRQ_SPEED_TEST)
    periphInitIrq( pa4, extiTriggerBoth, btnPinMode );
    periphInstallIrqHandler( pa4, pa4IrqHandlerProc );    
    #endif

    #if defined(DELAY_NANOSEC_TEST)
    periphInitIrq( btnPin, extiTriggerBoth, btnPinMode );
    periphInstallIrqHandler( btnPin, btnIrqHandlerProc );    
    #endif



    while(true)
    {
        #if defined(BUTTON_LED_TEST)
        bool btnNewState = btnPin;
        if (btnPrevState!=btnNewState) // state changed
        {
            btnPrevState = btnNewState;
            //if (btnNewState)
            //    ledPin       = !ledPin;
        }
        #endif

        #if defined(DELAY_NANOSEC_TEST)

        pa2.toggle();
        umba::hr_counter::delayNanosec( nanosecDelayVal );

        #endif

        #if defined(IRQ_SPEED_TEST)

        // 1) Сдвиг второго фронта на 875 нс на F100/24МГц
        //    Сдвиг второго фронта на 465 нс на F103/72МГц
        //    Сдвиг второго фронта на 370 нс на F303/72МГц
        //    Сдвиг второго фронта на 100 нс на F405/168МГц
        pa2.toggle();
        pa3.toggle();

        // 2) PA2 соединяем с PA4
        //    Осцилографом цепляем на PA2 и PA5
        //    Изменение PA2 вызовет прерывание PA4, в обработчике которого меняем PA5
        //    Если считать, что прерывание и прочее прошло мнгновенно, то должны получить чистые 725 нс
        //    Но, скорее всего, это не так быстро
        //    Поэтому от полученного времени отнимем 725 нс и получим, 
        //    сколько лишнего времени протупили в прерывании

        //    3.3 - 0.725 = 2.575 мкс - задержка на прерывании

        // 3) Немного оптимизировал - сделал безусловный вызов - если нет обработчика, то вызывается заглушка 
        //    1.680 - 0.725 = 0.955 мкс - уже неплохо

        // 4) Еще немного оптимизировал - убрал volatile и костыль из временной структуры
        //    1.480 - 0.725 = 0.755 мкс - еще лучше

        // 5) Еще немного оптимизировал - сделал force inline для обращений к портам
        //    1.320 вместе с задержкой на тогл - 475 нс
        //    1.320 - 0.475 = 0.845 - время на обработку прерывания слегка увеличилось (???)

        // 6) 

        delayMs(10);
        #endif

    }

}



#if defined(BUTTON_LED_TEST)

/*
UMBA_EXTI_IRQ_HANDLER_BEGIN(STM32_DISCOVERY_BTN_USER_GPIO_PIN_NO)
{
    ledPin = !ledPin;
}
UMBA_EXTI_IRQ_HANDLER_END(STM32_DISCOVERY_BTN_USER_GPIO_PIN_NO)
*/
/*
UMBA_IRQ_HANDLER( EXTI0_IRQ_HANDLER_NAME )
{
    if (gpioTestPendingEXTI(btnPin))
    {
        gpioClearPendingEXTI( btnPin );
        ledPin = !ledPin;
    }
}
*/
#endif

UMBA_PERIPH_DECLARE_SPI_IRQ_HANDLER_PROC( spiIrqHandler )
{

}


void spiInit()
{

    // SPI hints
    // 8/16 - https://diymcblog.blogspot.com/2018/03/spi-stm32-2.html
    // Статусы - http://www.cyberforum.ru/arm/thread2091007.html
    // Полезная инфа - https://microtechnics.ru/stm32-s-nulya-interfejs-spi/
    //   Важное дополнение – инициализация GPIO должна происходить после инициализации SPI, иначе могут возникнуть сбои в работе Slave.

    using namespace umba::periph::traits;

    SpiPrescaler psc100   = spiCalcPrescaler( MS_TEST_SPI,   100000 );
    SpiPrescaler psc150   = spiCalcPrescaler( MS_TEST_SPI,   150000 );
    SpiPrescaler psc200   = spiCalcPrescaler( MS_TEST_SPI,   200000 );
    SpiPrescaler psc250   = spiCalcPrescaler( MS_TEST_SPI,   250000 );
    SpiPrescaler psc500   = spiCalcPrescaler( MS_TEST_SPI,   500000 );
    SpiPrescaler psc1000  = spiCalcPrescaler( MS_TEST_SPI,  1000000 );
    SpiPrescaler psc2000  = spiCalcPrescaler( MS_TEST_SPI,  2000000 );
    SpiPrescaler psc3000  = spiCalcPrescaler( MS_TEST_SPI,  3000000 );
    SpiPrescaler psc4000  = spiCalcPrescaler( MS_TEST_SPI,  4000000 );
    SpiPrescaler psc5000  = spiCalcPrescaler( MS_TEST_SPI,  5000000 );
    SpiPrescaler psc10000 = spiCalcPrescaler( MS_TEST_SPI, 10000000 );
    SpiPrescaler psc15000 = spiCalcPrescaler( MS_TEST_SPI, 15000000 );
    SpiPrescaler psc20000 = spiCalcPrescaler( MS_TEST_SPI, 20000000 );

    periphInit( MS_TEST_SPI                      
              , MS_TEST_SPI_SCK_GPIO_PIN_ADDR    
              , MS_TEST_SPI_MISO_GPIO_PIN_ADDR   
              , MS_TEST_SPI_MOSI_GPIO_PIN_ADDR   
              , umba::periph::traits::spiDataBits8
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              #ifdef TIMINGS_CHECK
              , umba::periph::traits::spiPrescaler256
              #else
              , spiCalcPrescaler( MS_TEST_SPI,   1000000 )
              //, umba::periph::traits::spiPrescaler256
              #endif
              , PinSpeed::high // PinSpeed::low
              );

    msTestCsPin = true;

    periphInitIrq( MS_TEST_SPI, spiMakeEventType(spiEventRxReady) );
    periphInstallIrqHandler( MS_TEST_SPI, spiIrqHandler );

    

    
/*
    CPOL_CPHA   - clk - инверсный, данные - прямой
    nCPOL_CPHA  - Оба сигнала нормальная логика
    CPOL_nCPHA  - Оба сигнала инверсная логика
    nCPOL_nCPHA - clk - прямой, дата инверсная

    PinSpeed::low
    PinSpeed::medium
    PinSpeed::fast
    PinSpeed::high

*/

}


