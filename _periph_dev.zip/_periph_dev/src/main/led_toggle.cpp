#include "vgpio/i_virtual_gpio.h"
#include "vgpio/stm32_gpio.h"
#include "umba/time_service.h"


namespace vgpio     = umba::virtual_gpio;
namespace stm32gpio = umba::stm32_gpio;


stm32gpio::Stm32IoPort ledPort( vgpio::Port::C
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::output
                              , vgpio::PinPushPullMode::pushPull
                              , vgpio::pin_12
                              );




int main(void)
{
    umba::time_service::init();
    umba::time_service::start();

    ledPort.initPort();

    while(1)
    {
        umba::time_service::delayMs(1000);
        ledPort.toggleOutput( ledPort.getPins() );

    }

    return 0;
}
