#include "vgpio/i_virtual_gpio.h"
#include "vgpio/stm32_gpio.h"
#include "vgpio/virtual_gpio.h"
#include "umba/time_service.h"



namespace vgpio     = umba::virtual_gpio;
namespace stm32gpio = umba::stm32_gpio;


/*
umba::LegacyUartWriter   uartWriter(uart::uart3);
umba::SimpleFormatter    fmt(&uartWriter);
*/


const vgpio::PinType genPhisPin = vgpio::pin_4;

stm32gpio::Stm32IoPort genPhisPort( vgpio::Port::C
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::output
                              , vgpio::PinPushPullMode::pushPull
                              , genPhisPin
                              );

volatile unsigned delayCounter = 0;

void delay200khz()
{
    // Подбираем по осцилографу для микрухи на 72МГц
    // 44 -  98 КГц - 10.2 мкс период
    // 43 - 100 КГц - 10.0 мкс период
    // 1 единица - 0.2 мкс периода, 2 КГц частоты
    //for(int i=0; i!=43; ++i) {}
    
    
    // 28 - 102 КГц
    // 29 -  98 КГц
    // 1 единица - 0.4 мкс периода, 4 КГц частоты
    for(int i=0; i!=29; ++i)
        delayCounter++;
}



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    genPhisPort.initPort();

    genPhisPort.clrOutput( genPhisPort.getPins() );


    while(1)
    {
/*
        delay200khz();
        genPhisPort.toggleOutput( genPhisPort.getPins() );

        delay200khz();
        genPhisPort.toggleOutput( genPhisPort.getPins() );
*/

        delay200khz();
        uint16_t curVal  = GPIO_ReadOutputData( GPIOC );
        GPIO_Write( GPIOC, (uint16_t)(curVal ^ genPhisPin));

        delay200khz();
        GPIO_Write( GPIOC, (uint16_t)curVal);
    }

    return 0;
}



