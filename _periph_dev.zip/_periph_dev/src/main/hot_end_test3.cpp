#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "periph/gpio.h"
#include "periph/power.h"
#include "periph/adc.h"

#include "soft_spi.h"
#include "soft_interval.h"
#include "max31855.h"


#if !defined(STM32F3_SERIES)
    #error "STM32F3_SERIES not defined"
#endif

#include "vtx2_hotend.h"
#include "hot_end_dbg_uart_conf.h"






#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  lout(&charWritter);




static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;




#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )



void motorCtrl( umba::periph::GpioPin &motorIn1, umba::periph::GpioPin &motorIn2, int direction )
{
    if (direction<0)
    {
        motorIn1 = true;
        motorIn2 = false;
    }
    else if (direction>0)
    {
        motorIn1 = false;
        motorIn2 = true;
    }
    else
    {
        motorIn1 = false;
        motorIn2 = false;
    }
}



struct TermocoupleData
{
    umba::periph::GpioPin *pCsPin;
    int                   correction;
    int                   orgValue;
    int                   curValue;
    uint32_t              rawValue;
};




int main(void)
{

    int stateMotor1 = 0;
    int stateMotor2 = 0;
    //int onlyAllowedStateMotor2 = 0;

    umba::time_service::init();
    umba::time_service::start();
    
    using namespace umba::time_service;
    using namespace umba::omanip;
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;

/*
    umba::periph::traits::DacSimple motor1SpeedDac( MOTOR1_SPEED_DAC_CHANNEL_NO );
    umba::periph::traits::DacSimple motor2SpeedDac( MOTOR2_SPEED_DAC_CHANNEL_NO );

    // 12 Bit
    // DAC Output = 3.3 * DAC DOR / 4095
    // DAC output max for 1.22V: 1.22 / 3.3 * 4095 = 1513

    // 8 bit
    // DAC Output = 3.3 * DAC DOR / 255
    // DAC output max for 1.22V: 1.22 / 3.3 * 255 = 94

    motor1SpeedDac.connect();
    motor2SpeedDac.connect();

    motor1SpeedDac.write( 1000 );
    motor2SpeedDac.write( 1000 );
*/

    umba::periph::GpioPin  nichDim1( PA8 );
    umba::periph::GpioPin  nichDim2( PA9 );
    umba::periph::GpioPin  nichPwr( PA15 );

    nichDim1.connect();
    nichDim2.connect();
    nichPwr .connect();

    nichDim1 = false;
    nichDim2 = false;
    nichPwr  = false;

    DECLARE_PIN( termocouplesSckPin , HOTEND_TERMCPL_SPI_SCK  );
    DECLARE_PIN( termocouplesMisoPin, HOTEND_TERMCPL_SPI_MISO );
    DECLARE_PIN( termocouplesCs1Pin , HOTEND1_TERMCPL_CS      );
    DECLARE_PIN( termocouplesCs2Pin , HOTEND2_TERMCPL_CS      );

    termocouplesSckPin .connect();
    termocouplesMisoPin.connect();
    termocouplesCs1Pin .connect();
    termocouplesCs2Pin .connect();

    termocouplesSckPin = false;
    termocouplesCs1Pin = true;
    termocouplesCs2Pin = true;



    umba::periph::GpioPin  motor1SpeedPin( PA4 );
    umba::periph::GpioPin  motor2SpeedPin( PA5 );

    motor1SpeedPin.connect();
    motor2SpeedPin.connect();

    motor1SpeedPin = true;
    motor2SpeedPin = true;


    DECLARE_PIN( motor1In1Pin  , MOTOR1_IN1 );
    DECLARE_PIN( motor1In2Pin  , MOTOR1_IN2 );

    DECLARE_PIN( motor2In1Pin  , MOTOR2_IN1 );
    DECLARE_PIN( motor2In2Pin  , MOTOR2_IN2 );

    DECLARE_PIN( endStop1  , ENDSTOP_SWITCH1 );
    DECLARE_PIN( endStop2  , ENDSTOP_SWITCH2 );

    endStop1.connect();
    endStop2.connect();

    motor1In1Pin.connect();
    motor1In2Pin.connect();
                
    motor2In1Pin.connect();
    motor2In2Pin.connect();

    motor1In1Pin = false;
    motor1In2Pin = false;

    motor2In1Pin = false;
    motor2In2Pin = false;

    volatile bool e1 = endStop1;
    volatile bool e2 = endStop2;


    auto motorCurrentAdc = umba::periph::adcInitInject( ADC1, umba::periph::AdcSamplingSpeed::high, false, PA0, PA1 );
    #define MOTOR1_CURRENT_SENSOR_ADC_IDX 0
    #define MOTOR2_CURRENT_SENSOR_ADC_IDX 1

    
    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );

    umba::time_service::delayMs(300);

    lout<<"Starting"<<flush;

    using namespace umba::omanip;

    auto kbdHandler = umba::periph::makeKeyboardHandler
                    ( 
                         [&]( unsigned vkc, bool fPressed, size_t repeatCout )
                         {
                             using namespace umba::omanip;
                             //if (vkc & umba::periph::VirtualKeyCode::virtualCodeFlag)
                             //   lout<<umba::periph::VirtualKeyCode::getKeyCodeName(vkc); //<<endl;
                             //else
                             //   lout<<(char)(uint8_t)(vkc); //<<endl;

                             int newStateMotor1 = stateMotor1;
                             int newStateMotor2 = stateMotor2;


                             // Ручное управление
                             if (vkc==umba::periph::VirtualKeyCode::up)
                             {
                                 if (fPressed)
                                     newStateMotor1 =  1;
                                 else
                                     newStateMotor1 =  0;
                             }
                             else if (vkc==umba::periph::VirtualKeyCode::down)
                             {
                                 if (fPressed)
                                     newStateMotor1 = -1;
                                 else
                                     newStateMotor1 =  0;
                             }
                             else if (vkc==umba::periph::VirtualKeyCode::right)
                             {
                                 if (fPressed)
                                     newStateMotor2 =  1;
                                 else
                                     newStateMotor2 =  0;
                             }
                             else if (vkc==umba::periph::VirtualKeyCode::left)
                             {
                                 if (fPressed)
                                     newStateMotor2 = -1;
                                 else
                                     newStateMotor2 =  0;
                             }
                             else if (vkc==umba::periph::VirtualKeyCode::ins)
                             {
                                 if (fPressed && repeatCout<2)
                                 {
                                     nichDim1 = !nichDim1;
                                     lout<<"Nich 1: "<<nichDim1<<endl;
                                 }
                             }
                             else if (vkc==umba::periph::VirtualKeyCode::del)
                             {
                                 if (fPressed && repeatCout<2)
                                 {
                                     nichDim2 = !nichDim2;
                                     lout<<"Nich 2: "<<nichDim2<<endl;
                                 }
                             }


                             // Экструдер
                             if (stateMotor1!=newStateMotor1)
                             {
                                 stateMotor1 = newStateMotor1;
                                 motorCtrl( motor1In1Pin, motor1In2Pin, stateMotor1 );
                             }

                             // Прижим пятки
                             if (stateMotor2!=newStateMotor2)
                             {
                                 stateMotor2 = newStateMotor2;
                                 motorCtrl( motor2In1Pin, motor2In2Pin, stateMotor2 );
                             }

                         }
                    );

    umba::periph::legacy::UartTerminalKeyboard kbd = umba::periph::legacy::UartTerminalKeyboard( &kbdHandler, & DEBUG_TERMINAL_LEGACY_UART );

/*


    delayMs(500);

*/

    /*

    // Motor1

    // run forward
    motor1In1Pin = true;
    motor1In2Pin = false;

    delayMs(500);

    // run backward
    motor1In1Pin = false;
    motor1In2Pin = true;

    delayMs(500);

    // stop
    motor1In2Pin = false;


    // Motor2

    // run forward
    motor2In1Pin = true;
    motor2In2Pin = false;

    delayMs(500);

    // run backward
    motor2In1Pin = false;
    motor2In2Pin = true;

    delayMs(500);

    // stop
    motor2In2Pin = false;
    
*/                         
/*
    motor2In1Pin = false;
    motor2In2Pin = true;
*/

    nichPwr = true;
    //nichDim1 = true;
    //nichDim2 = true;

    TermocoupleData termocoupleData[2] = { { &termocouplesCs1Pin, -26, 0, 0, 0 }
                                         , { &termocouplesCs2Pin, -28, 0, 0, 0 }
                                         };


    //volatile uint32_t termocouple1Data = 0;
    //volatile uint32_t termocouple2Data = 0;

    SoftIntervalMs    termocouplesInterval(5000);
    unsigned          termocouplesCounter = 0;

    termocouplesInterval.reset();

    bool prevES1 = endStop1;
    bool prevES2 = endStop2;

    //unsigned prevCurrentMotor1 = 0;
    //unsigned prevCurrentMotor2 = 0;
    unsigned motorPrevCurrentValues[2] = { 0, 0 };



    while(1)
    {
        kbd.scanKeyboard();


        if (termocouplesInterval.checkTimedout())
        {
            termocoupleData[termocouplesCounter&1].rawValue = softSpiRead( 32, termocouplesSckPin, termocouplesMisoPin, *termocoupleData[termocouplesCounter&1].pCsPin, 0 );
            termocoupleData[termocouplesCounter&1].orgValue = max31855_getTempFromRaw(termocoupleData[termocouplesCounter&1].rawValue);
            termocoupleData[termocouplesCounter&1].curValue = termocoupleData[termocouplesCounter&1].orgValue + termocoupleData[termocouplesCounter&1].correction;

            lout<<"Termocouple 2 raw: "<<termocoupleData[termocouplesCounter&1].rawValue<<"   ";
            if (max31855_checkFaulFlags(termocoupleData[termocouplesCounter&1].rawValue))
            {
                lout<<"Fault";
            }
            else
            {
                lout<<"Temp "<<(termocouplesCounter&1)<<" org: "
                    <<termocoupleData[termocouplesCounter&1].orgValue<<" C ("
                    <<termocoupleData[termocouplesCounter&1].curValue<<" C)   Int: "
                    <<max31855_getInternalTempFromRaw(termocoupleData[termocouplesCounter&1].rawValue)<<" C";
            }
            lout<<endl;

            /*
            if (termocouplesCounter&1)
            {
                lout<<"Termocouple 2 raw: "<<termocouple2Data<<"   ";
                if (max31855_checkFaulFlags(termocouple2Data))
                {
                    lout<<"Fault";
                }
                else
                {
                    lout<<"Temp: "<<max31855_getTempFromRaw(termocouple2Data)<<" C ("<<val<<" C)   Int: "<<max31855_getInternalTempFromRaw(termocouple2Data)<<" C";
                }
                lout<<endl;
            }
            else
            {
                termocouple1Data = softSpiRead( 32, termocouplesSckPin, termocouplesMisoPin, *termocoupleData[termocouplesCounter&1].pCsPin, 0  );
                lout<<"Termocouple 1 raw: "<<termocouple1Data<<"   ";
                if (max31855_checkFaulFlags(termocouple1Data))
                {
                    lout<<"Fault";
                }
                else
                {
                    lout<<"Temp: "<<max31855_getTempFromRaw(termocouple1Data)<<"C   Int: "<<max31855_getInternalTempFromRaw(termocouple1Data)<<"C";
                }
                lout<<endl;
            }
            */
            termocouplesCounter++;
        }

        if (prevES1 != endStop1)
        {
            lout<<"ES1 changed: "<<endStop1<<endl;
            prevES1 = endStop1;
        }

        if (prevES2 != endStop2)
        {
            lout<<"ES2 changed: "<<endStop2<<endl;
            prevES2 = endStop2;
        }

        if (!endStop1 && stateMotor2>0)
        {
            lout<<"Endstop1: "<<endStop1<<endl;
            lout<<"Endstop2: "<<endStop2<<", StateMotor2: "<<stateMotor2<<endl;
            stateMotor2 = 0;
            motorCtrl( motor2In1Pin, motor2In2Pin, stateMotor2 );

            // Сработал концевик прижатия, дальше нельзя прижимать
            // Сгенерировать событие - просигналить в регистры и тп
            lout<<"Stop - low position"<<endl;
            //lout<<flush;
        }


        unsigned motorCurrentValues[2] = { 0, 0 };
        for( size_t i=0; i!=2; ++i)
        {
            motorCurrentValues[i] = motorCurrentAdc[i];
            if (motorPrevCurrentValues[i] != motorCurrentValues[i])
            {
                lout<<"Motor "<<(i+1)<<" current: "<<motorCurrentValues[i]<<endl;
                motorPrevCurrentValues[i] = motorCurrentValues[i];
            }
        }

        /*
        if (!endStop1 && stateMotor2<0)
        {
            stateMotor2 = 0;
            motorCtrl( motor2In1Pin, motor2In2Pin, stateMotor2 );

            // Сработал верхний концевик
            lout<<"Stop - high position"<<endl;
        }
        */

        //delayMs(500);
        //lout<<"Alive "<< n++ <<"\n";
    }

    return 0;
}




