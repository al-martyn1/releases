#pragma once

namespace regs
{
    namespace tvko
    {
        namespace rw
        {
            const uint8_t min = 0x80;

            //$RWBEGIN

            const uint8_t voltage_x_s8                                                = 0x80; /* 128 */ // скорость мотора оси X в % от -100 до 100
            const uint8_t voltage_y_s8                                                = 0x81; /* 129 */ // скорость мотора оси Y в % от -100 до 100
            const uint8_t camera_power_u8                                             = 0x82; /* 130 */ // on = 1/off = 0
            const uint8_t digital_zoom_u8                                             = 0x83; /* 131 */ // on = 1/off = 0
            const uint8_t auto_focus_u8                                               = 0x84; /* 132 */ // on = 1/off = 0
            const uint8_t zoom_speed_s8                                               = 0x85; /* 133 */ // от -8 до 8
            const uint8_t focus_speed_s8                                              = 0x86; /* 134 */ // от -8 до 8
            const uint8_t infrared_correction_u8                                      = 0x87; /* 135 */ // standart = 0, ir_light = 0x01
            const uint8_t white_balance_u8                                            = 0x88; /* 136 */ // auto = 0, manual = 0x05, sodium lamp = 0x07
            const uint8_t red_gain_u8                                                 = 0x89; /* 137 */ // от 0 до 255
            const uint8_t blue_gain_u8                                                = 0x8A; /* 138 */ // от 0 до 255
            const uint8_t automatic_exposure_u8                                       = 0x8B; /* 139 */ // full auto = 0, manual = 0x03, shutter_priority = 0x0a, iris_priority = 0x0b, bright = 0x0d
            const uint8_t shutter_u8                                                  = 0x8C; /* 140 */ // от 0x0 до 0x15, '0x0' - 1/1sec; '0x15' - 1/10000sec
            const uint8_t iris_u8                                                     = 0x8D; /* 141 */ // от 0x0 до 0x11, '0x0' - close; '0x01' - f28; '0x11' - f1.6
            const uint8_t gain_u8                                                     = 0x8E; /* 142 */ // от 0x0 до 0x0f
            const uint8_t bright_u8                                                   = 0x8F; /* 143 */ // от 0x0 до 0x1f
            const uint8_t backlight_compensation_u8                                   = 0x90; /* 144 */ // on = 1/off = 0
            const uint8_t defog_u8                                                    = 0x91; /* 145 */ // on = 1/off = 0
            const uint8_t high_resolution_mode_u8                                     = 0x92; /* 146 */ // on = 1/off = 0
            const uint8_t mirror_u8                                                   = 0x93; /* 147 */ // on = 1/off = 0
            const uint8_t black_white_u8                                              = 0x94; /* 148 */ // on = 1/off = 0
            const uint8_t flip_u8                                                     = 0x95; /* 149 */ // on = 1/off = 0
            const uint8_t infrared_mode_u8                                            = 0x96; /* 150 */ // on = 1/off = 0
            const uint8_t auto_infrared_mode_u8                                       = 0x97; /* 151 */ // on = 1/off = 0
            const uint8_t auto_infrared_mode_threshold_u8                             = 0x98; /* 152 */ // тут пределы не нашёл в даташите
            const uint8_t stabilizer_u8                                               = 0x99; /* 153 */ // on = 1/off = 0/hold = 2
            const uint8_t color_enhance_u8                                            = 0x9A; /* 154 */ // on = 1/off = 0
            const uint8_t color_enhance_threshold_level_u8                            = 0x9B; /* 155 */ // значения от 0 до 0x7f
            const uint8_t color_enhance_hysteresis_width_u8                           = 0x9C; /* 156 */ // значения от 0 до 0x7f
            const uint8_t color_enhance_fixed_color_y_of_high_intensity_side_u8       = 0x9D; /* 157 */ // значения от 0 до 0x7f
            const uint8_t color_enhance_fixed_color_cr_of_high_intensity_side_u8      = 0x9E; /* 158 */ // значения от 0 до 0x7f
            const uint8_t color_enhance_fixed_color_cb_of_high_intensity_side_u8      = 0x9F; /* 159 */ // значения от 0 до 0x7f
            const uint8_t color_enhance_fixed_color_y_of_low_intensity_side_u8        = 0xA0; /* 160 */ // значения от 0 до 0x7f
            const uint8_t color_enhance_fixed_color_cr_of_low_intensity_side_u8       = 0xA1; /* 161 */ // значения от 0 до 0x7f
            const uint8_t color_enhance_fixed_color_cb_of_low_intensity_side_u8       = 0xA2; /* 162 */ // значения от 0 до 0x7f
            const uint8_t zoom_direct_position_s16                                    = 0xA3; /* 163 */ // от 0 до не знаю

            //$RWEND

            const uint8_t max = 0xA4;
    

            struct meta
            {

                static
                bool reg_type_check( uint8_t regNo, int regType, unsigned regSize )
                {
                    switch(regNo)
                    {
                        case voltage_x_s8:
                             if (regType!=RDLC_REGTYPE_INT) return false;
                             if (regSize!=1) return false;
                             return true;

                        case voltage_y_s8:
                             if (regType!=RDLC_REGTYPE_INT) return false;
                             if (regSize!=1) return false;
                             return true;

                        case camera_power_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case digital_zoom_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case auto_focus_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case zoom_speed_s8:
                             if (regType!=RDLC_REGTYPE_INT) return false;
                             if (regSize!=1) return false;
                             return true;

                        case focus_speed_s8:
                             if (regType!=RDLC_REGTYPE_INT) return false;
                             if (regSize!=1) return false;
                             return true;

                        case infrared_correction_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case white_balance_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case red_gain_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case blue_gain_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case automatic_exposure_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case shutter_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case iris_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case gain_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case bright_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case backlight_compensation_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case defog_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case high_resolution_mode_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case mirror_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case black_white_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case flip_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case infrared_mode_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case auto_infrared_mode_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case auto_infrared_mode_threshold_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case stabilizer_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_threshold_level_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_hysteresis_width_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_fixed_color_y_of_high_intensity_side_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_fixed_color_cr_of_high_intensity_side_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_fixed_color_cb_of_high_intensity_side_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_fixed_color_y_of_low_intensity_side_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_fixed_color_cr_of_low_intensity_side_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case color_enhance_fixed_color_cb_of_low_intensity_side_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case zoom_direct_position_s16:
                             if (regType!=RDLC_REGTYPE_INT) return false;
                             if (regSize!=2) return false;
                             return true;

                    }
                    return false;
                }
    

                static
                const char* reg_get_name( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case voltage_x_s8: return "voltage_x_s8";
                        case voltage_y_s8: return "voltage_y_s8";
                        case camera_power_u8: return "camera_power_u8";
                        case digital_zoom_u8: return "digital_zoom_u8";
                        case auto_focus_u8: return "auto_focus_u8";
                        case zoom_speed_s8: return "zoom_speed_s8";
                        case focus_speed_s8: return "focus_speed_s8";
                        case infrared_correction_u8: return "infrared_correction_u8";
                        case white_balance_u8: return "white_balance_u8";
                        case red_gain_u8: return "red_gain_u8";
                        case blue_gain_u8: return "blue_gain_u8";
                        case automatic_exposure_u8: return "automatic_exposure_u8";
                        case shutter_u8: return "shutter_u8";
                        case iris_u8: return "iris_u8";
                        case gain_u8: return "gain_u8";
                        case bright_u8: return "bright_u8";
                        case backlight_compensation_u8: return "backlight_compensation_u8";
                        case defog_u8: return "defog_u8";
                        case high_resolution_mode_u8: return "high_resolution_mode_u8";
                        case mirror_u8: return "mirror_u8";
                        case black_white_u8: return "black_white_u8";
                        case flip_u8: return "flip_u8";
                        case infrared_mode_u8: return "infrared_mode_u8";
                        case auto_infrared_mode_u8: return "auto_infrared_mode_u8";
                        case auto_infrared_mode_threshold_u8: return "auto_infrared_mode_threshold_u8";
                        case stabilizer_u8: return "stabilizer_u8";
                        case color_enhance_u8: return "color_enhance_u8";
                        case color_enhance_threshold_level_u8: return "color_enhance_threshold_level_u8";
                        case color_enhance_hysteresis_width_u8: return "color_enhance_hysteresis_width_u8";
                        case color_enhance_fixed_color_y_of_high_intensity_side_u8: return "color_enhance_fixed_color_y_of_high_intensity_side_u8";
                        case color_enhance_fixed_color_cr_of_high_intensity_side_u8: return "color_enhance_fixed_color_cr_of_high_intensity_side_u8";
                        case color_enhance_fixed_color_cb_of_high_intensity_side_u8: return "color_enhance_fixed_color_cb_of_high_intensity_side_u8";
                        case color_enhance_fixed_color_y_of_low_intensity_side_u8: return "color_enhance_fixed_color_y_of_low_intensity_side_u8";
                        case color_enhance_fixed_color_cr_of_low_intensity_side_u8: return "color_enhance_fixed_color_cr_of_low_intensity_side_u8";
                        case color_enhance_fixed_color_cb_of_low_intensity_side_u8: return "color_enhance_fixed_color_cb_of_low_intensity_side_u8";
                        case zoom_direct_position_s16: return "zoom_direct_position_s16";
                    }
                    return 0;
                }
    

                static
                int reg_get_type( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case voltage_x_s8: return RDLC_REGTYPE_INT;
                        case voltage_y_s8: return RDLC_REGTYPE_INT;
                        case camera_power_u8: return RDLC_REGTYPE_UNSIGNED;
                        case digital_zoom_u8: return RDLC_REGTYPE_UNSIGNED;
                        case auto_focus_u8: return RDLC_REGTYPE_UNSIGNED;
                        case zoom_speed_s8: return RDLC_REGTYPE_INT;
                        case focus_speed_s8: return RDLC_REGTYPE_INT;
                        case infrared_correction_u8: return RDLC_REGTYPE_UNSIGNED;
                        case white_balance_u8: return RDLC_REGTYPE_UNSIGNED;
                        case red_gain_u8: return RDLC_REGTYPE_UNSIGNED;
                        case blue_gain_u8: return RDLC_REGTYPE_UNSIGNED;
                        case automatic_exposure_u8: return RDLC_REGTYPE_UNSIGNED;
                        case shutter_u8: return RDLC_REGTYPE_UNSIGNED;
                        case iris_u8: return RDLC_REGTYPE_UNSIGNED;
                        case gain_u8: return RDLC_REGTYPE_UNSIGNED;
                        case bright_u8: return RDLC_REGTYPE_UNSIGNED;
                        case backlight_compensation_u8: return RDLC_REGTYPE_UNSIGNED;
                        case defog_u8: return RDLC_REGTYPE_UNSIGNED;
                        case high_resolution_mode_u8: return RDLC_REGTYPE_UNSIGNED;
                        case mirror_u8: return RDLC_REGTYPE_UNSIGNED;
                        case black_white_u8: return RDLC_REGTYPE_UNSIGNED;
                        case flip_u8: return RDLC_REGTYPE_UNSIGNED;
                        case infrared_mode_u8: return RDLC_REGTYPE_UNSIGNED;
                        case auto_infrared_mode_u8: return RDLC_REGTYPE_UNSIGNED;
                        case auto_infrared_mode_threshold_u8: return RDLC_REGTYPE_UNSIGNED;
                        case stabilizer_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_threshold_level_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_hysteresis_width_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_fixed_color_y_of_high_intensity_side_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_fixed_color_cr_of_high_intensity_side_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_fixed_color_cb_of_high_intensity_side_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_fixed_color_y_of_low_intensity_side_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_fixed_color_cr_of_low_intensity_side_u8: return RDLC_REGTYPE_UNSIGNED;
                        case color_enhance_fixed_color_cb_of_low_intensity_side_u8: return RDLC_REGTYPE_UNSIGNED;
                        case zoom_direct_position_s16: return RDLC_REGTYPE_INT;
                    }
                    return false;
                }
    

                static
                int reg_get_size( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case voltage_x_s8: return 1;
                        case voltage_y_s8: return 1;
                        case camera_power_u8: return 1;
                        case digital_zoom_u8: return 1;
                        case auto_focus_u8: return 1;
                        case zoom_speed_s8: return 1;
                        case focus_speed_s8: return 1;
                        case infrared_correction_u8: return 1;
                        case white_balance_u8: return 1;
                        case red_gain_u8: return 1;
                        case blue_gain_u8: return 1;
                        case automatic_exposure_u8: return 1;
                        case shutter_u8: return 1;
                        case iris_u8: return 1;
                        case gain_u8: return 1;
                        case bright_u8: return 1;
                        case backlight_compensation_u8: return 1;
                        case defog_u8: return 1;
                        case high_resolution_mode_u8: return 1;
                        case mirror_u8: return 1;
                        case black_white_u8: return 1;
                        case flip_u8: return 1;
                        case infrared_mode_u8: return 1;
                        case auto_infrared_mode_u8: return 1;
                        case auto_infrared_mode_threshold_u8: return 1;
                        case stabilizer_u8: return 1;
                        case color_enhance_u8: return 1;
                        case color_enhance_threshold_level_u8: return 1;
                        case color_enhance_hysteresis_width_u8: return 1;
                        case color_enhance_fixed_color_y_of_high_intensity_side_u8: return 1;
                        case color_enhance_fixed_color_cr_of_high_intensity_side_u8: return 1;
                        case color_enhance_fixed_color_cb_of_high_intensity_side_u8: return 1;
                        case color_enhance_fixed_color_y_of_low_intensity_side_u8: return 1;
                        case color_enhance_fixed_color_cr_of_low_intensity_side_u8: return 1;
                        case color_enhance_fixed_color_cb_of_low_intensity_side_u8: return 1;
                        case zoom_direct_position_s16: return 2;
                    }
                    return -1;
                }
    

                static
                int reg_get_next( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case voltage_x_s8: return (int)(unsigned)voltage_y_s8;
                        case voltage_y_s8: return (int)(unsigned)camera_power_u8;
                        case camera_power_u8: return (int)(unsigned)digital_zoom_u8;
                        case digital_zoom_u8: return (int)(unsigned)auto_focus_u8;
                        case auto_focus_u8: return (int)(unsigned)zoom_speed_s8;
                        case zoom_speed_s8: return (int)(unsigned)focus_speed_s8;
                        case focus_speed_s8: return (int)(unsigned)infrared_correction_u8;
                        case infrared_correction_u8: return (int)(unsigned)white_balance_u8;
                        case white_balance_u8: return (int)(unsigned)red_gain_u8;
                        case red_gain_u8: return (int)(unsigned)blue_gain_u8;
                        case blue_gain_u8: return (int)(unsigned)automatic_exposure_u8;
                        case automatic_exposure_u8: return (int)(unsigned)shutter_u8;
                        case shutter_u8: return (int)(unsigned)iris_u8;
                        case iris_u8: return (int)(unsigned)gain_u8;
                        case gain_u8: return (int)(unsigned)bright_u8;
                        case bright_u8: return (int)(unsigned)backlight_compensation_u8;
                        case backlight_compensation_u8: return (int)(unsigned)defog_u8;
                        case defog_u8: return (int)(unsigned)high_resolution_mode_u8;
                        case high_resolution_mode_u8: return (int)(unsigned)mirror_u8;
                        case mirror_u8: return (int)(unsigned)black_white_u8;
                        case black_white_u8: return (int)(unsigned)flip_u8;
                        case flip_u8: return (int)(unsigned)infrared_mode_u8;
                        case infrared_mode_u8: return (int)(unsigned)auto_infrared_mode_u8;
                        case auto_infrared_mode_u8: return (int)(unsigned)auto_infrared_mode_threshold_u8;
                        case auto_infrared_mode_threshold_u8: return (int)(unsigned)stabilizer_u8;
                        case stabilizer_u8: return (int)(unsigned)color_enhance_u8;
                        case color_enhance_u8: return (int)(unsigned)color_enhance_threshold_level_u8;
                        case color_enhance_threshold_level_u8: return (int)(unsigned)color_enhance_hysteresis_width_u8;
                        case color_enhance_hysteresis_width_u8: return (int)(unsigned)color_enhance_fixed_color_y_of_high_intensity_side_u8;
                        case color_enhance_fixed_color_y_of_high_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_cr_of_high_intensity_side_u8;
                        case color_enhance_fixed_color_cr_of_high_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_cb_of_high_intensity_side_u8;
                        case color_enhance_fixed_color_cb_of_high_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_y_of_low_intensity_side_u8;
                        case color_enhance_fixed_color_y_of_low_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_cr_of_low_intensity_side_u8;
                        case color_enhance_fixed_color_cr_of_low_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_cb_of_low_intensity_side_u8;
                        case color_enhance_fixed_color_cb_of_low_intensity_side_u8: return (int)(unsigned)zoom_direct_position_s16;
                    }
                    return -1;
                }
    

                static
                int reg_get_prev( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case voltage_y_s8: return (int)(unsigned)voltage_x_s8;
                        case camera_power_u8: return (int)(unsigned)voltage_y_s8;
                        case digital_zoom_u8: return (int)(unsigned)camera_power_u8;
                        case auto_focus_u8: return (int)(unsigned)digital_zoom_u8;
                        case zoom_speed_s8: return (int)(unsigned)auto_focus_u8;
                        case focus_speed_s8: return (int)(unsigned)zoom_speed_s8;
                        case infrared_correction_u8: return (int)(unsigned)focus_speed_s8;
                        case white_balance_u8: return (int)(unsigned)infrared_correction_u8;
                        case red_gain_u8: return (int)(unsigned)white_balance_u8;
                        case blue_gain_u8: return (int)(unsigned)red_gain_u8;
                        case automatic_exposure_u8: return (int)(unsigned)blue_gain_u8;
                        case shutter_u8: return (int)(unsigned)automatic_exposure_u8;
                        case iris_u8: return (int)(unsigned)shutter_u8;
                        case gain_u8: return (int)(unsigned)iris_u8;
                        case bright_u8: return (int)(unsigned)gain_u8;
                        case backlight_compensation_u8: return (int)(unsigned)bright_u8;
                        case defog_u8: return (int)(unsigned)backlight_compensation_u8;
                        case high_resolution_mode_u8: return (int)(unsigned)defog_u8;
                        case mirror_u8: return (int)(unsigned)high_resolution_mode_u8;
                        case black_white_u8: return (int)(unsigned)mirror_u8;
                        case flip_u8: return (int)(unsigned)black_white_u8;
                        case infrared_mode_u8: return (int)(unsigned)flip_u8;
                        case auto_infrared_mode_u8: return (int)(unsigned)infrared_mode_u8;
                        case auto_infrared_mode_threshold_u8: return (int)(unsigned)auto_infrared_mode_u8;
                        case stabilizer_u8: return (int)(unsigned)auto_infrared_mode_threshold_u8;
                        case color_enhance_u8: return (int)(unsigned)stabilizer_u8;
                        case color_enhance_threshold_level_u8: return (int)(unsigned)color_enhance_u8;
                        case color_enhance_hysteresis_width_u8: return (int)(unsigned)color_enhance_threshold_level_u8;
                        case color_enhance_fixed_color_y_of_high_intensity_side_u8: return (int)(unsigned)color_enhance_hysteresis_width_u8;
                        case color_enhance_fixed_color_cr_of_high_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_y_of_high_intensity_side_u8;
                        case color_enhance_fixed_color_cb_of_high_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_cr_of_high_intensity_side_u8;
                        case color_enhance_fixed_color_y_of_low_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_cb_of_high_intensity_side_u8;
                        case color_enhance_fixed_color_cr_of_low_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_y_of_low_intensity_side_u8;
                        case color_enhance_fixed_color_cb_of_low_intensity_side_u8: return (int)(unsigned)color_enhance_fixed_color_cr_of_low_intensity_side_u8;
                        case zoom_direct_position_s16: return (int)(unsigned)color_enhance_fixed_color_cb_of_low_intensity_side_u8;
                    }
                    return -1;
                }
    

                static
                int reg_get_first( )
                {
                    return voltage_x_s8;
                }
    

                int reg_get_last( )
                {
                    return zoom_direct_position_s16;
                }
    

            }; // struct meta
    

        }

        namespace ro
        {
            const uint8_t min = 0x00;

            //$ROBEGIN

            const uint8_t current_x_s8                                                = 0x00; /*   0 */ // текущий ток мотора оси X в попугаях
            const uint8_t current_y_s8                                                = 0x01; /*   1 */ // текущий ток мотора оси X в попугаях
            const uint8_t temperature_u8                                              = 0x02; /*   2 */ // температура
            const uint8_t status_u8                                                   = 0x03; /*   3 */ // статус платы

            //$ROEND

            const uint8_t max = 0x03;
    

            struct meta
            {

                static
                bool reg_type_check( uint8_t regNo, int regType, unsigned regSize )
                {
                    switch(regNo)
                    {
                        case current_x_s8:
                             if (regType!=RDLC_REGTYPE_INT) return false;
                             if (regSize!=1) return false;
                             return true;

                        case current_y_s8:
                             if (regType!=RDLC_REGTYPE_INT) return false;
                             if (regSize!=1) return false;
                             return true;

                        case temperature_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                        case status_u8:
                             if (regType!=RDLC_REGTYPE_UNSIGNED) return false;
                             if (regSize!=1) return false;
                             return true;

                    }
                    return false;
                }
    

                static
                const char* reg_get_name( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case current_x_s8: return "current_x_s8";
                        case current_y_s8: return "current_y_s8";
                        case temperature_u8: return "temperature_u8";
                        case status_u8: return "status_u8";
                    }
                    return 0;
                }
    

                static
                int reg_get_type( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case current_x_s8: return RDLC_REGTYPE_INT;
                        case current_y_s8: return RDLC_REGTYPE_INT;
                        case temperature_u8: return RDLC_REGTYPE_UNSIGNED;
                        case status_u8: return RDLC_REGTYPE_UNSIGNED;
                    }
                    return false;
                }
    

                static
                int reg_get_size( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case current_x_s8: return 1;
                        case current_y_s8: return 1;
                        case temperature_u8: return 1;
                        case status_u8: return 1;
                    }
                    return -1;
                }
    

                static
                int reg_get_next( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case current_x_s8: return (int)(unsigned)current_y_s8;
                        case current_y_s8: return (int)(unsigned)temperature_u8;
                        case temperature_u8: return (int)(unsigned)status_u8;
                    }
                    return -1;
                }
    

                static
                int reg_get_prev( uint8_t regNo )
                {
                    switch(regNo)
                    {
                        case current_y_s8: return (int)(unsigned)current_x_s8;
                        case temperature_u8: return (int)(unsigned)current_y_s8;
                        case status_u8: return (int)(unsigned)temperature_u8;
                    }
                    return -1;
                }
    

                static
                int reg_get_first( )
                {
                    return current_x_s8;
                }
    

                int reg_get_last( )
                {
                    return status_u8;
                }
    

            }; // struct meta
    

        }

    }
}
