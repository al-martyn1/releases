// periph_board.PrjPcb - Generator: h_conf

// periph_board.PrjPcb - Netlist_1

// MCU DD2 STM32F103T8U7 peripherals

// BATTERY_RS485

#define BATTERY_RS485_UART                            UART2
#define BATTERY_RS485_LEGACY_UART                     uart::uart2
#define USE_UART2                                     1
#define BATTERY_RS485_UART_TX_GPIO                    GPIOA
#define BATTERY_RS485_UART_TX_GPIO_PIN_NO             2
#define BATTERY_RS485_UART_TX_GPIO_PIN_ADDR           UMBA_PINADDR_PA2
#define BATTERY_RS485_UART_TX_GPIO_PIN_SOURCE         GPIO_PinSource2
#define BATTERY_RS485_UART_TX_GPIO_PIN_DIRECTION      UMBA_GPIO_DIRECTION_OUT

#define BATTERY_RS485_UART_RX_GPIO                    GPIOA
#define BATTERY_RS485_UART_RX_GPIO_PIN_NO             3
#define BATTERY_RS485_UART_RX_GPIO_PIN_ADDR           UMBA_PINADDR_PA3
#define BATTERY_RS485_UART_RX_GPIO_PIN_SOURCE         GPIO_PinSource3
#define BATTERY_RS485_UART_RX_GPIO_PIN_DIRECTION      UMBA_GPIO_DIRECTION_IN

#define BATTERY_RS485_DE_GPIO                         GPIOA
#define BATTERY_RS485_DE_GPIO_PIN_NO                  4
#define BATTERY_RS485_DE_GPIO_PIN_ADDR                UMBA_PINADDR_PA4
#define BATTERY_RS485_DE_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PA4, UMBA_GPIO_DIRECTION_OUT
#define BATTERY_RS485_DE_GPIO_PIN_SOURCE              GPIO_PinSource4
#define BATTERY_RS485_DE_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT




// DEBUG_TERMINAL_UART

#define DEBUG_TERMINAL_UART                           UART1
#define DEBUG_TERMINAL_LEGACY_UART                    uart::uart1
#define USE_UART1                                     1
#define DEBUG_TERMINAL_UART_TX_GPIO                   GPIOA
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO            9
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_ADDR          UMBA_PINADDR_PA9
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_SOURCE        GPIO_PinSource9
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_OUT

#define DEBUG_TERMINAL_UART_RX_GPIO                   GPIOA
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO            10
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_ADDR          UMBA_PINADDR_PA10
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_SOURCE        GPIO_PinSource10
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_IN




// MOTOR

#define MOTOR_nFLAG_GPIO                              GPIOA
#define MOTOR_nFLAG_GPIO_PIN_NO                       1
#define MOTOR_nFLAG_GPIO_PIN_ADDR                     UMBA_PINADDR_PA1
#define MOTOR_nFLAG_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PA1, UMBA_GPIO_DIRECTION_OUT
#define MOTOR_nFLAG_GPIO_PIN_SOURCE                   GPIO_PinSource1
#define MOTOR_nFLAG_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT

#define MOTOR_IN2_GPIO                                GPIOA
#define MOTOR_IN2_GPIO_PIN_NO                         6
#define MOTOR_IN2_GPIO_PIN_ADDR                       UMBA_PINADDR_PA6
#define MOTOR_IN2_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PA6, UMBA_GPIO_DIRECTION_OUT
#define MOTOR_IN2_GPIO_PIN_SOURCE                     GPIO_PinSource6
#define MOTOR_IN2_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define MOTOR_IN1_GPIO                                GPIOA
#define MOTOR_IN1_GPIO_PIN_NO                         7
#define MOTOR_IN1_GPIO_PIN_ADDR                       UMBA_PINADDR_PA7
#define MOTOR_IN1_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PA7, UMBA_GPIO_DIRECTION_OUT
#define MOTOR_IN1_GPIO_PIN_SOURCE                     GPIO_PinSource7
#define MOTOR_IN1_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define MOTOR_DIS1_GPIO                               GPIOB
#define MOTOR_DIS1_GPIO_PIN_NO                        0
#define MOTOR_DIS1_GPIO_PIN_ADDR                      UMBA_PINADDR_PB0
#define MOTOR_DIS1_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB0, UMBA_GPIO_DIRECTION_OUT
#define MOTOR_DIS1_GPIO_PIN_SOURCE                    GPIO_PinSource0
#define MOTOR_DIS1_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR_DIS2_GPIO                               GPIOB
#define MOTOR_DIS2_GPIO_PIN_NO                        1
#define MOTOR_DIS2_GPIO_PIN_ADDR                      UMBA_PINADDR_PB1
#define MOTOR_DIS2_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB1, UMBA_GPIO_DIRECTION_OUT
#define MOTOR_DIS2_GPIO_PIN_SOURCE                    GPIO_PinSource1
#define MOTOR_DIS2_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR_INV_GPIO                                GPIOB
#define MOTOR_INV_GPIO_PIN_NO                         2
#define MOTOR_INV_GPIO_PIN_ADDR                       UMBA_PINADDR_PB2
#define MOTOR_INV_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB2, UMBA_GPIO_DIRECTION_OUT
#define MOTOR_INV_GPIO_PIN_SOURCE                     GPIO_PinSource2
#define MOTOR_INV_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define MOTOR_EN_GPIO                                 GPIOA
#define MOTOR_EN_GPIO_PIN_NO                          12
#define MOTOR_EN_GPIO_PIN_ADDR                        UMBA_PINADDR_PA12
#define MOTOR_EN_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PA12, UMBA_GPIO_DIRECTION_OUT
#define MOTOR_EN_GPIO_PIN_SOURCE                      GPIO_PinSource12
#define MOTOR_EN_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT




// MOTOR_CURRENT_SENSOR

#define MOTOR_CURRENT_SENSOR_SHDN_GPIO                GPIOA
#define MOTOR_CURRENT_SENSOR_SHDN_GPIO_PIN_NO         0
#define MOTOR_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR       UMBA_PINADDR_PA0
#define MOTOR_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR_DIR    UMBA_PINADDR_PA0, UMBA_GPIO_DIRECTION_OUT
#define MOTOR_CURRENT_SENSOR_SHDN_GPIO_PIN_SOURCE     GPIO_PinSource0
#define MOTOR_CURRENT_SENSOR_SHDN_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_OUT

#define MOTOR_CURRENT_SENSOR_ADC_GPIO                 GPIOA
#define MOTOR_CURRENT_SENSOR_ADC_GPIO_PIN_NO          5
#define MOTOR_CURRENT_SENSOR_ADC_GPIO_PIN_ADDR        UMBA_PINADDR_PA5
#define MOTOR_CURRENT_SENSOR_ADC_GPIO_PIN_SOURCE      GPIO_PinSource5
#define MOTOR_CURRENT_SENSOR_ADC_CHANNEL              ADC_Channel_5
#define MOTOR_CURRENT_SENSOR_ADC_CHANNEL_NO           5
#define MOTOR_CURRENT_SENSOR_ADC                      ADC1
#define USE_ADC1                                      1




// PSENSOR

#define PSENSOR_I2C                                   I2C1
#define USE_I2C1                                      1
#define PSENSOR_I2C_SCL_GPIO                          GPIOB
#define PSENSOR_I2C_SCL_GPIO_PIN_NO                   6
#define PSENSOR_I2C_SCL_GPIO_PIN_ADDR                 UMBA_PINADDR_PB6
#define PSENSOR_I2C_SCL_GPIO_PIN_SOURCE               GPIO_PinSource6

#define PSENSOR_I2C_SDA_GPIO                          GPIOB
#define PSENSOR_I2C_SDA_GPIO_PIN_NO                   7
#define PSENSOR_I2C_SDA_GPIO_PIN_ADDR                 UMBA_PINADDR_PB7
#define PSENSOR_I2C_SDA_GPIO_PIN_SOURCE               GPIO_PinSource7




// Unclassified


#define ESC_PWM_GPIO                                  GPIOA
#define ESC_PWM_GPIO_PIN_NO                           11
#define ESC_PWM_GPIO_PIN_ADDR                         UMBA_PINADDR_PA11
#define ESC_PWM_GPIO_PIN_SOURCE                       GPIO_PinSource11
#define ESC_PWM_TIM_CHANNEL                           TIM_Channel_4
#define ESC_PWM_TIM_CHANNEL_NO                        4
#define ESC_PWM_TIM                                   TIM1
#define USE_TIM1                                      1

#define LED_ERROR_GPIO                                GPIOB
#define LED_ERROR_GPIO_PIN_NO                         5
#define LED_ERROR_GPIO_PIN_ADDR                       UMBA_PINADDR_PB5
#define LED_ERROR_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB5, UMBA_GPIO_DIRECTION_OUT
#define LED_ERROR_GPIO_PIN_SOURCE                     GPIO_PinSource5
#define LED_ERROR_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define LED_LINK_GPIO                                 GPIOB
#define LED_LINK_GPIO_PIN_NO                          4
#define LED_LINK_GPIO_PIN_ADDR                        UMBA_PINADDR_PB4
#define LED_LINK_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PB4, UMBA_GPIO_DIRECTION_OUT
#define LED_LINK_GPIO_PIN_SOURCE                      GPIO_PinSource4
#define LED_LINK_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT




