// BLDC_Periph.PrjPcb - Generator: h_conf

// BLDC_Periph.PrjPcb - Netlist_1

// MCU DD1 STM32F303VD peripherals

// CAN

#define CAN_LBK_GPIO                                  GPIOA
#define CAN_LBK_GPIO_PIN_NO                           10
#define CAN_LBK_GPIO_PIN_ADDR                         UMBA_PINADDR_PA10
#define CAN_LBK_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PA10, UMBA_GPIO_DIRECTION_OUT
#define CAN_LBK_GPIO_PIN_SOURCE                       GPIO_PinSource10
#define CAN_LBK_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAN_CAN                                       CAN
#define USE_CAN                                       1
#define CAN_CAN_RX_GPIO                               GPIOA
#define CAN_CAN_RX_GPIO_PIN_NO                        11
#define CAN_CAN_RX_GPIO_PIN_ADDR                      UMBA_PINADDR_PA11
#define CAN_CAN_RX_GPIO_PIN_SOURCE                    GPIO_PinSource11
#define CAN_CAN_RX_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN

#define CAN_CAN_TX_GPIO                               GPIOA
#define CAN_CAN_TX_GPIO_PIN_NO                        12
#define CAN_CAN_TX_GPIO_PIN_ADDR                      UMBA_PINADDR_PA12
#define CAN_CAN_TX_GPIO_PIN_SOURCE                    GPIO_PinSource12
#define CAN_CAN_TX_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_IN




// MAX6954

#define MAX6954_CS_GPIO                               GPIOB
#define MAX6954_CS_GPIO_PIN_NO                        12
#define MAX6954_CS_GPIO_PIN_ADDR                      UMBA_PINADDR_PB12
#define MAX6954_CS_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT
#define MAX6954_CS_GPIO_PIN_SOURCE                    GPIO_PinSource12
#define MAX6954_CS_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MAX6954_SPI                                   SPI2
#define USE_SPI2                                      1
#define MAX6954_SPI_SCK_GPIO                          GPIOB
#define MAX6954_SPI_SCK_GPIO_PIN_NO                   13
#define MAX6954_SPI_SCK_GPIO_PIN_ADDR                 UMBA_PINADDR_PB13
#define MAX6954_SPI_SCK_GPIO_PIN_ADDR_DIR             UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT
#define MAX6954_SPI_SCK_GPIO_PIN_SOURCE               GPIO_PinSource13
#define MAX6954_SPI_SCK_GPIO_PIN_DIRECTION            UMBA_GPIO_DIRECTION_OUT

#define MAX6954_SPI_MISO_GPIO                         GPIOB
#define MAX6954_SPI_MISO_GPIO_PIN_NO                  14
#define MAX6954_SPI_MISO_GPIO_PIN_ADDR                UMBA_PINADDR_PB14
#define MAX6954_SPI_MISO_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PB14, UMBA_GPIO_DIRECTION_IN
#define MAX6954_SPI_MISO_GPIO_PIN_SOURCE              GPIO_PinSource14
#define MAX6954_SPI_MISO_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_IN

#define MAX6954_SPI_MOSI_GPIO                         GPIOB
#define MAX6954_SPI_MOSI_GPIO_PIN_NO                  15
#define MAX6954_SPI_MOSI_GPIO_PIN_ADDR                UMBA_PINADDR_PB15
#define MAX6954_SPI_MOSI_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PB15, UMBA_GPIO_DIRECTION_OUT
#define MAX6954_SPI_MOSI_GPIO_PIN_SOURCE              GPIO_PinSource15
#define MAX6954_SPI_MOSI_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT




// MCU1_UART

#define MCU1_UART_RX_GPIO                             GPIOC
#define MCU1_UART_RX_GPIO_PIN_NO                      4
#define MCU1_UART_RX_GPIO_PIN_ADDR                    UMBA_PINADDR_PC4
#define MCU1_UART_RX_GPIO_PIN_SOURCE                  GPIO_PinSource4
#define MCU1_UART_RX_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_IN

#define MCU1_UART_TX_GPIO                             GPIOC
#define MCU1_UART_TX_GPIO_PIN_NO                      5
#define MCU1_UART_TX_GPIO_PIN_ADDR                    UMBA_PINADDR_PC5
#define MCU1_UART_TX_GPIO_PIN_SOURCE                  GPIO_PinSource5
#define MCU1_UART_TX_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT




// Unclassified

#define ENC_A_TIM_GPIO                                GPIOB
#define ENC_A_TIM_GPIO_PIN_NO                         5
#define ENC_A_TIM_GPIO_PIN_ADDR                       UMBA_PINADDR_PB5
#define ENC_A_TIM_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB5, UMBA_GPIO_DIRECTION_OUT
#define ENC_A_TIM_GPIO_PIN_SOURCE                     GPIO_PinSource5
#define ENC_A_TIM_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define ENC_B_TIM_GPIO                                GPIOB
#define ENC_B_TIM_GPIO_PIN_NO                         6
#define ENC_B_TIM_GPIO_PIN_ADDR                       UMBA_PINADDR_PB6
#define ENC_B_TIM_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB6, UMBA_GPIO_DIRECTION_OUT
#define ENC_B_TIM_GPIO_PIN_SOURCE                     GPIO_PinSource6
#define ENC_B_TIM_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define VOLTAGE_VCC_GPIO                              GPIOC
#define VOLTAGE_VCC_GPIO_PIN_NO                       0
#define VOLTAGE_VCC_GPIO_PIN_ADDR                     UMBA_PINADDR_PC0
#define VOLTAGE_VCC_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PC0, UMBA_GPIO_DIRECTION_OUT
#define VOLTAGE_VCC_GPIO_PIN_SOURCE                   GPIO_PinSource0
#define VOLTAGE_VCC_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT

#define AUTO_BIT_RATE_GPIO                            GPIOD
#define AUTO_BIT_RATE_GPIO_PIN_NO                     10
#define AUTO_BIT_RATE_GPIO_PIN_ADDR                   UMBA_PINADDR_PD10
#define AUTO_BIT_RATE_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PD10, UMBA_GPIO_DIRECTION_OUT
#define AUTO_BIT_RATE_GPIO_PIN_SOURCE                 GPIO_PinSource10
#define AUTO_BIT_RATE_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT

#define TEMP_GPIO                                     GPIOB
#define TEMP_GPIO_PIN_NO                              11
#define TEMP_GPIO_PIN_ADDR                            UMBA_PINADDR_PB11
#define TEMP_GPIO_PIN_ADDR_DIR                        UMBA_PINADDR_PB11, UMBA_GPIO_DIRECTION_OUT
#define TEMP_GPIO_PIN_SOURCE                          GPIO_PinSource11
#define TEMP_GPIO_PIN_DIRECTION                       UMBA_GPIO_DIRECTION_OUT

#define SPI_IRQ_GPIO                                  GPIOC
#define SPI_IRQ_GPIO_PIN_NO                           7
#define SPI_IRQ_GPIO_PIN_ADDR                         UMBA_PINADDR_PC7
#define SPI_IRQ_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PC7, UMBA_GPIO_DIRECTION_OUT
#define SPI_IRQ_GPIO_PIN_SOURCE                       GPIO_PinSource7
#define SPI_IRQ_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define SPI_CLK_GPIO                                  GPIOC
#define SPI_CLK_GPIO_PIN_NO                           10
#define SPI_CLK_GPIO_PIN_ADDR                         UMBA_PINADDR_PC10
#define SPI_CLK_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PC10, UMBA_GPIO_DIRECTION_OUT
#define SPI_CLK_GPIO_PIN_SOURCE                       GPIO_PinSource10
#define SPI_CLK_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define SPI_MISO_GPIO                                 GPIOC
#define SPI_MISO_GPIO_PIN_NO                          11
#define SPI_MISO_GPIO_PIN_ADDR                        UMBA_PINADDR_PC11
#define SPI_MISO_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PC11, UMBA_GPIO_DIRECTION_OUT
#define SPI_MISO_GPIO_PIN_SOURCE                      GPIO_PinSource11
#define SPI_MISO_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define SPI_MOSI_GPIO                                 GPIOC
#define SPI_MOSI_GPIO_PIN_NO                          12
#define SPI_MOSI_GPIO_PIN_ADDR                        UMBA_PINADDR_PC12
#define SPI_MOSI_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PC12, UMBA_GPIO_DIRECTION_OUT
#define SPI_MOSI_GPIO_PIN_SOURCE                      GPIO_PinSource12
#define SPI_MOSI_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define STO_OUT_GPIO                                  GPIOD
#define STO_OUT_GPIO_PIN_NO                           2
#define STO_OUT_GPIO_PIN_ADDR                         UMBA_PINADDR_PD2
#define STO_OUT_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PD2, UMBA_GPIO_DIRECTION_OUT
#define STO_OUT_GPIO_PIN_SOURCE                       GPIO_PinSource2
#define STO_OUT_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define MCU1_LINK_DE_GPIO                             GPIOA
#define MCU1_LINK_DE_GPIO_PIN_NO                      2
#define MCU1_LINK_DE_GPIO_PIN_ADDR                    UMBA_PINADDR_PA2
#define MCU1_LINK_DE_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PA2, UMBA_GPIO_DIRECTION_OUT
#define MCU1_LINK_DE_GPIO_PIN_SOURCE                  GPIO_PinSource2
#define MCU1_LINK_DE_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define STO_IN1_GPIO                                  GPIOD
#define STO_IN1_GPIO_PIN_NO                           0
#define STO_IN1_GPIO_PIN_ADDR                         UMBA_PINADDR_PD0
#define STO_IN1_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PD0, UMBA_GPIO_DIRECTION_OUT
#define STO_IN1_GPIO_PIN_SOURCE                       GPIO_PinSource0
#define STO_IN1_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define SPI_CS1_GPIO                                  GPIOC
#define SPI_CS1_GPIO_PIN_NO                           9
#define SPI_CS1_GPIO_PIN_ADDR                         UMBA_PINADDR_PC9
#define SPI_CS1_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PC9, UMBA_GPIO_DIRECTION_OUT
#define SPI_CS1_GPIO_PIN_SOURCE                       GPIO_PinSource9
#define SPI_CS1_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define ANIN1PLUS_GPIO                                GPIOA
#define ANIN1PLUS_GPIO_PIN_NO                         4
#define ANIN1PLUS_GPIO_PIN_ADDR                       UMBA_PINADDR_PA4
#define ANIN1PLUS_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PA4, UMBA_GPIO_DIRECTION_OUT
#define ANIN1PLUS_GPIO_PIN_SOURCE                     GPIO_PinSource4
#define ANIN1PLUS_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define ANOUT1_GPIO                                   GPIOE
#define ANOUT1_GPIO_PIN_NO                            9
#define ANOUT1_GPIO_PIN_ADDR                          UMBA_PINADDR_PE9
#define ANOUT1_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PE9, UMBA_GPIO_DIRECTION_OUT
#define ANOUT1_GPIO_PIN_SOURCE                        GPIO_PinSource9
#define ANOUT1_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define DIGOUT1_GPIO                                  GPIOE
#define DIGOUT1_GPIO_PIN_NO                           12
#define DIGOUT1_GPIO_PIN_ADDR                         UMBA_PINADDR_PE12
#define DIGOUT1_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PE12, UMBA_GPIO_DIRECTION_OUT
#define DIGOUT1_GPIO_PIN_SOURCE                       GPIO_PinSource12
#define DIGOUT1_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define DIGIN1_GPIO                                   GPIOB
#define DIGIN1_GPIO_PIN_NO                            10
#define DIGIN1_GPIO_PIN_ADDR                          UMBA_PINADDR_PB10
#define DIGIN1_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PB10, UMBA_GPIO_DIRECTION_OUT
#define DIGIN1_GPIO_PIN_SOURCE                        GPIO_PinSource10
#define DIGIN1_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define STO_IN2_GPIO                                  GPIOD
#define STO_IN2_GPIO_PIN_NO                           1
#define STO_IN2_GPIO_PIN_ADDR                         UMBA_PINADDR_PD1
#define STO_IN2_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PD1, UMBA_GPIO_DIRECTION_OUT
#define STO_IN2_GPIO_PIN_SOURCE                       GPIO_PinSource1
#define STO_IN2_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define SPI_CS2_GPIO                                  GPIOC
#define SPI_CS2_GPIO_PIN_NO                           8
#define SPI_CS2_GPIO_PIN_ADDR                         UMBA_PINADDR_PC8
#define SPI_CS2_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PC8, UMBA_GPIO_DIRECTION_OUT
#define SPI_CS2_GPIO_PIN_SOURCE                       GPIO_PinSource8
#define SPI_CS2_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define ANIN2PLUS_GPIO                                GPIOA
#define ANIN2PLUS_GPIO_PIN_NO                         5
#define ANIN2PLUS_GPIO_PIN_ADDR                       UMBA_PINADDR_PA5
#define ANIN2PLUS_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PA5, UMBA_GPIO_DIRECTION_OUT
#define ANIN2PLUS_GPIO_PIN_SOURCE                     GPIO_PinSource5
#define ANIN2PLUS_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define ANOUT2_GPIO                                   GPIOE
#define ANOUT2_GPIO_PIN_NO                            10
#define ANOUT2_GPIO_PIN_ADDR                          UMBA_PINADDR_PE10
#define ANOUT2_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PE10, UMBA_GPIO_DIRECTION_OUT
#define ANOUT2_GPIO_PIN_SOURCE                        GPIO_PinSource10
#define ANOUT2_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define DIGOUT2_GPIO                                  GPIOE
#define DIGOUT2_GPIO_PIN_NO                           11
#define DIGOUT2_GPIO_PIN_ADDR                         UMBA_PINADDR_PE11
#define DIGOUT2_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PE11, UMBA_GPIO_DIRECTION_OUT
#define DIGOUT2_GPIO_PIN_SOURCE                       GPIO_PinSource11
#define DIGOUT2_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define DIGIN2_GPIO                                   GPIOE
#define DIGIN2_GPIO_PIN_NO                            15
#define DIGIN2_GPIO_PIN_ADDR                          UMBA_PINADDR_PE15
#define DIGIN2_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PE15, UMBA_GPIO_DIRECTION_OUT
#define DIGIN2_GPIO_PIN_SOURCE                        GPIO_PinSource15
#define DIGIN2_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define DIGIN3_GPIO                                   GPIOE
#define DIGIN3_GPIO_PIN_NO                            13
#define DIGIN3_GPIO_PIN_ADDR                          UMBA_PINADDR_PE13
#define DIGIN3_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PE13, UMBA_GPIO_DIRECTION_OUT
#define DIGIN3_GPIO_PIN_SOURCE                        GPIO_PinSource13
#define DIGIN3_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define DIGIN4_GPIO                                   GPIOE
#define DIGIN4_GPIO_PIN_NO                            14
#define DIGIN4_GPIO_PIN_ADDR                          UMBA_PINADDR_PE14
#define DIGIN4_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PE14, UMBA_GPIO_DIRECTION_OUT
#define DIGIN4_GPIO_PIN_SOURCE                        GPIO_PinSource14
#define DIGIN4_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define VOLTAGE5V_GPIO                                GPIOC
#define VOLTAGE5V_GPIO_PIN_NO                         1
#define VOLTAGE5V_GPIO_PIN_ADDR                       UMBA_PINADDR_PC1
#define VOLTAGE5V_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PC1, UMBA_GPIO_DIRECTION_OUT
#define VOLTAGE5V_GPIO_PIN_SOURCE                     GPIO_PinSource1
#define VOLTAGE5V_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT




