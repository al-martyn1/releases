#pragma once

#include "umba.h"
#include "periph/stm32_traits.h"

//#include "project_config.h"
//#include "callbacks/callbacks.h"

//Data Format
//| sign | out temp | reserved | fault | sign | in temp | reserved | SCV | SCG | OC | - meaning
//|  31  | 30...18  |    17    |  16   |  15  | 14...4  |     3    |  2  |  1  | 0  | - bit number
//
// SCV - thermocouple short-circuit to vcc
// SCG - thermocouple short-circuit to gnd
// OC  - thermocouple open-circuit( connection lost )
//
// CPOL = LOW, CPHA = 1
namespace temp_control
{
    void defaultWait( void );
    void defaultDelay( void );
    
    class Thermocouples
    {
    public:
        
        static Thermocouples & getInstance( void )
        {
            static Thermocouples couples;
            return couples;
        }
            
        void init( void )
        {
            //m_waiter = CALLBACK_BIND( defaultWait );
            //m_delayer = CALLBACK_BIND( defaultDelay );
            initPin();
            initSpi();
            m_isInited = true;
        }        
        void init( /*callback::VoidCallback delayHandler, callback::VoidCallback waitHandler*/ )
        {
            //m_waiter = waitHandler;
            //m_delayer = delayHandler;
            
            initPin();
            initSpi();
            m_isInited = true;
        }
        
        void work( void );
        
        bool getFault( uint8_t num )
        {
            return m_fault[num];
        }
        bool getSCV( uint8_t num )
        {
            return m_scv[num];
        }
        bool getSCG( uint8_t num )
        {
            return m_scg[num];
        }
        bool getOC( uint8_t num )
        {
            return m_oc[num];
        }
        float getExternal( uint8_t num )
        {
            return m_externalTemp[num];
        }
        float getInternal( uint8_t num )
        {
            return m_internalTemp[num];
        }
        
    private:
        
        Thermocouples( void ) = default;
    
        uint32_t sendSpiData( uint8_t num );
    
        void initPin(void);
        void initSpi(void);
            
        //callback::VoidCallback m_waiter;
        //callback::VoidCallback m_delayer;
        
        float m_externalTemp[2];
        float m_internalTemp[2];
    
        bool m_fault[2];
        bool m_scv[2];
        bool m_scg[2];
        bool m_oc[2];
    
        bool m_isInited = false;
            
        //const uint16_t cs_1_pin = GPIO_Pin_0;
        //const uint16_t cs_2_pin = GPIO_Pin_1;
        const uint16_t cs_1_pin = GPIO_Pin_11;
        const uint16_t cs_2_pin = GPIO_Pin_12;
        GPIO_TypeDef * const cs_port = HOTEND1_TERMCPL_CS_GPIO; // HOTEND2_TERMCPL_CS_GPIO is the same
    };
}
