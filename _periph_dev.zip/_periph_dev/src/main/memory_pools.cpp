#ifndef _WIN32
    #include "luart/uart_handle.h"
#endif

#include "vgpio/i_virtual_gpio.h"
#include "vgpio/stm32_gpio.h"
#include "vgpio/virtual_gpio.h"
#include "umba/time_service.h"

#include "periph/keyboard.h"

#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/allocator.h"
#include "umba/i_memory_pool.h"
#include "umba/memory_pools_impl.h"

#include <vector>

#include "containers/static_list.h"
#include "umba/bits.h"

#include <stdlib.h>
#include <vector>
#include <set>


using namespace umba::omanip;


#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
//#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<>   charWritter = umba::LegacyUartCharWriter<>(uart::uart3).setTextMode(true).setAnsiTerminalMode(true);
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  lout(&charWritter);



unsigned calcIdx(unsigned val, unsigned shift)
{
    unsigned res = val >> shift;
    if ((res << shift) != val)
        ++res;
    return res;
}



template<typename IterType>
void showRange( const char *pTitle, IterType first, IterType last )
{
    if (pTitle)
        lout<<pTitle<<": ";

    bool bFirst = true;

    for( ; first!=last; ++first)
    {
        if (!bFirst)
            lout << ", ";
        lout << *first;

        //auto info = first.getListItemInfo();
        //auto selfNo = first.getSelfNo();
        //lout << "(#" << selfNo<<",p"<<info.prev << ",n" << info.next << ")";
        bFirst = false;
    }

    lout<<umba::omanip::endl;
}

template<typename ContainerType>
void showContainer( const char *pTitle, const ContainerType &c )
{
    showRange( pTitle, c.begin(), c.end() );
}


unsigned randLog2()
{
    return umba::bits::getLog2((unsigned)rand());
}

unsigned randLog2Inv()
{
    return 16 - randLog2();
}


int main(void)
{

    uint64_t ui64 = 0;

    umba::time_service::init();
    umba::time_service::start();
    
#ifndef _WIN32
    uart::uart3.init( uart::Pins::UART3_PB10_PB11, 460800 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 307200 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 691200 );
#endif

/*
    unsigned numChunks = 4;
    unsigned chunkStartSize = 8;

    for (unsigned i = 1; i != 4097; ++i)
    {
        size_t blockSize = 0;
        size_t idx = umba::memory_pool_impl::calulatePoolIndex( i, &blockSize, numChunks, chunkStartSize );
        lout<<"Requested "<<i<<" bytes. Pool index: "<<idx<<", block size: "<<blockSize<<endl;
    }
*/


/*
    umba::RawMemPtr p1 = umba::globalStaticMemoryPool->allocateMemoryBlock(10, 8);
    umba::RawMemPtr p2 = umba::globalStaticMemoryPool->allocateMemoryBlock(40, 4);

    bool res = umba::globalStaticMemoryPool->expandMemoryBlock( p2, 100 );

    if (umba::globalStaticMemoryPool->deallocateMemoryBlock(p1))
        p1 = 0;

    if (umba::globalStaticMemoryPool->deallocateMemoryBlock(p2))
        p2 = 0;

    if (umba::globalStaticMemoryPool->deallocateMemoryBlock(p1))
        p1 = 0;
*/
    lout<<"\n\n";

    //lout<<"    // ";
    #if defined(_WIN64)
    lout<<"x64/";
    #else
    lout<<"x86/";
    #endif

    #if defined(NDEBUG)
    lout<<"Release";
    #else
    lout<<"Debug";
    #endif

    lout<<umba::omanip::endl;


    #ifdef _WIN32

    lout<<"RAND_MAX: "<<RAND_MAX<<"\n";

    srand( 0 );
    rand();

/*
    size_t allocationLim    = 50000;
    size_t totalAllocated   = 0;
    size_t totalAllocations = 0;

    size_t distributionLog[257] = { 0 };

    while( true )
    {
        size_t numBytes = randLog2Inv() * randLog2Inv();
        distributionLog[numBytes]++;
        numBytes *= 8;

        if ((totalAllocated + numBytes) > allocationLim)
           break;

        totalAllocations++;

        totalAllocated += numBytes;

        //lout<<"Allocate "<<numBytes<<" bytes\n";
    }

    lout<<"Total allocations: "<<totalAllocations<<umba::omanip::endl;


    lout<<"\n\nDistribution:\n";
    for(unsigned i=0; i!=256; ++i)
    {
        unsigned distibutionValue = umba::bits::getLog2(distributionLog[i]);
        if (distributionLog[i])
           distibutionValue += 1;

        lout<<umba::omanip::width(4)<<(i*8)<<" : "
            <<umba::omanip::width(4)<<distributionLog[i]
            <<"  |"
            <<umba::omanip::width( distibutionValue + 1 )<<"*"<<umba::omanip::endl;
    }
*/

    struct AllocTestInfo
    {
        void*    blockAddr = 0;
        size_t   blockSize = 0;
    };

    const size_t total_number_of_random_blocks = (size_t)RAND_MAX;

    std::vector< AllocTestInfo > blocks;
    blocks.reserve(total_number_of_random_blocks);

    size_t totalPlannedForAlloc = 0;

    for( size_t i=0; i!=total_number_of_random_blocks; ++i)
    {
        AllocTestInfo allocTestInfo;
        allocTestInfo.blockSize = randLog2Inv() * randLog2Inv();
        allocTestInfo.blockAddr = 0;
        blocks.push_back( allocTestInfo );
        totalPlannedForAlloc += allocTestInfo.blockSize;
    }

    lout<<"Planned for alloc: "<<totalPlannedForAlloc<<" bytes"<<umba::omanip::endl<<umba::omanip::endl;

    size_t totalAllocated       = 0;
    size_t currentlyAllocated   = 0;
    size_t totalAllocations     = 0;
    size_t totalDeallocations   = 0;

    std::set< void* >  allocatedBlocks;

    //size_t tryNo = 0;

    for( ; totalAllocations<1000*1000;  )
    {
        size_t idx = (size_t)rand();
        if (!blocks[idx].blockAddr)
        {
            blocks[idx].blockAddr = umba::globalHeapMemoryPool->allocateMemoryBlock( blocks[idx].blockSize, 0 /* alignment */ );
            if (!blocks[idx].blockAddr)
                break;
            lout<<"+ "<<blocks[idx].blockAddr<<" - "<<blocks[idx].blockSize<<" bytes"<<", allocation#: "<<totalAllocations<<umba::omanip::endl;
            if (allocatedBlocks.find(blocks[idx].blockAddr)!=allocatedBlocks.end())
            {
                lout<<"    !!! Block already allocated"<<umba::omanip::endl;
            }

            allocatedBlocks.insert(blocks[idx].blockAddr);

            *((size_t*)blocks[idx].blockAddr) = totalAllocations;
            //blocks[idx].blockSize;

            totalAllocations++;
            totalAllocated     += blocks[idx].blockSize;
            currentlyAllocated += blocks[idx].blockSize;
        }
        else
        {
            size_t no = *((size_t*)blocks[idx].blockAddr);
            lout<<"- "<<blocks[idx].blockAddr<<" - "<<blocks[idx].blockSize<<" bytes"<<", allocation #: "<<no<<umba::omanip::endl;
            if (allocatedBlocks.find(blocks[idx].blockAddr)==allocatedBlocks.end())
            {
                lout<<"    !!! Block NOT allocated"<<umba::omanip::endl;
            }

            allocatedBlocks.erase(blocks[idx].blockAddr);

            umba::globalHeapMemoryPool->deallocateMemoryBlock( blocks[idx].blockAddr );
            currentlyAllocated -= blocks[idx].blockSize;
        }
    }

    lout<<"Total allocations  : "<<totalAllocations<<"\n";
    lout<<"Total deallocations: "<<totalDeallocations<<"\n";
    lout<<"Total allocated    : "<<totalAllocated<<"\n";
    lout<<"Currently allocated: "<<currentlyAllocated<<umba::omanip::endl;

    #endif






/*

    #if defined(_WIN64)
    lout<<"    // x64/";
    #else
    lout<<"    // x86/";
    #endif

    #if defined(NDEBUG)
    lout<<"Release";
    #else
    lout<<"Debug";
    #endif

    lout<<umba::omanip::endl;

    lout<<"    // sizeof(umba::RawMemPtr)                    : "<<sizeof(umba::RawMemPtr)<<umba::omanip::endl;
    lout<<"    // sizeof(size_t)                             : "<<sizeof(size_t)<<umba::omanip::endl;
    lout<<"    // sizeof(GrowingMemoryPoolChunkInfo)         : "<<sizeof(umba::GrowingMemoryPoolChunkInfo)<<umba::omanip::endl;
    lout<<"    // sizeof(FixedSizeMemoryPool)                : "<<sizeof(umba::FixedSizeMemoryPool)<<umba::omanip::endl;
    lout<<"    // default_alignment                          : "<<umba::memory_pool_impl::default_alignment<<umba::omanip::endl;
    lout<<"    // Service payload for growing pool allocation: "<<umba::memory_pool_impl::calcGrowingPoolServicePayload()<<umba::omanip::endl;
    lout<<"    // Service payload of fixed pool object       : "<<umba::memory_pool_impl::calcFixedPoolObjectSizePayload()<<umba::omanip::endl;
    lout<<"    // Service payload for one fixed pool         : "<<umba::memory_pool_impl::calcSingleFixedPoolServicePayload()<<umba::omanip::endl;

    
    

    lout<<umba::omanip::coloring(umba::term::colors::green)<<"coloring(umba::term::colors::green)"<<umba::omanip::endl;
    lout<<umba::omanip::coloring(umba::ColoringLevel::emergency)<<"coloring(umba::ColoringLevel::emergency)"<<umba::omanip::endl;
    lout<<umba::omanip::emergency<<"emergency"<<umba::omanip::endl;
    lout<<umba::omanip::alert    <<"alert    "<<umba::omanip::endl;
    lout<<umba::omanip::critical <<"critical "<<umba::omanip::endl;
    lout<<umba::omanip::error    <<"error    "<<umba::omanip::endl;
    lout<<umba::omanip::warning  <<"warning  "<<umba::omanip::endl;
    lout<<umba::omanip::notice   <<"notice   "<<umba::omanip::endl;
    lout<<umba::omanip::info     <<"info     "<<umba::omanip::endl;
    lout<<umba::omanip::debug    <<"debug    "<<umba::omanip::endl;
    lout<<umba::omanip::good     <<"good     "<<umba::omanip::endl;
    lout<<umba::omanip::normal   <<"normal   "<<umba::omanip::endl;

    lout<<"\n\n";
*/


#ifndef _WIN32

    while(1)
    {
    }
#endif

    return 0;
}



