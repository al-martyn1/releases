#pragma once


class SoftIntervalMs
{

public:

    SoftIntervalMs( umba::time_service::TimeTick i)
      : m_interval(i)
      , m_lastTick(umba::time_service::getCurTimeMs())
    {

    }

    void reset()
    {
        m_lastTick = umba::time_service::getCurTimeMs();
    }

    bool checkTimedout()
    {
        umba::time_service::TimeTick tck = umba::time_service::getCurTimeMs();
        if ((tck-m_lastTick) < m_interval)
            return false;
        m_lastTick = tck; 
        return true;
    }

protected:

    umba::time_service::TimeTick m_interval;
    umba::time_service::TimeTick m_lastTick;
}; // class SoftIntervalMs

