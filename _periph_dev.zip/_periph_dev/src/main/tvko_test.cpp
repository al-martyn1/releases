#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"

#include "camera_task/camera_task.h"
#include "can/can_handle.h"
#include "cannabus/cannabus_slave_session.h"
#include "cannabus/cannabus_reg_table.h"

#include "rdlc_regtype.h"
#include "regs_tvko.h"
#include "cfg_tvko.h"

#include "periph/stm32_dac.h"
#include "periph/dac.h"


#if !defined(STM32F3_SERIES)
    #error "STM32F3_SERIES not defined"
#endif







//umba::SimpleFormatter  lout(&charWritter);


#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )



//umba::periph::GpioPin  motor1SpeedPin( PA4 );
//umba::periph::GpioPin  motor2SpeedPin( PA5 );

DECLARE_PIN( motor1In1Pin  , MOTOR1_IN1 );
DECLARE_PIN( motor1In2Pin  , MOTOR1_IN2 );

DECLARE_PIN( motor2In1Pin  , MOTOR2_IN1 );
DECLARE_PIN( motor2In2Pin  , MOTOR2_IN2 );


static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;



#define CON_UART DEBUG_TERMINAL_LEGACY_UART


void motorCtrl( umba::periph::GpioPin &motorIn1, umba::periph::GpioPin &motorIn2, int direction )
{
    if (direction<0)
    {
        motorIn1 = true;
        motorIn2 = false;
    }
    else if (direction>0)
    {
        motorIn1 = false;
        motorIn2 = true;
    }
    else
    {
        motorIn1 = false;
        motorIn2 = false;
    }
}


int stateMotor1 = 0;
int stateMotor2 = 0;

template< typename TSigned >
int8_t getDirection( TSigned s )
{
    if (!s) return 0;
    else if(s<0)
        return -1;
    return 1;
}


umba::periph::DacSimple dac1( MOTOR1_SPEED_DAC_CHANNEL_NO );
umba::periph::DacSimple dac2( MOTOR2_SPEED_DAC_CHANNEL_NO );



uint8_t getSpeedVal( int8_t motCtrl )
{
    if (motCtrl<0)
        motCtrl = -motCtrl;

    uint32_t res = (uint8_t)motCtrl;
    if (res > 100 )
       res = 100;
    res *= 250;
    res /= 100;
    return (uint8_t)res;
}


int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;

    static RegTable regTable;
    
    umba::time_service::delayMs(300);

    uint8_t address = 10;
    
    umba::periph::GpioPin canEnablePin(umba::periph::traits::GpioPinAddr({ GPIOA, 8 }), umba::periph::PinMode::gpio_out_pp);
    canEnablePin.connect();
    canEnablePin = false;

    dac1.connect();
    dac2.connect();


    //motor1SpeedPin.connect();
    //motor2SpeedPin.connect();

    //motor1SpeedPin = true;
    //motor2SpeedPin = true;

    //motor1In1Pin.connect();
    //motor1In2Pin.connect();
                
    //motor2In1Pin.connect();
    //motor2In2Pin.connect();

    motor1In1Pin = false;
    motor1In2Pin = false;

    motor2In1Pin = false;
    motor2In2Pin = false;

    
    //настраиваю кан
    can::can1.init( 125*1000, can::CanPins::A11_A12 );
    //раздаю фильтры под разные типы сообщений каннабуса
    {
        //буфер для бродкаста
        const uint8_t can_rx_buf_broadcast = 0;
        can::can1.setFilterMaskNormal(  can_rx_buf_broadcast,
                                        cannabus::filter_broadcast,
                                        cannabus::id_mask_addr );

        //буфер для прямого обращения
        const uint8_t can_rx_buf_direct = 1;
        can::can1.setFilterMaskNormal(  can_rx_buf_direct,
                                        cannabus::id_filter_direct_access,
                                        cannabus::id_mask_addr );


        uint8_t slaveFilter = address << cannabus::id_offset_addr;
        //настраиваю всем буфера
        for(uint8_t j = 2; j <= 13; j++)
        {
            can::can1.setFilterMaskNormal(  j,
                                            slaveFilter,
                                            cannabus::id_mask_addr );
        }
    }

    static auto linkLost = [](){ GPIO_ResetBits(GPIOB, GPIO_Pin_14); GPIO_SetBits(GPIOB, GPIO_Pin_13); };
    static auto linkRestored = [](){ GPIO_SetBits(GPIOB, GPIO_Pin_14); GPIO_ResetBits(GPIOB, GPIO_Pin_13); };

    static cannabus::SlaveSession slave( &can::can1, address, &regTable, linkLost, 1000, linkRestored );
    
    uart::uart1.init( uart::RxPins::UART1_PA10, uart::TxPins::UART1_PA9, 9600 );
    static camera::Worker cameraWorker( &regTable, &uart::uart1 );
    cameraWorker.init();

    int8_t curStateMotorX = 0;
    int8_t curStateMotorY = 0;

    
    while(1)
    {
        uint32_t time = umba::time_service::getCurTimeMs();
        
        slave.work( time );
        cameraWorker.work( time );

        //const uint8_t voltage_x_s8                                                = 0x80; // скорость мотора оси X в % от -100 до 100
        //const uint8_t voltage_y_s8                                                = 0x81; // скорость мотора оси Y в % от -100 до 100

    //dac1.connect();
    //dac2.connect();

        int8_t regMotX = regTable.getRegVal( regs::tvko::rw::voltage_x_s8 );
        int8_t regMotY = regTable.getRegVal( regs::tvko::rw::voltage_y_s8 );

        int8_t newStateMotorX = getDirection(regMotX);
        int8_t newStateMotorY = getDirection(regMotY);

        if (curStateMotorX != newStateMotorX)
        {
            curStateMotorX = newStateMotorX;
            //dac2 = getSpeedVal( curStateMotorX );
            dac2 = 100;
            motorCtrl( motor2In1Pin, motor2In2Pin, curStateMotorX );
            //table.setRegVal( regs::hot_end::ro::extruder_motor_state_u8, (uint8_t)curStateMotor1 );
        }

        if (curStateMotorY != newStateMotorY)
        {
            curStateMotorY = newStateMotorY;
            //dac1 = getSpeedVal( curStateMotorY );
            dac1 = 100;
            motorCtrl( motor1In1Pin, motor1In2Pin, curStateMotorY );
            
            //table.setRegVal( regs::hot_end::ro::sticker_motor_state_u8, (uint8_t)curStateMotor2 );
        }


    }

    return 0;
}




