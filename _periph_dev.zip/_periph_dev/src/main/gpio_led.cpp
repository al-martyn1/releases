// STM32F407VG Discovery board - https://www.st.com/content/ccc/resource/technical/document/user_manual/70/fe/4a/3f/e7/e1/4f/7d/DM00039084.pdf/files/DM00039084.pdf/jcr:content/translations/en.DM00039084.pdf

#include "umba.h"
#include "periph/gpio.h"
#include "umba/time_service.h"



// F4 Discovery LEDs


int main(void)
{
    umba::time_service::init();
    umba::time_service::start();


    using namespace umba::periph;
    
    GpioPin orangeLedPin   ( PD13 );
    GpioPin greenLedPin    ( PD12 );
    GpioPin redLedPin      ( PD14 );
    GpioPin blueLedPin     ( PD15 );

    GpioPin userButtonPin  ( PA0, input );


    orangeLedPin .connect();
    greenLedPin  .connect();
    redLedPin    .connect();
    blueLedPin   .connect();
    userButtonPin.connect();


    for( unsigned i=0; i!=10; ++i )
    {
        orangeLedPin = !orangeLedPin;
        greenLedPin  = !greenLedPin ;
        redLedPin    = !redLedPin   ;
        blueLedPin   = !blueLedPin  ;
        umba::time_service::delayMs(250);
    }

    orangeLedPin = false;
    greenLedPin  = true;
    redLedPin    = false;
    blueLedPin   = false;

    while(1)
    {
        orangeLedPin = userButtonPin;
        umba::time_service::delayMs(50);
    }


}

