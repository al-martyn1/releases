#pragma once

//#include "project_config.h"
#include <algorithm>
//#include "umba_array/umba_array.h"

namespace adc
{
    enum class AdcChannels_2
    {
        chan_3_esc_current = 0
    };
/*
    STRONG_ENUM( AdcChannels_3,
                 chan_5_motor_1_current  = 0,
                 chan_11_motor_2_current = 1,
                 max );

    STRONG_ENUM( AdcChannels_4,
                 chan_5_motor_1_temp = 0,
                 chan_8_motor_2_temp = 1,
                 max );
*/

    // using AdcDataType = decltype( ADC1->DR ); - ноуп, нужно убрать __IO, но нету type_traits
    using AdcDataType = uint32_t;

    template< size_t size >
    using RawDataArr = ::umba::Array< AdcDataType, size >;

    using RawDataArrView = ::umba::ArrayView< AdcDataType >;

    void init(void);

    template< typename Channels >
    class Adc
    {

        friend void init();

    public:

        AdcDataType getChannelValue( Channels chan )
        {
            // соберем массив данных от одного канала
            AdcDataType tempData[ adc_median_sample_size ];

            // данные с каналов идут один за другим в большой массив
            // соответственно один и тот же канал повторяется каждые AdcChannels::CHAN_MAX
            // а нужный нам начинается с chan-ного

            UMBA_ASSERT( chan < Channels::max );

            for( uint32_t i = chan.toInt(), j = 0; i < adc_raw_data_size; i += Channels::max, ++j )
            {
                tempData[ j ] = m_rawDataArr[ i ];
            }

            // найдем n order statistic

            std::nth_element(&tempData[ 0 ],
                             &tempData[ adc_median_sample_middle ],
                             &tempData[ adc_median_sample_size ] );

            // медиана
            return tempData[ adc_median_sample_middle ];
        }

    private:

        constexpr static size_t adc_median_sample_size   =  15;
        constexpr static size_t adc_median_sample_middle = adc_median_sample_size/2;
        constexpr static size_t adc_raw_data_size        = adc_median_sample_size * Channels::max;

        RawDataArr< adc_raw_data_size > m_rawDataArr{ };
    };


    extern Adc< AdcChannels_3 > adc_3;
    extern Adc< AdcChannels_4 > adc_4;

}
