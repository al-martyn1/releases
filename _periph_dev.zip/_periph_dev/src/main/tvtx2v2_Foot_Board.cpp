#include "luart/uart_handle.h"
#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/gpio.h"
#include "periph/power.h"
#include "periph/adc.h"
#include "periph/flash.h"

#include "boards_conf/tvtx2v2_Foot_Board_conf.h"
#include "boards_conf/tvtx2v2_Foot_Board_pins.cpp"

#include "rtkos/rtkos.h"
#include "rtkos/rtkos_protothread.h"
#include "rtkos/starters.h"

#include "callbacks/callbacks.h"
#include "milliganjubus_core/milliganjubus_simple_reg_table.h"
#include "milliganjubus_core/milliganjubus_slave_session.h"

#include "vtx2v2/telexertex2_types.h"
#include "vtx2v2/telexertex2_sucker_regs.h"

#include "crc/umba_crc.h"



//#include "pid_tuner/simple_tuner.h"


//#define FOOT_NUMBER 1
#define FOOT_NUMBER 2


//#define GANJUBUS_USE_DEBUG_UART
//#define GANJUBUS_ADDR_AUTO_DETECT
//#define LOG_SUCKER_EVENTS


//-----------------------------------------------------------------------------
#if defined(GANJUBUS_USE_DEBUG_UART)
    #if defined(GANJUBUS_ADDR_AUTO_DETECT)
        #error "Can't use ganjubus address autodetect. Debug UART port is used for Ganjubus communications"
    #endif
#endif

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
#ifdef GANJUBUS_USE_DEBUG_UART

    #define GANJUBUS_UART                    DEBUG_UART
    #define GANJUBUS_LEGACY_UART             DEBUG_LEGACY_UART
    #define GANJUBUS_UART_RX_GPIO            DEBUG_UART_RX_GPIO
    #define GANJUBUS_UART_RX_GPIO_PIN_NO     DEBUG_UART_RX_GPIO_PIN_NO
    #define GANJUBUS_UART_TX_GPIO            DEBUG_UART_TX_GPIO
    #define GANJUBUS_UART_TX_GPIO_PIN_NO     DEBUG_UART_TX_GPIO_PIN_NO

#else

    #define GANJUBUS_UART                    RS485_UART
    #define GANJUBUS_LEGACY_UART             RS485_LEGACY_UART
    #define GANJUBUS_UART_RX_GPIO            RS485_UART_RX_GPIO
    #define GANJUBUS_UART_RX_GPIO_PIN_NO     RS485_UART_RX_GPIO_PIN_NO
    #define GANJUBUS_UART_TX_GPIO            RS485_UART_TX_GPIO
    #define GANJUBUS_UART_TX_GPIO_PIN_NO     RS485_UART_TX_GPIO_PIN_NO

    #define GANJUBUS_USE_RS485
    #define GANJUBUS_RS485_LINK_DE_GPIO        RS485_LINK_DE_GPIO       
    #define GANJUBUS_RS485_LINK_DE_GPIO_PIN_NO RS485_LINK_DE_GPIO_PIN_NO

#endif
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
// For C6 use UMBA_TOO_LOW_MEM macro

// -E option make preprocessor output


//#define LOG_TO_UART
//-----------------------------------------------------------------------------


struct FootBoardConfig
{
    uint8_t  ganjubusAddr = 0;
};


struct FlashConfigCrcCalculator
{
    uint32_t operator()( const uint8_t * buf, size_t len)
    {
        return umba_crc32 (buf, (uint32_t)len);
    }
};




//-----------------------------------------------------------------------------
// Конфигурация ганджубуса
// TODO: Надо прошить во фдэш память
uint8_t     thisBoardGanjubusAddr = 0x10;
unsigned    ganjubusUartSpeed     = 57600;
// Полировщик ганджубуса
static milliganjubus::SlaveSession slaveSession;
bool configGood = false;
bool writeConfigResult = false;
bool ganjubusAddrDetectionDetected = false;
//-----------------------------------------------------------------------------
// int variable __attribute__((section("foo"))) = 10;
// http://www.keil.com/support/man/docs/armlink/armlink_pge1362066001103.htm
// http://www.keil.com/support/man/docs/armlink/armlink_pge1362066001618.htm
// http://www.keil.com/support/man/docs/armlink/armlink_pge1362066002650.htm
// const int baz __attribute__((at(0x0000))) = 100;
// const int foo __attribute__((section(".ARM.__at_0x2000"))) = 100;




//-----------------------------------------------------------------------------
// Тип таблицы регистров, таблица регистров, и safe proxy для ro/rw
typedef milliganjubus::SimpleRegTable< regs::SuckingFoot::ro::min, regs::SuckingFoot::ro::max, 
                                       regs::SuckingFoot::rw::min, regs::SuckingFoot::rw::max >
                             RawRegTable;
/*
typedef milliganjubus::SimpleRegTable< regs::SuckingFoot::RO::min, regs::SuckingFoot::RO::max, 
                                       regs::SuckingFoot::RW::min, regs::SuckingFoot::RW::max >
                             RawRegTable;
*/

RawRegTable    rawRegTable;
rdlc::RegTableSafe< RawRegTable, regs::SuckingFoot::ro::meta > roRegs( &rawRegTable );
rdlc::RegTableSafe< RawRegTable, regs::SuckingFoot::rw::meta > rwRegs( &rawRegTable );

//-----------------------------------------------------------------------------








//-----------------------------------------------------------------------------
using namespace umba::omanip;
using namespace umba::periph;
using namespace regs::SuckingFoot;
using namespace regs::types;



//-----------------------------------------------------------------------------
#include "tvtx2v2_Foot_Board_logic.h"
//-----------------------------------------------------------------------------






struct PredStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel4>
{
    umba::drivers::DriverAddress escAddr = umba::drivers::DriverAddress( umba::drivers::class_id_esc, 1 );

    //uint32_t u32;
    //float    f;

    //rdlc::RegTablePublic< RawRegTable, int >  rt = rdlc::makeRegTablePublic( rawRegTable, int() );

    //uint32_t                   pwmFreq       =  100;
    //uint32_t                   pwmOffPulse   =  800;
    //uint32_t                   pwmIdlePulse  = 1560;
    //uint32_t                   pwmMaxPulse   = 2300;
    //uint32_t                   pwmPulse      =  800; // current value
    uint8_t                    escMode       =    0; // off, idle, on - 0/1/2


    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning

         //using namespace regs::SuckingFoot;
         //using namespace regs::SuckingFoot;

         
         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_command, escMode );

         PT_YIELD();

         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_freq, FootBoardLogic::esc_default_pwm_freq );

         PT_YIELD();

         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_off, FootBoardLogic::esc_default_pwm_off_pulse );

         PT_YIELD();

         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_idliing, FootBoardLogic::esc_default_pwm_idle_pulse );
         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse, FootBoardLogic::esc_default_pwm_off_pulse );

         PT_YIELD();

         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_max, FootBoardLogic::esc_default_pwm_max_pulse  );

         PT_END();
    }

};




auto deviceLogic = FootBoardLogic();


struct FunalStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel6>
{
    umba::drivers::DriverAddress escAddr = umba::drivers::DriverAddress( umba::drivers::class_id_esc, 1 );
    //umba::drivers::DriverAddress timAddr = umba::drivers::DriverAddress( umba::drivers::class_id_tim_pwm, 1 );
    uint8_t  escCtrl   = 0; // off
    uint8_t  timCtrl   = 1;

    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning


         // Заполняем регистры значениями по умолчанию
         // При старте рабочего потока произойдет проверка обновления регистров,
         // и их стартовые значения будут раскиданы по драйверам/устройствам,
         // а регистры состояния будут отосланы мастеру

         using namespace regs::SuckingFoot;

         roRegs[ro::sucker_mode_u8    ] = (uint8_t)0; // Стоим, нет ошибки
         roRegs[ro::pressure_diff_u8  ] = (float)0.0f;
         roRegs[ro::esc_current_u8    ] = (uint8_t)0; // Тока нет
         roRegs[ro::surface_sensors_u8] = (uint8_t)0; // Датчики не замкнуты
         roRegs[ro::sucker_pid_scale_proportional_current_f32] = FootBoardLogic::default_pid_k_p;
         roRegs[ro::sucker_pid_scale_integral_current_f32    ] = FootBoardLogic::default_pid_k_i;
         roRegs[ro::sucker_pid_scale_differential_current_f32] = FootBoardLogic::default_pid_k_d;

         rwRegs[rw::sucker_ctrl_u8                   ] = (uint8_t)0;   // Команда "Стоять"
         rwRegs[rw::pressure_diff_ctrl_u8            ] = (uint8_t)0.0; // Нулевая разница давления
         rwRegs[rw::psensor_emergency_mode_ctrl_u8   ] = (uint8_t)0;   // 0 - работать на средних оборотах
         rwRegs[rw::sucker_pid_scale_proportional_f32] = (float)FootBoardLogic::default_pid_k_p; 
         rwRegs[rw::sucker_pid_scale_integral_f32    ] = (float)FootBoardLogic::default_pid_k_i;  
         rwRegs[rw::sucker_pid_scale_differential_f32] = (float)FootBoardLogic::default_pid_k_d;
         rwRegs[rw::impeller_esc_current_limit_u8    ] = (uint8_t)10; // 1А мА лимит по току

         // FootBoardLogic::esc_default_pwm_freq      - такого регистра нет
         rwRegs[rw::impeller_esc_pwm_interval_off_u16         ] = (uint16_t)FootBoardLogic::esc_default_pwm_off_pulse;
         //rwRegs[rw::esc_pwm_interval_min_u16         ] = (uint8_t)1560;
         rwRegs[rw::impeller_esc_pwm_interval_idle_u16        ] = (uint16_t)FootBoardLogic::esc_default_pwm_idle_pulse;
         rwRegs[rw::impeller_esc_pwm_interval_max_u16         ] = (uint16_t)FootBoardLogic::esc_default_pwm_max_pulse ;
                
         //umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_command, escCtrl );
         //postMessageDriverValue( timAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_ctrl, timCtrl );

         PT_YIELD();

         deviceLogic.timerSet( deviceLogic.timer_event_request_pressure, deviceLogic.timer_request_pressure_period ); // 10мс

         // Обновлять данные от датчика давления и тока в противофазе, для пущей равномерности бытия
         // Предполагается, что оба интервала равны.
         // Если нет, то будет не в противофазе, а просто с некоторым сдвигом, что тоже нормас
         timer.start( deviceLogic.timer_request_pressure_period/2 ); 
         PT_WAIT_UNTIL(timer.expired());

         deviceLogic.timerSet( deviceLogic.timer_event_requeste_esc_current, deviceLogic.timer_requeste_esc_current_period ); // 10 мс

         PT_YIELD();

         deviceLogic.timerSet( deviceLogic.timer_event_knobs, deviceLogic.timer_knobs_period );

         PT_YIELD();


         UMBA_RTKOS_LOG<<info<<"Ganjubus Address detection: ";
         if (ganjubusAddrDetectionDetected)
         {
             UMBA_RTKOS_LOG<<good<<"used"<<normal<<endl;
             UMBA_RTKOS_LOG<<info<<"Writting configuration to flash: ";
             if (writeConfigResult)
                 UMBA_RTKOS_LOG<<good<<"Ok";
             else
                 UMBA_RTKOS_LOG<<error<<"Failed";
             UMBA_RTKOS_LOG<<normal<<endl;
         }
         else
         {
             UMBA_RTKOS_LOG<<notice<<"not used"<<normal<<endl;
             UMBA_RTKOS_LOG<<info<<"Reading device configuration from flash: ";
             if (!configGood)
             {
                 UMBA_RTKOS_LOG<<error<<"Failed"<<normal<<endl;
             }
             else
             {
                 UMBA_RTKOS_LOG<<good<<"Ok"<<normal<<endl;
             }

         }

         UMBA_RTKOS_LOG<<notice<<"Ganjubus Address: "<<good<<hex<<thisBoardGanjubusAddr<<" ("<<thisBoardGanjubusAddr<<")"<<normal<<endl;

         PT_END();
    }

}; // struct FunalStarterThread


auto hwInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );
auto swInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );

auto starter0   =  umba::rtkos::StarterThreadOsInfo< umba::rtkos::OsInfoLogLevel::osSizeDetailsMore >(); 

auto starter1   =  umba::rtkos::StarterThreadHardwareInfo();

auto starter2   =  umba::rtkos::StarterThreadHardwareInitializer< decltype(hwInitDelays)>( hwInitDelays );

auto starter4   =  PredStarterThread();

auto starter5   =  umba::rtkos::StarterThreadSoftwareInitializer< decltype(swInitDelays)/*, umba::rtkos::RunLevel5*/>( swInitDelays );

auto starter6   =  FunalStarterThread();

auto stateIndicatorDriver = umba::drivers::periph::DeviceStateIndicator2LedsDriver( LED_ERROR_GPIO_PIN_ADDR, LED_LINK_GPIO_PIN_ADDR );

auto knobsDriver          = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_in_pulldown
                                                             , umba::periph::PinSpeed::low
                                                             , RANGEFINDER1_GPIO_PIN_ADDR
                                                             , RANGEFINDER2_GPIO_PIN_ADDR
                                                             , RANGEFINDER3_GPIO_PIN_ADDR
                                                             , RANGEFINDER4_GPIO_PIN_ADDR
                                                             );


auto timPwmDriver         = umba::drivers::periph::TimPwmDriver( TIM16, 1, UMBA_PINADDR_PB8 ); // TIM16_CH1 

auto escDriver            = umba::drivers::motors::EscDriver( umba::drivers::DriverAddress( umba::drivers::class_id_tim_pwm, umba::periph::periphGetNo( TIM16 ) ) );

auto kbdTermDriver        = umba::drivers::hid::KeyboardTerminalDriver( 
                                                                        #if defined(GANJUBUS_USE_DEBUG_UART) || defined(GANJUBUS_ADDR_AUTO_DETECT)
                                                                        umba::drivers::invalid_driver_address
                                                                        #else
                                                                        //umba::drivers::invalid_driver_address
                                                                        umba::drivers::DriverAddress( umba::drivers::class_id_stream
                                                                                                    , umba::periph::periphGetNo( & DEBUG_LEGACY_UART ) 
                                                                                                    )
                                                                        #endif
                                                                      );


auto debugUartDriver      = umba::drivers::periph::LegacyUartDriver( DEBUG_LEGACY_UART
                                                                   , DEBUG_UART_RX_GPIO_PIN_ADDR
                                                                   , DEBUG_UART_TX_GPIO_PIN_ADDR
                                                                   , 460800
                                                                   // No pinAddrRs485
                                                                   );

auto i2c = umba::drivers::periph::SoftI2cDriver(  PB7 /*SDA*/, PB6 /*SCL*/ );

auto psensor = umba::drivers::sensors::HSCSSNN001PD2A3_PSensorDriver( umba::drivers::DriverAddress( umba::drivers::class_id_i2c_soft
                                                                                                  , 1 // первый из сенсоров, см ниже порядок установки дров, попробуйте задать 3 для проверки
                                                                                                  ) 
                                                                    , FootBoardLogic::psensor_i2c_address // адрес сенсора на шине I2C
                                                                    , scalcus::average_times_64
                                                                    );

//auto adcSC     = umba::periph::traits::AdcSingleChannel( ADC2, UMBA_PINADDR_PA6, umba::periph::AdcSamplingSpeed::low );
umba::periph::traits::AdcSingleChannelDma<1024>  adcSC( ADC2, UMBA_PINADDR_PA6, umba::periph::AdcSamplingSpeed::low, umba::periph::traits::dma2_Channel1 );

auto adcDriver = umba::drivers::periph::makeAdcDriver( adcSC, scalcus::average_times_1, UMBA_PINADDR_PA6 );


/*
void FootBoardLogic::ganjubusPoll()
{
    auto tickNow = umba::time_service::getCurTimeMs();
    slaveSession.work( tickNow );
}
*/

int main(void)

{
    FootBoardConfig config;
    configGood = 
    umba::periph::flash::readConfig< FootBoardConfig
                                   , FlashConfigCrcCalculator
                                   , umba::periph::flash::flash_size_128K
                                   , umba::periph::flash::page_size_2048
                                   , 0x8000000
                                   >( config );

    /*
    
    // Базовый адрес устройства.
    // Если не используем автодетект, надо ручками прописать для какждой присоски отдельный адрес
    #if defined(GANJUBUS_ADDR_AUTO_DETECT)
    {
        // Когда отладочный UART никуда не подключен, лапки висят в воздухе
        // Подтянем их к единице, так как для выбора адреса будем на пины коротить землю с того же разъема
        GpioPin addrPin1( GpioPinAddr( DEBUG_UART_TX_GPIO_PIN_ADDR ), PinMode::gpio_in_pullup ); // PA9
        GpioPin addrPin2( GpioPinAddr( DEBUG_UART_RX_GPIO_PIN_ADDR ), PinMode::gpio_in_pullup ); // PA10

        uint8_t addrPins = 0;
        if (addrPin1==true)
            addrPins |= 1;
        if (addrPin2==true)
            addrPins |= 2;

        addrPins = (~addrPins) & 0x3; // чтобы адрес по умолчанию не отличался от базового
        thisBoardGanjubusAddr += addrPins;
        // Таким образом, если ничего не подключено, то в итоге адрес будет 0x10 (если бы не инвертили, было бы 0x13)
    }
    #endif
    */

    /* Логика определения адреса такова.
       Подтягиваем пины отладочного UART'а к единице. Если они болтаются в воздухе или к ним подключен
       UART, то мы получим единицы.

       Далее надо проверить пин TX (PA9). Внешний UART, даже если подключен, не трогает его - по нему вещяем мы сами.
       Поэтому случайно получить там 0 - не реально.
       Если он в нуле - значит, кто-то ручками его замкнул на землю, и хочет прошить адрес.
       Тогда мы смотрим состояние второго пина и берем с него адрес (инвертируя) и прибавляем к смещению (0x10)
     */
    //if (!configGood)

    /*
    bool valPA9  = false;
    bool valPA10 = false;
    {
        GpioPin addrPin1( GpioPinAddr( DEBUG_UART_TX_GPIO_PIN_ADDR ), PinMode::gpio_in_pullup ); // PA9  - TX
        GpioPin addrPin2( GpioPinAddr( DEBUG_UART_RX_GPIO_PIN_ADDR ), PinMode::gpio_in_pullup ); // PA10 - RX

        valPA9  = addrPin1;
        valPA10 = addrPin2;

        if (!valPA9) // явно притянули ногу к земле - хотят задать адрес
        {
            ganjubusAddrDetectionDetected = true;
            if (!valPA10) // если болтается в воздухе - то адрес дефолтный
               thisBoardGanjubusAddr++; // иначе - кто-то явно хочет поменять адрес

            config.ganjubusAddr = thisBoardGanjubusAddr;

            writeConfigResult = 
            umba::periph::flash::writeConfig< FootBoardConfig
                                            , FlashConfigCrcCalculator
                                            , umba::periph::flash::flash_size_128K
                                            , umba::periph::flash::page_size_2048
                                            , 0x8000000
                                            >( config );
            configGood = true;
        }
    }

    if (configGood)
    {
        thisBoardGanjubusAddr = config.ganjubusAddr;
    }
    */

    #ifndef FOOT_NUMBER
        #error "FOOT_NUMBER not defined"
    #endif

    #if FOOT_NUMBER!=1 && FOOT_NUMBER!=2
        #error "FOOT_NUMBER must be set to 1 or 2"
    #endif

    #if FOOT_NUMBER==1
        thisBoardGanjubusAddr = 0x10;
    #else
        thisBoardGanjubusAddr = 0x11;
    #endif

    #if defined(GANJUBUS_USE_DEBUG_UART) || defined(GANJUBUS_ADDR_AUTO_DETECT)

        UMBA_RTKOS_USE_LOG_STREAM_SWD();

    #else

        UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( DEBUG_LEGACY_UART, DEBUG_UART, 460800 );

    #endif

    //UMBA_RTKOS_LOG<<feed<<"------------------"<<endl;

    /*
    uint8_t   u8   = 1;
    int8_t    s8   = 2;
    uint16_t  u16  = 3;
    int16_t   s16  = 4;
    uint32_t  u32  = 5;
    int32_t   s32  = 6;
    float     f32  = 7.0f;
    
    UMBA_RTKOS_LOG<<"u8 : "<<hex<<(uint32_t)umba::drivers::makeValueInfoFlags( u8  )<<endl;
    UMBA_RTKOS_LOG<<"s8 : "<<hex<<(uint32_t)umba::drivers::makeValueInfoFlags( s8  )<<endl;
    UMBA_RTKOS_LOG<<"u16: "<<hex<<(uint32_t)umba::drivers::makeValueInfoFlags( u16 )<<endl;
    UMBA_RTKOS_LOG<<"s16: "<<hex<<(uint32_t)umba::drivers::makeValueInfoFlags( s16 )<<endl;
    UMBA_RTKOS_LOG<<"u32: "<<hex<<(uint32_t)umba::drivers::makeValueInfoFlags( u32 )<<endl;
    UMBA_RTKOS_LOG<<"s32: "<<hex<<(uint32_t)umba::drivers::makeValueInfoFlags( s32 )<<endl;
    UMBA_RTKOS_LOG<<"f32: "<<hex<<(uint32_t)umba::drivers::makeValueInfoFlags( f32 )<<endl;
    */

    //UMBA_RTKOS_LOG<<good<<"PA9 : "<<valPA9 <<normal<<"\n";
    //UMBA_RTKOS_LOG<<good<<"PA10: "<<valPA10<<normal<<endl;

    


    GANJUBUS_LEGACY_UART.init( GANJUBUS_UART_RX_GPIO, GANJUBUS_UART_RX_GPIO_PIN_NO
                      , GANJUBUS_UART_TX_GPIO, GANJUBUS_UART_TX_GPIO_PIN_NO
                      , ganjubusUartSpeed
                      #ifdef GANJUBUS_USE_RS485
                      , GANJUBUS_RS485_LINK_DE_GPIO, 1<<GANJUBUS_RS485_LINK_DE_GPIO_PIN_NO
                      #endif
                      );
                      
                      
    // __enable_irq();
    //  
    // while(true)
    // {
    //     GANJUBUS_LEGACY_UART.sendByte('a');
    //     for( volatile uint32_t i=0; i<10000; i++);
    // }
    
    static callback::Callback<void ( void )> linkLostCallback    ( []() { deviceLogic.onGanjubusLinkLost();     } );
    static callback::Callback<void ( void )> linkRestoredCallback( []() { deviceLogic.onGanjubusLinkRestored(); } );
    static callback::Callback<void ( void )> dataReceivedCallback( []() { deviceLogic.onGanjubusDataReceived(); } );

    
    slaveSession.init( GANJUBUS_LEGACY_UART
                     , thisBoardGanjubusAddr
                     , rawRegTable
                     , linkLostCallback
                     , linkRestoredCallback
                     , 5000 // lost link timeout
                     , dataReceivedCallback );         // коллбэки


    #if defined(GANJUBUS_USE_DEBUG_UART) || defined(GANJUBUS_ADDR_AUTO_DETECT)
    #else
    UMBA_DRIVER_CHECKED_INSTALL(debugUartDriver);
    #endif

    UMBA_DRIVER_CHECKED_INSTALL(stateIndicatorDriver);
    UMBA_DRIVER_CHECKED_INSTALL(kbdTermDriver       );
    UMBA_DRIVER_CHECKED_INSTALL(i2c                 );
    UMBA_DRIVER_CHECKED_INSTALL(psensor             );
    UMBA_DRIVER_CHECKED_INSTALL(adcDriver           );
    UMBA_DRIVER_CHECKED_INSTALL(timPwmDriver        );
    UMBA_DRIVER_CHECKED_INSTALL(escDriver           );
    UMBA_DRIVER_CHECKED_INSTALL(knobsDriver         );

    deviceLogic.psensorDriverAddr = psensor.getAssignedAddress();
                                                   
    UMBA_DRIVER_CHECKED_INSTALL(deviceLogic         );


    umba::rtkos::pollScheduleAdd( &starter0 );
    umba::rtkos::pollScheduleAdd( &starter1 );
    umba::rtkos::pollScheduleAdd( &starter2 );
    umba::rtkos::pollScheduleAdd( &starter4 );
    umba::rtkos::pollScheduleAdd( &starter5 );
    umba::rtkos::pollScheduleAdd( &starter6 );


    return UMBA_RTKOS_OS->run( umba::rtkos::RunLevel6 );

}


