
friend void initAdc();

template< typename BufSize >
class Adc
{

    friend void init();

public:

    uint16_t getValue( )
    {
        /*
        // соберем массив данных от одного канала
        AdcDataType tempData[ adc_median_sample_size ];

        // данные с каналов идут один за другим в большой массив
        // соответственно один и тот же канал повторяется каждые AdcChannels::CHAN_MAX
        // а нужный нам начинается с chan-ного

        UMBA_ASSERT( chan < Channels::max );

        for( uint32_t i = chan.toInt(), j = 0; i < adc_raw_data_size; i += Channels::max, ++j )
        {
            tempData[ j ] = m_rawDataArr[ i ];
        }

        // найдем n order statistic

        std::nth_element(&tempData[ 0 ],
                         &tempData[ adc_median_sample_middle ],
                         &tempData[ adc_median_sample_size ] );

        // медиана
        return tempData[ adc_median_sample_middle ];
        */
    }

private:

    //constexpr static size_t adc_median_sample_size   =  15;
    //constexpr static size_t adc_median_sample_middle = adc_median_sample_size/2;
    //constexpr static size_t adc_raw_data_size        = adc_median_sample_size * Channels::max;

    //RawDataArr< adc_raw_data_size > m_rawDataArr{ };
};

