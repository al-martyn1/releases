// main_board_slave.PrjPcb - Generator: h_conf

// main_board_slave.PrjPcb - Netlist_1

// MCU DD1 STM32F405RG peripherals

// BATTERY_RS485

#define BATTERY_RS485_DE_GPIO                         GPIOC
#define BATTERY_RS485_DE_GPIO_PIN_NO                  3
#define BATTERY_RS485_DE_GPIO_PIN_ADDR                UMBA_PINADDR_PC3
#define BATTERY_RS485_DE_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PC3, UMBA_GPIO_DIRECTION_OUT
#define BATTERY_RS485_DE_GPIO_PIN_SOURCE              GPIO_PinSource3
#define BATTERY_RS485_DE_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT

#define BATTERY_RS485_UART                            UART4
#define BATTERY_RS485_LEGACY_UART                     uart::uart4
#define USE_UART4                                     1
#define BATTERY_RS485_UART_TX_GPIO                    GPIOA
#define BATTERY_RS485_UART_TX_GPIO_PIN_NO             0
#define BATTERY_RS485_UART_TX_GPIO_PIN_ADDR           UMBA_PINADDR_PA0
#define BATTERY_RS485_UART_TX_GPIO_PIN_SOURCE         GPIO_PinSource0
#define BATTERY_RS485_UART_TX_GPIO_PIN_DIRECTION      UMBA_GPIO_DIRECTION_OUT

#define BATTERY_RS485_UART_RX_GPIO                    GPIOA
#define BATTERY_RS485_UART_RX_GPIO_PIN_NO             1
#define BATTERY_RS485_UART_RX_GPIO_PIN_ADDR           UMBA_PINADDR_PA1
#define BATTERY_RS485_UART_RX_GPIO_PIN_SOURCE         GPIO_PinSource1
#define BATTERY_RS485_UART_RX_GPIO_PIN_DIRECTION      UMBA_GPIO_DIRECTION_IN




// CANABUS_CAN

#define CANABUS_CAN_LOOPBACK_GPIO                     GPIOA
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_NO              10
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_ADDR            UMBA_PINADDR_PA10
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_ADDR_DIR        UMBA_PINADDR_PA10, UMBA_GPIO_DIRECTION_OUT
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_SOURCE          GPIO_PinSource10
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_DIRECTION       UMBA_GPIO_DIRECTION_OUT

#define CANABUS_CAN                                   CAN1
#define USE_CAN1                                      1
#define CANABUS_CAN_RX_GPIO                           GPIOA
#define CANABUS_CAN_RX_GPIO_PIN_NO                    11
#define CANABUS_CAN_RX_GPIO_PIN_ADDR                  UMBA_PINADDR_PA11
#define CANABUS_CAN_RX_GPIO_PIN_SOURCE                GPIO_PinSource11
#define CANABUS_CAN_RX_GPIO_PIN_DIRECTION             UMBA_GPIO_DIRECTION_IN

#define CANABUS_CAN_TX_GPIO                           GPIOA
#define CANABUS_CAN_TX_GPIO_PIN_NO                    12
#define CANABUS_CAN_TX_GPIO_PIN_ADDR                  UMBA_PINADDR_PA12
#define CANABUS_CAN_TX_GPIO_PIN_SOURCE                GPIO_PinSource12
#define CANABUS_CAN_TX_GPIO_PIN_DIRECTION             UMBA_GPIO_DIRECTION_IN




// DEBUG_TERMINAL_UART

#define DEBUG_TERMINAL_UART                           UART1
#define DEBUG_TERMINAL_LEGACY_UART                    uart::uart1
#define USE_UART1                                     1
#define DEBUG_TERMINAL_UART_TX_GPIO                   GPIOB
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO            6
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_ADDR          UMBA_PINADDR_PB6
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_SOURCE        GPIO_PinSource6
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_OUT

#define DEBUG_TERMINAL_UART_RX_GPIO                   GPIOB
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO            7
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_ADDR          UMBA_PINADDR_PB7
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_SOURCE        GPIO_PinSource7
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_IN




// GYRO

#define GYRO_SPI                                      SPI3
#define USE_SPI3                                      1
#define GYRO_SPI_SCK_GPIO                             GPIOC
#define GYRO_SPI_SCK_GPIO_PIN_NO                      10
#define GYRO_SPI_SCK_GPIO_PIN_ADDR                    UMBA_PINADDR_PC10
#define GYRO_SPI_SCK_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PC10, UMBA_GPIO_DIRECTION_OUT
#define GYRO_SPI_SCK_GPIO_PIN_SOURCE                  GPIO_PinSource10
#define GYRO_SPI_SCK_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define GYRO_SPI_MISO_GPIO                            GPIOC
#define GYRO_SPI_MISO_GPIO_PIN_NO                     11
#define GYRO_SPI_MISO_GPIO_PIN_ADDR                   UMBA_PINADDR_PC11
#define GYRO_SPI_MISO_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PC11, UMBA_GPIO_DIRECTION_IN
#define GYRO_SPI_MISO_GPIO_PIN_SOURCE                 GPIO_PinSource11
#define GYRO_SPI_MISO_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN

#define GYRO_SPI_MOSI_GPIO                            GPIOC
#define GYRO_SPI_MOSI_GPIO_PIN_NO                     12
#define GYRO_SPI_MOSI_GPIO_PIN_ADDR                   UMBA_PINADDR_PC12
#define GYRO_SPI_MOSI_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PC12, UMBA_GPIO_DIRECTION_OUT
#define GYRO_SPI_MOSI_GPIO_PIN_SOURCE                 GPIO_PinSource12
#define GYRO_SPI_MOSI_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT

#define GYRO_CS_XM_GPIO                               GPIOD
#define GYRO_CS_XM_GPIO_PIN_NO                        2
#define GYRO_CS_XM_GPIO_PIN_ADDR                      UMBA_PINADDR_PD2
#define GYRO_CS_XM_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PD2, UMBA_GPIO_DIRECTION_OUT
#define GYRO_CS_XM_GPIO_PIN_SOURCE                    GPIO_PinSource2
#define GYRO_CS_XM_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define GYRO_CS_G_GPIO                                GPIOB
#define GYRO_CS_G_GPIO_PIN_NO                         5
#define GYRO_CS_G_GPIO_PIN_ADDR                       UMBA_PINADDR_PB5
#define GYRO_CS_G_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB5, UMBA_GPIO_DIRECTION_OUT
#define GYRO_CS_G_GPIO_PIN_SOURCE                     GPIO_PinSource5
#define GYRO_CS_G_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT




// MOTOR1

#define MOTOR1_SPEED_DAC                              DAC
#define MOTOR1_SPEED_DAC_CHANNEL                      DAC_Channel_1
#define USE_DAC                                       1

#define MOTOR1_nFAULT_GPIO                            GPIOC
#define MOTOR1_nFAULT_GPIO_PIN_NO                     5
#define MOTOR1_nFAULT_GPIO_PIN_ADDR                   UMBA_PINADDR_PC5
#define MOTOR1_nFAULT_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PC5, UMBA_GPIO_DIRECTION_IN
#define MOTOR1_nFAULT_GPIO_PIN_SOURCE                 GPIO_PinSource5
#define MOTOR1_nFAULT_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN

#define MOTOR1_IN1_GPIO                               GPIOB
#define MOTOR1_IN1_GPIO_PIN_NO                        0
#define MOTOR1_IN1_GPIO_PIN_ADDR                      UMBA_PINADDR_PB0
#define MOTOR1_IN1_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB0, UMBA_GPIO_DIRECTION_OUT
#define MOTOR1_IN1_GPIO_PIN_SOURCE                    GPIO_PinSource0
#define MOTOR1_IN1_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR1_IN2_GPIO                               GPIOB
#define MOTOR1_IN2_GPIO_PIN_NO                        1
#define MOTOR1_IN2_GPIO_PIN_ADDR                      UMBA_PINADDR_PB1
#define MOTOR1_IN2_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB1, UMBA_GPIO_DIRECTION_OUT
#define MOTOR1_IN2_GPIO_PIN_SOURCE                    GPIO_PinSource1
#define MOTOR1_IN2_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT




// MOTOR1_CURRENT_SENSOR

#define MOTOR1_CURRENT_SENSOR_ADC_GPIO                GPIOA
#define MOTOR1_CURRENT_SENSOR_ADC_GPIO_PIN_NO         6
#define MOTOR1_CURRENT_SENSOR_ADC_GPIO_PIN_ADDR       UMBA_PINADDR_PA6
#define MOTOR1_CURRENT_SENSOR_ADC_GPIO_PIN_SOURCE     GPIO_PinSource6
#define MOTOR1_CURRENT_SENSOR_ADC_CHANNEL             ADC_Channel_6
#define MOTOR1_CURRENT_SENSOR_ADC_CHANNEL_NO          6
#define MOTOR1_CURRENT_SENSOR_ADC                     ADC1
#define USE_ADC1                                      1

#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO               GPIOC
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_NO        4
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR      UMBA_PINADDR_PC4
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR_DIR    UMBA_PINADDR_PC4, UMBA_GPIO_DIRECTION_OUT
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_SOURCE    GPIO_PinSource4
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_OUT




// MOTOR2

#define MOTOR2_SPEED_DAC                              DAC
#define MOTOR2_SPEED_DAC_CHANNEL                      DAC_Channel_2

#define MOTOR2_IN1_GPIO                               GPIOB
#define MOTOR2_IN1_GPIO_PIN_NO                        10
#define MOTOR2_IN1_GPIO_PIN_ADDR                      UMBA_PINADDR_PB10
#define MOTOR2_IN1_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB10, UMBA_GPIO_DIRECTION_OUT
#define MOTOR2_IN1_GPIO_PIN_SOURCE                    GPIO_PinSource10
#define MOTOR2_IN1_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR2_IN2_GPIO                               GPIOB
#define MOTOR2_IN2_GPIO_PIN_NO                        11
#define MOTOR2_IN2_GPIO_PIN_ADDR                      UMBA_PINADDR_PB11
#define MOTOR2_IN2_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB11, UMBA_GPIO_DIRECTION_OUT
#define MOTOR2_IN2_GPIO_PIN_SOURCE                    GPIO_PinSource11
#define MOTOR2_IN2_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR2_nFAULT_GPIO                            GPIOB
#define MOTOR2_nFAULT_GPIO_PIN_NO                     12
#define MOTOR2_nFAULT_GPIO_PIN_ADDR                   UMBA_PINADDR_PB12
#define MOTOR2_nFAULT_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_IN
#define MOTOR2_nFAULT_GPIO_PIN_SOURCE                 GPIO_PinSource12
#define MOTOR2_nFAULT_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN




// MOTOR2_CURRENT_SENSOR

#define MOTOR2_CURRENT_SENSOR_ADC_GPIO                GPIOA
#define MOTOR2_CURRENT_SENSOR_ADC_GPIO_PIN_NO         7
#define MOTOR2_CURRENT_SENSOR_ADC_GPIO_PIN_ADDR       UMBA_PINADDR_PA7
#define MOTOR2_CURRENT_SENSOR_ADC_GPIO_PIN_SOURCE     GPIO_PinSource7
#define MOTOR2_CURRENT_SENSOR_ADC_CHANNEL             ADC_Channel_7
#define MOTOR2_CURRENT_SENSOR_ADC_CHANNEL_NO          7
#define MOTOR2_CURRENT_SENSOR_ADC                     ADC1

#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO               GPIOB
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_NO        13
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR      UMBA_PINADDR_PB13
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR_DIR    UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_SOURCE    GPIO_PinSource13
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_OUT




// PSENSOR

#define PSENSOR_I2C                                   I2C1
#define USE_I2C1                                      1
#define PSENSOR_I2C_SCL_GPIO                          GPIOB
#define PSENSOR_I2C_SCL_GPIO_PIN_NO                   8
#define PSENSOR_I2C_SCL_GPIO_PIN_ADDR                 UMBA_PINADDR_PB8
#define PSENSOR_I2C_SCL_GPIO_PIN_SOURCE               GPIO_PinSource8

#define PSENSOR_I2C_SDA_GPIO                          GPIOB
#define PSENSOR_I2C_SDA_GPIO_PIN_NO                   9
#define PSENSOR_I2C_SDA_GPIO_PIN_ADDR                 UMBA_PINADDR_PB9
#define PSENSOR_I2C_SDA_GPIO_PIN_SOURCE               GPIO_PinSource9




// Unclassified

#define VIDEO4_BACK_CAM_EN_GPIO                       GPIOB
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_NO                15
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_ADDR              UMBA_PINADDR_PB15
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_ADDR_DIR          UMBA_PINADDR_PB15, UMBA_GPIO_DIRECTION_OUT
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_SOURCE            GPIO_PinSource15
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT

#define BATTERY_PRESENT_FLAG_GPIO                     GPIOC
#define BATTERY_PRESENT_FLAG_GPIO_PIN_NO              2
#define BATTERY_PRESENT_FLAG_GPIO_PIN_ADDR            UMBA_PINADDR_PC2
#define BATTERY_PRESENT_FLAG_GPIO_PIN_ADDR_DIR        UMBA_PINADDR_PC2, UMBA_GPIO_DIRECTION_IN
#define BATTERY_PRESENT_FLAG_GPIO_PIN_SOURCE          GPIO_PinSource2
#define BATTERY_PRESENT_FLAG_GPIO_PIN_DIRECTION       UMBA_GPIO_DIRECTION_IN

#define POWER_5V_EN_GPIO                              GPIOC
#define POWER_5V_EN_GPIO_PIN_NO                       7
#define POWER_5V_EN_GPIO_PIN_ADDR                     UMBA_PINADDR_PC7
#define POWER_5V_EN_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PC7, UMBA_GPIO_DIRECTION_OUT
#define POWER_5V_EN_GPIO_PIN_SOURCE                   GPIO_PinSource7
#define POWER_5V_EN_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT



#define ESC_PWM_GPIO                                  GPIOA
#define ESC_PWM_GPIO_PIN_NO                           2
#define ESC_PWM_GPIO_PIN_ADDR                         UMBA_PINADDR_PA2
#define ESC_PWM_GPIO_PIN_SOURCE                       GPIO_PinSource2
#define ESC_PWM_TIM_CHANNEL                           TIM_Channel_3
#define ESC_PWM_TIM_CHANNEL_NO                        3
#define ESC_PWM_TIM                                   TIM2
#define USE_TIM2                                      1

#define LED_ERROR_GPIO                                GPIOC
#define LED_ERROR_GPIO_PIN_NO                         8
#define LED_ERROR_GPIO_PIN_ADDR                       UMBA_PINADDR_PC8
#define LED_ERROR_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PC8, UMBA_GPIO_DIRECTION_OUT
#define LED_ERROR_GPIO_PIN_SOURCE                     GPIO_PinSource8
#define LED_ERROR_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define LED_LINK_GPIO                                 GPIOC
#define LED_LINK_GPIO_PIN_NO                          9
#define LED_LINK_GPIO_PIN_ADDR                        UMBA_PINADDR_PC9
#define LED_LINK_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PC9, UMBA_GPIO_DIRECTION_OUT
#define LED_LINK_GPIO_PIN_SOURCE                      GPIO_PinSource9
#define LED_LINK_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define VIDEO4_BACK_CAM_PWR_EN_GPIO                   GPIOC
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_NO            6
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_ADDR          UMBA_PINADDR_PC6
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_ADDR_DIR      UMBA_PINADDR_PC6, UMBA_GPIO_DIRECTION_OUT
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_SOURCE        GPIO_PinSource6
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_OUT




