/*
    MAX6954
    nCS - low active
    CLK - Данные (MAX6954 DIN) должны быть установлены на восходящем фронте
          MAX6954 DOUT - При чтении с него также по восхдящему фронту
          В отсутствие передачи уровень - низкий.

    Pg11 On initial power-up, all control registers are reset,
         the display is blanked, intensities are set to minimum,
         and shutdown is enabled (see Table 15).

    Pg 8 Table 5. Serial-Data Format (16 Bits)
    D15      - R/nW - set to 1 for reading
    D14-D08  - Address
    D07-D00  - Data


    Pg 13 Table 6. Register Address Map

    Configuration register: addr = 0x04
    Pg 24 Table 16. Configuration Register Format
                            D7 D6 D5 D4 D3 D2 D1 D0
    Configuration Register   P  I  R  T  E  B  X  S
              S - Shutdown Control
              X - Unused
              B - Blink Rate Selection
              E - Global Blink Enable/Disable
              T - Global Blink Timing Synchronization
              R - Global Clear Digit Data
              I - Global Intensity
              P - Blink Phase Readback
    
       Shutdown    - 0x01   - 
       BlinkState  - 0x08   - 


    Global Intensity register: addr = 0x02
       value 0x00 - 0x0F

    Write Digit Type register: addr = 0x0C  (see Table 12)
    See Table 13
    Total 8 digits under control
    Each bit means:  0 - 16-segment or 7-segment digit
                     1 - 14-segment digit

    DecodeMode register: addr = 0x01 (see Table 14)
    Each bit means:  0 - No decode for digit pair
                     1 - Hexadecimal decode for digit pair


    0x28 - 0x2D - Управляем светодиодами

    Digit 0a Plane P0 (7 Segment Only) register: addr = 0x28
    Digit 1a Plane P0 (7 Segment Only) register: addr = 0x29
    Digit 2a Plane P0 (7 Segment Only) register: addr = 0x2A
    Digit 3a Plane P0 (7 Segment Only) register: addr = 0x2B
    Digit 4a Plane P0 (7 Segment Only) register: addr = 0x2C
    Digit 5a Plane P0 (7 Segment Only) register: addr = 0x2D
    Digit 6a Plane P0 (7 Segment Only) register: addr = 0x2E
    Digit 7a Plane P0 (7 Segment Only) register: addr = 0x2F

    Intensity 10a (7 Segment Only) register: addr = 0x14
    Intensity 32a (7 Segment Only) register: addr = 0x15
    Intensity 54a (7 Segment Only) register: addr = 0x16
    Intensity 76a (7 Segment Only) register: addr = 0x17


    Pg 21 Table 9. Digit Plane Data Register Format
    Pg 21 Table 10. Segment Decoding for 7-Segment Displays
    Pg 22 Table 11. 7-Segment Segment Mapping Decoder for Hexadecimal Font
    Pg 22 Table 12. Digit-Type Register
    Pg 23 Table 13. Example Configurations for Display Digit Combinations
    Pg 23 Table 14. Decode-Mode Register Examples


    !!! Reading - Pg 8


    http://gitblit.dep111.rtc.local/summary/?r=Prometheus/Firmware/4chConsole.git
    http://gitblit.dep111.rtc.local/summary/?r=~ivan_bubnikov/constructor/indication.git
    
    http://gitblit.dep111.rtc.local/summary/?r=~alex_volkov/periph_board_program.git
    
    
    HL           - Десигнатор LED на схеме
    Анод OXX     - Название выхода MAX6954, к которому подключен анод
    Катод OXX    - Название выхода MAX6954, к которому подключен катод
    RV           - Register Value - 16ти-битное число, старшие 8 бит - номер регистра MAX6954,
                   младшие 8 бит - значение регистра
    NN           - порядковый номер светодиода (пина в регистре):
                   0x2801 - NN 0
                   0x2802 - NN 1
                   0x2880 - NN 7
                   0x2901 - NN 8
                   ...
    Светодиоды на плате разведены, как показано в таблице ниже, и если пронумеровать светдиоды, по порядку в таблице
    (красные со смещением +22) - столбец #, то требуется ремап
    
    Зеленые                                                                      Красные
            
    #   NN    HL#  Анод OXX : Катод OXX    RV                                    HL#  Анод OXX : Катод OXX           NN    # 
                                                                                                                             
     0  0x02  HL28    A O15 : K O_0      0x2804      Цифровой вход 1             HL21    A O13 : K O_3      0x2B10   0x1C  22
     1  0x01  HL34    A O16 : K O_0      0x2802      Цифровой вход 2             HL27    A O14 : K O_3      0x2B08   0x1B  23
     2  0x03  HL22    A O14 : K O_0      0x2808      Цифровой вход 3             HL_9    A O11 : K O_3      0x2B40   0x1E  24
     3  0x05  HL10    A O12 : K O_0      0x2820      Цифровой вход 4             HL15    A O12 : K O_3      0x2B20   0x1D  25
     4  0x04  HL16    A O13 : K O_0      0x2810      Цифровой выход 1            HL43    A O17 : K O_3      0x2B01   0x18  26
     5  0x06  HL_4    A O11 : K O_0      0x2840      Цифровой выход 2            HL47    A O18 : K O_3      0x2B80   0x1F  27
     6  0x0C  HL18    A O13 : K O_1      0x2910      Изолированный вход 1        HL33    A O15 : K O_3      0x2B04   0x1A  28
     7  0x0B  HL24    A O14 : K O_1      0x2908      Изолированный вход 2        HL39    A O16 : K O_3      0x2B02   0x19  29
     8  0x0E  HL_6    A O11 : K O_1      0x2940      Изолированный выход         HL19    A O13 : K O_4      0x2C10   0x24  30
     9  0x0D  HL12    A O12 : K O_1      0x2920      Аналоговый вход 1           HL25    A O14 : K O_4      0x2C08   0x23  31
    10  0x08  HL40    A O17 : K O_1      0x2901      Аналоговый вход 2           HL_7    A O11 : K O_4      0x2C40   0x26  32
    11  0x0F  HL44    A O18 : K O_1      0x2980      Аналоговый выход 1          HL13    A O12 : K O_4      0x2C20   0x25  33
    12  0x0A  HL30    A O15 : K O_1      0x2904      Аналоговый выход 2          HL41    A O17 : K O_4      0x2C01   0x20  34
    13  0x09  HL36    A O16 : K O_1      0x2902      CAN                         HL45    A O18 : K O_4      0x2C80   0x27  35
    14  0x14  HL20    A O13 : K O_2      0x2A10      UART                        HL31    A O15 : K O_4      0x2C04   0x22  36
    15  0x13  HL26    A O14 : K O_2      0x2A08      SPI                         HL37    A O16 : K O_4      0x2C02   0x21  37
    16  0x16  HL_8    A O11 : K O_2      0x2A40      ЛИР                         HL17    A O13 : K O_5      0x2D10   0x2C  38
    17  0x15  HL14    A O12 : K O_2      0x2A20      Энкодер 1                   HL11    A O12 : K O_5      0x2D20   0x2D  39
    18  0x10  HL42    A O17 : K O_2      0x2A01      Энкодер 2                   HL_5    A O11 : K O_5      0x2D40   0x2E  40
    19  0x17  HL46    A O18 : K O_2      0x2A80      +12В                        HL35    A O16 : K O_5      0x2D02   0x29  41
    20  0x12  HL32    A O15 : K O_2      0x2A04      +5В                         HL29    A O15 : K O_5      0x2D04   0x2A  42
    21  0x11  HL38    A O16 : K O_2      0x2A02      +3,3В                       HL23    A O14 : K O_5      0x2D08   0x2B  43
    
    Не подключенные номера (NN) - 0x00, 0x07, 0x28, 0x2F

*/


#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"


#if !defined(STM32F3_SERIES)
    #error "STM32F3_SERIES not defined"
#endif


#include "wiz2_BLDC_debug_board.h"

//#define USE_LEGACY_SPI_INIT

#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )

#define TOTAL_LEDS 44

void spiInit();
//uint16_t spiRead(uint16_t data);

//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);


DECLARE_PIN( max6954CsPin, MAX6954_CS ); // PB12

//static void* spi2Addr = (void*)MAX6954_SPI;
void writeLedCommand( SPI_TypeDef* SPIx, umba::periph::GpioPin &csPin, uint8_t ledNo, bool ledState );
void setLedRegs( SPI_TypeDef* SPIx, umba::periph::GpioPin &csPin, bool ledState, bool bWrite );
void setLedRegOnly( uint8_t ledNo, bool ledState );
void flushLedRegs( SPI_TypeDef* SPIx, umba::periph::GpioPin &csPin );

extern uint8_t ledNoRemap[TOTAL_LEDS];



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::time_service;
    using namespace umba::periph::traits;
    using namespace umba::omanip;

    //uart::uart1.init( GPIOC, 5, GPIOC, 4, 460800 );

    lout<<"Hello F303"<<endl;

    spiInit();

    uint16_t max6954_ctrlReg = 0x0400; // register addr (0x04) and initial register value

    // Отсылаем enable shutdown - clr bit 0 in ctrl reg (inverse logic)
    umba::periph::traits::spiWrite( MAX6954_SPI, max6954_ctrlReg, max6954CsPin, spiDoWaitNotBusy );

    // Отсылаем disable shutdown - bit 0 in ctrl reg (inverse logic)
    max6954_ctrlReg |= 0x01;

    umba::periph::traits::spiWrite( MAX6954_SPI, max6954_ctrlReg, max6954CsPin, spiDoWaitNotBusy );

    // Global Clear Digit Data (R Data Bit D5) - Digit data for both planes P0 and P1 are cleared on the rising edge of CS.
    umba::periph::traits::spiWrite( MAX6954_SPI, max6954_ctrlReg | 0x20, max6954CsPin, spiDoWaitNotBusy );

    // Digit data for both planes P0 and P1 are unaffected
    umba::periph::traits::spiWrite( MAX6954_SPI, max6954_ctrlReg       , max6954CsPin, spiDoWaitNotBusy );

    // Бит Global blink после старта равен 0 (Blink function is disabled.), ничего не делаем

    // Бит Global Intensity после старта равен 0 - интенсивность устанавливает глобально для всех, ничего не делаем

    // Устанавливаем интенсивность свечения
    // Регистр Global Intensity 0x02
    // Интенсивность 0x0F - максимальная
    umba::periph::traits::spiWrite( MAX6954_SPI, 0x020F, max6954CsPin, spiDoWaitNotBusy );

    // Устанавливаем режим всех индикаторов в режим 7ми сегментов (биты цифр равны 0)
    // Digit Type register: addr = 0x0C  (see Table 12)
    umba::periph::traits::spiWrite( MAX6954_SPI, 0x0C00, max6954CsPin, spiDoWaitNotBusy );

    // Устанавливаем режим декодирования -
    // декодирование в HEX не нужно, мы управляем отдельными светодиодами
    // DecodeMode register: addr = 0x01 (see Table 14)
    // Each bit means:  0 - No decode for digit pair
    //                  1 - Hexadecimal decode for digit pair
    umba::periph::traits::spiWrite( MAX6954_SPI, 0x0100, max6954CsPin, spiDoWaitNotBusy );


    setLedRegs( MAX6954_SPI, max6954CsPin, true, true );
    delayMs(300);
    setLedRegs( MAX6954_SPI, max6954CsPin, false, true );
    

    // void flushLedRegs( SPI_TypeDef* SPIx, umba::periph::GpioPin &csPin );



    // #define READ_TEST


    #ifdef READ_TEST

        // 1010 0101
        // 0x80 - Аналоговый выход 1
        // 0x20 - Аналоговый вход 1
        // 0x04 - Аналоговый выход 2
        // 0x01 - Аналоговый вход 2

        umba::periph::traits::spiWrite( MAX6954_SPI, 0x29A5, max6954CsPin, spiDoWaitNotBu );


    #else

        //#define SLOW_MO

        #ifndef SLOW_MO
            unsigned delayVal     = 8;
            unsigned delaySlowVal = 8;
            unsigned delayFastVal = 4;
        #else
            unsigned delayVal     = 350;
            unsigned delaySlowVal = 350;
            unsigned delayFastVal = 350;
        #endif

    #endif

    //static uint16_t regVal = 0;

    while(true)
    {
        #ifdef READ_TEST

        /*
        Чтобы прочитать регистр, нужно отправить что-нибудь на его адрес с поднятым старшим битом.
        Биты данных игнорируются.
        
        */

        umba::periph::traits::spiWrite( MAX6954_SPI, 0x2900 | 0x8000, max6954CsPin, spiDoWaitNotBu );
        //spiChipSelectPause();
        //uint16_t 
        regVal = umba::periph::traits::spiRead( MAX6954_SPI, 0, max6954CsPin );
        regVal &= 0xFF;
        
        // Если нужно посмотреть только осцилограммы на дискавери, то нужно закоментить
        // Если подключен MAX6954, то раскомментить
        //UMBA_ASSERT((regVal&0xFF)==0xA5);

        delayMs(10);


        #else

            for( auto ledNo = 0; ledNo!=TOTAL_LEDS; ++ledNo)
            {
                writeLedCommand( MAX6954_SPI, max6954CsPin, ledNo, true );
                delayMs(delayVal);
            }
            
            for( auto ledNo = 0; ledNo!=TOTAL_LEDS; ++ledNo)
            {
                writeLedCommand( MAX6954_SPI, max6954CsPin, ledNo, false );
                delayMs(delayVal);
            }
            
            for( auto ledNo = 0; ledNo!=TOTAL_LEDS/2; ++ledNo)
            {
                writeLedCommand( MAX6954_SPI, max6954CsPin, ledNo             , true );
                writeLedCommand( MAX6954_SPI, max6954CsPin, ledNo+TOTAL_LEDS/2, true );
                delayMs(delayVal);
            }
            
            for( auto ledNo = 0; ledNo!=TOTAL_LEDS/2; ++ledNo)
            {
                writeLedCommand( MAX6954_SPI, max6954CsPin, ledNo             , false );
                writeLedCommand( MAX6954_SPI, max6954CsPin, ledNo+TOTAL_LEDS/2, false );
                delayMs(delayVal);
            }
            
            //int minus5 = -5;
            int snakeLen = 5;
            
            setLedRegs( MAX6954_SPI, max6954CsPin, false, false );
            
            auto piuPiu = [&]( bool g, bool r )
            {
            
                for( int i = -snakeLen; i< (TOTAL_LEDS/2+snakeLen); ++i )
                {
                    setLedRegs( MAX6954_SPI, max6954CsPin, false, false );
                    for(int s = 0; s!=snakeLen; ++s )
                    {
                        int ledNo = i+s;
                        if (ledNo<0 || ledNo>=TOTAL_LEDS/2)
                            continue;
                        if (g)
                            setLedRegOnly((uint8_t)ledNo               , true);
                        if (r)
                            setLedRegOnly((uint8_t)(ledNo+TOTAL_LEDS/2), true);
                    }
                    flushLedRegs( MAX6954_SPI, max6954CsPin );
                    delayMs(delayFastVal);
                }
            };
            
            piuPiu( true , false );
            piuPiu( true , false );
            piuPiu( false, true  );
            piuPiu( false, true  );
            piuPiu( true , true  );
            piuPiu( true , true  );

        #endif

    }

    return 0;
}






void spiInit()
{

    // SPI hints
    // 8/16 - https://diymcblog.blogspot.com/2018/03/spi-stm32-2.html
    // Статусы - http://www.cyberforum.ru/arm/thread2091007.html
    // Полезная инфа - https://microtechnics.ru/stm32-s-nulya-interfejs-spi/
    //   Важное дополнение – инициализация GPIO должна происходить после инициализации SPI, иначе могут возникнуть сбои в работе Slave.

    using namespace umba::periph::traits;

    periphInit( MAX6954_SPI                      // SPI2
              , MAX6954_SPI_SCK_GPIO_PIN_ADDR    // PB13
              , MAX6954_SPI_MISO_GPIO_PIN_ADDR   // PB14
              , MAX6954_SPI_MOSI_GPIO_PIN_ADDR   // PB15
              , umba::periph::traits::spiDataBits16
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              , umba::periph::traits::spiPrescalerLowFreq
              , PinSpeed::low
              );

    max6954CsPin = true;

/*
    CPOL_CPHA   - clk - инверсный, данные - прямой
    nCPOL_CPHA  - Оба сигнала нормальная логика
    CPOL_nCPHA  - Оба сигнала инверсная логика
    nCPOL_nCPHA - clk - прямой, дата инверсная

    PinSpeed::low
    PinSpeed::medium
    PinSpeed::fast
    PinSpeed::high

*/

}

volatile
uint8_t ledRegs[6] = { 0 };


void setLedRegs( SPI_TypeDef* SPIx, umba::periph::GpioPin &csPin, bool ledState, bool bWrite )
{
    uint8_t v = ledState ? 0xFF : 0x00;
    for(auto i=0; i!=6; ++i)
    {
        ledRegs[i] = v;
    }

    if (bWrite)
        flushLedRegs( SPIx, csPin );
}

void flushLedRegs( SPI_TypeDef* SPIx, umba::periph::GpioPin &csPin )
{
    using namespace umba::periph::traits;
    for(auto regNo=0; regNo!=6; ++regNo)
    {
        uint16_t sendVal = 0x2800+(regNo<<8)+ledRegs[regNo];
        umba::periph::traits::spiWrite( SPIx, sendVal, csPin, spiDoWaitNotBusy );
        umba::time_service::delayMs(1);
    }
}

void setLedRegOnly( uint8_t ledNo, bool ledState )
{
    UMBA_ASSERT( ledNo<TOTAL_LEDS );
    ledNo = ledNoRemap[ledNo];

    uint8_t regNo  = (ledNo>>3) & 0x07;
    uint8_t bitNo  = ledNo     & 0x07;
    uint8_t bitVal = 1 << bitNo;

    if (ledState)
        ledRegs[regNo] |= bitVal;
    else
        ledRegs[regNo] &= ~bitVal;
}

void writeLedCommand( SPI_TypeDef* SPIx, umba::periph::GpioPin &csPin, uint8_t ledNo, bool ledState )
{
    using namespace umba::periph::traits;

    UMBA_ASSERT( ledNo<TOTAL_LEDS );
    ledNo = ledNoRemap[ledNo];

    uint8_t regNo  = (ledNo>>3) & 0x07;
    uint8_t bitNo  = ledNo     & 0x07;
    uint8_t bitVal = 1 << bitNo;

    if (ledState)
        ledRegs[regNo] |= bitVal;
    else
        ledRegs[regNo] &= ~bitVal;

    umba::periph::traits::spiWrite( SPIx, 0x2800+(regNo<<8)+ledRegs[regNo], csPin, spiDoWaitNotBusy );

}


uint8_t ledNoRemap[TOTAL_LEDS] = {
// green
(uint8_t)0x02, 
(uint8_t)0x01, 
(uint8_t)0x03, 
(uint8_t)0x05, 
(uint8_t)0x04, 
(uint8_t)0x06, 
(uint8_t)0x0C, 
(uint8_t)0x0B, 
(uint8_t)0x0E, 
(uint8_t)0x0D, 
(uint8_t)0x08, 
(uint8_t)0x0F, 
(uint8_t)0x0A, 
(uint8_t)0x09, 
(uint8_t)0x14, 
(uint8_t)0x13, 
(uint8_t)0x16, 
(uint8_t)0x15, 
(uint8_t)0x10, 
(uint8_t)0x17, 
(uint8_t)0x12, 
(uint8_t)0x11, 
// red
(uint8_t)0x1C, 
(uint8_t)0x1B, 
(uint8_t)0x1E, 
(uint8_t)0x1D, 
(uint8_t)0x18, 
(uint8_t)0x1F, 
(uint8_t)0x1A, 
(uint8_t)0x19, 
(uint8_t)0x24, 
(uint8_t)0x23, 
(uint8_t)0x26, 
(uint8_t)0x25, 
(uint8_t)0x20, 
(uint8_t)0x27, 
(uint8_t)0x22, 
(uint8_t)0x21, 
(uint8_t)0x2C, 
(uint8_t)0x2D, 
(uint8_t)0x2E, 
(uint8_t)0x29, 
(uint8_t)0x2A, 
(uint8_t)0x2B
};
