#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"


#include "periph/stm32_traits.h"
#include "vtx2_config.h"

#include "scalcus/pwm.h"
#include "scalcus/pid.h"
#include "scalcus/percent.h"


#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "psensor.h"






#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

   umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );

#endif

umba::SimpleFormatter  lout(&charWritter);




#define CON_UART DEBUG_TERMINAL_LEGACY_UART

//#define KBD_TEST

//#define IMPELLER_SIMPLE_UP_DOWN



#ifdef STM32F1_SERIES

    uint32_t escPwmStandby =  1020;
    uint32_t escPwmDelta   =    5;
    uint32_t escPwmMin     =  escPwmStandby + 60; // escPwmDelta;
    uint32_t escPwmMax     = 2000;

#else

    uint32_t escPwmStandby =  800;
    uint32_t escPwmDelta   =    5;
    uint32_t escPwmMin     =  escPwmStandby + 60; // escPwmDelta;
    uint32_t escPwmMax     = 2300;


#endif

uint32_t pwmCtrl = escPwmStandby; // mode - microsec

uint32_t pwmFreq = 50; // Hz


static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;


void initTimer( uint32_t pwmFreq );


double pressureValue = 0.0;
double minPressure = 0.0;
double maxPressure = 50.0; // in millibar

//scalcus::PidController pidController(4.0, 1.0, 0.005);
//scalcus::PidController pidController(20.0, 1.0, 0.005);
scalcus::PidController pidController(20.0, 5.0, 0.005);
bool impellerActive = false;
umba::time_service::TimeTick impellerLastTick; 

void impellerStart();
void impellerStop();


void printState();

#ifdef STM32F1_SERIES

#else

I2cPort i2c;

#endif

auto psensorHandler = [&](bool fLinkGood, HoneywellPressureSensorState sensorState, HoneywellFloat val)
                      {
                          //lout<<"Val: "<<val<<"\n";
                          printState();
                      };

#ifdef STM32F1_SERIES

    auto pSensor = HoneywellPressureSensor< decltype(psensorHandler) >( PSENSOR_I2C_SDA_GPIO_PIN_ADDR
                                                                      , PSENSOR_I2C_SCL_GPIO_PIN_ADDR
                                                                      , 0x28 // deviceBusAddr
                                                                      , psensorHandler
                                                                      );

#else

    auto pSensor = HoneywellPressureSensor< decltype(psensorHandler) >( i2c
                                          , umba::periph::dirty::I2cInitializer( PSENSOR_I2C, 100000, 0x15 // self addr - от балды
                                                                               , PSENSOR_I2C_SCL_GPIO, PSENSOR_I2C_SCL_GPIO_PIN_NO
                                                                               , PSENSOR_I2C_SDA_GPIO, PSENSOR_I2C_SDA_GPIO_PIN_NO
                                                                               )
                                          , 0x28 // deviceBusAddr
                                          , psensorHandler
                                          );

#endif



unsigned pwmPulseOutputMax = 0;

int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;

    


    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );

    umba::time_service::delayMs(300);


    initTimer(pwmFreq);


    pSensor.init();

    using namespace umba::omanip;




    lout<<feed<<"Starting"<<endl;


    auto kbdHandler = umba::periph::makeKeyboardHandler
                    ( 
                         [&]( unsigned vkc, bool fPressed, size_t repeatCout )
                         {
                             using namespace umba::omanip;

                             #ifndef KBD_TEST

                             #ifndef IMPELLER_SIMPLE_UP_DOWN
                             if (fPressed)
                             {
                                 uint32_t pwmCtrlPrev = pwmCtrl;
                                 if (vkc == umba::periph::VirtualKeyCode::up || vkc == umba::periph::VirtualKeyCode::pageUp )
                                 {
                                     if (impellerActive)
                                     {
                                         pressureValue += 0.25 * ( vkc == umba::periph::VirtualKeyCode::up ? 1.0 : 6.0 );
                                         if (pressureValue > 50.0)
                                             pressureValue = 50.0;
                                     }
                                     /*
                                     if (pwmCtrl!=escPwmStandby)
                                     {
                                         pwmCtrl += escPwmDelta * ( vkc == umba::periph::VirtualKeyCode::up ? 1 : 5 );
                                         if (pwmCtrl>escPwmMax)
                                             pwmCtrl = escPwmMax;
                                     }
                                     */
                                 }
                                 else if (vkc == umba::periph::VirtualKeyCode::down || vkc == umba::periph::VirtualKeyCode::pageDown )
                                 {
                                     if (impellerActive)
                                     {
                                         pressureValue -= 0.25 * ( vkc == umba::periph::VirtualKeyCode::down ? 1.0 : 6.0 );
                                         if (pressureValue < 0.0)
                                             pressureValue = 0.0;
                                     }

                                     /*
                                     if (pwmCtrl!=escPwmStandby)
                                     {
                                         pwmCtrl -= escPwmDelta * ( vkc == umba::periph::VirtualKeyCode::down ? 1 : 5 );
                                         if (pwmCtrl<escPwmMin)
                                             pwmCtrl = escPwmMin;
                                     }
                                     */
                                 }
                                 else if (vkc == umba::periph::VirtualKeyCode::enter || vkc == umba::periph::VirtualKeyCode::ins )
                                 {
                                     if (repeatCout<2)
                                     {
                                         if (!impellerActive)
                                             impellerStart();
                                         else
                                             impellerStop();
                                     
                                     }

                                     /*
                                     if (repeatCout<2)
                                     {
                                         if (pwmCtrl==escPwmStandby)
                                             pwmCtrl = escPwmMin;
                                         else
                                             pwmCtrl = escPwmStandby;
                                     }
                                     */
                                 }

                                 /*
                                 if (pwmCtrlPrev != pwmCtrl)
                                 {
                                     printState();
                                     lout<<"Set PWM: "<<pwmCtrl<<" us"<<endl;
                                     umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                                                          , pwmFreq, pwmPulseOutputMax
                                                                          , umba::periph::traits::TimerPwmControlType::microsecs
                                                                          , pwmCtrl
                                                                          );
                                 }
                                 */


                             }

                             #endif /* IMPELLER_SIMPLE_UP_DOWN */

                             #else
                             if (vkc & umba::periph::VirtualKeyCode::virtualCodeFlag)
                                lout<<umba::periph::VirtualKeyCode::getKeyCodeName(vkc); //<<endl;
                             else
                                lout<<(char)(uint8_t)(vkc); //<<endl;
                             if (fPressed)
                                lout<<" pressed, count: "<<repeatCout<<endl;
                             else
                                lout<<" released"<<endl;
                             #endif

                         }
                    );

    umba::periph::legacy::UartTerminalKeyboard kbd = umba::periph::legacy::UartTerminalKeyboard( &kbdHandler, & CON_UART);


    unsigned n = 0;
    bool directionDown = false;

    uint32_t pwmCtrlDx = 3;

    #if !defined(KBD_TEST) && !defined(IMPELLER_SIMPLE_UP_DOWN)

        umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                             , pwmFreq, pwmPulseOutputMax
                                             , umba::periph::traits::TimerPwmControlType::microsecs
                                             , pwmCtrl
                                             );

    #endif

    

    lout<<"Started\n\n"<<flush;

    while(1)
    {

        pSensor.poll();

        if (impellerActive)
        {
            uint32_t pwmCtrlPrev = pwmCtrl;

            if (!pSensor.getLinkGood() || !pSensor.isSensorStateGood())
            {
                pwmCtrl = escPwmMax;
            }
            else
            {
                umba::time_service::TimeTick curTick  = umba::time_service::getCurTimeMs();
                umba::time_service::TimeTick tickDiff = curTick - impellerLastTick;
                if (tickDiff)
                {
                    impellerLastTick = curTick;
                    double timeScale = tickDiff / 1000.0;
                    /*
                    double currentPressurePermille = scalcus::calcPermille<double>(pSensor.getValue(), minPressure, maxPressure);
                    double setPressurePermille     = scalcus::calcPermille<double>(pressureValue, minPressure, maxPressure);
                    double impactPermille = pidController.calculateImpact( setPressurePermille, currentPressurePermille, timeScale );
                   
                    double impactPermilleNormalized = impactPermille;
                   
                    if (impactPermilleNormalized<0.0)
                    {
                        impactPermilleNormalized = 0.0;
                        pidController.reset();
                     }
                    if (impactPermilleNormalized>1000.0)
                    {
                        impactPermilleNormalized = 1000.0;
                    }
                   
                    uint32_t impactPwmCtrl = scalcus::calcValueFromPermille( impactPermille, escPwmMin, escPwmMax );
                   
                    if (impactPwmCtrl<escPwmMin)
                        impactPwmCtrl = escPwmMin;
                    if (impactPwmCtrl>escPwmMax)
                        impactPwmCtrl = escPwmMax;

                    pwmCtrl = impactPwmCtrl;
                    */

                    pwmCtrl = pidController.calculateImpact( pressureValue, (double)pSensor.getValue(), minPressure, maxPressure, escPwmMin, escPwmMax, timeScale );
                }
            }

            if (pwmCtrlPrev != pwmCtrl)
            {
                //pwmCtrl = pwmCtrlPrev;
                umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                                     , pwmFreq, pwmPulseOutputMax
                                                     , umba::periph::traits::TimerPwmControlType::microsecs
                                                     , pwmCtrl
                                                     );
            }
        
        }


        //pressureValue

        #if defined(KBD_TEST) || !defined(IMPELLER_SIMPLE_UP_DOWN)

        kbd.scanKeyboard();

        #else

        umba::time_service::delayMs(25);
        //kbd.scanKeyboard();
        if (directionDown)
        {
            pwmCtrl -= pwmCtrlDx;
            if (pwmCtrl<escPwmMin)
            {
                directionDown = false;
            }
        }
        else
        {
            pwmCtrl += pwmCtrlDx;
            //if (pwmCtrl>10000) // 1/2 of 50Hz
            if (pwmCtrl>escPwmMax) // - ESC max
            {
                directionDown = true;
            }
        }

        umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                             , pwmFreq, pwmPulseOutputMax
                                             , umba::periph::traits::TimerPwmControlType::microsecs
                                             , pwmCtrl
                                             );

        #endif
    }

    return 0;
}

//-----------------------------------------------------------------------------
void initTimer( uint32_t pwmFreq )
{
    using namespace umba::periph::traits;


    uint16_t prescalerT1 = 0;
    uint16_t periodT1    = 0;

    scalcus::calcTimerPwmPrescalerAndPeriod( SystemCoreClock, pwmFreq, prescalerT1, periodT1 );
    pwmPulseOutputMax = periodT1;

    umba::periph::traits::timerBaseInit( ESC_PWM_TIM, prescalerT1, periodT1 ); 
    umba::periph::traits::timerInitChannelPwm( ESC_PWM_TIM, ESC_PWM_TIM_CHANNEL_NO, ESC_PWM_GPIO, ESC_PWM_GPIO_PIN_NO, (periodT1+1)/pwmFreq-1, TIM_OCMode_PWM2 );
    
    timerEnable( ESC_PWM_TIM );

    timerSetCaptureCompareRegister( ESC_PWM_TIM, ESC_PWM_TIM_CHANNEL_NO, 1 );


}

//-----------------------------------------------------------------------------
void printState()
{
    using namespace umba::omanip;
    lout<<cret<<"Pressure (set): "  <<width(5)<<precision(1)<<fixed<<pressureValue
        <<"   Pressure (cur): "     <<width(5)<<precision(1)<<fixed<<pSensor.getValue()
        <<"   Pressure Raw Data: "  <<width(6)<<hex<<pSensor.getRawData()

        <<"   Sensor link: "       <<width(4) <<(pSensor.getLinkGood() ? "link" : "fail")
        <<"   Sensor state: "      <<width(12)<<pSensor.getSensorStateStr()
        <<" "                      <<width(6) <<(pSensor.isSensorStateGood() ? "(ok)" : "(fail)");

    lout<<"    "
        <<"Impeller :"<<pwmCtrl<<" ms";

}

//-----------------------------------------------------------------------------
void impellerStart()
{
    pressureValue = 0.0;
    impellerActive = true;
    pidController.reset();
    impellerLastTick = umba::time_service::getCurTimeMs();

}

//-----------------------------------------------------------------------------
void impellerStop()
{
    pressureValue = 0.0;
    impellerActive = false;
    pidController.reset();

    umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                         , pwmFreq, pwmPulseOutputMax
                                         , umba::periph::traits::TimerPwmControlType::microsecs
                                         , escPwmStandby
                                         );

}

//-----------------------------------------------------------------------------

//    double calculateImpact( double setValue, double curValue, double timeScale )
