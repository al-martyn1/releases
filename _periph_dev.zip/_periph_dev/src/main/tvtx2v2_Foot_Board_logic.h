#pragma once


//-----------------------------------------------------------------------------

#include "drivers/messages_rtkos.h"
#include "drivers/periph/legacy_uart_driver.h"
#include "drivers/periph/soft_i2c_driver.h"
#include "drivers/periph/tim_pwm_driver_impl.h"
#include "drivers/periph/adc_driver_impl.h"
#include "drivers/periph/gpio_driver_impl.h"
#include "drivers/periph/device_state_indicator_driver_impl.h"

#include "drivers/motors/esc_driver_impl.h"

#include "drivers/hid/keyboard_terminal_driver.h"

#include "drivers/sensors/honeywell_psensor_driver.h"


#include "rtkos/handlers/keyboard_hadler_impl_base.h"

#include <cstdlib>
#include <cmath>

#include "scalcus/pid.h"

#include "vtx2v2/telexertex2_types.h"
#include "vtx2v2/telexertex2_sucker_regs.h"

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
// Вся логика тут
class FootBoardLogic : public umba::ITimerHandler               // for timers
                     , public umba::rtkos::IMessageHandler      // for keyboard
                     , public umba::rtkos::IDriverClientHandler // for driver responses
                     , public umba::IIdleCapable                // полощем ганджубус тут
{

public:

    typedef umba::drivers::DriverAddress  DriverAddress;
    typedef umba::rtkos::TimerEventId     TimerEventId;
    typedef umba::rtkos::TimerId          TimerId;


    // Адреса драйверов используемой периферии

    static constexpr DriverAddress driver_address_state_indicator = DriverAddress( umba::drivers::class_id_state_indicator, 1 );


    static constexpr DriverAddress driver_address_knobs    = DriverAddress( umba::drivers::class_id_gpio  , 1 );
    //static constexpr DriverAddress driver_address_psensor  = DriverAddress( umba::drivers::class_id_sensor, 1 );
    static constexpr DriverAddress driver_address_adc      = DriverAddress( umba::drivers::class_id_adc   , 1 );
    static constexpr DriverAddress driver_address_esc      = DriverAddress( umba::drivers::class_id_esc   , 1 );
    //static constexpr DriverAddress driver_address_esc      = DriverAddress( umba::drivers::class_id_tim_pwm , 1 );


    static constexpr float idle_current_limit = 0.5; // if in idle mode, current must be less than this value
    static constexpr double min_pressure = 0.0;
    static constexpr double max_pressure = 25.0; // in millibar


    // FootBoardLogic::
    static constexpr uint32_t  esc_default_pwm_freq        =  50; // Hz

    #if 0
    // Изначально ESC работала так:
    // 800 - idle
    // 850 - старт/идл (может и поменьше, не помню)
    // 1700 - мотор жрал ампер
    // Потом что-то произошло - возможно, случайно перепрограммировал
    // Стало так:
    static constexpr uint32_t  esc_default_pwm_off_pulse   = 1540;
    static constexpr uint32_t  esc_default_pwm_idle_pulse  = 1570;
    static constexpr uint32_t  esc_default_pwm_max_pulse   = 2300;
    #endif

    // Затем, похоже, опять перепрограммировал почти обратно так:
    //static constexpr uint32_t  esc_default_pwm_off_pulse   =  830;
    //static constexpr uint32_t  esc_default_pwm_idle_pulse  =  850;
    //static constexpr uint32_t  esc_default_pwm_max_pulse   = 1300;

    // Стандартные параметры - 
    // For PWM input, motor stop / arm below 1060μs, full power at 1860μs
    // https://www.flyingtech.co.uk/sites/default/files/product_files/AfroESC%2020A%20USER%20MANUAL_0.pdf
    // BLHeliSuite
    //static constexpr uint32_t  esc_default_pwm_off_pulse   = 1040;
    //static constexpr uint32_t  esc_default_pwm_idle_pulse  = 1060;
    //static constexpr uint32_t  esc_default_pwm_max_pulse   = 1860;

    // На новой ESCшке завелось так (но только на одной):
    // static constexpr uint32_t  esc_default_pwm_off_pulse   = 1150;
    // static constexpr uint32_t  esc_default_pwm_idle_pulse  = 1200;
    // static constexpr uint32_t  esc_default_pwm_max_pulse   = 1450;

    static constexpr uint32_t  esc_default_pwm_off_pulse   =  800;

    static constexpr uint32_t  esc_default_pwm_idle_pulse  = 1065;
    //static constexpr uint32_t  esc_default_pwm_idle_pulse  = 1100;
    //static constexpr uint32_t  esc_default_pwm_idle_pulse  = 1200;

    //static constexpr uint32_t  esc_default_pwm_max_pulse   = 1575; // 1575 - 1 А, 1700 - 1.5 Ампера
    //static constexpr uint32_t  esc_default_pwm_max_pulse   = 1800; // 1575 - 1 А, 1700 - 1.5 Ампера


    #if FOOT_NUMBER==1
        static constexpr uint32_t  esc_default_pwm_presuck_pulse   = 1200;
        static constexpr uint32_t  esc_default_pwm_max_pulse       = 2200;
    #else
        static constexpr uint32_t  esc_default_pwm_presuck_pulse   = 1250;
        static constexpr uint32_t  esc_default_pwm_max_pulse       = 2400;
    #endif



    static constexpr uint16_t  psensor_i2c_address         = 0x28u;

/*
                                                      // Вполне годно    Old Вершина
    //static constexpr float default_pid_k_p = 10.000f; //  20.000f          50.000f
    static constexpr float default_pid_k_p =  8.000f; //  20.000f          50.000f
    static constexpr float default_pid_k_i =  2.000f; //   2.000f           5.000f
    static constexpr float default_pid_k_d =  0.05f ; //   0.05f            0.005f
*/
    static constexpr float default_pid_k_p =  8.000f; 
    #if FOOT_NUMBER==1
        static constexpr float default_pid_k_i = 15.000f; 
    #else
        static constexpr float default_pid_k_i =  8.000f; 
    #endif
    static constexpr float default_pid_k_d =  0.05f ; 

    static constexpr float adcScaleFactor = 1725.0;
    //static constexpr float adcScaleFactor = 1725.0/2.2;


    static constexpr uint8_t pressure_drop_failure_percent_startup = 50;
    static constexpr uint8_t pressure_drop_failure_percent         = 20; // 50;


    static constexpr umba::rtkos::TimeTick timer_request_pressure_period      = 2; // ms
    static constexpr umba::rtkos::TimeTick timer_requeste_esc_current_period  = 2; // ms
    // ms - если обнаружен отказ датчика, запускаем таймер, и надеемся, что датчик оклимается. 
    // Если через этот перид датчик таки неживой, тогда фейлимся, как задано флагом m_psensorStopOnFailure
    static constexpr umba::rtkos::TimeTick timer_knobs_period                      =   25; 
    static constexpr umba::rtkos::TimeTick timer_psensor_failure_period            =  300; 
    static constexpr umba::rtkos::TimeTick timer_pid_period                        =    5; 
    static constexpr umba::rtkos::TimeTick timer_idle_check_motor_failure_period   =  200; // полсекунды на раскачку
    static constexpr umba::rtkos::TimeTick timer_starting_check_pressure_period    = 1500; // 1.5 секунды на присос 
    static constexpr umba::rtkos::TimeTick timer_check_pressure_period             =  500; // 1.5 секунды на резкий отлип

    static constexpr TimerEventId timer_event_knobs                      = 0; // таймер на опрос датчиков касания
    static constexpr TimerEventId timer_event_request_pressure           = 1; // таймер на опрос давления
    static constexpr TimerEventId timer_event_requeste_esc_current       = 2; // таймер на опрос тока импеллера
    static constexpr TimerEventId timer_event_psensor_failure            = 3; // таймер на остутствие связи с датчиком
    static constexpr TimerEventId timer_event_pid                        = 4; // таймер для PID регулятора
    static constexpr TimerEventId timer_event_idle_check_motor_failure   = 5; // таймер на проверку тока мотора на холостом ходу
    static constexpr TimerEventId timer_event_starting_check_pressure    = 6; // таймер на проверку достижения заданного давления
    static constexpr TimerEventId timer_event_check_pressure             = 7; // таймер на проверку достижения заданного давления

    static constexpr TimerEventId timer_event_do_job                     = 8; // таймер полировки
    
    //static constexpr TimerEventId timer_event_esc_decrease_pwm_on_current_limit = 6; // таймером мы 
    //static constexpr TimerEventId timer_event_emergency_rollback         = 7;
                                                                         

    static constexpr float delta_pressure_adjustment_step_size = 10.0f /* 2.5f */  * timer_pid_period / 1000.0f;

    DriverAddress                 psensorDriverAddr;

    

    UMBA_BEGIN_INTERFACE_MAP_EX( umba::ITimerHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IMessageHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IDriverClientHandler )
    UMBA_END_INTERFACE_MAP()

    UMBA_DELEGATE_QUERY_INTERFACE(umba::ITimerHandler)


    FootBoardLogic()
    {
        pwmAverager.setMaxCount(8);
    }

    // хелпер для установки таймера
    umba::rtkos::TimerId timerSet( umba::rtkos::TimerEventId eventId, umba::rtkos::TimeTick period )
    {
        return umba::rtkos::timerSet( this, eventId, period );
    }

protected:

    // Хелпер для инсталляции логики в систему
    void installDriverHandler( DriverAddress addrFrom )
    {
        timerSet( timer_event_do_job, 5 );        
        umba::rtkos::driverHandlerAdd( addrFrom, this );
    }

public:

    // Установка в систему
    bool install()
    {
        UMBA_RTKOS_OS->messagesSetHandler( umba::rtkos::message_keyboard_id, this );
        installDriverHandler(psensorDriverAddr);
        installDriverHandler(driver_address_adc    );
        installDriverHandler(driver_address_knobs  );
        auto prevIdleHandler = UMBA_RTKOS_OS->setIdleHandler( this );
        return prevIdleHandler==0; // Если кто-то уже занял обработчик идлы, то ошибка
        //return UMBA_RTKOS_OS->setIdleHandler( this );
    }

protected:

    enum class EscMode : uint8_t
    {
        stopped   = 0,
        stop      = 0,
        idle      = 1,
        start     = 2,
        started   = 2
    };

    // enum class methods - http://ideone.com/AkvqY7
    enum class SuckerMachineState
    {
        stopped,
        idling,

        // если Игорь отсылает команду на старт без промежуточного идлинга, то мы сами в него заходим, 
        // делаем всё как в идлинге, а потом сами перескакиваем в starting
        idling_to_start,

        idling_to_presuck,

        presuck,

        stopped_on_failure, // из этого состояния нет выхода, кроме как по обновлению suckerMode
        //psensor_wait_failure, // psensor помер, ждем, не оживет ли
        starting,
        //started_wait_pressure, // стартовали, установили ожидаемое давление, теперь ждем секунду и проверяем текущее давление
        started,
        started_wait_for_pressure_fail_stop

    };


    SuckerMachineState            m_suckerMachineState   = SuckerMachineState::stopped;     // состояние внутреннего автомата

    SuckerMode                    m_suckerMode           = SuckerMode::stopped; // Стоять
    SuckerErrorFlags::value_type  m_suckerErrorsState    = SuckerErrorFlags::no_errors; // Когда пишем в статус, объединяем с suckerMode

    volatile bool                 m_psensorGood          = true;  // По умолчанию - хорош. Если на старте не сработает, то по изменению будем реагировать
    volatile bool                 m_psensorStopOnFailure = false; // Остановиться при сбое датчика или пилить на среднем?
                                
    volatile float                m_currentPressureValue = 0.0; // текущее значение
    volatile float                m_targetPressureValue  = 0.0; // то, что надо получить
    volatile float                m_pressureValue        = 0.0; // плавно меняется
                                
    volatile uint16_t             m_escRawCurrentValue   = 0;
    volatile float                m_escCurrentValue      = 0.0; // ток на импеллере
    volatile float                m_escCurrentLimit      = 0.0; // лимит тока на импеллере

    volatile float                m_pidK_p               = default_pid_k_p;
    volatile float                m_pidK_i               = default_pid_k_i;
    volatile float                m_pidK_d               = default_pid_k_d;

    volatile unsigned             showLiveInfoLevel      = 0;

    volatile bool                 singleLineMode         = true;

    volatile bool                 m_checkingEngine       = false;
                                
    uint32_t                      m_escIntervalOff  = 0;
    //uint32_t                      m_escIntervalMin  = 0;
    uint32_t                      m_escIntervalIdle = 0;
    uint32_t                      m_escIntervalMax  = 0;
    // Интервал, если отвалился датчик давления. 
    // Пересчитать при изменении m_escIntervalIdle и m_escIntervalMax
    uint32_t                      m_escIntervalNoPSensor = 0; 

    uint32_t                      m_escCurrentDuty  = 0;

    umba::rtkos::TimerId          m_timerCheckPressureTimerId = umba::rtkos::timer_id_invalid;
    uint8_t                       m_pressureDropFailurePercentStartup = pressure_drop_failure_percent_startup;
    uint8_t                       m_pressureDropFailurePercent        = pressure_drop_failure_percent        ;

    scalcus::Averager<uint32_t,uint32_t,32>         pwmAverager;


    scalcus::PidController        m_pidController = scalcus::PidController(m_pidK_p, m_pidK_i, m_pidK_d);

    static
    const char* toStr( EscMode e )
    {
        switch(e)
        {
            case EscMode::stopped: return "stopped";
            case EscMode::idle   : return "idle";
            case EscMode::started: return "started";
            default: return "unknown";
        };
    }

    static
    const char* toStr( SuckerMachineState s )
    {
        switch(s)
        {
            case SuckerMachineState::stopped                     : return "stopped";
            case SuckerMachineState::idling                      : return "idling";
            case SuckerMachineState::idling_to_start             : return "idling_to_start";
            case SuckerMachineState::idling_to_presuck           : return "idling_to_presuck";
            case SuckerMachineState::presuck                     : return "presuck";
            case SuckerMachineState::stopped_on_failure          : return "stopped_on_failure";
            case SuckerMachineState::starting                    : return "starting";
            case SuckerMachineState::started                     : return "started";
            // case SuckerMachineState::started_wait_for_pressure_fail_stop: return ""; // not used
            default: return "unknown";
        };
    }

    static
    const char* toStr( SuckerMode m )
    {
        switch(m)
        {
            case SuckerMode::stopped: return "stopped";
            case SuckerMode::idle   : return "idle";
            case SuckerMode::presuck: return "presuck";
            case SuckerMode::sucking: return "sucking";
            default: return "unknown";
        };
    }


    void showDetailedInfo( )
    {
        UMBA_RTKOS_LOG<<"-----------------------------------------------------\n"
            <<"Machine state: "<<(unsigned)m_suckerMachineState<<"\n"
            <<"Sucker Mode  : "<<(unsigned)m_suckerMode<<"\n"
            <<"Error flags  : "<<hex<<m_suckerErrorsState<<"\n"
            <<"PSensor state: "<< (m_psensorGood ? normal : error) << (m_psensorGood ? "Ok" : "No link")<<"\n"
            <<"PSensor stop on failure: "<< m_psensorStopOnFailure <<"\n"
            <<"Current pressure: "<<m_currentPressureValue<<"\n"
            <<"Target pressure : "<<m_targetPressureValue<<"\n"
            <<"Pressure        : "<<m_pressureValue<<"\n"
            <<"Esc Current     : "<<m_escCurrentValue<<"\n"
            <<"Esc Current Lim : "<<m_escCurrentLimit<<"\n"
            <<"Esc Duty value  : "<<m_escCurrentDuty<<"\n"

            <<endl;


    }

    void showState( bool newLine = true )
    {
        using namespace umba::omanip;

        if (showLiveInfoLevel!=0)
            return;

        if (m_suckerMachineState==SuckerMachineState::stopped_on_failure || m_suckerMachineState==SuckerMachineState::stopped)
            return;

        UMBA_RTKOS_LOG<<"PWM: "<<width(4)<<m_escCurrentDuty<<"  "
                      <<"Iesc: "<<width(6)<<m_escCurrentValue<<"  "
                      <<"Cur dP: "<<width(6)<<m_currentPressureValue<<"  "
                      <<"Target dP: "<<width(6)<<m_targetPressureValue<<"  "
                      <<"dP: "<<width(6)<<m_pressureValue<<"  "
                      <<"MSt: "<<toStr(m_suckerMachineState)<<"  "
                      <<"PGood: "<<m_psensorGood<<"  "
                      <<"    ";
        if (newLine)
        {
            if (singleLineMode)
                UMBA_RTKOS_LOG<<cret;
            else
                UMBA_RTKOS_LOG<<endl;
        }
            //UMBA_RTKOS_LOG<<endl;

    }

    void setEscMode( EscMode m )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Set ESC mode: "<<toStr(m)<<"\n";
        #endif
        uint8_t escCtrl = (uint8_t)m;
        postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_command, escCtrl );
    }

    void setEscDutyPulse( uint32_t pulse )
    {
        #ifdef LOG_SUCKER_EVENTS
        //UMBA_RTKOS_LOG<<"Set pulse: "<<pulse<<"\n";
        #endif
        roRegs[ro::esc_pwm_u8 ] = (uint8_t)(pulse/10);
        postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse, pulse );
    }


    //---------------------------------------

public: // чтобы были видны оттуда, где ставятся колбэки на ганджубус

    //driver_address_state_indicator
    void onGanjubusLinkLost()
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<error<<"Ganjubus - Link Lost"<<normal<<"\n";
        #endif

        if (m_suckerMachineState!=SuckerMachineState::stopped)
        {
            doEmergencyStop( SuckerErrorFlags::ganjubus_failure );
            //postMessageDriverValue( driver_address_state_indicator, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_device_state_value, (uint32_t)0 );
        }
        updateGanjubusStatusReg();
    }

    void onGanjubusLinkRestored()
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<notice<<"Ganjubus - Link Restored"<<normal<<"\n";
        #endif
        // Nothing to do - witing for new commands
        // UNDONE: need to indicate normal work
        m_suckerErrorsState &= SuckerErrorFlags::ganjubus_failure;
        updateGanjubusStatusReg();
        //postMessageDriverValue( driver_address_state_indicator, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_device_state_value, (uint32_t)1 );
    }

    void onGanjubusDataReceived()
    {
        // UNDONE: need to indicate data transfering
        postMessageDriverValue( driver_address_state_indicator, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_device_activity_value, (uint32_t)0 );
    }

    uint8_t calcPressureDeltaPercent( )
    {
        if ( m_currentPressureValue < m_pressureValue ) // не достигли заданного
        {
            float deltaP = m_pressureValue - m_currentPressureValue;
            return (uint8_t)(100.0f*deltaP / m_pressureValue + 0.5f );
        }
        return 0;
    }



protected:

    //---------------------------------------
    // Основная логика
    //---------------------------------------

    virtual
    void onTimer( unsigned eventId ) override
    {
        switch( eventId )
        {
            case timer_event_do_job:
                 doJob();
                 break;

            case timer_event_knobs:
                 postMessageDeviceValueRequest( driver_address_knobs, 0 );
                 break;

            case timer_event_request_pressure:
                 postMessageDeviceValueRequest( psensorDriverAddr, 0 ); // pressure value id is 0, I know it
                 break;

            case timer_event_requeste_esc_current: 
                 postMessageDeviceValueRequest( driver_address_adc, 0 ); // current value id is 0, I know it
                 break;

            case timer_event_starting_check_pressure:
                 // UNDONE:
                 timerSet( timer_event_starting_check_pressure, 0 ); // стопарим таймер проверки давления

                 // m_pressureValue может не успеть дорасти до m_targetPressureValue
                 // но m_currentPressureValue не должно сильно отличаться от m_pressureValue
                 {
                     //uint8_t percentDeltaP = calcPressureDeltaPercent( );
                     //if (percentDeltaP>m_pressureDropFailurePercentStartup) // отличие на 25 процентов или больше
                     if (m_currentPressureValue < 1.5)
                     {
                         doEmergencyStop( SuckerErrorFlags::pressure_failure );
                     }
                 }

                 // если были в starting'е, то переместились в started
                 // если были в started, то ваще ничего не поменялось
                 m_suckerMachineState = SuckerMachineState::started;

                 break;


            // Если во время работы давление критично понизилось, то запускается данный таймер.
            // Если таймер сработал и давление всё же низкое - то это авария
            case timer_event_check_pressure:
                 timerSet( timer_event_check_pressure, 0 ); // стопарим таймер проверки давления
                 m_timerCheckPressureTimerId = umba::rtkos::timer_id_invalid;

                 {
                     //UMBA_RTKOS_LOG<<"Timer hits"<<endl;
                     //uint8_t percentDeltaP = calcPressureDeltaPercent( );
                     //if (percentDeltaP>m_pressureDropFailurePercent) // отличие на 50 процентов или больше
                     if (m_currentPressureValue<1.5)
                     {
                         //UMBA_RTKOS_LOG<<"Delta hits"<<endl;
                         doEmergencyStop( SuckerErrorFlags::pressure_failure );
                     }
                 }
                 break;

            case timer_event_pid:
                 {
                     // Проверяем, не отвалились ли мы
                     unsigned percentDeltaP = 0;
                     if (m_suckerMachineState==SuckerMachineState::started)
                     {
                         //uint8_t percentDeltaP = calcPressureDeltaPercent( );
                         //if (percentDeltaP>m_pressureDropFailurePercent) // отличие на 50 процентов или больше
                         if (m_currentPressureValue < 1.5)
                         {
                             if (m_timerCheckPressureTimerId==umba::rtkos::timer_id_invalid)
                             {
                                 // запускаем таймер проверки давления
                                 m_timerCheckPressureTimerId = umba::rtkos::timer_id_invalid==timerSet( timer_event_check_pressure, timer_check_pressure_period );
                             }
                         }
                         else
                         {
                             // а сбрасываем в обработчике таймера
                         }
                     }

                     // плавно увеличиваем целевое давление
                     float stepSize        = delta_pressure_adjustment_step_size;
                     float tgtCurDelta     = m_targetPressureValue - m_pressureValue;
                     float absTgtCurDelta  = std::fabs(tgtCurDelta);

                     if ( stepSize > absTgtCurDelta )
                          stepSize = absTgtCurDelta;

                     if (tgtCurDelta<0.0f)
                         stepSize = -stepSize;

                     m_pressureValue += stepSize;

                     // проверяем, а не изменилось ли состояние датчика давления?
                     // На самом деле, таймер запускается в обработчике сенсора всегда по смене состояния


                     // а теперь нам надо пидалить
                     if (!m_psensorGood)
                     {
                         // нет сенсора - не пидалим
                         m_escCurrentDuty = m_escIntervalNoPSensor;
                         setEscDutyPulse(m_escCurrentDuty);
                     }
                     else
                     {
                         // Пидалим
                         double timeScale = (double)timer_pid_period / 1000.0;
                         uint32_t newPwmCtrl = m_pidController.calculateImpact( (double)m_pressureValue /* setVal */ , (double)m_currentPressureValue /* curVal */ 
                                                                              , min_pressure /* masterMin */ , max_pressure /* masterMax */ 
                                                                              , m_escIntervalIdle /* slaveMin */ , m_escIntervalMax /* slaveMax */ 
                                                                              , timeScale
                                                                              );


                         float currentLimit = m_escCurrentLimit - 0.1f;
                         if (currentLimit<0.0f)
                             currentLimit = 0.0f;

                         bool allowSetNewPwm = true;
                         bool disallow1 = false;
                         bool disallow2 = false;


                         // Это не сработает, если лимит тока был уменьшен
                         // (потому что мы уже успели задать ширину PWM)
                         // Хотя лимит по току можно задавать во время работы, 
                         // его уменьшение будет применяться 
                         // только после перезапуска импеллера
                         if (m_escCurrentValue >= currentLimit)
                         {
                             disallow1 = true;
                             allowSetNewPwm = false;
                         }

                         if (newPwmCtrl>m_escIntervalMax)
                         {
                             disallow2 = true;
                             allowSetNewPwm = false;
                         }

                         if (showLiveInfoLevel)
                         {
                             auto tickNow = umba::time_service::getCurTimeMs();

                             UMBA_RTKOS_LOG<<width(6)<<tickNow<<"  "
                                           <<width(6)<<precision(2)<<(tickNow)/1000.0f<<"  "
                                           <<"Tgt dP: "<<width(6)<<precision(2)<<m_targetPressureValue<<"  "
                                           <<"Active dP: "<<width(6)<<precision(2)<<m_pressureValue<<"  "
                                           <<"Step dP: "<<width(6)<<stepSize<<"  "
                                           <<"Meassured dP: "<<width(6)<<precision(2)<<m_currentPressureValue<<"  "
                                           <<"Cur PWM: "<<width(4)<<m_escCurrentDuty<<"  "
                                           <<"New PWM: "<<width(4)<<newPwmCtrl<<"  "
                                           <<"Current: "<<width(6)<<precision(2)<<m_escCurrentValue<<"  "
                                           <<"Raw cur: "<<width(4)<<m_escRawCurrentValue<<"  "
                                           <<"DA1: "<<disallow1<<"  "
                                           <<"DA2: "<<disallow2<<"  "
                                           <<"dP misshit: "<<width(4)<<percentDeltaP<<"%  ";
                                           
                             if (singleLineMode)
                                 UMBA_RTKOS_LOG<<cret;
                             else
                                 UMBA_RTKOS_LOG<<endl;
                         }

                         bool bUpdatePulse = false;

                         if ( newPwmCtrl < m_escCurrentDuty )
                         {
                             bUpdatePulse = m_escCurrentDuty != newPwmCtrl;
                             m_escCurrentDuty = newPwmCtrl;
                         }
                         else
                         {
                             if (allowSetNewPwm)
                             {
                                 bUpdatePulse = m_escCurrentDuty != newPwmCtrl;
                                 m_escCurrentDuty = newPwmCtrl;
                             }
                         }

                         if (bUpdatePulse)
                         {
                             //pwmAverager.addValue(m_escCurrentDuty);
                             //setEscDutyPulse(pwmAverager.getAverageValue());
                             setEscDutyPulse(m_escCurrentDuty);
                         }
                     }
                 }
                 break;

            case timer_event_idle_check_motor_failure:
                 timerSet( timer_event_idle_check_motor_failure, 0 ); // остановка таймера проверки мотора - таймер однократный
                 m_checkingEngine = false;
                 if (m_escCurrentValue>=idle_current_limit)
                 {
                     // motor failure
                     doEmergencyStop( SuckerErrorFlags::impeller_failure );
                 }
                 else
                 {
                     if (m_suckerMachineState==SuckerMachineState::idling_to_start   
                      || m_suckerMachineState==SuckerMachineState::idling_to_presuck 
                        )
                     {
                         doStart();
                     }
                 }
                 break;

            case timer_event_psensor_failure: // timer_psensor_failure_period:
                 timerSet( timer_event_psensor_failure, 0 ); // таймер однократный, сработало - выключаем

                 #ifdef LOG_SUCKER_EVENTS
                 UMBA_RTKOS_LOG<<"PSensor failure timer shoots\n";
                 #endif

                 if (!m_psensorGood)
                 {
                     // Датчик так и находится в отвале
                     if (m_psensorStopOnFailure)
                     {
                         doEmergencyStop(SuckerErrorFlags::psensor_failure);
                     }
                     else // меняем состояние автомата с плохого на хорошее
                     {
                         // PID контроллер не будет использоваться, приводим его в начальное состояние
                         m_pidController.reset(); 

                         m_suckerErrorsState |= SuckerErrorFlags::psensor_failure;
                         updateGanjubusStatusReg();

                     }
                 }
                 else // m_psensorGood
                 {
                     // меняем состояние автомата с хорошего на плохое
                     // PID контроллер будет использоваться, приводим его в начальное состояние
                     m_pidController.reset(); 

                     m_suckerErrorsState &= ~ SuckerErrorFlags::psensor_failure;
                     updateGanjubusStatusReg();

                 }

                 break;
            //default:
        };

        // postMessageDriverValueRequest( ClassId classId, DriverId driverId, ValueId valueId, IDriver *pDriver = 0 )
    }

    // События от железа
    bool onHwPSensorGood( bool newState )
    {
        bool bChanged = m_psensorGood!=newState;
        m_psensorGood = newState;

        if (bChanged)
        {
            if (m_psensorGood)
                timerSet( timer_event_psensor_failure, 0 ); // выключаем таймер на потерю связи с датчиком давления
            else
                timerSet( timer_event_psensor_failure, timer_psensor_failure_period ); // запускаем таймер на потерю связи с датчиком давления
        }

        return bChanged;
    }

    bool onHwCurrentPressureValue( float newPressure ) 
    {
        bool res = std::fabs( m_currentPressureValue - newPressure ) > 0.1f;
        m_currentPressureValue = newPressure;
        roRegs[ ro::pressure_diff_u8 ] = (uint8_t)(m_currentPressureValue*10.0f+0.5f); // рапортуем delta P в 10ых долях миллибара
        return res;
    }

    bool onHwEscCurrentValue( float newValue, uint16_t rawVal ) 
    {
        bool res = std::fabs( m_escCurrentValue - newValue ) > 0.1f;
        m_escCurrentValue = newValue;
        m_escRawCurrentValue = rawVal;
        roRegs[ ro::esc_current_u8 ] = (uint8_t)(m_escCurrentValue*100.0f+0.5f); // рапортуем ток в 100ых долях ампера
        return res;
    }


    void updateGanjubusStatusReg()
    {
        roRegs[ ro::sucker_mode_u8 ] = (uint8_t)( m_suckerErrorsState | (uint8_t)m_suckerMode );
        SuckerErrorFlags::value_type fatalErrors = SuckerErrorFlags::psensor_failure | SuckerErrorFlags::impeller_failure;
        postMessageDriverValue( driver_address_state_indicator, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_device_error_value, (uint32_t)( m_suckerErrorsState&fatalErrors ? 1 : 0) );
    }

    // SuckerErrorFlags:: pressure_failure / psensor_failure / impeller_failure / ganjubus_failure / param_failure
    void doEmergencyStop( SuckerErrorFlags::value_type errorFlags )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"doEmergencyStop, cur mode: "<<toStr(m_suckerMode)<<", machine state: "<<toStr(m_suckerMachineState)<<endl;
        #endif

        setEscMode( EscMode::stop );
        setEscDutyPulse(m_escIntervalIdle); // устанавливаем скорость ХХ, на всякий случай, если в следующий раз включим, позабыв установить скорость

        timerSet( timer_event_pid, 0 ); // стопарим PID таймер (если работал)
        m_pidController.reset(); 

        m_pressureValue = 0.0;

        m_checkingEngine = false;
        timerSet( timer_event_idle_check_motor_failure, 0 ); // отключаем проверку мотора 

        m_suckerMode         =  SuckerMode::stopped;
        m_suckerMachineState =  SuckerMachineState::stopped_on_failure;
        m_suckerErrorsState  |= errorFlags;

        updateGanjubusStatusReg();

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<error<<"Emergency stop, error flags: "<<hex<<m_suckerErrorsState<<normal<<", cur mode: "<<toStr(m_suckerMode)<<", machine state: "<<toStr(m_suckerMachineState)<<endl;
        #endif
    }

    void doStop()
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"doStop, cur mode: "<<toStr(m_suckerMode)<<", machine state: "<<toStr(m_suckerMachineState)<<endl;
        #endif

        setEscMode( EscMode::stop );
        setEscDutyPulse(m_escIntervalIdle); // устанавливаем скорость ХХ, на всякий случай, если в следующий раз включим, позабыв установить скорость

        timerSet( timer_event_pid, 0 ); // стопарим PID таймер (если работал)
        m_pidController.reset(); 

        m_pressureValue = 0.0;

        m_checkingEngine = false;
        timerSet( timer_event_idle_check_motor_failure, 0 ); // отключаем проверку мотора

        m_suckerMode         =  SuckerMode::stopped;
        m_suckerMachineState =  SuckerMachineState::stopped;
        //m_suckerErrorsState  |= errorFlags;

        updateGanjubusStatusReg();

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<notice<<"Normal stop"<<normal<<", cur mode: "<<toStr(m_suckerMode)<<", machine state: "<<toStr(m_suckerMachineState)<<endl;
        #endif
    }

    // На ХХ переходим или из стоящего режима, или из рабочего
    // Можем, конечно, и из ХХ перейти опять в ХХ, но тут вообще ничего не изменится
    void doGoIdle( SuckerMachineState nextState = SuckerMachineState::idling ) // or idling_to_start
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"doGoIdle, cur mode: "<<toStr(m_suckerMode)<<", machine state: "<<toStr(m_suckerMachineState)<<endl;
        #endif


        if (!m_psensorGood && m_psensorStopOnFailure)
        {
            doEmergencyStop(SuckerErrorFlags::psensor_failure);
            return;
        }

        if ( nextState!=SuckerMachineState::idling 
          && nextState!=SuckerMachineState::idling_to_start 
          && nextState!=SuckerMachineState::idling_to_presuck 
           )
        {
            //UMBA_RTKOS_PANIC_MSG("doGoIdle: invalid next state");
        }

        if (!m_psensorGood)
        {
            m_suckerErrorsState |= SuckerErrorFlags::psensor_failure;
        }

        
        timerSet( timer_event_pid, 0 ); // стопарим PID таймер (если работал)

        if (m_suckerMachineState == SuckerMachineState::stopped)
        {
            setEscDutyPulse(m_escIntervalIdle);
            setEscMode( EscMode::idle );
            m_suckerMode =  SuckerMode::idle;
            m_pressureValue = 0.0;
        }
        else
        {
            m_pressureValue = m_currentPressureValue;
        }

        m_pidController.reset(); 
        updateGanjubusStatusReg();
        m_suckerMachineState = nextState;

        m_checkingEngine = true;
        timerSet( timer_event_idle_check_motor_failure, timer_idle_check_motor_failure_period ); // проверка мотора

        // Что еще я забыл сделать при включении холостого хода?
    
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"doGoIdle exiting, cur mode: "<<toStr(m_suckerMode)<<", machine state: "<<toStr(m_suckerMachineState)<<endl;
        #endif
    }

    void doStart()
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"doStart, cur mode: "<<toStr(m_suckerMode)<<", machine state: "<<toStr(m_suckerMachineState)<<endl;
        #endif

        if (m_suckerMachineState!=SuckerMachineState::idling
         && m_suckerMachineState!=SuckerMachineState::idling_to_start 
         && m_suckerMachineState!=SuckerMachineState::idling_to_presuck
         && m_suckerMachineState!=SuckerMachineState::presuck
           )
        {
            UMBA_RTKOS_PANIC_MSG("doStart: invalid prev state");
        }

        if (!m_psensorGood && m_psensorStopOnFailure)
        {
            doEmergencyStop(SuckerErrorFlags::psensor_failure);
            return;
        }


        m_pidController.reset(); 

        if (m_suckerMachineState==SuckerMachineState::idling_to_presuck)
        {
             m_escCurrentDuty = esc_default_pwm_presuck_pulse;
             //setEscDutyPulse(m_escCurrentDuty);
             setEscMode( EscMode::started );
             m_suckerMachineState = SuckerMachineState::presuck;
             m_suckerMode =  SuckerMode::presuck;
        }
        else
        {
            m_escCurrentDuty = esc_default_pwm_presuck_pulse; // m_psensorGood ? m_escIntervalIdle : m_escIntervalNoPSensor;
            timerSet( timer_event_pid, timer_pid_period ); // запускаем PID таймер
            //m_pressureValue = 0.0;
            m_pressureValue = m_currentPressureValue;
            m_suckerMachineState = SuckerMachineState::starting;
            m_suckerMode =  SuckerMode::sucking;
        }

        // запускаем таймер проверки давления - запускаем безусловно
        timerSet( timer_event_starting_check_pressure, timer_starting_check_pressure_period ); 

        setEscDutyPulse(m_escCurrentDuty);
        setEscMode( EscMode::started );

        updateGanjubusStatusReg();

        // Что ещё я забыл?

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"doStart, cur mode: "<<toStr(m_suckerMode)<<", machine state: "<<toStr(m_suckerMachineState)<<endl;
        #endif
    }

    void onGanjubusChangeSuckerMode( uint8_t newModeU8 )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Sucker Mode changing\n";
        #endif

        switch((SuckerMode)newModeU8)
        {
            case SuckerMode::stopped:     // В любом режиме стопимся и сбрасываем ошибки
                 m_suckerErrorsState = 0;
                 doStop();
                 break;

            case SuckerMode::idle   :     // Задано перейти в ждущий режим. Это можно сделать из любого состояния
                 m_suckerErrorsState = 0;
                 doGoIdle( SuckerMachineState::idling );
                 break;

            case SuckerMode::presuck:
                 m_suckerErrorsState = 0;
                 doGoIdle( SuckerMachineState::idling_to_presuck ); // переходим в режим presuck пробежкой через ожидалово
                 //m_suckerMachineState!=SuckerMachineState::idling_to_start 
                 break;

            case SuckerMode::sucking:
                 m_suckerErrorsState = 0;
                 //if (m_suckerMachineState == SuckerMachineState::stopped)
                     doGoIdle( SuckerMachineState::idling_to_start ); // переходим в режим работа пробежкой через ожидалово
                 //else

                 break;

            default:
                 m_suckerErrorsState = SuckerErrorFlags::param_failure;
                 doStop();
        }
    }

    void onGanjubusChangePressureCtrl( uint8_t pressureDeltaU8 )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Target pressure changing\n";
        #endif
        
        //m_targetPressureValue = ((float)pressureDeltaU8) / 10.0f;
        m_targetPressureValue = 1.15f*((float)pressureDeltaU8) / 10.0f;

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Target pressure value: "<< m_targetPressureValue <<endl;
        #endif
    }

    void onGanjubusChangeEscCurrentLimit( uint8_t curLimU8 )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Current limit changing\n";
        #endif
        
        m_escCurrentLimit = ((float)curLimU8) / 10.0f;

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Current limit value: "<< m_escCurrentLimit <<endl;
        #endif
    }


    //---------------------------------------
    // Обработчики установки параметров работы
    //---------------------------------------
    void onGanjubusChangePSensorEmergensyMode( uint8_t newModeU8 ) // m_psensorStopOnFailure
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"PSensor emergency/failure mode changing\n";
        #endif

        if (m_suckerMachineState != SuckerMachineState::stopped)
        {
            #ifdef LOG_SUCKER_EVENTS
            UMBA_RTKOS_LOG<<warning<<"Operation not valid in current state, emergency stopping with param failure"<<normal<<"\n";
            #endif
            doEmergencyStop(SuckerErrorFlags::param_failure);
        }

        m_psensorStopOnFailure = newModeU8 ? true : false; // Остановиться при сбое датчика или пилить на среднем?

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"PSensor emergency/failure mode: "<< (m_psensorStopOnFailure ? "stop on failure" : "continue on fixed speed") <<endl;
        #endif
    }

    void onGanjubusChangePidProportional( float v )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"PID Proportional K changing\n";
        #endif

        if (m_suckerMachineState != SuckerMachineState::stopped)
        {
            #ifdef LOG_SUCKER_EVENTS
            UMBA_RTKOS_LOG<<warning<<"Operation not valid in current state, emergency stopping with param failure"<<normal<<"\n";
            #endif
            doEmergencyStop(SuckerErrorFlags::param_failure);
        }

        m_pidK_p = v;
        m_pidController = scalcus::PidController(m_pidK_p, m_pidK_i, m_pidK_d);
        roRegs[ ro::sucker_pid_scale_proportional_current_f32 ] = m_pidK_p;

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"PID Proportional K value: "<<m_pidK_p<<endl;
        #endif
    }



    void onGanjubusChangePidIntegral( float v )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"PID Integral K changing\n";
        #endif

        if (m_suckerMachineState != SuckerMachineState::stopped)
        {
            #ifdef LOG_SUCKER_EVENTS
            UMBA_RTKOS_LOG<<warning<<"Operation not valid in current state, emergency stopping with param failure"<<normal<<"\n";
            #endif
            doEmergencyStop(SuckerErrorFlags::param_failure);
        }

        m_pidK_i = v;
        m_pidController = scalcus::PidController(m_pidK_p, m_pidK_i, m_pidK_d);
        roRegs[ ro::sucker_pid_scale_integral_current_f32 ] = m_pidK_i;

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"PID Integral K value: "<<m_pidK_i<<endl;
        #endif
    }

    void onGanjubusChangePidDifferential( float v )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"PID Differential K changing\n";
        #endif

        if (m_suckerMachineState != SuckerMachineState::stopped)
        {
            #ifdef LOG_SUCKER_EVENTS
            UMBA_RTKOS_LOG<<warning<<"Operation not valid in current state, emergency stopping with param failure"<<normal<<"\n";
            #endif
            doEmergencyStop(SuckerErrorFlags::param_failure);
        }

        m_pidK_d = v;
        m_pidController = scalcus::PidController(m_pidK_p, m_pidK_i, m_pidK_d);
        roRegs[ ro::sucker_pid_scale_differential_current_f32 ] = m_pidK_d;

        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"PID Differential K value: "<<m_pidK_d<<endl;
        #endif
    }

    void onGanjubusChangeEscIntervalOff( uint16_t u16 )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc 'Off' changing\n";
        #endif
        if (m_suckerMachineState != SuckerMachineState::stopped)
        {
            #ifdef LOG_SUCKER_EVENTS
            UMBA_RTKOS_LOG<<warning<<"Operation not valid in current state, emergency stopping with param failure"<<normal<<"\n";
            #endif
            doEmergencyStop(SuckerErrorFlags::param_failure);
        }
        m_escIntervalOff = (uint32_t)u16;
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc 'Off' pulse value: "<<m_escIntervalOff<<" ms"<<endl;
        #endif

        umba::drivers::postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_off, m_escIntervalOff );
    }

    /*
    void onGanjubusChangeEscIntervalMin( uint16_t u16 )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc Min changing\n";
        #endif
        if (m_suckerMachineState != SuckerMachineState::stopped)
        {
            #ifdef LOG_SUCKER_EVENTS
            UMBA_RTKOS_LOG<<warning<<"Operation not valid in current state, emergency stopping with param failure"<<normal<<"\n";
            #endif
            doEmergencyStop(SuckerErrorFlags::param_failure);
        }
        m_escIntervalMin = (uint32_t)u16;
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc Min new value: "<<m_escIntervalMin<<" ms\n";
        #endif
        calcEscIntervalNoPSensor();
    }
    */

    void onGanjubusChangeEscIntervalIdle( uint16_t u16 )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc Idle changing\n";
        #endif
        if (m_suckerMachineState != SuckerMachineState::stopped)
        {
            #ifdef LOG_SUCKER_EVENTS
            UMBA_RTKOS_LOG<<warning<<"Operation not valid in current state, emergency stopping with param failure"<<normal<<"\n";
            #endif
            doEmergencyStop(SuckerErrorFlags::param_failure);
        }
        m_escIntervalIdle = (uint32_t)u16;
        if (m_escIntervalIdle<m_escIntervalOff)
           m_escIntervalIdle = m_escIntervalOff;
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc Idle pulse value: "<<m_escIntervalIdle<<" ms"<<endl;
        #endif

        umba::drivers::postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_idliing, m_escIntervalIdle );
    }

    void onGanjubusChangeEscIntervalMax( uint16_t u16 )
    {
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc Max changing\n";
        #endif
        if (m_suckerMachineState != SuckerMachineState::stopped)
        {
            #ifdef LOG_SUCKER_EVENTS
            UMBA_RTKOS_LOG<<warning<<"Operation not valid in current state, emergency stopping with param failure"<<normal<<"\n";
            #endif
            doEmergencyStop(SuckerErrorFlags::param_failure);
        }
        m_escIntervalMax = (uint32_t)u16;
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc Max pulse value: "<<m_escIntervalMax<<" ms"<<endl;
        #endif

        calcEscIntervalNoPSensor();

        umba::drivers::postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_max, m_escIntervalMax );
    }

    void calcEscIntervalNoPSensor()
    {
        if (m_escIntervalMax<m_escIntervalIdle)
        {
            m_escIntervalNoPSensor = m_escIntervalIdle;
        }
        else
        {
            // 3/4 от максимальных оборотов
            m_escIntervalNoPSensor = m_escIntervalIdle + 3*(m_escIntervalMax - m_escIntervalIdle)/4;
        }
        #ifdef LOG_SUCKER_EVENTS
        UMBA_RTKOS_LOG<<"Esc 'No PSensor' pulse value: "<<m_escIntervalNoPSensor<<" ms"<<endl;
        #endif
    }


    //---------------------------------------
    virtual
    void onHandleMessage( umba::rtkos::Message &msg ) override
    {
        if (msg.id!=umba::rtkos::message_keyboard_id)
            return;

        umba::rtkos::MessageKeyboard &kbdMsg = msg.messageKeyboard;

        bool stateChanged = false;

        // Клавиатурные команды эмулируют установку значений по ганджубусу

        // Отпускания можно определять и по счетчику нажатий - там всегда 0

        using umba::rtkos::VirtualKeyCode;

        if (kbdMsg.repeatCount==1)
        {
            // Handle "Key pressed" here
            //if ( kbdMsg.keyCode==VirtualKeyCode::enter || kbdMsg.keyCode==VirtualKeyCode::ins )
            //    stateChanged |= startToggle();

            // Нажатие 0-9 задает соответствующую разницу давлений (в миллибарах)
            if (kbdMsg.keyCode >= (VirtualKeyCode)'0' && kbdMsg.keyCode <= (VirtualKeyCode)'9')
            {
                uint8_t targetPressure = (uint8_t)(uint16_t)(kbdMsg.keyCode) - (uint16_t)'0';
                rwRegs[rw::pressure_diff_ctrl_u8 ] = targetPressure * 10; // десятые доли
            }

            // По Enter перескакиваем так: stop -> idle -> start -> idle -> start -> ...
            // Только если нет ошибок
            else if (kbdMsg.keyCode == VirtualKeyCode::enter)
            {
                if (m_suckerErrorsState==SuckerErrorFlags::no_errors)
                {
                    switch(m_suckerMode)
                    {
                        case SuckerMode::stopped:
                             rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::idle   ;
                             break;

                        case SuckerMode::idle   : 
                             rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::sucking; 
                             break;

                        case SuckerMode::sucking: 
                             rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::idle   ; 
                             break;
                    }
                }
            }

            // По Backspace нужно очистить признаки ошибок, подав команду остановки
            else if (kbdMsg.keyCode == VirtualKeyCode::backspace)
            {
                rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::stopped;
            }

            else if (kbdMsg.keyCode == VirtualKeyCode::tab)
            {
                singleLineMode = !singleLineMode;
            }

            

            // По пробелу прыгаем между режимом сосания и остановкой, без промежуточного идлинга
            // Стартовать можем, только если нет ошибок
            // Признако ошибки не очищается
            else if (kbdMsg.keyCode == (VirtualKeyCode)' ')
            {
                switch(m_suckerMode)
                {
                    case SuckerMode::stopped: 
                                              if (m_suckerErrorsState==SuckerErrorFlags::no_errors)
                                              {
                                                  // Ошибок нет, можно стартовать сразу в режим сосания
                                                  rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::sucking;
                                              }
                                              else
                                              {
                                                  #ifdef LOG_SUCKER_EVENTS
                                                  UMBA_RTKOS_LOG<<"Clear errors"<<endl;
                                                  #endif
                                                  rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::stopped;
                                              }
                                              break;

                    case SuckerMode::idle:
                                              rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::stopped;
                                              break;

                    default:                  // Из сосания выключаемся безусловно
                                              // При ошибке мы уже в останове, поэтому пробел не сбросит флаги ошибки
                                              rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::stopped;
                }
            }

            else if (kbdMsg.keyCode == VirtualKeyCode::ins)
            {
                showLiveInfoLevel++;
                showLiveInfoLevel &= 3; // cycle 0,1,2,3
                 #ifdef LOG_SUCKER_EVENTS
                 UMBA_RTKOS_LOG<<"showLiveInfoLevel: "<<showLiveInfoLevel<<endl;
                 #endif


            }
            else if (kbdMsg.keyCode == VirtualKeyCode::f3)
            {
                showLiveInfoLevel = 3; // next [Ins] will reset it to 0
                showDetailedInfo( );
            }

        }

        if (!kbdMsg.repeatCount || kbdMsg.repeatCount==1)
        {
            // Handle "Key pressed/released" here
        }

        if (kbdMsg.repeatCount)
        {
            // Handle "Key pressed/repeated" here
            /*
            switch(kbdMsg.keyCode)
            {
                case VirtualKeyCode::up       : stateChanged |= incPayload( 10 ); break;
                case VirtualKeyCode::down     : stateChanged |= decPayload( 10 ); break;
                case VirtualKeyCode::page_up  : stateChanged |= incPayload( 50 ); break;
                case VirtualKeyCode::page_down: stateChanged |= decPayload( 50 ); break;
                //case VirtualKeyCode::: break;
            }
            */
        }

        if (stateChanged)
        {
            //postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_freq, pwmDuty );
            //postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_duty, pwmDuty );
            /*
            postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse, pwmDuty );
            uint8_t escCtrl = 2; // on
            postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_command, escCtrl );
            showState(false);
            */
        }

        /*
        UMBA_RTKOS_LOG<<umba::rtkos::getKeyCodeName( kbdMsg.keyCode )<<" ";
        if ((unsigned)kbdMsg.keyState)
           UMBA_RTKOS_LOG<<"pressed, ";
        else
           UMBA_RTKOS_LOG<<"released, ";

        UMBA_RTKOS_LOG<<"repeat count: "<<kbdMsg.repeatCount<<endl;
        */

    }

    //---------------------------------------
    virtual
    bool onMessageDriverClient( const umba::drivers::MessageDriver &msg ) override
    {
        using namespace umba::drivers;

        bool bHandled    = false;
        bool valsNeedToShow = false;

        ValueInfoFlags valueInfoFlags;

        
        if (isMessageDriverMine( msg, driver_address_knobs ))
        {
            uint32_t putTo = 0;
            if (umba::drivers::extractFromMessageValue( msg.value, putTo, &valueInfoFlags ))
            {
                roRegs[ro::surface_sensors_u8] = (uint8_t)putTo;
                bHandled = true;
            }
        }
        else if (isMessageDriverMine( msg, psensorDriverAddr ))
        {
            if (msg.header.driverMessageId == MessageId::driver_notify_datalink)
            {
                bHandled = true;
                valsNeedToShow |= onHwPSensorGood( msg.linkStatus ? true : false );
                //if (valsNeedToShow)
                //    UMBA_RTKOS_LOG<<"BAd sensor hits"<<endl;
            }

            if (!m_psensorGood)
            {} // dont extract data at all
            else
            {
                if ( isClientMessageDeviceValue(msg, sensors::value_id_sensor_value) )
                {
                    //float prevVal = m_currentPressureValue;
                    float putTo = 0.0;
                    if (!umba::drivers::extractFromMessageValue( msg.value, putTo, &valueInfoFlags ))
                    {
                        valsNeedToShow |= onHwPSensorGood( false );  // failed to obtain value, mark it as bad
                        //m_psensorGood = false;
                    }
                    else
                    {
                        //UMBA_RTKOS_LOG<<"LOGIC Pressure: "<<putTo<<", flags: "<<hex<<(uint32_t)valueInfoFlags<<"\n";
                        bHandled = true;
                        //m_currentPressureValue = putTo;
                        valsNeedToShow |= onHwCurrentPressureValue(putTo);
                    }

                    //if (valsNeedToShow)
                    //    UMBA_RTKOS_LOG<<"PSnsor hits, prev: "<<prevVal<<", new: "<<putTo<<endl;

                }
            }
        }
        else if (isMessageDriverMine( msg, driver_address_adc ))
        {
            if ( isClientMessageDeviceValue(msg, periph::value_id_adc_value) )
            {
                uint16_t putTo = 0;
                if (umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                {
                    //UMBA_RTKOS_LOG<<"LOGIC ADC: "<<putTo<<"\n";
                    //valsNeedToShow |= onHwEscCurrentValue( ((float)putTo)/1000.0f / 0.8f, putTo ) ;
                    //valsNeedToShow |= onHwEscCurrentValue( ((float)putTo)/844.0f, putTo ) ;
                    //valsNeedToShow |= onHwEscCurrentValue( ((float)putTo)/600.0f, putTo ) ;
                    valsNeedToShow |= onHwEscCurrentValue( ((float)putTo)/adcScaleFactor, putTo ) ;
                    bHandled = true;
                    //if (valsNeedToShow)
                    //    UMBA_RTKOS_LOG<<"Current hits"<<endl;

                }
            }
        }

        if (valsNeedToShow)
            showState();

        return bHandled;
    }

    //---------------------------------------
    //void ganjubusPoll();

    virtual
    bool onIdle() override
    {
        return true;
    }

    void doJob()
    {
        using namespace umba::omanip;

        // Полируем ганджубус
        {
            auto tickNow = umba::time_service::getCurTimeMs();
            slaveSession.work( tickNow );
        }

        static uint8_t   u8;
        static uint16_t  u16;
        static float    f32;

        if (rwRegs.getRegIfChanged( rw::sucker_ctrl_u8, u8))
           onGanjubusChangeSuckerMode(u8);

        //if (rwRegs.getRegIfChanged( rw::sucker_ctrl_u8, u8))
        //{
        //    onGanjubusChangeSuckerMode(u8);
        //}

        if (rwRegs.getRegIfChanged( rw::pressure_diff_ctrl_u8, u8))
            onGanjubusChangePressureCtrl(u8);

        if (rwRegs.getRegIfChanged( rw::psensor_emergency_mode_ctrl_u8, u8))
            onGanjubusChangePSensorEmergensyMode(u8);

        if (rwRegs.getRegIfChanged( rw::sucker_pid_scale_proportional_f32, f32))
            onGanjubusChangePidProportional(f32);

        if (rwRegs.getRegIfChanged( rw::sucker_pid_scale_integral_f32, f32))
            onGanjubusChangePidIntegral(f32);

        if (rwRegs.getRegIfChanged( rw::sucker_pid_scale_differential_f32, f32))
            onGanjubusChangePidDifferential(f32);

        if (rwRegs.getRegIfChanged( rw::impeller_esc_current_limit_u8, u8))
            onGanjubusChangeEscCurrentLimit(u8);

        if (rwRegs.getRegIfChanged( rw::impeller_esc_pwm_interval_off_u16, u16))
            onGanjubusChangeEscIntervalOff(u16);

        //if (rwRegs.getRegIfChanged( rw::esc_pwm_interval_min_u16, u16))
        //    onGanjubusChangeEscIntervalMin(u16);

        if (rwRegs.getRegIfChanged( rw::impeller_esc_pwm_interval_idle_u16, u16))
            onGanjubusChangeEscIntervalIdle(u16);

        if (rwRegs.getRegIfChanged( rw::impeller_esc_pwm_interval_max_u16, u16))
            onGanjubusChangeEscIntervalMax(u16);

        //return true;
        
    }

    //-----------------------------------------------------------------------------

public:

}; // class FootBoardLogic

