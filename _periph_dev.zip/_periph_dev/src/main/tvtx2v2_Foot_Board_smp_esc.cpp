#include "luart/uart_handle.h"
#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/gpio.h"
#include "periph/power.h"
#include "periph/adc.h"

#include "boards_conf/tvtx2v2_Foot_Board_conf.h"
#include "boards_conf/tvtx2v2_Foot_Board_pins.cpp"

#include "rtkos/rtkos.h"
#include "rtkos/rtkos_protothread.h"
#include "rtkos/starters.h"

#include "drivers/messages_rtkos.h"
#include "drivers/periph/legacy_uart_driver.h"
#include "drivers/periph/soft_i2c_driver.h"
#include "drivers/periph/tim_pwm_driver_impl.h"
#include "drivers/periph/adc_driver_impl.h"

#include "drivers/motors/esc_driver_impl.h"

#include "drivers/hid/keyboard_terminal_driver.h"

#include "drivers/sensors/honeywell_psensor_driver.h"


#include "rtkos/handlers/keyboard_hadler_impl_base.h"

#include <cstdlib>
#include <cmath>

#include "scalcus/pid.h"

#include "callbacks/callbacks.h"
#include "milliganjubus_core/milliganjubus_simple_reg_table.h"
#include "milliganjubus_core/milliganjubus_slave_session.h"

#include "vtx2v2/telexertex2_types.h"
#include "vtx2v2/telexertex2_sucker_regs.h"




#define GANJUBUS_USE_DEBUG_UART
//#define GANJUBUS_ADDR_AUTO_DETECT



//-----------------------------------------------------------------------------
#if defined(GANJUBUS_USE_DEBUG_UART)
    #if defined(GANJUBUS_ADDR_AUTO_DETECT)
        #error "Can't use ganjubus address autodetect. Debug UART port is used for Ganjubus communications"
    #endif
#endif

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
#ifdef GANJUBUS_USE_DEBUG_UART

    #define GANJUBUS_UART                    DEBUG_UART
    #define GANJUBUS_LEGACY_UART             DEBUG_LEGACY_UART
    #define GANJUBUS_UART_RX_GPIO            DEBUG_UART_TX_GPIO
    #define GANJUBUS_UART_RX_GPIO_PIN_NO     DEBUG_UART_TX_GPIO_PIN_NO
    #define GANJUBUS_UART_TX_GPIO            DEBUG_UART_TX_GPIO
    #define GANJUBUS_UART_TX_GPIO_PIN_NO     DEBUG_UART_TX_GPIO_PIN_NO

#else

    #define GANJUBUS_UART                    RS485_UART
    #define GANJUBUS_LEGACY_UART             RS485_LEGACY_UART
    #define GANJUBUS_UART_RX_GPIO            RS485_UART_TX_GPIO
    #define GANJUBUS_UART_RX_GPIO_PIN_NO     RS485_UART_TX_GPIO_PIN_NO
    #define GANJUBUS_UART_TX_GPIO            RS485_UART_TX_GPIO
    #define GANJUBUS_UART_TX_GPIO_PIN_NO     RS485_UART_TX_GPIO_PIN_NO

    #define GANJUBUS_USE_RS485
    #define GANJUBUS_RS485_LINK_DE_GPIO        RS485_LINK_DE_GPIO       
    #define GANJUBUS_RS485_LINK_DE_GPIO_PIN_NO RS485_LINK_DE_GPIO_PIN_NO

#endif
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
// For C6 use UMBA_TOO_LOW_MEM macro

// -E option make preprocessor output


//#define LOG_TO_UART
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
// Конфигурация ганджубуса
// TODO: Надо прошить во фдэш память
uint8_t     thisBoardGanjubusAddr = 0x10;
unsigned    ganjubusUartSpeed     = 57600;
// Полировщик ганджубуса
static milliganjubus::SlaveSession slaveSession;
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
// Тип таблицы регистров, таблица регистров, и safe proxy для ro/rw
typedef milliganjubus::SimpleRegTable< regs::SuckingFoot::ro::min, regs::SuckingFoot::ro::max, 
                                       regs::SuckingFoot::rw::min, regs::SuckingFoot::rw::max >
                             RawRegTable;
/*
typedef milliganjubus::SimpleRegTable< regs::SuckingFoot::RO::min, regs::SuckingFoot::RO::max, 
                                       regs::SuckingFoot::RW::min, regs::SuckingFoot::RW::max >
                             RawRegTable;
*/

RawRegTable    rawRegTable;
rdlc::RegTableSafe< RawRegTable, regs::SuckingFoot::ro::meta > roRegs;
rdlc::RegTableSafe< RawRegTable, regs::SuckingFoot::rw::meta > rwRegs;

//-----------------------------------------------------------------------------








//-----------------------------------------------------------------------------
using namespace umba::omanip;
using namespace umba::periph;
using namespace regs::SuckingFoot;
using namespace regs::types;

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
// Вся логика тут
class FootBoardLogic : public umba::ITimerHandler               // for timers
                     , public umba::rtkos::IMessageHandler      // for keyboard
                     , public umba::rtkos::IDriverClientHandler // for driver responses
                     , public umba::IIdleCapable                // полощем ганджубус тут
{

public:

    typedef umba::drivers::DriverAddress  DriverAddress;
    typedef umba::rtkos::TimerEventId     TimerEventId;
    typedef umba::rtkos::TimerId          TimerId;

    static constexpr umba::rtkos::TimeTick timer_request_pressure_period      = 10; // ms
    static constexpr umba::rtkos::TimeTick timer_requeste_esc_current_period  = 10; // ms
    // ms - если обнаружен отказ датчика, запускаем таймер, и надеемся, что датчик оклимается. 
    // Если через этот перид датчик таки неживой, тогда фейлимся, как задано флагом m_psensorStopOnFailure
    static constexpr umba::rtkos::TimeTick timer_psensor_failure_period  = 100; 

    static constexpr TimerEventId timer_event_request_pressure       = 0; // таймер на опрос давления
    static constexpr TimerEventId timer_event_requeste_esc_current   = 1; // таймера на опрос тока импеллера
    static constexpr TimerEventId timer_event_adjust_pressure        = 2; // 
    static constexpr TimerEventId timer_event_emergency_shot         = 3;
    static constexpr TimerEventId timer_event_emergency_rollback     = 4;

    // Адреса драйверов используемой периферии
    static constexpr DriverAddress driver_address_psensor  = DriverAddress( umba::drivers::class_id_sensor, 1 );
    static constexpr DriverAddress driver_address_adc      = DriverAddress( umba::drivers::class_id_adc   , 1 );
    static constexpr DriverAddress driver_address_esc      = DriverAddress( umba::drivers::class_id_esc   , 1 );
    //static constexpr DriverAddress driver_address_esc      = DriverAddress( umba::drivers::class_id_tim_pwm , 1 );
    

    UMBA_BEGIN_INTERFACE_MAP_EX( umba::ITimerHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IMessageHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IDriverClientHandler )
    UMBA_END_INTERFACE_MAP()

    UMBA_DELEGATE_QUERY_INTERFACE(umba::ITimerHandler)


    FootBoardLogic()
    {
    }

    // хелпер для установки таймера
    umba::rtkos::TimerId timerSet( umba::rtkos::TimerEventId eventId, umba::rtkos::TimeTick period )
    {
        return umba::rtkos::timerSet( this, eventId, period );
    }

protected:

    // Хелпер для инсталляции логики в систему
    void installDriverHandler( DriverAddress addrFrom )
    {
        umba::rtkos::driverHandlerAdd( addrFrom, this );
    }

public:

    // Установка в систему
    void install()
    {
        UMBA_RTKOS_OS->messagesSetHandler( umba::rtkos::message_keyboard_id, this );
        installDriverHandler(driver_address_psensor);
        installDriverHandler(driver_address_adc    );
        UMBA_RTKOS_OS->setIdleHandler( this );
    }

protected:

    enum class SuckerState
    {
        stopped,
        idling,
        stopped_on_failure, // из этого состояния нет выхода, кроме как по обновлению suckerMode
        psensor_wait_failure, // psensor помер, ждем, не оживет ли
        starting, 
        //started_wait_pressure, // стартовали, установили ожидаемое давление, теперь ждем секунду и проверяем текущее давление
        started,
        // если Игорь отсылает команду на старт без промежуточного идлинга, то мы сами в него заходим, 
        // делаем всё как в идлинге, а потом сами перескакиваем в starting
        idling_to_start, 
        started_wait_for_pressure_fail_stop

    };

    SuckerState               suckerState;    // состояние внутреннего автомата

    SuckerMode                suckerMode             = SuckerMode::stopped; // Стоять
    SuckerErrorFlags          suckerErrorsState      = SuckerErrorFlags::no_errors; // Когда пишем в статус, объединяем с suckerMode

    volatile bool             m_psensorGood          = true;  // По умолчанию - хорош. Если на старте не сработает, то по изменению будем реагировать
    volatile bool             m_psensorStopOnFailure = false; // Остановиться при сбое датчика или пилить на среднем?

    volatile float            m_currentPressureValue = 0.0; // текущее значение
    volatile float            m_targetPressureValue  = 0.0; // плавно меняется
    volatile float            m_PressureValue        = 0.0; // то, что надо получить

    volatile float            m_escCurrentValue      = 0.0; // ток на импеллере
    volatile float            m_escCurrentLimit      = 0.0; // лимит тока на импеллере

    uint32_t                  m_escIntervalOff  = 0;
    uint32_t                  m_escIntervalMin  = 0;
    uint32_t                  m_escIntervalIdle = 0;
    uint32_t                  m_escIntervalMax  = 0;
    // Интервал, если отвалился датчик давления. 
    // Пересчитать при изменении m_escIntervalMin и m_escIntervalMax
    uint32_t                  m_escIntervalNoPSensor = 0; 

    //scalcus::PidController    pidController(20.0, 5.0, 0.005);
    scalcus::PidController pidController = scalcus::PidController(20.0, 5.0, 0.005);


    /*
    bool incPayload( uint32_t v )
    {
        if (pwmDuty==800)
            return false;
        pwmDuty += v;
        return true;
    }

    bool decPayload( uint32_t v )
    {
        if ( (pwmDuty-v) <= 800)
            return false;
        pwmDuty -= v;
        return true;
    }

    bool startToggle()
    {
        if (pwmDuty==800)
           pwmDuty = 805;
        else
           pwmDuty = 800;

        return true;
    }
    */

    //bool 

    // сообщения
    bool onHwPSensorGood( bool newState )
    {
        bool res = m_psensorGood!=newState;
        m_psensorGood = newState;
        return res;
    }

    bool onHwCurrentPressureValue( float newPressure ) 
    {
        bool res = std::fabs( m_currentPressureValue - newPressure ) > 0.1f;
        m_currentPressureValue = newPressure;
        return res;
    }

    bool onHwEscCurrentValue( float newValue ) 
    {
        bool res = std::fabs( m_escCurrentValue - newValue ) > 0.1f;
        m_escCurrentValue = newValue;
        return res;
    }

    void showState( bool newLine = true )
    {
        using namespace umba::omanip;
        UMBA_RTKOS_LOG<<"PWM: "<<width(4)<<pwmDuty<<"  Iesc: "<<width(6)<<m_escCurrentValue<<"  dP: "<<width(6)<<m_currentPressureValue<<"    ";
        if (newLine)
            UMBA_RTKOS_LOG<<endl;
    }



    //---------------------------------------
    virtual
    void onTimer( unsigned eventId ) override
    {
        switch( eventId )
        {
            case timer_event_request_pressure:
                 postMessageDeviceValueRequest( driver_address_psensor, 0 ); // pressure value id is 0, I know it
                 break;

            case timer_event_requeste_esc_current: 
                 postMessageDeviceValueRequest( driver_address_adc, 0 ); // pressure value id is 0, I know it
                 break;
            //default:
        };

        // postMessageDriverValueRequest( ClassId classId, DriverId driverId, ValueId valueId, IDriver *pDriver = 0 )
    }

    void onGanjubusLinkLost()
    {}

    void onGanjubusLinkRestored()
    {}

    void onGanjubusDataReceived()
    {}



    void onGanjubusChangeSuckerMode( uint8_t newMode )
    {}

    void onGanjubusChangePressureCtrl( uint8_t pressureDelta )
    {}

    void onGanjubusChangePSensorEmergensyMode( uint8_t newMode ) // m_psensorStopOnFailure
    {}

    void onGanjubusChangePidProportional( float v )
    {}

    void onGanjubusChangePidIntegral( float v )
    {}

    void onGanjubusChangePidDifferential( float v )
    {}

    void onGanjubusChangeEscCurrentLimit( uint8_t v )
    {}

    void onGanjubusChangeEscIntervalOff( uint16_t v )
    {}

    void onGanjubusChangeEscIntervalMin( uint16_t v )
    {}

    void onGanjubusChangeEscIntervalIdle( uint16_t v )
    {}

    void onGanjubusChangeEscIntervalMax( uint16_t v )
    {}

/*
         rwRegs[rw::sucker_ctrl_u8                   ] = (uint8_t)0;   // Команда "Стоять"
         rwRegs[rw::pressure_diff_ctrl_u8            ] = (uint8_t)0.0; // Нулевая разница давления
         rwRegs[rw::psensor_emergency_mode_ctrl_u8   ] = (uint8_t)0;   // 0 - работать на средних оборотах
         rwRegs[rw::sucker_pid_scale_proportional_f32] = (float)20.0; 
         rwRegs[rw::sucker_pid_scale_integral_f32    ] = (float)5.0;  
         rwRegs[rw::sucker_pid_scale_differential_f32] = (float)0.005;
         rwRegs[rw::esc_current_limit_u8             ] = (uint8_t)10.0; // 1 ампер лимит по току
         rwRegs[rw::esc_pwm_interval_off_u16         ] = (uint8_t)800;
         rwRegs[rw::esc_pwm_interval_min_u16         ] = (uint8_t)1560;
         rwRegs[rw::esc_pwm_interval_idle_u16        ] = (uint8_t)1560;
         rwRegs[rw::esc_pwm_interval_max_u16         ] = (uint8_t)2300;
*/

    //---------------------------------------
    virtual
    void onHandleMessage( umba::rtkos::Message &msg ) override
    {
        if (msg.id!=umba::rtkos::message_keyboard_id)
            return;

        umba::rtkos::MessageKeyboard &kbdMsg = msg.messageKeyboard;

        bool stateChanged = false;

        // Отпускания можно определять и по счетчику нажатий - там всегда 0

        using umba::rtkos::VirtualKeyCode;

        if (kbdMsg.repeatCount==1)
        {
            // Handle "Key pressed" here
            //if ( kbdMsg.keyCode==VirtualKeyCode::enter || kbdMsg.keyCode==VirtualKeyCode::ins )
            //    stateChanged |= startToggle();

            // Нажатие 0-9 задает соответствующую разницу давлений (в миллибарах)
            if (kbdMsg.keyCode >= (VirtualKeyCode)'0' && kbdMsg.keyCode <= (VirtualKeyCode)'9')
            {
                uint8_t targetPressure = (uint8_t)(uint16_t)(kbdMsg.keyCode) - ((uint16_t))'0';
                rwRegs[rw::pressure_diff_ctrl_u8 ] = targetPressure * 10; // десятые доли
            }

            // По Enter перескакиваем так: stop -> idle -> start -> idle -> start -> ...
            // Только если нет ошибок
            if (kbdMsg.keyCode == VirtualKeyCode::enter)
            {
                if (suckerErrorsState==SuckerErrorFlags::no_errors)
                {
                    switch(suckerMode)
                    {
                        case SuckerMode::stopped: rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::idle   ; break;
                        case SuckerMode::idle   : rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::sucking; break;
                        case SuckerMode::sucking: rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::idle   ; break;
                    }
                }
            }

            // По Backspace нужно очистить признаки ошибок, подав команду остановки
            if (kbdMsg.keyCode == VirtualKeyCode::backspace)
            {
                rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::stopped;
            }

            // По пробелу прыгаем между режимом сосания и остановкой, без промежуточного идлинга
            // Стартовать можем, только если нет ошибок
            // Признако ошибки не очищается
            if (kbdMsg.keyCode == (VirtualKeyCode)' ')
            {
                switch(suckerMode)
                {
                    case SuckerMode::stopped: 
                    case SuckerMode::idle:
                                              if (suckerErrorsState==SuckerErrorFlags::no_errors)
                                              {
                                                  // Ошибок нет, можно стартовать сразу в режим сосания
                                                  rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::sucking;
                                              }

                    default:                  // Из сосания выключаемся безусловно
                                              // При ошибке мы уже в останове, поэтому пробел не сбросит флаги ошибки
                                              rwRegs[rw::sucker_ctrl_u8] = (uint8_t)SuckerMode::stopped;
                }
            }
        }

/*
         rwRegs[rw::sucker_ctrl_u8                   ] = (uint8_t)0;   // Команда "Стоять"
         rwRegs[rw::pressure_diff_ctrl_u8            ] = (uint8_t)0.0; // Нулевая разница давления
         rwRegs[rw::psensor_emergency_mode_ctrl_u8   ] = (uint8_t)0;   // 0 - работать на средних оборотах
         rwRegs[rw::sucker_pid_scale_proportional_f32] = (float)20.0; 
         rwRegs[rw::sucker_pid_scale_integral_f32    ] = (float)5.0;  
         rwRegs[rw::sucker_pid_scale_differential_f32] = (float)0.005;
         rwRegs[rw::esc_current_limit_u8             ] = (uint8_t)10.0; // 1 ампер лимит по току
         rwRegs[rw::esc_pwm_interval_off_u16         ] = (uint8_t)800;
         rwRegs[rw::esc_pwm_interval_min_u16         ] = (uint8_t)1560;
         rwRegs[rw::esc_pwm_interval_idle_u16        ] = (uint8_t)1560;
         rwRegs[rw::esc_pwm_interval_max_u16         ] = (uint8_t)2300;
*/

        if (!kbdMsg.repeatCount || kbdMsg.repeatCount==1)
        {
            // Handle "Key pressed/released" here
        }

        if (kbdMsg.repeatCount)
        {
            // Handle "Key pressed/repeated" here
            /*
            switch(kbdMsg.keyCode)
            {
                case VirtualKeyCode::up       : stateChanged |= incPayload( 10 ); break;
                case VirtualKeyCode::down     : stateChanged |= decPayload( 10 ); break;
                case VirtualKeyCode::page_up  : stateChanged |= incPayload( 50 ); break;
                case VirtualKeyCode::page_down: stateChanged |= decPayload( 50 ); break;
                //case VirtualKeyCode::: break;
            }
            */
        }

        if (stateChanged)
        {
            //postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_freq, pwmDuty );
            //postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_duty, pwmDuty );
            /*
            postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse, pwmDuty );
            uint8_t escCtrl = 2; // on
            postMessageDriverValue( driver_address_esc, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_command, escCtrl );
            showState(false);
            */
        }

        /*
        UMBA_RTKOS_LOG<<umba::rtkos::getKeyCodeName( kbdMsg.keyCode )<<" ";
        if ((unsigned)kbdMsg.keyState)
           UMBA_RTKOS_LOG<<"pressed, ";
        else
           UMBA_RTKOS_LOG<<"released, ";

        UMBA_RTKOS_LOG<<"repeat count: "<<kbdMsg.repeatCount<<endl;
        */

    }

    //---------------------------------------
    virtual
    bool onMessageDriverClient( const umba::drivers::MessageDriver &msg ) override
    {
        using namespace umba::drivers;

        bool bHandled    = false;
        bool valsNeedToShow = false;

        if (isMessageDriverMine( msg, driver_address_psensor ))
        {
            if (msg.header.driverMessageId == MessageId::driver_notify_datalink)
            {
                bHandled = true;
                valsNeedToShow |= onHwPSensorGood( msg.linkStatus ? true : false );
                //if (valsNeedToShow)
                //    UMBA_RTKOS_LOG<<"BAd sensor hits"<<endl;
            }

            if (!m_psensorGood)
            {} // dont extract data at all
            else
            {
                if ( isMessageDriverValue(msg, sensors::value_id_sensor_value) )
                {
                    float prevVal = m_currentPressureValue;
                    float putTo = 0.0;
                    if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                    {
                        valsNeedToShow |= onHwPSensorGood( false );  // failed to obtain value, mark it as bad
                        //m_psensorGood = false;
                    }
                    else
                    {
                        bHandled = true;
                        //m_currentPressureValue = putTo;
                        valsNeedToShow |= onHwCurrentPressureValue(putTo);
                    }

                    //if (valsNeedToShow)
                    //    UMBA_RTKOS_LOG<<"PSnsor hits, prev: "<<prevVal<<", new: "<<putTo<<endl;

                }
            }
        }
        else if (isMessageDriverMine( msg, driver_address_adc ))
        {
            if ( isMessageDriverValue(msg, periph::value_id_adc_value) )
            {
                uint16_t putTo = 0;
                if (umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                {
                    valsNeedToShow |= onHwEscCurrentValue( ((float)putTo)/1000.0f ) ;
                    bHandled = true;
                    //if (valsNeedToShow)
                    //    UMBA_RTKOS_LOG<<"Current hits"<<endl;

                }
            }
        }

        if (valsNeedToShow)
            showState();

        return bHandled;
    }

    //---------------------------------------
    //void ganjubusPoll();

    virtual
    bool onIdle() override
    {
        using namespace umba::omanip;

        // Полируем ганджубус
        {
            auto tickNow = umba::time_service::getCurTimeMs();
            slaveSession.work( tickNow );
        }

        static uint8_t   u8;
        static uint16_t  u16;
        static float    f32;

        if (rwRegs.getRegIfChanged( rw::sucker_ctrl_u8, u8))
            onGanjubusChangeSuckerMode(u8);

        if (rwRegs.getRegIfChanged( rw::pressure_diff_ctrl_u8, u8))
            onGanjubusChangePressureCtrl(u8);

        if (rwRegs.getRegIfChanged( rw::psensor_emergency_mode_ctrl_u8, u8))
            onGanjubusChangePSensorEmergensyMode(u8);

        if (rwRegs.getRegIfChanged( rw::sucker_pid_scale_proportional_f32, f32))
            onGanjubusChangePidProportional(f32);

        if (rwRegs.getRegIfChanged( rw::sucker_pid_scale_integral_f32, f32))
            onGanjubusChangePidIntegral(f32);

        if (rwRegs.getRegIfChanged( rw::sucker_pid_scale_differential_f32, f32))
            onGanjubusChangePidDifferential(f32);

        if (rwRegs.getRegIfChanged( rw::esc_current_limit_u8, u8))
            onGanjubusChangeEscCurrentLimit(u8);

        if (rwRegs.getRegIfChanged( rw::, u16))
            (u16);

        if (rwRegs.getRegIfChanged( rw::esc_pwm_interval_off_u16, u16))
            onGanjubusChangeEscIntervalOff(u16);

        if (rwRegs.getRegIfChanged( rw::esc_pwm_interval_min_u16, u16))
            onGanjubusChangeEscIntervalMin(u16);

        if (rwRegs.getRegIfChanged( rw::esc_pwm_interval_idle_u16, u16))
            onGanjubusChangeEscIntervalIdle(u16);

        if (rwRegs.getRegIfChanged( rw::esc_pwm_interval_max_u16, u16))
            onGanjubusChangeEscIntervalMax(u16);

        return true;
    }


    //-----------------------------------------------------------------------------
public:




}; // class FootBoardLogic




struct PredStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel4>
{
    umba::drivers::DriverAddress escAddr = umba::drivers::DriverAddress( umba::drivers::class_id_motor, 1 );

    //uint32_t u32;
    //float    f;

    //rdlc::RegTablePublic< RawRegTable, int >  rt = rdlc::makeRegTablePublic( rawRegTable, int() );

    uint32_t                   pwmFreq       =  100;
    uint32_t                   pwmOffPulse   =  800;
    uint32_t                   pwmIdlePulse  = 1560;
    uint32_t                   pwmMaxPulse   = 2300;
    uint32_t                   pwmPulse      =  800; // current value
    uint8_t                    escMode       =    0; // off, idle, on - 0/1/2


    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning

         //using namespace regs::SuckingFoot;
         //using namespace regs::SuckingFoot;

         //scalcus::PidController    pidController(20.0, 5.0, 0.005);
         
         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_command, escMode );

         PT_YIELD();

         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_freq, pwmFreq );

         PT_YIELD();

         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_off, pwmOffPulse );

         PT_YIELD();

         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_idliing, pwmIdlePulse );
         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse, pwmPulse );

         PT_YIELD();

         umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_duty_pulse_max, pwmMaxPulse );

         PT_END();
    }

};




auto deviceLogic = FootBoardLogic();


struct FunalStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel6>
{
    umba::drivers::DriverAddress escAddr = umba::drivers::DriverAddress( umba::drivers::class_id_motor, 1 );
    //umba::drivers::DriverAddress timAddr = umba::drivers::DriverAddress( umba::drivers::class_id_tim_pwm, 1 );
    uint8_t  escCtrl   = 0; // off
    uint8_t  timCtrl   = 1;

    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning

         //scalcus::PidController    pidController(20.0, 5.0, 0.005);

         // Заполняем регистры значениями по умолчанию
         // При старте рабочего потока произойдет проверка обновления регистров,
         // и их стартовые значения будут раскиданы по драйверам/устройствам,
         // а регистры состояния будут отосланы мастеру

         using namespace regs::SuckingFoot;

         roRegs[ro::sucker_mode_u8    ] = (uint8_t)0; // Стоим, нет ошибки
         roRegs[ro::pressure_diff_u8  ] = (float)0.0;
         roRegs[ro::esc_current_u8    ] = (uint8_t)0; // Тока нет
         roRegs[ro::surface_sensors_u8] = (uint8_t)0; // Датчики не замкнуты
         roRegs[ro::sucker_pid_scale_proportional_current_f32] = (float)20.0;
         roRegs[ro::sucker_pid_scale_integral_current_f32    ] = (float)5.0;
         roRegs[ro::sucker_pid_scale_differential_current_f32] = (float)0.005;

         rwRegs[rw::sucker_ctrl_u8                   ] = (uint8_t)0;   // Команда "Стоять"
         rwRegs[rw::pressure_diff_ctrl_u8            ] = (uint8_t)0.0; // Нулевая разница давления
         rwRegs[rw::psensor_emergency_mode_ctrl_u8   ] = (uint8_t)0;   // 0 - работать на средних оборотах
         rwRegs[rw::sucker_pid_scale_proportional_f32] = (float)20.0; 
         rwRegs[rw::sucker_pid_scale_integral_f32    ] = (float)5.0;  
         rwRegs[rw::sucker_pid_scale_differential_f32] = (float)0.005;
         rwRegs[rw::esc_current_limit_u8             ] = (uint8_t)10.0; // 1 ампер лимит по току
         rwRegs[rw::esc_pwm_interval_off_u16         ] = (uint8_t)800;
         rwRegs[rw::esc_pwm_interval_min_u16         ] = (uint8_t)1560;
         rwRegs[rw::esc_pwm_interval_idle_u16        ] = (uint8_t)1560;
         rwRegs[rw::esc_pwm_interval_max_u16         ] = (uint8_t)2300;
                

         //umba::drivers::postMessageDriverValue( escAddr, umba::drivers::MessageId::device_param_set, umba::drivers::motors::value_id_esc_pwm_command, escCtrl );
         //postMessageDriverValue( timAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_ctrl, timCtrl );

         PT_YIELD();

         deviceLogic.timerSet( deviceLogic.timer_event_request_pressure, deviceLogic.timer_request_pressure_period ); // 10мс

         // Обновлять данные от датчика давления и тока в противофазе, для пущей равномерности бытия
         // Предполагается, что оба интервала равны.
         // Если нет, то будет не в противофазе, а просто с некоторым сдвигом, что тоже нормас
         timer.start( deviceLogic.timer_request_pressure_period/2 ); 
         PT_WAIT_UNTIL(timer.expired());

         deviceLogic.timerSet( deviceLogic.timer_event_requeste_esc_current, deviceLogic.timer_requeste_esc_current_period ); // 10 мс

         PT_END();
    }

}; // struct FunalStarterThread


auto hwInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );
auto swInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );

auto starter0   =  umba::rtkos::StarterThreadOsInfo< umba::rtkos::OsInfoLogLevel::osSizeDetailsMore >(); 

auto starter1   =  umba::rtkos::StarterThreadHardwareInfo();

auto starter2   =  umba::rtkos::StarterThreadHardwareInitializer< decltype(hwInitDelays)>( hwInitDelays );

auto starter4   =  PredStarterThread();

auto starter5   =  umba::rtkos::StarterThreadSoftwareInitializer< decltype(swInitDelays)/*, umba::rtkos::RunLevel5*/>( swInitDelays );

auto starter6   =  FunalStarterThread();

auto timPwmDriver         = umba::drivers::periph::TimPwmDriver( TIM16, 1, UMBA_PINADDR_PB8 ); // TIM16_CH1 

auto escDriver            = umba::drivers::motors::EscDriver( umba::drivers::DriverAddress( umba::drivers::class_id_tim_pwm, 1 ) );

auto kbdTermDriver        = umba::drivers::hid::KeyboardTerminalDriver( umba::drivers::DriverAddress( umba::drivers::class_id_uart
                                                                                                    , umba::periph::periphGetNo( & DEBUG_LEGACY_UART ) 
                                                                                                    ) 
                                                                      );

auto debugUartDriver      = umba::drivers::periph::LegacyUartDriver( DEBUG_LEGACY_UART
                                                                   , DEBUG_UART_RX_GPIO_PIN_ADDR
                                                                   , DEBUG_UART_TX_GPIO_PIN_ADDR
                                                                   , 460800
                                                                   // No pinAddrRs485
                                                                   );

auto i2c = umba::drivers::periph::SoftI2cDriver(  PB7 /*SDA*/, PB6 /*SCL*/ );

auto psensor = umba::drivers::sensors::HSCSSNN001PD2A3_PSensorDriver( umba::drivers::DriverAddress( umba::drivers::class_id_i2c_soft
                                                                                                  , 1 // первый из сенсоров, см ниже порядок установки дров, попробуйте задать 3 для проверки
                                                                                                  ) 
                                                                    , 0x28u // адрес сенсора на шине I2C
                                                                    );

auto adcSC     = umba::periph::traits::AdcSingleChannel( ADC2, UMBA_PINADDR_PA6, umba::periph::AdcSamplingSpeed::low );
auto adcDriver = umba::drivers::periph::makeAdcDriver( adcSC, UMBA_PINADDR_PA6 );


/*
void FootBoardLogic::ganjubusPoll()
{
    auto tickNow = umba::time_service::getCurTimeMs();
    slaveSession.work( tickNow );
}
*/

int main(void)
{
    // Базовый адрес устройства.
    // Если не используем автодетект, надо ручками прописать для какждой присоски отдельный адрес
    #if defined(GANJUBUS_ADDR_AUTO_DETECT)
    {
        // Когда отладочный UART никуда не подключен, лапки висят в воздухе
        // Подтянем их к единице, так как для выбора адреса будем на пины коротить землю с того же разъема
        GpioPin addrPin1( GpioPinAddr( DEBUG_UART_TX_GPIO_PIN_ADDR ), PinMode::gpio_in_pullup ); // PA9
        GpioPin addrPin2( GpioPinAddr( DEBUG_UART_RX_GPIO_PIN_ADDR ), PinMode::gpio_in_pullup ); // PA10

        uint8_t addrPins = 0;
        if (addrPin1==true)
            addrPins |= 1;
        if (addrPin2==true)
            addrPins |= 2;

        addrPins = (~addrPins) & 0x3; // чтобы адрес по умолчанию не отличался от базового
        thisBoardGanjubusAddr += addrPins;
        // Таким образом, если ничего не подключено, то в итоге адрес будет 0x10 (если бы не инвертили, было бы 0x13)
    }
    #endif



    #if defined(GANJUBUS_USE_DEBUG_UART) || defined(GANJUBUS_ADDR_AUTO_DETECT)

        UMBA_RTKOS_USE_LOG_STREAM_SWD();

    #else

        UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( DEBUG_LEGACY_UART, DEBUG_UART, 460800 );

    #endif

    UMBA_RTKOS_LOG<<feed<<"------------------"<<endl;


    GANJUBUS_LEGACY_UART.init( GANJUBUS_UART_RX_GPIO, GANJUBUS_UART_RX_GPIO_PIN_NO
                      , GANJUBUS_UART_TX_GPIO, GANJUBUS_UART_TX_GPIO_PIN_NO
                      , ganjubusUartSpeed
                      #ifdef GANJUBUS_USE_RS485
                      , GANJUBUS_RS485_LINK_DE_GPIO, 1<<GANJUBUS_RS485_LINK_DE_GPIO_PIN_NO
                      #endif
                      );
    

    static callback::Callback<void ( void )> linkLostCallback    ( []() { deviceLogic.onGanjubusLinkLost();      } );
    static callback::Callback<void ( void )> linkRestoredCallback( []() { deviceLogic.onGanjubusLinkRestored();  } );
    static callback::Callback<void ( void )> dataReceivedCallback( []() {  deviceLogic.onGanjubusDataReceived(); } );

    
    slaveSession.init( GANJUBUS_LEGACY_UART
                     , thisBoardGanjubusAddr
                     , rawRegTable
                     , linkLostCallback
                     , linkRestoredCallback
                     , 5000 // lost link timeout
                     , dataReceivedCallback );         // коллбэки


    debugUartDriver.install();
    kbdTermDriver  .install();
    i2c            .install();
    psensor        .install();
    adcDriver      .install();
    timPwmDriver   .install();
    escDriver      .install();

    deviceLogic    .install();


    umba::rtkos::pollScheduleAdd( &starter0 );
    umba::rtkos::pollScheduleAdd( &starter1 );
    umba::rtkos::pollScheduleAdd( &starter2 );
    umba::rtkos::pollScheduleAdd( &starter4 );
    umba::rtkos::pollScheduleAdd( &starter5 );
    umba::rtkos::pollScheduleAdd( &starter6 );


    return UMBA_RTKOS_OS->run( umba::rtkos::RunLevel6 );

}


