// master options
// #define SPI_NOWAIT
// #define DISABLE_LOOP_SLAVE_POLLING

// slave options
#define NO_IRQ_LOGS
// #define BTN_USE_TOGGLE_LOGIC


#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
#include "umba/hr_counter.h"


extern umba::SimpleFormatter  lout;

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"



#include "periph/stm32_discovery.h"


#include "spi_test_master_slave.h"


#include "device_state_indicator.h"


#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )

void spiInit( bool bMaster );
void masterProc();
void slaveProc();

DECLARE_PIN( btnPin , STM32_DISCOVERY_BTN_USER );
DECLARE_PIN( msTestCsPin , MS_TEST_SPI_CS  );

umba::periph::GpioPin &ledPin = led1_Pin;

umba::periph::GpioPin  pinMastertMode( MS_TEST_SPI_MASTER_MODE_SELECT_PIN_ADDR, UMBA_GPIO_DIRECTION_IN );


using namespace umba::time_service;
using namespace umba::periph::traits;
using namespace umba::omanip;


//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::LegacyUartCharWriter<255>   charWritter = umba::LegacyUartCharWriter<255>( STM32_DISCOVERY_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);


umba::hr_counter::HiResTick  nanosecDelayVal = 0;


static bool btnPrevState = btnPin;


/*
    0x00-0x0D - RW, что записали, то и прочитали
    0x0E      - RO, регистр статуса - младший бит - состояние кнопки
    0x0F      - RO, регистр WHO_AM_I, там всегда SPI_WHO_AM_I_ID
*/
static
uint8_t slaveRegs[SPI_NUMBER_OF_REG] = { 0, 0, 0, 0
                                       , 0, 0, 0, 0
                                       , 0, 0, 0, 0
                                       , 0, 0, 0, SPI_WHO_AM_I_ID };

static
uint8_t curIdx = 0;
static
bool    bSlaveModeRead = false;

uint8_t spiSlaveFillingVal = 0xAA;

#include "umba/optimize_speed.h"
UMBA_PERIPH_DECLARE_SPI_IRQ_HANDLER_PROC( spiIrqHandler )
{
    // прочитали-записали 8 бит

    using namespace umba::periph::traits;
    bool ledsUpdated = false;
    //bool bFirst = false;

    uint8_t receivedByte = (uint8_t)spiReadGetValue( MS_TEST_SPI );
    
    if (curIdx == (uint8_t)0xFFu)
    {
        // first byte after start
        bSlaveModeRead = (receivedByte & (SPI_MS_TEST_CMD_READ >> 8)) ? true : false;
        curIdx = (receivedByte & ~(SPI_MS_TEST_CMD_READ >> 8) );
        if ( curIdx < SPI_NUMBER_OF_REG )
            spiWriteSetValue(MS_TEST_SPI, slaveRegs[curIdx]);
        #ifndef NO_IRQ_LOGS
        lout << "+ "<<hex<<width(2)<<noshowbase<<receivedByte<<"\n";
        lout<<"<-"<<hex<<width(2)<<noshowbase<<slaveRegs[curIdx]<<" at "<<curIdx<<"\n";
        #endif
        return;
        //bFirst = true;
    }

    if ( curIdx < SPI_NUMBER_OF_REG )
    {
        if (bSlaveModeRead)
        {
            //umba::periph::traits::spiWriteStart( MS_TEST_SPI, slaveRegs[curIdx++] );
            //spiStartPrepare( MS_TEST_SPI );
            spiWriteSetValue(MS_TEST_SPI, slaveRegs[curIdx]);
            #ifndef NO_IRQ_LOGS
            lout<<"->"<<hex<<width(2)<<noshowbase<<receivedByte<<"\n";
            lout<<"<-"<<hex<<width(2)<<noshowbase<<slaveRegs[curIdx]<<" at "<<curIdx<<"\n";
            #endif
            ++curIdx;
            // ??? spiWriteSetValue( SPIx, (SpiDataBits)dataSize, data );
        }
        else
        {

            if (curIdx==SPI_REG_CTRL_LEDS)
                ledsUpdated = true;

            if (SPI_REG_IS_RW(curIdx))
            {
                slaveRegs[curIdx] = receivedByte;
            }

            spiWriteSetValue(MS_TEST_SPI, slaveRegs[curIdx] );

            #ifndef NO_IRQ_LOGS
            lout<<"->"<<hex<<width(2)<<noshowbase<<receivedByte<<"\n";
            lout<<"T["<<curIdx<<"]="<<hex<<width(2)<<(unsigned)slaveRegs[curIdx]<<"\n";
            #endif
            
            #ifndef NO_IRQ_LOGS
            lout<<"<-"<<hex<<width(2)<<noshowbase<<slaveRegs[curIdx]<<"\n";
            #endif

            curIdx++;
        }
    }
    else // index out of range
    {
        spiWriteSetValue(MS_TEST_SPI, spiSlaveFillingVal );
        #ifndef NO_IRQ_LOGS
        lout << "Xidx: "<<curIdx<<"\n";
        #endif
    }

    if (ledsUpdated)
    {
        ledControl( false );
        ledControl( slaveRegs[SPI_REG_CTRL_LEDS], true );

        #ifndef NO_IRQ_LOGS
        lout << "LED: " <<slaveRegs[SPI_REG_CTRL_LEDS];
        lout<<"\n";
        #endif
    }

}

UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( chipSelectIrqHandlerProc )
{
    //https://stackoverflow.com/questions/20319801/spi-slave-setup-on-stm32f4-board
    spiStartPrepare( MS_TEST_SPI );
    spiReadGetValue( MS_TEST_SPI ); // очищаем буфер чтения
    spiWriteSetValue(MS_TEST_SPI, spiSlaveFillingVal ); // первый байт - нулевой
    curIdx = (uint8_t)0xFFu; // делаем невалидный индекс
    #ifndef NO_IRQ_LOGS
    lout<<"!!! - "<<hex<<width(2)<<noshowbase<<spiSlaveFillingVal<<endl;
    #endif
}
#include "umba/optimize_pop.h"


UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( btnIrqHandlerProc )
{
    // toggle logix
    #ifdef BTN_USE_TOGGLE_LOGIC

    if (btnPin.get())
    {
        #ifndef NO_IRQ_LOGS
        lout<<"BtnNewSt: ";
        #endif
        if (slaveRegs[ SPI_REG_STATUS ] & (uint8_t)SPI_STATUS_BTN1) // already set
            slaveRegs[ SPI_REG_STATUS ] &= ~((uint8_t)SPI_STATUS_BTN1);
        else
            slaveRegs[ SPI_REG_STATUS ] |=   (uint8_t)SPI_STATUS_BTN1;

        #ifndef NO_IRQ_LOGS
        lout << ( (slaveRegs[ SPI_REG_STATUS ] & (uint8_t)SPI_STATUS_BTN1 ) ? "Pressed" : "Released" ) << endl;
        #endif
    }

    #else

    if (btnPin.get())
        slaveRegs[ SPI_REG_STATUS ] |=   (uint8_t)SPI_STATUS_BTN1;
    else
        slaveRegs[ SPI_REG_STATUS ] &= ~((uint8_t)SPI_STATUS_BTN1);
    //ledPin = !ledPin;

    #endif

}



static volatile uint32_t hseVal   = 0;
static volatile uint32_t coreClk  = 0;
static volatile uint32_t sysClk   = 0;
static volatile uint32_t ahbClk   = 0;
static volatile uint32_t apb1Clk  = 0;
static volatile uint32_t apb2Clk  = 0;
static volatile uint32_t spiFreq  = 0;

static unsigned remoteLedNo = 0;


DeviceStateIndicator stateIndicator;
UMBA_DEVICE_STATE_INDICATOR_HANDLE_FAULTS(stateIndicator);





int main(void)
{

    bool bMaster = pinMastertMode; // btnPin;

    //while(btnPin==true); // stops until startup configuration btn not released

    umba::time_service::init();
    umba::time_service::start();

    if (!bMaster)
    {
        msTestCsPin.assignAddrAndMode( MS_TEST_SPI_CS_GPIO_PIN_ADDR, UMBA_GPIO_DIRECTION_IN );
    }

    ledStartup();
        
    STM32_DISCOVERY_LEGACY_UART.init( STM32_DISCOVERY_UART_RX_GPIO,  STM32_DISCOVERY_UART_RX_GPIO_PIN_NO, STM32_DISCOVERY_UART_TX_GPIO, STM32_DISCOVERY_UART_TX_GPIO_PIN_NO, 460800 );

    lout<<"Nanosec tick: "<<umba::hr_counter::getTick()<<endl;

    spiInit(bMaster);

    lout<<"Nanosec tick: "<<umba::hr_counter::getTick()<<endl;

    if (bMaster)
       masterProc();
    else
       slaveProc();


}

//-----------------------------------------------------------------------------
void spiInitMaster()
{

    // SPI hints
    // 8/16 - https://diymcblog.blogspot.com/2018/03/spi-stm32-2.html
    // Статусы - http://www.cyberforum.ru/arm/thread2091007.html
    // Полезная инфа - https://microtechnics.ru/stm32-s-nulya-interfejs-spi/
    //   Важное дополнение – инициализация GPIO должна происходить после инициализации SPI, иначе могут возникнуть сбои в работе Slave.

    using namespace umba::periph::traits;

    SpiPrescaler psc100   = spiCalcPrescaler( MS_TEST_SPI,   100000 );
    SpiPrescaler psc150   = spiCalcPrescaler( MS_TEST_SPI,   150000 );
    SpiPrescaler psc200   = spiCalcPrescaler( MS_TEST_SPI,   200000 );
    SpiPrescaler psc250   = spiCalcPrescaler( MS_TEST_SPI,   250000 );
    SpiPrescaler psc500   = spiCalcPrescaler( MS_TEST_SPI,   500000 );
    SpiPrescaler psc1000  = spiCalcPrescaler( MS_TEST_SPI,  1000000 );
    SpiPrescaler psc2000  = spiCalcPrescaler( MS_TEST_SPI,  2000000 );
    SpiPrescaler psc3000  = spiCalcPrescaler( MS_TEST_SPI,  3000000 );
    SpiPrescaler psc4000  = spiCalcPrescaler( MS_TEST_SPI,  4000000 );
    SpiPrescaler psc5000  = spiCalcPrescaler( MS_TEST_SPI,  5000000 );
    SpiPrescaler psc10000 = spiCalcPrescaler( MS_TEST_SPI, 10000000 );
    SpiPrescaler psc15000 = spiCalcPrescaler( MS_TEST_SPI, 15000000 );
    SpiPrescaler psc20000 = spiCalcPrescaler( MS_TEST_SPI, 20000000 );

    /*
    На F4/168 МГц с максимальным делителем 256 не получить частоту SPI ниже 656250 Гц.
    Период SPI SCK 1.5 мкс

    На F3/72 МГц с максимальным делителем 256 не получить частоту SPI ниже 93750 Гц.
    Период SPI SCK 10.65 мкс 

    */

    periphInit( MS_TEST_SPI                      
              , MS_TEST_SPI_SCK_GPIO_PIN_ADDR    
              , MS_TEST_SPI_MISO_GPIO_PIN_ADDR   
              , MS_TEST_SPI_MOSI_GPIO_PIN_ADDR   
              , spiDataBits16
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              #ifdef TIMINGS_CHECK
              , umba::periph::traits::spiPrescaler256
              #else
              , spiCalcPrescaler( MS_TEST_SPI,   10000 ) // request 10KHz
              //, umba::periph::traits::spiPrescaler256
              #endif
              , PinSpeed::high // PinSpeed::low
              );

    msTestCsPin = true;
}

//-----------------------------------------------------------------------------
void spiInitSlave()
{

    // SPI hints
    // 8/16 - https://diymcblog.blogspot.com/2018/03/spi-stm32-2.html
    // Статусы - http://www.cyberforum.ru/arm/thread2091007.html
    // Полезная инфа - https://microtechnics.ru/stm32-s-nulya-interfejs-spi/
    //   Важное дополнение – инициализация GPIO должна происходить после инициализации SPI, иначе могут возникнуть сбои в работе Slave.

    using namespace umba::periph::traits;

    SpiPrescaler psc100   = spiCalcPrescaler( MS_TEST_SPI,   100000 );
    SpiPrescaler psc150   = spiCalcPrescaler( MS_TEST_SPI,   150000 );
    SpiPrescaler psc200   = spiCalcPrescaler( MS_TEST_SPI,   200000 );
    SpiPrescaler psc250   = spiCalcPrescaler( MS_TEST_SPI,   250000 );
    SpiPrescaler psc500   = spiCalcPrescaler( MS_TEST_SPI,   500000 );
    SpiPrescaler psc1000  = spiCalcPrescaler( MS_TEST_SPI,  1000000 );
    SpiPrescaler psc2000  = spiCalcPrescaler( MS_TEST_SPI,  2000000 );
    SpiPrescaler psc3000  = spiCalcPrescaler( MS_TEST_SPI,  3000000 );
    SpiPrescaler psc4000  = spiCalcPrescaler( MS_TEST_SPI,  4000000 );
    SpiPrescaler psc5000  = spiCalcPrescaler( MS_TEST_SPI,  5000000 );
    SpiPrescaler psc10000 = spiCalcPrescaler( MS_TEST_SPI, 10000000 );
    SpiPrescaler psc15000 = spiCalcPrescaler( MS_TEST_SPI, 15000000 );
    SpiPrescaler psc20000 = spiCalcPrescaler( MS_TEST_SPI, 20000000 );

    periphInit( MS_TEST_SPI                      
              , MS_TEST_SPI_SCK_GPIO_PIN_ADDR    
              , MS_TEST_SPI_MISO_GPIO_PIN_ADDR   
              , MS_TEST_SPI_MOSI_GPIO_PIN_ADDR   
              , umba::periph::traits::spiDataBits8
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              , umba::periph::traits::spiPrescaler256
              , PinSpeed::high // PinSpeed::low
              , spiModeSlave
              );

    periphInitIrq( MS_TEST_SPI, spiMakeEventMask(spiEventRxReady) );
    periphInstallIrqHandler( MS_TEST_SPI, spiIrqHandler );

}

//-----------------------------------------------------------------------------
void spiInit( bool bMaster )
{
    if (bMaster)
        spiInitMaster();
    else
        spiInitSlave();

}

//-----------------------------------------------------------------------------
void masterProc()
{

    stateIndicator.setDeviceState(DeviceState::device_starting);

    lout<<"Nanosec tick: "<<umba::hr_counter::getTick()<<endl;

    lout<<"-----------------\nHello from Master on "<<STM32_DISCOVERY_NAME<<endl;


/*
    //DWT_LSR 32-bit read-only register located at 0xE0001FB4

SLK, bit [1] - Software Lock status. See the ARM® CoreSight™ Architecture Specification.
0 Lock clear. Software writes are permitted to this component's registers.
1 Lock set. Software writes to this component's registers are ignored, and reads have no side effects.
This bit resets to one on a Cold reset.

SLI, bit [0]
Software Lock implemented. See the ARM® CoreSight™ Architecture Specification.
The possible values of this bit are:
0 Software Lock not implemented or debugger access.
1 Software Lock is implemented and software access.
For a debugger read of this register, or when the Software Lock is not implemented, this bit is RAZ.
*/

    
    //__OM uint32_t *DWT_LAR = (uint32_t*)0xE0001FB0;
    __IM  uint32_t *DWT_LSR = (uint32_t*)0xE0001FB4;


    lout<<"Software lock inplemented: "<< ((*DWT_LSR)&1)<<endl;
    lout<<"Software lock status: "<< (((*DWT_LSR)&2) ? "locked" : "not locked")<<endl;

    if (umba::hr_counter::isCounterAvailable())
    {
        lout<<"+ HiRes counter available"<<endl;
    }
    else
    {
        lout<<"- HiRes counter NOT available"<<endl;
    }

    //DWT->CTRL |= 1;
//#define DWT_CTRL_CYCCNTENA_Pos              0U                                         /*!< DWT CTRL: CYCCNTENA Position */
//#define DWT_CTRL_CYCCNTENA_Msk             (0x1UL /*<< DWT_CTRL_CYCCNTENA_Pos*/)       /*!< DWT CTRL: CYCCNTENA Mask */
//#define DWT_CTRL_CYCCNTENA_Pos              0U                                         /*!< DWT CTRL: CYCCNTENA Position */
//#define DWT_CTRL_CYCCNTENA_Msk             (0x1UL /*<< DWT_CTRL_CYCCNTENA_Pos*/)       /*!< DWT CTRL: CYCCNTENA Mask */
//#define DWT_CTRL_CYCCNTENA_Pos              0U                                         /*!< DWT CTRL: CYCCNTENA Position */
//#define DWT_CTRL_CYCCNTENA_Msk             (0x1UL /*<< DWT_CTRL_CYCCNTENA_Pos*/)       /*!< DWT CTRL: CYCCNTENA Mask */
//#define DWT_CTRL_CYCCNTENA_Pos              0U                                         /*!< DWT CTRL: CYCCNTENA Position */
//#define DWT_CTRL_CYCCNTENA_Msk             (0x1UL /*<< DWT_CTRL_CYCCNTENA_Pos*/)       /*!< DWT CTRL: CYCCNTENA Mask */
//CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
//DWT->CYCCNT = 0;
//DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

/*
CM7
  __IOM uint32_t FUNCTION3;              //!< Offset: 0x058 (R/W)  Function Register 3 
        uint32_t RESERVED3[981U];
  __OM  uint32_t LAR;                    //!< Offset: 0xFB0 (  W)  Lock Access Register 
  __IM  uint32_t LSR;                    //!< Offset: 0xFB4 (R  )  Lock Status Register 

CM33
        uint32_t RESERVED32[934U];
  __IM  uint32_t LSR;                    //!< Offset: 0xFB4 (R  )  Lock Status Register

*/
    if (DWT->CTRL & (1<<25)) // NOCYCCNT, bit [25]
        lout<<"Cycle counter not implemented."<<endl;
    

    lout<<"DWT_CR: "<<hex<<DWT->CTRL<<endl;
    //DWT_CR 0x4000_0001
    //DWT_CR0x4000_0000

    

    lout<<"Nanosec tick: "<<umba::hr_counter::getTick()<<endl;

    hseVal  = clockGetFreq(ClockBus::OSCCLK);
    coreClk = clockGetFreq(ClockBus::CORECLK);
    sysClk  = clockGetFreq(ClockBus::SYSCLK);
    ahbClk  = clockGetFreq(ClockBus::AHB);
    apb1Clk = clockGetFreq(ClockBus::APB1);
    apb2Clk = clockGetFreq(ClockBus::APB2); 
    spiFreq = spiGetFreq( MS_TEST_SPI );

    lout<<"HSE : "<<width(9)<<left<<hseVal <<" Hz"<<endl;
    lout<<"CORE: "<<width(9)<<left<<coreClk<<" Hz"<<endl;
    lout<<"SYS : "<<width(9)<<left<<sysClk <<" Hz"<<endl;
    lout<<"AHB : "<<width(9)<<left<<ahbClk <<" Hz"<<endl;
    lout<<"APB1: "<<width(9)<<left<<apb1Clk<<" Hz"<<endl;
    lout<<"APB2: "<<width(9)<<left<<apb2Clk<<" Hz"<<endl;
    lout<<endl;
    lout<<"SPI : "<<width(9)<<left<<spiFreq<<" Hz"<<endl;

    //const char* getClockBusName( ClockBus clockBus )

    lout<<endl;
    lout<<"SPI1: "<<getClockBusName(periphClockGetBus(SPI1))<<endl;
    lout<<"SPI2: "<<getClockBusName(periphClockGetBus(SPI2))<<endl;
    lout<<"SPI3: "<<getClockBusName(periphClockGetBus(SPI3))<<endl;

    lout<<endl;
    ClockBus spiClockBus = periphClockGetBus( MS_TEST_SPI );
    lout<<"Test SPI is on the "<<getClockBusName(spiClockBus)<<endl;

    umba::hr_counter::NanosecInterval spiCsAfterPause = umba::hr_counter::microsec(20);

    lout<<"Test nanosec counter"<<endl;
    lout<<"Nanosec tick: "<<umba::hr_counter::getTick()<<endl;
    lout<<"Nanosec tick: "<<umba::hr_counter::getTick()<<endl;
    //umba::hr_counter::delayNanosec(csAfterPause);

    // HardFault handler работает 
    //int *pi = 0;
    //*pi = 6;
    //lout<<*pi<<endl;
    //UMBA_ASSERT_FAIL();

    lout<<"Start writting to slave registers"<<endl;

    spiWriteStart( MS_TEST_SPI, SPI_MS_TEST_CMD_WRITE | (0<<8) // начинаем с нулевого регистра
                 , &msTestCsPin, spiCsAfterPause );
    //lout<<"Write started"<<endl;
    spiWaitReceiveComplete( MS_TEST_SPI );
    spiWaitNotBusy( MS_TEST_SPI, spiDoWaitNotBusy );
    umba::hr_counter::delayNanosec(5000);

    spiWriteSetValue( MS_TEST_SPI, 0x0102 );
    spiWaitReceiveComplete( MS_TEST_SPI );
    spiWaitNotBusy( MS_TEST_SPI, spiDoWaitNotBusy );
    umba::hr_counter::delayNanosec(5000);

    spiWriteSetValue( MS_TEST_SPI, 0x0304 );
    spiWaitReceiveComplete( MS_TEST_SPI );
    spiWaitNotBusy( MS_TEST_SPI, spiDoWaitNotBusy );
    umba::hr_counter::delayNanosec(5000);

    spiWriteSetValue( MS_TEST_SPI, 0x0506 );
    spiWaitReceiveComplete( MS_TEST_SPI );
    spiWaitNotBusy( MS_TEST_SPI, spiDoWaitNotBusy );
    umba::hr_counter::delayNanosec(5000);

    spiWriteSetValue( MS_TEST_SPI, 0x0708 );
    spiWaitReceiveComplete( MS_TEST_SPI );
    spiWaitNotBusy( MS_TEST_SPI, spiDoWaitNotBusy );
    umba::hr_counter::delayNanosec(5000);

    spiWriteSetValue( MS_TEST_SPI, 0x090A );
    spiWaitReceiveComplete( MS_TEST_SPI );
    spiWaitNotBusy( MS_TEST_SPI, spiDoWaitNotBusy );
    umba::hr_counter::delayNanosec(5000);

    spiWriteSetValue( MS_TEST_SPI, 0x0B0C );
    spiWaitReceiveComplete( MS_TEST_SPI );
    spiWaitNotBusy( MS_TEST_SPI, spiDoWaitNotBusy );
    umba::hr_counter::delayNanosec(5000);
    
    msTestCsPin.toggle();



    lout<<"Slave initialized"<<endl;


    lout<<"Slave regs: ";

    for ( uint16_t slaveRegIdx = 0; slaveRegIdx!=0x10; ++slaveRegIdx )
    {
        uint8_t reg = (uint8_t)( spiRead( MS_TEST_SPI, SPI_MS_TEST_CMD_READ | slaveRegIdx<<8
                                                          , msTestCsPin, spiCsAfterPause
                                                          , spiDoWaitNotBusy ) & 0xFF );


        lout<<" "<<hex<<width(2)<<noshowbase<<reg<<" ";
        umba::hr_counter::delayNanosec(10000);
    }

    lout<<"\n";

    uint16_t whoIsThat = spiRead( MS_TEST_SPI, SPI_MS_TEST_CMD_READ | (SPI_REG_WHO_AM_I<<8)
                                                      , msTestCsPin, spiCsAfterPause
                                                      , spiDoWaitNotBusy ) & 0xFF;
    lout<<"Remote ID: "<<hex<<width(2)<<whoIsThat<<endl;


    bool remoteButtonPressed = false;

    unsigned logPulseCounter = 0;

    while(true)
    {
        logPulseCounter++;
        if ((logPulseCounter%50)==0)
        {
            //lout<<"Pulse"<<endl;
        }

        #ifdef DISABLE_LOOP_SLAVE_POLLING
        uint16_t remoteStatus = 0;
        #else
        uint16_t remoteStatus = spiRead( MS_TEST_SPI, SPI_MS_TEST_CMD_READ | (SPI_REG_STATUS<<8)
                                                          , msTestCsPin, spiCsAfterPause
                                                          , spiDoWaitNotBusy ) & 0xFF;
        #endif

        bool remoteButtonPressedNewState = remoteStatus & 1 ? true : false;
        if (remoteButtonPressed!=remoteButtonPressedNewState)
        {
            lout<<"Remote button status changed"<<endl;
            // pressed or released
            remoteButtonPressed = remoteButtonPressedNewState;
            if (remoteButtonPressed)
            {
                lout<<"Remote button pressed"<<endl;

                stateIndicator.indicateDataReception();

                ledControl( true );
                delayMs(50);
                ledControl( false );

                remoteLedNo++;
                remoteLedNo &= 0xFF;

                lout<<"Remote LED: "<<(unsigned)remoteLedNo<<endl;

                spiWrite( MS_TEST_SPI, SPI_MS_TEST_CMD_WRITE | (SPI_REG_CTRL_LEDS<<8) | (uint16_t)remoteLedNo
                                                          , msTestCsPin, spiCsAfterPause
                                                          , spiDoWaitNotBusy );
            }
        }
        
        delayMs(100);
        stateIndicator.poll();
    }

}

//-----------------------------------------------------------------------------
void slaveProc()
{
    lout<<"-----------------\nHello from Slave on "<<STM32_DISCOVERY_NAME<<endl;
    umba::hr_counter::HiResTick deltaTick = umba::hr_counter::convertNanosecToTick( (umba::hr_counter::HiResTick)100 );
    lout<<"100 ns in ticks: "<<deltaTick<<"\n";

    lout<<"Cur delay: "<<nanosecDelayVal<<" ns\n";
    lout<<"HRC Freq : "<<umba::hr_counter::getTickFreqKHz()<<" KHz\n";

    hseVal  = clockGetFreq(ClockBus::OSCCLK);
    coreClk = clockGetFreq(ClockBus::CORECLK);
    sysClk  = clockGetFreq(ClockBus::SYSCLK);
    ahbClk  = clockGetFreq(ClockBus::AHB);
    apb1Clk = clockGetFreq(ClockBus::APB1);
    apb2Clk = clockGetFreq(ClockBus::APB2); 
    spiFreq = spiGetFreq( MS_TEST_SPI );

    lout<<"HSE : "<<width(9)<<left<<hseVal <<" Hz"<<endl;
    lout<<"CORE: "<<width(9)<<left<<coreClk<<" Hz"<<endl;
    lout<<"SYS : "<<width(9)<<left<<sysClk <<" Hz"<<endl;
    lout<<"AHB : "<<width(9)<<left<<ahbClk <<" Hz"<<endl;
    lout<<"APB1: "<<width(9)<<left<<apb1Clk<<" Hz"<<endl;
    lout<<"APB2: "<<width(9)<<left<<apb2Clk<<" Hz"<<endl;


    static umba::hr_counter::HiResTick nanosecOrTick = 60200;
    nanosecOrTick *= umba::hr_counter::getTickFreqKHz();
    nanosecOrTick /= 1000;
    nanosecOrTick /= 1000;

    //gpio_in_floating / gpio_in_pulldown
    
    auto btnPinMode = PinMode::gpio_in_pulldown; // gpio_in_floating; gpio_in_pullup;

    periphInitIrq( btnPin, extiTriggerBoth, btnPinMode );
    periphInstallIrqHandler( btnPin, btnIrqHandlerProc );    

    periphInitIrq( msTestCsPin, extiTriggerFalling, PinMode::gpio_in_pullup );
    periphInstallIrqHandler( msTestCsPin, chipSelectIrqHandlerProc );    


    while(true)
    {
        #if defined(BUTTON_LED_TEST)
        bool btnNewState = btnPin;
        if (btnPrevState!=btnNewState) // state changed
        {
            btnPrevState = btnNewState;
            //if (btnNewState)
            //    ledPin       = !ledPin;
        }
        #endif

        delayMs(2500);

        lout<<"regs:";
        for( size_t regIdx = 0; regIdx!=SPI_NUMBER_OF_REG; ++regIdx)
        {
            lout<<" "<<hex<<width(2)<<noshowbase<<slaveRegs[regIdx];
        }
        lout<<endl;

    }

}
