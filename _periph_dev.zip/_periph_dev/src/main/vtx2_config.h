#pragma once

#ifdef STM32F103T8
    #include "vtl-periph.h"
#else
    #include "vtx2_master.h"
    //#include "vtx2_slave.h"
#endif


// vtx2_master
// ESC_PWM - TIM1_CH2

// vtx2_slave
// ESC_PWM - TIM2_CH3 TIM5_CH3 TIM9_CH1

// vtl-periph
// ESC_PWM - TIM1_CH4 




