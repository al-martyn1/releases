#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"




#if !defined(STM32F3_SERIES)
    #error "STM32F3_SERIES not defined"
#endif

#include "vtx2_hotend.h"
#include "hot_end_dbg_uart_conf.h"




#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  lout(&charWritter);




static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;



#define CON_UART DEBUG_TERMINAL_LEGACY_UART


inline
void uartReadByte( uart::Handle &u, uint8_t *pByte )
{
    if (pByte)
        *pByte = u.getByte();
    else
        u.getByte();
}


inline
bool uartWaitReadByte( uart::Handle &u, umba::time_service::TimeTick waitPeriod, uint8_t *pByte )
{
    if (u.isNewByte())
    {
        //lout<<"u:read\n";
        uartReadByte( u, pByte );
        return true;
    }

    if (!waitPeriod)
    {
        //lout<<"u:timedout\n";
        return false;
    }

    using namespace umba::time_service;

    TimeTick tickStart = getCurTimeMs();
    while( (getCurTimeMs()-tickStart) < waitPeriod)
    {
        //lout<<"u:while\n";
        if (u.isNewByte())
        {
            //lout<<"u:read 2\n";
            uartReadByte( u, pByte );
            return true;
        }
    }

    //lout<<"u:no_data\n";

    return false;
}


template< typename THandler >
void readTerminalInput( uart::Handle &u, const THandler &handler )
{
    // Esc - start, '[' - second, '~' (tilde) - end of sequence
    uint8_t buf[16];
    size_t idx = 0;

    const umba::time_service::TimeTick zeroWaitPeriod = 10;
    const umba::time_service::TimeTick seqWaitPeriod  = 10;

    if ( !uartWaitReadByte( u, zeroWaitPeriod, &buf[idx]) )
        return;

    using namespace umba::omanip;

    if (buf[idx]!=0x1B)
    {
        switch(buf[idx])
        {
            case 0x0D: handler( umba::periph::VirtualKeyCode::enter     ); return;
            case 0x09: handler( umba::periph::VirtualKeyCode::tab       ); return;
            case 0x1A: handler( umba::periph::VirtualKeyCode::pause     ); return;
            case 0x7F: handler( umba::periph::VirtualKeyCode::backspace ); return;
            default:   handler( buf[idx] ); return;
        }
        //lout<<"Received char: '"<<(char)buf[idx]<<"' ("<<width(4)<<hex<<buf[idx]<<")"<<endl;
        return;
    }

    if ( !uartWaitReadByte( u, seqWaitPeriod, &buf[idx]) )
    {
        handler( umba::periph::VirtualKeyCode::escape );
        //lout<<"Received ESCAPE"<<endl;
        return;
    }

    if (buf[idx]!='[')
    {
        handler( umba::periph::VirtualKeyCode::escape );
        handler( buf[idx] );
        //lout<<"Received ESCAPE"<<endl;
        //lout<<"Received char: '"<<(char)buf[idx]<<"' ("<<width(4)<<hex<<buf[idx]<<")"<<endl;
        return;
    }

    while( true )
    {
        if (idx==1)
        {
            switch(buf[0])
            {
                case 0x41: handler(umba::periph::VirtualKeyCode::up   ); return;
                case 0x42: handler(umba::periph::VirtualKeyCode::down ); return;
                case 0x43: handler(umba::periph::VirtualKeyCode::right); return;
                case 0x44: handler(umba::periph::VirtualKeyCode::left ); return;
            }
        }

        if ( !uartWaitReadByte(u, seqWaitPeriod, &buf[idx]) )
        {
            //
            lout<<"Broken ESC sequence - timedout: "<<endl;
            for( size_t i = 0; i!=idx; ++i )
            {
                lout<<" "<<width(4)<<hex<<buf[i];
            }
            lout<<endl;
            //
            return;
        }

        if (buf[idx]=='~')
        {
            /*
            lout<<"Received ESC sequence:";
            for( size_t i = 0; i!=idx; ++i )
            {
                lout<<" "<<width(4)<<hex<<buf[i];
            }
            lout<<endl;
            */
            if (idx==1)
            {
                switch(buf[0])
                {
                    case 0x31: handler(umba::periph::VirtualKeyCode::home     ); return;
                    case 0x32: handler(umba::periph::VirtualKeyCode::ins      ); return;
                    case 0x33: handler(umba::periph::VirtualKeyCode::del      ); return;
                    case 0x34: handler(umba::periph::VirtualKeyCode::end      ); return;
                    case 0x35: handler(umba::periph::VirtualKeyCode::pageUp   ); return;
                    case 0x36: handler(umba::periph::VirtualKeyCode::pageDown ); return;
                    default  : handler(umba::periph::VirtualKeyCode::unknown | buf[0] ); return;
                }
            }
            else if (idx==2)
            {
                switch(buf[0])
                   {
                    case 0x31:   if (buf[1]>=0x31 && buf[1] <= 0x35)
                                     { handler( (buf[1] - 0x31) + umba::periph::VirtualKeyCode::f1 ); return; }
                                 if (buf[1]>=0x37 && buf[1] <= 0x39)
                                     { handler( (buf[1] - 0x37) + umba::periph::VirtualKeyCode::f6 ); return; }
                                 handler(umba::periph::VirtualKeyCode::unknown | ((unsigned)buf[0])<<8 | buf[1] ); return;
                                 
                    case 0x32:   if (buf[1]>=0x30 && buf[1] <= 0x31)
                                     { handler( (buf[1] - 0x30) + umba::periph::VirtualKeyCode::f9 ); return; }
                                 if (buf[1]>=0x33 && buf[1] <= 0x34)
                                     { handler( (buf[1] - 0x33) + umba::periph::VirtualKeyCode::f11 ); return; }

                    default  :   handler(umba::periph::VirtualKeyCode::unknown | ((unsigned)buf[0])<<8 | buf[1] ); return;
                   }
            }
            return;
        }

        if ( (idx+1)!=(sizeof(buf)/sizeof(buf[0])) )
           ++idx;
    }

}




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;

    
    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );

    umba::time_service::delayMs(300);

    lout<<"Starting\n";

    using namespace umba::omanip;


    unsigned n = 0;
    while(1)
    {
        //if (CON_UART.isNewByte())
        //{
        //    lout<<"has data"<<endl;
        //}
        //uartReadByte( uart::Handle &u, uint8_t *pByte )
        // lout<<"Running\n";

        readTerminalInput( CON_UART
                         , []( unsigned vk )
                         {
                             using namespace umba::omanip;
                             if (vk & umba::periph::VirtualKeyCode::virtualCodeFlag)
                                lout<<umba::periph::VirtualKeyCode::getKeyCodeName(vk)<<endl;
                             else
                                lout<<(char)(uint8_t)(vk)<<endl;
                         }
                         );


    }

    return 0;
}




