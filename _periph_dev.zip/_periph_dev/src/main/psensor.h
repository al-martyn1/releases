#pragma once

#include "umba/umba.h"
#include "stm32.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "periph/gpio.h"




#ifdef STM32F1_SERIES

    #include "periph/dirty/stm32_i2c/soft_i2c.h"
    #include "periph/dirty/stm32_i2c/soft_timer.h"

#else 

    #include "periph/dirty/stm32_i2c/i2c_init.h"
    #include "periph/dirty/stm32_i2c/i2c_nonblocking.h"

#endif




#include "periph/dirty/honeywell.h"

// #ifdef STM32F1_SERIES
#define PSENSOR_USE_SOFT_I2C


//SoftI2c m_softI2c      { pins::vl53lox_i2c_sda     , pins::vl53lox_i2c_scl };


enum class HoneywellPressureSensorState
{
    normal             , // 00
    commandMode        , // 01
    staleData          , // 10 - data allready fetched
    diagnosticCondition  // 11
};

struct HoneywellPressureSensorOnChangeDoNothingHandler
{
    void operator()( bool fLinkGood, HoneywellPressureSensorState sensorState, HoneywellFloat val )
    {}
};








//-----------------------------------------------------------------------------


const HoneywellFloat psi2BarScale    = 0.0689476;


template< typename OnChangeHandlerType = HoneywellPressureSensorOnChangeDoNothingHandler>
class HoneywellPressureSensor
{

protected:

    
    #ifdef PSENSOR_USE_SOFT_I2C


    #else

        struct CompletionHandler : public II2cCompletionHandler
        {
            HoneywellPressureSensor *m_pOwner;
       
            CompletionHandler(HoneywellPressureSensor *pOwner) : m_pOwner(pOwner) {}
       
            virtual 
            bool onI2cCompletion( bool fFail, I2cPort &i2c ) override
            {
                //m_handlerFunctor(fFail, i2c);
                bool failStateChanged = m_pOwner->m_sensorLinkGood != !fFail;
                m_pOwner->m_sensorLinkGood = !fFail;

                uint8_t* pBuf = i2c.getReadBuf();

                if ( m_pOwner->parseSensorData( pBuf ) || failStateChanged )
                {
                    m_pOwner->m_onChangeHandler( m_pOwner->m_sensorLinkGood, m_pOwner->m_sensorState, m_pOwner->m_sensorValue );
                }

       
                /*
                if (fFail)
                {
                    if (failStateChanged)
                    {
                        m_pOwner->m_onChangeHandler( m_pOwner->m_sensorLinkGood, m_pOwner->m_sensorState, m_pOwner->m_sensorValue );
                    }
                    return true;
                }
       
                uint8_t* pBuf = i2c.getReadBuf();
       
                uint16_t rawSensorData = umba::bits::makeIntFromBytesBE<uint16_t>(&pBuf[0]);
                if (m_pOwner->m_rawSensorData==rawSensorData && !failStateChanged)
                    return true; // no changes, skip notification
       
                uint8_t statusBits = pBuf[0] & (0x80 | 0x40);
                statusBits >>= 6;
                pBuf[0] &= 0x3F;
                
                switch(statusBits)
                {
                    case 0: m_pOwner->m_sensorState = HoneywellPressureSensorState::normal ;
                            break;
                    case 1: m_pOwner->m_sensorState = HoneywellPressureSensorState::commandMode ;
                            break;
                    case 2: m_pOwner->m_sensorState = HoneywellPressureSensorState::staleData ;
                            break;
                    case 3: m_pOwner->m_sensorState = HoneywellPressureSensorState::diagnosticCondition ;
                            break;
                }
       
                uint16_t rawPressure    = umba::bits::makeIntFromBytesBE<uint16_t>(&pBuf[0]);
       
                //double pressureDeltaHoneywellBar = psi2BarScale * pressureDeltaHoneywell;
                //lout<<umba::omanip::width(6)<<n<<"  Pressure: "<<(1000.0*pressureDeltaHoneywellBar)<<"\n";
       
                m_pOwner->m_sensorValue = honeywellPressureSensor_HSCSSNN001PD2a3_valueConversion(rawPressure) * psi2BarScale * 1000.0;
                */
                //m_pOwner->m_onChangeHandler( m_pOwner->m_sensorLinkGood, m_pOwner->m_sensorState, m_pOwner->m_sensorValue );
       
                return true;
            }
       
        }; // struct CompletionHandler

    #endif


    friend struct CompletionHandler;

public:


    #ifdef PSENSOR_USE_SOFT_I2C

        HoneywellPressureSensor( umba::periph::GpioPinAddr sdaPinAddr
                               , umba::periph::GpioPinAddr sclPinAddr
                               , uint8_t deviceBusAddr
                               , const OnChangeHandlerType &onChangeHandler = HoneywellPressureSensorOnChangeDoNothingHandler()
                               , uint32_t half_bit_timeout = 15
                               )
          : m_softI2c( sdaPinAddr//umba::periph::GpioPin( { sdaPinAddr.port, (uint16_t)(1<<sdaPinAddr.pinNo) } )
                     , sclPinAddr//umba::periph::GpioPin( { sclPinAddr.port, (uint16_t)(1<<sclPinAddr.pinNo) } )
                     , half_bit_timeout
                     )
          , m_i2c2Timer()
          , m_deviceBusAddr(deviceBusAddr)
          , m_onChangeHandler(onChangeHandler)
          , m_rawSensorData(0)
          , m_sensorLinkGood(false)
          , m_sensorState(HoneywellPressureSensorState::normal)
          , m_sensorValue(0.0)
        {
        }

    #else

        HoneywellPressureSensor( I2cPort &i2c
                               , const umba::periph::dirty::I2cInitializer &initializer
                               , uint8_t deviceBusAddr
                               , const OnChangeHandlerType &onChangeHandler = HoneywellPressureSensorOnChangeDoNothingHandler()
                               )
          : m_i2c(i2c)
          , m_initializer(initializer)
          , m_i2cBatchListWorker( m_i2c, &m_i2cPSensorBatch[0] )
          , m_completionHandler( CompletionHandler(this) )
          , m_i2c2Timer()
          , m_deviceBusAddr(deviceBusAddr)
          , m_onChangeHandler(onChangeHandler)
          , m_rawSensorData(0)
          , m_sensorLinkGood(false)
          , m_sensorState(HoneywellPressureSensorState::normal)
          , m_sensorValue(0.0)
        {}

    #endif

    void init()
    {
        #ifdef PSENSOR_USE_SOFT_I2C

        #else

            m_i2c.init( m_initializer.getRawPort(), &m_initializer, &m_i2c2Timer, 2, 2 );
           
            m_i2cPSensorBatch[0] = { I2cBatchListEntry::READ, I2cBatchListEntry::SIMPLE, m_deviceBusAddr, &m_i2cBuf[0], 2 /* buf size */, &m_completionHandler };
            m_i2cPSensorBatch[1] = { I2cBatchListEntry::LISTEND };
            //m_i2cBatchListWorker = I2cBatchListWorker( m_i2c, &m_i2cPSensorBatch[0] );
            m_i2cBatchListWorker.setBatchList( &m_i2cPSensorBatch[0] );

        #endif
    }

    void poll()
    {
        #ifdef PSENSOR_USE_SOFT_I2C

            uint8_t  i2cBuf[2];

            bool newSensorLinkGood = m_softI2c.readFrom( m_deviceBusAddr, &i2cBuf[0], 2 );
            bool failStateChanged = newSensorLinkGood != m_sensorLinkGood;
            m_sensorLinkGood = newSensorLinkGood;
            if (!m_sensorLinkGood)
            {
                return;
            }

            if ( parseSensorData( &i2cBuf[0] ) || failStateChanged )
            {
                m_onChangeHandler( m_sensorLinkGood, m_sensorState, m_sensorValue );
            }

        #else

            m_i2cBatchListWorker.performBatchStep();
            {
                if (m_i2cBatchListWorker.isDone())
                {
                    m_i2cBatchListWorker.startBatch();
                }
            }

        #endif
    
    }

    bool getLinkGood() const
    {
        return m_sensorLinkGood;
    }

    HoneywellPressureSensorState getSensorState() const
    {
        return m_sensorState;
    }

    const char* getSensorStateStr() const
    {
        switch(m_sensorState)
           {
            case HoneywellPressureSensorState::normal              : return "Normal";
            case HoneywellPressureSensorState::commandMode         : return "Command Mode";
            case HoneywellPressureSensorState::staleData           : return "Stale Data";
            case HoneywellPressureSensorState::diagnosticCondition : return "Diagnostic";
           }
        return "Unknown";
    }

    bool isSensorStateGood() const
    {
        switch(m_sensorState)
           {
            case HoneywellPressureSensorState::normal              : return true;
            case HoneywellPressureSensorState::staleData           : return true;
           }
        return false;
    }

    HoneywellFloat getValue() const
    {
        return m_sensorValue;
    }

    uint16_t getRawData() const
    {
        return m_rawSensorData;
    }


    // return true if data changed
    bool parseSensorData( const uint8_t *pData )
    {
        uint16_t rawSensorData = umba::bits::makeIntFromBytesLE<uint16_t>(pData);
        if (m_rawSensorData==rawSensorData /*  && !failStateChanged */ )
            return false; // no changes, skip notification
        
        m_rawSensorData = rawSensorData;
        
        uint16_t statusBits = m_rawSensorData & (0x8000 | 0x4000); // i2cBuf[0] & (0x80 | 0x40);
        statusBits >>= 14;
        
        switch(statusBits)
        {
            case 0: m_sensorState = HoneywellPressureSensorState::normal ;
                    break;
            case 1: m_sensorState = HoneywellPressureSensorState::commandMode ;
                    break;
            case 2: m_sensorState = HoneywellPressureSensorState::staleData ;
                    break;
            case 3: m_sensorState = HoneywellPressureSensorState::diagnosticCondition ;
                    break;
        }
        
        uint16_t rawPressure    = m_rawSensorData & 0x3FFF;
        
        m_sensorValue = honeywellPressureSensor_HSCSSNN001PD2a3_valueConversion(rawPressure);
        m_sensorValue *= 1000.0;
        m_sensorValue *= psi2BarScale;
        
        // * psi2BarScale * 1000.0;

        return true;
    }


protected:



    #ifdef PSENSOR_USE_SOFT_I2C

        SoftI2c                                m_softI2c; //       { pins::vl53lox_i2c_sda     , pins::vl53lox_i2c_scl };

    #else

        I2cPort                               &m_i2c;
        umba::periph::dirty::I2cInitializer    m_initializer;
        I2cBatchListWorker                     m_i2cBatchListWorker;
        CompletionHandler                      m_completionHandler;
        I2cBatchListEntry                          m_i2cPSensorBatch[2];

    #endif

    SoftTimerMillisec                          m_i2c2Timer;
    uint8_t                                    m_deviceBusAddr;
                                              
    OnChangeHandlerType                        m_onChangeHandler;
                                              
    uint16_t                                   m_rawSensorData;
    bool                                       m_sensorLinkGood;
    HoneywellPressureSensorState               m_sensorState;
    HoneywellFloat                             m_sensorValue;
                                              
    #ifndef PSENSOR_USE_SOFT_I2C
        uint8_t                                    m_i2cBuf[2];
    #endif


}; // class HoneywellPressureSensor


