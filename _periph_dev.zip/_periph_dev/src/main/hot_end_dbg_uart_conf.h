#pragma once

#define DEBUG_TERMINAL_UART                           UART2
#define DEBUG_TERMINAL_LEGACY_UART                    uart::uart2
#define USE_UART2                                     1
#define DEBUG_TERMINAL_UART_TX_GPIO                   GPIOA
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO            2
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_SOURCE        GPIO_PinSource2
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_DIRECTION     GPIO_DIRECTION_OUT    /* Informational only */

#define DEBUG_TERMINAL_UART_RX_GPIO                   GPIOA
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO            3
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_SOURCE        GPIO_PinSource3
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_DIRECTION     GPIO_DIRECTION_IN    /* Informational only */

