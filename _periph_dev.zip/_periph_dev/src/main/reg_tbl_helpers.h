namespace umba {
namespace misc {



template< typename RegTable >
void setVal( RegTable, int8_t val, uint8_t regNo )
{

}

void setReg32Val( uint8_t lowRegNum, uint32_t val )
uint32_t getReg32Val( uint8_t lowRegNum )





} // namespace misc
} // namespace umba

