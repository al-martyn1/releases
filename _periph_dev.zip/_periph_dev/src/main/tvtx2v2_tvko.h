#pragma once

#include "vtx2v2/telexertex2_regs.h"

// Remap mainboard register names to namespace tvko, used in Vanya's camera code


namespace tvko{

namespace ro{

} // ro

namespace rw{

    //constexpr uint8_t tvko_azimuth_speed_ctrl_s8_raw_id                                ;
    //constexpr uint8_t tvko_elevation_speed_ctrl_s8_raw_id                              ;
    constexpr uint8_t camera_power_u8           = regs::Televertex2::rw::tvko_camera_power_u8_raw_id                 ;
    constexpr uint8_t digital_zoom_u8           = regs::Televertex2::rw::tvko_digital_zoom_u8_raw_id                 ;
    constexpr uint8_t auto_focus_u8             = regs::Televertex2::rw::tvko_auto_focus_u8_raw_id                   ;
    constexpr uint8_t zoom_speed_s8             = regs::Televertex2::rw::tvko_zoom_speed_s8_raw_id                   ;
    constexpr uint8_t focus_speed_s8            = regs::Televertex2::rw::tvko_focus_speed_s8_raw_id                  ;
    constexpr uint8_t infrared_correction_u8    = regs::Televertex2::rw::tvko_infrared_correction_u8_raw_id          ;
    constexpr uint8_t white_balance_u8          = regs::Televertex2::rw::tvko_white_balance_u8_raw_id                ;
    constexpr uint8_t red_gain_u8               = regs::Televertex2::rw::tvko_red_gain_u8_raw_id                     ;
    constexpr uint8_t blue_gain_u8              = regs::Televertex2::rw::tvko_blue_gain_u8_raw_id                    ;
    constexpr uint8_t automatic_exposure_u8     = regs::Televertex2::rw::tvko_automatic_exposure_u8_raw_id           ;
    constexpr uint8_t shutter_u8                = regs::Televertex2::rw::tvko_shutter_u8_raw_id                      ;
    constexpr uint8_t iris_u8                   = regs::Televertex2::rw::tvko_iris_u8_raw_id                         ;
    constexpr uint8_t gain_u8                   = regs::Televertex2::rw::tvko_gain_u8_raw_id                         ;
    constexpr uint8_t bright_u8                 = regs::Televertex2::rw::tvko_bright_u8_raw_id                       ;
    constexpr uint8_t backlight_compensation_u8 = regs::Televertex2::rw::tvko_backlight_compensation_u8_raw_id       ;
    constexpr uint8_t defog_u8                  = regs::Televertex2::rw::tvko_defog_u8_raw_id                        ;
    constexpr uint8_t high_resolution_mode_u8   = regs::Televertex2::rw::tvko_high_resolution_mode_u8_raw_id         ;
    constexpr uint8_t mirror_u8                 = regs::Televertex2::rw::tvko_mirror_u8_raw_id                       ;
    constexpr uint8_t black_white_u8            = regs::Televertex2::rw::tvko_black_white_u8_raw_id                  ;
    constexpr uint8_t flip_u8                   = regs::Televertex2::rw::tvko_flip_u8_raw_id                         ;
    constexpr uint8_t infrared_mode_u8          = regs::Televertex2::rw::tvko_infrared_mode_u8_raw_id                ;
    constexpr uint8_t auto_infrared_mode_u8     = regs::Televertex2::rw::tvko_auto_infrared_mode_u8_raw_id           ;
    constexpr uint8_t auto_infrared_mode_threshold_u8 = regs::Televertex2::rw::tvko_auto_infrared_mode_threshold_u8_raw_id ;
    constexpr uint8_t stabilizer_u8             = regs::Televertex2::rw::tvko_stabilizer_u8_raw_id                   ;
    //constexpr uint8_t color_enhance_u8          = regs::Televertex2::rw::tvko_color_enhance_u8_raw_id                ;

    constexpr uint8_t zoom_direct_position_s16                               = regs::Televertex2::rw::tvko_zoom_direct_position_u16_raw_id;
    //constexpr uint8_t color_enhance_fixed_color_cb_of_high_intensity_side_u8 = regs::Televertex2::rw::tvko_color_enhance_fixed_color_cb_of_high_intensity_side_u8_raw_id;
    //constexpr uint8_t color_enhance_fixed_color_cb_of_low_intensity_side_u8  = regs::Televertex2::rw::tvko_color_enhance_fixed_color_cb_of_low_intensity_side_u8_raw_id ;
    //constexpr uint8_t color_enhance_fixed_color_cr_of_high_intensity_side_u8 = regs::Televertex2::rw::tvko_color_enhance_fixed_color_cr_of_high_intensity_side_u8_raw_id;
//    constexpr uint8_t color_enhance_fixed_color_cr_of_low_intensity_side_u8  = regs::Televertex2::rw::tvko_color_enhance_fixed_color_cr_of_low_intensity_side_u8_raw_id ;
//    constexpr uint8_t color_enhance_fixed_color_y_of_high_intensity_side_u8  = regs::Televertex2::rw::tvko_color_enhance_fixed_color_y_of_high_intensity_side_u8_raw_id ;
//    constexpr uint8_t color_enhance_fixed_color_y_of_low_intensity_side_u8   = regs::Televertex2::rw::tvko_color_enhance_fixed_color_y_of_low_intensity_side_u8_raw_id  ;
//    constexpr uint8_t color_enhance_hysteresis_width_u8                      = regs::Televertex2::rw::tvko_color_enhance_hysteresis_width_u8_raw_id                     ;
//    constexpr uint8_t color_enhance_threshold_level_u8                       = regs::Televertex2::rw::tvko_color_enhance_threshold_level_u8_raw_id                      ;
    //constexpr uint8_t 

    /*
    constexpr uint8_t                      ;
    constexpr uint8_t                     ;
    constexpr uint8_t  ;
    constexpr uint8_t ;
    constexpr uint8_t ;
    constexpr uint8_t   ;
    constexpr uint8_t  ;
    constexpr uint8_t  ;
    constexpr uint8_t tvko_zoom_direct_position_u16_raw_id                              ;
    */
} // rw

} // namespace tvko


