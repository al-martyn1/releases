#include "protothread.h"

#include "umba/time_service.h"

class ExpiryTimer
{

public:

    void Start(umba::time_service::TimeTick p)
    {
        m_startTick = umba::time_service::getCurTimeMs();
        m_period    = p;
    }

    bool Expired() const
    {
        return (umba::time_service::getCurTimeMs() - m_startTick) >= m_period;
    }


protected:

    umba::time_service::TimeTick m_startTick = 0;
    umba::time_service::TimeTick m_period = 0;

};


 class LEDFlasher : public Protothread
 {
 public:
     virtual bool Run();

 private:
     ExpiryTimer _timer;
     uint32_t _i;
 };

 bool LEDFlasher::Run()
 {
     PT_BEGIN();

     for (_i = 0; _i < 10; _i++)
     {
         UMBA_RTKOS_LOG<<"I: "<<_i<<", cp 1, tick: "<<umba::time_service::getCurTimeMs()<<umba::omanip::endl;

         //SetLED(true);
         _timer.Start(1500);

         //UMBA_RTKOS_LOG<<"I: "<<_i<<", cp 2, tick: "<<umba::time_service::getCurTimeMs()<<umba::omanip::endl;

         PT_WAIT_UNTIL(_timer.Expired());

         UMBA_RTKOS_LOG<<"I: "<<_i<<", cp 2, tick: "<<umba::time_service::getCurTimeMs()<<umba::omanip::endl;

         //SetLED(false);
         _timer.Start(750);
         PT_WAIT_UNTIL(_timer.Expired());

         UMBA_RTKOS_LOG<<"I: "<<_i<<", cp 3, tick: "<<umba::time_service::getCurTimeMs()<<umba::omanip::endl;

     }

     UMBA_RTKOS_LOG<<"I: "<<_i<<", cp 5, tick: "<<umba::time_service::getCurTimeMs()<<umba::omanip::endl;

     PT_END();
 }

