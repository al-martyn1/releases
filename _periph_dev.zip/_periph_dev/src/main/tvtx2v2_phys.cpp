#include "umba/umba.h"
#include "umba/simple_formatter.h"

#include "tvtx2v2_phys.h"


umba::StdStreamCharWriter coutWriter(std::cout);
//umba::StdStreamCharWriter cerrWriter(std::cerr);
//umba::NulCharWriter       nulWriter;

//umba::SimpleFormatter logMsg(&coutWriter);
//umba::SimpleFormatter logErr(&cerrWriter);
//umba::SimpleFormatter logNul(&nulWriter);

umba::SimpleFormatter out(&coutWriter);



int main(int argc, char* argv[])
{


    return 0;
}