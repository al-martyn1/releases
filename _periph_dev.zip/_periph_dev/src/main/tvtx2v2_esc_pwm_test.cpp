// master options
//#define USE_BTN_FOR_SPI_PING

// slave options

#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
//#include "umba/hr_counter.h"


extern umba::SimpleFormatter  lout;

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"

#include "scalcus/pwm.h"


#define USE_PSENSOR 

#ifdef USE_PSENSOR 

#include "periph/dirty/stm32_i2c/soft_i2c.h"
#include "periph/dirty/stm32_i2c/soft_timer.h"
#include "periph/dirty/honeywell.h"

#include "psensor.h"

#endif


//#include "periph/stm32_discovery.h"


//#include "spi_test_master_slave.h"
//#include "device_state_indicator.h"

//#include "vtl-periph.h"

#include "boards_conf/tvtx2v2_Foot_Board_conf.h"
#include "boards_conf/tvtx2v2_Foot_Board_pins.cpp"

UMBA_PERIPH_DECLARE_PIN_EX( rangeFinder1_Pin,	 UMBA_PINADDR_PB14,	UMBA_GPIO_DIRECTION_IN );
UMBA_PERIPH_DECLARE_PIN_EX( rangeFinder2_Pin,	 UMBA_PINADDR_PB13,	UMBA_GPIO_DIRECTION_IN );
UMBA_PERIPH_DECLARE_PIN_EX( rangeFinder3_Pin,	 UMBA_PINADDR_PB12,	UMBA_GPIO_DIRECTION_IN );
UMBA_PERIPH_DECLARE_PIN_EX( rangeFinder4_Pin,	 UMBA_PINADDR_PB15,	UMBA_GPIO_DIRECTION_IN );


bool brf1Prev = false; // rangeFinder1_Pin
bool brf2Prev = false; // rangeFinder2_Pin
bool brf3Prev = false; // rangeFinder3_Pin
bool brf4Prev = false; // rangeFinder4_Pin


//#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )

//DECLARE_PIN( btnPin , STM32_DISCOVERY_BTN_USER );


using namespace umba::time_service;
using namespace umba::periph::traits;
using namespace umba::omanip;


umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);

// ESC PWM - PA11 TIM1 CH4
// X4 UART6 debug, TX: PA9 (X4.2), RX: PA10 (X4.1), GND: X4.3

uint32_t escPwmStandby =  100; // 800
uint32_t escPwmDelta   =    5;
uint32_t escPwmMin     =  escPwmStandby + escPwmDelta;
uint32_t escPwmMax     = 3000;

volatile uint32_t pwmFreq = 50; // Hz
volatile bool     bManualDbg = false;

unsigned pwmPulseOutputMax = 0;

void initTimer( uint32_t pwmFreq );


//UMBA_PERIPH_DECLARE_PIN
//I2cPort i2c;


uint32_t pwmCtrl = escPwmStandby; // mode - microsec

unsigned prevPressure = 0; // tenths

unsigned convertPressureToTenths( float v )
{
    if (v<0)
        v = 0.0;
    return (unsigned)(v*10.0);
}




#ifdef USE_PSENSOR 
auto psensorHandler = [&](bool fLinkGood, HoneywellPressureSensorState sensorState, float val)
                      {
                          //lout<<"Val: "<<val<<"\n";
                          //printState();
                          unsigned newPressure = convertPressureToTenths(val);
                          if (prevPressure!=newPressure)
                          {
                              prevPressure = newPressure;
                              lout<<"Pressure: "<<val<<", PWM: "<<pwmCtrl<<umba::omanip::endl;
                          }
                      };
                                                                    
auto pSensor = HoneywellPressureSensor< decltype(psensorHandler) >(  PB7 //PB6 // PB7 // SDA
                                                                  ,  PB6 //PB7 // PB6 // SCL
                                                                  , 0x28 // deviceBusAddr
                                                                  , psensorHandler
                                                                  , 100
                                                                  );
#endif


#ifdef STM32F303x8
    #warning "STM32F303x8"
#endif

#ifdef STM32F334x8
    #warning "STM32F334x8"
#endif

#ifdef STM32F301x8
    #warning "STM32F301x8"
#endif

#ifdef STM32F302x8
    #warning "STM32F302x8"
#endif




int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    DEBUG_LEGACY_UART.init( DEBUG_UART_RX_GPIO, DEBUG_UART_RX_GPIO_PIN_NO
                          , DEBUG_UART_TX_GPIO, DEBUG_UART_TX_GPIO_PIN_NO
                          , 460800 // 2*460800/3 // 3*460800/2 // 2*460800/3 // 460800*2
                          ); // bug - http://wiki.dep111.rtc.local/knowledge:stm32
    //STM32_DISCOVERY_LEGACY_UART.init( PA10, PA9, 460800 );

    initTimer(pwmFreq);

    brf1Prev = rangeFinder1_Pin;
    brf2Prev = rangeFinder2_Pin;
    brf3Prev = rangeFinder3_Pin;
    brf4Prev = rangeFinder4_Pin;


    

    //
    lout<<"Hello ESC TIM16 CH1!"<<endl;

    umba::periph::traits::timerPwmControl( TIM16 , 1
                                         , pwmFreq, pwmPulseOutputMax
                                         , umba::periph::traits::TimerPwmControlType::microsecs
                                         , pwmCtrl
                                         );

    #ifdef USE_PSENSOR 
    pSensor.init();
    #endif

    auto kbdHandler = umba::periph::makeKeyboardHandler
                    ( 
                         [&]( unsigned vkc, bool fPressed, size_t repeatCout )
                         {
                             using namespace umba::omanip;

                             if (vkc&umba::periph::VirtualKeyCode::virtualCodeFlag)
                                 lout<<"Key ["<<umba::periph::VirtualKeyCode::getKeyCodeName( vkc )<<"] ";
                             else
                                 lout<<"Key '"<<(char)(uint8_t)vkc<<"' ";

                             if (fPressed)
                                 lout<<"pressed"<<endl;
                             else
                                 lout<<"released"<<endl;

                             #ifndef KBD_TEST

                             #ifndef IMPELLER_SIMPLE_UP_DOWN
                             if (fPressed)
                             {
                                 uint32_t pwmCtrlPrev = pwmCtrl;

                                 if (vkc == umba::periph::VirtualKeyCode::up || vkc == umba::periph::VirtualKeyCode::pageUp )
                                 {
                                     if (pwmCtrl!=escPwmStandby)
                                     {
                                         pwmCtrl += escPwmDelta * ( vkc == umba::periph::VirtualKeyCode::up ? 1 : 5 );
                                         if (pwmCtrl>escPwmMax)
                                             pwmCtrl = escPwmMax;
                                     }
                                 }
                                 else if (vkc == umba::periph::VirtualKeyCode::down || vkc == umba::periph::VirtualKeyCode::pageDown )
                                 {
                                     if (pwmCtrl!=escPwmStandby)
                                     {
                                         pwmCtrl -= escPwmDelta * ( vkc == umba::periph::VirtualKeyCode::down ? 1 : 5 );
                                         if (pwmCtrl<escPwmMin)
                                             pwmCtrl = escPwmMin;
                                     }
                                 }
                                 else if (vkc == umba::periph::VirtualKeyCode::enter || vkc == umba::periph::VirtualKeyCode::ins )
                                 {
                                     if (repeatCout<2)
                                     {
                                         if (pwmCtrl==escPwmStandby)
                                             pwmCtrl = escPwmMin;
                                         else
                                             pwmCtrl = escPwmStandby;
                                     }
                                 }

                                 if (pwmCtrlPrev != pwmCtrl)
                                 {
                                     lout<<"Set PWM: "<<pwmCtrl<<" us"<<endl;
                                     umba::periph::traits::timerPwmControl( TIM16 , 1
                                                                          , pwmFreq, pwmPulseOutputMax
                                                                          , umba::periph::traits::TimerPwmControlType::microsecs
                                                                          , pwmCtrl
                                                                          );
                                 }

                             }

                             #endif /* IMPELLER_SIMPLE_UP_DOWN */

                             #else
                             if (vkc & umba::periph::VirtualKeyCode::virtualCodeFlag)
                                lout<<umba::periph::VirtualKeyCode::getKeyCodeName(vkc); //<<endl;
                             else
                                lout<<(char)(uint8_t)(vkc); //<<endl;
                             if (fPressed)
                                lout<<" pressed, count: "<<repeatCout<<endl;
                             else
                                lout<<" released"<<endl;
                             #endif

                         }
                    );

    umba::periph::legacy::UartTerminalKeyboard kbd = umba::periph::legacy::UartTerminalKeyboard( &kbdHandler, &uart::uart1 );


    unsigned n = 0;
    bool directionDown = false;

    uint32_t pwmCtrlDx = 3;

    #if !defined(KBD_TEST) && !defined(IMPELLER_SIMPLE_UP_DOWN)

        umba::periph::traits::timerPwmControl( TIM16 , 1
                                             , pwmFreq, pwmPulseOutputMax
                                             , umba::periph::traits::TimerPwmControlType::microsecs
                                             , pwmCtrl
                                             );

    #endif

    // https://www.st.com/resource/en/datasheet/stm32f303k8.pdf
    // https://www.st.com/en/microcontrollers-microprocessors/stm32f303c6.html

    while(true)
    {
         delayMs(20);

         /*
         if (bManualDbg)
         {
             bManualDbg = false;
             umba::periph::traits::timerPwmControl( TIM16 , 1
                                                  , pwmFreq, pwmPulseOutputMax
                                                  , umba::periph::traits::TimerPwmControlType::microsecs
                                                  , pwmCtrl
                                                  );
         }
         */

         #ifdef USE_PSENSOR 
         pSensor.poll();
         #endif

         bool brf1New = rangeFinder1_Pin;
         bool brf2New = rangeFinder2_Pin;
         bool brf3New = rangeFinder3_Pin;
         bool brf4New = rangeFinder4_Pin;

         if (brf1Prev!=brf1New)
         {
             lout<<"Knob #1 - "<<umba::time_service::getCurTimeMs()<<endl;
             brf1Prev = brf1New;
         }

         if (brf2Prev!=brf2New)
         {
             lout<<"Knob #2 - "<<umba::time_service::getCurTimeMs()<<endl;
             brf2Prev = brf2New;
         }

         if (brf3Prev!=brf3New)
         {
             lout<<"Knob #3 - "<<umba::time_service::getCurTimeMs()<<endl;
             brf3Prev = brf3New;
         }

         if (brf4Prev!=brf4New)
         {
             lout<<"Knob #4 - "<<umba::time_service::getCurTimeMs()<<endl;
             brf4Prev = brf4New;
         }


        // delayMs(250); lout<<"EHLO\n";
        
        #if defined(KBD_TEST) || !defined(IMPELLER_SIMPLE_UP_DOWN)

        kbd.scanKeyboard();

        #else

        umba::time_service::delayMs(25);
        //kbd.scanKeyboard();
        if (directionDown)
        {
            pwmCtrl -= pwmCtrlDx;
            if (pwmCtrl<escPwmMin)
            {
                directionDown = false;
            }
        }
        else
        {
            pwmCtrl += pwmCtrlDx;
            //if (pwmCtrl>10000) // 1/2 of 50Hz
            if (pwmCtrl>escPwmMax) // - ESC max
            {
                directionDown = true;
            }
        }

        umba::periph::traits::timerPwmControl( TIM16 , 1
                                             , pwmFreq, pwmPulseOutputMax
                                             , umba::periph::traits::TimerPwmControlType::microsecs
                                             , pwmCtrl
                                             );

        #endif
    }
}

//-----------------------------------------------------------------------------
void initTimer( uint32_t pwmFreq )
{
    using namespace umba::periph::traits;


    uint16_t prescalerT1 = 0;
    uint16_t periodT1    = 0;

    scalcus::calcTimerPwmPrescalerAndPeriod( SystemCoreClock, pwmFreq, prescalerT1, periodT1 );
    pwmPulseOutputMax = periodT1;

    umba::periph::traits::timerBaseInit( TIM16, prescalerT1, periodT1 ); 
    umba::periph::traits::timerInitChannelPwm( TIM16, 1, GPIOB, 8, (periodT1+1)/pwmFreq-1, TIM_OCMode_PWM2 );
    
    timerEnable( TIM16 );

    timerSetCaptureCompareRegister( TIM16, 1, 1 );
}
//-----------------------------------------------------------------------------
/*
extern "C" void assert_failed()
{}
*/
