#include <QCoreApplication>
#include <QUuid>
#include <QTextStream>
#include <QSerialPort>
#include <QTest>

#include <iostream>

#include "umba/umba.h"
#include "ihc/i_octet_stream.h"
#include "ihc/octet_stream_qserialport.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/parse_utils.h"

/*
    Как работает Голем - см. golem_test.cpp:
*/


//umba::NulCharWriter          charWritter;
umba::StdStreamCharWriter    charWritter(std::cout);
umba::SimpleFormatter  lout(&charWritter);

using namespace umba::omanip;


umba::SimpleFormatter& dump( const uint8_t *pData, size_t dataSize = 8 ) 
{
    for( size_t i = 0; i!=dataSize; ++i )
    {
        if (i)
           lout<<" ";
        lout<<noshowbase<<hex<<width(2)<<pData[i];
    }

    return lout;
}

umba::SimpleFormatter& dump( const char *pData, size_t dataSize = 8 ) 
{
    return dump( (const uint8_t *)pData, dataSize );
}


/* Контроллер голема может находится в следующих состояниях:
   1) Просто прием асинхронных данных
   2) Передача команды и прием эха и последующего ответа
*/

struct Golem
{
    typedef umba::ihc::StreamSize      StreamSize;
    typedef umba::ihc::StreamDiff      StreamDiff;
    typedef umba::ihc::StreamOctetType StreamOctetType;
    static const StreamSize StreamSizeNPos = umba::ihc::StreamSizeNPos;


    Golem(umba::ihc::IOctetIOStream *pStream)
    : m_pStream(pStream)
    {
    }

    void poll()
    {
        //m_pStream
        umba::ihc::streamReadHelper( m_pStream, [this](StreamOctetType o){ receiveOctet(o); } );
        checkClearEndSequence();
    }

    void checkClearEndSequence()
    {
         // each packet ends with line "* " - skip it
         if (recvCount==2 && recvBuf[0]==0x2A && recvBuf[1]==0x20)
         {
             recvCount = 0;
             m_receiveLineState = receiveLineStart;
         }
    }

    void receiveOctet( StreamOctetType o )
    {
        if (m_receiveLineState==receiveLineStart)
        {
             if (umba::parse_utils::isWhitespace( o ))
                 return;
             recvBuf[0] = o;
             recvCount  = 1;
             m_receiveLineState = receiveLineNext;
        }
        else
        {
            if ( o == 0x0D )
            {
                processRecvBuf();
                recvCount = 0;
                m_receiveLineState = receiveLineStart;
            }
            else
            {
                if (recvCount>=UMBA_COUNT_OF(recvBuf))
                {
                    return;
                }
                else
                {
                    recvBuf[recvCount++] = o;
                }
            }
        }
    }

    void processRecvBuf()
    {
        lout<<"Data received: ";
        dump(recvBuf, recvCount );
        lout<<endl;
    }


/*
GOLEM V1A
Commands:
C[<nn>]        - [Set] or read DU channel number, <nn>-number of channel
D<n>           - Display debug information, <n> - 0-off,1-Status,2-Status+Error
F[<xxxxxxxxxx>]- [Set] or read frequency of video transmitter,
                 <xxxxxxxxxx>-frequency in hertz (102000000..123000000)
I              - Display psramemers
K[<b>]         - [Set] or read camera keys, <b> 0-All keys release U-Up Press D-Down press
                 L-Left press R-Right press S-Set press
L<k3><k2><k1><k0> - Set scrambler key
M[<z>]         - [Set] or scrembler mode, <z> 0-off 1-on
P[<yyy>]       - [Set] or read power of video transmitter, <yyy>-power level (0..255)
R              - Reset
S              - Display status information
T              - Get volage and temperatures
V[<z>]         - [Set] or read video transmitter mode, <z> 0-off 1-on
W              - write settings in to flash memory
*
*/


// R reply and on start message
//GOLEM V1A (C) SET-1 2015-2018
//* Init SLAVE
//Channel00 [0]
//Calibrate [0]
//Start

//C00
//C01 [0]
//P100

// T
// Vinp= 4.962 V12=12.025 T=40

// V, V0, V1
// VideoTransmitter - ON
// VideoTransmitter - OFF

// F, FXXXXXXXXXXX
// F1230000000 - on simple query
// F1150000000 Hz - on set command

// S
// Disconnected


// I
// C00
// F1230000000
// P100
// VideoTransmitter - ON
// Scrambler - OFF

// L, LXXXX, M, M0, M1
// Scrambler - ON
// Scrambler - OFF



    void sendQuery( const StreamOctetType *pCmd, StreamSize cmdLen )
    {
        UMBA_ASSERT( (cmdLen+1) < UMBA_COUNT_OF(cmdBuf) ); // need additional space for 0x0D

        memcpy(cmdBuf, pCmd, cmdLen);
        cmdBuf[cmdLen] = 0x0D;
        sendCount = cmdLen;
        m_pStream->write( cmdBuf, sendCount+1);

        replyLineCount = 0;
    }

protected:

    enum State
    {
        read_async,
        read_reply
    };

    enum ReceiveLineState
    {
        receiveLineStart,
        receiveLineNext
    };

    umba::ihc::IOctetIOStream *m_pStream;

    StreamOctetType   recvBuf[32];
    StreamSize        recvCount = 0;
    ReceiveLineState  m_receiveLineState = receiveLineStart;

    StreamOctetType   cmdBuf[16];
    StreamSize        sendCount = 0;

    size_t            replyLineCount = 0;

}; // struct Golem




/*
umba::ihc::IOctetIOStream::StreamSize readReplyHelper( umba::ihc::IOctetIOStream *pStream
                                                     , umba::ihc::IOctetIOStream::StreamOctetType *pBuf
                                                     , umba::ihc::IOctetIOStream::StreamSize bufSize
                                                     )
{
    umba::ihc::IOctetIOStream::StreamSize readedTotal = 0;
    for(auto i = 0u; i!=10u; ++i)
    {
        QTest::qWait(10);
        auto octetsToRead = bufSize - readedTotal;
        if (!octetsToRead)
            break;
        umba::ihc::IOctetIOStream::StreamSize readed = pStream->read( &pBuf[readedTotal], octetsToRead );
        if (readed)
        {
            lout<<"Readed["<<i<<"]: ";
            dump( &pBuf[readedTotal], readed);
            lout<<endl;
        }

        readedTotal += readed;
    }

    return readedTotal;
}

umba::ihc::IOctetIOStream::StreamSize writeQeuryReadReplyHelper( umba::ihc::IOctetIOStream *pStream
                                                      , const char *queryStr
                                                      , umba::ihc::IOctetIOStream::StreamOctetType *pBuf
                                                      , umba::ihc::IOctetIOStream::StreamSize bufSize
                                                      )
{
    using namespace umba::ihc;
    StreamSize readedTotal = 0;
    StreamSize queryLen = (StreamSize)strlen(queryStr);

    lout<<"\n\n-------\nQuery string: ["<<queryStr<<"]"<<endl;

    for(StreamSize i = 0; i!=queryLen; ++i)
    {
        lout<<"Writting query octet: ";
        dump(&queryStr[i], 1);
        if (queryStr[i]>=' ' && queryStr[i]<128u)
            lout<<" - '"<<(char)queryStr[i]<<"'";
        lout<<endl;

        pStream->write( (StreamOctetType*)&queryStr[i], 1 );

        auto octetsToRead = bufSize - readedTotal;
        if (!octetsToRead)
        {
            lout<<error<<"No space for reply, breaking"<<endl;
            break;
        }
        readedTotal += readReplyHelper( pStream, &pBuf[readedTotal], octetsToRead );
    }

    return readedTotal;

}
*/


int main(int argc, char *argv[])
{
    std::cout << "At start of main"<<std::endl;
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("tenso-m");
    QCoreApplication::setApplicationVersion("1.0");

    // 19200, 1 stop, no parity
    // COM3

    std::cout << "Before lout" << std::endl;
    lout << "Starting"<<endl;
    std::cout << "After lout" << std::endl;

    // COM46/47
    std::string portName = "COM46";
    if (argc>1)
        portName = argv[1];

    lout << "Try to open port "<<portName<<endl;

    QSerialPort            qSerialPort;
    qSerialPort.setPortName( QString(portName.c_str())); 
    qSerialPort.setDataBits(QSerialPort::Data8);
    qSerialPort.setBaudRate(QSerialPort::Baud115200, QSerialPort::AllDirections);
    qSerialPort.setFlowControl(QSerialPort::NoFlowControl);
    qSerialPort.setParity(QSerialPort::NoParity);
    qSerialPort.setStopBits(QSerialPort::OneStop);
    qSerialPort.setReadBufferSize(1024);

    if (!qSerialPort.open(QIODevice::ReadWrite)
     )
    {
        lout<<error<<"Failed to open serial device '"<<portName<<"'\n";
        return 0;
    }

    umba::ihc::IOctetIOStreamImplQSerialPort iPort(qSerialPort);


    using namespace umba::ihc;

/*
    lout<<"Please turn on the Golem!!!"<<endl;
    StreamOctetType startMsgBuf[256];
    StreamSize startReaded = readReplyHelper( &iPort, startMsgBuf, 256 );
    while(!startReaded)
    {
        startReaded = readReplyHelper( &iPort, startMsgBuf, 256 );
    }

    lout<<"Full start dump  : ";
    dump(&startMsgBuf[0], startReaded );
    lout<<endl;

    lout<<"Full start string: ["<<(const char*)&startMsgBuf[0]<<"]"<<endl;
*/


    typedef const char* QueryType;

    QueryType queries[] = { "C"
                          , "C01"
                          , "C00"
                          , "R"
                          , "P"
                          , "P50"
                          , "P100"
                          , "T"
                          , "V"
                          , "V0"
                          , "V1"
                          , "F"
                          , "F1150000000"
                          , "F1230000000"
                          , "S"
                          , "I"

                          , "L"
                          , "L0123"
                          , "L0000"

                          , "M"
                          , "M1"
                          , "M0"

                          , "W"

                          //, ""
                          , 0
                          };

    Golem g(&iPort);

    for( auto i=0u; ; ++i)
    {
        QueryType q = queries[i];
        if (!q)
            break;

        lout<<"Query: ["<<q<<"]"<<endl;
        g.sendQuery( (const Golem::StreamOctetType *)q, strlen(q) );

        for(auto i = 0u; i!=50; ++i)
        {
            QTest::qWait(10);
            g.poll();
        }

        /*
        umba::ihc::IOctetIOStream::StreamOctetType rdBuf[256];
        auto readedTotal = writeQeuryReadReplyHelper( &iPort, q, rdBuf, 256u );
        auto numBytesToDump = readedTotal;
        if ((readedTotal+1) >= 256u)
        {
            lout<<warning<<"Tool large reply, size: "<<(unsigned)readedTotal<<normal<<endl;
            rdBuf[255] = 0;
            numBytesToDump = 255;
        }
        else
        {
            rdBuf[readedTotal] = 0;
        }

        lout<<"Full reply dump  : ";
        dump(&rdBuf[0], numBytesToDump);
        lout<<endl;

        lout<<"Full reply string: ["<<(const char*)&rdBuf[0]<<"]"<<endl;
        */
    }
    




    return 0;

}


