#include <QCoreApplication>
#include <QUuid>
#include <QTextStream>
#include <QSerialPort>
#include <QTest>

#include <iostream>

#include "umba/umba.h"
#include "ihc/i_octet_stream.h"
#include "ihc/octet_stream_qserialport.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/parse_utils.h"

#include "protocols/stream_protocol_impl_base.h"
#include "protocols/golem_protocol_impl_base.h"


/*
    Как работает Голем - см. golem_test.cpp:
*/


//umba::NulCharWriter          charWritter;
umba::StdStreamCharWriter    charWritter(std::cout);
umba::SimpleFormatter  lout(&charWritter);

using namespace umba::omanip;


umba::SimpleFormatter& dump( const uint8_t *pData, size_t dataSize = 8 ) 
{
    for( size_t i = 0; i!=dataSize; ++i )
    {
        if (i)
           lout<<" ";
        lout<<noshowbase<<hex<<width(2)<<pData[i];
    }

    return lout;
}

umba::SimpleFormatter& dump( const char *pData, size_t dataSize = 8 ) 
{
    return dump( (const uint8_t *)pData, dataSize );
}




struct GolemProtocol : public umba::protocols::IStreamProtocolImplBase< umba::protocols::IStreamProtocol >
{
    typedef umba::protocols::IStreamProtocolImplBase< umba::protocols::IStreamProtocol > BaseProtocol;


    virtual
    void poll() override
    {
        BaseProtocol::poll();
    }

    virtual
    bool isReadyForPoll() override
    {
        return true;
    }


private:

    virtual
    void onRawReceived( const StreamOctetType *pData, StreamSize dataSize ) override
    {
        // Затычка, можно не переопределять в наследниках, если протоколирование не нужно
        lout<<"Received raw: ";
        dump( pData, dataSize );
        lout<<" ("<<dataSize<<" octets)"<<endl;
    }
    
    //! Вызывается при отправке порции данных (перед), следует использовать для нужд логгирования.
    virtual
    void onRawSend( const StreamOctetType *pData, StreamSize dataSize ) override
    {
        lout<<"Sending raw: ";
        dump( pData, dataSize );
        lout<<endl;
    }

    virtual
    void handleParsedPacket( const BaseProtocol::StreamOctetType *pkt, BaseProtocol::StreamSize pktSize ) override
    //StreamOctetType parseGolemPacket( const BaseProtocol::StreamOctetType *pkt, BaseProtocol::StreamSize pktSize ) override
    {
        lout<<"Received: ";
        dump( pkt, pktSize );
        //lout<<endl;
        lout<<" - "<<std::string( (const char*)pkt, pktSize )<<endl;
        //return 0;
    }


}; // struct GolemProtocol




/* Контроллер голема может находится в следующих состояниях:
   1) Просто прием асинхронных данных
   2) Передача команды и прием эха и последующего ответа
*/


/*
GOLEM V1A
Commands:
C[<nn>]        - [Set] or read DU channel number, <nn>-number of channel
D<n>           - Display debug information, <n> - 0-off,1-Status,2-Status+Error
F[<xxxxxxxxxx>]- [Set] or read frequency of video transmitter,
                 <xxxxxxxxxx>-frequency in hertz (102000000..123000000)
I              - Display psramemers
K[<b>]         - [Set] or read camera keys, <b> 0-All keys release U-Up Press D-Down press
                 L-Left press R-Right press S-Set press
L<k3><k2><k1><k0> - Set scrambler key
M[<z>]         - [Set] or scrembler mode, <z> 0-off 1-on
P[<yyy>]       - [Set] or read power of video transmitter, <yyy>-power level (0..255)
R              - Reset
S              - Display status information
T              - Get volage and temperatures
V[<z>]         - [Set] or read video transmitter mode, <z> 0-off 1-on
W              - write settings in to flash memory
*
*/


// R reply and on start message
//GOLEM V1A (C) SET-1 2015-2018
//* Init SLAVE
//Channel00 [0]
//Calibrate [0]
//Start

//C00
//C01 [0]
//P100

// T
// Vinp= 4.962 V12=12.025 T=40

// V, V0, V1
// VideoTransmitter - ON
// VideoTransmitter - OFF

// F, FXXXXXXXXXXX
// F1230000000 - on simple query
// F1150000000 Hz - on set command

// S
// Disconnected


// I
// C00
// F1230000000
// P100
// VideoTransmitter - ON
// Scrambler - OFF

// L, LXXXX, M, M0, M1
// Scrambler - ON
// Scrambler - OFF






int main(int argc, char *argv[])
{
    std::cout << "At start of main"<<std::endl;
    QCoreApplication app(argc, argv);
    QCoreApplication::setApplicationName("tenso-m");
    QCoreApplication::setApplicationVersion("1.0");

    // 19200, 1 stop, no parity
    // COM3

    std::cout << "Before lout" << std::endl;
    lout << "Starting"<<endl;
    std::cout << "After lout" << std::endl;

    // COM46/47
    std::string portName = "COM46";
    if (argc>1)
        portName = argv[1];

    lout << "Try to open port "<<portName<<endl;

    QSerialPort            qSerialPort;
    qSerialPort.setPortName( QString(portName.c_str())); 
    qSerialPort.setDataBits(QSerialPort::Data8);
    qSerialPort.setBaudRate(QSerialPort::Baud115200, QSerialPort::AllDirections);
    qSerialPort.setFlowControl(QSerialPort::NoFlowControl);
    qSerialPort.setParity(QSerialPort::NoParity);
    qSerialPort.setStopBits(QSerialPort::OneStop);
    qSerialPort.setReadBufferSize(1024);

    if (!qSerialPort.open(QIODevice::ReadWrite)
     )
    {
        lout<<error<<"Failed to open serial device '"<<portName<<"'\n";
        return 0;
    }

    umba::ihc::IOctetIOStreamImplQSerialPort iPort(qSerialPort);


    //using namespace umba::ihc;

    umba::protocols::GolemPacketComposer<16> golemPacketComposer;
    umba::protocols::GolemPacketParser<32>   golemPacketParser;
    GolemProtocol golemProtocol;

    golemProtocol.setStream( &iPort );
    golemProtocol.setPacketComposer(&golemPacketComposer);
    golemProtocol.setPacketParser  (&golemPacketParser);


/*
    lout<<"Please turn on the Golem!!!"<<endl;
    StreamOctetType startMsgBuf[256];
    StreamSize startReaded = readReplyHelper( &iPort, startMsgBuf, 256 );
    while(!startReaded)
    {
        startReaded = readReplyHelper( &iPort, startMsgBuf, 256 );
    }

    lout<<"Full start dump  : ";
    dump(&startMsgBuf[0], startReaded );
    lout<<endl;

    lout<<"Full start string: ["<<(const char*)&startMsgBuf[0]<<"]"<<endl;
*/


    typedef const char* QueryType;

    QueryType queries[] = { "R"
                          , "C"
                          , "C01"
                          , "C00"
                          
                          , "P"
                          , "P50"
                          , "P100"
                          , "T"
                          , "V"
                          , "V0"
                          , "V1"
                          , "F"
                          , "F1150000000"
                          , "F1230000000"
                          , "S"
                          , "I"

                          , "L"
                          , "L0123"
                          , "L0000"

                          , "M"
                          , "M1"
                          , "M0"

                          , "W"

                          //, ""
                          , 0
                          };

    //Golem g(&iPort);

    for( auto i=0u; ; ++i)
    {
        QueryType q = queries[i];
        if (!q)
            break;

        lout<<"Query: ["<<q<<"]"<<endl;
        //g.sendQuery( (const Golem::StreamOctetType *)q, strlen(q) );
        golemProtocol.sendPacket( (const GolemProtocol::StreamOctetType *)q, strlen(q) );

        QTest::qWait(100);

        for(auto i = 0u; i!=50; ++i)
        {
            QTest::qWait(10);
            golemProtocol.poll();
        }

    }
    
    return 0;

}


