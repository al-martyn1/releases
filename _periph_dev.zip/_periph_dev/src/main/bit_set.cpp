#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"
#include "umba/bits.h"
#include "umba/bits_fmt.h"


#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>(uart::uart3).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  fmt(&charWritter);




int main(void)
{

    uint8_t buf[256] = { 0 };

    uart::uart3.init( uart::Pins::UART3_PB10_PB11, 460800 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 307200 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 691200 );


    using namespace umba::omanip;

    umba::bits::BitSet<uint8_t*, unsigned, unsigned> bitSet(buf, 100);
    //bitSet

    //unsigned bit = bitSet.getBit( (unsigned)3 );
    fmt<<"\nTest getBit"<<endl;
    for(unsigned i=0; i!=16; ++i)
        fmt<<"Bit "<<i<<": "<<bitSet.getBit( i )<<endl;

    fmt<<"\n                         "<<bitSet.getBinView( 8 )<<endl;
    
    bitSet.setBit( 2, 1 );
    fmt<<"\nTest setBit(2, true)   - "<<bitSet.getBinView( 8 )<<endl;

    bitSet.setBit( 12, 1 );
    fmt<<"Test setBit(12, true)  - "<<bitSet.getBinView( 8 )<<endl;

    bitSet.setBit( 12, 0 );
    fmt<<"Test setBit(12, false) - "<<bitSet.getBinView( 8 )<<endl;

    bitSet.setBit( 19, 1 );
    fmt<<"Test setBit(19, true)  - "<<bitSet.getBinView( 8 )<<endl;
    
/*

                         00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 0000
Test setBit(2, true)   - 00000100 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 0000
Test setBit(12, true)  - 00000100 00010000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 0000
Test setBit(12, false) - 00000100 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 0000
Test setBit(19, true)  - 00000100 00000000 00001000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 00000000 0000

*/

    while(1)
    {

    }

    return 0;
}



