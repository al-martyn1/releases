// main_board_master.PrjPcb - Generator: h_conf

// main_board_master.PrjPcb - Netlist_1

// MCU DD1 STM32F405RG peripherals

// BATTERY_RS485

#define BATTERY_RS485_UART                            UART5
#define BATTERY_RS485_LEGACY_UART                     uart::uart5
#define USE_UART5                                     1
#define BATTERY_RS485_UART_TX_GPIO                    GPIOC
#define BATTERY_RS485_UART_TX_GPIO_PIN_NO             12
#define BATTERY_RS485_UART_TX_GPIO_PIN_ADDR           UMBA_PINADDR_PC12
#define BATTERY_RS485_UART_TX_GPIO_PIN_SOURCE         GPIO_PinSource12
#define BATTERY_RS485_UART_TX_GPIO_PIN_DIRECTION      UMBA_GPIO_DIRECTION_OUT

#define BATTERY_RS485_UART_RX_GPIO                    GPIOD
#define BATTERY_RS485_UART_RX_GPIO_PIN_NO             2
#define BATTERY_RS485_UART_RX_GPIO_PIN_ADDR           UMBA_PINADDR_PD2
#define BATTERY_RS485_UART_RX_GPIO_PIN_SOURCE         GPIO_PinSource2
#define BATTERY_RS485_UART_RX_GPIO_PIN_DIRECTION      UMBA_GPIO_DIRECTION_IN

#define BATTERY_RS485_DE_GPIO                         GPIOB
#define BATTERY_RS485_DE_GPIO_PIN_NO                  5
#define BATTERY_RS485_DE_GPIO_PIN_ADDR                UMBA_PINADDR_PB5
#define BATTERY_RS485_DE_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PB5, UMBA_GPIO_DIRECTION_OUT
#define BATTERY_RS485_DE_GPIO_PIN_SOURCE              GPIO_PinSource5
#define BATTERY_RS485_DE_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT




// CANABUS_CAN

#define CANABUS_CAN_LOOPBACK_GPIO                     GPIOB
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_NO              11
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_ADDR            UMBA_PINADDR_PB11
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_ADDR_DIR        UMBA_PINADDR_PB11, UMBA_GPIO_DIRECTION_OUT
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_SOURCE          GPIO_PinSource11
#define CANABUS_CAN_LOOPBACK_GPIO_PIN_DIRECTION       UMBA_GPIO_DIRECTION_OUT

#define CANABUS_CAN                                   CAN2
#define USE_CAN2                                      1
#define CANABUS_CAN_RX_GPIO                           GPIOB
#define CANABUS_CAN_RX_GPIO_PIN_NO                    12
#define CANABUS_CAN_RX_GPIO_PIN_ADDR                  UMBA_PINADDR_PB12
#define CANABUS_CAN_RX_GPIO_PIN_SOURCE                GPIO_PinSource12
#define CANABUS_CAN_RX_GPIO_PIN_DIRECTION             UMBA_GPIO_DIRECTION_IN

#define CANABUS_CAN_TX_GPIO                           GPIOB
#define CANABUS_CAN_TX_GPIO_PIN_NO                    13
#define CANABUS_CAN_TX_GPIO_PIN_ADDR                  UMBA_PINADDR_PB13
#define CANABUS_CAN_TX_GPIO_PIN_SOURCE                GPIO_PinSource13
#define CANABUS_CAN_TX_GPIO_PIN_DIRECTION             UMBA_GPIO_DIRECTION_IN




// DEBUG_TERMINAL_UART

#define DEBUG_TERMINAL_UART                           UART6
#define DEBUG_TERMINAL_LEGACY_UART                    uart::uart6
#define USE_UART6                                     1
#define DEBUG_TERMINAL_UART_TX_GPIO                   GPIOC
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO            6
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_ADDR          UMBA_PINADDR_PC6
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_SOURCE        GPIO_PinSource6
#define DEBUG_TERMINAL_UART_TX_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_OUT

#define DEBUG_TERMINAL_UART_RX_GPIO                   GPIOC
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO            7
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_ADDR          UMBA_PINADDR_PC7
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_SOURCE        GPIO_PinSource7
#define DEBUG_TERMINAL_UART_RX_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_IN




// GOLEM_DATA_UART

#define GOLEM_DATA_UART                               UART4
#define GOLEM_DATA_LEGACY_UART                        uart::uart4
#define USE_UART4                                     1
#define GOLEM_DATA_UART_TX_GPIO                       GPIOA
#define GOLEM_DATA_UART_TX_GPIO_PIN_NO                0
#define GOLEM_DATA_UART_TX_GPIO_PIN_ADDR              UMBA_PINADDR_PA0
#define GOLEM_DATA_UART_TX_GPIO_PIN_SOURCE            GPIO_PinSource0
#define GOLEM_DATA_UART_TX_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT

#define GOLEM_DATA_UART_RX_GPIO                       GPIOA
#define GOLEM_DATA_UART_RX_GPIO_PIN_NO                1
#define GOLEM_DATA_UART_RX_GPIO_PIN_ADDR              UMBA_PINADDR_PA1
#define GOLEM_DATA_UART_RX_GPIO_PIN_SOURCE            GPIO_PinSource1
#define GOLEM_DATA_UART_RX_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_IN




// GOLEM_TERMINAL_UART

#define GOLEM_TERMINAL_UART                           UART2
#define GOLEM_TERMINAL_LEGACY_UART                    uart::uart2
#define USE_UART2                                     1
#define GOLEM_TERMINAL_UART_TX_GPIO                   GPIOA
#define GOLEM_TERMINAL_UART_TX_GPIO_PIN_NO            2
#define GOLEM_TERMINAL_UART_TX_GPIO_PIN_ADDR          UMBA_PINADDR_PA2
#define GOLEM_TERMINAL_UART_TX_GPIO_PIN_SOURCE        GPIO_PinSource2
#define GOLEM_TERMINAL_UART_TX_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_OUT

#define GOLEM_TERMINAL_UART_RX_GPIO                   GPIOA
#define GOLEM_TERMINAL_UART_RX_GPIO_PIN_NO            3
#define GOLEM_TERMINAL_UART_RX_GPIO_PIN_ADDR          UMBA_PINADDR_PA3
#define GOLEM_TERMINAL_UART_RX_GPIO_PIN_SOURCE        GPIO_PinSource3
#define GOLEM_TERMINAL_UART_RX_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_IN




// GYRO

#define GYRO_CS_XM_GPIO                               GPIOB
#define GYRO_CS_XM_GPIO_PIN_NO                        0
#define GYRO_CS_XM_GPIO_PIN_ADDR                      UMBA_PINADDR_PB0
#define GYRO_CS_XM_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB0, UMBA_GPIO_DIRECTION_OUT
#define GYRO_CS_XM_GPIO_PIN_SOURCE                    GPIO_PinSource0
#define GYRO_CS_XM_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define GYRO_CS_G_GPIO                                GPIOB
#define GYRO_CS_G_GPIO_PIN_NO                         1
#define GYRO_CS_G_GPIO_PIN_ADDR                       UMBA_PINADDR_PB1
#define GYRO_CS_G_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB1, UMBA_GPIO_DIRECTION_OUT
#define GYRO_CS_G_GPIO_PIN_SOURCE                     GPIO_PinSource1
#define GYRO_CS_G_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define GYRO_SPI                                      SPI2
#define USE_SPI2                                      1
#define GYRO_SPI_SCK_GPIO                             GPIOB
#define GYRO_SPI_SCK_GPIO_PIN_NO                      10
#define GYRO_SPI_SCK_GPIO_PIN_ADDR                    UMBA_PINADDR_PB10
#define GYRO_SPI_SCK_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PB10, UMBA_GPIO_DIRECTION_OUT
#define GYRO_SPI_SCK_GPIO_PIN_SOURCE                  GPIO_PinSource10
#define GYRO_SPI_SCK_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define GYRO_SPI_MISO_GPIO                            GPIOB
#define GYRO_SPI_MISO_GPIO_PIN_NO                     14
#define GYRO_SPI_MISO_GPIO_PIN_ADDR                   UMBA_PINADDR_PB14
#define GYRO_SPI_MISO_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PB14, UMBA_GPIO_DIRECTION_IN
#define GYRO_SPI_MISO_GPIO_PIN_SOURCE                 GPIO_PinSource14
#define GYRO_SPI_MISO_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN

#define GYRO_SPI_MOSI_GPIO                            GPIOB
#define GYRO_SPI_MOSI_GPIO_PIN_NO                     15
#define GYRO_SPI_MOSI_GPIO_PIN_ADDR                   UMBA_PINADDR_PB15
#define GYRO_SPI_MOSI_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PB15, UMBA_GPIO_DIRECTION_OUT
#define GYRO_SPI_MOSI_GPIO_PIN_SOURCE                 GPIO_PinSource15
#define GYRO_SPI_MOSI_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT




// MUX

#define MUX_EN_GPIO                                   GPIOC
#define MUX_EN_GPIO_PIN_NO                            1
#define MUX_EN_GPIO_PIN_ADDR                          UMBA_PINADDR_PC1
#define MUX_EN_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PC1, UMBA_GPIO_DIRECTION_OUT
#define MUX_EN_GPIO_PIN_SOURCE                        GPIO_PinSource1
#define MUX_EN_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define MUX_A0_GPIO                                   GPIOC
#define MUX_A0_GPIO_PIN_NO                            2
#define MUX_A0_GPIO_PIN_ADDR                          UMBA_PINADDR_PC2
#define MUX_A0_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PC2, UMBA_GPIO_DIRECTION_OUT
#define MUX_A0_GPIO_PIN_SOURCE                        GPIO_PinSource2
#define MUX_A0_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define MUX_A1_GPIO                                   GPIOC
#define MUX_A1_GPIO_PIN_NO                            3
#define MUX_A1_GPIO_PIN_ADDR                          UMBA_PINADDR_PC3
#define MUX_A1_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PC3, UMBA_GPIO_DIRECTION_OUT
#define MUX_A1_GPIO_PIN_SOURCE                        GPIO_PinSource3
#define MUX_A1_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT




// PSENSOR

#define PSENSOR_I2C                                   I2C3
#define USE_I2C3                                      1
#define PSENSOR_I2C_SDA_GPIO                          GPIOC
#define PSENSOR_I2C_SDA_GPIO_PIN_NO                   9
#define PSENSOR_I2C_SDA_GPIO_PIN_ADDR                 UMBA_PINADDR_PC9
#define PSENSOR_I2C_SDA_GPIO_PIN_SOURCE               GPIO_PinSource9

#define PSENSOR_I2C_SCL_GPIO                          GPIOA
#define PSENSOR_I2C_SCL_GPIO_PIN_NO                   8
#define PSENSOR_I2C_SCL_GPIO_PIN_ADDR                 UMBA_PINADDR_PA8
#define PSENSOR_I2C_SCL_GPIO_PIN_SOURCE               GPIO_PinSource8




// Unclassified

#define VIDEO1_FRONT_CAM_EN_GPIO                      GPIOB
#define VIDEO1_FRONT_CAM_EN_GPIO_PIN_NO               7
#define VIDEO1_FRONT_CAM_EN_GPIO_PIN_ADDR             UMBA_PINADDR_PB7
#define VIDEO1_FRONT_CAM_EN_GPIO_PIN_ADDR_DIR         UMBA_PINADDR_PB7, UMBA_GPIO_DIRECTION_OUT
#define VIDEO1_FRONT_CAM_EN_GPIO_PIN_SOURCE           GPIO_PinSource7
#define VIDEO1_FRONT_CAM_EN_GPIO_PIN_DIRECTION        UMBA_GPIO_DIRECTION_OUT

#define VIDEO2_HOTEND_CAM_EN_GPIO                     GPIOB
#define VIDEO2_HOTEND_CAM_EN_GPIO_PIN_NO              8
#define VIDEO2_HOTEND_CAM_EN_GPIO_PIN_ADDR            UMBA_PINADDR_PB8
#define VIDEO2_HOTEND_CAM_EN_GPIO_PIN_ADDR_DIR        UMBA_PINADDR_PB8, UMBA_GPIO_DIRECTION_OUT
#define VIDEO2_HOTEND_CAM_EN_GPIO_PIN_SOURCE          GPIO_PinSource8
#define VIDEO2_HOTEND_CAM_EN_GPIO_PIN_DIRECTION       UMBA_GPIO_DIRECTION_OUT

#define VIDEO3_TVKO_CAM_EN_GPIO                       GPIOB
#define VIDEO3_TVKO_CAM_EN_GPIO_PIN_NO                6
#define VIDEO3_TVKO_CAM_EN_GPIO_PIN_ADDR              UMBA_PINADDR_PB6
#define VIDEO3_TVKO_CAM_EN_GPIO_PIN_ADDR_DIR          UMBA_PINADDR_PB6, UMBA_GPIO_DIRECTION_OUT
#define VIDEO3_TVKO_CAM_EN_GPIO_PIN_SOURCE            GPIO_PinSource6
#define VIDEO3_TVKO_CAM_EN_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT

#define VIDEO4_BACK_CAM_EN_GPIO                       GPIOB
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_NO                9
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_ADDR              UMBA_PINADDR_PB9
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_ADDR_DIR          UMBA_PINADDR_PB9, UMBA_GPIO_DIRECTION_OUT
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_SOURCE            GPIO_PinSource9
#define VIDEO4_BACK_CAM_EN_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT

#define POWER_5V_EN_GPIO                              GPIOA
#define POWER_5V_EN_GPIO_PIN_NO                       4
#define POWER_5V_EN_GPIO_PIN_ADDR                     UMBA_PINADDR_PA4
#define POWER_5V_EN_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PA4, UMBA_GPIO_DIRECTION_OUT
#define POWER_5V_EN_GPIO_PIN_SOURCE                   GPIO_PinSource4
#define POWER_5V_EN_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_OUT

#define ESC_PWM_GPIO                                  GPIOA
#define ESC_PWM_GPIO_PIN_NO                           9
#define ESC_PWM_GPIO_PIN_ADDR                         UMBA_PINADDR_PA9
#define ESC_PWM_GPIO_PIN_SOURCE                       GPIO_PinSource9
#define ESC_PWM_TIM_CHANNEL                           TIM_Channel_2
#define ESC_PWM_TIM_CHANNEL_NO                        2
#define ESC_PWM_TIM                                   TIM1
#define USE_TIM1                                      1

#define BATTERY_PRESENT_FLAG_GPIO                     GPIOC
#define BATTERY_PRESENT_FLAG_GPIO_PIN_NO              11
#define BATTERY_PRESENT_FLAG_GPIO_PIN_ADDR            UMBA_PINADDR_PC11
#define BATTERY_PRESENT_FLAG_GPIO_PIN_ADDR_DIR        UMBA_PINADDR_PC11, UMBA_GPIO_DIRECTION_IN
#define BATTERY_PRESENT_FLAG_GPIO_PIN_SOURCE          GPIO_PinSource11
#define BATTERY_PRESENT_FLAG_GPIO_PIN_DIRECTION       UMBA_GPIO_DIRECTION_IN

#define LED_ERROR_GPIO                                GPIOA
#define LED_ERROR_GPIO_PIN_NO                         5
#define LED_ERROR_GPIO_PIN_ADDR                       UMBA_PINADDR_PA5
#define LED_ERROR_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PA5, UMBA_GPIO_DIRECTION_OUT
#define LED_ERROR_GPIO_PIN_SOURCE                     GPIO_PinSource5
#define LED_ERROR_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define LED_LINK_GPIO                                 GPIOA
#define LED_LINK_GPIO_PIN_NO                          6
#define LED_LINK_GPIO_PIN_ADDR                        UMBA_PINADDR_PA6
#define LED_LINK_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PA6, UMBA_GPIO_DIRECTION_OUT
#define LED_LINK_GPIO_PIN_SOURCE                      GPIO_PinSource6
#define LED_LINK_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define VIDEO1_FRONT_CAM_PWR_EN_GPIO                  GPIOC
#define VIDEO1_FRONT_CAM_PWR_EN_GPIO_PIN_NO           13
#define VIDEO1_FRONT_CAM_PWR_EN_GPIO_PIN_ADDR         UMBA_PINADDR_PC13
#define VIDEO1_FRONT_CAM_PWR_EN_GPIO_PIN_ADDR_DIR     UMBA_PINADDR_PC13, UMBA_GPIO_DIRECTION_OUT
#define VIDEO1_FRONT_CAM_PWR_EN_GPIO_PIN_SOURCE       GPIO_PinSource13
#define VIDEO1_FRONT_CAM_PWR_EN_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_OUT

#define VIDEO4_BACK_CAM_PWR_EN_GPIO                   GPIOC
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_NO            15
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_ADDR          UMBA_PINADDR_PC15
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_ADDR_DIR      UMBA_PINADDR_PC15, UMBA_GPIO_DIRECTION_OUT
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_SOURCE        GPIO_PinSource15
#define VIDEO4_BACK_CAM_PWR_EN_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_OUT

#define VIDEO2_HOTEND_CAM_PWR_EN_GPIO                 GPIOC
#define VIDEO2_HOTEND_CAM_PWR_EN_GPIO_PIN_NO          14
#define VIDEO2_HOTEND_CAM_PWR_EN_GPIO_PIN_ADDR        UMBA_PINADDR_PC14
#define VIDEO2_HOTEND_CAM_PWR_EN_GPIO_PIN_ADDR_DIR    UMBA_PINADDR_PC14, UMBA_GPIO_DIRECTION_OUT
#define VIDEO2_HOTEND_CAM_PWR_EN_GPIO_PIN_SOURCE      GPIO_PinSource14
#define VIDEO2_HOTEND_CAM_PWR_EN_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_OUT




