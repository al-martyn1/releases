#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"


#if !defined(STM32F4_SERIES)
    #error "STM32F4_SERIES not defined"
#endif

#include "periph/stm32_traits.h"
#include "vtx2_config.h"

#include "scalcus/pwm.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "psensor.h"






#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  lout(&charWritter);




#define CON_UART DEBUG_TERMINAL_LEGACY_UART

//#define KBD_TEST

//#define IMPELLER_SIMPLE_UP_DOWN




uint32_t escPwmStandby =  800;
uint32_t escPwmDelta   =    5;
uint32_t escPwmMin     =  escPwmStandby + escPwmDelta;
uint32_t escPwmMax     = 2300;

static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;


void initTimer( uint32_t pwmFreq );


uint32_t pwmCtrl = escPwmStandby; // mode - microsec

void printState();

I2cPort i2c;


auto psensorHandler = [&](bool fLinkGood, HoneywellPressureSensorState sensorState, float val)
                      {
                          //lout<<"Val: "<<val<<"\n";
                          printState();
                      };

auto pSensor = HoneywellPressureSensor< decltype(psensorHandler) >( i2c
                                      , umba::periph::dirty::I2cInitializer( PSENSOR_I2C, 100000, 0x15 // self addr - от балды
                                                                           , PSENSOR_I2C_SCL_GPIO, PSENSOR_I2C_SCL_GPIO_PIN_NO
                                                                           , PSENSOR_I2C_SDA_GPIO, PSENSOR_I2C_SDA_GPIO_PIN_NO
                                                                           )
                                      , 0x28 // deviceBusAddr
                                      , psensorHandler
                                      );




unsigned pwmPulseOutputMax = 0;

int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;

    uint32_t pwmFreq = 50; // Hz


    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );

    umba::time_service::delayMs(300);


    initTimer(pwmFreq);


    pSensor.init();

    using namespace umba::omanip;




    lout<<feed<<"Starting\n";


    auto kbdHandler = umba::periph::makeKeyboardHandler
                    ( 
                         [&]( unsigned vkc, bool fPressed, size_t repeatCout )
                         {
                             using namespace umba::omanip;

                             #ifndef KBD_TEST

                             #ifndef IMPELLER_SIMPLE_UP_DOWN
                             if (fPressed)
                             {
                                 uint32_t pwmCtrlPrev = pwmCtrl;
                                 if (vkc == umba::periph::VirtualKeyCode::up || vkc == umba::periph::VirtualKeyCode::pageUp )
                                 {
                                     if (pwmCtrl!=escPwmStandby)
                                     {
                                         pwmCtrl += escPwmDelta * ( vkc == umba::periph::VirtualKeyCode::up ? 1 : 5 );
                                         if (pwmCtrl>escPwmMax)
                                             pwmCtrl = escPwmMax;
                                     }
                                 }
                                 else if (vkc == umba::periph::VirtualKeyCode::down || vkc == umba::periph::VirtualKeyCode::pageDown )
                                 {
                                     if (pwmCtrl!=escPwmStandby)
                                     {
                                         pwmCtrl -= escPwmDelta * ( vkc == umba::periph::VirtualKeyCode::down ? 1 : 5 );
                                         if (pwmCtrl<escPwmMin)
                                             pwmCtrl = escPwmMin;
                                     }
                                 }
                                 else if (vkc == umba::periph::VirtualKeyCode::enter || vkc == umba::periph::VirtualKeyCode::ins )
                                 {
                                     if (repeatCout<2)
                                     {
                                         if (pwmCtrl==escPwmStandby)
                                             pwmCtrl = escPwmMin;
                                         else
                                             pwmCtrl = escPwmStandby;
                                     }
                                 }

                                 if (pwmCtrlPrev != pwmCtrl)
                                 {
                                     printState();
                                     /*
                                     lout<<"Set PWM: "<<pwmCtrl<<" us"<<endl;
                                     */
                                     umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                                                          , pwmFreq, pwmPulseOutputMax
                                                                          , umba::periph::traits::TimerPwmControlType::microsecs
                                                                          , pwmCtrl
                                                                          );
                                 }

                             }

                             #endif /* IMPELLER_SIMPLE_UP_DOWN */

                             #else
                             if (vkc & umba::periph::VirtualKeyCode::virtualCodeFlag)
                                lout<<umba::periph::VirtualKeyCode::getKeyCodeName(vkc); //<<endl;
                             else
                                lout<<(char)(uint8_t)(vkc); //<<endl;
                             if (fPressed)
                                lout<<" pressed, count: "<<repeatCout<<endl;
                             else
                                lout<<" released"<<endl;
                             #endif

                         }
                    );

    umba::periph::legacy::UartTerminalKeyboard kbd = umba::periph::legacy::UartTerminalKeyboard( &kbdHandler, & CON_UART);


    unsigned n = 0;
    bool directionDown = false;

    uint32_t pwmCtrlDx = 3;

    #if !defined(KBD_TEST) && !defined(IMPELLER_SIMPLE_UP_DOWN)

        umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                             , pwmFreq, pwmPulseOutputMax
                                             , umba::periph::traits::TimerPwmControlType::microsecs
                                             , pwmCtrl
                                             );

    #endif

    lout<<"Started\n\n";

    while(1)
    {

        pSensor.poll();

        #if defined(KBD_TEST) || !defined(IMPELLER_SIMPLE_UP_DOWN)

        kbd.scanKeyboard();

        #else

        umba::time_service::delayMs(25);
        //kbd.scanKeyboard();
        if (directionDown)
        {
            pwmCtrl -= pwmCtrlDx;
            if (pwmCtrl<escPwmMin)
            {
                directionDown = false;
            }
        }
        else
        {
            pwmCtrl += pwmCtrlDx;
            //if (pwmCtrl>10000) // 1/2 of 50Hz
            if (pwmCtrl>escPwmMax) // - ESC max
            {
                directionDown = true;
            }
        }

        umba::periph::traits::timerPwmControl( ESC_PWM_TIM , ESC_PWM_TIM_CHANNEL_NO
                                             , pwmFreq, pwmPulseOutputMax
                                             , umba::periph::traits::TimerPwmControlType::microsecs
                                             , pwmCtrl
                                             );

        #endif
    }

    return 0;
}

//-----------------------------------------------------------------------------
void initTimer( uint32_t pwmFreq )
{
    using namespace umba::periph::traits;


    uint16_t prescalerT1 = 0;
    uint16_t periodT1    = 0;

    scalcus::calcTimerPwmPrescalerAndPeriod( SystemCoreClock, pwmFreq, prescalerT1, periodT1 );
    pwmPulseOutputMax = periodT1;

    umba::periph::traits::timerBaseInit( ESC_PWM_TIM, prescalerT1, periodT1 ); 
    umba::periph::traits::timerInitChannelPwm( ESC_PWM_TIM, ESC_PWM_TIM_CHANNEL_NO, ESC_PWM_GPIO, ESC_PWM_GPIO_PIN_NO, (periodT1+1)/pwmFreq-1, TIM_OCMode_PWM2 );
    
    timerEnable( ESC_PWM_TIM );

    timerSetCaptureCompareRegister( ESC_PWM_TIM, ESC_PWM_TIM_CHANNEL_NO, 1 );


}

//-----------------------------------------------------------------------------
void printState()
{
    using namespace umba::omanip;
    lout<<cret<<"Pressure: " <<width(8) <<pSensor.getValue()
        <<"   Sensor link: " <<width(4) <<(pSensor.getLinkGood() ? "link" : "fail")
        <<"   Sensor state: "<<width(12)<<pSensor.getSensorStateStr()
        <<" "                <<width(6) <<(pSensor.isSensorStateGood() ? "(ok)" : "(fail)");

    lout<<"    "
        <<"Impeller :"<<pwmCtrl<<" ms";

}



