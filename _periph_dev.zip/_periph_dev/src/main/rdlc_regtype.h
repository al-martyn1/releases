#pragma once


#define RDLC_REGTYPE_FLOAT       -1
#define RDLC_REGTYPE_UNSIGNED     0
#define RDLC_REGTYPE_INT          1
