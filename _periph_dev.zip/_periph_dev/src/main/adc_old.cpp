#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "periph/gpio.h"
#include "periph/power.h"

#include "hot_end_dbg_uart_conf.h"


umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::SimpleFormatter  lout(&charWritter);



#define USE_COOL_ADC

void ADC_Injected_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStructure;
 
    RCC_ADCCLKConfig (RCC_PCLK2_Div6);
    /* Enable ADC1 and GPIOA clock */
    RCC_APB2PeriphClockCmd ( RCC_APB2Periph_GPIOA | RCC_APB2Periph_ADC1 ,   ENABLE ) ;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
 
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_NbrOfChannel = 1; //2;
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;
    ADC_Init(ADC1, &ADC_InitStructure);
 
    ADC_InjectedSequencerLengthConfig(ADC1, 2);
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_7Cycles5);
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_7Cycles5);
 
    ADC_ExternalTrigInjectedConvConfig( ADC1, ADC_ExternalTrigInjecConv_None );
 
    ADC_Cmd ( ADC1 , ENABLE ) ;
 
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));
 
    ADC_AutoInjectedConvCmd( ADC1, ENABLE );
    ADC_SoftwareStartInjectedConvCmd ( ADC1 , ENABLE ) ;
}

int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    using namespace umba::time_service;
    using namespace umba::omanip;


    //umba::periph::GpioPin adcPin( PA1, umba::periph::PinMode::gpio_in_floating ); // analog_in
    //adcPin.connect();

// AdcInjected adcInitInject( ADC_TypeDef* ADCx, AdcSamplingSpeed samplingSpeed, SomeStructuredTypeListItems... structs)

    #ifdef USE_COOL_ADC
        auto 
        //umba::periph::traits::AdcInjected 
        adc1 = umba::periph::traits::adcInitInject( ADC1, umba::periph::traits::AdcSamplingSpeed::high, false, PA1 );
    #endif

    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );

    delayMs(300);

    #ifndef USE_COOL_ADC
        #ifdef STM32F1_SERIES
            ADC_Injected_init();
        #endif
    #endif
    lout<<"Starting"<<endl;

    unsigned cnt = 0;

    unsigned prevVal = 0;

    while(1)
    {

        //lout<<"Loop: "<<cnt<<", pin: "<<adcPin<<endl;
        //lout<<"Pin: "<<adcPin<<endl;

        #ifdef USE_COOL_ADC
        
            unsigned newVal = adc1[0];
            if (newVal!=prevVal)
               lout<<"ADC[0]: "<< newVal <<endl;
            prevVal = newVal;

        #else

            #ifdef STM32F1_SERIES

                unsigned ADC_value0 = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
                unsigned ADC_value1 = ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_2);
               
                lout<<"ADC_value0: "<<ADC_value0<<endl;
                lout<<"ADC_value1: "<<ADC_value1<<endl;

            #endif

        #endif
        
        delayMs(100);
        cnt++;

    }

    return 0;

}



