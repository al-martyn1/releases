#include "vgpio/i_virtual_gpio.h"
#include "vgpio/stm32_gpio.h"
#include "vgpio/virtual_gpio.h"
#include "umba/time_service.h"


namespace vgpio     = umba::virtual_gpio;
namespace stm32gpio = umba::stm32_gpio;


const vgpio::PinType ledPhisPin = vgpio::pin_12;

stm32gpio::Stm32IoPort ledPhisPort( vgpio::Port::C
                              , vgpio::PinSpeed::slow
                              , vgpio::PinDirection::output
                              , vgpio::PinPushPullMode::pushPull
                              , ledPhisPin
                              );

//umba::virtual_gpio::
umba::virtual_gpio::VirtualOutputPin virtualPins[] = { { &ledPhisPort, ledPhisPin }
                                                     , { 0, 0 }
                                                     };

umba::virtual_gpio::VirtualOutputPort ledPort( &virtualPins[0] );


int main(void)
{
    umba::time_service::init();
    umba::time_service::start();

    ledPhisPort.initPort();
    ledPort.initPort();

    while(1)
    {
        umba::time_service::delayMs(1000);
        ledPort.toggleOutput( ledPort.getPins() );

    }

    return 0;
}
