#pragma once

/*
    Тест SPI

    16 регистров

    0x00-0x0D - RW, что записали, то и прочитали
    0x0E      - RO, регистр статуса - младший бит - состояние кнопки
    0x0F      - RO, регистр WHO_AM_I, там всегда SPI_WHO_AM_I_ID

    Мастер записывает циклический код во все регистры, кроме RO, затем считывает и сравнивает

    Также считывает статус и ID, если кнопка изменила своё значение: 
    а) выводим сообщение о новом состоянии
    б) инкрементируем номер светодиода и отсылаем его по SPI

    Слейва сделаем на F3 Discovery - там много светодиодов, и мастер может ими управлять по SPI


    Что получилось

    Master             Slave
    F303VC/72МГц       F407VG/168МГц      - работает четко, проблем нет
    F100КИ/48МГц       F407VG/168МГц      - Сначала было похоже, что как-то работает, но через жопу.
                                            Укоротил в несколько раз MISO - стало почти хорошо.
                                            Наверно нужно укоротить и остальные линии (как минимум, MOSi - SCK нормально дергался),
                                            чтобы стало сосвсем четко, но лень.
    F100КИ/48МГц       F303VC/72МГц       - Сначала думал - slave пытается как-то отвечать, но, похоже
                                            не хватает быстродействия.
                                            Но получив такие же результаты с F407VG и найдя причину там,
                                            думаю, тут была аналогичная проблема.
    F407VG/168МГц      F303VC/72МГц       - тут тоже плохо работало с теми же симптомами, что и предыдущие варианты

    F303VC/72МГц       F303VC/72МГц       - похоже, не успевает. Частота SPI - минимальная - 93.4КГц, на сотке - такая же.

    Итого, slave'ом для сложного протокола нормально работает только F4/168МГц


    F1 - 9.1.11 GPIO configurations for device peripherals


    http://dimoon.ru/obuchalka/stm32f1/programmirovanie-stm32-chast-6-spi.html

    Немного про слейва - https://learnbuildshare.wordpress.com/about/stm32/using-spi-as-slave/
       http://www.mcu.by/%D1%81%D1%82%D0%B0%D1%80%D1%82-arm-spi-master-spi-slave-%D1%87%D0%B0%D1%81%D1%82%D1%8C-2/

    Прерывания GPIO

    http://narodstream.ru/stm-urok-74-hal-exti-ili-vneshnie-preryvaniya/
    https://electronics.stackexchange.com/questions/353907/how-to-add-external-gpio-interrupts-on-stm32
    https://stackoverflow.com/questions/40057581/stm32f3-discovery-implement-gpio-interrupt

    https://stm32f4-discovery.net/2014/08/stm32f4-external-interrupts-tutorial/

    device has 16 external interrupt or event sources for GPIO
    for external pins (P0 to P15) on each port

    In section one (GPIOs) we have 16 interrupt lines. They are line0 to line15 and 
    they also represent pin number. This means, PA0 is connected to Line0 and PA13 is connected to Line13.

    You have to know that PB0 is also connected to Line0 and PC0 also and so on. 
    This is for all pins on board, All Px0 (where x is GPIO name) pins are connected 
    to Line0 and let’s say all Px3 are connected to Line3 on the Interrupt channel.


    F3/F4/L1 RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);


    http://www.count-zero.ru/2016/stm32_gpio/

    EXTI_TypeDef


EXTI0_IRQHandler
EXTI1_IRQHandler
EXTI2_IRQHandler
EXTI3_IRQHandler
EXTI4_IRQHandler
EXTI9_5_IRQHandler
EXTI15_10_IRQHandler

*/


#define SPI_NUMBER_OF_REG         0x10u

#define SPI_NUMBER_OF_DUMMY_REG   ((SPI_NUMBER_OF_REG) - 3) /* CTRL_LEDS, STATUS, WHO_AM_I are not dummy regs */



#define SPI_REG_CTRL_LEDS         0x0Du
#define SPI_REG_STATUS            0x0Eu
#define SPI_REG_WHO_AM_I          0x0Fu
                                 
#define SPI_WHO_AM_I_ID           0xA5u
                                 
#define SPI_STATUS_BTN1           0x01u


#define SPI_REG_IS_RW( regNo ) (((regNo) >= SPI_REG_STATUS) ? 0 : 1)
//#define SPI_REG_IS_RW( regNo ) (((regNo) == SPI_REG_CTRL_LEDS) ? 0 : 1)

#define SPI_MS_TEST_CMD_READ    0x8000u
#define SPI_MS_TEST_CMD_WRITE   0x0000u


// Master/Slave Test SPI

#define MS_TEST_SPI                           SPI2
#define MS_TEST_SPI_SCK_GPIO_PIN_ADDR         PB13
#define MS_TEST_SPI_MISO_GPIO_PIN_ADDR        PB14
#define MS_TEST_SPI_MOSI_GPIO_PIN_ADDR        PB15

#if defined(STM32F1_SERIES)

    #define MS_TEST_SPI_CS_GPIO_PIN_ADDR      PB11

#elif defined(STM32F3_SERIES) 

    #define MS_TEST_SPI_CS_GPIO_PIN_ADDR      PD11

#elif defined(STM32F4_SERIES)

    #define MS_TEST_SPI_CS_GPIO_PIN_ADDR      PD11

#endif

#define MS_TEST_SPI_CS_GPIO_PIN_ADDR_DIR      MS_TEST_SPI_CS_GPIO_PIN_ADDR, UMBA_GPIO_DIRECTION_OUT


#define MS_TEST_SPI_MASTER_MODE_SELECT_PIN_ADDR    UMBA_PINADDR_PA1


#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )



// shift numeration - skip non-controlled LEDs (PWR/COMM)

DECLARE_PIN( led1_Pin , STM32_DISCOVERY_LD3 );
DECLARE_PIN( led2_Pin , STM32_DISCOVERY_LD4 );

#if STM32_DISCOVERY_NUM_LEDS > 2
    DECLARE_PIN( led3_Pin , STM32_DISCOVERY_LD5 );
#endif

#if STM32_DISCOVERY_NUM_LEDS > 3
    DECLARE_PIN( led4_Pin , STM32_DISCOVERY_LD6 );
#endif

#if STM32_DISCOVERY_NUM_LEDS > 4
    DECLARE_PIN( led5_Pin , STM32_DISCOVERY_LD7 );
#endif

#if STM32_DISCOVERY_NUM_LEDS > 5
    DECLARE_PIN( led6_Pin , STM32_DISCOVERY_LD8 );
#endif

#if STM32_DISCOVERY_NUM_LEDS > 6
    DECLARE_PIN( led7_Pin , STM32_DISCOVERY_LD9 );
#endif

#if STM32_DISCOVERY_NUM_LEDS > 7
    DECLARE_PIN( led8_Pin , STM32_DISCOVERY_LD10 );
#endif


#if defined(STM32F1_SERIES)

    umba::periph::GpioPin *pLeds[ STM32_DISCOVERY_NUM_LEDS ] =
    {   &led1_Pin
    ,   &led2_Pin
    };

    umba::periph::GpioPin &pinErrorLed = led1_Pin; // возможно, перепутаны цвета
    umba::periph::GpioPin &pinGoodLed  = led2_Pin;

#elif defined(STM32F3_SERIES)
    umba::periph::GpioPin *pLeds[ STM32_DISCOVERY_NUM_LEDS ] =
    {   &led1_Pin // red
    ,   &led3_Pin // orange
    ,   &led5_Pin // green
    ,   &led7_Pin // blue
    ,   &led8_Pin // red
    ,   &led6_Pin // orange
    ,   &led4_Pin // green
    ,   &led2_Pin // blue
    };

    umba::periph::GpioPin &pinErrorLed = led1_Pin;
    umba::periph::GpioPin &pinGoodLed  = led4_Pin;

#elif defined(STM32F4_SERIES)

    umba::periph::GpioPin *pLeds[ STM32_DISCOVERY_NUM_LEDS ] =
    {   &led1_Pin // Orange
    ,   &led2_Pin // Green
    ,   &led3_Pin // Red
    ,   &led4_Pin // Blue
    };

    umba::periph::GpioPin &pinErrorLed = led3_Pin;
    umba::periph::GpioPin &pinGoodLed  = led2_Pin;

#endif


inline
void ledControl( unsigned ledNo, bool ledState )
{
    ledNo = ledNo % STM32_DISCOVERY_NUM_LEDS;
    *(pLeds[ ledNo ]) = ledState;
}

inline
void ledControl( bool ledState )
{
    for( unsigned ledNo=0; ledNo!=STM32_DISCOVERY_NUM_LEDS; ++ledNo )
        ledControl( ledNo, ledState );
}

inline 
void ledStartup()
{
    ledControl( false );
    for( unsigned i = 0; i!=7; ++i)
    {
        ledControl( i&1 ? true : false );
        umba::time_service::delayMs(100);
    }
}


