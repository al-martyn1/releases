#include "luart/uart_handle.h"
#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
#include "umba/debug_helpers.h"

//#include "stm32.h"

#include "periph/gpio.h"
#include "periph/power.h"
#include "periph/adc.h"
#include "periph/dac.h"
#include "periph/flash.h"

/*
#include "rtkos/rtkos.h"
#include "rtkos/rtkos_protothread.h"
#include "rtkos/starters.h"

#include "drivers/messages_rtkos.h"
#include "drivers/periph/legacy_uart_driver.h"
#include "drivers/periph/soft_i2c_driver.h"
#include "drivers/periph/tim_pwm_driver_impl.h"
#include "drivers/periph/adc_driver_impl.h"
#include "drivers/periph/dac_driver_impl.h"
#include "drivers/periph/gpio_driver_impl.h"
#include "drivers/periph/power_switch_driver_impl.h"
#include "drivers/periph/device_state_indicator_driver_impl.h"



#include "drivers/uplinks/golem_driver_impl.h"

//#include "drivers/motors/esc_driver_impl.h"

#include "drivers/hid/keyboard_terminal_driver.h"

//#include "drivers/sensors/honeywell_psensor_driver.h"


#include "rtkos/handlers/keyboard_hadler_impl_base.h"
*/

#include "callbacks/callbacks.h"

#include "milliganjubus_core/milliganjubus_i_milli_reg_table.h"
#include "milliganjubus_core/milliganjubus_simple_reg_table.h"
#include "milliganjubus_core/milliganjubus_slave_session.h"
#include "milliganjubus_core/milliganjubus_synchronizer.h"
#include "milliganjubus_core/milliganjubus_master_session.h"


//#include "boards_conf/tvtx2v2_Main_Board_pins.cpp"
#include "boards_conf/tvtx2v2_Main_Board_conf.h"


#include "vtx2v2/telexertex2_types.h"

#include "vtx2v2/telexertex2_hot_end_regs.h"

#include "crc/umba_crc.h"



//-----------------------------------------------------------------------------
// Configuration
//#define USE_LEFT_GANJUBUS_AS_DEBUG

// For C6 use UMBA_TOO_LOW_MEM macro

// -E option make preprocessor output


//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
#undef RS485_LEFT_UART
#undef RS485_LEFT_LEGACY_UART
#define RS485_LEFT_UART                               UART4
#define RS485_LEFT_LEGACY_UART                        uart::uart4

//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------


struct MainBoardConfig
{
    uint8_t duChannel      = 0;
    uint8_t videoChannel   = 0;
    uint8_t videoPower     = 50;
};

struct MainBoardLinkState
{
    uint8_t videoState     = 0;
    uint8_t scramblerState = 0;
};


struct FlashConfigCrcCalculator
{
    uint32_t operator()( const uint8_t * buf, size_t len)
    {
        return umba_crc32 (buf, (uint32_t)len);
    }
};

// VC - 256/48
// VD - 384/80
bool readConfig( MainBoardConfig &cfg )
{
    return
    umba::periph::flash::readConfig< MainBoardConfig
                                   , FlashConfigCrcCalculator
                                   , umba::periph::flash::flash_size_256K
                                   , umba::periph::flash::page_size_2048
                                   , 0x8000000
                                   >( cfg );
}

bool writeConfig( const MainBoardConfig &cfg )
{
    return
    umba::periph::flash::writeConfig< MainBoardConfig
                                    , FlashConfigCrcCalculator
                                    , umba::periph::flash::flash_size_256K
                                    , umba::periph::flash::page_size_2048
                                    , 0x8000000
                                    >( cfg );
}

bool invalidateConfig( const MainBoardConfig &cfg )
{
    return
    umba::periph::flash::invalidateConfig< MainBoardConfig
                                    , FlashConfigCrcCalculator
                                    , umba::periph::flash::flash_size_256K
                                    , umba::periph::flash::page_size_2048
                                    , 0x8000000
                                    >( );
}


MainBoardConfig     config;
MainBoardLinkState  mainBoardLinkState;
bool configGood = false;


//-----------------------------------------------------------------------------
// Конфигурация ганджубуса
uint8_t     thisBoardGanjubusAddr = 0x1;
/*
static milliganjubus::SlaveSession slaveSession;

bool writeConfigResult = false;
bool ganjubusAddrDetectionDetected = false;
*/
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Тип таблицы регистров, таблица регистров, и safe proxy для ro/rw
typedef milliganjubus::SimpleRegTable< regs::Televertex2::ro::min, regs::Televertex2::ro::max, 
                                       regs::Televertex2::rw::min, regs::Televertex2::rw::max >
                             RawRegTableMain;

RawRegTableMain     rawRegTableMain;
rdlc::RegTableSafe< RawRegTableMain, regs::Televertex2::ro::meta > roRegsMain( &rawRegTableMain );
rdlc::RegTableSafe< RawRegTableMain, regs::Televertex2::rw::meta > rwRegsMain( &rawRegTableMain );

static milliganjubus::SlaveSession slaveSession;

//-----------------------------------------------------------------------------

static milliganjubus::Synchronizer  synchronizerLeft  (50);
static milliganjubus::Synchronizer  synchronizerRight (50);
static milliganjubus::MasterSession masterSessionLeft ( 15 );
static milliganjubus::MasterSession masterSessionRight( 15 );


//static HotEndSlave hotEndSlave;

static Televertex2::SuckingFootLeft1    suckingFootLeft1;
static Televertex2::SuckingFootLeft2    suckingFootLeft2;
static Televertex2::SuckingFootRight1   suckingFootRight1;
static Televertex2::SuckingFootRight2   suckingFootRight2;

static Televertex2::HotEndLeft          hotEndLeft;
static Televertex2::HotEndRight         hotEndRight;

static Televertex2::JointLeft1          jointLeft1 ;
static Televertex2::JointLeft2          jointLeft2 ;
static Televertex2::JointRight1         jointRight1;
static Televertex2::JointRight2         jointRight2;

static Televertex2::Battery             battery;

static Televertex2::HotEndLeft          hotEndLeftFake1 ;
static Televertex2::HotEndLeft          hotEndLeftFake2 ;
static Televertex2::HotEndRight         hotEndRightFake1;
static Televertex2::HotEndRight         hotEndRightFake2;



static auto jointControllerLeft1  = Televertex2::makeJointController( &jointLeft1  , 312 );
static auto jointControllerLeft2  = Televertex2::makeJointController( &jointLeft2  , 512 );
static auto jointControllerRight1 = Televertex2::makeJointController( &jointRight1 , 312 );
static auto jointControllerRight2 = Televertex2::makeJointController( &jointRight2 , 512, true );


// Быстрые верхние подъемные суставы жмут 128 попугаев в секунду и стартуют на 30% от мощи
// Медленные нижние поворотные суставы жмут 40 попугаев в секунду и стартуют на 50% от мощи
static ActiveJointController activeJointControllerLeft1  = ActiveJointController(&jointControllerLeft1 , 128, 30 );
static ActiveJointController activeJointControllerLeft2  = ActiveJointController(&jointControllerLeft2 , 40 , 50 );
static ActiveJointController activeJointControllerRight1 = ActiveJointController(&jointControllerRight1, 128, 30 );
static ActiveJointController activeJointControllerRight2 = ActiveJointController(&jointControllerRight2, 40 , 50 );



//-----------------------------------------------------------------------------
using namespace umba::omanip;
using namespace umba::periph;
using namespace regs::Televertex2;
using namespace regs::types;



//-----------------------------------------------------------------------------
#include "tvtx2v2_Main_Board_logic.h"
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
#if defined(USE_LEFT_GANJUBUS_AS_DEBUG)
auto debugUartDriver      = umba::drivers::periph::LegacyUartDriver( RS485_LEFT_LEGACY_UART
                                                                   , RS485_LEFT_UART_RX_GPIO_PIN_ADDR
                                                                   , RS485_LEFT_UART_TX_GPIO_PIN_ADDR
                                                                   , 460800
                                                                   // No pinAddrRs485
                                                                   );
#endif

auto stateIndicatorDriver = umba::drivers::periph::DeviceStateIndicator2LedsDriver( LED_ERROR_GPIO_PIN_ADDR, LED_LINK_GPIO_PIN_ADDR );

auto golemTermUartDriver  = umba::drivers::periph::LegacyUartDriver( GOLEM_TERM_LEGACY_UART
                                                                   , GOLEM_TERM_UART_RX_GPIO_PIN_ADDR
                                                                   , GOLEM_TERM_UART_TX_GPIO_PIN_ADDR
                                                                   , 115200
                                                                   // No pinAddrRs485
                                                                   );


auto golemDriver          = umba::drivers::uplinks::GolemDriver( umba::drivers::DriverAddress( umba::drivers::class_id_stream
                                                                                             , umba::periph::periphGetNo( & GOLEM_TERM_LEGACY_UART ) 
                                                                                             )
                                                               );



auto kbdTermDriver        = umba::drivers::hid::KeyboardTerminalDriver( 
                                                                        #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)
                                                                        umba::drivers::invalid_driver_address
                                                                        #else
                                                                        //umba::drivers::invalid_driver_address
                                                                        umba::drivers::DriverAddress( umba::drivers::class_id_stream
                                                                                                    , umba::periph::periphGetNo( & RS485_LEFT_LEGACY_UART ) 
                                                                                                    )
                                                                        #endif
                                                                      );

auto muxPowerDriver       = umba::drivers::periph::PowerSwitchDriver( MUX_EN_GPIO_PIN_ADDR, false );
/*
auto muxEnDriver          = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , MUX_EN_GPIO_PIN_ADDR
                                                             );
*/
auto muxDriver            = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , MUX_A1_GPIO_PIN_ADDR
                                                             , MUX_A0_GPIO_PIN_ADDR
                                                             );
/*
auto camerasEnDriver      = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , TVKO_EN_GPIO_PIN_ADDR
                                                             , CAMERA1_EN_GPIO_PIN_ADDR
                                                             , CAMERA2_EN_GPIO_PIN_ADDR
                                                             );
*/
auto tvkoPowerDriver      = umba::drivers::periph::PowerSwitchDriver( TVKO_EN_GPIO_PIN_ADDR   , false );
auto cam1PowerDriver      = umba::drivers::periph::PowerSwitchDriver( CAMERA1_EN_GPIO_PIN_ADDR, false );
auto cam2PowerDriver      = umba::drivers::periph::PowerSwitchDriver( CAMERA2_EN_GPIO_PIN_ADDR, false );

auto tvkoMotor1CurrentSensorPowerDriver  = umba::drivers::periph::PowerSwitchDriver( TVKO_MOTOR1_AMPLIF_SHDN1_GPIO_PIN_ADDR, true );
auto tvkoMotor2CurrentSensorPowerDriver  = umba::drivers::periph::PowerSwitchDriver( TVKO_MOTOR1_AMPLIF_SHDN2_GPIO_PIN_ADDR, true );

// Почему-то по разному продетектились

auto tvkoMotor1SpeedDac     = umba::periph::DacSimple( UMBA_PINADDR_PA4, umba::periph::DacBits::bits_12 ); // TVKO_MOTOR1_SPEED_GPIO_PIN_ADDR   UMBA_PINADDR_PA4
auto tvkoMotor2SpeedDac     = umba::periph::DacSimple( UMBA_PINADDR_PA5, umba::periph::DacBits::bits_12 ); // TVKO_MOTOR2_SPEED_DAC_CHANNEL     DAC_Channel_2

auto tvkoMotor1SpeedDriver  = umba::drivers::periph::makeDacDriver( tvkoMotor1SpeedDac );
auto tvkoMotor2SpeedDriver  = umba::drivers::periph::makeDacDriver( tvkoMotor2SpeedDac );


auto motorCtrlPins1       = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , TVKO_MOTOR1_PWM1_GPIO_PIN_ADDR
                                                             , TVKO_MOTOR1_PWM2_GPIO_PIN_ADDR
                                                             );

auto motorCtrlPins2       = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , TVKO_MOTOR2_PWM1_GPIO_PIN_ADDR
                                                             , TVKO_MOTOR2_PWM2_GPIO_PIN_ADDR
                                                             );


/*
auto dbgDacPins            = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_out_pp
                                                             , umba::periph::PinSpeed::low
                                                             , UMBA_PINADDR_PA4
                                                             , UMBA_PINADDR_PA5
                                                             );
*/

//-----------------------------------------------------------------------------







//-----------------------------------------------------------------------------
struct PredStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel4>
{
    virtual bool run() override
    {
         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning
         PT_END();
    }

};




auto deviceLogic = MainBoardLogic();


static uint8_t data[6] = { 0x81u, 0x01u, 0x04u, 0x00, 0x02, 0xFFu };

struct FunalStarterThread : public umba::rtkos::StarterThreadBase<umba::rtkos::RunLevel6>
{
    virtual bool run() override
    {
        using namespace regs::types;
        using namespace umba::drivers;
        using namespace umba::drivers::uplinks;

         PT_BEGIN();
         PT_YIELD(); // simply remove never used warning

         deviceLogic.timerSet( deviceLogic.timer_event_tvko_power_on, deviceLogic.timer_interval_tvko_power_on );
         umba::drivers::postMessageDriverValue( muxDriver.getAssignedAddress(), umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_gpio_value, (uint32_t)0 );
         TVKO_LEGACY_UART.sendLocalArray( &data[0], sizeof(data));

         // turn off all motor crtl pins
         umba::drivers::postMessageDriverValue( motorCtrlPins1.getAssignedAddress(), umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_gpio_value, (uint32_t)0 );
         umba::drivers::postMessageDriverValue( motorCtrlPins2.getAssignedAddress(), umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_gpio_value, (uint32_t)0 );

         // DAC test
         //deviceLogic.timerSet( deviceLogic.timer_event_dac, deviceLogic.timer_interval_dac );

         //umba::drivers::postMessageDriverValue( dbgDacPins.getAssignedAddress(), umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_gpio_value, (uint32_t)3 );
         


         PT_END();
    }

}; // struct FunalStarterThread


auto hwInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );
auto swInitDelays = umba::drivers::TicksFromPowerConsumptionClass( 5, 25, 50, 100 );

auto starter0   =  umba::rtkos::StarterThreadOsInfo< umba::rtkos::OsInfoLogLevel::osSizeDetailsMore >(); 
auto starter1   =  umba::rtkos::StarterThreadHardwareInfo();
auto starter2   =  umba::rtkos::StarterThreadHardwareInitializer< decltype(hwInitDelays)>( hwInitDelays );
auto starter4   =  PredStarterThread();
auto starter5   =  umba::rtkos::StarterThreadSoftwareInitializer< decltype(swInitDelays)/*, umba::rtkos::RunLevel5*/>( swInitDelays );
auto starter6   =  FunalStarterThread();

#if 0
auto knobsDriver          = umba::drivers::periph::GpioDriver( umba::periph::PinMode::gpio_in_pulldown
                                                             , umba::periph::PinSpeed::low
                                                             , RANGEFINDER1_GPIO_PIN_ADDR
                                                             , RANGEFINDER2_GPIO_PIN_ADDR
                                                             , RANGEFINDER3_GPIO_PIN_ADDR
                                                             , RANGEFINDER4_GPIO_PIN_ADDR
                                                             );


auto timPwmDriver         = umba::drivers::periph::TimPwmDriver( TIM16, 1, UMBA_PINADDR_PB8 ); // TIM16_CH1 

auto adcSC     = umba::periph::traits::AdcSingleChannel( ADC2, UMBA_PINADDR_PA6, umba::periph::AdcSamplingSpeed::very_low );
auto adcDriver = umba::drivers::periph::makeAdcDriver( adcSC, scalcus::average_times_32, UMBA_PINADDR_PA6 );
#endif







int main(void)

{
/*
    GOLEM_DATA_LEGACY_UART.init( GOLEM_DATA_UART_RX_GPIO, GOLEM_DATA_UART_RX_GPIO_PIN_NO
                        , GOLEM_DATA_UART_TX_GPIO, GOLEM_DATA_UART_TX_GPIO_PIN_NO
                        , 115200 // 460800 // *3/2
                        );

        uart::uart3.init( GOLEM_TERM_UART_RX_GPIO, GOLEM_TERM_UART_RX_GPIO_PIN_NO
                        , GOLEM_TERM_UART_TX_GPIO, GOLEM_TERM_UART_TX_GPIO_PIN_NO
                        , 115200 // 460800 // *3/2
                        );

    uart::uart1.init( GPIOC, 5
                        , GPIOC, 4
                        , 115200 // 460800 // *3/2
                        );

    while(true)
    {
        //GOLEM_DATA_LEGACY_UART
        uart::uart1.sendByte(0xA5);
        //GOLEM_TERM_LEGACY_UART
        uart::uart3.sendByte(0xA5);
    }    
*/

    configGood = readConfig( config );


    if (configGood)
    {
        //thisBoardGanjubusAddr = config.ganjubusAddr;
    }


    #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)

        UMBA_RTKOS_USE_LOG_STREAM_SWD();

        RS485_LEFT_LEGACY_UART.init( RS485_LEFT_UART_RX_GPIO, RS485_LEFT_UART_RX_GPIO_PIN_NO
                          , RS485_LEFT_UART_TX_GPIO, RS485_LEFT_UART_TX_GPIO_PIN_NO
                          , 57600
                          , RS485_LEFT_LINK_DE_GPIO, 1<<RS485_LEFT_LINK_DE_GPIO_PIN_NO
                          );


    #else

        UMBA_RTKOS_USE_LOG_STREAM_CONSOLE( RS485_LEFT_LEGACY_UART, RS485_LEFT_UART, 460800 );

    #endif

    //UMBA_RTKOS_LOG<<feed<<"------------------"<<endl;

    RS485_RIGHT_LEGACY_UART.init( RS485_RIGHT_UART_RX_GPIO, RS485_RIGHT_UART_RX_GPIO_PIN_NO
                      , RS485_RIGHT_UART_TX_GPIO, RS485_RIGHT_UART_TX_GPIO_PIN_NO
                      , 57600
                      , RS485_RIGHT_LINK_DE_GPIO, 1<<RS485_RIGHT_LINK_DE_GPIO_PIN_NO
                      );

//    GOLEM_DATA_LEGACY_UART.init( GOLEM_DATA_UART_RX_GPIO, GOLEM_DATA_UART_RX_GPIO_PIN_NO
//                        , GOLEM_DATA_UART_TX_GPIO, GOLEM_DATA_UART_TX_GPIO_PIN_NO
//                        , 115200 // 460800 //*3/2
//                        );
    uart::uart1.init( GPIOC, 5
                        , GPIOC, 4
                        , 115200 // 460800 //*3/2
                        );

    TVKO_LEGACY_UART.init( TVKO_UART_RX_GPIO, TVKO_UART_RX_GPIO_PIN_NO
                        , TVKO_UART_TX_GPIO, TVKO_UART_TX_GPIO_PIN_NO
                        , 9600 // 460800 //*3/2
                        );


    constexpr auto ro_regs_update_interval_ms      = 50;
    constexpr auto ro_regs_fast_update_interval_ms = 5;

    suckingFootLeft1 .init( rawRegTableMain, 0x10, ro_regs_update_interval_ms );
    suckingFootLeft2 .init( rawRegTableMain, 0x11, ro_regs_update_interval_ms );
    suckingFootRight1.init( rawRegTableMain, 0x10, ro_regs_update_interval_ms );
    suckingFootRight2.init( rawRegTableMain, 0x11, ro_regs_update_interval_ms );

    hotEndLeft       .init( rawRegTableMain, 0x20, ro_regs_update_interval_ms );
    hotEndRight      .init( rawRegTableMain, 0x20, ro_regs_update_interval_ms );
                     
    jointLeft1       .init( rawRegTableMain, 0x01, ro_regs_fast_update_interval_ms );
    jointLeft2       .init( rawRegTableMain, 0x02, ro_regs_fast_update_interval_ms );
    jointRight1      .init( rawRegTableMain, 0x03, ro_regs_fast_update_interval_ms );
    jointRight2      .init( rawRegTableMain, 0x04, ro_regs_fast_update_interval_ms );

    battery          .init( rawRegTableMain, 0x70, ro_regs_update_interval_ms );

    hotEndLeftFake1 .init( rawRegTableMain, 0x21, ro_regs_update_interval_ms );
    hotEndLeftFake2 .init( rawRegTableMain, 0x22, ro_regs_update_interval_ms );
    hotEndRightFake1.init( rawRegTableMain, 0x21, ro_regs_update_interval_ms );
    hotEndRightFake2.init( rawRegTableMain, 0x22, ro_regs_update_interval_ms );

    // Обсираются сосалки - иногда поздновато присылают ответ
    // Поэтому мы их вставим после тех, кто не обсирается
    // Это суставы 
    // После обосравшихся сосал ставим hotEnd
    // Если что, то он будет ловить пакеты от тормозных обосравшихся сосал
    // и будет отваливаться, но зато грудью встанет на защиту суставов
    // После него будет батарейка (или вместо него)
    // Батарейка тоже может отваливаться, но нам пофик на неё. Нам главное, 
    // чтобы она слышала, что с ней разговаривают

    // Батарейка на правой ноге

    synchronizerLeft .addSlave( jointLeft1       );
    synchronizerLeft .addSlave( jointLeft2       );
    synchronizerLeft .addSlave( suckingFootLeft1 );
    synchronizerLeft .addSlave( hotEndLeftFake1  );
    synchronizerLeft .addSlave( suckingFootLeft2 );
    synchronizerLeft .addSlave( hotEndLeftFake2  );
    synchronizerLeft .addSlave( hotEndLeft       );

    synchronizerRight.addSlave( jointRight1      );
    synchronizerRight.addSlave( jointRight2      );
    synchronizerRight.addSlave( suckingFootRight1);
    synchronizerRight.addSlave( hotEndRightFake1 );
    synchronizerRight.addSlave( suckingFootRight2);
    synchronizerRight.addSlave( hotEndRightFake2 );
    synchronizerRight.addSlave( hotEndRight      );

    // Если запустились под отладчиком, то никаких разговоров с батарейкой
    if (!umba::isDebuggerPresent())
    {
        synchronizerRight.addSlave( battery );
    }


    {
        auto onValidAnswerReceived = CALLBACK_BIND( synchronizerLeft, milliganjubus::Synchronizer::onRelevantAnswerReceived );
        auto onIrrelevantAnswerReceived = CALLBACK_BIND( synchronizerLeft, milliganjubus::Synchronizer::ignoreIrrelevantAnswer );
        auto onConnectionFailure = CALLBACK_BIND( synchronizerLeft, milliganjubus::Synchronizer::onConnectionFailure );

        #if !defined(USE_LEFT_GANJUBUS_AS_DEBUG)

            masterSessionLeft.init( RS485_LEFT_LEGACY_UART, onValidAnswerReceived, onConnectionFailure, onIrrelevantAnswerReceived);
            milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( masterSessionLeft, milliganjubus::MasterSession::sendRequest );
            synchronizerLeft.init(sendRequest);

        #endif
    }

    {
        auto onValidAnswerReceived = CALLBACK_BIND( synchronizerRight, milliganjubus::Synchronizer::onRelevantAnswerReceived );
        auto onIrrelevantAnswerReceived = CALLBACK_BIND( synchronizerRight, milliganjubus::Synchronizer::ignoreIrrelevantAnswer );
        auto onConnectionFailure = CALLBACK_BIND( synchronizerRight, milliganjubus::Synchronizer::onConnectionFailure );

        masterSessionRight.init( RS485_RIGHT_LEGACY_UART, onValidAnswerReceived, onConnectionFailure, onIrrelevantAnswerReceived);
        milliganjubus::Synchronizer::SendRequest sendRequest = CALLBACK_BIND( masterSessionRight, milliganjubus::MasterSession::sendRequest );
        synchronizerRight.init(sendRequest);
    }
                     
    
    static callback::Callback<void ( void )> linkLostCallback    ( []() { deviceLogic.onGanjubusLinkLost();     } );
    static callback::Callback<void ( void )> linkRestoredCallback( []() { deviceLogic.onGanjubusLinkRestored(); } );
    static callback::Callback<void ( void )> dataReceivedCallback( []() { deviceLogic.onGanjubusDataReceived(); } );

    
    slaveSession.init( uart::uart1 // GOLEM_DATA_LEGACY_UART
                     , thisBoardGanjubusAddr
                     , rawRegTableMain
                     , linkLostCallback
                     , linkRestoredCallback
                     , 5000 // lost link timeout
                     , dataReceivedCallback );         // коллбэки


    roRegsMain[ro::robot_id_u8] = thisBoardGanjubusAddr;

    static camera::Worker cameraWorker( rwRegsMain.getRawTable(), & TVKO_LEGACY_UART );
    cameraWorker.init();



    /*
    Полировать так
    auto tickNow = umba::time_service::getCurTimeMs();
    slaveSession.work( tickNow );
    masterSessionRight.work( tickNow );
    masterSessionLeft.work( tickNow );
    */



    #if defined(USE_LEFT_GANJUBUS_AS_DEBUG)
        UMBA_DRIVER_CHECKED_INSTALL( debugUartDriver, umba::drivers::driver_id_device_number );
        //debugUartDriver.install( umba::drivers::driver_id_device_number );
    #endif

    UMBA_DRIVER_CHECKED_INSTALL(stateIndicatorDriver);

    UMBA_DRIVER_CHECKED_INSTALL( muxPowerDriver  );
    UMBA_DRIVER_CHECKED_INSTALL( tvkoPowerDriver );
    UMBA_DRIVER_CHECKED_INSTALL( cam1PowerDriver );
    UMBA_DRIVER_CHECKED_INSTALL( cam2PowerDriver );

    UMBA_DRIVER_CHECKED_INSTALL( tvkoMotor1CurrentSensorPowerDriver );
    UMBA_DRIVER_CHECKED_INSTALL( tvkoMotor2CurrentSensorPowerDriver );

    UMBA_DRIVER_CHECKED_INSTALL( muxDriver       );

    UMBA_DRIVER_CHECKED_INSTALL( tvkoMotor1SpeedDriver );
    UMBA_DRIVER_CHECKED_INSTALL( tvkoMotor2SpeedDriver );

    UMBA_DRIVER_CHECKED_INSTALL( motorCtrlPins1 );
    UMBA_DRIVER_CHECKED_INSTALL( motorCtrlPins2 );

    UMBA_DRIVER_CHECKED_INSTALL( activeJointControllerLeft1  );
    UMBA_DRIVER_CHECKED_INSTALL( activeJointControllerLeft2  );
    UMBA_DRIVER_CHECKED_INSTALL( activeJointControllerRight1 );
    UMBA_DRIVER_CHECKED_INSTALL( activeJointControllerRight2 );

    //UMBA_DRIVER_CHECKED_INSTALL( dbgDacPins );
    

    //UMBA_DRIVER_CHECKED_INSTALL( );


    UMBA_DRIVER_CHECKED_INSTALL(kbdTermDriver);

    UMBA_DRIVER_CHECKED_INSTALL( golemTermUartDriver, umba::drivers::driver_id_device_number );
    UMBA_DRIVER_CHECKED_INSTALL( golemDriver );

    /*
    if (!tvkoMotor1SpeedDac.isConnected())  tvkoMotor1SpeedDac.connect();
    if (!tvkoMotor2SpeedDac.isConnected())  tvkoMotor2SpeedDac.connect();

    //tvkoMotor1SpeedDac     = 0xFFF;
    //tvkoMotor2SpeedDac     = 0xFFF;
    tvkoMotor1SpeedDac     = 0;
    tvkoMotor2SpeedDac     = 0;
    */

    deviceLogic.pCameraWorker                 = &cameraWorker;

    deviceLogic.golemDriverAddress            = golemDriver          .getAssignedAddress();
    deviceLogic.muxDriverAddress              = muxDriver            .getAssignedAddress();
    deviceLogic.stateIndicatorDriverAddress   = stateIndicatorDriver .getAssignedAddress();

    deviceLogic.tvkoMotor1Speed               = tvkoMotor1SpeedDriver.getAssignedAddress();
    deviceLogic.tvkoMotor2Speed               = tvkoMotor2SpeedDriver.getAssignedAddress();
                                                

    UMBA_DRIVER_CHECKED_INSTALL(deviceLogic);


    umba::rtkos::pollScheduleAdd( &starter0 );
    umba::rtkos::pollScheduleAdd( &starter1 );
    umba::rtkos::pollScheduleAdd( &starter2 );
    umba::rtkos::pollScheduleAdd( &starter4 );
    umba::rtkos::pollScheduleAdd( &starter5 );
    umba::rtkos::pollScheduleAdd( &starter6 );


    return UMBA_RTKOS_OS->run( umba::rtkos::RunLevel6 );

}





