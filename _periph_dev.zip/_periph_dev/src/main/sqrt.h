#pragma once

#include <math.h>

#include "umba/optimize_speed.h"
//-----------------------------------------------------------------------------
inline
uint32_t fastSqrtGeneric16( uint32_t x )
{
   //if (x==1u)
   //    return 1u;

   uint32_t m, y, b;
   m = 0x4000;
   y = 0;
   while (m != 0)
   {
      b = y | m;
      y = y >> 1;
      if (x >= b)
      {
         x = x - b;
         y = y | m;
      }
      m = m >> 2;
   }
   return y;
}

//-----------------------------------------------------------------------------
//тоже самое но с типом long
uint32_t fastSqrtGeneric(uint32_t x)
{
    uint32_t m, y, b;
    m = 0x40000000;
    y = 0;
    while (m != 0) 
    {
        b = y | m;
        y = y >> 1;
        if (x >= b) 
        {
            x = x - b;
            y = y | m;
        }
        m = m >> 2;
    }
    return y;
}

inline uint32_t fastSqrtGeneric32(uint32_t x)
{
    return fastSqrtGeneric(x);
}

//-----------------------------------------------------------------------------
uint64_t fastSqrtGeneric(uint64_t x)
{
    uint64_t m, y, b;
    m = 0x4000000000000000ull;
    y = 0;
    while (m != 0) 
    {
        b = y | m;
        y = y >> 1;
        if (x >= b) 
        {
            x = x - b;
            y = y | m;
        }
        m = m >> 2;
    }
    return y;
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
inline
UMBA_FORCE_INLINE( uint32_t fastSqrtGeronGetStartVal(uint32_t x) )
{
    return 
    (x & 0xF0000000)               // 65536
    ? 65536
    : (x & 0x0F000000)             // 16384
      ? 16384
      : (x & 0x00F00000)           // 4096
        ? 4096
        : (x & 0x000F0000)         // 1024
          ? 1024
          : (x & 0x0000F000)       // 256
            ? 256
            : (x & 0x00000F00)     // 64
              ? 64
              : (x & 0x000000F0)   // 16
                ? 16
                : (x & 0x0000000F)
                  ? 4
                  : 2
                  ;
/*
                : (x & 0x00000008)
                  ? 16 // 4
                  : (x & 0x00000004)
                    ? 8 // 2
                    : 4 // 1
                    ;
*/
}

UMBA_FORCE_INLINE( uint64_t fastSqrtGeronGetStartVal(uint64_t x) )
{
    return (x & 0xFFFFFFFF00000000ull) ? 4294967295ull : (uint64_t)fastSqrtGeronGetStartVal((uint32_t)x);
}
/*
fastSqrtGeronGetIdx
    return 
    (x & 0xF0000000)               // 65536
    ? 0
    : (x & 0x0F000000)             // 16384
      ? 1
      : (x & 0x00F00000)           // 4096
        ? 2
        : (x & 0x000F0000)         // 1024
          ? 3
          : (x & 0x0000F000)       // 256
            ? 5
            : (x & 0x00000F00)     // 64
              ? 6
              : (x & 0x000000F0)   // 16
                ? 7
                : (x & 0x0000000F) // 4
                  ? 8
                  : 9
                  ;

    (x & 0xFF000000) // 4278190080, 0x01000000 - 16777216 sqrt - 4096
    ? 0
    : (x & 0x00FF0000) // 16711680, 0x00010000 -    65536
      ? 1
      : (x & 0x0000FF00) //  65280, 0x00000100 -      256
        ? 2
        : 3;
*/


#if 0
inline
uint32_t fastSqrtGeronGetStartVal(uint32_t x)
{
    static startVals[]
/*
    // now
    if (x > 1000000)
        use 1000
    else if (x > 50)
        use 63
    else
        use 7
*/
}
#endif

//a = x = x > 1000000 ? 1000 : (x > 50 ? 0x3f : 7);
inline
uint32_t fastSqrtGeron1(uint32_t x)
{
   uint32_t a,b;
   b = x;
   //a = x = x > 1000000 ? 1000 : (x > 50 ? 0x3f : 7);
   a = x = fastSqrtGeronGetStartVal(x);
   x = b/x;
   a = x = (x+a)>>1;
   x = b/x;
   a = x = (x+a)>>1;
   x = b/x;
   x = (x+a)>>1;
   return(x); 
}

//-----------------------------------------------------------------------------
inline
uint64_t fastSqrtGeron1(uint64_t x)
{
   uint64_t a,b;
   b = x;
   //a = x = x > 1000000 ? 1000 : (x > 50 ? 0x3f : 7);
   a = x = fastSqrtGeronGetStartVal(x);
   x = b/x;
   a = x = (x+a)>>1;
   x = b/x;
   a = x = (x+a)>>1;
   x = b/x;
   x = (x+a)>>1;
   return(x); 
}

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
inline
uint32_t fastSqrtGeron2(uint32_t a)
{
   //a <<= 4;
   uint32_t x;
   //const uint32_t s = a > 1000000 ? 1000 : (a > 50 ? 0x3f : 7);
   const uint32_t s = fastSqrtGeronGetStartVal(a);
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   return x;
   //return x>>2;
}

//-----------------------------------------------------------------------------
inline
uint64_t fastSqrtGeron2(uint64_t a)
{
   //a <<= 4;
   uint64_t x;
   //const uint64_t s = a > 1000000 ? 1000 : (a > 50 ? 0x3f : 7);
   const uint32_t s = fastSqrtGeronGetStartVal(a);
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   return x;
   //return x>>2;
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
inline
uint32_t accurateSqrtGeron2(uint32_t a)
{
   uint32_t x;
   const uint32_t s = fastSqrtGeronGetStartVal(a);
   //const uint32_t s = a > 1000000 ? 1000 : (a > 50 ? 0x3f : 7);
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   return(x);
}

//-----------------------------------------------------------------------------
inline
uint64_t accurateSqrtGeron2(uint64_t a)
{
   uint64_t x;
   const uint32_t s = fastSqrtGeronGetStartVal(a);
   //const uint64_t s = a > 1000000 ? 1000 : (a > 50 ? 0x3f : 7);
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   x = (a/s + s)>>1;
   x = (a/x + x)>>1;
   x = (a/x + x)>>1;
   return(x);
}

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
inline
float fastSqrtKarmak( float number )
{
    int32_t i;
	float x2, y;
	const float threehalfs = 1.5F;

	x2 = number * 0.5F;
	y  = number;
	i  = * ( int32_t * ) &y;                    // evil floating point bit level hacking
	i  = 0x5f3759df - ( i >> 1 );               // what the fuck? 
	y  = * ( float * ) &i;
	y  = y * ( threehalfs - ( x2 * y * y ) );   // 1st iteration
//	y  = y * ( threehalfs - ( x2 * y * y ) );   // 2nd iteration, this can be removed

	return 1/y;

}

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
inline
uint32_t fastSqrtKarmak( uint32_t number )
{
    return (uint32_t)(0.5 + fastSqrtKarmak( (float)number ));
}

//-----------------------------------------------------------------------------
inline
uint64_t fastSqrtKarmak( uint64_t number )
{
    return (uint64_t)(0.5 + fastSqrtKarmak( (float)number ));
}

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
// http://qaru.site/questions/96987/fastest-way-to-get-the-integer-part-of-sqrtn
inline
uint64_t fastUnknownUnsignedSqrt1(uint64_t a)
{
    uint64_t rem  = 0;
    //int64_t  root = 0;
    //int64_t  i;
    uint64_t  root = 0;
    uint64_t  i;

    for (i = 0; i < 16; i++)
    {
        root <<= 1;
        rem <<= 2;
        rem += a >> 30;
        a <<= 2;

        if (root < rem)
        {
            root++;
            rem -= root;
            root++;
        }
    }

    return (root >> 1);
}

//-----------------------------------------------------------------------------
// http://www.codecodex.com/wiki/Calculate_an_integer_square_root
template <typename type>  
inline
type fastUnknownUnsignedSqrt2(type remainder)  
{  
  if (remainder < 0) // if type is unsigned this will be ignored = no runtime  
    return 0; // negative number ERROR  
  
  type place = (type)1 << (sizeof (type) * 8 - 2); // calculated by precompiler = same runtime as: place = 0x40000000  
  while (place > remainder)  
    place /= 4; // optimized by complier as place >>= 2  
  
  type root = 0;  
  while (place)  
  {  
    if (remainder >= root+place)  
    {  
      remainder -= root+place;  
      root += place * 2;  
    }  
    root /= 2;  
    place /= 4;  
  }  
  return root;  
}  

template <typename type>  
inline
type fastUnknownUnsignedSqrt3( type n)  
{  
    type c = 0x8000u;
    type g = 0x8000u;  
  
    for(;;) {  
        if(g*g > n)  
            g ^= c;  
        c >>= 1;  
        if(c == 0)  
            return g;  
        g |= c;  
    }  
}  

//-----------------------------------------------------------------------------
inline
uint32_t crtSqrt( uint32_t number )
{
    return (uint32_t)(0.5 + sqrt( (double)number ));
}

//-----------------------------------------------------------------------------
inline
uint64_t crtSqrt( uint64_t number )
{
    return (uint64_t)(0.5 + sqrt( (double)number ));
}

//-----------------------------------------------------------------------------
const uint32_t sqrt_table[] =
        {
            0,
            4096,
            5792,
            7096,
            8192,
            9160,
            10032,
            10836,
            11584,
            12288,
            12952,
            13584,
            14188,
            14768,
            15324,
            15864,
            16384,
            16888,
            17376,
            17856,
            18316,
            18772,
            19212,
            19644,
            20068,
            20480,
            20884,
            21284,
            21672,
            22056,
            22436,
            22804,
            23172,
            23528,
            23884,
            24232,
            24576,
            24916,
            25248,
            25580,
            25904,
            26228,
            26544,
            26860,
            27168,
            27476,
            27780,
            28080,
            28376,
            28672,
            28964,
            29252,
            29536,
            29820,
            30100,
            30376,
            30652,
            30924,
            31196,
            31460,
            31728,
            31992,
            32252,
            32512,
            32768,
            33024,
            33276,
            33528,
            33776,
            34024,
            34268,
            34512,
            34756,
            34996,
            35236,
            35472,
            35708,
            35944,
            36176,
            36408,
            36636,
            36864,
            37092,
            37316,
            37540,
            37764,
            37984,
            38204,
            38424,
            38640,
            38860,
            39072,
            39288,
            39500,
            39712,
            39924,
            40132,
            40340,
            40548,
            40756,
            40960,
            41164,
            41368,
            41568,
            41772,
            41972,
            42172,
            42368,
            42568,
            42764,
            42960,
            43156,
            43348,
            43540,
            43732,
            43924,
            44116,
            44304,
            44492,
            44684,
            44868,
            45056,
            45240,
            45428,
            45612,
            45796,
            45976,
            46160,
            46340,
            46520,
            46700,
            46880,
            47060,
            47236,
            47416,
            47592,
            47768,
            47944,
            48116,
            48292,
            48464,
            48636,
            48808,
            48980,
            49152,
            49324,
            49492,
            49660,
            49828,
            50000,
            50164,
            50332,
            50500,
            50664,
            50832,
            50996,
            51160,
            51324,
            51484,
            51648,
            51812,
            51972,
            52132,
            52296,
            52456,
            52616,
            52772,
            52932,
            53092,
            53248,
            53404,
            53564,
            53720,
            53876,
            54028,
            54184,
            54340,
            54492,
            54648,
            54800,
            54952,
            55108,
            55260,
            55408,
            55560,
            55712,
            55860,
            56012,
            56160,
            56312,
            56460,
            56608,
            56756,
            56904,
            57052,
            57196,
            57344,
            57492,
            57636,
            57780,
            57928,
            58072,
            58216,
            58360,
            58504,
            58644,
            58788,
            58932,
            59072,
            59216,
            59356,
            59496,
            59640,
            59780,
            59920,
            60060,
            60200,
            60336,
            60476,
            60616,
            60752,
            60892,
            61028,
            61168,
            61304,
            61440,
            61576,
            61712,
            61848,
            61984,
            62120,
            62252,
            62388,
            62524,
            62656,
            62792,
            62924,
            63056,
            63192,
            63324,
            63456,
            63588,
            63720,
            63852,
            63980,
            64112,
            64244,
            64372,
            64504,
            64632,
            64764,
            64892,
            65020,
            65152,
            65280,
            65408,
            65536,
            65664,
            65792,
            65920,
            66048,
            66172,
            66300,
            66424,
            66552,
            66680,
            66804,
            66928,
            67056,
            67180,
            67304,
            67428,
            67552,
            67676,
            67800,
            67924,
            68048,
            68172,
            68292,
            68416,
            68540,
            68660,
            68784,
            68904,
            69028,
            69148,
            69268,
            69392,
            69512,
            69632,
            69752,
            69872,
            69992,
            70112,
            70232,
            70352,
            70472,
            70588,
            70708,
            70828,
            70944,
            71064,
            71180,
            71300,
            71416,
            71532,
            71652,
            71768,
            71884,
            72000,
            72116,
            72232,
            72348,
            72464,
            72580,
            72696,
            72812,
            72928,
            73044,
            73156,
            73272,
            73384,
            73500,
            73616,
            73728,
            73840,
            73956,
            74068,
            74180,
            74296,
            74408,
            74520,
            74632,
            74744,
            74856,
            74968,
            75080,
            75192,
            75304,
            75416,
            75528,
            75636,
            75748,
            75860,
            75968,
            76080,
            76192,
            76300,
            76408,
            76520,
            76628,
            76740,
            76848,
            76956,
            77064,
            77176,
            77284,
            77392,
            77500,
            77608,
            77716,
            77824,
            77932,
            78040,
            78148,
            78252,
            78360,
            78468,
            78576,
            78680,
            78788,
            78896,
            79000,
            79108,
            79212,
            79320,
            79424,
            79528,
            79636,
            79740,
            79844,
            79952,
            80056,
            80160,
            80264,
            80368,
            80472,
            80576,
            80680,
            80784,
            80888,
            80992,
            81096,
            81200,
            81304,
            81408,
            81508,
            81612,
            81716,
            81816,
            81920,
            82024,
            82124,
            82228,
            82328,
            82432,
            82532,
            82632,
            82736,
            82836,
            82936,
            83040,
            83140,
            83240,
            83340,
            83440,
            83544,
            83644,
            83744,
            83844,
            83944,
            84044,
            84144,
            84244,
            84340,
            84440,
            84540,
            84640,
            84740,
            84836,
            84936,
            85036,
            85132,
            85232,
            85332,
            85428,
            85528,
            85624,
            85724,
            85820,
            85920,
            86016,
            86112,
            86212,
            86308,
            86404,
            86504,
            86600,
            86696,
            86792,
            86888,
            86984,
            87084,
            87180,
            87276,
            87372,
            87468,
            87564,
            87660,
            87752,
            87848,
            87944,
            88040,
            88136,
            88232,
            88324,
            88420,
            88516,
            88612,
            88704,
            88800,
            88892,
            88988,
            89084,
            89176,
            89272,
            89364,
            89456,
            89552,
            89644,
            89740,
            89832,
            89924,
            90020,
            90112,
            90204,
            90296,
            90392,
            90484,
            90576,
            90668,
            90760,
            90852,
            90944,
            91040,
            91132,
            91224,
            91316,
            91404,
            91496,
            91588,
            91680,
            91772,
            91864,
            91956,
            92048,
            92136,
            92228,
            92320,
            92408,
            92500,
            92592,
            92682
        };
 
        const uint8_t help_sqrt_table[]=
        {
            2, 2, 2, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
            6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
            6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
            6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6
        };
 
        float sqrtBub( float num )
        {
            const auto to_float = 0.000244140625f;
 
            if( num == 0.f ) // только точный ноль воспринимаю нулем
            {
                return 0;
            }
            auto divider = 1.f;
 
            if( num < 256.f  )
            {
                divider = 0.00390625f;
                num *= 0x10000;
            }
 
            auto value = static_cast<uint32_t>( num );
 
            // супер алгоритм из инета
            auto shifted1 = value >> 9;
            auto shifted2 = 0;
            if( shifted1 )
            {
                shifted2 = value >> 15;
                if( shifted2 )
                {
                    value >>= 6;
                    shifted1 = value >> 15;
                    if( shifted1 )
                    {
                        value >>= 6;
                        shifted2 = value >> 15;
                        if( shifted2 )
                        {
                            value >>= 6;
                            return ( sqrt_table[value >> help_sqrt_table[shifted2]] << (9 + (help_sqrt_table[shifted2] >> 1)) ) * to_float * divider;
                        }
                        else
                        {
                            return ( sqrt_table[value >> help_sqrt_table[shifted1]] << (6 + (help_sqrt_table[shifted1] >> 1)) ) * to_float * divider;
                        }
                    }
                    else
                    {
                        return ( sqrt_table[value >> help_sqrt_table[shifted2]] << (3 + (help_sqrt_table[shifted2] >> 1)) ) * to_float * divider;
                    }
                }
                else
                {
                    return ( sqrt_table[value >> help_sqrt_table[shifted1]] << ( help_sqrt_table[shifted1] >> 1) ) * to_float * divider;
                }
            }
            else
            {
                return ( sqrt_table[value]  ) * to_float * divider;
            }
        }

uint32_t sqrtBub( uint32_t value )
    {
 
        if(!value)
        {
            return 0;
        }
        uint32_t shifted1 = value >> 9;
        uint32_t shifted2 = 0;
        if(shifted1)
        {
            shifted2 = value >> 15;
            if(shifted2)
            {
                value >>= 6;
                shifted1 = value >> 15;
                if(shifted1)
                {
                    value >>= 6;
                    shifted2 = value >> 15;
                    if(shifted2)
                    {
                        value >>= 6;
                        return sqrt_table[value >> help_sqrt_table[shifted2]] >> (3 - (help_sqrt_table[shifted2] >> 1));
                    }
                    else
                    {
                        return sqrt_table[value >> help_sqrt_table[shifted1]] >> (6 - (help_sqrt_table[shifted1] >> 1));
                    }
                }
                else
                {
                    return sqrt_table[value >> help_sqrt_table[shifted2]] >> (9 - (help_sqrt_table[shifted2] >> 1));
                }
            }
            else
            {
                return sqrt_table[value >> help_sqrt_table[shifted1]] >> (12 - (help_sqrt_table[shifted1] >> 1));
            }
        }
        else
        {
            return sqrt_table[value] >> 12;
        }
    }

uint32_t newton(uint32_t val)
{
    uint32_t tableVal = sqrtBub(val);
    
    tableVal = tableVal + val / tableVal;
    return tableVal >> 1;
}

template< typename T >
struct SqrtBub
{
    T operator()(T x)
    {
        return sqrtBub(x);
    }
};

template< typename T >
struct SqrtBub2
{
    T operator()(T x)
    {
        return newton(x);
    }
};


template< typename T >
struct SqrtGeneric
{
    T operator()(T x)
    {
        return fastSqrtGeneric(x);
    }
};

template< typename T >
struct SqrtGeron1
{
    T operator()(T x)
    {
        return fastSqrtGeron1(x);
    }
};

template< typename T >
struct SqrtGeron2
{
    T operator()(T x)
    {
        return fastSqrtGeron2(x);
    }
};

template< typename T >
struct SqrtGeronAccurate
{
    T operator()(T x)
    {
        return accurateSqrtGeron2(x);
    }
};

template< typename T >
struct SqrtKarmak
{
    T operator()(T x)
    {
        return fastSqrtKarmak(x);
    }
};

template< typename T >
struct UnknownUnsignedSqrt1
{
    T operator()(T x)
    {
        return fastUnknownUnsignedSqrt1(x);
    }
};

template< typename T >
struct UnknownUnsignedSqrt2
{
    T operator()(T x)
    {
        return fastUnknownUnsignedSqrt2(x);
    }
};

template< typename T >
struct UnknownUnsignedSqrt3
{
    T operator()(T x)
    {
        return fastUnknownUnsignedSqrt3(x);
    }
};

template< typename T >
struct SqrtCrt
{
    T operator()(T x)
    {
        return crtSqrt(x);
    }
};

#include "umba/optimize_pop.h"


//-----------------------------------------------------------------------------
/*
SqrtKarmak           : 667203788767             391
SqrtCrt              : 666666660000             531

Win32/Win64 
    Karmak version is faster to 1.5 times then CRT
    CRT version is most accurate


    For Win32/Win64 crt version is faster and most accurate
*/

/*
inline
uint32_t accurateUnsignedSqrt( uint32_t number )
{
    return (uint32_t)(0.5 + sqrt( (double)number ));
}

inline
uint64_t accurateUnsignedSqrt( uint64_t number )
{
    return (uint64_t)(0.5 + sqrt( (double)number ));
}

inline
uint32_t fastUnsignedSqrt( uint32_t number )
{
    return (uint32_t)(0.5 + fastSqrtKarmak( (float)number ));
}

inline
uint64_t fastUnsignedSqrt( uint64_t number )
{
    return (uint64_t)(0.5 + fastSqrtKarmak( (float)number ));
}

*/

