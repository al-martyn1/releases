#pragma once


inline
void softSpiLoopDelay( unsigned delayCounter )
{
    for( unsigned i = 0; i!=delayCounter; ++i ) {}
}


#define UMBA_LOOP_DELAY( n )    softSpiLoopDelay(n)
//#define UMBA_LOOP_DELAY( n )    do{ for( unsigned i = 0; i!=delayCounter; ++i ) {} } while(0)


inline
uint32_t softSpiRead( size_t numBitsToRead
                    , umba::periph::GpioPin &sckPin
                    , umba::periph::GpioPin &misoPin
                    , umba::periph::GpioPin &selectPin
                    , umba::periph::GpioPin *pOptionalPricklePin
                    , unsigned delayCounter = 2
                    )
{
    uint32_t res = 0;
    unsigned delayCounter2 = delayCounter/2;

    selectPin = false;
    UMBA_LOOP_DELAY(delayCounter); // tDV interval
    UMBA_LOOP_DELAY(delayCounter); // tCSS

    for( size_t i = 0; i!=numBitsToRead; ++i)
    {
    
        sckPin = true; // clock - up
        UMBA_LOOP_DELAY(delayCounter);
       
        sckPin = false; // clock - down
        UMBA_LOOP_DELAY(delayCounter2);
       
        // прочитать пин
        res <<= 1;
        if (misoPin)
            res |= 1;

        // дернем иголочный пин, покажем на осциле момент чтения
        if (pOptionalPricklePin)
        {
            *pOptionalPricklePin = true;
            UMBA_LOOP_DELAY(1);
            *pOptionalPricklePin = false;
        }

        UMBA_LOOP_DELAY(delayCounter2);

    }

    selectPin = true;

    return res;
}
