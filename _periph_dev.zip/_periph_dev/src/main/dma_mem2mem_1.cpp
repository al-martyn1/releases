#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
#include "umba/hr_counter.h"


//extern umba::SimpleFormatter  lout;

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"

#include "periph/stm32_discovery.h"


// memset/memcpy
#include <string.h>



using namespace umba::time_service;
using namespace umba::periph::traits;
using namespace umba::omanip;


//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::LegacyUartCharWriter<255>   charWritter = umba::LegacyUartCharWriter<255>( STM32_DISCOVERY_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);



uint8_t refArray1[8] = { 1, 2, 3, 4, 5, 6, 7, 8 };
uint8_t refArray2[8] = { 8, 7, 6, 5, 4, 3, 2, 1 };

uint8_t arraySrc[8]  = { 0 };
uint8_t arrayDst[8]  = { 0 };


umba::SimpleFormatter& dump( const uint8_t *pData, size_t dataSize = 8 ) 
{
    for( size_t i = 0; i!=8; ++i )
    {
        if (i)
           lout<<" ";
        lout<<hex<<pData[i];
    }

    return lout;
}


int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    STM32_DISCOVERY_LEGACY_UART.init( STM32_DISCOVERY_UART_RX_GPIO,  STM32_DISCOVERY_UART_RX_GPIO_PIN_NO, STM32_DISCOVERY_UART_TX_GPIO, STM32_DISCOVERY_UART_TX_GPIO_PIN_NO, 460800 );

    lout<<"---------------------------------\n";
    lout<<"Hello DMA mem2mem test#1 from "<<STM32_DISCOVERY_NAME<<endl;

    // void * memset ( void * ptr, int value, size_t num );
    // void* memcpy( void* dest, const void* src, std::size_t count );

    memcpy( arraySrc, refArray1, sizeof(refArray1) );
    memcpy( arrayDst, refArray2, sizeof(refArray2) );

    lout<<"------\n";
    lout<<"Arrays initialized\n";
    lout<<"Src: "; dump(arraySrc)<<"\n";
    lout<<"Dst: "; dump(arrayDst)<<"\n";
    lout<<"Contents equality: "<< (memcmp( arraySrc, arrayDst, sizeof(refArray1) )==0) <<endl;

    // Periph is a source

    dmaInitBase( DMA2, dmaChannel1
               , (void*)arrayDst, (void*)arraySrc
               , dmaChannelPriorityVeryHigh
               , 1 // hwChannel mean only for F4
               , dmaSizeBytes1
               , sizeof(arraySrc) //  numOfDataItems
               , dmaDirMemMemMode // dirRxTx
               , dmaIncMem
               , dmaIncPeriph
               , dmaCircOff
               );

    periphEnable( dmaGetChannelAddr( DMA2, dmaChannel1 ), dmaOn );

    /*
        periphWaitDisabled( dmaGetChannelAddr( DMA2, dmaChannel1 ) );

        Работает для F1/F3, но не работает для F4 - по окончании передачи флаг EN не сбрасывается 
        автоматически (но сбрасывается автоматически, если разрешено прерывание по окончании передачи)

        Поэтому корректный алгоритм - ждать флага TransferComplete и выключать канал DMA руками

    */

    dmaWaitEvents( DMA2, dmaChannel1, dmaChannelEventTransferComplete );
    //periphEnable( dmaGetChannelAddr( DMA2, dmaChannel1 ), dmaOff );
    dmaEndWaitEvents(DMA2, dmaChannel1);

    lout<<"Transfer complete\n";
    lout<<"Src: "; dump(arraySrc)<<"\n";
    lout<<"Dst: "; dump(arrayDst)<<"\n";
    lout<<"Contents equality: "<< (memcmp( arraySrc, arrayDst, sizeof(refArray1) )==0) <<endl;

    //bool periphIsEnabled< DMA_Channel_TypeDef >( DMA_Channel_TypeDef * DMACHx )


    while(true)
    {
    
    }

}



