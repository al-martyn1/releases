#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"


#if !defined(STM32F4_SERIES)
    #error "STM32F4_SERIES not defined"
#endif


#include "periph/dirty/stm32_i2c/i2c_init.h"
#include "periph/dirty/stm32_i2c/i2c_nonblocking.h"
#include "periph/dirty/honeywell.h"




#include "vtx2_config.h"




#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  lout(&charWritter);




static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;


umba::periph::dirty::I2cInitializer i2cInitializer 
    = umba::periph::dirty::I2cInitializer( PSENSOR_I2C
                                         , 100000
                                         , 0x15 // self addr - от балды
                                         , PSENSOR_I2C_SCL_GPIO, PSENSOR_I2C_SCL_GPIO_PIN_NO
                                         , PSENSOR_I2C_SDA_GPIO, PSENSOR_I2C_SDA_GPIO_PIN_NO
                                         );
SoftTimerMillisec i2c2Timer;


double pressureDeltaHoneywell = 0.0;
double atmoPressurePsi = 0;
double honeywellPressureOffsetPsi = 0;
const double pascal2PsiScale = 0.000145038;
const double psi2BarScale    = 0.0689476;


auto honeywellPressureSensorHandler = makeI2cCompletionHandlerGeneric( [&]( bool fFail, I2cPort &argI2c )
                              {
                                  uint8_t addr = argI2c.getBatchPeerAddr();
                                  size_t nReaded = argI2c.getNumBytesReaded();
                                  if (!fFail)
                                  {
                                      //lout<<"I2C done\n";
                                      uint8_t* pBuf = argI2c.getReadBuf();

                                      uint8_t statusBits = pBuf[0] & (0x80 | 0x40);
                                      statusBits >>= 6;
                                      pBuf[0] &= 0x3F;
                                      
                                      switch(statusBits)
                                      {
                                          case 0:
                                               lout<<"Normal operation, valid data\n";
                                               break;
                                          case 1:
                                               lout<<"Device in command mode\n";
                                               break;
                                          case 2:
                                               lout<<"Data that has already been fetched since the last measurement cycle\n";
                                               break;
                                          case 3:
                                               lout<<"Diagnostic condition\n";
                                               break;
                                      }

                                      uint16_t pressure    = umba::bits::makeIntFromBytesBE<uint16_t>(&pBuf[0]);
                                      lout<<"Raw pressure: "<<pressure<<"\n";
                                      //uint16_t temperature = bits::makeIntFromBytesBE<uint16_t>(&pBuf[2]);
                                      //temperature>>=5;
                                      pressureDeltaHoneywell = honeywellPressureSensor_HSCSSNN001PD2a3_valueConversion(pressure);
                                      pressureDeltaHoneywell -= honeywellPressureOffsetPsi;
                                      if (pressureDeltaHoneywell<0)
                                         pressureDeltaHoneywell = -pressureDeltaHoneywell;
                                      //lout<<"  Pressure: "<<(int)(100000.0*pressureDeltaHoneywell)<<"\n";
                                  }
                                  else
                                  {
                                      //lout<<"I2C failed\n";
                                  }
                              }
                          );


template < typename T >
struct SomeStruct
{
    T     val;
    SomeStruct() : val(0) {}
    SomeStruct(T t) : val(t) {}
};

template < typename T >
inline
SomeStruct<T> makeSomeStruct( T t )
{
    return SomeStruct<T>( t );
}


//---
template<std::size_t N, typename T, typename... types>
struct get_Nth_type
{
    using type = typename get_Nth_type<N - 1, types...>::type;
};

template<typename T, typename... types>
struct get_Nth_type<0, T, types...>
{
    using type = T;
};

template<std::size_t N, typename... Args>
using getVariadicArgsType = typename get_Nth_type<N, Args...>::type;


template<typename... Args>
struct TypeOfArgListHelper
{
    getVariadicArgsType<0, Args...> m_type;
    typedef decltype(m_type) list_item_type;
};


//---

template< typename ArrayItemType, typename SomeStructuredType >
inline
size_t buildSomeStructuredTypeArrayImpl( ArrayItemType *pArrayBuf
                                       , size_t arrayBufSize, size_t itemNo )
{
    return itemNo;
}


template< typename ArrayItemType, typename SomeStructuredType >
inline
size_t buildSomeStructuredTypeArrayImpl( ArrayItemType *pArrayBuf
                                       , size_t arrayBufSize, size_t itemNo
                                       , const SomeStructuredType &s )
{
    if (itemNo>=arrayBufSize)
    {
        //static_assert( itemNo<arrayBufSize, "Error" );
        //lout<<"Buffer overflow\n";
        return itemNo;
    }

    pArrayBuf[itemNo] = s;
    return itemNo+1;
}


template< typename ArrayItemType, typename SomeStructuredType
        , typename... SomeStructuredTypeListItems
        >
inline
size_t buildSomeStructuredTypeArrayImpl( ArrayItemType *pArrayBuf
                                       , size_t arrayBufSize, size_t itemNo
                                       , const SomeStructuredType &s
                                       , SomeStructuredTypeListItems... structs )
{
    if (itemNo>=arrayBufSize)
    {
        //static_assert( itemNo<arrayBufSize, "Error" );
        //lout<<"Buffer overflow\n";
        return itemNo;
    }
    else
    {
        buildSomeStructuredTypeArrayImpl( pArrayBuf, arrayBufSize, itemNo, s );
        return buildSomeStructuredTypeArrayImpl( pArrayBuf, arrayBufSize, itemNo+1, structs... );
    }
}

template< typename ArrayItemType, typename... SomeStructuredTypeListItems
        >
inline
size_t buildSomeStructuredTypeArray( ArrayItemType *pArrayBuf
                                   , size_t arrayBufSize
                                   , SomeStructuredTypeListItems... structs )
{
    return buildSomeStructuredTypeArrayImpl( pArrayBuf, arrayBufSize, (size_t)0, structs... );
}

template< typename... SomeStructuredTypeListItems
        >
inline
void printSomeStructuredTypeArgs( SomeStructuredTypeListItems... structs )
{
    //SomeStructuredTypeListItems buf[10];
    //typename 
    getVariadicArgsType< 0, SomeStructuredTypeListItems... > buf[10];

    //typename TypeOfArgListHelper< structs... > :: list_item_type buf[10];

    size_t sz = buildSomeStructuredTypeArray( buf, 10, structs... );

    lout<<"size: "<<sz<<"\n";

    for( size_t i = 0; i!=sz; ++i )
    {
        lout<<buf[i].val<<"\n";
    }
}






//template < typename TPeriph, typename TPinFunction, typename TPinAltFnInfo = PinAltFunctionInfo<TPinFunction> >
//void periphAltFunctionsConfigure( TPeriph *pPeriph, size_t numPins,  )



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;
/*    
    I2C1->CCR = 0;
#define I2C1                ((I2C_TypeDef *) I2C1_BASE)
#define I2C2                ((I2C_TypeDef *) I2C2_BASE)
#define I2C3                ((I2C_TypeDef *) I2C3_BASE)
*/
    
    #if 0
    DEBUG_TERMINAL_LEGACY_UART.init( uart::RxPins::UART6_PC7, uart::TxPins::UART6_PC6 
                                   , 460800 );       
    #else
    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );
    #endif

    umba::time_service::delayMs(300);

    lout<<"Starting\n";

    printSomeStructuredTypeArgs( makeSomeStruct( 3 ), makeSomeStruct( 5 ), makeSomeStruct( 6 ) );

    //umba::time_service::delayMs(1000);

    I2cPort i2c;
    i2c.init( PSENSOR_I2C, &i2cInitializer , &i2c2Timer, 2, 2 ); // 2msec both timeouts

    // PSensor HSCSSNN001PD2A3 - I2C addr - 0x28
    
    uint8_t psensorDataBuf[2] = { 0, 0 };

    I2cBatchListEntry i2cPSensorBatch[] = { 
                                             // Honeywell pressure sensor
                                             { I2cBatchListEntry::READ, I2cBatchListEntry::SIMPLE,
                                                   0x28, &psensorDataBuf[0], 2, &honeywellPressureSensorHandler }
                                          , { I2cBatchListEntry::LISTEND }
    };



    I2cBatchListWorker i2cBatchListWorker = I2cBatchListWorker( i2c, &i2cPSensorBatch[0] );

    //i2cBatchListWorker.setBatchList(i2cPSensorBatch);

    unsigned n = 0;
    while(1)
    {
        //lout<<"Running\n";
        //umba::time_service::delayMs(1000);

        i2cBatchListWorker.performBatchStep();
        //if (sensorPollDelay.isTimedOut())
        {
            if (i2cBatchListWorker.isDone())
            {
                umba::time_service::delayMs(5);
                i2cBatchListWorker.startBatch();
                //sensorPollDelay.reset();
            }
        }
        
        double pressureDeltaHoneywellBar = psi2BarScale * pressureDeltaHoneywell;
        lout<<umba::omanip::width(6)<<n<<"  Pressure: "<<(1000.0*pressureDeltaHoneywellBar)<<"\n";

        n++;

    }

    return 0;
}




