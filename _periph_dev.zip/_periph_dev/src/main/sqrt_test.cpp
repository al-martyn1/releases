/* Вычисление целочисленного корня

See doc/sqrt_*.txt for details

Summary: 

Win64 - with uint64_t SqrtKarmak wins x1.4 over CRT sqrt function

F1    - up to 1000    - SqrtBub2: x7  , SqrtGeron2: x3.5
        up to 10000   - SqrtBub2: x5.0, SqrtGeron2: x3.8
        up to 100000  - SqrtBub2: x4.9, SqrtGeron2: x4.0
        up to 1000000 - SqrtBub2: x4.9, SqrtGeron2: x4.1

F3    - up to 1000    - SqrtBub2: x2.5, SqrtGeron2: x2.5
        up to 10000   - SqrtBub2: x3.5, SqrtGeron2: x3.8
        up to 100000  - SqrtBub2: x3.3, SqrtGeron2: x3.9
        up to 1000000 - SqrtBub2: x3.2, SqrtGeron2: x3.9

F4    - up to 10000     - SqrtBub2: x5.0, SqrtGeron2: x3.0
        up to 100000    - SqrtBub2: x3.8, SqrtGeron2: x3.0
        up to 1000000   - SqrtBub2: x3.6, SqrtGeron2: x3.0
        up to 10000000  - SqrtBub2: x3.4, SqrtGeron2: x3.2
        up to 100000000 - SqrtBub2: x3.4, SqrtGeron2: x3.2



*/


#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
#include "umba/hr_counter.h"


extern umba::SimpleFormatter  lout;

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"

#include "periph/stm32_discovery.h"

#include "sqrt.h"



using namespace umba::time_service;
using namespace umba::periph::traits;
using namespace umba::omanip;


//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::LegacyUartCharWriter<255>   charWritter = umba::LegacyUartCharWriter<255>( STM32_DISCOVERY_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);

struct SquareTestResult
{
    uint64_t    sqrtSum;
    TimeTick    ticksElapsed;
};

template< typename IntegralType, typename Testable >
inline
SquareTestResult squareTest( IntegralType nMax, const char*fnName, Testable fn, SquareTestResult et )
{
    //platform::tick_t startTick = platform::getTickCount();
    //umba::hr_counter::HiResTick startTick = umba::hr_counter::getTick();
    TimeTick startTick = getCurTimeMs();

    SquareTestResult res = { 0, 0 };

    res.sqrtSum = 0;
    for( uint64_t n = 1; n!= nMax/* 100000000 */ ; ++n )
    {
        res.sqrtSum += fn(n);
    }

    res.ticksElapsed = getCurTimeMs()-startTick;
    lout<<fnName<<": "<<width(12)<<res.sqrtSum<<"  "; // "           "<< width(6) << (res.ticksElapsed) <<" ms";
    if (et.sqrtSum!=0)
    {
        int64_t percent = (int64_t)(100*res.sqrtSum/et.sqrtSum);
        int64_t accuracy = 100 - percent;
        if (accuracy<0)
            accuracy = -accuracy;

        lout<<"    "<<width(4)<< accuracy << "%";
    }
    else
    {
        lout<<"       - ";
    }

    lout<<"      "<< width(6) << (res.ticksElapsed) <<" ms";

    if (res.ticksElapsed && et.ticksElapsed)
    {
        lout<<"     x"<<fixed<<width(4)<<precision(1)<<((double)et.ticksElapsed)/ ((double)res.ticksElapsed)<<"";
    }
    else
    {
    }

    lout<<"\n";

    return res;

}


template< typename IntegralType, typename Testable >
inline
void testIvan( IntegralType nMax, const char* fnName, Testable fn )
{
    lout<<"---\ntestIvan of "<<fnName<<" with "<<nMax<<" iterations"<<endl;

    unsigned errCnt = 0;

    for( IntegralType i = 1; i != nMax; i++ )
    {
        for( IntegralType j = 1; j != nMax; j++ )
        {
            IntegralType sq = i*i + j*j;
        
            IntegralType sqr = fn(sq);
            if( ( i > sqr ) || ( j > sqr ) )
            {
	            lout<<"problem at i = " << i << " j = " << j << " sqrt = " << sqrt((double)sq) << " table = " << sqr << endl;
                ++errCnt;
            }
        }
    }

    lout<<"testIvan - done, errors: "<<errCnt<<endl;

}



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();

    STM32_DISCOVERY_LEGACY_UART.init( STM32_DISCOVERY_UART_RX_GPIO,  STM32_DISCOVERY_UART_RX_GPIO_PIN_NO, STM32_DISCOVERY_UART_TX_GPIO, STM32_DISCOVERY_UART_TX_GPIO_PIN_NO, 460800 );


    lout<<"-----------------\nHello sqrt_test on "<<STM32_DISCOVERY_NAME<<endl;
/*
    lout<<"\n";
    lout<<"Num of iterations: "<<100000000<<"\n";
    lout<<"Name                   Sum of squares    Time elapsed"<<"\n";
    squareTest<size_t>( 100000000, "SqrtGeneric          ", SqrtGeneric          <size_t>() );
    squareTest<size_t>( 100000000, "SqrtGeron1           ", SqrtGeron1           <size_t>() );
    squareTest<size_t>( 100000000, "SqrtGeron2           ", SqrtGeron2           <size_t>() );
    squareTest<size_t>( 100000000, "SqrtKarmak           ", SqrtKarmak           <size_t>() );
    squareTest<size_t>( 100000000, "UnknownUnsignedSqrt1 ", UnknownUnsignedSqrt1 <size_t>() );
    squareTest<size_t>( 100000000, "UnknownUnsignedSqrt2 ", UnknownUnsignedSqrt2 <size_t>() );
    squareTest<size_t>( 100000000, "UnknownUnsignedSqrt3 ", UnknownUnsignedSqrt3 <size_t>() );
    squareTest<size_t>( 100000000, "SqrtGeronAccurate    ", SqrtGeronAccurate    <size_t>() );
    squareTest<size_t>( 100000000, "SqrtCrt              ", SqrtCrt              <size_t>() );
*/

    #ifdef STM32F4_SERIES
    #if 0
    uint32_t testivanNum = 10000;
    testIvan<size_t>( testivanNum , "SqrtCrt"              , SqrtCrt              <size_t>() );
    //testIvan<size_t>( testivanNum , "SqrtGeneric"          , SqrtGeneric          <size_t>() );
    //testIvan<size_t>( testivanNum , "SqrtGeron1"           , SqrtGeron1           <size_t>() );
    testIvan<size_t>( testivanNum , "SqrtGeron2"           , SqrtGeron2           <size_t>() );
    testIvan<size_t>( testivanNum , "SqrtKarmak"           , SqrtKarmak           <size_t>() );
    //testIvan<size_t>( testivanNum , "UnknownUnsignedSqrt1" , UnknownUnsignedSqrt1 <size_t>() );
    testIvan<size_t>( testivanNum , "UnknownUnsignedSqrt2" , UnknownUnsignedSqrt2 <size_t>() );
    testIvan<size_t>( testivanNum , "UnknownUnsignedSqrt3" , UnknownUnsignedSqrt3 <size_t>() );
    //testIvan<size_t>( testivanNum , "SqrtGeronAccurate"    , SqrtGeronAccurate    <size_t>() );
    //testIvan<size_t>( testivanNum , "SqrtBub"              , SqrtBub              <size_t>() );
    testIvan<size_t>( testivanNum , "SqrtBub2"             , SqrtBub2             <size_t>() );

    //while(1);
    #endif
    #endif

    #if 0
    for(uint32_t i = 0; i!=256; ++i)
    {
        lout << i << "  " << SqrtCrt<uint32_t>()( i ) << "  " << SqrtGeron2<uint32_t>()(i) << endl;
    }

    //while(1);
    #endif

    uint32_t numIters[] = {         5
                          ,        10
                          ,        20
                          ,        30
                          ,        50
                          ,       100
                          ,       200
                          ,       300
                          ,       500
                          ,      1000
                          ,      2000
                          ,      3000
                          ,      5000
                          ,     10000
                          ,     20000
                          ,     30000
                          ,     50000
                          ,    100000
                          ,    200000
                          ,    300000
                          ,    400000
                          ,    500000
                          ,    600000
                          ,    700000
                          ,    800000
                          ,    900000
                          ,   1000000
                          // на быстром камешке посмотрим, как разные методы ведут себя в плане точности
                          #ifdef STM32F4_SERIES
                          //,   1500000
                          ,   2000000
                          //,   2500000
                          ,   3000000
                          //,   3500000
                          ,   4000000
                          //,   4500000
                          ,   5000000
                          ,  10000000
                          ,  20000000
                          //,  50000000
                          , 100000000
                          //, 500000000
                          //,1000000000
                          //,5000000000
                          #endif
                          };
    size_t idx = 0;
    for( ; idx!=(sizeof(numIters)/sizeof(numIters[0])); ++idx)
    {
        lout<<"\n";
        lout<<"Num of iterations: "<<numIters[idx]<<"\n";
        lout<<"Name                   Sum of squares   Accuracy   Time elapsed   Speed"<<"\n";
        SquareTestResult et = 
        squareTest<size_t>( numIters[idx] , "SqrtCrt              ", SqrtCrt              <size_t>(), SquareTestResult{0,0}  );
        squareTest<size_t>( numIters[idx] , "SqrtGeneric          ", SqrtGeneric          <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "SqrtGeron1           ", SqrtGeron1           <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "SqrtGeron2           ", SqrtGeron2           <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "SqrtKarmak           ", SqrtKarmak           <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "UnknownUnsignedSqrt1 ", UnknownUnsignedSqrt1 <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "UnknownUnsignedSqrt2 ", UnknownUnsignedSqrt2 <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "UnknownUnsignedSqrt3 ", UnknownUnsignedSqrt3 <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "SqrtGeronAccurate    ", SqrtGeronAccurate    <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "SqrtBub              ", SqrtBub              <size_t>(), et );
        squareTest<size_t>( numIters[idx] , "SqrtBub2             ", SqrtBub2             <size_t>(), et );
    }

/*
    uint32_t nmIters = 10000000;

    lout<<"\n";
    lout<<"Num of iterations: "<<10000000<<"\n";
    lout<<"Name                   Sum of squares    Time elapsed"<<"\n";
    squareTest<size_t>( 10000000 , "SqrtGeneric          ", SqrtGeneric          <size_t>() );
    squareTest<size_t>( 10000000 , "SqrtGeron1           ", SqrtGeron1           <size_t>() );
    squareTest<size_t>( 10000000 , "SqrtGeron2           ", SqrtGeron2           <size_t>() );
    squareTest<size_t>( 10000000 , "SqrtKarmak           ", SqrtKarmak           <size_t>() );
    squareTest<size_t>( 10000000 , "UnknownUnsignedSqrt1 ", UnknownUnsignedSqrt1 <size_t>() );
    squareTest<size_t>( 10000000 , "UnknownUnsignedSqrt2 ", UnknownUnsignedSqrt2 <size_t>() );
    squareTest<size_t>( 10000000 , "UnknownUnsignedSqrt3 ", UnknownUnsignedSqrt3 <size_t>() );
    squareTest<size_t>( 10000000 , "SqrtGeronAccurate    ", SqrtGeronAccurate    <size_t>() );
    squareTest<size_t>( 10000000 , "SqrtBub              ", SqrtBub              <size_t>() );
    squareTest<size_t>( 10000000 , "SqrtCrt              ", SqrtCrt              <size_t>() );

    lout<<"\n";
    lout<<"Num of iterations: "<<1000000<<"\n";
    lout<<"Name                   Sum of squares    Time elapsed"<<"\n";
    squareTest<size_t>( 1000000  , "SqrtGeneric          ", SqrtGeneric          <size_t>() );
    squareTest<size_t>( 1000000  , "SqrtGeron1           ", SqrtGeron1           <size_t>() );
    squareTest<size_t>( 1000000  , "SqrtGeron2           ", SqrtGeron2           <size_t>() );
    squareTest<size_t>( 1000000  , "SqrtKarmak           ", SqrtKarmak           <size_t>() );
    squareTest<size_t>( 1000000  , "UnknownUnsignedSqrt1 ", UnknownUnsignedSqrt1 <size_t>() );
    squareTest<size_t>( 1000000  , "UnknownUnsignedSqrt2 ", UnknownUnsignedSqrt2 <size_t>() );
    squareTest<size_t>( 1000000  , "UnknownUnsignedSqrt3 ", UnknownUnsignedSqrt3 <size_t>() );
    squareTest<size_t>( 1000000  , "SqrtGeronAccurate    ", SqrtGeronAccurate    <size_t>() );
    squareTest<size_t>( 1000000  , "SqrtBub              ", SqrtBub              <size_t>() );
    squareTest<size_t>( 1000000  , "SqrtCrt              ", SqrtCrt              <size_t>() );

    lout<<"\n";
    lout<<"Num of iterations: "<<100000<<"\n";
    lout<<"Name                   Sum of squares    Time elapsed"<<"\n";
    squareTest<size_t>( 100000   , "SqrtGeneric          ", SqrtGeneric          <size_t>() );
    squareTest<size_t>( 100000   , "SqrtGeron1           ", SqrtGeron1           <size_t>() );
    squareTest<size_t>( 100000   , "SqrtGeron2           ", SqrtGeron2           <size_t>() );
    squareTest<size_t>( 100000   , "SqrtKarmak           ", SqrtKarmak           <size_t>() );
    squareTest<size_t>( 100000   , "UnknownUnsignedSqrt1 ", UnknownUnsignedSqrt1 <size_t>() );
    squareTest<size_t>( 100000   , "UnknownUnsignedSqrt2 ", UnknownUnsignedSqrt2 <size_t>() );
    squareTest<size_t>( 100000   , "UnknownUnsignedSqrt3 ", UnknownUnsignedSqrt3 <size_t>() );
    squareTest<size_t>( 100000   , "SqrtGeronAccurate    ", SqrtGeronAccurate    <size_t>() );
    squareTest<size_t>( 100000   , "SqrtBub              ", SqrtBub              <size_t>() );
    squareTest<size_t>( 100000   , "SqrtCrt              ", SqrtCrt              <size_t>() );
*/

    lout<<"\n\nDone"<<endl;

    while(1);

}

