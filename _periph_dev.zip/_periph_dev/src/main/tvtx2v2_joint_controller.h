#pragma once

#include "vtx2v2/telexertex2_slaves.h"
#include <utility>

//#define JOINT_MEMBERS_FOR_IGOR

namespace Televertex2
{


struct JointControllerBase
{

    // Состояние
    uint16_t    ro_currentAngle      ; // ro::current_angle_u16
    uint8_t     ro_stateCounter      ; // ro::state_counter_u8
    uint16_t    ro_negativeAngleLimit; // ro::negative_angle_limit_u16
    uint16_t    ro_positiveAngleLimit; // ro::positive_angle_limit_u16
    uint8_t     ro_noMovementFlag    ; // ro::no_movement_flag_u8
    
    // управление
    uint16_t    rw_targetAngle       = 0; // rw::target_angle_u16
    int8_t      rw_speed             = 0; // rw::speed_s8
    uint8_t     rw_modeCtrl          = 0; // rw::mode_ctrl_u8
    uint8_t     rw_noMovementPeriod  = 0; // rw::no_movement_period_u8

    #ifdef JOINT_MEMBERS_FOR_IGOR
    // то что по шине пробегало - для Игоря
    uint16_t    master_targetAngle       = 0; // rw::target_angle_u16
    int8_t      master_speed             = 0; // rw::speed_s8
    uint8_t     master_modeCtrl          = 0; // rw::mode_ctrl_u8
    uint8_t     master_noMovementPeriod  = 0; // rw::no_movement_period_u8
    #endif

    int16_t     iMinAngle             = 0;
    int16_t     iMaxAngle             = 0;
    int16_t     iCurAngle             = 0;
    int16_t     rw_targetAngleInput   = 0; // нескорректированный угол от минус мина до плюс макса

    bool isBusy() const
    {
        return ro_stateCounter&1 ? true : false;
    }

    int16_t angleDiff( int16_t a1, int16_t a2 ) const
    {
        int16_t d = a1-a2;
        if (d<0)
            return -d;

        return d;
    }

    bool isTargetReached( int16_t targetAngle, int16_t currentAngle ) const
    {
        int16_t delta = angleDiff( currentAngle, targetAngle );
        return delta < 2;
    }

    bool isTargetReached( int16_t targetAngle ) const
    {
        return isTargetReached( targetAngle, iCurAngle );
    }



    bool isTargetReached( ) const
    {
        return isTargetReached( rw_targetAngleInput );
    }

    virtual void poll() = 0;

protected:

    uint16_t recalcTargetAngle( int16_t a )
    {
        if (m_needCorrection)
        {
            return (uint16_t)((int16_t)m_zeroPoint - rw_targetAngleInput);
            //return ro_positiveAngleLimit - a;
        }
        else
        {
            return (uint16_t)((int16_t)m_zeroPoint + rw_targetAngleInput);
            //return a + ro_negativeAngleLimit;
        }
    }


    uint16_t    m_shadow_rw_targetAngle       = 0;
    int8_t      m_shadow_rw_speed             = 0;
    uint8_t     m_shadow_rw_modeCtrl          = 0; // Режим движения - 0 - Неподвижность, 1 - Скорость, 2 - Позиция, 3 - Движение в 0 (см. тип JointMode в vertex_types.rdl)
    uint8_t     m_shadow_rw_noMovementPeriod  = 0;

    uint16_t    m_zeroPoint = 0; // нужно задать

    bool        m_needCorrection             = false;
    int16_t     m_shadow_rw_targetAngleInput = 0;

}; // JointControllerBase


template<typename JointType>
struct JointController : public JointControllerBase
{
    JointController(JointType *pJoint, uint16_t zeroPoint, bool needCorrection = false )
    : m_pJoint(pJoint)
    {
        m_needCorrection = needCorrection;
        m_zeroPoint      = zeroPoint;
    }

    virtual
    void poll() override
    {
        using namespace regs::Joint;

        ro_currentAngle       = m_pJoint->roRegs[ ro::current_angle_u16        ];
        ro_stateCounter       = m_pJoint->roRegs[ ro::state_counter_u8         ];
        ro_negativeAngleLimit = m_pJoint->roRegs[ ro::negative_angle_limit_u16 ];
        ro_positiveAngleLimit = m_pJoint->roRegs[ ro::positive_angle_limit_u16 ];
        ro_noMovementFlag     = m_pJoint->roRegs[ ro::no_movement_flag_u8      ];

        #ifdef JOINT_MEMBERS_FOR_IGOR
        master_targetAngle       = m_pJoint->rwRegs[ rw::target_angle_u16 ]; // rw::target_angle_u16
        master_speed             = m_pJoint->rwRegs[ rw::speed_s8 ]; // rw::speed_s8
        master_modeCtrl          = m_pJoint->rwRegs[ rw::mode_ctrl_u8 ]; // rw::mode_ctrl_u8
        master_noMovementPeriod  = m_pJoint->rwRegs[ rw::no_movement_period_u8 ]; // rw::no_movement_period_u8
        #endif

        iMinAngle                = (int16_t)ro_negativeAngleLimit - (int16_t)m_zeroPoint;
        iMaxAngle                = (int16_t)ro_positiveAngleLimit - (int16_t)m_zeroPoint;
        iCurAngle                = (int16_t)ro_currentAngle - (int16_t)m_zeroPoint;

        if (m_shadow_rw_targetAngleInput!=rw_targetAngleInput)
        {
            m_shadow_rw_targetAngleInput = rw_targetAngleInput;
            rw_targetAngle = recalcTargetAngle( rw_targetAngleInput );
        }
        

        if ( m_shadow_rw_targetAngle                != rw_targetAngle )
        {
            m_shadow_rw_targetAngle                  = rw_targetAngle;
            m_pJoint->rwRegs[ rw::target_angle_u16 ] = rw_targetAngle;
        }

        if ( m_shadow_rw_speed              != rw_speed )
        {
            m_shadow_rw_speed                = rw_speed;
            m_pJoint->rwRegs[ rw::speed_s8 ] = rw_speed;
        }

        if ( m_shadow_rw_modeCtrl               != rw_modeCtrl )
        {
            m_shadow_rw_modeCtrl                 = rw_modeCtrl;
            m_pJoint->rwRegs[ rw::mode_ctrl_u8 ] = rw_modeCtrl;
        }

        if ( m_shadow_rw_noMovementPeriod                != rw_noMovementPeriod )
        {
            m_shadow_rw_noMovementPeriod                  = rw_noMovementPeriod;
            m_pJoint->rwRegs[ rw::no_movement_period_u8 ] = rw_noMovementPeriod;
        }

    }

protected:

    JointType  *m_pJoint                   ;

}; // JointController


template<typename JointType>
inline
JointController<JointType> makeJointController( JointType *pJoint, uint16_t zeroPoint, bool needCorrection = false )
{
    return JointController<JointType>( pJoint, zeroPoint, needCorrection );
}


} // namespace Televertex2



//----------------------------------------------------------
enum class ActiveJointFailState
{
    ok,
    unknown // general error
};



class ActiveJointController : public umba::ITimerHandler               // for timers
                            , public umba::IPollCapable                // для полировки
{

    typedef umba::time_service::TimeTick TimeTick;


public:

    UMBA_BEGIN_INTERFACE_MAP_EX( umba::ITimerHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::IPollCapable )
    UMBA_END_INTERFACE_MAP()

    UMBA_DELEGATE_QUERY_INTERFACE(umba::ITimerHandler)


    ActiveJointController( Televertex2::JointControllerBase *pJointController
                         , uint16_t jointSpeed          // сколько сустав может выжать, в попугаях в секунду, задается сверху при инициализации
                         , uint8_t jointSpeedMinPercent // минимальная скорость для данного сустава, в процентах от максимума. Снеё он будет стартовать. Задается сверху при инициализации
                         )
    : m_pJointController(pJointController)
    , m_jointSpeed(m_jointSpeed)           
    , m_jointSpeedMinPercent(m_jointSpeedMinPercent) 
    {}

    // Установка в систему
    bool install()
    {
       //timerSet(  /* umba::rtkos::TimerEventId */ 0, 15 );
        return umba::rtkos::pollScheduleAdd( this, umba::rtkos::PollPriority::normal );
    }

    bool isMotorBusy() const
    {
        return m_pJointController->isBusy();
    }

    bool isBusy() const
    {
        return m_isStarted;
    }

    bool isFailed() const
    {
        return m_failState!=ActiveJointFailState::ok;
    }

    // http://www.keil.com/support/man/docs/uv4/uv4_cm_breakset.htm?_ga=2.117787466.258239130.1565581302-1508115793.1541001193
    // http://www.keil.com/support/man/docs/uv4/uv4_db_expressions.htm
    // _break_=(_RWORD(0x3e78)==0x0010105B )
    // BS WRITE 0x20000DB6, 1, cnt , "cmd"
    void restart( )
    {
    }


protected:

    template<typename T>
    bool isInRange( T val, T n, T x)
    {
        if (x < n)
           std::swap( x, n );

        return val >= n && val <= x ;
    }

    umba::rtkos::TimerId timerSet( umba::rtkos::TimerEventId eventId, umba::rtkos::TimeTick period )
    {
        return umba::rtkos::timerSet( this, eventId, period );
    }

    virtual
    bool isReadyForPoll() override 
    {
        return true;
    }

    virtual
    void poll() override
    {
        m_pJointController->poll();

        m_curAngle = m_pJointController->iCurAngle;

        if (!m_isStarted)
        {
            if (m_targetAngleShadow != m_targetAngle)
            {
                m_targetAngleShadow = m_targetAngle;
                start( m_targetAngle );
            }
        }
    }


    int16_t getDistanceToEnd() const
    {
        //int16_t d = m_phaseTargets[numPhases-1] - m_curAngle;
        //return d<0 ? -d : d;
        return 0;
    }
    

public:

    void start( int16_t targetAngle, bool useMaxPower = false )
    {

        m_startTick               = umba::time_service::getCurTimeMs();;
        m_lastDistanceUpdateTick  = m_startTick;
        m_lastDistance            = 0; // set to max here

    }


protected:

    void doJob()
    {
        m_pJointController->poll();

        if (!m_isStarted)
            return;

        if (m_moveToZero)
            return;

        if (m_savedJountStateCounter==m_pJointController->ro_stateCounter)
        {
            // Тут проверить, как долго он тупит, и вывалиться по ошибке
            return; // motor еще не стартовал
        }


        // m_pJointController->isBusy()

        /* 
            
            Быстрый шарнир делает примерно 128 попугаев в секунду на максимальной скорости, 
            и, соответственно, 12 попугаев на минимальноё 10ти процентной скорости
            Медленный - допустим, в 4 раз медленнее.

            Итого минимальная скорость - 3 попугая в секунду

            Время, за которое сустав должен изменить позицию на 1 (0.3516 градуса) - нужно высчитать.

            Надо задавать для сустава максимальную скорость в попугаях в секунду, и высчитывать величину 
            таймаута на изменение позиции.
            Для 128 пг/сек этот таймаут равен 1000/128 - 7.8125 мс/пг
            На всякий случай скорость делим на 2 - в плохих положениях, под большой нагрузкой, 
            возможно более медленное движение. И учитываем текущую заданную (в процентах) скорость.
            Для макс 128пг/сек при 40% скорости:
                128.2 = 64
                64*50/100 = 32
                1000/32 = 31 мс


            На каждом цикле нам нужно определять дистанцию до целевой точки.

            Нужно просчитать величину таймаута от предыдущего считывания позиции на основании текущей скорости.
            Если дистанцию проверяли слишком давно, то нужно добавить газку

            Если предыдущая дистанция равна или меньше текущей - то стоим или даже сдвинулись назад.
            Нужно увеличивать мощность (на 15%).
            Если мощность достигла максималочки, то стартануть с минималки, и увеличить счетчик рестарта с минималкой.
            Если счетчик рестарта достиг лимита, то нужно остановить мотор, послав команду 0, и дождаться его останова

            Ускорение, которое гарантирует плавный старт и вызывает минимальное возмущение.

            45/0.3516 = 127.98
            Нулевой угол - 312, 312+128 = 440 (0x1B8 - 0xB8 0x01)

            86/0.3516 = 244.59 (лимит - 560, поэтому не берем 90)
            Нулевой угол - 312, 312+245 = 557 (0x22D - 0x2D 0x02, а лучше - 0x20 0x02)

            Эмпирически кажется, что если бы полной скорости мы достигли бы на половине пути, то было бы гораздо лучше.
            Условно говоря, на разгон есть полсекунды. 
            
            Формула увеличения скорости для обработчика таймера = Vt = (t -t0)*a, где a=2 для полусекундного разгона

            Окончание движения. 



        
         */


        //-------------------
        //if (m_pJointController->isTargetReached())

    }

    virtual
    void onTimer( unsigned eventId ) override
    {
        doJob();
    }

    int16_t       m_targetAngle     = 0; // для управления из отладчика.
    int16_t       m_curAngle        = 0; // обновляется мотором
    int16_t       m_fixedStartAngle = 0; // зафиксированный при старте текущий угол

    int16_t       m_targetAngleShadow = 0; // теневик для управления из отладчика


    uint16_t      m_jointSpeed;           // сколько сустав может выжать, в попугаях в секунду, задается сверху при инициализации
    uint8_t       m_jointSpeedMinPercent; // минимальная скорость для данного сустава, в процентах от максимума. Снеё он будет стартовать. Задается сверху при инициализации


    volatile bool m_isStarted   = false;
    ActiveJointFailState   m_failState    = ActiveJointFailState::ok;

    bool          m_moveToZero  = false;
    uint8_t       m_powerRestartCounter = 0;

    uint8_t       m_savedJountStateCounter; // сохраняем текущий счетчик сустава, по нему определякем - стартанул ли, и остановился ли


    uint8_t       m_curStateCounter; // Это наш счетчик состояния

    uint8_t       m_curPower;

    TimeTick      m_startTick;
    TimeTick      m_lastDistanceUpdateTick;

    uint16_t      m_lastDistance;


    Televertex2::JointControllerBase *m_pJointController;

};



