#include "luart/uart_handle.h"
#include "umba/time_service.h"

#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/allocator.h"
#include <vector>


#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>(uart::uart3).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  fmt(&charWritter);





static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;



int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;
   
    
    uart::uart3.init( uart::Pins::UART3_PB10_PB11, 460800 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 307200 );
    //uart::uart3.init( uart::Pins::UART3_PB10_PB11, 691200 );

    umba::time_service::HiresTimeTick prevHr = 0;
    while(1)
    {
        //umba::time_service::delayMs(1);
        using namespace umba::omanip;
        umba::time_service::TimeTick tickHi, tickLo, tickMod;
        umba::time_service::getCurTimeHiresRaw( &tickHi, &tickLo, &tickMod );
        //umba::time_service::HiresTimeTick hrTick = umba::time_service::calcCurTimeHires( tickHi, tickLo, tickMod );
        umba::time_service::HiresTimeTick hr1 = umba::time_service::getCurTimeHires();
        umba::time_service::HiresTimeTick hr2 = umba::time_service::getCurTimeHires();

        fmt<<"Cur tick: "<<width(8)<<hr1<<" usec,  Next time call: "<<width(8)<<hr2
           <<" usec,  Diff: "<<width(4)<<(hr2-hr1)<<" usec,  Long tick: "<<width(6)<<umba::time_service::getCurTimeMs()
           <<" ms,  Ellapsed from prev: "<<width(6)<<(hr1-prevHr)<<" usec\n";
        prevHr = hr1;
        //fmt<<"Cur tick: "<<width(8)<<umba::time_service::getCurTimeHires()<<", tickHi: "<<width(6)<<tickHi<<", tickLo: "<<width(6)<<tickLo
        //   <<", tickMod: "<<width(6)<<tickMod<<", hrTick: "<<width(8)<<hrTick<<width(6)<<", MS tick: "<<umba::time_service::getCurTimeMs()
        //   <<", hr1: "<<hr1<<", h2: "<<hr2<<", diff: "<<(hr2-hr1)<<"\n";
    }

    return 0;
}



/*

Размер буфера UartWritter'а - 128 байт
Скорость UART - 460800 бод - ~41890 байт/сек
Строка - 130 байт длиной

Время выполнения кода вывода: ~300мкс

Ellapsed from prev:    276 usec
Ellapsed from prev:    312 usec
Ellapsed from prev:    292 usec
Ellapsed from prev:    297 usec
Ellapsed from prev:    304 usec
Ellapsed from prev:    301 usec
Ellapsed from prev:    305 usec
Ellapsed from prev:    304 usec

Время отсылки: ~3000 - 300 = 2700мкс
Cur tick:     3284 usec,  Next time call:     3288 usec,  Diff:    4 usec,  Long tick:      3 ms,  Ellapsed from prev:   2975 usec
Cur tick:     6370 usec,  Next time call:     6376 usec,  Diff:    6 usec,  Long tick:      6 ms,  Ellapsed from prev:   3086 usec
Cur tick:     9445 usec,  Next time call:     9452 usec,  Diff:    7 usec,  Long tick:      9 ms,  Ellapsed from prev:   3075 usec
Cur tick:    12559 usec,  Next time call:    12563 usec,  Diff:    4 usec,  Long tick:     12 ms,  Ellapsed from prev:   3114 usec
Cur tick:    15634 usec,  Next time call:    15638 usec,  Diff:    4 usec,  Long tick:     15 ms,  Ellapsed from prev:   3075 usec
Cur tick:    18709 usec,  Next time call:    18713 usec,  Diff:    4 usec,  Long tick:     18 ms,  Ellapsed from prev:   3075 usec
Cur tick:    21787 usec,  Next time call:    21793 usec,  Diff:    6 usec,  Long tick:     22 ms,  Ellapsed from prev:   3078 usec

1000/3.075 = 325.2 раз в секунду отсылается строка
325.2*130  = 42276 байт в секунду реально передается




Cur tick:       28 usec,  Next time call:       32 usec,  Diff:    4 usec,  Long tick:      0 ms,  Ellapsed from prev:     28 usec
Cur tick:      309 usec,  Next time call:      313 usec,  Diff:    4 usec,  Long tick:      0 ms,  Ellapsed from prev:    281 usec
Cur tick:     3284 usec,  Next time call:     3288 usec,  Diff:    4 usec,  Long tick:      3 ms,  Ellapsed from prev:   2975 usec
Cur tick:     6370 usec,  Next time call:     6376 usec,  Diff:    6 usec,  Long tick:      6 ms,  Ellapsed from prev:   3086 usec
Cur tick:     9445 usec,  Next time call:     9452 usec,  Diff:    7 usec,  Long tick:      9 ms,  Ellapsed from prev:   3075 usec
Cur tick:    12559 usec,  Next time call:    12563 usec,  Diff:    4 usec,  Long tick:     12 ms,  Ellapsed from prev:   3114 usec
Cur tick:    15634 usec,  Next time call:    15638 usec,  Diff:    4 usec,  Long tick:     15 ms,  Ellapsed from prev:   3075 usec
Cur tick:    18709 usec,  Next time call:    18713 usec,  Diff:    4 usec,  Long tick:     18 ms,  Ellapsed from prev:   3075 usec
Cur tick:    21787 usec,  Next time call:    21793 usec,  Diff:    6 usec,  Long tick:     22 ms,  Ellapsed from prev:   3078 usec
Cur tick:    24866 usec,  Next time call:    24870 usec,  Diff:    4 usec,  Long tick:     25 ms,  Ellapsed from prev:   3079 usec
Cur tick:    27942 usec,  Next time call:    27946 usec,  Diff:    4 usec,  Long tick:     28 ms,  Ellapsed from prev:   3076 usec
Cur tick:    31028 usec,  Next time call:    31032 usec,  Diff:    4 usec,  Long tick:     31 ms,  Ellapsed from prev:   3086 usec
Cur tick:    34104 usec,  Next time call:    34108 usec,  Diff:    4 usec,  Long tick:     37 ms,  Ellapsed from prev:   3076 usec
Cur tick:    37201 usec,  Next time call:    37205 usec,  Diff:    4 usec,  Long tick:     40 ms,  Ellapsed from prev:   3097 usec
Cur tick:    40279 usec,  Next time call:    40285 usec,  Diff:    6 usec,  Long tick:     43 ms,  Ellapsed from prev:   3078 usec
Cur tick:    43357 usec,  Next time call:    43361 usec,  Diff:    4 usec,  Long tick:     46 ms,  Ellapsed from prev:   3078 usec
Cur tick:    46432 usec,  Next time call:    46436 usec,  Diff:    4 usec,  Long tick:     49 ms,  Ellapsed from prev:   3075 usec
Cur tick:    49509 usec,  Next time call:    49513 usec,  Diff:    4 usec,  Long tick:     52 ms,  Ellapsed from prev:   3077 usec
Cur tick:    52595 usec,  Next time call:    52599 usec,  Diff:    4 usec,  Long tick:     55 ms,  Ellapsed from prev:   3086 usec
Cur tick:    55695 usec,  Next time call:    55699 usec,  Diff:    4 usec,  Long tick:     58 ms,  Ellapsed from prev:   3100 usec
Cur tick:    58772 usec,  Next time call:    58778 usec,  Diff:    6 usec,  Long tick:     61 ms,  Ellapsed from prev:   3077 usec
Cur tick:    61852 usec,  Next time call:    61856 usec,  Diff:    4 usec,  Long tick:     64 ms,  Ellapsed from prev:   3080 usec
Cur tick:    64938 usec,  Next time call:    64942 usec,  Diff:    4 usec,  Long tick:     67 ms,  Ellapsed from prev:   3086 usec
Cur tick:    68014 usec,  Next time call:    68018 usec,  Diff:    4 usec,  Long tick:     71 ms,  Ellapsed from prev:   3076 usec
Cur tick:    71134 usec,  Next time call:    71138 usec,  Diff:    4 usec,  Long tick:     74 ms,  Ellapsed from prev:   3120 usec
Cur tick:    74209 usec,  Next time call:    74213 usec,  Diff:    4 usec,  Long tick:     77 ms,  Ellapsed from prev:   3075 usec
Cur tick:    77284 usec,  Next time call:    77288 usec,  Diff:    4 usec,  Long tick:     80 ms,  Ellapsed from prev:   3075 usec
Cur tick:    80362 usec,  Next time call:    80368 usec,  Diff:    6 usec,  Long tick:     83 ms,  Ellapsed from prev:   3078 usec
Cur tick:    83439 usec,  Next time call:    83444 usec,  Diff:    5 usec,  Long tick:     86 ms,  Ellapsed from prev:   3077 usec
Cur tick:    86515 usec,  Next time call:    86519 usec,  Diff:    4 usec,  Long tick:     89 ms,  Ellapsed from prev:   3076 usec
Cur tick:    89602 usec,  Next time call:    89606 usec,  Diff:    4 usec,  Long tick:     92 ms,  Ellapsed from prev:   3087 usec
Cur tick:    92675 usec,  Next time call:    92679 usec,  Diff:    4 usec,  Long tick:     95 ms,  Ellapsed from prev:   3073 usec
Cur tick:    95792 usec,  Next time call:    95796 usec,  Diff:    4 usec,  Long tick:     98 ms,  Ellapsed from prev:   3117 usec
Cur tick:    98867 usec,  Next time call:    98871 usec,  Diff:    4 usec,  Long tick:    101 ms,  Ellapsed from prev:   3075 usec
Cur tick:   104722 usec,  Next time call:   104726 usec,  Diff:    4 usec,  Long tick:    104 ms,  Ellapsed from prev:   5855 usec
Cur tick:   107808 usec,  Next time call:   107815 usec,  Diff:    7 usec,  Long tick:    108 ms,  Ellapsed from prev:   3086 usec
Cur tick:   110883 usec,  Next time call:   110890 usec,  Diff:    7 usec,  Long tick:    111 ms,  Ellapsed from prev:   3075 usec
Cur tick:   113996 usec,  Next time call:   114001 usec,  Diff:    5 usec,  Long tick:    114 ms,  Ellapsed from prev:   3113 usec
Cur tick:   117072 usec,  Next time call:   117076 usec,  Diff:    4 usec,  Long tick:    117 ms,  Ellapsed from prev:   3076 usec
Cur tick:   120147 usec,  Next time call:   120154 usec,  Diff:    7 usec,  Long tick:    120 ms,  Ellapsed from prev:   3075 usec
Cur tick:   123222 usec,  Next time call:   123228 usec,  Diff:    6 usec,  Long tick:    123 ms,  Ellapsed from prev:   3075 usec
Cur tick:   126299 usec,  Next time call:   126303 usec,  Diff:    4 usec,  Long tick:    126 ms,  Ellapsed from prev:   3077 usec
Cur tick:   129374 usec,  Next time call:   129378 usec,  Diff:    4 usec,  Long tick:    129 ms,  Ellapsed from prev:   3075 usec
Cur tick:   132460 usec,  Next time call:   132464 usec,  Diff:    4 usec,  Long tick:    132 ms,  Ellapsed from prev:   3086 usec
Cur tick:   135537 usec,  Next time call:   135541 usec,  Diff:    4 usec,  Long tick:    138 ms,  Ellapsed from prev:   3077 usec
Cur tick:   138633 usec,  Next time call:   138640 usec,  Diff:    7 usec,  Long tick:    141 ms,  Ellapsed from prev:   3096 usec
Cur tick:   141708 usec,  Next time call:   141715 usec,  Diff:    7 usec,  Long tick:    144 ms,  Ellapsed from prev:   3075 usec
Cur tick:   144789 usec,  Next time call:   144793 usec,  Diff:    4 usec,  Long tick:    147 ms,  Ellapsed from prev:   3081 usec




Размер буфера UartWritter'а - 1024 байт - хватает на 3 мс, если срать постоянно


Cur tick:       28 usec,  Next time call:       32 usec,  Diff:    4 usec,  Long tick:      0 ms,  Ellapsed from prev:     28 usec
Cur tick:      304 usec,  Next time call:      308 usec,  Diff:    4 usec,  Long tick:      0 ms,  Ellapsed from prev:    276 usec
Cur tick:      616 usec,  Next time call:      620 usec,  Diff:    4 usec,  Long tick:      0 ms,  Ellapsed from prev:    312 usec
Cur tick:      908 usec,  Next time call:      915 usec,  Diff:    7 usec,  Long tick:      1 ms,  Ellapsed from prev:    292 usec
Cur tick:     1205 usec,  Next time call:     1210 usec,  Diff:    5 usec,  Long tick:      1 ms,  Ellapsed from prev:    297 usec
Cur tick:     1509 usec,  Next time call:     1513 usec,  Diff:    4 usec,  Long tick:      1 ms,  Ellapsed from prev:    304 usec
Cur tick:     1810 usec,  Next time call:     1814 usec,  Diff:    4 usec,  Long tick:      2 ms,  Ellapsed from prev:    301 usec
Cur tick:     2115 usec,  Next time call:     2119 usec,  Diff:    4 usec,  Long tick:      2 ms,  Ellapsed from prev:    305 usec
Cur tick:     2419 usec,  Next time call:     2423 usec,  Diff:    4 usec,  Long tick:      2 ms,  Ellapsed from prev:    304 usec
Cur tick:     3379 usec,  Next time call:     3385 usec,  Diff:    6 usec,  Long tick:      3 ms,  Ellapsed from prev:    960 usec
Cur tick:     3682 usec,  Next time call:     3686 usec,  Diff:    4 usec,  Long tick:      3 ms,  Ellapsed from prev:    303 usec
Cur tick:     9514 usec,  Next time call:     9518 usec,  Diff:    4 usec,  Long tick:      9 ms,  Ellapsed from prev:   5832 usec
Cur tick:     9821 usec,  Next time call:     9826 usec,  Diff:    5 usec,  Long tick:     15 ms,  Ellapsed from prev:    307 usec
Cur tick:    15657 usec,  Next time call:    15661 usec,  Diff:    4 usec,  Long tick:     15 ms,  Ellapsed from prev:   5836 usec
Cur tick:    15973 usec,  Next time call:    15980 usec,  Diff:    7 usec,  Long tick:     21 ms,  Ellapsed from prev:    316 usec
Cur tick:    21781 usec,  Next time call:    21788 usec,  Diff:    7 usec,  Long tick:     21 ms,  Ellapsed from prev:   5808 usec
Cur tick:    22101 usec,  Next time call:    22105 usec,  Diff:    4 usec,  Long tick:     27 ms,  Ellapsed from prev:    320 usec
Cur tick:    27916 usec,  Next time call:    27920 usec,  Diff:    4 usec,  Long tick:     28 ms,  Ellapsed from prev:   5815 usec
Cur tick:    28234 usec,  Next time call:    28240 usec,  Diff:    6 usec,  Long tick:     33 ms,  Ellapsed from prev:    318 usec
Cur tick:    34062 usec,  Next time call:    34066 usec,  Diff:    4 usec,  Long tick:     34 ms,  Ellapsed from prev:   5828 usec
Cur tick:    34381 usec,  Next time call:    34385 usec,  Diff:    4 usec,  Long tick:     40 ms,  Ellapsed from prev:    319 usec
Cur tick:    40197 usec,  Next time call:    40201 usec,  Diff:    4 usec,  Long tick:     40 ms,  Ellapsed from prev:   5816 usec
Cur tick:    40514 usec,  Next time call:    40518 usec,  Diff:    4 usec,  Long tick:     46 ms,  Ellapsed from prev:    317 usec
Cur tick:    46361 usec,  Next time call:    46365 usec,  Diff:    4 usec,  Long tick:     46 ms,  Ellapsed from prev:   5847 usec
Cur tick:    46677 usec,  Next time call:    46681 usec,  Diff:    4 usec,  Long tick:     52 ms,  Ellapsed from prev:    316 usec
Cur tick:    52485 usec,  Next time call:    52489 usec,  Diff:    4 usec,  Long tick:     52 ms,  Ellapsed from prev:   5808 usec
Cur tick:    52800 usec,  Next time call:    52807 usec,  Diff:    7 usec,  Long tick:     58 ms,  Ellapsed from prev:    315 usec
Cur tick:    58608 usec,  Next time call:    58612 usec,  Diff:    4 usec,  Long tick:     58 ms,  Ellapsed from prev:   5808 usec
Cur tick:    58927 usec,  Next time call:    58931 usec,  Diff:    4 usec,  Long tick:     64 ms,  Ellapsed from prev:    319 usec
Cur tick:    64743 usec,  Next time call:    64747 usec,  Diff:    4 usec,  Long tick:     64 ms,  Ellapsed from prev:   5816 usec
Cur tick:    65061 usec,  Next time call:    65067 usec,  Diff:    6 usec,  Long tick:     70 ms,  Ellapsed from prev:    318 usec
Cur tick:    70908 usec,  Next time call:    70912 usec,  Diff:    4 usec,  Long tick:     71 ms,  Ellapsed from prev:   5847 usec
Cur tick:    76752 usec,  Next time call:    76758 usec,  Diff:    6 usec,  Long tick:     76 ms,  Ellapsed from prev:   5844 usec
Cur tick:    77072 usec,  Next time call:    77076 usec,  Diff:    4 usec,  Long tick:     77 ms,  Ellapsed from prev:    320 usec
Cur tick:    82908 usec,  Next time call:    82912 usec,  Diff:    4 usec,  Long tick:     83 ms,  Ellapsed from prev:   5836 usec
Cur tick:    83226 usec,  Next time call:    83232 usec,  Diff:    6 usec,  Long tick:     83 ms,  Ellapsed from prev:    318 usec
Cur tick:    89032 usec,  Next time call:    89036 usec,  Diff:    4 usec,  Long tick:     89 ms,  Ellapsed from prev:   5806 usec
Cur tick:    89351 usec,  Next time call:    89355 usec,  Diff:    4 usec,  Long tick:     89 ms,  Ellapsed from prev:    319 usec
Cur tick:    95155 usec,  Next time call:    95161 usec,  Diff:    6 usec,  Long tick:     95 ms,  Ellapsed from prev:   5804 usec
Cur tick:    95473 usec,  Next time call:    95477 usec,  Diff:    4 usec,  Long tick:     95 ms,  Ellapsed from prev:    318 usec
Cur tick:   101291 usec,  Next time call:   101295 usec,  Diff:    4 usec,  Long tick:    101 ms,  Ellapsed from prev:   5818 usec
Cur tick:   101617 usec,  Next time call:   101622 usec,  Diff:    5 usec,  Long tick:    107 ms,  Ellapsed from prev:    326 usec
Cur tick:   107434 usec,  Next time call:   107438 usec,  Diff:    4 usec,  Long tick:    107 ms,  Ellapsed from prev:   5817 usec
Cur tick:   107761 usec,  Next time call:   107765 usec,  Diff:    4 usec,  Long tick:    113 ms,  Ellapsed from prev:    327 usec
Cur tick:   113556 usec,  Next time call:   113563 usec,  Diff:    7 usec,  Long tick:    113 ms,  Ellapsed from prev:   5795 usec
Cur tick:   113883 usec,  Next time call:   113888 usec,  Diff:    5 usec,  Long tick:    119 ms,  Ellapsed from prev:    327 usec
Cur tick:   119714 usec,  Next time call:   119718 usec,  Diff:    4 usec,  Long tick:    119 ms,  Ellapsed from prev:   5831 usec
Cur tick:   120043 usec,  Next time call:   120047 usec,  Diff:    4 usec,  Long tick:    125 ms,  Ellapsed from prev:    329 usec
Cur tick:   125838 usec,  Next time call:   125842 usec,  Diff:    4 usec,  Long tick:    126 ms,  Ellapsed from prev:   5795 usec
Cur tick:   126167 usec,  Next time call:   126171 usec,  Diff:    4 usec,  Long tick:    131 ms,  Ellapsed from prev:    329 usec
Cur tick:   131972 usec,  Next time call:   131976 usec,  Diff:    4 usec,  Long tick:    132 ms,  Ellapsed from prev:   5805 usec
Cur tick:   132301 usec,  Next time call:   132305 usec,  Diff:    4 usec,  Long tick:    138 ms,  Ellapsed from prev:    329 usec
Cur tick:   138144 usec,  Next time call:   138148 usec,  Diff:    4 usec,  Long tick:    138 ms,  Ellapsed from prev:   5843 usec
Cur tick:   138470 usec,  Next time call:   138475 usec,  Diff:    5 usec,  Long tick:    144 ms,  Ellapsed from prev:    326 usec
Cur tick:   144267 usec,  Next time call:   144273 usec,  Diff:    6 usec,  Long tick:    144 ms,  Ellapsed from prev:   5797 usec
Cur tick:   144593 usec,  Next time call:   144598 usec,  Diff:    5 usec,  Long tick:    150 ms,  Ellapsed from prev:    326 usec
Cur tick:   150403 usec,  Next time call:   150407 usec,  Diff:    4 usec,  Long tick:    150 ms,  Ellapsed from prev:   5810 usec
Cur tick:   150730 usec,  Next time call:   150734 usec,  Diff:    4 usec,  Long tick:    156 ms,  Ellapsed from prev:    327 usec
Cur tick:   156573 usec,  Next time call:   156577 usec,  Diff:    4 usec,  Long tick:    156 ms,  Ellapsed from prev:   5843 usec
Cur tick:   162397 usec,  Next time call:   162401 usec,  Diff:    4 usec,  Long tick:    162 ms,  Ellapsed from prev:   5824 usec
Cur tick:   162724 usec,  Next time call:   162728 usec,  Diff:    4 usec,  Long tick:    162 ms,  Ellapsed from prev:    327 usec
Cur tick:   168530 usec,  Next time call:   168536 usec,  Diff:    6 usec,  Long tick:    168 ms,  Ellapsed from prev:   5806 usec
Cur tick:   168856 usec,  Next time call:   168860 usec,  Diff:    4 usec,  Long tick:    169 ms,  Ellapsed from prev:    326 usec
Cur tick:   174686 usec,  Next time call:   174690 usec,  Diff:    4 usec,  Long tick:    174 ms,  Ellapsed from prev:   5830 usec
Cur tick:   175015 usec,  Next time call:   175019 usec,  Diff:    4 usec,  Long tick:    175 ms,  Ellapsed from prev:    329 usec
Cur tick:   180809 usec,  Next time call:   180813 usec,  Diff:    4 usec,  Long tick:    181 ms,  Ellapsed from prev:   5794 usec
Cur tick:   181137 usec,  Next time call:   181141 usec,  Diff:    4 usec,  Long tick:    181 ms,  Ellapsed from prev:    328 usec
Cur tick:   186933 usec,  Next time call:   186938 usec,  Diff:    5 usec,  Long tick:    187 ms,  Ellapsed from prev:   5796 usec
Cur tick:   187260 usec,  Next time call:   187266 usec,  Diff:    6 usec,  Long tick:    192 ms,  Ellapsed from prev:    327 usec
Cur tick:   193086 usec,  Next time call:   193090 usec,  Diff:    4 usec,  Long tick:    193 ms,  Ellapsed from prev:   5826 usec



Размер буфера UartWritter'а - 2048 байт - хватает на 5 мс, если срать постоянно


Cur tick:       28 usec,  Next time call:       32 usec,  Diff:    4 usec,  Long tick:      0 ms,  Ellapsed from prev:     28 usec
Cur tick:      304 usec,  Next time call:      308 usec,  Diff:    4 usec,  Long tick:      0 ms,  Ellapsed from prev:    276 usec
Cur tick:      616 usec,  Next time call:      620 usec,  Diff:    4 usec,  Long tick:      0 ms,  Ellapsed from prev:    312 usec
Cur tick:      908 usec,  Next time call:      915 usec,  Diff:    7 usec,  Long tick:      1 ms,  Ellapsed from prev:    292 usec
Cur tick:     1205 usec,  Next time call:     1210 usec,  Diff:    5 usec,  Long tick:      1 ms,  Ellapsed from prev:    297 usec
Cur tick:     1509 usec,  Next time call:     1513 usec,  Diff:    4 usec,  Long tick:      1 ms,  Ellapsed from prev:    304 usec
Cur tick:     1810 usec,  Next time call:     1814 usec,  Diff:    4 usec,  Long tick:      2 ms,  Ellapsed from prev:    301 usec
Cur tick:     2115 usec,  Next time call:     2119 usec,  Diff:    4 usec,  Long tick:      2 ms,  Ellapsed from prev:    305 usec
Cur tick:     2419 usec,  Next time call:     2423 usec,  Diff:    4 usec,  Long tick:      2 ms,  Ellapsed from prev:    304 usec
Cur tick:     2720 usec,  Next time call:     2726 usec,  Diff:    6 usec,  Long tick:      2 ms,  Ellapsed from prev:    301 usec
Cur tick:     3025 usec,  Next time call:     3029 usec,  Diff:    4 usec,  Long tick:      3 ms,  Ellapsed from prev:    305 usec
Cur tick:     3401 usec,  Next time call:     3405 usec,  Diff:    4 usec,  Long tick:      3 ms,  Ellapsed from prev:    376 usec
Cur tick:     3704 usec,  Next time call:     3709 usec,  Diff:    5 usec,  Long tick:      3 ms,  Ellapsed from prev:    303 usec
Cur tick:     4008 usec,  Next time call:     4014 usec,  Diff:    6 usec,  Long tick:      4 ms,  Ellapsed from prev:    304 usec
Cur tick:     4311 usec,  Next time call:     4315 usec,  Diff:    4 usec,  Long tick:      4 ms,  Ellapsed from prev:    303 usec
Cur tick:     4615 usec,  Next time call:     4619 usec,  Diff:    4 usec,  Long tick:      4 ms,  Ellapsed from prev:    304 usec
Cur tick:     4918 usec,  Next time call:     4922 usec,  Diff:    4 usec,  Long tick:      5 ms,  Ellapsed from prev:    303 usec
Cur tick:     5221 usec,  Next time call:     5227 usec,  Diff:    6 usec,  Long tick:      5 ms,  Ellapsed from prev:    303 usec
Cur tick:     5525 usec,  Next time call:     5529 usec,  Diff:    4 usec,  Long tick:      9 ms,  Ellapsed from prev:    304 usec
Cur tick:     9630 usec,  Next time call:     9634 usec,  Diff:    4 usec,  Long tick:      9 ms,  Ellapsed from prev:   4105 usec
Cur tick:     9935 usec,  Next time call:     9941 usec,  Diff:    6 usec,  Long tick:     15 ms,  Ellapsed from prev:    305 usec
Cur tick:    15753 usec,  Next time call:    15757 usec,  Diff:    4 usec,  Long tick:     15 ms,  Ellapsed from prev:   5818 usec
Cur tick:    16071 usec,  Next time call:    16075 usec,  Diff:    4 usec,  Long tick:     21 ms,  Ellapsed from prev:    318 usec
Cur tick:    21928 usec,  Next time call:    21932 usec,  Diff:    4 usec,  Long tick:     22 ms,  Ellapsed from prev:   5857 usec
Cur tick:    22248 usec,  Next time call:    22252 usec,  Diff:    4 usec,  Long tick:     27 ms,  Ellapsed from prev:    320 usec
Cur tick:    28053 usec,  Next time call:    28059 usec,  Diff:    6 usec,  Long tick:     28 ms,  Ellapsed from prev:   5805 usec
Cur tick:    28371 usec,  Next time call:    28375 usec,  Diff:    4 usec,  Long tick:     34 ms,  Ellapsed from prev:    318 usec
Cur tick:    34178 usec,  Next time call:    34182 usec,  Diff:    4 usec,  Long tick:     34 ms,  Ellapsed from prev:   5807 usec
Cur tick:    34494 usec,  Next time call:    34499 usec,  Diff:    5 usec,  Long tick:     40 ms,  Ellapsed from prev:    316 usec
Cur tick:    40311 usec,  Next time call:    40315 usec,  Diff:    4 usec,  Long tick:     40 ms,  Ellapsed from prev:   5817 usec
Cur tick:    40629 usec,  Next time call:    40633 usec,  Diff:    4 usec,  Long tick:     46 ms,  Ellapsed from prev:    318 usec



*/


