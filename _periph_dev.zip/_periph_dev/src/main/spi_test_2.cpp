// master options
//#define USE_BTN_FOR_SPI_PING

// slave options

#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"
#include "umba/hr_counter.h"


extern umba::SimpleFormatter  lout;

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"
#include "periph/gpio.h"



#include "periph/stm32_discovery.h"


#include "spi_test_master_slave.h"


#include "device_state_indicator.h"


#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )

uint16_t spiValueStep = (uint16_t)256;

void spiInit( bool bMaster );
void masterProc();
void slaveProc();

DECLARE_PIN( btnPin , STM32_DISCOVERY_BTN_USER );
DECLARE_PIN( msTestCsPin , MS_TEST_SPI_CS  );

umba::periph::GpioPin &ledPin = led1_Pin;

umba::periph::GpioPin  pinMastertMode( MS_TEST_SPI_MASTER_MODE_SELECT_PIN_ADDR, UMBA_GPIO_DIRECTION_IN );


using namespace umba::time_service;
using namespace umba::periph::traits;
using namespace umba::omanip;


//umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( uart::uart1 ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
umba::LegacyUartCharWriter<255>   charWritter = umba::LegacyUartCharWriter<255>( STM32_DISCOVERY_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
//umba::SwvCharWritter   charWritter;
umba::SimpleFormatter  lout(&charWritter);


umba::hr_counter::HiResTick  nanosecDelayVal = 0;

//static volatile bool btnPrevState    = btnPin;
static volatile bool btnStateChanged = false;


static volatile uint16_t spiValue = 0;

#include "umba/optimize_speed.h"
UMBA_PERIPH_DECLARE_SPI_IRQ_HANDLER_PROC( spiIrqHandler )
{
    uint16_t tmpVal = spiReadGetValue( MS_TEST_SPI );
    spiWriteSetValue(MS_TEST_SPI, tmpVal );

    uint16_t prevTest1 = spiValue+spiValueStep;
    uint16_t prevTest2 = spiValue-spiValueStep;
    if ( (tmpVal != spiValue) && (tmpVal != prevTest1) && (tmpVal != prevTest2) )
    {
        lout<<"prev: "<<spiValue<<" ("<<hex<<width(4)<<spiValue<<"), new: "<<tmpVal<<" ("<<hex<<width(4)<<tmpVal<<")\n";
    }

    spiValue = tmpVal;
}

UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( chipSelectIrqHandlerProc )
{
    spiStartPrepare( MS_TEST_SPI );
    spiReadGetValue( MS_TEST_SPI ); // очищаем буфер чтения
    spiWriteSetValue(MS_TEST_SPI, spiValue );
}
#include "umba/optimize_pop.h"


UMBA_PERIPH_DECLARE_GPIO_EXTI_HANDLER_PROC( btnIrqHandlerProc )
{
    btnStateChanged = true;
/*
    bool btnNewState
    if (btnPin.get() != btnPrevState)
        btnStateChanged = true;

    btnPrevState

static volatile bool btnPrevState    = btnPin;
static volatile bool btnStateChanged = false;
*/
}


DeviceStateIndicator stateIndicator;
UMBA_DEVICE_STATE_INDICATOR_HANDLE_FAULTS(stateIndicator);

static volatile uint32_t hseVal   = 0;
static volatile uint32_t coreClk  = 0;
static volatile uint32_t sysClk   = 0;
static volatile uint32_t ahbClk   = 0;
static volatile uint32_t apb1Clk  = 0;
static volatile uint32_t apb2Clk  = 0;
static volatile uint32_t spiFreq  = 0;


int main(void)
{

    bool bMaster = pinMastertMode; // btnPin;

    //while(btnPin==true); // stops until startup configuration btn not released

    umba::time_service::init();
    umba::time_service::start();

    stateIndicator.setDeviceState(DeviceState::device_starting);

    if (!bMaster)
    {
        msTestCsPin.assignAddrAndMode( MS_TEST_SPI_CS_GPIO_PIN_ADDR, UMBA_GPIO_DIRECTION_IN );
    }

    ledStartup();
        
    STM32_DISCOVERY_LEGACY_UART.init( STM32_DISCOVERY_UART_RX_GPIO,  STM32_DISCOVERY_UART_RX_GPIO_PIN_NO, STM32_DISCOVERY_UART_TX_GPIO, STM32_DISCOVERY_UART_TX_GPIO_PIN_NO, 460800 );

    spiInit(bMaster);

    hseVal  = clockGetFreq(ClockBus::OSCCLK);
    coreClk = clockGetFreq(ClockBus::CORECLK);
    sysClk  = clockGetFreq(ClockBus::SYSCLK);
    ahbClk  = clockGetFreq(ClockBus::AHB);
    apb1Clk = clockGetFreq(ClockBus::APB1);
    apb2Clk = clockGetFreq(ClockBus::APB2); 
    spiFreq = spiGetFreq( MS_TEST_SPI );

    lout<<"-----------------\nHello from "<<(bMaster ? "Master" : "Slave")<<" on "<<STM32_DISCOVERY_NAME<<endl;

    lout<<"HSE : "<<width(9)<<left<<hseVal <<" Hz"<<endl;
    lout<<"CORE: "<<width(9)<<left<<coreClk<<" Hz"<<endl;
    lout<<"SYS : "<<width(9)<<left<<sysClk <<" Hz"<<endl;
    lout<<"AHB : "<<width(9)<<left<<ahbClk <<" Hz"<<endl;
    lout<<"APB1: "<<width(9)<<left<<apb1Clk<<" Hz"<<endl;
    lout<<"APB2: "<<width(9)<<left<<apb2Clk<<" Hz"<<endl;
    lout<<endl;
    lout<<"SPI : "<<width(9)<<left<<spiFreq<<" Hz"<<endl;

    lout<<endl;
    lout<<"SPI1: "<<getClockBusName(periphClockGetBus(SPI1))<<endl;
    lout<<"SPI2: "<<getClockBusName(periphClockGetBus(SPI2))<<endl;
    lout<<"SPI3: "<<getClockBusName(periphClockGetBus(SPI3))<<endl;

    lout<<endl;
    ClockBus spiClockBus = periphClockGetBus( MS_TEST_SPI );
    lout<<"Test SPI is on the "<<getClockBusName(spiClockBus)<<endl;


    stateIndicator.setDeviceState(DeviceState::standby);

    if (bMaster)
       masterProc();
    else
       slaveProc();
}

//-----------------------------------------------------------------------------
void spiInitMaster()
{
    using namespace umba::periph::traits;

    /*
    На F4/168 МГц с максимальным делителем 256 не получить частоту SPI ниже 656250 Гц.
    Период SPI SCK 1.5 мкс

    На F3/72 МГц с максимальным делителем 256 не получить частоту SPI ниже 93750 Гц.
    Период SPI SCK 10.65 мкс 

    */

    periphInit( MS_TEST_SPI                      
              , MS_TEST_SPI_SCK_GPIO_PIN_ADDR    
              , MS_TEST_SPI_MISO_GPIO_PIN_ADDR   
              , MS_TEST_SPI_MOSI_GPIO_PIN_ADDR   
              , spiDataBits16
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              , spiCalcPrescaler( MS_TEST_SPI,   10000 ) // request 10KHz
              , PinSpeed::high // PinSpeed::low
              );

    msTestCsPin = true;
}

//-----------------------------------------------------------------------------
void spiInitSlave()
{
    using namespace umba::periph::traits;

    periphInit( MS_TEST_SPI                      
              , MS_TEST_SPI_SCK_GPIO_PIN_ADDR    
              , MS_TEST_SPI_MISO_GPIO_PIN_ADDR   
              , MS_TEST_SPI_MOSI_GPIO_PIN_ADDR   
              , spiDataBits16
              , BitsDirection::msb
              , SpiMode::nCPOL_nCPHA
              , spiPrescaler256 // no mean for slave
              , PinSpeed::high // PinSpeed::low
              , spiModeSlave
              );

    periphInitIrq( MS_TEST_SPI, spiMakeEventMask(spiEventRxReady) );
    periphInstallIrqHandler( MS_TEST_SPI, spiIrqHandler );

}

//-----------------------------------------------------------------------------
void spiInit( bool bMaster )
{
    if (bMaster)
        spiInitMaster();
    else
        spiInitSlave();

}

//-----------------------------------------------------------------------------
void masterProc()
{
    #ifdef USE_BTN_FOR_SPI_PING
    auto btnPinMode = PinMode::gpio_in_pulldown; // gpio_in_floating; gpio_in_pullup;

    periphInitIrq( btnPin, extiTriggerBoth, btnPinMode );
    periphInstallIrqHandler( btnPin, btnIrqHandlerProc );    
    #endif

    umba::hr_counter::NanosecInterval spiCsAfterPause = 0 ; // umba::hr_counter::microsec(20);
    unsigned errCount = 0;
    unsigned overflowCount = 0;

    while(true)
    {
        #ifdef USE_BTN_FOR_SPI_PING
        while(!btnStateChanged)
        {
            delayMs(10);
            stateIndicator.poll();
        }

        btnStateChanged = false;
        delayMs(30); // Debounce interval

        if (!btnPin)
            continue;
        #endif

        //spiValue = spiValueStep;

        spiWrite( MS_TEST_SPI, spiValue 
                , msTestCsPin, spiCsAfterPause
                , spiDoWaitNotBusy
                );

        //umba::hr_counter::delayNanosec( umba::hr_counter::microsec(5) );
        //delayMs(1); // дает задержку 2.8 мс между записью и чтением - с этой задержкой слейв начинает успевать отвечать корректно
        //delayMs(2); // дает задержку 4.3 мс 
        //delayMs(3); // дает задержку 5.8 мс

        uint16_t remoteSpiValue = spiRead( MS_TEST_SPI, spiValue
                                         , msTestCsPin, spiCsAfterPause
                                         , spiDoWaitNotBusy
                                         );

        if (remoteSpiValue!=spiValue)
            ++errCount;

        lout<<(remoteSpiValue==spiValue ? "+" : "!")
            <<" "<<spiValue<<" ("<<hex<<width(4)<<spiValue<<")"
            <<" "<<remoteSpiValue<<" ("<<hex<<width(4)<<remoteSpiValue<<")"<<endl;
        //lout<<"prev: "<<spiValue<<" ("<<hex<<width(4)<<spiValue<<"), new: "<<tmpVal<<" ("<<hex<<width(4)<<tmpVal<<")\n";
        //++spiValue;

        spiValue += spiValueStep;

        if (!spiValue)
            overflowCount++;

        #ifndef USE_BTN_FOR_SPI_PING
        delayMs(10);

        // Btn used to show stat
        if (!btnPin)
            continue;

        delayMs(30); // Debounce interval

        if (!btnPin)
            continue;

        lout<<"Total errors: "<<errCount<<" from "<<(overflowCount*0x10000+(unsigned)spiValue)<<" cases"<<endl;
        stateIndicator.poll();
        #endif

    }

}

//-----------------------------------------------------------------------------
void slaveProc()
{

    periphInitIrq( msTestCsPin, extiTriggerFalling, PinMode::gpio_in_pullup );
    periphInstallIrqHandler( msTestCsPin, chipSelectIrqHandlerProc );    

    spiWriteSetValue(MS_TEST_SPI, 0 );

    while(true)
    {
        stateIndicator.poll();
        delayMs(50);

    }

}
