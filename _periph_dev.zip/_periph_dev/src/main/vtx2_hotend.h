// Hot-End.PrjPcb - Generator: h_conf

// Hot-End.PrjPcb - Netlist_1

// MCU DD1 STM32F303CBT6 peripherals

// CANABUS_CAN

#define CANABUS_CAN_LBK_GPIO                          GPIOA
#define CANABUS_CAN_LBK_GPIO_PIN_NO                   10
#define CANABUS_CAN_LBK_GPIO_PIN_ADDR                 UMBA_PINADDR_PA10
#define CANABUS_CAN_LBK_GPIO_PIN_ADDR_DIR             UMBA_PINADDR_PA10, UMBA_GPIO_DIRECTION_OUT
#define CANABUS_CAN_LBK_GPIO_PIN_SOURCE               GPIO_PinSource10
#define CANABUS_CAN_LBK_GPIO_PIN_DIRECTION            UMBA_GPIO_DIRECTION_OUT

#define CANABUS_CAN                                   CAN
#define USE_CAN                                       1
#define CANABUS_CAN_RX_GPIO                           GPIOA
#define CANABUS_CAN_RX_GPIO_PIN_NO                    11
#define CANABUS_CAN_RX_GPIO_PIN_ADDR                  UMBA_PINADDR_PA11
#define CANABUS_CAN_RX_GPIO_PIN_SOURCE                GPIO_PinSource11
#define CANABUS_CAN_RX_GPIO_PIN_DIRECTION             UMBA_GPIO_DIRECTION_IN

#define CANABUS_CAN_TX_GPIO                           GPIOA
#define CANABUS_CAN_TX_GPIO_PIN_NO                    12
#define CANABUS_CAN_TX_GPIO_PIN_ADDR                  UMBA_PINADDR_PA12
#define CANABUS_CAN_TX_GPIO_PIN_SOURCE                GPIO_PinSource12
#define CANABUS_CAN_TX_GPIO_PIN_DIRECTION             UMBA_GPIO_DIRECTION_IN




// HOTEND_TERMCPL

#define HOTEND_TERMCPL_SPI_SCK_GPIO                   GPIOB
#define HOTEND_TERMCPL_SPI_SCK_GPIO_PIN_NO            13
#define HOTEND_TERMCPL_SPI_SCK_GPIO_PIN_ADDR          UMBA_PINADDR_PB13
#define HOTEND_TERMCPL_SPI_SCK_GPIO_PIN_ADDR_DIR      UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT
#define HOTEND_TERMCPL_SPI_SCK_GPIO_PIN_SOURCE        GPIO_PinSource13
#define HOTEND_TERMCPL_SPI_SCK_GPIO_PIN_DIRECTION     UMBA_GPIO_DIRECTION_OUT

#define HOTEND_TERMCPL_SPI_MISO_GPIO                  GPIOB
#define HOTEND_TERMCPL_SPI_MISO_GPIO_PIN_NO           14
#define HOTEND_TERMCPL_SPI_MISO_GPIO_PIN_ADDR         UMBA_PINADDR_PB14
#define HOTEND_TERMCPL_SPI_MISO_GPIO_PIN_ADDR_DIR     UMBA_PINADDR_PB14, UMBA_GPIO_DIRECTION_IN
#define HOTEND_TERMCPL_SPI_MISO_GPIO_PIN_SOURCE       GPIO_PinSource14
#define HOTEND_TERMCPL_SPI_MISO_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_IN




// MOTOR1

#define MOTOR1_SPEED_DAC                              DAC1
#define MOTOR1_SPEED_DAC_CHANNEL                      DAC_Channel_1
#define MOTOR1_SPEED_DAC_CHANNEL_NO                   1
#define USE_DAC1                                      1

#define MOTOR1_IN2_GPIO                               GPIOB
#define MOTOR1_IN2_GPIO_PIN_NO                        7
#define MOTOR1_IN2_GPIO_PIN_ADDR                      UMBA_PINADDR_PB7
#define MOTOR1_IN2_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB7, UMBA_GPIO_DIRECTION_OUT
#define MOTOR1_IN2_GPIO_PIN_SOURCE                    GPIO_PinSource7
#define MOTOR1_IN2_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR1_IN1_GPIO                               GPIOB
#define MOTOR1_IN1_GPIO_PIN_NO                        8
#define MOTOR1_IN1_GPIO_PIN_ADDR                      UMBA_PINADDR_PB8
#define MOTOR1_IN1_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB8, UMBA_GPIO_DIRECTION_OUT
#define MOTOR1_IN1_GPIO_PIN_SOURCE                    GPIO_PinSource8
#define MOTOR1_IN1_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR1_nFAULT_GPIO                            GPIOB
#define MOTOR1_nFAULT_GPIO_PIN_NO                     9
#define MOTOR1_nFAULT_GPIO_PIN_ADDR                   UMBA_PINADDR_PB9
#define MOTOR1_nFAULT_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PB9, UMBA_GPIO_DIRECTION_IN
#define MOTOR1_nFAULT_GPIO_PIN_SOURCE                 GPIO_PinSource9
#define MOTOR1_nFAULT_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN




// MOTOR1_CURRENT_SENSOR

#define MOTOR1_CURRENT_SENSOR_ADC_GPIO                GPIOA
#define MOTOR1_CURRENT_SENSOR_ADC_GPIO_PIN_NO         0
#define MOTOR1_CURRENT_SENSOR_ADC_GPIO_PIN_ADDR       UMBA_PINADDR_PA0
#define MOTOR1_CURRENT_SENSOR_ADC_GPIO_PIN_SOURCE     GPIO_PinSource0
#define MOTOR1_CURRENT_SENSOR_ADC_CHANNEL             ADC_Channel_1
#define MOTOR1_CURRENT_SENSOR_ADC_CHANNEL_NO          1
#define MOTOR1_CURRENT_SENSOR_ADC                     ADC1
#define USE_ADC1                                      1

#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO               GPIOA
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_NO        3
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR      UMBA_PINADDR_PA3
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR_DIR    UMBA_PINADDR_PA3, UMBA_GPIO_DIRECTION_OUT
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_SOURCE    GPIO_PinSource3
#define MOTOR1_CURRENT_SENSOR_SHDN_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_OUT




// MOTOR2

#define MOTOR2_SPEED_DAC                              DAC1
#define MOTOR2_SPEED_DAC_CHANNEL                      DAC_Channel_2
#define MOTOR2_SPEED_DAC_CHANNEL_NO                   2

#define MOTOR2_IN2_GPIO                               GPIOB
#define MOTOR2_IN2_GPIO_PIN_NO                        4
#define MOTOR2_IN2_GPIO_PIN_ADDR                      UMBA_PINADDR_PB4
#define MOTOR2_IN2_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB4, UMBA_GPIO_DIRECTION_OUT
#define MOTOR2_IN2_GPIO_PIN_SOURCE                    GPIO_PinSource4
#define MOTOR2_IN2_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR2_IN1_GPIO                               GPIOB
#define MOTOR2_IN1_GPIO_PIN_NO                        5
#define MOTOR2_IN1_GPIO_PIN_ADDR                      UMBA_PINADDR_PB5
#define MOTOR2_IN1_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB5, UMBA_GPIO_DIRECTION_OUT
#define MOTOR2_IN1_GPIO_PIN_SOURCE                    GPIO_PinSource5
#define MOTOR2_IN1_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define MOTOR2_nFAULT_GPIO                            GPIOB
#define MOTOR2_nFAULT_GPIO_PIN_NO                     6
#define MOTOR2_nFAULT_GPIO_PIN_ADDR                   UMBA_PINADDR_PB6
#define MOTOR2_nFAULT_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PB6, UMBA_GPIO_DIRECTION_IN
#define MOTOR2_nFAULT_GPIO_PIN_SOURCE                 GPIO_PinSource6
#define MOTOR2_nFAULT_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN




// MOTOR2_CURRENT_SENSOR

#define MOTOR2_CURRENT_SENSOR_ADC_GPIO                GPIOA
#define MOTOR2_CURRENT_SENSOR_ADC_GPIO_PIN_NO         1
#define MOTOR2_CURRENT_SENSOR_ADC_GPIO_PIN_ADDR       UMBA_PINADDR_PA1
#define MOTOR2_CURRENT_SENSOR_ADC_GPIO_PIN_SOURCE     GPIO_PinSource1
#define MOTOR2_CURRENT_SENSOR_ADC_CHANNEL             ADC_Channel_2
#define MOTOR2_CURRENT_SENSOR_ADC_CHANNEL_NO          2
#define MOTOR2_CURRENT_SENSOR_ADC                     ADC1

#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO               GPIOA
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_NO        2
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR      UMBA_PINADDR_PA2
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_ADDR_DIR    UMBA_PINADDR_PA2, UMBA_GPIO_DIRECTION_OUT
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_SOURCE    GPIO_PinSource2
#define MOTOR2_CURRENT_SENSOR_SHDN_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_OUT




// Unclassified

#define BOARD_TEMPERATURE_ADC_GPIO                    GPIOA
#define BOARD_TEMPERATURE_ADC_GPIO_PIN_NO             6
#define BOARD_TEMPERATURE_ADC_GPIO_PIN_ADDR           UMBA_PINADDR_PA6
#define BOARD_TEMPERATURE_ADC_GPIO_PIN_SOURCE         GPIO_PinSource6
#define BOARD_TEMPERATURE_ADC_CHANNEL                 ADC_Channel_3
#define BOARD_TEMPERATURE_ADC_CHANNEL_NO              3
#define BOARD_TEMPERATURE_ADC                         ADC2
#define USE_ADC2                                      1

#define HOTEND1_NICH_DIM_PWM_GPIO                     GPIOA
#define HOTEND1_NICH_DIM_PWM_GPIO_PIN_NO              8
#define HOTEND1_NICH_DIM_PWM_GPIO_PIN_ADDR            UMBA_PINADDR_PA8
#define HOTEND1_NICH_DIM_PWM_GPIO_PIN_SOURCE          GPIO_PinSource8
#define HOTEND1_NICH_DIM_PWM_TIM_CHANNEL              TIM_Channel_1
#define HOTEND1_NICH_DIM_PWM_TIM_CHANNEL_NO           1
#define HOTEND1_NICH_DIM_PWM_TIM                      TIM1
#define USE_TIM1                                      1

#define HOTEND2_NICH_DIM_PWM_GPIO                     GPIOA
#define HOTEND2_NICH_DIM_PWM_GPIO_PIN_NO              9
#define HOTEND2_NICH_DIM_PWM_GPIO_PIN_ADDR            UMBA_PINADDR_PA9
#define HOTEND2_NICH_DIM_PWM_GPIO_PIN_SOURCE          GPIO_PinSource9
#define HOTEND2_NICH_DIM_PWM_TIM_CHANNEL              TIM_Channel_2
#define HOTEND2_NICH_DIM_PWM_TIM_CHANNEL_NO           2
#define HOTEND2_NICH_DIM_PWM_TIM                      TIM1

#define ENDSTOP_SWITCH2_GPIO                          GPIOB
#define ENDSTOP_SWITCH2_GPIO_PIN_NO                   1
#define ENDSTOP_SWITCH2_GPIO_PIN_ADDR                 UMBA_PINADDR_PB1
#define ENDSTOP_SWITCH2_GPIO_PIN_ADDR_DIR             UMBA_PINADDR_PB1, UMBA_GPIO_DIRECTION_IN
#define ENDSTOP_SWITCH2_GPIO_PIN_SOURCE               GPIO_PinSource1
#define ENDSTOP_SWITCH2_GPIO_PIN_DIRECTION            UMBA_GPIO_DIRECTION_IN

#define ENDSTOP_SWITCH1_GPIO                          GPIOB
#define ENDSTOP_SWITCH1_GPIO_PIN_NO                   0
#define ENDSTOP_SWITCH1_GPIO_PIN_ADDR                 UMBA_PINADDR_PB0
#define ENDSTOP_SWITCH1_GPIO_PIN_ADDR_DIR             UMBA_PINADDR_PB0, UMBA_GPIO_DIRECTION_IN
#define ENDSTOP_SWITCH1_GPIO_PIN_SOURCE               GPIO_PinSource0
#define ENDSTOP_SWITCH1_GPIO_PIN_DIRECTION            UMBA_GPIO_DIRECTION_IN

#define LED_ERROR_GPIO                                GPIOB
#define LED_ERROR_GPIO_PIN_NO                         10
#define LED_ERROR_GPIO_PIN_ADDR                       UMBA_PINADDR_PB10
#define LED_ERROR_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB10, UMBA_GPIO_DIRECTION_OUT
#define LED_ERROR_GPIO_PIN_SOURCE                     GPIO_PinSource10
#define LED_ERROR_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define LED_LINK_GPIO                                 GPIOA
#define LED_LINK_GPIO_PIN_NO                          7
#define LED_LINK_GPIO_PIN_ADDR                        UMBA_PINADDR_PA7
#define LED_LINK_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PA7, UMBA_GPIO_DIRECTION_OUT
#define LED_LINK_GPIO_PIN_SOURCE                      GPIO_PinSource7
#define LED_LINK_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define HOTEND1_TERMCPL_CS_GPIO                       GPIOB
#define HOTEND1_TERMCPL_CS_GPIO_PIN_NO                11
#define HOTEND1_TERMCPL_CS_GPIO_PIN_ADDR              UMBA_PINADDR_PB11
#define HOTEND1_TERMCPL_CS_GPIO_PIN_ADDR_DIR          UMBA_PINADDR_PB11, UMBA_GPIO_DIRECTION_OUT
#define HOTEND1_TERMCPL_CS_GPIO_PIN_SOURCE            GPIO_PinSource11
#define HOTEND1_TERMCPL_CS_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT

#define HOTEND2_TERMCPL_CS_GPIO                       GPIOB
#define HOTEND2_TERMCPL_CS_GPIO_PIN_NO                12
#define HOTEND2_TERMCPL_CS_GPIO_PIN_ADDR              UMBA_PINADDR_PB12
#define HOTEND2_TERMCPL_CS_GPIO_PIN_ADDR_DIR          UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT
#define HOTEND2_TERMCPL_CS_GPIO_PIN_SOURCE            GPIO_PinSource12
#define HOTEND2_TERMCPL_CS_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT




