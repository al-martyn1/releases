#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"





#if !defined(STM32F3_SERIES)
    #error "STM32F3_SERIES not defined"
#endif

#include "vtx2_hotend.h"
#include "hot_end_dbg_uart_conf.h"






#define LOG_TO_UART


#if !defined(UMBA_MCU_USED)
#error "Not an MCU target"
#endif


#ifdef _WIN32

    #include <iostream>

    umba::StdStreamCharWriter      charWritter( std::cout );

#else

    #ifdef LOG_TO_UART
        umba::LegacyUartCharWriter<2048>   charWritter = umba::LegacyUartCharWriter<2048>( DEBUG_TERMINAL_LEGACY_UART ).setTextMode(true).setAnsiTerminalMode(true).setAtFastBlink( false );
    #else    
        umba::SwvCharWritter           charWritter;
    #endif

#endif

umba::SimpleFormatter  lout(&charWritter);




static volatile uint32_t hseVal = 0;
static volatile uint32_t sysClk = 0;



#define CON_UART DEBUG_TERMINAL_LEGACY_UART





int main(void)
{

    umba::time_service::init();
    umba::time_service::start();
    
    hseVal = HSE_VALUE;
    sysClk = SystemCoreClock;

    
    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );

    umba::time_service::delayMs(300);

    lout<<"Starting\n";

    using namespace umba::omanip;

    auto kbdHandler = umba::periph::makeKeyboardHandler
                    ( 
                         []( unsigned vkc, bool fPressed, size_t repeatCout )
                         {
                             using namespace umba::omanip;
                             if (vkc & umba::periph::VirtualKeyCode::virtualCodeFlag)
                                lout<<umba::periph::VirtualKeyCode::getKeyCodeName(vkc); //<<endl;
                             else
                                lout<<(char)(uint8_t)(vkc); //<<endl;
                             if (fPressed)
                                lout<<" pressed, count: "<<repeatCout<<endl;
                             else
                                lout<<" released"<<endl;
                         }
                    );

    umba::periph::legacy::UartTerminalKeyboard kbd = umba::periph::legacy::UartTerminalKeyboard( &kbdHandler, & CON_UART);


    unsigned n = 0;
    while(1)
    {
        kbd.scanKeyboard();
    }

    return 0;
}




