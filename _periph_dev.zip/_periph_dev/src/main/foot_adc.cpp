#include "adc.h"
#include "mcu_configuration.h"
#include "umba_array/umba_array.h"

namespace adc
{

   // AdcDataType rawDataArr[ adc_raw_data_size ];

    Adc< AdcChannels_3 > adc_3;
    Adc< AdcChannels_4 > adc_4;

    struct Params
    {
        uint32_t rccDma = 0;
        DMA_Channel_TypeDef * dmaChannel = nullptr;

        ADC_TypeDef * adc = nullptr;
        uint32_t rccAdc = 0;
        uint32_t adcPllDivider = 0;

        RawDataArrView rawDataArr{nullptr};
    };

    template< typename ... Channels>
    static void initPeriph( const Params & params, Channels ... channels );

    void init(void)
    {
        /*
        ----------------------------------------------------------------------------------------------------
                                             НОГИ
        ----------------------------------------------------------------------------------------------------
        */

        // ноги - тактирование

        // сунем токи на АЦП3, а температуры - в АЦП4

        // ADC3 канал 5 - PB13 - motor_1_current
        // ADC34 канал 11 - PD14 - motor_2_current

        // ADC4 канал 5 - РВ15 - motor_1_temperature
        // ADC34 канал 8  - PD11 - motor_2_temperature

        // к сожалению, ноги на разных АЦП, это потребует использования двух разных DMA
        // это несколько осложняет происходящее

        auto initPin_Analog = []( const umba::GpioPin & pin )
        {
            pin.initIn_Floating();

            GPIO_InitTypeDef gpio;
            GPIO_StructInit( &gpio );

            gpio.GPIO_Pin = pin.getRawPin();
            gpio.GPIO_Mode = GPIO_Mode_AN;
            GPIO_Init( pin.getRawPort(), &gpio);
        };

        initPin_Analog( pins::motor_1_current );
        initPin_Analog( pins::motor_2_current );
        initPin_Analog( pins::motor_1_temperature );
        initPin_Analog( pins::motor_2_temperature );

        /*
        ----------------------------------------------------------------------------------------------------
                                             DMA + ADC
        ----------------------------------------------------------------------------------------------------
        */

        // сунем токи на АЦП3, а температуры - в АЦП4

        // АЦП3 канал 5 и канал 11 - DMA2 канал 5
        {
            Params params;

            params.adc = ADC3;
            params.rccAdc = RCC_AHBPeriph_ADC34;
            params.adcPllDivider = RCC_ADC34PLLCLK_Div256;

            params.dmaChannel = DMA2_Channel5;
            params.rccDma = RCC_AHBPeriph_DMA2;

            params.rawDataArr = adc_3.m_rawDataArr;

            initPeriph( params, ADC_Channel_5, ADC_Channel_11 );
        }
        
        // АЦП4 канал 5 и канал 8 - DMA2 канал 2
        {
            Params params;

            params.adc = ADC4;
            params.rccAdc = RCC_AHBPeriph_ADC34;
            params.adcPllDivider = RCC_ADC34PLLCLK_Div256;

            params.dmaChannel = DMA2_Channel2;
            params.rccDma = RCC_AHBPeriph_DMA2;

            params.rawDataArr = adc_4.m_rawDataArr;

            initPeriph( params, ADC_Channel_5, ADC_Channel_8 );
        }
    }



    // предполагается, что все channels - это инты аля ADC_Channel_8
    template< typename ... Channels>
    static void initPeriph( const Params & params, Channels ... channels )
    {
        /*
        ----------------------------------------------------------------------------------------------------
                                              DMA
        ----------------------------------------------------------------------------------------------------
        */

        // DMA - тактирование

        RCC_AHBPeriphClockCmd( params.rccDma, ENABLE );

        // DMA - настройка
        DMA_InitTypeDef       DMA_InitStructure;


        /* DMA channel configuration ----------------------------------------------*/
        DMA_DeInit( params.dmaChannel );

        DMA_InitStructure.DMA_BufferSize = params.rawDataArr.size();
        DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t) ( &params.adc->DR );
        DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t) params.rawDataArr.data();

        // остальное всегда одно и то же
        DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
        DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
        DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
        // TODO: параметризовать по размеру ADC->DR
        DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
        DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
        DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
        DMA_InitStructure.DMA_Priority = DMA_Priority_High;
        DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;

        DMA_Init( params.dmaChannel, &DMA_InitStructure );

        /* Enable channel */
        DMA_Cmd( params.dmaChannel, ENABLE );

        /*
        ----------------------------------------------------------------------------------------------------
                                               ADC
        ----------------------------------------------------------------------------------------------------
        */

        RCC_AHBPeriphClockCmd( params.rccAdc, ENABLE);

        // без этого калибровка не завершалась
        // не очень понятно почему TODO: понять
        RCC_ADCCLKConfig( params.adcPllDivider );

        /* Calibration procedure */
        ADC_VoltageRegulatorCmd( params.adc, ENABLE);

        /* Insert delay equal to 10 µs */
        for( volatile uint32_t i=0; i<SystemCoreClock/100000; i++ )
        {
            __NOP();
        }

        ADC_SelectCalibrationMode( params.adc, ADC_CalibrationMode_Single );
        ADC_StartCalibration( params.adc );

        while( ADC_GetCalibrationStatus( params.adc ) != RESET );

        // ацп - настройка

        ADC_InitTypeDef ADC_InitStructure;
        ADC_StructInit( &ADC_InitStructure );

        // общая
        ADC_CommonInitTypeDef ADC_CommonInitStructure;

        ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
        ADC_CommonInitStructure.ADC_Clock = ADC_Clock_AsynClkMode;
        ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_1;
        ADC_CommonInitStructure.ADC_DMAMode = ADC_DMAMode_Circular;
        ADC_CommonInitStructure.ADC_TwoSamplingDelay = 0;

        ADC_CommonInit( params.adc, &ADC_CommonInitStructure );

        /* adc configuration ------------------------------------------------------*/
        ADC_InitStructure.ADC_ContinuousConvMode = ADC_ContinuousConvMode_Enable;
        ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
        ADC_InitStructure.ADC_ExternalTrigConvEvent = ADC_ExternalTrigConvEvent_0;
        ADC_InitStructure.ADC_ExternalTrigEventEdge = ADC_ExternalTrigEventEdge_None;
        ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
        ADC_InitStructure.ADC_OverrunMode = ADC_OverrunMode_Disable;
        ADC_InitStructure.ADC_AutoInjMode = ADC_AutoInjec_Disable;

        ADC_InitStructure.ADC_NbrOfRegChannel = sizeof...(channels);
        ADC_Init( params.adc, &ADC_InitStructure );

        uint8_t chan[] = { channels... };

        // настройка каналов - в каком порядке они будут конвертиться
        for( uint8_t i = 0; i<NUM_ELEM(chan); i++ )
        {
            ADC_RegularChannelConfig( params.adc, chan[i], i+1, ADC_SampleTime_601Cycles5 );
        }

        /*
        ----------------------------------------------------------------------------------------------------
                                               Стартуем
        ----------------------------------------------------------------------------------------------------
        */

        /* Configures the ADC DMA */
        ADC_DMAConfig( params.adc, ADC_DMAMode_Circular );
        /* Enable the ADC DMA */
        ADC_DMACmd( params.adc, ENABLE );

        /* Enable adc*/
        ADC_Cmd( params.adc, ENABLE );

        /* wait for adc ADRDY */
        while( !ADC_GetFlagStatus( params.adc, ADC_FLAG_RDY ) ) {;}

        /* Enable the DMA channel */
        DMA_Cmd( params.dmaChannel, ENABLE );

        /* Start adc Software Conversion */
        ADC_StartConversion( params.adc );
    }


}
