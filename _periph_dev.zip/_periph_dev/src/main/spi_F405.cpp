#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "umba/umba.h"
#include "umba/bits.h"
#include "umba/time_service.h"

#include "stm32.h"

#include "periph/vk_codes.h"
#include "periph/keyboard_uart.h"

#include "periph/gpio.h"
#include "periph/power.h"

#include "vtx2_hotend.h"
#include "hot_end_dbg_uart_conf.h"

#include "soft_spi.h"
#include "soft_interval.h"


#define DECLARE_PIN( pinName, pinConfigName )  umba::periph::GpioPin  pinName( pinConfigName##_GPIO_PIN_ADDR_DIR )

DECLARE_PIN( termocouplesSckPin , HOTEND_TERMCPL_SPI_SCK  );
DECLARE_PIN( termocouplesMisoPin, HOTEND_TERMCPL_SPI_MISO );
DECLARE_PIN( termocouplesCs1Pin , HOTEND1_TERMCPL_CS      );
//DECLARE_PIN( termocouplesCs2Pin , HOTEND2_TERMCPL_CS      );
umba::periph::GpioPin  termocouplesCs2Pin( PB12, UMBA_GPIO_DIRECTION_OUT ); // Через него посигналим







int main()
{
    umba::time_service::init();
    umba::time_service::start();

    using namespace umba::time_service;

    termocouplesSckPin .connect();
    termocouplesMisoPin.connect();
    termocouplesCs1Pin .connect();
    termocouplesCs2Pin .connect();

    termocouplesSckPin = false;
    termocouplesCs1Pin = true;
    termocouplesCs2Pin = true;

    //hseVal = HSE_VALUE;
    //sysClk = SystemCoreClock;

/*    
    DEBUG_TERMINAL_LEGACY_UART.init( DEBUG_TERMINAL_UART_RX_GPIO, DEBUG_TERMINAL_UART_RX_GPIO_PIN_NO
                                   , DEBUG_TERMINAL_UART_TX_GPIO, DEBUG_TERMINAL_UART_TX_GPIO_PIN_NO
                                   , 460800 );

    umba::time_service::delayMs(300);

    lout<<"Starting\n";

    using namespace umba::omanip;
*/


    volatile uint32_t termocouple1Data = 0;
    volatile uint32_t termocouple2Data = 0;

    SoftIntervalMs    termocouplesInterval(1000);
    unsigned          termocouplesCounter = 0;

    termocouplesInterval.reset();

    unsigned n = 0;
    while(1)
    {
        if (termocouplesInterval.checkTimedout())
        {
            if (termocouplesCounter&1)
                termocouple2Data = softSpiRead( 32, termocouplesSckPin, termocouplesMisoPin, termocouplesCs2Pin, 0 /* &termocouplesCs2Pin */  );
            else
                termocouple1Data = softSpiRead( 32, termocouplesSckPin, termocouplesMisoPin, termocouplesCs1Pin, 0 /* &termocouplesCs2Pin */  );

            termocouplesCounter++;
        }

        
    }


    
    return 0;
}

