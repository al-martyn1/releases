#pragma once

#include "visca.h"

namespace camera
{
    class Camera
    {
        public:
            
        void init( ISerialPort * p ) 
        {
            m_visca.init( p );
        }
        
        void work( uint32_t time )
        {
            if( !m_isCommandFinished ) 
            {
                switch( m_currentCommand.type )
                {
                    case Command::Type::VARIANT:
                    {
                        auto answer = m_visca.sendCommand( m_currentCommand.code, m_currentCommand.variant );
                        if( ( answer == Answer::ACK ) || ( answer == Answer::CMD_COMPLETED ) )
                        {
                            m_isCommandFinished = true;
                        }
                        break;
                    }
                    case Command::Type::PARAMETER:
                    {
                        auto answer = m_visca.sendCommand( m_currentCommand.code, m_currentCommand.p1 );
                        if( ( answer == Answer::ACK ) || ( answer == Answer::CMD_COMPLETED ) )
                        {
                            m_isCommandFinished = true;
                        }
                        break;
                    }
                    case Command::Type::PARAMETER_U16:
                    {
                        auto answer = m_visca.sendCommandZoomDirect( m_currentCommand.p_u16 );
                        if( ( answer == Answer::ACK ) || ( answer == Answer::CMD_COMPLETED ) )
                        {
                            m_isCommandFinished = true;
                        }
                        break;
                    }
                    case Command::Type::MULTIPARAMETER:
                    {
                        auto answer = m_visca.sendCommandColorEnhance(  m_currentCommand.p1, 
                                                                        m_currentCommand.p2, 
                                                                        m_currentCommand.p3, 
                                                                        m_currentCommand.p4, 
                                                                        m_currentCommand.p5, 
                                                                        m_currentCommand.p6, 
                                                                        m_currentCommand.p7, 
                                                                        m_currentCommand.p8 );
                        if( ( answer == Answer::ACK ) || ( answer == Answer::CMD_COMPLETED ) )
                        {
                            m_isCommandFinished = true;
                        }
                        break;
                    }
                }
            }
        }
        
        bool sendCommand( Codes cmdCode, Variant variant )
        {
            if( !m_isCommandFinished ) return false;
            m_currentCommand.code = cmdCode;
            m_currentCommand.type = Command::Type::VARIANT;
            m_currentCommand.variant = variant;
            m_isCommandFinished = false;
            
            return true;
        }
        bool sendCommand( Codes cmdCode, uint8_t parameter )
        {
            if( !m_isCommandFinished ) return false;
            m_currentCommand.code = cmdCode;
            m_currentCommand.type = Command::Type::PARAMETER;
            m_currentCommand.p1 = parameter;
            m_isCommandFinished = false;
            
            return true;
        }
        bool sendCommandZoomDirect( uint16_t zoom )
        {
            if( !m_isCommandFinished ) return false;
            m_currentCommand.type = Command::Type::PARAMETER_U16;
            m_currentCommand.p_u16 = zoom;
            m_isCommandFinished = false;
            
            return true;
        }
        bool sendCommandColorEnhance( uint8_t thresholdLevel, uint8_t HysteresisWidth,
                                    uint8_t High_Y, uint8_t High_Cr, uint8_t High_Cb,
                                    uint8_t Low_Y, uint8_t Low_Cr, uint8_t Low_Cb )
        {
            if( !m_isCommandFinished ) return false;
            m_currentCommand.type = Command::Type::MULTIPARAMETER;
            m_currentCommand.p1 = thresholdLevel;
            m_currentCommand.p2 = HysteresisWidth;
            m_currentCommand.p3 = High_Y;
            m_currentCommand.p4 = High_Cr;
            m_currentCommand.p5 = High_Cb;
            m_currentCommand.p6 = Low_Y;
            m_currentCommand.p7 = Low_Cr;
            m_currentCommand.p8 = Low_Cb;
            m_isCommandFinished = false;
            
            return true;
        }
        
        private:

        struct Command
        {
            enum Type{ VARIANT, PARAMETER, PARAMETER_U16, MULTIPARAMETER };
            Codes code = Codes::POWER;
            Type type;
            uint8_t p1;
            uint8_t p2;
            uint8_t p3;
            uint8_t p4;
            uint8_t p5;
            uint8_t p6;
            uint8_t p7;
            uint8_t p8;
            
            uint16_t p_u16;
            Variant variant = Variant::OFF;
        };
        
        Command m_currentCommand;
        bool m_isCommandFinished = true;
        
        Visca m_visca;
    };
}
