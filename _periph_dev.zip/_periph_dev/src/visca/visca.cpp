/*
ФАЙЛ ОТПРАВКИ КОМАНД ПО ПРОТОКОЛУ VISCA
Вид пакета для отправки:
    StartByte    <Data>     0xFF
   
Вид StartByte:
    0x88 - для broadcast сообщений
    0x8A - для сообщений по адресу A
    
У камеры адрес 1 и очень не хочется его менять

    <Data>
Для broadcast сообщений длина может быть различной
Для сообщений по адресу, не связанных с выводом osd и настройкой свойств строки - 4 байта
Для сообщений - вывода osd или настройки свойств строки - 14 байт
--------------------------------------------------------------------------------------------------------------------------------------
Вид пакета ответа:

    ACK или CMD_COMPLETED:
    0x90 <Code> 0xFF
    
    ERROR:
    0x90 0x61 <Error Code> 0xFF
*/

#include "visca.h"
//#include "Common_Functions/common_functions.h"

namespace common_functions
{
    /**************************************************************************************************
    Описание:  Функция ограничения значения сверху и снизу
    Аргументы: value - значение
               min - минимум
               max - максимум
    Возврат:   Ссылка на value, чтобы можно было делать цепочки и использовать clamp в вызовах других функций
    Замечания: Явное задание параметров шаблона не требуется: int a = 19; clamp(a, 0, 10);
    **************************************************************************************************/
    template <typename T, typename U, typename V>
    T & clamp(T & value, U min, V max)
    {
        if( value > max )
            value = max;

        else if( value < min )
            value = min;
            
        return value;
    }
}

#define START_BYTE                          0x90
#define STOP_BYTE                           0xff
        
#define ACK_CODE                            0x41
#define COMPLETION_CODE                     0x51
#define ERROR_CODE                          0x61
        
#define ACK_CODE_LENGTH                     3
#define ERROR_CODE_LENGTH                   4
#define MAX_ANSWER_LENGTH                   ERROR_CODE_LENGTH

#define START_BYTE_POSITION                 0
#define ACK_NACK_CODE_POSITION              1
#define ERROR_CODE_OR_ACK_STOP_POSITION     2
#define ERROR_STOP_POSITION                 3

#define SYNTAX_ERROR_CODE                   0x02
#define BUFFER_FULL_CODE                    0x03
#define CMD_CANCELED_CODE                   0x04
#define NO_SOCKET_CODE                      0x05
#define CMD_NOT_EXECUTABLE_CODE             0x41

#define BROADCAST_COMMAND_LENGTH            3
#define DIRECT_COMMAND_LENGTH               6
#define DOUBLE_PARAM_COMMAND_LENGTH         9
#define COLOR_PARAM_COMMAND_LENGTH          13
#define PRINT_COMMAND_LENGTH                16
        
#define MAX_LINE_NUMBER                     10
        
#define PRINT_DATA_SIZE                     10
#define PRINT_DATA_POSITION                 5
#define COLOR_POSITION                      7
#define LINE_NUMBER_POSITION                4
#define LINE_PART_SHIFT                     4
#define SPEED_POSITION                      4
        
#define ACTIVE_COLOR                        0
#define INACTIVE_COLOR                      5
#define CURRENT_COLOR                       5

const uint8_t Visca:: cmd_addr_set[]                                 = { 0x88, 0x30, 0x01, 0xFF };
const uint8_t Visca:: cmd_if_clr[]                                   = { 0x88, 0x01, 0x00, 0x01, 0xFF };

const uint8_t Visca:: cmd_power[]                                    = { 0x81, 0x01, 0x04, 0x00, 0x02, 0xFF };

const uint8_t Visca:: cmd_zoom_tele_with_speed[]                     = { 0x81, 0x01, 0x04, 0x07, 0x20, 0xFF };
const uint8_t Visca:: cmd_zoom_wide_with_speed[]                     = { 0x81, 0x01, 0x04, 0x07, 0x30, 0xFF };
const uint8_t Visca:: cmd_zoom_stop[]                                = { 0x81, 0x01, 0x04, 0x07, 0x00, 0xFF };
const uint8_t Visca:: cmd_zoom_direct[]                              = { 0x81, 0x01, 0x04, 0x47, 0x00, 0x00, 0x00, 0x00, 0xFF };

const uint8_t Visca:: cmd_d_zoom[]                                   = { 0x81, 0x01, 0x04, 0x06, 0x02, 0xFF };

const uint8_t Visca:: cmd_focus_far_with_speed[]                     = { 0x81, 0x01, 0x04, 0x08, 0x20, 0xFF };
const uint8_t Visca:: cmd_focus_near_with_speed[]                    = { 0x81, 0x01, 0x04, 0x08, 0x30, 0xFF };
const uint8_t Visca:: cmd_focus_stop[]                               = { 0x81, 0x01, 0x04, 0x08, 0x00, 0xFF };

const uint8_t Visca:: cmd_autofocus[]                                = { 0x81, 0x01, 0x04, 0x38, 0x02, 0xFF };

const uint8_t Visca:: cmd_cam_ir_correction_mode[]                   = { 0x81, 0x01, 0x04, 0x11, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_white_balance_mode[]                   = { 0x81, 0x01, 0x04, 0x35, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_red_gain_reset[]                       = { 0x81, 0x01, 0x04, 0x03, 0x00, 0xFF };
const uint8_t Visca:: cmd_cam_red_gain_direct[]                      = { 0x81, 0x01, 0x04, 0x43, 0x00, 0x00, 0x00, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_blue_gain_reset[]                      = { 0x81, 0x01, 0x04, 0x04, 0x00, 0xFF };
const uint8_t Visca:: cmd_cam_blue_gain_direct[]                     = { 0x81, 0x01, 0x04, 0x44, 0x00, 0x00, 0x00, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_automatic_exposure_mode[]              = { 0x81, 0x01, 0x04, 0x39, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_shutter_direct[]                       = { 0x81, 0x01, 0x04, 0x4A, 0x00, 0x00, 0x00, 0x00, 0xFF };
const uint8_t Visca:: cmd_cam_iris_direct[]                          = { 0x81, 0x01, 0x04, 0x4B, 0x00, 0x00, 0x00, 0x00, 0xFF };
const uint8_t Visca:: cmd_cam_gain_direct[]                          = { 0x81, 0x01, 0x04, 0x4C, 0x00, 0x00, 0x00, 0x00, 0xFF };
const uint8_t Visca:: cmd_cam_bright_direct[]                        = { 0x81, 0x01, 0x04, 0x4D, 0x00, 0x00, 0x00, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_backlight_compensation[]               = { 0x81, 0x01, 0x04, 0x33, 0x02, 0xFF };

const uint8_t Visca:: cmd_cam_defog[]                                = { 0x81, 0x01, 0x04, 0x37, 0x02, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_high_resolution[]                      = { 0x81, 0x01, 0x04, 0x52, 0x02, 0xFF };

const uint8_t Visca:: cmd_mirror[]                                   = { 0x81, 0x01, 0x04, 0x61, 0x02, 0xFF };

const uint8_t Visca:: cmd_bw_on[]                                    = { 0x81, 0x01, 0x04, 0x63, 0x04, 0xFF };
const uint8_t Visca:: cmd_bw_off[]                                   = { 0x81, 0x01, 0x04, 0x63, 0x00, 0xFF };

const uint8_t Visca:: cmd_flip[]                                     = { 0x81, 0x01, 0x04, 0x66, 0x02, 0xFF };

const uint8_t Visca:: cmd_cam_icr[]                                  = { 0x81, 0x01, 0x04, 0x01, 0x02, 0xFF };
const uint8_t Visca:: cmd_cam_auto_icr[]                             = { 0x81, 0x01, 0x04, 0x51, 0x02, 0xFF };
const uint8_t Visca:: cmd_cam_auto_icr_threshold[]                   = { 0x81, 0x01, 0x04, 0x21, 0x00, 0x00, 0x00, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_stabilizer[]                           = { 0x81, 0x01, 0x04, 0x34, 0x02, 0xFF };
const uint8_t Visca:: cmd_cam_stabilizer_hold[]                      = { 0x81, 0x01, 0x04, 0x34, 0x00, 0xFF };

const uint8_t Visca:: cmd_cam_continuous_zoom_pos_reply[]            = { 0x81, 0x01, 0x04, 0x69, 0x02, 0xFF };
//const uint8_t Visca:: cmd_cam_continuous_zoom_pos_reply[]          = { 0x81, 0x01, 0x04, };

const uint8_t Visca:: cmd_cam_color_enhance[]                        = { 0x81, 0x01, 0x04, 0x50, 0x02, 0xFF };
const uint8_t Visca:: cmd_cam_color_enhance_params[]                 = { 0x81, 0x01, 0x04, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF };

const uint8_t Visca:: cmd_title_clr[] =		        {0x81, 0x01, 0x04, 0x74, 0x1F, 0xFF};
const uint8_t Visca:: cmd_title_on[] =	            {0x81, 0x01, 0x04, 0x74, 0x2F, 0xFF};
const uint8_t Visca:: cmd_title_off[] =	            {0x81, 0x01, 0x04, 0x74, 0x3F, 0xFF};
    
const uint8_t Visca:: cmd_title_set[] =             {0x81, 0x01, 0x04, 0x73, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF};


void Visca::init(ISerialPort * uart)
{
    m_uart = uart;
}
/**************************************************************************************************
Описание:  Установка адреса устройства
Аргументы: Адрес
Возврат:   Нет
Замечания: Блокирует поток на время отправления broadcast команды
**************************************************************************************************/
void Visca::setAddress(uint8_t address)
{
//    uint8_t cmd[sizeof(cmd_addr_set)]; 
//    memcpy(cmd, cmd_addr_set, sizeof(cmd_addr_set));

//    cmd[BROADCAST_COMMAND_LENGTH] = address;
//    
//    //если не дождался семафора, то, к сожалению, здесь придётся зависнуть
//    if(osSemaphoreTake(this->m_uart->getTransmitCompleteSem(), 1000) == pdFALSE)
//    {
//        UMBA_ASSERT_FAIL();
//    }

//    bool result = this->m_uart->sendLocalArray(cmd, NUM_ELEM(Visca::cmd_addr_set));
//    UMBA_ASSERT(result);
}

/**************************************************************************************************
Описание:  Очищает буфер команд на устройстве
Аргументы: Нет
Возврат:   Нет
Замечания: Блокирует поток на время отправления broadcast команды
**************************************************************************************************/
void Visca::ifClear()
{
//    //если не дождался семафора, то, к сожалению, здесь придётся зависнуть
//    if(osSemaphoreTake(this->m_uart->getTransmitCompleteSem(), 1000) == pdFALSE)
//    {
//        UMBA_ASSERT_FAIL();
//    }
//    
//    bool result = this->m_uart->sendLocalArray(Visca::cmd_if_clr, NUM_ELEM(Visca::cmd_if_clr));
//    UMBA_ASSERT(result);
}

/**************************************************************************************************
Описание:  Посылает команду на устройство, ждёт ответа
Аргументы: Код команды, состояние вкл/выкл
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/
Answer Visca::sendCommand( Codes cmdCode, Variant variant )
{
    uint8_t cmd[DIRECT_COMMAND_LENGTH + 1];
    switch(cmdCode)
    {
        case Codes::POWER:
            memcpy(cmd, Visca::cmd_power, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::D_ZOOM:
            memcpy(cmd, Visca::cmd_d_zoom, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::AUTO_FOCUS:
            memcpy(cmd, Visca::cmd_autofocus, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::BACKLIGHT_COMPENSATION:
            memcpy(cmd, Visca::cmd_cam_backlight_compensation, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::DEFOG:
            memcpy(cmd, Visca::cmd_cam_defog, DIRECT_COMMAND_LENGTH + 1);
            break;
        case Codes::HIGH_RESOLUTION_MODE:
            memcpy(cmd, Visca::cmd_cam_high_resolution, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::MIRROR:
            memcpy(cmd, Visca::cmd_mirror, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::BLACK_WHITE:
            memcpy(cmd, Visca::cmd_bw_on, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::FLIP:
            memcpy(cmd, Visca::cmd_flip, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::INFRARED_MODE:
            memcpy(cmd, Visca::cmd_cam_icr, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::AUTO_INFRARED_MODE:
            memcpy(cmd, Visca::cmd_cam_auto_icr, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::STABILIZER:
            memcpy(cmd, Visca::cmd_cam_stabilizer, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::ZOOM_POS_REPLY:
            memcpy(cmd, Visca::cmd_cam_continuous_zoom_pos_reply, DIRECT_COMMAND_LENGTH);
            break;
        case Codes::COLOR_ENHANCE:
            memcpy(cmd, Visca::cmd_cam_color_enhance, DIRECT_COMMAND_LENGTH);
            break;
        default:
        {
            return Answer::ERROR_WRONG_CMD_CODE;
        }
    }
    //по дефолту все команды включают. поэтому надо проверить и выключить
    //черно-былй режим - это режим и у него немного другая команда
    if( variant == Variant::OFF )
    {
        cmd[4] = variant.toInt();
        if( cmdCode == Codes::BLACK_WHITE )
        {
            memcpy(cmd, Visca::cmd_bw_off, DIRECT_COMMAND_LENGTH);
        }
    }
    if( cmdCode == Codes::DEFOG )
    {
        Answer ans = sendViscaCommand(cmd, DIRECT_COMMAND_LENGTH + 1);// отсылаем
        return ans;
    }
    Answer ans = sendViscaCommand(cmd, DIRECT_COMMAND_LENGTH);// отсылаем
    return ans;
}

/**************************************************************************************************
Описание:  Посылает команду на устройство, ждёт ответа
Аргументы: Код команды, параметр
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/
Answer Visca::sendCommand(Codes cmdCode, uint8_t parameter)
{
    uint8_t cmd[DOUBLE_PARAM_COMMAND_LENGTH];
    ParamType type = ParamType::BYTE;
    switch(cmdCode)
    {
        case Codes::ZOOM:
        {
            int8_t speed = (int8_t)parameter;
            if( speed < 0)
            {
                common_functions::clamp( speed, -8, -1 );
                parameter = -speed - 1;
                memcpy(cmd, Visca::cmd_zoom_wide_with_speed, DIRECT_COMMAND_LENGTH);
            }
            else if( speed > 0 )
            {
                common_functions::clamp( speed, 1, 8 );
                parameter = speed - 1;
                memcpy(cmd, Visca::cmd_zoom_tele_with_speed, DIRECT_COMMAND_LENGTH);
            }
            else
            {
                memcpy(cmd, Visca::cmd_zoom_stop, DIRECT_COMMAND_LENGTH);
            }
            type = ParamType::NIBBLE;
            break;
        }
        case Codes::FOCUS:
        {
            int8_t speed = (int8_t)parameter;
            if( speed < 0)
            {
                common_functions::clamp( speed, -8, -1 );
                parameter = -speed - 1;
                memcpy(cmd, Visca::cmd_focus_near_with_speed, DIRECT_COMMAND_LENGTH);
            }
            else if( speed > 0 )
            {
                common_functions::clamp( speed, 1, 8 );
                parameter = speed - 1;
                memcpy(cmd, Visca::cmd_focus_far_with_speed, DIRECT_COMMAND_LENGTH);
            }
            else
            {
                memcpy(cmd, Visca::cmd_focus_stop, DIRECT_COMMAND_LENGTH);
            }
            type = ParamType::NIBBLE;
            break;
        }
        case Codes::INFRARED_CORRECTION:
        {
            if( ( (IRCorrection)parameter == (IRCorrection::IR_LIGHT) ) || ( (IRCorrection)parameter == (IRCorrection::STANDART) ) )
            {
                memcpy(cmd, Visca::cmd_cam_ir_correction_mode, DIRECT_COMMAND_LENGTH);
            }
            else
            {
                return Answer::ERROR_WRONG_CMD_CODE;
            }
            type = ParamType::NIBBLE;
            break;
        }
        case Codes::WHITE_BALANCE:
        {
            if( ( (WhiteBalance)parameter == (WhiteBalance::AUTO) ) ||
                ( (WhiteBalance)parameter == (WhiteBalance::MANUAL) ) ||
                ( (WhiteBalance)parameter == (WhiteBalance::SODIUM_LAMP_AUTO) ) )
            {
               memcpy(cmd, Visca::cmd_cam_white_balance_mode, DIRECT_COMMAND_LENGTH);
            }
            else
            {
               return Answer::ERROR_WRONG_CMD_CODE;
            }
            type = ParamType::NIBBLE;
            break;
        }
        case Codes::RED_GAIN:
        {
            memcpy(cmd, Visca::cmd_cam_red_gain_direct, DOUBLE_PARAM_COMMAND_LENGTH);
            type = ParamType::BYTE;
            break;
        }
        case Codes::BLUE_GAIN:
        {
            memcpy(cmd, Visca::cmd_cam_blue_gain_direct, DOUBLE_PARAM_COMMAND_LENGTH);
            type = ParamType::BYTE;
            break;
        }
        case Codes::AUTOMATIC_EXPOSURE:
        {
            if( ( (AutomaticExposure)parameter == (AutomaticExposure::FULL_AUTO) ) ||
                ( (AutomaticExposure)parameter == (AutomaticExposure::MANUAL) ) ||
                ( (AutomaticExposure)parameter == (AutomaticExposure::SHUTTER_PRIORITY) ) ||
                ( (AutomaticExposure)parameter == (AutomaticExposure::IRIS_PRIORITY) ) ||
                ( (AutomaticExposure)parameter == (AutomaticExposure::BRIGHT) ) )
            {
               memcpy(cmd, Visca::cmd_cam_automatic_exposure_mode, DIRECT_COMMAND_LENGTH);
            }
            else
            {
               return Answer::ERROR_WRONG_CMD_CODE;
            }
            type = ParamType::NIBBLE;
            break;
        }
        case Codes::SHUTTER:
        {
            common_functions::clamp( parameter, 0, 0x15 );
            memcpy(cmd, Visca::cmd_cam_shutter_direct, DOUBLE_PARAM_COMMAND_LENGTH);
            type = ParamType::BYTE;
            break;
        }
        case Codes::IRIS:
        {
            common_functions::clamp( parameter, 0, 0x11 );
            memcpy(cmd, Visca::cmd_cam_iris_direct, DOUBLE_PARAM_COMMAND_LENGTH);
            type = ParamType::BYTE;
            break;
        }
        case Codes::GAIN:
        {
            common_functions::clamp( parameter, 0, 0x0F );
            memcpy(cmd, Visca::cmd_cam_gain_direct, DOUBLE_PARAM_COMMAND_LENGTH);
            type = ParamType::BYTE;
            break;
        }
        case Codes::BRIGHT:
        {
            common_functions::clamp( parameter, 0, 0x1F );
            memcpy(cmd, Visca::cmd_cam_bright_direct, DOUBLE_PARAM_COMMAND_LENGTH);
            type = ParamType::BYTE;
            break;
        }
        case Codes::AUTO_INFRARED_MODE:
        {
            memcpy(cmd, Visca::cmd_cam_auto_icr_threshold, DOUBLE_PARAM_COMMAND_LENGTH);
            type = ParamType::BYTE;
            break;
        }
        case Codes::STABILIZER:
        {
            if( ( (Stabilizer)parameter == (Stabilizer::HOLD) ) )
            {
               memcpy(cmd, Visca::cmd_cam_stabilizer_hold, DIRECT_COMMAND_LENGTH);
            }
            else
            {
               return Answer::ERROR_WRONG_CMD_CODE;
            }
            type = ParamType::NIBBLE;
            break;
        }
        default:
        {
            return Answer::ERROR_WRONG_CMD_CODE;
        }
    }
    Answer ans = Answer::ERROR_WRONG_CMD_CODE;
    if( type == ParamType::NIBBLE )
    {
        //добавляем параметр в пакет, размер параметра уже проверен выше
        cmd[4] += parameter;
        ans = sendViscaCommand(cmd, DIRECT_COMMAND_LENGTH);// отсылаем
    }
    else
    {
        //добавляем параметр в пакет, разбиваем байт на 2 ниббла
        cmd[6] += (parameter >> 4);
        cmd[7] += (parameter & 0x0F);
        ans = sendViscaCommand(cmd, DOUBLE_PARAM_COMMAND_LENGTH);// отсылаем
    }
    return ans;

}


Answer Visca::sendCommandZoomDirect( uint16_t zoom )
{
    uint8_t cmd[COLOR_PARAM_COMMAND_LENGTH];
    common_functions::clamp( zoom, 0, 0x4000 );
    memcpy(cmd, Visca::cmd_zoom_direct, DOUBLE_PARAM_COMMAND_LENGTH);


    cmd[4] = (zoom >> 12) & 0x0F;
    cmd[5] = (zoom >> 8) & 0x0F;
    cmd[6] = (zoom >> 4) & 0x0F;
    cmd[7] = (zoom >> 0) & 0x0F;

    Answer ans = Answer::ERROR_WRONG_CMD_CODE;
    ans = sendViscaCommand(cmd, DOUBLE_PARAM_COMMAND_LENGTH);// отсылаем
    
    return ans;
}
/**************************************************************************************************
Описание:  Посылает команду настройки палитры на  устройство, ждёт ответа
Аргументы: Куча параметров
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/
Answer Visca::sendCommandColorEnhance( uint8_t thresholdLevel, uint8_t HysteresisWidth,
                                uint8_t High_Y, uint8_t High_Cr, uint8_t High_Cb,
                                uint8_t Low_Y, uint8_t Low_Cr, uint8_t Low_Cb )
{

    uint8_t cmd[COLOR_PARAM_COMMAND_LENGTH];

    common_functions::clamp( thresholdLevel, 0, 0x7F );
    common_functions::clamp( HysteresisWidth, 0, 0x7F );
    common_functions::clamp( High_Y, 0, 0x7F );
    common_functions::clamp( High_Cr, 0, 0x7F );
    common_functions::clamp( High_Cb, 0, 0x7F );
    common_functions::clamp( Low_Y, 0, 0x7F );
    common_functions::clamp( Low_Cr, 0, 0x7F );
    common_functions::clamp( Low_Cb, 0, 0x7F );
    memcpy(cmd, Visca::cmd_cam_color_enhance_params, COLOR_PARAM_COMMAND_LENGTH);

    cmd[4] = thresholdLevel;
    cmd[5] = HysteresisWidth;
    cmd[6] = High_Y;
    cmd[7] = High_Cr;
    cmd[8] = High_Cb;
    cmd[9] = Low_Y;
    cmd[10] = Low_Cr;
    cmd[11] = Low_Cb;
    
    Answer ans = Answer::ERROR_WRONG_CMD_CODE;
    ans = sendViscaCommand(cmd, COLOR_PARAM_COMMAND_LENGTH);// отсылаем
    
    return ans;
}

/**************************************************************************************************
Описание:  Отрисовка 
Аргументы: Номер линии, начиная с нулевой, номер половины экрана 1 или 2, данные в коде из даташита виски
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/        
Answer Visca::printHalfLine(uint8_t line, uint8_t part, const uint8_t * data) // перерисовывает полстроки
{   
    if(line > MAX_LINE_NUMBER)
    {
        line = MAX_LINE_NUMBER;
    }

//у экрана есть 1-я и 2-я половины, остальное - не катит
    if(part > 2 || part == 0)
    {
        part = 2;
    }
    static uint8_t cmd[PRINT_COMMAND_LENGTH];
    memcpy(cmd, cmd_title_set, PRINT_COMMAND_LENGTH);
    
    //в байте LINE_NUMBER_POSITION находится номер линии и код:
    //    1 - настройка свойств линии(цвет, блинк и тд)
    //    2 - вывести первые 10 символов
    //    3 - вывести вторые 10 символов
    cmd[LINE_NUMBER_POSITION] = (line ) + ((part + 1)<< LINE_PART_SHIFT); 
    
    //копирую в строку команды 10 символов из переданного массива
    //массив data имеет длину 20 символов, если вывожу вторую половину, то беру символы из data с 10 по 19
    memcpy(&cmd[PRINT_DATA_POSITION], &data[(part - 1) * PRINT_DATA_SIZE], PRINT_DATA_SIZE);
    
    Answer ans = sendViscaCommand(cmd, PRINT_COMMAND_LENGTH);// отсылаем
    return ans;

}

/**************************************************************************************************
Описание:  Отрисовка 
Аргументы: Номер линии, начиная с нулевой, данные в коде из даташита виски
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/        
Answer Visca::printLine(uint8_t line, const uint8_t * data) // перерисовывает полстроки
{  
    Answer ans = Answer::ACK;
    ans = printHalfLine(line, 1, data);
    if(ans == Answer::ACK || ans == Answer::CMD_COMPLETED)
    {
        ans = printHalfLine(line, 2, data);
        return ans;
    }
    return ans;
}
        
/**************************************************************************************************
Описание:  Команда очистки экрана
Аргументы: Нет
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/
Answer Visca::clearOsd(void)
{
    Answer ans = sendViscaCommand(Visca::cmd_title_clr, NUM_ELEM(Visca::cmd_title_clr));
    return ans;

}
    
/**************************************************************************************************
Описание:  Команда разрешения вывода на экран
Аргументы: Нет
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/
Answer Visca::osdOn(void)
{
    Answer ans = sendViscaCommand(Visca::cmd_title_on, NUM_ELEM(Visca::cmd_title_on));
    return ans;

}
    
/**************************************************************************************************
Описание:  Команда запрещения вывода на экран
Аргументы: Нет
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/
Answer Visca::osdOff(void)
{
    Answer ans = sendViscaCommand(Visca::cmd_title_off, NUM_ELEM(Visca::cmd_title_off));
    return ans;
}
        
/**************************************************************************************************
Описание:  Меняет цвет строки исходя из статуса
Аргументы: Номер строки, статус
Возврат:   Код ответа
Замечания: Блокирует поток до получения ответа
**************************************************************************************************/
Answer Visca::setStatus(uint8_t line, Status status)
{
    if(line > MAX_LINE_NUMBER)
    {
        line = MAX_LINE_NUMBER;
        return Answer::ERROR_WRONG_CMD_CODE;
    }
    
    static uint8_t cmd[PRINT_COMMAND_LENGTH];
    memcpy(cmd, Visca::cmd_title_set, PRINT_COMMAND_LENGTH);
    cmd[LINE_NUMBER_POSITION] += line;
    switch(status)
    {
        case Status::ACTIVE:
        {
            cmd[COLOR_POSITION] = ACTIVE_COLOR;
            break;
        }
        case Status::INACTIVE:
        {
            cmd[COLOR_POSITION] = INACTIVE_COLOR;
            break;
        }
        case Status::CURRENT:
        {
            cmd[COLOR_POSITION] = CURRENT_COLOR;
            break;
        }
        
    }
    Answer ans = sendViscaCommand(cmd, PRINT_COMMAND_LENGTH);// отсылаем
    return ans;

}
 

Answer Visca::sendViscaCommand(const uint8_t * data, uint8_t size)
{
    switch( m_sendState )
    {
        case SendStates::PREPARE:
        {
            if( m_uart->isTransmitComplete() )
            {
                m_sendState = SendStates::SEND;
            }

            break;
        }
        case SendStates::SEND:
        {
            bool result = m_uart->sendLocalArray(data, size);
            UMBA_ASSERT(result);
                
            m_sendState = SendStates::WAIT_ANSWER;
                        
            break;
        }
        case SendStates::WAIT_ANSWER:
        {
            Answer answer = Answer::COMPOSING;
            if( m_uart->isNewByte() )
            {
                answer = viscaComposer( m_uart->getByte() );
            }
            if( ( answer == Answer::CMD_COMPLETED ) || ( answer == Answer::ACK ) )
            {
                m_sendState = SendStates::PREPARE;
                return answer;
            }
            break;
        }
        default:
        {
            UMBA_ASSERT_FAIL();
        }
        
    }
    
    return Answer::COMPOSING;
}


Answer Visca::viscaComposer(uint8_t data)
{
    static uint8_t answerMassive[MAX_ANSWER_LENGTH];
    static uint8_t currentNum = 0;
    static uint8_t length = 0;

    static Answer answer = Answer::ACK;
                
    answerMassive[currentNum] = data;
    length++;
   
    while(length > currentNum)
    {
        switch(currentNum)
        {
            case START_BYTE_POSITION:
            {
                currentNum++;
                if(answerMassive[START_BYTE_POSITION] != START_BYTE)
                {
                    onError(answerMassive, currentNum, length);
                }
                break;
            }
            case ACK_NACK_CODE_POSITION:
            {
                currentNum++;
                switch(answerMassive[ACK_NACK_CODE_POSITION])
                {
                    case ACK_CODE:
                    {
                        answer = Answer::ACK; 
                        break;
                    }
                    case COMPLETION_CODE:
                    {
                        answer = Answer::CMD_COMPLETED; 
                        break;
                    }
                    case ERROR_CODE:
                    {
                        answer = Answer::ERROR_SYNTAX; 
                        break;
                    }
                    default:
                    {
                        onError(answerMassive, currentNum, length);
                        break;
                    }
                }
                break;
            }
            case ERROR_CODE_OR_ACK_STOP_POSITION:
            {
                currentNum++;
                //если предполагали не ошибку, то ждём конец
                if(answer == Answer::ACK || answer == Answer::CMD_COMPLETED)
                {
                    if(answerMassive[ERROR_CODE_OR_ACK_STOP_POSITION] == STOP_BYTE)
                    {
                        currentNum = 0; 
                        length = 0;
                        return answer;
                    }
                    else
                    {
                        onError(answerMassive, currentNum, length);
                    }
                }
                else
                {
                    switch(answerMassive[ERROR_CODE_OR_ACK_STOP_POSITION])
                    {
                        case SYNTAX_ERROR_CODE:
                        {
                            answer = Answer::ERROR_SYNTAX; 
                            break;
                        }
                        case BUFFER_FULL_CODE:
                        {
                            answer = Answer::ERROR_CMD_BUFFER_FULL; 
                            break;
                        }
                        case CMD_CANCELED_CODE:
                        {
                            answer = Answer::ERROR_CMD_CANCELED; 
                            break;
                        }
                        case NO_SOCKET_CODE:
                        {
                            answer = Answer::ERROR_NO_SOCKET; 
                            break;
                        }
                        case CMD_NOT_EXECUTABLE_CODE:
                        {
                            answer = Answer::ERROR_CMD_NOT_EXECUTABLE; 
                            break;
                        }
                        default:
                        {
                            onError(answerMassive, currentNum, length);
                            break;
                        }

                    }
                }
                break;
            }
            case ERROR_STOP_POSITION:
            {
                currentNum = 0;
                if(answerMassive[ERROR_STOP_POSITION] == STOP_BYTE)
                {
                    length = 0;
                    return answer;
                }
                else
                {
                    onError(answerMassive, currentNum, length);
                }
                break;
            }
        }
    }
    return Answer::COMPOSING;
 
}


void Visca::onError(uint8_t * buffer, uint8_t & number, uint8_t & length)
{
    for(int i = 0; i < length; i++)
    {
        buffer[i] = buffer[i + 1];
    }
    number = 0;
    length--;
}
