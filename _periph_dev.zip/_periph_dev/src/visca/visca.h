#pragma once

#include <stdint.h>
#include "luart/uart_handle.h"
#include <string.h>


STRONG_ENUM( Variant,   ON = 0x02,
                        OFF = 0x03 );
//ниббловые параметры
STRONG_ENUM( IRCorrection, STANDART = 0x00,
                           IR_LIGHT = 0x01 );

STRONG_ENUM( WhiteBalance, AUTO = 0x00,
                           MANUAL = 0x05,
                           SODIUM_LAMP_AUTO = 0x07 );

STRONG_ENUM( AutomaticExposure, FULL_AUTO = 0x00,
                                MANUAL = 0x03,
                                SHUTTER_PRIORITY = 0x0A,
                                IRIS_PRIORITY = 0x0B,
                                BRIGHT = 0x0D );

STRONG_ENUM( Stabilizer, HOLD = 0x00 );


//коды, которые привяжутся к классам элементов меню и будут передаваться в функцию отправки в visca
STRONG_ENUM( Codes, POWER,                          // - ON/OFF
                    ZOOM,                           // - param
                    D_ZOOM,                         // - ON/OFF
                    FOCUS,                          // - param
                    AUTO_FOCUS,                     // - ON/OFF
                    INFRARED_CORRECTION,            // - param Standart/ir light
                    WHITE_BALANCE,                  // - param Auto/Manual/Sodium lamp
                    RED_GAIN,                       // - param direct
                    BLUE_GAIN,                      // - param direct
                    AUTOMATIC_EXPOSURE,             // - param full auto/shutter priority
                    SHUTTER,                        // - param direct
                    IRIS,                           // - param direct
                    GAIN,                           // - param direct
                    BRIGHT,                         // - param direct
                    BACKLIGHT_COMPENSATION,         // - ON/OFF
                    DEFOG,                          // - ON/OFF
                    HIGH_RESOLUTION_MODE,           // - ON/OFF
                    MIRROR,                         // - ON/OFF
                    BLACK_WHITE,                    // - ON/OFF
                    FLIP,                           // - ON/OFF
                    INFRARED_MODE,                  // - ON/OFF
                    AUTO_INFRARED_MODE,             // - ON/OFF + param Threshold
                    STABILIZER,                     // - ON/OFF + param Hold
                    ZOOM_POS_REPLY,                 // - ON/OFF
                    COLOR_ENHANCE );                // - ON/OFF + too much params..............

STRONG_ENUM(Answer, ACK                         = 0,
                    CMD_COMPLETED               = 1,
                    ERROR_SYNTAX                = 2,
                    ERROR_CMD_BUFFER_FULL       = 3,
                    ERROR_CMD_CANCELED          = 4,
                    ERROR_NO_SOCKET             = 5,
                    ERROR_CMD_NOT_EXECUTABLE    = 6,
                    ERROR_WRONG_CMD_CODE        = 7,
                    ERROR_UART_UNABLE           = 8,
                    COMPOSING                   = 9,                
                    TIMEOUT                     = 10);

STRONG_ENUM(Status, ACTIVE,
                    INACTIVE,
                    CURRENT  );
    
class Visca
{
public:
    
    void init(ISerialPort * uart);
    
    //эти методы блокируют поток
    //так как до тех пор, пока команда не будет принята, на камеру нет смысла слать следующую
    //а поток будет занят только камерой, то блокирующие методы не должны быть смертельными
    void setAddress(uint8_t address);
    void ifClear(void);
    Answer sendCommand(Codes cmdCode, Variant variant);
    Answer sendCommand(Codes cmdCode, uint8_t parameter);
    Answer sendCommandZoomDirect( uint16_t zoom );
    Answer sendCommandColorEnhance( uint8_t thresholdLevel, uint8_t HysteresisWidth,
                                    uint8_t High_Y, uint8_t High_Cr, uint8_t High_Cb,
                                    uint8_t Low_Y, uint8_t Low_Cr, uint8_t Low_Cb );
    
    Answer printHalfLine(uint8_t line, uint8_t part, const uint8_t * data); // рисует полстроки
    Answer printLine(uint8_t line, const uint8_t * data); // рисует строку
    Answer clearOsd(void);
    Answer osdOn(void);
    Answer osdOff(void);
    Answer setStatus(uint8_t line, Status status);  // функции 

private:

    STRONG_ENUM( ParamType, NIBBLE,
                            BYTE );
    // Команды
    static const uint8_t cmd_addr_set[];
    static const uint8_t cmd_if_clr[]; 
    
    static const uint8_t cmd_power[];

    static const uint8_t cmd_zoom_tele_with_speed[];
    static const uint8_t cmd_zoom_wide_with_speed[];
    static const uint8_t cmd_zoom_stop[];
    static const uint8_t cmd_zoom_direct[];
    
    static const uint8_t cmd_d_zoom[];

    static const uint8_t cmd_focus_far_with_speed[];
    static const uint8_t cmd_focus_near_with_speed[];
    static const uint8_t cmd_focus_stop[];
    
    static const uint8_t cmd_autofocus[];
    
    static const uint8_t cmd_cam_ir_correction_mode[];

    static const uint8_t cmd_cam_white_balance_mode[];

    static const uint8_t cmd_cam_red_gain_reset[];
    static const uint8_t cmd_cam_red_gain_direct[];
    
    static const uint8_t cmd_cam_blue_gain_reset[];
    static const uint8_t cmd_cam_blue_gain_direct[];

    static const uint8_t cmd_cam_automatic_exposure_mode[];

    static const uint8_t cmd_cam_shutter_direct[];
    static const uint8_t cmd_cam_iris_direct[];    
    static const uint8_t cmd_cam_gain_direct[];
    static const uint8_t cmd_cam_bright_direct[];

    static const uint8_t cmd_cam_backlight_compensation[];

    static const uint8_t cmd_cam_defog[];

    static const uint8_t cmd_cam_high_resolution[];

    static const uint8_t cmd_mirror[];

    static const uint8_t cmd_bw_on[];
    static const uint8_t cmd_bw_off[];

    static const uint8_t cmd_flip[];
    
    static const uint8_t cmd_cam_icr[];
    static const uint8_t cmd_cam_auto_icr[];
    static const uint8_t cmd_cam_auto_icr_threshold[];

    static const uint8_t cmd_cam_stabilizer[];
    static const uint8_t cmd_cam_stabilizer_hold[];

    static const uint8_t cmd_cam_continuous_zoom_pos_reply[];
    //static const uint8_t cmd_cam_continuous_zoom_pos_reply[];

    static const uint8_t cmd_cam_color_enhance[];
    static const uint8_t cmd_cam_color_enhance_params[];

    static const uint8_t cmd_title_clr[];
    static const uint8_t cmd_title_on[];
    static const uint8_t cmd_title_off[];
    
    static const uint8_t cmd_title_set[];
    
    ISerialPort * m_uart;
    
    enum class SendStates{ PREPARE, SEND, WAIT_ANSWER, FINISHED };
    
    SendStates m_sendState = SendStates::PREPARE;
    
    Answer sendViscaCommand(const uint8_t * data, uint8_t size);
    Answer viscaComposer(uint8_t data);
    void onError(uint8_t * buffer, uint8_t & counter, uint8_t & length);
    
};
