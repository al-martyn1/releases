#pragma once

#include "umba/interface.h"
#include "umba/basic_interfaces.h"
#include "ihc/i_octet_stream.h"
#include "classes.h"
#include "umba/stl.h"
#include "umba/errors.h"

// umba::drivers::

namespace umba
{
namespace drivers
{

interface IDriver;

typedef uint16_t  DriverId;

// new style
constexpr DriverId driver_id_invalid          = (DriverId)-1;
constexpr DriverId driver_id_any              = driver_id_invalid;
constexpr DriverId driver_id_auto             = driver_id_invalid;
constexpr DriverId driver_id_device_number    = (DriverId)-2; // соответствует аппаратному номеру устройства 
constexpr DriverId driver_id_broadcast        = driver_id_invalid;

constexpr DriverId invalid_driver_id          = driver_id_invalid      ;
constexpr DriverId id_auto_driver_id          = driver_id_auto         ;
constexpr DriverId device_number_driver_id    = driver_id_device_number;
constexpr DriverId broadcast_driver_id        = driver_id_broadcast    ;



//-----------------------------------------------------------------------------
typedef   uint16_t  ValueId;
constexpr ValueId   value_id_any              = (ValueId)-1;

//-----------------------------------------------------------------------------
typedef uint16_t    DeviceBusAddress;
constexpr DeviceBusAddress invalid_device_bus_address = (DeviceBusAddress)-1;

//-----------------------------------------------------------------------------
typedef umba::time_service::TimeTick  TimeTick;

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------

struct DriverAddress
{
    ClassId          classId  ;
    DriverId         driverId ; // umba::drivers::invalid_driver_id

    constexpr DriverAddress( )
    : classId(umba::drivers::class_id_unknown)
    , driverId(umba::drivers::invalid_driver_id)
    {}

    constexpr DriverAddress( ClassId clsid )
    : classId(clsid)
    , driverId(umba::drivers::invalid_driver_id)
    {}

    constexpr DriverAddress( ClassId clsid, DriverId drvid )
    : classId(clsid)
    , driverId(drvid)
    {}

    int compareTo( const DriverAddress &other, bool allowMask = false ) const
    {
        if (classId < other.classId )
            return -1;
        if (classId > other.classId )
            return 1;

        if (driverId==other.driverId)
            return 0;

        //if (allowMask && (driverId==umba::drivers::invalid_driver_id || other.driverId==umba::drivers::invalid_driver_id))
        if (allowMask && (other.driverId==umba::drivers::invalid_driver_id))
            return 0;

        if (driverId < other.driverId )
            return -1;
        if (driverId > other.driverId )
            return 1;

        return 0;
    }

    bool isInvalid() const
    {
        return classId == class_id_unknown &&  driverId == invalid_driver_id;
    }

    bool isValid() const
    {
        return !isInvalid();
    }
    

}; // struct DriverAddress


constexpr DriverAddress invalid_driver_address = { class_id_unknown, invalid_driver_id };







//-----------------------------------------------------------------------------
enum class PowerConsumptionClass : uint32_t
{
    low, medium, high, very
};

//-----------------------------------------------------------------------------
struct TicksFromPowerConsumptionClass
{
    TicksFromPowerConsumptionClass( TimeTick ticksLow, TimeTick ticksMedium, TimeTick ticksHigh, TimeTick ticksVery )
    : m_ticksLow(ticksLow), m_ticksMedium(ticksMedium), m_ticksHigh(ticksHigh), m_ticksVery(ticksVery)
    {}

    TimeTick operator()( PowerConsumptionClass pcc )
    {
        switch(pcc)
        {
            case umba::drivers::PowerConsumptionClass::low   : return m_ticksLow;
            case umba::drivers::PowerConsumptionClass::medium: return m_ticksMedium;
            case umba::drivers::PowerConsumptionClass::high  : return m_ticksHigh;
            default:                                           return m_ticksVery;
        }
    
    }

protected:

    TimeTick m_ticksLow, m_ticksMedium, m_ticksHigh, m_ticksVery;
};


//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
enum class ValueInfoFlags : uint32_t
{
    data_size_mask       = 0x0002,
                        
    data_size_8          = 0x0000,
    data_size_16         = 0x0001,
    data_size_32         = 0x0002,
    data_size_64         = 0x0003,
                        
    flag_signed          = 0x0004,
    flag_integral        = 0x0008,

    data_u8              = 0x0000 | flag_integral,
    data_u16             = 0x0001 | flag_integral,
    data_u32             = 0x0002 | flag_integral,
    data_u64             = 0x0003 | flag_integral,

    data_s8              = 0x0000 | flag_integral | flag_signed,
    data_s16             = 0x0001 | flag_integral | flag_signed,
    data_s32             = 0x0002 | flag_integral | flag_signed,
    data_s64             = 0x0003 | flag_integral | flag_signed,

    data_float           = data_size_32,
    data_double          = data_size_64,

    data_type_mask       = 0x000F,
                        
    flags_scale_binary   = 0x0010,  // otherwise - decimal
    scale_mask           = 0xFF00, // convert to int8_t
};

//-----------------------------------------------------------------------------
inline
const char* getValueInfoTypeName(ValueInfoFlags v)
{
    switch( v )
    {
        case ValueInfoFlags::data_u8    : return "u8";
        case ValueInfoFlags::data_u16   : return "u16";
        case ValueInfoFlags::data_u32   : return "u32";
        case ValueInfoFlags::data_u64   : return "u64";
                                             
        case ValueInfoFlags::data_s8    : return "s8";
        case ValueInfoFlags::data_s16   : return "s16";
        case ValueInfoFlags::data_s32   : return "s32";
        case ValueInfoFlags::data_s64   : return "s64";
                                             
        case ValueInfoFlags::data_float : return "f32";
        case ValueInfoFlags::data_double: return "f64";

        default : return "UNK";
    };

}



//-----------------------------------------------------------------------------
template <typename T>
inline
ValueInfoFlags getValueInfoSizeFlags( T t )
{
    switch( sizeof(T) )
    {
        //case 1: return ValueInfoFlags::;
        case 2:  return ValueInfoFlags::data_size_16;
        case 4:  return ValueInfoFlags::data_size_32;
        case 8:  return ValueInfoFlags::data_size_64;
        default: return ValueInfoFlags::data_size_8 ;
    };
}

//-----------------------------------------------------------------------------
/*
template<class T ,
         class = typename std::enable_if<std::is_integral<T>::value>::type >
T foo3(T t) // обратите внимание, сигнатура функции не меняется
{
    return t;
}
*/

// http://ideone.com/rmvoEo
// https://ru.cppreference.com/w/cpp/types/enable_if
// https://ru.stackoverflow.com/questions/735392/Включение-шаблонов-и-stdenable-if

#if 0
template <typename T  /* , typename = typename std::enable_if<std::is_integral<T>::value >::type */  >
inline
auto getValueInfoIntegralFlag( T t ) -> decltype( typename std::enable_if<std::is_integral<T>::value >::type(), ValueInfoFlags() )
{
    return ValueInfoFlags::flag_integral;
}

template <typename T /* , typename = typename std::enable_if<std::is_floating_point<T>::value >::type */  >
inline
auto getValueInfoIntegralFlag( T t ) -> decltype( typename std::enable_if<std::is_floating_point<T>::value >::type(), ValueInfoFlags() )
{
    return (ValueInfoFlags)0;
}
//-----------------------------------------------------------------------------

template <typename T  >
inline
auto getValueInfoSignedFlag( T t ) -> decltype( typename std::enable_if<std::is_signed<T>::value >::type(), ValueInfoFlags() )
{
    return ValueInfoFlags::flag_signed;
}


template <typename T  >
inline
auto getValueInfoSignedFlag( T t ) -> decltype( typename std::enable_if< !std::is_signed<T>::value >::type(), ValueInfoFlags() )
{
    return (ValueInfoFlags)0;
}
#endif


constexpr ValueInfoFlags getValueInfoIntegralFlag( int8_t   v ) { return ValueInfoFlags::flag_integral; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( uint8_t  v ) { return ValueInfoFlags::flag_integral; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( int16_t  v ) { return ValueInfoFlags::flag_integral; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( uint16_t v ) { return ValueInfoFlags::flag_integral; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( int32_t  v ) { return ValueInfoFlags::flag_integral; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( uint32_t v ) { return ValueInfoFlags::flag_integral; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( int64_t  v ) { return ValueInfoFlags::flag_integral; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( uint64_t v ) { return ValueInfoFlags::flag_integral; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( float    v ) { return (ValueInfoFlags)0; }
constexpr ValueInfoFlags getValueInfoIntegralFlag( double   v ) { return (ValueInfoFlags)0; }

constexpr ValueInfoFlags getValueInfoSignedFlag( int8_t   v ) { return ValueInfoFlags::flag_signed; }
constexpr ValueInfoFlags getValueInfoSignedFlag( uint8_t  v ) { return (ValueInfoFlags)0; }
constexpr ValueInfoFlags getValueInfoSignedFlag( int16_t  v ) { return ValueInfoFlags::flag_signed; }
constexpr ValueInfoFlags getValueInfoSignedFlag( uint16_t v ) { return (ValueInfoFlags)0; }
constexpr ValueInfoFlags getValueInfoSignedFlag( int32_t  v ) { return ValueInfoFlags::flag_signed; }
constexpr ValueInfoFlags getValueInfoSignedFlag( uint32_t v ) { return (ValueInfoFlags)0; }
constexpr ValueInfoFlags getValueInfoSignedFlag( int64_t  v ) { return ValueInfoFlags::flag_signed; }
constexpr ValueInfoFlags getValueInfoSignedFlag( uint64_t v ) { return (ValueInfoFlags)0; }


//-----------------------------------------------------------------------------
inline
ValueInfoFlags packValueInfoFlags( ValueInfoFlags szis, int8_t scale = 0, bool bScaleBinary = false )
{
    uint32_t res = (uint32_t)szis & ( (uint32_t)ValueInfoFlags::data_size_mask
                                    | (uint32_t)ValueInfoFlags::flag_integral
                                    | (uint32_t)ValueInfoFlags::flag_signed
                                    ) ;
    if (scale)
    {
        res |= ((uint32_t)(uint8_t)scale) << 8;
    }

    if (bScaleBinary)
        res |= (uint32_t)ValueInfoFlags::flags_scale_binary;

    return (ValueInfoFlags)res;
}

inline
ValueInfoFlags packValueInfoFlags( ValueInfoFlags sz, bool fIntegral, bool fSigned, int8_t scale = 0, bool bScaleBinary = false )
{
    uint32_t res = (uint32_t)sz & (uint32_t)ValueInfoFlags::data_size_mask;

    if (fSigned)
        res |= (uint32_t)ValueInfoFlags::flag_signed;

    if (fIntegral)
        res |= (uint32_t)ValueInfoFlags::flag_integral;

    return packValueInfoFlags( (ValueInfoFlags)res, scale, bScaleBinary );
}

//-----------------------------------------------------------------------------
constexpr ValueInfoFlags makeValueInfoFlags( float  v ) { return ValueInfoFlags::data_float;  }
constexpr ValueInfoFlags makeValueInfoFlags( double v ) { return ValueInfoFlags::data_double; }

template <typename T>
inline
ValueInfoFlags makeValueInfoFlags( T t )
{
    return (ValueInfoFlags)((uint32_t)getValueInfoSizeFlags(t) | (uint32_t)getValueInfoIntegralFlag(t) | (uint32_t)getValueInfoSignedFlag(t));
}



#if 0
template <typename T>
inline
auto makeValueInfoFlags( T t ) -> decltype( typename std::enable_if< std::is_floating_point<T>::value >::type(), ValueInfoFlags() )
{
    return (ValueInfoFlags)((uint32_t)getValueInfoSizeFlags(t) /* | (uint32_t)getValueInfoIntegralFlag(t) */  /*  | (uint32_t)getValueInfoSignedFlag(t) */ ) ;
}

template <typename T>
inline
auto makeValueInfoFlags( T t ) -> decltype( typename std::enable_if< !std::is_floating_point<T>::value >::type(), ValueInfoFlags() )
{
    return (ValueInfoFlags)((uint32_t)getValueInfoSizeFlags(t) | (uint32_t)getValueInfoIntegralFlag(t) | (uint32_t)getValueInfoSignedFlag(t));
}
#endif








} // namespace drivers
} // namespace umba

