#pragma once

#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"
#include "ihc/octet_stream_buf.h"

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"
#include "periph/periph.h"
#include "periph/soft/soft_i2c.h"


#ifdef LUART_UART_HANDLE_H
    //#error "LUART_UART_HANDLE_H defined"
#else
    #error "LUART_UART_HANDLE_H NOT defined"
#endif



namespace umba
{
namespace drivers
{
namespace periph
{


//#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
//#include "x_esc_device_params.h"
//#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE



class SoftI2cDriver : public DriverImplBase< class_id_i2c_soft, subclass_id_software, PowerConsumptionClass::low >
{

    typedef DriverImplBase< class_id_i2c_soft, subclass_id_software, PowerConsumptionClass::low > BaseImpl;

public:

    UMBA_DRIVER_DESCRIPTION( "Soft I2C" )

    SoftI2cDriver( umba::periph::GpioPinAddr pinSda
                 , umba::periph::GpioPinAddr pinScl
                 )
    : BaseImpl()
    , m_pinSda(pinSda)
    , m_pinScl(pinScl)
    {
    }

    SoftI2cDriver( SoftI2cDriver && ) = default;

    bool install( DriverId driverId = driver_id_auto )
    {
        #ifdef RTKOS_RTKOS_H
        //DriverId 
        return umba::rtkos::driverInstall( DriverAddress(class_id_value, driverId ), subclass_id_value, this );
        //umba::rtkos::messageFilterAdd( this );
        //umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::normal );
        #endif
        // TimerId timerSet ( Object *pObj, TimerEventId eventId, TimeTick period )
    }


    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NO_PARAMS()

    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()
    

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);

        oss<<"SDA:"<<m_pinSda<<" SCL:"<<m_pinScl;
        return umba::periph::isValidPinAddr(m_pinSda) && umba::periph::isValidPinAddr(m_pinScl);
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        m_i2c.setHalfBitTimeout( 50 );
        m_i2c.setAddrs( m_pinSda, m_pinScl );
        m_i2c.init();
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        using namespace umba::omanip;

        // Send data to device here
        if (msg.header.classId!=class_id_value)
            return dumpMsg(msg);

        if (msg.header.driverId!=m_driverSelfId)
            return dumpMsg(msg);
        
        if (msg.header.driverMessageId!=MessageId::driver_raw_data_request)
            return dumpMsg(msg);
        
        //UMBA_ASSERT(msg.header.pDriver);

        //msg.rawData.deviceBusAddress
        //msg.rawData.dataSize
        if (msg.rawData.dataSize>=8) // too much
            return dumpMsg(msg);

        const uint8_t * pData = getMessageDriverRawData( msg );

        uint8_t buf[8];

        bool newSensorResult = m_i2c.readFrom( (uint8_t)msg.rawData.deviceBusAddress, &buf[0], (size_t)msg.rawData.dataSize );
        //if (newSensorResult!=m_lastResult)

        m_lastResult = newSensorResult;

        MessageDriver msgRes;
        initMessageDriver( msgRes, class_id_value, m_driverSelfId, MessageId::driver_notify_carrier, static_cast<IDriver*>( this ) );

        msgRes.linkStatus = newSensorResult ? 1 : 0;
        #ifdef RTKOS_RTKOS_H
        umba::rtkos::messagePost( msgRes );
        #endif

        msgRes.header.driverMessageId = MessageId::driver_notify_datalink;
        #ifdef RTKOS_RTKOS_H
        umba::rtkos::messagePost( msgRes );
        #endif

        //dumpMsg(msg, "Input message");

        if (newSensorResult)
        {
            //IDriver* pd = static_cast<IDriver*>( this );
            //UMBA_RTKOS_LOG<<"PD: "<<groupsize(8)<<hex<<(uintptr_t)pd<<endl;
            //initMessageDriver( msgRes, class_id_value, m_driverSelfId, MessageId::driver_raw_data, pd );
            initMessageDriver( msgRes, class_id_value, m_driverSelfId, MessageId::driver_raw_data, static_cast<IDriver*>( this ) );
            setMessageDriverRawData( msgRes, &buf[0], msg.rawData.dataSize, msg.rawData.deviceBusAddress );

            //dumpMsg(msgRes, "Sending from I2C");

            #ifdef RTKOS_RTKOS_H
            umba::rtkos::messagePost( msgRes );
            #endif
        }
        
        return true;

    }

    UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    /*
    virtual
    bool isReadyForPoll() override 
    {
        return true;
    }

    virtual
    void poll() override
    {
        using namespace umba::omanip;
        //UMBA_RTKOS_LOG<<"UART Polling"<<endl;

        uint8_t buf[8];
        size_t i = 0;
        while( m_uart.isNewByte() && i<8 )
        {
            buf[i++] = m_uart.getByte();
        }

        if (i>0)
        {
            //UMBA_RTKOS_LOG<<"UART Polling: some bytes received: "<<i<<endl;
            MessageDriver msg;
            initMessageDriver( msg, class_id_value, m_driverSelfId, MessageId::driver_raw_data, static_cast<IDriver*>( this ) );
            setMessageDriverRawData( msg, &buf[0], i );

            #ifdef RTKOS_RTKOS_H
            umba::rtkos::messagePost( msg );
            #endif
        }
    }
    */


protected:

//    umba::periph::GpioPinAddr  m_pwmPinAddr;
//    umba::periph::GpioPin      m_pwmPin; 

//    TIM_TypeDef               *TIMx       = 0;
//          m_pwmPin; 

    umba::periph::GpioPinAddr      m_pinSda;
    umba::periph::GpioPinAddr      m_pinScl;
    umba::periph::soft::SoftI2c    m_i2c;
    bool                           m_lastResult = false;

};


} // namespace periph
} // namespace drivers
} // namespace umba

