#pragma once

#include "gpio_driver_impl.h"
#include "device_state_indicator/device_state_indicator_impl_base.h"

namespace umba
{
namespace drivers
{
namespace periph
{

#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_device_state_indicator_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE


class DeviceStateIndicator2LedsDriver : public GpioDriverImplBase< class_id_state_indicator, subclass_id_hardware, PowerConsumptionClass::low, PowerConsumptionClass::low >
                                      , protected DeviceStateIndicatorImplBase
{

    typedef GpioDriverImplBase< class_id_state_indicator, subclass_id_hardware, PowerConsumptionClass::low, PowerConsumptionClass::low > BaseImpl;
    
public:

    UMBA_DRIVER_DESCRIPTION( "State indicator 2 LEDs" )

    DeviceStateIndicator2LedsDriver( umba::periph::GpioPinAddr errLedAddr
                                   , umba::periph::GpioPinAddr okLedAddr
                                   )
    : BaseImpl( umba::periph::PinMode::gpio_out_pp, umba::periph::PinSpeed::medium, errLedAddr, okLedAddr )
    {
    }

    DeviceStateIndicator2LedsDriver( DeviceStateIndicator2LedsDriver && ) = default;

    bool install( DriverId driverId = driver_id_auto )
    {
        #ifdef RTKOS_RTKOS_H
        if (!umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::normal ))
            return false;
        return umba::rtkos::driverInstall( DriverAddress(BaseImpl::class_id_value, driverId), BaseImpl::subclass_id_value, this );
        #endif
    }

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_device_state_indicator_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_device_state_indicator_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    virtual
    bool isReadyForPoll() override 
    {
        return true;
    }

    virtual
    void poll() override
    {
        DeviceStateIndicatorImplBase::poll();
    }

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);

        oss<<"State indicator";
        oss<<"; Pins: ";

        if (m_totalPinsTaken>m_numberOfPins)
        {
            oss<<" Too many pins taken";
        }
        else
        {
            for( size_t i = 0; i!=m_numberOfPins; ++i)
            {
                oss<<" "<<umba::periph::superunpackGpioPinAddr( m_packedPins[i] );
            }
        }

        return true; //isValidPinAddr(m_pinAdc);
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        using namespace umba::periph::traits;
        //auto addr = umba::periph::superunpackGpioPinAddr( m_packedPins[0] );
        //umba::periph::GpioPin pin = umba::periph::GpioPin( addr, m_pinsMode, m_pinsSpeed );
        //pin = m_initialState;
        return umba::errors::ok;
    }


    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        //auto addr = umba::periph::superunpackGpioPinAddr( m_packedPins[0] );
        //umba::periph::GpioPin pin = umba::periph::GpioPin( addr, m_pinsMode, m_pinsSpeed );
        //pin = !m_initialState;
        return umba::errors::ok;
    }

    virtual
    void handleIndicatorAction( Indicator indicator, IndicatorAction action ) override
    {
        umba::periph::GpioPinAddr ledAddr;
        if (indicator==Indicator::error_indicator)
            ledAddr = umba::periph::superunpackGpioPinAddr( m_packedPins[0] );
        else
            ledAddr = umba::periph::superunpackGpioPinAddr( m_packedPins[1] );

        umba::periph::GpioPin pin = umba::periph::GpioPin( ledAddr, m_pinsMode, m_pinsSpeed );

        switch(action)
        {
            case IndicatorAction::indicator_set:
                 pin = true;
                 break;
            case IndicatorAction::indicator_clear:
                 pin = false;
                 break;
            case IndicatorAction::indicator_toggle:
                 pin = !pin;
                 break;
       }
    }

/*
enum class DeviceState
{
    device_starting,
    standby        ,
    no_link        = standby,
    working        ,
    link_good      = working,
    //data_reception
};

    void setDeviceState( DeviceState s ) = 0;

    void setErrorState( bool fSet ) = 0;

    virtual
    bool isErrorState() const = 0;

    virtual
    void fatalError() = 0;

    void indicateDataReception() = 0;

    virtual
    void indicateInterraction() = 0;

UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_device_state_value                  , 0, "0 - standby/no link, 1 - working/link good " );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_device_activity_value               , 1, "0 - indicate data reception, 1 - indicate user interraction" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_device_error_value                  , 2, "0 - no error, 1 - error, 2 - fatal error" );


*/

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        using namespace umba::omanip;

        if (!isMessageDriverMine( msg, BaseImpl::m_driverSelfAddress ))
            return dumpMsg(msg);

        bool isSetCmd   = isMessageDriverMessageId( msg, MessageId::device_param_set );
        //bool isQueryCmd = isMessageDriverMessageId( msg, MessageId::device_param_request );

        if ( /* !isQueryCmd && */  !isSetCmd)
            return dumpMsg(msg, "Unsupported cmd for parameter");

        switch( msg.value.id )
        {
            case value_id_device_state_value:
                 {
                     uint32_t value = 0;
                     
                     if (!umba::drivers::extractFromMessageValue( msg.value, value /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");

                     if (value==0)
                         DeviceStateIndicatorImplBase::setDeviceState( DeviceState::standby );
                     else
                         DeviceStateIndicatorImplBase::setDeviceState( DeviceState::link_good );
                     
                 }
                 break;

            case value_id_device_activity_value:
                 {
                     uint32_t value = 0;
                     
                     if (!umba::drivers::extractFromMessageValue( msg.value, value /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");

                     if (value==0)
                         DeviceStateIndicatorImplBase::indicateDataReception();
                     else
                         DeviceStateIndicatorImplBase::indicateInterraction();
                     
                 }
                 break;

            case value_id_device_error_value:
                 {
                     uint32_t value = 0;
                     
                     if (!umba::drivers::extractFromMessageValue( msg.value, value /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");

                     if (value==0)
                         DeviceStateIndicatorImplBase::setErrorState( false );
                     else if (value==1)
                         DeviceStateIndicatorImplBase::setErrorState( true );
                     else
                         DeviceStateIndicatorImplBase::fatalError();
                 }
                 break;

            default: return dumpMsg(msg);
        };

        return true;
    }



protected:

};


} // namespace periph
} // namespace drivers
} // namespace umba
