#pragma once

#include "umba/time_service.h"

typedef umba::time_service::TimeTick TimeTick;

enum class DeviceState
{
    device_starting,
    standby        ,
    no_link        = standby,
    working        ,
    link_good      = working,
    //data_reception
};




struct DeviceStateIndicatorTimeouts
{
    TimeTick startupBlinkingTimeout          =   50;
    TimeTick startupIndicationTimeout        =  300;

    TimeTick standbyBlinkingTimeout          = 1000;

    TimeTick workingStateBlinkingTimeout     =  250;

    TimeTick dataReceptionBlinkingTimeout    =   20;
    TimeTick dataReceptionIndicationTimeout  =  200; //500;

    TimeTick interactionBlinkingTimeout      =   50;
    TimeTick interactionIndicationTimeout    =  200;

    TimeTick errorBlinkingTimeout            =  150;

    TimeTick fatalBlinkingTimeout            =  600;

};


class IDeviceStateIndicator
{
public:

    virtual
    void poll() = 0;

    virtual
    void setTimeouts( const DeviceStateIndicatorTimeouts &to ) = 0;

    virtual
    void getTimeouts( DeviceStateIndicatorTimeouts &to ) const = 0;

    virtual
    void setDeviceState( DeviceState s ) = 0;

    virtual
    DeviceState getDeviceState( ) const = 0;

    virtual
    void indicateDataReception() = 0;

    virtual
    void indicateInterraction() = 0;

    // Set or clear error state
    virtual
    void setErrorState( bool fSet ) = 0;

    virtual
    bool isErrorState() const = 0;

    virtual
    void fatalError() = 0;

}; // class IDeviceStateIndicator


#define UMBA_DEVICE_STATE_INDICATOR_HANDLE_FAULTS( devState )   \
    extern "C"                                                  \
    {                                                           \
        void HardFault_Handler( void )                          \
        {                                                       \
            (devState).fatalError();                            \
        }                                                       \
                                                                \
        void MemManage_Handler( void )                          \
        {                                                       \
            (devState).fatalError();                            \
        }                                                       \
                                                                \
        void UsageFault_Handler( void )                         \
        {                                                       \
            (devState).fatalError();                            \
        }                                                       \
                                                                \
        void BusFault_Handler( void )                           \
        {                                                       \
            (devState).fatalError();                            \
        }                                                       \
                                                                \
    }                                                           \
                                                                \
    struct __691CA36E_B6CD_4088_80A7_FAE4129E30CC__             \
    {}
