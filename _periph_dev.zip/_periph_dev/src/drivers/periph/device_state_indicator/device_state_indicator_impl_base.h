#pragma once

#include "i_device_state_indicator.h"


// Реализация соответствует спецификации RFCRTC002

class DeviceStateIndicatorImplBase : public IDeviceStateIndicator
{
protected:

    enum class InternalState
    {
        waiting_startup_blinking,
        startup_blinking,
        normal_work,
        data_reception_mode,
        interaction_mode
    };

    enum class Indicator
    {
        work_indicator,
        error_indicator
    };

    enum class IndicatorAction
    {
        indicator_set,
        indicator_clear,
        indicator_toggle
    };

    virtual
    void handleIndicatorAction( Indicator indicator, IndicatorAction action ) = 0;

public:

    virtual
    void setTimeouts( const DeviceStateIndicatorTimeouts &to ) override { m_timeouts = to; }

    virtual
    void getTimeouts( DeviceStateIndicatorTimeouts &to ) const override { to = m_timeouts; }

    virtual
    DeviceState getDeviceState( ) const override { return m_deviceState; }

    // Set or clear error state
    virtual
    void setErrorState( bool fSet ) override;

    virtual
    bool isErrorState() const override;

    virtual
    void poll() override;

    virtual
    void setDeviceState( DeviceState s ) override;

    virtual
    void indicateDataReception() override;

    virtual
    void indicateInterraction() override;

    virtual
    void fatalError() override;

    TimeTick getNow()
    {
        return umba::time_service::getCurTimeMs();
    }

protected:

    DeviceStateIndicatorTimeouts    m_timeouts;
    TimeTick                        m_blinkLastTick      = 0;
    TimeTick                        m_indicationLastTick = 0;
    TimeTick                        m_errorBlinkLastTick = 0;

    DeviceState                     m_deviceState   = DeviceState::device_starting;
    InternalState                   m_internalState = InternalState::waiting_startup_blinking;

    int                             m_errorCount    = 0;

    //TimeTick getCurTimeMs();
/*
enum class DeviceState
{
    device_starting,
    standby        ,
    no_link        = standby,
    working        ,
*/

}; // class DeviceStateIndicatorImplBase


