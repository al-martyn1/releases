#pragma once

#include "device_state_indicator_impl_base.h"

class DeviceStateIndicator : public DeviceStateIndicatorImplBase
{
protected:

    virtual
    void handleIndicatorAction( Indicator indicator, IndicatorAction action ) override;

};
