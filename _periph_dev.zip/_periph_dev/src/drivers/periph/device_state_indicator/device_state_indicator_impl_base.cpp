#include "device_state_indicator_impl_base.h"
//#include "umba/critical_section.h"

//UMBA_CRITICAL_SECTION( umba::globalCriticalSection );

using namespace umba::time_service;

//-----------------------------------------------------------------------------
void DeviceStateIndicatorImplBase::setErrorState( bool fSet )
{
    //UMBA_CRITICAL_SECTION( umba::globalCriticalSection );
    if (fSet) m_errorCount++;
    else      m_errorCount--;

    if (!m_errorCount)
    {   // becomes no error
        handleIndicatorAction( Indicator::error_indicator, IndicatorAction::indicator_clear );
    }
    else if (m_errorCount>0)
    {
        // becomes error state
        handleIndicatorAction( Indicator::error_indicator, IndicatorAction::indicator_set );
        m_errorBlinkLastTick = getNow();
    }
}

//-----------------------------------------------------------------------------
bool DeviceStateIndicatorImplBase::isErrorState() const
{
    return m_errorCount>0;
}

//-----------------------------------------------------------------------------
void DeviceStateIndicatorImplBase::poll()
{
    auto tickNow = getNow();

    if (isErrorState() && m_internalState!=InternalState::startup_blinking)
    {
        auto dt = tickNow - m_errorBlinkLastTick;
        if (dt>=m_timeouts.errorBlinkingTimeout)
        {
            m_errorBlinkLastTick = tickNow;
            handleIndicatorAction( Indicator::error_indicator, IndicatorAction::indicator_toggle );
        }
    }

    switch(m_internalState)
    {
        case InternalState::waiting_startup_blinking:
             {
                 //m_deviceState   = s;
                 m_blinkLastTick = tickNow;
                 m_indicationLastTick = tickNow;
                 m_internalState = InternalState::startup_blinking;
             }
             break;
        //case InternalState::waiting_startup_blinking:
        //     break;
        case InternalState::startup_blinking:
             {
                 auto dtb = tickNow - m_blinkLastTick;
                 if (dtb>=m_timeouts.startupBlinkingTimeout)
                 {
                     m_blinkLastTick = tickNow;
                     handleIndicatorAction( Indicator::work_indicator, IndicatorAction::indicator_toggle );
                     handleIndicatorAction( Indicator::error_indicator, IndicatorAction::indicator_toggle );
                 }

                 auto dti = tickNow - m_indicationLastTick;
                 if (dti>=m_timeouts.startupIndicationTimeout)
                 {
                     handleIndicatorAction( Indicator::error_indicator, IndicatorAction::indicator_clear );
                     m_blinkLastTick = tickNow;
                     m_internalState = InternalState::normal_work;
                     if (m_deviceState == DeviceState::device_starting)
                         m_deviceState   = DeviceState::standby;
                 }
             }
             break;
/*
    device_starting,
    standby        ,
    no_link        = standby,
    working        ,
    link_good      = working,
*/

        case InternalState::normal_work:
             {
                 auto to = m_deviceState==DeviceState::standby 
                         ? m_timeouts.standbyBlinkingTimeout 
                         : m_timeouts.workingStateBlinkingTimeout
                         ;
                 auto dt = tickNow - m_blinkLastTick;
                 if (dt >= to)
                 {
                     m_blinkLastTick = tickNow;
                     handleIndicatorAction( Indicator::work_indicator, IndicatorAction::indicator_toggle );
                 }
             }
             break;

        case InternalState::data_reception_mode:
        case InternalState::interaction_mode:
             {
                 auto toBlink = m_internalState==InternalState::data_reception_mode 
                         ? m_timeouts.dataReceptionBlinkingTimeout 
                         : m_timeouts.interactionBlinkingTimeout
                         ;
                 auto toAct = m_internalState==InternalState::data_reception_mode 
                         ? m_timeouts.dataReceptionIndicationTimeout
                         : m_timeouts.interactionIndicationTimeout
                         ;
                 auto dtb = tickNow - m_blinkLastTick;
                 if (dtb>=toBlink)
                 {
                     m_blinkLastTick = tickNow;
                     handleIndicatorAction( Indicator::work_indicator, IndicatorAction::indicator_toggle );
                 }

                 auto dti = tickNow - m_indicationLastTick;
                 if (dti>=toAct)
                 {
                     m_blinkLastTick = tickNow;
                     m_internalState = InternalState::normal_work;
                 }
             }
             break;
    }

}

//-----------------------------------------------------------------------------
/*

    enum class InternalState
    {
        waiting_startup_blinking,
        startup_blinking,
        normal_work,
        data_reception_mode,
        interaction_mode
    };

enum class DeviceState
{
    device_starting,
    standby        ,
    no_link        = standby,
    working        ,
    link_good      = working,
    //data_reception
};

*/
void DeviceStateIndicatorImplBase::setDeviceState( DeviceState s )
{
    auto tickNow = getNow();

    switch(m_internalState)
    {
        case InternalState::waiting_startup_blinking:
             {
                 m_deviceState   = s;
                 m_blinkLastTick = tickNow;
                 m_indicationLastTick = tickNow;
                 m_internalState = InternalState::startup_blinking;
             }
             break;

        case InternalState::startup_blinking:
        case InternalState::normal_work:
        case InternalState::data_reception_mode:
        case InternalState::interaction_mode:
             {
                 if (s==DeviceState::standby || s==DeviceState::working)
                     m_deviceState   = s;
             }
             break;
    }         

}

//-----------------------------------------------------------------------------
void DeviceStateIndicatorImplBase::indicateDataReception()
{
    if (m_internalState!=InternalState::normal_work)
        return;
    auto tickNow = getNow();
    m_blinkLastTick      = tickNow;
    m_indicationLastTick = tickNow;

    m_internalState = InternalState::data_reception_mode;

}

//-----------------------------------------------------------------------------
void DeviceStateIndicatorImplBase::indicateInterraction()
{
    auto tickNow = getNow();
    m_blinkLastTick      = tickNow;
    m_indicationLastTick = tickNow;

    m_internalState = InternalState::interaction_mode;
}

//-----------------------------------------------------------------------------
void DeviceStateIndicatorImplBase::fatalError()
{
    auto t = SystemCoreClock;
    t /= 10000;
    t *= m_timeouts.fatalBlinkingTimeout;
    t /= 2;

    handleIndicatorAction( Indicator::work_indicator , IndicatorAction::indicator_clear );
    handleIndicatorAction( Indicator::error_indicator, IndicatorAction::indicator_set );

    while(true)
    {
        for( auto i = 0; i!= t; ++i) {}
        handleIndicatorAction( Indicator::work_indicator , IndicatorAction::indicator_toggle );
        handleIndicatorAction( Indicator::error_indicator, IndicatorAction::indicator_toggle );
    }
    
}

//-----------------------------------------------------------------------------




