#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "scalcus/pwm.h"
#include "scalcus/percent.h"

#include "periph/periph.h"




namespace umba
{
namespace drivers
{
namespace periph
{

/*
ValueId esc_pwm_freq                 = 100; // uint32 Hz
ValueId esc_pwm_duration_off         = 800;
ValueId esc_pwm_duration_duty        = 1100; // 
ValueId esc_pwm_duration_max         = 1700;
ValueId esc_pwm_command              = 0;
*/

/*
ValueId value_id_esc_pwm_freq                 = 0;
ValueId value_id_esc_pwm_duration_off         = 1;
ValueId value_id_esc_pwm_duration_duty        = 2;
ValueId value_id_esc_pwm_duration_max         = 3;
ValueId value_id_esc_pwm_command              = 4; // off, on/hh, on
ValueId value_id_esc_pwm_duration_target      = 5; // целевая скорость
*/

#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_tim_pwm_device_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE



class TimPwmDriver : public DriverImplBase< class_id_tim_pwm, subclass_id_hardware, PowerConsumptionClass::medium >
{

    typedef DriverImplBase< class_id_tim_pwm, subclass_id_hardware, PowerConsumptionClass::medium > BaseImpl;
    
public:

    UMBA_DRIVER_DESCRIPTION( "TIM PWM" )

    TimPwmDriver( TIM_TypeDef  *TIMx, unsigned chNo, umba::periph::GpioPinAddr pinPwm )
    : BaseImpl()
    , m_TIMx(TIMx)
    , m_timChannel(chNo)
    , m_pinPwm(pinPwm)
    {
    }


    TimPwmDriver( TimPwmDriver && ) = default;

    bool install( DriverId driverId = driver_id_device_number )
    {
        #ifdef RTKOS_RTKOS_H
        if ( driverId == driver_id_device_number )
            driverId = (DriverId)umba::periph::periphGetNo( m_TIMx );
        return umba::rtkos::driverInstall( DriverAddress(class_id_value, driverId), subclass_id_value, this );
        #endif
    }



    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_tim_pwm_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_tim_pwm_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);
        //umba::ihc::IhcOctetStreamCharWriter writter(pStreamTo);
        //umba::SimpleFormatter oss( &writter );

        oss<<"TIM#"<<umba::periph::periphGetNo( m_TIMx )<<" CH:"<<m_timChannel<<" PWM:"<<m_pinPwm;

        return umba::periph::isValidPinAddr(m_pinPwm) && ( m_timChannel>=1 && m_timChannel<=4);
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }


    void stopTimer()
    {
        using namespace umba::periph::traits;
        timerEnable( m_TIMx, DISABLE );
    }

    void startTimer()
    {
        configureBase(true);
        using namespace umba::periph::traits;
        timerEnable( m_TIMx, ENABLE );
       
        timerSetCaptureCompareRegister( m_TIMx, m_timChannel, 1 );
    }

    // Requires timer to be stopped
    void configureBase( bool bFinal = true)
    {
        using namespace umba::periph::traits;

        uint16_t prescalerT1 = 0;
        uint16_t periodT1    = 0;
       
        scalcus::calcTimerPwmPrescalerAndPeriod( SystemCoreClock, m_pwmFreq, prescalerT1, periodT1 );
        m_pwmPulseOutputMax = periodT1;
       
        umba::periph::traits::timerBaseInit( m_TIMx, prescalerT1, periodT1 ); 
        umba::periph::traits::timerInitChannelPwm( m_TIMx, m_timChannel, m_pinPwm.port, m_pinPwm.pinNo, (periodT1+1)/m_pwmFreq-1, TIM_OCMode_PWM2 );
        
    }

    // On the fly
    void configureTimerPwm( unsigned pwmCtrl )
    {
        using namespace umba::periph::traits;

        umba::periph::traits::timerPwmControl( m_TIMx , m_timChannel
                                             , m_pwmFreq, m_pwmPulseOutputMax
                                             , m_dutyMode ? umba::periph::traits::TimerPwmControlType::microsecs : umba::periph::traits::TimerPwmControlType::permille
                                             , pwmCtrl
                                             );
    }

    void configureTimerPwm( )
    {
        configureTimerPwm( m_duty );
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        using namespace umba::periph::traits;
        configureBase(false);
        stopTimer();
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        using namespace umba::omanip;

        if (!isMessageDriverMine( msg, m_driverSelfAddress ))
            return dumpMsg(msg);

        bool isSetCmd   = isMessageDriverMessageId( msg, MessageId::device_param_set );
        bool isQueryCmd = isMessageDriverMessageId( msg, MessageId::device_param_request );

        if (!isSetCmd && !isQueryCmd)
            return dumpMsg(msg, "Unsupported message id");

        switch( msg.value.id )
        {
            case value_id_tim_pwm_freq: // "PWM Freq, Hz (default: 100Hz)"
                 {
                     if (isQueryCmd)
                     {
                         postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_tim_pwm_freq, m_pwmFreq, static_cast<IDriver*>(this) );
                     }
                     else
                     {
                         // m_pwmMode
                         //uint32_t  m_pwmFreq
                         uint32_t putTo = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                            return dumpMsg(msg, "Error in format");
                         m_pwmFreq = putTo;
                         if (m_pwmMode)
                         {
                             stopTimer();
                             startTimer();
                         }
                     }
                 }
                 break;

            case value_id_tim_pwm_duty: // "Duty pulse, time in usec or permille"
                 {
                     if (isQueryCmd)
                     {
                         postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_tim_pwm_duty, m_duty, static_cast<IDriver*>(this) );
                     }
                     else
                     {
                         uint32_t putTo = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                            return dumpMsg(msg, "Error in format");

                         m_duty = putTo;
                         if (m_pwmMode)
                            configureTimerPwm( ); // change on the fly
                     }
                 }
                 break;

            case value_id_tim_pwm_duty_mode: // "Duty mode: 0 - permille (default), 1 - time in usec"
                 {
                     if (isQueryCmd)
                     {
                         postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_tim_pwm_duty_mode, m_dutyMode, static_cast<IDriver*>(this) );
                     }
                     else
                     {
                         uint8_t putTo = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                            return dumpMsg(msg, "Error in format");

                         if (m_pwmMode)
                             stopTimer();
                         m_dutyMode = putTo;
                         m_pwmMode = 0; // off
                     }
                 }
                 break;

            case value_id_tim_pwm_idling_level: // "Output level whuile idling, default - 0 (set to 1 not implemented currently)"
                 {
                     // UNDONE: !!!
                 }
                 //break;
                 return dumpMsg(msg);

            case value_id_tim_pwm_ctrl: // "0 - OFF, 1 - ON"
                 {
                     if (isQueryCmd)
                     {
                         postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_tim_pwm_ctrl, m_pwmMode, static_cast<IDriver*>(this) );
                     }
                     else
                     {
                         uint8_t putTo = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                            return dumpMsg(msg, "Error in format");

                         m_pwmMode = putTo;
                         if (!m_pwmMode)
                         {
                             stopTimer();
                         }
                         else
                         {
                             startTimer();
                             configureTimerPwm( );
                         }
                     }
                 }
                 break;

            default: return dumpMsg(msg);
        };

        return true;
    }


protected:

    TIM_TypeDef                *m_TIMx;
    unsigned                    m_timChannel;
    umba::periph::GpioPinAddr   m_pinPwm;

    uint32_t                    m_pwmFreq  = 100;
    uint32_t                    m_duty     = 0;
    uint8_t                     m_dutyMode = 0; // 0 - permille, 1 - usec
    uint8_t                     m_pwmMode  = 0; // off

    unsigned                    m_pwmPulseOutputMax = 0;

};


} // namespace periph
} // namespace drivers
} // namespace umba

