UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_power_state_value                  , 0, "On/Off" );
