UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_value                  , 0, "ADC value" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_value_percent          , 1, "ADC value in percents of max" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_value_permille         , 2, "ADC value in permilles of max" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_bits                   , 3, "Number of bits in sample" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_max_value              , 4, "Max ADC value" );
//UMBA_DRIVER_DECLARE_VALUE_ID_CODE( , , "" )
