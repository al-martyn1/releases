#pragma once

#include "gpio_driver_impl.h"


#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_power_switch_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE



namespace umba
{
namespace drivers
{
namespace periph
{

#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_power_switch_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE


class PowerSwitchDriver : public GpioDriverImplBase< class_id_power_switch, subclass_id_hardware, PowerConsumptionClass::medium, PowerConsumptionClass::medium >
{

    typedef GpioDriverImplBase< class_id_power_switch, subclass_id_hardware, PowerConsumptionClass::medium, PowerConsumptionClass::medium > BaseImpl;
    
public:

    UMBA_DRIVER_DESCRIPTION( "Power switch" )

    PowerSwitchDriver( umba::periph::GpioPinAddr pinAddr
                     , bool                      initialState
                     , PowerConsumptionClass     powerConsumption = PowerConsumptionClass::medium
                     , umba::periph::PinSpeed    pinsSpeed        = umba::periph::PinSpeed::medium
                     )
    : BaseImpl( umba::periph::PinMode::gpio_out_pp, pinsSpeed, pinAddr )
    , m_initialState(initialState)
    , m_powerConsumption(powerConsumption)
    {
    }

    PowerSwitchDriver( PowerSwitchDriver && ) = default;

    bool install( DriverId driverId = driver_id_auto )
    {
        #ifdef RTKOS_RTKOS_H
        return umba::rtkos::driverInstall( DriverAddress(BaseImpl::class_id_value, driverId), BaseImpl::subclass_id_value, this );
        #endif
    }

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_power_switch_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_power_switch_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE


    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);

        oss<<"Power switch";

        oss<<"; Power consumption: ";
        switch(m_powerConsumption)
        {
            case PowerConsumptionClass::low:     oss<<"Low"; break;
            case PowerConsumptionClass::medium:  oss<<"Medium"; break;
            case PowerConsumptionClass::high:    oss<<"High"; break;
            case PowerConsumptionClass::very:    oss<<"Very high"; break;
            default: return false; // cause kernel panic
        }

        oss<<"; Pin: ";

        if (m_totalPinsTaken>m_numberOfPins)
        {
            oss<<" Too many pins taken";
        }
        else
        {
            for( size_t i = 0; i!=m_numberOfPins; ++i)
            {
                oss<<" "<<umba::periph::superunpackGpioPinAddr( m_packedPins[i] );
            }
        }

        return true; //isValidPinAddr(m_pinAdc);
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        using namespace umba::periph::traits;
        auto addr = umba::periph::superunpackGpioPinAddr( m_packedPins[0] );
        umba::periph::GpioPin pin = umba::periph::GpioPin( addr, m_pinsMode, m_pinsSpeed );
        pin = m_initialState;
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        auto addr = umba::periph::superunpackGpioPinAddr( m_packedPins[0] );
        umba::periph::GpioPin pin = umba::periph::GpioPin( addr, m_pinsMode, m_pinsSpeed );
        pin = !m_initialState;
        return umba::errors::ok;
    }

    virtual
    PowerConsumptionClass getPowerClass(const DriverAddress &driverAddress) override
    {
        if (!m_driverHardwareStarted)
            return PowerConsumptionClass::low;
        return m_powerConsumption;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        using namespace umba::omanip;

        if (!isMessageDriverMine( msg, BaseImpl::m_driverSelfAddress ))
            return dumpMsg(msg);

        bool isSetCmd   = isMessageDriverMessageId( msg, MessageId::device_param_set );
        //bool isQueryCmd = isMessageDriverMessageId( msg, MessageId::device_param_request );

        if ( /* !isQueryCmd && */  !isSetCmd)
            return dumpMsg(msg, "Unsupported cmd for parameter");

        switch( msg.value.id )
        {
            case value_id_gpio_value:
                 {
                     uint32_t value = 0;

                     umba::drivers::extractFromMessageValue( msg.value, value /* ValueInfoFlags *pInfoFlags */ );

                     auto addr = umba::periph::superunpackGpioPinAddr( m_packedPins[0] );
                     umba::periph::GpioPin pin = umba::periph::GpioPin( addr, m_pinsMode, m_pinsSpeed );
                     pin = value ? !m_initialState : m_initialState;
                 }
                 break;

            default: return dumpMsg(msg);
        };

        return true;
    }


protected:

    bool                     m_initialState;
    PowerConsumptionClass    m_powerConsumption;

};


} // namespace periph
} // namespace drivers
} // namespace umba
