UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_mul                    , 0, "ADC value multiplier, default: 1, used to produce output as val*mult/div" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_div                    , 1, "ADC value divider, default: 1, used to produce output as val*mult/div" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_scale                  , 2, "ADC value float scaler, used instead of mult/div" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_zero                   , 3, "ADC zero offset value" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_clamp                  , 4, "ADC clamp value" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_filter                 , 5, "ADC filtering mode: 0-none, 1-Avg, 2-Median, 3-Median Avg, 4-Min, 5-Max" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_filter_size            , 6, "ADC filtering buffer size" );

