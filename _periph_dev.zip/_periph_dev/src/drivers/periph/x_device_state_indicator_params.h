UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_device_state_value                  , 0, "0 - standby/no link, 1 - working/link good " );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_device_activity_value               , 1, "0 - indicate data reception, 1 - indicate user interraction" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_device_error_value                  , 2, "0 - no error, 1 - error, 2 - fatal error" );
