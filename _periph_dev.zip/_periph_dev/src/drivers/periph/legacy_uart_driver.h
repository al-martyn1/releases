#pragma once

#include "luart/uart_handle.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"
#include "ihc/octet_stream_buf.h"

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"
#include "periph/periph.h"


#ifdef LUART_UART_HANDLE_H
    //#error "LUART_UART_HANDLE_H defined"
#else
    #error "LUART_UART_HANDLE_H NOT defined"
#endif


// #define UMBA_DRIVERS_LEGACY_UART_DRIVER_LOG_RAW_DATA_IN_OUT



namespace umba
{
namespace drivers
{
namespace periph
{


umba::SimpleFormatter& dump( const uint8_t *pData, size_t dataSize = 8 ) 
{
    using namespace umba::omanip;
    for( size_t i = 0; i!=dataSize; ++i )
    {
        if (i)
           UMBA_RTKOS_LOG<<" ";
        UMBA_RTKOS_LOG<<noshowbase<<hex<<width(2)<<pData[i];
    }

    return UMBA_RTKOS_LOG;
}

umba::SimpleFormatter& dumpEscaped( const uint8_t *pData, size_t dataSize = 8 ) 
{
    using namespace umba::omanip;
    for( size_t i = 0; i!=dataSize; ++i )
    {
        char ch = (char)pData[i];
        if (ch<' ')
        {
            if (ch=='\r')
                UMBA_RTKOS_LOG<<"\\r";
            else if (ch=='\n')
                UMBA_RTKOS_LOG<<"\\n";
            else if (ch=='\t')
                UMBA_RTKOS_LOG<<"\\t";
            else
                UMBA_RTKOS_LOG<<"\\"<<hex<<width(2)<<pData[i];
        }
        else
        {
            UMBA_RTKOS_LOG<<ch;
        }
    }

    return UMBA_RTKOS_LOG;
}


//#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
//#include "x_esc_device_params.h"
//#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE



class LegacyUartDriver : public DriverImplBase< class_id_stream, subclass_id_uart, PowerConsumptionClass::low >
{

    typedef DriverImplBase< class_id_stream, subclass_id_uart, PowerConsumptionClass::low > BaseImpl;

public:

    UMBA_DRIVER_DESCRIPTION( "UART" )

     /* UART_TypeDef *pUart */ 
    LegacyUartDriver( uart::Handle &handle
                    , umba::periph::GpioPinAddr pinAddrRx
                    , umba::periph::GpioPinAddr pinAddrTx
                    , unsigned                  portSpeed
                    , umba::periph::GpioPinAddr pinAddrRs485 = umba::periph::GpioPinAddr{ 0, 0 }
                    )
    : BaseImpl()
    , m_uart(handle)
    , m_pinAddrRx   (pinAddrRx   )
    , m_pinAddrTx   (pinAddrTx   )
    , m_portSpeed   (portSpeed   )
    , m_pinAddrRs485(pinAddrRs485)
    {
    }

    LegacyUartDriver( LegacyUartDriver && ) = default;

    bool install( DriverId driverId = driver_id_device_number )
    {
        #ifdef RTKOS_RTKOS_H
        if ( driverId == driver_id_device_number )
            driverId = (DriverId)umba::periph::periphGetNo( &m_uart );

        if (!umba::rtkos::messageFilterAdd( this ))
            return false;

        if (!umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::normal ))
            return false;
        return umba::rtkos::driverInstall( DriverAddress(class_id_value, driverId), subclass_id_value, this );
        #endif
        // TimerId timerSet ( Object *pObj, TimerEventId eventId, TimeTick period )
    }


    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NO_PARAMS()

    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT() // не является клиентом другого драйвера

    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    /*
    virtual
    bool onFilterMessage( umba::rtkos::Message &msg ) override
    {
        return false;
    }
    */

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);


        oss<<"UART#"<<umba::periph::periphGetNo( &m_uart )<<" RX:"<<m_pinAddrRx<<" TX:"<<m_pinAddrTx<<", "<<m_portSpeed;

        if (umba::periph::isValidPinAddr(m_pinAddrRs485))
        {
            oss<<", RS485 CTRL: "<<m_pinAddrRs485;
        }

        return umba::periph::isValidPinAddr(m_pinAddrTx) && umba::periph::isValidPinAddr(m_pinAddrRx);
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        if (!m_uart.isInited())
        {
            if (!umba::periph::isValidPinAddr(m_pinAddrRs485))
            {
                m_uart.init( m_pinAddrRx.port, m_pinAddrRx.pinNo
                           , m_pinAddrTx.port, m_pinAddrTx.pinNo
                           , m_portSpeed
                           );
            }
            else
            {
                m_uart.init( m_pinAddrRx.port, m_pinAddrRx.pinNo
                           , m_pinAddrTx.port, m_pinAddrTx.pinNo
                           , m_portSpeed
                           , m_pinAddrRs485.port
                           , 1<<m_pinAddrRs485.pinNo
                           );
            }
        }

        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        // Send data here
        //if (msg.id!=message_driver_id)
        //    return false;

        //if (msg.messageDriver.header.pDriver!=0) // пришло не от клиента - какая-то ошибка
        //    return false;

        if (msg.header.classId!=class_id_value) // пришло не нам
            return false;

        if (msg.header.driverId!=m_driverSelfId) // пришло не нам
            return false;

        if (msg.header.driverMessageId!=MessageId::driver_raw_data) // UART не умеет работать по запросу данных - он только сам асинхронно принимает
            return false;

        // msg.messageDriver.rawData.deviceBusAddress - UART не имеет адресации на физическом уровне
        // На 485 интерфейсе может быть организована логическая адресация, но мы об этом ничего не знаем

        using namespace umba::omanip;
        #if defined(UMBA_DRIVERS_LEGACY_UART_DRIVER_LOG_RAW_DATA_IN_OUT)
        UMBA_RTKOS_LOG<<"UART#"<<umba::periph::periphGetNo( &m_uart )<<" OUT: ";
        //UMBA_RTKOS_LOG<<"PORT OUT: ";
        dump( msg.rawData.data, msg.rawData.dataSize );
        UMBA_RTKOS_LOG<<" - ";
        dumpEscaped( msg.rawData.data, msg.rawData.dataSize );
        UMBA_RTKOS_LOG<<endl;
        #endif

        if (isOsStarted())
        {
            m_uart.sendLocalArray( msg.rawData.data, msg.rawData.dataSize );
        }
        
        return true;
    }

    // UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    virtual
    bool isReadyForPoll() override 
    {
        return true;
    }

    virtual
    void poll() override
    {
        using namespace umba::omanip;
        //UMBA_RTKOS_LOG<<"UART Polling"<<endl;

        MessageDriver  msg;
        initMessageDriver( msg, class_id_value, m_driverSelfId, MessageId::driver_raw_data, this );

        const size_t msgBufSize = sizeof(MessageDriverRawData::data);
        const size_t maxSize    = msgBufSize;
        uint8_t buf[ maxSize ];
        size_t i = 0;

        while( m_uart.isNewByte() )
        {
            i = 0;
            while( m_uart.isNewByte() && i < sizeof(buf) )
            {
                buf[i++] = m_uart.getByte();
            }
            
            size_t readedNow = i;
            i = 0;

            if (readedNow)
            {
                if (isOsStarted()) // отправляем в очередь, если ось стартовала, иначе - просто выгребаем
                {
                    #if defined(UMBA_DRIVERS_LEGACY_UART_DRIVER_LOG_RAW_DATA_IN_OUT)
                    UMBA_RTKOS_LOG<<"UART#"<<umba::periph::periphGetNo( &m_uart )<<" IN : ";
                    //UMBA_RTKOS_LOG<<"PORT IN : ";
                    dump( buf, readedNow );
                    UMBA_RTKOS_LOG<<" - ";
                    dumpEscaped(buf, readedNow);
                    UMBA_RTKOS_LOG<<"\n";
                    #endif
                   
                    setMessageDriverRawData( msg, (uint8_t*)&buf[0], readedNow, invalid_device_bus_address );
                    #ifdef RTKOS_RTKOS_H
                    umba::rtkos::messagePost( msg );
                    #endif
                }
            }
            else
            {
                break;
            }

        /* UMBA_RTKOS_LOG<<width(6)<<"  Golem: ";
         * for (BaseProtocol::StreamSize i = 0; i!=pktSize; ++i)
         * {
         *     UMBA_RTKOS_LOG<<(char)pkt[i];
         * }
         * UMBA_RTKOS_LOG<<", RAW: ";
         * dump( pkt, pktSize );
         * UMBA_RTKOS_LOG<<endl;
         */


        }

        #if 0
        size_t i = 0;
        while( m_uart.isNewByte() && i < sizeof(buf) )
        {
            buf[i++] = m_uart.getByte();
        }

        MessageDriver  msg;
        //StreamSize max_packet_size = sizeof(msg.rawData.data);

        initMessageDriver( msg, m_streamDriverAddr, MessageId::driver_raw_data,  /* IDriver */ 0 );

        while(nOctets>max_packet_size)
        {
            setMessageDriverRawData( msg, (uint8_t*)pData, max_packet_size, invalid_device_bus_address );
            umba::rtkos::messagePost( msg );
            nOctets -= max_packet_size;
            pData   += max_packet_size;
        }

        if (nOctets) 
        {
            setMessageDriverRawData( msg, (uint8_t*)pData, nOctets, invalid_device_bus_address );
            umba::rtkos::messagePost( msg );
        }


        size_t totalReceived = i;
        for( i = 0; i >= msgBufSize; )
        while (i>0)
        {
            //UMBA_RTKOS_LOG<<"UART Polling: some bytes received: "<<i<<endl;
            MessageDriver msg;
            initMessageDriver( msg, class_id_value, m_driverSelfId, MessageId::driver_raw_data, static_cast<IDriver*>( this ) );
            setMessageDriverRawData( msg, &buf[0], i );

            #ifdef RTKOS_RTKOS_H
            umba::rtkos::messagePost( msg );
            #endif
        }
        #endif
    }



protected:

//    umba::periph::GpioPinAddr  m_pwmPinAddr;
//    umba::periph::GpioPin      m_pwmPin; 

//    TIM_TypeDef               *TIMx       = 0;
//          m_pwmPin; 

    uart::Handle                   &m_uart;
    umba::periph::GpioPinAddr      m_pinAddrRx;
    umba::periph::GpioPinAddr      m_pinAddrTx;
    unsigned                       m_portSpeed;
    umba::periph::GpioPinAddr      m_pinAddrRs485 = umba::periph::GpioPinAddr{ 0, 0 };

};


} // namespace periph
} // namespace drivers
} // namespace umba

