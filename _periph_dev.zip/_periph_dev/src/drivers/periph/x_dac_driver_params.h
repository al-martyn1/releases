UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_dac_mul                    , 0, "DAC value multiplier, default: 1, used to produce output as val*mult/div" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_dac_div                    , 1, "DAC value divider, default: 1, used to produce output as val*mult/div" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_dac_scale                  , 2, "DAC value float scaler, used instead of mult/div" );
