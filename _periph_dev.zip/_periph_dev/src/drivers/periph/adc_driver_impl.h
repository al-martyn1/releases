#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "scalcus/pwm.h"
#include "scalcus/percent.h"

#include "periph/periph.h"

#include "scalcus/averager.h"


namespace umba
{
namespace drivers
{
namespace periph
{


#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_adc_device_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE


template <typename AdcObject>
class AdcDriver : public DriverImplBase< class_id_adc, subclass_id_hardware, PowerConsumptionClass::medium >
{

    typedef DriverImplBase< class_id_adc, subclass_id_hardware, PowerConsumptionClass::medium > BaseImpl;
    
public:

    UMBA_DRIVER_DESCRIPTION( "ADC" )

    AdcDriver( AdcObject &adcObject, size_t avgNumber, umba::periph::GpioPinAddr pinAdc, umba::periph::GpioPinAddr pinAdcCtrlOnOff, bool valueOn = true)
    : BaseImpl()
    , m_adc(adcObject)
    , averager()
    , m_pinAdc(pinAdc)
    , m_pinAdcCtrlOnOff(pinAdcCtrlOnOff)
    , m_pinValueOn(valueOn)
    {
        averager.setMaxCount(avgNumber);
    }

    AdcDriver( AdcDriver && ) = default;

    bool install( DriverId driverId = driver_id_auto )
    {
        #ifdef RTKOS_RTKOS_H
        if (!umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::high /* normal */  ))
            return false;

        return umba::rtkos::driverInstall( DriverAddress(class_id_value, driverId), subclass_id_value, this );
        #endif
    }


    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_adc_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_adc_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    //UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);
        //umba::ihc::IhcOctetStreamCharWriter writter(pStreamTo);
        //umba::SimpleFormatter oss( &writter );

        oss<<"ADC "<<m_pinAdc;
        if (umba::periph::isValidPinAddr(m_pinAdcCtrlOnOff))
        {
            oss<<"On/OFF:"<<m_pinAdcCtrlOnOff;
        }

        return umba::periph::isValidPinAddr(m_pinAdc);
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        using namespace umba::periph::traits;
        if (isValidPinAddr(m_pinAdcCtrlOnOff))
        {
            umba::periph::GpioPin pin = umba::periph::GpioPin( m_pinAdcCtrlOnOff, umba::periph::PinMode::gpio_out_pp );
            pin = m_pinValueOn; // true;
        }
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    bool isReadyForPoll() override 
    {
        return true;
    }

    virtual
    void poll() override
    {
        using namespace umba::omanip;
        //UMBA_RTKOS_LOG<<"UART Polling"<<endl;
        uint16_t val = m_adc;

        rawLast = val;

        //if (rawLast) // костыль - игнорировать нулевые значения
            averager.addValue(rawLast);
    }

    uint16_t getValue()
    {
        avg       = averager.getAverageValue( );
        median    = averager.getMedianValue();
        medianAvg = averager.getAverageMedianValue();
        maxVal    = averager.getMax();

        //return averager.getAverageValue( );
        return avg;
        //return maxVal;
    }



    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        using namespace umba::omanip;

        if (!isMessageDriverMine( msg, m_driverSelfAddress ))
            return dumpMsg(msg);

        //bool isSetCmd   = isMessageDriverMessageId( msg, MessageId::device_param_set );
        bool isQueryCmd = isMessageDriverMessageId( msg, MessageId::device_param_request );

        if (!isQueryCmd)
            return dumpMsg(msg, "Unsupported cmd for parameter");

        switch( msg.value.id )
        {
            case value_id_adc_value:
                 {
                     postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_adc_value, getValue(), static_cast<IDriver*>(this) );
                 }
                 break;

            case value_id_adc_value_percent:
                 {
                     uint32_t val = (uint32_t)getValue();
                     val = 100 * val / 4095;
                     postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_adc_value_percent, (uint16_t)val, static_cast<IDriver*>(this) );
                 }
                 break;

            case value_id_adc_value_permille:
                 {
                     uint32_t val = (uint32_t)getValue();
                     val = 1000 * val / 4095;
                     postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_adc_value_permille, (uint16_t)val, static_cast<IDriver*>(this) );
                 }
                 break;

            case value_id_adc_bits:
                 {
                     uint16_t bits = 12;
                     postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_adc_bits, bits, static_cast<IDriver*>(this) );
                 }
                 break;

            case value_id_adc_max_value:
                 {
                     uint16_t maxRawVal = 4095;
                     postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_adc_max_value, maxRawVal, static_cast<IDriver*>(this) );
                 }
                 break;

            default: return dumpMsg(msg);
        };

        return true;
    }

protected:

    AdcObject                                      &m_adc;
    scalcus::Averager<uint16_t,uint32_t,8>         averager;
    umba::periph::GpioPinAddr                      m_pinAdc;
    umba::periph::GpioPinAddr                      m_pinAdcCtrlOnOff;
    bool                                           m_pinValueOn;

    uint16_t                                rawLast;
    uint16_t                                avg;
    uint16_t                                median;
    uint16_t                                medianAvg;
    uint16_t                                maxVal;


};


template<typename AdcObject>
inline
AdcDriver<AdcObject> makeAdcDriver( AdcObject &&obj
                                  , size_t avgSize
                                  , umba::periph::GpioPinAddr pinAdc
                                  , umba::periph::GpioPinAddr pinAdcCtrlOnOff = umba::periph::invalid_pin_addr
                                  , bool valueOn = true
                                  )
{
    return AdcDriver<AdcObject>( obj, avgSize, pinAdc, pinAdcCtrlOnOff, valueOn);
    //return std::move( AdcDriver<AdcObject>( obj, pinAdc, pinAdcCtrlOnOff) );
}



} // namespace periph
} // namespace drivers
} // namespace umba

