UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_id_hardware        ,  0xA8B580B0, "HW periph" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_id_software        ,  0x4C04545F, "Soft emulation" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_id_uart            ,  0xDAF1011A, "UART" );

