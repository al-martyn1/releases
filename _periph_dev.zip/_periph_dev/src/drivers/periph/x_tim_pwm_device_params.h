UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_tim_pwm_freq               , 0, "PWM Freq, Hz (default: 100Hz)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_tim_pwm_duty               , 1, "Duty pulse, time in usec or permille" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_tim_pwm_duty_mode          , 2, "Duty mode: 0 - permille (default), 1 - time in usec" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_tim_pwm_idling_level       , 3, "Output level whuile idling, default - 0 (set to 1 not implemented currently)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_tim_pwm_ctrl               , 4, "0 - OFF, 1 - ON" );
//UMBA_DRIVER_DECLARE_VALUE_ID_CODE( , , "" )
