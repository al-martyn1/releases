UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_gpio_value                  , 0, "bits" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_gpio_bits                   , 1, "Number of bits in port" );
//UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_adc_max_value              , 2, "Max ADC value" );
//UMBA_DRIVER_DECLARE_VALUE_ID_CODE( , , "" )
