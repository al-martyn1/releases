UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_dac_value                  , 0, "DAC value" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_dac_value_percent          , 1, "DAC value in percents of max" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_dac_value_permille         , 2, "DAC value in permilless of max" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_dac_bits                   , 3, "Number of bits in sample" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_dac_max_value              , 4, "Max DAC value" );
