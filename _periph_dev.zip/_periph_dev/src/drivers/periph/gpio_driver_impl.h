#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "scalcus/pwm.h"
#include "scalcus/percent.h"

#include "periph/periph.h"
#include "periph/gpio.h"

//#include "scalcus/averager.h"

#include "umba/variadic_helpers.h"


#include <utility>


namespace umba
{
namespace drivers
{
namespace periph
{


#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_gpio_device_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

// GpioPinAddr
// uint32_t packGpioPinAddr( GpioPinAddr pa )
// GpioPinAddr unpackGpioPinAddr( uint32_t pa )

// class GpioDriver : public DriverImplBase< class_id_gpio, subclass_id_hardware, PowerConsumptionClass::medium >

template< ClassId ClassIdValue, SubclassId SubclassIdValue
        , PowerConsumptionClass hwPowerConsumption = PowerConsumptionClass::medium
        , PowerConsumptionClass swPowerConsumption = PowerConsumptionClass::medium
        >
class GpioDriverImplBase : public DriverImplBase< ClassIdValue, SubclassIdValue, hwPowerConsumption, swPowerConsumption >
{

    typedef DriverImplBase< ClassIdValue, SubclassIdValue, hwPowerConsumption, swPowerConsumption > BaseImpl;
    
public:

    UMBA_DRIVER_DESCRIPTION( "GPIO" )

    // Первыми идут старшие пины
    template< typename... PinAddr >
    GpioDriverImplBase( umba::periph::PinMode pinsMode, umba::periph::PinSpeed pinsSpeed, PinAddr... pinAddrs )
    : BaseImpl()
    , m_pinsSpeed(pinsSpeed)
    , m_pinsMode(pinsMode)
    {
        umba::getVariadicArgsType< 0, PinAddr... > buf[sizeof...(pinAddrs)];
        //umba::
        size_t sz = umba::buildSomeTypeArray< sizeof...(pinAddrs) > (buf, pinAddrs...);

        m_totalPinsTaken = sz;
        m_numberOfPins   = std::min( (size_t)32, sz );

        for( size_t i = 0; i!=m_numberOfPins; ++i)
        {
            m_packedPins[i] = umba::periph::superpackGpioPinAddr( buf[i] );
        }
    }

    GpioDriverImplBase( GpioDriverImplBase && ) = default;

    bool install( DriverId driverId = driver_id_auto )
    {
        #ifdef RTKOS_RTKOS_H
        return umba::rtkos::driverInstall( DriverAddress(BaseImpl::class_id_value, driverId), BaseImpl::subclass_id_value, this );
        #endif
    }


    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( BaseImpl::class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( BaseImpl::class_id_value, BaseImpl::subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_gpio_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_gpio_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);

        oss<<"GPIO/";

        if (m_pinsMode==umba::periph::PinMode::gpio_out_od || m_pinsMode==umba::periph::PinMode::gpio_out_pp )
            oss<<"OUT";
        else
            oss<<"IN";

        oss<<"; Speed: ";

        switch(m_pinsSpeed)
        {
            case umba::periph::PinSpeed::low:    oss<<"Low"; break;
            case umba::periph::PinSpeed::medium: oss<<"Medium"; break;
            case umba::periph::PinSpeed::fast:   oss<<"Fast"; break;
            case umba::periph::PinSpeed::high:   oss<<"High"; break;
            default: return false; // cause kernel panic
        }

        oss<<"; Pins: ";

        if (m_totalPinsTaken>m_numberOfPins)
        {
            oss<<" Too many pins taken";
        }
        else
        {
            for( size_t i = 0; i!=m_numberOfPins; ++i)
            {
                oss<<" "<<umba::periph::superunpackGpioPinAddr( m_packedPins[i] );
            }
        }

        return true; //isValidPinAddr(m_pinAdc);
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        using namespace umba::periph::traits;   
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        using namespace umba::omanip;

        if (!isMessageDriverMine( msg, BaseImpl::m_driverSelfAddress ))
            return dumpMsg(msg);

        bool isSetCmd   = isMessageDriverMessageId( msg, MessageId::device_param_set );
        bool isQueryCmd = isMessageDriverMessageId( msg, MessageId::device_param_request );

        if (!isQueryCmd && !isSetCmd)
            return dumpMsg(msg, "Unsupported cmd for parameter");

        switch( msg.value.id )
        {
            case value_id_gpio_value:
                 {
                     uint32_t value = 0;

                     if (isSetCmd)
                     {
                         if (!umba::drivers::extractFromMessageValue( msg.value, value /* ValueInfoFlags *pInfoFlags */ ))
                            return dumpMsg(msg, "Error in format");
                     }

                     uint32_t mask = 1<<(m_numberOfPins-1);
                     for( size_t i = 0; i!=m_numberOfPins; ++i, mask >>= 1)
                     {
                         auto addr = umba::periph::superunpackGpioPinAddr( m_packedPins[i] );
                         umba::periph::GpioPin pin = umba::periph::GpioPin( addr, m_pinsMode, m_pinsSpeed );

                         if (isQueryCmd)
                         {
                             bool pinVal = pin;

                             //if (pinVal)
                             //   UMBA_RTKOS_LOG<<"Knob detected !!!\n";
                             if (true==pinVal)
                                 value |= mask;
                         }
                         else
                         {
                             if (value&mask)
                                 pin = true;
                             else
                                 pin = false;
                         }
                     }

                     if (isQueryCmd)
                         postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_gpio_value, value, static_cast<IDriver*>(this) );
                 }
                 break;

            case value_id_gpio_bits:
                 {
                     uint32_t bits = m_numberOfPins;
                     postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_gpio_bits, bits, static_cast<IDriver*>(this) );
                 }
                 break;

            default: return dumpMsg(msg);
        };

        return true;
    }

protected:

    using BaseImpl::dumpMsg;
    using BaseImpl::m_driverSelfAddress;

    uint16_t      m_packedPins[32];
    size_t        m_totalPinsTaken = 0;
    size_t        m_numberOfPins   = 0;

    umba::periph::PinSpeed  m_pinsSpeed;
    umba::periph::PinMode   m_pinsMode;

};


typedef GpioDriverImplBase< class_id_gpio, subclass_id_hardware, PowerConsumptionClass::medium, PowerConsumptionClass::medium >    GpioDriver;


} // namespace periph
} // namespace drivers
} // namespace umba

