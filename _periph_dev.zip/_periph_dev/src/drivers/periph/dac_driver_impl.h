#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "scalcus/pwm.h"
#include "scalcus/percent.h"

#include "periph/periph.h"

#include "scalcus/averager.h"


namespace umba {
namespace drivers {
namespace periph {


#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_dac_device_params.h"
#include "x_dac_driver_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE


template <typename DacObject>
class DacDriver : public DriverImplBase< class_id_dac, subclass_id_hardware, PowerConsumptionClass::low, PowerConsumptionClass::low >
{

    typedef DriverImplBase< class_id_dac, subclass_id_hardware, PowerConsumptionClass::low, PowerConsumptionClass::low > BaseImpl;
    
public:

    UMBA_DRIVER_DESCRIPTION( "DAC" )

    DacDriver( DacObject &dacObject )
    : BaseImpl()
    , m_dac(dacObject)
    {
        m_maxVal = (1 << (unsigned)m_dac.getNumberOfBits()) - 1;
    }

    DacDriver( DacDriver && ) = default;

    bool install( DriverId driverId = driver_id_auto )
    {
        #ifdef RTKOS_RTKOS_H
        return umba::rtkos::driverInstall( DriverAddress(class_id_value, driverId), subclass_id_value, this );
        #endif
    }


    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    //UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_dac_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_dac_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NAMES_BEGIN()
    #include "x_dac_driver_params.h"
    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DRIVER_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_dac_driver_params.h"
    UMBA_DRIVER_DECLARE_DRIVER_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE


    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);
        //umba::ihc::IhcOctetStreamCharWriter writter(pStreamTo);
        //umba::SimpleFormatter oss( &writter );

        oss<<"DAC "<<m_dac.getPinAddr();
        return umba::periph::isValidPinAddr(m_dac.getPinAddr());
    }

    // DacBits getNumberOfBits() const
    // GpioPinAddr getPinAddr()

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        using namespace umba::periph::traits;
        if (!m_dac.isConnected())
            m_dac.connect();
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    uint32_t scaleValue( uint32_t val )
    {
        if (m_useFloatScale)
        {
            val = (uint32_t)(m_scale * (float)val);
        }
        else
        {
            val = val * m_mul / m_div;
        }

        if (val >= m_maxVal)
            val = m_maxVal;

        return val;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        using namespace umba::omanip;

        if (!isMessageDriverMine( msg, m_driverSelfAddress ))
            return dumpMsg(msg);

        uint32_t val = 0;

        if (isMessageDriverMessageId( msg, MessageId::device_param_set ))
        {
            switch( msg.value.id )
            {
                case value_id_dac_value:
                     {
                         umba::drivers::extractFromMessageValue( msg.value, val );
                         m_dac = scaleValue( val );
                         return true;
                     }

                case value_id_dac_value_percent:
                     {
                         umba::drivers::extractFromMessageValue( msg.value, val );
                         val = val * m_maxVal / 100;
                         m_dac = scaleValue( val );
                         return true;
                     }

                case value_id_dac_value_permille:
                     {
                         umba::drivers::extractFromMessageValue( msg.value, val );
                         val = val * m_maxVal / 1000;
                         m_dac = scaleValue( val );
                         return true;
                     }
            }
        }
        else if (isMessageDriverMessageId( msg, MessageId::device_param_request ))
        {
            switch( msg.value.id )
            {
                case value_id_dac_bits:
                     {
                         postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_dac_bits, (uint32_t)m_dac.getNumberOfBits(), static_cast<IDriver*>(this) );
                         return true;
                     }

                case value_id_dac_max_value:
                     {
                         postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_dac_max_value, m_maxVal, static_cast<IDriver*>(this) );
                         return true;
                     }
            }
        }
        else if (isMessageDriverMessageId( msg, MessageId::driver_param_set ))
        {
            switch( msg.value.id )
            {
                case value_id_dac_mul:
                     {
                         umba::drivers::extractFromMessageValue( msg.value, m_mul );
                         m_useFloatScale = false;
                         return true;
                     }

                case value_id_dac_div:
                     {
                         umba::drivers::extractFromMessageValue( msg.value, m_div );
                         m_useFloatScale = false;
                         return true;
                     }

                case value_id_dac_scale:
                     {
                         umba::drivers::extractFromMessageValue( msg.value, m_scale );
                         m_useFloatScale = true;
                         return true;
                     }
            }
        }

        return dumpMsg(msg);
    }


protected:

    DacObject                                      &m_dac;
    uint32_t                                       m_mul = 1;
    uint32_t                                       m_div = 1;
    float                                          m_scale = 1.0;
    bool                                           m_useFloatScale = false;
    uint32_t                                       m_maxVal;

};


template<typename DacObject>
inline
DacDriver<DacObject> makeDacDriver( DacObject &&obj )
{
    return DacDriver<DacObject>( obj );
    //return std::move( AdcDriver<AdcObject>( obj, pinAdc, pinAdcCtrlOnOff) );
}



} // namespace periph
} // namespace drivers
} // namespace umba

