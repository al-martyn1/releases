#pragma once

#include "rtkos/rtkos.h"



namespace umba
{
namespace drivers
{

// msgId - MessageId::device_param_response / MessageId::device_param_notify
template<typename ValueType>
inline
void postMessageDriverValue( ClassId classId, DriverId driverId, MessageId msgId, ValueId valueId, ValueType value, IDriver *pDriver = 0)
{
    MessageDriver msg;
    initMessageDriver( msg, classId, driverId, msgId, pDriver );
    msg.value = makeMessageValue( valueId, value );
    // .id        = valueId;
    //msg.value.valueInfo = 
    umba::rtkos::messagePost( msg );
}

// msgId - MessageId::device_param_response / MessageId::device_param_notify
template<typename ValueType>
inline
void postMessageDriverValue( DriverAddress peerAddr /* or self, if pDriver is non-zero */, MessageId msgId, ValueId valueId, ValueType value, IDriver *pDriver = 0 )
{
    postMessageDriverValue( peerAddr.classId, peerAddr.driverId, msgId, valueId, value, pDriver );
}

inline
void postMessageDriverValueRequest( ClassId classId, DriverId driverId, ValueId valueId, IDriver *pDriver = 0 )
{
    MessageDriver msg;
    initMessageDriver( msg, classId, driverId, MessageId::driver_param_request, pDriver );
    msg.value.id = valueId;
    umba::rtkos::messagePost( msg );
}

inline
void postMessageDriverValueRequest( DriverAddress addr, ValueId valueId, IDriver *pDriver = 0 )
{
    postMessageDriverValueRequest( addr.classId, addr.driverId, valueId, pDriver );
}

inline
void postMessageDeviceValueRequest( ClassId classId, DriverId driverId, ValueId valueId, IDriver *pDriver = 0 )
{
    MessageDriver msg;
    initMessageDriver( msg, classId, driverId, MessageId::device_param_request, pDriver );
    msg.value.id = valueId;
    umba::rtkos::messagePost( msg );
}

inline
void postMessageDeviceValueRequest( DriverAddress addr, ValueId valueId, IDriver *pDriver = 0 )
{
    postMessageDeviceValueRequest( addr.classId, addr.driverId, valueId, pDriver );
}



} // namespace drivers
} // namespace umba

