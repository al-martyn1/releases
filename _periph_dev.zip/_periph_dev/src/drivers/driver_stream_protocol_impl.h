#pragma once

#include "umba/interface.h"
#include "umba/basic_interfaces.h"
#include "ihc/i_octet_stream.h"

#include "basic_types.h"
#include "rtkos/messages.h"

#include "umba/time_service.h"

#include <utility>



namespace umba{

namespace drivers{


template<size_t ReadBufSize>
struct IOctetIOStreamImplDriver : implements umba::ihc::IOctetIOStream
{

    UMBA_BEGIN_INTERFACE_MAP_EX( umba::ihc::IOctetOStream )
         UMBA_IMPLEMENT_INTERFACE( umba::ihc::IOctetIOStream )
         UMBA_IMPLEMENT_INTERFACE( umba::ihc::IOctetIStream )
    UMBA_END_INTERFACE_MAP()


    IOctetIOStreamImplDriver( DriverAddress streamDriverAddr ) 
    : m_streamDriverAddr(streamDriverAddr)
    {
    }

    bool putDriverDataToReadBuffer( const umba::drivers::MessageDriver &msg )
    {
        if (!isMessageDriverMine( msg, m_streamDriverAddr )) // not from our device
           return false;

        if (msg.header.driverMessageId != MessageId::driver_raw_data)
           return false;

        StreamSize nPutOctets  = (StreamSize)msg.rawData.dataSize;
        if (!nPutOctets)
            return true;

        const StreamOctetType * pRawData = (const StreamOctetType*)getMessageDriverRawData( msg );
        if (!pRawData)
            return true;
        
        StreamSize nAvailSpace = ReadBufSize - m_nReadBufOctets;
        nPutOctets = std::min( nAvailSpace, nPutOctets ); // лишнее отбрасываем, увы
        if (!nPutOctets)
            return true;

        memcpy( &m_readBuf[m_nReadBufOctets], pRawData, nPutOctets );
        m_nReadBufOctets += nPutOctets;

        return true;
    }

    virtual
    bool canRead() override
    {
        return m_nReadBufOctets > 0;
    }

    virtual
    StreamSize read( StreamOctetType *pBuf, StreamSize bufSize ) override
    {
        if (!bufSize)
            return 0;

        UMBA_ASSERT(pBuf != 0);

        StreamSize nRead = std::min( bufSize, m_nReadBufOctets );
        if (!nRead)
            return nRead;

        memcpy( pBuf, &m_readBuf[0], nRead );
        StreamSize tailSize = m_nReadBufOctets - nRead;
        if (tailSize)
        {
            memmove( &m_readBuf[0], &m_readBuf[nRead], tailSize ); // Не слишком оптимально, ну да ладно
        }

        m_nReadBufOctets -= nRead;

        return nRead;
    }

    virtual
    void fetch( StreamSize bufSize ) override
    {
        MessageDriver msg;
        initMessageDriverDriverRawDataRequest( msg, m_streamDriverAddr, bufSize, invalid_device_bus_address );
        umba::rtkos::messagePost( msg );
    }


    virtual
    bool canWrite(StreamSize nOctets) override
    {
        //if (nOctets>max_packet_size) // максимально возможная порцайка
        //    return false;
        return true;
    }

    virtual
    void write( const StreamOctetType *pData, StreamSize nOctets) override
    {
        UMBA_ASSERT(pData != 0);

        MessageDriver  msg;
        StreamSize max_packet_size = sizeof(msg.rawData.data);

        initMessageDriver( msg, m_streamDriverAddr, MessageId::driver_raw_data,  /* IDriver */ 0 );

        while(nOctets>max_packet_size)
        {
            setMessageDriverRawData( msg, (uint8_t*)pData, max_packet_size, invalid_device_bus_address );
            umba::rtkos::messagePost( msg );
            nOctets -= max_packet_size;
            pData   += max_packet_size;
        }

        if (nOctets) 
        {
            setMessageDriverRawData( msg, (uint8_t*)pData, nOctets, invalid_device_bus_address );
            umba::rtkos::messagePost( msg );
        }
    }

    virtual
    void write( const char *pData, size_t dataSize ) override
    {
        write( (const StreamOctetType *)pData, (StreamSize)dataSize);
    }

    virtual
    void flush( ) override
    {
    }


protected:

    DriverAddress      m_streamDriverAddr;
    StreamOctetType    m_readBuf[ReadBufSize];
    StreamSize         m_nReadBufOctets = 0;




}; // struct IOctetIOStreamImplDriver

} // namespace drivers 

} // namespace umba

