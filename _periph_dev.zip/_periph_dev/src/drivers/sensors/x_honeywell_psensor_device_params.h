UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_sensor_value               , 0, "Pressure delta under atmo, in mBars. Readonly" );
