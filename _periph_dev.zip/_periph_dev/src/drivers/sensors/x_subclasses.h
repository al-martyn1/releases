UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_sensor_limit_switch_id   ,  0xF6289008, "Limit switch" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_sensor_current_id        ,  0x35D04CE5, "Current sensor" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_sensor_temperature_id    ,  0x2D0873E2, "Temperature sensor" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_sensor_pressure_id       ,  0x507C866C, "Pressure sensor" );

