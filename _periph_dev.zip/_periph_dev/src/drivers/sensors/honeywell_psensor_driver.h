#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#ifdef RTKOS_RTKOS_H
    #include "rtkos/vk_codes.h"
    #include "../messages_rtkos.h"
#endif

#include "umba/bits.h"

#include "scalcus/averager.h"


namespace umba
{
namespace drivers
{
namespace sensors
{

/*
ValueId esc_pwm_freq                 = 100; // uint32 Hz
ValueId esc_pwm_duration_off         = 800;
ValueId esc_pwm_duration_duty        = 1100; // 
ValueId esc_pwm_duration_max         = 1700;
ValueId esc_pwm_command              = 0;
*/

/*
ValueId value_id_esc_pwm_freq                 = 0;
ValueId value_id_esc_pwm_duration_off         = 1;
ValueId value_id_esc_pwm_duration_duty        = 2;
ValueId value_id_esc_pwm_duration_max         = 3;
ValueId value_id_esc_pwm_command              = 4; // off, on/hh, on
ValueId value_id_esc_pwm_duration_target      = 5; // целевая скорость
*/

#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_honeywell_psensor_device_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE



#ifdef RTKOS_RTKOS_H
constexpr umba::rtkos::TimerEventId  KeyboardTerminalDriver_checkForSingleEscapeTimerEvent = 0;
constexpr umba::rtkos::TimerEventId  KeyboardTerminalDriver_checkForKeyRelease             = 1;
#endif


const float HSCSSNN001PD2A3_psi2BarScale    = 0.0689476;

class HSCSSNN001PD2A3_PSensorDriver : public DriverImplBase< class_id_sensor, subclass_sensor_pressure_id, PowerConsumptionClass::low >
{

    
    
public:

    UMBA_DRIVER_DESCRIPTION( "Pressure sensor HSCSSNN001PD2A3" )

    HSCSSNN001PD2A3_PSensorDriver( DriverAddress drvAddrDataSource, DeviceBusAddress i2cSensorAddr, size_t avgSize = scalcus::average_times_4 )
    : m_drvAddrDataSource(drvAddrDataSource)
    , m_i2cSensorAddr( i2cSensorAddr )
    {
        averager.setMaxCount(avgSize);
    }

    HSCSSNN001PD2A3_PSensorDriver( HSCSSNN001PD2A3_PSensorDriver && ) = default;

    bool install()
    {
        using namespace umba::omanip;

        #ifdef RTKOS_RTKOS_H
        //DriverId 
        if (!umba::rtkos::driverInstall( DriverAddress(class_id_value), subclass_id_value, this ))
            return false;
        //UMBA_RTKOS_LOG<<"Installing driver handler: "<<groupsize(8)<<hex<<(uintptr_t)this<<endl;
        return umba::rtkos::driverHandlerAdd( m_drvAddrDataSource, this );
        #endif
    }



    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()
    //UMBA_DRIVER_DECLARE_DEVICE_PARAM_NO_PARAMS()

    
    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_honeywell_psensor_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_honeywell_psensor_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE
    

    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    //UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    
    virtual
    bool onMessageDriverClient( const umba::drivers::MessageDriver &msg ) override
    {
        using namespace umba::omanip;

        //UMBA_RTKOS_LOG<<"onMessageDriverClient called\n";
        if (!isMessageDriverMine( msg, m_drvAddrDataSource )) // not from I2C device
           return dumpMsg(msg);

        if (msg.header.driverMessageId == MessageId::driver_notify_carrier)
        {
            return true; // simply skip it
        }

        if (msg.header.driverMessageId == MessageId::driver_notify_datalink)
        {
            MessageDriver msgRes;
            initMessageDriver( msgRes, m_driverSelfAddress, MessageId::driver_notify_datalink, static_cast<IDriver*>( this ) );
            msgRes.linkStatus = msg.linkStatus;
            umba::rtkos::messagePost( msgRes );
            if (!msgRes.linkStatus)
                averager.reset(); // Перезапуск усреднителя при потере связи
            return true;
        }

        if (msg.header.driverMessageId == MessageId::driver_raw_data)
        {
            if (msg.rawData.dataSize!=2) // some error occurs, wrong data size
            {
                MessageDriver msgRes;
                initMessageDriver( msgRes, m_driverSelfAddress, MessageId::driver_notify_datalink, static_cast<IDriver*>( this ) );
                msgRes.linkStatus = 0; // set broken link
                umba::rtkos::messagePost( msgRes );
                return true;
            }

            const uint8_t * pRawData = getMessageDriverRawData( msg );
            uint16_t rawSensorData = umba::bits::makeIntFromBytesLE<uint16_t>(pRawData);

            uint16_t statusBits = rawSensorData & (0x8000 | 0x4000); // i2cBuf[0] & (0x80 | 0x40);
            statusBits >>= 14;

            /*
            switch(statusBits)
            {
                case 0: //m_sensorState = HoneywellPressureSensorState::normal ;
                        //UMBA_RTKOS_LOG<<"Sensor: normal\n";
                        break;           
                case 1: //m_sensorState = HoneywellPressureSensorState::commandMode ;
                        //UMBA_RTKOS_LOG<<"Sensor: command mode\n";
                        break;
                case 2: //m_sensorState = HoneywellPressureSensorState::staleData ;
                        //UMBA_RTKOS_LOG<<"Sensor: stale data\n";
                        break;
                case 3: //m_sensorState = HoneywellPressureSensorState::diagnosticCondition ;
                        //UMBA_RTKOS_LOG<<"Sensor: diagnostic condition\n";
                        break;
            }
            */

            uint16_t rawPressure    = rawSensorData & 0x3FFF;
            float sensorValue = honeywellPressureSensor_HSCSSNN001PD2a3_valueConversion(rawPressure);
            sensorValue *= 1000.0f;
            sensorValue *= HSCSSNN001PD2A3_psi2BarScale;

            if (sensorValue<0)
                sensorValue = -sensorValue;

            //sensorValue = averager.makeAverageValue(sensorValue);
            //sensorValue = averager.makeMedianValue(sensorValue);
            //sensorValue = averager.makeAverageMedianValue(sensorValue);

            //MessageDriver msgRes;
            //initMessageDriverValue( msgRes, class_id_value, m_driverSelfId, MessageId::device_param_response, value_id_sensor_value, sensorValue, static_cast<IDriver*>(this) );
            //umba::rtkos::messagePost( msgRes );

            postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_sensor_value, sensorValue, static_cast<IDriver*>(this) );

            /*
            MessageDriver msg; // peerAddr.classId, peerAddr.driverId
            initMessageDriver( msg, m_driverSelfAddress.classId, m_driverSelfAddress.driverId, MessageId::device_param_response, static_cast<IDriver*>(this) );
            msg.value = makeMessageValue( value_id_sensor_value, sensorValue );

            UMBA_RTKOS_LOG<<"DRV Pressure: "<<sensorValue<<", raw: "<<rawPressure<<" ";
            UMBA_RTKOS_LOG<<", flags: "<<hex<<(uint32_t)msg.value.valueInfo<<endl;

            umba::rtkos::messagePost( msg );
            */

            return true;

            //msg.rawData.dataSize
        }

        return dumpMsg(msg);
        //msgRes.header.driverMessageId = MessageId::driver_notify_datalink;
        //return false;
    }
    

    float honeywellPressureSensor_HSCSSNN001PD2a3_valueConversion( uint16_t sensorOutputVal )
    {
        uint16_t outputMin = 1638;  // 10%
        uint16_t outputMax = 14745; // 90%
        uint16_t outputDelta = outputMax - outputMin;
    
        float Pmin = -1.0;  // 10%
        float Pmax =  1.0; // 90%
        float deltaP = Pmax - Pmin;
    
        uint16_t outputValDeltaMin = sensorOutputVal - outputMin;
    
        float deltasProduction = deltaP * outputValDeltaMin;
        float deltasProductionNormed = deltasProduction / outputDelta;
        float P = deltasProductionNormed + Pmin;
        return P;
    }



    #ifdef RTKOS_RTKOS_H

    #endif

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        #ifdef RTKOS_RTKOS_H

        //UMBA_RTKOS_LOG<<"Honey, class: "<<hex<<class_id_value<<", no: "<<m_driverSelfId<<"\n";
        //UMBA_RTKOS_LOG<<"I2C, class: "<<hex<<m_drvAddrDataSource.classId<<", no: "<<m_drvAddrDataSource.driverId<<"\n";

        UMBA_ASSERT(m_drvAddrDataSource.classId!=class_id_value);

        umba::drivers::IDriver* pDriver = UMBA_RTKOS_OS->driverGet( m_drvAddrDataSource );
        if (pDriver)
        {
            pDriver->getDriverDescription( m_drvAddrDataSource, pStreamTo );
            pStreamTo->write( ": ", 2 );
            return pDriver->getDriverConfigInfo( m_drvAddrDataSource, pStreamTo );
        }
        else
        {
            writeInvalidConfigString( pStreamTo );
            return false;
        }
        #endif
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        if (!isMessageDriverMine( msg, class_id_value, m_driverSelfId ))
            return dumpMsg(msg);

        if (!isMessageDriverMessageId( msg, MessageId::device_param_request ))
            return dumpMsg(msg);

        if (msg.value.id!=value_id_sensor_value)
            return dumpMsg(msg);

        MessageDriver msgReq;
        initMessageDriverDriverRawDataRequest( msgReq, m_drvAddrDataSource, 2, m_i2cSensorAddr );
        umba::rtkos::messagePost( msgReq );
        return true;
    }


protected:

    DriverAddress          m_drvAddrDataSource;
    DeviceBusAddress       m_i2cSensorAddr;

    scalcus::Averager<float,float,16>        averager;

};


} // namespace sensors
} // namespace drivers
} // namespace umba

