#pragma once

// umba::drivers

// NOTE: rtkos.h must be included before this file for special option using

#include "i_driver.h"
#include <string.h>

#include "messages_dump.h"


namespace umba
{
namespace drivers
{

template< ClassId ClassIdValue, SubclassId SubclassIdValue
        , PowerConsumptionClass hwPowerConsumption = PowerConsumptionClass::medium
        , PowerConsumptionClass swPowerConsumption = PowerConsumptionClass::medium
        >
class DriverImplBase : public  IDriver
                     , UMBA_DRIVERS_INHERITANS IDriverPrivate
                     , public umba::IPollCapable          // для полировки
                     , public umba::ITimerHandler         // для периодической работы
                     #ifdef RTKOS_RTKOS_H
                     , public umba::rtkos::IDriverClientHandler // для подписки на сообщения от других драйверов (нижлежащего уровня)
                     , public umba::rtkos::IMessageFilter // для фильтрации сообщений
                     #endif
{

public:

    static const ClassId   class_id_value      = ClassIdValue;
    static const SubclassId subclass_id_value  = SubclassIdValue;

public:

    DriverImplBase()
    {
    }

    UMBA_BEGIN_INTERFACE_MAP_EX( IDriver )
         UMBA_IMPLEMENT_INTERFACE( IDriverPrivate )
         UMBA_IMPLEMENT_INTERFACE( IPollCapable )
         UMBA_IMPLEMENT_INTERFACE( ITimerHandler )
         #ifdef RTKOS_RTKOS_H
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IDriverClientHandler )
         UMBA_IMPLEMENT_INTERFACE( umba::rtkos::IMessageFilter )
         #endif
    UMBA_END_INTERFACE_MAP()

    UMBA_DELEGATE_QUERY_INTERFACE(IDriver)

    #ifdef RTKOS_RTKOS_H
    umba::rtkos::TimerId timerSet( umba::rtkos::TimerEventId eventId, umba::rtkos::TimeTick period )
    {
        return umba::rtkos::timerSet( this, eventId, period );
    }
    #endif

    virtual
    void setDriverId( ClassId classId, SubclassId subclassId, DriverId driverId ) override
    {
        // classId, subclassId not used in single device driver
        m_driverSelfId      = driverId;
        m_driverSelfAddress = DriverAddress(class_id_value, driverId);
    }

    virtual
    DriverId getDriverId( const DriverAddress &driverAddress ) override
    {
        return m_driverSelfId;
    }

    virtual
    void getDriverClassName( ClassId classId, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        const char* clsName = getClassName( classId );
        pStreamTo->write( clsName, strlen(clsName) );
    }

    virtual
    void getDriverDescription( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
    }

    virtual
    PowerConsumptionClass getPowerClass(const DriverAddress &driverAddress) override
    {
        if (!m_driverHardwareStarted)
            return hwPowerConsumption;
        return swPowerConsumption;
    }

    void writeInvalidConfigString( umba::ihc::IOctetOStream *pStreamTo )
    {
        static const char *invalidHwConfig = "<INVALID HW CONFIG>";
        pStreamTo->write(invalidHwConfig, strlen(invalidHwConfig));
    }

    virtual
    void driverSoftwareSetStarted(const DriverAddress &driverAddress) override
    {
        m_driverSoftwareStarted = true;
    }

    virtual
    void driverHardwareSetStarted(const DriverAddress &driverAddress) override
    {
        m_driverHardwareStarted = true;
    }

    virtual
    DriverAddress getAssignedAddress() override
    {
        return m_driverSelfAddress;
    }

    virtual
    bool isDriverHardwareInitialized() override
    {
        return m_driverHardwareStarted;
    }

    virtual
    bool isDriverSoftwareInitialized() override
    {
        return m_driverSoftwareStarted;
    }

    virtual
    bool isDriverInitialized() override
    {
        return m_driverHardwareStarted && m_driverSoftwareStarted;
    }

    bool isOsStarted()
    {
        return UMBA_RTKOS_OS->isOsStarted();
    }


protected:

    DriverId       m_driverSelfId      = invalid_driver_id;
    DriverAddress  m_driverSelfAddress = DriverAddress(0, invalid_driver_id);
    volatile bool  m_driverHardwareStarted = false;
    volatile bool  m_driverSoftwareStarted = false;

    
    bool dumpMsg( const MessageDriver &msg, const char *title = 0 )
    {
        #ifdef RTKOS_RTKOS_H
        using namespace umba::omanip;

        umba::ihc::IOctetOStreamImplBuf<48> strTo;
        if (title)
           UMBA_RTKOS_LOG<<notice<<title<<normal<<"\n";

        getDriverClassName( class_id_value, strTo.clearEx());
        UMBA_RTKOS_LOG<<"This driver is: "<<groupsize(8)<<hex<<class_id_value<<", #"<<m_driverSelfId<<" - "<<strTo.c_str()<<"\n";
        UMBA_RTKOS_LOG<<"Message:\n";
        dumpMessageDriver( msg, this );
        UMBA_RTKOS_LOG<<endl;
        #endif
        return false;
    }
    


}; // class DriverImplBase




#define UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE(             id, value, descr )    constexpr umba::drivers::ValueId id = value
#define UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(        id, value, descr )    case value: { const char *str = #id ; pStreamTo->write(str, strlen(str)); } return true
#define UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION( id, value, descr )    case value: { const char *str = descr; pStreamTo->write(str, strlen(str)); } return true

//#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_PARAM_CONST_VALUE(id, value, descr)
//#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
//#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)

#define UMBA_DRIVER_DECLARE_DRIVER_PARAM_NAMES_BEGIN() \
    virtual                                             \
    bool getDriverParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                   \
        UMBA_ASSERT(pStreamTo!=0);                      \
        switch(paramId)                                 \
        {

#define UMBA_DRIVER_DECLARE_DRIVER_PARAM_NAMES_END() \
             /* default: return "<UNKNOWN>"; */      \
        }                                            \
        return false;                                   \
    }


#define UMBA_DRIVER_DECLARE_DRIVER_PARAM_DESCRIPTIONS_BEGIN() \
    virtual                                             \
    bool getDriverParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                   \
        UMBA_ASSERT(pStreamTo!=0);                      \
        switch(paramId)                                 \
        {

#define UMBA_DRIVER_DECLARE_DRIVER_PARAM_DESCRIPTIONS_END() \
        }                                               \
        return false;                                   \
    }


#define UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()\
    virtual                                             \
    bool getDriverParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                   \
        UMBA_ASSERT(pStreamTo!=0);                      \
        return false;                                   \
    }                                                   \
    virtual                                             \
    bool getDriverParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                   \
        UMBA_ASSERT(pStreamTo!=0);                      \
        return false;                                   \
    }



#define UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN() \
    virtual                                             \
    bool getDeviceParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                   \
        UMBA_ASSERT(pStreamTo!=0);                      \
        switch(paramId)                                 \
        {

#define UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END() \
             /* default: return "<UNKNOWN>"; */      \
        }                                            \
        return false;                                   \
    }


#define UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN() \
    virtual                                             \
    bool getDeviceParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                   \
        UMBA_ASSERT(pStreamTo!=0);                      \
        switch(paramId)                                 \
        {

#define UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END() \
        }                                             \
        return false;                                   \
    }


#define UMBA_DRIVER_DECLARE_DEVICE_PARAM_NO_PARAMS()\
    virtual                                             \
    bool getDeviceParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                   \
        UMBA_ASSERT(pStreamTo!=0);                      \
        return false;                                   \
    }                                                   \
    virtual                                             \
    bool getDeviceParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                   \
        UMBA_ASSERT(pStreamTo!=0);                      \
        return false;                                   \
    }




#define UMBA_DRIVER_DESCRIPTION( dsc ) \
    virtual                            \
    void getDriverDescription( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                                     \
        UMBA_ASSERT(pStreamTo!=0);                      \
        static const char* driverDescription = dsc;                       \
        pStreamTo->write( driverDescription, strlen(driverDescription) ); \
    }

#define UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( curClass ) \
    virtual                                                 \
    void getDriverSubclassName( ClassId classId, SubclassId subclassId, umba::ihc::IOctetOStream *pStreamTo ) override \
    {                                                       \
        const char* subclsName = getSublassName( subclassId ); \
        if (classId == curClass)                            \
            pStreamTo->write( subclsName, strlen(subclsName) );   \
    }

#define UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( cls, sub ) \
    virtual                                                  \
    ClassId getDriverClass() override                        \
    {                                                        \
        return cls;                                          \
    }                                                        \
                                                             \
    virtual                                                  \
    SubclassId getDriverSubclass() override                  \
    {                                                        \
        return sub;                                          \
    }




#ifdef RTKOS_RTKOS_H

    #define UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT() \
    virtual                                                \
    bool onFilterMessage( umba::rtkos::Message &msg ) override \
    {                                                      \
        return false;                                      \
    }

#else

    #define UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()

#endif



#define UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT() \
                                                     \
    virtual                                          \
    void poll() override {}                          \
                                                     \
    virtual                                          \
    bool isReadyForPoll() override { return false; }




#ifdef RTKOS_RTKOS_H

    #define UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()  \
        virtual                                                    \
        bool onMessageDriverClient( const umba::drivers::MessageDriver &msg ) override \
        {                                                                              \
            return false;                                                              \
        }

    #define UMBA_DRIVER_CHECKED_INSTALL( drv, ... )                             \
        do                                                                      \
        {                                                                       \
            if ( ! drv.install(__VA_ARGS__) )                                   \
            {                                                                   \
                UMBA_RTKOS_PANIC_MSG( "Failed to install driver '" #drv "'" );  \
            }                                                                   \
                                                                                \
        } while(0)

#else

    #define UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    #define UMBA_DRIVER_CHECKED_INSTALL( drv, ... ) UMBA_ASSERT_FAIL()

#endif






/*
interface IMessageFilter : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xCE509227);

    virtual
    bool onFilterMessage( Message &msg ) = 0;

}; // interface IPollCapable
*/



} // namespace drivers
} // namespace umba


