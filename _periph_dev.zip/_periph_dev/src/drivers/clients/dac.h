#pragma once

#include "drivers/periph/dac_driver_impl.h"
#include "drivers/client_impl_base.h"


namespace umba {
namespace drivers {

IMBA_DRIVERS_CLIENT_IMPL_BEGIN( DacClient )

    void setValue( uint32_t val )
    {
        postMessageDriverValue( m_driverAddr, umba::drivers::MessageId::device_param_set
                              , umba::drivers::periph::value_id_dac_value
                              , val
                              );
    }

    void setValuePercent( uint32_t val )
    {
        postMessageDriverValue( m_driverAddr, umba::drivers::MessageId::device_param_set
                              , umba::drivers::periph::value_id_dac_value_percent
                              , val
                              );
    }

    void setValuePermille( uint32_t val )
    {
        postMessageDriverValue( m_driverAddr, umba::drivers::MessageId::device_param_set
                              , umba::drivers::periph::value_id_dac_value_permille
                              , val
                              );
    }

    void queryBits( )
    {
        postMessageDriverValue( m_driverAddr, umba::drivers::MessageId::device_param_request
                              , umba::drivers::periph::value_id_dac_bits
                              , (uint32_t)0
                              );
    }

    void queryMaxValue( )
    {
        postMessageDriverValue( m_driverAddr, umba::drivers::MessageId::device_param_request
                              , umba::drivers::periph::value_id_dac_max_value
                              , (uint32_t)0
                              );
    }

    void setValueMul( uint32_t val )
    {
        postMessageDriverValue( m_driverAddr, umba::drivers::MessageId::driver_param_set
                              , umba::drivers::periph::value_id_dac_mul
                              , val
                              );
    }

    void setValueDiv( uint32_t val )
    {
        postMessageDriverValue( m_driverAddr, umba::drivers::MessageId::driver_param_set
                              , umba::drivers::periph::value_id_dac_div
                              , val
                              );
    }

    void setValueScale( float val )
    {
        postMessageDriverValue( m_driverAddr, umba::drivers::MessageId::driver_param_set
                              , umba::drivers::periph::value_id_dac_scale
                              , val
                              );
    }


IMBA_DRIVERS_CLIENT_IMPL_END( DacClient )


} // namespace drivers
} // namespace umba


