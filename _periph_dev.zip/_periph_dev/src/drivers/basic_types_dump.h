#pragma once

#include "basic_types.h"



namespace umba
{
namespace drivers
{

inline
void dumpDriverAddress( const DriverAddress &addr )
{
    using namespace umba::omanip;

    UMBA_RTKOS_LOG<<"Address: "<<groupsize(8)<<hex<<addr.classId<<", #"<<addr.driverId;
}



} // namespace drivers
} // namespace umba

