UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_freq               , 0, "PWM Freq, Hz" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duration_off       , 1, "Duty pulse when OFF, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duration_idliing   , 2, "Duty pulse when IDLING, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duration_max       , 3, "Duty pulse MAX, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_command            , 4, "0 - OFF, 1 - ON/IDLING, 2 - ON" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duration_target    , 5, "Target duty pulse value for 'ON' mode" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duration_current   , 6, "Current pulse value" );
//UMBA_DRIVER_DECLARE_VALUE_ID_CODE( , , "" )
