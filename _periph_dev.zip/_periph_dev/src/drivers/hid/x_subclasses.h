UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_hid_terminal_keyboard    ,  0x2319A0F9, "Keyboard (Terminal)" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_hid_device_keyboard      ,  0xCBF4F0D9, "Keyboard" );

