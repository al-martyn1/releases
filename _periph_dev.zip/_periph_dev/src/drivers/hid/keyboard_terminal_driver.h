#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#ifdef RTKOS_RTKOS_H
    #include "rtkos/vk_codes.h"
#endif


// #define DEBUG_KEYBOARD_TERMINAL_DRIVER



namespace umba
{
namespace drivers
{
namespace hid
{

/*
#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_esc_device_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE
*/
    #ifdef RTKOS_RTKOS_H
    constexpr umba::rtkos::TimerEventId  KeyboardTerminalDriver_checkForSingleEscapeTimerEvent = 0;
    constexpr umba::rtkos::TimerEventId  KeyboardTerminalDriver_checkForKeyRelease             = 1;
    #endif


class KeyboardTerminalDriver : public DriverImplBase< class_id_hid, subclass_hid_terminal_keyboard, PowerConsumptionClass::low >
{
    
public:

    UMBA_DRIVER_DESCRIPTION( "Terminal keyboard" )

    KeyboardTerminalDriver( DriverAddress drvAddrDataSource )
    : m_drvAddrDataSource(drvAddrDataSource)
    {
    }

    KeyboardTerminalDriver( KeyboardTerminalDriver && ) = default;

    bool install(DriverId driverId = driver_id_auto)
    {
        #ifdef RTKOS_RTKOS_H
        //DriverId 
        if (!umba::rtkos::messageFilterAdd( this ))
            return false;
        //umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::normal );
        return umba::rtkos::driverInstall( DriverAddress(class_id_value, driverId), subclass_id_value, this );
        #endif
        // TimerId timerSet ( Object *pObj, TimerEventId eventId, TimeTick period )
    }



    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NO_PARAMS()

    /*
    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_esc_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_esc_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE
    */

    //UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    #ifdef RTKOS_RTKOS_H
    virtual
    bool onFilterMessage( umba::rtkos::Message &msg ) override
    {
        if (msg.id!=umba::rtkos::message_driver_id)
            return false;

        if (!isMessageFromDriver( msg.messageDriver ))
            return false;

        if (msg.messageDriver.header.driverMessageId!=MessageId::driver_raw_data)
            return false; // not data

        if (msg.messageDriver.rawData.dataSize==0)
            return false; // no data

        if (  msg.messageDriver.header.classId  != m_drvAddrDataSource.classId
           || msg.messageDriver.header.driverId != m_drvAddrDataSource.driverId
           )
            return false; // Not our message

        using namespace umba::omanip;

        const uint8_t *pMsgData = getMessageDriverRawData( msg.messageDriver );

        #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
            UMBA_RTKOS_LOG<<"KBD, data from UART: "<<msg.messageDriver.rawData.dataSize<<" - ";
            for( size_t i=0; i!=msg.messageDriver.rawData.dataSize; ++i)
                UMBA_RTKOS_LOG<<" "<<hex<<pMsgData[i];
            UMBA_RTKOS_LOG<<endl;
        #endif

        for( size_t i=0; i!=msg.messageDriver.rawData.dataSize; ++i)
        {
            processDataByte( msg.tick, pMsgData[i] );
        }

        if (m_escapeSequenceCounter && m_escapeSequence[m_escapeSequenceCounter-1]==0x1B)
        {
            timerSet( KeyboardTerminalDriver_checkForSingleEscapeTimerEvent, 10 ); // 10 ms for single escape check
        }
        else
        {
            timerSet( KeyboardTerminalDriver_checkForSingleEscapeTimerEvent, 0 );
        }

        return true; // false; Disable "Not handled" warnings
    }

    void processDataByte( umba::rtkos::TimeTick tick, uint8_t byte )
    {
        using namespace umba::omanip;

        /*

        0x5B - '['
        0x31 - '1'
        0x32 - '2'
        0x39 - '9'
        0x7E - '~'

        F1    - 0x1B 0x5B 0x31 0x31 0x7E
        F2    - 0x1B 0x5B 0x31 0x32 0x7E
        F3    - 0x1B 0x5B 0x31 0x33 0x7E
        F4    - 0x1B 0x5B 0x31 0x34 0x7E
        F5    - 0x1B 0x5B 0x31 0x35 0x7E
        F6    - 0x1B 0x5B 0x31 0x37 0x7E
        F7    - 0x1B 0x5B 0x31 0x38 0x7E
        F8    - 0x1B 0x5B 0x31 0x39 0x7E
        F9    - 0x1B 0x5B 0x32 0x30 0x7E
        F10   - 0x1B 0x5B 0x32 0x31 0x7E
        F11   - 0x1B 0x5B 0x32 0x33 0x7E
        F12   - 0x1B 0x5B 0x32 0x34 0x7E
             
        PUP   - 0x1B 0x5B 0x35 0x7E
        PDW   - 0x1B 0x5B 0x36 0x7E
        HOM   - 0x1B 0x5B 0x31 0x7E
        END   - 0x1B 0x5B 0x34 0x7E
        INS   - 0x1B 0x5B 0x32 0x7E
        DEL   - 0x1B 0x5B 0x33 0x7E

        UP    - 0x1B 0x5B 0x41
        DOWN  - 0x1B 0x5B 0x42
        LEFT  - 0x1B 0x5B 0x44
        RIGHT - 0x1B 0x5B 0x43
        */

        if (!m_escapeSequenceCounter)
        {
            #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP1\n";
            #endif

            if (byte!=0x1B)
            {
                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP2\n";
                #endif
                switch(byte)
                {
                    case 0x0D: generateKeyPress( umba::rtkos::VirtualKeyCode::enter     );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP2.1\n"; */  return;
                    case 0x09: generateKeyPress( umba::rtkos::VirtualKeyCode::tab       );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP2.2\n"; */  return;
                    case 0x1A: generateKeyPress( umba::rtkos::VirtualKeyCode::pause     );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP2.3\n"; */  return;
                    case 0x7F: generateKeyPress( umba::rtkos::VirtualKeyCode::backspace );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP2.4\n"; */  return;
                    default:   generateKeyPress( (umba::rtkos::VirtualKeyCode)byte )     ;  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP2.5\n"; */  return;
                }
            }
            else
            {
                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP3\n";
                #endif
                m_escapeSequence[m_escapeSequenceCounter++] = byte;
            }
        }
        else if (byte==0x7E) // check escape seq
        {
            #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP4\n";
            #endif
            // try to parse full esc seq
            if (m_escapeSequenceCounter<3)
            {
                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP5\n";
                #endif
                m_escapeSequenceCounter = 0; // wrong sequence
            }
            else if (m_escapeSequence[1]!=0x5B)
            {
                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP6\n";
                #endif
                m_escapeSequenceCounter = 0; // wrong sequence
            }
            else if (m_escapeSequenceCounter==3)
            {
                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP7\n";
                #endif
                switch(m_escapeSequence[2])
                {
                    case 0x31: generateKeyPress( umba::rtkos::VirtualKeyCode::home     );   /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP7.1\n"; */  break;
                    case 0x32: generateKeyPress( umba::rtkos::VirtualKeyCode::ins      );   /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP7.2\n"; */  break;
                    case 0x33: generateKeyPress( umba::rtkos::VirtualKeyCode::del      );   /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP7.3\n"; */  break;
                    case 0x34: generateKeyPress( umba::rtkos::VirtualKeyCode::end      );   /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP7.4\n"; */  break;
                    case 0x35: generateKeyPress( umba::rtkos::VirtualKeyCode::page_up   );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP7.5\n"; */  break;
                    case 0x36: generateKeyPress( umba::rtkos::VirtualKeyCode::page_down );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP7.6\n"; */  break;
                    //default  : // generateKeyPress( umba::rtkos::VirtualKeyCode::unknown | m_escapeSequence[0] ); return;
                }

                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP8\n";
                #endif

                m_escapeSequenceCounter = 0;
            }
            else if (m_escapeSequenceCounter==4)
            {
                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP9\n";
                #endif
                switch(m_escapeSequence[2])
                   {
                    case 0x31:   if (m_escapeSequence[3]>=0x31 && m_escapeSequence[3] <= 0x35)
                                     { generateKeyPress( (umba::rtkos::VirtualKeyCode)( (unsigned)(m_escapeSequence[3] - 0x31) + (unsigned)umba::rtkos::VirtualKeyCode::f1 ) );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP9.1\n"; */  }
                                 if (m_escapeSequence[3]>=0x37 && m_escapeSequence[3] <= 0x39)
                                     { generateKeyPress( (umba::rtkos::VirtualKeyCode)( (unsigned)(m_escapeSequence[3] - 0x37) + (unsigned)umba::rtkos::VirtualKeyCode::f6 ) );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP9.2\n"; */  }
                                 break;
                                 
                    case 0x32:   if (m_escapeSequence[3]>=0x30 && m_escapeSequence[3] <= 0x31)
                                     { generateKeyPress( (umba::rtkos::VirtualKeyCode)( (unsigned)(m_escapeSequence[3] - 0x30) + (unsigned)umba::rtkos::VirtualKeyCode::f9 ) );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP9.3\n"; */  }
                                 if (m_escapeSequence[3]>=0x33 && m_escapeSequence[3] <= 0x34)
                                     { generateKeyPress( (umba::rtkos::VirtualKeyCode)( (unsigned)(m_escapeSequence[3] - 0x33) + (unsigned)umba::rtkos::VirtualKeyCode::f11 ) );  /* UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP9.4\n"; */  }
                                 break;

                    //default  :   generateKeyPress(umba::rtkos::VirtualKeyCode::unknown | ((unsigned)m_escapeSequence[0])<<8 | m_escapeSequence[1] ); return;
                   }

                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP10\n";
                #endif
                m_escapeSequenceCounter = 0;
            }
            else
            {
                #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                    UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP11\n";
                #endif
                m_escapeSequenceCounter = 0;
            }
            
            // no next sequence here

        }
        else if (byte==0x1B) // check escape seq
        {
            #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
               UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP12\n";
            #endif
            // try to parse esc seq without marker
            if (checkCursorEscapes())
            {
               #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                   UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP12.true\n";
               #endif
            }
            else
            {
               #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                   UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP12.false\n";
               #endif
            }
            m_escapeSequenceCounter = 0;
            if (m_escapeSequenceCounter<sizeof(m_escapeSequence))
                m_escapeSequence[m_escapeSequenceCounter++] = byte; // next seq starts
        }
        else 
        {
            if (m_escapeSequenceCounter<sizeof(m_escapeSequence))
                m_escapeSequence[m_escapeSequenceCounter++] = byte; // next seq starts
            #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP13\n";
            #endif
            if (checkCursorEscapes())
            {
               #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                   UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP13.true\n";
               #endif
            }
            else
            {
               #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                   UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP13.false\n";
               #endif
            }

            if (m_escapeSequenceCounter>4)
                m_escapeSequenceCounter = 0; // too long sequence, clear it

            //generateKeyPress( (umba::rtkos::VirtualKeyCode)byte );
        }

        #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
            UMBA_RTKOS_LOG<<hex<<byte<<" - "<<"CP14, counter: "<<m_escapeSequenceCounter<<"\n"; 
        #endif
        if (m_escapeSequenceCounter)
        {
            #ifdef DEBUG_KEYBOARD_TERMINAL_DRIVER
                UMBA_RTKOS_LOG<<"Escape Sequence Buf:";
                for (size_t i=0; i!=m_escapeSequenceCounter; ++i)
                    UMBA_RTKOS_LOG<<" "<<hex<<m_escapeSequence[i];
                UMBA_RTKOS_LOG<<endl;
            #endif
        }
    }


    bool checkCursorEscapes()
    {
        using namespace umba::omanip;

        if (m_escapeSequenceCounter<3)
            return false;
        if (m_escapeSequence[0]!=0x1B)
            return false;
        if (m_escapeSequence[1]!=0x5B)
            return false;

        switch(m_escapeSequence[2])
        {
            case 0x41: generateKeyPress(umba::rtkos::VirtualKeyCode::up   ); break;
            case 0x42: generateKeyPress(umba::rtkos::VirtualKeyCode::down ); break;
            case 0x43: generateKeyPress(umba::rtkos::VirtualKeyCode::right); break;
            case 0x44: generateKeyPress(umba::rtkos::VirtualKeyCode::left ); break;
            default: return false;
        }

        //UMBA_RTKOS_LOG<<"CP15\n";
        size_t moveCnt = m_escapeSequenceCounter-3;
        if (!moveCnt)
        {
            //UMBA_RTKOS_LOG<<"CP16\n";
            m_escapeSequenceCounter = 0;
        }
        else
        {
            //UMBA_RTKOS_LOG<<"CP17\n";
            memmove( &m_escapeSequence[0], &m_escapeSequence[3], moveCnt);
            m_escapeSequenceCounter -= 3;
        }

        return true;

        //UMBA_RTKOS_LOG<<"CP18, moveCnt: "<<moveCnt<<", escSeqCnt: "<<m_escapeSequenceCounter<<"\n";
    }


    void generateKeyPress( umba::rtkos::VirtualKeyCode vkc )
    {
        //UMBA_RTKOS_LOG<<"GP1\n";
        if (vkc==umba::rtkos::VirtualKeyCode::unknown)
        {
            if (lastKey!=umba::rtkos::VirtualKeyCode::unknown)
            {
                //UMBA_RTKOS_LOG<<"GP1.1\n";
                postKeyPressEvent( lastKey, 0 );
                lastKey = umba::rtkos::VirtualKeyCode::unknown;
            }
            //UMBA_RTKOS_LOG<<"GP2\n";
            timerSet( KeyboardTerminalDriver_checkForKeyRelease, 0 );
            return;
        }

        //UMBA_RTKOS_LOG<<"GP3\n";
        if (lastKey!=vkc)
        {

            //UMBA_RTKOS_LOG<<"GP4\n";
            if (lastKey!=umba::rtkos::VirtualKeyCode::unknown)
            {
                //UMBA_RTKOS_LOG<<"GP5\n";
                postKeyPressEvent( lastKey, 0 );
           
                lastKey = umba::rtkos::VirtualKeyCode::unknown;
            }

            //UMBA_RTKOS_LOG<<"GP6\n";
            if (vkc==umba::rtkos::VirtualKeyCode::unknown)
            {
                //UMBA_RTKOS_LOG<<"GP7\n";
                timerSet( KeyboardTerminalDriver_checkForKeyRelease, 0 );
                return;
            }

            //UMBA_RTKOS_LOG<<"GP8\n";
            lastKey = vkc;
            keyPressCounter = 1;

            postKeyPressEvent( lastKey, keyPressCounter );

            timerSet( KeyboardTerminalDriver_checkForKeyRelease, 500 ); // 330 ms wait for release
        }
        else
        {
            //UMBA_RTKOS_LOG<<"GP9\n";
            ++keyPressCounter;

            postKeyPressEvent( lastKey, keyPressCounter );

            timerSet( KeyboardTerminalDriver_checkForKeyRelease, 500 ); // 330 ms wait for release
        }

    }

    void postKeyPressEvent( umba::rtkos::VirtualKeyCode vkc, size_t pressCounter ) // 0 - released
    {
        //UMBA_RTKOS_LOG<<"POST MSG\n";
        umba::rtkos::Message msg;
        msg.id = umba::rtkos::message_keyboard_id;

        char ch = 0; // for char events generation

        msg.messageKeyboard.keyboardId = umba::rtkos::terminal_keyboard_id;
        msg.messageKeyboard.keyCode = lastKey;
        msg.messageKeyboard.repeatCount = pressCounter;

        unsigned uKeyCode = (unsigned)msg.messageKeyboard.keyCode;
        if ( uKeyCode >= (unsigned)(uint8_t)' ' && uKeyCode < 0x7F) // ascii
        {
            ch = (char)uKeyCode; // в символ транслируем как есть
            if ( uKeyCode >= (unsigned)(uint8_t)'a' && uKeyCode <= (unsigned)(uint8_t)'z')
            {
                // а виртуальные коды всегда в верхнем регистре
                uKeyCode -= (unsigned)(uint8_t)'a';
                uKeyCode += (unsigned)(uint8_t)'A';
                msg.messageKeyboard.keyCode = (umba::rtkos::VirtualKeyCode)uKeyCode;
            }
        }
        else if (  uKeyCode == (unsigned)umba::rtkos::VirtualKeyCode::enter
                || uKeyCode == (unsigned)umba::rtkos::VirtualKeyCode::tab
                || uKeyCode == (unsigned)umba::rtkos::VirtualKeyCode::escape
                )
        {
            // Для трансляции в char просто снимаем признак виртуальности
            ch = (char)(uint8_t)(uKeyCode & ~(unsigned)umba::rtkos::VirtualKeyCode::virtual_code_flag);
        }


        if (pressCounter)
        {
            msg.messageKeyboard.keyState = umba::rtkos::VirtualKeyState::pressed;

        }
        else
        {
            msg.messageKeyboard.keyState = umba::rtkos::VirtualKeyState::released;
            ch = 0; // Даже если что-то было - сбрасываем. Отпускания не генерят событий InputChar
        }


        umba::rtkos::messagePost( msg );

        if (ch!=0)
        {
            // генерим следом символьное событие
            msg.id = umba::rtkos::message_input_char_id;
            msg.messageInputChar.charCode = ch;
            umba::rtkos::messagePost( msg );
        }
    }

    #endif

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        //auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);

        //oss<<"Soft I2C";
        #ifdef RTKOS_RTKOS_H
        //UMBA_RTKOS_LOG<<"\nBound driver class: "<<hex<<m_drvAddrDataSource.classId<<", id: "<<hex<<m_drvAddrDataSource.driverId<<", isValid: "<<m_drvAddrDataSource.isValid()<<", isInvalid: "<<m_drvAddrDataSource.isInvalid()<<endl;


        if (!m_drvAddrDataSource.isValid())
        {
            //UMBA_RTKOS_LOG<<"Not valid condition shots"<<endl;
            auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);
            //pStreamTo->write( ": ", 2 );
            oss<<"NOT BOUND";
            return true;
        }

        umba::drivers::IDriver* pDriver = UMBA_RTKOS_OS->driverGet( m_drvAddrDataSource );
        if (pDriver)
        {
            pDriver->getDriverDescription( m_drvAddrDataSource, pStreamTo );
            pStreamTo->write( ": ", 2 );
            return pDriver->getDriverConfigInfo( m_drvAddrDataSource, pStreamTo );
        }
        else
        {
            writeInvalidConfigString( pStreamTo );
            return false;
        }
        #endif
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
        switch(eventId)
        {
            case KeyboardTerminalDriver_checkForSingleEscapeTimerEvent:
                 {
                     //UMBA_RTKOS_LOG<<"TM1.1\n";
                     if (m_escapeSequenceCounter==1 && m_escapeSequence[0]==0x1B)
                     {
                         //UMBA_RTKOS_LOG<<"TM1.2\n";
                         generateKeyPress(umba::rtkos::VirtualKeyCode::escape   );
                         m_escapeSequenceCounter = 0;
                     }
                     //UMBA_RTKOS_LOG<<"TM1.3\n";
                     timerSet( KeyboardTerminalDriver_checkForSingleEscapeTimerEvent, 0 );
                 }
                 break;

            case KeyboardTerminalDriver_checkForKeyRelease:
                 {
                     //UMBA_RTKOS_LOG<<"TM2.1\n";
                     generateKeyPress(umba::rtkos::VirtualKeyCode::unknown);
                 }
                 break;
        };
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        return false;
    }




protected:

    DriverAddress m_drvAddrDataSource;

    uint8_t       m_escapeSequence[16]; // escape sequence buf
    size_t        m_escapeSequenceCounter = 0;

    umba::rtkos::VirtualKeyCode lastKey = umba::rtkos::VirtualKeyCode::unknown;
    size_t        keyPressCounter = 0;

};


} // namespace hid
} // namespace drivers
} // namespace umba

