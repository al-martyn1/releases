#pragma once

//umba::drivers::uplinks::GolemState

namespace umba{
namespace drivers{
namespace uplinks{


struct GolemState
{
    uint8_t     golemLink         = 0; // has data from Golem?
    uint8_t     dataLink          = 0;  // is datalink to PDU on? - value_id_golem_status_connected
    uint8_t     duChannel         = 0;
    uint8_t     videoChannel      = 0; // or -1 for non-standard freq
    uint32_t    videoFreq         = 0;
    uint8_t     videoState        = 0; // on/off
    uint8_t     videoPower        = 0; // 0-255

    uint8_t     scramblerState    = 0;
                                 
    int8_t      temperature       = 0;
    float       v5                = 0.0f;
    float       v12               = 0.0f;

    int8_t      datalink_P        = 0;
    int8_t      datalink_RSSI_L   = 0;
    int8_t      datalink_RSSI_L_R = 0;
    int8_t      datalink_LQI_L    = 0;
    int8_t      datalink_LQI_L_R  = 0;

    uint32_t    unexpectedCounter = 0;
    uint32_t    invalidCounter    = 0;
};

/*
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_driver_link_timeout         ,  0, "Datalink timeout (W/O)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_driver_ping_period          ,  1, "Ping period (R/O)" );

UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_scrambler_key               ,  5, "Scrambler key (W/0)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_reset                       ,  7, "Set to 1 for reset" );

*/




bool golemHandleMessage( const umba::drivers::MessageDriver &msg
                       , const umba::drivers::DriverAddress &golemDriverAddress
                       , GolemState &golemState
                       )
{
    using namespace umba::drivers;
    using namespace umba::drivers::uplinks;

    if (!isMessageDriverMine( msg, golemDriverAddress ))
        return false;

    ValueInfoFlags valueInfoFlags;
    //uint32_t u32;
    bool bHandled = false;
    

    if (msg.header.driverMessageId == MessageId::driver_notify_datalink)
    {
        golemState.golemLink = msg.linkStatus;
        bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_status_connected) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.dataLink, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_du_channel) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.duChannel, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_video_channel) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.videoChannel, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_video_freq) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.videoFreq, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_video_transmission_ctrl) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.videoState, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_video_transmission_power) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.videoPower, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_scrambler_ctrl) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.scramblerState, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_temperature) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.temperature, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_voltage_5v ) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.v12, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_voltage_12v ) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.v5, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_datalink_P) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.datalink_P, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_datalink_RSSI_L) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.datalink_RSSI_L, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_datalink_RSSI_L_R) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.datalink_RSSI_L_R, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_datalink_LQI_L) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.datalink_LQI_L, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDeviceValue(msg, value_id_golem_datalink_LQI_L_R) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.datalink_LQI_L_R, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDriverValue(msg, value_id_golem_driver_unexpected_cnt ) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.unexpectedCounter, &valueInfoFlags ))
            bHandled = true;
    }
    else if ( isClientMessageDriverValue(msg, value_id_golem_driver_invalid_cnt ) )
    {
        if (umba::drivers::extractFromMessageValue( msg.value, golemState.invalidCounter, &valueInfoFlags ))
            bHandled = true;
    }

    return bHandled;
}



/*
struct GolemState
{
    uint32_t    unexpectedCounter = 0;
    uint32_t    invalidCounter    = 0;
};

*/



} // namespace uplinks
} // namespace drivers
} // namespace umba


