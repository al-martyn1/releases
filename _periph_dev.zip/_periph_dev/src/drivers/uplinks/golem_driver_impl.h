#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

//#include "periph/gpio.h"
//#include "periph/stm32_traits.h"

//#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

//#include "scalcus/pwm.h"

//#include "periph/periph.h"

#include "../driver_stream_protocol_impl.h"
#include "protocols/golem_protocol_impl_base.h"
#include "../messages_rtkos.h"

#include "umba/const_string.h"
#include "umba/format_utils.h"




//#define UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA


namespace umba
{
namespace drivers
{
namespace uplinks
{

#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_golem_device_params.h"
#include "x_golem_driver_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE


//#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
//#include "x_golem_device_params.h"
//#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

const uint32_t golemFreqs[4] = { 1230000000
                               , 1190000000
                               , 1150000000
                               , 1110000000
                               };



umba::SimpleFormatter& dump( const uint8_t *pData, size_t dataSize = 8 ) 
{
    using namespace umba::omanip;
    for( size_t i = 0; i!=dataSize; ++i )
    {
        //if (i)
           UMBA_RTKOS_LOG<<" ";
        UMBA_RTKOS_LOG<<noshowbase<<hex<<width(2)<<pData[i];
    }

    return UMBA_RTKOS_LOG;
}


umba::SimpleFormatter& dumpEscaped( const uint8_t *pData, size_t dataSize = 8 ) 
{
    using namespace umba::omanip;
    for( size_t i = 0; i!=dataSize; ++i )
    {
        char ch = (char)pData[i];
        if (ch<' ')
        {
            if (ch=='\r')
                UMBA_RTKOS_LOG<<"\\r";
            else if (ch=='\n')
                UMBA_RTKOS_LOG<<"\\n";
            else if (ch=='\t')
                UMBA_RTKOS_LOG<<"\\t";
            else
                UMBA_RTKOS_LOG<<"\\"<<hex<<width(2)<<pData[i];
        }
        else
        {
            UMBA_RTKOS_LOG<<ch;
        }
    }

    return UMBA_RTKOS_LOG;
}


struct GolemProtocol : public umba::protocols::GolemProtocolImplBase
{
    typedef umba::protocols::GolemProtocolImplBase BaseProtocol;

    GolemProtocol( DriverAddress  drvAddrSendFrom
                 , IDriver       *pDriverSendFrom
                 )
    : BaseProtocol()
    , m_drvAddrSendFrom(drvAddrSendFrom)
    , m_pDriverSendFrom(pDriverSendFrom)
    {
        setPingPeriod(675); // 1000-325
        setCarrierTimeout(6000);
        setDatalinkTimeout(5000);
        setGolemReadReplyDelayPeriod(75);
    }

    void resetUnexpectedPacketsCounter()
    {
        m_unexpectedPacketsCounter = 0;
    }

    void resetInvalidPacketsCounter()
    {
        m_unexpectedPacketsCounter = 0;
    }

    void setDriverAddr( DriverAddress  drvAddrSendFrom )
    {
        m_drvAddrSendFrom = drvAddrSendFrom;
    }


private:


    virtual
    void onRawReceived( const StreamOctetType *pData, StreamSize dataSize ) override
    {
        // Затычка, можно не переопределять в наследниках, если протоколирование не нужно
        using namespace umba::omanip;
        if (m_dumpFlag)
        {
            UMBA_RTKOS_LOG<<"GOLEM -> : "; dump( pData, dataSize ); UMBA_RTKOS_LOG<<" ("; dumpEscaped( pData, dataSize ); UMBA_RTKOS_LOG<<")\n";
        }

        //UMBA_RTKOS_LOG<<"Received raw: ";
        //dump( pData, dataSize );
        //UMBA_RTKOS_LOG<<" ("<<dataSize<<" octets)"<<" - ";
        //<<endl;
        /* for (BaseProtocol::StreamSize i = 0; i!=dataSize; ++i)
         * {
         *     UMBA_RTKOS_LOG<<(char)pData[i];
         * }
         * UMBA_RTKOS_LOG<<endl;
         */

    }

    virtual
    void onRawSend( const StreamOctetType *pData, StreamSize dataSize ) override
    {
        if (m_dumpFlag)
        {
            UMBA_RTKOS_LOG<<"GOLEM <- : "; dump( pData, dataSize ); UMBA_RTKOS_LOG<<" ("; dumpEscaped( pData, dataSize ); UMBA_RTKOS_LOG<<")\n";
        }

        /*
        #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
            using namespace umba::omanip;
            UMBA_RTKOS_LOG<<"    Golem(TO): ";
            dump( pData, dataSize );
            UMBA_RTKOS_LOG<<" - ";
            dumpEscaped(pData, dataSize);
            UMBA_RTKOS_LOG<<endl;
        #endif
        */
    }

    const char *pingSequence = "SITM";

    virtual
    void onPing( ) override
    {
        m_commandPtr = &pingSequence[0];

        using namespace umba::omanip;

        #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
            auto tickNow = umba::time_service::getCurTimeMs();
            UMBA_RTKOS_LOG<<width(6)<<tickNow<<"  ---\n";
        #endif

        sendCurentCommand();
    }

    void sendCurentCommand()
    {
        using namespace umba::omanip;
        
        if (!m_commandPtr)
            return;
            
        m_replyLineCounter = 0;
        if (*m_commandPtr)
            sendPacket( (const uint8_t*)m_commandPtr, 1 );
    }

    // sendPacket( &statusQueryCmd, 1 );
    // clearLastSentCommand()
/*
  3394  ---
  3445  Golem [S0]: S, RAW: 0x53
  3446  Golem [S1]: P=35  RSSI L=-26 R=-33  LQI  L=11 R=10, RAW: 0x50 0x3D 0x33 0x35 0x20 0x20 0x52 0x53 0x53 0x49 0x20 0x4C 0x3D 0x2D 0x32 0x36 0x20 0x52 0x3D 0x2D 0x33 0x33 0x20 0x20 0x4C 0x51 0x49 0x20 0x20 0x4C 0x3D 0x31 0x31 0x20 0x52 0x3D 0x31 0x30
  3503  Golem [I0]: I, RAW: 0x49
  3503  Golem [I1]: C00, RAW: 0x43 0x30 0x30
  3504  Golem [I2]: F1230000000, RAW: 0x46 0x31 0x32 0x33 0x30 0x30 0x30 0x30 0x30 0x30 0x30
  3506  Golem [I3]: P000, RAW: 0x50 0x30 0x30 0x30
  3507  Golem [I4]: VideoTransmitter - OFF, RAW: 0x56 0x69 0x64 0x65 0x6F 0x54 0x72 0x61 0x6E 0x73 0x6D 0x69 0x74 0x74 0x65 0x72 0x20 0x2D 0x20 0x4F 0x46 0x46
  3562  Golem [T0]: ScT, RAW: 0x53 0x63 0x54
  3562  Golem [T1]: Vinp= 5.096 V12= 4.744 T=27, RAW: 0x56 0x69 0x6E 0x70 0x3D 0x20 0x35 0x2E 0x30 0x39 0x36 0x20 0x56 0x31 0x32 0x3D 0x20 0x34 0x2E 0x37 0x34 0x34 0x20 0x54 0x3D 0x32 0x37
  3616  Golem [M0]: M, RAW: 0x4D
  3616  Golem [M1]: Scrambler - OFF, RAW: 0x53 0x63 0x72 0x61 0x6D 0x62 0x6C 0x65 0x72 0x20 0x2D 0x20 0x4F 0x46 0x46

*/

    bool isDriverInitialized()
    {
        if (!m_pDriverSendFrom)
            return false;
        return m_pDriverSendFrom->isDriverInitialized();
    }

    virtual
    void onCarrierStateChanged( bool newState ) override
    {
        #if 0
        // Затычка для переопределения
        //postMessageDriverValue( m_driverSelfAddress, MessageId::device_param_response, value_id_sensor_value, sensorValue, static_cast<IDriver*>(this) );
        #endif
    }

    virtual
    void onDatalinkStateChanged( bool newState ) override
    {
        if (isDriverInitialized())
        {
            MessageDriver msgRes;
            initMessageDriver( msgRes, m_drvAddrSendFrom, MessageId::driver_notify_datalink, m_pDriverSendFrom );
            msgRes.linkStatus = newState ? 1 : 0;
            umba::rtkos::messagePost( msgRes );
        }
    }

    template<typename ValueType>
    inline
    void postMessageDriverValue( MessageId msgId, ValueId valueId, ValueType value )
    {
        umba::drivers::postMessageDriverValue( m_drvAddrSendFrom, msgId, valueId, value, m_pDriverSendFrom );
    }


    bool parseParam( const umba::ConstString<> &str, size_t &offs, int64_t &res, const char *pktStr, size_t pktSize )
    {
        offs += umba::parse_utils::skipWhitespaces( &pktStr[offs], pktSize - offs );
        if ( umba::startsWith( &pktStr[offs], str ) )
        {
            offs += str.size();
            if (umba::parse_utils::toNumberEx( &pktStr[offs], pktSize - offs, 10, &res, &offs ))
            {
                #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                UMBA_RTKOS_LOG<<"    Golem: "<<str.c_str()<<" "<<res<<"\n";
                #endif
                return true;
            }
        }

        ++m_invalidPacketsCounter;
        postMessageDriverValue( MessageId::driver_param_notify, value_id_golem_driver_invalid_cnt, m_invalidPacketsCounter );

        return false;
    }

    bool parseParam( const umba::ConstString<> &str, size_t &offs, float &res, size_t nDecDigits, const char *pktStr, size_t pktSize )
    {
        offs += umba::parse_utils::skipWhitespaces( &pktStr[offs], pktSize - offs );
        if ( umba::startsWith( &pktStr[offs], str ) )
        {
            offs += str.size();
            //if (umba::parse_utils::toNumberEx( &pktStr[offs], pktSize - offs, 10, &res, &offs ))
            int64_t ires;
            if ( umba::parse_utils::toDecimalFixedPoint( &pktStr[offs], pktSize - offs, nDecDigits, &ires, &offs ))
            {
                res = (float)ires / (float)umba::parse_utils::pow10( nDecDigits );
                #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                UMBA_RTKOS_LOG<<"    Golem: "<<str.c_str()<<" "<<res<<"\n";
                #endif
                return true;
            }
        }

        ++m_invalidPacketsCounter;
        postMessageDriverValue( MessageId::driver_param_notify, value_id_golem_driver_invalid_cnt, m_invalidPacketsCounter );

        return false;
    }

    virtual
    void handleParseError  ( const StreamOctetType *pkt, StreamSize pktSize, umba::Error parseRes ) override
    {
        ++m_invalidPacketsCounter;
        postMessageDriverValue( MessageId::driver_param_notify, value_id_golem_driver_unexpected_cnt, m_invalidPacketsCounter );
    }

    void postVideoFreq( uint32_t freq )
    {
        #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
        UMBA_RTKOS_LOG<<"Golem : post value_id_golem_video_channel"<<freq<<"\n";
        #endif
        postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_freq, freq );
        size_t i = 0, size = UMBA_COUNT_OF(golemFreqs);
        for(; i!=size; ++i)
        {
            if (golemFreqs[i]==freq)
                break;
        }

        if (i>=size)
        {
            #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
            UMBA_RTKOS_LOG<<"Golem : post value_id_golem_video_channel"<<(uint8_t)-1<<"\n";
            #endif
            postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_channel, (uint8_t)-1 );
        }
        else
        {
            #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
            UMBA_RTKOS_LOG<<"Golem : post value_id_golem_video_channel"<<(uint8_t)i<<"\n";
            #endif
            postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_channel, (uint8_t)i );
        }
    }



    virtual
    StreamOctetType parseGolemPacket( const BaseProtocol::StreamOctetType *pkt, BaseProtocol::StreamSize pktSize ) override
    {
        if (!isDriverInitialized())
            return *pkt;

        using namespace umba::omanip;

        #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
            auto tickNow = umba::time_service::getCurTimeMs();
            UMBA_RTKOS_LOG<<width(6)<<tickNow<<"  Golem ["<<(char)getLastSentCommand()<<m_replyLineCounter<<"]: ";
            for (BaseProtocol::StreamSize i = 0; i!=pktSize; ++i)
            {
                UMBA_RTKOS_LOG<<(char)pkt[i];
            }
            UMBA_RTKOS_LOG<<", RAW: ";
            dump( pkt, pktSize );
            UMBA_RTKOS_LOG<<endl;
        #endif

        static const umba::ConstString<> cStr = "C";
        static const umba::ConstString<> fStr = "F";
        static const umba::ConstString<> pStr = "P";
        static const umba::ConstString<> videoTransmitterStr = "VideoTransmitter - ";

        static const umba::ConstString<> onStr  = "ON";
        static const umba::ConstString<> offStr = "OFF";
        static const umba::ConstString<> hzStr  = "Hz";

        const char *pktStr = (const char*)pkt; // Он с гарантией нуль-терминированный
        int64_t iVal = 0;
        float   fVal = 0.0f;

        size_t offs = 0;

        char lastCommand = getLastSentCommand();
        switch( lastCommand )
        {
            case 0:
                 {
                     m_unexpectedPacketsCounter++;
                     #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                     UMBA_RTKOS_LOG<<error<<"Golem unexpected counter: "<<m_unexpectedPacketsCounter<<normal<<"\n";
                     #endif
                     postMessageDriverValue( MessageId::driver_param_notify, value_id_golem_driver_unexpected_cnt, m_invalidPacketsCounter );
                 }
                 break;

            case 'S':
                 {
                     if (!m_replyLineCounter)
                     {
                         m_replyLineCounter++;
                     }
                     else
                     {
                         /*
                         P=31  RSSI L=-24 R=-33  LQI  L=12 R=11
                           or
                         Disconnected
                         */
                         static const umba::ConstString<> disconnectedStr = "Disconnected";
                         static const umba::ConstString<> pStr            = "P=";
                         static const umba::ConstString<> rssiStr         = "RSSI L=";
                         static const umba::ConstString<> rStr            = "R=";
                         static const umba::ConstString<> lqiStr          = "LQI  L=";

                         offs += umba::parse_utils::skipWhitespaces( &pktStr[offs], pktSize - offs );

                         if ( umba::startsWith( pktStr, disconnectedStr ) )
                         {
                             #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                             UMBA_RTKOS_LOG<<error<<"Golem : disconnected"<<normal<<"\n";
                             #endif

                             postMessageDriverValue( MessageId::device_param_notify, value_id_golem_status_connected, (uint8_t)0 );
                         }
                         else
                         {
                             postMessageDriverValue( MessageId::device_param_notify, value_id_golem_status_connected, (uint8_t)1 );

                             // P= 
                             if (parseParam( pStr, offs, iVal, pktStr, pktSize ))
                             {
                                 #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                 UMBA_RTKOS_LOG<<"Golem : post value_id_golem_datalink_P"<<(int16_t)(int8_t)iVal<<"\n";
                                 #endif
                                 postMessageDriverValue( MessageId::device_param_notify, value_id_golem_datalink_P, (int8_t)iVal );
                             }

                             // RSSI L=
                             if (parseParam( rssiStr, offs, iVal, pktStr, pktSize ))
                             {
                                 #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                 UMBA_RTKOS_LOG<<"Golem : post value_id_golem_datalink_RSSI_L"<<(int16_t)(int8_t)iVal<<"\n";
                                 #endif
                                 postMessageDriverValue( MessageId::device_param_notify, value_id_golem_datalink_RSSI_L, (int8_t)iVal );
                             }

                             // R=
                             if (parseParam( rStr, offs, iVal, pktStr, pktSize ))
                             {
                                 #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                 UMBA_RTKOS_LOG<<"Golem : post value_id_golem_datalink_RSSI_L_R"<<(int16_t)(int8_t)iVal<<"\n";
                                 #endif
                                 postMessageDriverValue( MessageId::device_param_notify, value_id_golem_datalink_RSSI_L_R, (int8_t)iVal );
                             }

                             // LQI  L=
                             if (parseParam( lqiStr, offs, iVal, pktStr, pktSize ))
                             {
                                 #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                 UMBA_RTKOS_LOG<<"Golem : post value_id_golem_datalink_LQI_L"<<(int16_t)(int8_t)iVal<<"\n";
                                 #endif
                                 postMessageDriverValue( MessageId::device_param_notify, value_id_golem_datalink_LQI_L, (int8_t)iVal );
                             }

                             // R
                             if (parseParam( rStr, offs, iVal, pktStr, pktSize ))
                             {
                                 #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                 UMBA_RTKOS_LOG<<"Golem : post value_id_golem_datalink_LQI_L_R"<<(int16_t)(int8_t)iVal<<"\n";
                                 #endif
                                 postMessageDriverValue( MessageId::device_param_notify, value_id_golem_datalink_LQI_L_R, (int8_t)iVal );
                             }
                         }

                         clearLastSentCommand();
                         ++m_commandPtr;
                         sendCurentCommand();
                     }
                 }
                 break;

            case 'I': // or ScI
                 {

                     switch(m_replyLineCounter)
                     {
                         case 0: ++m_replyLineCounter; break; // simple skip

                         case 1: // parse [C00]
                                 ++m_replyLineCounter;
                                 if (parseParam( cStr, offs, iVal, pktStr, pktSize ))
                                 {
                                     #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                     UMBA_RTKOS_LOG<<"Golem : post value_id_golem_du_channel"<<(uint8_t)iVal<<"\n";
                                     #endif
                                     postMessageDriverValue( MessageId::device_param_notify, value_id_golem_du_channel, (uint8_t)iVal );
                                 }
                                 break;

                         case 2: // parse [F1230000000]
                                 ++m_replyLineCounter;
                                 if (parseParam( fStr, offs, iVal, pktStr, pktSize ))
                                 {
                                     postVideoFreq((uint32_t)iVal);
                                     /*
                                     postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_freq, (uint32_t)iVal );
                                     size_t i = 0, size = UMBA_COUNT_OF(golemFreqs);
                                     for(; i!=size; ++i)
                                     {
                                         if (golemFreqs[i]==(uint32_t)iVal)
                                             break;
                                     }

                                     if (i>=size)
                                         postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_channel, (uint8_t)-1 );
                                     else
                                         postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_channel, (uint8_t)i );
                                     */
                                 }
                                 break;

                         case 3: // parse [P000]
                                 ++m_replyLineCounter;
                                 if (parseParam( pStr, offs, iVal, pktStr, pktSize ))
                                 {
                                     #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                     UMBA_RTKOS_LOG<<"Golem : post value_id_golem_video_transmission_power"<<(uint8_t)iVal<<"\n";
                                     #endif
                                     postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_transmission_power, (uint8_t)iVal );
                                 }
                                 break;

                         case 4: // parse [VideoTransmitter - OFF]
                                 offs += umba::parse_utils::skipWhitespaces( &pktStr[offs], pktSize - offs );
                                 if ( umba::startsWith( &pktStr[offs], videoTransmitterStr ) )
                                 {
                                     offs += videoTransmitterStr.size();
                                     offs += umba::parse_utils::skipWhitespaces( &pktStr[offs], pktSize - offs );
                                     if ( umba::startsWith( &pktStr[offs], onStr ) )
                                     {
                                         #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                         UMBA_RTKOS_LOG<<"    Golem - "<<videoTransmitterStr.c_str()<<" "<<onStr.c_str()<<"\n";
                                         #endif
                                         postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_transmission_ctrl, (uint8_t)1 );
                                     }
                                     else if ( umba::startsWith( &pktStr[offs], offStr ) )
                                     {
                                         #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                         UMBA_RTKOS_LOG<<"    Golem - "<<videoTransmitterStr.c_str()<<" "<<offStr.c_str()<<"\n";
                                         #endif
                                         postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_transmission_ctrl, (uint8_t)0 );
                                     }
                                     else
                                     {
                                         #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                         UMBA_RTKOS_LOG<<"    Golem - "<<videoTransmitterStr.c_str()<<" INVALID\n";
                                         #endif
                                         ++m_invalidPacketsCounter;
                                         postMessageDriverValue( MessageId::device_param_notify, value_id_golem_driver_unexpected_cnt, m_invalidPacketsCounter );
                                     }
                                 }

                                 ++m_commandPtr;
                                 clearLastSentCommand();
                                 sendCurentCommand();
                                 //++m_replyLineCounter;
                                 break;

                         case 5: // parse [ScI] - хз, что это, и на самом деле оно вместо эха
                                 ++m_commandPtr;
                                 clearLastSentCommand();
                                 sendCurentCommand();
                                 //++m_replyLineCounter;
                                 break;
                     };
                 }
                 break;

            case 'T': //  Vinp= 5.096 V12= 4.748 T=32,
                 {
                     static const umba::ConstString<> vInpStr = "Vinp=";
                     static const umba::ConstString<> v12Str  = "V12=";
                     static const umba::ConstString<> tStr    = "T=";

                     if (!m_replyLineCounter)
                     {
                         m_replyLineCounter++;
                     }
                     else
                     {
                         //bool parseParam( const umba::ConstString<> &str, size_t &offs, float &res, size_t nDecDigits, const char *pktStr, size_t pktSize )
                         if (parseParam( vInpStr, offs, fVal, (size_t)3, pktStr, pktSize ))
                         {
                             #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                             UMBA_RTKOS_LOG<<"Golem : post value_id_golem_voltage_5v"<<fVal<<"\n";
                             #endif
                             postMessageDriverValue( MessageId::device_param_notify, value_id_golem_voltage_5v, fVal );
                         }
                         if (parseParam( v12Str, offs, fVal, (size_t)3, pktStr, pktSize ))
                         {
                             #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                             UMBA_RTKOS_LOG<<"Golem : post value_id_golem_voltage_12v"<<fVal<<"\n";
                             #endif
                             postMessageDriverValue( MessageId::device_param_notify, value_id_golem_voltage_12v, fVal );
                         }
                         if (parseParam( tStr, offs, iVal, pktStr, pktSize ))
                         {
                             #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                             UMBA_RTKOS_LOG<<"Golem : post value_id_golem_video_transmission_power"<<(int8_t)iVal<<"\n";
                             #endif
                             postMessageDriverValue( MessageId::device_param_notify, value_id_golem_temperature, (int8_t)iVal );
                         }

                         clearLastSentCommand();
                         ++m_commandPtr;
                         sendCurentCommand();
                     }
                 }
                 break;

            case 'M':
                 {
                     static const umba::ConstString<> scramblerStr = "Scrambler - ";
                     if (!m_replyLineCounter)
                     {
                         m_replyLineCounter++;
                     }
                     else
                     {
                         
                         offs += umba::parse_utils::skipWhitespaces( &pktStr[offs], pktSize - offs );
                         if ( umba::startsWith( &pktStr[offs], scramblerStr ) )
                         {
                             offs += scramblerStr.size();
                             offs += umba::parse_utils::skipWhitespaces( &pktStr[offs], pktSize - offs );
                             if ( umba::startsWith( &pktStr[offs], onStr ) )
                             {
                                 #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                 UMBA_RTKOS_LOG<<"    Golem - "<<scramblerStr.c_str()<<" "<<onStr.c_str()<<"\n";
                                 #endif
                                 postMessageDriverValue( MessageId::device_param_notify, value_id_golem_scrambler_ctrl, (uint8_t)1 );
                             }
                             else if ( umba::startsWith( &pktStr[offs], offStr ) )
                             {
                                 #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                                 UMBA_RTKOS_LOG<<"    Golem - "<<scramblerStr.c_str()<<" "<<offStr.c_str()<<"\n";
                                 #endif
                                 postMessageDriverValue( MessageId::device_param_notify, value_id_golem_scrambler_ctrl, (uint8_t)0 );
                             }
                         }
                         else
                         {
                             #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                             UMBA_RTKOS_LOG<<"    Golem - "<<scramblerStr.c_str()<<" INVALID\n";
                             #endif
                             ++m_invalidPacketsCounter;
                             postMessageDriverValue( MessageId::driver_param_notify, value_id_golem_driver_unexpected_cnt, m_invalidPacketsCounter );
                         }

                         clearLastSentCommand();
                         ++m_commandPtr;
                         sendCurentCommand();
                     }
                 }
                 break;

            case 'P':
                 {
                     if (!m_replyLineCounter)
                     {
                         if (parseParam( fStr, offs, iVal, pktStr, pktSize ))
                         {
                             postVideoFreq((uint32_t)iVal);
                         }
                         else if (parseParam( pStr, offs, iVal, pktStr, pktSize ))
                         {
                             //postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_transmission_power, (uint8_t)iVal );
                             ++m_replyLineCounter;
                         }
                     }
                     else if (parseParam( pStr, offs, iVal, pktStr, pktSize ))
                     {
                         #if defined(UMBA_DRIVERS_GOLEM_DRIVER_LOG_DATA)
                         UMBA_RTKOS_LOG<<"Golem : post value_id_golem_video_transmission_power"<<(uint8_t)iVal<<"\n";
                         #endif
                         postMessageDriverValue( MessageId::device_param_notify, value_id_golem_video_transmission_power, (uint8_t)iVal );
                     }
                 }
                 break;

            case 'F':
                 {
                     if (parseParam( fStr, offs, iVal, pktStr, pktSize ))
                     {
                         offs += umba::parse_utils::skipWhitespaces( &pktStr[offs], pktSize - offs );
                         if ( umba::startsWith( &pktStr[offs], hzStr ) )
                         {
                             // second time got FXXX... - this is not an echo, this is applied value
                             postVideoFreq((uint32_t)iVal);
                         }
                         // hzStr0 Hz
                     }
                 }
                 break;

        }

        return *pkt;
    }

    DriverAddress       m_drvAddrSendFrom;
    IDriver            *m_pDriverSendFrom;

    const char* m_commandPtr                = &pingSequence[0];
    size_t      m_replyLineCounter          = 0;
    uint32_t    m_unexpectedPacketsCounter  = 0;
    uint32_t    m_invalidPacketsCounter     = 0;

public:

    bool        m_dumpFlag = false;


}; // struct GolemProtocol


/*

S reply
 P=31  RSSI L=-24 R=-33  LQI  L=12 R=11
   or
 Disconnected


GOLEM V1A
Commands:
C[<nn>]        - [Set] or read DU channel number, <nn>-number of channel
D<n>           - Display debug information, <n> - 0-off,1-Status,2-Status+Error
F[<xxxxxxxxxx>]- [Set] or read frequency of video transmitter,
                 <xxxxxxxxxx>-frequency in hertz (102000000..123000000)
I              - Display psramemers
K[<b>]         - [Set] or read camera keys, <b> 0-All keys release U-Up Press D-Down press
                 L-Left press R-Right press S-Set press
L<k3><k2><k1><k0> - Set scrambler key
M[<z>]         - [Set] or scrembler mode, <z> 0-off 1-on
P[<yyy>]       - [Set] or read power of video transmitter, <yyy>-power level (0..255)
R              - Reset
S              - Display status information
T              - Get volage and temperatures
V[<z>]         - [Set] or read video transmitter mode, <z> 0-off 1-on
W              - write settings in to flash memory
*
*/


// R reply and on start message
//GOLEM V1A (C) SET-1 2015-2018
//* Init SLAVE
//Channel00 [0]
//Calibrate [0]
//Start

//C00
//C01 [0]
//P100

// T
// Vinp= 4.962 V12=12.025 T=40

// V, V0, V1
// VideoTransmitter - ON
// VideoTransmitter - OFF

// F, FXXXXXXXXXXX
// F1230000000 - on simple query
// F1150000000 Hz - on set command

// S
// Disconnected


// I
// C00
// F1230000000
// P100
// VideoTransmitter - ON
// Scrambler - OFF

// L, LXXXX, M, M0, M1
// Scrambler - ON
// Scrambler - OFF







class GolemDriver : public DriverImplBase< class_id_uplink, subclass_id_golem, PowerConsumptionClass::medium >
{

    typedef DriverImplBase< class_id_uplink, subclass_id_golem, PowerConsumptionClass::medium > BaseImpl;

public:

    UMBA_DRIVER_DESCRIPTION( "Golem uart-radiolink/video transmitter" )

    GolemDriver( DriverAddress drvAddrDataSource )
    : BaseImpl()
    , m_drvAddrDataSource(drvAddrDataSource)
    , m_golemStream(drvAddrDataSource)
    , m_golemProtocol( m_driverSelfAddress, this )
    {
        m_golemProtocol.setStream( &m_golemStream );
        m_golemProtocol.setPacketComposer(&m_golemPacketComposer);
        m_golemProtocol.setPacketParser  (&m_golemPacketParser);
    }

    GolemDriver( GolemDriver && ) = default;

    bool install(DriverId driverId = driver_id_auto)
    {
        #ifdef RTKOS_RTKOS_H
        //DriverId 
        if (!umba::rtkos::messageFilterAdd( this ))
            return false;
        if (!umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::normal ))
            return false;
        return umba::rtkos::driverInstall( DriverAddress(class_id_value, driverId), subclass_id_value, this );
        
        #endif
    }

    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    //UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_golem_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_golem_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE


    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NAMES_BEGIN()
    #include "x_golem_driver_params.h"
    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DRIVER_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_golem_driver_params.h"
    UMBA_DRIVER_DECLARE_DRIVER_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    //UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    //UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    virtual
    void poll() override
    {
        m_golemProtocol.poll();
    }

    virtual
    bool isReadyForPoll() override { return true; }


    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        //auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);

        //oss<<"Soft I2C";
        #ifdef RTKOS_RTKOS_H
        //UMBA_RTKOS_LOG<<"\nBound driver class: "<<hex<<m_drvAddrDataSource.classId<<", id: "<<hex<<m_drvAddrDataSource.driverId<<", isValid: "<<m_drvAddrDataSource.isValid()<<", isInvalid: "<<m_drvAddrDataSource.isInvalid()<<endl;


        if (!m_drvAddrDataSource.isValid())
        {
            //UMBA_RTKOS_LOG<<"Not valid condition shots"<<endl;
            auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);
            //pStreamTo->write( ": ", 2 );
            oss<<"NOT BOUND";
            return true;
        }

        umba::drivers::IDriver* pDriver = UMBA_RTKOS_OS->driverGet( m_drvAddrDataSource );
        if (pDriver)
        {
            pDriver->getDriverDescription( m_drvAddrDataSource, pStreamTo );
            pStreamTo->write( ": ", 2 );
            return pDriver->getDriverConfigInfo( m_drvAddrDataSource, pStreamTo );
        }
        else
        {
            writeInvalidConfigString( pStreamTo );
            return false;
        }
        #endif
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    //void initTimer()

    virtual
    bool onFilterMessage( umba::rtkos::Message &msg ) override
    {
        if (msg.id!=umba::rtkos::message_driver_id)
            return false;

        if (!isMessageFromDriver( msg.messageDriver ))
            return false;

        if (msg.messageDriver.header.driverMessageId!=MessageId::driver_raw_data)
            return false; // not data

        if (msg.messageDriver.rawData.dataSize==0)
            return false; // no data

        if (  msg.messageDriver.header.classId  != m_drvAddrDataSource.classId
           || msg.messageDriver.header.driverId != m_drvAddrDataSource.driverId
           )
            return false; // Not our message

        bool res = m_golemStream.putDriverDataToReadBuffer( msg.messageDriver );
        m_golemProtocol.poll();

        return res;
    }


    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        using namespace umba::periph::traits;

        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        // TimerId timerSet ( Object *pObj, TimerEventId eventId, TimeTick period )

        /*
        uint8_t statusQueryCmd = (uint8_t)'R';
        m_golemProtocol.sendPacket( &statusQueryCmd, 1 );

        uint8_t cmd2[2] = { 'D', '0' };
        m_golemProtocol.sendPacket( &cmd2[0], 2 );

        cmd2[0] = 'S';
        m_golemProtocol.sendPacket( &cmd2[0], 2 );

        statusQueryCmd = (uint8_t)'W';
        m_golemProtocol.sendPacket( &statusQueryCmd, 1 );

        statusQueryCmd = (uint8_t)'S';
        //m_golemProtocol.sendPacket( &statusQueryCmd, 1 );

        statusQueryCmd = (uint8_t)'C';
        //m_golemProtocol.sendPacket( &statusQueryCmd, 1 );

        statusQueryCmd = (uint8_t)'I';
        //m_golemProtocol.sendPacket( &statusQueryCmd, 1 );
        */

        {
            MessageDriver msgRes;
            initMessageDriver( msgRes, m_driverSelfAddress, MessageId::driver_notify_datalink, this );
            msgRes.linkStatus = m_golemProtocol.isDatalinkGood( ) ? 1 : 0;
            umba::rtkos::messagePost( msgRes );
        }

        return umba::errors::ok;
    }

    virtual
    void setDriverId( ClassId classId, SubclassId subclassId, DriverId driverId ) override
    {
        BaseImpl::setDriverId( classId, subclassId, driverId );
        m_golemProtocol.setDriverAddr( m_driverSelfAddress );
    }

    bool canSend(const MessageDriver &msg)
    {
        if (m_golemProtocol.canSend())
            return true;

        #if defined(UMBA_RTKOS_LOG)
        using namespace umba::omanip;
        //UMBA_RTKOS_LOG<<error<<"Golem communications is currently active, can't send control packet"<<normal<<endl;
        #endif

        // put msg back to queue
        umba::rtkos::messagePost( msg );

        return false;
    }
    

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        if (!isMessageDriverMine( msg, class_id_value, m_driverSelfId ))
            return dumpMsg(msg);

        else if (isMessageDriverMessageId( msg, MessageId::driver_param_set ) )
        {
            switch(msg.value.id)
            {
                case -1:
                     {
                         uint32_t val = 0;
                         umba::drivers::extractFromMessageValue( msg.value, val );
                         m_golemProtocol.m_dumpFlag = val ? true : false;
                     }
                     break;

                case value_id_golem_driver_link_timeout:
                     {
                         uint32_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (val<2000)
                             val = 2000;
                         if (val>10000)
                             val = 10000;

                         m_golemProtocol.setCarrierTimeout(val+1000);
                         m_golemProtocol.setDatalinkTimeout(val);
                     }
                     break;

                case value_id_golem_driver_ping_period :
                     {
                         uint32_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (val<1000)
                             val = 1000;
                         if (val>5000)
                             val = 5000;

                         m_golemProtocol.setPingPeriod( val-325 ); // 1000-325 325 мс занимает цикл полного опроса голема
                     }
                     break;
                     
                default: return dumpMsg(msg);
            }
        }
        else if (isMessageDriverMessageId( msg, MessageId::device_param_set ) )
        {
            uint8_t cmdBuf[32];
            
            switch(msg.value.id)
            {
                case value_id_golem_du_channel:
                     {
                         uint8_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (val>98)
                             return false;

                         if (!canSend(msg))
                             return true;

                         cmdBuf[0] = 'C';
                         size_t len = 1 + umba::format_utils::formatNumber( &cmdBuf[1], sizeof(cmdBuf)-1, (uint64_t)val, 10, 2, '0' );
                         m_golemProtocol.sendPacket( &cmdBuf[0], len );
                     }
                     break;
           
                case value_id_golem_video_channel:
                     {
                         uint8_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (val>3)
                             return false;

                         if (!canSend(msg))
                             return true;

                         cmdBuf[0] = 'F';
                         size_t len = 1 + umba::format_utils::formatNumber( &cmdBuf[1], sizeof(cmdBuf)-1, (uint64_t)golemFreqs[val], 10, 2, '0' );
                         m_golemProtocol.sendPacket( &cmdBuf[0], len );
                     }
                     break;
           
                case value_id_golem_video_transmission_ctrl:
                     {
                         uint8_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (!canSend(msg))
                             return true;

                         cmdBuf[0] = 'V';
                         cmdBuf[1] = val ? '1' : '0';
                         m_golemProtocol.sendPacket( &cmdBuf[0], 2 );
                     }
                     break;
           
                case value_id_golem_video_transmission_power:
                     {
                         uint8_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (!canSend(msg))
                             return true;

                         cmdBuf[0] = 'P';
                         size_t len = 1 + umba::format_utils::formatNumber( &cmdBuf[1], sizeof(cmdBuf)-1, (uint64_t)val, 10, 3, '0' );
                         m_golemProtocol.sendPacket( &cmdBuf[0], len );
                     }
                     break;
           
                case value_id_golem_scrambler_ctrl:
                     {
                         uint8_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (!canSend(msg))
                             return true;

                         cmdBuf[0] = 'M';
                         cmdBuf[1] = val ? '1' : '0';
                         m_golemProtocol.sendPacket( &cmdBuf[0], 2 );
                     }
                     break;
           
                case value_id_golem_scrambler_key:
                     {
                         uint16_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (!canSend(msg))
                             return true;

                         cmdBuf[0] = 'L';
                         size_t len = 1 + umba::format_utils::formatNumber( &cmdBuf[1], sizeof(cmdBuf)-1, (uint64_t)val&0xFFFFu, 16, 4, '0' );
                         m_golemProtocol.sendPacket( &cmdBuf[0], len );
                     }
                     break;
           
                case value_id_golem_reset:
                     {
                         uint8_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (!canSend(msg))
                             return true;

                         cmdBuf[0] = 'R';
                         m_golemProtocol.sendPacket( &cmdBuf[0], 1 );
                     }
                     break;

                case value_id_golem_store_to_flash:
                     {
                         uint8_t val = 0;
                         if (!umba::drivers::extractFromMessageValue( msg.value, val ))
                            return dumpMsg(msg, "Error in format");

                         if (!canSend(msg))
                             return true;

                         cmdBuf[0] = 'W';
                         m_golemProtocol.sendPacket( &cmdBuf[0], 1 );
                     }
                     break;

                     
           
                default: return dumpMsg(msg);
            }
        }
        else
        {
            return dumpMsg(msg);
        }


            

        return true;
    }




protected:

    DriverAddress                             m_drvAddrDataSource;
    IOctetIOStreamImplDriver<64>              m_golemStream;
    umba::protocols::GolemPacketComposer<32>  m_golemPacketComposer;
    umba::protocols::GolemPacketParser<64>    m_golemPacketParser;
    GolemProtocol                             m_golemProtocol;
    bool                                      m_dumpFlag = false;

};


} // namespace uplinks
} // namespace drivers
} // namespace umba

