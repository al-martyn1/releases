UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_id_golem           ,  0x7FE515BF, "Golem" );

