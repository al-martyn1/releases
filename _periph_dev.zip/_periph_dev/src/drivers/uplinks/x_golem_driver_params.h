UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_driver_link_timeout         ,  0, "Datalink timeout (W/O)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_driver_ping_period          ,  1, "Ping period (R/O)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_driver_unexpected_cnt       ,  2, "Unexpected packets counter" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_driver_invalid_cnt          ,  3, "Invalid packets counter" );
