UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_du_channel                  ,  0, "DU channel, 00-98" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_video_channel               ,  1, "Video channel # (0-3) or Freq exact (1230000000-1110000000)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_video_freq                  ,  2, "Video channel frequency (notify only)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_video_transmission_ctrl     ,  3, "Video on/off" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_video_transmission_power    ,  4, "Video transmitter power, 0-255" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_scrambler_key               ,  5, "Scrambler key (W/0)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_scrambler_ctrl              ,  6, "Scrambler on/off" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_reset                       ,  7, "Set to 1 for reset" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_store_to_flash              ,  8, "Set to 1 to write settings to device flash" );

UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_temperature                 ,  9, "Temperature (R/O, f32)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_voltage_5v                  , 10, "5V Source voltage (R/O, f32)" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_voltage_12v                 , 11, "12V Source voltage (R/O, f32)" );

UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_datalink_P                  , 12, "Datalink status P" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_datalink_RSSI_L             , 13, "Datalink status RSSI L" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_datalink_RSSI_L_R           , 14, "Datalink status RSSI L  R" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_datalink_LQI_L              , 15, "Datalink status LQI L" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_datalink_LQI_L_R            , 16, "Datalink status LQI L  R" );
                                                                            
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_golem_status_connected            , 17, "Uplink connection status" );
//UMBA_DRIVER_DECLARE_VALUE_ID_CODE( , , "" )




