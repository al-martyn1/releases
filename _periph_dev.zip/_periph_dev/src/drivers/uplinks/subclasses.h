#pragma once

namespace umba
{
namespace drivers
{
namespace uplinks
{


#define UMBA_DRIVER_DECLARE_CLASS_CODE( id, value, descr )    UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_CONST_VALUE( SubclassId, id, value, descr )
#include "x_subclasses.h"
#undef UMBA_DRIVER_DECLARE_CLASS_CODE

#define UMBA_DRIVER_DECLARE_CLASS_CODE( id, value, descr )    UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_CONST_NAME( SubclassId, id, value, descr )
inline
const char* getSublassName( SubclassId id )
{
    switch(id)
    {
        #include "x_subclasses.h"

        default: return "<UNKNOWN>";
    }
}
#undef UMBA_DRIVER_DECLARE_CLASS_CODE


} // namespace uplinks
} // namespace drivers
} // namespace umba

