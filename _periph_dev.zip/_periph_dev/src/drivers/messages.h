#pragma once

#include "basic_types.h"


// umba::drivers


/* Сообщения для драйверов кладуться в начало очереди сообщений.
   Если драйвер не может сейчас обработать сообщение, то кладет сообщение 
   в конец очереди, при этом увеличив счетчик отложенности.
   У себя он хранит свое значение счетчика,
   и может начать обработку сообщений с таким же или большим номером,
   остальное перенаправляет в хвост. Так делается, чтобы сообщения, например, 
   на отправку данных, не изменили свой порядок.
   При достижении счетчиком максимального значения драйвер отбрасывает сообщения.
*/


/* Конфигурация.
   Конфигурация может быть как драйвера, так и устройства

   Конфигурация драйвера - это параметры связи, таймауты, и тп

   Конфигурация устройства зависит от конфигурации устройства

   Можно запросить параметры конфигурации



*/

namespace umba
{
namespace drivers
{





//-----------------------------------------------------------------------------
enum class MessageId : uint16_t
{
    deffered_mask               = 0xFF00,  // отложенное сообщение - маска счетчика отложенности (забил на это)
    driver_message_any          = 0xFFFF,
                               
    driver_param_request_list   = 0x0001,  // в драйвер, посылает клиентский код - хочет получить весь список
    driver_param_request        = 0x0002,  // запрос значения, в драйвер, посылает клиентский код
    driver_param_response       = 0x0003,  // из драйвера - ответы драйвера
    driver_param_set            = 0x0004,  // в драйвер - установка
    driver_param_set_ack        = 0x0005,  // из драйвера - подтверждение установки
    driver_param_set_err        = 0x0006,  // из драйвера - ошибка установки (неверное значение)
    driver_param_notify         = 0x0007,  // из драйвера - параметр изменился - присылаются асинхронно (не в ответ)
    driver_param_mask           = 0x000F,

    device_param_request_list   = 0x0010,  // в драйвер, посылает клиентский код - хочет получить весь список с текущими значениями
    device_param_request        = 0x0020,  // в устройство, посылает клиентский код
    device_param_response       = 0x0030,  // из драйвера - ответы драйвера, полученные от устройства
    device_param_set            = 0x0040,  // в устройство - установка
    device_param_set_ack        = 0x0050,  // // из драйвера/устройства - подтверждение установки
    device_param_set_err        = 0x0060,  // // из драйвера/устройства - ошибка установки (неверное значение)
    device_param_notify         = 0x0070,  // из устройства - значение изменилось - присылаются асинхронно (не в ответ)
    device_param_mask           = 0x00F0,

    param_mask                  = 0x00FF,  // driver or device param


    driver_raw_data             = 0x0100,  // сырые данные от/к драйверу
    driver_raw_data_request     = 0x0200,  // запрос данных, если RawData::dataSize не равно нулю, считавается заданное количество байт, иначе - сколько получится

    driver_notify_carrier       = 0x0300,  // состояние канала связи (несущая)
    driver_notify_datalink      = 0x0400,  // состояние данных (логическая связь)


};

//-----------------------------------------------------------------------------


constexpr IDriver*  driver_addr_any = (IDriver*)-1;


//-----------------------------------------------------------------------------
struct MessageDriverHeader
{
    IDriver    *pDriver; //!< Если не 0, то сообщение от драйвера, иначе - драйверу

    ClassId     classId;   // 
    DriverId    driverId;

    MessageId   driverMessageId;
};


//-----------------------------------------------------------------------------
inline
bool isMessageFromDriver( const MessageDriverHeader &hdr )
{
    return hdr.pDriver!=0;
}



//-----------------------------------------------------------------------------

// driver/device_request_list  - MessageValue not filled at all
// driver/device_param_request - 'id' valid
// driver/device_response      - 'id', valueInfo, and some in union are valid
// driver/device_set           - 'id', valueInfo, and some in union must be valid
// driver/device_set_ack       - 'id' valid
// driver/device_set_err       - 'id' valid
// driver/device_param_notify  - 'id', valueInfo, and some in union are valid

struct MessageValue
{
    ValueId         id;
    ValueInfoFlags  valueInfo;
    union
    {
         uint8_t     u8;
        uint16_t    u16;
        uint32_t    u32;
        uint64_t    u64;

          int8_t     s8;
         int16_t    s16;
         int32_t    s32;
         int64_t    s64;

           float    f32;
          double    f64;
    };
};


template<typename T>
inline
MessageValue makeMessageValue( ValueId id, T t )
{
    MessageValue val;
    val.id         = id;
    val.valueInfo  = makeValueInfoFlags( t );

    switch((ValueInfoFlags)((uint32_t)val.valueInfo & (uint32_t)ValueInfoFlags::data_type_mask))
    {
        case ValueInfoFlags::data_u8    : val. u8 = (uint8_t )t; break;
        case ValueInfoFlags::data_u16   : val.u16 = (uint16_t)t; break;
        case ValueInfoFlags::data_u32   : val.u32 = (uint32_t)t; break;
        case ValueInfoFlags::data_u64   : val.u64 = (uint64_t)t; break;

        case ValueInfoFlags::data_s8    : val. s8 =  (int8_t )t; break;
        case ValueInfoFlags::data_s16   : val.s16 =  (int16_t)t; break;
        case ValueInfoFlags::data_s32   : val.s32 =  (int32_t)t; break;
        case ValueInfoFlags::data_s64   : val.s64 =  (int64_t)t; break;

        case ValueInfoFlags::data_float : val.f32 =  (float)  t; break;
        case ValueInfoFlags::data_double: val.f64 =  (double) t; break;

        default : val.u64 = (uint64_t)t;
    };

    return val;
}

inline
const char* getValueInfoName( ValueInfoFlags valueInfo )
{
    switch((ValueInfoFlags)((uint32_t)valueInfo & (uint32_t)ValueInfoFlags::data_type_mask))
    {
        case ValueInfoFlags::data_u8    : return "u8";
        case ValueInfoFlags::data_u16   : return "u16";
        case ValueInfoFlags::data_u32   : return "u32";
        case ValueInfoFlags::data_u64   : return "u64";

        case ValueInfoFlags::data_s8    : return "s8";
        case ValueInfoFlags::data_s16   : return "s16";
        case ValueInfoFlags::data_s32   : return "s32";
        case ValueInfoFlags::data_s64   : return "s64";

        case ValueInfoFlags::data_float : return "f32";
        case ValueInfoFlags::data_double: return "f64";

        default : return "UNK";
    };
}

template<typename T>
bool extractFromMessageValue( const MessageValue &val, T &t, ValueInfoFlags *pInfoFlags = 0 )
{
    ValueInfoFlags localFlags       = makeValueInfoFlags(t);
    ValueInfoFlags localDataType    = (ValueInfoFlags)((uint32_t)localFlags    & (uint32_t)ValueInfoFlags::data_type_mask);
    ValueInfoFlags receivedDataType = (ValueInfoFlags)((uint32_t)val.valueInfo & (uint32_t)ValueInfoFlags::data_type_mask);

    if (pInfoFlags)
    {
        *pInfoFlags = receivedDataType; // val.valueInfo;
    }

    /*
    if ( localDataType != receivedDataType )
    {
        #if defined(UMBA_RTKOS_LOG)
        using namespace umba::omanip;
        UMBA_RTKOS_LOG<<error<<"Error: MessageValue: expected '"<<getValueInfoTypeName(localDataType)<<"', but fond '"<<getValueInfoTypeName(receivedDataType)<<"'"<<endl;

        getValueInfoTypeName(ValueInfoFlags v)
        #endif
        
        return false;
    }
    */

    switch( receivedDataType )
    {
        case ValueInfoFlags::data_u8    : t = (T)val. u8; break;
        case ValueInfoFlags::data_u16   : t = (T)val.u16; break;
        case ValueInfoFlags::data_u32   : t = (T)val.u32; break;
        case ValueInfoFlags::data_u64   : t = (T)val.u64; break;
                                             
        case ValueInfoFlags::data_s8    : t = (T)val. s8; break;
        case ValueInfoFlags::data_s16   : t = (T)val.s16; break;
        case ValueInfoFlags::data_s32   : t = (T)val.s32; break;
        case ValueInfoFlags::data_s64   : t = (T)val.s64; break;
                                             
        case ValueInfoFlags::data_float : t = (T)val.f32; break;
        case ValueInfoFlags::data_double: t = (T)val.f64; break;

        default : t = (T)val.u64;
    };

    if ( localDataType != receivedDataType )
    {
        #if defined(UMBA_RTKOS_LOG)
        UMBA_RTKOS_OS->handleDriverValueConvertFailed( localDataType, receivedDataType );
        #endif
        return false;
    }
    //handleDriverValueConvertFailed( umba::drivers::ValueInfoFlags expected, umba::drivers::ValueInfoFlags got ) override

    return true;

}




// Generic Messages
struct MessageDriverRawData
{
    DeviceBusAddress   deviceBusAddress; // Для 
    uint16_t           dataSize;
    uint8_t            data[16];
};





struct MessageDriver
{
    MessageDriverHeader header;

    union
    {
        uint8_t                   linkStatus; // driver_notify_carrier / driver_notify_datalink - 0/1
        MessageValue              value;
        MessageDriverRawData      rawData;
    };
};



inline
bool isMessageFromDriver( const MessageDriver &msg )
{
    return isMessageFromDriver(msg.header);
}

inline
void initMessageDriver( MessageDriver &msg, ClassId classId, DriverId driverId, MessageId msgId, IDriver *pDriver = 0)
{
    msg.header.pDriver         = pDriver;
    msg.header.classId         = classId;
    msg.header.driverId        = driverId;
    msg.header.driverMessageId = msgId;
}

inline
void initMessageDriver( MessageDriver &msg, DriverAddress addr, MessageId msgId, IDriver *pDriver = 0)
{
    initMessageDriver( msg, addr.classId, addr.driverId, msgId, pDriver );
}

inline
void initMessageDriverDriverRawDataRequest( MessageDriver &msg, ClassId classId, DriverId driverId, size_t requestedBytes = 0, DeviceBusAddress busAddr = invalid_device_bus_address )
{
    //msg.header.pDriver             = 0;
    //msg.header.classId             = classId;
    //msg.header.driverId            = driverId;
    //msg.header.driverMessageId     = MessageId::driver_raw_data_request;
    initMessageDriver( msg, classId, driverId, MessageId::driver_raw_data_request, 0 );
    msg.rawData.deviceBusAddress   = busAddr;
    msg.rawData.dataSize           = requestedBytes;
}

inline
void initMessageDriverDriverRawDataRequest( MessageDriver &msg, DriverAddress peerAddr, size_t requestedBytes = 0, DeviceBusAddress busAddr = invalid_device_bus_address )
{
    initMessageDriverDriverRawDataRequest( msg, peerAddr.classId, peerAddr.driverId, requestedBytes, busAddr );
}

inline
void initMessageDriverValueRequest( MessageDriver &msg, ClassId classId, DriverId driverId, ValueId valueId )
{
    initMessageDriver( msg, classId, driverId, MessageId::device_param_request, 0 );
    msg.value.id = valueId;
}

inline
void initMessageDriverValueRequest( MessageDriver &msg, DriverAddress peerAddr, ValueId valueId )
{
    initMessageDriverValueRequest( msg, peerAddr.classId, peerAddr.driverId, valueId );
}



// driver_param_response
// driver_param_set
// driver_param_notify

// device_param_response
// device_param_set
// device_param_notify

template<typename ValueType>
inline
void initMessageDriverValue( MessageDriver &msg, ClassId classId, DriverId driverId, MessageId msgId, ValueId valueId, ValueType value, IDriver *pDriver = 0)
{
    initMessageDriver( msg, classId, driverId, msgId, pDriver );
    msg.value = makeMessageValue( valueId, value );
    // .id        = valueId;
    //msg.value.valueInfo = 
}

template<typename ValueType>
inline
void initMessageDriverValue( MessageDriver &msg, DriverAddress peerAddr /* or self, if pDriver is non-zero */, MessageId msgId, ValueId valueId, ValueType value, IDriver *pDriver = 0 )
{
    initMessageDriverValue( msg, peerAddr.classId, peerAddr.driverId, msgId, valueId, value, pDriver );
}



/*
            MessageDriver msgRes;
            initMessageDriverValue( msgRes, class_id_value, m_driverSelfId, MessageId::device_param_response, value_id_sensor_value, sensorValue, static_cast<IDriver*>(this) );
            umba::rtkos::messagePost( msgRes );
*/



// На будущее, когда у нас будет пул памяти, то память будем выделять динамически, и доступ к сырым данным изменится
// Поэтому заранее напишем хелперов, через которых будем осуществлять доступ к сырым данным сообщения
inline
bool setMessageDriverRawData( MessageDriver &msg, uint8_t *pData, size_t dataSize, DeviceBusAddress busAddr = invalid_device_bus_address )
{
    msg.rawData.deviceBusAddress = busAddr;
    msg.rawData.dataSize         = std::min( dataSize, sizeof(msg.rawData.data) );

    memcpy( &msg.rawData.data[0], pData, msg.rawData.dataSize );
    
    return msg.rawData.dataSize == dataSize; // all data was sent
}

inline
const uint8_t * getMessageDriverRawData( const MessageDriver &msg )
{
    return &msg.rawData.data[0];
}

inline
void freeMessageDriverRawData( MessageDriver &msg )
{
    if (msg.header.driverMessageId != MessageId::driver_raw_data)
    {
        return;
    }

    // free data here
}

inline
bool isMessageDriverMine( const MessageDriver &msg, ClassId myClassId, DriverId driverId )
{
    return msg.header.classId==myClassId && msg.header.driverId==driverId;
}

inline
bool isMessageDriverMine( const MessageDriver &msg, DriverAddress myAddr )
{
    return isMessageDriverMine( msg, myAddr.classId, myAddr.driverId );
}

inline
bool isMessageDriverMessageId( const MessageDriver &msg, MessageId id )
{
    return msg.header.driverMessageId==id;
}


inline
bool isClientMessageDriverValue( const MessageDriver &msg )
{
    const bool isResponse = msg.header.driverMessageId == MessageId::driver_param_response;
    const bool isNotify   = msg.header.driverMessageId == MessageId::driver_param_notify;
    return isResponse || isNotify;
}

inline
bool isClientMessageDriverValue( const MessageDriver &msg, ValueId id )
{
    if (!isClientMessageDriverValue(msg))
        return false;
    return msg.value.id == id;
}

inline
bool isClientMessageDeviceValue( const MessageDriver &msg )
{
    return msg.header.driverMessageId == MessageId::device_param_response || msg.header.driverMessageId == MessageId::device_param_notify;
}

inline
bool isClientMessageDeviceValue( const MessageDriver &msg, ValueId id )
{
    if (!isClientMessageDeviceValue(msg))
        return false;
    return msg.value.id == id;
}





} // namespace drivers
} // namespace umba

