#pragma once

#include "basic_types.h"



namespace umba
{
namespace drivers
{

inline
void dumpMessageDriverHeader( const MessageDriverHeader &hdr )
{
    using namespace umba::omanip;
    UMBA_RTKOS_LOG<<"Timestamp: "<<umba::time_service::getCurTimeMs()<<"\n";
    UMBA_RTKOS_LOG<<"Header:\n";
    if (!hdr.pDriver)
        UMBA_RTKOS_LOG<<"  Destination is a driver\n";
    else
        UMBA_RTKOS_LOG<<"  Destination is a client, msg from driver: "<<groupsize(8)<<hex<<(uintptr_t)hdr.pDriver<<"\n";
    UMBA_RTKOS_LOG<<"  Dst class ID  : "<<groupsize(8)<<hex<<(uintptr_t)hdr.classId<<"\n";
    UMBA_RTKOS_LOG<<"  Dst driver ID : "<<hdr.driverId<<"\n";
    UMBA_RTKOS_LOG<<"  Driver Msg ID : ";
    switch(hdr.driverMessageId)
    {
        case MessageId::driver_param_request_list:  UMBA_RTKOS_LOG<<"driver_param_request_list" ; break;
        case MessageId::driver_param_request     :  UMBA_RTKOS_LOG<<"driver_param_request"      ; break;
        case MessageId::driver_param_response    :  UMBA_RTKOS_LOG<<"driver_param_response"     ; break;
        case MessageId::driver_param_set         :  UMBA_RTKOS_LOG<<"driver_param_set"          ; break;
        case MessageId::driver_param_set_ack     :  UMBA_RTKOS_LOG<<"driver_param_set_ack"      ; break;
        case MessageId::driver_param_set_err     :  UMBA_RTKOS_LOG<<"driver_param_set_err"      ; break;
        case MessageId::driver_param_notify      :  UMBA_RTKOS_LOG<<"driver_param_notify"       ; break;

        case MessageId::device_param_request_list:  UMBA_RTKOS_LOG<<"device_param_request_list" ; break;
        case MessageId::device_param_request     :  UMBA_RTKOS_LOG<<"device_param_request"      ; break;
        case MessageId::device_param_response    :  UMBA_RTKOS_LOG<<"device_param_response"     ; break;
        case MessageId::device_param_set         :  UMBA_RTKOS_LOG<<"device_param_set"          ; break;
        case MessageId::device_param_set_ack     :  UMBA_RTKOS_LOG<<"device_param_set_ack"      ; break;
        case MessageId::device_param_set_err     :  UMBA_RTKOS_LOG<<"device_param_set_err"      ; break;
        case MessageId::device_param_notify      :  UMBA_RTKOS_LOG<<"device_param_notify"       ; break;
        case MessageId::device_param_mask        :  UMBA_RTKOS_LOG<<"device_param_mask"         ; break;

        case MessageId::driver_raw_data          :  UMBA_RTKOS_LOG<<"driver_raw_data"           ; break;
        case MessageId::driver_raw_data_request  :  UMBA_RTKOS_LOG<<"driver_raw_data_request"   ; break;

        case MessageId::driver_notify_carrier    :  UMBA_RTKOS_LOG<<"driver_notify_carrier"     ; break;
        case MessageId::driver_notify_datalink   :  UMBA_RTKOS_LOG<<"driver_notify_datalink"    ; break;
        //case MessageId:::  UMBA_RTKOS_LOG<<"" ; break;
    };

    UMBA_RTKOS_LOG<<"\n";
}




const uint8_t * getMessageDriverRawData( const MessageDriver &msg );

inline
void dumpMessageDriver( const MessageDriver &msg, IDriver *pDriver )
{
    using namespace umba::omanip;

    dumpMessageDriverHeader( msg.header );
    umba::ihc::IOctetOStreamImplBuf<48> strTo;

    UMBA_RTKOS_LOG<<"Data:\n";

    switch(msg.header.driverMessageId)
    {

        case MessageId::driver_param_request:
             {
                 UMBA_RTKOS_LOG<<"  Requested driver param: "<<msg.value.id;//<<"";
                 if (pDriver)
                 {
                     pDriver->getDriverParamName( DriverAddress(msg.header.classId, msg.header.driverId), msg.value.id, &strTo );
                     UMBA_RTKOS_LOG<<strTo.c_str();
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;

        case MessageId::device_param_request:
             {
                 UMBA_RTKOS_LOG<<"  Requested device param: "<<msg.value.id<<"\n";
                 if (pDriver)
                 {
                     pDriver->getDeviceParamName( DriverAddress(msg.header.classId, msg.header.driverId), msg.value.id, &strTo );
                     UMBA_RTKOS_LOG<<strTo.c_str();
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;

        case MessageId::driver_param_response:
             {
                 UMBA_RTKOS_LOG<<"  Responsed driver param: "<<msg.value.id;//<<"";
                 if (pDriver)
                 {
                     pDriver->getDriverParamName( DriverAddress(msg.header.classId, msg.header.driverId), msg.value.id, &strTo );
                     UMBA_RTKOS_LOG<<strTo.c_str();
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;

        case MessageId::device_param_response:
             {
                 UMBA_RTKOS_LOG<<"  Responsed device param: "<<msg.value.id<<"\n";
                 if (pDriver)
                 {
                     pDriver->getDeviceParamName( DriverAddress(msg.header.classId, msg.header.driverId), msg.value.id, &strTo );
                     UMBA_RTKOS_LOG<<strTo.c_str();
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;

        case MessageId::driver_param_set:
             {
                 UMBA_RTKOS_LOG<<"  Setting driver param: "<<msg.value.id<<"\n";
                 if (pDriver)
                 {
                     pDriver->getDriverParamName( DriverAddress(msg.header.classId, msg.header.driverId), msg.value.id, &strTo );
                     UMBA_RTKOS_LOG<<strTo.c_str();
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;

        case MessageId::device_param_set:
             {
                 UMBA_RTKOS_LOG<<"  Setting device param: "<<msg.value.id<<"\n";
                 if (pDriver)
                 {
                     pDriver->getDeviceParamName( DriverAddress(msg.header.classId, msg.header.driverId), msg.value.id, &strTo );
                     UMBA_RTKOS_LOG<<strTo.c_str();
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;

        case MessageId::driver_param_notify:
             {
                 UMBA_RTKOS_LOG<<"  Notification about driver param: "<<msg.value.id<<"\n";
                 if (pDriver)
                 {
                     pDriver->getDriverParamName( DriverAddress(msg.header.classId, msg.header.driverId), msg.value.id, &strTo );
                     UMBA_RTKOS_LOG<<strTo.c_str();
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;

        case MessageId::device_param_notify:
             {
                 UMBA_RTKOS_LOG<<"  Notification about device param: "<<msg.value.id<<"\n";
                 if (pDriver)
                 {
                     pDriver->getDeviceParamName( DriverAddress(msg.header.classId, msg.header.driverId), msg.value.id, &strTo );
                     UMBA_RTKOS_LOG<<strTo.c_str();
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;

        case MessageId::driver_raw_data:
             {
                 //UMBA_RTKOS_LOG<<"  \n";
                 UMBA_RTKOS_LOG<<"  Device bus address: "<<hex<<msg.rawData.deviceBusAddress<<"\n";
                 UMBA_RTKOS_LOG<<"  Raw data["<<msg.rawData.dataSize<<"]:";
                 const uint8_t * pData = getMessageDriverRawData( msg );
                 for(uint16_t i=0; i!=msg.rawData.dataSize; ++i)
                 {
                     UMBA_RTKOS_LOG<<" "<<hex<<pData[i];
                 }
                 UMBA_RTKOS_LOG<<"\n";
             }
             break;
        case MessageId::driver_raw_data_request:
             {
                 UMBA_RTKOS_LOG<<"  Device bus address: "<<hex<<msg.rawData.deviceBusAddress<<"\n";
                 UMBA_RTKOS_LOG<<"  Requested "<<msg.rawData.dataSize<<" bytes of raw data\n";
             }
             break;

        case MessageId::driver_notify_carrier:
             {
                  UMBA_RTKOS_LOG<<"  Carrier status: ";
                  if (msg.linkStatus)
                     UMBA_RTKOS_LOG<<good<<"Connected"<<normal;
                  else
                     UMBA_RTKOS_LOG<<notice<<"No link"<<normal;
             }
             break;

        case MessageId::driver_notify_datalink:
             {
                  UMBA_RTKOS_LOG<<"  Datalink status: ";
                  if (msg.linkStatus)
                     UMBA_RTKOS_LOG<<good<<"Connected"<<normal;
                  else
                     UMBA_RTKOS_LOG<<notice<<"No link"<<normal;
             }
             break;

        default:
             UMBA_RTKOS_LOG<<notice<<"  No details"<<normal;

    }
    UMBA_RTKOS_LOG<<endl;

}



} // namespace drivers
} // namespace umba

