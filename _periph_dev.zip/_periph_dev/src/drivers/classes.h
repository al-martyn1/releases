#pragma once

#include "umba/interface.h"
#include "umba/basic_interfaces.h"
#include "ihc/i_octet_stream.h"


// umba::drivers

namespace umba
{
namespace drivers
{


typedef   uint32_t  ClassId;
//constexpr ClassId   class_id_any = (ClassId)-1;

/*
enum class ClassId : uint32_t
{
    class_id_unknown    = 0,
    device_state_monitor = 0x5006B934u

};


constexpr ClassId class_id_unknown = ClassId::class_id_unknown;
*/

#define UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_CONST_VALUE( type, id, value, descr )    constexpr type id = value##u
#define UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_CONST_NAME( type, id, value, descr )     case value##u: return descr


#define UMBA_DRIVER_DECLARE_CLASS_CODE( id, value, descr )    UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_CONST_VALUE( ClassId, id, value, descr )
#include "x_classes.h"
#undef UMBA_DRIVER_DECLARE_CLASS_CODE

#define UMBA_DRIVER_DECLARE_CLASS_CODE( id, value, descr )    UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_CONST_NAME( ClassId, id, value, descr )
inline
const char* getClassName( ClassId id )
{
    switch(id)
    {
        #include "x_classes.h"

        default: return "<UNKNOWN>";
    }
}


#undef UMBA_DRIVER_DECLARE_CLASS_CODE




typedef uint32_t  SubclassId;

constexpr  SubclassId subclass_id_default   = (SubclassId)0;
//constexpr  SubclassId subclass_id_hardware  = (SubclassId)0;
//constexpr  SubclassId subclass_id_software  = (SubclassId)1;
constexpr  SubclassId subclass_id_any       = (SubclassId)-1;


} // namespace drivers
} // namespace umba

#include "motors/subclasses.h"
#include "sensors/subclasses.h"




//umba::ihc::IOctetIStream *pStream







// #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
// #include "x_classes.h"
// #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

// #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
// UMBA_DRIVER_DECLARE_DRIVER_PARAM_NAMES_BEGIN()
// #include "x_classes.h"
// UMBA_DRIVER_DECLARE_DRIVER_PARAM_NAMES_END()
// #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

// #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
// UMBA_DRIVER_DECLARE_DRIVER_PARAM_DESCRIPTIONS_BEGIN()
// #include "x_classes.h"
// UMBA_DRIVER_DECLARE_DRIVER_PARAM_DESCRIPTIONS_END()
// #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE



/*
inline
const char* getClassName( ClassId id )
{
    switch(id)
    {
        #include "x_classes.h"

        default: return "<UNKNOWN>";
    }
}




// #define UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_CONST_VALUE( type, id, value, descr )    constexpr type id = value##u
// #define UMBA_DRIVER_DECLARE_DECLARE_DESCRIPTED_CONST_NAME( type, id, value, descr )     case value##u: return descr
case ParamValue: return ParamName

case ParamValue: return ParamDescription


    virtual
    void getDriverParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    virtual
    void getDriverParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //---------

    virtual
    void getDeviceParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    virtual
    void getDeviceParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

*/



