#pragma once

#include "drivers/periph/dac_driver_impl.h"


#define IMBA_DRIVERS_CLIENT_IMPL_BEGIN( ClientClassName )                    \
                                                                             \
           class ClientClassName                                             \
           {                                                                 \
                                                                             \
           public:                                                           \
                                                                             \
               ClientClassName()                   = default;                \
               ClientClassName(const ClientClassName &)  = default;          \
               ClientClassName(ClientClassName &&)       = default;          \
               ClientClassName& operator=( ClientClassName &dc ) = default;  \
                                                                             \
               ClientClassName( const umba::drivers::DriverAddress &addr )   \
               : m_driverAddr(addr)                                          \
               {}                                                            \
                                                                             \
               void operator=( const umba::drivers::DriverAddress &addr )    \
               {                                                             \
                   m_driverAddr = addr;                                      \
               }                                                             \
                                                                             \
               umba::drivers::DriverAddress getAssignedAddress() const       \
               {                                                             \
                   return m_driverAddr;                                      \
               }                                                             \
                                                                             \
               /* Helpers to handle vals from diver */                       \
                                                                             \
               bool isMessageMine( const umba::drivers::MessageDriver &msg ) const \
               {                                                                   \
                   return umba::drivers::isMessageDriverMine( msg, m_driverAddr ); \
               }                                                                   \
                                                                                   \
               bool isMessageDeviceValue( const umba::drivers::MessageDriver &msg, umba::drivers::ValueId id ) \
               {                                                                                               \
                   if (!(msg.header.driverMessageId == umba::drivers::MessageId::device_param_response || msg.header.driverMessageId == umba::drivers::MessageId::device_param_notify)) \
                       return false;                                                                           \
                   return msg.value.id == id;                                                                  \
               }                                                                                               \
                                                                                                               \
               bool isMessageDriverValue( const umba::drivers::MessageDriver &msg, umba::drivers::ValueId id ) \
               {                                                                                               \
                   if (!(msg.header.driverMessageId == umba::drivers::MessageId::driver_param_response || msg.header.driverMessageId == umba::drivers::MessageId::driver_param_notify)) \
                       return false;                                                                           \
                   return msg.value.id == id;                                                                  \
               }                                                                                               \
                                                                             \
           protected:                                                        \
                                                                             \
                umba::drivers::DriverAddress   m_driverAddr  = umba::drivers::invalid_driver_address; \
                                                                             \
           public:


#define IMBA_DRIVERS_CLIENT_IMPL_END( ClientClassName ) \
           }; /* class ClientClassName */

