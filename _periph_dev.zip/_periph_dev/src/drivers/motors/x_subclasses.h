UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_id_motor_dc        ,  0x87D77A1B, "DC Motor" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( subclass_id_esc_pwm         ,  0x6C9E10FF, "ESC Motor" );

