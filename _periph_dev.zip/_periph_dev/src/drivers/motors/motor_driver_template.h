#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"




namespace umba
{
namespace drivers
{
namespace motors
{

/*
ValueId esc_pwm_freq                 = 100; // uint32 Hz
ValueId esc_pwm_duration_off         = 800;
ValueId esc_pwm_duration_duty        = 1100; // 
ValueId esc_pwm_duration_max         = 1700;
ValueId esc_pwm_command              = 0;
*/

/*
ValueId value_id_esc_pwm_freq                 = 0;
ValueId value_id_esc_pwm_duration_off         = 1;
ValueId value_id_esc_pwm_duration_duty        = 2;
ValueId value_id_esc_pwm_duration_max         = 3;
ValueId value_id_esc_pwm_command              = 4; // off, on/hh, on
ValueId value_id_esc_pwm_duration_target      = 5; // целевая скорость
*/

#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_esc_device_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE



class EscDriver : public DriverImplBase< class_id_motor, subclass_motor_esc_pwm_id, PowerConsumptionClass::medium >
{

    
public:

    UMBA_DRIVER_DESCRIPTION( "ESC PWM Brushless motor" )

    EscDriver( unsigned i )
    {
    }

    EscDriver(  )
    {

        // TimerId timerSet ( Object *pObj, TimerEventId eventId, TimeTick period )
    }

    EscDriver( EscDriver && ) = default;

    void install()
    {
        #ifdef RTKOS_RTKOS_H
        //DriverId 
        umba::rtkos::driverInstall( DriverAddress(class_id_value), subclass_id_value, this );
        umba::rtkos::messageFilterAdd( this );
        //umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::normal );
        #endif
        // TimerId timerSet ( Object *pObj, TimerEventId eventId, TimeTick period )
    }



    //UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_motor )
    //UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_motor, subclass_motor_esc_pwm_id )
    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_esc_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_esc_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);
        //umba::ihc::IhcOctetStreamCharWriter writter(pStreamTo);
        //umba::SimpleFormatter oss( &writter );

        oss<<"Soft I2C";
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        return umba::errors::ok;
    }

    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        return false;
    }




protected:

    umba::periph::GpioPinAddr  m_pwmPinAddr;
    umba::periph::GpioPin      m_pwmPin; 

    TIM_TypeDef               *TIMx       = 0;
//          m_pwmPin; 


};


} // namespace motors
} // namespace drivers
} // namespace umba

