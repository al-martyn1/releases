#pragma once

#include "../driver_impl_base.h"
#include "subclasses.h"

#include "periph/gpio.h"
#include "periph/stm32_traits.h"

#include "ihc/octet_stream_buf.h"
#include "umba/i_char_writer.h"
#include "umba/simple_formatter.h"

#include "scalcus/pwm.h"

#include "periph/periph.h"




namespace umba
{
namespace drivers
{
namespace motors
{

/*
ValueId esc_pwm_freq                 = 100; // uint32 Hz
ValueId esc_pwm_duration_off         = 800;
ValueId esc_pwm_duration_duty        = 1100; // 
ValueId esc_pwm_duration_max         = 1700;
ValueId esc_pwm_command              = 0;
*/

/*
ValueId value_id_esc_pwm_freq                 = 0;
ValueId value_id_esc_pwm_duration_off         = 1;
ValueId value_id_esc_pwm_duration_duty        = 2;
ValueId value_id_esc_pwm_duration_max         = 3;
ValueId value_id_esc_pwm_command              = 4; // off, on/hh, on
ValueId value_id_esc_pwm_duration_target      = 5; // целевая скорость
*/

#define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE( id, value, descr )
#include "x_esc_device_params.h"
#undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE



class EscDriver : public DriverImplBase< class_id_esc, subclass_id_esc_pwm, PowerConsumptionClass::medium >
{

    typedef DriverImplBase< class_id_esc, subclass_id_esc_pwm, PowerConsumptionClass::medium > BaseImpl;
public:

    UMBA_DRIVER_DESCRIPTION( "ESC PWM Brushless motor" )

    EscDriver( DriverAddress timPwmAddr )
    : BaseImpl()
    , m_timPwmAddr(timPwmAddr)
    {
    }

    EscDriver( EscDriver && ) = default;

    bool install(DriverId driverId = driver_id_auto)
    {
        #ifdef RTKOS_RTKOS_H
        //DriverId 
        if (!umba::rtkos::driverInstall( DriverAddress(class_id_value, driverId), subclass_id_value, this ))
            return false;
        return umba::rtkos::messageFilterAdd( this );
        //umba::rtkos::pollScheduleAdd ( this, umba::rtkos::PollPriority::normal );
        #endif
        // TimerId timerSet ( Object *pObj, TimerEventId eventId, TimeTick period )
    }



    //UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_esc )
    //UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_esc, subclass_motor_esc_pwm_id )
    UMBA_DRIVER_IMPLEMENT_GET_SUBCLASS_NAME( class_id_value )
    UMBA_DRIVER_IMPLEMENT_GET_CLASS_SUBCLASS( class_id_value, subclass_id_value )

    UMBA_DRIVER_DECLARE_DRIVER_PARAM_NO_PARAMS()

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_NAME(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_BEGIN()
    #include "x_esc_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_NAMES_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    #define UMBA_DRIVER_DECLARE_VALUE_ID_CODE( id, value, descr )  UMBA_DRIVER_DECLARE_DESCRIPTED_PARAM_CONST_VALUE_DESCRIPTION(id, value, descr)
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_BEGIN()
    #include "x_esc_device_params.h"
    UMBA_DRIVER_DECLARE_DEVICE_PARAM_DESCRIPTIONS_END()
    #undef UMBA_DRIVER_DECLARE_VALUE_ID_CODE

    UMBA_DRIVER_IMPLEMENT_MESSAGE_FILTER_ON_FILTER_MESSAGE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_POLL_CAPABLE_DEFAULT()
    UMBA_DRIVER_IMPLEMENT_DRIVER_CLIENT_HANDLER_DEFAULT()

    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) override
    {
        if (!pStreamTo)
            return false;
        UMBA_ASSERT(pStreamTo);

        using namespace umba::omanip;

        auto& oss = UMBA_RTKOS_OS->getUnsafeStream(pStreamTo);

        oss<<"ESC on ";

        umba::drivers::IDriver* pDriver = UMBA_RTKOS_OS->driverGet( m_timPwmAddr );
        if (pDriver)
        {
            pDriver->getDriverDescription( m_timPwmAddr, pStreamTo );
            pStreamTo->write( ": ", 2 );
            return pDriver->getDriverConfigInfo( m_timPwmAddr, pStreamTo );
        }
        else
        {
            writeInvalidConfigString( pStreamTo );
            return false;
        }
        return true;
    }

    virtual
    void onTimer( unsigned eventId ) override
    {
    }

    //void initTimer()


    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) override
    {
        using namespace umba::periph::traits;

        return umba::errors::ok;
    }

    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) override
    {
        umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_freq, m_pwmFreq );
        uint8_t  dutyMode = 1; // usec
        umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_duty_mode, dutyMode );

        setSlaveDuty();

        //uint8_t  pwmCtrl  = 1; // on
        //umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_ctrl, pwmCtrl );

        forcePwmCtrl(1);

        return umba::errors::ok;
    }

    void forcePwmCtrl( uint8_t ctrl )
    {
        umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_ctrl, ctrl );
    }

    void setSlaveDuty()
    {
        if (!m_escMode)
        {
            umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_duty, m_pwmOffPulse );
        }
        else if (m_escMode>1)
        {
            umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_duty, m_pwmPulse );
        }
        else
        {
            umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_duty, m_pwmIdlePulse );
        }

        if (m_driverSoftwareStarted)
        {
            //uint8_t  pwmCtrl  = 1; // on
            //umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_ctrl, pwmCtrl );
            //forcePwmCtrl(pwmCtrl);
        }

    }
    virtual
    bool onMessageDriver(const MessageDriver &msg)
    {
        if (!isMessageDriverMine( msg, class_id_value, m_driverSelfId ))
            return dumpMsg(msg);

        if (!isMessageDriverMessageId( msg, MessageId::device_param_set ))
            return dumpMsg(msg);

        switch(msg.value.id)
        {
            case value_id_esc_pwm_freq:
                 {
                     uint32_t putTo = 0;
                     if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");
                     m_pwmFreq = putTo;

                     umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_freq, m_pwmFreq );
                     uint8_t  dutyMode = 1; // usec
                     umba::drivers::postMessageDriverValue( m_timPwmAddr, umba::drivers::MessageId::device_param_set, umba::drivers::periph::value_id_tim_pwm_duty_mode, dutyMode );

                     setSlaveDuty();


                 }
                 break;

            case value_id_esc_pwm_duty_pulse_off:
                 {
                     uint32_t putTo = 0;
                     if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");
                     m_pwmOffPulse = putTo;
                     //if (m_pwmOffPulse<500)
                     //    m_pwmOffPulse = 500;
                     setSlaveDuty();
                 }
                 break;

            case value_id_esc_pwm_duty_pulse_idliing:
                 {
                     uint32_t putTo = 0;
                     if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");
                     m_pwmIdlePulse = putTo;
                     //if (m_pwmIdlePulse>m_pwmMaxPulse/2)
                     //    m_pwmIdlePulse = m_pwmMaxPulse/2;
                     //if (m_pwmIdlePulse<m_pwmOffPulse)
                     //    m_pwmIdlePulse = m_pwmOffPulse;
                     setSlaveDuty();
                 }
                 break;

            case value_id_esc_pwm_duty_pulse_max:
                 {
                     uint32_t putTo = 0;
                     if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");
                     m_pwmMaxPulse = putTo;
                     //if (m_pwmMaxPulse>2300)
                     //    m_pwmMaxPulse = 2300;
                     //if (m_pwmMaxPulse<1200)
                     //    m_pwmMaxPulse = 1200;
                     setSlaveDuty();
                 }
                 break;

            case value_id_esc_pwm_duty_pulse:
                 {
                     uint32_t putTo = 0;
                     if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");
                     m_pwmPulse = putTo;
                     if (m_pwmPulse<m_pwmOffPulse)
                         m_pwmPulse = m_pwmOffPulse;
                     if (m_pwmPulse>m_pwmMaxPulse)
                         m_pwmPulse = m_pwmMaxPulse;
                     setSlaveDuty();
                 }
                 break;

            case value_id_esc_pwm_command:
                 {
                     uint8_t putTo = 0;
                     if (!umba::drivers::extractFromMessageValue( msg.value, putTo /* ValueInfoFlags *pInfoFlags */ ))
                        return dumpMsg(msg, "Error in format");
                     m_escMode = putTo;
                     setSlaveDuty();
                 }
                 break;

            default: return dumpMsg(msg);
        }
        return true;
    }




protected:

    DriverAddress              m_timPwmAddr;

    uint32_t                   m_pwmFreq       = 1000;
    uint32_t                   m_pwmOffPulse   =  800;
    uint32_t                   m_pwmIdlePulse  = 1200;
    uint32_t                   m_pwmMaxPulse   = 2300;
    uint32_t                   m_pwmPulse      =  800; // current value
    uint8_t                    m_escMode       =    0; // off, idle, on - 0/1/2

/*

UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_freq               , 0, "PWM Freq, Hz" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duty_pulse_off     , 1, "Duty pulse when OFF, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duty_pulse_idliing , 2, "Duty pulse when IDLING, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duty_pulse_max     , 3, "Duty pulse MAX, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duty_pulse         , 4, "Duty pulse when ON" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_command            , 4, "0 - OFF, 1 - ON/IDLING, 2 - ON" );

*/




//          m_pwmPin; 


};


} // namespace motors
} // namespace drivers
} // namespace umba

