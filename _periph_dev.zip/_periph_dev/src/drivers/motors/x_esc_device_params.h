UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_freq               , 0, "PWM Freq, Hz" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duty_pulse_off     , 1, "Duty pulse when OFF, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duty_pulse_idliing , 2, "Duty pulse when IDLING, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duty_pulse_max     , 3, "Duty pulse MAX, ms" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_duty_pulse         , 4, "Duty pulse when ON" );
UMBA_DRIVER_DECLARE_VALUE_ID_CODE( value_id_esc_pwm_command            , 5, "0 - OFF, 1 - ON/IDLING, 2 - ON" );
//UMBA_DRIVER_DECLARE_VALUE_ID_CODE( , , "" )
