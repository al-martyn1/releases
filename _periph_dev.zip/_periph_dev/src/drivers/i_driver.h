#pragma once

#include "umba/interface.h"
#include "umba/basic_interfaces.h"
#include "ihc/i_octet_stream.h"

#include "basic_types.h"
#include "rtkos/messages.h"

#include "umba/time_service.h"


// umba::drivers


// Реализация драйвера по умолчанию наследует базовые интерфейсы в защищенном режиме,
// чтобы пользователь случайно не вызвал то, что должно вызываться операционной системой.
// Если операционная система не используется, но хочется использовать готовые драйвера, 
// то некоторые методы нужно дергать ручками, и они должны быть доступны.
// В этом случае для всего проекта дефайним макро UMBA_DRIVERS_IMPL_USE_PUBLIC_INHERITANS

#ifdef UMBA_DRIVERS_USE_PUBLIC_INHERITANS
    #define UMBA_DRIVERS_INHERITANS  public
#else
    #define UMBA_DRIVERS_INHERITANS  protected
#endif



namespace umba
{
namespace drivers
{



interface IDriverPrivate : inherits umba::IUnknown
{

    UMBA_DECLARE_INTERFACE_ID(0xE512B6F1);

    //! Получить класс драйвера
    /*! А если у нас мультидрайвер?
        Тогда при инсталляции драйвера в ОС класс должен явно задаваться,
        и, если не задан явно, то это фатальная ошибка.

        Все ипостаси мультидрайвера могут иметь одинаковый ИД, если они разного класса.

        Мультидрайвер - это когда, например, неколько различных логических устройств 
        объединены в одно физическое, или когда несколько физических устройств 
        висят на одной шине SPI/I2C etc.

        Мультидрайвер может быть составлен из нескольких обычных драйверов.
        В этом случае он сам должен диспечирезировать все запросы в нужные вложенные драйвера.
     */
    virtual
    ClassId getDriverClass() = 0;

    //! Возвращает подкласс драйвера
    /*! Подкласс драйвера служит в основном только информационной цели, и используется
        только для сужения критериев поиска.

        Метод не вызывается при добавлении мультидрайвера
     */ 
    virtual
    SubclassId getDriverSubclass() = 0;

    //! Вызывается, если при добавлении драйвера идентификатор был автоматически назначен
    /*! Для мультидрайвера вызывается столько раз, сколько раз он был добавлен
     */
    virtual
    void setDriverId( ClassId classId, SubclassId subclassId, DriverId driverId ) = 0;


    //! Сюда доходят только адресованные конкретному драйверу сообщения
    /*! При диспечеризации эта часть извлекается из системного сообщения, просто для того, чтобы в драйвере
        меньше шевелить телом.
     */
    virtual
    bool onMessageDriver(const MessageDriver &msg) = 0;

    //! Для мультидрайвера будет вызван несколько раз 
    virtual
    umba::Error driverHardwareInit(const DriverAddress &driverAddress) = 0;

    virtual
    void driverHardwareSetStarted(const DriverAddress &driverAddress) = 0;

    //! Для мультидрайвера будет вызван несколько раз 
    virtual
    umba::Error driverSoftwareStart(const DriverAddress &driverAddress) = 0;

    virtual
    void driverSoftwareSetStarted(const DriverAddress &driverAddress) = 0;


};


#ifdef UMBA_MSVC_COMPILER_USED
    #pragma warning(push)
    // C4584
    #pragma warning (disable: 4584)
#endif

interface IDriver : public umba::IUnknown // UMBA_DRIVERS_INHERITANS IDriverPrivate
{

    UMBA_DECLARE_INTERFACE_ID(0x93C0C9E3);

    //---------

    //! Возвращает идентификатор драйвера, заданный при создании экземпляра (или автоматически назначенный)
    virtual
    DriverId getDriverId( const DriverAddress &driverAddress ) = 0;

    //---------

    virtual
    void getDriverClassName( ClassId classId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    virtual
    void getDriverSubclassName( ClassId classId, SubclassId subclassId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //---------

    virtual
    void getDriverDescription( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //! return false if invalid config detected
    virtual
    bool getDriverConfigInfo( const DriverAddress &driverAddress, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //---------

    virtual
    bool getDriverParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    virtual
    bool getDriverParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //---------

    virtual
    bool getDeviceParamName( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    virtual
    bool getDeviceParamInfo( const DriverAddress &driverAddress, ValueId paramId, umba::ihc::IOctetOStream *pStreamTo ) = 0;

    //---------

    virtual
    PowerConsumptionClass getPowerClass(const DriverAddress &driverAddress) = 0;

    virtual
    DriverAddress getAssignedAddress() = 0;

    virtual
    bool isDriverHardwareInitialized() = 0;

    virtual
    bool isDriverSoftwareInitialized() = 0;

    virtual
    bool isDriverInitialized() = 0;


    //---------

}; // interface IDriver

#ifdef UMBA_MSVC_COMPILER_USED
    #pragma warning(pop)
#endif


/*
    virtual
    bool canWrite(StreamSize nOctets) = 0;
    virtual
    void write( const StreamOctetType *pData, StreamSize nOctets) = 0;
*/





} // namespace drivers
} // namespace umba


