UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_unknown               ,  0           , "Unknown class" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_any                   ,  (ClassId)-1 , "Any class" );

// Аппаратная периферия, обычно не имеет подклассов
// Следует добавлять с ID, равным аппаратному номеру
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_tim_pwm               ,  0x11AA08C4, "TIM PWM" );

// Режим обмена - обычный потоковый.
// Кроме UARTов вроде бы ничего из периферии так и не умеет
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_stream                ,  0x06B70510, "Stream" ); // streams such UART etc

// Дополнительно задается адрес на шине
// Нужно бы переименовать в class_id_dgramm_i2c
// Это бы показало, что режим обмена - поток дэйтаграмм, каждая из которых имеет свой адрес
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_i2c                   ,  0x12C04850, "I2C" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_i2c_soft              ,  0x12C0F36D, "I2C Soft" );

// Для SPI адрес на шине - это порядковый номер пина CS, переданный в списке пинов
// Нужно бы переименовать в class_id_dgramm_spi
// Нужно бы переименовать в class_id_dgramm_i2c
// Это бы показало, что режим обмена - поток дэйтаграмм, каждая из которых имеет свой адрес
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_spi                   ,  0xBF10F01E, "SPI" );

// Устройства DAC/ADC - всегда одноканальные,
// нумерация сквозная, зависит от порядка добавления
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_dac                   ,  0xDAC03659, "DAC" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_adc                   ,  0xADC053C2, "ADC" );

// GPIO не инициализируется при аппаратной инициализации, а при первом обращении
// GPIO может работать как на IN, так и на OUT, зависит от того, как инициализирован
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_gpio                  ,  0xDF101BE8, "GPIO" );

UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_power_switch          ,  0xF0BEB1E8, "Power switch" );

UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_state_indicator       ,  0x19D0B934, "State indicator" );

// Драйверы высокого уровня. Желательно, чтобы они работали через драйвера низкого уровня
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_hid                   ,  0xF1D093EC, "HID" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_sensor                ,  0x8E9857EA, "Sensor" );
//UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_motor                 ,  0xAA010F45, "Motor" );
UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_esc                   ,  0x89C5E766, "Motor" );

UMBA_DRIVER_DECLARE_CLASS_CODE ( class_id_uplink                ,  0xAF11CB75, "Uplink" );
