// Main_Board.PrjPcb - Generator: extern_cpp_pins_snake


#include "tvtx2v2_Main_Board_conf.h"

// Main_Board.PrjPcb - Netlist_1

// MCU DD1 STM32F303VD peripherals

// BATTERY

UMBA_PERIPH_EXTERN_PIN( battery_charge_detect_Pin );
UMBA_PERIPH_EXTERN_PIN( battery_present_Pin );

// CAMERAS_EN

UMBA_PERIPH_EXTERN_PIN( tvko_en_Pin );    
UMBA_PERIPH_EXTERN_PIN( camera1_en_Pin ); 
UMBA_PERIPH_EXTERN_PIN( camera2_en_Pin ); 

// GOLEM_UART_DATA


// GOLEM_UART_TERM


// GYRO

UMBA_PERIPH_EXTERN_PIN( gyro_cs_xm_Pin ); 
UMBA_PERIPH_EXTERN_PIN( gyro_cs_g_Pin );  

// MUX

UMBA_PERIPH_EXTERN_PIN( mux_en_Pin );     
UMBA_PERIPH_EXTERN_PIN( mux_a0_Pin );     
UMBA_PERIPH_EXTERN_PIN( mux_a1_Pin );     

// RS485_LEFT

UMBA_PERIPH_EXTERN_PIN( rs485_left_link_de_Pin );

// RS485_RIGHT

UMBA_PERIPH_EXTERN_PIN( rs485_right_link_de_Pin );

// STATE_LEDS

UMBA_PERIPH_EXTERN_PIN( led_error_Pin );  
UMBA_PERIPH_EXTERN_PIN( led_link_Pin );   

// TVKO

UMBA_PERIPH_EXTERN_PIN( tvko_motor2_out_Pin );
UMBA_PERIPH_EXTERN_PIN( tvko_motor1_amplif_shdn2_Pin );

// TVKO_MOTOR1

UMBA_PERIPH_EXTERN_PIN( tvko_motor1_out_Pin );
UMBA_PERIPH_EXTERN_PIN( tvko_motor1_speed_Pin );
UMBA_PERIPH_EXTERN_PIN( tvko_motor1_nfault_Pin );
UMBA_PERIPH_EXTERN_PIN( tvko_motor1_amplif_shdn1_Pin );
UMBA_PERIPH_EXTERN_PIN( tvko_motor1_pwm1_Pin );
UMBA_PERIPH_EXTERN_PIN( tvko_motor1_pwm2_Pin );

// TVKO_MOTOR2

UMBA_PERIPH_EXTERN_PIN( tvko_motor2_nfault_Pin );
UMBA_PERIPH_EXTERN_PIN( tvko_motor2_pwm1_Pin );
UMBA_PERIPH_EXTERN_PIN( tvko_motor2_pwm2_Pin );

// TVKO_UART


