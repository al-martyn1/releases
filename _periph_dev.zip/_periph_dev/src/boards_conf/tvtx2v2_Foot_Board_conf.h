// Foot_Board.PrjPcb - Generator: h_conf


#include "periph/gpio.h"

// Foot_Board.PrjPcb - Netlist_1

// MCU DD2 STM32F303CBT6 peripherals

// Unclassified

#define LIR_DATA_GPIO                                 GPIOB
#define LIR_DATA_GPIO_PIN_NO                          4
#define LIR_DATA_GPIO_PIN_ADDR                        UMBA_PINADDR_PB4
#define LIR_DATA_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PB4, UMBA_GPIO_DIRECTION_OUT
#define LIR_DATA_GPIO_PIN_SOURCE                      GPIO_PinSource4
#define LIR_DATA_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define ESC_CURRENT_GPIO                              GPIOA
#define ESC_CURRENT_GPIO_PIN_NO                       6
#define ESC_CURRENT_GPIO_PIN_ADDR                     UMBA_PINADDR_PA6
#define ESC_CURRENT_GPIO_PIN_ADDR_DIR                 UMBA_PINADDR_PA6, UMBA_GPIO_DIRECTION_IN
#define ESC_CURRENT_GPIO_PIN_SOURCE                   GPIO_PinSource6
#define ESC_CURRENT_GPIO_PIN_DIRECTION                UMBA_GPIO_DIRECTION_IN


#define RANGEFINDER1_GPIO                             GPIOB
#define RANGEFINDER1_GPIO_PIN_NO                      14
#define RANGEFINDER1_GPIO_PIN_ADDR                    UMBA_PINADDR_PB14
#define RANGEFINDER1_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PB14, UMBA_GPIO_DIRECTION_OUT
#define RANGEFINDER1_GPIO_PIN_SOURCE                  GPIO_PinSource14
#define RANGEFINDER1_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define RANGEFINDER2_GPIO                             GPIOB
#define RANGEFINDER2_GPIO_PIN_NO                      13
#define RANGEFINDER2_GPIO_PIN_ADDR                    UMBA_PINADDR_PB13
#define RANGEFINDER2_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT
#define RANGEFINDER2_GPIO_PIN_SOURCE                  GPIO_PinSource13
#define RANGEFINDER2_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define RANGEFINDER3_GPIO                             GPIOB
#define RANGEFINDER3_GPIO_PIN_NO                      12
#define RANGEFINDER3_GPIO_PIN_ADDR                    UMBA_PINADDR_PB12
#define RANGEFINDER3_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT
#define RANGEFINDER3_GPIO_PIN_SOURCE                  GPIO_PinSource12
#define RANGEFINDER3_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define RANGEFINDER4_GPIO                             GPIOB
#define RANGEFINDER4_GPIO_PIN_NO                      15
#define RANGEFINDER4_GPIO_PIN_ADDR                    UMBA_PINADDR_PB15
#define RANGEFINDER4_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PB15, UMBA_GPIO_DIRECTION_OUT
#define RANGEFINDER4_GPIO_PIN_SOURCE                  GPIO_PinSource15
#define RANGEFINDER4_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT




// DEBUG_UART

#define DEBUG_UART                                    UART1
#define DEBUG_LEGACY_UART                             uart::uart1
#define USE_UART1                                     1
#define DEBUG_UART_TX_GPIO                            GPIOA
#define DEBUG_UART_TX_GPIO_PIN_NO                     9
#define DEBUG_UART_TX_GPIO_PIN_ADDR                   UMBA_PINADDR_PA9
#define DEBUG_UART_TX_GPIO_PIN_SOURCE                 GPIO_PinSource9
#define DEBUG_UART_TX_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT

#define DEBUG_UART_RX_GPIO                            GPIOA
#define DEBUG_UART_RX_GPIO_PIN_NO                     10
#define DEBUG_UART_RX_GPIO_PIN_ADDR                   UMBA_PINADDR_PA10
#define DEBUG_UART_RX_GPIO_PIN_SOURCE                 GPIO_PinSource10
#define DEBUG_UART_RX_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN




// PSENSOR

#define PSENSOR_I2C                                   I2C1
#define USE_I2C1                                      1
#define PSENSOR_I2C_SCL_GPIO                          GPIOB
#define PSENSOR_I2C_SCL_GPIO_PIN_NO                   6
#define PSENSOR_I2C_SCL_GPIO_PIN_ADDR                 UMBA_PINADDR_PB6
#define PSENSOR_I2C_SCL_GPIO_PIN_SOURCE               GPIO_PinSource6

#define PSENSOR_I2C_SDA_GPIO                          GPIOB
#define PSENSOR_I2C_SDA_GPIO_PIN_NO                   7
#define PSENSOR_I2C_SDA_GPIO_PIN_ADDR                 UMBA_PINADDR_PB7
#define PSENSOR_I2C_SDA_GPIO_PIN_SOURCE               GPIO_PinSource7




// RS485

#define RS485_LINK_DE_GPIO                            GPIOB
#define RS485_LINK_DE_GPIO_PIN_NO                     2
#define RS485_LINK_DE_GPIO_PIN_ADDR                   UMBA_PINADDR_PB2
#define RS485_LINK_DE_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PB2, UMBA_GPIO_DIRECTION_OUT
#define RS485_LINK_DE_GPIO_PIN_SOURCE                 GPIO_PinSource2
#define RS485_LINK_DE_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT

#define RS485_UART                                    UART3
#define RS485_LEGACY_UART                             uart::uart3
#define USE_UART3                                     1
#define RS485_UART_TX_GPIO                            GPIOB
#define RS485_UART_TX_GPIO_PIN_NO                     10
#define RS485_UART_TX_GPIO_PIN_ADDR                   UMBA_PINADDR_PB10
#define RS485_UART_TX_GPIO_PIN_SOURCE                 GPIO_PinSource10
#define RS485_UART_TX_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT

#define RS485_UART_RX_GPIO                            GPIOB
#define RS485_UART_RX_GPIO_PIN_NO                     11
#define RS485_UART_RX_GPIO_PIN_ADDR                   UMBA_PINADDR_PB11
#define RS485_UART_RX_GPIO_PIN_SOURCE                 GPIO_PinSource11
#define RS485_UART_RX_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN




// STATE_LEDS

#define LED_LINK_GPIO                                 GPIOB
#define LED_LINK_GPIO_PIN_NO                          1
#define LED_LINK_GPIO_PIN_ADDR                        UMBA_PINADDR_PB1
#define LED_LINK_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PB1, UMBA_GPIO_DIRECTION_OUT
#define LED_LINK_GPIO_PIN_SOURCE                      GPIO_PinSource1
#define LED_LINK_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT

#define LED_ERROR_GPIO                                GPIOB
#define LED_ERROR_GPIO_PIN_NO                         0
#define LED_ERROR_GPIO_PIN_ADDR                       UMBA_PINADDR_PB0
#define LED_ERROR_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PB0, UMBA_GPIO_DIRECTION_OUT
#define LED_ERROR_GPIO_PIN_SOURCE                     GPIO_PinSource0
#define LED_ERROR_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT




