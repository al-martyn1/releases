// Foot_Board.PrjPcb - Generator: extern_cpp_pins_snake


#include "tvtx2v2_Foot_Board_conf.h"

// Foot_Board.PrjPcb - Netlist_1

// MCU DD2 STM32F303CBT6 peripherals

// Unclassified

UMBA_PERIPH_EXTERN_PIN( lir_data_Pin );   
UMBA_PERIPH_EXTERN_PIN( esc_current_Pin );
UMBA_PERIPH_EXTERN_PIN( rangefinder1_Pin );
UMBA_PERIPH_EXTERN_PIN( rangefinder2_Pin );
UMBA_PERIPH_EXTERN_PIN( rangefinder3_Pin );
UMBA_PERIPH_EXTERN_PIN( rangefinder4_Pin );

// DEBUG_UART


// PSENSOR


// RS485

UMBA_PERIPH_EXTERN_PIN( rs485_link_de_Pin );

// STATE_LEDS

UMBA_PERIPH_EXTERN_PIN( led_link_Pin );   
UMBA_PERIPH_EXTERN_PIN( led_error_Pin );  

