// Main_Board.PrjPcb - Generator: h_conf


#include "periph/gpio.h"

// Main_Board.PrjPcb - Netlist_1

// MCU DD1 STM32F303VD peripherals

// BATTERY

#define BATTERY_CHARGE_DETECT_GPIO                    GPIOD
#define BATTERY_CHARGE_DETECT_GPIO_PIN_NO             14
#define BATTERY_CHARGE_DETECT_GPIO_PIN_ADDR           UMBA_PINADDR_PD14
#define BATTERY_CHARGE_DETECT_GPIO_PIN_ADDR_DIR       UMBA_PINADDR_PD14, UMBA_GPIO_DIRECTION_OUT
#define BATTERY_CHARGE_DETECT_GPIO_PIN_SOURCE         GPIO_PinSource14
#define BATTERY_CHARGE_DETECT_GPIO_PIN_DIRECTION      UMBA_GPIO_DIRECTION_OUT

#define BATTERY_PRESENT_GPIO                          GPIOD
#define BATTERY_PRESENT_GPIO_PIN_NO                   15
#define BATTERY_PRESENT_GPIO_PIN_ADDR                 UMBA_PINADDR_PD15
#define BATTERY_PRESENT_GPIO_PIN_ADDR_DIR             UMBA_PINADDR_PD15, UMBA_GPIO_DIRECTION_OUT
#define BATTERY_PRESENT_GPIO_PIN_SOURCE               GPIO_PinSource15
#define BATTERY_PRESENT_GPIO_PIN_DIRECTION            UMBA_GPIO_DIRECTION_OUT




// CAMERAS_EN

#define TVKO_EN_GPIO                                  GPIOA
#define TVKO_EN_GPIO_PIN_NO                           1
#define TVKO_EN_GPIO_PIN_ADDR                         UMBA_PINADDR_PA1
#define TVKO_EN_GPIO_PIN_ADDR_DIR                     UMBA_PINADDR_PA1, UMBA_GPIO_DIRECTION_OUT
#define TVKO_EN_GPIO_PIN_SOURCE                       GPIO_PinSource1
#define TVKO_EN_GPIO_PIN_DIRECTION                    UMBA_GPIO_DIRECTION_OUT

#define CAMERA1_EN_GPIO                               GPIOB
#define CAMERA1_EN_GPIO_PIN_NO                        12
#define CAMERA1_EN_GPIO_PIN_ADDR                      UMBA_PINADDR_PB12
#define CAMERA1_EN_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PB12, UMBA_GPIO_DIRECTION_OUT
#define CAMERA1_EN_GPIO_PIN_SOURCE                    GPIO_PinSource12
#define CAMERA1_EN_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define CAMERA2_EN_GPIO                               GPIOA
#define CAMERA2_EN_GPIO_PIN_NO                        0
#define CAMERA2_EN_GPIO_PIN_ADDR                      UMBA_PINADDR_PA0
#define CAMERA2_EN_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PA0, UMBA_GPIO_DIRECTION_OUT
#define CAMERA2_EN_GPIO_PIN_SOURCE                    GPIO_PinSource0
#define CAMERA2_EN_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT




// GOLEM_UART_DATA

#define GOLEM_DATA_UART                               UART1
#define GOLEM_DATA_LEGACY_UART                        uart::uart1
#define USE_UART1                                     1
#define GOLEM_DATA_UART_TX_GPIO                       GPIOC
#define GOLEM_DATA_UART_TX_GPIO_PIN_NO                4
#define GOLEM_DATA_UART_TX_GPIO_PIN_ADDR              UMBA_PINADDR_PC4
#define GOLEM_DATA_UART_TX_GPIO_PIN_SOURCE            GPIO_PinSource4
#define GOLEM_DATA_UART_TX_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT

#define GOLEM_DATA_UART_RX_GPIO                       GPIOC
#define GOLEM_DATA_UART_RX_GPIO_PIN_NO                5
#define GOLEM_DATA_UART_RX_GPIO_PIN_ADDR              UMBA_PINADDR_PC5
#define GOLEM_DATA_UART_RX_GPIO_PIN_SOURCE            GPIO_PinSource5
#define GOLEM_DATA_UART_RX_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_IN




// GOLEM_UART_TERM

#define GOLEM_TERM_UART                               UART3
#define GOLEM_TERM_LEGACY_UART                        uart::uart3
#define USE_UART3                                     1
#define GOLEM_TERM_UART_TX_GPIO                       GPIOB
#define GOLEM_TERM_UART_TX_GPIO_PIN_NO                10
#define GOLEM_TERM_UART_TX_GPIO_PIN_ADDR              UMBA_PINADDR_PB10
#define GOLEM_TERM_UART_TX_GPIO_PIN_SOURCE            GPIO_PinSource10
#define GOLEM_TERM_UART_TX_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT

#define GOLEM_TERM_UART_RX_GPIO                       GPIOB
#define GOLEM_TERM_UART_RX_GPIO_PIN_NO                11
#define GOLEM_TERM_UART_RX_GPIO_PIN_ADDR              UMBA_PINADDR_PB11
#define GOLEM_TERM_UART_RX_GPIO_PIN_SOURCE            GPIO_PinSource11
#define GOLEM_TERM_UART_RX_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_IN




// GYRO

#define GYRO_SPI                                      SPI2
#define USE_SPI2                                      1
#define GYRO_SPI_SCK_GPIO                             GPIOB
#define GYRO_SPI_SCK_GPIO_PIN_NO                      13
#define GYRO_SPI_SCK_GPIO_PIN_ADDR                    UMBA_PINADDR_PB13
#define GYRO_SPI_SCK_GPIO_PIN_ADDR_DIR                UMBA_PINADDR_PB13, UMBA_GPIO_DIRECTION_OUT
#define GYRO_SPI_SCK_GPIO_PIN_SOURCE                  GPIO_PinSource13
#define GYRO_SPI_SCK_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define GYRO_CS_XM_GPIO                               GPIOD
#define GYRO_CS_XM_GPIO_PIN_NO                        12
#define GYRO_CS_XM_GPIO_PIN_ADDR                      UMBA_PINADDR_PD12
#define GYRO_CS_XM_GPIO_PIN_ADDR_DIR                  UMBA_PINADDR_PD12, UMBA_GPIO_DIRECTION_OUT
#define GYRO_CS_XM_GPIO_PIN_SOURCE                    GPIO_PinSource12
#define GYRO_CS_XM_GPIO_PIN_DIRECTION                 UMBA_GPIO_DIRECTION_OUT

#define GYRO_CS_G_GPIO                                GPIOC
#define GYRO_CS_G_GPIO_PIN_NO                         8
#define GYRO_CS_G_GPIO_PIN_ADDR                       UMBA_PINADDR_PC8
#define GYRO_CS_G_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PC8, UMBA_GPIO_DIRECTION_OUT
#define GYRO_CS_G_GPIO_PIN_SOURCE                     GPIO_PinSource8
#define GYRO_CS_G_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define GYRO_SPI_MISO_GPIO                            GPIOA
#define GYRO_SPI_MISO_GPIO_PIN_NO                     10
#define GYRO_SPI_MISO_GPIO_PIN_ADDR                   UMBA_PINADDR_PA10
#define GYRO_SPI_MISO_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PA10, UMBA_GPIO_DIRECTION_IN
#define GYRO_SPI_MISO_GPIO_PIN_SOURCE                 GPIO_PinSource10
#define GYRO_SPI_MISO_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_IN

#define GYRO_SPI_MOSI_GPIO                            GPIOA
#define GYRO_SPI_MOSI_GPIO_PIN_NO                     11
#define GYRO_SPI_MOSI_GPIO_PIN_ADDR                   UMBA_PINADDR_PA11
#define GYRO_SPI_MOSI_GPIO_PIN_ADDR_DIR               UMBA_PINADDR_PA11, UMBA_GPIO_DIRECTION_OUT
#define GYRO_SPI_MOSI_GPIO_PIN_SOURCE                 GPIO_PinSource11
#define GYRO_SPI_MOSI_GPIO_PIN_DIRECTION              UMBA_GPIO_DIRECTION_OUT




// MUX

#define MUX_EN_GPIO                                   GPIOE
#define MUX_EN_GPIO_PIN_NO                            14
#define MUX_EN_GPIO_PIN_ADDR                          UMBA_PINADDR_PE14
#define MUX_EN_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PE14, UMBA_GPIO_DIRECTION_OUT
#define MUX_EN_GPIO_PIN_SOURCE                        GPIO_PinSource14
#define MUX_EN_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define MUX_A0_GPIO                                   GPIOE
#define MUX_A0_GPIO_PIN_NO                            15
#define MUX_A0_GPIO_PIN_ADDR                          UMBA_PINADDR_PE15
#define MUX_A0_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PE15, UMBA_GPIO_DIRECTION_OUT
#define MUX_A0_GPIO_PIN_SOURCE                        GPIO_PinSource15
#define MUX_A0_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT

#define MUX_A1_GPIO                                   GPIOE
#define MUX_A1_GPIO_PIN_NO                            13
#define MUX_A1_GPIO_PIN_ADDR                          UMBA_PINADDR_PE13
#define MUX_A1_GPIO_PIN_ADDR_DIR                      UMBA_PINADDR_PE13, UMBA_GPIO_DIRECTION_OUT
#define MUX_A1_GPIO_PIN_SOURCE                        GPIO_PinSource13
#define MUX_A1_GPIO_PIN_DIRECTION                     UMBA_GPIO_DIRECTION_OUT




// RS485_LEFT

#define RS485_LEFT_UART                               UART3
#define RS485_LEFT_LEGACY_UART                        uart::uart3
#define RS485_LEFT_UART_TX_GPIO                       GPIOC
#define RS485_LEFT_UART_TX_GPIO_PIN_NO                10
#define RS485_LEFT_UART_TX_GPIO_PIN_ADDR              UMBA_PINADDR_PC10
#define RS485_LEFT_UART_TX_GPIO_PIN_SOURCE            GPIO_PinSource10
#define RS485_LEFT_UART_TX_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT

#define RS485_LEFT_UART_RX_GPIO                       GPIOC
#define RS485_LEFT_UART_RX_GPIO_PIN_NO                11
#define RS485_LEFT_UART_RX_GPIO_PIN_ADDR              UMBA_PINADDR_PC11
#define RS485_LEFT_UART_RX_GPIO_PIN_SOURCE            GPIO_PinSource11
#define RS485_LEFT_UART_RX_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_IN

#define RS485_LEFT_LINK_DE_GPIO                       GPIOD
#define RS485_LEFT_LINK_DE_GPIO_PIN_NO                0
#define RS485_LEFT_LINK_DE_GPIO_PIN_ADDR              UMBA_PINADDR_PD0
#define RS485_LEFT_LINK_DE_GPIO_PIN_ADDR_DIR          UMBA_PINADDR_PD0, UMBA_GPIO_DIRECTION_OUT
#define RS485_LEFT_LINK_DE_GPIO_PIN_SOURCE            GPIO_PinSource0
#define RS485_LEFT_LINK_DE_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_OUT




// RS485_RIGHT

#define RS485_RIGHT_UART                              UART5
#define RS485_RIGHT_LEGACY_UART                       uart::uart5
#define USE_UART5                                     1
#define RS485_RIGHT_UART_TX_GPIO                      GPIOC
#define RS485_RIGHT_UART_TX_GPIO_PIN_NO               12
#define RS485_RIGHT_UART_TX_GPIO_PIN_ADDR             UMBA_PINADDR_PC12
#define RS485_RIGHT_UART_TX_GPIO_PIN_SOURCE           GPIO_PinSource12
#define RS485_RIGHT_UART_TX_GPIO_PIN_DIRECTION        UMBA_GPIO_DIRECTION_OUT

#define RS485_RIGHT_LINK_DE_GPIO                      GPIOD
#define RS485_RIGHT_LINK_DE_GPIO_PIN_NO               1
#define RS485_RIGHT_LINK_DE_GPIO_PIN_ADDR             UMBA_PINADDR_PD1
#define RS485_RIGHT_LINK_DE_GPIO_PIN_ADDR_DIR         UMBA_PINADDR_PD1, UMBA_GPIO_DIRECTION_OUT
#define RS485_RIGHT_LINK_DE_GPIO_PIN_SOURCE           GPIO_PinSource1
#define RS485_RIGHT_LINK_DE_GPIO_PIN_DIRECTION        UMBA_GPIO_DIRECTION_OUT

#define RS485_RIGHT_UART_RX_GPIO                      GPIOD
#define RS485_RIGHT_UART_RX_GPIO_PIN_NO               2
#define RS485_RIGHT_UART_RX_GPIO_PIN_ADDR             UMBA_PINADDR_PD2
#define RS485_RIGHT_UART_RX_GPIO_PIN_SOURCE           GPIO_PinSource2
#define RS485_RIGHT_UART_RX_GPIO_PIN_DIRECTION        UMBA_GPIO_DIRECTION_IN




// STATE_LEDS

#define LED_ERROR_GPIO                                GPIOE
#define LED_ERROR_GPIO_PIN_NO                         5
#define LED_ERROR_GPIO_PIN_ADDR                       UMBA_PINADDR_PE5
#define LED_ERROR_GPIO_PIN_ADDR_DIR                   UMBA_PINADDR_PE5, UMBA_GPIO_DIRECTION_OUT
#define LED_ERROR_GPIO_PIN_SOURCE                     GPIO_PinSource5
#define LED_ERROR_GPIO_PIN_DIRECTION                  UMBA_GPIO_DIRECTION_OUT

#define LED_LINK_GPIO                                 GPIOE
#define LED_LINK_GPIO_PIN_NO                          6
#define LED_LINK_GPIO_PIN_ADDR                        UMBA_PINADDR_PE6
#define LED_LINK_GPIO_PIN_ADDR_DIR                    UMBA_PINADDR_PE6, UMBA_GPIO_DIRECTION_OUT
#define LED_LINK_GPIO_PIN_SOURCE                      GPIO_PinSource6
#define LED_LINK_GPIO_PIN_DIRECTION                   UMBA_GPIO_DIRECTION_OUT




// TVKO

#define TVKO_MOTOR2_OUT_GPIO                          GPIOC
#define TVKO_MOTOR2_OUT_GPIO_PIN_NO                   2
#define TVKO_MOTOR2_OUT_GPIO_PIN_ADDR                 UMBA_PINADDR_PC2
#define TVKO_MOTOR2_OUT_GPIO_PIN_ADDR_DIR             UMBA_PINADDR_PC2, UMBA_GPIO_DIRECTION_IN
#define TVKO_MOTOR2_OUT_GPIO_PIN_SOURCE               GPIO_PinSource2
#define TVKO_MOTOR2_OUT_GPIO_PIN_DIRECTION            UMBA_GPIO_DIRECTION_IN

#define TVKO_MOTOR1_AMPLIF_SHDN2_GPIO                 GPIOC
#define TVKO_MOTOR1_AMPLIF_SHDN2_GPIO_PIN_NO          3
#define TVKO_MOTOR1_AMPLIF_SHDN2_GPIO_PIN_ADDR        UMBA_PINADDR_PC3
#define TVKO_MOTOR1_AMPLIF_SHDN2_GPIO_PIN_ADDR_DIR    UMBA_PINADDR_PC3, UMBA_GPIO_DIRECTION_IN
#define TVKO_MOTOR1_AMPLIF_SHDN2_GPIO_PIN_SOURCE      GPIO_PinSource3
#define TVKO_MOTOR1_AMPLIF_SHDN2_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_IN




// TVKO_MOTOR1

#define TVKO_MOTOR1_OUT_GPIO                          GPIOC
#define TVKO_MOTOR1_OUT_GPIO_PIN_NO                   0
#define TVKO_MOTOR1_OUT_GPIO_PIN_ADDR                 UMBA_PINADDR_PC0
#define TVKO_MOTOR1_OUT_GPIO_PIN_ADDR_DIR             UMBA_PINADDR_PC0, UMBA_GPIO_DIRECTION_IN
#define TVKO_MOTOR1_OUT_GPIO_PIN_SOURCE               GPIO_PinSource0
#define TVKO_MOTOR1_OUT_GPIO_PIN_DIRECTION            UMBA_GPIO_DIRECTION_IN

#define TVKO_MOTOR1_SPEED_GPIO                        GPIOA
#define TVKO_MOTOR1_SPEED_GPIO_PIN_NO                 4
#define TVKO_MOTOR1_SPEED_GPIO_PIN_ADDR               UMBA_PINADDR_PA4
#define TVKO_MOTOR1_SPEED_GPIO_PIN_ADDR_DIR           UMBA_PINADDR_PA4, UMBA_GPIO_DIRECTION_OUT
#define TVKO_MOTOR1_SPEED_GPIO_PIN_SOURCE             GPIO_PinSource4
#define TVKO_MOTOR1_SPEED_GPIO_PIN_DIRECTION          UMBA_GPIO_DIRECTION_OUT

#define TVKO_MOTOR1_nFAULT_GPIO                       GPIOB
#define TVKO_MOTOR1_nFAULT_GPIO_PIN_NO                7
#define TVKO_MOTOR1_nFAULT_GPIO_PIN_ADDR              UMBA_PINADDR_PB7
#define TVKO_MOTOR1_nFAULT_GPIO_PIN_ADDR_DIR          UMBA_PINADDR_PB7, UMBA_GPIO_DIRECTION_IN
#define TVKO_MOTOR1_nFAULT_GPIO_PIN_SOURCE            GPIO_PinSource7
#define TVKO_MOTOR1_nFAULT_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_IN

#define TVKO_MOTOR1_AMPLIF_SHDN1_GPIO                 GPIOC
#define TVKO_MOTOR1_AMPLIF_SHDN1_GPIO_PIN_NO          1
#define TVKO_MOTOR1_AMPLIF_SHDN1_GPIO_PIN_ADDR        UMBA_PINADDR_PC1
#define TVKO_MOTOR1_AMPLIF_SHDN1_GPIO_PIN_ADDR_DIR    UMBA_PINADDR_PC1, UMBA_GPIO_DIRECTION_IN
#define TVKO_MOTOR1_AMPLIF_SHDN1_GPIO_PIN_SOURCE      GPIO_PinSource1
#define TVKO_MOTOR1_AMPLIF_SHDN1_GPIO_PIN_DIRECTION    UMBA_GPIO_DIRECTION_IN

#define TVKO_MOTOR1_PWM1_GPIO                         GPIOB
#define TVKO_MOTOR1_PWM1_GPIO_PIN_NO                  4
#define TVKO_MOTOR1_PWM1_GPIO_PIN_ADDR                UMBA_PINADDR_PB4
#define TVKO_MOTOR1_PWM1_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PB4, UMBA_GPIO_DIRECTION_OUT
#define TVKO_MOTOR1_PWM1_GPIO_PIN_SOURCE              GPIO_PinSource4
#define TVKO_MOTOR1_PWM1_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT

#define TVKO_MOTOR1_PWM2_GPIO                         GPIOB
#define TVKO_MOTOR1_PWM2_GPIO_PIN_NO                  5
#define TVKO_MOTOR1_PWM2_GPIO_PIN_ADDR                UMBA_PINADDR_PB5
#define TVKO_MOTOR1_PWM2_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PB5, UMBA_GPIO_DIRECTION_OUT
#define TVKO_MOTOR1_PWM2_GPIO_PIN_SOURCE              GPIO_PinSource5
#define TVKO_MOTOR1_PWM2_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT




// TVKO_MOTOR2

#define TVKO_MOTOR2_SPEED_DAC                         DAC1
#define TVKO_MOTOR2_SPEED_DAC_CHANNEL                 DAC_Channel_2
#define TVKO_MOTOR2_SPEED_DAC_CHANNEL_NO              2
#define USE_DAC1                                      1

#define TVKO_MOTOR2_nFAULT_GPIO                       GPIOD
#define TVKO_MOTOR2_nFAULT_GPIO_PIN_NO                6
#define TVKO_MOTOR2_nFAULT_GPIO_PIN_ADDR              UMBA_PINADDR_PD6
#define TVKO_MOTOR2_nFAULT_GPIO_PIN_ADDR_DIR          UMBA_PINADDR_PD6, UMBA_GPIO_DIRECTION_IN
#define TVKO_MOTOR2_nFAULT_GPIO_PIN_SOURCE            GPIO_PinSource6
#define TVKO_MOTOR2_nFAULT_GPIO_PIN_DIRECTION         UMBA_GPIO_DIRECTION_IN

#define TVKO_MOTOR2_PWM1_GPIO                         GPIOD
#define TVKO_MOTOR2_PWM1_GPIO_PIN_NO                  3
#define TVKO_MOTOR2_PWM1_GPIO_PIN_ADDR                UMBA_PINADDR_PD3
#define TVKO_MOTOR2_PWM1_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PD3, UMBA_GPIO_DIRECTION_OUT
#define TVKO_MOTOR2_PWM1_GPIO_PIN_SOURCE              GPIO_PinSource3
#define TVKO_MOTOR2_PWM1_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT

#define TVKO_MOTOR2_PWM2_GPIO                         GPIOD
#define TVKO_MOTOR2_PWM2_GPIO_PIN_NO                  4
#define TVKO_MOTOR2_PWM2_GPIO_PIN_ADDR                UMBA_PINADDR_PD4
#define TVKO_MOTOR2_PWM2_GPIO_PIN_ADDR_DIR            UMBA_PINADDR_PD4, UMBA_GPIO_DIRECTION_OUT
#define TVKO_MOTOR2_PWM2_GPIO_PIN_SOURCE              GPIO_PinSource4
#define TVKO_MOTOR2_PWM2_GPIO_PIN_DIRECTION           UMBA_GPIO_DIRECTION_OUT




// TVKO_UART

#define TVKO_UART                                     UART2
#define TVKO_LEGACY_UART                              uart::uart2
#define USE_UART2                                     1
#define TVKO_UART_TX_GPIO                             GPIOA
#define TVKO_UART_TX_GPIO_PIN_NO                      2
#define TVKO_UART_TX_GPIO_PIN_ADDR                    UMBA_PINADDR_PA2
#define TVKO_UART_TX_GPIO_PIN_SOURCE                  GPIO_PinSource2
#define TVKO_UART_TX_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_OUT

#define TVKO_UART_RX_GPIO                             GPIOA
#define TVKO_UART_RX_GPIO_PIN_NO                      3
#define TVKO_UART_RX_GPIO_PIN_ADDR                    UMBA_PINADDR_PA3
#define TVKO_UART_RX_GPIO_PIN_SOURCE                  GPIO_PinSource3
#define TVKO_UART_RX_GPIO_PIN_DIRECTION               UMBA_GPIO_DIRECTION_IN




