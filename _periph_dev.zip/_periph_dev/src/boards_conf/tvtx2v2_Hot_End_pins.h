// Hot-End.PrjPcb - Generator: extern_cpp_pins_snake


#include "tvtx2v2_Hot_End_conf.h"

// Hot-End.PrjPcb - Netlist_1

// MCU DD1 STM32F303CBT6 peripherals

// Unclassified

UMBA_PERIPH_EXTERN_PIN( cooler_en_Pin );  
UMBA_PERIPH_EXTERN_PIN( heater_en_Pin );  
UMBA_PERIPH_EXTERN_PIN( temperature_Pin );

// EXTRUDER_MOTOR

UMBA_PERIPH_EXTERN_PIN( extruder_motor_current_Pin );
UMBA_PERIPH_EXTERN_PIN( extruder_motor_amplif_shdn_Pin );
UMBA_PERIPH_EXTERN_PIN( extruder_motor_speed_Pin );
UMBA_PERIPH_EXTERN_PIN( extruder_motor_nfault_Pin );
UMBA_PERIPH_EXTERN_PIN( extruder_motor_in1_Pin );
UMBA_PERIPH_EXTERN_PIN( extruder_motor_in2_Pin );

// RS485

UMBA_PERIPH_EXTERN_PIN( rs485_link_de_Pin );

// STATE_LEDS

UMBA_PERIPH_EXTERN_PIN( led_link_Pin );   

