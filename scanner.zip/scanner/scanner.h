#ifndef SCANNER_H
#define SCANNER_H


#if !defined(_STACK_) && !defined(_STLP_STACK) && !defined(__STD_STACK__) && !defined(_CPP_STACK) && !defined(_GLIBCXX_STACK)
    #include <stack>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#if !defined(PCPPDFA_H)
    #include "pcppdfa.h"
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_STACK_) && !defined(_STLP_STACK) && !defined(__STD_STACK__) && !defined(_CPP_STACK) && !defined(_GLIBCXX_STACK)
    #include <stack>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#include <scanner/scannerBase.h>


#if !defined(LEXTYPES_H)
    #include "lextypes.h"
#endif

#include "incbase.h"


 /* #define STATE next_state
  * #define PREV_STATE state
  * #define RETURN if (e) { *err = e; } return next_state
  * #define INPUT_CHAR (unsigned char)ch
  * #define BEGIN(st) next_state = SIXML_STATE_##st
  * #define SET_ERROR(error) next_state = -1; e = SIXML_ERROR_##error
  */


struct CScannerEvent
{
    text_position_t  startPos;
    text_position_t  curPos;
    int              token;
    int              info1;
    int              info2;
    int              info3;
    int              info4;

    //const char*      filename;
    unsigned         filenameId;

    //void*            ptr1;
    //void*            ptr2;

    std::string      text; 

    void clear(int t = 0, const std::string &txt = std::string())
       {
        token = t;
        text  = txt;
       }

   CFilePosition getStartPos() const { return CFilePosition(startPos, filenameId); }


    CScannerEvent() 
       : startPos()
       , curPos()
       , token()
       , info1(0)
       , info2(0)
       , info3(0)
       , info4(0)
       , filenameId(0)
       , text()
       //, ptr1(0)
       //, ptr2(0)
       {}

    CScannerEvent( int t
                 , const std::string txt
                 ) 
       : startPos()
       , curPos()
       , token(t)
       , info1(0)
       , info2(0)
       , info3(0)
       , info4(0)
       , filenameId(0)
       , text(txt)
       //, ptr1(0)
       //, ptr2(0)
       {}
    CScannerEvent( const text_position_t &sp
                 , const text_position_t &cp
                 , int t
                 , const std::string txt
                 ) 
       : startPos(sp)
       , curPos(cp)
       , token(t)
       , info1(0)
       , info2(0)
       , info3(0)
       , info4(0)
       , filenameId(0)
       , text(txt)
       //, ptr1(0)
       //, ptr2(0)
       {}
};

inline
std::string shieldStringLikeCEscaping(const std::string& str)
   {
    std::string res;
    for(std::string::size_type pos = 0, size=str.size(); pos!=size; ++pos)
       {       
        switch(str[pos])
           {
            case '\n':  res.append("\\n");
                    break;
            case '\r':  res.append("\\r");
                    break;
            case '\t':  res.append("\\t");
                    break;
            /* case '\g':  res.append("\\g");
             *         break;
             */
            /* case '\n':  res.append("\\n");
             *         break;
             */
            default:            
                    res.append(1, str[pos]);
           }
       }
    return res;
   }

inline
void fsmObjSerialize( std::ostream &os, const CScannerEvent &evt)
   {
    os<<getLexemTypeStr(evt.token)<<" ["<<shieldStringLikeCEscaping(evt.text)<<"]";
   }


struct CScannerErrorContext
{
    text_position_t  pos;
    std::string      curFile;
    std::string      text1;

    void setWhere(const CScannerEvent &evt, const std::vector<std::string> &files)
        {
         typedef std::vector<std::string>::size_type size_type;
         pos = evt.startPos;
         if (size_type(evt.filenameId)>=files.size())
            curFile = "-";
         else
            curFile = files[evt.filenameId];
        }

    std::string formatErrorPrefix(int err);
    //std::string formatErrorPrefix(const std::string &filename, int err);
    static std::string formatFilePos(const std::string &filename, int line, int pos);
    static std::string formatFilePos(const std::string &filename, text_position_t pos);
    
    virtual std::string formatError(int err);
};


//-----------------------------------------------------------------------------
inline
bool isSpaceTokenEvent(const CScannerEvent &evt)
   {
    return LT_IS_WHITESPACE(evt.token)!=0;
   }

//-----------------------------------------------------------------------------
inline
bool isCommentTokenEvent(const CScannerEvent &evt)
   {
    return LT_IS_COMMENT(evt.token)!=0;
   }

//-----------------------------------------------------------------------------


#ifndef C_SCANNER_DISABLE_IOSTREAM_IO
//#if defined(_IOSTREAM_) || defined(_STLP_IOSTREAM) || defined(__STD_IOSTREAM__) || defined(_CPP_IOSTREAM) || defined(_GLIBCXX_IOSTREAM)
inline
std::ostream& operator<<(std::ostream &os, const CScannerEvent& evt)
   {
    #ifndef C_SCANNER_DISABLE_EXTENDED_IOSTREAM_IO
    os<<getLexemTypeStr(evt.token)<<" i1:"<<evt.info1<<", i2:"<<evt.info2<<" - ["<<evt.text<<"]\n";
    #else
    os<<evt.text;
    #ifndef C_SCANNER_EXTENDED_IOSTREAM_IO_DISABLE_APPEND_SPACE
    os<<std::string(" ");
    #endif
    #endif
    return os;
   }
//template<typename TElem>
inline
std::ostream& operator<<(std::ostream &os, const std::vector<CScannerEvent>& vec)
   {
    for(std::vector<CScannerEvent>::const_iterator it = vec.begin(); it!=vec.end(); ++it)
       {
        os<<*it; os<<std::string("\n");
       }
    return os;
   }
//#endif
#endif

struct CMacrosInfo
{
    typedef std::vector<std::string>::size_type  index_type;

    bool                        haveArgs;
    std::map<std::string, index_type>  args;
    std::string                 text;
};

#ifndef C_SCANNER_DISABLE_IOSTREAM_IO
inline
std::ostream& operator<<(std::ostream &os, const CMacrosInfo& mi)
   {
    std::vector<std::string> args(mi.args.size(), std::string());

    std::map<std::string, CMacrosInfo::index_type>::const_iterator amIt = mi.args.begin();
    for(; amIt!=mi.args.end(); ++amIt)
       {
        if (amIt->second<0 || amIt->second>=args.size()) continue;
        args[amIt->second] = amIt->first;
       }

    if (mi.haveArgs) os<<std::string(" args - (");
    std::vector<std::string>::const_iterator ait = args.begin();
    for(; ait!=args.end(); ++ait)
       {
        if (ait!=args.begin()) os<<std::string(",");
        os<<*ait;
       }
    if (mi.haveArgs) os<<std::string(")");
    os<<std::string(", body - ")<<mi.text<<std::string("\n");
    return os;
   }
#endif



struct CPreprocessorOptions
{
    bool parseDefines;
    bool parseIncludes;
    bool parseUserIncludes;
    bool parseIfdef;

    CPreprocessorOptions()
       : parseDefines(true)
       , parseIncludes(true)
       , parseUserIncludes(true)
       , parseIfdef(true)
       {}
};

class CPrettyCppScannerBase;


enum CConditionState 
{
    csWaitElse,
    csWaitEndif
};

struct CCondition
{
    bool               cond; // if false - all data ignored
    CConditionState    state;
    unsigned           filenameId;
    text_position_t    pos;
    CCondition(bool c, CConditionState s, int f, text_position_t p) : cond(c), state(s), filenameId(f), pos(p) {}
};



bool parseMacroDefinition(const std::string &mDef, std::string &name, CMacrosInfo &info);
bool parseMacroTokensPaste(const std::vector<std::string> &args, const CMacrosInfo &info, std::string &res);


//CPrettyCppScannerBase
class CMacroPreprocessorBase// : public
{
        friend class CPrettyCppScannerBase;

        // �� ����������� ����������� ������ ��������
        std::set<std::string>    dontParseMacroses;

        // ����������� ����������� ������ ��������
        std::map<std::string, CMacrosInfo>  forceParseMacroses;

        // ������������� ������������ �������
        std::map<std::string, CMacrosInfo>  macroses;

        std::vector<CCondition>              conditionStack;
        bool                                 curCondition;

        // currently processed macro information
        //CMacrosInfo  currentMacro;
        //bool         currentMacroProcessing; // flag indicates that currentMacro is valid

        std::vector<CScannerEvent> eventBuf;
        bool fReady;
        bool fBuffered;
        bool fIgnore;
        int  bracketDepth;

        CPrettyCppScannerBase* pOwnerScanner;
        IIncludeSearch*        pIncludeFinder;

    public:


        bool hasUnclosedConditions() const
           {
            return !conditionStack.empty();
           }
        
        void getUnclosedConditions( std::vector<CCondition> &cs ) const
           {
            cs = conditionStack;
           }

        void clearUnclosedConditions()
           {
            conditionStack.clear();
           }

        CPreprocessorOptions    options;

        int put(const CScannerEvent &evt);
        bool getReady() const { return fReady; }
        bool getIgnore() const { return fIgnore; }
        bool getBuffered() const { return fBuffered; }
        void clearFlags() { fReady = true; fBuffered = false; fIgnore = false; eventBuf.clear(); }

        void dumpMacrosses( ::std::ostream &os )
           {
            os<<"--- forceParseMacroses\n";
            std::map<std::string, CMacrosInfo>::const_iterator it = forceParseMacroses.begin();
            for(; it!=forceParseMacroses.end(); ++it)
               {
                os<<it->first<<"\n";
               }
            os<<"--- macroses\n";
            it = macroses.begin();
            for(; it!=macroses.end(); ++it)
               {
                os<<it->first<<"\n";
               }
           }

        bool addMacro(const std::string &m)
           {
            std::string macroName;
            CMacrosInfo macroInfo;
            if (!parseMacroDefinition(m, macroName, macroInfo))
               return false;

            macroses[macroName] = macroInfo;
            return true;
           }

        bool addForceMacro(const std::string &m)
           {
            std::string macroName;
            CMacrosInfo macroInfo;
            if (!parseMacroDefinition(m, macroName, macroInfo))
               return false;

            forceParseMacroses[macroName] = macroInfo;
            return true;
           }

        CMacroPreprocessorBase(CPrettyCppScannerBase* pos = 0)
           : dontParseMacroses()
           , forceParseMacroses()
           , macroses()
           , conditionStack()
           , curCondition(true)
           //, currentMacro()
           //, currentMacroProcessing()
           , eventBuf()
           , fReady(true)
           , fBuffered(false)
           , bracketDepth(0)
           , pOwnerScanner(pos)
           , pIncludeFinder(0)
           {}

        bool calcCondition() const
           {
            bool res = true;
            std::vector<CCondition>::const_iterator it = conditionStack.begin();
            for(; it!=conditionStack.end(); ++it)
               {
                res = res && it->cond;
               }
            return res;
           }
           

        void setIncludeFinder(IIncludeSearch *pis)
           {
            pIncludeFinder = pis;
           }

    protected:
        /*
        virtual int chainTokenProcessing( const CScannerEvent &evt )
           {
            //events.push_back(evt);
           }
        */
    public:

        const std::vector<CScannerEvent>& getBufferedEvents() const { return eventBuf; }
        virtual ~CMacroPreprocessorBase() {}
        /*
        bool isMacroSC(const CScannerEvent &evt) // Set Current
           {
            bool res = ::isMacro( evt, dontParseMacroses, forceParseMacroses, macroses, &currentMacro);
            if (res) currentMacroProcessing = true;
            return res;
           }

        bool isMacro(const CScannerEvent &evt) const
           {
            return ::isMacro( evt, dontParseMacroses, forceParseMacroses, macroses, 0);
           }

        //void resetCurrentMacro() { currentMacroProcessing = false; }
        */

};



struct CCppScannerOptions
{
    bool dontPreprocess;
    bool noDefaultCppKeywords;

    CCppScannerOptions()
       : dontPreprocess(false)
       , noDefaultCppKeywords(false)
       {}

};



class CPrettyCppScannerBase
{
        friend class CMacroPreprocessorBase;

        std::stack<int>     stateStack;
        int                 stateCode;
        int                 errCode;
        std::string         tokenBuf;
        text_position_t     curPos;
        text_position_t     startPos;

        std::string         currentFileName;

    public:
        CCppScannerOptions  options;


    private:

        CScannerEvent           preprocessorBuf;
        CMacroPreprocessorBase *ppp;
        CScannerErrorContext   *pErrContext;

        std::map<std::string, int>  customKeywords;

        void pushState(int st) 
           { 
            stateStack.push(st);
           }
        
        //-----------------------------------------------------------------------------
        int  popState()
           {
            if (stateStack.empty()) return 1; // NORMAL
            int res = stateStack.top();
            stateStack.pop();
            return res;
           }
        
        //-----------------------------------------------------------------------------
        int  getState()
           {
            if (stateStack.empty()) return 1; // NORMAL
            return stateStack.top();
           }
        
        //-----------------------------------------------------------------------------
        int  getPrevState()
           {
            if (stateStack.empty()) return 1; // NORMAL
            int cur = popState();
            int prev = getState();
            pushState(cur);
            return prev;
           }

        void setStartPos() { startPos = curPos; }
        void incPos()      { curPos.inc(); }
        void incLine()     { curPos.newLine(); }

        int dfa_fn(int ch, int state, int *err);

    protected:
        
        /*
        virtual int analize( int token, 
                             const std::string &text,
                             const text_position_t &startPosition,
                             const text_position_t &curPosition);
        */
        virtual int analize( const CScannerEvent &evt );

        int analizeAux( const CScannerEvent &evt )
           {
            if (options.dontPreprocess)
                return analize( evt );
            if (!ppp)
                return analize( evt );
            
            int res = ppp->put(evt);
            if (res) return res;

            if (ppp->getIgnore())
               return 0;

            if (!ppp->getReady())
               return 0;
            if (!ppp->getBuffered())
               return analize( evt );

            const std::vector<CScannerEvent>& buf = ppp->getBufferedEvents();
            std::vector<CScannerEvent>::const_iterator it = buf.begin();
            for(; it!=buf.end(); ++it)
               {
                int res = analize( *it );
                if (res) return res;
               }
            ppp->clearFlags();
            return 0;
           }

        int analize(int token, const std::string &text)
           {
            // dont translate ident here, make it in child classes
            //isIdentIsCppKeyword(text, token);
            //return analize(token, text, startPos, curPos);
            if (token==LT_PREPROCESSOR_NEXT_LINE)
               {
                if (preprocessorBuf.token==LT_PREPROCESSOR_NEW_LINE)
                   { // ����������� ������������� ��������� �������������
                    preprocessorBuf.text.append(1, '\n');
                    preprocessorBuf.text.append(text);
                    preprocessorBuf.curPos = curPos;
                    return 0;
                   }
                else // ����������� ������������� ��������� �������������
                   { // �� ������ ������ �������������
                    return analizeAux(CScannerEvent(startPos, curPos, LT_PREPROCESSOR, text));
                   }
               }
            else if (token==LT_PREPROCESSOR_NEW_LINE)
               { // ����� ��������� ������������� �� �����
                int res = 0;
                if (preprocessorBuf.token==LT_PREPROCESSOR_NEW_LINE)
                   { // � ������ ���-�� ����
                    res = analizeAux(CScannerEvent(preprocessorBuf.startPos, preprocessorBuf.curPos, LT_PREPROCESSOR, preprocessorBuf.text));
                   }
                 // ��������� ����� � �����
                preprocessorBuf = CScannerEvent(startPos, curPos, token, text);
                return res;
               }
            else // �� ����� ���-�� �������� �� �������������
               {
                int res = 0; // �������� �� ��������� ����������������
                if (preprocessorBuf.token==LT_PREPROCESSOR_NEW_LINE)
                   { // � ������ ���-�� ����
                    res = analizeAux(CScannerEvent(preprocessorBuf.startPos, preprocessorBuf.curPos, LT_PREPROCESSOR, preprocessorBuf.text));
                   }
                preprocessorBuf.token = 0;
                if (res) return res;
               }

            /*
            if (token==LT_PREPROCESSOR) // ������������ - ����������� ��� ��������� ������
               {
                if (preprocessorBuf.token==LT_PREPROCESSOR_NEW_LINE)
                   { // ����������� ������������� ��������� �������������
                    preprocessorBuf.text.append(1, '\n');
                    preprocessorBuf.text.append(text);
                    preprocessorBuf.curPos = curPos;
                   }
                else // ��������� ������
                   {
                    return analize(CScannerEvent(startPos, curPos, token, text));
                   }
               }
            else
               {
                if (token==LT_PREPROCESSOR_NEW_LINE)
                   { // ����� ������
                   
                   
                   }
               }
            

            if (preprocessorBuf.token==LT_PREPROCESSOR_NEW_LINE)
            */

            return analizeAux(CScannerEvent(startPos, curPos, token, text));
           }

        CPrettyCppScannerBase(const CPrettyCppScannerBase &c) 
           : stateStack(),
             stateCode(PRETTY_PRINT_STATE_LINE_START),
             errCode(0),
             tokenBuf(),
             curPos(),
             startPos(),
             currentFileName(),
             options(c.options),
             preprocessorBuf(),
             ppp(c.ppp),
             pErrContext(c.pErrContext),
             customKeywords(c.customKeywords)
           {}

        virtual CPrettyCppScannerBase* clone() const
           {
            return new CPrettyCppScannerBase(*this);
           }

           


    public:

        CPrettyCppScannerBase() 
           : stateStack(),
             stateCode(PRETTY_PRINT_STATE_LINE_START),
             errCode(0),
             tokenBuf(),
             curPos(),
             startPos(),
             currentFileName(),
             options(),
             preprocessorBuf(),
             ppp(0),
             pErrContext(0),
             customKeywords()
           {}

        virtual ~CPrettyCppScannerBase() {}

        void setPreprocessor(CMacroPreprocessorBase *pp)
           {
            if (ppp) 
               delete ppp;
            ppp = pp;
            if (ppp) ppp->pOwnerScanner = this;
           }

        CMacroPreprocessorBase* releasePreprocessor()
           {
            CMacroPreprocessorBase* ret = ppp;
            ppp = 0;
            //ret->pOwnerScanner = 0;
            return ret;
           }


        void setDefaultPreprocessor()
           {
            setPreprocessor(new CMacroPreprocessorBase());
           }

        CMacroPreprocessorBase* getPreprocessor() { return ppp; }

        static CMacroPreprocessorBase* createDefaultPreprocessor() { return new CMacroPreprocessorBase(); }
                                                     
        int getErrorCode() const { return errCode; }

        int getStateCode() { return stateCode; }

        void addCustomKeyword(const std::string &name, int code)
           {
            customKeywords[name] = code;
           }

        bool translateEventBasic(CScannerEvent &evt) const
           {
            if (options.noDefaultCppKeywords) return false;
            return isIdentIsCppKeyword(evt.text, evt.token);
           }

        bool translateEventCustom(CScannerEvent &evt) const
           {
            if (evt.token!=LT_IDENT) return false;
            std::map<std::string, int>::const_iterator it = customKeywords.find(evt.text);
            if (it==customKeywords.end()) return false;
            evt.token = it->second;
            return true;
           }

        bool translateEvent(CScannerEvent &evt) const
           {
            if (evt.token!=LT_IDENT) return false;
            //if (translateEventBasic(evt)) return true;
            //return translateEventCustom(evt);
            if (translateEventCustom(evt)) return true;
            return translateEventBasic(evt);
           }

        void addAliasClass(const std::string &alias)   { addCustomKeyword(alias, LT_KWD_CLASS); }
        void addAliasStruct(const std::string &alias)  { addCustomKeyword(alias, LT_KWD_STRUCT); }
        void addAliasTypedef(const std::string &alias) { addCustomKeyword(alias, LT_KWD_TYPEDEF); }
        void addAliasEnum(const std::string &alias)    { addCustomKeyword(alias, LT_KWD_ENUM); }

        void addCustomAttribute(const std::string &name)    { addCustomKeyword(name, LT_CUSTOM_ATTRIBUTE); }
        void addCustomKeyword(const std::string &name)      { addCustomKeyword(name, LT_CUSTOM_KEYWORD); }
        void addCustomType(const std::string &name)         { addCustomKeyword(name, LT_CUSTOM_TYPE); }
        void addCustomTypeModifier(const std::string &name) { addCustomKeyword(name, LT_CUSTOM_TYPE_MODIFIER); }
        //void addCustom(const std::string &name) { addCustomKeyword(name, ); }

        virtual void setCurrentFile(const std::string &fn)
           {
            currentFileName = fn;
            if (pErrContext) pErrContext->curFile = fn;
           }

        void setErrorContext(CScannerErrorContext *pec) 
           {
            pErrContext = pec;
            if (pErrContext) pErrContext->curFile = currentFileName;
           }

        int put(int ch)
           {
            stateCode = dfa_fn(ch, stateCode, &errCode);
            if (ch=='\n') incLine();
            else          incPos();
            if (stateCode<0 || errCode) return 0;
            return 1;
           }

        void reset()
           {
            stateCode = PRETTY_PRINT_STATE_LINE_START;
           }

        int finalize()
           {
            stateCode = dfa_fn(-1, stateCode, &errCode);
            if (stateCode<0 || errCode) return 0;
            return 1;    
           }

        int getError()
           {
            return errCode;
           }

        static char const* getErrorStr(int err);

        char const* getErrorStr()
           {
            return getErrorStr(errCode);
           }

}; // class CPrettyCppScannerBase


class CTokenVectorBuilder: public CPrettyCppScannerBase
{
        std::vector<CScannerEvent>   &events;

    protected:

        int analize( const CScannerEvent &evt )
           {
            events.push_back(evt);
            return 0;
           }

    public:
        CTokenVectorBuilder(std::vector<CScannerEvent> &evt)
           : CPrettyCppScannerBase()
           , events(evt)
           {}

};


inline
int buildTokenVector(const std::string &text, std::vector<CScannerEvent> &events)
   {
    CTokenVectorBuilder scanner(events);
    //std::string::size_type i=0, size=text.size();
    int res = 0;
    std::string::const_iterator it = text.begin();
    for(; it!=text.end(); ++it)
       {
        res = scanner.put((unsigned char)*it);
        if (!res) break;
       }
    if (res) res = scanner.finalize();
    return res ? int(0) : scanner.getErrorCode();
   }




inline
bool isIdentifierChar(char ch)
   {
    if (ch>='a' && ch<='z') return true;
    if (ch>='A' && ch<='Z') return true;
    if (ch>='0' && ch<='9') return true;
    if (ch=='_') return true;
    return false;
   }

inline
bool isNotIdentifierChar(char ch)
   {
    return !isIdentifierChar(ch);
   }

//int  parseMacroTokensPaste(const std::vector<std::string> &args, const CMacrosInfo &info, std::string &res);
bool isMacro( const CScannerEvent                       &evt,
              const std::set<std::string>               &dontParseMacroses,
              const std::map<std::string, CMacrosInfo>  &forceParseMacroses,
              const std::map<std::string, CMacrosInfo>  &macroses,
              CMacrosInfo *pMi
            );


void stringizeScannerEvents( std::vector<CScannerEvent>::const_iterator evlB
                           , std::vector<CScannerEvent>::const_iterator evlE,
                           std::string &str);
inline
void stringizeScannerEvents(const std::vector<CScannerEvent> &eventList, std::string &str)
   {
    //str.reserve(eventList.size()*8);
    stringizeScannerEvents(eventList.begin(), eventList.end(), str);
   }


int preprocessEvents(std::vector<CScannerEvent>::const_iterator evlB,
                     std::vector<CScannerEvent>::const_iterator evlE,
                     std::vector<CScannerEvent>                 &resEventList,
                     const std::set<std::string>                &dontParseMacroses,
                     const std::map<std::string, CMacrosInfo>   &forceParseMacroses,
                     const std::map<std::string, CMacrosInfo>   &macroses,
                     std::set<std::string>                      &usedMacroses,
                     CScannerErrorContext *pErrContext
                    );

inline
int preprocessEvents(const std::vector<CScannerEvent> &eventList,
                     std::vector<CScannerEvent>       &resEventList,
                     const std::set<std::string>               &dontParseMacroses,
                     const std::map<std::string, CMacrosInfo>  &forceParseMacroses,
                     const std::map<std::string, CMacrosInfo>  &macroses,
                     std::set<std::string>                     &usedMacroses,
                     CScannerErrorContext *pErrContext
                    )
   {
    //resEventList.reserve(eventList.size());
    return preprocessEvents( eventList.begin(), eventList.end(), resEventList, 
                             dontParseMacroses, forceParseMacroses, macroses, usedMacroses, pErrContext );
   }


std::string tokenTextQuote(const std::string &tt);
std::string getTokenTypeName(int toketId);

int getLiteralType(const std::string &literal); // -1 - err, 0 - quoted with apos (char literal), 1 - double quoted (string literal)
std::string literalUnquote(const std::string &literal);
bool isValidCppName(const std::string &s);





#endif /* SCANNER_H */

