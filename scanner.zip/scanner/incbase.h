#ifndef SCANNER_INCBASE_H
#define SCANNER_INCBASE_H

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#include <marty/filesys.h>



struct IIncludeSearchA
{
        virtual
        MARTY_FILESYSTEM_NS handle_t 
        searchForInclude( const std::string &includedFromFile
                        , const std::string &includeFile
                        , std::string &foundFilename
                        ) = 0;
};

struct IIncludeSearchW
{
        virtual
        MARTY_FILESYSTEM_NS handle_t 
        searchForInclude( const std::wstring &includedFromFile
                        , const std::wstring &includeFile
                        , std::wstring &foundFilename
                        ) = 0;
};

#if defined(UNICODE) || defined(_UNICODE)
    #define  IIncludeSearch IIncludeSearchW
#else
    #define  IIncludeSearch IIncludeSearchA
#endif



#endif /* SCANNER_INCBASE_H */

