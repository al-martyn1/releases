#ifndef INCSEARCH_H
#define INCSEARCH_H


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/trim.hpp>


#include <marty/filesys.h>
#include <marty/filename.h>

#ifndef MARTY_STRING
    #define MARTY_STRING(TC) ::std::basic_string<TC>
#endif

#ifndef MARTY_TCSTRING
    #define MARTY_TCSTRING   MARTY_STRING(TC)
#endif


template<typename TC, TC C>
struct splitSemicolonList_isExactChar
{
    bool operator()(TC c) const
       { return c==C; }
};

inline
void splitSemicolonList( const ::std::string& str, ::std::vector<::std::string> &splitted )
   {
    ::boost::algorithm::split(splitted, str, splitSemicolonList_isExactChar<char, ';'>(), boost::algorithm::token_compress_on);
   }

inline
void splitSemicolonList( const ::std::wstring& str, ::std::vector<::std::wstring> &splitted )
   {
    ::boost::algorithm::split(splitted, str, splitSemicolonList_isExactChar<wchar_t, L';'>(), boost::algorithm::token_compress_on);
   }




template <typename TC>
class CIncludeFinder
{

        std::vector< MARTY_TCSTRING >    includeSearchPaths;
    
        template<char C>
        struct isExactChar
        {
            bool operator()(char c) const
               { return c==C; }
        };


    public:

        static const MARTY_FILESYSTEM_NS handle_t hInvalidHandle = MARTY_FILESYSTEM_NS hInvalidHandle;

        CIncludeFinder()
           : includeSearchPaths()
           {}

        MARTY_TCSTRING getPathList() const
           {
            MARTY_TCSTRING res;
            std::vector< MARTY_TCSTRING >::const_iterator it = includeSearchPaths.begin();
            for(; it!=includeSearchPaths.end(); ++it)
               {
                if (it->empty()) continue;
                if (!res.empty()) res.append( 1, (TC)';');
                res.append(*it);
               }
            return res;
           }

        void clearPaths()
           {
            includeSearchPaths.clear();
           }
    
        void addPath(const MARTY_TCSTRING &path)
           {
            includeSearchPaths.push_back(path);
           }
    
        void addPathList(const MARTY_TCSTRING &pathList)
           {
            std::vector< MARTY_TCSTRING > paths;
            ::boost::algorithm::split(paths, pathList, isExactChar<';'>(), boost::algorithm::token_compress_on);
            std::copy(paths.begin(), paths.end(), std::back_inserter(includeSearchPaths) );
           }

        void searchByMask( const MARTY_TCSTRING &mask
                         , std::vector< MARTY_TCSTRING > &foundFiles
                         , std::vector< MARTY_TCSTRING > *pFoundFilesRelativeNames
                         )
           {
            std::vector< MARTY_TCSTRING >::const_iterator it = includeSearchPaths.begin();
            for(; it!=includeSearchPaths.end(); ++it)
               {
                std::vector<MARTY_FILESYSTEM::CFindFileInfo<TC> > matchedFiles;
                MARTY_FILESYSTEM::findFiles( matchedFiles, *it, mask, true );
                std::vector<MARTY_FILESYSTEM::CFindFileInfo<TC> >::const_iterator mit = matchedFiles.begin();
                for(; mit!=matchedFiles.end(); ++mit)
                   {
                    MARTY_TCSTRING fullName = MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME::appendPath(mit->path, mit->file));
                    foundFiles.push_back( fullName );
                    if (pFoundFilesRelativeNames)
                       {
                        MARTY_TCSTRING subPathName;
                        
                        if ( MARTY_FILENAME::subPath( subPathName, MARTY_FILENAME_NS makeCanonical(*it) /* mit->path */ , fullName ))
                           pFoundFilesRelativeNames->push_back(subPathName);
                        else
                           pFoundFilesRelativeNames->push_back(fullName);
                       }
                   }
               }
           }
             // includeSearchPaths

        MARTY_FILESYSTEM_NS handle_t 
        searchForStandartInclude( const MARTY_TCSTRING &includeFile, MARTY_TCSTRING &foundFilename )
           {
            typename std::vector< MARTY_TCSTRING >::const_iterator it = includeSearchPaths.begin();
            for(; it!=includeSearchPaths.end(); ++it)
               {
                MARTY_TCSTRING name = 
                      MARTY_FILENAME_NS makeCanonical(
                                        MARTY_FILENAME_NS appendPath(*it, includeFile)
                                                     );

                MARTY_FILESYSTEM_NS handle_t h =
                      MARTY_FILESYSTEM_NS openFile(name, MARTY_FILESYSTEM_NS o_rdonly);
                if (h!=MARTY_FILESYSTEM_NS hInvalidHandle)
                   {
                    foundFilename = name;
                    return h;
                   }
               }
            return MARTY_FILESYSTEM_NS hInvalidHandle;
           }

        MARTY_FILESYSTEM_NS handle_t 
        searchForUserInclude( const MARTY_TCSTRING &includedFromFile
                            , const MARTY_TCSTRING &includeFile
                            , MARTY_TCSTRING &foundFilename
                            )
           {
            MARTY_TCSTRING basepath = 
                  MARTY_FILENAME_NS getPath(
                                    MARTY_FILENAME_NS makeCanonical( includedFromFile )
                                           );

            MARTY_TCSTRING name = MARTY_FILENAME_NS appendPath(basepath, includeFile);

            if (!MARTY_FILENAME_NS isAbsolutePath(name))
               {
                name = MARTY_FILENAME_NS appendPath(MARTY_FILESYSTEM_NS getCurrentDirectory(), name);
               }

            MARTY_FILESYSTEM_NS handle_t h =
                  MARTY_FILESYSTEM_NS openFile(name, MARTY_FILESYSTEM_NS o_rdonly);
            if (h!=MARTY_FILESYSTEM_NS hInvalidHandle)
               {
                foundFilename = name;
               }

            return h;
           }


        MARTY_FILESYSTEM_NS handle_t 
        searchForInclude( const MARTY_TCSTRING &includedFromFile
                        , const MARTY_TCSTRING &includeFile
                        , MARTY_TCSTRING &foundFilename
                        )
           {
            const TC lb = sizeof(TC)==1 ? '<'  : L'<';
            const TC rb = sizeof(TC)==1 ? '>'  : L'>';
            const TC qu = sizeof(TC)==1 ? '\"' : L'\"';

            typename MARTY_TCSTRING::size_type s = includeFile.size();
            if (s<2) return MARTY_FILESYSTEM_NS hInvalidHandle;

            if (includeFile[0]==lb)
               {
                s--; if (includeFile[s]==rb) s--;
                return searchForStandartInclude(MARTY_TCSTRING(includeFile, 1, s), foundFilename);
               }            
            if (includeFile[0]==qu)
               {
                s--; if (includeFile[s]==qu) s--;
                MARTY_FILESYSTEM_NS handle_t h = searchForUserInclude(includedFromFile, MARTY_TCSTRING(includeFile, 1, s), foundFilename);
                if (h==MARTY_FILESYSTEM_NS hInvalidHandle)
                   {
                    h = searchForStandartInclude(MARTY_TCSTRING(includeFile, 1, s), foundFilename);
                   }
                return h;
               }

            return MARTY_FILESYSTEM_NS hInvalidHandle;
           }


};




#endif /* INCSEARCH_H */

