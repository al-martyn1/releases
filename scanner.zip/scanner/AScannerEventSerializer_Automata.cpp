/* Warning! Automaticaly generated file, do not edit */

#include "AScannerEventSerializer_Automata.h"





namespace scanner {



}; // namespace scanner {

