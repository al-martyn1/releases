 #ifndef PCPPDFA_H
 #define PCPPDFA_H


 /* PRETTY_PRINT States */
 #define  PRETTY_PRINT_STATE_ERROR                  -1
 #define  PRETTY_PRINT_STATE_END                    0
 #define  PRETTY_PRINT_STATE_LINE_START             1
 #define  PRETTY_PRINT_STATE_PREPROCESSOR           2
 #define  PRETTY_PRINT_STATE_PREPROCESSOR_WAIT_CRLF  3
 #define  PRETTY_PRINT_STATE_PREPROCESSOR_NEXT_LINES  4
 #define  PRETTY_PRINT_STATE_PREPROCESSOR_NEXT_LINES_WAIT_CRLF  5
 #define  PRETTY_PRINT_STATE_NORMAL                 6
 #define  PRETTY_PRINT_STATE_WAIT_WIDE_STRING       7
 #define  PRETTY_PRINT_STATE_READ_NUMBER            8
 #define  PRETTY_PRINT_STATE_READ_HEXSTART          9
 #define  PRETTY_PRINT_STATE_READ_HEX               10
 #define  PRETTY_PRINT_STATE_READ_OCT               11
 #define  PRETTY_PRINT_STATE_READ_BIN               12
 #define  PRETTY_PRINT_STATE_READ_FLOAT             13
 #define  PRETTY_PRINT_STATE_READ_FLOAT_EXPONENT    14
 #define  PRETTY_PRINT_STATE_READ_FLOAT_EXPONENT2   15
 #define  PRETTY_PRINT_STATE_READ_FLOAT_EXPONENT3   16
 #define  PRETTY_PRINT_STATE_READ_DQUOT             17
 #define  PRETTY_PRINT_STATE_READ_DQUOT_BS          18
 #define  PRETTY_PRINT_STATE_READ_APOS              19
 #define  PRETTY_PRINT_STATE_READ_APOS_BS           20
 #define  PRETTY_PRINT_STATE_READ_IDENT             21
 #define  PRETTY_PRINT_STATE_READ_DIV               22
 #define  PRETTY_PRINT_STATE_READ_SINGLE_COMMENT    23
 #define  PRETTY_PRINT_STATE_READ_COMMENT           24
 #define  PRETTY_PRINT_STATE_READ_COMMENT_WAIT_END  25
 #define  PRETTY_PRINT_STATE_READ_MULT              26
 #define  PRETTY_PRINT_STATE_READ_EQ                27
 #define  PRETTY_PRINT_STATE_READ_DOT               28
 #define  PRETTY_PRINT_STATE_READ_COLON             29
 #define  PRETTY_PRINT_STATE_READ_PLUS              30
 #define  PRETTY_PRINT_STATE_READ_NOT               31
 #define  PRETTY_PRINT_STATE_READ_AND               32
 #define  PRETTY_PRINT_STATE_READ_MINUS             33
 #define  PRETTY_PRINT_STATE_READ_PTR_ACC           34
 #define  PRETTY_PRINT_STATE_READ_MOD               35
 #define  PRETTY_PRINT_STATE_READ_LESS              36
 #define  PRETTY_PRINT_STATE_READ_LESS_LESS         37
 #define  PRETTY_PRINT_STATE_READ_GREATER           38
 #define  PRETTY_PRINT_STATE_READ_GREATER_GREATER   39
 #define  PRETTY_PRINT_STATE_READ_XOR               40
 #define  PRETTY_PRINT_STATE_READ_OR                41

 #define  PRETTY_PRINT_START_STATE   PRETTY_PRINT_STATE_LINE_START


 /* PRETTY_PRINT Errors */

 /* No error */
 #define  PRETTY_PRINT_ERROR_OK    0

 /* Unknown error */
 #define  PRETTY_PRINT_ERROR_UNKNOWN_ERR    1

 /* The unexpected end of file encountered */
 #define  PRETTY_PRINT_ERROR_ERR_EOF    2

 /* Debug DFA break */
 #define  PRETTY_PRINT_ERROR_ERR_BREAK    3

 /* Token is different with operator literal */
 #define  PRETTY_PRINT_ERROR_ERR_BAD_OPERATOR    4

 /* Unexpected token '%s' reached */
 #define  PRETTY_PRINT_ERROR_ERR_UNEXPECTED_TOKEN    5

 /* Number of arguments passed to macro '%s' mismatch number of arguments in macro definition */
 #define  PRETTY_PRINT_ERROR_ERR_MACRO_ARGS_COUNT_MISMATCH    6

 /* Error in macro '%s' definition - invalid token-pasting (##) or stringizing (#) operation */
 #define  PRETTY_PRINT_ERROR_ERR_TOKEN_PASTING    7

 /* Redifinition of macros '%s' is different from previous definition */
 #define  PRETTY_PRINT_ERROR_ERR_MACRO_REDEF_NOT_IDENTICAL    8

 /* Failed to parsing macro '%s' definition */
 #define  PRETTY_PRINT_ERROR_ERR_MACRO_DEFINITION_PARSING_FAILED    9

 /* Can't find include file '%s' */
 #define  PRETTY_PRINT_ERROR_ERR_CANT_FIND_INCLUDE    10

 /* %s expected an identifier */
 #define  PRETTY_PRINT_ERROR_ERR_IFDEF_EXPECTED_IDENTIFIER    11



 #endif /* PCPPDFA_H */
 // Custom actions goes here
