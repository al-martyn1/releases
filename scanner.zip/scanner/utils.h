#ifndef SCANNER_UTILS_H
#define SCANNER_UTILS_H

// F:\work\cli2\trunk\src\scanner\utils.h


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

namespace scanner{
namespace utils{


std::string prepareMultilineComment(const std::string &text);
std::string prepareSinglelineComment(const std::string &text);

const int comentTypeNone    = 0;
const int comentTypeJavadoc = 1; //   /**     */
const int comentTypeQtdoc   = 2; //   /*!     */
const int comentTypeDoxygen = 3; //   ///

int isSpecialComment(::std::string &text, bool singleLineComment);
void splitStringToWords(const ::std::string &str, ::std::vector< ::std::string> &words, bool preserveLinefeed = true);
::std::string mergeStringFromWords(const ::std::vector< ::std::string> &words);
void splitStringDoxyStyle(const ::std::string &str, ::std::vector< ::std::pair< ::std::string, ::std::string > > &pairs, bool preserveLinefeed = true);
void splitStringDoxyStyle(const ::std::string &str, ::std::vector< ::std::pair< ::std::string, ::std::vector< ::std::string> > > &pairs, bool preserveLinefeed = true);
::std::string mergeDoxyStyleToString(const  ::std::vector< ::std::pair< ::std::string, ::std::string > > &pairs);
::std::string mergeVectorToString(const ::std::vector< ::std::string> &v, char chSep = ' ');

inline
void filtrateLinefeeds(const ::std::vector< ::std::string> &wordsIn, ::std::vector< ::std::string> &wordsOut)
   {
    wordsOut.reserve(wordsIn.size());
    ::std::vector< ::std::string>::const_iterator it = wordsIn.begin();
    for(; it!=wordsIn.end(); ++it)
       {
        if (it->empty() || (*it)==::std::string("\n")) continue;
        wordsOut.push_back(*it);
       }
   }

inline
bool testNeedQuotes( const ::std::string &srcWord, ::std::string &quotedWord)
   {
    bool bNeed = false;
    quotedWord.reserve(srcWord.size());

    ::std::string::size_type i=0, size = srcWord.size();
    for(; i!=size; ++i)
       {
        bool isSpace = (srcWord[i]>0 && srcWord[i]<=' ');
        if (isSpace || srcWord[i]=='\"')
           bNeed = true;
        if (srcWord[i]=='\"')
           quotedWord.append(1, srcWord[i]); // ��������� �������
        quotedWord.append(1, srcWord[i]);
       }
    return bNeed;
   }


}; // namespace scanner
}; // namespace utils


#endif /* SCANNER_UTILS_H */

