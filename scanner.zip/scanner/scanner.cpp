
#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(SCANNER_H)
    #include "scanner.h"
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/trim.hpp>


#if !defined(LEXTYPES_H)
    #include "lextypes.h"
#endif

#if !defined(_IOMANIP_) && !defined(_STLP_IOMANIP) && !defined(__STD_IOMANIP__) && !defined(_CPP_IOMANIP) && !defined(_GLIBCXX_IOMANIP)
    #include <iomanip>
#endif

#if !defined(PCPPDFA_H)
    #include "pcppdfa.h"
#endif


#include <stdio.h>
#include <stdlib.h>

#include "AScannerEventSerializer_Automata.h"



using std::cout;

#define CHECK_OP(opLt, opStr)   \
        case opLt: if (event.text!=opStr) return PRETTY_PRINT_ERROR_ERR_BAD_OPERATOR; \
                   break;


//-----------------------------------------------------------------------------
/*
int CPrettyCppScannerBase::analize(int token, const std::string &text,
                             const text_position_t &startPosition,
                             const text_position_t &curPosition)
*/
int CPrettyCppScannerBase::analize( const CScannerEvent &_event )
   {
    CScannerEvent event = _event;
    switch(event.token)
       {
        CHECK_OP(LT_BLOCK_START         , "{")
        CHECK_OP(LT_BLOCK_END           , "}")
        CHECK_OP(LT_BRACKET_START       , "(")
        CHECK_OP(LT_BRACKET_END         , ")")
        CHECK_OP(LT_INDEX_START         , "[")
        CHECK_OP(LT_INDEX_END           , "]")

        CHECK_OP(LT_DIV                 ,  "/"  )
        CHECK_OP(LT_DIV_ASSIGN          ,  "/=" )
        CHECK_OP(LT_COLON               ,  ":"  )
        CHECK_OP(LT_DOUBLE_COLON        ,  "::" )
        CHECK_OP(LT_DOT                 ,  "."  )
        CHECK_OP(LT_COMMA               ,  ","  )
        CHECK_OP(LT_PLUS                ,  "+"  )
        CHECK_OP(LT_PLUS_PLUS           ,  "++" )
        CHECK_OP(LT_PLUS_ASSIGN         ,  "+=" )
        CHECK_OP(LT_BIN_NOT             ,  "~"  )
        CHECK_OP(LT_BOOL_NOT            ,  "!"  )
        CHECK_OP(LT_NOT_EQ              ,  "!=" )
        CHECK_OP(LT_BIN_AND             ,  "&"  )
        CHECK_OP(LT_BIN_AND_ASSIGN      ,  "&=" )
        CHECK_OP(LT_BOOL_AND            ,  "&&" )
        CHECK_OP(LT_MULT_ASSIGN         ,  "*=" )
        CHECK_OP(LT_MULT                ,  "*"  )
        CHECK_OP(LT_DOT_MULT            ,  ".*" )
        CHECK_OP(LT_PTR_ACC_MULT        ,  "->*")
        CHECK_OP(LT_PTR_ACC             ,  "->" )
        CHECK_OP(LT_MINUS               ,  "-"  )
        CHECK_OP(LT_MINUS_MINUS         ,  "--" )
        CHECK_OP(LT_MINUS_ASSIGN        ,  "-=" )
        CHECK_OP(LT_MOD                 ,  "%"  )
        CHECK_OP(LT_MOD_ASSIGN          ,  "%=" )
        CHECK_OP(LT_LESS                ,  "<"  )
        CHECK_OP(LT_LESS_EQ             ,  "<=" )
        CHECK_OP(LT_SHIFT_LEFT          ,  "<<" )
        CHECK_OP(LT_SHIFT_LEFT_ASSIGN   ,  "<<=")
        CHECK_OP(LT_GREATER             ,  ">"  )
        CHECK_OP(LT_GREATER_EQ          ,  ">=" )
        CHECK_OP(LT_SHIFT_RIGHT         ,  ">>" )
        CHECK_OP(LT_SHIFT_RIGHT_ASSIGN  ,  ">>=")
        CHECK_OP(LT_ASSIGN              ,  "="  )
        CHECK_OP(LT_EQ                  ,  "==" )
        CHECK_OP(LT_BIN_XOR             ,  "^"  )
        CHECK_OP(LT_BIN_XOR_ASSIGN      ,  "^=" )
        CHECK_OP(LT_BIN_OR              ,  "|"  )
        CHECK_OP(LT_BIN_OR_ASSIGN       ,  "|=" )
        CHECK_OP(LT_BOOL_OR             ,  "||" )
        CHECK_OP(LT_QUESTION            ,  "?"  )
        //CHECK_OP()
       };


    isIdentIsCppKeyword(event.text, event.token);



    std::ios_base::fmtflags prevFlags = cout.flags();
    if (event.token==LT_PREPROCESSOR)
       {
        int ppToken = extractPreprocessorDirective(event.text);
        std::string macroName;
        CMacrosInfo macroInfo;
        if (ppToken==LTPP_DEFINE && parseMacroDefinition(event.text, macroName, macroInfo))
           {
            cout<<"#define "<<macroName<<macroInfo<<"\n";
           }
        else
           {
            cout<<"#";
            cout.width(29);
            cout.setf(std::ios_base::left);
            cout<<getPpLexemTypeStr(ppToken);
            cout.flags(prevFlags);
            cout<<": ["<<event.text<<"]\n";
           }
       }
    else
       {
        cout.width(30);
        cout.setf(std::ios_base::left);
        cout<<getLexemTypeStr(event.token);
        cout.flags(prevFlags);
        cout<<": ["<<event.text<<"]\n";
       }


    return 0;
   }

//-----------------------------------------------------------------------------
template<typename Iter>
bool isWS(Iter i)
   {
    std::locale loc = std::locale::classic();
    return std::isspace(*i, loc);
   }

//-----------------------------------------------------------------------------
template<typename Iter>
Iter skipWS(Iter b, Iter e)
   {
    std::locale loc = std::locale::classic();
    while(b!=e && std::isspace(*b, loc)) ++b;
    return b;
   }

template<typename Iter>
Iter skipWSorFirstEq(Iter b, Iter e)
   {
    std::locale loc = std::locale::classic();
    if (b==e) return b;
    if (std::isspace(*b, loc) || *b=='=') ++b;
    while(b!=e && std::isspace(*b, loc)) ++b;
    return b;
   }
template<char C>
struct isExactChar
{
    bool operator()(char c) const
       { return c==C; }
};

//-----------------------------------------------------------------------------
bool parseMacroDefinition(const std::string &mDef, std::string &name, CMacrosInfo &info)
   {
    std::string::const_iterator startIt = skipWS(mDef.begin(), mDef.end());
    if (startIt==mDef.end()) return false;

    std::string::const_iterator it = std::find_if(startIt, mDef.end(), isNotIdentifierChar);
    if (it==mDef.end())
       { // macro without body (empty)
        name = std::string(startIt, it);
        info.haveArgs = false;
        info.text = std::string();
        info.args = std::map<std::string, CMacrosInfo::index_type>();
        return true;
       }

    if (isWS(it) || *it=='=')
       {
        name = std::string(startIt, it);
        info.haveArgs = false;
        //startIt = it;
        it = skipWSorFirstEq(it, mDef.end());
        info.text = std::string(it, mDef.end());
        info.args = std::map<std::string, CMacrosInfo::index_type>();
        return true;
       }

    if (*it!='(') return false;

    name = std::string(startIt, it);

    ++it;
    if (it==mDef.end()) return false;
    startIt = it;
    it = std::find(startIt, mDef.end(), ')');
    if (it==mDef.end()) return false;

    std::vector<std::string> args;
    std::string strToSplit(startIt, it);
    //info.args
    ::boost::algorithm::split(args, strToSplit, isExactChar<','>(), boost::algorithm::token_compress_off);
    ++it;
    //startIt = it;
    //it = skipWSorFirstEq(it, mDef.end());
    startIt = skipWSorFirstEq(it, mDef.end());
    info.haveArgs = true;
    info.text = ::boost::algorithm::trim_copy(std::string(startIt, mDef.end()));

    std::vector<std::string>::iterator ait = args.begin();
    for(; ait!=args.end(); ++ait)
       {
        ::boost::algorithm::trim(*ait);
       }

    if (args.empty() || args.size()==1 && args[0].empty())
       { // args empty
        info.args = std::map<std::string, CMacrosInfo::index_type>();
        return true;
       }

    CMacrosInfo::index_type idx = 0;
    ait = args.begin();
    for(; ait!=args.end(); ++ait, ++idx)
       {
        info.args[*ait] = idx;
       }
    return true;
   }

//-----------------------------------------------------------------------------
bool parseMacroTokensPaste(const std::vector<std::string> &args, const CMacrosInfo &info, std::string &res)
   {
    res.clear();
    res.reserve(info.text.size());
    std::string::const_iterator it = info.text.begin();
    for(; it!=info.text.end(); ++it)
       {
        if (*it!='#') { res.append(1, *it); continue; }
        ++it;
        if (it==info.text.end()) return false;
        if (*it!='#')
           { // lookup end of identifier
            std::string::const_iterator itEnd = std::find_if(it, info.text.end(), isNotIdentifierChar);
            std::map<std::string, CMacrosInfo::index_type>::const_iterator amIt = info.args.find(std::string(it, itEnd));
            if (amIt==info.args.end()) // reference to non-existen parameter
               return false;

            if (amIt->second>=args.size())
               return false; // actual taken params count not match params in macro definition
            res.append(1, '\"');
            res.append(args[amIt->second]);
            res.append(1, '\"');
            it = itEnd;
            --it;
            continue;
           }
        ++it;
        if (it==info.text.end()) return false;

        std::string::const_iterator itEnd = std::find_if(it, info.text.end(), isNotIdentifierChar);
        std::map<std::string, CMacrosInfo::index_type>::const_iterator amIt = info.args.find(std::string(it, itEnd));
        if (amIt==info.args.end()) // reference to non-existen parameter
           return false;

        if (amIt->second>=args.size())
           return false; // actual taken params count not match params in macro definition
        res.append(args[amIt->second]);
        it = itEnd;
        --it;
       }
    return true;
   }

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
bool isMacro( const CScannerEvent                       &evt,
              const std::set<std::string>               &dontParseMacroses,
              const std::map<std::string, CMacrosInfo>  &forceParseMacroses,
              const std::map<std::string, CMacrosInfo>  &macroses,
              CMacrosInfo *pMi
            )
   {
    if (evt.token!=LT_IDENT) return false;

    std::set<std::string>::const_iterator dontIt = dontParseMacroses.find(evt.text);
    if (dontIt!=dontParseMacroses.end())
       return false; // dont process this macro

    std::map<std::string, CMacrosInfo>::const_iterator it = forceParseMacroses.find(evt.text);
    if (it!=forceParseMacroses.end())
       {
        if (pMi) *pMi = it->second;
        return true;       
       }
    it = macroses.find(evt.text);
    if (it!=macroses.end())
       {
        if (pMi) *pMi = it->second;
        return true;       
       }
    return false;
   }

//-----------------------------------------------------------------------------
void stringizeScannerEvents( std::vector<CScannerEvent>::const_iterator evlB
                           , std::vector<CScannerEvent>::const_iterator evlE,
                           std::string &str)
   {
    scanner::CScannerEventSerializator ser;
    ser.resetAutomata( );

    for(; evlB!=evlE; ++evlB)
       {
        ser.putEvent(*evlB);
       }

    ser.eod();
    //return ser.buf;
    str = ser.buf;

    /*
    //str.clear();
    str.reserve(str.size() + (evlE-evlB)*8);
    //std::vector<CScannerEvent>::const_iterator it = eventList.begin();
    bool prevWS = str.empty();
    for(; evlB!=evlE; ++evlB)
       {
        if (LT_IS_COMMENT(evlB->token) || LT_IS_PREPROCESSOR(evlB->token))
           { 
            prevWS = false; 
            continue;
           }
        
        if (LT_IS_WHITESPACE(evlB->token))
           {
            prevWS = true;
            str.append(evlB->text);
            continue;
           }
        if (!prevWS)
           str.append(1, ' ');
        str.append(evlB->text);
        prevWS = false;
       }
    */
   }


int preprocessEvents(std::vector<CScannerEvent>::const_iterator evlB,
                     std::vector<CScannerEvent>::const_iterator evlE,
                     std::vector<CScannerEvent>                 &resEventList,
                     const std::set<std::string>                &dontParseMacroses,
                     const std::map<std::string, CMacrosInfo>   &forceParseMacroses,
                     const std::map<std::string, CMacrosInfo>   &macroses,
                     std::set<std::string>                      &usedMacroses,
                     CScannerErrorContext *pErrContext
                    )
   {
    resEventList.reserve(resEventList.size() + (evlE-evlB));
    //resEventList.reserve(eventList.size());
    CMacrosInfo foundMacro;
    std::string foundMacroName;
    //std::vector<CScannerEvent>::const_iterator b = eventList.begin();
    while(evlB!=evlE)
       {
        for(; evlB!=evlE; ++evlB)
           {
            if (pErrContext) pErrContext->pos = evlB->curPos;

            if (evlB->token!=LT_IDENT) 
               { // simple copy non-ident
                resEventList.push_back(*evlB);
                continue;
               }

            if (usedMacroses.find(evlB->text)!=usedMacroses.end())
               { // name found in allready used macroses
                resEventList.push_back(*evlB);
                continue;
               }

            if (!isMacro(*evlB, dontParseMacroses, forceParseMacroses, macroses, &foundMacro))
               { // not a macro
                resEventList.push_back(*evlB);
                continue;
               }
            // found macro
            break;
           }

        if (evlB==evlE) return 0;
        foundMacroName = evlB->text;
        evlB++; // jump to next token

        if (!foundMacro.haveArgs)
           {
            usedMacroses.insert(foundMacroName);
            std::vector<CScannerEvent> macroTextEvents;
            macroTextEvents.reserve(32);
            int bres = buildTokenVector(foundMacro.text, macroTextEvents);
            if (bres) return bres;
            std::vector<CScannerEvent> resMacroTextEvents;
            bres = preprocessEvents( macroTextEvents.begin()
                                   , macroTextEvents.end()
                                   , resMacroTextEvents
                                   , dontParseMacroses
                                   , forceParseMacroses
                                   , macroses
                                   , usedMacroses
                                   , pErrContext );
            if (bres) return bres;

            std::copy(resMacroTextEvents.begin(), resMacroTextEvents.end(), std::back_inserter(resEventList) );
           }
        else
           {
            int bracketDepth = 0;
            for(; evlB!=evlE; ++evlB)
               {
                if (LT_IS_WHITESPACE(evlB->token)) continue;
                if (evlB->token!=LT_BRACKET_START) 
                   {
                    if (pErrContext)
                        pErrContext->text1 = evlB->token;
                    return PRETTY_PRINT_ERROR_ERR_UNEXPECTED_TOKEN;
                   }
                bracketDepth++;
                break;
               }

            if (evlB==evlE) 
               {
                if (pErrContext)
                    pErrContext->text1 = foundMacroName;
                return PRETTY_PRINT_ERROR_ERR_MACRO_ARGS_COUNT_MISMATCH;
               }
            evlB++; // jump to next token
            if (evlB==evlE) 
               {
                if (pErrContext)
                    pErrContext->text1 = foundMacroName;
                return PRETTY_PRINT_ERROR_ERR_MACRO_ARGS_COUNT_MISMATCH;
               }
            
            // found opening bracket
            std::vector<std::string> args;
            args.reserve(foundMacro.args.size());
            std::vector<CScannerEvent> curArg;

            std::vector< std::vector<CScannerEvent> > argsAsEvents;
            argsAsEvents.reserve(foundMacro.args.size());

            curArg.reserve(16);
            for(;evlB!=evlE; ++evlB)
               {
                if (evlB->token==LT_COMMA && bracketDepth==1)
                   {
                    std::string strArg;
                    stringizeScannerEvents(curArg, strArg);
                    args.push_back(strArg);
                    argsAsEvents.push_back(curArg);
                    curArg.clear();
                    continue;
                   }

                if (evlB->token==LT_BRACKET_START)
                   {
                    bracketDepth++;
                    curArg.push_back(*evlB);
                    continue;
                   }

                if (evlB->token==LT_BRACKET_END)
                   {
                    bracketDepth--;
                    if (bracketDepth<=0)
                       {
                        break; // end bracket reached
                       }
                    curArg.push_back(*evlB);
                    continue;
                   }
                curArg.push_back(*evlB);
               }
            if (evlB==evlE) 
               {
                if (pErrContext)
                    pErrContext->text1 = foundMacroName;
                return PRETTY_PRINT_ERROR_ERR_MACRO_ARGS_COUNT_MISMATCH;
               }
            evlB++; // jump to next token

            // need to preprocess curArg
               { // std::vector<CScannerEvent> curArg;
                std::set<std::string>          usedMacrosesCopy = usedMacroses;
                std::vector<CScannerEvent>     curArgParsed;
                int curArgPpRes = preprocessEvents( curArg.begin()
                                                  , curArg.end()
                                                  , curArgParsed
                                                  , dontParseMacroses
                                                  , forceParseMacroses
                                                  , macroses
                                                  , usedMacrosesCopy
                                                  , pErrContext
                                                  );
                if (curArgPpRes) return curArgPpRes;
                curArgParsed.swap(curArg);
               }

            std::string strArg;
            stringizeScannerEvents(curArg, strArg);
            args.push_back(strArg);
            argsAsEvents.push_back(curArg);

            std::string pastedText;
            bool mtpRes = parseMacroTokensPaste(args, foundMacro, pastedText);
            if (!mtpRes)
               {
                if (pErrContext)
                    pErrContext->text1 = foundMacroName;
                return PRETTY_PRINT_ERROR_ERR_TOKEN_PASTING;
               }

            usedMacroses.insert(foundMacroName);
            std::vector<CScannerEvent> macroTextEvents;
            macroTextEvents.reserve(32);
            int bres = buildTokenVector(pastedText, macroTextEvents);
            if (bres) return bres;

            std::vector<CScannerEvent> macroTextEventsSubsted;
            macroTextEventsSubsted.reserve(macroTextEvents.size());

            std::vector<CScannerEvent>::const_iterator mteIt = macroTextEvents.begin();
            for(; mteIt!=macroTextEvents.end(); ++mteIt)
               {
                std::map<std::string, CMacrosInfo::index_type>::const_iterator ait = foundMacro.args.find(mteIt->text);
                if (ait==foundMacro.args.end())
                   { // not an arg
                    macroTextEventsSubsted.push_back(*mteIt);
                    continue;
                   }

                if (ait->second>=argsAsEvents.size())
                   {
                    if (pErrContext)
                        pErrContext->text1 = foundMacroName;
                    return PRETTY_PRINT_ERROR_ERR_MACRO_ARGS_COUNT_MISMATCH;
                   }

                std::copy(argsAsEvents[ait->second].begin(), argsAsEvents[ait->second].end(), std::back_inserter(macroTextEventsSubsted) );
               }

            std::vector<CScannerEvent> resMacroTextEvents;
            bres = preprocessEvents( macroTextEventsSubsted.begin()
                                   , macroTextEventsSubsted.end()
                                   , resMacroTextEvents
                                   , dontParseMacroses
                                   , forceParseMacroses
                                   , macroses
                                   , usedMacroses
                                   , pErrContext );
            if (bres) return bres;
            std::copy(resMacroTextEvents.begin(), resMacroTextEvents.end(), std::back_inserter(resEventList) );
            //std::vector<CScannerEvent>::const_iterator
           }
       }
    return 0;
   }


//-----------------------------------------------------------------------------
int CMacroPreprocessorBase::put(const CScannerEvent &_evt)
   {
    fIgnore = false;
    if (!fReady)
       {
        if (_evt.token==LT_BRACKET_START)
           {
            bracketDepth++;
            // fBuffered = true; // dont needed at this state
            // fReady = false; // dont touch
            eventBuf.push_back(_evt);
            return 0;
           }
        if (_evt.token==LT_BRACKET_END)
           {
            bracketDepth--;
            eventBuf.push_back(_evt);
            if (bracketDepth<=0)
               {
                // TODO: process buffered data here
                std::vector<CScannerEvent> resEventList;
                std::set<std::string> usedMacroses;
                int res = preprocessEvents( eventBuf, resEventList, 
                                            dontParseMacroses, forceParseMacroses, 
                                            macroses, usedMacroses, 
                                            (pOwnerScanner ? pOwnerScanner->pErrContext : 0)
                                          );
                if (res) return res;
                eventBuf.swap(resEventList);
                fBuffered = true;
                fReady    = true;
                bracketDepth = 0;
               }
            return 0;
           }
        // other tokens simply buffered
        eventBuf.push_back(_evt);
        return 0;
       }

    CScannerEvent evt = _evt;
    if (evt.token==LT_PREPROCESSOR)
       {
        int ppToken = extractPreprocessorDirective(evt.text);

        //if (!conditionStack.empty() && !conditionStack.top().cond)
        if((ppToken==LTPP_IFDEF  ||
            ppToken==LTPP_IFNDEF ||
            ppToken==LTPP_ELSE   ||
            /*ppToken==LTPP_ELIF   ||*/
            ppToken==LTPP_ENDIF)
          && options.parseIfdef)
          {
           if (ppToken==LTPP_IFDEF || ppToken==LTPP_IFNDEF)
              {
               std::string macroName = ::boost::algorithm::trim_copy(evt.text);
               if (macroName.empty())
                  {
                   if (pOwnerScanner && pOwnerScanner->pErrContext)
                      {
                       pOwnerScanner->pErrContext->pos   = evt.curPos;
                       pOwnerScanner->pErrContext->text1 = "#if[n]def";
                      }
                   return PRETTY_PRINT_ERROR_ERR_IFDEF_EXPECTED_IDENTIFIER;
                  }
               
               bool bFound = macroses.find(macroName)!=macroses.end();
               conditionStack.push_back(CCondition(((ppToken==LTPP_IFDEF) ? bFound : !bFound), csWaitElse, evt.filenameId, evt.startPos ));
               curCondition = calcCondition();
               fIgnore = true;
               return 0;
              }
           if (ppToken==LTPP_ELSE)
              {
               //PRETTY_PRINT_ERROR_ERR_UNEXPECTED_TOKEN
               if (conditionStack.empty() || conditionStack.back().state!=csWaitElse)
                  {
                   if (pOwnerScanner && pOwnerScanner->pErrContext)
                      {
                       pOwnerScanner->pErrContext->pos   = evt.startPos; //evt.curPos;
                       pOwnerScanner->pErrContext->text1 = "#else";
                      }
                   return PRETTY_PRINT_ERROR_ERR_UNEXPECTED_TOKEN;
                  }
               conditionStack.back().cond  = !conditionStack.back().cond;
               conditionStack.back().state = csWaitEndif;
               fIgnore = true;
               curCondition = calcCondition();
               return 0;
              }
           if (ppToken==LTPP_ENDIF)
              {
               if (conditionStack.empty())
                  {
                   if (pOwnerScanner && pOwnerScanner->pErrContext)
                      {
                       pOwnerScanner->pErrContext->pos   = evt.startPos; //evt.curPos;
                       pOwnerScanner->pErrContext->text1 = "#endif";
                      }
                   return PRETTY_PRINT_ERROR_ERR_UNEXPECTED_TOKEN;
                  }
               conditionStack.pop_back();
               fIgnore = true;
               curCondition = calcCondition();
               return 0;
              }
          }


        if (!curCondition)
           {
            fIgnore = true;
            return 0;
           }

        if ((ppToken==LTPP_DEFINE || ppToken==LTPP_UNDEF) && options.parseDefines)
           {
            std::string macroName;
            CMacrosInfo macroInfo;
            if (ppToken==LTPP_DEFINE)
               {
                if (!parseMacroDefinition(evt.text, macroName, macroInfo))
                   {
                    if (pOwnerScanner && pOwnerScanner->pErrContext)
                       {
                        pOwnerScanner->pErrContext->pos   = evt.curPos;
                        pOwnerScanner->pErrContext->text1 = macroName;
                       }
                    return PRETTY_PRINT_ERROR_ERR_MACRO_DEFINITION_PARSING_FAILED;
                   }
               }
            else // undef
               {
                macroName = ::boost::algorithm::trim_copy(evt.text);
                if (macroName.empty())
                   {
                    if (pOwnerScanner && pOwnerScanner->pErrContext)
                       {
                        pOwnerScanner->pErrContext->pos   = evt.curPos;
                        pOwnerScanner->pErrContext->text1 = "#undef";
                       }
                    return PRETTY_PRINT_ERROR_ERR_IFDEF_EXPECTED_IDENTIFIER;
                   }
                //return PRETTY_PRINT_ERROR_ERR_IFDEF_EXPECTED_IDENTIFIER;
               }

            std::map<std::string, CMacrosInfo>::iterator it = macroses.find(macroName);
            if (ppToken==LTPP_DEFINE && it!=macroses.end())
               {
                if (pOwnerScanner && pOwnerScanner->pErrContext)
                   {
                    pOwnerScanner->pErrContext->pos   = evt.curPos;
                    pOwnerScanner->pErrContext->text1 = macroName;
                   }
                return PRETTY_PRINT_ERROR_ERR_MACRO_REDEF_NOT_IDENTICAL;
               }
            /*
            if (ppToken==LTPP_UNDEF && it==macroses.end())
               {
                //ERR_IFDEF_EXPECTED_IDENTIFIER
               }
            */
            if (ppToken==LTPP_DEFINE)
               macroses[macroName] = macroInfo;
            else
               {
                // non-existence of macro name don't produce any error messages
                if (it!=macroses.end()) macroses.erase(it);
               }

            fIgnore = true;
            return 0;
           }

        if (ppToken==LTPP_INCLUDE /*  && options.parseIncludes */ )
           {
            // TODO: need to preprocess expression
            std::string includeExpr = ::boost::algorithm::trim_copy(evt.text);
            bool fUserInclude = (!includeExpr.empty() && includeExpr[0]!='<');

            if ((fUserInclude && options.parseUserIncludes) || (!fUserInclude && options.parseIncludes))
               {
                if (pIncludeFinder && pOwnerScanner)
                   {
                    std::string foundFilename;
                    MARTY_FILESYSTEM_NS handle_t hFoundFile = pIncludeFinder->searchForInclude( 
                                                                              pOwnerScanner->currentFileName,
                                                                              includeExpr,
                                                                              foundFilename   );
                    if (hFoundFile==MARTY_FILESYSTEM_NS hInvalidHandle) 
                       {
                        if (pOwnerScanner && pOwnerScanner->pErrContext)
                           {
                            pOwnerScanner->pErrContext->pos   = evt.curPos;
                            pOwnerScanner->pErrContext->text1 = ::boost::algorithm::trim_copy(evt.text);
                           }
                        return PRETTY_PRINT_ERROR_ERR_CANT_FIND_INCLUDE;
                       }
    
                    CPrettyCppScannerBase *pScanner = pOwnerScanner->clone();
                    CPrettyCppScannerBase *pSavedOwner = pOwnerScanner;
    
                    pScanner->releasePreprocessor();
                    pScanner->setPreprocessor(this);
                    pScanner->setCurrentFile(foundFilename);
    
                    char buf[4096];
                    int readed = MARTY_FILESYSTEM_NS readFile(hFoundFile, buf, sizeof(buf));
                    while(readed>0)
                       {
                        for(int i=0; i<readed; ++i)
                           {
                            unsigned char ch = (unsigned char)buf[i];
                            if (ch==0xFF) ch = 0xDF; // bug with russian small YA - switch to capital YA
                            if (!pScanner->put((unsigned char)ch))
                               {
                                pSavedOwner->errCode = pScanner->getError();
                                MARTY_FILESYSTEM_NS closeFile(hFoundFile);
                                pScanner->releasePreprocessor();
                                pOwnerScanner = pSavedOwner;
    
                                return pSavedOwner->errCode;
                                //std::cerr<<"Error: "<<scanner.getError()<<" - "<<scanner.getErrorStr()<<"\n";
                                //return 2;
                               }
                           }
                        readed = MARTY_FILESYSTEM_NS readFile(hFoundFile, buf, sizeof(buf));
                       }
            
                    pScanner->finalize();
                    MARTY_FILESYSTEM_NS closeFile(hFoundFile);
    
                    pScanner->releasePreprocessor();
                    //pSavedOwner->setPreprocessor(this);
                    pOwnerScanner = pSavedOwner;
    
                    delete pScanner;
                   }
                fIgnore = true;
                return 0;
               }
           }

        fBuffered = false;
        fReady    = true; // owner (client) can process this token without touching pp buffer
        return 0;
       }

    if (!curCondition)
       {
        fIgnore = true;
        return 0;
       }


    CMacrosInfo foundMacro;
    std::string foundMacroName;

    if (!isMacro(evt, dontParseMacroses, forceParseMacroses, macroses, &foundMacro))
       { // not a macro
        fBuffered = false;
        fReady    = true; // owner (client) can process this token without touching pp buffer
        return 0;
       }

    eventBuf.push_back(_evt);

    if (!foundMacro.haveArgs)
       {
        std::vector<CScannerEvent> resEventList;
        std::set<std::string> usedMacroses;
        int res = preprocessEvents( eventBuf, resEventList, 
                                    dontParseMacroses, forceParseMacroses, 
                                    macroses, usedMacroses,
                                    (pOwnerScanner ? pOwnerScanner->pErrContext : 0)
                                  );
        if (res) return res;
        eventBuf.swap(resEventList);
        fBuffered = true;
        fReady    = true;
       }
    else
       {
        fBuffered = true;
        fReady    = false;       
       }
    return 0;
   }


#ifndef WIN32
    #ifndef _sprintf
        #define _sprintf sprintf
        #define _snprintf snprintf
        #define __scanner_undef_sprintf
    #endif
#endif

std::string CScannerErrorContext::formatFilePos(const std::string &filename, int line, int pos)
   {
    char buf[4096];
    _snprintf(buf, sizeof(buf)/sizeof(buf[0]), "%s:%d:%d", filename.c_str(), line+1, pos+1);
    return std::string(buf);
   }

std::string CScannerErrorContext::formatFilePos(const std::string &filename, text_position_t pos)
   {
    return formatFilePos(filename, pos.line, pos.pos);
   }


std::string CScannerErrorContext::formatErrorPrefix(int err)
   {
    char buf[4096];
    //_snprintf(buf, sizeof(buf)/sizeof(buf[0]), "Error %d - %s:%d:%d - ", err, curFile.c_str(), pos.line+1, pos.pos+1);
    //return std::string(buf);
    _snprintf(buf, sizeof(buf)/sizeof(buf[0]), "Error %d - ", err/*, curFile.c_str(), pos.line+1, pos.pos+1*/);
    return std::string(buf) + formatFilePos(curFile, pos) + std::string(" - ");
   }

std::string CScannerErrorContext::formatError(int err)
   {
    char buf[4096];
    //_snprintf(buf, sizeof(buf)/sizeof(buf[0]), "Error %d - %s:%d:%d - ", err, curFile.c_str(), pos.line+1, pos.pos+1);
    //std::string res = buf;
    std::string res = formatErrorPrefix(err);

    if (err==PRETTY_PRINT_ERROR_ERR_UNEXPECTED_TOKEN || 
        err==PRETTY_PRINT_ERROR_ERR_MACRO_ARGS_COUNT_MISMATCH ||
        err==PRETTY_PRINT_ERROR_ERR_CANT_FIND_INCLUDE ||
        err==PRETTY_PRINT_ERROR_ERR_IFDEF_EXPECTED_IDENTIFIER ||
        err==PRETTY_PRINT_ERROR_ERR_TOKEN_PASTING ||
        err==PRETTY_PRINT_ERROR_ERR_MACRO_REDEF_NOT_IDENTICAL ||
        err==PRETTY_PRINT_ERROR_ERR_MACRO_DEFINITION_PARSING_FAILED // ||
       )
       {
        _snprintf(buf, sizeof(buf)/sizeof(buf[0]), CPrettyCppScannerBase::getErrorStr(err), text1.c_str());
        res.append(buf);
       }
    else
       {
        res.append(CPrettyCppScannerBase::getErrorStr(err));
       }

    return res;

    // else if (err==)
    //    {
    //    }
    //CPrettyCppScannerBase::getErrorStr
   }


#ifdef __scanner_undef_sprintf
    #undef __scanner_undef_sprintf
    #undef _sprintf
    #undef _snprintf
#endif


inline
bool isAlpha(char ch)
   {
    if (ch>='a' && ch<='z') return true;
    if (ch>='A' && ch<='Z') return true;
    return false;
   }

inline
bool isDigit(char ch)
   {
    if (ch>='0' && ch<='9') return true;
    return false;
   }

bool isValidCppName(const std::string &s)
   {
    std::string::const_iterator it = s.begin();
    if (it==s.end()) return false;

    if (*it!='_' && !isAlpha(*it)) return false;

    for(; it!=s.end(); ++it)
       if (*it!='_' && !isAlpha(*it) && !isDigit(*it)) return false;

    return true;
   }

int getLiteralType(const std::string &literal)
   {
    if (literal.empty()) return -1;
    if (literal[0]=='\'') return 0;
    return 1;
   }

std::string literalUnquote(const std::string &literal)
   {
    if (literal.empty()) return std::string();
    if (literal.size()<2) return literal;
    return std::string(literal, 1, literal.size()-2);
   }

std::string tokenTextQuote(const std::string &tt)
   {
    if (tt.empty()) return std::string("\"\"");
    if (tt[0]=='\"' || tt[0]=='\'') return tt;
    return std::string(1, '\"') + tt + std::string(1, '\"');
   }

std::string getTokenTypeName(int tokenId)
   {
    if (tokenId==LT_IDENT)
       return std::string("identifier");

    if (LT_IS_A(tokenId, LTF_CUSTOM_TYPE) || LT_IS_A(tokenId, LTF_BASE_TYPE))
       return std::string("type");

    if (LT_IS_A(tokenId, LTF_CUSTOM_TYPE_MODIFIER) || LT_IS_A(tokenId, LTF_BASE_TYPE_MODIFIER))
       return std::string("type modifier");
       
    if (LT_IS_A(tokenId, LTF_CUSTOM_ATTRIBUTE) || LT_IS_A(tokenId, LTF_ATTRIBUTE))
       return std::string("attribute");

    if (LT_IS_A(tokenId, LTF_CUSTOM_KEYWORD) || LT_IS_A(tokenId, LTF_KEYWORD))
       return std::string("keyword");

    /* if (LT_IS_A(tokenId, ) || LT_IS_A(tokenId, ))
     *    return std::string("")
     */

    if (LT_IS_A(tokenId, LTF_PAIR))
       {
        if (LT_IS_A(tokenId, LTF_BEGIN))
           return std::string("opening");
        else
           return std::string("closing");
       }

    if (LT_IS_A(tokenId, LTF_OPERATOR))
       return std::string("operator");

    if (LT_IS_A(tokenId, LTF_STATEMENT))
       return std::string("statement");

    if (LT_IS_A(tokenId, LTF_STRING_LITERAL))
       return std::string("literal constant");

    if (LT_IS_A(tokenId, LTF_NUMBER))
       return std::string("numeric constant");

    if (tokenId==LT_OPERATOR_END)
       return std::string("semicolon");

    if (tokenId==LT_OPERATOR_END)
       return std::string("semicolon");

    if (LT_IS_A(tokenId, LTF_WHITESPACE))
       return std::string("whitespace");

    if (LT_IS_A(tokenId, LTF_COMMENT))
       return std::string("comment");

    if (LT_IS_A(tokenId, LTF_PREPROCESSOR))
       return std::string("preprocessor directive");

    /* if (LT_IS_A(tokenId, ))
     *    return std::string("")
     *  
     */
    //return std::string("<unknown>");
    return std::string("identifier");
   }




