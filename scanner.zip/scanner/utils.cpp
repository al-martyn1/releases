#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif


#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/split.hpp>


#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif


//using namespace ::boost::algorithm;

inline
bool is_lfchar(char ch)
   {
    return ch=='\n';
   }


#include "utils.h"

namespace scanner{
namespace utils{

using namespace ::std;
using namespace ::boost::algorithm;

inline
double calcCharOccurencePercent(const std::string &text, char ch)
   {
    if (!text.size()) return 0;
    return double(count_if(text.begin(), text.end(), bind2nd(equal_to<char>(), ch))) / double(text.size()) * 100.0;
   }



//-----------------------------------------------------------------------------
int isSpecialComment(std::string &text, bool singleLineComment)
   {
    const double maxOccurenceLimit = 20.0;
    //unsigned mcount = count_if(text.begin(), text.end(), bind2nd(less<char>(), '*'));
    //unsigned scount = count_if(text.begin(), text.end(), bind2nd(less<char>(), '/'));
    //if ()
    /*
    if (!singleLineComment && ::boost::algorithm::starts_with(text, std::string("*")))
       {
        text.erase(std::string::size_type(0), std::string::size_type(1));
        ::boost::algorithm::trim(text);
        return comentTypeJavadoc;
       }
    */
    if (!singleLineComment)
       { // multiline comment
        if (!text.empty() && (text[0]=='*' || text[0]=='!'))
           {
            if (calcCharOccurencePercent(text, '*') > maxOccurenceLimit || 
                calcCharOccurencePercent(text, '!') > maxOccurenceLimit ||
                calcCharOccurencePercent(text, '-') > maxOccurenceLimit)
                return comentTypeNone;

            char ch = text[0];
            text.erase(std::string::size_type(0), std::string::size_type(1));
            ::boost::algorithm::trim(text);
            if (ch=='*') return comentTypeJavadoc;
            else         return comentTypeQtdoc;
           }
       }
    else
       { // single line comment
        if (!text.empty() && (text[0]=='/' || text[0]=='!'))
           {
            if (calcCharOccurencePercent(text, '/') > maxOccurenceLimit || 
                calcCharOccurencePercent(text, '!') > maxOccurenceLimit ||
                calcCharOccurencePercent(text, '-') > maxOccurenceLimit)
                return comentTypeNone;

            char ch = text[0];
            text.erase(std::string::size_type(0), std::string::size_type(1));
            ::boost::algorithm::trim(text);
            if (ch=='/') return comentTypeDoxygen;
            else         return comentTypeQtdoc;
           }
        /*
        if (calcCharOccurencePercent(text, '*') > 30.0)
           {
            //std::cout<<"Percent too much, *\n";
            return comentTypeNone;
           }
        if (calcCharOccurencePercent(text, '/') > 30.0)
           {
            //std::cout<<"Percent too much, /\n";
            return comentTypeNone;
           }
        if (calcCharOccurencePercent(text, '-') > 30.0)
           {
            //std::cout<<"Percent too much, -\n";
            return comentTypeNone;
           }
        if (calcCharOccurencePercent(text, '!') > 30.0)
           {
            //std::cout<<"Percent too much, !\n";
            return comentTypeNone;
           }

        if (::boost::algorithm::starts_with(text, std::string("/")))
           {
            text.erase(std::string::size_type(0), std::string::size_type(1));
            ::boost::algorithm::trim_left(text);
            return comentTypeDoxygen;
           }
        */
       }
    return comentTypeNone;
   }

//-----------------------------------------------------------------------------
std::string prepareMultilineComment(const std::string &text)
   {
    std::string textCopy = ::boost::algorithm::trim_copy(text);
    if (::boost::algorithm::starts_with(textCopy, std::string("/*")))
       {
        textCopy.erase(std::string::size_type(0), std::string::size_type(2));
       }
    if (::boost::algorithm::ends_with(textCopy, std::string("*/")))
       {
        textCopy.erase(textCopy.size()-2, std::string::size_type(2));
       }

    std::vector<std::string> lines;
    ::boost::algorithm::split(lines, textCopy, is_lfchar, boost::algorithm::token_compress_off);

    textCopy.clear();

    std::vector<std::string>::iterator lit = lines.begin();
    if (lit!=lines.end()) 
       {
        textCopy.append(*lit);
        ++lit; // skip first line - may be it is javadoc style
       }
    for(; lit!=lines.end(); ++lit)
       {
        ::boost::algorithm::trim(*lit);        

        //if (lit!=lines.begin())
        //   {
        //    if (::boost::algorithm::starts_with(*lit, std::string("*")))
        if (!lit->empty() && ((*lit)[0]=='*'  /* || (*lit)[0]=='!' */ ))
               {
                lit->erase(std::string::size_type(0), std::string::size_type(1));
                ::boost::algorithm::trim_left(*lit);
               }
        //   }

        //if (!textCopy.empty() && *(textCopy.rbegin())!=' ') textCopy.append(1, ' ');
        if (!textCopy.empty()) textCopy.append(1, '\n');
        textCopy.append(*lit);
       }
    //std::
    return textCopy;
   }

//-----------------------------------------------------------------------------
std::string prepareSinglelineComment(const std::string &text)
   {
    std::string textCopy = ::boost::algorithm::trim_copy(text);

    if (::boost::algorithm::starts_with(textCopy, std::string("//")))
       {
        //std::cout<<"SLC starts with //\n";
        textCopy.erase(std::string::size_type(0), std::string::size_type(2));
       }
    else
       {
        //std::cout<<"SLC NOT starts with //\n";
       }
    return textCopy;
    //return ::boost::algorithm::trim_copy(textCopy);
   }

//-----------------------------------------------------------------------------
void splitStringToWords(const ::std::string &str, ::std::vector< ::std::string> &words, bool preserveLinefeed)
   {
    ::std::string curWord;
    ::std::string::const_iterator it = str.begin();
    bool inQuot   = false;
    bool prevQuot = false;

    for(; it!=str.end(); ++it)
       {
        bool isQuot = (*it=='\"');
        if (isQuot)
           {
            if (!inQuot) 
               { // �� � ������������ ������
                inQuot = true;
                //curWord.append(1, *it); ������� �� ������ � �����
                continue;
               }
            else // ������� ���������� � ������������ ������
               {
                if (prevQuot)
                   { // ���������� - ����� ������� - ������������� ������� ������������ � ����
                    prevQuot = false;
                    curWord.append(1, *it);
                    continue;
                   }
                else
                   { // ���������� ������ � ���� ��������� �������
                    prevQuot = true;
                    continue;
                   }
               }
           }

        if (prevQuot)
           {
            if (!inQuot) 
               { // 
                *((int*)0) = 0; // ����� �� ����� ���� �������,���� �������� - �� ���-�� ������
               }
            else
               { // ���������� ������ - �������, � ������� - ���, � �� ���������� � ������������ ������
                prevQuot = false;
                inQuot = false;
               }
           }


        bool isSpace = (*it>0 && *it<=' ');
        
        if (isSpace && !inQuot)
           {
            if (!curWord.empty()) 
               {
                words.push_back(curWord);
                curWord.clear();
               }
            if (*it=='\n' && preserveLinefeed) words.push_back(::std::string(1, '\n'));
           }
        else
           {
            curWord.append(1, *it);
           }
       }
    if (!curWord.empty()) 
       {
        words.push_back(curWord);
        curWord.clear();
       }
   }

//-----------------------------------------------------------------------------
::std::string mergeStringFromWords(const ::std::vector< ::std::string> &words)
   {
    ::std::string res;
    ::std::vector< ::std::string>::const_iterator it = words.begin();
    for(; it!=words.end(); ++it)
       {
        if (!res.empty() && res[res.size()-1]!='\n' && *it!=::std::string("\n")) res.append(1, ' ');
        ::std::string word;
        if (testNeedQuotes(*it, word))
           {
            res.append(1, '\"');
            res.append(word);
            res.append(1, '\"');
           }
        else
           {
            res.append(word);
           }
        //res.append(*it);
       }
    return res;
   }

//-----------------------------------------------------------------------------
void splitStringDoxyStyle(const ::std::string &str, ::std::vector< ::std::pair< ::std::string, ::std::vector< ::std::string> > > &pairs, bool preserveLinefeed)
   {
    ::std::vector< ::std::string> words;
    splitStringToWords(str, words, preserveLinefeed);

    ::std::vector< ::std::string> curWords;
    ::std::string doxyTag;

    ::std::vector< ::std::string>::iterator wit = words.begin();
    for(; wit!=words.end(); ++wit)
       {
        if (wit->empty()) continue;

        bool isDoxyTag = false;
        if ((*wit)[0]=='\\')
           {
            if (wit->size()>1 && (*wit)[1]=='\\')
               { // shielded slash
                wit->erase(::std::string::size_type(0), ::std::string::size_type(1));
               }
            else
               {
                isDoxyTag = true;
               }
           }
        if (!isDoxyTag)
           {
            curWords.push_back(*wit);
            continue;
           }

        if (!doxyTag.empty() || !curWords.empty())
           {
            pairs.push_back( ::std::make_pair(doxyTag, curWords) );
            //doxyTag.erase(::std::string::size_type(0), ::std::string::size_type(1));
            curWords.erase(curWords.begin(), curWords.end());
           }
        doxyTag = *wit;
       }

    if (!doxyTag.empty() || !curWords.empty())
       {
        pairs.push_back( ::std::make_pair(doxyTag, curWords) );
       }
   }

//-----------------------------------------------------------------------------
void splitStringDoxyStyle(const ::std::string &str, ::std::vector< ::std::pair< ::std::string, ::std::string > > &pairs, bool preserveLinefeed)
   {
    ::std::vector< ::std::string> words;
    splitStringToWords(str, words, preserveLinefeed);

    ::std::vector< ::std::string> curWords;
    ::std::string doxyTag;

    ::std::vector< ::std::string>::iterator wit = words.begin();
    for(; wit!=words.end(); ++wit)
       {
        if (wit->empty()) continue;

        bool isDoxyTag = false;
        if ((*wit)[0]=='\\')
           {
            if (wit->size()>1 && (*wit)[1]=='\\')
               { // shielded slash
                wit->erase(::std::string::size_type(0), ::std::string::size_type(1));
               }
            else
               {
                isDoxyTag = true;
               }
           }
        if (!isDoxyTag)
           {
            curWords.push_back(*wit);
            continue;
           }

        if (!doxyTag.empty() || !curWords.empty())
           {
            ::std::string merged = mergeStringFromWords(curWords);
            pairs.push_back( ::std::make_pair(doxyTag, merged) );
            //doxyTag.erase(::std::string::size_type(0), ::std::string::size_type(1));
            curWords.erase(curWords.begin(), curWords.end());
           }
        doxyTag = *wit;
       }

    if (!doxyTag.empty() || !curWords.empty())
       {
        ::std::string merged = mergeStringFromWords(curWords);
        pairs.push_back( ::std::make_pair(doxyTag, merged) );
       }

   }

//-----------------------------------------------------------------------------
::std::string mergeVectorToString(const ::std::vector< ::std::string> &v, char chSep)
   {
    ::std::string res;
    ::std::vector< ::std::string>::const_iterator it = v.begin();
    for(; it!=v.end(); ++it)
       {
        bool addSpace = !res.empty();
        //if (it->empty() || (*it)[it->size()-1]!='\n')
        if (it->empty())
           addSpace = false;
        else if ((*it)[0]=='\n')
           {
            addSpace = false;
            if (it->size()==1 && res.empty()) continue;
           }
      
        if (addSpace && (!res.empty() && res[res.size()-1]=='\n'))
           addSpace = false;

        if (addSpace)
           res.append(1, chSep);

        res.append(*it);
       }
    return res;
   }

//-----------------------------------------------------------------------------
::std::string mergeDoxyStyleToString(const ::std::vector< ::std::pair< ::std::string, ::std::string > > &pairs)
   {
    ::std::string res;
    ::std::vector< ::std::pair< ::std::string, ::std::string > >::const_iterator it = pairs.begin();
    for(; it!=pairs.end(); ++it)
       {
        if (!res.empty()) 
           {
            if (!it->second.empty() && it->second[it->second.size()-1]!='\n')
               res.append(1, '\n');
           }
        res.append(it->first); 
        bool addSpace = false;
        if (it->first.empty() || it->first[it->first.size()-1]!='\n')
           addSpace = true;
        if (!addSpace && (it->second.empty() || it->second[0]!='\n'))
           addSpace = true;
        if (addSpace)
           res.append(1, ' '); 
        //res.append(it->second);

        ::std::string word;
        if (testNeedQuotes(it->second, word))
           {
            res.append(1, '\"');
            res.append(word);
            res.append(1, '\"');
           }
        else
           {
            res.append(word);
           }

       }
    return res;
   }


}; // namespace scanner
}; // namespace utils


