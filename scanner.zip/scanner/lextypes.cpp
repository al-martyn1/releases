
#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_LOCALE_) && !defined(_STLP_LOCALE) && !defined(__STD_LOCALE__) && !defined(_CPP_LOCALE) && !defined(_GLIBCXX_LOCALE)
    #include <locale>
#endif


#if !defined(LEXTYPES_H)
    #include "lextypes.h"
#endif









//-----------------------------------------------------------------------------
#define INSERT_LEXEM_NAME(v) m[v] = #v

//-----------------------------------------------------------------------------
std::string getPpLexemTypeStr(int lt)
   {
    static std::map<int, std::string> m;
    if (m.empty())
       {
        INSERT_LEXEM_NAME( LTPP_NONE       );
        INSERT_LEXEM_NAME( LTPP_UNKNOWN    );
        INSERT_LEXEM_NAME( LTPP_DEFINE     );
        INSERT_LEXEM_NAME( LTPP_UNDEF      );
        INSERT_LEXEM_NAME( LTPP_IF         );
        INSERT_LEXEM_NAME( LTPP_IFDEF      );
        INSERT_LEXEM_NAME( LTPP_IFNDEF     );
        INSERT_LEXEM_NAME( LTPP_ELSE       );
        INSERT_LEXEM_NAME( LTPP_ELIF       );
        INSERT_LEXEM_NAME( LTPP_ENDIF      );
        INSERT_LEXEM_NAME( LTPP_PRAGMA     );
        INSERT_LEXEM_NAME( LTPP_WARNING    );
        INSERT_LEXEM_NAME( LTPP_ERROR      );
        INSERT_LEXEM_NAME( LTPP_INCLUDE    );
        //INSERT_LEXEM_NAME( );
       }
    std::map<int, std::string>::const_iterator it = m.find(lt);
    if (it==m.end()) 
       {
        char buf[256];
        #ifdef _WIN32
            #if _MSC_VER>=1400
            _snprintf_s(buf, sizeof(buf)-1, sizeof(buf)-1, "LTPP_UNKNOWN_%d", lt);
            #else
            _snprintf(buf, sizeof(buf)-1, "LTPP_UNKNOWN_%d", lt);
           #endif
        #else
        snprintf(buf, sizeof(buf)-1, "LTPP_UNKNOWN_%d", lt);
        #endif
        return std::string(buf);
       }
    return it->second;
   }

//-----------------------------------------------------------------------------
std::string getLexemTypeStr(int lt)
   {
    static std::map<int, std::string> m;
    if (m.empty())
       {
        INSERT_LEXEM_NAME(LT_END                     );
        INSERT_LEXEM_NAME(LT_PREPROCESSOR_START      );
        INSERT_LEXEM_NAME(LT_PREPROCESSOR            );
        INSERT_LEXEM_NAME(LT_PREPROCESSOR_NEW_LINE   );
        INSERT_LEXEM_NAME(LT_PREPROCESSOR_END        );
        INSERT_LEXEM_NAME(LT_PREPROCESSOR_NEXT_LINE  );
        INSERT_LEXEM_NAME(LT_STRING                  );
        INSERT_LEXEM_NAME(LT_STRING_NO_END           );
        INSERT_LEXEM_NAME(LT_STRING_NO_START         );
        INSERT_LEXEM_NAME(LT_OPERATOR_END            );
        INSERT_LEXEM_NAME(LT_BLOCK_START             );
        INSERT_LEXEM_NAME(LT_BLOCK_END               );
        INSERT_LEXEM_NAME(LT_BRACKET_START           );
        INSERT_LEXEM_NAME(LT_BRACKET_END             );
        INSERT_LEXEM_NAME(LT_INDEX_START             );
        INSERT_LEXEM_NAME(LT_INDEX_END               );
        INSERT_LEXEM_NAME(LT_IDENT                   );
        INSERT_LEXEM_NAME(LT_NUMBER                  );
        INSERT_LEXEM_NAME(LT_DIV                     );
        INSERT_LEXEM_NAME(LT_DIV_ASSIGN              );
        INSERT_LEXEM_NAME(LT_COLON                   );
        INSERT_LEXEM_NAME(LT_DOUBLE_COLON            );
        INSERT_LEXEM_NAME(LT_DOT                     );
        INSERT_LEXEM_NAME(LT_COMMA                   );
        INSERT_LEXEM_NAME(LT_PLUS                    );
        INSERT_LEXEM_NAME(LT_PLUS_PLUS               );
        INSERT_LEXEM_NAME(LT_PLUS_ASSIGN             );
        INSERT_LEXEM_NAME(LT_BIN_NOT                 );
        INSERT_LEXEM_NAME(LT_BOOL_NOT                );
        INSERT_LEXEM_NAME(LT_NOT_EQ                  );
        INSERT_LEXEM_NAME(LT_BIN_AND                 );
        INSERT_LEXEM_NAME(LT_BIN_AND_ASSIGN          );
        INSERT_LEXEM_NAME(LT_BOOL_AND                );
        INSERT_LEXEM_NAME(LT_MULT_ASSIGN             );
        INSERT_LEXEM_NAME(LT_MULT                    );
        INSERT_LEXEM_NAME(LT_DOT_MULT                );
        INSERT_LEXEM_NAME(LT_PTR_ACC_MULT            );
        INSERT_LEXEM_NAME(LT_PTR_ACC                 );
        INSERT_LEXEM_NAME(LT_MINUS                   );
        INSERT_LEXEM_NAME(LT_MINUS_MINUS             );
        INSERT_LEXEM_NAME(LT_MINUS_ASSIGN            );
        INSERT_LEXEM_NAME(LT_MOD                     );
        INSERT_LEXEM_NAME(LT_MOD_ASSIGN              );
        INSERT_LEXEM_NAME(LT_LESS                    );
        INSERT_LEXEM_NAME(LT_LESS_EQ                 );
        INSERT_LEXEM_NAME(LT_SHIFT_LEFT              );
        INSERT_LEXEM_NAME(LT_SHIFT_LEFT_ASSIGN       );
        INSERT_LEXEM_NAME(LT_GREATER                 );
        INSERT_LEXEM_NAME(LT_GREATER_EQ              );
        INSERT_LEXEM_NAME(LT_SHIFT_RIGHT             );
        INSERT_LEXEM_NAME(LT_SHIFT_RIGHT_ASSIGN      );
        INSERT_LEXEM_NAME(LT_ASSIGN                  );
        INSERT_LEXEM_NAME(LT_EQ                      );
        INSERT_LEXEM_NAME(LT_BIN_XOR                 );
        INSERT_LEXEM_NAME(LT_BIN_XOR_ASSIGN          );
        INSERT_LEXEM_NAME(LT_BIN_OR                  );
        INSERT_LEXEM_NAME(LT_BIN_OR_ASSIGN           );
        INSERT_LEXEM_NAME(LT_BOOL_OR                 );
        INSERT_LEXEM_NAME(LT_QUESTION                );
        INSERT_LEXEM_NAME(LT_HASH                    );
        INSERT_LEXEM_NAME(LT_BACKSLASH               );
        
        
        INSERT_LEXEM_NAME(LT_COMMENT_SINGLE_LINE     );
        INSERT_LEXEM_NAME(LT_COMMENT                 );
        INSERT_LEXEM_NAME(LT_COMMENT_END             );

        INSERT_LEXEM_NAME(LT_HEX_NUMBER  );
        INSERT_LEXEM_NAME(LT_BIN_NUMBER  );
        INSERT_LEXEM_NAME(LT_OCT_NUMBER  );
        INSERT_LEXEM_NAME(LT_FLOAT_NUMBER);

        INSERT_LEXEM_NAME(LT_UNKNOWN);


        INSERT_LEXEM_NAME(LT_KWD_MS_ABSTRACT             );
        INSERT_LEXEM_NAME(LT_KWD_MS_ALIGNOF              );
        INSERT_LEXEM_NAME(LT_KWD_MS_ASM                  );
        INSERT_LEXEM_NAME(LT_KWD_MS_ASSUME               );
        INSERT_LEXEM_NAME(LT_KWD_MS_BASED                );
        INSERT_LEXEM_NAME(LT_KWD_MS_BOX                  );
        INSERT_LEXEM_NAME(LT_KWD_MS_CDECL                );
        INSERT_LEXEM_NAME(LT_KWD_MS_DECLSPEC             );
        INSERT_LEXEM_NAME(LT_KWD_MS_DELEGATE             );
        INSERT_LEXEM_NAME(LT_KWD_MS_EVENT                );
        INSERT_LEXEM_NAME(LT_KWD_MS_EXCEPT               );
        INSERT_LEXEM_NAME(LT_KWD_MS_FASTCALL             );
        INSERT_LEXEM_NAME(LT_KWD_MS_FINALY               );
        INSERT_LEXEM_NAME(LT_KWD_MS_FORCEINLINE          );
        INSERT_LEXEM_NAME(LT_KWD_MS_GC                   );
        INSERT_LEXEM_NAME(LT_KWD_MS_HOOK                 );
        INSERT_LEXEM_NAME(LT_KWD_MS_IDENTIFIER           );
        INSERT_LEXEM_NAME(LT_KWD_MS_IF_EXIST             );
        INSERT_LEXEM_NAME(LT_KWD_MS_IF_NOT_EXIST         );
        INSERT_LEXEM_NAME(LT_KWD_MS_INLINE               );
        INSERT_LEXEM_NAME(LT_KWD_MS_INT8                 );
        INSERT_LEXEM_NAME(LT_KWD_MS_INT16                );
        INSERT_LEXEM_NAME(LT_KWD_MS_INT32                );
        INSERT_LEXEM_NAME(LT_KWD_MS_INT64                );
        INSERT_LEXEM_NAME(LT_KWD_MS_INTERFACE            );
        INSERT_LEXEM_NAME(LT_KWD_MS_LEAVE                );
        INSERT_LEXEM_NAME(LT_KWD_MS_M64                  );
        INSERT_LEXEM_NAME(LT_KWD_MS_M128                 );
        INSERT_LEXEM_NAME(LT_KWD_MS_M128D                );
        INSERT_LEXEM_NAME(LT_KWD_MS_M128I                );
        INSERT_LEXEM_NAME(LT_KWD_MS_MULTIPLE_INHERITANCE );
        INSERT_LEXEM_NAME(LT_KWD_MS_NOGC                 );
        INSERT_LEXEM_NAME(LT_KWD_MS_NOOP                 );
        INSERT_LEXEM_NAME(LT_KWD_MS_PIN                  );
        INSERT_LEXEM_NAME(LT_KWD_MS_PROPERTY             );
        INSERT_LEXEM_NAME(LT_KWD_MS_RAISE                );
        INSERT_LEXEM_NAME(LT_KWD_MS_SEALED               );
        INSERT_LEXEM_NAME(LT_KWD_MS_SINGLE_INHERITANCE   );
        INSERT_LEXEM_NAME(LT_KWD_MS_STDCALL              );
        INSERT_LEXEM_NAME(LT_KWD_MS_SUPER                );
        INSERT_LEXEM_NAME(LT_KWD_MS_TRY_CAST             );
        INSERT_LEXEM_NAME(LT_KWD_MS_TRY                  );
        INSERT_LEXEM_NAME(LT_KWD_MS_UNHOOK               );
        INSERT_LEXEM_NAME(LT_KWD_MS_UUIDOF               );
        INSERT_LEXEM_NAME(LT_KWD_MS_VALUE                );
        INSERT_LEXEM_NAME(LT_KWD_MS_VIRTUAL_INHERITANCE  );
        INSERT_LEXEM_NAME(LT_KWD_MS_W64                  );
        INSERT_LEXEM_NAME(LT_KWD_MS_WCHAR_T              );
        INSERT_LEXEM_NAME(LT_KWD_BOOL                    );
        INSERT_LEXEM_NAME(LT_KWD_BREAK                   );
        INSERT_LEXEM_NAME(LT_KWD_CASE                    );
        INSERT_LEXEM_NAME(LT_KWD_CATCH                   );
        INSERT_LEXEM_NAME(LT_KWD_CHAR                    );
        INSERT_LEXEM_NAME(LT_KWD_CLASS                   );
        INSERT_LEXEM_NAME(LT_KWD_CONST                   );
        INSERT_LEXEM_NAME(LT_KWD_CONST_CAST              );
        INSERT_LEXEM_NAME(LT_KWD_CONTINUE                );
        INSERT_LEXEM_NAME(LT_KWD_DEFAULT                 );
        INSERT_LEXEM_NAME(LT_KWD_DELETE                  );
        INSERT_LEXEM_NAME(LT_KWD_DEPRECATED              );
        INSERT_LEXEM_NAME(LT_KWD_DLLEXPORT               );
        INSERT_LEXEM_NAME(LT_KWD_DLLIMPORT               );
        INSERT_LEXEM_NAME(LT_KWD_DO                      );
        INSERT_LEXEM_NAME(LT_KWD_DOUBLE                  );
        INSERT_LEXEM_NAME(LT_KWD_DYNAMIC_CAST            );
        INSERT_LEXEM_NAME(LT_KWD_ELSE                    );
        INSERT_LEXEM_NAME(LT_KWD_ENUM                    );
        INSERT_LEXEM_NAME(LT_KWD_EXPLICIT                );
        INSERT_LEXEM_NAME(LT_KWD_EXTERN                  );
        INSERT_LEXEM_NAME(LT_KWD_FALSE                   );
        INSERT_LEXEM_NAME(LT_KWD_FLOAT                   );
        INSERT_LEXEM_NAME(LT_KWD_FOR                     );
        INSERT_LEXEM_NAME(LT_KWD_FRIEND                  );
        INSERT_LEXEM_NAME(LT_KWD_GOTO                    );
        INSERT_LEXEM_NAME(LT_KWD_IF                      );
        INSERT_LEXEM_NAME(LT_KWD_INLINE                  );
        INSERT_LEXEM_NAME(LT_KWD_INT                     );
        INSERT_LEXEM_NAME(LT_KWD_LONG                    );
        INSERT_LEXEM_NAME(LT_KWD_MUTABLE                 );
        INSERT_LEXEM_NAME(LT_KWD_NAKED                   );
        INSERT_LEXEM_NAME(LT_KWD_NAMESPACE               );
        INSERT_LEXEM_NAME(LT_KWD_NEW                     );
        INSERT_LEXEM_NAME(LT_KWD_NOINLINE                );
        INSERT_LEXEM_NAME(LT_KWD_NORETURN                );
        INSERT_LEXEM_NAME(LT_KWD_NOTHROW                 );
        INSERT_LEXEM_NAME(LT_KWD_NOVTABLE                );
        INSERT_LEXEM_NAME(LT_KWD_OPERATOR                );
        INSERT_LEXEM_NAME(LT_KWD_PRIVATE                 );
        INSERT_LEXEM_NAME(LT_KWD_PROPERTY                );
        INSERT_LEXEM_NAME(LT_KWD_PROTECTED               );
        INSERT_LEXEM_NAME(LT_KWD_PUBLIC                  );
        INSERT_LEXEM_NAME(LT_KWD_REGISTER                );
        INSERT_LEXEM_NAME(LT_KWD_REINTERPRET_CAST        );
        INSERT_LEXEM_NAME(LT_KWD_RETURN                  );
        INSERT_LEXEM_NAME(LT_KWD_SELECTANY               );
        INSERT_LEXEM_NAME(LT_KWD_SHORT                   );
        INSERT_LEXEM_NAME(LT_KWD_SIGNED                  );
        INSERT_LEXEM_NAME(LT_KWD_SIZEOF                  );
        INSERT_LEXEM_NAME(LT_KWD_STATIC                  );
        INSERT_LEXEM_NAME(LT_KWD_STATIC_CAST             );
        INSERT_LEXEM_NAME(LT_KWD_STRUCT                  );
        INSERT_LEXEM_NAME(LT_KWD_SWITCH                  );
        INSERT_LEXEM_NAME(LT_KWD_TEMPLATE                );
        INSERT_LEXEM_NAME(LT_KWD_THIS                    );
        INSERT_LEXEM_NAME(LT_KWD_THREAD                  );
        INSERT_LEXEM_NAME(LT_KWD_THROW                   );
        INSERT_LEXEM_NAME(LT_KWD_TRUE                    );
        INSERT_LEXEM_NAME(LT_KWD_TRY                     );
        INSERT_LEXEM_NAME(LT_KWD_TYPEDEF                 );
        INSERT_LEXEM_NAME(LT_KWD_TYPEID                  );
        INSERT_LEXEM_NAME(LT_KWD_TYPENAME                );
        INSERT_LEXEM_NAME(LT_KWD_UNION                   );
        INSERT_LEXEM_NAME(LT_KWD_UNSIGNED                );
        INSERT_LEXEM_NAME(LT_KWD_USING                   );
        INSERT_LEXEM_NAME(LT_KWD_DECLARATION             );
        INSERT_LEXEM_NAME(LT_KWD_DIRECTIVE               );
        INSERT_LEXEM_NAME(LT_KWD_UUID                    );
        INSERT_LEXEM_NAME(LT_KWD_VIRTUAL                 );
        INSERT_LEXEM_NAME(LT_KWD_VOID                    );
        INSERT_LEXEM_NAME(LT_KWD_VOLATILE                );
        INSERT_LEXEM_NAME(LT_KWD_WCHAR_T                 );
        INSERT_LEXEM_NAME(LT_KWD_WHILE                   );

        INSERT_LEXEM_NAME(LT_LINEFEED                    );
        INSERT_LEXEM_NAME(LT_SPACE                       );



//        INSERT_LEXEM_NAME();
       }
    std::map<int, std::string>::const_iterator it = m.find(lt);
    if (it==m.end()) 
       {
        if (LT_IS_A(lt, LTF_CUSTOM_ATTRIBUTE))
           return std::string("LTF_CUSTOM_ATTRIBUTE");

        if (LT_IS_A(lt, LTF_CUSTOM_TYPE))
           return std::string("LTF_CUSTOM_TYPE");

        if (LT_IS_A(lt, LTF_CUSTOM_TYPE_MODIFIER))
           return std::string("LTF_CUSTOM_TYPE_MODIFIER");

        if (LT_IS_A(lt, LTF_CUSTOM_KEYWORD))
           return std::string("LTF_CUSTOM_KEYWORD");

        if (LT_IS_A(lt, LTF_CUSTOM))
           return std::string("LTF_CUSTOM");

        // if (LT_IS_A(lt, LTF_CUSTOM_ATTRIBUTE))
        //    return std::string("");
        // if (LT_IS_A(lt, LTF_CUSTOM_ATTRIBUTE))
        //    return std::string("");

        char buf[256];
        #ifdef _WIN32
            #if _MSC_VER>=1400
            _snprintf_s(buf, sizeof(buf)-1, sizeof(buf)-1, "LT_UNKNOWN_%d", lt);
            #else
            _snprintf(buf, sizeof(buf)-1, "LT_UNKNOWN_%d", lt);
           #endif
        #else
        snprintf(buf, sizeof(buf)-1, "LT_UNKNOWN_%d", lt);
        #endif
        return std::string(buf);
       }
    return it->second;
   }

//-----------------------------------------------------------------------------
std::map<std::string, int>& getPreprocessorMap()
   {
    static std::map<std::string, int> m;
    if (m.empty())
       {
        m["define"]            = LTPP_DEFINE ;
        m["undef"]             = LTPP_UNDEF  ;
        m["if"]                = LTPP_IF     ;
        m["ifdef"]             = LTPP_IFDEF  ;
        m["ifndef"]            = LTPP_IFNDEF ;
        m["else"]              = LTPP_ELSE   ;
        m["elif"]              = LTPP_ELIF   ;
        m["endif"]             = LTPP_ENDIF  ;
        m["pragma"]            = LTPP_PRAGMA ;
        m["warning"]           = LTPP_WARNING;
        m["error"]             = LTPP_ERROR  ;
        m["include"]           = LTPP_INCLUDE;
        //m[""]             = ;
       }
    return m;
   }

//-----------------------------------------------------------------------------
int  extractPreprocessorDirective(std::string &text)
   {
    std::locale loc = std::locale::classic();
    std::string::iterator it = text.begin();
    // skip initial (leading) spaces
    while(it!=text.end() && std::isspace(*it, loc)) ++it;

    if (it==text.end()) return LTPP_NONE;
    if (*it!='#')       return LTPP_NONE;

    ++it; // found #
    // skip spaces between # and preprocessor keyword
    while(it!=text.end() && std::isspace(*it, loc)) ++it;
    if (it==text.end()) return LTPP_NONE; // only # found in text and nothing more

    std::string::iterator itStart = it;
    while(it!=text.end() && !std::isspace(*it, loc)) ++it; // skip non-spaces

    std::map<std::string, int>::const_iterator ppIt = getPreprocessorMap().find(std::string(itStart, it));
    if (ppIt==getPreprocessorMap().end())
       return LTPP_UNKNOWN;

    // skip spaces
    while(it!=text.end() && std::isspace(*it, loc)) ++it;
    text.erase(text.begin(), it);
    return ppIt->second;
   }

//-----------------------------------------------------------------------------
bool isIdentIsCppKeyword(const std::string &lexText, int &lt)
   {
    if (lt!=LT_IDENT) return false;
    std::map<std::string, int>::const_iterator it = getKeywordsMap().find(lexText);
    if (it==getKeywordsMap().end()) return false;
    lt = it->second;
    return true;
   }

//-----------------------------------------------------------------------------
std::map<std::string, int>& getKeywordsMap()
   {
    static std::map<std::string, int> m;
    if (m.empty())
       {
        m["__abstract"]             = LT_KWD_MS_ABSTRACT              ;
        m["__alignof"]              = LT_KWD_MS_ALIGNOF               ;
        m["__asm"]                  = LT_KWD_MS_ASM                   ;
        m["__assume"]               = LT_KWD_MS_ASSUME                ;
        m["__based"]                = LT_KWD_MS_BASED                 ;
        m["__box"]                  = LT_KWD_MS_BOX                   ;
        m["__cdecl"]                = LT_KWD_MS_CDECL                 ;
        m["__declspec"]             = LT_KWD_MS_DECLSPEC              ;
        m["__delegate"]             = LT_KWD_MS_DELEGATE              ;
        m["__event"]                = LT_KWD_MS_EVENT                 ;
        m["__except"]               = LT_KWD_MS_EXCEPT                ;
        m["__fastcall"]             = LT_KWD_MS_FASTCALL              ;
        m["__finally"]              = LT_KWD_MS_FINALY                ;
        m["__forceinline"]          = LT_KWD_MS_FORCEINLINE           ;
        m["__gc"]                   = LT_KWD_MS_GC                    ;
        m["__hook"]                 = LT_KWD_MS_HOOK                  ;
        m["__identifier"]           = LT_KWD_MS_IDENTIFIER            ;
        m["__if_exists"]            = LT_KWD_MS_IF_EXIST              ;
        m["__if_not_exists"]        = LT_KWD_MS_IF_NOT_EXIST          ;
        m["__inline"]               = LT_KWD_MS_INLINE                ;
        m["__int8"]                 = LT_KWD_MS_INT8                  ;
        m["__int16"]                = LT_KWD_MS_INT16                 ;
        m["__int32"]                = LT_KWD_MS_INT32                 ;
        m["__int64"]                = LT_KWD_MS_INT64                 ;
        m["__interface"]            = LT_KWD_MS_INTERFACE             ;
        m["__leave"]                = LT_KWD_MS_LEAVE                 ;
        m["__m64"]                  = LT_KWD_MS_M64                   ;
        m["__m128"]                 = LT_KWD_MS_M128                  ;
        m["__m128d"]                = LT_KWD_MS_M128D                 ;
        m["__m128i"]                = LT_KWD_MS_M128I                 ;
        m["__multiple_inheritance"] = LT_KWD_MS_MULTIPLE_INHERITANCE  ;
        m["__nogc"]                 = LT_KWD_MS_NOGC                  ;
        m["__noop"]                 = LT_KWD_MS_NOOP                  ;
        m["__pin"]                  = LT_KWD_MS_PIN                   ;
        m["__property"]             = LT_KWD_MS_PROPERTY              ;
        m["__raise"]                = LT_KWD_MS_RAISE                 ;
        m["__sealed"]               = LT_KWD_MS_SEALED                ;
        m["__single_inheritance"]   = LT_KWD_MS_SINGLE_INHERITANCE    ;
        m["__stdcall"]              = LT_KWD_MS_STDCALL               ;
        m["__super"]                = LT_KWD_MS_SUPER                 ;
        m["__try_cast"]             = LT_KWD_MS_TRY_CAST              ;
        m["__try"]                  = LT_KWD_MS_TRY                   ;
        //m["__except"]               = LT_KWD_MS_EXCEPT                ;
        //m["__finally"]              = LT_KWD_MS_FINALY                ;
        m["__unhook"]               = LT_KWD_MS_UNHOOK                ;
        m["__uuidof"]               = LT_KWD_MS_UUIDOF                ;
        m["__value"]                = LT_KWD_MS_VALUE                 ;
        m["__virtual_inheritance"]  = LT_KWD_MS_VIRTUAL_INHERITANCE   ;
        m["__w64"]                  = LT_KWD_MS_W64                   ;
        m["__wchar_t"]              = LT_KWD_MS_WCHAR_T               ;
        m["and"]                    = LT_BOOL_AND                     ;
        m["and_eq"]                 = LT_BIN_AND_ASSIGN               ;
        m["bitand"]                 = LT_BIN_AND                      ;
        m["bitor"]                  = LT_BIN_OR                       ;
        m["compl"]                  = LT_BIN_NOT                      ;
        m["not"]                    = LT_BOOL_NOT                     ;
        m["or"]                     = LT_BOOL_OR                      ;
        m["or_eq"]                  = LT_BIN_OR_ASSIGN                ;
        m["xor"]                    = LT_BIN_XOR                      ;
        m["xor_eq"]                 = LT_BIN_XOR_ASSIGN               ;
        m["not_eq"]                 = LT_NOT_EQ                       ;
        m["bool"]                   = LT_KWD_BOOL                     ;
        m["break"]                  = LT_KWD_BREAK                    ;
        m["case"]                   = LT_KWD_CASE                     ;
        m["catch"]                  = LT_KWD_CATCH                    ;
        m["char"]                   = LT_KWD_CHAR                     ;
        m["class"]                  = LT_KWD_CLASS                    ;
        m["const"]                  = LT_KWD_CONST                    ;
        m["const_cast"]             = LT_KWD_CONST_CAST               ;
        m["continue"]               = LT_KWD_CONTINUE                 ;
        m["default"]                = LT_KWD_DEFAULT                  ;
        m["delete"]                 = LT_KWD_DELETE                   ;
        m["deprecated"]             = LT_KWD_DEPRECATED               ;
        m["dllexport"]              = LT_KWD_DLLEXPORT                ;
        m["dllimport"]              = LT_KWD_DLLIMPORT                ;
        m["do"]                     = LT_KWD_DO                       ;
        m["double"]                 = LT_KWD_DOUBLE                   ;
        m["dynamic_cast"]           = LT_KWD_DYNAMIC_CAST             ;
        m["else"]                   = LT_KWD_ELSE                     ;
        m["enum"]                   = LT_KWD_ENUM                     ;
        m["explicit"]               = LT_KWD_EXPLICIT                 ;
        m["extern"]                 = LT_KWD_EXTERN                   ;
        m["false"]                  = LT_KWD_FALSE                    ;
        m["float"]                  = LT_KWD_FLOAT                    ;
        m["for"]                    = LT_KWD_FOR                      ;
        m["friend"]                 = LT_KWD_FRIEND                   ;
        m["goto"]                   = LT_KWD_GOTO                     ;
        m["if"]                     = LT_KWD_IF                       ;
        m["inline"]                 = LT_KWD_INLINE                   ;
        m["int"]                    = LT_KWD_INT                      ;
        m["long"]                   = LT_KWD_LONG                     ;
        m["mutable"]                = LT_KWD_MUTABLE                  ;
        m["naked"]                  = LT_KWD_NAKED                    ;
        m["namespace"]              = LT_KWD_NAMESPACE                ;
        m["new"]                    = LT_KWD_NEW                      ;
        m["noinline"]               = LT_KWD_NOINLINE                 ;
        m["noreturn"]               = LT_KWD_NORETURN                 ;
        m["nothrow"]                = LT_KWD_NOTHROW                  ;
        m["novtable"]               = LT_KWD_NOVTABLE                 ;
        m["operator"]               = LT_KWD_OPERATOR                 ;
        m["private"]                = LT_KWD_PRIVATE                  ;
        m["property"]               = LT_KWD_PROPERTY                 ;
        m["protected"]              = LT_KWD_PROTECTED                ;
        m["public"]                 = LT_KWD_PUBLIC                   ;
        m["register"]               = LT_KWD_REGISTER                 ;
        m["reinterpret_cast"]       = LT_KWD_REINTERPRET_CAST         ;
        m["return"]                 = LT_KWD_RETURN                   ;
        m["selectany"]              = LT_KWD_SELECTANY                ;
        m["short"]                  = LT_KWD_SHORT                    ;
        m["signed"]                 = LT_KWD_SIGNED                   ;
        m["sizeof"]                 = LT_KWD_SIZEOF                   ;
        m["static"]                 = LT_KWD_STATIC                   ;
        m["static_cast"]            = LT_KWD_STATIC_CAST              ;
        m["struct"]                 = LT_KWD_STRUCT                   ;
        m["switch"]                 = LT_KWD_SWITCH                   ;
        m["template"]               = LT_KWD_TEMPLATE                 ;
        m["this"]                   = LT_KWD_THIS                     ;
        m["thread"]                 = LT_KWD_THREAD                   ;
        m["throw"]                  = LT_KWD_THROW                    ;
        m["true"]                   = LT_KWD_TRUE                     ;
        m["try"]                    = LT_KWD_TRY                      ;
        m["typedef"]                = LT_KWD_TYPEDEF                  ;
        m["typeid"]                 = LT_KWD_TYPEID                   ;
        m["typename"]               = LT_KWD_TYPENAME                 ;
        m["union"]                  = LT_KWD_UNION                    ;
        m["unsigned"]               = LT_KWD_UNSIGNED                 ;
        m["using"]                  = LT_KWD_USING                    ;
        m["declaration"]            = LT_KWD_DECLARATION              ;
        m["directive"]              = LT_KWD_DIRECTIVE                ;
        m["uuid"]                   = LT_KWD_UUID                     ;
        m["virtual"]                = LT_KWD_VIRTUAL                  ;
        m["void"]                   = LT_KWD_VOID                     ;
        m["volatile"]               = LT_KWD_VOLATILE                 ;
        m["wchar_t"]                = LT_KWD_WCHAR_T                  ;
        m["while"]                  = LT_KWD_WHILE                    ;
        //m[""] =                                                     ;

       }
    return m;
   }


















 /* __abstract                    */  
 /* __alignof                     */  
 /* __asm                         */  
 /* __assume                      */  
 /* __based                       */  
 /* __box                         */  
 /* __cdecl                       */  
 /* __declspec                    */  
 /* __delegate                    */  
 /* __event                       */  
 /* __except                      */  
 /* __fastcall                    */  
 /* __finally                     */  
 /* __forceinline                 */  
 /* __gc                          */  
 /* __hook                        */  
 /* __identifier                  */  
 /* __if_exists                   */  
 /* __if_not_exists               */  
 /* __inline                      */  
 /* __int8                        */  
 /* __int16                       */  
 /* __int32                       */  
 /* __int64                       */  
 /* __interface                   */  
 /* __leave                       */  
 /* __m64                         */  
 /* __m128                        */  
 /* __m128d                       */  
 /* __m128i                       */  
 /* __multiple_inheritance        */  
 /* __nogc                        */  
 /* __noop                        */  
 /* __pin                         */  
 /* __property                    */  
 /* __raise                       */  
 /* __sealed                      */  
 /* __single_inheritance          */  
 /* __stdcall                     */  
 /* __super                       */  
 /* __try_cast                    */  
 /* __try                         */  
 /* __except                      */  
 /* __try                         */  
 /* __finally                     */  
 /* __unhook                      */  
 /* __uuidof                      */  
 /* __value                       */  
 /* __virtual_inheritance         */  
 /* __w64                         */  
 /* __wchar_t                     */  
 /* and    */
 /* and_eq    */
 /* bitand    */
 /* bitor    */
 /* compl    */
 /* not    */
 /* or     */
 /* or_eq     */
 /* xor     */
 /* xor_eq     */
 /* not_eq     */
 /* bool                          */  
 /* break                         */  
 /* case                          */  
 /* catch                         */  
 /* char                          */  
 /* class                         */  
 /* const                         */  
 /* const_cast                    */  
 /* continue                      */  
 /* default                       */  
 /* delete                        */  
 /* deprecated                    */  
 /* dllexport                     */  
 /* dllimport                     */  
 /* do                            */  
 /* double                        */  
 /* dynamic_cast                  */  
 /* else                          */  
 /* enum                          */  
 /* explicit                      */  
 /* extern                        */  
 /* false                         */  
 /* float                         */  
 /* for                           */  
 /* friend                        */  
 /* goto                          */  
 /* if                            */  
 /* inline                        */  
 /* int                           */  
 /* long                          */  
 /* mutable                       */  
 /* naked                         */  
 /* namespace                     */  
 /* new                           */  
 /* noinline                      */  
 /* noreturn                      */  
 /* nothrow                       */  
 /* novtable                      */  
 /* operator                      */  
 /* private                       */  
 /* property                      */  
 /* protected                     */  
 /* public                        */  
 /* register                      */  
 /* reinterpret_cast              */  
 /* return                        */  
 /* selectany                     */  
 /* short                         */  
 /* signed                        */  
 /* sizeof                        */  
 /* static                        */  
 /* static_cast                   */  
 /* struct                        */  
 /* switch                        */  
 /* template                      */  
 /* this                          */  
 /* thread                        */  
 /* throw                         */  
 /* true                          */  
 /* try                           */  
 /* typedef                       */  
 /* typeid                        */  
 /* typename                      */  
 /* union                         */  
 /* unsigned                      */  
 /* using                         */  
 /* declaration                   */  
 /* using                         */  
 /* directive                     */  
 /* uuid                          */  
 /* virtual                       */  
 /* void                          */  
 /* volatile                      */  
 /* __wchar_t                     */  
 /* wchar_t                       */  
 /* while                         */  
