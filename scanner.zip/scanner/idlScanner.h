#ifndef UDGSCANNER_H
#define UDGSCANNER_H


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif


/* #include "scanner/scanner.h"
 * #include "scanner/incSearch.h"
 * #include "scanner/incbase.h"
 */

#include "scanner.h"
#include "incSearch.h"
#include "incbase.h"


struct CIncludeFinderImpl : public IIncludeSearchA,
                            public CIncludeFinder<char>
{
        virtual
        MARTY_FILESYSTEM_NS handle_t 
        searchForInclude( const std::string &includedFromFile
                        , const std::string &includeFile
                        , std::string &foundFilename
                        )
        {
         return CIncludeFinder<char>::searchForInclude(includedFromFile, includeFile, foundFilename);
        }

        virtual ~CIncludeFinderImpl() {}

};



class CC2IdlScanner : public CPrettyCppScannerBase
{
        std::vector<CScannerEvent> &events;
        std::vector<std::string>   &files;

        typedef std::vector<std::string>::size_type fnindex_t;

        fnindex_t curFileId;


    public:

        CC2IdlScanner( std::vector<CScannerEvent> &eList
                     , std::vector<std::string> &fList)
            : CPrettyCppScannerBase() 
            , events(eList)
            , files(fList)
            , curFileId(0)
            {
            }

        CC2IdlScanner( std::vector<CScannerEvent> &eList
                     , std::vector<std::string> &fList
                     , const std::string &file)
            : CPrettyCppScannerBase() 
            , events(eList)
            , files(fList)
            , curFileId(files.size())
            {
             CPrettyCppScannerBase::setCurrentFile(file);
             files.push_back(file);
            }

        CC2IdlScanner( const CC2IdlScanner &ccs )
            : CPrettyCppScannerBase(ccs) 
            , events(ccs.events)
            , files(ccs.files)
            , curFileId(0)
            {
            }

        virtual void setCurrentFile(const std::string &fn)
            {
             CPrettyCppScannerBase::setCurrentFile(fn);
             curFileId = files.size();
             files.push_back(fn);
            }

        int analize( const CScannerEvent &_evt )
           {
            CScannerEvent evt = _evt;        
            translateEvent(evt);
            evt.filenameId = (unsigned)curFileId;
            events.push_back(evt);
            return 0;
           }

    private:
        virtual CPrettyCppScannerBase* clone() const
           {
            return new CC2IdlScanner(*this);
           }
    
};


template <typename Iter>
Iter findNextScannerEvent(Iter b, Iter e)
   {
    while(b!=e && (LT_IS_WHITESPACE(b->token) || LT_IS_COMMENT(b->token))) b++;
    return b;
   }



#endif /* UDGSCANNER_H */

