#ifndef LEXTYPES_H
#define LEXTYPES_H

#include <scanner/lexDef.h>

#ifdef __cplusplus

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif

#include "ppDefs.h"

std::string getLexemTypeStr(int lt);
std::map<std::string, int>& getKeywordsMap();
bool isIdentIsCppKeyword(const std::string &lexText, int &lt);

std::string getPpLexemTypeStr(int lt);
std::map<std::string, int>& getPreprocessorMap();
int  extractPreprocessorDirective(std::string &text);


#endif

#endif /* LEXTYPES_H */

