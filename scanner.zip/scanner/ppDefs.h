#ifndef PPDEFS_H
#define PPDEFS_H

#define LTPP_NONE        0x0000
#define LTPP_UNKNOWN    -1
#define LTPP_DEFINE      0x0001
#define LTPP_UNDEF       0x0002
#define LTPP_IF          0x0003
#define LTPP_IFDEF       0x0004
#define LTPP_IFNDEF      0x0005
#define LTPP_ELSE        0x0006
#define LTPP_ELIF        0x0007
#define LTPP_ENDIF       0x0008
#define LTPP_PRAGMA      0x0009
#define LTPP_WARNING     0x000A
#define LTPP_ERROR       0x000B
#define LTPP_INCLUDE     0x000C
//#define LTPP_            0x000





#endif /* PPDEFS_H */

