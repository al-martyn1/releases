#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif

#include "../gccstub.h"


#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif

#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif



/*
getopt links 
    Failed to open page  - http://www.codeproject.com/KB/cpp/getopt4win.aspx
    http://www.codeproject.com/Articles/1940/XGetopt-A-Unix-compatible-getopt-for-MFC-and-Win32
*/


int strncasecmp (const char * __sz1, const char * __sz2, size_t __sizeMaxCompare)
  {
   return _strnicmp (__sz1, __sz2, __sizeMaxCompare);
  }

int strcasecmp (const char * __sz1, const char * __sz2)
  {
   return _stricmp (__sz1, __sz2);
  }


char *basename (char *p)
   { /* return last part of the path */
    /*
    Sample Input and Output Strings for basename()
    In the following table, the input string is the value pointed to by path, 
    and the output string is the return value of the basename() function.
    
    Input String       Output String
    "/usr/lib"          "lib"
    "/usr/"             "usr"
    "/"                 "/"
    "///"               "/"
    "//usr//lib//"      "lib"
    */

    static char drive[4];
    static char dirname[4096];
    static char fname[4096];
    static char fext[128];
    static char resname[4096];

    int len = strlen(p);
    while(len>0)
       {
        if (p[len-1] == '/' || p[len-1] == '\\') len--;
       }
    p[len] = 0; /* we have reached one of the slashes or we got the start of the string (len>=0) */

    _splitpath( p, drive, dirname, fname, fext );
    strcpy( resname, fname );
    strcat( resname, fext );
    return &resname[0];
   }

char *dirname  (char *)
   {
    static char drive[4];
    static char dirname[4096];
    static char fname[4096];
    static char fext[128];

    int len = strlen(p);
    while(len>0)
       {
        if (p[len-1] == '/' || p[len-1] == '\\') len--;
       }
    p[len] = 0; /* we have reached one of the slashes or we got the start of the string (len>=0) */

    _splitpath( p, drive, dirname, fname, fext );
    return &dirname[0];
   }


#include "getopt.c"