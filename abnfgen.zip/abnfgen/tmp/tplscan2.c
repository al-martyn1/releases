
#line 1 "tplscan.rl"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "abnf.h"

/*
extern char *template_file;
extern struct abnf_rule *rules;
extern FILE *out_stream, *in_stream;
extern struct abnf_print_info info;
*/


#line 33 "tplscan.rl"



#line 2 "tplscan.c"
static const char _AbnfTplScan_actions[] = {
	0, 1, 0, 1, 1, 1, 2, 1, 
	3, 1, 4, 1, 5, 1, 6, 1, 
	7
};

static const char _AbnfTplScan_key_offsets[] = {
	0, 1, 2, 3, 5, 6, 7, 8, 
	9, 10, 11, 12, 13, 14, 15, 16
};

static const char _AbnfTplScan_trans_keys[] = {
	37, 37, 35, 67, 77, 35, 37, 37, 
	42, 47, 35, 37, 37, 42, 47, 47, 
	42, 0
};

static const char _AbnfTplScan_single_lengths[] = {
	1, 1, 1, 2, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 1, 1, 1
};

static const char _AbnfTplScan_range_lengths[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0
};

static const char _AbnfTplScan_index_offsets[] = {
	0, 2, 4, 6, 9, 11, 13, 15, 
	17, 19, 21, 23, 25, 27, 29, 31
};

static const char _AbnfTplScan_trans_targs[] = {
	1, 14, 2, 14, 3, 14, 4, 9, 
	14, 5, 14, 6, 14, 7, 14, 8, 
	14, 14, 14, 10, 14, 11, 14, 12, 
	14, 13, 14, 14, 14, 15, 14, 0, 
	14, 14, 14, 14, 14, 14, 14, 14, 
	14, 14, 14, 14, 14, 14, 14, 14, 
	0
};

static const char _AbnfTplScan_trans_actions[] = {
	0, 15, 0, 15, 0, 15, 0, 0, 
	15, 0, 15, 0, 15, 0, 15, 0, 
	15, 9, 15, 0, 15, 0, 15, 0, 
	15, 0, 15, 7, 15, 5, 11, 0, 
	13, 15, 15, 15, 15, 15, 15, 15, 
	15, 15, 15, 15, 15, 15, 15, 13, 
	0
};

static const char _AbnfTplScan_to_state_actions[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 1, 0
};

static const char _AbnfTplScan_from_state_actions[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 3, 0
};

static const char _AbnfTplScan_eof_trans[] = {
	47, 47, 47, 47, 47, 47, 47, 47, 
	47, 47, 47, 47, 47, 47, 0, 48
};

static const int AbnfTplScan_start = 14;
static const int AbnfTplScan_error = -1;

static const int AbnfTplScan_en_header = 14;


#line 36 "tplscan.rl"



#define BUFSIZE 4096

int abnf_scan_template_file( const char *filename, FILE *os, struct abnf_rule *rules, struct abnf_print_info *info, int howPrintActions);

int abnf_scan_template_file( const char *filename, FILE *os, struct abnf_rule *rules, struct abnf_print_info *info, int howPrintActions)
{
    int cs, act;
    char *ts, *te;
    int stack[1], top;

    static char inbuf[BUFSIZE];
    /*bool single_line = false;*/
    int single_line = 0;
    int inline_depth = 0;

    int space;
    char *p;
    /*int readed;*/
    /*bool*/ int done = 0 /*false*/;
    int have = 0;
    int len;
    char *pe;
    char *eof;


    FILE *fs = fopen( filename, "rt");
    if (!fs) 
       {
        fprintf( stderr, "Scan template error: failed to open template file %s\n", filename );
        return -1;
       }

    
#line 74 "tplscan.c"
	{
	cs = AbnfTplScan_start;
	ts = 0;
	te = 0;
	act = 0;
	}

#line 72 "tplscan.rl"

    while ( !done )
    {
        /* How much space is in the buffer? */
        /*int*/ space = BUFSIZE - have;
        if ( space == 0 )
        {
            /* Buffer is full. */
            fprintf( stderr, "Scan template error: token too big\n" );
            return -1;
        }

        /* Read in a block. */
        /*char*/ p = inbuf + have;
        len = fread( (void*)p, 1 /*Item size in bytes*/, space, fs );
        /*cin.read( p, space );*/
        /*int len = cin.gcount();*/
        /*char* */ pe = p + len;
        /*char* */ eof = 0;

        /* Check for EOF. */
        if ( len == 0 ) {
            eof = pe;
            /*done = true;*/
            done = 1;
        }

        
#line 80 "tplscan.c"
	{
	int _klen;
	unsigned int _trans;
	const char *_acts;
	unsigned int _nacts;
	const char *_keys;

	if ( p == pe )
		goto _test_eof;
_resume:
	_acts = _AbnfTplScan_actions + _AbnfTplScan_from_state_actions[cs];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 ) {
		switch ( *_acts++ ) {
	case 1:
#line 1 "NONE"
	{ts = p;}
	break;
#line 97 "tplscan.c"
		}
	}

	_keys = _AbnfTplScan_trans_keys + _AbnfTplScan_key_offsets[cs];
	_trans = _AbnfTplScan_index_offsets[cs];

	_klen = _AbnfTplScan_single_lengths[cs];
	if ( _klen > 0 ) {
		const char *_lower = _keys;
		const char *_mid;
		const char *_upper = _keys + _klen - 1;
		while (1) {
			if ( _upper < _lower )
				break;

			_mid = _lower + ((_upper-_lower) >> 1);
			if ( (*p) < *_mid )
				_upper = _mid - 1;
			else if ( (*p) > *_mid )
				_lower = _mid + 1;
			else {
				_trans += (unsigned int)(_mid - _keys);
				goto _match;
			}
		}
		_keys += _klen;
		_trans += _klen;
	}

	_klen = _AbnfTplScan_range_lengths[cs];
	if ( _klen > 0 ) {
		const char *_lower = _keys;
		const char *_mid;
		const char *_upper = _keys + (_klen<<1) - 2;
		while (1) {
			if ( _upper < _lower )
				break;

			_mid = _lower + (((_upper-_lower) >> 1) & ~1);
			if ( (*p) < _mid[0] )
				_upper = _mid - 2;
			else if ( (*p) > _mid[1] )
				_lower = _mid + 2;
			else {
				_trans += (unsigned int)((_mid - _keys)>>1);
				goto _match;
			}
		}
		_trans += _klen;
	}

_match:
_eof_trans:
	cs = _AbnfTplScan_trans_targs[_trans];

	if ( _AbnfTplScan_trans_actions[_trans] == 0 )
		goto _again;

	_acts = _AbnfTplScan_actions + _AbnfTplScan_trans_actions[_trans];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 )
	{
		switch ( *_acts++ )
		{
	case 2:
#line 1 "NONE"
	{te = p+1;}
	break;
	case 3:
#line 20 "tplscan.rl"
	{te = p+1;{
                      /*fprintf(os, "Machine goes here\n" ); fflush(os);*/
                      abnf_print_ragel_rules( os, rules, info, howPrintActions );
                     }}
	break;
	case 4:
#line 24 "tplscan.rl"
	{te = p+1;{
                      /*fprintf(os, "Code goes here\n" ); fflush(os);*/
                      abnf_print_ragel_actions_code(  os, rules, info, 3 );
                     }}
	break;
	case 5:
#line 28 "tplscan.rl"
	{te = p+1;{
                      fprintf(os, "%c", (*p) ); fflush(os);
                     }}
	break;
	case 6:
#line 28 "tplscan.rl"
	{te = p;p--;{
                      fprintf(os, "%c", (*p) ); fflush(os);
                     }}
	break;
	case 7:
#line 28 "tplscan.rl"
	{{p = ((te))-1;}{
                      fprintf(os, "%c", (*p) ); fflush(os);
                     }}
	break;
#line 191 "tplscan.c"
		}
	}

_again:
	_acts = _AbnfTplScan_actions + _AbnfTplScan_to_state_actions[cs];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 ) {
		switch ( *_acts++ ) {
	case 0:
#line 1 "NONE"
	{ts = 0;}
	break;
#line 202 "tplscan.c"
		}
	}

	if ( ++p != pe )
		goto _resume;
	_test_eof: {}
	if ( p == eof )
	{
	if ( _AbnfTplScan_eof_trans[cs] > 0 ) {
		_trans = _AbnfTplScan_eof_trans[cs] - 1;
		goto _eof_trans;
	}
	}

	}

#line 100 "tplscan.rl"

        if ( cs == AbnfTplScan_error ) {
            /* Machine failed before finding a token. */
            fprintf( stderr, "Scan template error: parse error\n" );
            /*cerr << "PARSE ERROR" << endl;*/
            /*exit(1);*/
        }

        if ( ts == 0 )
            have = 0;
        else {
            /* There is a prefix to preserve, shift it over. */
            have = pe - ts;
            memmove( inbuf, ts, have );
            te = inbuf + (te-ts);
            ts = inbuf;
        }
    }
    return 0;
}

#ifdef SCAN_TPL_STANDALONE
int main(int argc, char* argv[])
{
    FILE *of;
    if (argc<2)
       {
        fprintf( stderr, "No input files taken\n" );
        return 1;
       }

    of = stdout;
    if (argc>2)
       of = fopen( argv[2], "wt");
    if (of==0)
       of = stdout;

    if (abnf_scan_template_file( argv[1], of )<0) return 1;
    return 0;
}
#endif


