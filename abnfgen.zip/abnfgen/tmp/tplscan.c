
#include <stdlib.h>
#include <stdio.h>
#include <string.h>






static const char _AbnfTplScan_actions[] = {
    0, 1, 0, 1, 1, 1, 2, 1, 
    3, 1, 4, 1, 5, 1, 6
};

static const char _AbnfTplScan_key_offsets[] = {
    0, 1, 2, 3, 4, 5, 6, 7, 
    8, 9, 10
};

static const char _AbnfTplScan_trans_keys[] = {
    37, 37, 35, 77, 35, 37, 37, 42, 
    47, 47, 42, 0
};

static const char _AbnfTplScan_single_lengths[] = {
    1, 1, 1, 1, 1, 1, 1, 1, 
    1, 1, 1
};

static const char _AbnfTplScan_range_lengths[] = {
    0, 0, 0, 0, 0, 0, 0, 0, 
    0, 0, 0
};

static const char _AbnfTplScan_index_offsets[] = {
    0, 2, 4, 6, 8, 10, 12, 14, 
    16, 18, 20
};

static const char _AbnfTplScan_trans_targs[] = {
    1, 9, 2, 9, 3, 9, 4, 9, 
    5, 9, 6, 9, 7, 9, 8, 9, 
    9, 9, 10, 9, 0, 9, 9, 9, 
    9, 9, 9, 9, 9, 9, 9, 9, 
    0
};

static const char _AbnfTplScan_trans_actions[] = {
    0, 13, 0, 13, 0, 13, 0, 13, 
    0, 13, 0, 13, 0, 13, 0, 13, 
    7, 13, 5, 9, 0, 11, 13, 13, 
    13, 13, 13, 13, 13, 13, 13, 11, 
    0
};

static const char _AbnfTplScan_to_state_actions[] = {
    0, 0, 0, 0, 0, 0, 0, 0, 
    0, 1, 0
};

static const char _AbnfTplScan_from_state_actions[] = {
    0, 0, 0, 0, 0, 0, 0, 0, 
    0, 3, 0
};

static const char _AbnfTplScan_eof_trans[] = {
    31, 31, 31, 31, 31, 31, 31, 31, 
    31, 0, 32
};

static const int AbnfTplScan_start = 9;
static const int AbnfTplScan_error = -1;

static const int AbnfTplScan_en_header = 9;





#define BUFSIZE 4096

int abnf_scan_template_file( const char *filename, FILE *os);

int abnf_scan_template_file( const char *filename, FILE *os)
{
    int cs, act;
    char *ts, *te;
    int stack[1], top;

    static char inbuf[BUFSIZE];
    /*bool single_line = false;*/
    int single_line = 0;
    int inline_depth = 0;

    int space;
    char *p;
    /*int readed;*/
    /*bool*/ int done = 0 /*false*/;
    int have = 0;
    int len;
    char *pe;
    char *eof;


    FILE *fs = fopen( filename, "rt");
    if (!fs) 
       {
        fprintf( stderr, "Scan template error: failed to open template file %s\n", filename );
        return -1;
       }

    
    {
    cs = AbnfTplScan_start;
    ts = 0;
    te = 0;
    act = 0;
    }


    while ( !done )
    {
        /* How much space is in the buffer? */
        /*int*/ space = BUFSIZE - have;
        if ( space == 0 )
        {
            /* Buffer is full. */
            fprintf( stderr, "Scan template error: token too big\n" );
            return -1;
        }

        /* Read in a block. */
        /*char*/ p = inbuf + have;
        len = fread( (void*)p, 1 /*Item size in bytes*/, space, fs );
        /*cin.read( p, space );*/
        /*int len = cin.gcount();*/
        /*char* */ pe = p + len;
        /*char* */ eof = 0;

        /* Check for EOF. */
        if ( len == 0 ) {
            eof = pe;
            /*done = true;*/
            done = 0;
        }

        
    {
    int _klen;
    unsigned int _trans;
    const char *_acts;
    unsigned int _nacts;
    const char *_keys;

    if ( p == pe )
        goto _test_eof;
_resume:
    _acts = _AbnfTplScan_actions + _AbnfTplScan_from_state_actions[cs];
    _nacts = (unsigned int) *_acts++;
    while ( _nacts-- > 0 ) {
        switch ( *_acts++ ) {
    case 1:
    {ts = p;}
    break;
        }
    }

    _keys = _AbnfTplScan_trans_keys + _AbnfTplScan_key_offsets[cs];
    _trans = _AbnfTplScan_index_offsets[cs];

    _klen = _AbnfTplScan_single_lengths[cs];
    if ( _klen > 0 ) {
        const char *_lower = _keys;
        const char *_mid;
        const char *_upper = _keys + _klen - 1;
        while (1) {
            if ( _upper < _lower )
                break;

            _mid = _lower + ((_upper-_lower) >> 1);
            if ( (*p) < *_mid )
                _upper = _mid - 1;
            else if ( (*p) > *_mid )
                _lower = _mid + 1;
            else {
                _trans += (unsigned int)(_mid - _keys);
                goto _match;
            }
        }
        _keys += _klen;
        _trans += _klen;
    }

    _klen = _AbnfTplScan_range_lengths[cs];
    if ( _klen > 0 ) {
        const char *_lower = _keys;
        const char *_mid;
        const char *_upper = _keys + (_klen<<1) - 2;
        while (1) {
            if ( _upper < _lower )
                break;

            _mid = _lower + (((_upper-_lower) >> 1) & ~1);
            if ( (*p) < _mid[0] )
                _upper = _mid - 2;
            else if ( (*p) > _mid[1] )
                _lower = _mid + 2;
            else {
                _trans += (unsigned int)((_mid - _keys)>>1);
                goto _match;
            }
        }
        _trans += _klen;
    }

_match:
_eof_trans:
    cs = _AbnfTplScan_trans_targs[_trans];

    if ( _AbnfTplScan_trans_actions[_trans] == 0 )
        goto _again;

    _acts = _AbnfTplScan_actions + _AbnfTplScan_trans_actions[_trans];
    _nacts = (unsigned int) *_acts++;
    while ( _nacts-- > 0 )
    {
        switch ( *_acts++ )
        {
    case 2:
    {te = p+1;}
    break;
    case 3:
    {te = p+1;{
                      fprintf(os, "/* Machine goes here */\n" );
                     }}
    break;
    case 4:
    {te = p+1;{
                      fprintf(os, "%c", (*p) );
                     }}
    break;
    case 5:
    {te = p;p--;{
                      fprintf(os, "%c", (*p) );
                     }}
    break;
    case 6:
    {{p = ((te))-1;}{
                      fprintf(os, "%c", (*p) );
                     }}
    break;
        }
    }

_again:
    _acts = _AbnfTplScan_actions + _AbnfTplScan_to_state_actions[cs];
    _nacts = (unsigned int) *_acts++;
    while ( _nacts-- > 0 ) {
        switch ( *_acts++ ) {
    case 0:
    {ts = 0;}
    break;
        }
    }

    if ( ++p != pe )
        goto _resume;
    _test_eof: {}
    if ( p == eof )
    {
    if ( _AbnfTplScan_eof_trans[cs] > 0 ) {
        _trans = _AbnfTplScan_eof_trans[cs] - 1;
        goto _eof_trans;
    }
    }

    }


        if ( cs == AbnfTplScan_error ) {
            /* Machine failed before finding a token. */
            fprintf( stderr, "Scan template error: parse error\n" );
            /*cerr << "PARSE ERROR" << endl;*/
            /*exit(1);*/
        }

        if ( ts == 0 )
            have = 0;
        else {
            /* There is a prefix to preserve, shift it over. */
            have = pe - ts;
            memmove( inbuf, ts, have );
            te = inbuf + (te-ts);
            ts = inbuf;
        }
    }
    return 0;
}

#ifdef SCAN_TPL_STANDALONE
int main(int argc, char* argv[])
{
    FILE *of;
    if (argc<2)
       {
        fprintf( stderr, "No input files taken\n" );
        return 1;
       }

    of = stdout;
    if (argc>2)
       of = fopen( argv[2], "wt");
    if (of==0)
       of = stdout;

    if (abnf_scan_template_file( argv[1], of )<0) return 1;
    return 0;
}
#endif


