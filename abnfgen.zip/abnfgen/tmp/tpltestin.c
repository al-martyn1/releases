#include "abc.h"

int main()
{

/* Code for actions */
/*%%#M#%%*/

/* Machine */
/*%%#M#%%*/

}

/* End of template */