#ifndef UTILS_PFSSTR_H
    #include "../utils/pfsstr.h"
#endif

#ifndef PARSERS_PFSSAX_H
    #include "parsers/pfssax.h"
#endif


#ifdef PFS_SAX_STANDALONE
    FILE *ofs;
#endif


/*-------------------------------------------------------------------------*/
static
void PFS_COMMONCALLTYPE pfs_sax_parser_reset_aux( pfs_sax_parser_t *psp ) /* set all scanner vars to initial state */
{
    psp->err       = PFS_SAX_ERR_OK;
    psp->num_attrs = 0;
    psp->top       = 0;
    
}

/*-------------------------------------------------------------------------*/
pfs_sax_parser_t* PFS_COMMONCALLTYPE pfs_sax_parser_create ( pfs_allocator_t  *pa )
{
    pfs_sax_parser_t *psp = 0; 
    if (!pa) return 0;

    psp = PFS_ALLOCATE_OBJECT( pa, pfs_sax_parser_t );
    if (!psp) return psp;

    #if defined(PFS_SAX_ALLOW_DYNAMIC_BUFFERS) && PFS_SAX_ALLOW_DYNAMIC_BUFFERS!=0
    pfs_str_init_mixed     ( &psp->tag_name   , PFS_SAX_TAG_NAME_SIZE_MAX   , &psp->tag_name_buf[0], pa );
    pfs_str_init_mixed     ( &psp->text       , PFS_SAX_TEXT_BUF_SIZE_MAX   , &psp->text_buf[0]    , pa );
    pfs_str_init_mixed     ( &psp->entity     , PFS_SAX_ENTITY_BUF_SIZE_MAX , &psp->entity_buf[0]  , pa );
    #else
    pfs_str_init_static    ( &psp->tag_name   , PFS_SAX_TAG_NAME_SIZE_MAX   , &psp->tag_name_buf[0] );
    pfs_str_init_static    ( &psp->text       , PFS_SAX_TEXT_BUF_SIZE_MAX   , &psp->text_buf[0]     );
    pfs_str_init_static    ( &psp->entity     , PFS_SAX_ENTITY_BUF_SIZE_MAX , &psp->entity_buf[0]   );
    #endif

    psp->pAllocator = pa;
    PFS_REFCOUNTED_ADDREF(psp->pAllocator);

    pfs_sax_parser_reset_aux(psp);

    return psp;
}

/*-------------------------------------------------------------------------*/
void                PFS_COMMONCALLTYPE pfs_sax_parser_destroy( pfs_sax_parser_t *psp )
{
    pfs_allocator_t  *pa = psp->pAllocator;
    pfs_str_destroy( &psp->tag_name   );
    pfs_str_destroy( &psp->text );
    pfs_str_destroy( &psp->entity );

    PFS_FREE( pa, psp );
    if (pa)
       PFS_REFCOUNTED_RELEASE(pa);
}

/*-------------------------------------------------------------------------*/
int PFS_COMMONCALLTYPE pfs_sax_parser_reset( pfs_sax_parser_t *psp ) /* reset scanner after parsing query */
{
    pfs_str_reduce_mem_usage_ex( &psp->tag_name  , PFS_SAX_TAG_NAME_SIZE_MAX );
    pfs_str_reduce_mem_usage_ex( &psp->text      , PFS_SAX_TEXT_BUF_SIZE_MAX );
    pfs_str_reduce_mem_usage_ex( &psp->entity    , PFS_SAX_ENTITY_BUF_SIZE_MAX );

    pfs_sax_parser_reset_aux(psp);

    return 0;
}

/*-------------------------------------------------------------------------*/
int PFS_COMMONCALLTYPE pfs_sax_parser_bufferize_query(pfs_sax_parser_t *psp, char ch)
{
/*
    if ( pfs_str_size(&psp->pRequest->query_text) >= psp->pRequest->limits.query_size_lim )
       {
        psp->err = PFS_HTTPSC_ERR_URI_TOO_LONG;
        return -1;
       }
    return pfs_str_append_char( &psp->pRequest->query_text, ch );
*/
    return 0;
}

/*-------------------------------------------------------------------------*/
int PFS_COMMONCALLTYPE pfs_sax_parser_bufferize(pfs_sax_parser_t *psp, char ch)
{
/*
    if ( pfs_str_size(&psp->pRequest->headers_text) >= psp->pRequest->limits.headers_text_lim )
       {
        psp->err = PFS_HTTPSC_ERR_HDRS_TOO_LONG;
        return -1;
       }
    return pfs_str_append_char( &psp->pRequest->headers_text, ch );
*/
    return 0;
}

/*-------------------------------------------------------------------------*/
int PFS_COMMONCALLTYPE pfs_sax_parser_bufferize_skip_lws(pfs_sax_parser_t *psp, char ch)
{
/*
    if (ch=='\r' || ch=='\n') return 0;
    if ( pfs_str_size(&psp->pRequest->headers_text) >= psp->pRequest->limits.headers_text_lim )
       {
        psp->err = PFS_HTTPSC_ERR_HDRS_TOO_LONG;
        return -1;
       }
    return pfs_str_append_char( &psp->pRequest->headers_text, ch );
*/
    return 0;
}

/*-------------------------------------------------------------------------*/
int PFS_COMMONCALLTYPE pfs_sax_parser_bufferize_data(pfs_sax_parser_t *psp, char ch)
{
/*
    if ( pfs_str_size(&psp->pRequest->body_text) >= psp->pRequest->limits.data_size_lim )
       {
        psp->err = PFS_HTTPSC_ERR_DATA_TOO_LONG;
        return -1;
       }
    return pfs_str_append_char( &psp->pRequest->body_text, ch );
*/
    return 0;
}


/*-------------------------------------------------------------------------*/
/*

/*%%#C#%%*/

*/

/*-------------------------------------------------------------------------*/
/*%%#M#%%*/

/*-------------------------------------------------------------------------*/
%% write data;

/*-------------------------------------------------------------------------*/
int PFS_COMMONCALLTYPE pfs_sax_parser_init( pfs_sax_parser_t *psp ) /* initialize scanner before parsing query */
{
    %% write init;
    pfs_sax_parser_reset_aux(psp);
    return 1;
}

/*-------------------------------------------------------------------------*/
int PFS_COMMONCALLTYPE pfs_sax_parser_execute( pfs_sax_parser_t *psp, const char *data, int len, int isEof )
{
    const char *p = data;
    const char *pe = data + len;
    const char *eof = isEof ? pe : 0;

    %% write exec;

    if ( psp->cs == pfs_sax_parser_error )
        return -1;
    if ( psp->cs >= pfs_sax_parser_first_final )
        return 1;
    return 0;
}

/*-------------------------------------------------------------------------*/
int PFS_COMMONCALLTYPE pfs_sax_parser_finish( pfs_sax_parser_t *psp )
{
    if ( psp->cs == pfs_sax_parser_error )
        return -1;
    if ( psp->cs >= pfs_sax_parser_first_final )
        return 1;
    return 0;
}

/*-------------------------------------------------------------------------*/
/* BNF event handlers */
/*-------------------------------------------------------------------------*/

void PFS_COMMONCALLTYPE pfs_sax_parser_e_HttpVersion(pfs_sax_parser_t *psp, char ch)
{
/*
    psp->curChunk.start = pfs_str_size(&psp->pRequest->query_text);
*/
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_l_HttpVersion(pfs_sax_parser_t *psp, char ch)
{
    /* const pfs_http_token_info_t *pti;
     * psp->curChunk.size = pfs_str_size(&psp->pRequest->query_text) - psp->curChunk.start;
     * pti = pfs_http_find_token( &psp->pRequest->query_text, &psp->curChunk );
     * if (pti) 
     *    {
     *     psp->pRequest->ver_info.info = pti;
     *     pfs_str_erase_at_end( &psp->pRequest->query_text, psp->curChunk.size ); 
     *  
     *     switch(psp->pRequest->ver_info.info->id)
     *        {
     *         case PFS_HTTOKEN_HTTP_1_0:  psp->pRequest->http_ver_major = 1; psp->pRequest->http_ver_minor = 0; break;
     *         case PFS_HTTOKEN_HTTP_1_1:  psp->pRequest->http_ver_major = 1; psp->pRequest->http_ver_minor = 1; break;
     *         default:                    psp->pRequest->http_ver_major = 0; psp->pRequest->http_ver_minor = 9;
     *        }
     *    }
     * else
     *    {
     *     psp->pRequest->ver_info.name = psp->curChunk;
     *     psp->pRequest->http_ver_major = 0; psp->pRequest->http_ver_minor = 9;
     *    }
     */
}


/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_l_HttpHeaderName(pfs_sax_parser_t *psp, char ch)
{
    /* const pfs_http_hdr_info_t *phi;
     * if (psp->pRequest->num_headers >= PFS_HTTP_NUM_HEADERS_MAX)
     *    {
     *     return;
     *    }
     *  
     * psp->curChunk.size = pfs_str_size(&psp->pRequest->headers_text) - psp->curChunk.start;
     * phi = pfs_http_find_header( &psp->pRequest->headers_text, &psp->curChunk );
     * if (phi) 
     *    {
     *     psp->pRequest->headers[psp->pRequest->num_headers].info = phi;
     *     pfs_str_erase_at_end( &psp->pRequest->headers_text, psp->curChunk.size );
     *    }
     * else
     *    {
     *     psp->pRequest->headers[psp->pRequest->num_headers].name = psp->curChunk;
     *    }
     * ++psp->pRequest->num_headers;
     */
}

/*-------------------------------------------------------------------------*/



void PFS_COMMONCALLTYPE pfs_sax_parser_e_HttpMethod(pfs_sax_parser_t *psp, char ch)
{
    /* psp->curChunk.start = pfs_str_size(&psp->pRequest->query_text);
     */
 /* nothing to do */
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_l_HttpMethod(pfs_sax_parser_t *psp, char ch)
{
    /* const pfs_http_verb_info_t *pvi;
     * psp->curChunk.size = pfs_str_size(&psp->pRequest->query_text) - psp->curChunk.start;
     * pvi = pfs_http_find_verb( &psp->pRequest->query_text, &psp->curChunk );
     * if (pvi) 
     *    {
     *     psp->pRequest->verb_info.info = pvi;
     *     pfs_str_erase_at_end( &psp->pRequest->query_text, psp->curChunk.size );
     *    }
     * else
     *    {
     *     psp->pRequest->verb_info.name = psp->curChunk;
     *    }
     */
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_t_HttpMethod(pfs_sax_parser_t *psp, char ch)
{
    /* pfs_sax_parser_bufferize_query(psp, ch);
     */
}

/*-------------------------------------------------------------------------*/



void PFS_COMMONCALLTYPE pfs_sax_parser_e_HttpRequestURI(pfs_sax_parser_t *psp, char ch)
{
    /* psp->curChunk.start = pfs_str_size(&psp->pRequest->query_text);
     */
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_l_HttpRequestURI(pfs_sax_parser_t *psp, char ch)
{
    /* psp->curChunk.size = pfs_str_size(&psp->pRequest->query_text) - psp->curChunk.start;
     */
/*    psp->pRequest->uri = psp->curChunk; */
    /* psp->pRequest->verb_info.text = psp->curChunk;
     */
    
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_t_HttpRequestURI(pfs_sax_parser_t *psp, char ch)
{
    /* pfs_sax_parser_bufferize_query(psp, ch);
     */
}

/*-------------------------------------------------------------------------*/

void PFS_COMMONCALLTYPE pfs_sax_parser_e_HttpHeaderText(pfs_sax_parser_t *psp, char ch)
{
    /* psp->curChunk.start = pfs_str_size(&psp->pRequest->headers_text);
     */
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_l_HttpHeaderText(pfs_sax_parser_t *psp, char ch)
{
    /* if (psp->pRequest->num_headers > PFS_HTTP_NUM_HEADERS_MAX)
     *    {
     *     return;
     *    }
     *  
     * psp->curChunk.size = pfs_str_size(&psp->pRequest->headers_text) - psp->curChunk.start;
     * psp->pRequest->headers[psp->pRequest->num_headers-1].text = psp->curChunk;
     */
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_t_HttpHeaderText(pfs_sax_parser_t *psp, char ch)
{
    /* if (psp->pRequest->num_headers > PFS_HTTP_NUM_HEADERS_MAX) return; /* don't put data to headers buf if headers limit reached */
     * pfs_sax_parser_bufferize_skip_lws(psp, ch);
     */
}

/*-------------------------------------------------------------------------*/

void PFS_COMMONCALLTYPE pfs_sax_parser_e_HttpRequest(pfs_sax_parser_t *psp, char ch)
{
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_l_HttpRequest(pfs_sax_parser_t *psp, char ch)
{
}

/*-------------------------------------------------------------------------*/
void PFS_COMMONCALLTYPE pfs_sax_parser_t_HttpRequest(pfs_sax_parser_t *psp, char ch)
{
}

/*-------------------------------------------------------------------------*/

#ifdef PFS_SAX_STANDALONE
    /*#define PFS_SAX_TEST_PRINT*/
#endif

#if defined(PFS_SAX_STANDALONE) || defined(PFS_SAX_TEST_PRINT)
    #include <stdio.h>
    #include <stdlib.h>
#endif


#ifdef PFS_HTTPSC_TEST_PRINT
size_t PFS_COMMONCALLTYPE print_request_dump( FILE *ofs, const pfs_http_request_t *pRequest )
{

    int id;
    pfs_size_t i;
    fprintf(ofs, "--------------------------\n" );
    fprintf(ofs, "Raw query string: [%.*s]\n", pfs_str_size(&pRequest->query_text), pfs_str_c_str(&pRequest->query_text) );
    fprintf(ofs, "------------------------\n" );
    fprintf(ofs, "Raw headers string: [%.*s]\n\n", pfs_str_size(&pRequest->headers_text), pfs_str_c_str(&pRequest->headers_text) );
    fprintf(ofs, "------------------------\n" );
    fprintf(ofs, "----- Parsed request -----\n");
    fprintf(ofs, " ---- Query ----\n");
    fprintf(ofs, "Verb: ");

    PFS_STR_BEG_DECL_STATIC_BUF_STR( verb, 128 );
        pfs_http_request_get_verb_str(pRequest, &verb);
        id = pfs_http_request_get_verb(pRequest);
        fprintf(ofs, "%s (%s)\n", pfs_str_c_str(&verb), (id<=0 ? "Unknown" : "Known") );
        /*
        if (pRequest->verb_info.info)
           fprintf(ofs, "%.*s\n", pRequest->verb_info.info->nameLen, pRequest->verb_info.info->strName );
        else
           fprintf(ofs, "%.*s (unknown)\n", pRequest->verb_info.name.size, pfs_str_c_str(&pRequest->query_text) + pRequest->verb_info.name.start );
        */
    PFS_STR_END_DECL_STATIC_BUF_STR();

    fprintf(ofs, "URI: ");
    PFS_STR_BEG_DECL_STATIC_BUF_STR( uri, 4096 );
        pfs_http_request_get_uri(pRequest, &uri);
        fprintf(ofs, "%s\n", pfs_str_c_str(&uri) );
        /*
        fprintf(ofs, "%.*s\n", pRequest->verb_info.text.size, pfs_str_c_str(&pRequest->query_text) + pRequest->verb_info.text.start );
        */
    PFS_STR_END_DECL_STATIC_BUF_STR();
/*
    fprintf(ofs, "HTTP version string: ");
    if (pRequest->ver_info.info)
       fprintf(ofs, "%.*s", pRequest->ver_info.info->nameLen, pRequest->ver_info.info->strName );
    else
       {
        if (pRequest->ver_info.name.size>0)
           fprintf(ofs, "%.*s (unknown)", pRequest->ver_info.name.size, pfs_str_c_str(&pRequest->query_text) + pRequest->ver_info.name.start );
       }
    fprintf(ofs, "\n" );
*/
    {
     int httpVer = pfs_http_request_get_ver(pRequest);
     fprintf(ofs, "HTTP detected version: %d.%d\n", (httpVer>>8)&0xFF , httpVer&0xFF );
     /*
     fprintf(ofs, "HTTP detected version: %d.%d\n", pRequest->http_ver_major , pRequest->http_ver_minor );
     */
    }

    fprintf(ofs, "  --- Headers ---\n");
    fprintf(ofs, "  ! Number of headers: %d\n", pRequest->num_headers);

    for(i=0; i!=pRequest->num_headers; ++i)
       {
        PFS_STR_BEG_DECL_STATIC_BUF_STR( hdr_name, 4096 );
        PFS_STR_BEG_DECL_STATIC_BUF_STR( hdr_text, 4096 );
            pfs_http_request_get_hdrStr(pRequest     , i, &hdr_name );
            pfs_http_request_get_hdrTextStr(pRequest, i, &hdr_text );
            id = pfs_http_request_get_hdrId(pRequest, i );
            fprintf(ofs, "Header: %s (%s)\n", pfs_str_c_str(&hdr_name), (id<=0 ? "Unknown" : "Known") );
            fprintf(ofs, "  Text: %s\n", pfs_str_c_str(&hdr_text) );
            /*
            fprintf(ofs, "%.*s\n", pRequest->verb_info.text.size, pfs_str_c_str(&pRequest->query_text) + pRequest->verb_info.text.start );
            */
        PFS_STR_END_DECL_STATIC_BUF_STR();
        PFS_STR_END_DECL_STATIC_BUF_STR();

        /*
        fprintf(ofs, "Header: ");
        if (pRequest->headers[i].info)
           fprintf(ofs, "%.*s\n", pRequest->headers[i].info->nameLen, pRequest->headers[i].info->strName );
        else
           fprintf(ofs, "%.*s (unknown)\n", pRequest->headers[i].name.size, pfs_str_c_str(&pRequest->headers_text) + pRequest->headers[i].name.start );
        fprintf(ofs, "  Text: ");
        fprintf(ofs, "%.*s\n", pRequest->headers[i].text.size, pfs_str_c_str(&pRequest->headers_text) + pRequest->headers[i].text.start );
        */
       }

    fprintf(ofs, "  --- Statistic ---\n");
    fprintf(ofs, "Used     : %d bytes\nAllocated: %d bytes\n", pfs_http_request_calc_used_mem( pRequest, 0 ), pfs_http_request_calc_used_mem( pRequest, 1 ) );

    fprintf(ofs, "\n\n" );

    return pfs_http_request_calc_used_mem( pRequest, 1 );

    /* %.*s */
}
#endif




#ifdef PFS_SAX_STANDALONE

#define BUFSIZE 4096
char rdbuf[BUFSIZE];

int main(int argc, char* argv[])
{
    pfs_sax_parser_t *psp;
    pfs_size_t qSize = 0;
    pfs_size_t aSize = 0;
    FILE *ifs;
    if (argc<2)
       {
        fprintf( stderr, "No input files taken\n" );
        return 1;
       }

    ifs = stdin;
    if (argc>1)
       ifs = fopen( argv[1], "rb");
    if (!ifs)
       {
        fprintf( stderr, "Failed to open input stream %s\n", argv[1] );
        return 1;
       }

    ofs = stdout;
    if (argc>2)
       ofs = fopen( argv[2], "wb");
    if (!ofs)
       {
        fprintf( stderr, "Failed to open output stream %s\n", argv[2] );
        return 1;
       }

    psp = pfs_sax_parser_create ( pfs_get_common_allocator() );
    pfs_sax_parser_init( psp );

    while ( 1 )
    {
        int len = fread( rdbuf, 1, BUFSIZE, ifs /*stdin*/ );
        qSize += (pfs_size_t)len;
        pfs_sax_parser_execute( psp, rdbuf, len, len != BUFSIZE );
        if ( len != BUFSIZE ) break;
    }
    
    if ( pfs_sax_parser_finish( psp ) <= 0 )
       {
        fprintf( stderr, "Error parsing input\n" );
        /*fprintf( stderr, "Error parsing input\n" );
        std::cerr << "buffer content: "<<sc.tmp<<"\n";*/
       }

    return 0;

}

#endif /* PFS_SAX_STANDALONE */





