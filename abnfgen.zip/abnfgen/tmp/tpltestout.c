#include "abc.h"

int main()
{

/* Code for actions */
/* Machine goes here */


/* Machine */
/* Machine goes here */


}

/* End of template */