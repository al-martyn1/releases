/*
 Added some extentions for ragel generator.
 (c) 2013, Alexander Martynov (Marty) amart at mail ru
*/

#ifndef RULCHK_RAGEL_H
#define RULCHK_RAGEL_H

/* add this lines to your scr
#ifndef RULCHK_RAGEL_H
    #include "rulchk_ragel.h"
#endif
*/

#ifdef __cplusplus
extern "C" {
#endif

void abnf_add_rule_to_allowed_actions( const char *rule_name );
int  abnf_is_rule_allowed_for_actions( const char *rule_name );
int  abnf_is_rules_separately_allowed_for_actions(  );

#ifdef __cplusplus
};
#endif


#endif /* RULCHK_RAGEL_H */

