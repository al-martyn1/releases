/*
 *  Copyright 2007 by Tomas Mandys <tomas.mandys at 2p dot cz>
 */

/*  This file is part of abnfgen.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  It is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include "abnf.h"
#include "rulchk_ragel.h"



extern int add_ragel_actions;
extern int add_ragel_actions_bodies;
extern int disable_ragel_prolog_epilog;
extern char ragel_machine_name[];
extern char ragel_actions_prefix[];
extern char *ragel_alphatype;
extern char *ragel_access;


extern char*      ragel_custom_actions[1024];
extern int        ragel_custom_actions_count;

/* 5C - \ error */

/* export to ragel */
#define ABNF_IS_VALID_OR_ESCAPABLE_CHAR(_c_) ( ((_c_)>=0x20 && (_c_)<=0x7e) || \
        (_c_)=='\0' || (_c_)=='\a' || (_c_)=='\b' || (_c_)=='\t' || \
        (_c_)=='\n' || (_c_)=='\v' || (_c_)=='\f' || (_c_)=='\r' )

static char* abnf_escape_char(char c) {
    static char buff[5];
    if (ABNF_IS_VALID_OR_ESCAPABLE_CHAR(c)) {
        switch (c) {
            case '\0':
                return "\\0";
            case '\a':
                return "\\a";
            case '\b':
                return "\\b";
            case '\t':
                return "\\t";
            case '\n':
                return "\\n";
            case '\v':
                return "\\v";
            case '\f':
                return "\\f";
            case '\r':
                return "\\r";
            case '"':
                return "\\\"";
            case '\\':
                return "\\\\";
            default:
                buff[0] = c;
                buff[1] = '\0';
                break;
        }
    }
    else {
        snprintf(buff, sizeof(buff)-1, "%%x%.2x", (unsigned char) c);
    }
    return buff;
}

static char* abnf_get_ragel_rule_name(struct abnf_str s, struct abnf_rule *rules) {
    static char buff[100];
    struct abnf_rule *pr;
    unsigned int i;
    char *reserved[] = {"any", "ascii", "extend", "alpha", "digit", "alnum", "lower", "upper",
                    "xdigit", "cntrl", "graph", "print", "punct", "space", "null", "empty", NULL};
    /* get name as declared, name is case sensitive in ragel but unsensitive in abnf */
    if (rules) {
        pr = abnf_find_rule(rules, s);
        if (pr) s = pr->name;
    }
    /* make copy */
    if (s.len > sizeof(buff)-1) s.len = sizeof(buff)-1;
    memcpy(buff, s.s, s.len);
    buff[s.len] = '\0';
    /* change '-' to '_' */
    for (i=0; i<s.len; i++) {
        if (buff[i] == '-') buff[i] = '_';
    }
    /* there are built in rules in ragel, add suffix '_' is name is in conflict */
    for (i=0; reserved[i]; i++) {
        if (strcmp(reserved[i], buff) == 0) {
            buff[s.len] = '_';
            s.len++;
            buff[s.len] = '\0';
        }
    }
    return buff;
}

static void abnf_print_ragel_element(FILE *stream, struct abnf_rule *pr, struct abnf_element *e);
static void abnf_print_ragel_alternations(FILE *stream, struct abnf_rule *pr, struct abnf_alternation *pa) {
    struct abnf_concatenation *pc;
    int ia, na, ic, nc;
    na = abnf_alternation_count(pa);
    for (ia = 0; pa; pa = pa->next, ia++) {
        if (ia > 0) fprintf(stream, " | ");
        nc = abnf_concatenation_count(pa->concatenation);
        if (na > 1 && nc > 1) fprintf(stream, "( ");
        for (ic = 0, pc = pa->concatenation; pc; ic++, pc = pc->next) {
            if (ic > 0) fprintf(stream, " "); /* or '.' */
            abnf_print_ragel_element(stream, pr, &pc->repetition.element);
            if (ABNF_IS_OPTIONAL(pc->repetition))
                fprintf(stream, "?");
            else if (ABNF_IS_ANY(pc->repetition))
                fprintf(stream, "*");
            else if (ABNF_IS_MORE(pc->repetition))
                fprintf(stream, "+");
            else if (!ABNF_IS_ONCE(pc->repetition)) {
                fprintf(stream, "{");
                if (pc->repetition.min > 0) fprintf(stream, "%u", pc->repetition.min);
                if (pc->repetition.min != pc->repetition.max) {
                    fprintf(stream, ",");
                    if (pc->repetition.max != ABNF_INFINITY) fprintf(stream, "%u", pc->repetition.max);
                }
                fprintf(stream, "}");
            }
        }
        if (na > 1 && nc > 1) fprintf(stream, " )");
    }
}

static void abnf_print_ragel_element(FILE *stream, struct abnf_rule *pr, struct abnf_element *e) {
    int i, j, n, na, nc;
    switch (e->type) {
        case ABNF_ET_RULE:
            fprintf(stream, "%s", abnf_get_ragel_rule_name(e->u.rule.name, pr));
            break;
        case ABNF_ET_GROUP:
            na = abnf_alternation_count(e->u.group);
            if (e->u.group)
                nc = abnf_concatenation_count(e->u.group->concatenation);
            else
                nc = 0;
            if (na > 1 || (na == 1 && nc > 1)) fprintf(stream, "( "); /* abnf_print_ragel_alternation won't add parenthesis */
                abnf_print_ragel_alternations(stream, pr, e->u.group);
            if (na > 1 || (na == 1 && nc > 1)) fprintf(stream, " )"); /* abnf_print_ragel_alternation won't add parenthesis */
            break;
        case ABNF_ET_RANGE:
            if (e->u.range.lo == e->u.range.hi) {
                if (ABNF_IS_ALPHA(e->u.range.lo) || !ABNF_IS_VALID_OR_ESCAPABLE_CHAR(e->u.range.lo) ) {
                    fprintf(stream, "0x%.2x", e->u.range.lo);
                }
                else
                    fprintf(stream, "\"%s\"", abnf_escape_char(e->u.range.lo));
            }
            else {
                /* if (ABNF_IS_VALID_OR_ESCAPABLE_CHAR(e->u.range.lo) && ABNF_IS_VALID_OR_ESCAPABLE_CHAR(e->u.range.hi)) {
                    fprintf(stream, "\"%c\"..\"%c\"", e->u.range.lo, e->u.range.hi);
                }
                else */
                    fprintf(stream, "0x%.2x..0x%.2x", e->u.range.lo, e->u.range.hi);
            }
            break;
        case ABNF_ET_STRING:
            for (i=0; i < e->u.string.len; i++) {
                if (i > 0) fprintf(stream, ".");
                fprintf(stream, "0x%.2x", (unsigned char) e->u.string.s[i]);
            }
            break;
        case ABNF_ET_TOKEN:
            for (i=0, n=0; i < e->u.token.len; n++) {
                if (ABNF_IS_VALID_TOKEN_CHAR(e->u.token.s[i])) {
                    for (i++; i < e->u.token.len && ABNF_IS_VALID_TOKEN_CHAR(e->u.token.s[i]); i++);
                }
                else {
                    for (i++; i < e->u.token.len && !ABNF_IS_VALID_TOKEN_CHAR(e->u.token.s[i]); i++);
                }
            }
            if (n > 1) fprintf(stream, "( ");
            for (i=0; i < e->u.token.len; ) {
                if (i > 0) fprintf(stream, " ");
                j = i;
                if (ABNF_IS_VALID_OR_ESCAPABLE_CHAR(e->u.token.s[i])) {
                    int alpha_fl = 0;
                    fprintf(stream, "\"");
                    do {
                        if (ABNF_IS_ALPHA(e->u.token.s[i]))
                            alpha_fl = 1;
                        fprintf(stream, "%s", abnf_escape_char(e->u.token.s[i]));
                        i++;
                    } while (ABNF_IS_VALID_OR_ESCAPABLE_CHAR(e->u.token.s[i]) && i < e->u.token.len);
                    fprintf(stream, "\"");
                    if (alpha_fl)
                        fprintf(stream, "i");
                }
                else {
                    for (i++; i < e->u.token.len && !ABNF_IS_VALID_TOKEN_CHAR(e->u.token.s[i]); i++) {
                        if (i > j) fprintf(stream, ".");
                        fprintf(stream, "0x%.2x", (unsigned char) e->u.token.s[i]);
                    }
                }
            }
            if (n > 1) fprintf(stream, " )");
            break;

        default:
            ;
    }
}


int abnf_print_is_simple_rule( const char *rule_name )
{
    if (strcmp(rule_name, "ALPHA")==0) return 1;
    if (strcmp(rule_name, "BIT")==0) return 1;
    if (strcmp(rule_name, "CHAR")==0) return 1;
    if (strcmp(rule_name, "CR")==0) return 1;
    if (strcmp(rule_name, "LF")==0) return 1;
    if (strcmp(rule_name, "CRLF")==0) return 1;
    if (strcmp(rule_name, "CTL")==0) return 1;
    if (strcmp(rule_name, "DIGIT")==0) return 1;
    if (strcmp(rule_name, "DQUOTE")==0) return 1;
    if (strcmp(rule_name, "HEXDIG")==0) return 1;
    if (strcmp(rule_name, "HEX")==0) return 1;
    if (strcmp(rule_name, "HTAB")==0) return 1;
    if (strcmp(rule_name, "HT")==0) return 1;
    if (strcmp(rule_name, "LWS")==0) return 1;
    if (strcmp(rule_name, "LWSP")==0) return 1;
    if (strcmp(rule_name, "OCTET")==0) return 1;
    if (strcmp(rule_name, "SP")==0) return 1;
    if (strcmp(rule_name, "VCHAR")==0) return 1;
    if (strcmp(rule_name, "WSP")==0) return 1;
    if (strcmp(rule_name, "WS")==0) return 1;
    if (strcmp(rule_name, "UPALPHA")==0) return 1;
    if (strcmp(rule_name, "LOALPHA")==0) return 1;
    return 0;
}


extern char *action_handler_params;
extern char *action_call_params   ;


void abnf_print_ragel_action_definition(FILE *stream, int how, const char *actionCode, int inlineRagelActionsCode, const char * action_prefix, const char * action_name, const char * action_rule_name );
void abnf_print_ragel_action_definition(FILE *stream, int how, const char *actionCode, int inlineRagelActionsCode, const char * action_prefix, const char * action_name, const char * action_rule_name )
{
 switch(how)
    {
     case 1: fprintf(stream, "\taction %s%s%s {}\n" , action_prefix, action_name, action_rule_name );
             break;
     case 2: fprintf(stream, "\taction %s%s%s { %s%s%s(%s); }\n" 
                             , action_prefix, action_name, action_rule_name
                             , action_prefix, action_name, action_rule_name 
                             , action_call_params ? action_call_params : ""
                    );
             break;
     case 3: 
     case 4: 
             if (actionCode)
                 fprintf(stream, "    %svoid %s%s%s(%s) { const char *rlA = \"%s\"; const char *rlT = \"%c\"; %s }\n" 
                                 , inlineRagelActionsCode ? "inline " : ""
                                 , action_prefix, action_name, action_rule_name
                                 , action_handler_params ? action_handler_params : ""
                                 , action_rule_name, *action_name, actionCode
                        );
             else
                 fprintf(stream, "    void %s%s%s(%s);\n" 
                                 , action_prefix, action_name, action_rule_name
                                 , action_handler_params ? action_handler_params : ""
                        );
             break;
    }
}

int check_rule_name_to_add_actions( int na, const char *name )
{
    if (abnf_is_rules_separately_allowed_for_actions())
       {
        /*
        printf("Rules separately allowed for actions, checking rule %s\n", name);
        */
        return abnf_is_rule_allowed_for_actions( name );
       }
    /*
    printf("Rules with only one alternative are used\n");
    */
    if (na==1 && !abnf_print_is_simple_rule(name))
       {
        return 1;
       }
    return 0;
}


/*
To make names shorter, change
entering_ to e_
leaving_  to l_
ata_      to t_ (all transition action)
*/

void abnf_print_ragel_actions_code(FILE *stream, struct abnf_rule *rules, struct abnf_print_info *info, int howPrintActions, char* enterLeaveTransitionCode[3], int inlineRagelActionsCode) {
    int na;
    struct abnf_rule *pr, *last_pr;

    for (pr = rules; pr; pr = pr->next) {
            na = abnf_alternation_count(pr->alternation);
            if (check_rule_name_to_add_actions(na, abnf_get_ragel_rule_name(pr->name, NULL)))
               {
                abnf_print_ragel_action_definition(stream, howPrintActions, enterLeaveTransitionCode[0], inlineRagelActionsCode, ragel_actions_prefix, "e_", abnf_get_ragel_rule_name(pr->name, NULL) );
                abnf_print_ragel_action_definition(stream, howPrintActions, enterLeaveTransitionCode[1], inlineRagelActionsCode, ragel_actions_prefix, "l_", abnf_get_ragel_rule_name(pr->name, NULL) );
                abnf_print_ragel_action_definition(stream, howPrintActions, enterLeaveTransitionCode[2], inlineRagelActionsCode, ragel_actions_prefix, "t_", abnf_get_ragel_rule_name(pr->name, NULL) );
               }
        last_pr = pr;
    }

    if (last_pr)
       {
        if (check_rule_name_to_add_actions( 1, "main" ) )
           {
            abnf_print_ragel_action_definition(stream, howPrintActions, enterLeaveTransitionCode[0], inlineRagelActionsCode, ragel_actions_prefix, "e_", "main" );
            abnf_print_ragel_action_definition(stream, howPrintActions, enterLeaveTransitionCode[1], inlineRagelActionsCode, ragel_actions_prefix, "l_" , "main" );
            abnf_print_ragel_action_definition(stream, howPrintActions, enterLeaveTransitionCode[2], inlineRagelActionsCode, ragel_actions_prefix, "t_"     , "main" );
           }
       }

}


#if 0
static void abnf_print_ragel_alternations(FILE *stream, struct abnf_rule *pr, struct abnf_alternation *pa) {
    struct abnf_concatenation *pc;
    int ia, na, ic, nc;
    na = abnf_alternation_count(pa);
    for(ia = 0; pa; pa = pa->next, ia++)
       {
        if (ia > 0) fprintf(stream, " | ");
        nc = abnf_concatenation_count(pa->concatenation);
        if (na > 1 && nc > 1) 
           fprintf(stream, "( ");
        for (ic = 0, pc = pa->concatenation; pc; ic++, pc = pc->next)
           {
            if (ic > 0) fprintf(stream, " "); /* or '.' */
            abnf_print_ragel_element(stream, pr, &pc->repetition.element);
            if (ABNF_IS_OPTIONAL(pc->repetition))
                fprintf(stream, "?");
            else if (ABNF_IS_ANY(pc->repetition))
                fprintf(stream, "*");
            else if (ABNF_IS_MORE(pc->repetition))
                fprintf(stream, "+");
            else if (!ABNF_IS_ONCE(pc->repetition))
               {
                fprintf(stream, "{");
                if (pc->repetition.min > 0) fprintf(stream, "%u", pc->repetition.min);
                if (pc->repetition.min != pc->repetition.max)
                   {
                    fprintf(stream, ",");
                    if (pc->repetition.max != ABNF_INFINITY) fprintf(stream, "%u", pc->repetition.max);
                   }
                fprintf(stream, "}");
               }
        }
        if (na > 1 && nc > 1) fprintf(stream, " )");
    }
}
#endif
#if 0
static int abnf_rule_is_self_container(FILE *stream, struct abnf_rule *pr )
{
    static char rule_name[100];
    int num_alternations, alt_i;
    int num_concatenations, conc_i;
    struct abnf_alternation *pAlternation;
    strcpy(rule_name, abnf_get_ragel_rule_name(pr->name, NULL) );

    num_alternations = abnf_alternation_count(pr->alternation);
    pAlternation = pr->alternation;

    for(alt_i = 0; pAlternation; pAlternation = pAlternation->next, ++alt_i)
       {
       
       }

}
const str_pair_t* find_ragel_custom_rule( const char *rulename );
#endif


void abnf_print_ragel_rules(FILE *stream, struct abnf_rule *rules, struct abnf_print_info *info, int howPrintActions, char* enterLeaveTransitionCode[3], int inlineRagelActionsCode ) {
    int na, i;
    const str_pair_t* pcr; /* custom rule ptr */
    struct abnf_rule *pr, *last_pr;
    struct abnf_print_comment comment_def = {.pre_comment = NULL, .line_comment = "# ", .post_comment = NULL};

    if (!disable_ragel_prolog_epilog)
       {
        fprintf(stream, "%%%%{\n");
        abnf_print_header(stream, info, &comment_def);

        fprintf(stream, "\tmachine %s;\n", ragel_machine_name);
        if (ragel_alphatype) fprintf(stream, "\talphtype %s;\n", ragel_alphatype);
        if (ragel_access)    fprintf(stream, "\taccess %s;\n"  , ragel_access);
        fprintf(stream, "\n");
       }

    last_pr = NULL;

    if (add_ragel_actions!=0 && howPrintActions!=0)
       {
        abnf_print_ragel_actions_code(stream, rules, info, howPrintActions, enterLeaveTransitionCode, inlineRagelActionsCode);
        fprintf(stream, "\n");
        for(i=0; i!=ragel_custom_actions_count; ++i)
           {
            fprintf(stream, "\taction %s\n", ragel_custom_actions[i]);
           }
        fprintf(stream, "\n");

        last_pr = NULL;
       }

    for (pr = rules; pr; pr = pr->next) {
        pcr = find_ragel_custom_rule( abnf_get_ragel_rule_name(pr->name, NULL) );
        if (pcr) 
           {
            fprintf(stream, "\t%s = %s;\n", pcr->first, pcr->second );
            continue;
           }
        fprintf(stream, "\t%s = ", abnf_get_ragel_rule_name(pr->name, NULL));

        if (add_ragel_actions!=0)
           {
            na = abnf_alternation_count(pr->alternation);
            if (check_rule_name_to_add_actions(na, abnf_get_ragel_rule_name(pr->name, NULL))) fprintf(stream, "( ");
            /*
            if (na==1 && !abnf_print_is_simple_rule(abnf_get_ragel_rule_name(pr->name, NULL))) fprintf(stream, "( ");
            */
           }

        abnf_print_ragel_alternations(stream, pr, pr->alternation);

        if (add_ragel_actions!=0)
           {
            /*
            if (na==1 && !abnf_print_is_simple_rule(abnf_get_ragel_rule_name(pr->name, NULL)))
            */
            if (check_rule_name_to_add_actions(na, abnf_get_ragel_rule_name(pr->name, NULL)))
               {
                fprintf(stream, " )");
                fprintf(stream, "\t>%se_%s", ragel_actions_prefix , abnf_get_ragel_rule_name(pr->name, NULL) );
                fprintf(stream, "\t%%%sl_%s", ragel_actions_prefix , abnf_get_ragel_rule_name(pr->name, NULL) );
                fprintf(stream, "\t$%st_%s"     , ragel_actions_prefix , abnf_get_ragel_rule_name(pr->name, NULL) );
               }
           }

        fprintf(stream, ";\n");
        last_pr = pr;
    }
    fprintf(stream, "\n\t# instantiate machine rules\n");
    if (last_pr)
        {
         if (add_ragel_actions!=0 && check_rule_name_to_add_actions( 1, "main" ) )
            {
             fprintf(stream, "\tmain:= ( %s )", abnf_get_ragel_rule_name(last_pr->name, NULL));
             fprintf(stream, "\t>%se_main", ragel_actions_prefix );
             fprintf(stream, "\t%%%sl_main", ragel_actions_prefix );
             fprintf(stream, "\t$%st_main"     , ragel_actions_prefix );
             fprintf(stream, ";\n");
            }
         else
            {
             fprintf(stream, "\tmain:= %s;\n", abnf_get_ragel_rule_name(last_pr->name, NULL));
            }
        }
    else
        fprintf(stream, "\t# main:= <rule_name>;\n");

    if (!disable_ragel_prolog_epilog)
       {
        fprintf(stream, "}%%%%\n");
       }

}

