/*
 Added some extentions for ragel generator.
 (c) 2013, Alexander Martynov (Marty) amart at mail ru
*/

#ifndef RULCHK_RAGEL_H
    #include "rulchk_ragel.h"
#endif
/*
#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif
*/

#if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
    #include <malloc.h>
#endif

#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif



typedef char* pstr;

pstr rules_allowed_for_actions[4096];
unsigned num_rules_allowed = 0;


//static ::std::set< ::std::string > rules_allowed_for_actions;

void abnf_add_rule_to_allowed_actions( const char *rule_name )
{
    if (!rule_name) return;
    rules_allowed_for_actions[num_rules_allowed] = (pstr)malloc( strlen(rule_name)+1 );
    strcpy( rules_allowed_for_actions[num_rules_allowed], rule_name );
    ++num_rules_allowed;
    /*
    rules_allowed_for_actions.insert( ::std::string(rule_name) );
    */
}

int  abnf_is_rule_allowed_for_actions( const char *rule_name )
{
    unsigned i=0;
    if (!rule_name) return 0;

    for(; i!=num_rules_allowed; ++i)
       {
        if (strcmp( rules_allowed_for_actions[i], rule_name)==0) return 1;
       }
    return 0;
    /*
    ::std::set< ::std::string >::const_iterator it = rules_allowed_for_actions.find( ::std::string(rule_name) );
    return it == rules_allowed_for_actions.end() ? 0 : 1;
    */
}

int  abnf_is_rules_separately_allowed_for_actions(  )
{
    return (int)num_rules_allowed;
}

