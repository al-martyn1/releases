#ifndef PARSERS_PFSSAX_H
#define PARSERS_PFSSAX_H

/* add this lines to your scr
#ifndef PARSERS_PFSSAX_H
    #include "parsers/pfssax.h"
#endif
*/

#ifndef UTILS_PFSSTR_H
    #include "../utils/pfsstr.h"
#endif


#ifndef UTILS_PFSTYPES_H
    #include "../utils/pfstypes.h"
#endif

#if defined(PFS_PLATFORM_16BIT) || defined(PFS_PLATFORM_16BIT_SIMULATION)
    #ifndef PFS_SAX_PLATFORM_TINY
        #define PFS_SAX_PLATFORM_TINY
    #endif
#elif defined(PFS_PLATFORM_EMBED)
    #ifndef PFS_SAX_PLATFORM_SMALL
        #define PFS_SAX_PLATFORM_SMALL
    #endif
#else
    #ifndef PFS_SAX_PLATFORM_GENERIC
        #define PFS_SAX_PLATFORM_GENERIC
    #endif
#endif

#if defined(PFS_SAX_PLATFORM_TINY) || defined(PFS_SAX_PLATFORM_SMALL) || defined(PFS_SAX_PLATFORM_GENERIC)
    /* check conflicts */
    #if defined(PFS_SAX_PLATFORM_TINY) && defined(PFS_SAX_PLATFORM_SMALL)
        #error "Both PFS_SAX_PLATFORM_TINY and PFS_SAX_PLATFORM_SMALL defined"
    #endif
    #if defined(PFS_SAX_PLATFORM_TINY) && defined(PFS_SAX_PLATFORM_GENERICL)
        #error "Both PFS_SAX_PLATFORM_TINY and PFS_SAX_PLATFORM_GENERICL defined"
    #endif
    #if defined(PFS_SAX_PLATFORM_SMALL) && defined(PFS_SAX_PLATFORM_GENERIC)
        #error "Both PFS_SAX_PLATFORM_SMALL and PFS_SAX_PLATFORM_GENERIC defined"
    #endif
#else
    #define PFS_SAX_PLATFORM_GENERIC
#endif

/* Constants description

   PFS_SAX_TAG_NAME_SIZE_MAX  - max tag name lenght. 
                                For PFS_SAX_TAG_BUF_INIT_SIZE and PFS_SAX_PLATFORM_SMALL
                                buffer can't grow up the space to hold more large tag names.
                                For PFS_SAX_PLATFORM_GENERIC buffer can grows up.

   PFS_SAX_ATTRIBUTES_BUF_SIZE_MAX - max buffer size for atrr names and values.

   PFS_SAX_TEXT_BUF_SIZE_MAX    max text buffer size. If there is not enough memory to bufferize
                                tt, then 'characters' event will be called and buffer will be cleared.

   PFS_SAX_NUM_ATTRIBUTES_MAX - maximum number of attributes in one tag
*/

#ifndef PFS_SAX_TAG_BUF_SIZE_MAX
    #if defined(PFS_SAX_PLATFORM_TINY)

        #define PFS_SAX_TAG_NAME_SIZE_MAX            64
        #define PFS_SAX_ATTRIBUTES_BUF_SIZE_MAX      128
        #define PFS_SAX_NUM_ATTRIBUTES_MAX           32
        #define PFS_SAX_TEXT_BUF_SIZE_MAX            256
        #define PFS_SAX_ENTITY_BUF_SIZE_MAX          16     /* Assume that embedded apps accept only std entities */
        #define PFS_SAX_TAG_MAX_NESTING_LEVEL        32

    #elif defined(PFS_SAX_PLATFORM_SMALL)

        #define PFS_SAX_TAG_NAME_SIZE_MAX            128
        #define PFS_SAX_ATTRIBUTES_BUF_SIZE_MAX      256
        #define PFS_SAX_NUM_ATTRIBUTES_MAX           64
        #define PFS_SAX_TEXT_BUF_SIZE_MAX            512
        #define PFS_SAX_ENTITY_BUF_SIZE_MAX          128
        #define PFS_SAX_TAG_MAX_NESTING_LEVEL        64

    #else

        #define PFS_SAX_TAG_NAME_SIZE_MAX            1024
        #define PFS_SAX_ATTRIBUTES_BUF_SIZE_MAX      1024
        #define PFS_SAX_NUM_ATTRIBUTES_MAX           1024
        #define PFS_SAX_TEXT_BUF_SIZE_MAX            1024
        #define PFS_SAX_ENTITY_BUF_SIZE_MAX          256
        #define PFS_SAX_TAG_MAX_NESTING_LEVEL        1024

        #define PFS_SAX_ALLOW_DYNAMIC_BUFFERS        1

    #endif
#endif

#define PFS_SAX_ERR_OK              0



typedef struct tag_pfs_sax_parser_t
{
    char                   tag_name_buf[PFS_SAX_TAG_NAME_SIZE_MAX];
    char                   text_buf[PFS_SAX_TEXT_BUF_SIZE_MAX];
    char                   entity_buf[PFS_SAX_ENTITY_BUF_SIZE_MAX];
    pfs_str_chunk_pair_t   attributes[PFS_SAX_NUM_ATTRIBUTES_MAX];

    pfs_allocator_t       *pAllocator;

    pfs_string_t           tag_name;
    pfs_string_t           text;
    pfs_string_t           entity;
    pfs_size_t             num_attrs;
    pfs_ulong_t            numeric_entity_val;

    int                    err; /* PFS_SAX_ERR_* */
    int                    cs;
    int                    stack[PFS_SAX_TAG_MAX_NESTING_LEVEL];
    int                    top;

} pfs_sax_parser_t;




#endif /* PARSERS_PFSSAX_H */

