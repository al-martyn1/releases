
/* #line 1 "parse_tpl.rl" */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "abnf.h"

/*
extern char *template_file;
extern struct abnf_rule *rules;
extern FILE *out_stream, *in_stream;
extern struct abnf_print_info info;
extern char ragel_machine_name[256]
*/


/* #line 70 "parse_tpl.rl" */



/* #line 2 "parse_tpl.c" */
static const char _AbnfTplScan_actions[] = {
	0, 1, 0, 1, 1, 1, 2, 1, 
	3, 1, 4, 1, 5, 1, 6, 1, 
	7, 1, 8, 1, 9, 1, 10
};

static const char _AbnfTplScan_key_offsets[] = {
	0, 2, 3, 4, 5, 6, 7, 8, 
	9, 10, 11, 12, 13, 14, 15, 16, 
	17, 18, 19, 20, 21, 22, 23, 24, 
	25, 26, 27, 28, 29, 30, 31, 32, 
	33, 34, 35, 36, 37, 38, 39, 40, 
	41, 42, 43, 46, 47, 48, 49, 50, 
	51, 52, 53, 54, 55, 56, 57, 58, 
	59, 60, 61, 62, 63, 64, 65, 66, 
	67, 68, 69, 70, 71, 72, 73, 74, 
	75, 76, 77, 78, 79, 80, 82, 83
};

static const char _AbnfTplScan_trans_keys[] = {
	69, 70, 82, 82, 95, 83, 84, 65, 
	84, 69, 95, 78, 65, 77, 69, 37, 
	37, 73, 82, 83, 84, 95, 70, 73, 
	78, 65, 76, 95, 83, 84, 65, 84, 
	69, 95, 78, 65, 77, 69, 37, 37, 
	37, 37, 35, 67, 68, 77, 35, 37, 
	37, 42, 47, 69, 70, 73, 78, 69, 
	95, 73, 78, 76, 73, 78, 69, 95, 
	69, 86, 69, 78, 84, 83, 35, 37, 
	37, 42, 47, 35, 37, 37, 42, 47, 
	37, 47, 37, 42, 0
};

static const char _AbnfTplScan_single_lengths[] = {
	2, 1, 1, 1, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 1, 1, 1, 
	1, 1, 3, 1, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 1, 1, 1, 
	1, 1, 1, 1, 1, 2, 1, 1
};

static const char _AbnfTplScan_range_lengths[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0
};

static const unsigned char _AbnfTplScan_index_offsets[] = {
	0, 3, 5, 7, 9, 11, 13, 15, 
	17, 19, 21, 23, 25, 27, 29, 31, 
	33, 35, 37, 39, 41, 43, 45, 47, 
	49, 51, 53, 55, 57, 59, 61, 63, 
	65, 67, 69, 71, 73, 75, 77, 79, 
	81, 83, 85, 89, 91, 93, 95, 97, 
	99, 101, 103, 105, 107, 109, 111, 113, 
	115, 117, 119, 121, 123, 125, 127, 129, 
	131, 133, 135, 137, 139, 141, 143, 145, 
	147, 149, 151, 153, 155, 157, 160, 162
};

static const char _AbnfTplScan_trans_targs[] = {
	1, 16, 77, 2, 77, 3, 77, 4, 
	77, 5, 77, 6, 77, 7, 77, 8, 
	77, 9, 77, 10, 77, 11, 77, 12, 
	77, 13, 77, 14, 77, 15, 77, 77, 
	77, 17, 77, 18, 77, 19, 77, 20, 
	77, 21, 77, 22, 77, 23, 77, 24, 
	77, 25, 77, 26, 77, 27, 77, 28, 
	77, 29, 77, 30, 77, 31, 77, 32, 
	77, 33, 77, 34, 77, 35, 77, 36, 
	77, 37, 77, 38, 77, 77, 77, 40, 
	77, 41, 77, 42, 77, 43, 48, 72, 
	77, 44, 77, 45, 77, 46, 77, 47, 
	77, 77, 77, 49, 77, 50, 77, 51, 
	77, 52, 77, 53, 77, 54, 77, 55, 
	77, 56, 77, 57, 77, 58, 77, 59, 
	77, 60, 77, 61, 77, 62, 77, 63, 
	77, 64, 77, 65, 77, 66, 77, 67, 
	77, 68, 77, 69, 77, 70, 77, 71, 
	77, 77, 77, 73, 77, 74, 77, 75, 
	77, 76, 77, 77, 77, 78, 79, 77, 
	0, 77, 39, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 77, 77, 77, 77, 77, 
	77, 77, 77, 0
};

static const char _AbnfTplScan_trans_actions[] = {
	0, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 11, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 13, 21, 0, 
	21, 0, 21, 0, 21, 0, 0, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 9, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 0, 21, 0, 21, 0, 
	21, 15, 21, 0, 21, 0, 21, 0, 
	21, 0, 21, 7, 21, 5, 5, 17, 
	0, 19, 0, 19, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 21, 21, 21, 21, 21, 21, 21, 
	21, 19, 19, 0
};

static const char _AbnfTplScan_to_state_actions[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 1, 0, 0
};

static const char _AbnfTplScan_from_state_actions[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 3, 0, 0
};

static const unsigned char _AbnfTplScan_eof_trans[] = {
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 241, 241, 241, 
	241, 241, 241, 241, 241, 0, 243, 243
};

static const int AbnfTplScan_start = 77;
static const int AbnfTplScan_error = -1;

static const int AbnfTplScan_en_header = 77;


/* #line 73 "parse_tpl.rl" */



#define BUFSIZE 4096

int abnf_scan_template_file( const char *filename, FILE *os, struct abnf_rule *rules, struct abnf_print_info *info, int howPrintActions, char* enterLeaveTransitionCode[3], int inlineRagelActionsCode);

int abnf_scan_template_file( const char *filename, FILE *os, struct abnf_rule *rules, struct abnf_print_info *info, int howPrintActions, char* enterLeaveTransitionCode[3], int inlineRagelActionsCode)
{
    int cs, act;
    char *ts, *te;
    int stack[1], top;

    static char inbuf[BUFSIZE];
    /*bool single_line = false;*/
    int single_line = 0;
    int inline_depth = 0;

    int space;
    char *p;
    /*int readed;*/
    /*bool*/ int done = 0 /*false*/;
    int have = 0;
    int len;
    char *pe;
    char *eof;


    FILE *fs = fopen( filename, "rt");
    if (!fs) 
       {
        fprintf( stderr, "Scan template error: failed to open template file %s\n", filename );
        return -1;
       }

    
/* #line 186 "parse_tpl.c" */
	{
	cs = AbnfTplScan_start;
	ts = 0;
	te = 0;
	act = 0;
	}

/* #line 109 "parse_tpl.rl" */

    while ( !done )
    {
        /* How much space is in the buffer? */
        /*int*/ space = BUFSIZE - have;
        if ( space == 0 )
        {
            /* Buffer is full. */
            fprintf( stderr, "Scan template error: token too big\n" );
            return -1;
        }

        /* Read in a block. */
        /*char*/ p = inbuf + have;
        len = fread( (void*)p, 1 /*Item size in bytes*/, space, fs );
        /*cin.read( p, space );*/
        /*int len = cin.gcount();*/
        /*char* */ pe = p + len;
        /*char* */ eof = 0;

        /* Check for EOF. */
        if ( len == 0 ) {
            eof = pe;
            /*done = true;*/
            done = 1;
        }

        
/* #line 192 "parse_tpl.c" */
	{
	int _klen;
	unsigned int _trans;
	const char *_acts;
	unsigned int _nacts;
	const char *_keys;

	if ( p == pe )
		goto _test_eof;
_resume:
	_acts = _AbnfTplScan_actions + _AbnfTplScan_from_state_actions[cs];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 ) {
		switch ( *_acts++ ) {
	case 1:
/* #line 1 "NONE" */
	{ts = p;}
	break;
/* #line 209 "parse_tpl.c" */
		}
	}

	_keys = _AbnfTplScan_trans_keys + _AbnfTplScan_key_offsets[cs];
	_trans = _AbnfTplScan_index_offsets[cs];

	_klen = _AbnfTplScan_single_lengths[cs];
	if ( _klen > 0 ) {
		const char *_lower = _keys;
		const char *_mid;
		const char *_upper = _keys + _klen - 1;
		while (1) {
			if ( _upper < _lower )
				break;

			_mid = _lower + ((_upper-_lower) >> 1);
			if ( (*p) < *_mid )
				_upper = _mid - 1;
			else if ( (*p) > *_mid )
				_lower = _mid + 1;
			else {
				_trans += (unsigned int)(_mid - _keys);
				goto _match;
			}
		}
		_keys += _klen;
		_trans += _klen;
	}

	_klen = _AbnfTplScan_range_lengths[cs];
	if ( _klen > 0 ) {
		const char *_lower = _keys;
		const char *_mid;
		const char *_upper = _keys + (_klen<<1) - 2;
		while (1) {
			if ( _upper < _lower )
				break;

			_mid = _lower + (((_upper-_lower) >> 1) & ~1);
			if ( (*p) < _mid[0] )
				_upper = _mid - 2;
			else if ( (*p) > _mid[1] )
				_lower = _mid + 2;
			else {
				_trans += (unsigned int)((_mid - _keys)>>1);
				goto _match;
			}
		}
		_trans += _klen;
	}

_match:
_eof_trans:
	cs = _AbnfTplScan_trans_targs[_trans];

	if ( _AbnfTplScan_trans_actions[_trans] == 0 )
		goto _again;

	_acts = _AbnfTplScan_actions + _AbnfTplScan_trans_actions[_trans];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 )
	{
		switch ( *_acts++ )
		{
	case 2:
/* #line 1 "NONE" */
	{te = p+1;}
	break;
	case 3:
/* #line 24 "parse_tpl.rl" */
	{te = p+1;{
                      /*fprintf(os, "Machine goes here\n" ); fflush(os);*/
                      abnf_print_ragel_rules( os, rules, info, howPrintActions, enterLeaveTransitionCode, inlineRagelActionsCode );
                     }}
	break;
	case 4:
/* #line 28 "parse_tpl.rl" */
	{te = p+1;{
                      /*fprintf(os, "Code goes here\n" ); fflush(os);*/
                      abnf_print_ragel_actions_code(  os, rules, info, 3, enterLeaveTransitionCode, inlineRagelActionsCode);
                     }}
	break;
	case 5:
/* #line 32 "parse_tpl.rl" */
	{te = p+1;{ /*char ragel_machine_name[256]*/
                      extern char ragel_machine_name[256];
                      fprintf(os, "%s_error", ragel_machine_name ); fflush(os);
                     }}
	break;
	case 6:
/* #line 36 "parse_tpl.rl" */
	{te = p+1;{
                      extern char ragel_machine_name[256];
                      fprintf(os, "%s_first_final", ragel_machine_name ); fflush(os);
                     }}
	break;
	case 7:
/* #line 40 "parse_tpl.rl" */
	{te = p+1;{
                      extern char ragel_machine_name[256];
                      //extern char *ragelActionsCode[3];
                      unsigned numOfInlineCodeTaken = 0;
                      unsigned i = 0;
                      for(; i != 3; ++i)
                         {
                          if (enterLeaveTransitionCode[i]!=0)
                             {
                              const char *evt = i==0?"ENTER":(i==1?"LEAVE":"TRANSITION");
                              fprintf(os, "#define %s_INLINE_%s_EVENTS 1\n", ragel_machine_name, evt ); fflush(os);
                              numOfInlineCodeTaken++;
                             }
                         }
                      if (numOfInlineCodeTaken>0)
                         {
                          fprintf(os, "#define %s_INLINE_EVENTS 1\n", ragel_machine_name ); fflush(os);
                         }
                      else
                         {
                          fprintf(os, "/* #define %s_INLINE_EVENTS 1 */\n", ragel_machine_name ); fflush(os);
                         }
                     }}
	break;
	case 8:
/* #line 65 "parse_tpl.rl" */
	{te = p+1;{
                      fprintf(os, "%c", (*p) ); fflush(os);
                     }}
	break;
	case 9:
/* #line 65 "parse_tpl.rl" */
	{te = p;p--;{
                      fprintf(os, "%c", (*p) ); fflush(os);
                     }}
	break;
	case 10:
/* #line 65 "parse_tpl.rl" */
	{{p = ((te))-1;}{
                      fprintf(os, "%c", (*p) ); fflush(os);
                     }}
	break;
/* #line 340 "parse_tpl.c" */
		}
	}

_again:
	_acts = _AbnfTplScan_actions + _AbnfTplScan_to_state_actions[cs];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 ) {
		switch ( *_acts++ ) {
	case 0:
/* #line 1 "NONE" */
	{ts = 0;}
	break;
/* #line 351 "parse_tpl.c" */
		}
	}

	if ( ++p != pe )
		goto _resume;
	_test_eof: {}
	if ( p == eof )
	{
	if ( _AbnfTplScan_eof_trans[cs] > 0 ) {
		_trans = _AbnfTplScan_eof_trans[cs] - 1;
		goto _eof_trans;
	}
	}

	}

/* #line 137 "parse_tpl.rl" */

        if ( cs == AbnfTplScan_error ) {
            /* Machine failed before finding a token. */
            fprintf( stderr, "Scan template error: parse error\n" );
            /*cerr << "PARSE ERROR" << endl;*/
            /*exit(1);*/
        }

        if ( ts == 0 )
            have = 0;
        else {
            /* There is a prefix to preserve, shift it over. */
            have = pe - ts;
            memmove( inbuf, ts, have );
            te = inbuf + (te-ts);
            ts = inbuf;
        }
    }
    return 0;
}

#ifdef SCAN_TPL_STANDALONE
int main(int argc, char* argv[])
{
    struct abnf_print_info info;
    FILE *of;
    char* ragelActionsCode[3] = { "EnterCode","LeaveCode","TransitionCode" };
    int in_file_count = 0;
    struct abnf_str in_files[16];
    //str_pair_t ragel_custom_rules[4096];
    //int        ragel_custom_rules_count = 0;
    struct abnf_rule *rules = NULL;

    if (argc<2)
       {
        fprintf( stderr, "No input files taken\n" );
        return 1;
       }

    of = stdout;
    if (argc>2)
       {
        of = fopen( argv[2], "wt");
       }
    if (of==0)
       {
        of = stdout;
       }

    in_files[in_file_count] = argv[1];
    in_flags[in_file_count] = if_File;
    in_file_count++;

    if (abnf_scan_template_file( argv[1], of, rules )<0) return 1;

    abnf_scan_template_file( template_file, out_stream, rules, &info, 2 /*add_ragel_actions_bodies*/, ragelActionsCode );

    return 0;
}
#endif


