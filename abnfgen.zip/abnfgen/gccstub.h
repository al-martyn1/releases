#ifndef D__ABNFGEN_GCCSTUB_H
#define D__ABNFGEN_GCCSTUB_H

/* add this lines to your scr
#ifndef D__ABNFGEN_GCCSTUB_H
    #include "D:/abnfgen/gccstub.h"
#endif
*/


#if !defined(__GNUC__)

#include "msvc/getopt.h"

#ifdef __cplusplus
extern "C" {
#endif

int strncasecmp (const char *, const char *, size_t);
int strcasecmp  (const char*, const char *);

char *basename (char *);
char *dirname  (char *);

#ifdef __cplusplus
};
#endif

#endif /* #if !defined(__GNUC__) */


#endif /* D__ABNFGEN_GCCSTUB_H */

