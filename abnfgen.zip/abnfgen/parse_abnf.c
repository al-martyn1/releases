
/* #line 1 "parse_abnf.rl" */
/*
 *  Copyright 2007 by Tomas Mandys <tomas.mandys at 2p dot cz>
 */

/*  This file is part of abnfgen.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  It is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include "abnf.h"


/* #line 427 "parse_abnf.rl" */


int abnf_parse_abnf(FILE* in_stream, struct abnf_rule** rules, struct abnf_str origin) {
    #define ABNF_BUFF_CHUNK 1024
	#define ABNF_MAX_ALTERNATION 50
	#define MAX_ERR_LIST_LEN 200
	#define top_stack alternation_stack[alternation_count-1]
	#define top_element top_stack.conc_prev->repetition.element
	#define DBG(_s_) { \
	/*	fprintf(stderr, "%s: #%d: cs: %d, top: %d: st+0:%d, st-1:%d, tok:%d, line: %d, (%d): '%.10s'\n", (_s_), __LINE__, cs, top, stack[top], top>0?stack[top-1]:-1, tokend-tokstart, line, *p, p); */ \
	}
	#define DBG_STACK(_s_) { \
	/*	fprintf(stderr, "%s:%d  line: %d, '%.10s'\n", (_s_), alternation_count, line, p); */ \
	}

	
/* #line 2 "parse_abnf.c" */
static const char _abnf_reader_actions[] = {
	0, 1, 0, 1, 10, 1, 35, 1, 
	36, 1, 38, 1, 39, 1, 41, 1, 
	42, 1, 43, 1, 44, 1, 45, 1, 
	46, 1, 47, 1, 48, 1, 49, 1, 
	50, 1, 51, 1, 52, 2, 1, 0, 
	2, 2, 0, 2, 4, 0, 2, 5, 
	0, 2, 5, 35, 2, 5, 36, 2, 
	6, 0, 2, 6, 35, 2, 6, 36, 
	2, 7, 0, 2, 7, 35, 2, 7, 
	36, 2, 8, 0, 2, 9, 0, 2, 
	10, 0, 2, 11, 0, 2, 12, 0, 
	2, 13, 0, 2, 14, 0, 2, 15, 
	0, 2, 16, 0, 2, 18, 0, 2, 
	19, 0, 2, 20, 0, 2, 21, 0, 
	2, 22, 0, 2, 24, 0, 2, 25, 
	0, 2, 27, 35, 2, 30, 35, 2, 
	33, 35, 2, 37, 0, 2, 40, 9, 
	3, 1, 13, 0, 3, 2, 13, 0, 
	3, 3, 4, 0, 3, 4, 10, 0, 
	3, 4, 12, 0, 3, 4, 15, 0, 
	3, 4, 17, 0, 3, 4, 23, 0, 
	3, 5, 13, 0, 3, 6, 13, 0, 
	3, 7, 13, 0, 3, 9, 13, 0, 
	3, 13, 1, 0, 3, 13, 2, 0, 
	3, 14, 12, 0, 3, 14, 17, 0, 
	3, 14, 23, 0, 3, 16, 12, 0, 
	3, 16, 17, 0, 3, 16, 23, 0, 
	3, 18, 19, 0, 3, 24, 25, 0, 
	3, 26, 27, 0, 3, 26, 28, 36, 
	3, 29, 30, 0, 3, 29, 31, 36, 
	3, 32, 33, 0, 3, 32, 34, 36, 
	4, 1, 9, 13, 0, 4, 3, 4, 
	10, 0, 4, 3, 4, 12, 0, 4, 
	3, 4, 15, 0, 4, 3, 4, 17, 
	0, 4, 3, 4, 23, 0, 4, 5, 
	9, 13, 0, 4, 6, 9, 13, 0, 
	4, 7, 9, 13, 0, 4, 9, 13, 
	1, 0, 4, 9, 13, 2, 0, 4, 
	26, 27, 13, 0, 4, 29, 30, 13, 
	0, 4, 32, 33, 13, 0, 5, 26, 
	27, 9, 13, 0, 5, 29, 30, 9, 
	13, 0, 5, 32, 33, 9, 13, 0
	
};

static const short _abnf_reader_key_offsets[] = {
	0, 0, 9, 12, 13, 18, 24, 25, 
	29, 34, 39, 40, 41, 53, 56, 59, 
	72, 78, 80, 81, 83, 100, 101, 106, 
	112, 113, 114, 119, 133, 144, 147, 150, 
	155, 161, 162, 163, 168, 182, 194, 195, 
	201, 202, 203, 209, 210, 212, 214, 216, 
	218, 224, 230, 236, 245, 252, 259, 264, 
	266, 270, 271, 274, 275, 276, 282, 292, 
	300, 306, 313, 319, 325, 332, 341, 351, 
	359, 368, 382, 394
};

static const char _abnf_reader_trans_keys[] = {
	9, 10, 13, 32, 59, 65, 90, 97, 
	122, 10, 13, 59, 10, 9, 10, 13, 
	32, 126, 9, 10, 13, 32, 59, 61, 
	61, 9, 10, 32, 59, 9, 10, 13, 
	32, 59, 9, 10, 13, 32, 59, 10, 
	10, 34, 37, 40, 42, 60, 91, 48, 
	57, 65, 90, 97, 122, 34, 32, 126, 
	34, 32, 126, 34, 37, 40, 42, 47, 
	60, 91, 48, 57, 65, 90, 97, 122, 
	66, 68, 88, 98, 100, 120, 48, 49, 
	10, 48, 49, 9, 10, 13, 32, 34, 
	37, 40, 42, 59, 60, 91, 48, 57, 
	65, 90, 97, 122, 10, 9, 10, 13, 
	32, 59, 9, 10, 13, 32, 41, 59, 
	41, 10, 9, 10, 32, 41, 59, 34, 
	37, 40, 41, 42, 47, 60, 91, 48, 
	57, 65, 90, 97, 122, 34, 37, 40, 
	60, 91, 48, 57, 65, 90, 97, 122, 
	62, 32, 126, 62, 32, 126, 9, 10, 
	13, 32, 59, 9, 10, 13, 32, 59, 
	93, 93, 10, 9, 10, 32, 59, 93, 
	34, 37, 40, 42, 47, 60, 91, 93, 
	48, 57, 65, 90, 97, 122, 34, 37, 
	40, 42, 60, 91, 48, 57, 65, 90, 
	97, 122, 10, 9, 10, 13, 32, 59, 
	93, 93, 10, 9, 10, 13, 32, 41, 
	59, 41, 48, 49, 48, 57, 48, 57, 
	48, 57, 48, 57, 65, 70, 97, 102, 
	48, 57, 65, 70, 97, 102, 48, 57, 
	65, 70, 97, 102, 9, 10, 13, 32, 
	59, 65, 90, 97, 122, 45, 48, 57, 
	65, 90, 97, 122, 45, 48, 57, 65, 
	90, 97, 122, 9, 10, 13, 32, 59, 
	9, 32, 9, 10, 13, 32, 10, 9, 
	32, 126, 61, 47, 9, 10, 13, 32, 
	47, 59, 9, 10, 13, 32, 45, 46, 
	47, 48, 49, 59, 9, 10, 13, 32, 
	47, 48, 49, 59, 9, 10, 13, 32, 
	47, 59, 9, 10, 13, 32, 41, 47, 
	59, 9, 10, 13, 32, 47, 59, 9, 
	10, 13, 32, 47, 59, 9, 10, 13, 
	32, 47, 59, 93, 9, 10, 13, 32, 
	46, 47, 48, 49, 59, 9, 10, 13, 
	32, 45, 46, 47, 59, 48, 57, 9, 
	10, 13, 32, 47, 59, 48, 57, 9, 
	10, 13, 32, 46, 47, 59, 48, 57, 
	9, 10, 13, 32, 45, 46, 47, 59, 
	48, 57, 65, 70, 97, 102, 9, 10, 
	13, 32, 47, 59, 48, 57, 65, 70, 
	97, 102, 9, 10, 13, 32, 46, 47, 
	59, 48, 57, 65, 70, 97, 102, 0
};

static const char _abnf_reader_single_lengths[] = {
	0, 5, 3, 1, 3, 6, 1, 4, 
	5, 5, 1, 1, 6, 1, 1, 7, 
	6, 2, 1, 2, 11, 1, 5, 6, 
	1, 1, 5, 8, 5, 1, 1, 5, 
	6, 1, 1, 5, 8, 6, 1, 6, 
	1, 1, 6, 1, 2, 0, 0, 0, 
	0, 0, 0, 5, 1, 1, 5, 2, 
	4, 1, 1, 1, 1, 6, 10, 8, 
	6, 7, 6, 6, 7, 9, 8, 6, 
	7, 8, 6, 7
};

static const char _abnf_reader_range_lengths[] = {
	0, 2, 0, 0, 1, 0, 0, 0, 
	0, 0, 0, 0, 3, 1, 1, 3, 
	0, 0, 0, 0, 3, 0, 0, 0, 
	0, 0, 0, 3, 3, 1, 1, 0, 
	0, 0, 0, 0, 3, 3, 0, 0, 
	0, 0, 0, 0, 0, 1, 1, 1, 
	3, 3, 3, 2, 3, 3, 0, 0, 
	0, 0, 1, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 1, 1, 
	1, 3, 3, 3
};

static const short _abnf_reader_index_offsets[] = {
	0, 0, 8, 12, 14, 19, 26, 28, 
	33, 39, 45, 47, 49, 59, 62, 65, 
	76, 83, 86, 88, 91, 106, 108, 114, 
	121, 123, 125, 131, 143, 152, 155, 158, 
	164, 171, 173, 175, 181, 193, 203, 205, 
	212, 214, 216, 223, 225, 228, 230, 232, 
	234, 238, 242, 246, 254, 259, 264, 270, 
	273, 278, 280, 283, 285, 287, 294, 305, 
	314, 321, 329, 336, 343, 351, 361, 371, 
	379, 388, 400, 410
};

static const unsigned char _abnf_reader_indicies[] = {
	0, 2, 3, 0, 4, 5, 5, 1, 
	2, 3, 4, 1, 2, 1, 4, 2, 
	3, 4, 1, 6, 7, 8, 6, 6, 
	9, 1, 9, 1, 11, 12, 11, 11, 
	10, 0, 2, 3, 0, 4, 1, 13, 
	2, 3, 13, 4, 10, 7, 1, 15, 
	14, 17, 18, 19, 20, 22, 24, 21, 
	23, 23, 16, 26, 25, 16, 28, 27, 
	16, 29, 30, 31, 32, 33, 35, 37, 
	34, 36, 36, 16, 38, 39, 40, 38, 
	39, 40, 16, 41, 42, 16, 43, 16, 
	44, 45, 16, 46, 47, 48, 46, 17, 
	18, 19, 20, 46, 22, 24, 21, 23, 
	23, 16, 47, 16, 50, 51, 52, 50, 
	50, 49, 53, 54, 55, 53, 56, 53, 
	16, 56, 16, 54, 16, 57, 58, 57, 
	59, 57, 49, 29, 30, 31, 56, 32, 
	33, 35, 37, 34, 36, 36, 16, 60, 
	61, 62, 64, 66, 63, 65, 65, 16, 
	68, 67, 16, 70, 69, 16, 72, 73, 
	74, 72, 72, 71, 75, 76, 77, 75, 
	75, 56, 16, 56, 16, 76, 16, 78, 
	79, 78, 78, 80, 71, 29, 30, 31, 
	32, 33, 35, 37, 56, 34, 36, 36, 
	16, 81, 82, 83, 84, 86, 88, 85, 
	87, 87, 16, 89, 16, 75, 90, 77, 
	75, 75, 56, 16, 80, 71, 91, 16, 
	53, 92, 55, 53, 56, 53, 16, 59, 
	49, 93, 94, 16, 95, 16, 96, 16, 
	97, 16, 98, 99, 99, 16, 100, 101, 
	101, 16, 102, 103, 103, 16, 0, 2, 
	3, 0, 4, 5, 5, 1, 105, 106, 
	105, 105, 104, 105, 106, 105, 105, 107, 
	109, 15, 110, 109, 111, 108, 109, 109, 
	112, 114, 15, 115, 114, 113, 15, 116, 
	111, 111, 117, 119, 118, 121, 120, 123, 
	124, 125, 123, 126, 123, 122, 128, 129, 
	130, 128, 131, 132, 133, 41, 42, 128, 
	127, 135, 136, 137, 135, 138, 44, 45, 
	135, 134, 139, 43, 140, 139, 33, 139, 
	16, 141, 91, 142, 141, 56, 33, 141, 
	16, 144, 145, 146, 144, 147, 144, 143, 
	149, 150, 151, 149, 152, 149, 148, 153, 
	89, 154, 153, 33, 153, 56, 16, 156, 
	157, 158, 156, 159, 160, 93, 94, 156, 
	155, 128, 129, 130, 128, 161, 162, 133, 
	128, 95, 127, 135, 136, 137, 135, 138, 
	135, 96, 134, 156, 157, 158, 156, 163, 
	160, 156, 97, 155, 128, 129, 130, 128, 
	164, 165, 133, 128, 98, 99, 99, 127, 
	135, 136, 137, 135, 138, 135, 100, 101, 
	101, 134, 156, 157, 158, 156, 166, 160, 
	156, 102, 103, 103, 155, 0
};

static const char _abnf_reader_trans_targs[] = {
	2, 0, 51, 3, 4, 5, 6, 6, 
	10, 7, 8, 9, 9, 8, 54, 56, 
	0, 13, 16, 22, 28, 37, 29, 67, 
	31, 14, 61, 14, 61, 13, 16, 22, 
	28, 20, 37, 29, 67, 31, 17, 45, 
	48, 62, 62, 15, 63, 63, 12, 12, 
	21, 23, 26, 26, 42, 24, 24, 25, 
	64, 23, 23, 65, 13, 16, 22, 28, 
	29, 67, 31, 30, 66, 30, 66, 32, 
	35, 35, 39, 33, 33, 34, 32, 32, 
	68, 13, 16, 22, 28, 37, 29, 67, 
	31, 36, 40, 27, 43, 69, 69, 70, 
	71, 72, 73, 73, 74, 74, 75, 75, 
	52, 53, 53, 52, 54, 55, 57, 58, 
	54, 54, 54, 11, 54, 54, 59, 60, 
	59, 59, 0, 15, 15, 18, 20, 0, 
	15, 15, 18, 19, 44, 20, 0, 15, 
	15, 18, 20, 15, 18, 27, 41, 0, 
	15, 15, 18, 20, 0, 15, 15, 18, 
	20, 36, 38, 0, 15, 15, 18, 44, 
	20, 46, 47, 47, 49, 50, 50
};

static const short _abnf_reader_trans_actions[] = {
	88, 0, 76, 1, 1, 85, 88, 180, 
	1, 130, 40, 188, 298, 140, 29, 133, 
	5, 144, 273, 144, 263, 253, 144, 258, 
	268, 100, 216, 1, 103, 43, 164, 43, 
	156, 1, 148, 43, 152, 160, 106, 109, 
	112, 1, 73, 180, 1, 73, 88, 180, 
	1, 37, 184, 293, 37, 88, 180, 1, 
	1, 136, 248, 37, 97, 212, 97, 79, 
	97, 204, 208, 115, 220, 1, 118, 37, 
	184, 293, 37, 88, 180, 1, 136, 248, 
	37, 91, 200, 91, 94, 79, 91, 192, 
	196, 180, 180, 180, 180, 1, 73, 79, 
	79, 79, 79, 82, 79, 82, 79, 82, 
	13, 0, 3, 15, 19, 0, 0, 0, 
	21, 25, 17, 0, 27, 23, 33, 0, 
	35, 31, 124, 308, 324, 232, 232, 49, 
	168, 278, 46, 46, 46, 46, 58, 172, 
	283, 55, 55, 88, 1, 88, 1, 127, 
	313, 330, 240, 240, 121, 303, 318, 224, 
	224, 88, 1, 67, 176, 288, 64, 64, 
	64, 46, 46, 64, 46, 46, 64
};

static const short _abnf_reader_to_state_actions[] = {
	0, 9, 9, 0, 0, 9, 9, 9, 
	9, 9, 0, 0, 9, 0, 0, 9, 
	0, 0, 0, 0, 0, 0, 0, 9, 
	9, 0, 9, 9, 0, 0, 0, 0, 
	9, 9, 0, 9, 9, 0, 0, 9, 
	9, 0, 9, 9, 0, 0, 0, 0, 
	0, 0, 0, 0, 9, 0, 9, 0, 
	0, 0, 0, 9, 0, 0, 0, 0, 
	0, 9, 0, 9, 9, 0, 0, 0, 
	0, 0, 0, 0
};

static const short _abnf_reader_from_state_actions[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 11, 0, 11, 0, 
	0, 0, 0, 11, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0
};

static const short _abnf_reader_eof_actions[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 5, 5, 5, 5, 
	5, 5, 5, 5, 5, 5, 5, 5, 
	5, 5, 5, 5, 5, 5, 5, 5, 
	5, 5, 5, 5, 5, 5, 5, 5, 
	5, 5, 5, 5, 5, 5, 5, 5, 
	5, 5, 5, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 236, 52, 61, 
	7, 7, 244, 228, 7, 70, 52, 61, 
	70, 52, 61, 70
};

static const short _abnf_reader_eof_trans[] = {
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 15, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 108, 0, 113, 
	114, 117, 118, 0, 121, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0
};

static const int abnf_reader_start = 1;
static const int abnf_reader_first_final = 51;

static const int abnf_reader_en_rulename_scan = 52;
static const int abnf_reader_en_c_wsp_scan = 54;
static const int abnf_reader_en_equal_scan = 59;
static const int abnf_reader_en_alternation = 12;
static const int abnf_reader_en_main = 1;


/* #line 443 "parse_abnf.rl" */

	char *p, *pe, *buff, *ts, *te, *eof;
	int cs, top, stack[50], act;
	struct abnf_str last_rulename, last_str;
	unsigned int last_val, last_val_mult;
	int assign_rule_flag, token_flag, val_flag;
	struct abnf_rule *last_rule = NULL;
	unsigned int line;
	struct {
		struct abnf_alternation **top;
		struct abnf_alternation *prev;
		struct abnf_concatenation *conc_prev;
	} alternation_stack[ABNF_MAX_ALTERNATION];
	unsigned int alternation_count = 0;

	size_t i, n;

	/* read file into buffer */
	buff = NULL;
	n = 0;
	do {
		p = abnf_realloc(buff, n + ABNF_BUFF_CHUNK);
		if (!p) {
			if (buff) abnf_free(buff);
			return -1;
		}
		buff = p;
		i = fread(buff+n, sizeof(*buff), ABNF_BUFF_CHUNK, in_stream);
		n += i;
	} while (i == ABNF_BUFF_CHUNK);
	/* ABNF defines line ends as CRLF so adjust CR / LF */
	pe = buff + n;
	p = buff;

	
/* #line 319 "parse_abnf.c" */
	{
	cs = abnf_reader_start;
	top = 0;
	ts = 0;
	te = 0;
	act = 0;
	}

/* #line 478 "parse_abnf.rl" */
	line = 1;
	/* unwarnings */
	assign_rule_flag = token_flag = val_flag = 0;
	last_val = last_val_mult = 0;
	last_rulename.s = last_str.s = 0;
	last_rulename.len = last_str.len = 0;
	i = abnf_reader_en_rulename_scan;
	i = abnf_reader_en_c_wsp_scan;
	i = abnf_reader_en_equal_scan;
	i = abnf_reader_en_alternation;
	i = abnf_reader_en_main;

	for (last_rule = *rules; last_rule && last_rule->next; last_rule=last_rule->next);

	
/* #line 326 "parse_abnf.c" */
	{
	int _klen;
	unsigned int _trans;
	const char *_acts;
	unsigned int _nacts;
	const char *_keys;

	if ( p == pe )
		goto _test_eof;
	if ( cs == 0 )
		goto _out;
_resume:
	_acts = _abnf_reader_actions + _abnf_reader_from_state_actions[cs];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 ) {
		switch ( *_acts++ ) {
	case 39:
/* #line 1 "NONE" */
	{ts = p;}
	break;
/* #line 345 "parse_abnf.c" */
		}
	}

	_keys = _abnf_reader_trans_keys + _abnf_reader_key_offsets[cs];
	_trans = _abnf_reader_index_offsets[cs];

	_klen = _abnf_reader_single_lengths[cs];
	if ( _klen > 0 ) {
		const char *_lower = _keys;
		const char *_mid;
		const char *_upper = _keys + _klen - 1;
		while (1) {
			if ( _upper < _lower )
				break;

			_mid = _lower + ((_upper-_lower) >> 1);
			if ( (*p) < *_mid )
				_upper = _mid - 1;
			else if ( (*p) > *_mid )
				_lower = _mid + 1;
			else {
				_trans += (unsigned int)(_mid - _keys);
				goto _match;
			}
		}
		_keys += _klen;
		_trans += _klen;
	}

	_klen = _abnf_reader_range_lengths[cs];
	if ( _klen > 0 ) {
		const char *_lower = _keys;
		const char *_mid;
		const char *_upper = _keys + (_klen<<1) - 2;
		while (1) {
			if ( _upper < _lower )
				break;

			_mid = _lower + (((_upper-_lower) >> 1) & ~1);
			if ( (*p) < _mid[0] )
				_upper = _mid - 2;
			else if ( (*p) > _mid[1] )
				_lower = _mid + 2;
			else {
				_trans += (unsigned int)((_mid - _keys)>>1);
				goto _match;
			}
		}
		_trans += _klen;
	}

_match:
	_trans = _abnf_reader_indicies[_trans];
_eof_trans:
	cs = _abnf_reader_trans_targs[_trans];

	if ( _abnf_reader_trans_actions[_trans] == 0 )
		goto _again;

	_acts = _abnf_reader_actions + _abnf_reader_trans_actions[_trans];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 )
	{
		switch ( *_acts++ )
		{
	case 0:
/* #line 35 "parse_abnf.rl" */
	{
		if (abnf_stop_flag) {p++; goto _out; }
//		DBG("$");
	}
	break;
	case 1:
/* #line 40 "parse_abnf.rl" */
	{
		struct abnf_concatenation *pc;
		pc = top_stack.conc_prev;
		DBG("add_group");
		top_element.type = ABNF_ET_GROUP;
		top_element.u.group = NULL;
		if (alternation_count < ABNF_MAX_ALTERNATION-1) {
			DBG_STACK("AG++");
			alternation_count++;
			top_stack.top = &pc->repetition.element.u.group;
			top_stack.prev = NULL;
			top_stack.conc_prev = NULL;
		}
		else {
			fprintf(stderr, "alternation stack overflow\n");
			{p++; goto _out; }
		}
		p--;
		{stack[top++] = cs; cs = 12; goto _again;}
	}
	break;
	case 2:
/* #line 61 "parse_abnf.rl" */
	{
		DBG("add_rule");
		if (alternation_count < ABNF_MAX_ALTERNATION-1) {
			struct abnf_rule *pr;

			DBG_STACK("AR++");
			alternation_count++;

			pr = abnf_find_rule(*rules, last_rulename);
			// fprintf(stderr, "adding rule:'%.*s'\n", last_rulename.len, last_rulename.s);
			if (!assign_rule_flag) {  /* "=/" */
				DBG("finding rule");
				if (!pr) DBG("not found");
			}
			else {    /* "=" */
				if (pr) {
					fprintf(stderr, "WARNING: overwriting rule '%.*s', comming from '%.*s' by '%.*s'\n",
						last_rulename.len, last_rulename.s,
						pr->origin.len, pr->origin.s,
						origin.len, origin.s);
					if (pr == last_rule) {
						last_rule = last_rule->prev;  /* last_rule is != NULL because pr!= NULL, if ->prev nil then no item left */
					}
					abnf_remove_list_item(*rules, pr);
					abnf_destroy_rules(pr);
					pr = NULL;  /* "=" */
				}
			}
			if (!pr) {
				pr = abnf_add_rule(
					abnf_dupl_str(last_rulename),
					NULL,
					NULL
				);
				if (!pr) {p++; goto _out; }
				if (origin.len) {
					abnf_rule_assign_origin(pr, NULL, abnf_dupl_str(origin));
				}
				if (!last_rule) {
					*rules = pr;

				}
				else {
					last_rule->next = pr;
					pr->prev = last_rule;
				}
				last_rule = pr;
			}

			top_stack.top = &pr->alternation;
			if (pr->alternation) {
				for (top_stack.prev = pr->alternation;
					top_stack.prev->next;
					top_stack.prev = top_stack.prev->next);
			}
			else {
				top_stack.prev = NULL;
			}
			top_stack.conc_prev = NULL;
		}
		else {
			fprintf(stderr, "alternation stack overflow\n");
			{p++; goto _out; }
		}
		p--;
		{stack[top++] = cs; cs = 12; goto _again;}
	}
	break;
	case 3:
/* #line 129 "parse_abnf.rl" */
	{
		struct abnf_alternation *pa;
		DBG("add_alternation");
		pa = abnf_add_alternation(NULL, NULL);
		if (!pa) {p++; goto _out; }
		if (top_stack.prev == NULL) {
			*(top_stack.top) = pa;
		}
		else {
			top_stack.prev->next = pa;
			pa->prev = top_stack.prev;
		}
		top_stack.prev = pa;
		top_stack.conc_prev = NULL;
	}
	break;
	case 4:
/* #line 145 "parse_abnf.rl" */
	{
		struct abnf_concatenation *pc;
		struct abnf_element r;
		DBG("add_concatenation");
		r.type = ABNF_ET_NONE;
		pc = abnf_add_concatenation(abnf_mk_repetition(r, 1, 1), NULL);
		if (!pc) {p++; goto _out; }
		if (top_stack.conc_prev == NULL) {
			top_stack.prev->concatenation = pc;
		}
		else {
			top_stack.conc_prev->next = pc;
			pc->prev = top_stack.conc_prev;
		}
		top_stack.conc_prev = pc;
		val_flag = 0;
		last_val = 0; last_val_mult = 10;
	}
	break;
	case 5:
/* #line 164 "parse_abnf.rl" */
	{
		top_element = abnf_mk_element_range(last_val, last_val);
		last_val = 0;
	}
	break;
	case 6:
/* #line 169 "parse_abnf.rl" */
	{
		top_element.u.range.hi = last_val;
	}
	break;
	case 7:
/* #line 173 "parse_abnf.rl" */
	{
		if (top_element.type == ABNF_ET_RANGE) {
			/* change range to string */
			struct abnf_str s;
			char buff[2];
			s.len = sizeof(buff);
			s.s = buff;
			buff[0] = top_element.u.range.lo;
			buff[1] = (char) last_val;
			top_element = abnf_mk_element_string(abnf_dupl_str(s));
			if (!top_element.u.string.s) {p++; goto _out; }
		}
		else {
			/* prev alloc was sucessfull otherwise called fbreak */
			char *p;
			p = abnf_realloc(top_element.u.string.s, top_element.u.string.len+1);
			if (!p) {p++; goto _out; }
			p[top_element.u.string.len++] = last_val;
			top_element.u.string.s = p;
		}
		last_val = 0;
	}
	break;
	case 8:
/* #line 199 "parse_abnf.rl" */
	{last_val = (last_val * last_val_mult) + ((*p)-'0');}
	break;
	case 9:
/* #line 202 "parse_abnf.rl" */
	{ line++;}
	break;
	case 10:
/* #line 206 "parse_abnf.rl" */
	{last_val = (last_val * last_val_mult) + ((*p)-'0'); val_flag = 1;}
	break;
	case 11:
/* #line 210 "parse_abnf.rl" */
	{
			last_val = (last_val * last_val_mult) + (10+(*p)-(((*p)>='A' && (*p)<='F')?'A':'a'));
		}
	break;
	case 12:
/* #line 236 "parse_abnf.rl" */
	{
		last_rulename.len = 0;
		p--;
		DBG("call-rulename_scan");
		{stack[top++] = cs; cs = 52; goto _again;}
	}
	break;
	case 13:
/* #line 281 "parse_abnf.rl" */
	{
		p--;
		DBG("call c_wsp_scan");
		{stack[top++] = cs; cs = 54; goto _again;}
	}
	break;
	case 14:
/* #line 308 "parse_abnf.rl" */
	{
			if (val_flag) {
				top_stack.conc_prev->repetition.min = last_val;
				top_stack.conc_prev->repetition.max = last_val;
			}
		}
	break;
	case 15:
/* #line 315 "parse_abnf.rl" */
	{
				top_stack.conc_prev->repetition.min = val_flag?last_val:0;
				val_flag = 0;
				last_val = 0;
				top_stack.conc_prev->repetition.max = ABNF_INFINITY;
			}
	break;
	case 16:
/* #line 321 "parse_abnf.rl" */
	{
				if (val_flag) {
					top_stack.conc_prev->repetition.max = last_val;
				}
			}
	break;
	case 17:
/* #line 336 "parse_abnf.rl" */
	{top_stack.conc_prev->repetition.min = 0; top_stack.conc_prev->repetition.max = 1;}
	break;
	case 18:
/* #line 344 "parse_abnf.rl" */
	{token_flag = 1; last_str.s = p;}
	break;
	case 19:
/* #line 345 "parse_abnf.rl" */
	{last_str.len = p-last_str.s;}
	break;
	case 20:
/* #line 348 "parse_abnf.rl" */
	{last_val_mult=2;}
	break;
	case 21:
/* #line 354 "parse_abnf.rl" */
	{last_val_mult=10;}
	break;
	case 22:
/* #line 360 "parse_abnf.rl" */
	{last_val_mult=16;}
	break;
	case 23:
/* #line 366 "parse_abnf.rl" */
	{last_val = 0;}
	break;
	case 24:
/* #line 371 "parse_abnf.rl" */
	{token_flag = 0; last_str.s = p;}
	break;
	case 25:
/* #line 372 "parse_abnf.rl" */
	{last_str.len = p-last_str.s;}
	break;
	case 26:
/* #line 376 "parse_abnf.rl" */
	{top_element = abnf_mk_element_rule(abnf_dupl_str(last_rulename));}
	break;
	case 27:
/* #line 377 "parse_abnf.rl" */
	{top_element = abnf_mk_element_rule(abnf_dupl_str(last_rulename)); DBG("%!rulename");}
	break;
	case 29:
/* #line 382 "parse_abnf.rl" */
	{top_element = abnf_mk_element_token(abnf_dupl_str(last_str));}
	break;
	case 30:
/* #line 383 "parse_abnf.rl" */
	{top_element = abnf_mk_element_token(abnf_dupl_str(last_str));DBG("%!charval");}
	break;
	case 32:
/* #line 387 "parse_abnf.rl" */
	{top_element = abnf_mk_element_string(abnf_dupl_str(last_str));}
	break;
	case 33:
/* #line 388 "parse_abnf.rl" */
	{top_element = abnf_mk_element_string(abnf_dupl_str(last_str));DBG("%!proseval");}
	break;
	case 35:
/* #line 398 "parse_abnf.rl" */
	{
					alternation_count--;
					DBG_STACK("AC--");
					p--;
					DBG("$!RETAL");
					{cs = stack[--top]; goto _again;}
				}
	break;
	case 37:
/* #line 414 "parse_abnf.rl" */
	{ p--; {stack[top++] = cs; cs = 59; goto _again;} }
	break;
	case 40:
/* #line 1 "NONE" */
	{te = p+1;}
	break;
	case 41:
/* #line 229 "parse_abnf.rl" */
	{te = p+1;{
			p--;
			{cs = stack[--top]; goto _again;}
		}}
	break;
	case 42:
/* #line 222 "parse_abnf.rl" */
	{te = p;p--;{
			DBG("rulename_scan-A");
			last_rulename.s = ts;
			last_rulename.len = te-ts;
			{cs = stack[--top]; goto _again;}
		}}
	break;
	case 43:
/* #line 256 "parse_abnf.rl" */
	{te = p+1;{
			DBG("c_wsp_scan-CRLR WSP");
		}}
	break;
	case 44:
/* #line 274 "parse_abnf.rl" */
	{te = p+1;{
			p--;
			DBG("c_wsp_scan-ANY");
			{cs = stack[--top]; goto _again;}
		}}
	break;
	case 45:
/* #line 251 "parse_abnf.rl" */
	{te = p;p--;{
			DBG("c_wsp_scan-WSP");
		}}
	break;
	case 46:
/* #line 261 "parse_abnf.rl" */
	{te = p;p--;{
			DBG("c_wsp_scan-\";\" CRLR WSP");
		}}
	break;
	case 47:
/* #line 266 "parse_abnf.rl" */
	{te = p;p--;{
			if (*p == '\n') line--;
			p--; /* set LF as next char */
			DBG("c_wsp_scan-CRLF");
			{cs = stack[--top]; goto _again;}
		}}
	break;
	case 48:
/* #line 274 "parse_abnf.rl" */
	{te = p;p--;{
			p--;
			DBG("c_wsp_scan-ANY");
			{cs = stack[--top]; goto _again;}
		}}
	break;
	case 49:
/* #line 266 "parse_abnf.rl" */
	{{p = ((te))-1;}{
			if (*p == '\n') line--;
			p--; /* set LF as next char */
			DBG("c_wsp_scan-CRLF");
			{cs = stack[--top]; goto _again;}
		}}
	break;
	case 50:
/* #line 289 "parse_abnf.rl" */
	{te = p+1;{
			assign_rule_flag = 0;
			//fhold;
			DBG("equal_scan-'=/'");
			{cs = stack[--top]; goto _again;}
		}}
	break;
	case 51:
/* #line 301 "parse_abnf.rl" */
	{te = p+1;{
			p--;
			{cs = stack[--top]; goto _again;}
		}}
	break;
	case 52:
/* #line 295 "parse_abnf.rl" */
	{te = p;p--;{
			assign_rule_flag = 1;
			//fhold;
			DBG("equal_scan-'='");
			{cs = stack[--top]; goto _again;}
		}}
	break;
/* #line 772 "parse_abnf.c" */
		}
	}

_again:
	_acts = _abnf_reader_actions + _abnf_reader_to_state_actions[cs];
	_nacts = (unsigned int) *_acts++;
	while ( _nacts-- > 0 ) {
		switch ( *_acts++ ) {
	case 38:
/* #line 1 "NONE" */
	{ts = 0;}
	break;
/* #line 783 "parse_abnf.c" */
		}
	}

	if ( cs == 0 )
		goto _out;
	if ( ++p != pe )
		goto _resume;
	_test_eof: {}
	if ( p == eof )
	{
	if ( _abnf_reader_eof_trans[cs] > 0 ) {
		_trans = _abnf_reader_eof_trans[cs] - 1;
		goto _eof_trans;
	}
	const char *__acts = _abnf_reader_actions + _abnf_reader_eof_actions[cs];
	unsigned int __nacts = (unsigned int) *__acts++;
	while ( __nacts-- > 0 ) {
		switch ( *__acts++ ) {
	case 5:
/* #line 164 "parse_abnf.rl" */
	{
		top_element = abnf_mk_element_range(last_val, last_val);
		last_val = 0;
	}
	break;
	case 6:
/* #line 169 "parse_abnf.rl" */
	{
		top_element.u.range.hi = last_val;
	}
	break;
	case 7:
/* #line 173 "parse_abnf.rl" */
	{
		if (top_element.type == ABNF_ET_RANGE) {
			/* change range to string */
			struct abnf_str s;
			char buff[2];
			s.len = sizeof(buff);
			s.s = buff;
			buff[0] = top_element.u.range.lo;
			buff[1] = (char) last_val;
			top_element = abnf_mk_element_string(abnf_dupl_str(s));
			if (!top_element.u.string.s) {p++; goto _out; }
		}
		else {
			/* prev alloc was sucessfull otherwise called fbreak */
			char *p;
			p = abnf_realloc(top_element.u.string.s, top_element.u.string.len+1);
			if (!p) {p++; goto _out; }
			p[top_element.u.string.len++] = last_val;
			top_element.u.string.s = p;
		}
		last_val = 0;
	}
	break;
	case 26:
/* #line 376 "parse_abnf.rl" */
	{top_element = abnf_mk_element_rule(abnf_dupl_str(last_rulename));}
	break;
	case 28:
/* #line 378 "parse_abnf.rl" */
	{top_element = abnf_mk_element_rule(abnf_dupl_str(last_rulename)); DBG("%/rulename");}
	break;
	case 29:
/* #line 382 "parse_abnf.rl" */
	{top_element = abnf_mk_element_token(abnf_dupl_str(last_str));}
	break;
	case 31:
/* #line 384 "parse_abnf.rl" */
	{top_element = abnf_mk_element_token(abnf_dupl_str(last_str));DBG("%/charval");}
	break;
	case 32:
/* #line 387 "parse_abnf.rl" */
	{top_element = abnf_mk_element_string(abnf_dupl_str(last_str));}
	break;
	case 34:
/* #line 389 "parse_abnf.rl" */
	{top_element = abnf_mk_element_string(abnf_dupl_str(last_str));DBG("%/proseval");}
	break;
	case 35:
/* #line 398 "parse_abnf.rl" */
	{
					alternation_count--;
					DBG_STACK("AC--");
					p--;
					DBG("$!RETAL");
					{cs = stack[--top]; goto _again;}
				}
	break;
	case 36:
/* #line 405 "parse_abnf.rl" */
	{
					DBG_STACK("AT--");
				}
	break;
/* #line 868 "parse_abnf.c" */
		}
	}
	}

	_out: {}
	}

/* #line 493 "parse_abnf.rl" */

	if (cs < abnf_reader_first_final) {
		fprintf(stderr, "origin:'%.*s', line: %u, cs: %d, rule parsing error at %d\n", origin.len, origin.s, line, cs, p-buff);
		if (pe-p<=MAX_ERR_LIST_LEN) {
			fprintf(stderr, "%.*s\n", pe-p, p);
		}
		else {
			fprintf(stderr, "%.*s\n.......and %d chars continue\n", MAX_ERR_LIST_LEN, p, pe-p-MAX_ERR_LIST_LEN);
		}
	}
	else if (alternation_count > 1) {  /* BUG?: it should be zero but it's permanently 1 */
		fprintf(stderr, "stack is not empty, ac: %d, top: %d, cs: %d\n", alternation_count, top, cs);
	}
	abnf_free(buff);

	return 0;
}
