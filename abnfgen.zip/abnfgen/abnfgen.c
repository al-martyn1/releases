/*
 *  Copyright 2007 by Tomas Mandys <tomas.mandys at 2p dot cz>
 */

/*  This file is part of abnf tools.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  It is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Ragel; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#define ABNFGEN_C 1

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "abnf.h"

#if !defined(_MSC_VER)
    #include <unistd.h>
#else
    #include "gccstub.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#if !defined(_MSC_VER)
    #include <libgen.h>
#endif
#include <errno.h>

#define _GNU_SOURCE

#if !defined(_MSC_VER)
    #include <getopt.h>
#endif

#include <signal.h>
#include <string.h>

#ifndef RULCHK_RAGEL_H
    #include "rulchk_ragel.h"
#endif

/*
#define GETOPT_DEBUG 1
*/


static int verbose = 0;
int add_ragel_actions = 0;
int add_ragel_actions_bodies = 0; /* 0 no, 1 empty, 2 text, ( 3 code, 4 - proto - used internally )*/
int print_c_prototypes = 0;
int disable_ragel_prolog_epilog = 0;
char ragel_machine_name[256]   = "generated_from_abnf";
char ragel_actions_prefix[256] = "generated_from_abnf_";

char *ragelActionsCode[3] = { 0,0,0 };
int inlineRagelActionsCode = 0;

str_pair_t ragel_custom_rules[4096];
int        ragel_custom_rules_count = 0;

char*      ragel_custom_actions[4096];
int        ragel_custom_actions_count = 0;

char *action_handler_params = 0;
char *action_call_params    = 0;
char *ragel_alphatype       = 0;
char *ragel_access          = 0;

char *template_file = NULL;
struct abnf_rule *rules = NULL, *pr;
FILE *out_stream, *in_stream;
struct abnf_print_info info;


void printRagelActionCodeHandlers( int optch, const char *where)
{
    #ifdef GETOPT_DEBUG
    unsigned i = 0;
    unsigned nCodes = 0;
    printf("%s, optind: %i, char: %c (%i)\n", where, optind, (char)optch, optch);
    for(; i!=3; ++i)
       {
        if (ragelActionsCode[i]) nCodes++;
        printf("ragelActionsCode[%u]: %s\n", i, ragelActionsCode[i]==0?"NULL":ragelActionsCode[i]);
       }
    printf("Actions with code: %u\n---\n", nCodes);
    #endif
}


static void print_version() {
    printf("%s", NAME_S " - ABNF generator, v" VERSION_S "\n");
}

static void print_help(char *name) {
    print_version();
    printf("Usage: %s [options] <file> [[options] <file> ...]\n", basename(name));
    printf("Following internal rule lists supported\n");
    printf("  'core': rfc2234 core rules\n");
    printf("  'abnf': rfc2234 ABNF rules\n");
    printf("  '-':    forces reading from stdin\n");
    printf("\n");
    printf("  -f format   format of output\n");
    printf("              'abnf':  print ABNF rules\n");
    printf("              'ragel': print Ragel rules (default)\n");
    printf("              'self':  print abnfgen C rules\n");
    printf("  -o file     output file name, default: stdout\n");
    printf("  -t in_type  type of next input file\n");
    printf("              'file': load rules from file\n");
    printf("              'self': load internal rules (default)\n");
    printf("\n");
    printf("Common options:\n");
    printf("  -F          print output even an ABNF rule error is detected\n");
    printf("  -h,-H       print this help\n");
    printf("  -v          print more info to stderr\n");
    printf("  -V          print version\n");
    printf("\n");
    printf("Ragel options:\n");
    printf("  -a          add entering/leaving/all transitions\n");
    printf("              action handlers to ragel output for all possible rules\n");
    printf("              (this feature can be turned on only for exact\n");
    printf("              specified rules using -r option)\n");
    printf("  -A def      add action definitions to ragel output\n");
    printf("              def (definition): \n");
    printf("              'empty': empty action definitions\n");
    printf("              'text': action definitions with text\n");
    printf("  -c X:code_string print code in action handlers\n");
    printf("              where 'X': E - for enter, L - for leave\n");
    printf("              , T - for transition action handlers\n");
    printf("              , and 'code_string' is some portion of C/C++ code\n");
    printf("              'X:' prefix can be skipped to use code for all action handler types\n");
    printf("  -i          add 'inline' keyword for action handler functions with code\n");
    /*printf("              'code': generate 'C' code for functions\n");*/
    printf("  -D list     set 'C' lang action handler parameters list\n");
    printf("              (int,char,...) etc\n");
    printf("  -C list     set 'C' lang action handler call arguments\n");
    printf("              (i,fc,...) etc\n");
    printf("  -M name     set ragel's machine name\n");
    printf("  -L alphtype set ragel's machine alphtype\n");
    printf("  -S access   set ragel's access statement\n");
    printf("  -P prefix   set ragel's actions prefix\n");
    printf("  -p          do not print ragel's\n");
    printf("              prolog/epilog code\n");
    printf("  -r name     add actions to rule 'name'\n");
    printf("  -T file     use template file 'file'\n");
    printf("              to output ragel (/*%%%%#M#%%%%*/ and /*%%%%#C#%%%%*/\n");
    printf("              are only special points to place\n");
    printf("              machine definition and 'C' code for actions)\n");
    printf("              \n");
    printf("  -u file     set ragel rules file.\n");
    printf("              Each line contain one ragel rule, which will be used\n");
    printf("              instead of generating rule with the same name.\n");
    printf("              Lines started with ';' or '#' are ignored.\n");
    printf("Examples:\n");
    printf("  %s core rfc3261.txt -f ragel -F -o rfc3261.rl\n", basename(name));
    printf("  %s core - -f abnf\n", basename(name));
    printf("\n");
}

int abnf_stop_flag = 0;

static void sig_term(int signr) {
    abnf_stop_flag++;
    fprintf(stderr, "Signal (%d) detected\n", signr);
    if (signr != SIGINT || abnf_stop_flag > 1) { /* double ^C */
        exit(0);
    }
}
#define SIGNAL(sig) \
    if (signal(sig, sig_term) == SIG_ERR) {\
        printf("can't install signal handler for %s\n", #sig);\
        exit (-1);\
}

int abnf_is_space( char ch );
void abnf_str_rtrim( char *str );
char* abnf_str_ltrim( char *str );

int abnf_is_space( char ch )
{
    if (ch==0x09 || ch==0x0A || ch==0x0D || ch==' ') return 1;
    return 0;
}

void abnf_str_rtrim( char *str )
{
    int len = strlen(str);
    while(len>0 && abnf_is_space(str[len-1]) ) --len;
    str[len] = 0;
}

char* abnf_str_ltrim( char *str )
{
    while(*str && abnf_is_space(*str) ) ++str;
    return str;
}

int read_ragel_rules( const char *filename )
{
    char buf[4096];
    char *first, *second;
    int lineNo = 0;
    int len;
    int use_actions = 0;


    FILE *fin = fopen(filename, "rt");  /* it's null terminated */
    if (!fin)
       {
        fprintf(stderr, "ERROR: failed to open ragel rules file %s\n", filename );
        return -1;
       }

    while( fgets(&buf[0], sizeof(buf), fin) )
       {
        ++lineNo;
        first = abnf_str_ltrim(buf);
        abnf_str_rtrim(first);
        if ( strcmp(first,"#actions#")==0 || strcmp(first,";actions;")==0 )
           {
            use_actions = 1; continue;
           }
        if ( strcmp(first,"#rules#")==0 || strcmp(first,";rules;")==0 )
           {
            use_actions = 0; continue;
           }

        if (!*first || *first==';' || *first=='#') continue;

        if (use_actions)
           {
            if (ragel_custom_actions_count>=1024)
               {
                fprintf(stderr, "ERROR: the maximum number of custom ragel actions reached (-u option)\n" );
                return -1;
               }

            ragel_custom_actions[ragel_custom_actions_count] = (char*)malloc( strlen(first)+1 );
            strcpy(ragel_custom_actions[ragel_custom_actions_count], first );
            ++ragel_custom_actions_count;
           }
        else
           {
            if (ragel_custom_rules_count>=4096)
               {
                fprintf(stderr, "ERROR: the maximum number of custom ragel rules reached (-u option)\n" );
                return -1;
               }

            second = first;
            while(*second && *second!='=') ++second;
            if (!*second)
               {
                fprintf(stderr, "ERROR: invalid rule definition in line %d, file: %s\n", lineNo, filename );
                return -1;
               }
            *second = 0; ++second;
            first = abnf_str_ltrim( first );
            abnf_str_rtrim( first );
            second = abnf_str_ltrim( second );
            abnf_str_rtrim( second );
            len = strlen(second);
            if (len>0 && second[len-1]==';') 
               {
                second[len-1] = 0;
                abnf_str_rtrim( second );
               }
    
            ragel_custom_rules[ragel_custom_rules_count].first  = (char*)malloc(strlen(first)+1);
            strcpy( ragel_custom_rules[ragel_custom_rules_count].first, first );
            ragel_custom_rules[ragel_custom_rules_count].second = (char*)malloc(strlen(second)+1);
            strcpy( ragel_custom_rules[ragel_custom_rules_count].second, second );
            /*fprintf( stderr, "[%s] = [%s]\n", ragel_custom_rules[ragel_custom_rules_count].first, ragel_custom_rules[ragel_custom_rules_count].second );*/
            ++ragel_custom_rules_count;

           }
       }

    return 0;
}




const str_pair_t* find_ragel_custom_rule( const char *rulename )
{
    int i = 0;
    for(; i!=ragel_custom_rules_count; ++i)
       {
        if (strcmp( ragel_custom_rules[i].first, rulename )==0) return &ragel_custom_rules[i];
       }
    return 0;
}


int main(int argc, char** argv) {

    #define MAX_IN_FILES 50

    enum {of_Default, of_Ragel, of_Abnf, of_Self} out_fmt = of_Default;
    enum {if_File, if_Internal} cur_in_fmt = if_Internal, in_flags[MAX_IN_FILES];
    static char short_opts[] = "+f:o:t:M:L:P:A:r:T:D:C:c:S:u:iFhHvVap";
    int i, c, in_file_count = 0, force_flag = 0;
    struct abnf_str in_files[MAX_IN_FILES];
    char *out_file = NULL;
    int argNo = 1;


    /*
    char *template_file = NULL;
    struct abnf_rule *rules = NULL, *pr;
    FILE *out_stream, *in_stream;
    struct abnf_print_info info;
    */

    /* default initialization failed ? */
    ragelActionsCode[0] = 0;
    ragelActionsCode[1] = 0;
    ragelActionsCode[2] = 0;
    /*
    {
            unsigned i = 0;
            for(; i!=3; ++i)
               {
                fprintf(out_stream, "1 ragelActionsCode[%u]: %s\n", i, ragelActionsCode[i]==0?"NULL":ragelActionsCode[i]);
               }
    }
    */


    #define append_rule(_pr_) {\
        if (_pr_) { \
            if (rules == NULL) { \
                rules = (_pr_); \
            } \
            else { \
                struct abnf_rule *last_rule = NULL; \
                for (last_rule = rules; last_rule->next; last_rule=last_rule->next);\
                last_rule->next = (_pr_); \
                (_pr_)->prev = last_rule; \
            } \
        } \
    }


    /* look if there is a -h, e.g. -f -h construction won't catch it later */

    #ifdef GETOPT_DEBUG
    printf("Args (1):\n");
    for(argNo = 1; argNo<argc; ++argNo)
       printf("argv[%i]: [%s]\n", argNo, argv[argNo]);
    printf("\n");
    #endif

    optind = 1;  /* reset getopt */
    opterr = 0;
    while (optind < argc) {
        c = getopt(argc, argv, short_opts);
        if (optind > argc)
            break;
        if (c == 'h' || (optarg && strcmp(optarg, "-h") == 0)) {
            print_help(argv[0]);
            return 0;
        }
        if (c == -1) optind++;
    }

    #ifdef GETOPT_DEBUG
    printf("Args (2):\n");
    for(argNo = 1; argNo<argc; ++argNo)
       printf("argv[%i]: [%s]\n", argNo, argv[argNo]);
    printf("\n");
    #endif

    optind = 1;  /* reset getopt */
    opterr = 0;
    while (optind < argc) {
        c = getopt(argc, argv, short_opts);
        if (optind > argc)
            break;
        #ifdef GETOPT_DEBUG
        printf("getopt returns: '%c', optind: %i, argv[optind]: %s, optarg: %s\n", c, optind, argv[optind], optarg==0?"NULL":optarg);
        printf("Args (3):\n");
        for(argNo = 1; argNo<argc; ++argNo)
           printf("argv[%i]: [%s]\n", argNo, argv[argNo]);
        printf("\n");
        #endif

        if (c == -1) {
            printRagelActionCodeHandlers(c,"INPUT 1");
            if (in_file_count < MAX_IN_FILES) {
                in_files[in_file_count] = abnf_mk_str(argv[optind]);
                in_flags[in_file_count] = cur_in_fmt;
                in_file_count++;
            }
            //printf("argv[optind]: %s\n", argv[optind]);
            optind++;
            //if (optind < argc)
            //   printf("argv[++optind]: %s\n", argv[optind]);
            printRagelActionCodeHandlers(c,"INPUT 2");
        }
        else {
            switch (c) {
                case 'f':
                    printRagelActionCodeHandlers(c,"f");
                    if (out_fmt) {
                        fprintf(stderr, "ERROR: only one -f options allowed\n");
                        goto err;
                    }
                    if (strcasecmp("rl", optarg)==0 || strcasecmp("ragel", optarg)==0)
                        out_fmt = of_Ragel;
                    else if (strcasecmp("abnf", optarg)==0)
                        out_fmt = of_Abnf;
                    else if (strcasecmp("self", optarg)==0)
                        out_fmt = of_Self;
                    else {
                        fprintf(stderr, "ERROR: unknown format '-f %s'\n", optarg);
                        goto err;
                    }
                    break;
                case 't':
                    printRagelActionCodeHandlers(c,"t");
                    if (strcasecmp("self", optarg)==0)
                        cur_in_fmt = if_Internal;
                    else if (strcasecmp("file", optarg)==0)
                        cur_in_fmt = if_File;
                    else {
                        fprintf(stderr, "ERROR: unknown type '-t %s'\n", optarg);
                        goto err;
                    }
                    break;
                case 'M':
                    printRagelActionCodeHandlers(c,"M");
                    strcpy(ragel_machine_name, optarg);
                    if (strcmp(ragel_actions_prefix, "generated_from_abnf_")==0)
                       {
                        strcpy(ragel_actions_prefix, optarg);
                        strcat(ragel_actions_prefix, "_");
                       }
                    break;
                case 'L':
                    printRagelActionCodeHandlers(c,"L");
                    ragel_alphatype = optarg;
                    break;
                case 'P':
                    printRagelActionCodeHandlers(c,"P");
                    strcpy(ragel_actions_prefix, optarg);
                    break;
                case 'o':
                    printRagelActionCodeHandlers(c,"o");
                    out_file = optarg;
                    break;
                case 'F':
                    printRagelActionCodeHandlers(c,"F");
                    force_flag++;
                    break;
                case 'v':
                    printRagelActionCodeHandlers(c,"v");
                    verbose++;
                    break;
                case 'V':
                    printRagelActionCodeHandlers(c,"V");
                    print_version();
                    return 0;
                case 'a':
                    printRagelActionCodeHandlers(c,"a");
                    add_ragel_actions++;
                    break;
                case 'c':
                    {
                     printRagelActionCodeHandlers(c,"c1");
                     if (strlen(optarg) < 2)
                         {
                          fprintf(stderr, "ERROR: -c if (strlen(optarg) < 2)\n");
                          break;
                         }
                     printRagelActionCodeHandlers(c,"c2");
                     int at = 2;
                     if (*(optarg+1)==':')
                        {
                         printRagelActionCodeHandlers(c,"c3");
                         fprintf(stderr, "ERROR: -c if (*(optarg+1)==':')\n");
                         if (*optarg=='E' || *optarg=='e')
                            {
                             printRagelActionCodeHandlers(c,"c4");
                             fprintf(stderr, "ERROR: -c if (*optarg=='E' || *optarg=='e')\n");
                             at = 0;
                            }
                         else if (*optarg=='L' || *optarg=='l')
                            {
                             printRagelActionCodeHandlers(c,"c6");
                             fprintf(stderr, "ERROR: -c else if (*optarg=='E' || *optarg=='e')\n");
                             at = 1;
                            }
                         printRagelActionCodeHandlers(c,"c7");
                         optarg += 2;
                         ragelActionsCode[at] = optarg;
                         fprintf(stderr, "ERROR: -c set %u inline to %s\n", at, ragelActionsCode[at]);
                         printRagelActionCodeHandlers(c,"c8");
                        }
                     else
                        {
                         printRagelActionCodeHandlers(c,"c9");
                         fprintf(stderr, "ERROR: -c COMMON\n");
                         ragelActionsCode[0] = optarg;
                         ragelActionsCode[1] = optarg;
                         ragelActionsCode[2] = optarg;
                        }
                     printRagelActionCodeHandlers(c,"c10");
                    }
                    break;
                case 'r':
                    printRagelActionCodeHandlers(c,"r1");
                    #ifdef GETOPT_DEBUG
                    printf("%s\n", optarg);
                    #endif
                    abnf_add_rule_to_allowed_actions( optarg );
                    printRagelActionCodeHandlers(c,"r2");
                    break;
                case 'T':
                    printRagelActionCodeHandlers(c,"T");
                    template_file = optarg;
                    break;
                case 'D':
                    printRagelActionCodeHandlers(c,"D");
                    action_handler_params = optarg;
                    break;
                case 'C':
                    printRagelActionCodeHandlers(c,"C");
                    action_call_params = optarg;
                    break;
                case 'S':
                    printRagelActionCodeHandlers(c,"S");
                    ragel_access = optarg;
                    break;

                case 'u':
                    printRagelActionCodeHandlers(c,"u");
                    read_ragel_rules( optarg );
                    break;

                case 'i':
                    printRagelActionCodeHandlers(c,"u");
                    inlineRagelActionsCode++;
                    break;
                case 'A':
                    printRagelActionCodeHandlers(c,"A");
                    if (strcasecmp("empty", optarg)==0)
                        add_ragel_actions_bodies = 1;
                    else if (strcasecmp("text", optarg)==0)
                        add_ragel_actions_bodies = 2;
                    /*
                    else if (strcasecmp("code", optarg)==0)
                        add_ragel_actions_bodies = 3;
                    */
                    else {
                        fprintf(stderr, "ERROR: unknown type '-A %s'\n", optarg);
                        goto err;
                    }
                    break;

                case 'p':
                    printRagelActionCodeHandlers(c,"p");
                    disable_ragel_prolog_epilog++;
                    break;
                case 'h':
                case 'H':
                case '?':
                    printRagelActionCodeHandlers(c,"H");
                    break;
                default:
                    printRagelActionCodeHandlers(c,"DEFAULT");
                    fprintf(stderr, "getopt returned character code 0x%x\n", c);
                    break;
            }
        }
    }

    SIGNAL(SIGTERM);
    SIGNAL(SIGINT);
    //SIGNAL(SIGQUIT);

    if (in_file_count == 0) {
        in_files[in_file_count] = abnf_mk_str("");  /* stdin */
        in_flags[in_file_count] = if_File;
        in_file_count++;
    }
    for (i=0; i < in_file_count; i++) {
        if (abnf_stop_flag) return 0;
        switch (in_flags[i]) {
            case if_File:
                /* stdin / file */
            try_file:
                if (!in_files[i].len || (strcmp(in_files[i].s, "-") == 0)) {
                    if (verbose) fprintf(stdout, "infile: stdin\n");
                    if (abnf_parse_abnf(stdin, &rules, in_files[i]) < 0) goto err_2;
                }
                else {
                    if (verbose) fprintf(stdout, "infile: %s\n", in_files[i].s);
                    in_stream = fopen(in_files[i].s, "r");  /* it's null terminated */
                    if (!in_stream) {
                        fprintf(stderr, "ERROR: %s (errno:%d)\n", strerror(errno), errno);
                        goto err_2;
                    }
                    if (abnf_parse_abnf(in_stream, &rules, in_files[i]) < 0) goto err_2;
                    fclose(in_stream);
                }
                break;
            case if_Internal:
                if (verbose) fprintf(stdout, "self: %s\n", in_files[i].s);
                if (strcasecmp("core", in_files[i].s) == 0) {  /* we can do it, it's null terminated */
                    pr = abnf_declare_core_rules(NULL);
                }
                else if (strcasecmp("abnf", in_files[i].s) == 0) {
                    pr = abnf_declare_abnf_rules(NULL);
                }
                else {
                    goto try_file;
                }
                append_rule(pr);
                break;
            default:
                ;
        }
    }
    if (abnf_stop_flag) return 0;

    if (out_file) {
        if (verbose) fprintf(stdout, "outfile: %s\n", out_file);
        out_stream = fopen(out_file, "w+");
    }
    else {
        if (verbose) fprintf(stdout, "outfile: stdout\n");
        out_stream = stdout;
    }

    if (abnf_check_rules(stderr, rules) != 0 && force_flag == 0) {
        return 3;
    }

    printRagelActionCodeHandlers(c,"MAIN 1");
    info.in_files = in_files;
    info.in_file_count = in_file_count;
    info.out_file = abnf_mk_str(out_file);
    switch (out_fmt) {
        case of_Default:
        case of_Ragel:
            if (verbose) fprintf(stdout, "outformat: ragel\n");
            abnf_resolve_rule_dependencies(stderr, &rules);
            if (template_file!=0)
               {
                printRagelActionCodeHandlers(c,"MAIN 2");
                abnf_scan_template_file( template_file, out_stream, rules, &info, add_ragel_actions_bodies, ragelActionsCode, inlineRagelActionsCode );
               }
            else
               {
                printRagelActionCodeHandlers(c,"MAIN 3");
                /*abnf_print_ragel_actions_code(out_stream, rules, &info, add_ragel_actions_bodies);*/
                abnf_print_ragel_rules(out_stream, rules, &info, add_ragel_actions_bodies, ragelActionsCode, inlineRagelActionsCode);
               }
            break;
        case of_Abnf:
            if (verbose) fprintf(stdout, "outformat: abnf\n");
            abnf_print_abnf_rules(out_stream, rules, &info);
            break;
        case of_Self:
            if (verbose) fprintf(stdout, "outformat: self\n");
            abnf_print_self_rules(out_stream, rules, &info);
            break;
        default:
            ;
    }
    abnf_destroy_rules(rules);
    if (out_file) {
        fclose(out_stream);
    }

//destroy:
    return 0;

err:
    abnf_destroy_rules(rules);
    fprintf(stderr, "Type '%s -h <command>' for help on a specific command.\n", basename(argv[0]));
    return 1;
err_2:
    abnf_destroy_rules(rules);
    return 2;
}
