/*!
\project fsmgen - ��������� �������� ������� ���������� FSM (Finite State Machine) ��� C � C++
�� ���������� ��������� � ��������� ��������, ��������� � ������� smxml ��� � ������� .dia.

    \incpath #(BOOST.include) #(MARTYUSR.include)
    \libpath #(BOOST.lib) #(MARTYUSR.lib)

    \configuration release unicode_release
        \libraries cli2
        \libpath
        \incpath
    
    \configuration debug unicode_debug
        \libraries cli2
        \libpath
        \incpath


\platform mingw win32
    \configuration release unicode_release
        \libraries cli2 cli3
        \libpath
        \incpath
    
    \configuration debug unicode_debug
        \libraries cli2
        \libpath
        \incpath
*/


#include <cli/cli2.h>

#include <iostream>
#include <fstream>

#include <cli/io/ioTypes.h> 
#include <cli/cli2.h> 


#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if defined(DIA_USE_OLD_SIXML)
    #include <sixml/sixmlx.h>
    #include <sixml/serializ.h>
#else
    #include <cli/xml/sixml/pugixml/serializer.h>
    #ifndef CLI_MISC_READUTILS_H
        #include <cli/misc/readutils.h>
    #endif
    
    #ifndef CLI_MISC_WRITEUTILS_H
        #include <cli/misc/writeutils.h>
    #endif
#endif


#include <dia/dia.h>
#include <fsm/fsmdef.h>
#include <marty/libapi.h>
#include <marty/filename.h>
#include <marty/filesys.h>
#include <marty/confUtils.h>



#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/predicate.hpp>
//#include <boost/regex.hpp>
#include <boost/algorithm/string/split.hpp>
//#include <boost/algorithm/string/trim.hpp>

#if defined(DIA_USE_OLD_SIXML)
    #include "../common/6mlerr.h"
#else
    #define CATCH_6ML_ERRORS(bFlagErr, strErr) \
    catch(...)                                 \
       {                                       \
        return false;                          \
       }
#endif

#include "../common/incSearch.h"
//-?> vcxfsmmain.cpp"x=-09q76Q - xpen kakaya-to
#include "../dia/diaConv.h"

#include "generator.h"
#include "util.h"


#if defined(DIA_USE_OLD_SIXML)
    #include <sixml/sixmlx.cxx>
#else
    #include <cli/xml/sixml/pugixml/pugixml.cpp>
#endif

using MARTY_LIBAPI_NS       tstring;
using MARTY_FILENAME_NS     changeExtention;
using MARTY_LIBAPI_NS       getModuleFileName;
using MARTY_FILESYSTEM_NS   getCurrentDirectory;

using MARTY_FILENAME_NS     appendPath;

using MARTY_FILESYSTEM_NS   getCurrentDirectory;
using MARTY_FILESYSTEM_NS   openFile;
using MARTY_FILESYSTEM_NS   closeFile;
//using MARTY_FILESYSTEM_NS   handle_t;
using MARTY_FILESYSTEM_NS   fileopenmode;

inline
bool createFileOverwrite(const MARTY_LIBAPI::tstring &filename, bool fOverwrite)
   {
    fileopenmode omode = fileopenmode (MARTY_FILESYSTEM_NS o_rdwr | MARTY_FILESYSTEM_NS o_creat);
    if (!fOverwrite)
       omode = fileopenmode (omode | MARTY_FILESYSTEM_NS o_excl);
    
    MARTY_FILESYSTEM_NS handle_t hFile = openFile(filename, omode);
    if (hFile == MARTY_FILESYSTEM_NS hInvalidHandle) return false;
    closeFile(hFile);
    return true;
   }

int parse_option(const char* s);
int read_config_file(const char* fname);
void print_help();

int generateFlags = 0;
std::string stackSize = "256";
std::string generateForLang;
std::string filePrefix;
std::vector<std::string> namespaces;
std::string namesStyle;
std::string saveIntermediateAutomataToFile;


CIncludeFinder<TCHAR> includeFinder;

//std::vector<MARTY_LIBAPI::tstring> forceIncludeFiles;

std::map<std::string, fsm::CStateMachineInfo> stateMachines;




int main(int argc, char* argv[])
   {
    // std::vector<CGuardConditionPair> cond;
    // parseGuardCondition("'0'-'9',',',TOKEN_TEST, TOKEN_START-TOKEN_END", cond);
    //  
    // std::vector<CGuardConditionPair>::const_iterator condIt = cond.begin();
    // for(; condIt!=cond.end(); ++condIt)
    //    {
    //     if (condIt->minVal.empty())
    //        {
    //         std::cout<<"Error: invalid range - min value not taken";
    //         continue;
    //        }
    //     if (condIt->maxVal.empty())
    //        {
    //         std::cout<<condIt->minVal<<", ";
    //        }
    //     else
    //        {
    //         std::cout<<condIt->minVal<<"-"<<condIt->maxVal<<", ";
    //        }
    //    }
    // return 0;

    #if !defined(DIA_USE_OLD_SIXML)
        cliInit();
    #endif

    MARTY_LIBAPI::tstring executableFileName;
    if (getModuleFileName(0, executableFileName))
       {
        std::cout<<"Error: system error - can't get executable file name.\nExiting.\n";
        return 0;
       }

    MARTY_LIBAPI::tstring confName = changeExtention( executableFileName, MARTY_LIBAPI::tstring(_T(".conf")));

    read_config_file(confName.c_str());

    includeFinder.addPath(getCurrentDirectory());

    for (int i=1; i<argc; i++)
        {
         int pr = 0;
         switch(*argv[i])
           {
            case '-':
            case '/':  
                       pr = parse_option(argv[i]);
                       break;
            case '@':  pr = read_config_file(argv[i]+1);
                       break;
            
            default:
                       {
                        int res = generateAutomata( includeFinder, stateMachines, generateFlags, generateForLang, namespaces, namesStyle, filePrefix, argv[i], saveIntermediateAutomataToFile, stackSize);
                        if (res) 
                           return res;
                        saveIntermediateAutomataToFile = filePrefix = generateForLang = std::string();
                        generateFlags = 0;
                        namespaces.erase(namespaces.begin(), namespaces.end());
                        stackSize = "256";
                       }
           };
         
         if (pr) 
            return pr;
        }

    return 0;
   }



//-----------------------------------------------------------------------------
int read_config_file(const char* fname) 
{
 std::ifstream cfg(fname);
 std::string cfg_line;
 std::getline(cfg,cfg_line);
 cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
 while(cfg && cfg_line.size())
   {
      int pr = 0;
      switch(cfg_line[0])
        {
         case '-':
         case '/':  pr = parse_option(cfg_line.c_str());
                    break;
        };
    if (pr) return pr;
    std::getline(cfg,cfg_line);
    cfg_line = ::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  
   }
 return 0;
}


int parse_option(const char* s)
{
 if (*s!='-' && *s!='/')
    {
     std::cout<<"Invalid command line option: '"<<s<<"'\n";
     return 3;
    }
 char key = *((++s)++);

 switch(key)
   {
    case 'G':
              {
               char genFlag = *s;
               ++s;
               switch(genFlag)
                  {
                   case 'a':
                            generateFlags |= FGF_GENERATE_ALL;
                            break;

                   case 's':
                            generateFlags |= FGF_SHORT_INT;
                            break;

                   case 'e':
                            generateFlags |= FGF_STATIC_CONST_AS_ENUM;
                            break;

                   case 'x':
                            generateFlags |= FGF_DONT_GENERATE_CODE;
                            break;

                   case 't':
                            generateFlags |= FGF_MAKE_CALL_STAT;
                            break;

                   case 'd':
                            if (*s!='-')
                               generateFlags |= FGF_GENERATE_AUTOMATA_CLASS_DEF;
                            break;

                   case 'i':
                            if (*s!='-')
                               generateFlags |= FGF_GENERATE_AUTOMATA_CLASS_IMPL;
                            break;
/*
                   case 'c':
                            if (*s!='-')
                               generateFlags |= FGF_GENERATE_CONTEXT_CLASSES_DEF;
                            break;

                   case 't':
                            if (*s!='-')
                               generateFlags |= FGF_GENERATE_AUTOMATA_CLASS_TPL;
                            break;
*/
                   case 'W':
                            if (*s!='-')
                               generateFlags |= FGF_USE_WCHAR;
                            break;

                   case 'T':
                            if (*s!='-')
                               generateFlags |= FGF_USE_TCHAR;
                            break;

                   case 'N':
                             {
                              //std::vector< MARTY_TCSTRING > nsList;
                              std::vector< std::string > nsList;
                              std::string str(s);
                              ::boost::algorithm::split(nsList, str, fsm::util::CIsExactChar<','>(), boost::algorithm::token_compress_on);
                              std::copy(nsList.begin(), nsList.end(), std::back_inserter(namespaces) );
                             }
                             break;

                   case 'S':
                             saveIntermediateAutomataToFile = s;
                             break;

                   case 'C':
                            if (*s!='-')
                               generateFlags |= FGF_USE_LOCKING;
                             break;

                   case 'L':

                             switch(*s)
                                {
                                 case '-':  
                                         generateFlags &= ~(FGF_USE_LOGGING|FGF_USE_GUARD_LOGGING);
                                         break;
                                 case '1':  
                                         generateFlags |= FGF_USE_LOGGING;
                                         break;
                                 case '2':  
                                         generateFlags |= FGF_USE_LOGGING|FGF_USE_GUARD_LOGGING;
                                         break;

                                 case '3':  
                                 case '+':  
                                         generateFlags |= FGF_USE_LOGGING|FGF_USE_GUARD_LOGGING|FGF_LOG_ORG_STATE_NAMES;
                                         break;
                                 // case '-':  
                                 //         break;
                                 default:            
                                         std::cout<<"Invalid command line option: '-GL"<<s<<"'\n";
                                }
                             break;

                   case 'l':

                             switch(*s)
                                {
                                 case 'm':  
                                         generateFlags |= FGF_LOG_TRANSITION_SUMMARY_MULTILINE;
                                         break;
                                 // case '-':  
                                 //         break;
                                 default:            
                                         std::cout<<"Invalid command line option: '-Gl"<<s<<"'\n";
                                }
                             break;

                   case 'M':

                             switch(*s)
                                {
                                 case 'o':  
                                         generateFlags |= FGF_LOG_ORG_STATE_NAMES;
                                         break;
                                 // case '-':  
                                 //         break;
                                 default:            
                                         std::cout<<"Invalid command line option: '-GM"<<s<<"'\n";
                                }
                             break;

                   case 'D':
                            if (*s!='-')
                               generateFlags |= FGF_INADMISSIBLE_EVENTS_IGNORED;
                             break;

                   case 'I':
                            if (*s!='-')
                               generateFlags |= FGF_INLINE_METHODS;
                             break;

                   case 'R':
                            if (*s!='-')
                               generateFlags |= FGF_NO_CUSTOM_RESET;
                             break;

                   case 'V':
                            if (*s!='-')
                               generateFlags |= FGF_TRANSITION_COVERAGE;
                             break;

                   default:
                            {
                             std::cout<<"Invalid generator (-GX) option: '-G"<<genFlag<<s<<"'\n";
                             return 3;
                            }
                  };
              }
              break;
/*
    case 'O':
              {
               char genOpt = *s;
               ++s;
               switch(genOpt)
                  {
                   case 'n':
                             {
                              //std::vector< MARTY_TCSTRING > nsList;
                              std::vector< std::string > nsList;
                              std::string str(s);
                              ::boost::algorithm::split(nsList, str, fsm::util::CIsExactChar<','>(), boost::algorithm::token_compress_on);
                              std::copy(nsList.begin(), nsList.end(), std::back_inserter(namespaces) );
                             }
                             break;
                   case 's':
                             saveIntermediateAutomataToFile = s;
                             break;
                  };
              }
              break;
*/              

    case 'L':
              generateForLang = s;
              break;

    case 'S':
              {
               char genFlag = *s;
               ++s;
               switch(genFlag)
                  {
                   case 'F':
                            generateFlags |= FGF_FORCE_ADD_STACK;
                            break;
                   case 'O':
                            generateFlags |= FGF_STACK_NO_OVERFLOW_CALLS;
                            break;
                   case 'C':
                            generateFlags |= FGF_STACK_FORCE_PLAIN_C;
                            break;
                   case 'S':
                            stackSize = s;
                            if (stackSize.empty())
                               {
                                std::cout<<"Invalid stack size (-SSsize option)\n";
                               }
                            //generateFlags |= FGF_STACK_NO_OVERFLOW_CALLS;
                            break;
                   default:
                            {
                             std::cout<<"Invalid stack (-S) option: '-S"<<genFlag<<s<<"'\n";
                             return 3;
                            }
                  };
              }
              break;

    case 'f':
              filePrefix = s;
              break;

    case 'n':
              namesStyle = s;
              break;          

    case 'I':
              includeFinder.addPathList(s);
              break;

    case 'i':              
              if (*s!=0)
                  {
                   MARTY_LIBAPI::tstring lookupForFile = s;
                   if (!fsm::loadFsm(includeFinder, stateMachines, lookupForFile, false))
                      {
                       return 5;
                      }
                  }
              break;              

    case 'd':              
              if (*s!=0)
                  {
                   MARTY_LIBAPI::tstring lookupForFile = s;
                   if (!fsm::loadFsm(includeFinder, stateMachines, lookupForFile, true))
                      {
                       return 5;
                      }
                  }
              break;              

    case 'a': generateFlags |= FGF_ADD_FILENAME_AUTOMATA_SUFFIX;
              break;


    case 'w':
              {
               ::std::string exeFilename;
               getModuleFileName(0, exeFilename);
               std::cout<<"fsmgen location: "<<exeFilename<<"\n";
               return 1;
              }

    case '?': 
    case 'h': 
              print_help();
              return 2;              

    default:  
              std::cout<<"Invalid command line option: '-"<<s<<"'\n";
              print_help();
              return 3;
   };
 return 0;
}

//-----------------------------------------------------------------------------
void print_help()
{
 std::cout<<"Finite State Machine code generator\n";
 std::cout<<"Generate state machine code from .smxml definition (or from .dia definition)\n";
 std::cout<<"Usage: fsmgen [-option [-option]] automata1 [-option [-option]] automata2 ...\n";
 std::cout<<"Options:\n";
 std::cout<<"  -Ipathlist  - semicolon separated include path list.\n";
 std::cout<<"  -ifile      - load state machine definition file from .smxml.\n";
 std::cout<<"  -dfile      - load state machine definition file from .dia.\n";
 std::cout<<"  -Llang      - generate code for language 'lang'\n";
 std::cout<<"  -fprefix    - set prefix for generated file names\n";
 std::cout<<"  -a          - add '_Automata' suffix for filenames (for compatibility with older versions)\n";
// std::cout<<"  -OX         - options\n";
 std::cout<<"  -GX+        - generator options, X can be one of:\n";
 std::cout<<"                a          - generate all source\n";
 std::cout<<"                d+|-       - generate automata class definition\n";
 std::cout<<"                i+|-       - generate automata implementation (for event handlers)\n";
 std::cout<<"                t          - print calling/inlining summary information (prints inlined and called automatas hierarchy)\n";
 std::cout<<"                x          - don't generate any code, exiting after basic checks,\n";
 std::cout<<"                             saving expanded automata definition (if -GSfile option taken),\n";
 std::cout<<"                             and after calling statistics printed (if -Gt option taken)\n";
// std::cout<<"                c+|-       - generate context classes definition\n";
// std::cout<<"                t+|-       - generate automata implementation template (for other methods)\n";
 std::cout<<"                s          - assume that target int is short\n";
 std::cout<<"                e          - generate static const members as enum\n";
 std::cout<<"                T          - for character literals use _T() macro\n";
 std::cout<<"                W          - for character literals use L prefix (treated by compiler as wide char prefix)\n";
 std::cout<<"                C          - generate code for lock/unlock automata object on events entry/exit\n";
 std::cout<<"                LX         - generate code for logging automata events, X is one of: \n";
 std::cout<<"                             -  - logging is off\n";
 std::cout<<"                             1  - generate code without guard variables logging\n";
 std::cout<<"                             2  - generate code with guard variables logging\n";
 std::cout<<"                             3  - generate code with guard variables logging\n";
 std::cout<<"                                  and original state names in form - machine:state\n";
 std::cout<<"                             +  - same as 2\n";
 std::cout<<"                             Note: for events with non-Pod selectors/guards must be defined serialization function\n";
 std::cout<<"                                   void fsmObjSerialize( std::ostream &os, const GUARDOBJ &o);\n";
 std::cout<<"                lX         - logging options, X is one of:\n";
 std::cout<<"                             m  - make multiline transition summary information message\n";
 std::cout<<"                D          - generate code to ignore undefined events.\n";
 std::cout<<"                             Otherwise they are turn automata into special error state '__int_stateInadmissibleEnd__'\n";
 std::cout<<"                I          - generate inline code.\n";
 std::cout<<"                R          - disable generation of customReset method.\n";
 std::cout<<"                V          - generate code for check transitions coverage\n";
 std::cout<<"                             (C++ only, inadmissible events not checked).\n";
 std::cout<<"                Nns1,ns2,... - use namespaces, in C++ view as ::ns1::ns2::AutomataClass etc\n";
 std::cout<<"                Sfile.smxml  - save expanded automata definition (with subautomatas etc) into file.smxml\n";
 std::cout<<"                MX           - automatic comment options, , X can be one of:\n";
 std::cout<<"                             o  - use in comments original state names in form - machine:state\n";
 std::cout<<"                                  using -GL3 or -GL+ takes the same behavior\n";

 std::cout<<"  -SX         - automata state stack generation options, X can be one of:\n";
 std::cout<<"                F          - force add stack vars and methods\n";
 std::cout<<"                O          - don't generate and use stack overflow/underflow events\n";
 std::cout<<"                C          - for C++ use plain C state stack model\n";
 std::cout<<"                Ssize      - set stack size (for plain C)\n";

 std::cout<<"  -w          - prints path/name, where is fsmgen located, and exit.\n";
}

