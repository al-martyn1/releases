#ifndef FSMGEN_UTIL_H
#define FSMGEN_UTIL_H

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/split.hpp>


namespace fsm
{
namespace util
{

template<char C>
struct CIsExactChar
{
    bool operator()(char c) const
       { return c==C; }
};

template <typename TC>
bool isUpper(const TC ch)
   {
    if (ch>=(TC)'A' && ch<=(TC)'Z') return true;
    return false;
   }

template <typename TC>
bool isLower(const TC ch)
   {
    if (ch>=(TC)'a' && ch<=(TC)'z') return true;
    return false;
   }

template <typename TC>
bool isDigit(const TC ch)
   {
    if (ch>=(TC)'0' && ch<=(TC)'9') return true;
    return false;
   }

template <typename TC>
bool isUnderscore(const TC ch)
   {
    if (ch==(TC)'_') return true;
    return false;
   }

template <typename IterT, typename PredT>
bool hasA(IterT b, IterT e, const PredT &pred)
   {
    return std::find_if(b, e, pred)!=e;
   }

template <typename IterT>
bool hasUpper(IterT b, IterT e)
   {
    return hasA(b, e, isUpper<typename IterT::value_type>);
   }

template <typename IterT>
bool hasUnderscore(IterT b, IterT e)
   {
    return hasA(b, e, CIsExactChar<'_'>() /* isUnderscore */ );
   }

struct CToCMacroTransformator
{
    char operator()(char ch)
        { 
         //if (ch>='0' && ch<='9') return ch;
         if (isDigit(ch)) return ch;

         //if (ch>='A' && ch<='Z') return ch;
         if (isUpper(ch)) return ch;
         
         //if (ch>='a' && ch<='z') return (ch - 'a') + 'A';
         if (isLower(ch)) return (ch - 'a') + 'A';

         return '_';
        }
};

template <typename Ch>
std::basic_string<Ch> alignLeft(const std::basic_string<Ch> &str, typename std::basic_string<Ch>::size_type s, typename Ch spaceChar )
   {
    std::basic_string<Ch> res = str;
    if (res.size()>=s) return res;
    return res + std::basic_string<Ch>(s-res.size(), spaceChar);
   }

inline
std::string codeIndent(const std::string &code, int indent)
   {
    std::vector< std::string > lines;
    ::boost::algorithm::split(lines, code, fsm::util::CIsExactChar<'\n'>(), boost::algorithm::token_compress_off);

    std::string res, indStr(std::string::size_type(indent), ' ');
    std::vector< std::string >::const_iterator it = lines.begin();
    for(; it!=lines.end(); ++it)
       {
        if (!res.empty())
           res.append(1, '\n');
        if (!it->empty())
           res.append(indStr);
        res.append(*it);
       }
    return res;
   }


}; // namespace util
}; // namespace fsm


#endif /* FSMGEN_UTIL_H */

