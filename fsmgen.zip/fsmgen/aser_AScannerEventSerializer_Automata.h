#ifndef ASER_ASCANNEREVENTSERIALIZER_AUTOMATA_H
#define ASER_ASCANNEREVENTSERIALIZER_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */
/* Visit www.purefractalsolutions.com for more details */
#include "../scanner/lextypes.h"
#include "../scanner/scanner.h"





namespace codegen {

class CScannerEventSerializator {

public:     static const int     ST_eND       = 0x80000001; //!< AScannerEventSerializer:END
public:     static const int     ST_waitGt    = 0x00000002; //!< AScannerEventSerializer:WAIT_GT
public:     static const int     ST_waitLt    = 0x00000003; //!< AScannerEventSerializer:WAIT_LT
public:     static const int     ST_waitLtgt  = 0x00000004; //!< AScannerEventSerializer:WAIT_LTGT
public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__


    public:     std::string          buf         ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state


    public:     
        int
        putEvent
                ( const CScannerEvent &evt         
                )
           {
            /* guard variable - evt.token */
            switch(this->curState)
               {
                case ST_waitGt:    /* AScannerEventSerializer:WAIT_GT */
                        if (evt.token==LT_GREATER || evt.token==LT_SHIFT_RIGHT) /* Guard: [LT_GREATER,LT_SHIFT_RIGHT] */
                           {
                               /* State WAIT_GT - exit_action empty */
                               /* Transition from WAIT_GT to WAIT_GT actions */
                               { appendBuf(" "); appendBuf(evt.text); }
                               /* State WAIT_GT - entry_action empty */
                            this->curState = ST_waitGt;
                           }
                        else
                           {
                               /* State WAIT_GT - exit_action empty */
                               /* Transition from WAIT_GT to WAIT_LTGT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_LTGT - entry_action empty */
                            this->curState = ST_waitLtgt;
                           }
                     break;
                case ST_waitLt:    /* AScannerEventSerializer:WAIT_LT */
                        if (evt.token==LT_LESS || evt.token==LT_SHIFT_LEFT) /* Guard: [LT_LESS,LT_SHIFT_LEFT] */
                           {
                               /* State WAIT_LT - exit_action empty */
                               /* Transition from WAIT_LT to WAIT_LT actions */
                               { appendBuf(" "); appendBuf(evt.text); }
                               /* State WAIT_LT - entry_action empty */
                            this->curState = ST_waitLt;
                           }
                        else
                           {
                               /* State WAIT_LT - exit_action empty */
                               /* Transition from WAIT_LT to WAIT_LTGT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_LTGT - entry_action empty */
                            this->curState = ST_waitLtgt;
                           }
                     break;
                case ST_waitLtgt:    /* AScannerEventSerializer:WAIT_LTGT */
                        if (evt.token==LT_LESS || evt.token==LT_SHIFT_LEFT) /* Guard: [LT_LESS,LT_SHIFT_LEFT] */
                           {
                               /* State WAIT_LTGT - exit_action empty */
                               /* Transition from WAIT_LTGT to WAIT_LT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_LT - entry_action empty */
                            this->curState = ST_waitLt;
                           }
                        else if (evt.token==LT_GREATER || evt.token==LT_SHIFT_RIGHT) /* Guard: [LT_GREATER,LT_SHIFT_RIGHT] */
                           {
                               /* State WAIT_LTGT - exit_action empty */
                               /* Transition from WAIT_LTGT to WAIT_GT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_GT - entry_action empty */
                            this->curState = ST_waitGt;
                           }
                        else
                           {
                               /* State WAIT_LTGT - exit_action empty */
                               /* Transition from WAIT_LTGT to WAIT_LTGT actions */
                               { appendBuf(evt.text); }
                               /* State WAIT_LTGT - entry_action empty */
                            this->curState = ST_waitLtgt;
                           }
                     break;
               };
            return this->curState;
           }

    public:     
        int
        eod
           ( 
           )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_waitGt:    /* AScannerEventSerializer:WAIT_GT */
                           {
                               /* State WAIT_GT - exit_action empty */
                               /* Transition from WAIT_GT to END actions */
                               /* End state END - entry_action empty */
                            this->curState = ST_eND;
                           }
                     break;
                case ST_waitLt:    /* AScannerEventSerializer:WAIT_LT */
                           {
                               /* State WAIT_LT - exit_action empty */
                               /* Transition from WAIT_LT to END actions */
                               /* End state END - entry_action empty */
                            this->curState = ST_eND;
                           }
                     break;
                case ST_waitLtgt:    /* AScannerEventSerializer:WAIT_LTGT */
                           {
                               /* State WAIT_LTGT - exit_action empty */
                               /* Transition from WAIT_LTGT to END actions */
                               /* End state END - entry_action empty */
                            this->curState = ST_eND;
                           }
                     break;
               };
            return this->curState;
           }

    private:    
        void
        appendBuf
                 ( const std::string &str         
                 )
           {
            buf.append(str);
           }

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->customResetAutomata(  );
            this->curState = ST_waitLtgt;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return 0;
           }


};


}; // namespace codegen {

#endif /* ASER_ASCANNEREVENTSERIALIZER_AUTOMATA_H */
