#ifndef FSMGEN_GENERATOR_H
#define FSMGEN_GENERATOR_H


#define FGF_GENERATE_AUTOMATA_CLASS_DEF       0x00000001
#define FGF_GENERATE_AUTOMATA_CLASS_IMPL      0x00000002
#define FGF_GENERATE_CONTEXT_CLASSES_DEF      0x00000004
#define FGF_GENERATE_AUTOMATA_CLASS_TPL       0x00000008

#define FGF_GENERATE_ALL                      0x0000000F

#define FGF_USE_TCHAR                         0x00000100
#define FGF_USE_WCHAR                         0x00000200

#define FGF_USE_LOGGING                       0x00000400
#define FGF_USE_LOCKING                       0x00000800

#define FGF_INADMISSIBLE_EVENTS_IGNORED       0x00001000

#define FGF_INLINE_METHODS                    0x00002000
#define FGF_NO_CUSTOM_RESET                   0x00004000

#define FGF_TRANSITION_COVERAGE               0x00008000

#define FGF_USE_GUARD_LOGGING                 0x00010000

#define FGF_FORCE_ADD_STACK                   0x00020000
#define FGF_STACK_FORCE_PLAIN_C               0x00040000
#define FGF_STACK_NO_OVERFLOW_CALLS           0x00080000

#define FGF_MAKE_CALL_STAT                    0x00100000
#define FGF_DONT_GENERATE_CODE                0x00200000
#define FGF_LOG_ORG_STATE_NAMES               0x00400000

#define FGF_LOG_TRANSITION_SUMMARY_MULTILINE  0x00800000

#define FGF_SHORT_INT                         0x01000000
#define FGF_STATIC_CONST_AS_ENUM              0x02000000
#define FGF_ADD_FILENAME_AUTOMATA_SUFFIX      0x04000000

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
    #include <sstream>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#include <fsm/fsmdef.h>

#include "../common/incSearch.h"

#include "langGen.h"


//-----------------------------------------------------------------------------
//template <typename TC>
struct CGuardConditionPair
{
    std::string   minVal;
    std::string   maxVal;

    std::string makeCondition(const std::string &varName, bool useTdef, bool useL) const
       {
        std::string nV = minVal, xV = maxVal;
        if (nV.empty()) nV = xV;
        if (nV.empty()) return std::string(); // error        

        if (nV[0]=='(')
           return nV;

        if (nV[0]=='\'')
           {
            if (useTdef)
               nV = std::string("_T(") + nV + std::string(")");
            else if (useL)
               nV = std::string("L") + nV;
           }

        if (!xV.empty() && xV[0]=='\'')
           {
            if (useTdef)
               xV = std::string("_T(") + xV + std::string(")");
            else if (useL)
               xV = std::string("L") + xV;
           }

        if (xV.empty()) return varName + std::string("==") + nV;
        return varName + std::string(">=") + nV + std::string(" && ") + varName + std::string("<=") + xV;
       }
};

//-----------------------------------------------------------------------------
inline
std::string makeCondition(const std::vector<CGuardConditionPair> &cond, const std::string &varName, bool useTdef, bool useL)
   {
    std::string res;
    std::vector<CGuardConditionPair>::const_iterator it = cond.begin();
    for(; it!=cond.end(); ++it)
       {
        std::string tmp = it->makeCondition(varName, useTdef, useL);
        if (tmp.empty()) return tmp;
        if (!res.empty()) 
           {
            if (!tmp.empty() && (tmp[0]=='(' || tmp[0]=='|'))
               {
                res = std::string("(") + res + std::string(")");
                if (tmp[0]=='|')
                   res.append("|");
                else
                   res.append(" && ");
               }
            else
               res.append(" || ");
           }
        res.append(tmp);
       }
    return res;
   }

//-----------------------------------------------------------------------------
inline
std::string generateMemberAccess(fsm::ISourceGenerator *pGen, const std::string &stateVarName, const std::string &pthisStr)
    {
     std::stringstream ss;
     pGen->generateMemberAccess(ss, stateVarName, pthisStr);
     return ss.str();
    }

//-----------------------------------------------------------------------------
inline
std::string correctActionCode( fsm::ISourceGenerator *pGen
                             , const std::string &actionCode
                             , const marty::uml::CClassInfo &curClass
                             , const std::vector<marty::uml::CClassInfo> &allClasses
                             , const std::vector<std::string> &namespaces
                             , const std::vector<std::string> &defines
                             )
   {
    /*
    std::string res;
    int callRes = 0;
    if (!actionCode.empty() && actionCode[actionCode.size()-1]!=';') 
        callRes = pGen->convertCode(actionCode + std::string(1, ';'), curClass, allClasses, namespaces, defines, res);
    else
        callRes = pGen->convertCode(actionCode, curClass, allClasses, namespaces, defines, res);

    if (callRes) res = actionCode; // convert error, return org code string

    return res;
    */
    if (!actionCode.empty() && actionCode[actionCode.size()-1]!=';') 
        return actionCode + std::string(1, ';');
    else
        return actionCode;
   }

//-----------------------------------------------------------------------------
std::string generateLogEventCall( fsm::ISourceGenerator *pGen
                                , const fsm::CStateMachineInfo &stateMachine
                                , int genFlags
                                , const std::string &automataClassName
                                , const std::vector<std::string> &namespaces
                                , const std::map< std::string, fsm::CConstantName > &stateNames
                                , const fsm::CTransitionInfo &transition
                                , const std::string &codeStr
                                , const std::string &msgStr
                                );

//-----------------------------------------------------------------------------
int parseGuardCondition(const std::string &str, std::vector<CGuardConditionPair> &cond);


int generateAssignNextState( std::ostream &os
                           , const fsm::CStateMachineInfo &stateMachine
                           , fsm::ISourceGenerator *pGen
                           , int genFlags
                           , const marty::uml::CClassInfo &automataClass
                           , const std::vector<std::string> &namespaces
                           , const std::map< std::string, fsm::CConstantName > &stateNames
                           , const fsm::CTransitionInfo &transition
                           , const std::string &stateVar
                           , const std::string &eventHandlerName
                           , const std::vector<std::string> &eventHandlerArgList
                           , const std::string &indent
                           );


int generateExecActions( std::ostream &os
                       , const fsm::CStateMachineInfo &stateMachine
                       , fsm::ISourceGenerator *pGen
                       , const marty::uml::CClassInfo &automataClass
                       , const std::vector<std::string> &namespaces
                       , const std::map< std::string, fsm::CConstantName > &stateNames
                       , const std::vector<std::string> &defines
                       , int genFlags
                       , const fsm::CTransitionInfo &transition
                       , const std::string &eventHandlerName
                       , const std::vector<std::string> &eventHandlerArgList
                       , const std::string &indent
                       );

int generateStateCode( std::ostream &os
                     , const fsm::CStateMachineInfo &stateMachine
                     , fsm::ISourceGenerator *pGen
                     , int genFlags
                     , const marty::uml::CClassInfo &automataClass
                     , const std::vector<std::string> &namespaces
                     , const std::map< std::string, fsm::CConstantName > &stateNames
                     , const std::vector<std::string> &defines
                     , const std::string &eventName
                     , const std::string &stateName
                     , const std::string &eventHandlerName
                     , const std::vector<std::string> &eventHandlerArgList
                     , const std::vector<fsm::transition_pos_type> &trPosList
                     , const std::string &guardVar
                     , const std::string &stateVar
                     , bool  isPodGuardArg
                     , const std::string &guardObject
                     , const std::string &indent
                     );

int generateAutomata( const CIncludeFinder<TCHAR> &includeFinder
                    , const std::map<std::string, fsm::CStateMachineInfo> &stateMachines
                    , int genFlags
                    , const std::string &generateForLang
                    , const std::vector<std::string> &namespaces
                    , const std::string &namesStyle
                    , const std::string &filePrefix
                    , const std::string &automataName
                    , const std::string &saveIntermediateAutomata
                    , const std::string &stackSizeStr
                    );

int substAutomataIncludes( const CIncludeFinder<TCHAR> &includeFinder
                         , std::map<std::string, fsm::CStateMachineInfo> &stateMachines
                         , fsm::CStateMachineInfo &stateMachine
                         , std::map<std::string, std::set<std::string> > &inlinedAutomatas
                         );


#endif /* FSMGEN_GENERATOR_H */

