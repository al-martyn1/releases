#ifndef FSMGEN_LANGGEN_H
#define FSMGEN_LANGGEN_H


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#include <marty/umlclass.h>

#include <fsm/fsmdef.h>



#include "namenot.h"

namespace fsm
{

struct CConstantName
{
    bool        bFinal;
    int         value;
    std::string attrName;
    std::string intName;
    std::string extName;

    CConstantName() : bFinal(false), value(0), attrName(), intName(), extName() {}
    CConstantName(bool bf) : bFinal(bf), value(0), attrName(), intName(), extName() {}
    CConstantName(bool bf, int v) : bFinal(bf), value(v), attrName(), intName(), extName() {}
};


using namespace marty::uml;

struct ISourceGenerator
{
    INameNotationMaker* nmaker;

    ISourceGenerator(const std::string &namesStyle)
       : nmaker(0)
       {
        nmaker = cretateNameNotationMaker(namesStyle);
       }

    virtual ~ISourceGenerator()
       {
        delete nmaker;
       }

    virtual int isAllowedCppTransitionCoverage( ) = 0;
    virtual int isAllowedCppInline( ) = 0;
    virtual int generateCppTransitionCoverage( std::ostream &os ) = 0;


    virtual int isPodType( const std::string &typeName ) = 0;

    virtual std::string getLangName() = 0;

    virtual int makeEmptyReturn( std::ostream &os
                               , const marty::uml::CClassMethodInfo &methodInfo
                                 ) = 0;

    virtual int generatePushStateCode( const CClassInfo &curClass
                                     , const std::vector<std::string> &namespaces
                                     , std::ostream &os
                                     , bool bPlain
                                     , bool bCallOverflows
                                     , bool bLangPlainC
                                     )       = 0;

    virtual int generateSpawnStateCode( const CClassInfo &curClass
                                     , const std::vector<std::string> &namespaces
                                     , std::ostream &os
                                     , bool bPlain
                                     , bool bCallOverflows
                                     , bool bLangPlainC
                                     )       = 0;

    virtual int generatePopStateCode( const CClassInfo &curClass
                                    , const std::vector<std::string> &namespaces
                                    , std::ostream &os
                                    , bool bPlain
                                    , bool bCallOverflows
                                    , bool bLangPlainC
                                    )        = 0;

    virtual int generateClearStateStackCode( const CClassInfo &curClass
                                           , const std::vector<std::string> &namespaces
                                           , std::ostream &os
                                           , bool bPlain
                                           , bool bCallOverflows) = 0;

    virtual int addStackIncludesDefines( const CClassInfo &curClass
                                       , const std::vector<std::string> &namespaces
                                       , std::vector<std::string> &includes
                                       , std::vector<std::string> &defines
                                       , bool bPlain
                                       )        = 0;

    virtual int addStackVars( CClassInfo &curClass
                            , const std::vector<std::string> &namespaces
                            , const std::string &stackSizeStr
                            , bool bPlainCodeStyle
                            , bool bCallOverflows
                            , bool bInline
                            , bool bLangPlainC
                            )                = 0;
    

    virtual int convertCode( const std::string &cppStyleCode
                           , const CClassInfo &curClass
                           , const std::vector<CClassInfo> &allClasses
                           , const std::vector<std::string> &namespaces
                           , const std::vector<std::string> &defines
                           , std::string &toStr
                           ) = 0;
                
    virtual int generateIncludes( std::ostream &os
                                , const std::vector<std::string> &includesList 
                                ) = 0;

    virtual int generateDefines( std::ostream &os
                                , const std::vector<std::string> &definesList 
                                ) = 0;

    virtual int generateFunctionCall( std::ostream &os
                                    , const std::vector<std::string> &namespaces
                                    , const std::string &className
                                    , const std::string &fnName
                                    , const std::string &pthisName
                                    , const std::vector<std::string> &args
                                    ) = 0;

    virtual int generateMemberAccess( std::ostream &os
                                    , const std::string &memberName
                                    , const std::string &pthisName
                                    ) = 0;

    virtual int generateConstantNames( std::map< std::string, CConstantName > &names, 
                                       const std::vector<std::string> &namespaces,
                                       const std::string &className,
                                       const std::string &prefix, 
                                       const std::string &postfix) = 0;
    
    virtual int generateHeaderProlog( std::ostream &os
                                       , const std::string &filename
                                       , const std::vector<std::string> &namespaces
                                       , const std::vector<std::string> &incFiles
                                       , const std::vector<std::string> &defines
                                       ) = 0;
    virtual int generateHeaderEpilog( std::ostream &os
                                       , const std::string &filename
                                       , const std::vector<std::string> &namespaces
                                       ) = 0;
    virtual int generateSourceProlog( std::ostream &os
                                       , const std::string &filename
                                       , const std::vector<std::string> &namespaces
                                       , const std::vector<std::string> &incFiles
                                       , const std::vector<std::string> &defines
                                       ) = 0;
    virtual int generateSourceEpilog( std::ostream &os
                                       , const std::string &filename
                                       , const std::vector<std::string> &namespaces
                                       ) = 0;

    virtual std::string getHeaderSuffix() = 0;

    virtual std::string getSourceSuffix() = 0;

    virtual int generateClassDefinition( std::ostream &os
                                       , const std::vector<std::string> &namespaces
                                       , const CClassInfo &clInfo
                                       , int genFlags
                                       ) = 0;
    virtual int generateClassImplemetation( std::ostream &os
                                       , const std::vector<std::string> &namespaces
                                       , const CClassInfo &clInfo
                                       , std::map<std::string, std::string> &methodsCode
                                       ) = 0;
    virtual int generateClassImplTemplate( std::ostream &os
                                       , const std::vector<std::string> &namespaces
                                       , const CClassInfo &clInfo
                                       , std::map<std::string, std::string> &methodsCode
                                       ) = 0;
    virtual int generateEventContextClassDefinition( std::ostream &os
                                       , const std::vector<std::string> &namespaces
                                       , const CClassInfo &clInfo
                                       ) = 0;

    virtual std::string makeMethodName( INameNotationMaker* nm
                              , const std::vector<std::string> &namespaces
                              , const std::string &className
                              , const std::string &methodName
                              , bool plainLang
                              ) = 0;

    std::string makeMethodName( const std::vector<std::string> &namespaces
                              , const std::string &className
                              , const std::string &methodName
                              , bool plainC
                              )
       {
        return makeMethodName( nmaker, namespaces, className, methodName, plainC);
       }

    virtual std::string modifyGuardVarName( const std::string &guardVarName )
       {
        return guardVarName;
       }

    virtual std::string generateGuardVarSerializeCode( const std::string &guardVarName, const std::string &serializeToVarName ) = 0;
    virtual std::string getSerializedVarValueCode( const std::string &serializeToVarName ) = 0;

    virtual void addLoggerIncludes( std::vector<std::string> & includeFiles) {}

    virtual
    std::string generateLogEventCall( fsm::ISourceGenerator *pGen
                                    , const fsm::CStateMachineInfo &stateMachine
                                    , int genFlags
                                    , const std::string &automataClassName
                                    , const std::string &logMethodName
                                    , const std::string &pthisStr
                                    , const std::vector<std::string> &namespaces
                                    , const std::map< std::string, fsm::CConstantName > &stateNames
                                    , const fsm::CTransitionInfo &transition
                                    , const std::string &codeStr
                                    , const std::string &msgStr
                                    ) = 0;

    



};

ISourceGenerator* createGenerator(const std::string &lang, const std::string &namesStyle);


}; // namespace fsm


#endif /* FSMGEN_LANGGEN_H */

