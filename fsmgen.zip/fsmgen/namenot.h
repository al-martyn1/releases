#ifndef FSMGEN_NAMENOT_H
#define FSMGEN_NAMENOT_H


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

namespace fsm
{

struct INameNotationMaker
{
    virtual std::string makeName(const std::vector<std::string> &v) = 0;
    virtual std::string makeName(const std::string &n);
    virtual void        splitName(const std::string &name, std::vector<std::string> &v);
};


INameNotationMaker* cretateNameNotationMaker(const std::string &style);


}; // namespace fsm


#endif /* FSMGEN_NAMENOT_H */

