/* Warning! Automaticaly generated file, do not edit */
/* Visit www.purefractalsolutions.com for more details */

#include "aser_AScannerEventSerializer_Automata.h"





namespace codegen {



}; // namespace codegen {

