#include "namenot.h"


#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/case_conv.hpp>
#include <boost/algorithm/string/split.hpp>

#include "util.h"

namespace fsm
{

using ::boost::algorithm::to_lower_copy;
using ::boost::algorithm::to_upper_copy;

std::string INameNotationMaker::makeName(const std::string &n)
   {
    std::vector<std::string> v;
    splitName(n, v);
    return makeName(v);
   }

void  INameNotationMaker::splitName(const std::string &name, std::vector<std::string> &v)
   {
    if (fsm::util::hasUnderscore(name.begin(), name.end()))
       { // std c
        ::boost::algorithm::split(v, name, fsm::util::CIsExactChar<'_'>(), boost::algorithm::token_compress_on);
       }
    else if (fsm::util::hasUpper(name.begin(), name.end()))
       { // camel
        std::string buf;
        for (std::string::const_iterator it = name.begin(); it!=name.end(); ++it)
            {
             if (fsm::util::isUpper(*it))
                {
                 if (!buf.empty()) v.push_back(buf);
                 buf = std::string(1, *it);
                }
             else 
                buf.append(1, *it);
            }
        if (!buf.empty()) v.push_back(buf);
       }
    else 
       {
        v.push_back(name);
       }
   }

struct CamelNameNotationMaker : public INameNotationMaker
{
/*
    std::string makeName(const std::string &n)
       { // TODO: split and merge name here 
        return n;
       }
*/
    std::string makeName(const std::vector<std::string> &v)
       {
        std::string res; 
        std::vector<std::string>::const_iterator it = v.begin();
        for(; it!=v.end(); ++it)
           {
            //if (res.empty())
            if (it->empty()) continue;
            if (res.empty())
               {
                res.append(to_lower_copy(*it)); // 
               }
            else
               {
                res.append(to_upper_copy(std::string(*it, 0, 1))); // 
                if (it->size()>1)
                   res.append(to_lower_copy(std::string(*it, 1, std::string::npos))); // 
               }
           }
        return res;
       }
};


struct MsNameNotationMaker : public INameNotationMaker
{
/*
    std::string makeName(const std::string &n)
       { // TODO: split and merge name here 
        return n;
       }
*/
    std::string makeName(const std::vector<std::string> &v)
       {
        std::string res; 
        std::vector<std::string>::const_iterator it = v.begin();
        for(; it!=v.end(); ++it)
           {
            //if (res.empty())
            if (it->empty()) continue;
            res.append(to_upper_copy(std::string(*it, 0, 1))); // 
            if (it->size()>1)
               res.append(to_lower_copy(std::string(*it, 1, std::string::npos))); // 
           }
        return res;
       }
};


struct StdCNameNotationMaker : public INameNotationMaker
{
/*
    std::string makeName(const std::string &n)
       { // TODO: split and merge name here 
        return n;
       }
*/
    std::string makeName(const std::vector<std::string> &v)
       {
        std::string res; 
        std::vector<std::string>::const_iterator it = v.begin();
        for(; it!=v.end(); ++it)
           {
            if (!res.empty()) 
               res.append(1, '_');
            res.append(to_lower_copy(*it));
           }
        return res;
       }
};

struct StdCDefineNameNotationMaker : public INameNotationMaker
{
/*
    std::string makeName(const std::string &n)
       { // TODO: split and merge name here 
        return n;
       }
*/
    std::string makeName(const std::vector<std::string> &v)
       {
        std::string res; 
        std::vector<std::string>::const_iterator it = v.begin();
        for(; it!=v.end(); ++it)
           {
            if (!res.empty()) 
               res.append(1, '_');
            res.append(to_upper_copy(*it));
           }
        return res;
       }
};


INameNotationMaker* cretateNameNotationMaker(const std::string &style)
   {
    if (style=="stdc") return new StdCNameNotationMaker();
    else if (style=="ms") return new MsNameNotationMaker();
    else if (style=="def") return new StdCDefineNameNotationMaker();
    //else if (style=="camel") return new CamelNameNotationMaker();
    return new CamelNameNotationMaker(); // 
   }


}; // namespace fsm


