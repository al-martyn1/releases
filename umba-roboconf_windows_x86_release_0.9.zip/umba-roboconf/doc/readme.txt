Robot Configuration Extraction Tool version 0.9
Windows/x86
Built with MSVC v19.16.27049 compiler
Built at Jun 28 2024 23:14:31
Built at Jun 28 2024 23:14:31

Usage: roboconf [OPTIONS] input_file [output_file]

Options:

-h
-?
--help
    Show this help.
