#ifndef FSM_FSMDEF_H
#define FSM_FSMDEF_H

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_INC_ERRNO) && !defined(_ERRNO_H_) && !defined(_ERRNO_H)
    #include <errno.h>
#endif

#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/predicate.hpp>


#if defined(DIA_USE_OLD_SIXML)
    #include <sixml/sixmlx.h>
    #include <sixml/serializ.h>
#else
    #include <cli/xml/sixml/pugixml/serializer.h>
    #ifndef CLI_MISC_READUTILS_H
        #include <cli/misc/readutils.h>
    #endif
    
    #ifndef CLI_MISC_WRITEUTILS_H
        #include <cli/misc/writeutils.h>
    #endif
#endif

#include <marty/umlclass.h>



namespace fsm
{

using namespace marty::uml;
//using ::boost::algorithm::trim_copy;
//using ::boost::algorithm::trim;

inline
void trim(std::string &str)
   {
    ::boost::algorithm::trim(str);
   }


struct CStateInfo
{
    std::string     name        ;
    std::string     orgName     ; // ��������������� ������ � �������� ��������� ����������� �� call �����������, 
                                ; // ������� �� �������� ��������� return;
    std::string     entryAction ;
    std::string     doAction    ;
    std::string     exitAction  ;
    std::string     complexRef; // reference to automata
                                // for compaund states this member defines name of used automata
    std::string     callRef;
    std::string     callAction;
    std::string     includeFile;

    bool            isFinal;
    bool            bReturn;
    bool            recurCall;
    bool            recurRet;
    bool            bSpawn;

    std::string     orgStateMachine;
    std::string     localName;       // name in original state machine
                                     // if orgName is set, orgName and localName are equal
                                     // localName is alwais set

    CStateInfo() 
       : name()
       , orgName()
       , entryAction()
       , doAction()
       , exitAction()
       , complexRef()
       , callRef()
       , callAction()
       , includeFile()
       , isFinal(false)
       , bReturn(false)
       , recurCall(false)
       , recurRet(false)
       , bSpawn(false)
       , orgStateMachine()
       , localName()
       {}


    void trim()
       {
        fsm::trim(name);
        fsm::trim(orgName);
        fsm::trim(entryAction);
        fsm::trim(doAction);
        fsm::trim(exitAction);
        fsm::trim(complexRef);
        fsm::trim(callRef);        
        fsm::trim(callAction);        
        fsm::trim(includeFile);
       }

    std::string getStateName(bool getOriginal) const
       {
        if (!getOriginal) return name;
        return orgStateMachine + std::string(":") + localName;
       }

    std::string getStateName(int getOriginal) const
       {
        return getStateName(getOriginal ? true : false);
       }

    STRUCT_LAYOUT_DEFAULT(CStateInfo)
            attribute(_T("name")            , &CStateInfo::name                    );
            attribute(_T("original-name")   , &CStateInfo::orgName      , tstring());
            simple(_T("entry-action")       , &CStateInfo::entryAction  , tstring());
            simple(_T("do-action")          , &CStateInfo::doAction     , tstring());
            simple(_T("exit-action")        , &CStateInfo::exitAction   , tstring());
            simple(_T("call-entry-action")  ,&CStateInfo::callAction , tstring());
            simple(_T("complex-ref")        , &CStateInfo::complexRef   , tstring());
            simple(_T("call-ref")           , &CStateInfo::callRef      , tstring());
            simple(_T("include-smxml")      , &CStateInfo::includeFile  , tstring());
            attribute(_T("is-final")        , &CStateInfo::isFinal   , false);
            attribute(_T("return")          , &CStateInfo::bReturn   , false);
            attribute(_T("recurse-on-call") , &CStateInfo::recurCall , false);
            attribute(_T("recurse-on-ret")  , &CStateInfo::recurRet  , false);
            attribute(_T("spawn")           , &CStateInfo::bSpawn    , false);
    END_STRUCT_LAYOUT()
};

struct CStateNameEqualTo
{
    std::string  equalToName;
    CStateNameEqualTo() : equalToName() {}
    CStateNameEqualTo(const CStateNameEqualTo &eq) : equalToName(eq.equalToName) {}
    CStateNameEqualTo(const std::string &n) : equalToName(n) {}

    bool operator()(const CStateInfo &st)
       {
        return st.name==equalToName;
       }
};


/*
struct CActionInfo
{
    std::string        action;
}
*/

struct CTransitionInfo
{
    std::string     startState;
    std::string     endState;
    std::string     trigger;
    std::string     guard;
    bool            inner;
    bool            ignoreAllActions;

    std::vector<std::string>  actions;

    CTransitionInfo() 
       : startState()
       , endState()
       , trigger()
       , guard()
       , inner(false)
       , ignoreAllActions(false)
       , actions()
       {}

    void trim()
       {
        fsm::trim(startState);
        fsm::trim(endState);
        fsm::trim(trigger);
        fsm::trim(guard);
        std::vector<std::string>::iterator it = actions.begin();
        for(; it!=actions.end(); ++it)
           {
            fsm::trim(*it);
           }
       }

    //::boost::algorithm::trim_copy(cfg_line); //trim(cfg_line);  

    STRUCT_LAYOUT_DEFAULT(CTransitionInfo)
            attribute(_T("start-state") , &CTransitionInfo::startState                   );
            attribute(_T("end-state")   , &CTransitionInfo::endState   , tstring( /* _T("") */ ) );
            attribute(_T("inner")       , &CTransitionInfo::inner      , false           );
            simple(_T("trigger")        , &CTransitionInfo::trigger    , tstring( /* _T("") */ ) );
            //simple(_T("action")         , &CTransitionInfo::action     , tstring( /* _T("") */ ));
            array(_T("actions")         , &CTransitionInfo::actions    , _T("action")            );
            simple(_T("guard")          , &CTransitionInfo::guard      , tstring( /* _T("") */ ) );
    END_STRUCT_LAYOUT()

};


// �������� �����, ���� ����� 
// 1) ��������� � �������� ���������,
// 2) �������� (�������) ��������
// 3) ��������� (guard conditions)
// ��� ���� �� �����, ����������� �� �������� �� ��������� ����������/�������
// ����� �� �����, ���������� �� �������� � ��� ����������� ��� ���

inline
bool isEqualTransitions(const CTransitionInfo &tr1, const CTransitionInfo &tr2)
   {
    return tr1.startState==tr2.startState && tr1.endState==tr2.endState && tr1.trigger==tr2.trigger && tr1.guard==tr2.guard;
   }

struct transitionsEqual
{
    bool operator()(const CTransitionInfo &tr1, const CTransitionInfo &tr2)
       {
        return tr1.startState==tr2.startState && tr1.endState==tr2.endState && tr1.trigger==tr2.trigger && tr1.guard==tr2.guard;
       }
};

struct transitionLess
{
    bool operator()(const CTransitionInfo &tr1, const CTransitionInfo &tr2) const
       {
        int cmpStart = tr1.startState.compare(tr2.startState);
        if (cmpStart<0) return true;
        else if (!cmpStart)
           {
            /* int cmpEnd = tr1.endState.compare(tr2.endState);
             * if (cmpEnd<0) return true;
             * else if (!cmpEnd)
             *    {
             */
                int cmpTrigger = tr1.trigger.compare(tr2.trigger);
                if (cmpTrigger<0) return true;
                else if (!cmpTrigger)
                   {
                    /* if (tr1.guard!=tr2.guard && tr2.guard.empty())
                     *    return true; // ������ - � ����� �����, tr1 - less
                     *  
                     * if (tr1.guard!=tr2.guard && tr2.guard==std::string("*"))
                     *    return true; // * - � ����� �����, tr1 - less
                     */

                    //if (tr1.trigger.size()>tr2.trigger.size())
                    //   return true; // ���� �� ������ ������, �� ���� � ������, �.�. ������

                    int cmpGuard = tr1.guard.compare(tr2.guard);
                    if (cmpGuard>0) return true;
                   }
               /* }
                */
           }
        return false;
       }
};


struct transitionLessStrict
{
    bool operator()(const CTransitionInfo &tr1, const CTransitionInfo &tr2) const
       {
        int cmpStart = tr1.startState.compare(tr2.startState);
        if (cmpStart<0) return true;
        else if (!cmpStart)
           {
            /* int cmpEnd = tr1.endState.compare(tr2.endState);
             * if (cmpEnd<0) return true;
             * else if (!cmpEnd)
             *    {
             */
                int cmpTrigger = tr1.trigger.compare(tr2.trigger);
                if (cmpTrigger<0) return true;
                else if (!cmpTrigger)
                   {
                    /* if (tr1.guard!=tr2.guard && tr2.guard.empty())
                     *    return true; // ������ - � ����� �����, tr1 - less
                     *  
                     * if (tr1.guard!=tr2.guard && tr2.guard==std::string("*"))
                     *    return true; // * - � ����� �����, tr1 - less
                     */

                    //if (tr1.trigger.size()>tr2.trigger.size())
                    //   return true; // ���� �� ������ ������, �� ���� � ������, �.�. ������

                    int cmpGuard = tr1.guard.compare(tr2.guard);
                    if (cmpGuard>0) return true;
                    else if (!cmpGuard)
                       {
                        int cmpEnd = tr1.endState.compare(tr2.endState);
                        if (cmpEnd<0) return true;
                       }
                   }
               /* }
                */
           }
        return false;
       }
};



typedef std::vector<CTransitionInfo>::size_type transition_pos_type;
typedef std::vector<CStateInfo>     ::size_type state_pos_type;


struct testStruct
{
   static const int STATE1 = 1;
   static const int STATE2 = 2;
};


struct CStateMachineInfo
{
    std::string                   loadedFromFile; // aux member, not serialized to XML
    std::string                   name;
    std::string                   startState;
    std::string                   automataClass;
    std::string                   callEntryAction;
    std::string                   inlineEntryAction;
    

    //std::vector<std::string>      endStates;

    std::vector<CClassInfo>            classes;
    std::vector<CStateInfo>            states;
    std::vector<CTransitionInfo>       transitions;
    std::map<std::string, std::string> callables; // callables[calledAutomataName] = call state

    mutable std::map<std::string, state_pos_type>   stateMap;


    std::string getStateName(const std::string &modifiedName, bool getOriginal) const
       {
        if (!getOriginal) return modifiedName;
        const CStateInfo* pState = getStateInfo(modifiedName);
        if (!pState)      return modifiedName;
        return pState->orgStateMachine + std::string(":") + pState->localName;
       }

    std::string getStateName(const std::string &modifiedName, int getOriginal) const
       {
        return getStateName(modifiedName, getOriginal ? true : false);
       }

    void updateStatesOrgStateMachine()
       {
        std::vector<CStateInfo>::iterator it = states.begin();
        for(; it!=states.end(); ++it)
           {
            it->orgStateMachine = name;
            it->localName       = it->name;
           }
       }

    void buildStateMap() const
       {
        stateMap.erase(stateMap.begin(), stateMap.end());

        state_pos_type pos = 0, size = states.size();
        for(; pos!=size; ++pos)
           stateMap[states[pos].name] = pos;
       }

    const CStateInfo* getStateInfo(const std::string &stateName) const
       {
        if (stateMap.size()!=states.size())
           buildStateMap();

        std::map<std::string, state_pos_type>::const_iterator it = stateMap.find(stateName);
        if (it==stateMap.end()) return 0;
        return &states[it->second];
       }

    void trim()
       {
        std::vector<CStateInfo>::iterator sit = states.begin();
        for(; sit!=states.end(); ++sit)
           sit->trim();

        std::vector<CTransitionInfo>::iterator tit = transitions.begin();
        for(; tit!=transitions.end(); ++tit)
           tit->trim();

        fsm::trim(callEntryAction  );
        fsm::trim(inlineEntryAction);
       }


    void addActionToTransitions(const std::vector<transition_pos_type> &trPosList, const std::string &action)
       {
        if (action.empty()) return;
        std::vector<transition_pos_type>::const_iterator it = trPosList.begin();
        for(; it!=trPosList.end(); ++it)
           {
            transitions[*it].actions.push_back(action);
           }
       }

    void setTransitionsStartState(const std::vector<transition_pos_type> &trPosList, const std::string &stateName)
       {
        if (stateName.empty()) return;
        std::vector<transition_pos_type>::const_iterator it = trPosList.begin();
        for(; it!=trPosList.end(); ++it)
           {
            transitions[*it].startState = stateName;
           }
       }

    void setTransitionsEndState(const std::vector<transition_pos_type> &trPosList, const std::string &stateName)
       {
        if (stateName.empty()) return;
        std::vector<transition_pos_type>::const_iterator it = trPosList.begin();
        for(; it!=trPosList.end(); ++it)
           {
            transitions[*it].endState = stateName;
           }
       }

    void modifyStateNames(const std::string &prefix, const std::string &postfix)
       {
        startState = prefix + startState + postfix;

        std::vector<CStateInfo>::iterator stIt = states.begin();
        for(; stIt!=states.end(); ++stIt)
           {
            stIt->name = prefix + stIt->name + postfix;
           }

        std::vector<CTransitionInfo>::iterator trIt = transitions.begin();
        for(; trIt!=transitions.end(); ++trIt)
           {
            trIt->startState = prefix + trIt->startState + postfix;
            trIt->endState   = prefix + trIt->endState + postfix;
           }
       }

    /*
    std::vector<CStateInfo>::const_iterator 
    findState(const std::string &stateName) const
       {
        std::vector<CStateInfo>::const_iterator it = states.begin();
        for(; it!=states.begin(); ++it)
           {
            if (it->name==stateName)
               return it;
           }
        states.end();
       }
    */

    state_pos_type findFinalStates(bool bIsFinal, std::vector<state_pos_type> &stPosList) const
       {
        std::vector<CStateInfo>::size_type pos = 0, size = states.size();
        for(; pos!=size; ++pos)
           {
            if (states[pos].isFinal==bIsFinal)
               stPosList.push_back(pos);
           }
        return (state_pos_type)stPosList.size();
       }
    
    transition_pos_type findTransitionsByEventFrom(const std::string &eventName, const std::string &stateName, std::vector<transition_pos_type> &trPosList) const
       {
        transition_pos_type pos = 0, size = transitions.size();
        for(; pos!=size; ++pos)
           {
            if (transitions[pos].trigger==eventName && transitions[pos].startState==stateName)
               trPosList.push_back(pos);
           }
        return (transition_pos_type)trPosList.size();
       }
    
    transition_pos_type findTransitionsFrom(const std::string &stateName, std::vector<transition_pos_type> &trPosList) const
       {
        transition_pos_type pos = 0, size = transitions.size();
        for(; pos!=size; ++pos)
           {
            if (transitions[pos].startState==stateName)
               trPosList.push_back(pos);
           }
        return (transition_pos_type)trPosList.size();
       }
    
    transition_pos_type findTransitionsTo(const std::string &stateName, std::vector<transition_pos_type> &trPosList) const
       {
        transition_pos_type pos = 0, size = transitions.size();
        for(; pos!=size; ++pos)
           {
            if (transitions[pos].endState==stateName)
               trPosList.push_back(pos);
           }
        return (transition_pos_type)trPosList.size();
       }
    

    STRUCT_LAYOUT_DEFAULT(CStateMachineInfo)
            attribute(_T("name")          , &CStateMachineInfo::name           );
            attribute(_T("start-state")   , &CStateMachineInfo::startState     );
            attribute(_T("automata-class"), &CStateMachineInfo::automataClass  );
            simple(_T("call-entry-action"), &CStateMachineInfo::callEntryAction, tstring());
            simple(_T("inline-entry-action"), &CStateMachineInfo::inlineEntryAction, tstring());
            //attribute(_T("end-state")     , &CTransitionInfo::endState   , tstring(_T("")) );
            array(_T("classes")           , &CStateMachineInfo::classes     , _T("class") );
            array(_T("states")            , &CStateMachineInfo::states      , _T("state") );
            array(_T("transitions")       , &CStateMachineInfo::transitions , _T("transition") );
    END_STRUCT_LAYOUT()
};

struct CFsmConfig
{
    std::vector<CStateMachineInfo>   fsmList;
    std::vector<CClassInfo>          classes;

    void trim()
       {
        std::vector<CStateMachineInfo>::iterator it = fsmList.begin();
        for(; it!=fsmList.end(); ++it)
           it->trim();
       }

    void updateStatesOrgStateMachine()
       {
        std::vector<CStateMachineInfo>::iterator it = fsmList.begin();
        for(; it!=fsmList.end(); ++it)
           {
            it->updateStatesOrgStateMachine();
           }
       }
    

    STRUCT_LAYOUT_DEFAULT(CFsmConfig)
            array(0           , &CFsmConfig::fsmList, _T("state-machine"));
            array(_T("classes") , &CFsmConfig::classes, _T("class") );
    END_STRUCT_LAYOUT()

    #if !defined(DIA_USE_OLD_SIXML)
    INLINE_SIXML_SIMPLE_SAVELOAD_METHODS( "fsm" )
    #endif

};


//-----------------------------------------------------------------------------
inline
void save_fsmdef(const std::string &filename, const CFsmConfig &fsm)
   {   
    #if defined(DIA_USE_OLD_SIXML)
    sixml::serializer::write_xml( filename.c_str(),  
                                  "fsm", 
                                  fsm, 
                                  sixml::serializer::write_attr::more_indent, // default_method, less_indent, more_indent
                                  true
                                );
    #else
    ::std::string fsmXml;
    fsm.save(fsmXml);
    ::cli::misc::utils::writeFile( filename, fsmXml );
    #endif

   }

//-----------------------------------------------------------------------------
inline
void load_fsmdef(const std::string &filename, CFsmConfig &fsm)
   {
    #if defined(DIA_USE_OLD_SIXML)
    sixml::serializer::load_xml<fsm::CFsmConfig>(filename.c_str(), fsm);
    #else
    ::std::string fsmXml;
    //RCODE res = 
    ::cli::misc::utils::readFile( filename, fsmXml );
    fsm.load(fsmXml);
    #endif

    fsm.trim();
    fsm.updateStatesOrgStateMachine();

   }



}; // namespace fsm

#endif /* FSM_FSMDEF_H */