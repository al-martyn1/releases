#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_VARIANT_H
#define CLI_VARIANT_H

/*
#ifndef CLI_VARIANT_H
    #include <cli/variant.h>
#endif
*/

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#define cliCreateVariant cliGetVariant

EXTERN_CLI
CLIAPIENTRY
INTERFACE_CLI_IVARIANT*
CLICALL
cliGetVariant( );



// }; // namespace cli

#endif // CLI_VARIANT_H

