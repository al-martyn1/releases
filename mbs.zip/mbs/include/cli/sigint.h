#include <cli/ponce.h>
#pragma once

#ifndef CLI_SIGINT_H
#define CLI_SIGINT_H

#include <signal.h>

#if defined(WIN32) || defined(_WIN32)

    #define CLI_DECLARE_SIGINT_HANDLER_EX(flagVar)                 \
                        volatile int flagVar = 0;                  \
                        void __cdecl cliStdSigintHandler(int);     \
                        void __cdecl cliStdSigintHandler(int)      \
                           {                                       \
                            flagVar = 1;                           \
                           }
    
    #define CLI_INIT_SIGINT()    signal(SIGINT, cliStdSigintHandler)

#else

    #define CLI_DECLARE_SIGINT_HANDLER_EX(flagVar)                 \
                        volatile int flagVar = 0;                  \
                        void cliStdSigintHandler(int);             \
                        void cliStdSigintHandler(int)              \
                           {                                       \
                            flagVar = 1;                           \
                           }
    
    #define CLI_INIT_SIGINT()    signal(SIGINT, cliStdSigintHandler)

#endif

#define CLI_DECLARE_SIGINT_HANDLER()    CLI_DECLARE_SIGINT_HANDLER_EX(ctrlCHandled)

#endif /* CLI_SIGINT_H */

