#ifndef CLI_IO_IOTYPES_H
#define CLI_IO_IOTYPES_H

/*
#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif
*/

#if defined(_WIN32) || defined(WIN32)
    #ifdef _MSC_VER
        #if defined(_WINSOCKAPI_) && !defined(_WINSOCK2API_)
            #error "Error: Win32 - <winsock2.h> must be included before <windows.h>. You need <cli/io/ioTypes.h> to be included before any other header, include CLI headers before all other."
        #endif
    #endif
    #ifndef INCL_WINSOCK_API_TYPEDEFS
        #define INCL_WINSOCK_API_TYPEDEFS 1
    #endif
    #include <winsock2.h>
    #include <windows.h>
    #include <Ws2tcpip.h>

    #ifdef _MSC_VER
        #pragma comment( lib, "ws2_32" )
    #endif


#else

    #ifndef _NETDB_H
        #include <netdb.h>
    #endif

    #if !defined(_NETINET_IN_H) && !defined(_NETINET_IN_H_)
        #include <netinet/in.h>
    #endif

#endif

// INVALID_HANDLE_VALUE


#if defined(_WIN32) || defined(WIN32)

    typedef HANDLE     SYS_GENERIC_IO_HANDLE;
    typedef HANDLE     SYS_PIPE_HANDLE;
    typedef HANDLE     SYS_FILE_HANDLE;
    typedef SOCKET     SYS_SOCKET_HANDLE;
    // next two types are equal
    typedef HANDLE     SYS_SERIAL_HANDLE;
    typedef HANDLE     SYS_COM_HANDLE;

    #define INVALID_SYS_GENERIC_IO_HANDLE       INVALID_HANDLE_VALUE
    #define INVALID_SYS_PIPE_HANDLE             INVALID_HANDLE_VALUE
    #define INVALID_SYS_FILE_HANDLE             INVALID_HANDLE_VALUE
    #define INVALID_SYS_SOCKET_HANDLE           INVALID_SOCKET
    #define INVALID_SYS_SERIAL_HANDLE           INVALID_HANDLE_VALUE
    #define INVALID_SYS_COM_HANDLE              INVALID_HANDLE_VALUE

#else

    typedef int        SYS_GENERIC_IO_HANDLE;
    typedef int        SYS_PIPE_HANDLE;
    typedef int        SYS_FILE_HANDLE;
    typedef int        SYS_SOCKET_HANDLE;
    // next two types are equal
    typedef int        SYS_SERIAL_HANDLE;
    typedef int        SYS_COM_HANDLE;

    #define INVALID_SYS_GENERIC_IO_HANDLE       -1
    #define INVALID_SYS_PIPE_HANDLE             -1
    #define INVALID_SYS_FILE_HANDLE             -1
    #define INVALID_SYS_SOCKET_HANDLE           -1
    #define INVALID_SYS_SERIAL_HANDLE           -1
    #define INVALID_SYS_COM_HANDLE              -1

#endif

#endif /* CLI_IO_IOTYPES_H */

