#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_SERIALHLP_H
#define CLI_IO_SERIALHLP_H

#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef CLI_IO_ISERIAL_H
    #include <cli/io/iserial.h>
#endif


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif


#if defined(WIN32) || defined(_WIN32)
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else
    #include <alloca.h>
    #ifndef _alloca
        #define _alloca  alloca
    #endif
#endif

#ifndef MARTY_ENV_H
    #include <marty/env.h>
#endif

#if defined(WIN32) || defined(_WIN32)

    #ifndef MARTY_WINAPI_H
        #include <marty/winapi.h>
    #endif

    #include <winnt.h>

#endif

#if defined(WIN32) || defined(_WIN32)
    #if !defined(_WINTERNL_)
        #ifndef _NTDEF_
        typedef LONG NTSTATUS, *PNTSTATUS;
        //typedef BYTE  BOOLEAN;
        #endif
    
        #include <cli/pshpack1.h>
        typedef struct _UNICODE_STRING {
            USHORT Length;
            USHORT MaximumLength;
            PWSTR  Buffer;
        } UNICODE_STRING, *PUNICODE_STRING;
        #include <cli/poppack.h>
    
        #include <cli/pshpack1.h>
        typedef struct _OBJECT_ATTRIBUTES {
            ULONG Length;
            HANDLE RootDirectory;
            PUNICODE_STRING ObjectName;
            ULONG Attributes;
            PVOID SecurityDescriptor;
            PVOID SecurityQualityOfService;
        } OBJECT_ATTRIBUTES, *POBJECT_ATTRIBUTES;
        #include <cli/poppack.h>
    #endif
#endif


namespace cli  {
namespace io   {


inline
::std::wstring getSerialDeviceNameOnly(const ::std::wstring &deviceName)
   {
    //::std::wstring &deviceName
    ::std::wstring::size_type pos = 0, lastPos = ::std::wstring::npos, size = deviceName.size();
    for(; pos!=size; ++pos)
       {
        if (deviceName[pos]==L'/' || deviceName[pos]==L'\\') lastPos = pos;
       }
    if (lastPos==::std::wstring::npos) return deviceName;
    return ::std::wstring( deviceName, lastPos+1, ::std::wstring::npos );
   }



#if defined(WIN32) || defined(_WIN32)

#ifndef IN
#define IN
#endif

#ifndef OUT
#define OUT
#endif

#ifndef OPTIONAL
#define OPTIONAL
#endif

#ifndef __in
#define __in
#endif

#ifndef __out
#define __out
#endif


typedef NTSTATUS (WINAPI *NtOpenSymbolicLinkObjectFnPtr)(
                  __out  PHANDLE LinkHandle,
                  __in   ACCESS_MASK DesiredAccess,
                  __in   POBJECT_ATTRIBUTES ObjectAttributes
                 );

typedef NTSTATUS (WINAPI *NtCloseFnPtr)(IN HANDLE Handle);

typedef NTSTATUS (WINAPI *NtQuerySymbolicLinkObjectFnPtr)( 
                 IN HANDLE SymbolicLinkHandle, 
                 OUT PUNICODE_STRING NameString, 
                 OUT PULONG ResultLength OPTIONAL 
                 ); 

typedef NTSTATUS (WINAPI *NtQuerySystemInformationFnPtr)(
                 IN DWORD                SystemInformationClass, // SYSTEM_INFORMATION_CLASS SystemInformationClass,
                 OUT PVOID               SystemInformation,
                 IN ULONG                SystemInformationLength,
                 OUT PULONG              ReturnLength OPTIONAL );


#ifndef OBJ_CASE_INSENSITIVE
    #define OBJ_CASE_INSENSITIVE  0x00000040
#endif

#ifndef NT_SUCCESS
    #define NT_SUCCESS(Status) ((LONG)(Status) >= 0) 
#endif

#ifdef NT_ERROR
    #define NT_ERROR(Status) ((ULONG)(Status) >> 30 == 3) 
#endif

#ifndef InitializeObjectAttributes
    #define InitializeObjectAttributes( p, n, a, r, s ) {                                            \
                                                         (p)->Length = sizeof( OBJECT_ATTRIBUTES ); \
                                                         (p)->RootDirectory = r;                    \
                                                         (p)->Attributes = a;                       \
                                                         (p)->ObjectName = n;                       \
                                                         (p)->SecurityDescriptor = s;               \
                                                         (p)->SecurityQualityOfService = NULL;      \
                                                        }
#endif // InitializeObjectAttributes

inline
::std::wstring getSymbolicLinkObjectName(const ::std::wstring &deviceName)
   {
    HMODULE hNtDll = ::GetModuleHandleW( L"Ntdll.dll" );
    if (!hNtDll) return ::std::wstring();

    NtOpenSymbolicLinkObjectFnPtr pNtOpenSymbolicLinkObject = (NtOpenSymbolicLinkObjectFnPtr)GetProcAddress( hNtDll, "NtOpenSymbolicLinkObject" );
    if (!pNtOpenSymbolicLinkObject) return ::std::wstring();

    NtCloseFnPtr pNtClose = (NtCloseFnPtr)GetProcAddress( hNtDll, "NtClose" );
    if (!pNtClose) return ::std::wstring();

    NtQuerySymbolicLinkObjectFnPtr pNtQuerySymbolicLinkObject = (NtQuerySymbolicLinkObjectFnPtr)GetProcAddress( hNtDll, "NtQuerySymbolicLinkObject" );
    if (!pNtQuerySymbolicLinkObject) return ::std::wstring();

    WCHAR *linkNameBuf = (WCHAR*)_alloca( (deviceName.size() + 1) * sizeof(WCHAR) );
    deviceName.copy( linkNameBuf, deviceName.size(), 0);
    linkNameBuf[deviceName.size()] = 0;
    USHORT dnSize = (USHORT)deviceName.size()*sizeof(WCHAR);

    UNICODE_STRING linkName = { dnSize, dnSize+sizeof(WCHAR), linkNameBuf };
    OBJECT_ATTRIBUTES ObjectAttributes;
    InitializeObjectAttributes( &ObjectAttributes, &linkName, OBJ_CASE_INSENSITIVE, 0, 0 );

    HANDLE hLinkHandle = INVALID_HANDLE_VALUE;
    NTSTATUS Status = pNtOpenSymbolicLinkObject( &hLinkHandle 
                                               , STANDARD_RIGHTS_REQUIRED | 0x1 // SYMBOLIC_LINK_ALL_ACCESS // | GENERIC_READ 
                                               , &ObjectAttributes
                                               );
    if (!NT_SUCCESS( Status ))
       return ::std::wstring();

    WCHAR linkNameTargetBuf[1024];
    UNICODE_STRING linkTarget = { 0, (USHORT)sizeof(linkNameTargetBuf), linkNameTargetBuf };
    Status = pNtQuerySymbolicLinkObject( hLinkHandle
                                       , &linkTarget
                                       , 0
                                       );
    pNtClose( hLinkHandle );
    if (!NT_SUCCESS( Status ))
       return ::std::wstring();

    return ::std::wstring( linkNameTargetBuf, linkTarget.Length/sizeof(WCHAR) );
   }


inline
::std::wstring getSerialDeviceName(const ::std::wstring &deviceName)
   { // \??\COMX
    return getSymbolicLinkObjectName( ::std::wstring(L"\\??\\") + getSerialDeviceNameOnly(deviceName) );
   }

#include <cli/pshpack1.h>
typedef struct _SYSTEM_HANDLE
{
    DWORD   ProcessID;
    //WORD    HandleType; // aka BYTE HandleType; BYTE flags;
    BYTE    HandleType; 
    BYTE    flags;
    WORD    HandleNumber;
    DWORD   KernelAddress;
    DWORD   GrantedAccess; //  Flags; // aka Granted access
} SYSTEM_HANDLE;
#include <cli/poppack.h>

#include <cli/pshpack1.h>
typedef struct _SYSTEM_HANDLE_INFORMATION
{
    DWORD           Count;
    SYSTEM_HANDLE   Handles[1];
} SYSTEM_HANDLE_INFORMATION;
#include <cli/poppack.h>


// hi.GetName( (HANDLE)h.HandleNumber, name, h.ProcessID );
void getSystemHandlesInformation( ::std::vector< SYSTEM_HANDLE > &handles /* , WORD filterType = 0xFFFF */ )
   {
    HMODULE hNtDll = ::GetModuleHandleW( L"Ntdll.dll" );
    if (!hNtDll) return ; // ::std::wstring();

    NtQuerySystemInformationFnPtr pNtQuerySystemInformation = (NtQuerySystemInformationFnPtr)GetProcAddress( hNtDll, "NtQuerySystemInformation" );
    if (!pNtQuerySystemInformation) return ; //

    DWORD sizeNeeded = 0;
    SYSTEM_HANDLE_INFORMATION* pHandlesInfo = (SYSTEM_HANDLE_INFORMATION*)_alloca( sizeof(SYSTEM_HANDLE_INFORMATION) );

    // 16 -  SystemHandleInformation,
    // see http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/System%20Information/SYSTEM_INFORMATION_CLASS.html
    if ( pNtQuerySystemInformation( 16, pHandlesInfo, sizeof(SYSTEM_HANDLE_INFORMATION), &sizeNeeded ) != 0 )
       {
        if ( sizeNeeded == 0 )
           return ; // error
        pHandlesInfo = (SYSTEM_HANDLE_INFORMATION*)_alloca( sizeNeeded + 256 );
       }

    
    if ( pNtQuerySystemInformation( 16, pHandlesInfo, sizeNeeded + 256, &sizeNeeded ) != 0 )
       return ; // error

    handles.reserve(pHandlesInfo->Count);
    for(DWORD i=0; i!=pHandlesInfo->Count; ++i)
       {
        //if (filterType==0xFFFF || filterType==pHandlesInfo->Handles[i].HandleType)
           handles.push_back(pHandlesInfo->Handles[i]);
       }

/*
typedef NTSTATUS (WINAPI *NtQuerySystemInformationFnPtr)(
                 IN DWORD                SystemInformationClass, // SYSTEM_INFORMATION_CLASS SystemInformationClass,
                 OUT PVOID               SystemInformation,
                 IN ULONG                SystemInformationLength,
                 OUT PULONG              ReturnLength OPTIONAL );
*/
   }


#endif // #if defined(WIN32) || defined(_WIN32)



inline
void getSerialDevicesInfo( ::std::wstring &deviceNameFmt
                         , ::std::wstring &deviceDisplayNameFmt
                         , int &deviceNoAdd
                         )
   {
    /* http://www.easysw.com/~mike/serial/serial.html
    Table 2 - Serial Port Device Files 
     System            Port 1        Port 2 
    IRIXR             /dev/ttyf1    /dev/ttyf2 
    HP-UX             /dev/tty1p0   /dev/tty2p0 
    SolarisR/SunOS(R) /dev/ttya     /dev/ttyb 
    LinuxR            /dev/ttyS0    /dev/ttyS1 
    Digital UNIXR     /dev/tty01    /dev/tty02 
    ---
    FreeBSD found in other docs 
                      /dev/ttyd0    /dev/ttyd1
    */

    #ifdef _WIN32
    const ::std::wstring defDeviceSystemNameFormat( MARTY_WINAPI_NS isWinNt() ? L"\\\\.\\COM%1" : L"COM%1" );
    const ::std::wstring defDeviceDisplayNameFormat( L"COM%1" );
    const int defSerialDeviceNoAddVal = 1;
    #elif defined(LINUX)
    const ::std::wstring defDeviceSystemNameFormat( L"/dev/ttyS%1" );
    const ::std::wstring defDeviceDisplayNameFormat( L"/dev/ttyS%1" );
    const int defSerialDeviceNoAddVal = 0;
    #elif defined(FREEBSD)
    const ::std::wstring defDeviceSystemNameFormat( L"/dev/ttyd%1" );
    const ::std::wstring defDeviceDisplayNameFormat( L"/dev/ttyd%1" );
    const int defSerialDeviceNoAddVal = 0;
    #else // UNDONE: please send me info about other systems
       #error "Serial I/O devices: nor Win32 nor Linux nor FreeBSD - other systems not supported now"
    #endif

    bool bRes = marty::env::getVar(::std::wstring(L"CLI2_IO_SERIAL_DEVICE_NAME"), deviceNameFmt )
             || marty::env::getVar(::std::wstring(L"CLI_IO_SERIAL_DEVICE_NAME"), deviceNameFmt );
    if (!bRes) deviceNameFmt = defDeviceSystemNameFormat;

    bRes = marty::env::getVar(::std::wstring(L"CLI2_IO_SERIAL_DEVICE_DISPLAY_NAME"), deviceDisplayNameFmt )
        || marty::env::getVar(::std::wstring(L"CLI_IO_SERIAL_DEVICE_DISPLAY_NAME"), deviceDisplayNameFmt );

    if (!bRes) deviceDisplayNameFmt = defDeviceDisplayNameFormat;

    ::std::wstring  serialDeviceNoAddValStr ;
    bRes = marty::env::getVar(::std::wstring(L"CLI2_IO_SERIAL_DEVICENO_ADD"), serialDeviceNoAddValStr )
        || marty::env::getVar(::std::wstring(L"CLI_IO_SERIAL_DEVICENO_ADD"), serialDeviceNoAddValStr );
    if (!bRes)
       {
        deviceNoAdd = defSerialDeviceNoAddVal;
       }
    else
       { // ��� ���� ���� �������� wcstoi, ������� ���� �������� ��������� ��������
        if (serialDeviceNoAddValStr==L"-1")     deviceNoAdd = -1;
        else if (serialDeviceNoAddValStr==L"0") deviceNoAdd = 0;
        else if (serialDeviceNoAddValStr==L"1") deviceNoAdd = 1;
        else if (serialDeviceNoAddValStr==L"2") deviceNoAdd = 2; // ?
        //else if (serialDeviceNoAddValStr==L"") deviceNoAdd = ;
        else deviceNoAdd = defSerialDeviceNoAddVal;
       }
   }


}; // namespace io
}; // namespace cli



#endif /* CLI_IO_SERIALHLP_H */



