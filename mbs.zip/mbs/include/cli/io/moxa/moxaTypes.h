#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_MOXA_MOXATYPES_H
#define CLI_IO_MOXA_MOXATYPES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/io/moxa/moxaTypes.h>", CLI_IO_MOXA_MOXATYPES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IO_MOXA_MOXATYPES_H
    #include <cli/io/moxa/moxaTypes.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::moxa::PortOpMode */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_MOXA_PORTOPMODE            DWORD
#else
    #define ENUM_CLI_MOXA_PORTOPMODE            DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_MOXA_PORTOPMODE_PAIRSLAVE
    #define CLI_MOXA_PORTOPMODE_PAIRSLAVE     CONSTANT_DWORD(0x0)
#endif /* CLI_MOXA_PORTOPMODE_PAIRSLAVE */

#ifndef CLI_MOXA_PORTOPMODE_PAIRMASTER
    #define CLI_MOXA_PORTOPMODE_PAIRMASTER    CONSTANT_DWORD(0x1)
#endif /* CLI_MOXA_PORTOPMODE_PAIRMASTER */

#ifndef CLI_MOXA_PORTOPMODE_REALCOM
    #define CLI_MOXA_PORTOPMODE_REALCOM       CONSTANT_DWORD(0x2)
#endif /* CLI_MOXA_PORTOPMODE_REALCOM */

#ifndef CLI_MOXA_PORTOPMODE_UNK3
    #define CLI_MOXA_PORTOPMODE_UNK3          CONSTANT_DWORD(0x3)
#endif /* CLI_MOXA_PORTOPMODE_UNK3 */

#ifndef CLI_MOXA_PORTOPMODE_UNK4
    #define CLI_MOXA_PORTOPMODE_UNK4          CONSTANT_DWORD(0x4)
#endif /* CLI_MOXA_PORTOPMODE_UNK4 */

#ifndef CLI_MOXA_PORTOPMODE_UNK5
    #define CLI_MOXA_PORTOPMODE_UNK5          CONSTANT_DWORD(0x5)
#endif /* CLI_MOXA_PORTOPMODE_UNK5 */

#ifndef CLI_MOXA_PORTOPMODE_UNK6
    #define CLI_MOXA_PORTOPMODE_UNK6          CONSTANT_DWORD(0x6)
#endif /* CLI_MOXA_PORTOPMODE_UNK6 */

#ifndef CLI_MOXA_PORTOPMODE_DISABLED
    #define CLI_MOXA_PORTOPMODE_DISABLED      CONSTANT_DWORD(0x7)
#endif /* CLI_MOXA_PORTOPMODE_DISABLED */

#ifndef CLI_MOXA_PORTOPMODE_REVERSETELNET
    #define CLI_MOXA_PORTOPMODE_REVERSETELNET                 CONSTANT_DWORD(0x8)
#endif /* CLI_MOXA_PORTOPMODE_REVERSETELNET */

#ifndef CLI_MOXA_PORTOPMODE_UNK9
    #define CLI_MOXA_PORTOPMODE_UNK9          CONSTANT_DWORD(0x9)
#endif /* CLI_MOXA_PORTOPMODE_UNK9 */

#ifndef CLI_MOXA_PORTOPMODE_TCPSERVER
    #define CLI_MOXA_PORTOPMODE_TCPSERVER     CONSTANT_DWORD(0xA)
#endif /* CLI_MOXA_PORTOPMODE_TCPSERVER */

#ifndef CLI_MOXA_PORTOPMODE_UNKB
    #define CLI_MOXA_PORTOPMODE_UNKB          CONSTANT_DWORD(0xB)
#endif /* CLI_MOXA_PORTOPMODE_UNKB */

#ifndef CLI_MOXA_PORTOPMODE_UNKC
    #define CLI_MOXA_PORTOPMODE_UNKC          CONSTANT_DWORD(0xC)
#endif /* CLI_MOXA_PORTOPMODE_UNKC */

#ifndef CLI_MOXA_PORTOPMODE_TCPCLIENT
    #define CLI_MOXA_PORTOPMODE_TCPCLIENT     CONSTANT_DWORD(0xD)
#endif /* CLI_MOXA_PORTOPMODE_TCPCLIENT */

#ifndef CLI_MOXA_PORTOPMODE_UDP
    #define CLI_MOXA_PORTOPMODE_UDP           CONSTANT_DWORD(0xE)
#endif /* CLI_MOXA_PORTOPMODE_UDP */

#ifndef CLI_MOXA_PORTOPMODE_UNKF
    #define CLI_MOXA_PORTOPMODE_UNKF          CONSTANT_DWORD(0xF)
#endif /* CLI_MOXA_PORTOPMODE_UNKF */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
            namespace PortOpMode {
                    const DWORD pairSlave        = CONSTANT_DWORD(0x0);
                    const DWORD pairMaster       = CONSTANT_DWORD(0x1);
                    const DWORD realCom          = CONSTANT_DWORD(0x2);
                    const DWORD unk3             = CONSTANT_DWORD(0x3);
                    const DWORD unk4             = CONSTANT_DWORD(0x4);
                    const DWORD unk5             = CONSTANT_DWORD(0x5);
                    const DWORD unk6             = CONSTANT_DWORD(0x6);
                    const DWORD disabled         = CONSTANT_DWORD(0x7);
                    const DWORD reverseTelnet    = CONSTANT_DWORD(0x8);
                    const DWORD unk9             = CONSTANT_DWORD(0x9);
                    const DWORD tcpServer        = CONSTANT_DWORD(0xA);
                    const DWORD unkB             = CONSTANT_DWORD(0xB);
                    const DWORD unkC             = CONSTANT_DWORD(0xC);
                    const DWORD tcpClient        = CONSTANT_DWORD(0xD);
                    const DWORD udp              = CONSTANT_DWORD(0xE);
                    const DWORD unkF             = CONSTANT_DWORD(0xF);
            }; // namespace PortOpMode
        }; // namespace moxa
    }; // namespace cli
    /* using namespace ::cli::moxa::PortOpMode; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPacketHeader */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPacketHeader
    #ifndef STRUCT_CLI_MOXA_CPACKETHEADER_PREDECLARED
    #define STRUCT_CLI_MOXA_CPACKETHEADER_PREDECLARED
        struct CPacketHeader;
        #ifndef STRUCT_CLI_MOXA_CPACKETHEADER
            #define STRUCT_CLI_MOXA_CPACKETHEADER     ::cli::moxa::CPacketHeader
        #endif
    #endif // STRUCT_CLI_MOXA_CPACKETHEADER_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPacketHeader
    #ifndef STRUCT_CLI_MOXA_CPACKETHEADER_PREDECLARED
    #define STRUCT_CLI_MOXA_CPACKETHEADER_PREDECLARED
        struct  tag_cli_moxa_CPacketHeader;
        typedef struct tag_cli_moxa_CPacketHeader cli_moxa_CPacketHeader;
        #ifndef STRUCT_CLI_MOXA_CPACKETHEADER
            #define STRUCT_CLI_MOXA_CPACKETHEADER     struct tag_cli_moxa_CPacketHeader
        #endif
    #endif // STRUCT_CLI_MOXA_CPACKETHEADER_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPACKETHEADER_DEFINED
            #define STRUCT_CLI_MOXA_CPACKETHEADER_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                BYTE                        pktid;
                BYTE                        result;
                WORD                        pktLen;
                DWORD                       id;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPACKETHEADER_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CDeviceIdStruct */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CDeviceIdStruct
    #ifndef STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_PREDECLARED
    #define STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_PREDECLARED
        struct CDeviceIdStruct;
        #ifndef STRUCT_CLI_MOXA_CDEVICEIDSTRUCT
            #define STRUCT_CLI_MOXA_CDEVICEIDSTRUCT   ::cli::moxa::CDeviceIdStruct
        #endif
    #endif // STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CDeviceIdStruct
    #ifndef STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_PREDECLARED
    #define STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_PREDECLARED
        struct  tag_cli_moxa_CDeviceIdStruct;
        typedef struct tag_cli_moxa_CDeviceIdStruct cli_moxa_CDeviceIdStruct;
        #ifndef STRUCT_CLI_MOXA_CDEVICEIDSTRUCT
            #define STRUCT_CLI_MOXA_CDEVICEIDSTRUCT   struct tag_cli_moxa_CDeviceIdStruct
        #endif
    #endif // STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_DEFINED
            #define STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                DWORD                       appId;
                WORD                        hardwareId;
                BYTE                        macAddress[6];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CCommonRequest */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CCommonRequest
    #ifndef STRUCT_CLI_MOXA_CCOMMONREQUEST_PREDECLARED
    #define STRUCT_CLI_MOXA_CCOMMONREQUEST_PREDECLARED
        struct CCommonRequest;
        #ifndef STRUCT_CLI_MOXA_CCOMMONREQUEST
            #define STRUCT_CLI_MOXA_CCOMMONREQUEST    ::cli::moxa::CCommonRequest
        #endif
    #endif // STRUCT_CLI_MOXA_CCOMMONREQUEST_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CCommonRequest
    #ifndef STRUCT_CLI_MOXA_CCOMMONREQUEST_PREDECLARED
    #define STRUCT_CLI_MOXA_CCOMMONREQUEST_PREDECLARED
        struct  tag_cli_moxa_CCommonRequest;
        typedef struct tag_cli_moxa_CCommonRequest cli_moxa_CCommonRequest;
        #ifndef STRUCT_CLI_MOXA_CCOMMONREQUEST
            #define STRUCT_CLI_MOXA_CCOMMONREQUEST    struct tag_cli_moxa_CCommonRequest
        #endif
    #endif // STRUCT_CLI_MOXA_CCOMMONREQUEST_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CCOMMONREQUEST_DEFINED
            #define STRUCT_CLI_MOXA_CCOMMONREQUEST_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETHEADER           header;
                STRUCT_CLI_MOXA_CDEVICEIDSTRUCT         deviceId[1];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CCOMMONREQUEST_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPacketFullHeader */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPacketFullHeader
    #ifndef STRUCT_CLI_MOXA_CPACKETFULLHEADER_PREDECLARED
    #define STRUCT_CLI_MOXA_CPACKETFULLHEADER_PREDECLARED
        struct CPacketFullHeader;
        #ifndef STRUCT_CLI_MOXA_CPACKETFULLHEADER
            #define STRUCT_CLI_MOXA_CPACKETFULLHEADER                 ::cli::moxa::CPacketFullHeader
        #endif
        #ifndef STRUCT_CLI_MOXA_CREQUESTPACKET
            #define STRUCT_CLI_MOXA_CREQUESTPACKET    ::cli::moxa::CRequestPacket
        #endif
        typedef STRUCT_CLI_MOXA_CPACKETFULLHEADER                 CRequestPacket;

    #endif // STRUCT_CLI_MOXA_CPACKETFULLHEADER_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPacketFullHeader
    #ifndef STRUCT_CLI_MOXA_CPACKETFULLHEADER_PREDECLARED
    #define STRUCT_CLI_MOXA_CPACKETFULLHEADER_PREDECLARED
        struct  tag_cli_moxa_CPacketFullHeader;
        typedef struct tag_cli_moxa_CPacketFullHeader cli_moxa_CPacketFullHeader;
        #ifndef STRUCT_CLI_MOXA_CPACKETFULLHEADER
            #define STRUCT_CLI_MOXA_CPACKETFULLHEADER                 struct tag_cli_moxa_CPacketFullHeader
        #endif
        #ifndef STRUCT_CLI_MOXA_CREQUESTPACKET
            #define STRUCT_CLI_MOXA_CREQUESTPACKET    cli_moxa_CRequestPacket
        #endif
        typedef STRUCT_CLI_MOXA_CPACKETFULLHEADER                 cli_moxa_CRequestPacket;

    #endif // STRUCT_CLI_MOXA_CPACKETFULLHEADER_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPACKETFULLHEADER_DEFINED
            #define STRUCT_CLI_MOXA_CPACKETFULLHEADER_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                BYTE                        pktid;
                BYTE                        result;
                WORD                        pktLen;
                DWORD                       id;
                STRUCT_CLI_MOXA_CDEVICEIDSTRUCT         deviceId;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPACKETFULLHEADER_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CDeviceInfo4Packet */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CDeviceInfo4Packet
    #ifndef STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_PREDECLARED
        struct CDeviceInfo4Packet;
        #ifndef STRUCT_CLI_MOXA_CDEVICEINFO4PACKET
            #define STRUCT_CLI_MOXA_CDEVICEINFO4PACKET                ::cli::moxa::CDeviceInfo4Packet
        #endif
    #endif // STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CDeviceInfo4Packet
    #ifndef STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_PREDECLARED
        struct  tag_cli_moxa_CDeviceInfo4Packet;
        typedef struct tag_cli_moxa_CDeviceInfo4Packet cli_moxa_CDeviceInfo4Packet;
        #ifndef STRUCT_CLI_MOXA_CDEVICEINFO4PACKET
            #define STRUCT_CLI_MOXA_CDEVICEINFO4PACKET                struct tag_cli_moxa_CDeviceInfo4Packet
        #endif
    #endif // STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_DEFINED
            #define STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                BYTE                        ipAddress[4];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CDEVICEINFO4PACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CDeviceSerialNumberPacket */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CDeviceSerialNumberPacket
    #ifndef STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_PREDECLARED
        struct CDeviceSerialNumberPacket;
        #ifndef STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET
            #define STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET         ::cli::moxa::CDeviceSerialNumberPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CDeviceSerialNumberPacket
    #ifndef STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_PREDECLARED
        struct  tag_cli_moxa_CDeviceSerialNumberPacket;
        typedef struct tag_cli_moxa_CDeviceSerialNumberPacket cli_moxa_CDeviceSerialNumberPacket;
        #ifndef STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET
            #define STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET         struct tag_cli_moxa_CDeviceSerialNumberPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_DEFINED
            #define STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                BYTE                        unknown1[8];
                DWORD                       serialNumber;
                BYTE                        unknown2[4];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CBeepControlPacket */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CBeepControlPacket
    #ifndef STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_PREDECLARED
        struct CBeepControlPacket;
        #ifndef STRUCT_CLI_MOXA_CBEEPCONTROLPACKET
            #define STRUCT_CLI_MOXA_CBEEPCONTROLPACKET                ::cli::moxa::CBeepControlPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CBeepControlPacket
    #ifndef STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_PREDECLARED
        struct  tag_cli_moxa_CBeepControlPacket;
        typedef struct tag_cli_moxa_CBeepControlPacket cli_moxa_CBeepControlPacket;
        #ifndef STRUCT_CLI_MOXA_CBEEPCONTROLPACKET
            #define STRUCT_CLI_MOXA_CBEEPCONTROLPACKET                struct tag_cli_moxa_CBeepControlPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_DEFINED
            #define STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                WORD                        beepCmd;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CBEEPCONTROLPACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPortStateRequestPacket */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPortStateRequestPacket
    #ifndef STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_PREDECLARED
        struct CPortStateRequestPacket;
        #ifndef STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET
            #define STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET           ::cli::moxa::CPortStateRequestPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPortStateRequestPacket
    #ifndef STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_PREDECLARED
        struct  tag_cli_moxa_CPortStateRequestPacket;
        typedef struct tag_cli_moxa_CPortStateRequestPacket cli_moxa_CPortStateRequestPacket;
        #ifndef STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET
            #define STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET           struct tag_cli_moxa_CPortStateRequestPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_DEFINED
            #define STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                WORD                        cmd;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPortStateData */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPortStateData
    #ifndef STRUCT_CLI_MOXA_CPORTSTATEDATA_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTSTATEDATA_PREDECLARED
        struct CPortStateData;
        #ifndef STRUCT_CLI_MOXA_CPORTSTATEDATA
            #define STRUCT_CLI_MOXA_CPORTSTATEDATA    ::cli::moxa::CPortStateData
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTSTATEDATA_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPortStateData
    #ifndef STRUCT_CLI_MOXA_CPORTSTATEDATA_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTSTATEDATA_PREDECLARED
        struct  tag_cli_moxa_CPortStateData;
        typedef struct tag_cli_moxa_CPortStateData cli_moxa_CPortStateData;
        #ifndef STRUCT_CLI_MOXA_CPORTSTATEDATA
            #define STRUCT_CLI_MOXA_CPORTSTATEDATA    struct tag_cli_moxa_CPortStateData
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTSTATEDATA_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPORTSTATEDATA_DEFINED
            #define STRUCT_CLI_MOXA_CPORTSTATEDATA_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                WORD                        speed;
                WORD                        u1;
                BYTE                        dataBits:2;
                BYTE                        stopBits:1;
                BYTE                        fParity:1;
                BYTE                        parity:2;
                BYTE                        u2:2;
                BYTE                        flowCtrl:2;
                BYTE                        u3:6;
                WORD                        u4;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPORTSTATEDATA_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPortStatePacketFixed */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPortStatePacketFixed
    #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_PREDECLARED
        struct CPortStatePacketFixed;
        #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED
            #define STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED             ::cli::moxa::CPortStatePacketFixed
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPortStatePacketFixed
    #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_PREDECLARED
        struct  tag_cli_moxa_CPortStatePacketFixed;
        typedef struct tag_cli_moxa_CPortStatePacketFixed cli_moxa_CPortStatePacketFixed;
        #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED
            #define STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED             struct tag_cli_moxa_CPortStatePacketFixed
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_DEFINED
            #define STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                DWORD                       unk1;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPortStatePacket */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPortStatePacket
    #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTSTATEPACKET_PREDECLARED
        struct CPortStatePacket;
        #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKET
            #define STRUCT_CLI_MOXA_CPORTSTATEPACKET  ::cli::moxa::CPortStatePacket
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTSTATEPACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPortStatePacket
    #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTSTATEPACKET_PREDECLARED
        struct  tag_cli_moxa_CPortStatePacket;
        typedef struct tag_cli_moxa_CPortStatePacket cli_moxa_CPortStatePacket;
        #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKET
            #define STRUCT_CLI_MOXA_CPORTSTATEPACKET  struct tag_cli_moxa_CPortStatePacket
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTSTATEPACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPORTSTATEPACKET_DEFINED
            #define STRUCT_CLI_MOXA_CPORTSTATEPACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                DWORD                       unk1;
                STRUCT_CLI_MOXA_CPORTSTATEDATA          portInfo[1];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPORTSTATEPACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::COpModeRequesrPacket */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   COpModeRequesrPacket
    #ifndef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_PREDECLARED
        struct COpModeRequesrPacket;
        #ifndef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET
            #define STRUCT_CLI_MOXA_COPMODEREQUESRPACKET              ::cli::moxa::COpModeRequesrPacket
        #endif
        #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOREQUESTPACKET
            #define STRUCT_CLI_MOXA_CTCPSERVERINFOREQUESTPACKET       ::cli::moxa::CTcpServerInfoRequestPacket
        #endif
        typedef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET              CTcpServerInfoRequestPacket;

        #ifndef STRUCT_CLI_MOXA_CPORTALIASREQUESTPACKET
            #define STRUCT_CLI_MOXA_CPORTALIASREQUESTPACKET           ::cli::moxa::CPortAliasRequestPacket
        #endif
        typedef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET              CPortAliasRequestPacket;

    #endif // STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_COpModeRequesrPacket
    #ifndef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_PREDECLARED
        struct  tag_cli_moxa_COpModeRequesrPacket;
        typedef struct tag_cli_moxa_COpModeRequesrPacket cli_moxa_COpModeRequesrPacket;
        #ifndef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET
            #define STRUCT_CLI_MOXA_COPMODEREQUESRPACKET              struct tag_cli_moxa_COpModeRequesrPacket
        #endif
        #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOREQUESTPACKET
            #define STRUCT_CLI_MOXA_CTCPSERVERINFOREQUESTPACKET       cli_moxa_CTcpServerInfoRequestPacket
        #endif
        typedef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET              cli_moxa_CTcpServerInfoRequestPacket;

        #ifndef STRUCT_CLI_MOXA_CPORTALIASREQUESTPACKET
            #define STRUCT_CLI_MOXA_CPORTALIASREQUESTPACKET           cli_moxa_CPortAliasRequestPacket
        #endif
        typedef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET              cli_moxa_CPortAliasRequestPacket;

    #endif // STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_DEFINED
            #define STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                BYTE                        cmd;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_COPMODEREQUESRPACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPortOpModeData */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPortOpModeData
    #ifndef STRUCT_CLI_MOXA_CPORTOPMODEDATA_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTOPMODEDATA_PREDECLARED
        struct CPortOpModeData;
        #ifndef STRUCT_CLI_MOXA_CPORTOPMODEDATA
            #define STRUCT_CLI_MOXA_CPORTOPMODEDATA   ::cli::moxa::CPortOpModeData
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTOPMODEDATA_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPortOpModeData
    #ifndef STRUCT_CLI_MOXA_CPORTOPMODEDATA_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTOPMODEDATA_PREDECLARED
        struct  tag_cli_moxa_CPortOpModeData;
        typedef struct tag_cli_moxa_CPortOpModeData cli_moxa_CPortOpModeData;
        #ifndef STRUCT_CLI_MOXA_CPORTOPMODEDATA
            #define STRUCT_CLI_MOXA_CPORTOPMODEDATA   struct tag_cli_moxa_CPortOpModeData
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTOPMODEDATA_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPORTOPMODEDATA_DEFINED
            #define STRUCT_CLI_MOXA_CPORTOPMODEDATA_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                BYTE                        opMode:4;
                BYTE                        unk:4;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPORTOPMODEDATA_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::COpModePacket */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   COpModePacket
    #ifndef STRUCT_CLI_MOXA_COPMODEPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_COPMODEPACKET_PREDECLARED
        struct COpModePacket;
        #ifndef STRUCT_CLI_MOXA_COPMODEPACKET
            #define STRUCT_CLI_MOXA_COPMODEPACKET     ::cli::moxa::COpModePacket
        #endif
    #endif // STRUCT_CLI_MOXA_COPMODEPACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_COpModePacket
    #ifndef STRUCT_CLI_MOXA_COPMODEPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_COPMODEPACKET_PREDECLARED
        struct  tag_cli_moxa_COpModePacket;
        typedef struct tag_cli_moxa_COpModePacket cli_moxa_COpModePacket;
        #ifndef STRUCT_CLI_MOXA_COPMODEPACKET
            #define STRUCT_CLI_MOXA_COPMODEPACKET     struct tag_cli_moxa_COpModePacket
        #endif
    #endif // STRUCT_CLI_MOXA_COPMODEPACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_COPMODEPACKET_DEFINED
            #define STRUCT_CLI_MOXA_COPMODEPACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                DWORD                       unk1;
                STRUCT_CLI_MOXA_CPORTOPMODEDATA         opMode[1];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_COPMODEPACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::COpModePacketFixed */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   COpModePacketFixed
    #ifndef STRUCT_CLI_MOXA_COPMODEPACKETFIXED_PREDECLARED
    #define STRUCT_CLI_MOXA_COPMODEPACKETFIXED_PREDECLARED
        struct COpModePacketFixed;
        #ifndef STRUCT_CLI_MOXA_COPMODEPACKETFIXED
            #define STRUCT_CLI_MOXA_COPMODEPACKETFIXED                ::cli::moxa::COpModePacketFixed
        #endif
    #endif // STRUCT_CLI_MOXA_COPMODEPACKETFIXED_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_COpModePacketFixed
    #ifndef STRUCT_CLI_MOXA_COPMODEPACKETFIXED_PREDECLARED
    #define STRUCT_CLI_MOXA_COPMODEPACKETFIXED_PREDECLARED
        struct  tag_cli_moxa_COpModePacketFixed;
        typedef struct tag_cli_moxa_COpModePacketFixed cli_moxa_COpModePacketFixed;
        #ifndef STRUCT_CLI_MOXA_COPMODEPACKETFIXED
            #define STRUCT_CLI_MOXA_COPMODEPACKETFIXED                struct tag_cli_moxa_COpModePacketFixed
        #endif
    #endif // STRUCT_CLI_MOXA_COPMODEPACKETFIXED_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_COPMODEPACKETFIXED_DEFINED
            #define STRUCT_CLI_MOXA_COPMODEPACKETFIXED_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                DWORD                       unk1;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_COPMODEPACKETFIXED_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CTcpServerPortInfoData */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CTcpServerPortInfoData
    #ifndef STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_PREDECLARED
    #define STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_PREDECLARED
        struct CTcpServerPortInfoData;
        #ifndef STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA
            #define STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA            ::cli::moxa::CTcpServerPortInfoData
        #endif
    #endif // STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CTcpServerPortInfoData
    #ifndef STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_PREDECLARED
    #define STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_PREDECLARED
        struct  tag_cli_moxa_CTcpServerPortInfoData;
        typedef struct tag_cli_moxa_CTcpServerPortInfoData cli_moxa_CTcpServerPortInfoData;
        #ifndef STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA
            #define STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA            struct tag_cli_moxa_CTcpServerPortInfoData
        #endif
    #endif // STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_DEFINED
            #define STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                USHORT                      commandPort;
                USHORT                      dataPort;
                DWORD                       unk1;
                DWORD                       unk2;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CTcpServerInfoPacket */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CTcpServerInfoPacket
    #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_PREDECLARED
        struct CTcpServerInfoPacket;
        #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET
            #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET              ::cli::moxa::CTcpServerInfoPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CTcpServerInfoPacket
    #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_PREDECLARED
        struct  tag_cli_moxa_CTcpServerInfoPacket;
        typedef struct tag_cli_moxa_CTcpServerInfoPacket cli_moxa_CTcpServerInfoPacket;
        #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET
            #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET              struct tag_cli_moxa_CTcpServerInfoPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_DEFINED
            #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                DWORD                       unk1;
                STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA              portInfo[1];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CTcpServerInfoPacketFixed */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CTcpServerInfoPacketFixed
    #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_PREDECLARED
    #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_PREDECLARED
        struct CTcpServerInfoPacketFixed;
        #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED
            #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED         ::cli::moxa::CTcpServerInfoPacketFixed
        #endif
    #endif // STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CTcpServerInfoPacketFixed
    #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_PREDECLARED
    #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_PREDECLARED
        struct  tag_cli_moxa_CTcpServerInfoPacketFixed;
        typedef struct tag_cli_moxa_CTcpServerInfoPacketFixed cli_moxa_CTcpServerInfoPacketFixed;
        #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED
            #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED         struct tag_cli_moxa_CTcpServerInfoPacketFixed
        #endif
    #endif // STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_DEFINED
            #define STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                DWORD                       unk1;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPortAliasPortData */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPortAliasPortData
    #ifndef STRUCT_CLI_MOXA_CPORTALIASPORTDATA_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTALIASPORTDATA_PREDECLARED
        struct CPortAliasPortData;
        #ifndef STRUCT_CLI_MOXA_CPORTALIASPORTDATA
            #define STRUCT_CLI_MOXA_CPORTALIASPORTDATA                ::cli::moxa::CPortAliasPortData
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTALIASPORTDATA_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPortAliasPortData
    #ifndef STRUCT_CLI_MOXA_CPORTALIASPORTDATA_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTALIASPORTDATA_PREDECLARED
        struct  tag_cli_moxa_CPortAliasPortData;
        typedef struct tag_cli_moxa_CPortAliasPortData cli_moxa_CPortAliasPortData;
        #ifndef STRUCT_CLI_MOXA_CPORTALIASPORTDATA
            #define STRUCT_CLI_MOXA_CPORTALIASPORTDATA                struct tag_cli_moxa_CPortAliasPortData
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTALIASPORTDATA_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPORTALIASPORTDATA_DEFINED
            #define STRUCT_CLI_MOXA_CPORTALIASPORTDATA_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                CHAR                        portAlias[16];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPORTALIASPORTDATA_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPortAliasPacket */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPortAliasPacket
    #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTALIASPACKET_PREDECLARED
        struct CPortAliasPacket;
        #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKET
            #define STRUCT_CLI_MOXA_CPORTALIASPACKET  ::cli::moxa::CPortAliasPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTALIASPACKET_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPortAliasPacket
    #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKET_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTALIASPACKET_PREDECLARED
        struct  tag_cli_moxa_CPortAliasPacket;
        typedef struct tag_cli_moxa_CPortAliasPacket cli_moxa_CPortAliasPacket;
        #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKET
            #define STRUCT_CLI_MOXA_CPORTALIASPACKET  struct tag_cli_moxa_CPortAliasPacket
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTALIASPACKET_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKET_DEFINED
            #define STRUCT_CLI_MOXA_CPORTALIASPACKET_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                DWORD                       unk1;
                STRUCT_CLI_MOXA_CPORTALIASPORTDATA      aliases[1];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPORTALIASPACKET_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CPortAliasPacketFixed */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CPortAliasPacketFixed
    #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_PREDECLARED
        struct CPortAliasPacketFixed;
        #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED
            #define STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED             ::cli::moxa::CPortAliasPacketFixed
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CPortAliasPacketFixed
    #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_PREDECLARED
    #define STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_PREDECLARED
        struct  tag_cli_moxa_CPortAliasPacketFixed;
        typedef struct tag_cli_moxa_CPortAliasPacketFixed cli_moxa_CPortAliasPacketFixed;
        #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED
            #define STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED             struct tag_cli_moxa_CPortAliasPacketFixed
        #endif
    #endif // STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_DEFINED
            #define STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CPACKETFULLHEADER       header;
                DWORD                       unk1;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif

#endif /* CLI_IO_MOXA_MOXATYPES_H */
