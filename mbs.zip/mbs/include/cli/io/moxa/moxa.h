#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_MOXA_MOXA_H
#define CLI_IO_MOXA_MOXA_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/io/moxa/moxa.h>", CLI_IO_MOXA_MOXA_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IO_MOXA_MOXA_H
    #include <cli/io/moxa/moxa.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif

#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IO_MOXA_MOXATYPES_H
    #include <cli/io/moxa/moxaTypes.h>
#endif

#ifndef CLI_IO_ISERIAL_H
    #include <cli/io/iserial.h>
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CMoxaSerialPortInfo */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace serial {
                struct                                   COptions;
                #ifndef STRUCT_CLI_IO_SERIAL_COPTIONS
                    #define STRUCT_CLI_IO_SERIAL_COPTIONS     ::cli::io::serial::COptions
                #endif

            }; // namespace serial
        }; // namespace io
    }; // namespace cli

#else /* C-like declarations */

    #ifndef STRUCT_CLI_IO_SERIAL_COPTIONS_PREDECLARED
    #define STRUCT_CLI_IO_SERIAL_COPTIONS_PREDECLARED
    typedef struct tag_cli_io_serial_COptions                    cli_io_serial_COptions;
    #endif //STRUCT_CLI_IO_SERIAL_COPTIONS
    #ifndef STRUCT_CLI_IO_SERIAL_COPTIONS
        #define STRUCT_CLI_IO_SERIAL_COPTIONS     struct tag_cli_io_serial_COptions
    #endif


#endif /* end of C-like declarations */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CMoxaSerialPortInfo
    #ifndef STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_PREDECLARED
    #define STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_PREDECLARED
        struct CMoxaSerialPortInfo;
        #ifndef STRUCT_CLI_MOXA_CMOXASERIALPORTINFO
            #define STRUCT_CLI_MOXA_CMOXASERIALPORTINFO               ::cli::moxa::CMoxaSerialPortInfo
        #endif
    #endif // STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CMoxaSerialPortInfo
    #ifndef STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_PREDECLARED
    #define STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_PREDECLARED
        struct  tag_cli_moxa_CMoxaSerialPortInfo;
        typedef struct tag_cli_moxa_CMoxaSerialPortInfo cli_moxa_CMoxaSerialPortInfo;
        #ifndef STRUCT_CLI_MOXA_CMOXASERIALPORTINFO
            #define STRUCT_CLI_MOXA_CMOXASERIALPORTINFO               struct tag_cli_moxa_CMoxaSerialPortInfo
        #endif
    #endif // STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_DEFINED
            #define STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_IO_SERIAL_COPTIONS           options;
                ENUM_CLI_MOXA_PORTOPMODE    opMode;
                USHORT                      tcpDataPort;
                USHORT                      tcpCommandPort;
                WCHAR                       portAlias[20];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CMOXASERIALPORTINFO_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::moxa::CMoxaServerInfo */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            struct                                   IpAddress;
            #ifndef STRUCT_CLI_INET_IPADDRESS
                #define STRUCT_CLI_INET_IPADDRESS         ::cli::inet::IpAddress
            #endif

        }; // namespace inet
    }; // namespace cli
    namespace cli {
        namespace moxa {
            struct                                   CDeviceIdStruct;
            #ifndef STRUCT_CLI_MOXA_CDEVICEIDSTRUCT
                #define STRUCT_CLI_MOXA_CDEVICEIDSTRUCT   ::cli::moxa::CDeviceIdStruct
            #endif

        }; // namespace moxa
    }; // namespace cli

#else /* C-like declarations */

    #ifndef STRUCT_CLI_INET_IPADDRESS_PREDECLARED
    #define STRUCT_CLI_INET_IPADDRESS_PREDECLARED
    typedef struct tag_cli_inet_IpAddress    cli_inet_IpAddress;
    #endif //STRUCT_CLI_INET_IPADDRESS
    #ifndef STRUCT_CLI_INET_IPADDRESS
        #define STRUCT_CLI_INET_IPADDRESS         struct tag_cli_inet_IpAddress
    #endif

    #ifndef STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_PREDECLARED
    #define STRUCT_CLI_MOXA_CDEVICEIDSTRUCT_PREDECLARED
    typedef struct tag_cli_moxa_CDeviceIdStruct                  cli_moxa_CDeviceIdStruct;
    #endif //STRUCT_CLI_MOXA_CDEVICEIDSTRUCT
    #ifndef STRUCT_CLI_MOXA_CDEVICEIDSTRUCT
        #define STRUCT_CLI_MOXA_CDEVICEIDSTRUCT   struct tag_cli_moxa_CDeviceIdStruct
    #endif


#endif /* end of C-like declarations */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace moxa {
    #define CLI_STRUCT_NAME                   CMoxaServerInfo
    #ifndef STRUCT_CLI_MOXA_CMOXASERVERINFO_PREDECLARED
    #define STRUCT_CLI_MOXA_CMOXASERVERINFO_PREDECLARED
        struct CMoxaServerInfo;
        #ifndef STRUCT_CLI_MOXA_CMOXASERVERINFO
            #define STRUCT_CLI_MOXA_CMOXASERVERINFO   ::cli::moxa::CMoxaServerInfo
        #endif
    #endif // STRUCT_CLI_MOXA_CMOXASERVERINFO_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_moxa_CMoxaServerInfo
    #ifndef STRUCT_CLI_MOXA_CMOXASERVERINFO_PREDECLARED
    #define STRUCT_CLI_MOXA_CMOXASERVERINFO_PREDECLARED
        struct  tag_cli_moxa_CMoxaServerInfo;
        typedef struct tag_cli_moxa_CMoxaServerInfo cli_moxa_CMoxaServerInfo;
        #ifndef STRUCT_CLI_MOXA_CMOXASERVERINFO
            #define STRUCT_CLI_MOXA_CMOXASERVERINFO   struct tag_cli_moxa_CMoxaServerInfo
        #endif
    #endif // STRUCT_CLI_MOXA_CMOXASERVERINFO_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_MOXA_CMOXASERVERINFO_DEFINED
            #define STRUCT_CLI_MOXA_CMOXASERVERINFO_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_MOXA_CDEVICEIDSTRUCT         deviceId;
                DWORD                       serialNumber;
                WCHAR                       productName[32];
                WCHAR                       serverName[32];
                STRUCT_CLI_INET_IPADDRESS               serverAddr;
                UINT                        udpCommonPort;
                SIZE_T                      numberOfPorts;
                STRUCT_CLI_MOXA_CMOXASERIALPORTINFO     portInfo[16];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_MOXA_CMOXASERVERINFO_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::moxa::iMoxaFinder */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_MOXA_IMOXAFINDER_IID
    #define INTERFACE_CLI_MOXA_IMOXAFINDER_IID    "/cli/moxa/iMoxaFinder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace moxa {
    #define INTERFACE iMoxaFinder
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_MOXA_IMOXAFINDER
       #define INTERFACE_CLI_MOXA_IMOXAFINDER    ::cli::moxa::iMoxaFinder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_moxa_iMoxaFinder
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_MOXA_IMOXAFINDER
       #define INTERFACE_CLI_MOXA_IMOXAFINDER    cli_moxa_iMoxaFinder
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::moxa::iMoxaFinder methods */
                CLIMETHOD(searchAddressListGet) (THIS_ CLISTR*           _searchAddressList
                                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                ) PURE;
                CLIMETHOD(searchAddressListSet) (THIS_ const CLISTR*     _searchAddressList
                                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                ) PURE;
                CLIMETHOD(searchAddressListSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(clearAll) (THIS) PURE;
                CLIMETHOD(searchForServers) (THIS_ SIZE_T    tryCount /* [in] size_t  tryCount  */
                                                 , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                                 , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                            ) PURE;
                CLIMETHOD(foundServersGet) (THIS_ STRUCT_CLI_MOXA_CMOXASERVERINFO*    _foundServers /* [out] ::cli::moxa::CMoxaServerInfo _foundServers  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           ) PURE;
                CLIMETHOD(foundServersSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::moxa::iMoxaFinder >
           {
            static char const * getName() { return INTERFACE_CLI_MOXA_IMOXAFINDER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::moxa::iMoxaFinder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::moxa::iMoxaFinder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace moxa {
            // interface ::cli::moxa::iMoxaFinder wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_MOXA_IMOXAFINDER >
                                          */
                     >
            class CiMoxaFinderWrapper
            {
                public:
            
                    typedef  CiMoxaFinderWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiMoxaFinderWrapper() :
                       pif(0) {}
            
                    CiMoxaFinderWrapper( iMoxaFinder *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiMoxaFinderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiMoxaFinderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiMoxaFinderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiMoxaFinderWrapper(const CiMoxaFinderWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiMoxaFinderWrapper()  { }
            
                    CiMoxaFinderWrapper& operator=(const CiMoxaFinderWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_searchAddressList( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = searchAddressListGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_searchAddressList( SIZE_T idx1 , const ::std::wstring &_searchAddressList
                                              )
                       { // MS style - index goes before value, need reorder
                        RCODE res = searchAddressListSet( _searchAddressList, idx1 );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    SIZE_T size_searchAddressList(  )
                       {
                        SIZE_T size;
                        RCODE res = searchAddressListSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, searchAddressList, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE searchAddressListGet( ::std::wstring    &_searchAddressList
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              )
                       {
                        CCliStr tmp__searchAddressList; CCliStr_init( tmp__searchAddressList );
                    
                        RCODE res = pif->searchAddressListGet(&tmp__searchAddressList, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _searchAddressList, tmp__searchAddressList);
                           }
                        return res;
                       }
                    
                    RCODE searchAddressListSet( const ::std::wstring    &_searchAddressList
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              )
                       {
                        CCliStr tmp__searchAddressList; CCliStr_lightCopyTo( tmp__searchAddressList, _searchAddressList);
                    
                        return pif->searchAddressListSet(&tmp__searchAddressList, idx1);
                       }
                    
                    RCODE searchAddressListSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->searchAddressListSize(_size);
                       }
                    
                    RCODE clearAll( )
                       {
                        return pif->clearAll();
                       }
                    
                    RCODE searchForServers( SIZE_T    tryCount /* [in] size_t  tryCount  */
                                          , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                          , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                          )
                       {
                    
                    
                    
                        return pif->searchForServers(tryCount, timeoutFixed, timeoutMultiplier);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    STRUCT_CLI_MOXA_CMOXASERVERINFO get_foundServers( SIZE_T idx1 )
                       {
                        STRUCT_CLI_MOXA_CMOXASERVERINFO tmpVal;
                        RCODE res = foundServersGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_foundServers(  )
                       {
                        SIZE_T size;
                        RCODE res = foundServersSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, STRUCT_CLI_MOXA_CMOXASERVERINFO, foundServers, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE foundServersGet( STRUCT_CLI_MOXA_CMOXASERVERINFO    &_foundServers /* [out] ::cli::moxa::CMoxaServerInfo _foundServers  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         )
                       {
                    
                    
                        return pif->foundServersGet(&_foundServers, idx1);
                       }
                    
                    RCODE foundServersSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->foundServersSize(_size);
                       }
                    

            
            
            }; // class CiMoxaFinderWrapper
            
            typedef CiMoxaFinderWrapper< ::cli::CCliPtr< INTERFACE_CLI_MOXA_IMOXAFINDER     > >  CiMoxaFinder;
            typedef CiMoxaFinderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_MOXA_IMOXAFINDER > >  CiMoxaFinder_nrc; /* No ref counting for interface used */
            typedef CiMoxaFinderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_MOXA_IMOXAFINDER > >  CiMoxaFinder_tmp; /* for temporary usage, same as CiMoxaFinder_nrc */
            
            
            
            
            
        }; // namespace moxa
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::moxa::iMoxaManager */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iArgList;
        #ifndef INTERFACE_CLI_IARGLIST
            #define INTERFACE_CLI_IARGLIST            ::cli::iArgList
        #endif

    }; // namespace cli
    namespace cli {
        namespace moxa {
            interface                                iMoxaFinder;
            #ifndef INTERFACE_CLI_MOXA_IMOXAFINDER
                #define INTERFACE_CLI_MOXA_IMOXAFINDER    ::cli::moxa::iMoxaFinder
            #endif

        }; // namespace moxa
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IARGLIST_PREDECLARED
    #define INTERFACE_CLI_IARGLIST_PREDECLARED
    typedef interface tag_cli_iArgList       cli_iArgList;
    #endif //INTERFACE_CLI_IARGLIST
    #ifndef INTERFACE_CLI_IARGLIST
        #define INTERFACE_CLI_IARGLIST            struct tag_cli_iArgList
    #endif

    #ifndef INTERFACE_CLI_MOXA_IMOXAFINDER_PREDECLARED
    #define INTERFACE_CLI_MOXA_IMOXAFINDER_PREDECLARED
    typedef interface tag_cli_moxa_iMoxaFinder                   cli_moxa_iMoxaFinder;
    #endif //INTERFACE_CLI_MOXA_IMOXAFINDER
    #ifndef INTERFACE_CLI_MOXA_IMOXAFINDER
        #define INTERFACE_CLI_MOXA_IMOXAFINDER    struct tag_cli_moxa_iMoxaFinder
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_MOXA_IMOXAMANAGER_IID
    #define INTERFACE_CLI_MOXA_IMOXAMANAGER_IID    "/cli/moxa/iMoxaManager"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace moxa {
    #define INTERFACE iMoxaManager
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_MOXA_IMOXAMANAGER
       #define INTERFACE_CLI_MOXA_IMOXAMANAGER    ::cli::moxa::iMoxaManager
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_moxa_iMoxaManager
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_MOXA_IMOXAMANAGER
       #define INTERFACE_CLI_MOXA_IMOXAMANAGER    cli_moxa_iMoxaManager
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::moxa::iMoxaManager methods */
                CLIMETHOD(createFinder) (THIS_ INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                             , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                             , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                             , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                        ) PURE;
                CLIMETHOD(createFinderEx) (THIS_ const CLISTR*     srvAddrMask
                                               , INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                               , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                               , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                               , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                          ) PURE;
                CLIMETHOD(createFinderExList) (THIS_ INTERFACE_CLI_IARGLIST*    addrList /* [in] ::cli::iArgList*  addrList  */
                                                   , INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                                   , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                                   , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                                   , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                              ) PURE;
                CLIMETHOD(updateServerInfo) (THIS_ STRUCT_CLI_MOXA_CMOXASERVERINFO*    srvInfo /* [in,out] ::cli::moxa::CMoxaServerInfo srvInfo  */) PURE;
                CLIMETHOD(serverBeep) (THIS_ const STRUCT_CLI_MOXA_CMOXASERVERINFO*    srv /* [in,ref] ::cli::moxa::CMoxaServerInfo  srv  */
                                           , BOOL    beepONOff /* [in] bool  beepONOff  */
                                      ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace moxa
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::moxa::iMoxaManager >
           {
            static char const * getName() { return INTERFACE_CLI_MOXA_IMOXAMANAGER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::moxa::iMoxaManager* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::moxa::iMoxaManager > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace moxa {
            // interface ::cli::moxa::iMoxaManager wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_MOXA_IMOXAMANAGER >
                                          */
                     >
            class CiMoxaManagerWrapper
            {
                public:
            
                    typedef  CiMoxaManagerWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiMoxaManagerWrapper() :
                       pif(0) {}
            
                    CiMoxaManagerWrapper( iMoxaManager *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiMoxaManagerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiMoxaManagerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiMoxaManagerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiMoxaManagerWrapper(const CiMoxaManagerWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiMoxaManagerWrapper()  { }
            
                    CiMoxaManagerWrapper& operator=(const CiMoxaManagerWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE createFinder( INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                      , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                      , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                      , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                      )
                       {
                    
                    
                    
                    
                        return pif->createFinder(finder, tryCount, timeoutFixed, timeoutMultiplier);
                       }
                    
                    RCODE createFinderEx( const ::std::wstring    &srvAddrMask
                                        , INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                        , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                        , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                        , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                        )
                       {
                        CCliStr tmp_srvAddrMask; CCliStr_lightCopyTo( tmp_srvAddrMask, srvAddrMask);
                    
                    
                    
                    
                        return pif->createFinderEx(&tmp_srvAddrMask, finder, tryCount, timeoutFixed, timeoutMultiplier);
                       }
                    
                    RCODE createFinderExList( INTERFACE_CLI_IARGLIST*    addrList /* [in] ::cli::iArgList*  addrList  */
                                            , INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                            , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                            , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                            , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                            )
                       {
                    
                    
                    
                    
                    
                        return pif->createFinderExList(addrList, finder, tryCount, timeoutFixed, timeoutMultiplier);
                       }
                    
                    RCODE updateServerInfo( STRUCT_CLI_MOXA_CMOXASERVERINFO    &srvInfo /* [in,out] ::cli::moxa::CMoxaServerInfo srvInfo  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->updateServerInfo(&srvInfo);
                       }
                    
                    RCODE serverBeep( const STRUCT_CLI_MOXA_CMOXASERVERINFO    &srv /* [in,ref] ::cli::moxa::CMoxaServerInfo  srv  (struct passed by ref in wrapper) */
                                    , BOOL    beepONOff /* [in] bool  beepONOff  */
                                    )
                       {
                    
                    
                        return pif->serverBeep(&srv, beepONOff);
                       }
                    

            
            
            }; // class CiMoxaManagerWrapper
            
            typedef CiMoxaManagerWrapper< ::cli::CCliPtr< INTERFACE_CLI_MOXA_IMOXAMANAGER     > >  CiMoxaManager;
            typedef CiMoxaManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_MOXA_IMOXAMANAGER > >  CiMoxaManager_nrc; /* No ref counting for interface used */
            typedef CiMoxaManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_MOXA_IMOXAMANAGER > >  CiMoxaManager_tmp; /* for temporary usage, same as CiMoxaManager_nrc */
            
            
            
            
            
        }; // namespace moxa
    }; // namespace cli

#endif





#endif /* CLI_IO_MOXA_MOXA_H */
