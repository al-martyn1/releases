#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_MOXA_MOXAASPPDEFS_H
#define CLI_IO_MOXA_MOXAASPPDEFS_H

/* add this lines to your scr
#ifndef CLI_IO_MOXA_MOXAASPPDEFS_H
    #include <cli/io/moxa/moxaAsppDefs.h>
#endif
*/


#define ASPP_CMD_IOCTL          16  // 0x10
#define ASPP_CMD_FLOWCTRL       17  // 0x11
#define ASPP_CMD_LSTATUS        19  // 0x13
#define ASPP_CMD_LINECTRL       18  // 0x12
#define ASPP_CMD_FLUSH          20  // 0x14
#define ASPP_CMD_OQUEUE         22  // 0x16
#define ASPP_CMD_SETBAUD        23  // 0x17
#define ASPP_CMD_START_BREAK    33  // 0x21
#define ASPP_CMD_STOP_BREAK     34  // 0x22
#define ASPP_CMD_START_NOTIFY   36  // 0x24
#define ASPP_CMD_STOP_NOTIFY    37  // 0x25
#define ASPP_CMD_HOST           43  // 0x2B
#define ASPP_CMD_PORT_INIT      44  // 0x2C
#define ASPP_CMD_WAIT_OQUEUE    47  // 0x2F

#define ASPP_CMD_NOTIFY         38  // 0x26
#define ASPP_CMD_POLLING        39  // 0x27
#define ASPP_CMD_ALIVE          40  // 0x28

#define ASPP_CMD_IQUEUE         21  // 0x15
#define ASPP_CMD_XONXOFF        24  // 0x18
#define ASPP_CMD_PORT_RESET     32  // 0x20
#define ASPP_CMD_RESENT_TIME    46  // 0x2E
#define ASPP_CMD_TX_FIFO        48  // 0x30
#define ASPP_CMD_SETXON         51  // 0x33
#define ASPP_CMD_SETXOFF        52  // 0x34

#define ASPP_FLUSH_RX_BUFFER    0
#define ASPP_FLUSH_TX_BUFFER    1
#define ASPP_FLUSH_ALL_BUFFER   2

#define ASPP_IOCTL_B300         0
#define ASPP_IOCTL_B600         1
#define ASPP_IOCTL_B1200        2
#define ASPP_IOCTL_B2400        3
#define ASPP_IOCTL_B4800        4
#define ASPP_IOCTL_B7200        5
#define ASPP_IOCTL_B9600        6
#define ASPP_IOCTL_B19200       7
#define ASPP_IOCTL_B38400       8
#define ASPP_IOCTL_B57600       9
#define ASPP_IOCTL_B115200      10
#define ASPP_IOCTL_B230400      11
#define ASPP_IOCTL_B460800      12
#define ASPP_IOCTL_B921600      13
#define ASPP_IOCTL_B150         14
#define ASPP_IOCTL_B134         15
#define ASPP_IOCTL_B110         16
#define ASPP_IOCTL_B75          17
#define ASPP_IOCTL_B50          18

#define ASPP_IOCTL_BITS8        3
#define ASPP_IOCTL_BITS7        2
#define ASPP_IOCTL_BITS6        1
#define ASPP_IOCTL_BITS5        0

#define ASPP_IOCTL_STOP1        0
#define ASPP_IOCTL_STOP2        4

#define ASPP_IOCTL_EVEN         8
#define ASPP_IOCTL_ODD          16
#define ASPP_IOCTL_MARK         24
#define ASPP_IOCTL_SPACE        32
#define ASPP_IOCTL_NONE         0



#endif /* CLI_IO_MOXA_MOXAASPPDEFS_H */

