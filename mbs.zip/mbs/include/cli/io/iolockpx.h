#ifndef CLI_IO_IOLOCKPX_H
#define CLI_IO_IOLOCKPX_H

#if defined(WIN32) || defined(_WIN32)
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else
    #include <alloca.h>
    #ifndef _alloca
        #define _alloca  alloca
    #endif
#endif

#if !defined(WIN32) && !defined(_WIN32)
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

#if !defined(_INC_STDIO) && !defined(_STDIO_H_) && !defined(_STDIO_H)
    #include <stdio.h>
#endif

#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif

#ifndef CLI_IO_SERIALHLP_H
    #include <cli/io/serialHlp.h>
#endif


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif


namespace cli
{
namespace io
{

namespace util
{
/*
inline
char digit2char(unsigned d)
   {
    if (d<10) return (char)d+'0';
    return (char)d+'A'-10;
   }

inline
::std::string uint2str(uint t, int ss = 10, int width = 0, char fill=' ')
   {
    ::std::string res;
    while(t)
       {
        res.append( 1, digit2char( t % ss) );
        t = t / ss;
       }

    if (width>0 && (int)res.size()<width)
       res.append( width - res.size(), fill );

    ::std::reverse( res.begin(), res.end() );
    if (res.empty()) return "0";
    return res;
   }

inline // pBuf must point to enough buf
size_t uint2str(char *pBuf, uint t, int ss = 10)
   {
    size_t len = 0;
    char *pOrg = pBuf;
    ::std::string res;
    while(t)
       {
        ++len;
        *pBuf++ = digit2char( t % ss);
        t = t / ss;
       }
    if (pBuf==pOrg) { *pBuf++ = '0'; ++len; }
    *pBuf = 0; --pBuf;
    size_t i = 0;
    for(; i!=len/2; ++i)
       {
        char tmp = *pBuf; *pBuf = *pOrg; *pOrg = tmp; ++pOrg; --pBuf;
       }

    return len;
   }
*/

}; // namespace util

// trye to make new lock for exclusive usage file/resource
// return false if resource allready locked
// return true if lock newly taken
inline
bool tryMakeNewExclusiveLock( const char* lockFileName)
   {
    PID_T pid = getpid();
    char strPid[64];
    char strTick[64];
    sprintf(strPid, "%u", pid);
    sprintf(strTick, "%u", (unsigned)cliGetTickCount());

    char* uniqName = (char*)_alloca( strlen(lockFileName) + strlen(strPid) + strlen(strTick) + 16 );
    strcpy( uniqName, lockFileName );
    strcat( uniqName, "." );
    strcat( uniqName, strPid );
    strcat( uniqName, "." );
    strcat( uniqName, strTick );

    //mode_t prevMask = umask(0777);
    mode_t prevMask = umask(0111);
    //std::cout<<"prevMask: "<<prevMask<<"\n";
    //std::cout<<"newMask : "<<umask(0777)<<"\n";

    mode_t creatMode = S_IRWXU|S_IRWXG|S_IRWXO;
    int newLockFile = ::open( uniqName, O_CREAT|O_WRONLY, creatMode );
    if (newLockFile==-1) 
       {
        ::umask(prevMask);
        return false; // failed to lock
       }
    //std::cout<<"newLockFile: "<<newLockFile<<"\n";
    ssize_t bytesToWrite = strlen(strPid);
    if (::write(newLockFile, strPid, (size_t)bytesToWrite )!=bytesToWrite)
       {
        //std::cout<<"Write error: "<<errno<<" "<<strerror(errno)<<"\n";
        //std::cout<<"newLockFile: "<<newLockFile<<"\n";
        ::close(newLockFile);
        ::unlink(uniqName);
        ::umask(prevMask);
        return false;
       }
    ::close(newLockFile);

    bool res = false;
    if (::link(uniqName, lockFileName)==-1)
       {
        struct stat s;
        ::stat(uniqName, &s);
        if (s.st_nlink>=2) res = true;       
       }
    else
       {
        res = true;
       }
    
    ::unlink(uniqName);
    ::umask(prevMask);
    return res;
   }

bool makeExclusiveLock( const char* lockFileName, PID_T *pPidOwner)
   {
    if (pPidOwner) *pPidOwner = 0;

    if (tryMakeNewExclusiveLock(lockFileName)) return true;

    /*
    PID_T pid = getpid();
    char strPid[64];
    sprintf(strPid, "%u", pid);
    */
    int lockFile = open( lockFileName, O_RDWR);
    if (lockFile==-1)
       {
        return false;
       }

    char buf[64];
    ssize_t readed = read( lockFile, buf, 63);
    if (readed==-1)
       {
        close(lockFile);
        if (pPidOwner) *pPidOwner = 0;
        return false;
       }
    buf[readed] = 0;
    close(lockFile);

    PID_T lockOwnersPid = (PID_T)strtoul( buf, 0, 10);
    int kr = kill(lockOwnersPid, 0);
    if (kr!=-1)
       { // process with specified pid was found
        if (pPidOwner) *pPidOwner = lockOwnersPid;
        return false;
       }
    // process not found
    unlink(lockFileName);

    return tryMakeNewExclusiveLock(lockFileName);
   }

void unlockExclusiveLock( const char* lockFileName )
   {
    unlink(lockFileName);
   }


::std::string makeLockFileName( const ::std::wstring &devName)
   {
    ::std::wstring devOnly = getSerialDeviceNameOnly(devName);
    //::std::string strDevOnly; strDevOnly.reserve(devOnly.size());
    ::std::string lockName = "/var/lock/LCK..";
    ::std::wstring::size_type i=0, size = devOnly.size();
    for(; i!=size; ++i)
       {
        lockName.append(1, (char)devOnly[i]);
       }
    return lockName;
   }



}; // namespace io
}; // namespace cli


#endif // !defined(WIN32) && !defined(_WIN32)

#endif /* CLI_IO_IOLOCKPX_H */

