#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_I_IO_H
#define CLI_IO_I_IO_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/io/i_io.h>", CLI_IO_I_IO_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::io::IOConnectingState */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_IO_IOCONNECTINGSTATE       UINT
#else
    #define ENUM_CLI_IO_IOCONNECTINGSTATE       UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_IO_IOCONNECTINGSTATE_ABORTREQUEST
    #define CLI_IO_IOCONNECTINGSTATE_ABORTREQUEST             CONSTANT_UINT(0x00000000)
#endif /* CLI_IO_IOCONNECTINGSTATE_ABORTREQUEST */

#ifndef CLI_IO_IOCONNECTINGSTATE_STATECONNECTED
    #define CLI_IO_IOCONNECTINGSTATE_STATECONNECTED           CONSTANT_UINT(0x00000001)
#endif /* CLI_IO_IOCONNECTINGSTATE_STATECONNECTED */

#ifndef CLI_IO_IOCONNECTINGSTATE_STATEFAILED
    #define CLI_IO_IOCONNECTINGSTATE_STATEFAILED              CONSTANT_UINT(0x00000002)
#endif /* CLI_IO_IOCONNECTINGSTATE_STATEFAILED */

#ifndef CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING
    #define CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING           CONSTANT_UINT(0x00000003)
#endif /* CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING */

#ifndef CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING
    #define CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING            CONSTANT_UINT(0x00000004)
#endif /* CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING */

#ifndef CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING
    #define CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING         CONSTANT_UINT(0x00000005)
#endif /* CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING */

#ifndef CLI_IO_IOCONNECTINGSTATE_BEGINCONNECTING
    #define CLI_IO_IOCONNECTINGSTATE_BEGINCONNECTING          CONSTANT_UINT(0x00000006)
#endif /* CLI_IO_IOCONNECTINGSTATE_BEGINCONNECTING */

#ifndef CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING
    #define CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING           CONSTANT_UINT(0x00000007)
#endif /* CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING */

#ifndef CLI_IO_IOCONNECTINGSTATE_SUCCESSCONNECTING
    #define CLI_IO_IOCONNECTINGSTATE_SUCCESSCONNECTING        CONSTANT_UINT(0x00000008)
#endif /* CLI_IO_IOCONNECTINGSTATE_SUCCESSCONNECTING */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace IOConnectingState {
                    const UINT abortRequest     = CONSTANT_UINT(0x00000000);
                    const UINT stateConnected   = CONSTANT_UINT(0x00000001);
                    const UINT stateFailed      = CONSTANT_UINT(0x00000002);
                    const UINT beginResolving   = CONSTANT_UINT(0x00000003);
                    const UINT failResolving    = CONSTANT_UINT(0x00000004);
                    const UINT successResolving = CONSTANT_UINT(0x00000005);
                    const UINT beginConnecting  = CONSTANT_UINT(0x00000006);
                    const UINT failConnecting   = CONSTANT_UINT(0x00000007);
                    const UINT successConnecting        = CONSTANT_UINT(0x00000008);
            }; // namespace IOConnectingState
        }; // namespace io
    }; // namespace cli
    /* using namespace ::cli::io::IOConnectingState; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::io::IOStreamType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_IO_IOSTREAMTYPE            DWORD
#else
    #define ENUM_CLI_IO_IOSTREAMTYPE            DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_IO_IOSTREAMTYPE_FSERIAL
    #define CLI_IO_IOSTREAMTYPE_FSERIAL       CONSTANT_DWORD(0x00010000)
#endif /* CLI_IO_IOSTREAMTYPE_FSERIAL */

#ifndef CLI_IO_IOSTREAMTYPE_FSEEKABLE
    #define CLI_IO_IOSTREAMTYPE_FSEEKABLE     CONSTANT_DWORD(0x00020000)
#endif /* CLI_IO_IOSTREAMTYPE_FSEEKABLE */

#ifndef CLI_IO_IOSTREAMTYPE_FSOCKET
    #define CLI_IO_IOSTREAMTYPE_FSOCKET       CONSTANT_DWORD(0x00040000)
#endif /* CLI_IO_IOSTREAMTYPE_FSOCKET */

#ifndef CLI_IO_IOSTREAMTYPE_FDATAGRAMM
    #define CLI_IO_IOSTREAMTYPE_FDATAGRAMM    CONSTANT_DWORD(0x00080000)
#endif /* CLI_IO_IOSTREAMTYPE_FDATAGRAMM */

#ifndef CLI_IO_IOSTREAMTYPE_FMEMORY
    #define CLI_IO_IOSTREAMTYPE_FMEMORY       CONSTANT_DWORD(0x00100000)
#endif /* CLI_IO_IOSTREAMTYPE_FMEMORY */

#ifndef CLI_IO_IOSTREAMTYPE_FPIPE
    #define CLI_IO_IOSTREAMTYPE_FPIPE         CONSTANT_DWORD(0x00200000)
#endif /* CLI_IO_IOSTREAMTYPE_FPIPE */

#ifndef CLI_IO_IOSTREAMTYPE_FPAIRED
    #define CLI_IO_IOSTREAMTYPE_FPAIRED       CONSTANT_DWORD(0x00400000)
#endif /* CLI_IO_IOSTREAMTYPE_FPAIRED */

#ifndef CLI_IO_IOSTREAMTYPE_UNKNOWNTYPE
    #define CLI_IO_IOSTREAMTYPE_UNKNOWNTYPE   CONSTANT_DWORD(0x00000000)
#endif /* CLI_IO_IOSTREAMTYPE_UNKNOWNTYPE */

#ifndef CLI_IO_IOSTREAMTYPE_FILE
    #define CLI_IO_IOSTREAMTYPE_FILE          CONSTANT_DWORD(0x00020001)
#endif /* CLI_IO_IOSTREAMTYPE_FILE */

#ifndef CLI_IO_IOSTREAMTYPE_MEMORY
    #define CLI_IO_IOSTREAMTYPE_MEMORY        CONSTANT_DWORD(0x00120002)
#endif /* CLI_IO_IOSTREAMTYPE_MEMORY */

#ifndef CLI_IO_IOSTREAMTYPE_SERIAL
    #define CLI_IO_IOSTREAMTYPE_SERIAL        CONSTANT_DWORD(0x00010003)
#endif /* CLI_IO_IOSTREAMTYPE_SERIAL */

#ifndef CLI_IO_IOSTREAMTYPE_TCP
    #define CLI_IO_IOSTREAMTYPE_TCP           CONSTANT_DWORD(0x00040004)
#endif /* CLI_IO_IOSTREAMTYPE_TCP */

#ifndef CLI_IO_IOSTREAMTYPE_UDP
    #define CLI_IO_IOSTREAMTYPE_UDP           CONSTANT_DWORD(0x000C0005)
#endif /* CLI_IO_IOSTREAMTYPE_UDP */

#ifndef CLI_IO_IOSTREAMTYPE_SERIAL_TCP
    #define CLI_IO_IOSTREAMTYPE_SERIAL_TCP    CONSTANT_DWORD(0x00050006)
#endif /* CLI_IO_IOSTREAMTYPE_SERIAL_TCP */

#ifndef CLI_IO_IOSTREAMTYPE_PIPE
    #define CLI_IO_IOSTREAMTYPE_PIPE          CONSTANT_DWORD(0x00200007)
#endif /* CLI_IO_IOSTREAMTYPE_PIPE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace IOStreamType {
                    const DWORD fSerial          = CONSTANT_DWORD(0x00010000);
                    const DWORD fSeekable        = CONSTANT_DWORD(0x00020000);
                    const DWORD fSocket          = CONSTANT_DWORD(0x00040000);
                    const DWORD fDatagramm       = CONSTANT_DWORD(0x00080000);
                    const DWORD fMemory          = CONSTANT_DWORD(0x00100000);
                    const DWORD fPipe            = CONSTANT_DWORD(0x00200000);
                    const DWORD fPaired          = CONSTANT_DWORD(0x00400000);
                    const DWORD unknownType      = CONSTANT_DWORD(0x00000000);
                    const DWORD file             = CONSTANT_DWORD(0x00020001);
                    const DWORD memory           = CONSTANT_DWORD(0x00120002);
                    const DWORD serial           = CONSTANT_DWORD(0x00010003);
                    const DWORD tcp              = CONSTANT_DWORD(0x00040004);
                    const DWORD udp              = CONSTANT_DWORD(0x000C0005);
                    const DWORD serial_tcp       = CONSTANT_DWORD(0x00050006);
                    const DWORD pipe             = CONSTANT_DWORD(0x00200007);
            }; // namespace IOStreamType
        }; // namespace io
    }; // namespace cli
    /* using namespace ::cli::io::IOStreamType; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::io::ESeekMoveMethod */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_IO_ESEEKMOVEMETHOD         UINT
#else
    #define ENUM_CLI_IO_ESEEKMOVEMETHOD         UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_IO_ESEEKMOVEMETHOD_BEGIN
    #define CLI_IO_ESEEKMOVEMETHOD_BEGIN      CONSTANT_UINT(0)
#endif /* CLI_IO_ESEEKMOVEMETHOD_BEGIN */

#ifndef CLI_IO_ESEEKMOVEMETHOD_CURRENT
    #define CLI_IO_ESEEKMOVEMETHOD_CURRENT    1
#endif /* CLI_IO_ESEEKMOVEMETHOD_CURRENT */

#ifndef CLI_IO_ESEEKMOVEMETHOD_END
    #define CLI_IO_ESEEKMOVEMETHOD_END        2
#endif /* CLI_IO_ESEEKMOVEMETHOD_END */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace ESeekMoveMethod {
                    const UINT begin            = CONSTANT_UINT(0);
                    const UINT current          = CONSTANT_UINT(1);
                    const UINT end              = CONSTANT_UINT(2);
            }; // namespace ESeekMoveMethod
        }; // namespace io
    }; // namespace cli
    /* using namespace ::cli::io::ESeekMoveMethod; */
    
#endif





/* ------------------------------------------------------ */
/* Interface: ::cli::io::iConnectingStateWatcher */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER_IID
    #define INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER_IID    "/cli/io/iConnectingStateWatcher"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iConnectingStateWatcher
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER
       #define INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER    ::cli::io::iConnectingStateWatcher
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iConnectingStateWatcher
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER
       #define INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER    cli_io_iConnectingStateWatcher
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iConnectingStateWatcher methods */
                CLIMETHOD(onConnectingStateEvent) (THIS_ ENUM_CLI_IO_IOCONNECTINGSTATE    conState /* [in] ::cli::io::IOConnectingState  conState  */
                                                       , const CLISTR*     infoStr
                                                  ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iConnectingStateWatcher >
           {
            static char const * getName() { return INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iConnectingStateWatcher* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iConnectingStateWatcher > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iConnectingStateWatcher wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER >
                                          */
                     >
            class CiConnectingStateWatcherWrapper
            {
                public:
            
                    typedef  CiConnectingStateWatcherWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiConnectingStateWatcherWrapper() :
                       pif(0) {}
            
                    CiConnectingStateWatcherWrapper( iConnectingStateWatcher *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiConnectingStateWatcherWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiConnectingStateWatcherWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiConnectingStateWatcherWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiConnectingStateWatcherWrapper(const CiConnectingStateWatcherWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiConnectingStateWatcherWrapper()  { }
            
                    CiConnectingStateWatcherWrapper& operator=(const CiConnectingStateWatcherWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE onConnectingStateEvent( ENUM_CLI_IO_IOCONNECTINGSTATE    conState /* [in] ::cli::io::IOConnectingState  conState  */
                                                , const ::std::wstring    &infoStr
                                                )
                       {
                    
                        CCliStr tmp_infoStr; CCliStr_lightCopyTo( tmp_infoStr, infoStr);
                        return pif->onConnectingStateEvent(conState, &tmp_infoStr);
                       }
                    

            
            
            }; // class CiConnectingStateWatcherWrapper
            
            typedef CiConnectingStateWatcherWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER     > >  CiConnectingStateWatcher;
            typedef CiConnectingStateWatcherWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER > >  CiConnectingStateWatcher_nrc; /* No ref counting for interface used */
            typedef CiConnectingStateWatcherWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER > >  CiConnectingStateWatcher_tmp; /* for temporary usage, same as CiConnectingStateWatcher_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::io::iIStream */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            interface                                iOStream;
            #ifndef INTERFACE_CLI_IO_IOSTREAM
                #define INTERFACE_CLI_IO_IOSTREAM         ::cli::io::iOStream
            #endif

        }; // namespace io
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IO_IOSTREAM_PREDECLARED
    #define INTERFACE_CLI_IO_IOSTREAM_PREDECLARED
    typedef interface tag_cli_io_iOStream    cli_io_iOStream;
    #endif //INTERFACE_CLI_IO_IOSTREAM
    #ifndef INTERFACE_CLI_IO_IOSTREAM
        #define INTERFACE_CLI_IO_IOSTREAM         struct tag_cli_io_iOStream
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_IISTREAM_IID
    #define INTERFACE_CLI_IO_IISTREAM_IID    "/cli/io/iIStream"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iIStream
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_IISTREAM
       #define INTERFACE_CLI_IO_IISTREAM    ::cli::io::iIStream
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iIStream
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_IISTREAM
       #define INTERFACE_CLI_IO_IISTREAM    cli_io_iIStream
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iIStream methods */
                CLIMETHOD_(ENUM_CLI_IO_IOSTREAMTYPE, getStreamType) (THIS) PURE;
                CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                     , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                     , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                ) PURE;
                CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                            , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                            , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                            , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                       ) PURE;
                CLIMETHOD(closeStream) (THIS) PURE;
                CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */) PURE;
                CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */) PURE;
                CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName) PURE;
                CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iIStream >
           {
            static char const * getName() { return INTERFACE_CLI_IO_IISTREAM_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iIStream* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iIStream > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iIStream wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_IISTREAM >
                                          */
                     >
            class CiIStreamWrapper
            {
                public:
            
                    typedef  CiIStreamWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiIStreamWrapper() :
                       pif(0) {}
            
                    CiIStreamWrapper( iIStream *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiIStreamWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiIStreamWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiIStreamWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiIStreamWrapper(const CiIStreamWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiIStreamWrapper()  { }
            
                    CiIStreamWrapper& operator=(const CiIStreamWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    ENUM_CLI_IO_IOSTREAMTYPE getStreamType( )
                       {
                        return pif->getStreamType();
                       }
                    
                    RCODE read( VOID*    buf /* [out,flat] void buf[]  */
                              , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                              , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                              )
                       {
                    
                    
                    
                        return pif->read(buf, numBytesToRead, numBytesReaded);
                       }
                    
                    RCODE readTimeout( VOID*    buf /* [out,flat] void buf[]  */
                                     , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                     , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                     , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                     )
                       {
                    
                    
                    
                    
                        return pif->readTimeout(buf, numBytesToRead, numBytesReaded, millisecTimeout);
                       }
                    
                    RCODE closeStream( )
                       {
                        return pif->closeStream();
                       }
                    
                    RCODE initStreamWithHandle( SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
                       {
                    
                        return pif->initStreamWithHandle(handle);
                       }
                    
                    RCODE createWriteEnd( INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
                       {
                    
                        return pif->createWriteEnd(pStream);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_streamName( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = streamNameGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_streamName( const ::std::wstring &_streamName
                                       )
                       {
                        RCODE res = streamNameSet( _streamName );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, streamName );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE streamNameGet( ::std::wstring    &_streamName)
                       {
                        CCliStr tmp__streamName; CCliStr_init( tmp__streamName );
                        RCODE res = pif->streamNameGet(&tmp__streamName);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _streamName, tmp__streamName);
                           }
                        return res;
                       }
                    
                    RCODE streamNameSet( const ::std::wstring    &_streamName)
                       {
                        CCliStr tmp__streamName; CCliStr_lightCopyTo( tmp__streamName, _streamName);
                        return pif->streamNameSet(&tmp__streamName);
                       }
                    

            
            
            }; // class CiIStreamWrapper
            
            typedef CiIStreamWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_IISTREAM     > >  CiIStream;
            typedef CiIStreamWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IISTREAM > >  CiIStream_nrc; /* No ref counting for interface used */
            typedef CiIStreamWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IISTREAM > >  CiIStream_tmp; /* for temporary usage, same as CiIStream_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::io::iOStream */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            interface                                iIStream;
            #ifndef INTERFACE_CLI_IO_IISTREAM
                #define INTERFACE_CLI_IO_IISTREAM         ::cli::io::iIStream
            #endif

        }; // namespace io
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IO_IISTREAM_PREDECLARED
    #define INTERFACE_CLI_IO_IISTREAM_PREDECLARED
    typedef interface tag_cli_io_iIStream    cli_io_iIStream;
    #endif //INTERFACE_CLI_IO_IISTREAM
    #ifndef INTERFACE_CLI_IO_IISTREAM
        #define INTERFACE_CLI_IO_IISTREAM         struct tag_cli_io_iIStream
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_IOSTREAM_IID
    #define INTERFACE_CLI_IO_IOSTREAM_IID    "/cli/io/iOStream"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iOStream
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_IOSTREAM
       #define INTERFACE_CLI_IO_IOSTREAM    ::cli::io::iOStream
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iOStream
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_IOSTREAM
       #define INTERFACE_CLI_IO_IOSTREAM    cli_io_iOStream
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iOStream methods */
                CLIMETHOD_(ENUM_CLI_IO_IOSTREAMTYPE, getStreamType) (THIS) PURE;
                CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                      , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                      , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 ) PURE;
                CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                             , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                             , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                             , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                        ) PURE;
                CLIMETHOD(closeStream) (THIS) PURE;
                CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */) PURE;
                CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */) PURE;
                CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName) PURE;
                CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iOStream >
           {
            static char const * getName() { return INTERFACE_CLI_IO_IOSTREAM_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iOStream* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iOStream > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iOStream wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_IOSTREAM >
                                          */
                     >
            class CiOStreamWrapper
            {
                public:
            
                    typedef  CiOStreamWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiOStreamWrapper() :
                       pif(0) {}
            
                    CiOStreamWrapper( iOStream *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiOStreamWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiOStreamWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiOStreamWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiOStreamWrapper(const CiOStreamWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiOStreamWrapper()  { }
            
                    CiOStreamWrapper& operator=(const CiOStreamWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    ENUM_CLI_IO_IOSTREAMTYPE getStreamType( )
                       {
                        return pif->getStreamType();
                       }
                    
                    RCODE write( const VOID*    buf /* [in,flat] void  buf[]  */
                               , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                               , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                               )
                       {
                    
                    
                    
                        return pif->write(buf, numBytesToWrite, numBytesWritten);
                       }
                    
                    RCODE writeTimeout( const VOID*    buf /* [in,flat] void  buf[]  */
                                      , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                      , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                      , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                      )
                       {
                    
                    
                    
                    
                        return pif->writeTimeout(buf, numBytesToWrite, numBytesWritten, millisecTimeout);
                       }
                    
                    RCODE closeStream( )
                       {
                        return pif->closeStream();
                       }
                    
                    RCODE initStreamWithHandle( SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
                       {
                    
                        return pif->initStreamWithHandle(handle);
                       }
                    
                    RCODE createReadEnd( INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
                       {
                    
                        return pif->createReadEnd(pStream);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_streamName( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = streamNameGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_streamName( const ::std::wstring &_streamName
                                       )
                       {
                        RCODE res = streamNameSet( _streamName );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, streamName );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE streamNameGet( ::std::wstring    &_streamName)
                       {
                        CCliStr tmp__streamName; CCliStr_init( tmp__streamName );
                        RCODE res = pif->streamNameGet(&tmp__streamName);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _streamName, tmp__streamName);
                           }
                        return res;
                       }
                    
                    RCODE streamNameSet( const ::std::wstring    &_streamName)
                       {
                        CCliStr tmp__streamName; CCliStr_lightCopyTo( tmp__streamName, _streamName);
                        return pif->streamNameSet(&tmp__streamName);
                       }
                    

            
            
            }; // class CiOStreamWrapper
            
            typedef CiOStreamWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_IOSTREAM     > >  CiOStream;
            typedef CiOStreamWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IOSTREAM > >  CiOStream_nrc; /* No ref counting for interface used */
            typedef CiOStreamWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IOSTREAM > >  CiOStream_tmp; /* for temporary usage, same as CiOStream_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::io::iIOStream */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            interface                                iConnectingStateWatcher;
            #ifndef INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER
                #define INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER          ::cli::io::iConnectingStateWatcher
            #endif

        }; // namespace io
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER_PREDECLARED
    #define INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER_PREDECLARED
    typedef interface tag_cli_io_iConnectingStateWatcher         cli_io_iConnectingStateWatcher;
    #endif //INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER
    #ifndef INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER
        #define INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER          struct tag_cli_io_iConnectingStateWatcher
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_IIOSTREAM_IID
    #define INTERFACE_CLI_IO_IIOSTREAM_IID    "/cli/io/iIOStream"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iIOStream
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_IIOSTREAM
       #define INTERFACE_CLI_IO_IIOSTREAM    ::cli::io::iIOStream
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iIOStream
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_IIOSTREAM
       #define INTERFACE_CLI_IO_IIOSTREAM    cli_io_iIOStream
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iIOStream methods */
                CLIMETHOD_(ENUM_CLI_IO_IOSTREAMTYPE, getStreamType) (THIS) PURE;
                CLIMETHOD(open) (THIS_ const CLISTR*     streamName
                                     , const CLISTR*     host
                                     , const CLISTR*     port
                                     , const CLISTR*     path
                                     , const CLISTR*     options
                                     , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                ) PURE;
                CLIMETHOD(openPStr) (THIS_ CLIPSTR           streamName
                                         , CLIPSTR           host
                                         , CLIPSTR           port
                                         , CLIPSTR           path
                                         , CLIPSTR           options
                                         , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                    ) PURE;
                CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                     , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                     , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                ) PURE;
                CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                            , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                            , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                            , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                       ) PURE;
                CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                      , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                      , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 ) PURE;
                CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                             , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                             , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                             , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                        ) PURE;
                CLIMETHOD(closeStream) (THIS) PURE;
                CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */) PURE;
                CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */) PURE;
                CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */) PURE;
                CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName) PURE;
                CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iIOStream >
           {
            static char const * getName() { return INTERFACE_CLI_IO_IIOSTREAM_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iIOStream* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iIOStream > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iIOStream wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_IIOSTREAM >
                                          */
                     >
            class CiIOStreamWrapper
            {
                public:
            
                    typedef  CiIOStreamWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiIOStreamWrapper() :
                       pif(0) {}
            
                    CiIOStreamWrapper( iIOStream *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiIOStreamWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiIOStreamWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiIOStreamWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiIOStreamWrapper(const CiIOStreamWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiIOStreamWrapper()  { }
            
                    CiIOStreamWrapper& operator=(const CiIOStreamWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    ENUM_CLI_IO_IOSTREAMTYPE getStreamType( )
                       {
                        return pif->getStreamType();
                       }
                    
                    RCODE open( const ::std::wstring    &streamName
                              , const ::std::wstring    &host
                              , const ::std::wstring    &port
                              , const ::std::wstring    &path
                              , const ::std::wstring    &options
                              , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                              )
                       {
                        CCliStr tmp_streamName; CCliStr_lightCopyTo( tmp_streamName, streamName);
                        CCliStr tmp_host; CCliStr_lightCopyTo( tmp_host, host);
                        CCliStr tmp_port; CCliStr_lightCopyTo( tmp_port, port);
                        CCliStr tmp_path; CCliStr_lightCopyTo( tmp_path, path);
                        CCliStr tmp_options; CCliStr_lightCopyTo( tmp_options, options);
                    
                        return pif->open(&tmp_streamName, &tmp_host, &tmp_port, &tmp_path, &tmp_options, pConWatcher);
                       }
                    
                    RCODE openPStr( ::std::wstring    streamName
                                  , ::std::wstring    host
                                  , ::std::wstring    port
                                  , ::std::wstring    path
                                  , ::std::wstring    options
                                  , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                  )
                       {
                        CCliPStr tmp_streamName; CCliPStr_lightCopyTo( tmp_streamName, streamName);
                        CCliPStr tmp_host; CCliPStr_lightCopyTo( tmp_host, host);
                        CCliPStr tmp_port; CCliPStr_lightCopyTo( tmp_port, port);
                        CCliPStr tmp_path; CCliPStr_lightCopyTo( tmp_path, path);
                        CCliPStr tmp_options; CCliPStr_lightCopyTo( tmp_options, options);
                    
                        return pif->openPStr(tmp_streamName, tmp_host, tmp_port, tmp_path, tmp_options, pConWatcher);
                       }
                    
                    RCODE read( VOID*    buf /* [out,flat] void buf[]  */
                              , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                              , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                              )
                       {
                    
                    
                    
                        return pif->read(buf, numBytesToRead, numBytesReaded);
                       }
                    
                    RCODE readTimeout( VOID*    buf /* [out,flat] void buf[]  */
                                     , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                     , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                     , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                     )
                       {
                    
                    
                    
                    
                        return pif->readTimeout(buf, numBytesToRead, numBytesReaded, millisecTimeout);
                       }
                    
                    RCODE write( const VOID*    buf /* [in,flat] void  buf[]  */
                               , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                               , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                               )
                       {
                    
                    
                    
                        return pif->write(buf, numBytesToWrite, numBytesWritten);
                       }
                    
                    RCODE writeTimeout( const VOID*    buf /* [in,flat] void  buf[]  */
                                      , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                      , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                      , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                      )
                       {
                    
                    
                    
                    
                        return pif->writeTimeout(buf, numBytesToWrite, numBytesWritten, millisecTimeout);
                       }
                    
                    RCODE closeStream( )
                       {
                        return pif->closeStream();
                       }
                    
                    RCODE initStreamWithHandle( SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
                       {
                    
                        return pif->initStreamWithHandle(handle);
                       }
                    
                    RCODE createReadEnd( INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
                       {
                    
                        return pif->createReadEnd(pStream);
                       }
                    
                    RCODE createWriteEnd( INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
                       {
                    
                        return pif->createWriteEnd(pStream);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_streamName( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = streamNameGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_streamName( const ::std::wstring &_streamName
                                       )
                       {
                        RCODE res = streamNameSet( _streamName );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, streamName );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE streamNameGet( ::std::wstring    &_streamName)
                       {
                        CCliStr tmp__streamName; CCliStr_init( tmp__streamName );
                        RCODE res = pif->streamNameGet(&tmp__streamName);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _streamName, tmp__streamName);
                           }
                        return res;
                       }
                    
                    RCODE streamNameSet( const ::std::wstring    &_streamName)
                       {
                        CCliStr tmp__streamName; CCliStr_lightCopyTo( tmp__streamName, _streamName);
                        return pif->streamNameSet(&tmp__streamName);
                       }
                    

            
            
            }; // class CiIOStreamWrapper
            
            typedef CiIOStreamWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_IIOSTREAM     > >  CiIOStream;
            typedef CiIOStreamWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IIOSTREAM > >  CiIOStream_nrc; /* No ref counting for interface used */
            typedef CiIOStreamWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IIOSTREAM > >  CiIOStream_tmp; /* for temporary usage, same as CiIOStream_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::io::iIOFactory */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            interface                                iIOStream;
            #ifndef INTERFACE_CLI_IO_IIOSTREAM
                #define INTERFACE_CLI_IO_IIOSTREAM        ::cli::io::iIOStream
            #endif

            interface                                iPipe;
            #ifndef INTERFACE_CLI_IO_IPIPE
                #define INTERFACE_CLI_IO_IPIPE            ::cli::io::iPipe
            #endif

        }; // namespace io
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IO_IIOSTREAM_PREDECLARED
    #define INTERFACE_CLI_IO_IIOSTREAM_PREDECLARED
    typedef interface tag_cli_io_iIOStream   cli_io_iIOStream;
    #endif //INTERFACE_CLI_IO_IIOSTREAM
    #ifndef INTERFACE_CLI_IO_IIOSTREAM
        #define INTERFACE_CLI_IO_IIOSTREAM        struct tag_cli_io_iIOStream
    #endif

    #ifndef INTERFACE_CLI_IO_IPIPE_PREDECLARED
    #define INTERFACE_CLI_IO_IPIPE_PREDECLARED
    typedef interface tag_cli_io_iPipe       cli_io_iPipe;
    #endif //INTERFACE_CLI_IO_IPIPE
    #ifndef INTERFACE_CLI_IO_IPIPE
        #define INTERFACE_CLI_IO_IPIPE            struct tag_cli_io_iPipe
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_IIOFACTORY_IID
    #define INTERFACE_CLI_IO_IIOFACTORY_IID    "/cli/io/iIOFactory"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iIOFactory
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_IIOFACTORY
       #define INTERFACE_CLI_IO_IIOFACTORY    ::cli::io::iIOFactory
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iIOFactory
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_IIOFACTORY
       #define INTERFACE_CLI_IO_IIOFACTORY    cli_io_iIOFactory
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iIOFactory methods */
                CLIMETHOD(splitName) (THIS_ const CLISTR*     streamName
                                          , CLISTR*           type
                                          , CLISTR*           host
                                          , CLISTR*           port
                                          , CLISTR*           path
                                          , CLISTR*           options
                                     ) PURE;
                CLIMETHOD(splitNamePStr) (THIS_ CLIPSTR           streamName
                                              , CLIPSTR*          type
                                              , CLIPSTR*          host
                                              , CLIPSTR*          port
                                              , CLIPSTR*          path
                                              , CLIPSTR*          options
                                         ) PURE;
                CLIMETHOD(mergeName) (THIS_ CLISTR*           streamName
                                          , const CLISTR*     type
                                          , const CLISTR*     host
                                          , const CLISTR*     port
                                          , const CLISTR*     path
                                          , const CLISTR*     options
                                     ) PURE;
                CLIMETHOD(mergeNamePStr) (THIS_ CLIPSTR*          streamName
                                              , CLIPSTR           type
                                              , CLIPSTR           host
                                              , CLIPSTR           port
                                              , CLIPSTR           path
                                              , CLIPSTR           options
                                         ) PURE;
                CLIMETHOD(makeFullQualifiedName) (THIS_ CLISTR*           streamName) PURE;
                CLIMETHOD(makeFullQualifiedNamePStr) (THIS_ CLIPSTR*          streamName) PURE;
                CLIMETHOD(createStream) (THIS_ const CLISTR*     streamName
                                             , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                             , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                        ) PURE;
                CLIMETHOD(createStreamPstr) (THIS_ CLIPSTR           streamName
                                                 , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                                 , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                            ) PURE;
                CLIMETHOD(createStreamChars) (THIS_ const WCHAR*    streamName /* [in,flat] wchar  streamName[]  */
                                                  , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                                  , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                                  , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                             ) PURE;
                CLIMETHOD(createPipeStreams) (THIS_ INTERFACE_CLI_IO_IIOSTREAM**    ioReadEnd /* [out] ::cli::io::iIOStream* ioReadEnd  */
                                                  , INTERFACE_CLI_IO_IIOSTREAM**    ioWriteEnd /* [out] ::cli::io::iIOStream* ioWriteEnd  */
                                             ) PURE;
                CLIMETHOD(createBidiPipeStreams) (THIS_ INTERFACE_CLI_IO_IIOSTREAM**    ioEnd1 /* [out] ::cli::io::iIOStream* ioEnd1  */
                                                      , INTERFACE_CLI_IO_IIOSTREAM**    ioEnd2 /* [out] ::cli::io::iIOStream* ioEnd2  */
                                                 ) PURE;
                CLIMETHOD(createPipe) (THIS_ INTERFACE_CLI_IO_IPIPE**    ipipe /* [out] ::cli::io::iPipe* ipipe  */) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iIOFactory >
           {
            static char const * getName() { return INTERFACE_CLI_IO_IIOFACTORY_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iIOFactory* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iIOFactory > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iIOFactory wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_IIOFACTORY >
                                          */
                     >
            class CiIOFactoryWrapper
            {
                public:
            
                    typedef  CiIOFactoryWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiIOFactoryWrapper() :
                       pif(0) {}
            
                    CiIOFactoryWrapper( iIOFactory *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiIOFactoryWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiIOFactoryWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiIOFactoryWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiIOFactoryWrapper(const CiIOFactoryWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiIOFactoryWrapper()  { }
            
                    CiIOFactoryWrapper& operator=(const CiIOFactoryWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE splitName( const ::std::wstring    &streamName
                                   , ::std::wstring    &type
                                   , ::std::wstring    &host
                                   , ::std::wstring    &port
                                   , ::std::wstring    &path
                                   , ::std::wstring    &options
                                   )
                       {
                        CCliStr tmp_streamName; CCliStr_lightCopyTo( tmp_streamName, streamName);
                        CCliStr tmp_type; CCliStr_init( tmp_type );
                        CCliStr tmp_host; CCliStr_init( tmp_host );
                        CCliStr tmp_port; CCliStr_init( tmp_port );
                        CCliStr tmp_path; CCliStr_init( tmp_path );
                        CCliStr tmp_options; CCliStr_init( tmp_options );
                        RCODE res = pif->splitName(&tmp_streamName, &tmp_type, &tmp_host, &tmp_port, &tmp_path, &tmp_options);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( type, tmp_type);
                            CCliStr_copyFromIfModified( host, tmp_host);
                            CCliStr_copyFromIfModified( port, tmp_port);
                            CCliStr_copyFromIfModified( path, tmp_path);
                            CCliStr_copyFromIfModified( options, tmp_options);
                           }
                        return res;
                       }
                    
                    RCODE splitNamePStr( ::std::wstring    streamName
                                       , ::std::wstring    &type
                                       , ::std::wstring    &host
                                       , ::std::wstring    &port
                                       , ::std::wstring    &path
                                       , ::std::wstring    &options
                                       )
                       {
                        CCliPStr tmp_streamName; CCliPStr_lightCopyTo( tmp_streamName, streamName);
                        CCliPStr tmp_type; CCliPStr_init( tmp_type );
                        CCliPStr tmp_host; CCliPStr_init( tmp_host );
                        CCliPStr tmp_port; CCliPStr_init( tmp_port );
                        CCliPStr tmp_path; CCliPStr_init( tmp_path );
                        CCliPStr tmp_options; CCliPStr_init( tmp_options );
                        RCODE res = pif->splitNamePStr(tmp_streamName, &tmp_type, &tmp_host, &tmp_port, &tmp_path, &tmp_options);
                        if (RCOK(res))
                           {
                            CCliPStr_copyFromIfModified( type, tmp_type);
                            CCliPStr_copyFromIfModified( host, tmp_host);
                            CCliPStr_copyFromIfModified( port, tmp_port);
                            CCliPStr_copyFromIfModified( path, tmp_path);
                            CCliPStr_copyFromIfModified( options, tmp_options);
                           }
                        return res;
                       }
                    
                    RCODE mergeName( ::std::wstring    &streamName
                                   , const ::std::wstring    &type
                                   , const ::std::wstring    &host
                                   , const ::std::wstring    &port
                                   , const ::std::wstring    &path
                                   , const ::std::wstring    &options
                                   )
                       {
                        CCliStr tmp_streamName; CCliStr_init( tmp_streamName );
                        CCliStr tmp_type; CCliStr_lightCopyTo( tmp_type, type);
                        CCliStr tmp_host; CCliStr_lightCopyTo( tmp_host, host);
                        CCliStr tmp_port; CCliStr_lightCopyTo( tmp_port, port);
                        CCliStr tmp_path; CCliStr_lightCopyTo( tmp_path, path);
                        CCliStr tmp_options; CCliStr_lightCopyTo( tmp_options, options);
                        RCODE res = pif->mergeName(&tmp_streamName, &tmp_type, &tmp_host, &tmp_port, &tmp_path, &tmp_options);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( streamName, tmp_streamName);
                           }
                        return res;
                       }
                    
                    RCODE mergeNamePStr( ::std::wstring    &streamName
                                       , ::std::wstring    type
                                       , ::std::wstring    host
                                       , ::std::wstring    port
                                       , ::std::wstring    path
                                       , ::std::wstring    options
                                       )
                       {
                        CCliPStr tmp_streamName; CCliPStr_init( tmp_streamName );
                        CCliPStr tmp_type; CCliPStr_lightCopyTo( tmp_type, type);
                        CCliPStr tmp_host; CCliPStr_lightCopyTo( tmp_host, host);
                        CCliPStr tmp_port; CCliPStr_lightCopyTo( tmp_port, port);
                        CCliPStr tmp_path; CCliPStr_lightCopyTo( tmp_path, path);
                        CCliPStr tmp_options; CCliPStr_lightCopyTo( tmp_options, options);
                        RCODE res = pif->mergeNamePStr(&tmp_streamName, tmp_type, tmp_host, tmp_port, tmp_path, tmp_options);
                        if (RCOK(res))
                           {
                            CCliPStr_copyFromIfModified( streamName, tmp_streamName);
                           }
                        return res;
                       }
                    
                    RCODE makeFullQualifiedName( ::std::wstring    &streamName)
                       {
                        CCliStr tmp_streamName; CCliStr_lightCopyTo( tmp_streamName, streamName);
                        RCODE res = pif->makeFullQualifiedName(&tmp_streamName);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( streamName, tmp_streamName);
                           }
                        return res;
                       }
                    
                    RCODE makeFullQualifiedNamePStr( ::std::wstring    &streamName)
                       {
                        CCliPStr tmp_streamName; CCliPStr_lightCopyTo( tmp_streamName, streamName);
                        RCODE res = pif->makeFullQualifiedNamePStr(&tmp_streamName);
                        if (RCOK(res))
                           {
                            CCliPStr_copyFromIfModified( streamName, tmp_streamName);
                           }
                        return res;
                       }
                    
                    RCODE createStream( const ::std::wstring    &streamName
                                      , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                      , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                      )
                       {
                        CCliStr tmp_streamName; CCliStr_lightCopyTo( tmp_streamName, streamName);
                    
                    
                        return pif->createStream(&tmp_streamName, ios, pConWatcher);
                       }
                    
                    RCODE createStreamPstr( ::std::wstring    streamName
                                          , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                          , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                          )
                       {
                        CCliPStr tmp_streamName; CCliPStr_lightCopyTo( tmp_streamName, streamName);
                    
                    
                        return pif->createStreamPstr(tmp_streamName, ios, pConWatcher);
                       }
                    
                    RCODE createStreamChars( const WCHAR*    streamName /* [in,flat] wchar  streamName[]  */
                                           , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                           , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                           , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                           )
                       {
                    
                    
                    
                    
                        return pif->createStreamChars(streamName, nameSize, ios, pConWatcher);
                       }
                    
                    RCODE createPipeStreams( INTERFACE_CLI_IO_IIOSTREAM**    ioReadEnd /* [out] ::cli::io::iIOStream* ioReadEnd  */
                                           , INTERFACE_CLI_IO_IIOSTREAM**    ioWriteEnd /* [out] ::cli::io::iIOStream* ioWriteEnd  */
                                           )
                       {
                    
                    
                        return pif->createPipeStreams(ioReadEnd, ioWriteEnd);
                       }
                    
                    RCODE createBidiPipeStreams( INTERFACE_CLI_IO_IIOSTREAM**    ioEnd1 /* [out] ::cli::io::iIOStream* ioEnd1  */
                                               , INTERFACE_CLI_IO_IIOSTREAM**    ioEnd2 /* [out] ::cli::io::iIOStream* ioEnd2  */
                                               )
                       {
                    
                    
                        return pif->createBidiPipeStreams(ioEnd1, ioEnd2);
                       }
                    
                    RCODE createPipe( INTERFACE_CLI_IO_IPIPE**    ipipe /* [out] ::cli::io::iPipe* ipipe  */)
                       {
                    
                        return pif->createPipe(ipipe);
                       }
                    

            
            
            }; // class CiIOFactoryWrapper
            
            typedef CiIOFactoryWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_IIOFACTORY     > >  CiIOFactory;
            typedef CiIOFactoryWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IIOFACTORY > >  CiIOFactory_nrc; /* No ref counting for interface used */
            typedef CiIOFactoryWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IIOFACTORY > >  CiIOFactory_tmp; /* for temporary usage, same as CiIOFactory_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::io::iSeekable */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_ISEEKABLE_IID
    #define INTERFACE_CLI_IO_ISEEKABLE_IID    "/cli/io/iSeekable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iSeekable
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_ISEEKABLE
       #define INTERFACE_CLI_IO_ISEEKABLE    ::cli::io::iSeekable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iSeekable
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_ISEEKABLE
       #define INTERFACE_CLI_IO_ISEEKABLE    cli_io_iSeekable
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iSeekable methods */
                CLIMETHOD(getPos) (THIS_ FILE_SIZE_T*    curPos /* [out] file_size_t curPos  */) PURE;
                CLIMETHOD(setPos) (THIS_ ENUM_CLI_IO_ESEEKMOVEMETHOD    method /* [in] ::cli::io::ESeekMoveMethod  method  */
                                       , FILE_DIFF_T    distanceToMove /* [in] file_diff_t  distanceToMove  */
                                       , FILE_SIZE_T*    newPos /* [out,optional] file_size_t newPos  */
                                  ) PURE;
                CLIMETHOD(getSize) (THIS_ FILE_SIZE_T*    size /* [out] file_size_t size  */) PURE;
                CLIMETHOD(setSize) (THIS_ FILE_SIZE_T    newSize /* [in] file_size_t  newSize  */) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iSeekable >
           {
            static char const * getName() { return INTERFACE_CLI_IO_ISEEKABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iSeekable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iSeekable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iSeekable wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_ISEEKABLE >
                                          */
                     >
            class CiSeekableWrapper
            {
                public:
            
                    typedef  CiSeekableWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiSeekableWrapper() :
                       pif(0) {}
            
                    CiSeekableWrapper( iSeekable *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiSeekableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiSeekableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiSeekableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiSeekableWrapper(const CiSeekableWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiSeekableWrapper()  { }
            
                    CiSeekableWrapper& operator=(const CiSeekableWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE getPos( FILE_SIZE_T*    curPos /* [out] file_size_t curPos  */)
                       {
                    
                        return pif->getPos(curPos);
                       }
                    
                    RCODE setPos( ENUM_CLI_IO_ESEEKMOVEMETHOD    method /* [in] ::cli::io::ESeekMoveMethod  method  */
                                , FILE_DIFF_T    distanceToMove /* [in] file_diff_t  distanceToMove  */
                                , FILE_SIZE_T*    newPos /* [out,optional] file_size_t newPos  */
                                )
                       {
                    
                    
                    
                        return pif->setPos(method, distanceToMove, newPos);
                       }
                    
                    RCODE getSize( FILE_SIZE_T*    size /* [out] file_size_t size  */)
                       {
                    
                        return pif->getSize(size);
                       }
                    
                    RCODE setSize( FILE_SIZE_T    newSize /* [in] file_size_t  newSize  */)
                       {
                    
                        return pif->setSize(newSize);
                       }
                    

            
            
            }; // class CiSeekableWrapper
            
            typedef CiSeekableWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_ISEEKABLE     > >  CiSeekable;
            typedef CiSeekableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_ISEEKABLE > >  CiSeekable_nrc; /* No ref counting for interface used */
            typedef CiSeekableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_ISEEKABLE > >  CiSeekable_tmp; /* for temporary usage, same as CiSeekable_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::io::iIOStreamHolder */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_IIOSTREAMHOLDER_IID
    #define INTERFACE_CLI_IO_IIOSTREAMHOLDER_IID    "/cli/io/iIOStreamHolder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iIOStreamHolder
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_IIOSTREAMHOLDER
       #define INTERFACE_CLI_IO_IIOSTREAMHOLDER    ::cli::io::iIOStreamHolder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iIOStreamHolder
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_IIOSTREAMHOLDER
       #define INTERFACE_CLI_IO_IIOSTREAMHOLDER    cli_io_iIOStreamHolder
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iIOStreamHolder methods */
                CLIMETHOD(streamPtrGet) (THIS_ INTERFACE_CLI_IO_IIOSTREAM**    _streamPtr /* [out] ::cli::io::iIOStream* _streamPtr  */) PURE;
                CLIMETHOD(streamPtrSet) (THIS_ INTERFACE_CLI_IO_IIOSTREAM*    _streamPtr /* [in] ::cli::io::iIOStream*  _streamPtr  */) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iIOStreamHolder >
           {
            static char const * getName() { return INTERFACE_CLI_IO_IIOSTREAMHOLDER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iIOStreamHolder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iIOStreamHolder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iIOStreamHolder wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_IIOSTREAMHOLDER >
                                          */
                     >
            class CiIOStreamHolderWrapper
            {
                public:
            
                    typedef  CiIOStreamHolderWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiIOStreamHolderWrapper() :
                       pif(0) {}
            
                    CiIOStreamHolderWrapper( iIOStreamHolder *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiIOStreamHolderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiIOStreamHolderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiIOStreamHolderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiIOStreamHolderWrapper(const CiIOStreamHolderWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiIOStreamHolderWrapper()  { }
            
                    CiIOStreamHolderWrapper& operator=(const CiIOStreamHolderWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    INTERFACE_CLI_IO_IIOSTREAM* get_streamPtr( )
                       {
                        INTERFACE_CLI_IO_IIOSTREAM* tmpVal;
                        RCODE res = streamPtrGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_streamPtr( INTERFACE_CLI_IO_IIOSTREAM* _streamPtr
                                      )
                       {
                        RCODE res = streamPtrSet( _streamPtr );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_IO_IIOSTREAM*, streamPtr );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE streamPtrGet( INTERFACE_CLI_IO_IIOSTREAM**    _streamPtr /* [out] ::cli::io::iIOStream* _streamPtr  */)
                       {
                    
                        return pif->streamPtrGet(_streamPtr);
                       }
                    
                    RCODE streamPtrSet( INTERFACE_CLI_IO_IIOSTREAM*    _streamPtr /* [in] ::cli::io::iIOStream*  _streamPtr  */)
                       {
                    
                        return pif->streamPtrSet(_streamPtr);
                       }
                    

            
            
            }; // class CiIOStreamHolderWrapper
            
            typedef CiIOStreamHolderWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_IIOSTREAMHOLDER     > >  CiIOStreamHolder;
            typedef CiIOStreamHolderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IIOSTREAMHOLDER > >  CiIOStreamHolder_nrc; /* No ref counting for interface used */
            typedef CiIOStreamHolderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IIOSTREAMHOLDER > >  CiIOStreamHolder_tmp; /* for temporary usage, same as CiIOStreamHolder_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif





#endif /* CLI_IO_I_IO_H */
