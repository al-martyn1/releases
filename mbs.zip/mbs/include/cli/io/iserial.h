#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_ISERIAL_H
#define CLI_IO_ISERIAL_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/io/iserial.h>", CLI_IO_ISERIAL_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IO_ISERIAL_H
    #include <cli/io/iserial.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::io::serial::Parity */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_IO_SERIAL_PARITY           UINT
#else
    #define ENUM_CLI_IO_SERIAL_PARITY           UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_IO_SERIAL_PARITY_USEDEFAULT
    #define CLI_IO_SERIAL_PARITY_USEDEFAULT   CONSTANT_UINT(0)
#endif /* CLI_IO_SERIAL_PARITY_USEDEFAULT */

#ifndef CLI_IO_SERIAL_PARITY_NONE
    #define CLI_IO_SERIAL_PARITY_NONE         CONSTANT_UINT(0)
#endif /* CLI_IO_SERIAL_PARITY_NONE */

#ifndef CLI_IO_SERIAL_PARITY_FPARITY
    #define CLI_IO_SERIAL_PARITY_FPARITY      4
#endif /* CLI_IO_SERIAL_PARITY_FPARITY */

#ifndef CLI_IO_SERIAL_PARITY_EVEN
    #define CLI_IO_SERIAL_PARITY_EVEN         4
#endif /* CLI_IO_SERIAL_PARITY_EVEN */

#ifndef CLI_IO_SERIAL_PARITY_MARK
    #define CLI_IO_SERIAL_PARITY_MARK         5
#endif /* CLI_IO_SERIAL_PARITY_MARK */

#ifndef CLI_IO_SERIAL_PARITY_ODD
    #define CLI_IO_SERIAL_PARITY_ODD          6
#endif /* CLI_IO_SERIAL_PARITY_ODD */

#ifndef CLI_IO_SERIAL_PARITY_SPACE
    #define CLI_IO_SERIAL_PARITY_SPACE        7
#endif /* CLI_IO_SERIAL_PARITY_SPACE */

#ifndef CLI_IO_SERIAL_PARITY_DONTTOUCH
    #define CLI_IO_SERIAL_PARITY_DONTTOUCH    8
#endif /* CLI_IO_SERIAL_PARITY_DONTTOUCH */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace serial {
                namespace Parity {
                        const UINT useDefault       = CONSTANT_UINT(0);
                        const UINT none             = CONSTANT_UINT(0);
                        const UINT fParity          = CONSTANT_UINT(4);
                        const UINT even             = CONSTANT_UINT(4);
                        const UINT mark             = CONSTANT_UINT(5);
                        const UINT odd              = CONSTANT_UINT(6);
                        const UINT space            = CONSTANT_UINT(7);
                        const UINT dontTouch        = CONSTANT_UINT(8);
                }; // namespace Parity
            }; // namespace serial
        }; // namespace io
    }; // namespace cli
    /* using namespace ::cli::io::serial::Parity; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::io::serial::DataBits */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_IO_SERIAL_DATABITS         UINT
#else
    #define ENUM_CLI_IO_SERIAL_DATABITS         UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_IO_SERIAL_DATABITS_DONTTOUCH
    #define CLI_IO_SERIAL_DATABITS_DONTTOUCH  CONSTANT_UINT(0)
#endif /* CLI_IO_SERIAL_DATABITS_DONTTOUCH */

#ifndef CLI_IO_SERIAL_DATABITS_USEDEFAULT
    #define CLI_IO_SERIAL_DATABITS_USEDEFAULT                 8
#endif /* CLI_IO_SERIAL_DATABITS_USEDEFAULT */

#ifndef CLI_IO_SERIAL_DATABITS_DATABITS5
    #define CLI_IO_SERIAL_DATABITS_DATABITS5  5
#endif /* CLI_IO_SERIAL_DATABITS_DATABITS5 */

#ifndef CLI_IO_SERIAL_DATABITS_DATABITS6
    #define CLI_IO_SERIAL_DATABITS_DATABITS6  6
#endif /* CLI_IO_SERIAL_DATABITS_DATABITS6 */

#ifndef CLI_IO_SERIAL_DATABITS_DATABITS7
    #define CLI_IO_SERIAL_DATABITS_DATABITS7  7
#endif /* CLI_IO_SERIAL_DATABITS_DATABITS7 */

#ifndef CLI_IO_SERIAL_DATABITS_DATABITS8
    #define CLI_IO_SERIAL_DATABITS_DATABITS8  8
#endif /* CLI_IO_SERIAL_DATABITS_DATABITS8 */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace serial {
                namespace DataBits {
                        const UINT dontTouch        = CONSTANT_UINT(0);
                        const UINT useDefault       = CONSTANT_UINT(8);
                        const UINT dataBits5        = CONSTANT_UINT(5);
                        const UINT dataBits6        = CONSTANT_UINT(6);
                        const UINT dataBits7        = CONSTANT_UINT(7);
                        const UINT dataBits8        = CONSTANT_UINT(8);
                }; // namespace DataBits
            }; // namespace serial
        }; // namespace io
    }; // namespace cli
    /* using namespace ::cli::io::serial::DataBits; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::io::serial::StopBits */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_IO_SERIAL_STOPBITS         UINT
#else
    #define ENUM_CLI_IO_SERIAL_STOPBITS         UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_IO_SERIAL_STOPBITS_DONTTOUCH
    #define CLI_IO_SERIAL_STOPBITS_DONTTOUCH  CONSTANT_UINT(0)
#endif /* CLI_IO_SERIAL_STOPBITS_DONTTOUCH */

#ifndef CLI_IO_SERIAL_STOPBITS_USEDEFAULT
    #define CLI_IO_SERIAL_STOPBITS_USEDEFAULT                 1
#endif /* CLI_IO_SERIAL_STOPBITS_USEDEFAULT */

#ifndef CLI_IO_SERIAL_STOPBITS_STOPBITS1
    #define CLI_IO_SERIAL_STOPBITS_STOPBITS1  1
#endif /* CLI_IO_SERIAL_STOPBITS_STOPBITS1 */

#ifndef CLI_IO_SERIAL_STOPBITS_STOPBITS2
    #define CLI_IO_SERIAL_STOPBITS_STOPBITS2  2
#endif /* CLI_IO_SERIAL_STOPBITS_STOPBITS2 */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace serial {
                namespace StopBits {
                        const UINT dontTouch        = CONSTANT_UINT(0);
                        const UINT useDefault       = CONSTANT_UINT(1);
                        const UINT stopBits1        = CONSTANT_UINT(1);
                        const UINT stopBits2        = CONSTANT_UINT(2);
                }; // namespace StopBits
            }; // namespace serial
        }; // namespace io
    }; // namespace cli
    /* using namespace ::cli::io::serial::StopBits; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::io::serial::COptions */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace serial {
    #define CLI_STRUCT_NAME                   COptions
    #ifndef STRUCT_CLI_IO_SERIAL_COPTIONS_PREDECLARED
    #define STRUCT_CLI_IO_SERIAL_COPTIONS_PREDECLARED
        struct COptions;
        #ifndef STRUCT_CLI_IO_SERIAL_COPTIONS
            #define STRUCT_CLI_IO_SERIAL_COPTIONS     ::cli::io::serial::COptions
        #endif
    #endif // STRUCT_CLI_IO_SERIAL_COPTIONS_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_io_serial_COptions
    #ifndef STRUCT_CLI_IO_SERIAL_COPTIONS_PREDECLARED
    #define STRUCT_CLI_IO_SERIAL_COPTIONS_PREDECLARED
        struct  tag_cli_io_serial_COptions;
        typedef struct tag_cli_io_serial_COptions cli_io_serial_COptions;
        #ifndef STRUCT_CLI_IO_SERIAL_COPTIONS
            #define STRUCT_CLI_IO_SERIAL_COPTIONS     struct tag_cli_io_serial_COptions
        #endif
    #endif // STRUCT_CLI_IO_SERIAL_COPTIONS_PREDECLARED

#endif /* end of C-like declarations */

                #ifndef STRUCT_CLI_IO_SERIAL_COPTIONS_DEFINED
                #define STRUCT_CLI_IO_SERIAL_COPTIONS_DEFINED
                #include <cli/pshpack4.h>
                CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                    DWORD                       baudRate;
                    ENUM_CLI_IO_SERIAL_PARITY               parity:4;
                    ENUM_CLI_IO_SERIAL_DATABITS             dataBits:8;
                    ENUM_CLI_IO_SERIAL_STOPBITS             stopBits:4;
                    UINT                        reserved:16;
                CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
                #include <cli/poppack.h>
                #endif // STRUCT_CLI_IO_SERIAL_COPTIONS_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; // namespace serial
        }; // namespace io
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::io::iSerialHelper */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_ISERIALHELPER_IID
    #define INTERFACE_CLI_IO_ISERIALHELPER_IID    "/cli/io/iSerialHelper"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iSerialHelper
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_ISERIALHELPER
       #define INTERFACE_CLI_IO_ISERIALHELPER    ::cli::io::iSerialHelper
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iSerialHelper
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_ISERIALHELPER
       #define INTERFACE_CLI_IO_ISERIALHELPER    cli_io_iSerialHelper
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iSerialHelper methods */
                CLIMETHOD(buildOptionsString) (THIS_ const STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [in,ref] ::cli::io::serial::COptions  options  */
                                                   , CLISTR*           optString
                                              ) PURE;
                CLIMETHOD(parseOptionsString) (THIS_ const CLISTR*     optString
                                                   , STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [out] ::cli::io::serial::COptions options  */
                                              ) PURE;
                CLIMETHOD(makeSystemDeviceName) (THIS_ const CLISTR*     usnDevicePath
                                                     , CLISTR*           sysDeviceName
                                                ) PURE;
                CLIMETHOD(makeDisplayDeviceName) (THIS_ const CLISTR*     usnDevicePath
                                                      , CLISTR*           sysDeviceName
                                                 ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iSerialHelper >
           {
            static char const * getName() { return INTERFACE_CLI_IO_ISERIALHELPER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iSerialHelper* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iSerialHelper > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iSerialHelper wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_ISERIALHELPER >
                                          */
                     >
            class CiSerialHelperWrapper
            {
                public:
            
                    typedef  CiSerialHelperWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiSerialHelperWrapper() :
                       pif(0) {}
            
                    CiSerialHelperWrapper( iSerialHelper *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiSerialHelperWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiSerialHelperWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiSerialHelperWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiSerialHelperWrapper(const CiSerialHelperWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiSerialHelperWrapper()  { }
            
                    CiSerialHelperWrapper& operator=(const CiSerialHelperWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE buildOptionsString( const STRUCT_CLI_IO_SERIAL_COPTIONS    &options /* [in,ref] ::cli::io::serial::COptions  options  (struct passed by ref in wrapper) */
                                            , ::std::wstring    &optString
                                            )
                       {
                    
                        CCliStr tmp_optString; CCliStr_init( tmp_optString );
                        RCODE res = pif->buildOptionsString(&options, &tmp_optString);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( optString, tmp_optString);
                           }
                        return res;
                       }
                    
                    RCODE parseOptionsString( const ::std::wstring    &optString
                                            , STRUCT_CLI_IO_SERIAL_COPTIONS    &options /* [out] ::cli::io::serial::COptions options  (struct passed by ref in wrapper) */
                                            )
                       {
                        CCliStr tmp_optString; CCliStr_lightCopyTo( tmp_optString, optString);
                    
                        return pif->parseOptionsString(&tmp_optString, &options);
                       }
                    
                    RCODE makeSystemDeviceName( const ::std::wstring    &usnDevicePath
                                              , ::std::wstring    &sysDeviceName
                                              )
                       {
                        CCliStr tmp_usnDevicePath; CCliStr_lightCopyTo( tmp_usnDevicePath, usnDevicePath);
                        CCliStr tmp_sysDeviceName; CCliStr_init( tmp_sysDeviceName );
                        RCODE res = pif->makeSystemDeviceName(&tmp_usnDevicePath, &tmp_sysDeviceName);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( sysDeviceName, tmp_sysDeviceName);
                           }
                        return res;
                       }
                    
                    RCODE makeDisplayDeviceName( const ::std::wstring    &usnDevicePath
                                               , ::std::wstring    &sysDeviceName
                                               )
                       {
                        CCliStr tmp_usnDevicePath; CCliStr_lightCopyTo( tmp_usnDevicePath, usnDevicePath);
                        CCliStr tmp_sysDeviceName; CCliStr_init( tmp_sysDeviceName );
                        RCODE res = pif->makeDisplayDeviceName(&tmp_usnDevicePath, &tmp_sysDeviceName);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( sysDeviceName, tmp_sysDeviceName);
                           }
                        return res;
                       }
                    

            
            
            }; // class CiSerialHelperWrapper
            
            typedef CiSerialHelperWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_ISERIALHELPER     > >  CiSerialHelper;
            typedef CiSerialHelperWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_ISERIALHELPER > >  CiSerialHelper_nrc; /* No ref counting for interface used */
            typedef CiSerialHelperWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_ISERIALHELPER > >  CiSerialHelper_tmp; /* for temporary usage, same as CiSerialHelper_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::io::iSerial */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_ISERIAL_IID
    #define INTERFACE_CLI_IO_ISERIAL_IID    "/cli/io/iSerial"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iSerial
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_ISERIAL
       #define INTERFACE_CLI_IO_ISERIAL    ::cli::io::iSerial
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iSerial
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_ISERIAL
       #define INTERFACE_CLI_IO_ISERIAL    cli_io_iSerial
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iSerial methods */
                CLIMETHOD(setSerialOptions) (THIS_ const STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [in,ref] ::cli::io::serial::COptions  options  */) PURE;
                CLIMETHOD(getSerialOptions) (THIS_ STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [out] ::cli::io::serial::COptions options  */) PURE;
                CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                     , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                     , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                ) PURE;
                CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                            , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                            , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                            , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                       ) PURE;
                CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                      , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                      , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 ) PURE;
                CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                             , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                             , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                             , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                        ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iSerial >
           {
            static char const * getName() { return INTERFACE_CLI_IO_ISERIAL_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iSerial* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iSerial > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iSerial wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_ISERIAL >
                                          */
                     >
            class CiSerialWrapper
            {
                public:
            
                    typedef  CiSerialWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiSerialWrapper() :
                       pif(0) {}
            
                    CiSerialWrapper( iSerial *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiSerialWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiSerialWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiSerialWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiSerialWrapper(const CiSerialWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiSerialWrapper()  { }
            
                    CiSerialWrapper& operator=(const CiSerialWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE setSerialOptions( const STRUCT_CLI_IO_SERIAL_COPTIONS    &options /* [in,ref] ::cli::io::serial::COptions  options  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->setSerialOptions(&options);
                       }
                    
                    RCODE getSerialOptions( STRUCT_CLI_IO_SERIAL_COPTIONS    &options /* [out] ::cli::io::serial::COptions options  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->getSerialOptions(&options);
                       }
                    
                    RCODE read( VOID*    buf /* [out,flat] void buf[]  */
                              , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                              , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                              )
                       {
                    
                    
                    
                        return pif->read(buf, numBytesToRead, numBytesReaded);
                       }
                    
                    RCODE readTimeout( VOID*    buf /* [out,flat] void buf[]  */
                                     , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                     , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                     , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                     )
                       {
                    
                    
                    
                    
                        return pif->readTimeout(buf, numBytesToRead, numBytesReaded, millisecTimeout);
                       }
                    
                    RCODE write( const VOID*    buf /* [in,flat] void  buf[]  */
                               , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                               , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                               )
                       {
                    
                    
                    
                        return pif->write(buf, numBytesToWrite, numBytesWritten);
                       }
                    
                    RCODE writeTimeout( const VOID*    buf /* [in,flat] void  buf[]  */
                                      , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                      , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                      , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                      )
                       {
                    
                    
                    
                    
                        return pif->writeTimeout(buf, numBytesToWrite, numBytesWritten, millisecTimeout);
                       }
                    

            
            
            }; // class CiSerialWrapper
            
            typedef CiSerialWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_ISERIAL     > >  CiSerial;
            typedef CiSerialWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_ISERIAL > >  CiSerial_nrc; /* No ref counting for interface used */
            typedef CiSerialWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_ISERIAL > >  CiSerial_tmp; /* for temporary usage, same as CiSerial_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif





#endif /* CLI_IO_ISERIAL_H */
