#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_MSTREAMS_H
#define CLI_IO_MSTREAMS_H

/* add this lines to your src
#ifndef CLI_IO_MSTREAMS_H
    #include <cli/io/mstreams.h>
#endif
*/

#ifndef CLI_IO_IO_H
    #include <cli/io/io.h>
#endif

#ifndef CLI_ICLONEAB_H
    #include <cli/icloneab.h>
#endif

#ifndef CLI_IMEMBLOCK_H
    #include <cli/imemblock.h>
#endif


#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_INC_MEMORY) && !defined(_MEMORY_H_) && !defined(_MEMORY_H)
    #include <memory.h>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif


/*
   memory streams implementations

   * raw memory streams
   CMemoryIStream  - provides INTERFACE_CLI_IO_IISTREAM, INTERFACE_CLI_IMEMBLOCK
                              INTERFACE_CLI_ICLONEABLE, INTERFACE_CLI_IO_ISEEKABLE
   CMemoryOStream  - provides INTERFACE_CLI_IO_IOSTREAM, INTERFACE_CLI_IMEMBLOCK
                              INTERFACE_CLI_ICLONEABLE, INTERFACE_CLI_IO_ISEEKABLE
   CMemoryIOStream - provides INTERFACE_CLI_IO_IISTREAM, INTERFACE_CLI_IO_IOSTREAM, 
                              INTERFACE_CLI_IO_IIOSTREAM, INTERFACE_CLI_IMEMBLOCK
                              INTERFACE_CLI_ICLONEABLE, INTERFACE_CLI_IO_ISEEKABLE
   read/write to memory block
   //when there is no space to write data, value EC_NOT_ENOUGH_MEM will be returned

   * string streams
   CStdStringPtrIStream, CStdStringPtrOStream, CStdStringPtrIOStream
   CStdStringIStream, CStdStringOStream, CStdStringIOStream are same as CMemory* streams
   with one differrence - iMemBlock::setBlock will fail in all cases


   * shared string streams
   same as CStdString*Stream, but shared string was used. It means that the object copied
   with iCloneable::cloneObject share the same string


//EC_NO_MEM
//EC_NOT_ENOUGH_MEM

       get/set memory block (INTERFACE_CLI_IMEMBLOCK)
       seek pointer         (INTERFACE_CLI_IO_ISEEKABLE)

*/




namespace cli
{
namespace io
{

namespace implhlp {

inline SIZE_T calcNumBytesAvailForReading( SIZE_T curPos, SIZE_T blockSize, SIZE_T requestedNumBytes )
   {
    if (curPos>=blockSize) return 0; // bytes available
    SIZE_T bytesAvail = blockSize - curPos;
    if (bytesAvail > requestedNumBytes) return requestedNumBytes;
    return bytesAvail;
   }

inline SIZE_T calcNumBytesAvailForWriting( SIZE_T curPos, SIZE_T blockSize, SIZE_T requestedNumBytes )
   {
    return calcNumBytesAvailForReading( curPos, blockSize, requestedNumBytes );
   }

inline RCODE seekableSetPos( ENUM_CLI_IO_ESEEKMOVEMETHOD method, FILE_DIFF_T distanceToMove, FILE_SIZE_T* newPos
                           , SIZE_T &curPos, SIZE_T bufSize
                           )
   {
    switch(method)
       {
        case CLI_IO_ESEEKMOVEMETHOD_BEGIN:
                curPos = (SIZE_T)(SSIZE_T)distanceToMove;
                if (curPos>bufSize) curPos = bufSize;
                break;

        case CLI_IO_ESEEKMOVEMETHOD_CURRENT:
                curPos = (SIZE_T)(SSIZE_T)((FILE_DIFF_T)(FILE_SIZE_T)curPos + distanceToMove);
                if (curPos>bufSize) curPos = bufSize;
                break;

        case CLI_IO_ESEEKMOVEMETHOD_END:
                curPos = (SIZE_T)(SSIZE_T)((FILE_DIFF_T)(FILE_SIZE_T)bufSize + distanceToMove);
                if (curPos>bufSize) curPos = bufSize;
                break;

        default: return EC_INVALID_PARAM;
       }
    if (newPos) *newPos = curPos;
    return EC_OK;
   }


}; // namespace implhlp


struct CMemoryIStream : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IO_IISTREAM
                      , public INTERFACE_CLI_IMEMBLOCK
                      , public INTERFACE_CLI_IO_ISEEKABLE
                      , public INTERFACE_CLI_ICLONEABLE
                      , public INTERFACE_CLI_ICONSTRUCTABLE
                      , public INTERFACE_CLI_ISHARECLONEABLE
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef CMemoryIStream this_class;

    BYTE                    *pMemoryBase;
    SIZE_T                   memorySize;
    SIZE_T                   pos;
    ::cli::CCriticalSection  cs;
    ::std::wstring           streamName;

    CMemoryIStream() 
       : base_impl(DEF_MODULE)
       , pMemoryBase(0)
       , memorySize(0)
       , pos(0)
       , cs()
       , streamName(L"generic memory istream")
       {}

    CMemoryIStream( BYTE *pMem, SIZE_T memSize, SIZE_T p = 0) 
       : base_impl(DEF_MODULE)
       , pMemoryBase(pMem)
       , memorySize(memSize)
       , pos(p)
       , cs()
       , streamName(L"generic memory istream")
       {}

    CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertyGetImpl(_streamName, streamName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       
       }

    CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertySetImpl(_streamName, streamName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CMemoryIStream, INTERFACE_CLI_IO_IISTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IMEMBLOCK )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICLONEABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICONSTRUCTABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISHARECLONEABLE )
    CLI_END_INTERFACE_MAP(CMemoryIStream)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    // INTERFACE_CLI_IMEMBLOCK
    CLIMETHOD(setBlock) (THIS_ const VOID*    pBlockAddr /* [in] void*  pBlockAddr  */
                             , SIZE_T    blockSize /* [in] size_t  blockSize  */
                        )
       {
        CLI_SCOPED_LOCK(cs);
        pMemoryBase = (BYTE*)pBlockAddr;
        memorySize  = blockSize;
        if (!pMemoryBase) memorySize = 0;
        pos = 0; // reset position when new block assigned
        return EC_OK;
       }

    CLIMETHOD(getBlock) (THIS_ VOID**    pBlockAddr /* [out] void* pBlockAddr  */
                             , SIZE_T*    blockSize /* [out] size_t blockSize  */
                        )
       {
        CLI_SCOPED_LOCK(cs);
        if (pBlockAddr) *pBlockAddr = (VOID*)pMemoryBase;
        if (blockSize)  *blockSize  = memorySize;
        return EC_OK;
       }

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLIMETHOD(constructObject) (THIS_ INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */)
       {
        CLI_TRY{
                if (!pNewObj) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewObj" );  }
                this_class *pNewStream = new this_class( );
                *pNewObj = static_cast< INTERFACE_CLI_ICONSTRUCTABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ICLONEABLE
    CLIMETHOD(cloneObject) (THIS_ INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                CLI_SCOPED_LOCK(cs);
                this_class *pNewStream = new this_class( pMemoryBase, memorySize, pos );
                *pObjClone = static_cast< INTERFACE_CLI_ICLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ISHARECLONEABLE
    CLIMETHOD(shareCloneObject) (THIS_ INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                CLI_SCOPED_LOCK(cs);
                this_class *pNewStream = new this_class( pMemoryBase, memorySize, 0 );
                *pObjClone = static_cast< INTERFACE_CLI_ISHARECLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_IO_ISEEKABLE
    CLIMETHOD(getPos) (THIS_ FILE_SIZE_T*    curPos /* [out] file_size_t curPos  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (curPos) *curPos = pos;
        return EC_OK;
       }

    CLIMETHOD(setPos) (THIS_ ENUM_CLI_IO_ESEEKMOVEMETHOD    method /* [in] ::cli::io::ESeekMoveMethod  method  */
                           , FILE_DIFF_T    distanceToMove /* [in] file_diff_t  distanceToMove  */
                           , FILE_SIZE_T*    newPos /* [out,optional] file_size_t newPos  */
                      )
       {
        CLI_SCOPED_LOCK(cs);
        return implhlp::seekableSetPos( method, distanceToMove, newPos, pos, memorySize );
       }

    CLIMETHOD(getSize) (THIS_ FILE_SIZE_T*    size /* [out] file_size_t size  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (size) *size = memorySize;
        return EC_OK;
       }

    CLIMETHOD(setSize) (THIS_ FILE_SIZE_T    newSize /* [in] file_size_t  newSize  */)
       {
        CLI_SCOPED_LOCK(cs);
        if ((SIZE_T)newSize>memorySize) return EC_INVALID_PARAM;
        memorySize = (SIZE_T)newSize; // logical truncate memory block
        if (pos>memorySize) pos = memorySize;
        return EC_OK;
       }


    // INTERFACE_CLI_IO_IISTREAM
    CLIMETHOD_(ENUM_CLI_IO_IOSTREAMTYPE, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_MEMORY | CLI_IO_IOSTREAMTYPE_FPAIRED;
       }

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        CLI_SCOPED_LOCK(cs);
        if (!pMemoryBase) return EC_BROKEN_STREAM;
        numBytesToRead = implhlp::calcNumBytesAvailForReading( pos, memorySize, numBytesToRead );
        memcpy( (void*)buf, (const void*)(pMemoryBase+pos), numBytesToRead );
        if (numBytesReaded) *numBytesReaded = numBytesToRead;
        pos += numBytesToRead;
        return EC_OK;
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        return read( buf, numBytesToRead, numBytesReaded );
       }

    CLIMETHOD(closeStream) (THIS)
       {
        CLI_SCOPED_LOCK(cs);
        pMemoryBase = 0;
        memorySize  = 0;
        pos = 0;
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */);

}; // struct CMemoryIStream




struct CMemoryOStream : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IO_IOSTREAM
                      , public INTERFACE_CLI_IMEMBLOCK
                      , public INTERFACE_CLI_IO_ISEEKABLE
                      , public INTERFACE_CLI_ICLONEABLE
                      , public INTERFACE_CLI_ICONSTRUCTABLE
                      , public INTERFACE_CLI_ISHARECLONEABLE
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef CMemoryOStream this_class;

    BYTE              *pMemoryBase;
    SIZE_T             memorySize;
    SIZE_T             pos;
    ::cli::CCriticalSection  cs;
    ::std::wstring           streamName;

    CMemoryOStream() 
       : base_impl(DEF_MODULE)
       , pMemoryBase(0)
       , memorySize(0)
       , pos(0)
       , cs()
       , streamName(L"generic memory ostream")
       {}

    CMemoryOStream( BYTE *pMem, SIZE_T memSize, SIZE_T p = 0 ) 
       : base_impl(DEF_MODULE)
       , pMemoryBase(pMem)
       , memorySize(memSize)
       , pos(p)
       , cs()
       , streamName(L"generic memory ostream")
       {}

    CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertyGetImpl(_streamName, streamName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       
       }

    CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertySetImpl(_streamName, streamName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CMemoryOStream, INTERFACE_CLI_IO_IOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IMEMBLOCK )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICLONEABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICONSTRUCTABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISHARECLONEABLE )
    CLI_END_INTERFACE_MAP(CMemoryOStream)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    // INTERFACE_CLI_IMEMBLOCK
    CLIMETHOD(setBlock) (THIS_ const VOID*    pBlockAddr /* [in] void*  pBlockAddr  */
                             , SIZE_T    blockSize /* [in] size_t  blockSize  */
                        )
       {
        CLI_SCOPED_LOCK(cs);
        pMemoryBase = (BYTE*)pBlockAddr;
        memorySize  = blockSize;
        if (!pMemoryBase) memorySize = 0;
        pos = 0; // reset position when new block assigned
        return EC_OK;
       }

    CLIMETHOD(getBlock) (THIS_ VOID**    pBlockAddr /* [out] void* pBlockAddr  */
                             , SIZE_T*    blockSize /* [out] size_t blockSize  */
                        )
       {
        CLI_SCOPED_LOCK(cs);
        if (pBlockAddr) *pBlockAddr = (VOID*)pMemoryBase;
        if (blockSize)  *blockSize  = memorySize;
        return EC_OK;
       }

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLIMETHOD(constructObject) (THIS_ INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */)
       {
        CLI_TRY{
                if (!pNewObj) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewObj" );  }
                this_class *pNewStream = new this_class( );
                *pNewObj = static_cast< INTERFACE_CLI_ICONSTRUCTABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ICLONEABLE
    CLIMETHOD(cloneObject) (THIS_ INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                CLI_SCOPED_LOCK(cs);
                this_class *pNewStream = new this_class( pMemoryBase, memorySize, pos );
                *pObjClone = static_cast< INTERFACE_CLI_ICLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ISHARECLONEABLE
    CLIMETHOD(shareCloneObject) (THIS_ INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                CLI_SCOPED_LOCK(cs);
                this_class *pNewStream = new this_class( pMemoryBase, memorySize, 0 );
                *pObjClone = static_cast< INTERFACE_CLI_ISHARECLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_IO_ISEEKABLE
    CLIMETHOD(getPos) (THIS_ FILE_SIZE_T*    curPos /* [out] file_size_t curPos  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (curPos) *curPos = pos;
        return EC_OK;
       }

    CLIMETHOD(setPos) (THIS_ ENUM_CLI_IO_ESEEKMOVEMETHOD    method /* [in] ::cli::io::ESeekMoveMethod  method  */
                           , FILE_DIFF_T    distanceToMove /* [in] file_diff_t  distanceToMove  */
                           , FILE_SIZE_T*    newPos /* [out,optional] file_size_t newPos  */
                      )
       {
        CLI_SCOPED_LOCK(cs);
        return implhlp::seekableSetPos( method, distanceToMove, newPos, pos, memorySize );
       }

    CLIMETHOD(getSize) (THIS_ FILE_SIZE_T*    size /* [out] file_size_t size  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (size) *size = memorySize;
        return EC_OK;
       }

    CLIMETHOD(setSize) (THIS_ FILE_SIZE_T    newSize /* [in] file_size_t  newSize  */)
       {
        CLI_SCOPED_LOCK(cs);
        if ((SIZE_T)newSize>memorySize) return EC_INVALID_PARAM;
        memorySize = (SIZE_T)newSize; // logical truncate memory block
        if (pos>memorySize) pos = memorySize;
        return EC_OK;
       }


    // INTERFACE_CLI_IO_IOSTREAM
    CLIMETHOD_(ENUM_CLI_IO_IOSTREAMTYPE, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_MEMORY | CLI_IO_IOSTREAMTYPE_FPAIRED;
       }

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        CLI_SCOPED_LOCK(cs);
        if (!pMemoryBase) return EC_BROKEN_STREAM;
        if (numBytesToWrite)
           {
            numBytesToWrite = implhlp::calcNumBytesAvailForWriting( pos, memorySize, numBytesToWrite );
            if (!numBytesToWrite)
               {
                if (numBytesWritten) *numBytesWritten = 0;
                return EC_NOT_ENOUGH_MEM;
               }
            memcpy( (void*)(pMemoryBase+pos), (const void*)buf, numBytesToWrite );
            if (numBytesWritten) *numBytesWritten = numBytesToWrite;
            pos += numBytesToWrite;
           }
        else
           {
            if (numBytesWritten) *numBytesWritten = numBytesToWrite;
            return EC_OK;
           }
        return EC_OK;
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        return write( buf, numBytesToWrite, numBytesWritten );
       }

    CLIMETHOD(closeStream) (THIS)
       {
        CLI_SCOPED_LOCK(cs);
        pMemoryBase = 0;
        memorySize  = 0;
        pos = 0;
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */);

}; // struct CMemoryOStream




struct CMemoryIOStream : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IO_IIOSTREAM
                      , public INTERFACE_CLI_IO_IISTREAM
                      , public INTERFACE_CLI_IO_IOSTREAM
                      , public INTERFACE_CLI_IMEMBLOCK
                      , public INTERFACE_CLI_IO_ISEEKABLE
                      , public INTERFACE_CLI_ICLONEABLE
                      , public INTERFACE_CLI_ICONSTRUCTABLE
                      , public INTERFACE_CLI_ISHARECLONEABLE
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef CMemoryIOStream this_class;

    BYTE              *pMemoryBase;
    SIZE_T             memorySize;
    SIZE_T             pos;
    ::cli::CCriticalSection  cs;
    ::std::wstring           streamName;

    CMemoryIOStream() 
       : base_impl(DEF_MODULE)
       , pMemoryBase(0)
       , memorySize(0)
       , pos(0)
       , cs()
       , streamName(L"generic memory iostream")
       {}

    CMemoryIOStream( BYTE *pMem, SIZE_T memSize, SIZE_T p = 0 ) 
       : base_impl(DEF_MODULE)
       , pMemoryBase(pMem)
       , memorySize(memSize)
       , pos(p)
       , cs()
       , streamName(L"generic memory iostream")
       {}

    CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertyGetImpl(_streamName, streamName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       
       }

    CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertySetImpl(_streamName, streamName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CMemoryIOStream, INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IMEMBLOCK )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICLONEABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICONSTRUCTABLE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISHARECLONEABLE )
    CLI_END_INTERFACE_MAP(CMemoryIOStream)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    // INTERFACE_CLI_IMEMBLOCK
    CLIMETHOD(setBlock) (THIS_ const VOID*    pBlockAddr /* [in] void*  pBlockAddr  */
                             , SIZE_T    blockSize /* [in] size_t  blockSize  */
                        )
       {
        CLI_SCOPED_LOCK(cs);
        pMemoryBase = (BYTE*)pBlockAddr;
        memorySize  = blockSize;
        if (!pMemoryBase) memorySize = 0;
        pos = 0; // reset position when new block assigned
        return EC_OK;
       }

    CLIMETHOD(getBlock) (THIS_ VOID**    pBlockAddr /* [out] void* pBlockAddr  */
                             , SIZE_T*    blockSize /* [out] size_t blockSize  */
                        )
       {
        CLI_SCOPED_LOCK(cs);
        if (pBlockAddr) *pBlockAddr = (VOID*)pMemoryBase;
        if (blockSize)  *blockSize  = memorySize;
        return EC_OK;
       }

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLIMETHOD(constructObject) (THIS_ INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */)
       {
        CLI_TRY{
                if (!pNewObj) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewObj" );  }
                this_class *pNewStream = new this_class( );
                *pNewObj = static_cast< INTERFACE_CLI_ICONSTRUCTABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ICLONEABLE
    CLIMETHOD(cloneObject) (THIS_ INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                CLI_SCOPED_LOCK(cs);
                this_class *pNewStream = new this_class( pMemoryBase, memorySize, pos );
                *pObjClone = static_cast< INTERFACE_CLI_ICLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ISHARECLONEABLE
    CLIMETHOD(shareCloneObject) (THIS_ INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                CLI_SCOPED_LOCK(cs);
                this_class *pNewStream = new this_class( pMemoryBase, memorySize, 0 );
                *pObjClone = static_cast< INTERFACE_CLI_ISHARECLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_IO_ISEEKABLE
    CLIMETHOD(getPos) (THIS_ FILE_SIZE_T*    curPos /* [out] file_size_t curPos  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (curPos) *curPos = pos;
        return EC_OK;
       }

    CLIMETHOD(setPos) (THIS_ ENUM_CLI_IO_ESEEKMOVEMETHOD    method /* [in] ::cli::io::ESeekMoveMethod  method  */
                           , FILE_DIFF_T    distanceToMove /* [in] file_diff_t  distanceToMove  */
                           , FILE_SIZE_T*    newPos /* [out,optional] file_size_t newPos  */
                      )
       {
        CLI_SCOPED_LOCK(cs);
        return implhlp::seekableSetPos( method, distanceToMove, newPos, pos, memorySize );
       }

    CLIMETHOD(getSize) (THIS_ FILE_SIZE_T*    size /* [out] file_size_t size  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (size) *size = memorySize;
        return EC_OK;
       }

    CLIMETHOD(setSize) (THIS_ FILE_SIZE_T    newSize /* [in] file_size_t  newSize  */)
       {
        CLI_SCOPED_LOCK(cs);
        if ((SIZE_T)newSize>memorySize) return EC_INVALID_PARAM;
        memorySize = (SIZE_T)newSize; // logical truncate memory block
        if (pos>memorySize) pos = memorySize;
        return EC_OK;
       }

    // INTERFACE_CLI_IO_IOSTREAM
    CLIMETHOD_(ENUM_CLI_IO_IOSTREAMTYPE, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_MEMORY | CLI_IO_IOSTREAMTYPE_FPAIRED;
       }

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        CLI_SCOPED_LOCK(cs);
        if (!pMemoryBase) return EC_BROKEN_STREAM;
        numBytesToRead = implhlp::calcNumBytesAvailForReading( pos, memorySize, numBytesToRead );
        memcpy( (void*)buf, (const void*)(pMemoryBase+pos), numBytesToRead );
        if (numBytesReaded) *numBytesReaded = numBytesToRead;
        pos += numBytesToRead;
        return EC_OK;
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        return read( buf, numBytesToRead, numBytesReaded );
       }

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        CLI_SCOPED_LOCK(cs);
        if (!pMemoryBase) return EC_BROKEN_STREAM;
        if (numBytesToWrite)
           {
            numBytesToWrite = implhlp::calcNumBytesAvailForWriting( pos, memorySize, numBytesToWrite );
            if (!numBytesToWrite)
               {
                if (numBytesWritten) *numBytesWritten = 0;
                return EC_NOT_ENOUGH_MEM;
               }
            memcpy( (void*)(pMemoryBase+pos), (const void*)buf, numBytesToWrite );
            if (numBytesWritten) *numBytesWritten = numBytesToWrite;
            pos += numBytesToWrite;
           }
        else
           {
            if (numBytesWritten) *numBytesWritten = numBytesToWrite;
            return EC_OK;
           }
        return EC_OK;
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        return write( buf, numBytesToWrite, numBytesWritten );
       }

    CLIMETHOD(closeStream) (THIS)
       {
        CLI_SCOPED_LOCK(cs);
        pMemoryBase = 0;
        memorySize  = 0;
        pos = 0;
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */);
    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */);

    CLIMETHOD(open) (THIS_ const CLISTR*     streamName
                         , const CLISTR*     host
                         , const CLISTR*     port
                         , const CLISTR*     path
                         , const CLISTR*     options
                         , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                    )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(openPStr) (THIS_ CLIPSTR           streamName
                             , CLIPSTR           host
                             , CLIPSTR           port
                             , CLIPSTR           path
                             , CLIPSTR           options
                             , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                        )
       {
        return EC_NOT_IMPLEMENTED;
       }



}; // struct CMemoryIOStream



inline CLIMETHODIMP(CMemoryOStream::createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CLI_SCOPED_LOCK(cs);
            CMemoryIStream *pNewStream = new CMemoryIStream( pMemoryBase, pos, 0 );
            *pStream = static_cast< INTERFACE_CLI_IO_IISTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }

inline CLIMETHODIMP(CMemoryIStream::createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CLI_SCOPED_LOCK(cs);
            CMemoryOStream *pNewStream = new CMemoryOStream( pMemoryBase, memorySize, 0 );
            *pStream = static_cast< INTERFACE_CLI_IO_IOSTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }

inline CLIMETHODIMP(CMemoryIOStream::createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CLI_SCOPED_LOCK(cs);
            CMemoryIStream *pNewStream = new CMemoryIStream( pMemoryBase, pos, 0 );
            *pStream = static_cast< INTERFACE_CLI_IO_IISTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }

inline CLIMETHODIMP(CMemoryIOStream::createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CLI_SCOPED_LOCK(cs);
            CMemoryOStream *pNewStream = new CMemoryOStream( pMemoryBase, memorySize, 0 );
            *pStream = static_cast< INTERFACE_CLI_IO_IOSTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }






}; // namespace io
}; // namespace cli




#endif /* CLI_IO_MSTREAMS_H */

