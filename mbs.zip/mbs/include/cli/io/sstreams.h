#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_SSTREAMS_H
#define CLI_IO_SSTREAMS_H

/* add this lines to your src
#ifndef CLI_IO_SSTREAMS_H
    #include <cli/io/sstreams.h>
#endif
*/

#ifndef CLI_IO_MSTREAMS_H
    #include <cli/io/mstreams.h>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif


/*
   see also mstreams.h

   * ::std::string streams
   CStdStringPtrIStream, CStdStringPtrOStream, CStdStringPtrIOStream
   CStdStringIStream, CStdStringOStream, CStdStringIOStream are same as CMemory* streams
   with one differrence - iMemBlock::setBlock will fail in all cases

   * shared string streams
   same as CStdString*Stream, but shared string was used. It means that the object copied
   with iCloneable::cloneObject share the same string

   1) ����� �������� ������ �� ��������� - ��� �������� ������������ ��� �������
   2) ����� �������� ������ �� ������/�� �������� - ��� �������� ������������ ��� ������.
   3) ����� �� �������� ������ - ��������� � ������������ ����� (������)


*/




namespace cli
{
namespace io
{

struct iStdStringPtrHolder : public INTERFACE_CLI_IUNKNOWN
{
    CLIMETHOD_(::std::string*, getStringPtr)() PURE;
};

#define INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER        ::cli::io::iStdStringPtrHolder
#define INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER_IID    "/cli-internals/cli/io/iStdStringPtrHolder"

#define CLI_IO_IMPLEMENT_ISTDSTRINGPTRHOLDER(className)                                \
            CLIMETHOD_(VOID, destroy) (THIS)                                           \
               {                                                                       \
                delete this;                                                           \
               }                                                                       \
            CLI_BEGIN_INTERFACE_MAP2(className, INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER ) \
                CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER )        \
            CLI_END_INTERFACE_MAP(className)                                           \
            CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }              \
            CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


struct CStdStringPtrHolder : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public iStdStringPtrHolder
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    ::std::string *pStr;
    CStdStringPtrHolder( ::std::string *str) : base_impl(DEF_MODULE), pStr(str) {}
    ~CStdStringPtrHolder( ) {}

    #include <cli/compspec/pdelnvdtoroff.h>
    CLI_IO_IMPLEMENT_ISTDSTRINGPTRHOLDER(CStdStringPtrHolder)
    #include <cli/compspec/pdelnvdtoron.h>

    CLIMETHOD_(::std::string*, getStringPtr)() { return pStr; }

}; // struct CStdStringPtrHolder


struct CStdStringPtrOwner : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public iStdStringPtrHolder
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    ::std::string *pStr;
    CStdStringPtrOwner( ::std::string *p = 0) : base_impl(DEF_MODULE), pStr(p) 
       {
        if (!pStr) pStr = new ::std::string();
       }
    ~CStdStringPtrOwner( ) { delete pStr; }


    #include <cli/compspec/pdelnvdtoroff.h>
    CLI_IO_IMPLEMENT_ISTDSTRINGPTRHOLDER(CStdStringPtrOwner)
    #include <cli/compspec/pdelnvdtoron.h>

    CLIMETHOD_(::std::string*, getStringPtr)() { return pStr; }

}; // struct CStdStringPtrOwner


struct CStdStringOwner : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public iStdStringPtrHolder
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    ::std::string str;
    CStdStringOwner( ) : base_impl(DEF_MODULE), str() { }
    CStdStringOwner( const ::std::string &s ) : base_impl(DEF_MODULE), str(s) { }
    CStdStringOwner( const char* pData, SIZE_T len ) : base_impl(DEF_MODULE), str(pData,len) { }
    ~CStdStringOwner( ) { }

    #include <cli/compspec/pdelnvdtoroff.h>
    CLI_IO_IMPLEMENT_ISTDSTRINGPTRHOLDER(CStdStringOwner)
    #include <cli/compspec/pdelnvdtoron.h>

    CLIMETHOD_(::std::string*, getStringPtr)() { return &str; }

}; // struct CStdStringOwner




//template <typename TBase>
struct CStringStreamImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IO_IISTREAM
                      , public INTERFACE_CLI_IO_IOSTREAM
                      , public INTERFACE_CLI_IO_IIOSTREAM
                      , public INTERFACE_CLI_IMEMBLOCK
                      , public INTERFACE_CLI_IO_ISEEKABLE
                      , public INTERFACE_CLI_ICLONEABLE
                      , public INTERFACE_CLI_ICONSTRUCTABLE
                      , public INTERFACE_CLI_ISHARECLONEABLE
                      //, public TBase
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef CStringStreamImpl this_class;

    ::cli::CCliPtr< INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER > data;
    SIZE_T                                                 pos;
    ::cli::CCriticalSection                                cs;
    ::std::wstring                                         streamName;

    /* �������� ����� �� ������� �� �� �� ������ */                             
    CStringStreamImpl( INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER *p, bool noAddRef = false )
       : base_impl(DEF_MODULE)                                                  
       , data( p, noAddRef )                                                    
       , pos(0)                                                                 
       , cs()
       , streamName(L"generic string iostream")
       {}                                                                       
                                                                                
    /* �������� � ������������ ������ */                                        
    CStringStreamImpl( const ::std::string &str)                                
       : base_impl(DEF_MODULE)                                                  
       , data( new CStdStringOwner(str), true )                                 
       , pos(0)                                                                 
       , cs()
       , streamName(L"generic string iostream")
       {}                                                                       

    /* �������� �� ������ � ������������ � ������ */                                        
    CStringStreamImpl( const char* pData, SIZE_T len )                                
       : base_impl(DEF_MODULE)                                                  
       , data( new CStdStringOwner( pData, len ), true )                                 
       , pos(0)                                                                 
       , cs()
       , streamName(L"generic string iostream")
       {}                                                                       
                                                                                
    /* �������� � ������������ ������ � ������� */                              
    CStringStreamImpl( const ::std::string &str, SIZE_T p)                      
       : base_impl(DEF_MODULE)                                                  
       , data( new CStdStringOwner(str), true )                                 
       , pos(p)                                                                 
       , cs()
       , streamName(L"generic string iostream")
       {}                                                                       
                                                                                
    /* �������� � �������������� ��������� �� ������ */                         
    CStringStreamImpl( ::std::string *pStr)                                     
       : base_impl(DEF_MODULE)                                                  
       , data( new CStdStringPtrHolder(pStr), true )                            
       , pos(0)                                                                 
       , cs()
       , streamName(L"generic string iostream")
       {}                                                                       
                                                                                
    CStringStreamImpl( )                                                        
       : base_impl(DEF_MODULE)                                                  
       , data( new CStdStringOwner(), true )                                    
       , pos(0)                                                                 
       , cs()
       , streamName(L"generic string iostream")
       {}


    CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertyGetImpl(_streamName, streamName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       
       }

    CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertySetImpl(_streamName, streamName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_IMEMBLOCK

    CLIMETHOD(setBlock) (THIS_ const VOID*    pBlockAddr /* [in] void*  pBlockAddr  */
                             , SIZE_T    blockSize /* [in] size_t  blockSize  */
                        )
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!data) 
                   {
                    CStdStringOwner *pStrOwner = new CStdStringOwner( ::std::string( (const char*)pBlockAddr, blockSize ) );
                    data = pStrOwner;
                    pStrOwner->release();
                    return EC_OK;
                   }

                ::std::string *pStr = data->getStringPtr();
                if (!pStr) return EC_BROKEN_STREAM;
                if (!pBlockAddr || !blockSize) 
                   {
                    pStr->clear();
                    return EC_OK;
                   }
        
                pStr->assign( (::std::string::value_type*)pBlockAddr, blockSize );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getBlock) (THIS_ VOID**    pBlockAddr /* [out] void* pBlockAddr  */
                             , SIZE_T*    blockSize /* [out] size_t blockSize  */
                        )
       {
        CLI_SCOPED_LOCK(cs);
        ::std::string *pStr = 0;
        if (!!data) pStr = data->getStringPtr();
        if (!pStr)
           {
            if (pBlockAddr) *pBlockAddr = 0;
            if (blockSize)  *blockSize  = 0;
            return EC_OK;
           }

        if (pBlockAddr) *pBlockAddr = (VOID*)pStr->data();
        if (blockSize)  *blockSize  = pStr->size();
        return EC_OK;
       }

    // INTERFACE_CLI_IO_ISEEKABLE
    CLIMETHOD(getPos) (THIS_ FILE_SIZE_T*    curPos /* [out] file_size_t curPos  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (curPos) *curPos = pos;
        return EC_OK;
       }

    CLIMETHOD(setPos) (THIS_ ENUM_CLI_IO_ESEEKMOVEMETHOD    method /* [in] ::cli::io::ESeekMoveMethod  method  */
                           , FILE_DIFF_T    distanceToMove /* [in] file_diff_t  distanceToMove  */
                           , FILE_SIZE_T*    newPos /* [out,optional] file_size_t newPos  */
                      )
       {
        CLI_SCOPED_LOCK(cs);
        //if (!data) return EC_BROKEN_STREAM;
        ::std::string *pStr = 0;
        if (!!data) pStr = data->getStringPtr();
        if (!pStr) return EC_BROKEN_STREAM;
        switch(method)
           {
            case CLI_IO_ESEEKMOVEMETHOD_BEGIN:
                    pos = (SIZE_T)(SSIZE_T)distanceToMove;
                    if (pos>pStr->size()) pos = pStr->size();
                    break;
        
            case CLI_IO_ESEEKMOVEMETHOD_CURRENT:
                    pos = (SIZE_T)(SSIZE_T)((FILE_DIFF_T)(FILE_SIZE_T)pos + distanceToMove);
                    if (pos>pStr->size()) pos = pStr->size();
                    break;
        
            case CLI_IO_ESEEKMOVEMETHOD_END:
                    pos = (SIZE_T)(SSIZE_T)((FILE_DIFF_T)(FILE_SIZE_T)pStr->size() + distanceToMove);
                    if (pos>pStr->size()) pos = pStr->size();
                    break;
        
            default: return EC_INVALID_PARAM;
           }
        if (newPos) *newPos = pos;
        return EC_OK;
       }

    CLIMETHOD(getSize) (THIS_ FILE_SIZE_T*    size /* [out] file_size_t size  */)
       {
        CLI_SCOPED_LOCK(cs);
        ::std::string *pStr = 0;
        if (!!data) pStr = data->getStringPtr();
        if (!pStr) return EC_BROKEN_STREAM;
        //::std::string *pStr = data->getStringPtr();
        //if (!pStr) return EC_OK;
        if (size) *size = pStr->size();
        return EC_OK;
       }

    CLIMETHOD(setSize) (THIS_ FILE_SIZE_T    newSize /* [in] file_size_t  newSize  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                ::std::string *pStr = 0;
                if (!!data) pStr = data->getStringPtr();
                if (!pStr) return EC_BROKEN_STREAM;
                //::std::string *pStr = data->getStringPtr();
                //if (!pStr) return EC_OK;
                pStr->resize( (SIZE_T)newSize, 0 );
                if (pos>pStr->size()) pos = pStr->size();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_IO_IISTREAM
    CLIMETHOD_(ENUM_CLI_IO_IOSTREAMTYPE, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_MEMORY | CLI_IO_IOSTREAMTYPE_FPAIRED;
       }

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        CLI_SCOPED_LOCK(cs);
        ::std::string *pStr = 0;
        if (!!data) pStr = data->getStringPtr();
        if (!pStr) return EC_BROKEN_STREAM;
        
        numBytesToRead = implhlp::calcNumBytesAvailForReading( pos, pStr->size(), numBytesToRead );
        memcpy( (void*)buf, (const void*)(pStr->data()+pos), numBytesToRead );
        if (numBytesReaded) *numBytesReaded = numBytesToRead;
        pos += numBytesToRead;
        return EC_OK;
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        return read( buf, numBytesToRead, numBytesReaded );
       }

    CLIMETHOD(closeStream) (THIS)
       {
        //data->release();
        CLI_SCOPED_LOCK(cs);
        data = 0;
        pos = 0;
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(open) (THIS_ const CLISTR*     streamName
                         , const CLISTR*     host
                         , const CLISTR*     port
                         , const CLISTR*     path
                         , const CLISTR*     options
                         , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                    )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(openPStr) (THIS_ CLIPSTR           streamName
                             , CLIPSTR           host
                             , CLIPSTR           port
                             , CLIPSTR           path
                             , CLIPSTR           options
                             , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                        )
       {
        return EC_NOT_IMPLEMENTED;
       }


    // INTERFACE_CLI_IO_IOSTREAM

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        CLI_SCOPED_LOCK(cs);
        ::std::string *pStr = 0;
        if (!!data) pStr = data->getStringPtr();
        if (!pStr) return EC_BROKEN_STREAM;

        if (!buf || !numBytesToWrite)
           {
            if (numBytesWritten) *numBytesWritten = numBytesToWrite;
            return EC_OK;
           }
        
        SIZE_T strSize = pStr->size();
        SIZE_T written = 0;
        ::std::string &str = *pStr;
        const char *dataFrom = (const char*)buf;
        while( (pos < strSize) && (written != numBytesToWrite))
           {
            str[pos++] = *dataFrom++; ++written;
           }

        SIZE_T appendCount = numBytesToWrite-written;

        if (appendCount)
           pStr->append( dataFrom+written, appendCount );
        written += appendCount;
        pos     += appendCount;

        if (numBytesWritten) *numBytesWritten = written;

        return EC_OK;
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        return write( buf, numBytesToWrite, numBytesWritten );
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */);
    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */);




}; // struct CStringStreamImpl


#define CLI_IO_IMPLEMENT_SSTREAMS_CTORS(className, baseName)                    \
    /* �������� ����� �� ������� �� �� �� ������ */                             \
    className( INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER *p, bool noAddRef = false ) \
       : baseName(p,noAddRef)                                                   \
       {}                                                                       \
                                                                                \
    /* �������� � ������������ ������ */                                        \
    className( const ::std::string &str)                                        \
       : baseName(str)                                                          \
       {}                                                                       \
                                                                                \
    /* �������� � ������������ ������ � ������� */                              \
    className( const ::std::string &str, SIZE_T p)                              \
       : baseName(str, p)                                                       \
       {}                                                                       \
                                                                                \
    className( const char* pData, SIZE_T len)                                   \
       : baseName(pData,len)                                                    \
       {}                                                                       \
                                                                                \
    /* �������� � �������������� ��������� �� ������ */                         \
    className( ::std::string *pStr)                                             \
       : baseName(pStr)                                                         \
       {}                                                                       \
                                                                                \
    className( )                                                                \
       : baseName()                                                             \
       {}


#define CLI_IO_IMPLEMENT_SSTREAMS_CONSTRUCT_OBJECT()                                                                                              \
    CLIMETHOD(constructObject) (THIS_ INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */)                      \
       {                                                                                                                                          \
        CLI_TRY{                                                                                                                                  \
                if (!pNewObj) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewObj" );  } \
                this_class *pNewStream = new this_class( );                                                                                       \
                *pNewObj = static_cast< INTERFACE_CLI_ICONSTRUCTABLE* >(pNewStream);                                                              \
               }                                                                                                                                  \
        CLI_CATCH_RETURN_CLI_EXCEPTION()                                                                                                          \
        CLI_CATCH_RETURN_STD_EXCEPTIONS()                                                                                                         \
        return EC_OK;                                                                                                                             \
       }

#define CLI_IO_IMPLEMENT_SSTREAMS_CLONE_OBJECT()                                                                                              \
    CLIMETHOD(cloneObject) (THIS_ INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)                          \
       {                                                                                                                                      \
        CLI_TRY{                                                                                                                              \
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  } \
                ::std::string *pStr = 0;                                                                                                      \
                if (!!data) pStr = data->getStringPtr();                                                                                      \
                this_class *pNewStream = pStr ? new this_class( *pStr, pos ) : new this_class();                                              \
                *pObjClone = static_cast< INTERFACE_CLI_ICLONEABLE* >(pNewStream);                                                            \
               }                                                                                                                              \
        CLI_CATCH_RETURN_CLI_EXCEPTION()                                                                                                      \
        CLI_CATCH_RETURN_STD_EXCEPTIONS()                                                                                                     \
        return EC_OK;                                                                                                                         \
       }

#define CLI_IO_IMPLEMENT_SSTREAMS_SHARE_CLONE_OBJECT()                                                                                              \
    CLIMETHOD(shareCloneObject) (THIS_ INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)                \
       {                                                                                                                                      \
        CLI_TRY{                                                                                                                              \
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  } \
                this_class *pNewStream = new this_class( data.getIfPtr() );                                                                   \
                *pObjClone = static_cast< INTERFACE_CLI_ISHARECLONEABLE* >(pNewStream);                                                       \
               }                                                                                                                              \
        CLI_CATCH_RETURN_CLI_EXCEPTION()                                                                                                      \
        CLI_CATCH_RETURN_STD_EXCEPTIONS()                                                                                                     \
        return EC_OK;                                                                                                                         \
       }




struct CStringIStream : public CStringStreamImpl
{
    typedef CStringIStream this_class;

    CLI_IO_IMPLEMENT_SSTREAMS_CTORS(CStringIStream, CStringStreamImpl)
    CLI_BEGIN_INTERFACE_MAP2(CStringIStream, INTERFACE_CLI_IMEMBLOCK)           
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IMEMBLOCK )                      
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )                   
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICLONEABLE )                     
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICONSTRUCTABLE )                 
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISHARECLONEABLE )
    CLI_END_INTERFACE_MAP(CStringIStream)

    CLIMETHOD_(VOID, destroy) (THIS)
       {
        #include <cli/compspec/delthis.h>
       }
    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLI_IO_IMPLEMENT_SSTREAMS_CONSTRUCT_OBJECT()
    // INTERFACE_CLI_ICLONEABLE
    CLI_IO_IMPLEMENT_SSTREAMS_CLONE_OBJECT()
    // INTERFACE_CLI_ISHARECLONEABLE
    CLI_IO_IMPLEMENT_SSTREAMS_SHARE_CLONE_OBJECT()

};

struct CStringOStream : public CStringStreamImpl
{
    typedef CStringOStream this_class;

    CLI_IO_IMPLEMENT_SSTREAMS_CTORS(CStringOStream, CStringStreamImpl)
    CLI_BEGIN_INTERFACE_MAP2(CStringOStream, INTERFACE_CLI_IMEMBLOCK)           
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IMEMBLOCK )                      
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )                   
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICLONEABLE )                     
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICONSTRUCTABLE )                 
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISHARECLONEABLE )
    CLI_END_INTERFACE_MAP(CStringOStream)
    CLIMETHOD_(VOID, destroy) (THIS)
       {
        #include <cli/compspec/delthis.h>
       }
    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLI_IO_IMPLEMENT_SSTREAMS_CONSTRUCT_OBJECT()
    // INTERFACE_CLI_ICLONEABLE
    CLI_IO_IMPLEMENT_SSTREAMS_CLONE_OBJECT()
    // INTERFACE_CLI_ISHARECLONEABLE
    CLI_IO_IMPLEMENT_SSTREAMS_SHARE_CLONE_OBJECT()

};


struct CStringIOStream : public CStringStreamImpl
{
    typedef CStringIOStream this_class;

    CLI_IO_IMPLEMENT_SSTREAMS_CTORS(CStringIOStream, CStringStreamImpl)
    CLI_BEGIN_INTERFACE_MAP2(CStringIOStream, INTERFACE_CLI_IMEMBLOCK)           
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IMEMBLOCK )                      
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )                   
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICLONEABLE )                     
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICONSTRUCTABLE )                 
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISHARECLONEABLE )
    CLI_END_INTERFACE_MAP(CStringIOStream)
    CLIMETHOD_(VOID, destroy) (THIS)
       {
        #include <cli/compspec/delthis.h>
       }
    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLI_IO_IMPLEMENT_SSTREAMS_CONSTRUCT_OBJECT()
    // INTERFACE_CLI_ICLONEABLE
    CLI_IO_IMPLEMENT_SSTREAMS_CLONE_OBJECT()
    // INTERFACE_CLI_ISHARECLONEABLE
    CLI_IO_IMPLEMENT_SSTREAMS_SHARE_CLONE_OBJECT()

};



inline CLIMETHODIMP(CStringStreamImpl::createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CLI_SCOPED_LOCK(cs);
            CStringIStream *pNewStream = new CStringIStream( data.getIfPtr() );
            *pStream = static_cast< INTERFACE_CLI_IO_IISTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }

inline CLIMETHODIMP(CStringStreamImpl::createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CLI_SCOPED_LOCK(cs);
            CStringOStream *pNewStream = new CStringOStream( data.getIfPtr() );
            *pStream = static_cast< INTERFACE_CLI_IO_IOSTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }








#if 0

#define CLI_IO_IMPLEMENT_SSTREAMS_CTORS(className)                                   \
    /* �������� ����� �� ������� �� �� �� ������ */                             \
    className( INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER *p, bool noAddRef = false ) \
       : base_impl(DEF_MODULE)                                                  \
       , data( p, noAddRef )                                                    \
       , pos(0)                                                                 \
       {}                                                                       \
                                                                                \
    /* �������� � ������������ ������ */                                        \
    className( const ::std::string &str)                                        \
       : base_impl(DEF_MODULE)                                                  \
       , data( new CStdStringOwner(str), true )                                 \
       , pos(0)                                                                 \
       {}                                                                       \
                                                                                \
    /* �������� � ������������ ������ � ������� */                              \
    className( const ::std::string &str, SIZE_T p)                              \
       : base_impl(DEF_MODULE)                                                  \
       , data( new CStdStringOwner(str), true )                                 \
       , pos(p)                                                                 \
       {}                                                                       \
                                                                                \
    /* �������� � �������������� ��������� �� ������ */                         \
    className( ::std::string *pStr)                                             \
       : base_impl(DEF_MODULE)                                                  \
       , data( new CStdStringPtrHolder(pStr), true )                            \
       , pos(0)                                                                 \
       {}                                                                       \
                                                                                \
    className( )                                                                \
       : base_impl(DEF_MODULE)                                                  \
       , data( new CStdStringOwner(), true )                                    \
       , pos(0)                                                                 \
       {}


#define CLI_IO_BEGIN_IMPLEMENT_STRINGSTREAM(className)                          \
    CLI_BEGIN_INTERFACE_MAP2(className, INTERFACE_CLI_IMEMBLOCK)                \
        /*CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM )*/                \
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IMEMBLOCK )                      \
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )                   \
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICLONEABLE )                     \
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICONSTRUCTABLE )                 \
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISHARECLONEABLE )

#define CLI_IO_END_IMPLEMENT_STRINGSTREAM(className)                            \
    CLI_END_INTERFACE_MAP(className)                                            \
    void destroy() { delete this; }                                             \
    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }               \
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


struct CStringIStream : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IO_IISTREAM
                      , public INTERFACE_CLI_IMEMBLOCK
                      , public INTERFACE_CLI_IO_ISEEKABLE
                      , public INTERFACE_CLI_ICLONEABLE
                      , public INTERFACE_CLI_ICONSTRUCTABLE
                      , public INTERFACE_CLI_ISHARECLONEABLE
                      , public CStringStreamImpl<CStringIStream>
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef CStringIStream this_class;

    ::cli::CCliPtr< INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER > data;
    SIZE_T                                                 pos;

    CLI_IO_IMPLEMENT_SSTREAMS_CTORS(CStringIStream)

    CLI_IO_BEGIN_IMPLEMENT_STRINGSTREAM(CStringIStream)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM )
    CLI_IO_END_IMPLEMENT_STRINGSTREAM(CStringIStream)

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLIMETHOD(constructObject) (THIS_ INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */)
       {
        CLI_TRY{
                if (!pNewObj) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewObj" );  }
                this_class *pNewStream = new this_class( );
                *pNewObj = static_cast< INTERFACE_CLI_ICONSTRUCTABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ICLONEABLE
    CLIMETHOD(cloneObject) (THIS_ INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                ::std::string *pStr = 0;
                if (!!data) pStr = data->getStringPtr();
                this_class *pNewStream = pStr ? new this_class( *pStr, pos ) : new this_class();
                *pObjClone = static_cast< INTERFACE_CLI_ICLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ISHARECLONEABLE
    CLIMETHOD(shareCloneObject) (THIS_ INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                this_class *pNewStream = new this_class( data->getIfPtr() );
                *pObjClone = static_cast< INTERFACE_CLI_ISHARECLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */);

}; // struct CStringIStream





struct CStringOStream : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IO_IOSTREAM
                      , public INTERFACE_CLI_IMEMBLOCK
                      , public INTERFACE_CLI_IO_ISEEKABLE
                      , public INTERFACE_CLI_ICLONEABLE
                      , public INTERFACE_CLI_ICONSTRUCTABLE
                      , public INTERFACE_CLI_ISHARECLONEABLE
                      , public CStringStreamImpl<CStringOStream>
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef CStringOStream this_class;

    ::cli::CCliPtr< INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER > data;
    SIZE_T                                                 pos;

    CLI_IO_IMPLEMENT_SSTREAMS_CTORS(CStringOStream)

    CLI_IO_BEGIN_IMPLEMENT_STRINGSTREAM(CStringOStream)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM )
    CLI_IO_END_IMPLEMENT_STRINGSTREAM(CStringOStream)

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLIMETHOD(constructObject) (THIS_ INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */)
       {
        CLI_TRY{
                if (!pNewObj) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewObj" );  }
                this_class *pNewStream = new this_class( );
                *pNewObj = static_cast< INTERFACE_CLI_ICONSTRUCTABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ICLONEABLE
    CLIMETHOD(cloneObject) (THIS_ INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                ::std::string *pStr = 0;
                if (!!data) pStr = data->getStringPtr();
                this_class *pNewStream = pStr ? new this_class( *pStr, pos ) : new this_class();
                *pObjClone = static_cast< INTERFACE_CLI_ICLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ISHARECLONEABLE
    CLIMETHOD(shareCloneObject) (THIS_ INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                this_class *pNewStream = new this_class( data->getIfPtr() );
                *pObjClone = static_cast< INTERFACE_CLI_ISHARECLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */);

}; // struct CStringOStream




struct CStringIOStream : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IO_IISTREAM
                      , public INTERFACE_CLI_IO_IOSTREAM
                      , public INTERFACE_CLI_IO_IIOSTREAM
                      , public INTERFACE_CLI_IMEMBLOCK
                      , public INTERFACE_CLI_IO_ISEEKABLE
                      , public INTERFACE_CLI_ICLONEABLE
                      , public INTERFACE_CLI_ICONSTRUCTABLE
                      , public INTERFACE_CLI_ISHARECLONEABLE
                      , public CStringStreamImpl<CStringIOStream>
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef CStringIOStream this_class;

    ::cli::CCliPtr< INTERFACE_CLI_IO_ISTDSTRINGPTRHOLDER > data;
    SIZE_T                                                 pos;

    CLI_IO_IMPLEMENT_SSTREAMS_CTORS(CStringIOStream)

    CLI_IO_BEGIN_IMPLEMENT_STRINGSTREAM(CStringIOStream)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
    CLI_IO_END_IMPLEMENT_STRINGSTREAM(CStringIOStream)

    // INTERFACE_CLI_ICONSTRUCTABLE
    CLIMETHOD(constructObject) (THIS_ INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */)
       {
        CLI_TRY{
                if (!pNewObj) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewObj" );  }
                this_class *pNewStream = new this_class( );
                *pNewObj = static_cast< INTERFACE_CLI_ICONSTRUCTABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ICLONEABLE
    CLIMETHOD(cloneObject) (THIS_ INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                ::std::string *pStr = 0;
                if (!!data) pStr = data->getStringPtr();
                this_class *pNewStream = pStr ? new this_class( *pStr, pos ) : new this_class();
                *pObjClone = static_cast< INTERFACE_CLI_ICLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    // INTERFACE_CLI_ISHARECLONEABLE
    CLIMETHOD(shareCloneObject) (THIS_ INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
       {
        CLI_TRY{
                if (!pObjClone) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pObjClone" );  }
                this_class *pNewStream = new this_class( data->getIfPtr() );
                *pObjClone = static_cast< INTERFACE_CLI_ISHARECLONEABLE* >(pNewStream);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */);
    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */);

}; // struct CStringIOStream






inline CLIMETHODIMP(CStringOStream::createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CStringIStream *pNewStream = new CStringIStream( data->getIfPtr() );
            *pStream = static_cast< INTERFACE_CLI_IO_IISTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }

inline CLIMETHODIMP(CStringIStream::createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CStringOStream *pNewStream = new CStringOStream( data->getIfPtr() );
            *pStream = static_cast< INTERFACE_CLI_IO_IOSTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }

inline CLIMETHODIMP(CStringIOStream::createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CStringIStream *pNewStream = new CStringIStream( data->getIfPtr() );
            *pStream = static_cast< INTERFACE_CLI_IO_IISTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }

inline CLIMETHODIMP(CStringIOStream::createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
   {
    CLI_TRY{
            if (!pStream) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStream" );  }
            CStringOStream *pNewStream = new CStringOStream( data->getIfPtr() );
            *pStream = static_cast< INTERFACE_CLI_IO_IOSTREAM* >(pNewStream);
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }


#endif



}; // namespace io
}; // namespace cli




#endif /* CLI_IO_SSTREAMS_H */

