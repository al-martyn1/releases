#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_IPIPE_H
#define CLI_IO_IPIPE_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/io/ipipe.h>", CLI_IO_IPIPE_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IO_IPIPE_H
    #include <cli/io/ipipe.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::io::iPipe */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_IPIPE_IID
    #define INTERFACE_CLI_IO_IPIPE_IID    "/cli/io/iPipe"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iPipe
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_IPIPE
       #define INTERFACE_CLI_IO_IPIPE    ::cli::io::iPipe
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iPipe
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_IPIPE
       #define INTERFACE_CLI_IO_IPIPE    cli_io_iPipe
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iPipe methods */
                CLIMETHOD(initPipe) (THIS_ SYS_PIPE_HANDLE    hRead /* [in] sys_pipe_handle  hRead  */
                                         , SYS_PIPE_HANDLE    hWrite /* [in] sys_pipe_handle  hWrite  */
                                    ) PURE;
                CLIMETHOD(getHandles) (THIS_ SYS_PIPE_HANDLE*    hRead /* [out] sys_pipe_handle hRead  */
                                           , SYS_PIPE_HANDLE*    hWrite /* [out] sys_pipe_handle hWrite  */
                                      ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iPipe >
           {
            static char const * getName() { return INTERFACE_CLI_IO_IPIPE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iPipe* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iPipe > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iPipe wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_IPIPE >
                                          */
                     >
            class CiPipeWrapper
            {
                public:
            
                    typedef  CiPipeWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiPipeWrapper() :
                       pif(0) {}
            
                    CiPipeWrapper( iPipe *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiPipeWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiPipeWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiPipeWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiPipeWrapper(const CiPipeWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiPipeWrapper()  { }
            
                    CiPipeWrapper& operator=(const CiPipeWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE initPipe( SYS_PIPE_HANDLE    hRead /* [in] sys_pipe_handle  hRead  */
                                  , SYS_PIPE_HANDLE    hWrite /* [in] sys_pipe_handle  hWrite  */
                                  )
                       {
                    
                    
                        return pif->initPipe(hRead, hWrite);
                       }
                    
                    RCODE getHandles( SYS_PIPE_HANDLE*    hRead /* [out] sys_pipe_handle hRead  */
                                    , SYS_PIPE_HANDLE*    hWrite /* [out] sys_pipe_handle hWrite  */
                                    )
                       {
                    
                    
                        return pif->getHandles(hRead, hWrite);
                       }
                    

            
            
            }; // class CiPipeWrapper
            
            typedef CiPipeWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_IPIPE     > >  CiPipe;
            typedef CiPipeWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IPIPE > >  CiPipe_nrc; /* No ref counting for interface used */
            typedef CiPipeWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IPIPE > >  CiPipe_tmp; /* for temporary usage, same as CiPipe_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif





#endif /* CLI_IO_IPIPE_H */
