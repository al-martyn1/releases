#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_IO_H
#define CLI_IO_IO_H

/* Add next lines to your C/C++ code
#ifndef CLI_IO_IO_H
    #include <cli/io/io.h>
#endif
*/


#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef CLI_IO_IPIPE_H
    #include <cli/io/ipipe.h>
#endif

#ifndef CLI_IO_ISERIAL_H
    #include <cli/io/iserial.h>
#endif

#ifndef CLI_INET_ISOCK_H
    #include <cli/inet/isock.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif


#ifdef __cplusplus


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


namespace cli
{
namespace io
{
namespace impl
{


struct CConnectionStateWatcher : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                , public INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CConnectionStateWatcher() : base_impl(DEF_MODULE) {}

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP(CConnectionStateWatcher)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER )
    CLI_END_INTERFACE_MAP(CConnectionStateWatcher)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    CLIMETHOD(onConnectingStateEvent) (THIS_ UINT    conState /* [in] ::cli::io::IOConnectingState  conState  */
                          , const CLISTR*     infoStr
                     )
       {
        return onConnectingStateEvent( conState, stdstr(infoStr) );
       }

    // must be implemented in descendants
    CLIMETHOD(onConnectingStateEvent)( UINT conState, const std::wstring &infoStr ) PURE;
/*
// Sample implementation
       {
        switch(conState)
           {
            case CLI_IO_IOCONNECTINGSTATE_ABORTREQUEST:  
                    ::std::cout<<"Connecting to "<<infoStr<<" - abort requested\n";
                    //return EC_ABORT;
                    break;

            case CLI_IO_IOCONNECTINGSTATE_STATECONNECTED:  
                    ::std::cout<<"Stream connected to "<<infoStr<<"\n";
                    break;

            case CLI_IO_IOCONNECTINGSTATE_STATEFAILED:  
                    ::std::cout<<"Failed to connect stream to "<<infoStr<<"\n";
                    break;

            case CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING:  
                    ::std::cout<<"Starting name resolution for "<<infoStr<<"\n";
                    break;

            case CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING:  
                    ::std::cout<<"Name resolution failed for "<<infoStr<<"\n";
                    break;

            case CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING:  
                    ::std::cout<<"Name resolved "<<infoStr<<"\n";
                    break;

            case CLI_IO_IOCONNECTINGSTATE_BEGINCONNECTING:  
                    ::std::cout<<"Connecting to "<<infoStr<<"\n";
                    break;

            case CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING:  
                    ::std::cout<<"Connecting to "<<infoStr<<" failed\n";
                    break;

            case CLI_IO_IOCONNECTINGSTATE_SUCCESSCONNECTING:  
                    ::std::cout<<"Connection established with "<<infoStr<<"\n";
                    break;
           }
        return EC_OK;
       }
*/

}; // struct CConnectionStateWatcher


}; // namespace impl
}; // namespace io
}; // namespace cli

#endif // __cplusplus

#endif /* CLI_IO_IO_H */

