#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IO_COMSCAN_H
#define CLI_IO_COMSCAN_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/io/comscan.h>", CLI_IO_COMSCAN_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IO_COMSCAN_H
    #include <cli/io/comscan.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_ISERIAL_H
    #include <cli/io/iserial.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::io::PortState */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_IO_PORTSTATE               DWORD
#else
    #define ENUM_CLI_IO_PORTSTATE               DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_IO_PORTSTATE_AVAILABLE
    #define CLI_IO_PORTSTATE_AVAILABLE        CONSTANT_DWORD(0)
#endif /* CLI_IO_PORTSTATE_AVAILABLE */

#ifndef CLI_IO_PORTSTATE_INUSE
    #define CLI_IO_PORTSTATE_INUSE            1
#endif /* CLI_IO_PORTSTATE_INUSE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace PortState {
                    const DWORD available        = CONSTANT_DWORD(0);
                    const DWORD inUse            = CONSTANT_DWORD(1);
            }; // namespace PortState
        }; // namespace io
    }; // namespace cli
    /* using namespace ::cli::io::PortState; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::io::PortFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_IO_PORTFLAGS               DWORD
#else
    #define ENUM_CLI_IO_PORTFLAGS               DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_IO_PORTFLAGS_LOCALPORT
    #define CLI_IO_PORTFLAGS_LOCALPORT        CONSTANT_DWORD(0x0001)
#endif /* CLI_IO_PORTFLAGS_LOCALPORT */

#ifndef CLI_IO_PORTFLAGS_NETWORKPORT
    #define CLI_IO_PORTFLAGS_NETWORKPORT      CONSTANT_DWORD(0x0002)
#endif /* CLI_IO_PORTFLAGS_NETWORKPORT */

#ifndef CLI_IO_PORTFLAGS_ONLYDATA
    #define CLI_IO_PORTFLAGS_ONLYDATA         CONSTANT_DWORD(0x0004)
#endif /* CLI_IO_PORTFLAGS_ONLYDATA */

#ifndef CLI_IO_PORTFLAGS_DATAANDCONTROL
    #define CLI_IO_PORTFLAGS_DATAANDCONTROL   CONSTANT_DWORD(0x0008)
#endif /* CLI_IO_PORTFLAGS_DATAANDCONTROL */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            namespace PortFlags {
                    const DWORD localPort        = CONSTANT_DWORD(0x0001);
                    const DWORD networkPort      = CONSTANT_DWORD(0x0002);
                    const DWORD onlyData         = CONSTANT_DWORD(0x0004);
                    const DWORD dataAndControl   = CONSTANT_DWORD(0x0008);
            }; // namespace PortFlags
        }; // namespace io
    }; // namespace cli
    /* using namespace ::cli::io::PortFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::io::CIOPortInfo */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
    #define CLI_STRUCT_NAME                   CIOPortInfo
    #ifndef STRUCT_CLI_IO_CIOPORTINFO_PREDECLARED
    #define STRUCT_CLI_IO_CIOPORTINFO_PREDECLARED
        struct CIOPortInfo;
        #ifndef STRUCT_CLI_IO_CIOPORTINFO
            #define STRUCT_CLI_IO_CIOPORTINFO         ::cli::io::CIOPortInfo
        #endif
    #endif // STRUCT_CLI_IO_CIOPORTINFO_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_io_CIOPortInfo
    #ifndef STRUCT_CLI_IO_CIOPORTINFO_PREDECLARED
    #define STRUCT_CLI_IO_CIOPORTINFO_PREDECLARED
        struct  tag_cli_io_CIOPortInfo;
        typedef struct tag_cli_io_CIOPortInfo cli_io_CIOPortInfo;
        #ifndef STRUCT_CLI_IO_CIOPORTINFO
            #define STRUCT_CLI_IO_CIOPORTINFO         struct tag_cli_io_CIOPortInfo
        #endif
    #endif // STRUCT_CLI_IO_CIOPORTINFO_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_IO_CIOPORTINFO_DEFINED
            #define STRUCT_CLI_IO_CIOPORTINFO_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                ENUM_CLI_IO_PORTSTATE       state;
                PID_T                       ownerPid;
                ENUM_CLI_IO_PORTFLAGS       flags;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_IO_CIOPORTINFO_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::io::iPortFinder */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IO_IPORTFINDER_IID
    #define INTERFACE_CLI_IO_IPORTFINDER_IID    "/cli/io/iPortFinder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace io {
    #define INTERFACE iPortFinder
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IO_IPORTFINDER
       #define INTERFACE_CLI_IO_IPORTFINDER    ::cli::io::iPortFinder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_io_iPortFinder
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IO_IPORTFINDER
       #define INTERFACE_CLI_IO_IPORTFINDER    cli_io_iPortFinder
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::io::iPortFinder methods */
                CLIMETHOD(addrListGet) (THIS_ CLISTR*           _addrList
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       ) PURE;
                CLIMETHOD(addrListSet) (THIS_ const CLISTR*     _addrList
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       ) PURE;
                CLIMETHOD(addrListSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(portsGet) (THIS_ CLISTR*           _ports
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    ) PURE;
                CLIMETHOD(portsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(portHostsGet) (THIS_ CLISTR*           _portHosts
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                CLIMETHOD(portHostsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(portServerNamesGet) (THIS_ CLISTR*           _portServerNames
                                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              ) PURE;
                CLIMETHOD(portServerNamesSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(portsDescriptionGet) (THIS_ CLISTR*           _portsDescription
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               ) PURE;
                CLIMETHOD(portsDescriptionSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(portsInfoGet) (THIS_ STRUCT_CLI_IO_CIOPORTINFO*    _portsInfo /* [out] ::cli::io::CIOPortInfo _portsInfo  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                CLIMETHOD(portsInfoSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(clearAddrList) (THIS) PURE;
                CLIMETHOD(searchForPorts) (THIS_ ENUM_CLI_IO_PORTFLAGS    flags /* [in] ::cli::io::PortFlags  flags  */
                                               , ENUM_CLI_IO_PORTFLAGS*    resFlags /* [out] ::cli::io::PortFlags resFlags  */
                                          ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace io
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::io::iPortFinder >
           {
            static char const * getName() { return INTERFACE_CLI_IO_IPORTFINDER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::io::iPortFinder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::io::iPortFinder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace io {
            // interface ::cli::io::iPortFinder wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_IO_IPORTFINDER >
                                          */
                     >
            class CiPortFinderWrapper
            {
                public:
            
                    typedef  CiPortFinderWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiPortFinderWrapper() :
                       pif(0) {}
            
                    CiPortFinderWrapper( iPortFinder *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiPortFinderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiPortFinderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiPortFinderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiPortFinderWrapper(const CiPortFinderWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiPortFinderWrapper()  { }
            
                    CiPortFinderWrapper& operator=(const CiPortFinderWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_addrList( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = addrListGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_addrList( SIZE_T idx1 , const ::std::wstring &_addrList
                                     )
                       { // MS style - index goes before value, need reorder
                        RCODE res = addrListSet( _addrList, idx1 );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    SIZE_T size_addrList(  )
                       {
                        SIZE_T size;
                        RCODE res = addrListSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, addrList, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE addrListGet( ::std::wstring    &_addrList
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
                       {
                        CCliStr tmp__addrList; CCliStr_init( tmp__addrList );
                    
                        RCODE res = pif->addrListGet(&tmp__addrList, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _addrList, tmp__addrList);
                           }
                        return res;
                       }
                    
                    RCODE addrListSet( const ::std::wstring    &_addrList
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
                       {
                        CCliStr tmp__addrList; CCliStr_lightCopyTo( tmp__addrList, _addrList);
                    
                        return pif->addrListSet(&tmp__addrList, idx1);
                       }
                    
                    RCODE addrListSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->addrListSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_ports( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = portsGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_ports(  )
                       {
                        SIZE_T size;
                        RCODE res = portsSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, ports, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE portsGet( ::std::wstring    &_ports
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
                       {
                        CCliStr tmp__ports; CCliStr_init( tmp__ports );
                    
                        RCODE res = pif->portsGet(&tmp__ports, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _ports, tmp__ports);
                           }
                        return res;
                       }
                    
                    RCODE portsSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->portsSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_portHosts( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = portHostsGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_portHosts(  )
                       {
                        SIZE_T size;
                        RCODE res = portHostsSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, portHosts, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE portHostsGet( ::std::wstring    &_portHosts
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                       {
                        CCliStr tmp__portHosts; CCliStr_init( tmp__portHosts );
                    
                        RCODE res = pif->portHostsGet(&tmp__portHosts, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _portHosts, tmp__portHosts);
                           }
                        return res;
                       }
                    
                    RCODE portHostsSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->portHostsSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_portServerNames( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = portServerNamesGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_portServerNames(  )
                       {
                        SIZE_T size;
                        RCODE res = portServerNamesSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, portServerNames, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE portServerNamesGet( ::std::wstring    &_portServerNames
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            )
                       {
                        CCliStr tmp__portServerNames; CCliStr_init( tmp__portServerNames );
                    
                        RCODE res = pif->portServerNamesGet(&tmp__portServerNames, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _portServerNames, tmp__portServerNames);
                           }
                        return res;
                       }
                    
                    RCODE portServerNamesSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->portServerNamesSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_portsDescription( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = portsDescriptionGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_portsDescription(  )
                       {
                        SIZE_T size;
                        RCODE res = portsDescriptionSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, portsDescription, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE portsDescriptionGet( ::std::wstring    &_portsDescription
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
                       {
                        CCliStr tmp__portsDescription; CCliStr_init( tmp__portsDescription );
                    
                        RCODE res = pif->portsDescriptionGet(&tmp__portsDescription, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _portsDescription, tmp__portsDescription);
                           }
                        return res;
                       }
                    
                    RCODE portsDescriptionSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->portsDescriptionSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    STRUCT_CLI_IO_CIOPORTINFO get_portsInfo( SIZE_T idx1 )
                       {
                        STRUCT_CLI_IO_CIOPORTINFO tmpVal;
                        RCODE res = portsInfoGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_portsInfo(  )
                       {
                        SIZE_T size;
                        RCODE res = portsInfoSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, STRUCT_CLI_IO_CIOPORTINFO, portsInfo, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE portsInfoGet( STRUCT_CLI_IO_CIOPORTINFO    &_portsInfo /* [out] ::cli::io::CIOPortInfo _portsInfo  (struct passed by ref in wrapper) */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                       {
                    
                    
                        return pif->portsInfoGet(&_portsInfo, idx1);
                       }
                    
                    RCODE portsInfoSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->portsInfoSize(_size);
                       }
                    
                    RCODE clearAddrList( )
                       {
                        return pif->clearAddrList();
                       }
                    
                    RCODE searchForPorts( ENUM_CLI_IO_PORTFLAGS    flags /* [in] ::cli::io::PortFlags  flags  */
                                        , ENUM_CLI_IO_PORTFLAGS*    resFlags /* [out] ::cli::io::PortFlags resFlags  */
                                        )
                       {
                    
                    
                        return pif->searchForPorts(flags, resFlags);
                       }
                    

            
            
            }; // class CiPortFinderWrapper
            
            typedef CiPortFinderWrapper< ::cli::CCliPtr< INTERFACE_CLI_IO_IPORTFINDER     > >  CiPortFinder;
            typedef CiPortFinderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IPORTFINDER > >  CiPortFinder_nrc; /* No ref counting for interface used */
            typedef CiPortFinderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IO_IPORTFINDER > >  CiPortFinder_tmp; /* for temporary usage, same as CiPortFinder_nrc */
            
            
            
            
            
        }; // namespace io
    }; // namespace cli

#endif





#endif /* CLI_IO_COMSCAN_H */
