#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_PTHCSEC_H
#define CLI_PTHCSEC_H

/* add this lines to your src
#ifndef CLI_PTHCSEC_H
    #include <cli/pthcsec.h>
#endif
*/

#include <pthread.h>

// int pthread_spin_destroy(pthread_spinlock_t *lock);
// int pthread_spin_init(pthread_spinlock_t *lock, int pshared);
// pshared is PTHREAD_PROCESS_PRIVATE
//int pthread_spin_lock(pthread_spinlock_t *lock);
//int pthread_spin_trylock(pthread_spinlock_t *lock);
//int pthread_spin_unlock(pthread_spinlock_t *lock);




namespace cli
{
// some implementations based on pthread
namespace pth
{

// UNDONE: need to be implemented
class CSpinLock
{
        //mutable pthread_spinlock_t  spinlock;

    public:

        CSpinLock(unsigned argSpinCount = 0, bool forceSingleCpu = false) // params used for compatibility with sleep-driven critical section
           //: spinlock()
           {
            //pthread_spin_init( &spinlock, PTHREAD_PROCESS_PRIVATE );
           }

        ~CSpinLock()
           {
            //if (pthread_spin_destroy(&spinlock) == EBUSY)
            //   throw ::std::runtime_error("~cli::pth::CSpinLock - can't destory non-released object");
           }

    private:

        CSpinLock(const CSpinLock&);
        CSpinLock& operator=(const CSpinLock&);

    public:

        bool tryLock() const
           {
            //if (pthread_spin_trylock(&spinlock)==0) return true; // spin locked by as, need to be unlocked
            //return false; // spin locked by another thread or other err
            return false;
           }

        void lock()    const
           {
            //if (pthread_spin_lock(&spinlock)==0)
           }

        void unlock()  const
           {}

};


// pthread_mutex_lock
// pthread_mutex_unlock
// pthread_mutex_trylock
// pthread_mutex_init
// pthread_mutex_destroy
// pthread_mutexattr_init
// pthread_mutexattr_destroy
// pthread_mutexattr_setpshared
class CMutexLock
{
        //mutable pthread_spinlock_t  spinlock;
        mutable  pthread_mutex_t mux;

    public:

        CMutexLock(unsigned argSpinCount = 0, bool forceSingleCpu = false) // params used for compatibility with sleep-driven critical section
           //: spinlock()
           {
            pthread_mutexattr_t muxAttr;
            pthread_mutexattr_init( &muxAttr );
            pthread_mutexattr_settype( &muxAttr, PTHREAD_MUTEX_RECURSIVE );

            #if defined(PTHREAD_PROCESS_PRIVATE) && !defined(CLI_PTH_CMUTEXLOCK_USE_DEFAULT_PTHREAD_PROCESS_PRIVATE)
            pthread_mutexattr_setpshared( &muxAttr, PTHREAD_PROCESS_PRIVATE );
            #endif

            pthread_mutex_init( &mux, &muxAttr );
            pthread_mutexattr_destroy( &muxAttr );
           }

        ~CMutexLock()
           {
            if (pthread_mutex_destroy(&mux)==EBUSY)
               throw ::std::runtime_error("~cli::pth::CMutexLock - can't destory non-released object");
           }

    private:

        CMutexLock(const CMutexLock&);
        CMutexLock& operator=(const CMutexLock&);

    public:

        bool tryLock() const
           {
            if (pthread_mutex_trylock(&mux)==0) return true; // mutex is free or locked by as, need to be unlocked
            // owned by another thread
            return false; // no unlock required
           }

        void lock()    const
           {
            pthread_mutex_lock(&mux);
           }

        void unlock()  const
           {
            pthread_mutex_unlock(&mux);
           }

};






}; // namespace pth
}; // namespace cli


#endif /* CLI_PTHCSEC_H */
