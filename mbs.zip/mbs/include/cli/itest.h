#ifndef CLI_ITEST_H
#define CLI_ITEST_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/itest.h>", CLI_ITEST_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_ITEST_H
    #include <cli/itest.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::iGlobalTest */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_IGLOBALTEST_IID
    #define INTERFACE_IGLOBALTEST_IID    "/iGlobalTest"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define INTERFACE iGlobalTest
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_IGLOBALTEST
       #define INTERFACE_IGLOBALTEST    ::iGlobalTest
    #endif
#else /* C-like declaration */
    #define INTERFACE iGlobalTest
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_IGLOBALTEST
       #define INTERFACE_IGLOBALTEST    iGlobalTest
    #endif
#endif

    CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
    {
        
        /* interface ::cli::iUnknown methods */
        CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                       , VOID**    ifPtr /* [out] void* ifPtr  */
                                  ) PURE;
        CLIMETHOD_(ULONG, addRef) (THIS) PURE;
        CLIMETHOD_(ULONG, release) (THIS) PURE;
        
        /* interface ::iGlobalTest methods */
        CLIMETHOD(testMethod) (THIS) PURE;
    };

#if defined(__cplusplus) && !defined(CINTERFACE)


    namespace cli{
        template<> struct CIidOfImpl< ::iGlobalTest >
           {
            static char const * getName() { return INTERFACE_IGLOBALTEST_IID; }
           };
        template<> struct CIidOfImpl< ::iGlobalTest* >
           {
            static char const * getName() { return CIidOfImpl< ::iGlobalTest > :: getName(); }
           };
    }; // namespace cli

    // interface ::iGlobalTest wrapper
    // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
    template <
              typename smartPtrType
                                  /*
                                  =
                                      ::cli::CCliPtr< INTERFACE_IGLOBALTEST >
                                  */
             >
    class CiGlobalTestWrapper
    {
        public:
    
            typedef  CiGlobalTestWrapper< smartPtrType >           wrapper_type;
            typedef  typename smartPtrType::interface_type              interface_type;
            typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
            typedef  typename smartPtrType::pointer_type                pointer_type;
    
        protected:
    
            // pointer to interface variable name
            // allways must be pif - autogeneration depends on this name
            smartPtrType                pif;
    
        public:
    
            CiGlobalTestWrapper() :
               pif(0) {}
    
            CiGlobalTestWrapper( iGlobalTest *_pi, bool noAddRef=false) :
               pif(_pi, noAddRef)
              { }
    
            operator bool() const { return bool(pif); }
            bool operator!() const { return pif.operator!(); }
            interface_pointer_type* getPP() { return pif.getPP(); }
    
            interface_pointer_type getIfPtr()
               {
                interface_pointer_type* ptrPtr = pif.getPP();
                if (!ptrPtr) return 0;
                return *ptrPtr;
               }
    
            void release()
               {
                pif.release();
               }
    
            CiGlobalTestWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
               pif(0)
              {
               RCODE res = pif.createObject( componentId, pOuter );
               if (RC_FAIL(res))
                  throw ::std::runtime_error("Failed to create requiested component");
              }
    
            CiGlobalTestWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
               pif(0)
              {
               if (componentId.empty())
                  throw ::std::runtime_error("Empty component name taken");
               RCODE res = pif.createObject( componentId.c_str(), pOuter );
               if (RC_FAIL(res))
                  throw ::std::runtime_error("Failed to create requiested component");
              }
    
           CiGlobalTestWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
               pif(0)
              {
               ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
               RCODE res = tmpPtr.queryInterface(pif);
               if (RC_FAIL(res))
                  throw ::std::runtime_error("Requested interface not supported by object");
              }
    
            CiGlobalTestWrapper(const CiGlobalTestWrapper &i) :
                pif(i.pif) { }
    
            ~CiGlobalTestWrapper()  { }
    
            CiGlobalTestWrapper& operator=(const CiGlobalTestWrapper &i)
               {
                if (&i!=this) pif = i.pif;
                return *this;
               }
    
            template <typename T>
            RCODE queryInterface( T **t)
              {
               return pif.queryInterface(t);
              }
    
            template <typename T>
            RCODE queryInterface( T &t)
              {
               t.release();
               return pif.queryInterface(t.getPP());
              }
    
            RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
               {
                return pif.createObject(componentId, pOuter);
               }
    
    
            // Automaticaly generated methods code goes here
    
            RCODE testMethod( )
               {
                return pif->testMethod();
               }
            

    
    
    }; // class CiGlobalTestWrapper
    
    typedef CiGlobalTestWrapper< ::cli::CCliPtr< INTERFACE_IGLOBALTEST     > >  CiGlobalTest;
    typedef CiGlobalTestWrapper< ::cli::CFoolishPtr< INTERFACE_IGLOBALTEST > >  CiGlobalTest_nrc; /* No ref counting for interface used */
    typedef CiGlobalTestWrapper< ::cli::CFoolishPtr< INTERFACE_IGLOBALTEST > >  CiGlobalTest_tmp; /* for temporary usage, same as CiGlobalTest_nrc */
    
    
    
    
    

#endif






/* ------------------------------------------------------ */
/* Interface: ::iGlobalTestNoWrapper */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_IGLOBALTESTNOWRAPPER_IID
    #define INTERFACE_IGLOBALTESTNOWRAPPER_IID    "/iGlobalTestNoWrapper"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define INTERFACE iGlobalTestNoWrapper
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_IGLOBALTESTNOWRAPPER
       #define INTERFACE_IGLOBALTESTNOWRAPPER    ::iGlobalTestNoWrapper
    #endif
#else /* C-like declaration */
    #define INTERFACE iGlobalTestNoWrapper
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_IGLOBALTESTNOWRAPPER
       #define INTERFACE_IGLOBALTESTNOWRAPPER    iGlobalTestNoWrapper
    #endif
#endif

    CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
    {
        
        /* interface ::cli::iUnknown methods */
        CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                       , VOID**    ifPtr /* [out] void* ifPtr  */
                                  ) PURE;
        CLIMETHOD_(ULONG, addRef) (THIS) PURE;
        CLIMETHOD_(ULONG, release) (THIS) PURE;
        
        /* interface ::iGlobalTestNoWrapper methods */
        CLIMETHOD(testMethod) (THIS) PURE;
    };

#if defined(__cplusplus) && !defined(CINTERFACE)


    namespace cli{
        template<> struct CIidOfImpl< ::iGlobalTestNoWrapper >
           {
            static char const * getName() { return INTERFACE_IGLOBALTESTNOWRAPPER_IID; }
           };
        template<> struct CIidOfImpl< ::iGlobalTestNoWrapper* >
           {
            static char const * getName() { return CIidOfImpl< ::iGlobalTestNoWrapper > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif






/* ------------------------------------------------------ */
/* Interface: ::iGlobalTestFree */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifndef INTERFACE_IGLOBALTESTFREE_IID
    #define INTERFACE_IGLOBALTESTFREE_IID    "/iGlobalTestFree"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define INTERFACE iGlobalTestFree
    #ifndef INTERFACE_IGLOBALTESTFREE
       #define INTERFACE_IGLOBALTESTFREE    ::iGlobalTestFree
    #endif
#else /* C-like declaration */
    #define INTERFACE iGlobalTestFree
    #ifndef INTERFACE_IGLOBALTESTFREE
       #define INTERFACE_IGLOBALTESTFREE    iGlobalTestFree
    #endif
#endif

    CLI_DECLARE_INTERFACE(INTERFACE)
    {
        
        /* interface ::iGlobalTestFree methods */
        CLIMETHOD(testMethod) (THIS) PURE;
    };

#if defined(__cplusplus) && !defined(CINTERFACE)

    // interface ::iGlobalTestFree wrapper
    // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
    template <
              typename smartPtrType
                                  /*
                                  =
                                      ::cli::CFoolishPtr< INTERFACE_IGLOBALTESTFREE >
                                  */
             >
    class CiGlobalTestFreeWrapper
    {
        public:
    
            typedef  CiGlobalTestFreeWrapper< smartPtrType >           wrapper_type;
            typedef  typename smartPtrType::interface_type              interface_type;
            typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
            typedef  typename smartPtrType::pointer_type                pointer_type;
    
        protected:
    
            // pointer to interface variable name
            // allways must be pif - autogeneration depends on this name
            smartPtrType                pif;
    
        public:
    
            CiGlobalTestFreeWrapper() :
               pif(0) {}
    
            CiGlobalTestFreeWrapper( iGlobalTestFree *_pi, bool noAddRef=false) :
               pif(_pi, noAddRef)
              { }
    
            operator bool() const { return bool(pif); }
            bool operator!() const { return pif.operator!(); }
            interface_pointer_type* getPP() { return pif.getPP(); }
    
            interface_pointer_type getIfPtr()
               {
                interface_pointer_type* ptrPtr = pif.getPP();
                if (!ptrPtr) return 0;
                return *ptrPtr;
               }
    
            void release()
               {
                pif.release();
               }
    
    
            CiGlobalTestFreeWrapper(const CiGlobalTestFreeWrapper &i) :
                pif(i.pif) { }
    
            ~CiGlobalTestFreeWrapper()  { }
    
            CiGlobalTestFreeWrapper& operator=(const CiGlobalTestFreeWrapper &i)
               {
                if (&i!=this) pif = i.pif;
                return *this;
               }
    
    
    
            // Automaticaly generated methods code goes here
    
            RCODE testMethod( )
               {
                return pif->testMethod();
               }
            

    
    
    }; // class CiGlobalTestFreeWrapper
    
    typedef CiGlobalTestFreeWrapper< ::cli::CCliPtr< INTERFACE_IGLOBALTESTFREE     > >  CiGlobalTestFree;
    typedef CiGlobalTestFreeWrapper< ::cli::CFoolishPtr< INTERFACE_IGLOBALTESTFREE > >  CiGlobalTestFree_nrc; /* No ref counting for interface used */
    typedef CiGlobalTestFreeWrapper< ::cli::CFoolishPtr< INTERFACE_IGLOBALTESTFREE > >  CiGlobalTestFree_tmp; /* for temporary usage, same as CiGlobalTestFree_nrc */
    
    
    
    
    

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iTest */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITEST_IID
    #define INTERFACE_CLI_ITEST_IID    "/cli/iTest"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTest
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ITEST
       #define INTERFACE_CLI_ITEST    ::cli::iTest
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTest
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ITEST
       #define INTERFACE_CLI_ITEST    cli_iTest
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iTest methods */
            CLIMETHOD(testMethod) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTest >
           {
            static char const * getName() { return INTERFACE_CLI_ITEST_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTest* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTest > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iTest wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ITEST >
                                      */
                 >
        class CiTestWrapper
        {
            public:
        
                typedef  CiTestWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestWrapper() :
                   pif(0) {}
        
                CiTestWrapper( iTest *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTestWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTestWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTestWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTestWrapper(const CiTestWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestWrapper()  { }
        
                CiTestWrapper& operator=(const CiTestWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE testMethod( )
                   {
                    return pif->testMethod();
                   }
                

        
        
        }; // class CiTestWrapper
        
        typedef CiTestWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITEST     > >  CiTest;
        typedef CiTestWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITEST > >  CiTest_nrc; /* No ref counting for interface used */
        typedef CiTestWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITEST > >  CiTest_tmp; /* for temporary usage, same as CiTest_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iTestNoWrapper */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITESTNOWRAPPER_IID
    #define INTERFACE_CLI_ITESTNOWRAPPER_IID    "/cli/iTestNoWrapper"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTestNoWrapper
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ITESTNOWRAPPER
       #define INTERFACE_CLI_ITESTNOWRAPPER    ::cli::iTestNoWrapper
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTestNoWrapper
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ITESTNOWRAPPER
       #define INTERFACE_CLI_ITESTNOWRAPPER    cli_iTestNoWrapper
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iTestNoWrapper methods */
            CLIMETHOD(testMethod) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTestNoWrapper >
           {
            static char const * getName() { return INTERFACE_CLI_ITESTNOWRAPPER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTestNoWrapper* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTestNoWrapper > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iTestFree */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifndef INTERFACE_CLI_ITESTFREE_IID
    #define INTERFACE_CLI_ITESTFREE_IID    "/cli/iTestFree"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTestFree
    #ifndef INTERFACE_CLI_ITESTFREE
       #define INTERFACE_CLI_ITESTFREE    ::cli::iTestFree
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTestFree
    #ifndef INTERFACE_CLI_ITESTFREE
       #define INTERFACE_CLI_ITESTFREE    cli_iTestFree
    #endif
#endif

        CLI_DECLARE_INTERFACE(INTERFACE)
        {
            
            /* interface ::cli::iTestFree methods */
            CLIMETHOD(testMethod) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

        // interface ::cli::iTestFree wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CFoolishPtr< INTERFACE_CLI_ITESTFREE >
                                      */
                 >
        class CiTestFreeWrapper
        {
            public:
        
                typedef  CiTestFreeWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestFreeWrapper() :
                   pif(0) {}
        
                CiTestFreeWrapper( iTestFree *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
        
                CiTestFreeWrapper(const CiTestFreeWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestFreeWrapper()  { }
        
                CiTestFreeWrapper& operator=(const CiTestFreeWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
        
        
                // Automaticaly generated methods code goes here
        
                RCODE testMethod( )
                   {
                    return pif->testMethod();
                   }
                

        
        
        }; // class CiTestFreeWrapper
        
        typedef CiTestFreeWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITESTFREE     > >  CiTestFree;
        typedef CiTestFreeWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITESTFREE > >  CiTestFree_nrc; /* No ref counting for interface used */
        typedef CiTestFreeWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITESTFREE > >  CiTestFree_tmp; /* for temporary usage, same as CiTestFree_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_ITEST_H */
