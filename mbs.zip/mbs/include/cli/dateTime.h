#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DATETIME_H
#define CLI_DATETIME_H

/*
#ifndef CLI_DATETIME_H
    #include <cli/dateTime.h>
#endif
*/

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#if !defined(_INC_TIME) && !defined(_TIME_H_) && !defined(_TIME_H)
    #include <time.h>
#endif

#if !defined(_WIN32) && !defined(_WIN32)
    #include <sys/time.h>
#endif


#ifdef __cplusplus

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif


#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

/*
#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif
*/

// for testing Linux bahavior under Windows
// #define CLI_TIME_USE_POSIX_TIME

namespace cli
{

namespace datetime_util
{

    SHORT getUtcCurrentOffset();


    #if defined(_WIN32) || defined(WIN32)
    inline
    STRUCT_CLI_CLISYSTEMTIME win32ToCliSystemtime( const SYSTEMTIME &st )
       {
        STRUCT_CLI_CLISYSTEMTIME res;
        res.year      = st.wYear;
        res.month     = st.wMonth;
        res.dayOfWeek = st.wDayOfWeek;
        res.day       = st.wDay;
        res.hour      = st.wHour;
        res.minute    = st.wMinute;
        res.second    = st.wSecond;
        res.microsec  = 1000*(DWORD)(st.wMilliseconds);
        res.gmOffset  = 0;

        // fix Sunday
        if (!res.dayOfWeek) res.dayOfWeek = 6;
        else --res.dayOfWeek;

        return res;
       }

    inline
    SYSTEMTIME cliToWin32Systemtime( const STRUCT_CLI_CLISYSTEMTIME &st)
       {
        SYSTEMTIME res;
        res.wYear         = st.year     ;
        res.wMonth        = st.month    ;
        res.wDayOfWeek    = st.dayOfWeek;
        res.wDay          = st.day      ;
        res.wHour         = st.hour     ;
        res.wMinute       = st.minute   ;
        res.wSecond       = st.second   ;
        res.wMilliseconds = (WORD)(st.microsec/1000);

        // fix Sunday
        if (res.wDayOfWeek==6) res.wDayOfWeek = 0;
        else ++res.wDayOfWeek;

        return res;
       }

    inline
    STRUCT_CLI_CLISYSTEMTIME win32FiletimeToCliSystemtime( FILETIME ft )
       {
        SYSTEMTIME st;
        if (!::FileTimeToSystemTime( &ft, &st ))
           {
            //RCODE err = WIN2RC(::GetLastError());
            //CLI_THROW( err );
            throw ::std::runtime_error("win32FiletimeToCliSystemtime: FileTimeToSystemTime failed");
           }

        STRUCT_CLI_CLISYSTEMTIME res = win32ToCliSystemtime(st);
        ULARGE_INTEGER ul;
        ul.LowPart   = ft.dwLowDateTime;
        ul.HighPart  = ft.dwHighDateTime;
        res.microsec = (DWORD)((ul.QuadPart/10)%1000000);
        return res;
       }

    inline
    FILETIME cliSystemtimeToWin32Filetime( const STRUCT_CLI_CLISYSTEMTIME &cliSt )
       {
        SYSTEMTIME st = cliToWin32Systemtime( cliSt );
        st.wMilliseconds = 0;
        FILETIME ft;
        if (!::SystemTimeToFileTime(&st, &ft))
           {
            //RCODE err = WIN2RC(::GetLastError());
            //CLI_THROW( err );
            throw ::std::runtime_error("cliSystemtimeToWin32Filetime: SystemTimeToFileTime failed");
           }
        //ft += cliSt.microsec*10;
        ULARGE_INTEGER ul;
        ul.LowPart   = ft.dwLowDateTime;
        ul.HighPart  = ft.dwHighDateTime;
        ul.QuadPart += cliSt.microsec*10;
        ft.dwLowDateTime  = ul.LowPart;
        ft.dwHighDateTime = ul.HighPart;
        return ft;
       }

    #ifndef CLI_TIME_USE_POSIX_TIME
    inline
    CLI_TIME_T cliSystemtimeToCliTime( const STRUCT_CLI_CLISYSTEMTIME &cliSt )
       {
        FILETIME ft = cliSystemtimeToWin32Filetime(cliSt);
        ULARGE_INTEGER ul;
        ul.LowPart   = ft.dwLowDateTime;
        ul.HighPart  = ft.dwHighDateTime;
        return ul.QuadPart / 10;
       }

    inline
    STRUCT_CLI_CLISYSTEMTIME cliTimeToCliSystemtime( CLI_TIME_T ct )
       {
        ULARGE_INTEGER ul;
        ul.QuadPart = ct*10;
        FILETIME ft;
        ft.dwLowDateTime  = ul.LowPart ;
        ft.dwHighDateTime = ul.HighPart;
        return win32FiletimeToCliSystemtime( ft );
       }
    #endif

    inline
    CLI_TIME_T win32FiletimeToCliTime( FILETIME ft )
       {
        ULARGE_INTEGER ul;
        ul.LowPart   = ft.dwLowDateTime;
        ul.HighPart  = ft.dwHighDateTime;
        return ul.QuadPart / 10;
       }

    inline
    FILETIME win32FiletimeToCliTime( CLI_TIME_T ct )
       {
        ULARGE_INTEGER ul;
        ul.QuadPart = ct;
        ul.QuadPart *= 10;
        FILETIME ft;
        ft.dwLowDateTime  = ul.LowPart ;
        ft.dwHighDateTime = ul.HighPart;
        return ft;
       }

    inline // UTC
    STRUCT_CLI_CLISYSTEMTIME now()
       {
        SYSTEMTIME st;
        ::GetSystemTime( &st );
        return win32ToCliSystemtime(st);
       }

    SHORT getUtcCurrentOffset();

    inline // Local
    STRUCT_CLI_CLISYSTEMTIME localNow()
       {
        SYSTEMTIME st;
        ::GetLocalTime( &st );
        STRUCT_CLI_CLISYSTEMTIME res = win32ToCliSystemtime(st);
        res.gmOffset = getUtcCurrentOffset();
        return res;
       }

    inline
    SHORT getUtcCurrentOffset()
       {
        TIME_ZONE_INFORMATION tzInfo;
        DWORD res = GetTimeZoneInformation( &tzInfo );
        if (res==TIME_ZONE_ID_INVALID) return 0;
        else if (res==TIME_ZONE_ID_STANDARD)
           return -(SHORT)(tzInfo.Bias + tzInfo.StandardBias);
        else if (res==TIME_ZONE_ID_DAYLIGHT)
           return -(SHORT)(tzInfo.Bias+tzInfo.DaylightBias);
        return -(SHORT)tzInfo.Bias;
       }

    #endif // WIN32


    inline
    STRUCT_CLI_CLISYSTEMTIME unixTmToCliSystemtime( const struct tm &st )
       {
        STRUCT_CLI_CLISYSTEMTIME res;
        res.year      = st.tm_year;     res.year += 1900;
        res.month     = st.tm_mon;      ++res.month;
        res.dayOfWeek = st.tm_wday;
        res.day       = st.tm_mday;
        res.hour      = st.tm_hour;
        res.minute    = st.tm_min;
        res.second    = st.tm_sec;
        res.microsec  = 0;
        res.gmOffset  = 0;

        // fix Sunday
        if (!res.dayOfWeek) res.dayOfWeek = 6;
        else --res.dayOfWeek;

        return res;
       }

    inline
    struct tm cliSystemTimeToUnixTm( const STRUCT_CLI_CLISYSTEMTIME &ct)
       {
        struct tm st;
        st.tm_year =  ct.year     - 1900;
        st.tm_mon  =  ct.month    - 1;
        st.tm_wday =  ct.dayOfWeek;
        st.tm_mday =  ct.day      ;
        st.tm_hour =  ct.hour     ;
        st.tm_min  =  ct.minute   ;
        st.tm_sec  =  ct.second   ;
        st.tm_yday = 0;
        st.tm_isdst = 0;
        // fix Sunday
        if (st.tm_wday==6) st.tm_wday = 0;
        else ++st.tm_wday;
        return st;
       }

    #if !defined(_WIN32) && !defined(WIN32)
    inline
    time_t struct_tm_to_time_t( const struct tm &ut )
       {
        #ifdef CLI_TIME_NO_GNU_TIMEGM
        time_t ret;
        char *tz;

        tz = getenv("TZ");
        setenv("TZ", "", 1);
        tzset();
        ret = mktime(&ut);
        if (tz)
            setenv("TZ", tz, 1);
        else
            unsetenv("TZ");
        tzset();
        return ret;
        #else
        // #define CLI_TIME_NO_GNU_TIMEGM
        // if there is no timegm function, define macro above for project
        struct tm tmp = ut;
        return timegm(&tmp);
        #endif
       }
    #endif

    inline
    time_t cliSystemTimeToUnixTime(const STRUCT_CLI_CLISYSTEMTIME &ct)
       {
        struct tm ut = cliSystemTimeToUnixTm(ct);
        #if !defined(_WIN32) && !defined(WIN32)
        //struct timezone tz; tz.tz_minuteswest = 0; tz.tz_dsttime = 0;
        //gettimeofday( 0, &tz );
        //return mktime( &ut ); // - 60*tz.tz_minuteswest; // + 60*((CLI_STIME_T)getUtcCurrentOffset()); // reenterable
        return struct_tm_to_time_t(ut);
        #else // WIN32
            #if defined(_MSC_VER) && _MSC_VER>=1400
            return _mkgmtime( &ut );
            #else
            //struct timezone tz; tz.tz_minuteswest = 0; tz.tz_dsttime = 0;
            //gettimeofday( 0, &tz );
            return mktime( &ut );// + 60*tz.tz_minuteswest; // + 60*((CLI_STIME_T)getUtcCurrentOffset());
            #endif
        #endif
       }

    #if !defined(_WIN32) && !defined(WIN32)
    inline
    struct timeval cliSystemTimeToUnixTimeval(const STRUCT_CLI_CLISYSTEMTIME &ct)
       {
        struct timeval tv;
        tv.tv_sec  = cliSystemTimeToUnixTime( ct );
        tv.tv_usec = ct.microsec;
        return tv;
       }
    #endif

    inline
    STRUCT_CLI_CLISYSTEMTIME unixTimeToCliSystemtime( time_t t )
       {
        #if defined(_WIN32) || defined(WIN32)
            #if defined(_MSC_VER) && _MSC_VER>=1400
                struct tm ut;
                #ifdef _USE_32BIT_TIME_T
                errno_t err = _gmtime32_s( &ut, &t );
                #else
                errno_t err = _gmtime64_s( &ut, &t );
                #endif
                if (err)
                   {
                    //CLI_THROW(POSIX2RC(err));
                    throw ::std::runtime_error("unixTimeToCliSystemtime: _gmtime_s failed");
                   }
            #else // !_MSC_VER
                static ::cli::CCriticalSection cs;
                struct tm ut;
                {
                 CLI_SCOPED_LOCK(cs);
                 struct tm *pUt = gmtime( &t );
                 if (!pUt)
                    {
                     //CLI_THROW(POSIX2RC(EINVAL));
                     throw ::std::runtime_error("unixTimeToCliSystemtime: gmtime failed");
                    }
                 ut  = *pUt;
                }
            #endif
        #else // !WIN32
            struct tm ut;
            struct tm *pUt = gmtime_r( &t, &ut );
            if (!pUt)
               {
                //CLI_THROW(POSIX2RC(EINVAL));
                throw ::std::runtime_error("unixTimeToCliSystemtime: gmtime_r failed");
               }
        #endif

        return unixTmToCliSystemtime( ut );
       }

    #if !defined(_WIN32) && !defined(WIN32)
    inline
    STRUCT_CLI_CLISYSTEMTIME unixTimevalToCliSystemtime( const struct timeval &tv )
       {
        STRUCT_CLI_CLISYSTEMTIME ct = unixTimeToCliSystemtime( tv.tv_sec );
        ct.microsec = tv.tv_usec;
        return ct;
       }
    #endif

    inline
    STRUCT_CLI_CLISYSTEMTIME unixTimeToCliSystemtimeLocal( time_t t )
       {
        #if defined(_WIN32) || defined(WIN32)
            #if defined(_MSC_VER) && _MSC_VER>=1400
                struct tm ut;
                #ifdef _USE_32BIT_TIME_T
                errno_t err = _localtime32_s( &ut, &t );
                #else
                errno_t err = _localtime64_s( &ut, &t );
                #endif
                if (err)
                   {
                    //CLI_THROW(POSIX2RC(err));
                    throw ::std::runtime_error("unixTimeToCliSystemtimeLocal: _localtime_s failed");
                   }
            #else // !_MSC_VER
                static ::cli::CCriticalSection cs;
                struct tm ut;
                {
                 CLI_SCOPED_LOCK(cs);
                 struct tm *pUt = localtime( &t );
                 if (!pUt)
                    {
                     //CLI_THROW(POSIX2RC(EINVAL));
                     throw ::std::runtime_error("unixTimeToCliSystemtimeLocal: localtime failed");
                    }
                 ut = *pUt;
                }
            #endif
        #else // !WIN32
            struct tm ut;
            struct tm *pUt = localtime_r( &t, &ut );
            if (!pUt)
               {
                //CLI_THROW(POSIX2RC(EINVAL));
                throw ::std::runtime_error("unixTimeToCliSystemtimeLocal: localtime_r failed");
               }
        #endif

        return unixTmToCliSystemtime( ut );
       }

    #if !defined(_WIN32) && !defined(WIN32)
    inline
    STRUCT_CLI_CLISYSTEMTIME unixTimevalToCliSystemtimeLocal( const struct timeval &tv )
       {
        STRUCT_CLI_CLISYSTEMTIME ct = unixTimeToCliSystemtimeLocal( tv.tv_sec );
        ct.microsec = tv.tv_usec;
        return ct;
       }
    #endif

/*
 #include <sys/time.h>
       #include <time.h>

       int gettimeofday(struct timeval *tv, struct timezone *tz);
       int settimeofday(const struct timeval *tv , const struct timezone *tz);

         struct timeval {
             time_t      tv_sec;     // seconds
             suseconds_t tv_usec;    // microseconds
         };

       and gives the number of seconds and microseconds since the Epoch (see time(2)).  The tz argument is a struct timezone:

         struct timezone {
             int tz_minuteswest;     // minutes west of Greenwich
             int tz_dsttime;         // type of DST correction
         };
*/


    // 1240428288 - invalid
      const CLI_UTIME_T unixEpochShift = 11644473600ull;
    //const CLI_UTIME_T unixEpochShift =  1240428288ull;
    //const CLI_UTIME_T unixEpochShift =  1740428288ull;

    inline
    CLI_TIME_T unixTimeToCliTime( time_t t )
       {
        CLI_UTIME_T res = (CLI_UTIME_T)t;
        //CLI_TIME_T add = 1240428288;
        res += (CLI_UTIME_T)unixEpochShift;
        res *= 1000000;
        return (CLI_TIME_T)res;
       }

    #if !defined(_WIN32) && !defined(WIN32)
    inline
    CLI_TIME_T unixTimevalToCliTime( const struct timeval &tv )
       {
        CLI_UTIME_T res = (CLI_UTIME_T)unixTimeToCliTime(tv.tv_sec);
        //res += unixEpochShift;
        //res *= 1000000;
        res += (CLI_UTIME_T)tv.tv_usec;
        return (CLI_TIME_T)res;
       }
    #endif

    inline
    time_t cliTimeToUnixTime( CLI_TIME_T t )
       {
        CLI_UTIME_T tmp = (CLI_UTIME_T)t;
        tmp /= 1000000;
        //CLI_TIME_T sub = 1240428288;
        tmp -= (CLI_UTIME_T)unixEpochShift;
        return (time_t)tmp;
       }

    #if !defined(_WIN32) && !defined(WIN32)
    inline
    struct timeval cliTimeToUnixTimeval( CLI_TIME_T t )
       {
        struct timeval tv;
        tv.tv_sec = cliTimeToUnixTime( t );
        //tv.tv_sec  = (time_t)(((CLI_UTIME_T)(t)) / 1000000);
        tv.tv_usec = (suseconds_t)(((CLI_UTIME_T)(t)) % 1000000);
        //CLI_TIME_T sub = 1240428288;
        //tv.tv_sec += (CLI_UTIME_T)unixEpochShift;
        return tv;
       }
    #endif

    #if (!defined(_WIN32) && !defined(WIN32)) || defined(CLI_TIME_USE_POSIX_TIME)
    inline
    CLI_TIME_T cliSystemtimeToCliTime( const STRUCT_CLI_CLISYSTEMTIME &cliSt )
       {
        time_t t = cliSystemTimeToUnixTime( cliSt );
        if (t==((time_t)-1)) t = 0;
        CLI_UTIME_T ct = unixTimeToCliTime(t);
        ct += (CLI_UTIME_T)cliSt.microsec;
        return (CLI_TIME_T)ct;
       }

    inline
    STRUCT_CLI_CLISYSTEMTIME cliTimeToCliSystemtime( CLI_TIME_T ct )
       {
        time_t t = cliTimeToUnixTime( ct );
        STRUCT_CLI_CLISYSTEMTIME st = unixTimeToCliSystemtime( t );
        st.microsec = DWORD(ct%1000000);
        return st;
        //return unixTimeToCliSystemtime( t );
       }
    #endif

    #if !defined(_WIN32) && !defined(WIN32)
    inline
    STRUCT_CLI_CLISYSTEMTIME now()
       {
        //time_t t;
        //return unixTimeToCliSystemtime( time( &t ) );
        struct timeval tv;
        //int
        gettimeofday( &tv, 0);
        // UNDONE: use clock_gettime instead of gettimeofday
        return unixTimevalToCliSystemtime( tv );
       }

    SHORT getUtcCurrentOffset();

    inline
    STRUCT_CLI_CLISYSTEMTIME localNow()
       {
        //time_t t;
        //return unixTimeToCliSystemtimeLocal( time( &t ) );
        struct timeval tv;
        //int
        gettimeofday( &tv, 0);
        STRUCT_CLI_CLISYSTEMTIME res = unixTimevalToCliSystemtimeLocal( tv );
        res.gmOffset = getUtcCurrentOffset();
        return res;

       }

    inline
    SHORT getUtcCurrentOffset()
       {
        time_t t;
        time( &t );
        STRUCT_CLI_CLISYSTEMTIME curTimeUtc   = unixTimeToCliSystemtime( t );
        STRUCT_CLI_CLISYSTEMTIME curTimeLocal = unixTimeToCliSystemtimeLocal( t );
        CLI_TIME_T ctu = cliSystemtimeToCliTime( curTimeUtc );
        CLI_TIME_T ctl = cliSystemtimeToCliTime( curTimeLocal );
        return (SHORT)((ctl - ctu)/1000000/60); // in minutes
       }

    #endif

}; // namespace datetime_util





struct CDateTime : public STRUCT_CLI_CLISYSTEMTIME
{

    static const CLI_TIME_T secondMicrosecs =      1000000ull;
    static const CLI_TIME_T minuteMicrosecs =     60000000ull;
    static const CLI_TIME_T hourMicrosecs   =   3600000000ull;
    static const CLI_TIME_T dayMicrosecs    =  86400000000ull;
    static const CLI_TIME_T weekMicrosecs   = 604800000000ull;

    void clearDate() { year = 0; month = 0; dayOfWeek = 0; day = 0; }
    void clearTime() { hour = 0; minute = 0; second = 0; microsec = 0; }
    void clear()     { clearDate(); clearTime(); gmOffset = 0; }

    CDateTime()
       {
        clear();
       }

    #if defined(_WIN32) || defined(WIN32)
    CDateTime( FILETIME ft )
       {
        *this = datetime_util::win32FiletimeToCliSystemtime( ft );
       }

    CDateTime( const SYSTEMTIME &st )
       {
        *this = datetime_util::win32ToCliSystemtime( st );
       }

    operator SYSTEMTIME() const
       {
        return datetime_util::cliToWin32Systemtime( *this );
       }

    FILETIME toFiletime() const
       {
        return datetime_util::cliSystemtimeToWin32Filetime( *this );
       }

    #else
    CDateTime( const struct timeval &tv )
       {
        *this = datetime_util::unixTimevalToCliSystemtime( tv );
       }
    #endif


    CDateTime(const STRUCT_CLI_CLISYSTEMTIME &st)
       {
        year       = st.year     ;
        month      = st.month    ;
        dayOfWeek  = st.dayOfWeek;
        day        = st.day      ;
        hour       = st.hour     ;
        minute     = st.minute   ;
        second     = st.second   ;
        microsec   = st.microsec ;
       }

    CDateTime& operator=(const STRUCT_CLI_CLISYSTEMTIME &st)
       {
        if (&st==this) return *this;
        year       = st.year     ;
        month      = st.month    ;
        dayOfWeek  = st.dayOfWeek;
        day        = st.day      ;
        hour       = st.hour     ;
        minute     = st.minute   ;
        second     = st.second   ;
        microsec   = st.microsec ;
        return *this;
       }

    operator STRUCT_CLI_CLISYSTEMTIME()
       {
        STRUCT_CLI_CLISYSTEMTIME st;
        st.year       = year     ;
        st.month      = month    ;
        st.dayOfWeek  = dayOfWeek;
        st.day        = day      ;
        st.hour       = hour     ;
        st.minute     = minute   ;
        st.second     = second   ;
        st.microsec   = microsec ;
        return st;
       }

    CDateTime( const struct tm &ut )
       {
        *this = datetime_util::unixTmToCliSystemtime( ut );
       }

/*
    CDateTime( time_t t ) // conflicts with CDateTime( CLI_TIME_T t )
       {
        *this = datetime_util::unixTimeToCliSystemtime( t );
       }
*/

    CDateTime( CLI_TIME_T t )
       {
        *this = datetime_util::cliTimeToCliSystemtime( t );
       }

    void updateDayOfWeek()
       {
        SHORT tmp = gmOffset;
        // update dayOfWeek
        *this = datetime_util::cliTimeToCliSystemtime( datetime_util::cliSystemtimeToCliTime(*this) );
        gmOffset = tmp;
       }

    // date
    CDateTime( WORD y, WORD mon, WORD d )
       {
        clear();
        year       = y;
        month      = mon;
        day        = d;
        updateDayOfWeek();
       }
    // time
    CDateTime( WORD h, WORD min, WORD s, DWORD mcs )
       {
        clear();
        hour       = h;
        minute     = min;
        second     = s;
        microsec   = mcs;
       }

    operator CLI_TIME_T () const
       {
        //return datetime_util::cliSystemtimeToCliTime( (STRUCT_CLI_CLISYSTEMTIME)*this );
        return datetime_util::cliSystemtimeToCliTime( *this );
       }

    CDateTime( WORD y, WORD mon, WORD d, WORD h, WORD min, WORD s, DWORD mcs = 0 )
       {
        clear();
        year       = y;
        month      = mon;
        day        = d;
        hour       = h;
        minute     = min;
        second     = s;
        microsec   = mcs;

        updateDayOfWeek();
       }

    static CDateTime now()
       {
        return datetime_util::now();
       }

    static CDateTime localNow()
       {
        return datetime_util::localNow();
       }


    static CDateTime dayBegin( const CDateTime &dt )
       {
        CDateTime res = dt;
        res.hour       = 0;
        res.minute     = 0;
        res.second     = 0;
        res.microsec   = 0;
        return res;
       }

    static CDateTime dayEnd( const CDateTime &dt )
       {
        CDateTime res = dt;
        res.hour       = 23;
        res.minute     = 59;
        res.second     = 59;
        res.microsec   = 999999;
        return res;
       }

    static CDateTime hourBegin( const CDateTime &dt )
       {
        CDateTime res = dt;
        res.minute     = 0;
        res.second     = 0;
        res.microsec   = 0;
        return res;
       }

    static CDateTime hourEnd( const CDateTime &dt )
       {
        CDateTime res = dt;
        res.minute     = 59;
        res.second     = 59;
        res.microsec   = 999999;
        return res;
       }

    static CDateTime minuteBegin( const CDateTime &dt )
       {
        CDateTime res = dt;
        res.second     = 0;
        res.microsec   = 0;
        return res;
       }

    static CDateTime minuteEnd( const CDateTime &dt )
       {
        CDateTime res = dt;
        res.second     = 59;
        res.microsec   = 999999;
        return res;
       }

    static CDateTime weekBegin( const CDateTime &dt )
       {
        CDateTime res = dayBegin(dt);
        res.updateDayOfWeek();
        CLI_TIME_T ctm = res;
        ctm -= res.dayOfWeek * dayMicrosecs;
        res = ctm;
        return res;
       }

    static CDateTime weekEnd( const CDateTime &dt )
       {
        return CDateTime(((CLI_TIME_T)weekBegin(dt)) + weekMicrosecs - 1);
       }

    static CDateTime monthBegin( const CDateTime &dt )
       {
        CDateTime res = dayBegin(dt);
        res.day = 1;
        res.updateDayOfWeek();
        return res;
       }

    static CDateTime yearBegin( const CDateTime &dt )
       {
        CDateTime res = dayBegin(dt);
        res.day   = 1;
        res.month = 0;
        res.updateDayOfWeek();
        return res;
       }

    static CDateTime mergeDateTime( const CDateTime &date, const CDateTime &time )
       {
        CDateTime res = date;
        res.hour       = time.hour    ;
        res.minute     = time.minute  ;
        res.second     = time.second  ;
        res.microsec   = time.microsec;
        res.updateDayOfWeek();
        return res;
       }

    static
    SHORT localUtcOffset() // local time offset from UTC
       {
        return datetime_util::getUtcCurrentOffset();
       }

}; // CDateTime

}; // namespace cli


#endif // __cplusplus


#endif /* CLI_DATETIME_H */

