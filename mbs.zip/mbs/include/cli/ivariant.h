#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IVARIANT_H
#define CLI_IVARIANT_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/ivariant.h>", CLI_IVARIANT_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::VariantType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_VARIANTTYPE                DWORD
#else
    #define ENUM_CLI_VARIANTTYPE                DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_VARIANTTYPE_VT_EMPTY
    #define CLI_VARIANTTYPE_VT_EMPTY          CONSTANT_DWORD(0)
#endif /* CLI_VARIANTTYPE_VT_EMPTY */

#ifndef CLI_VARIANTTYPE_VT_NONE
    #define CLI_VARIANTTYPE_VT_NONE           CONSTANT_DWORD(0)
#endif /* CLI_VARIANTTYPE_VT_NONE */

#ifndef CLI_VARIANTTYPE_VT_CHAR
    #define CLI_VARIANTTYPE_VT_CHAR           1
#endif /* CLI_VARIANTTYPE_VT_CHAR */

#ifndef CLI_VARIANTTYPE_VT_WCHAR
    #define CLI_VARIANTTYPE_VT_WCHAR          2
#endif /* CLI_VARIANTTYPE_VT_WCHAR */

#ifndef CLI_VARIANTTYPE_VT_SHORT
    #define CLI_VARIANTTYPE_VT_SHORT          3
#endif /* CLI_VARIANTTYPE_VT_SHORT */

#ifndef CLI_VARIANTTYPE_VT_USHORT
    #define CLI_VARIANTTYPE_VT_USHORT         4
#endif /* CLI_VARIANTTYPE_VT_USHORT */

#ifndef CLI_VARIANTTYPE_VT_INT
    #define CLI_VARIANTTYPE_VT_INT            5
#endif /* CLI_VARIANTTYPE_VT_INT */

#ifndef CLI_VARIANTTYPE_VT_UINT
    #define CLI_VARIANTTYPE_VT_UINT           6
#endif /* CLI_VARIANTTYPE_VT_UINT */

#ifndef CLI_VARIANTTYPE_VT_INT64
    #define CLI_VARIANTTYPE_VT_INT64          7
#endif /* CLI_VARIANTTYPE_VT_INT64 */

#ifndef CLI_VARIANTTYPE_VT_UINT64
    #define CLI_VARIANTTYPE_VT_UINT64         8
#endif /* CLI_VARIANTTYPE_VT_UINT64 */

#ifndef CLI_VARIANTTYPE_VT_INT_PTR
    #define CLI_VARIANTTYPE_VT_INT_PTR        9
#endif /* CLI_VARIANTTYPE_VT_INT_PTR */

#ifndef CLI_VARIANTTYPE_VT_UINT_PTR
    #define CLI_VARIANTTYPE_VT_UINT_PTR       10
#endif /* CLI_VARIANTTYPE_VT_UINT_PTR */

#ifndef CLI_VARIANTTYPE_VT_FLOAT
    #define CLI_VARIANTTYPE_VT_FLOAT          11
#endif /* CLI_VARIANTTYPE_VT_FLOAT */

#ifndef CLI_VARIANTTYPE_VT_DOUBLE
    #define CLI_VARIANTTYPE_VT_DOUBLE         12
#endif /* CLI_VARIANTTYPE_VT_DOUBLE */

#ifndef CLI_VARIANTTYPE_VT_PSTRING
    #define CLI_VARIANTTYPE_VT_PSTRING        13
#endif /* CLI_VARIANTTYPE_VT_PSTRING */

#ifndef CLI_VARIANTTYPE_VT_PTR
    #define CLI_VARIANTTYPE_VT_PTR            14
#endif /* CLI_VARIANTTYPE_VT_PTR */

#ifndef CLI_VARIANTTYPE_VT_DUMP
    #define CLI_VARIANTTYPE_VT_DUMP           15
#endif /* CLI_VARIANTTYPE_VT_DUMP */

#ifndef CLI_VARIANTTYPE_VT_DATETIME
    #define CLI_VARIANTTYPE_VT_DATETIME       16
#endif /* CLI_VARIANTTYPE_VT_DATETIME */

#ifndef CLI_VARIANTTYPE_VT_BOOL
    #define CLI_VARIANTTYPE_VT_BOOL           17
#endif /* CLI_VARIANTTYPE_VT_BOOL */

#ifndef CLI_VARIANTTYPE_VT_COLORREF
    #define CLI_VARIANTTYPE_VT_COLORREF       18
#endif /* CLI_VARIANTTYPE_VT_COLORREF */

#ifndef CLI_VARIANTTYPE_VT_IUNKNOWN
    #define CLI_VARIANTTYPE_VT_IUNKNOWN       19
#endif /* CLI_VARIANTTYPE_VT_IUNKNOWN */

#ifndef CLI_VARIANTTYPE_VT_BIGINT
    #define CLI_VARIANTTYPE_VT_BIGINT         20
#endif /* CLI_VARIANTTYPE_VT_BIGINT */

#ifndef CLI_VARIANTTYPE_VT_RATIONAL
    #define CLI_VARIANTTYPE_VT_RATIONAL       21
#endif /* CLI_VARIANTTYPE_VT_RATIONAL */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace VariantType {
                const DWORD vt_empty         = CONSTANT_DWORD(0);
                const DWORD vt_none          = CONSTANT_DWORD(0);
                const DWORD vt_char          = CONSTANT_DWORD(1);
                const DWORD vt_wchar         = CONSTANT_DWORD(2);
                const DWORD vt_short         = CONSTANT_DWORD(3);
                const DWORD vt_ushort        = CONSTANT_DWORD(4);
                const DWORD vt_int           = CONSTANT_DWORD(5);
                const DWORD vt_uint          = CONSTANT_DWORD(6);
                const DWORD vt_int64         = CONSTANT_DWORD(7);
                const DWORD vt_uint64        = CONSTANT_DWORD(8);
                const DWORD vt_int_ptr       = CONSTANT_DWORD(9);
                const DWORD vt_uint_ptr      = CONSTANT_DWORD(10);
                const DWORD vt_float         = CONSTANT_DWORD(11);
                const DWORD vt_double        = CONSTANT_DWORD(12);
                const DWORD vt_pstring       = CONSTANT_DWORD(13);
                const DWORD vt_ptr           = CONSTANT_DWORD(14);
                const DWORD vt_dump          = CONSTANT_DWORD(15);
                const DWORD vt_datetime      = CONSTANT_DWORD(16);
                const DWORD vt_bool          = CONSTANT_DWORD(17);
                const DWORD vt_colorref      = CONSTANT_DWORD(18);
                const DWORD vt_iUnknown      = CONSTANT_DWORD(19);
                const DWORD vt_bigint        = CONSTANT_DWORD(20);
                const DWORD vt_rational      = CONSTANT_DWORD(21);
        }; // namespace VariantType
    }; // namespace cli
    /* using namespace ::cli::VariantType; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::BigInteger */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
    #define CLI_STRUCT_NAME                   BigInteger
    #ifndef STRUCT_CLI_BIGINTEGER_PREDECLARED
    #define STRUCT_CLI_BIGINTEGER_PREDECLARED
        struct BigInteger;
        #ifndef STRUCT_CLI_BIGINTEGER
            #define STRUCT_CLI_BIGINTEGER             ::cli::BigInteger
        #endif
    #endif // STRUCT_CLI_BIGINTEGER_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_BigInteger
    #ifndef STRUCT_CLI_BIGINTEGER_PREDECLARED
    #define STRUCT_CLI_BIGINTEGER_PREDECLARED
        struct  tag_cli_BigInteger;
        typedef struct tag_cli_BigInteger cli_BigInteger;
        #ifndef STRUCT_CLI_BIGINTEGER
            #define STRUCT_CLI_BIGINTEGER             struct tag_cli_BigInteger
        #endif
    #endif // STRUCT_CLI_BIGINTEGER_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef STRUCT_CLI_BIGINTEGER_DEFINED
        #define STRUCT_CLI_BIGINTEGER_DEFINED
        #include <cli/pshpack8.h>
        CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
            UINT64                      loPart;
            INT64                       hiPart;
        CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
        #include <cli/poppack.h>
        #endif // STRUCT_CLI_BIGINTEGER_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::RationalNumber */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
    #define CLI_STRUCT_NAME                   RationalNumber
    #ifndef STRUCT_CLI_RATIONALNUMBER_PREDECLARED
    #define STRUCT_CLI_RATIONALNUMBER_PREDECLARED
        struct RationalNumber;
        #ifndef STRUCT_CLI_RATIONALNUMBER
            #define STRUCT_CLI_RATIONALNUMBER         ::cli::RationalNumber
        #endif
    #endif // STRUCT_CLI_RATIONALNUMBER_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_RationalNumber
    #ifndef STRUCT_CLI_RATIONALNUMBER_PREDECLARED
    #define STRUCT_CLI_RATIONALNUMBER_PREDECLARED
        struct  tag_cli_RationalNumber;
        typedef struct tag_cli_RationalNumber cli_RationalNumber;
        #ifndef STRUCT_CLI_RATIONALNUMBER
            #define STRUCT_CLI_RATIONALNUMBER         struct tag_cli_RationalNumber
        #endif
    #endif // STRUCT_CLI_RATIONALNUMBER_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef STRUCT_CLI_RATIONALNUMBER_DEFINED
        #define STRUCT_CLI_RATIONALNUMBER_DEFINED
        #include <cli/pshpack8.h>
        CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
            STRUCT_CLI_BIGINTEGER       nominator;
            STRUCT_CLI_BIGINTEGER       denominator;
        CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
        #include <cli/poppack.h>
        #endif // STRUCT_CLI_RATIONALNUMBER_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::InlineDataHolder */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
    #define CLI_STRUCT_NAME                   InlineDataHolder
    #ifndef STRUCT_CLI_INLINEDATAHOLDER_PREDECLARED
    #define STRUCT_CLI_INLINEDATAHOLDER_PREDECLARED
        struct InlineDataHolder;
        #ifndef STRUCT_CLI_INLINEDATAHOLDER
            #define STRUCT_CLI_INLINEDATAHOLDER       ::cli::InlineDataHolder
        #endif
    #endif // STRUCT_CLI_INLINEDATAHOLDER_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_InlineDataHolder
    #ifndef STRUCT_CLI_INLINEDATAHOLDER_PREDECLARED
    #define STRUCT_CLI_INLINEDATAHOLDER_PREDECLARED
        struct  tag_cli_InlineDataHolder;
        typedef struct tag_cli_InlineDataHolder cli_InlineDataHolder;
        #ifndef STRUCT_CLI_INLINEDATAHOLDER
            #define STRUCT_CLI_INLINEDATAHOLDER       struct tag_cli_InlineDataHolder
        #endif
    #endif // STRUCT_CLI_INLINEDATAHOLDER_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef STRUCT_CLI_INLINEDATAHOLDER_DEFINED
        #define STRUCT_CLI_INLINEDATAHOLDER_DEFINED
        #include <cli/pshpack8.h>
        CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
            BYTE                      * pData;
            BYTE                        inlineData[16];
        CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
        #include <cli/poppack.h>
        #endif // STRUCT_CLI_INLINEDATAHOLDER_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Union: ::cli::VariantValue */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        struct                                   CLISYSTEMTIME;
        #ifndef STRUCT_CLI_CLISYSTEMTIME
            #define STRUCT_CLI_CLISYSTEMTIME          ::cli::CLISYSTEMTIME
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef STRUCT_CLI_CLISYSTEMTIME_PREDECLARED
    #define STRUCT_CLI_CLISYSTEMTIME_PREDECLARED
    typedef struct tag_cli_CLISYSTEMTIME     cli_CLISYSTEMTIME;
    #endif //STRUCT_CLI_CLISYSTEMTIME
    #ifndef STRUCT_CLI_CLISYSTEMTIME
        #define STRUCT_CLI_CLISYSTEMTIME          struct tag_cli_CLISYSTEMTIME
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef CLI_UNION_NAME
   #undef CLI_UNION_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
    #define CLI_UNION_NAME                   VariantValue
    #ifndef UNION_CLI_VARIANTVALUE_PREDECLARED
    #define UNION_CLI_VARIANTVALUE_PREDECLARED
        struct VariantValue;
        #ifndef UNION_CLI_VARIANTVALUE
            #define UNION_CLI_VARIANTVALUE            ::cli::VariantValue
        #endif
    #endif // UNION_CLI_VARIANTVALUE_PREDECLARED

#else /* C-like declarations */

    #define CLI_UNION_NAME                   cli_VariantValue
    #ifndef UNION_CLI_VARIANTVALUE_PREDECLARED
    #define UNION_CLI_VARIANTVALUE_PREDECLARED
        struct  tag_cli_VariantValue;
        typedef struct tag_cli_VariantValue cli_VariantValue;
        #ifndef UNION_CLI_VARIANTVALUE
            #define UNION_CLI_VARIANTVALUE            struct tag_cli_VariantValue
        #endif
    #endif // UNION_CLI_VARIANTVALUE_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef UNION_CLI_VARIANTVALUE_DEFINED
        #define UNION_CLI_VARIANTVALUE_DEFINED
        CLI_BEGIN_UNION_DECLARATION(CLI_UNION_NAME)
            CHAR                        vChar;
            WCHAR                       vWChar;
            SHORT                       vShort;
            USHORT                      vUShort;
            INT                         vInt;
            UINT                        vUInt;
            INT64                       vInt64;
            UINT64                      vUInt64;
            INT_PTR                     vIntPtr;
            UINT_PTR                    vUIntPtr;
            FLOAT                       vFloat;
            DOUBLE                      vDouble;
            CLIPSTR                     vStr;
            VOID                      * vPtr;
            CLIPCSTR                    vDump;
            STRUCT_CLI_CLISYSTEMTIME    vDatetime;
            BOOL                        vBool;
            INTERFACE_CLI_IUNKNOWN    * vUnknown;
            STRUCT_CLI_BIGINTEGER       vBigint;
            STRUCT_CLI_RATIONALNUMBER               vRational;
            STRUCT_CLI_INLINEDATAHOLDER             vDataHolder;
        CLI_END_UNION_DECLARATION(CLI_UNION_NAME);
        #endif // UNION_CLI_VARIANTVALUE_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::Variant */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
    #define CLI_STRUCT_NAME                   Variant
    #ifndef STRUCT_CLI_VARIANT_PREDECLARED
    #define STRUCT_CLI_VARIANT_PREDECLARED
        struct Variant;
        #ifndef STRUCT_CLI_VARIANT
            #define STRUCT_CLI_VARIANT                ::cli::Variant
        #endif
    #endif // STRUCT_CLI_VARIANT_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_Variant
    #ifndef STRUCT_CLI_VARIANT_PREDECLARED
    #define STRUCT_CLI_VARIANT_PREDECLARED
        struct  tag_cli_Variant;
        typedef struct tag_cli_Variant cli_Variant;
        #ifndef STRUCT_CLI_VARIANT
            #define STRUCT_CLI_VARIANT                struct tag_cli_Variant
        #endif
    #endif // STRUCT_CLI_VARIANT_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef STRUCT_CLI_VARIANT_DEFINED
        #define STRUCT_CLI_VARIANT_DEFINED
        #include <cli/pshpack8.h>
        CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
            ENUM_CLI_VARIANTTYPE        valType;
            UNION_CLI_VARIANTVALUE      value;
        CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
        #include <cli/poppack.h>
        #endif // STRUCT_CLI_VARIANT_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iReadOnlyVariant */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iReadOnlyVariant;
        #ifndef INTERFACE_CLI_IREADONLYVARIANT
            #define INTERFACE_CLI_IREADONLYVARIANT    ::cli::iReadOnlyVariant
        #endif

        interface                                iVariant;
        #ifndef INTERFACE_CLI_IVARIANT
            #define INTERFACE_CLI_IVARIANT            ::cli::iVariant
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IREADONLYVARIANT_PREDECLARED
    #define INTERFACE_CLI_IREADONLYVARIANT_PREDECLARED
    typedef interface tag_cli_iReadOnlyVariant                   cli_iReadOnlyVariant;
    #endif //INTERFACE_CLI_IREADONLYVARIANT
    #ifndef INTERFACE_CLI_IREADONLYVARIANT
        #define INTERFACE_CLI_IREADONLYVARIANT    struct tag_cli_iReadOnlyVariant
    #endif

    #ifndef INTERFACE_CLI_IVARIANT_PREDECLARED
    #define INTERFACE_CLI_IVARIANT_PREDECLARED
    typedef interface tag_cli_iVariant       cli_iVariant;
    #endif //INTERFACE_CLI_IVARIANT
    #ifndef INTERFACE_CLI_IVARIANT
        #define INTERFACE_CLI_IVARIANT            struct tag_cli_iVariant
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IREADONLYVARIANT_IID
    #define INTERFACE_CLI_IREADONLYVARIANT_IID    "/cli/iReadOnlyVariant"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iReadOnlyVariant
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IREADONLYVARIANT
       #define INTERFACE_CLI_IREADONLYVARIANT    ::cli::iReadOnlyVariant
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iReadOnlyVariant
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IREADONLYVARIANT
       #define INTERFACE_CLI_IREADONLYVARIANT    cli_iReadOnlyVariant
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iReadOnlyVariant methods */
            CLIMETHOD_(ENUM_CLI_VARIANTTYPE, getType) (THIS) PURE;
            CLIMETHOD(getTypeStringChars) (THIS_ WCHAR*    buf /* [out,flat] wchar buf[]  */
                                               , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                          ) PURE;
            CLIMETHOD(getTypeString) (THIS_ CLISTR*           typeStr) PURE;
            CLIMETHOD_(STRUCT_CLI_VARIANT*, getVariantRawPtr) (THIS) PURE;
            CLIMETHOD(cloneVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantCopy /* [out] ::cli::iVariant* pVariantCopy  */) PURE;
            CLIMETHOD(cloneVariantReadOnly) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    pVariantCopy /* [out] ::cli::iReadOnlyVariant* pVariantCopy  */) PURE;
            CLIMETHOD(createEmptyVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantEmpty /* [out] ::cli::iVariant* pVariantEmpty  */) PURE;
            CLIMETHOD(serializeSimple) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(serializeAdvanced) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(serializeAdvancedSeparate) (THIS_ CLISTR*           strValue
                                                      , CLISTR*           strType
                                                 ) PURE;
            CLIMETHOD(valueQueryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                , VOID**    ifPtr /* [out] void* ifPtr  */
                                           ) PURE;
            CLIMETHOD(getChar) (THIS_ CHAR*    ch /* [out] char ch  */) PURE;
            CLIMETHOD(getWChar) (THIS_ WCHAR*    wch /* [out] wchar wch  */) PURE;
            CLIMETHOD(getShort) (THIS_ SHORT*    s /* [out] short s  */) PURE;
            CLIMETHOD(getUShort) (THIS_ USHORT*    us /* [out] ushort us  */) PURE;
            CLIMETHOD(getInt) (THIS_ INT*    i /* [out] int i  */) PURE;
            CLIMETHOD(getUInt) (THIS_ UINT*    i /* [out] uint i  */) PURE;
            CLIMETHOD(getColorref) (THIS_ COLORREF*    i /* [out] colorref i  */) PURE;
            CLIMETHOD(getInt64) (THIS_ INT64*    i /* [out] int64 i  */) PURE;
            CLIMETHOD(getUInt64) (THIS_ UINT64*    i /* [out] uint64 i  */) PURE;
            CLIMETHOD(getIntPtr) (THIS_ INT_PTR*    i /* [out] int_ptr i  */) PURE;
            CLIMETHOD(getUIntPtr) (THIS_ UINT_PTR*    i /* [out] uint_ptr i  */) PURE;
            CLIMETHOD(getFloat) (THIS_ FLOAT*    f /* [out] float f  */) PURE;
            CLIMETHOD(getDouble) (THIS_ DOUBLE*    d /* [out] double d  */) PURE;
            CLIMETHOD(getPtr) (THIS_ VOID**    vptr /* [out] void* vptr  */) PURE;
            CLIMETHOD(getString) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(getStringPStr) (THIS_ CLIPSTR*          str) PURE;
            CLIMETHOD(getStringChars) (THIS_ WCHAR*    buf /* [out,flat] wchar buf[]  */
                                           , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                      ) PURE;
            CLIMETHOD(getDump) (THIS_ CLIPCSTR*         str) PURE;
            CLIMETHOD(getDate) (THIS_ STRUCT_CLI_CLISYSTEMTIME*    datetime /* [out] ::cli::CLISYSTEMTIME datetime  */) PURE;
            CLIMETHOD(getBool) (THIS_ BOOL*    b /* [out] bool b  */) PURE;
            CLIMETHOD(getUnknown) (THIS_ INTERFACE_CLI_IUNKNOWN**    pUnknown /* [out] ::cli::iUnknown* pUnknown  */) PURE;
            CLIMETHOD(getBigInteger) (THIS_ STRUCT_CLI_BIGINTEGER*    bigint /* [out] ::cli::BigInteger bigint  */) PURE;
            CLIMETHOD(getRationalNumber) (THIS_ STRUCT_CLI_RATIONALNUMBER*    rational /* [out] ::cli::RationalNumber rational  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iReadOnlyVariant >
           {
            static char const * getName() { return INTERFACE_CLI_IREADONLYVARIANT_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iReadOnlyVariant* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iReadOnlyVariant > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iReadOnlyVariant wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IREADONLYVARIANT >
                                      */
                 >
        class CiReadOnlyVariantWrapper
        {
            public:
        
                typedef  CiReadOnlyVariantWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiReadOnlyVariantWrapper() :
                   pif(0) {}
        
                CiReadOnlyVariantWrapper( iReadOnlyVariant *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiReadOnlyVariantWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiReadOnlyVariantWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiReadOnlyVariantWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiReadOnlyVariantWrapper(const CiReadOnlyVariantWrapper &i) :
                    pif(i.pif) { }
        
                ~CiReadOnlyVariantWrapper()  { }
        
                CiReadOnlyVariantWrapper& operator=(const CiReadOnlyVariantWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                ENUM_CLI_VARIANTTYPE getType( )
                   {
                    return pif->getType();
                   }
                
                RCODE getTypeStringChars( WCHAR*    buf /* [out,flat] wchar buf[]  */
                                        , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                        )
                   {
                
                
                    return pif->getTypeStringChars(buf, bufSize);
                   }
                
                RCODE getTypeString( ::std::wstring    &typeStr)
                   {
                    CCliStr tmp_typeStr; CCliStr_init( tmp_typeStr );
                    RCODE res = pif->getTypeString(&tmp_typeStr);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( typeStr, tmp_typeStr);
                       }
                    return res;
                   }
                
                STRUCT_CLI_VARIANT* getVariantRawPtr( )
                   {
                    return pif->getVariantRawPtr();
                   }
                
                RCODE cloneVariant( INTERFACE_CLI_IVARIANT**    pVariantCopy /* [out] ::cli::iVariant* pVariantCopy  */)
                   {
                
                    return pif->cloneVariant(pVariantCopy);
                   }
                
                RCODE cloneVariantReadOnly( INTERFACE_CLI_IREADONLYVARIANT**    pVariantCopy /* [out] ::cli::iReadOnlyVariant* pVariantCopy  */)
                   {
                
                    return pif->cloneVariantReadOnly(pVariantCopy);
                   }
                
                RCODE createEmptyVariant( INTERFACE_CLI_IVARIANT**    pVariantEmpty /* [out] ::cli::iVariant* pVariantEmpty  */)
                   {
                
                    return pif->createEmptyVariant(pVariantEmpty);
                   }
                
                RCODE serializeSimple( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->serializeSimple(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE serializeAdvanced( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->serializeAdvanced(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE serializeAdvancedSeparate( ::std::wstring    &strValue
                                               , ::std::wstring    &strType
                                               )
                   {
                    CCliStr tmp_strValue; CCliStr_init( tmp_strValue );
                    CCliStr tmp_strType; CCliStr_init( tmp_strType );
                    RCODE res = pif->serializeAdvancedSeparate(&tmp_strValue, &tmp_strType);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( strValue, tmp_strValue);
                        CCliStr_copyFromIfModified( strType, tmp_strType);
                       }
                    return res;
                   }
                
                RCODE valueQueryInterface( const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                         , VOID**    ifPtr /* [out] void* ifPtr  */
                                         )
                   {
                
                
                    return pif->valueQueryInterface(interfaceId, ifPtr);
                   }
                
                RCODE getChar( CHAR*    ch /* [out] char ch  */)
                   {
                
                    return pif->getChar(ch);
                   }
                
                RCODE getWChar( WCHAR*    wch /* [out] wchar wch  */)
                   {
                
                    return pif->getWChar(wch);
                   }
                
                RCODE getShort( SHORT*    s /* [out] short s  */)
                   {
                
                    return pif->getShort(s);
                   }
                
                RCODE getUShort( USHORT*    us /* [out] ushort us  */)
                   {
                
                    return pif->getUShort(us);
                   }
                
                RCODE getInt( INT*    i /* [out] int i  */)
                   {
                
                    return pif->getInt(i);
                   }
                
                RCODE getUInt( UINT*    i /* [out] uint i  */)
                   {
                
                    return pif->getUInt(i);
                   }
                
                RCODE getColorref( COLORREF*    i /* [out] colorref i  */)
                   {
                
                    return pif->getColorref(i);
                   }
                
                RCODE getInt64( INT64*    i /* [out] int64 i  */)
                   {
                
                    return pif->getInt64(i);
                   }
                
                RCODE getUInt64( UINT64*    i /* [out] uint64 i  */)
                   {
                
                    return pif->getUInt64(i);
                   }
                
                RCODE getIntPtr( INT_PTR*    i /* [out] int_ptr i  */)
                   {
                
                    return pif->getIntPtr(i);
                   }
                
                RCODE getUIntPtr( UINT_PTR*    i /* [out] uint_ptr i  */)
                   {
                
                    return pif->getUIntPtr(i);
                   }
                
                RCODE getFloat( FLOAT*    f /* [out] float f  */)
                   {
                
                    return pif->getFloat(f);
                   }
                
                RCODE getDouble( DOUBLE*    d /* [out] double d  */)
                   {
                
                    return pif->getDouble(d);
                   }
                
                RCODE getPtr( VOID**    vptr /* [out] void* vptr  */)
                   {
                
                    return pif->getPtr(vptr);
                   }
                
                RCODE getString( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getString(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getStringPStr( ::std::wstring    &str)
                   {
                    CCliPStr tmp_str; CCliPStr_init( tmp_str );
                    RCODE res = pif->getStringPStr(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliPStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getStringChars( WCHAR*    buf /* [out,flat] wchar buf[]  */
                                    , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                    )
                   {
                
                
                    return pif->getStringChars(buf, bufSize);
                   }
                
                RCODE getDump( ::std::string    &str)
                   {
                    CCliPCStr tmp_str; CCliPCStr_init( tmp_str );
                    RCODE res = pif->getDump(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliPCStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getDate( STRUCT_CLI_CLISYSTEMTIME    &datetime /* [out] ::cli::CLISYSTEMTIME datetime  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->getDate(&datetime);
                   }
                
                RCODE getBool( BOOL*    b /* [out] bool b  */)
                   {
                
                    return pif->getBool(b);
                   }
                
                RCODE getUnknown( INTERFACE_CLI_IUNKNOWN**    pUnknown /* [out] ::cli::iUnknown* pUnknown  */)
                   {
                
                    return pif->getUnknown(pUnknown);
                   }
                
                RCODE getBigInteger( STRUCT_CLI_BIGINTEGER    &bigint /* [out] ::cli::BigInteger bigint  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->getBigInteger(&bigint);
                   }
                
                RCODE getRationalNumber( STRUCT_CLI_RATIONALNUMBER    &rational /* [out] ::cli::RationalNumber rational  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->getRationalNumber(&rational);
                   }
                

        
        
        }; // class CiReadOnlyVariantWrapper
        
        typedef CiReadOnlyVariantWrapper< ::cli::CCliPtr< INTERFACE_CLI_IREADONLYVARIANT     > >  CiReadOnlyVariant;
        typedef CiReadOnlyVariantWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IREADONLYVARIANT > >  CiReadOnlyVariant_nrc; /* No ref counting for interface used */
        typedef CiReadOnlyVariantWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IREADONLYVARIANT > >  CiReadOnlyVariant_tmp; /* for temporary usage, same as CiReadOnlyVariant_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iVariant */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IVARIANT_IID
    #define INTERFACE_CLI_IVARIANT_IID    "/cli/iVariant"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iVariant
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IVARIANT
       #define INTERFACE_CLI_IVARIANT    ::cli::iVariant
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iVariant
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IVARIANT
       #define INTERFACE_CLI_IVARIANT    cli_iVariant
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iVariant methods */
            CLIMETHOD_(ENUM_CLI_VARIANTTYPE, getType) (THIS) PURE;
            CLIMETHOD(convertType) (THIS_ ENUM_CLI_VARIANTTYPE    newType /* [in] ::cli::VariantType  newType  */) PURE;
            CLIMETHOD(getTypeStringChars) (THIS_ WCHAR*    buf /* [out,flat] wchar buf[]  */
                                               , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                          ) PURE;
            CLIMETHOD(getTypeString) (THIS_ CLISTR*           typeStr) PURE;
            CLIMETHOD_(STRUCT_CLI_VARIANT*, getVariantRawPtr) (THIS) PURE;
            CLIMETHOD(assignVariant) (THIS_ INTERFACE_CLI_IVARIANT*    pVariant /* [in] ::cli::iVariant*  pVariant  */) PURE;
            CLIMETHOD(assignRawVariant) (THIS_ const STRUCT_CLI_VARIANT*    v /* [in,ref] ::cli::Variant  v  */) PURE;
            CLIMETHOD(cloneVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantCopy /* [out] ::cli::iVariant* pVariantCopy  */) PURE;
            CLIMETHOD(cloneVariantReadOnly) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    pVariantCopy /* [out] ::cli::iReadOnlyVariant* pVariantCopy  */) PURE;
            CLIMETHOD(createEmptyVariant) (THIS_ INTERFACE_CLI_IVARIANT**    pVariantEmpty /* [out] ::cli::iVariant* pVariantEmpty  */) PURE;
            CLIMETHOD(serializeSimple) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(serializeAdvanced) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(serializeAdvancedSeparate) (THIS_ CLISTR*           strValue
                                                      , CLISTR*           strType
                                                 ) PURE;
            CLIMETHOD(deserializeSimple) (THIS_ const CLISTR*     str) PURE;
            CLIMETHOD(deserializeAdvanced) (THIS_ const CLISTR*     str) PURE;
            CLIMETHOD(deserializeAdvancedSeparate) (THIS_ const CLISTR*     strValue
                                                        , const CLISTR*     strType
                                                   ) PURE;
            CLIMETHOD(valueQueryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                , VOID**    ifPtr /* [out] void* ifPtr  */
                                           ) PURE;
            CLIMETHOD(setEmpty) (THIS) PURE;
            CLIMETHOD(setChar) (THIS_ CHAR    ch /* [in] char  ch  */) PURE;
            CLIMETHOD(setWChar) (THIS_ WCHAR    wch /* [in] wchar  wch  */) PURE;
            CLIMETHOD(setShort) (THIS_ SHORT    s /* [in] short  s  */) PURE;
            CLIMETHOD(setUShort) (THIS_ USHORT    us /* [in] ushort  us  */) PURE;
            CLIMETHOD(setInt) (THIS_ INT    i /* [in] int  i  */) PURE;
            CLIMETHOD(setUInt) (THIS_ UINT    i /* [in] uint  i  */) PURE;
            CLIMETHOD(setColorref) (THIS_ COLORREF    i /* [in] colorref  i  */) PURE;
            CLIMETHOD(setInt64) (THIS_ INT64    i /* [in] int64  i  */) PURE;
            CLIMETHOD(setUInt64) (THIS_ UINT64    i /* [in] uint64  i  */) PURE;
            CLIMETHOD(setIntPtr) (THIS_ INT_PTR    i /* [in] int_ptr  i  */) PURE;
            CLIMETHOD(setUIntPtr) (THIS_ UINT_PTR    i /* [in] uint_ptr  i  */) PURE;
            CLIMETHOD(setFloat) (THIS_ FLOAT    f /* [in] float  f  */) PURE;
            CLIMETHOD(setDouble) (THIS_ DOUBLE    d /* [in] double  d  */) PURE;
            CLIMETHOD(setPtr) (THIS_ const VOID*    vptr /* [in] void*  vptr  */) PURE;
            CLIMETHOD(setString) (THIS_ const CLISTR*     str) PURE;
            CLIMETHOD(setStringPStr) (THIS_ CLIPSTR           str) PURE;
            CLIMETHOD(setStringChars) (THIS_ const WCHAR*    str /* [in,flat] wchar  str[]  */
                                           , SIZE_T    strSize /* [in] size_t  strSize  */
                                      ) PURE;
            CLIMETHOD(setDump) (THIS_ const BYTE*    d /* [in,flat] byte  d[]  */
                                    , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                               ) PURE;
            CLIMETHOD(setDate) (THIS_ const STRUCT_CLI_CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */) PURE;
            CLIMETHOD(setBool) (THIS_ BOOL    b /* [in] bool  b  */) PURE;
            CLIMETHOD(setUnknown) (THIS_ INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */) PURE;
            CLIMETHOD(setBigInteger) (THIS_ const STRUCT_CLI_BIGINTEGER*    bigint /* [in,ref] ::cli::BigInteger  bigint  */) PURE;
            CLIMETHOD(setRationalNumber) (THIS_ const STRUCT_CLI_RATIONALNUMBER*    rational /* [in,ref] ::cli::RationalNumber  rational  */) PURE;
            CLIMETHOD(getChar) (THIS_ CHAR*    ch /* [out] char ch  */) PURE;
            CLIMETHOD(getWChar) (THIS_ WCHAR*    wch /* [out] wchar wch  */) PURE;
            CLIMETHOD(getShort) (THIS_ SHORT*    s /* [out] short s  */) PURE;
            CLIMETHOD(getUShort) (THIS_ USHORT*    us /* [out] ushort us  */) PURE;
            CLIMETHOD(getInt) (THIS_ INT*    i /* [out] int i  */) PURE;
            CLIMETHOD(getUInt) (THIS_ UINT*    i /* [out] uint i  */) PURE;
            CLIMETHOD(getColorref) (THIS_ COLORREF*    i /* [out] colorref i  */) PURE;
            CLIMETHOD(getInt64) (THIS_ INT64*    i /* [out] int64 i  */) PURE;
            CLIMETHOD(getUInt64) (THIS_ UINT64*    i /* [out] uint64 i  */) PURE;
            CLIMETHOD(getIntPtr) (THIS_ INT_PTR*    i /* [out] int_ptr i  */) PURE;
            CLIMETHOD(getUIntPtr) (THIS_ UINT_PTR*    i /* [out] uint_ptr i  */) PURE;
            CLIMETHOD(getFloat) (THIS_ FLOAT*    f /* [out] float f  */) PURE;
            CLIMETHOD(getDouble) (THIS_ DOUBLE*    d /* [out] double d  */) PURE;
            CLIMETHOD(getPtr) (THIS_ VOID**    vptr /* [out] void* vptr  */) PURE;
            CLIMETHOD(getString) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(getStringPStr) (THIS_ CLIPSTR*          str) PURE;
            CLIMETHOD(getStringChars) (THIS_ WCHAR*    buf /* [out,flat] wchar buf[]  */
                                           , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                      ) PURE;
            CLIMETHOD(getDump) (THIS_ CLIPCSTR*         str) PURE;
            CLIMETHOD(getDate) (THIS_ STRUCT_CLI_CLISYSTEMTIME*    datetime /* [out] ::cli::CLISYSTEMTIME datetime  */) PURE;
            CLIMETHOD(getBool) (THIS_ BOOL*    b /* [out] bool b  */) PURE;
            CLIMETHOD(getUnknown) (THIS_ INTERFACE_CLI_IUNKNOWN**    pUnknown /* [out] ::cli::iUnknown* pUnknown  */) PURE;
            CLIMETHOD(getBigInteger) (THIS_ STRUCT_CLI_BIGINTEGER*    bigint /* [out] ::cli::BigInteger bigint  */) PURE;
            CLIMETHOD(getRationalNumber) (THIS_ STRUCT_CLI_RATIONALNUMBER*    rational /* [out] ::cli::RationalNumber rational  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iVariant >
           {
            static char const * getName() { return INTERFACE_CLI_IVARIANT_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iVariant* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iVariant > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iVariant wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IVARIANT >
                                      */
                 >
        class CiVariantWrapper
        {
            public:
        
                typedef  CiVariantWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiVariantWrapper() :
                   pif(0) {}
        
                CiVariantWrapper( iVariant *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiVariantWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiVariantWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiVariantWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiVariantWrapper(const CiVariantWrapper &i) :
                    pif(i.pif) { }
        
                ~CiVariantWrapper()  { }
        
                CiVariantWrapper& operator=(const CiVariantWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                ENUM_CLI_VARIANTTYPE getType( )
                   {
                    return pif->getType();
                   }
                
                RCODE convertType( ENUM_CLI_VARIANTTYPE    newType /* [in] ::cli::VariantType  newType  */)
                   {
                
                    return pif->convertType(newType);
                   }
                
                RCODE getTypeStringChars( WCHAR*    buf /* [out,flat] wchar buf[]  */
                                        , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                        )
                   {
                
                
                    return pif->getTypeStringChars(buf, bufSize);
                   }
                
                RCODE getTypeString( ::std::wstring    &typeStr)
                   {
                    CCliStr tmp_typeStr; CCliStr_init( tmp_typeStr );
                    RCODE res = pif->getTypeString(&tmp_typeStr);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( typeStr, tmp_typeStr);
                       }
                    return res;
                   }
                
                STRUCT_CLI_VARIANT* getVariantRawPtr( )
                   {
                    return pif->getVariantRawPtr();
                   }
                
                RCODE assignVariant( INTERFACE_CLI_IVARIANT*    pVariant /* [in] ::cli::iVariant*  pVariant  */)
                   {
                
                    return pif->assignVariant(pVariant);
                   }
                
                RCODE assignRawVariant( const STRUCT_CLI_VARIANT    &v /* [in,ref] ::cli::Variant  v  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->assignRawVariant(&v);
                   }
                
                RCODE cloneVariant( INTERFACE_CLI_IVARIANT**    pVariantCopy /* [out] ::cli::iVariant* pVariantCopy  */)
                   {
                
                    return pif->cloneVariant(pVariantCopy);
                   }
                
                RCODE cloneVariantReadOnly( INTERFACE_CLI_IREADONLYVARIANT**    pVariantCopy /* [out] ::cli::iReadOnlyVariant* pVariantCopy  */)
                   {
                
                    return pif->cloneVariantReadOnly(pVariantCopy);
                   }
                
                RCODE createEmptyVariant( INTERFACE_CLI_IVARIANT**    pVariantEmpty /* [out] ::cli::iVariant* pVariantEmpty  */)
                   {
                
                    return pif->createEmptyVariant(pVariantEmpty);
                   }
                
                RCODE serializeSimple( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->serializeSimple(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE serializeAdvanced( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->serializeAdvanced(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE serializeAdvancedSeparate( ::std::wstring    &strValue
                                               , ::std::wstring    &strType
                                               )
                   {
                    CCliStr tmp_strValue; CCliStr_init( tmp_strValue );
                    CCliStr tmp_strType; CCliStr_init( tmp_strType );
                    RCODE res = pif->serializeAdvancedSeparate(&tmp_strValue, &tmp_strType);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( strValue, tmp_strValue);
                        CCliStr_copyFromIfModified( strType, tmp_strType);
                       }
                    return res;
                   }
                
                RCODE deserializeSimple( const ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->deserializeSimple(&tmp_str);
                   }
                
                RCODE deserializeAdvanced( const ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->deserializeAdvanced(&tmp_str);
                   }
                
                RCODE deserializeAdvancedSeparate( const ::std::wstring    &strValue
                                                 , const ::std::wstring    &strType
                                                 )
                   {
                    CCliStr tmp_strValue; CCliStr_lightCopyTo( tmp_strValue, strValue);
                    CCliStr tmp_strType; CCliStr_lightCopyTo( tmp_strType, strType);
                    return pif->deserializeAdvancedSeparate(&tmp_strValue, &tmp_strType);
                   }
                
                RCODE valueQueryInterface( const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                         , VOID**    ifPtr /* [out] void* ifPtr  */
                                         )
                   {
                
                
                    return pif->valueQueryInterface(interfaceId, ifPtr);
                   }
                
                RCODE setEmpty( )
                   {
                    return pif->setEmpty();
                   }
                
                RCODE setChar( CHAR    ch /* [in] char  ch  */)
                   {
                
                    return pif->setChar(ch);
                   }
                
                RCODE setWChar( WCHAR    wch /* [in] wchar  wch  */)
                   {
                
                    return pif->setWChar(wch);
                   }
                
                RCODE setShort( SHORT    s /* [in] short  s  */)
                   {
                
                    return pif->setShort(s);
                   }
                
                RCODE setUShort( USHORT    us /* [in] ushort  us  */)
                   {
                
                    return pif->setUShort(us);
                   }
                
                RCODE setInt( INT    i /* [in] int  i  */)
                   {
                
                    return pif->setInt(i);
                   }
                
                RCODE setUInt( UINT    i /* [in] uint  i  */)
                   {
                
                    return pif->setUInt(i);
                   }
                
                RCODE setColorref( COLORREF    i /* [in] colorref  i  */)
                   {
                
                    return pif->setColorref(i);
                   }
                
                RCODE setInt64( INT64    i /* [in] int64  i  */)
                   {
                
                    return pif->setInt64(i);
                   }
                
                RCODE setUInt64( UINT64    i /* [in] uint64  i  */)
                   {
                
                    return pif->setUInt64(i);
                   }
                
                RCODE setIntPtr( INT_PTR    i /* [in] int_ptr  i  */)
                   {
                
                    return pif->setIntPtr(i);
                   }
                
                RCODE setUIntPtr( UINT_PTR    i /* [in] uint_ptr  i  */)
                   {
                
                    return pif->setUIntPtr(i);
                   }
                
                RCODE setFloat( FLOAT    f /* [in] float  f  */)
                   {
                
                    return pif->setFloat(f);
                   }
                
                RCODE setDouble( DOUBLE    d /* [in] double  d  */)
                   {
                
                    return pif->setDouble(d);
                   }
                
                RCODE setPtr( const VOID*    vptr /* [in] void*  vptr  */)
                   {
                
                    return pif->setPtr(vptr);
                   }
                
                RCODE setString( const ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->setString(&tmp_str);
                   }
                
                RCODE setStringPStr( ::std::wstring    str)
                   {
                    CCliPStr tmp_str; CCliPStr_lightCopyTo( tmp_str, str);
                    return pif->setStringPStr(tmp_str);
                   }
                
                RCODE setStringChars( const WCHAR*    str /* [in,flat] wchar  str[]  */
                                    , SIZE_T    strSize /* [in] size_t  strSize  */
                                    )
                   {
                
                
                    return pif->setStringChars(str, strSize);
                   }
                
                RCODE setDump( const BYTE*    d /* [in,flat] byte  d[]  */
                             , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                             )
                   {
                
                
                    return pif->setDump(d, dumpSize);
                   }
                
                RCODE setDate( const STRUCT_CLI_CLISYSTEMTIME    &datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->setDate(&datetime);
                   }
                
                RCODE setBool( BOOL    b /* [in] bool  b  */)
                   {
                
                    return pif->setBool(b);
                   }
                
                RCODE setUnknown( INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */)
                   {
                
                    return pif->setUnknown(pUnknown);
                   }
                
                RCODE setBigInteger( const STRUCT_CLI_BIGINTEGER    &bigint /* [in,ref] ::cli::BigInteger  bigint  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->setBigInteger(&bigint);
                   }
                
                RCODE setRationalNumber( const STRUCT_CLI_RATIONALNUMBER    &rational /* [in,ref] ::cli::RationalNumber  rational  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->setRationalNumber(&rational);
                   }
                
                RCODE getChar( CHAR*    ch /* [out] char ch  */)
                   {
                
                    return pif->getChar(ch);
                   }
                
                RCODE getWChar( WCHAR*    wch /* [out] wchar wch  */)
                   {
                
                    return pif->getWChar(wch);
                   }
                
                RCODE getShort( SHORT*    s /* [out] short s  */)
                   {
                
                    return pif->getShort(s);
                   }
                
                RCODE getUShort( USHORT*    us /* [out] ushort us  */)
                   {
                
                    return pif->getUShort(us);
                   }
                
                RCODE getInt( INT*    i /* [out] int i  */)
                   {
                
                    return pif->getInt(i);
                   }
                
                RCODE getUInt( UINT*    i /* [out] uint i  */)
                   {
                
                    return pif->getUInt(i);
                   }
                
                RCODE getColorref( COLORREF*    i /* [out] colorref i  */)
                   {
                
                    return pif->getColorref(i);
                   }
                
                RCODE getInt64( INT64*    i /* [out] int64 i  */)
                   {
                
                    return pif->getInt64(i);
                   }
                
                RCODE getUInt64( UINT64*    i /* [out] uint64 i  */)
                   {
                
                    return pif->getUInt64(i);
                   }
                
                RCODE getIntPtr( INT_PTR*    i /* [out] int_ptr i  */)
                   {
                
                    return pif->getIntPtr(i);
                   }
                
                RCODE getUIntPtr( UINT_PTR*    i /* [out] uint_ptr i  */)
                   {
                
                    return pif->getUIntPtr(i);
                   }
                
                RCODE getFloat( FLOAT*    f /* [out] float f  */)
                   {
                
                    return pif->getFloat(f);
                   }
                
                RCODE getDouble( DOUBLE*    d /* [out] double d  */)
                   {
                
                    return pif->getDouble(d);
                   }
                
                RCODE getPtr( VOID**    vptr /* [out] void* vptr  */)
                   {
                
                    return pif->getPtr(vptr);
                   }
                
                RCODE getString( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getString(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getStringPStr( ::std::wstring    &str)
                   {
                    CCliPStr tmp_str; CCliPStr_init( tmp_str );
                    RCODE res = pif->getStringPStr(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliPStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getStringChars( WCHAR*    buf /* [out,flat] wchar buf[]  */
                                    , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                    )
                   {
                
                
                    return pif->getStringChars(buf, bufSize);
                   }
                
                RCODE getDump( ::std::string    &str)
                   {
                    CCliPCStr tmp_str; CCliPCStr_init( tmp_str );
                    RCODE res = pif->getDump(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliPCStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getDate( STRUCT_CLI_CLISYSTEMTIME    &datetime /* [out] ::cli::CLISYSTEMTIME datetime  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->getDate(&datetime);
                   }
                
                RCODE getBool( BOOL*    b /* [out] bool b  */)
                   {
                
                    return pif->getBool(b);
                   }
                
                RCODE getUnknown( INTERFACE_CLI_IUNKNOWN**    pUnknown /* [out] ::cli::iUnknown* pUnknown  */)
                   {
                
                    return pif->getUnknown(pUnknown);
                   }
                
                RCODE getBigInteger( STRUCT_CLI_BIGINTEGER    &bigint /* [out] ::cli::BigInteger bigint  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->getBigInteger(&bigint);
                   }
                
                RCODE getRationalNumber( STRUCT_CLI_RATIONALNUMBER    &rational /* [out] ::cli::RationalNumber rational  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->getRationalNumber(&rational);
                   }
                

        
        
        }; // class CiVariantWrapper
        
        typedef CiVariantWrapper< ::cli::CCliPtr< INTERFACE_CLI_IVARIANT     > >  CiVariant;
        typedef CiVariantWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IVARIANT > >  CiVariant_nrc; /* No ref counting for interface used */
        typedef CiVariantWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IVARIANT > >  CiVariant_tmp; /* for temporary usage, same as CiVariant_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iVariantConvert */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IVARIANTCONVERT_IID
    #define INTERFACE_CLI_IVARIANTCONVERT_IID    "/cli/iVariantConvert"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iVariantConvert
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IVARIANTCONVERT
       #define INTERFACE_CLI_IVARIANTCONVERT    ::cli::iVariantConvert
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iVariantConvert
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IVARIANTCONVERT
       #define INTERFACE_CLI_IVARIANTCONVERT    cli_iVariantConvert
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iVariantConvert methods */
            CLIMETHOD(objectValueToString) (THIS_ CLISTR*           str) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iVariantConvert >
           {
            static char const * getName() { return INTERFACE_CLI_IVARIANTCONVERT_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iVariantConvert* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iVariantConvert > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iVariantConvert wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IVARIANTCONVERT >
                                      */
                 >
        class CiVariantConvertWrapper
        {
            public:
        
                typedef  CiVariantConvertWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiVariantConvertWrapper() :
                   pif(0) {}
        
                CiVariantConvertWrapper( iVariantConvert *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiVariantConvertWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiVariantConvertWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiVariantConvertWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiVariantConvertWrapper(const CiVariantConvertWrapper &i) :
                    pif(i.pif) { }
        
                ~CiVariantConvertWrapper()  { }
        
                CiVariantConvertWrapper& operator=(const CiVariantConvertWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE objectValueToString( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->objectValueToString(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                

        
        
        }; // class CiVariantConvertWrapper
        
        typedef CiVariantConvertWrapper< ::cli::CCliPtr< INTERFACE_CLI_IVARIANTCONVERT     > >  CiVariantConvert;
        typedef CiVariantConvertWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IVARIANTCONVERT > >  CiVariantConvert_nrc; /* No ref counting for interface used */
        typedef CiVariantConvertWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IVARIANTCONVERT > >  CiVariantConvert_tmp; /* for temporary usage, same as CiVariantConvert_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IVARIANT_H */
