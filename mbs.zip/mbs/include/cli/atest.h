#ifndef CLI_ATEST_H
#define CLI_ATEST_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/atest.h>", CLI_ATEST_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_ATEST_H
    #include <cli/atest.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif


/* ------------------------------------------------------ */
/* Union: ::atest::AUnion */
/* ------------------------------------------------------ */

#ifdef CLI_UNION_NAME
   #undef CLI_UNION_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace atest {
    #define CLI_UNION_NAME                   AUnion
    #ifndef UNION_ATEST_AUNION_PREDECLARED
    #define UNION_ATEST_AUNION_PREDECLARED
        struct AUnion;
        #ifndef UNION_ATEST_AUNION
            #define UNION_ATEST_AUNION                ::atest::AUnion
        #endif
        #ifndef UNION_ATEST_AUN
            #define UNION_ATEST_AUN                   ::atest::AUN
        #endif
        typedef UNION_ATEST_AUNION                AUN;

    #endif // UNION_ATEST_AUNION_PREDECLARED

#else /* C-like declarations */

    #define CLI_UNION_NAME                   atest_AUnion
    #ifndef UNION_ATEST_AUNION_PREDECLARED
    #define UNION_ATEST_AUNION_PREDECLARED
        struct  tag_atest_AUnion;
        typedef struct tag_atest_AUnion atest_AUnion;
        #ifndef UNION_ATEST_AUNION
            #define UNION_ATEST_AUNION                struct tag_atest_AUnion
        #endif
        #ifndef UNION_ATEST_AUN
            #define UNION_ATEST_AUN                   atest_AUN
        #endif
        typedef UNION_ATEST_AUNION                atest_AUN;

    #endif // UNION_ATEST_AUNION_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef UNION_ATEST_AUNION_DEFINED
        #define UNION_ATEST_AUNION_DEFINED
        CLI_BEGIN_UNION_DECLARATION(CLI_UNION_NAME)
            INT                         a;
            CHAR                        b;
        CLI_END_UNION_DECLARATION(CLI_UNION_NAME);
        #endif // UNION_ATEST_AUNION_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest
#endif


/* ------------------------------------------------------ */
/* Struct: ::atest::AStruct */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace atest {
    #define CLI_STRUCT_NAME                   AStruct
    #ifndef STRUCT_ATEST_ASTRUCT_PREDECLARED
    #define STRUCT_ATEST_ASTRUCT_PREDECLARED
        struct AStruct;
        #ifndef STRUCT_ATEST_ASTRUCT
            #define STRUCT_ATEST_ASTRUCT              ::atest::AStruct
        #endif
        #ifndef STRUCT_ATEST_ASTRU
            #define STRUCT_ATEST_ASTRU                ::atest::ASTRU
        #endif
        typedef STRUCT_ATEST_ASTRUCT              ASTRU;

    #endif // STRUCT_ATEST_ASTRUCT_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   atest_AStruct
    #ifndef STRUCT_ATEST_ASTRUCT_PREDECLARED
    #define STRUCT_ATEST_ASTRUCT_PREDECLARED
        struct  tag_atest_AStruct;
        typedef struct tag_atest_AStruct atest_AStruct;
        #ifndef STRUCT_ATEST_ASTRUCT
            #define STRUCT_ATEST_ASTRUCT              struct tag_atest_AStruct
        #endif
        #ifndef STRUCT_ATEST_ASTRU
            #define STRUCT_ATEST_ASTRU                atest_ASTRU
        #endif
        typedef STRUCT_ATEST_ASTRUCT              atest_ASTRU;

    #endif // STRUCT_ATEST_ASTRUCT_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef STRUCT_ATEST_ASTRUCT_DEFINED
        #define STRUCT_ATEST_ASTRUCT_DEFINED
        #include <cli/pshpack8.h>
        CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
            INT                         a;
            INT                         b;
            UNION_ATEST_AUNION          u;
        CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
        #include <cli/poppack.h>
        #endif // STRUCT_ATEST_ASTRUCT_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest
#endif


/* ------------------------------------------------------ */
/* Interface: ::atest::iTestBase */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_ATEST_ITESTBASE_IID
    #define INTERFACE_ATEST_ITESTBASE_IID    "/atest/iTestBase"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace atest {
    #define INTERFACE iTestBase
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_ATEST_ITESTBASE
       #define INTERFACE_ATEST_ITESTBASE    ::atest::iTestBase
    #endif
#else /* C-like declaration */
    #define INTERFACE atest_iTestBase
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_ATEST_ITESTBASE
       #define INTERFACE_ATEST_ITESTBASE    atest_iTestBase
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::atest::iTestBase methods */
            CLIMETHOD(strBaseGet) (THIS_ CLISTR*           _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSet) (THIS_ const CLISTR*     _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(strBaseSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    ) PURE;
            CLIMETHOD(structSimpleGet) (THIS_ STRUCT_ATEST_ASTRUCT*    _structSimple /* [out] ::atest::AStruct _structSimple  */) PURE;
            CLIMETHOD(structSimpleSet) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structSimple /* [in,ref] ::atest::AStruct  _structSimple  */) PURE;
            CLIMETHOD(structV1Get) (THIS_ STRUCT_ATEST_ASTRUCT*    _structV1 /* [out] ::atest::AStruct _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Set) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structV1 /* [in,ref] ::atest::AStruct  _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Size) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Get) (THIS_ UNION_ATEST_AUNION*    _structV2 /* [out] ::atest::AUnion _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Set) (THIS_ const UNION_ATEST_AUNION*    _structV2 /* [in,ref] ::atest::AUnion  _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Size1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Size2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest

    namespace cli{
        template<> struct CIidOfImpl< ::atest::iTestBase >
           {
            static char const * getName() { return INTERFACE_ATEST_ITESTBASE_IID; }
           };
        template<> struct CIidOfImpl< ::atest::iTestBase* >
           {
            static char const * getName() { return CIidOfImpl< ::atest::iTestBase > :: getName(); }
           };
    }; // namespace cli

    namespace atest {
        // interface ::atest::iTestBase wrapper
        // generated from f:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_ATEST_ITESTBASE >
                                      */
                 >
        class CiTestBaseWrapper
        {
            public:
        
                typedef  CiTestBaseWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestBaseWrapper() :
                   pif(0) {}
        
                CiTestBaseWrapper( iTestBase *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTestBaseWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTestBaseWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTestBaseWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTestBaseWrapper(const CiTestBaseWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestBaseWrapper()  { }
        
                CiTestBaseWrapper& operator=(const CiTestBaseWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strBase( SIZE_T idx1
                                          , SIZE_T idx2
                                          )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strBaseGet( tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strBase( SIZE_T idx1
                                , SIZE_T idx2
                                , const ::std::wstring &_strBase
                                )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = strBaseSet( _strBase, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_strBase(  )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_strBase( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, ::std::wstring, strBase, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strBaseGet( ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_init( tmp__strBase );
                
                
                    RCODE res = pif->strBaseGet(&tmp__strBase, idx1, idx2);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strBase, tmp__strBase);
                       }
                    return res;
                   }
                
                RCODE strBaseSet( const ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_lightCopyTo( tmp__strBase, _strBase);
                
                
                    return pif->strBaseSet(&tmp__strBase, idx1, idx2);
                   }
                
                RCODE strBaseSize1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strBaseSize1(_size);
                   }
                
                RCODE strBaseSize2( SIZE_T*    _size /* [out] size_t _size  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
                   {
                
                
                    return pif->strBaseSize2(_size, idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structSimple( )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structSimpleGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structSimple( const STRUCT_ATEST_ASTRUCT &_structSimple
                                     )
                   {
                    RCODE res = structSimpleSet( _structSimple );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_ATEST_ASTRUCT, structSimple );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structSimpleGet( STRUCT_ATEST_ASTRUCT    &_structSimple /* [out] ::atest::AStruct _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleGet(&_structSimple);
                   }
                
                RCODE structSimpleSet( const STRUCT_ATEST_ASTRUCT    &_structSimple /* [in,ref] ::atest::AStruct  _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleSet(&_structSimple);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structV1( SIZE_T idx1 )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structV1Get( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV1( SIZE_T idx1 , const STRUCT_ATEST_ASTRUCT &_structV1
                                 )
                   { // MS style - index goes before value, need reorder
                    RCODE res = structV1Set( _structV1, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_structV1(  )
                   {
                    SIZE_T size;
                    RCODE res = structV1Size( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, STRUCT_ATEST_ASTRUCT, structV1, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV1Get( STRUCT_ATEST_ASTRUCT    &_structV1 /* [out] ::atest::AStruct _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Get(&_structV1, idx1);
                   }
                
                RCODE structV1Set( const STRUCT_ATEST_ASTRUCT    &_structV1 /* [in,ref] ::atest::AStruct  _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Set(&_structV1, idx1);
                   }
                
                RCODE structV1Size( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV1Size(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                UNION_ATEST_AUNION get_structV2( SIZE_T idx1
                                               , SIZE_T idx2
                                               )
                   {
                    UNION_ATEST_AUNION tmpVal;
                    RCODE res = structV2Get( &tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV2( SIZE_T idx1
                                 , SIZE_T idx2
                                 , UNION_ATEST_AUNION _structV2
                                 )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = structV2Set( _structV2, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_structV2(  )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_structV2( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, UNION_ATEST_AUNION, structV2, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV2Get( UNION_ATEST_AUNION    &_structV2 /* [out] ::atest::AUnion _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Get(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Set( const UNION_ATEST_AUNION    &_structV2 /* [in,ref] ::atest::AUnion  _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Set(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Size1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV2Size1(_size);
                   }
                
                RCODE structV2Size2( SIZE_T*    _size /* [out] size_t _size  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   )
                   {
                
                
                    return pif->structV2Size2(_size, idx1);
                   }
                

        
        
        }; // class CiTestBaseWrapper
        
        typedef CiTestBaseWrapper< ::cli::CCliPtr< INTERFACE_ATEST_ITESTBASE     > >  CiTestBase;
        typedef CiTestBaseWrapper< ::cli::CFoolishPtr< INTERFACE_ATEST_ITESTBASE > >  CiTestBase_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace atest

#endif






/* ------------------------------------------------------ */
/* Interface: ::atest::iTestEx */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace atest {
        interface                                iTestBase;
        #ifndef INTERFACE_ATEST_ITESTBASE
            #define INTERFACE_ATEST_ITESTBASE         ::atest::iTestBase
        #endif

    }; // namespace atest

#else /* C-like declarations */

    #ifndef INTERFACE_ATEST_ITESTBASE_PREDECLARED
    #define INTERFACE_ATEST_ITESTBASE_PREDECLARED
    typedef interface tag_atest_iTestBase    atest_iTestBase;
    #endif //INTERFACE_ATEST_ITESTBASE
    #ifndef INTERFACE_ATEST_ITESTBASE
        #define INTERFACE_ATEST_ITESTBASE         struct tag_atest_iTestBase
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_ATEST_ITESTEX_IID
    #define INTERFACE_ATEST_ITESTEX_IID    "/atest/iTestEx"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace atest {
    #define INTERFACE iTestEx
    #define BASE_INTERFACE ::atest::iTestBase
    #ifndef INTERFACE_ATEST_ITESTEX
       #define INTERFACE_ATEST_ITESTEX    ::atest::iTestEx
    #endif
#else /* C-like declaration */
    #define INTERFACE atest_iTestEx
    #define BASE_INTERFACE atest_iTestBase
    #ifndef INTERFACE_ATEST_ITESTEX
       #define INTERFACE_ATEST_ITESTEX    atest_iTestEx
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::atest::iTestBase methods */
            CLIMETHOD(strBaseGet) (THIS_ CLISTR*           _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSet) (THIS_ const CLISTR*     _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(strBaseSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    ) PURE;
            CLIMETHOD(structSimpleGet) (THIS_ STRUCT_ATEST_ASTRUCT*    _structSimple /* [out] ::atest::AStruct _structSimple  */) PURE;
            CLIMETHOD(structSimpleSet) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structSimple /* [in,ref] ::atest::AStruct  _structSimple  */) PURE;
            CLIMETHOD(structV1Get) (THIS_ STRUCT_ATEST_ASTRUCT*    _structV1 /* [out] ::atest::AStruct _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Set) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structV1 /* [in,ref] ::atest::AStruct  _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Size) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Get) (THIS_ UNION_ATEST_AUNION*    _structV2 /* [out] ::atest::AUnion _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Set) (THIS_ const UNION_ATEST_AUNION*    _structV2 /* [in,ref] ::atest::AUnion  _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Size1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Size2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     ) PURE;
            
            /* interface ::atest::iTestEx methods */
            CLIMETHOD(strExGet) (THIS_ CLISTR*           _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSet) (THIS_ const CLISTR*     _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest

    namespace cli{
        template<> struct CIidOfImpl< ::atest::iTestEx >
           {
            static char const * getName() { return INTERFACE_ATEST_ITESTEX_IID; }
           };
        template<> struct CIidOfImpl< ::atest::iTestEx* >
           {
            static char const * getName() { return CIidOfImpl< ::atest::iTestEx > :: getName(); }
           };
    }; // namespace cli

    namespace atest {
        // interface ::atest::iTestEx wrapper
        // generated from f:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_ATEST_ITESTEX >
                                      */
                 >
        class CiTestExWrapper
        {
            public:
        
                typedef  CiTestExWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestExWrapper() :
                   pif(0) {}
        
                CiTestExWrapper( iTestEx *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTestExWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTestExWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTestExWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTestExWrapper(const CiTestExWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestExWrapper()  { }
        
                CiTestExWrapper& operator=(const CiTestExWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strBase( SIZE_T idx1
                                          , SIZE_T idx2
                                          )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strBaseGet( tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strBase( SIZE_T idx1
                                , SIZE_T idx2
                                , const ::std::wstring &_strBase
                                )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = strBaseSet( _strBase, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_strBase(  )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_strBase( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, ::std::wstring, strBase, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strBaseGet( ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_init( tmp__strBase );
                
                
                    RCODE res = pif->strBaseGet(&tmp__strBase, idx1, idx2);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strBase, tmp__strBase);
                       }
                    return res;
                   }
                
                RCODE strBaseSet( const ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_lightCopyTo( tmp__strBase, _strBase);
                
                
                    return pif->strBaseSet(&tmp__strBase, idx1, idx2);
                   }
                
                RCODE strBaseSize1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strBaseSize1(_size);
                   }
                
                RCODE strBaseSize2( SIZE_T*    _size /* [out] size_t _size  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
                   {
                
                
                    return pif->strBaseSize2(_size, idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structSimple( )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structSimpleGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structSimple( const STRUCT_ATEST_ASTRUCT &_structSimple
                                     )
                   {
                    RCODE res = structSimpleSet( _structSimple );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_ATEST_ASTRUCT, structSimple );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structSimpleGet( STRUCT_ATEST_ASTRUCT    &_structSimple /* [out] ::atest::AStruct _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleGet(&_structSimple);
                   }
                
                RCODE structSimpleSet( const STRUCT_ATEST_ASTRUCT    &_structSimple /* [in,ref] ::atest::AStruct  _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleSet(&_structSimple);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structV1( SIZE_T idx1 )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structV1Get( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV1( SIZE_T idx1 , const STRUCT_ATEST_ASTRUCT &_structV1
                                 )
                   { // MS style - index goes before value, need reorder
                    RCODE res = structV1Set( _structV1, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_structV1(  )
                   {
                    SIZE_T size;
                    RCODE res = structV1Size( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, STRUCT_ATEST_ASTRUCT, structV1, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV1Get( STRUCT_ATEST_ASTRUCT    &_structV1 /* [out] ::atest::AStruct _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Get(&_structV1, idx1);
                   }
                
                RCODE structV1Set( const STRUCT_ATEST_ASTRUCT    &_structV1 /* [in,ref] ::atest::AStruct  _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Set(&_structV1, idx1);
                   }
                
                RCODE structV1Size( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV1Size(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                UNION_ATEST_AUNION get_structV2( SIZE_T idx1
                                               , SIZE_T idx2
                                               )
                   {
                    UNION_ATEST_AUNION tmpVal;
                    RCODE res = structV2Get( &tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV2( SIZE_T idx1
                                 , SIZE_T idx2
                                 , UNION_ATEST_AUNION _structV2
                                 )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = structV2Set( _structV2, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_structV2(  )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_structV2( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, UNION_ATEST_AUNION, structV2, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV2Get( UNION_ATEST_AUNION    &_structV2 /* [out] ::atest::AUnion _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Get(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Set( const UNION_ATEST_AUNION    &_structV2 /* [in,ref] ::atest::AUnion  _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Set(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Size1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV2Size1(_size);
                   }
                
                RCODE structV2Size2( SIZE_T*    _size /* [out] size_t _size  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   )
                   {
                
                
                    return pif->structV2Size2(_size, idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strEx( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strExGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strEx( SIZE_T idx1 , const ::std::wstring &_strEx
                              )
                   { // MS style - index goes before value, need reorder
                    RCODE res = strExSet( _strEx, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_strEx(  )
                   {
                    SIZE_T size;
                    RCODE res = strExSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, strEx, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strExGet( ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_init( tmp__strEx );
                
                    RCODE res = pif->strExGet(&tmp__strEx, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strEx, tmp__strEx);
                       }
                    return res;
                   }
                
                RCODE strExSet( const ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_lightCopyTo( tmp__strEx, _strEx);
                
                    return pif->strExSet(&tmp__strEx, idx1);
                   }
                
                RCODE strExSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strExSize(_size);
                   }
                

        
        
        }; // class CiTestExWrapper
        
        typedef CiTestExWrapper< ::cli::CCliPtr< INTERFACE_ATEST_ITESTEX     > >  CiTestEx;
        typedef CiTestExWrapper< ::cli::CFoolishPtr< INTERFACE_ATEST_ITESTEX > >  CiTestEx_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace atest

#endif






/* ------------------------------------------------------ */
/* Interface: ::atest::iTestAnotherEx */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_ATEST_ITESTANOTHEREX_IID
    #define INTERFACE_ATEST_ITESTANOTHEREX_IID    "/atest/iTestAnotherEx"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace atest {
    #define INTERFACE iTestAnotherEx
    #define BASE_INTERFACE ::atest::iTestBase
    #ifndef INTERFACE_ATEST_ITESTANOTHEREX
       #define INTERFACE_ATEST_ITESTANOTHEREX    ::atest::iTestAnotherEx
    #endif
#else /* C-like declaration */
    #define INTERFACE atest_iTestAnotherEx
    #define BASE_INTERFACE atest_iTestBase
    #ifndef INTERFACE_ATEST_ITESTANOTHEREX
       #define INTERFACE_ATEST_ITESTANOTHEREX    atest_iTestAnotherEx
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::atest::iTestBase methods */
            CLIMETHOD(strBaseGet) (THIS_ CLISTR*           _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSet) (THIS_ const CLISTR*     _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(strBaseSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    ) PURE;
            CLIMETHOD(structSimpleGet) (THIS_ STRUCT_ATEST_ASTRUCT*    _structSimple /* [out] ::atest::AStruct _structSimple  */) PURE;
            CLIMETHOD(structSimpleSet) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structSimple /* [in,ref] ::atest::AStruct  _structSimple  */) PURE;
            CLIMETHOD(structV1Get) (THIS_ STRUCT_ATEST_ASTRUCT*    _structV1 /* [out] ::atest::AStruct _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Set) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structV1 /* [in,ref] ::atest::AStruct  _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Size) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Get) (THIS_ UNION_ATEST_AUNION*    _structV2 /* [out] ::atest::AUnion _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Set) (THIS_ const UNION_ATEST_AUNION*    _structV2 /* [in,ref] ::atest::AUnion  _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Size1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Size2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     ) PURE;
            
            /* interface ::atest::iTestAnotherEx methods */
            CLIMETHOD(doSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
            CLIMETHOD(strExGet) (THIS_ CLISTR*           _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSet) (THIS_ const CLISTR*     _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest

    namespace cli{
        template<> struct CIidOfImpl< ::atest::iTestAnotherEx >
           {
            static char const * getName() { return INTERFACE_ATEST_ITESTANOTHEREX_IID; }
           };
        template<> struct CIidOfImpl< ::atest::iTestAnotherEx* >
           {
            static char const * getName() { return CIidOfImpl< ::atest::iTestAnotherEx > :: getName(); }
           };
    }; // namespace cli

    namespace atest {
        // interface ::atest::iTestAnotherEx wrapper
        // generated from f:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_ATEST_ITESTANOTHEREX >
                                      */
                 >
        class CiTestAnotherExWrapper
        {
            public:
        
                typedef  CiTestAnotherExWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestAnotherExWrapper() :
                   pif(0) {}
        
                CiTestAnotherExWrapper( iTestAnotherEx *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTestAnotherExWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTestAnotherExWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTestAnotherExWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTestAnotherExWrapper(const CiTestAnotherExWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestAnotherExWrapper()  { }
        
                CiTestAnotherExWrapper& operator=(const CiTestAnotherExWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strBase( SIZE_T idx1
                                          , SIZE_T idx2
                                          )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strBaseGet( tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strBase( SIZE_T idx1
                                , SIZE_T idx2
                                , const ::std::wstring &_strBase
                                )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = strBaseSet( _strBase, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_strBase(  )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_strBase( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, ::std::wstring, strBase, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strBaseGet( ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_init( tmp__strBase );
                
                
                    RCODE res = pif->strBaseGet(&tmp__strBase, idx1, idx2);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strBase, tmp__strBase);
                       }
                    return res;
                   }
                
                RCODE strBaseSet( const ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_lightCopyTo( tmp__strBase, _strBase);
                
                
                    return pif->strBaseSet(&tmp__strBase, idx1, idx2);
                   }
                
                RCODE strBaseSize1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strBaseSize1(_size);
                   }
                
                RCODE strBaseSize2( SIZE_T*    _size /* [out] size_t _size  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
                   {
                
                
                    return pif->strBaseSize2(_size, idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structSimple( )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structSimpleGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structSimple( const STRUCT_ATEST_ASTRUCT &_structSimple
                                     )
                   {
                    RCODE res = structSimpleSet( _structSimple );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_ATEST_ASTRUCT, structSimple );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structSimpleGet( STRUCT_ATEST_ASTRUCT    &_structSimple /* [out] ::atest::AStruct _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleGet(&_structSimple);
                   }
                
                RCODE structSimpleSet( const STRUCT_ATEST_ASTRUCT    &_structSimple /* [in,ref] ::atest::AStruct  _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleSet(&_structSimple);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structV1( SIZE_T idx1 )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structV1Get( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV1( SIZE_T idx1 , const STRUCT_ATEST_ASTRUCT &_structV1
                                 )
                   { // MS style - index goes before value, need reorder
                    RCODE res = structV1Set( _structV1, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_structV1(  )
                   {
                    SIZE_T size;
                    RCODE res = structV1Size( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, STRUCT_ATEST_ASTRUCT, structV1, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV1Get( STRUCT_ATEST_ASTRUCT    &_structV1 /* [out] ::atest::AStruct _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Get(&_structV1, idx1);
                   }
                
                RCODE structV1Set( const STRUCT_ATEST_ASTRUCT    &_structV1 /* [in,ref] ::atest::AStruct  _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Set(&_structV1, idx1);
                   }
                
                RCODE structV1Size( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV1Size(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                UNION_ATEST_AUNION get_structV2( SIZE_T idx1
                                               , SIZE_T idx2
                                               )
                   {
                    UNION_ATEST_AUNION tmpVal;
                    RCODE res = structV2Get( &tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV2( SIZE_T idx1
                                 , SIZE_T idx2
                                 , UNION_ATEST_AUNION _structV2
                                 )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = structV2Set( _structV2, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_structV2(  )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_structV2( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, UNION_ATEST_AUNION, structV2, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV2Get( UNION_ATEST_AUNION    &_structV2 /* [out] ::atest::AUnion _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Get(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Set( const UNION_ATEST_AUNION    &_structV2 /* [in,ref] ::atest::AUnion  _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Set(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Size1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV2Size1(_size);
                   }
                
                RCODE structV2Size2( SIZE_T*    _size /* [out] size_t _size  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   )
                   {
                
                
                    return pif->structV2Size2(_size, idx1);
                   }
                
                RCODE doSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->doSomething(some);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strEx( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strExGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strEx( SIZE_T idx1 , const ::std::wstring &_strEx
                              )
                   { // MS style - index goes before value, need reorder
                    RCODE res = strExSet( _strEx, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_strEx(  )
                   {
                    SIZE_T size;
                    RCODE res = strExSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, strEx, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strExGet( ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_init( tmp__strEx );
                
                    RCODE res = pif->strExGet(&tmp__strEx, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strEx, tmp__strEx);
                       }
                    return res;
                   }
                
                RCODE strExSet( const ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_lightCopyTo( tmp__strEx, _strEx);
                
                    return pif->strExSet(&tmp__strEx, idx1);
                   }
                
                RCODE strExSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strExSize(_size);
                   }
                

        
        
        }; // class CiTestAnotherExWrapper
        
        typedef CiTestAnotherExWrapper< ::cli::CCliPtr< INTERFACE_ATEST_ITESTANOTHEREX     > >  CiTestAnotherEx;
        typedef CiTestAnotherExWrapper< ::cli::CFoolishPtr< INTERFACE_ATEST_ITESTANOTHEREX > >  CiTestAnotherEx_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace atest

#endif






/* ------------------------------------------------------ */
/* Interface: ::atest::iTestMulti */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace atest {
        interface                                iTestAnotherEx;
        #ifndef INTERFACE_ATEST_ITESTANOTHEREX
            #define INTERFACE_ATEST_ITESTANOTHEREX    ::atest::iTestAnotherEx
        #endif

        interface                                iTestEx;
        #ifndef INTERFACE_ATEST_ITESTEX
            #define INTERFACE_ATEST_ITESTEX           ::atest::iTestEx
        #endif

    }; // namespace atest

#else /* C-like declarations */

    #ifndef INTERFACE_ATEST_ITESTANOTHEREX_PREDECLARED
    #define INTERFACE_ATEST_ITESTANOTHEREX_PREDECLARED
    typedef interface tag_atest_iTestAnotherEx                   atest_iTestAnotherEx;
    #endif //INTERFACE_ATEST_ITESTANOTHEREX
    #ifndef INTERFACE_ATEST_ITESTANOTHEREX
        #define INTERFACE_ATEST_ITESTANOTHEREX    struct tag_atest_iTestAnotherEx
    #endif

    #ifndef INTERFACE_ATEST_ITESTEX_PREDECLARED
    #define INTERFACE_ATEST_ITESTEX_PREDECLARED
    typedef interface tag_atest_iTestEx      atest_iTestEx;
    #endif //INTERFACE_ATEST_ITESTEX
    #ifndef INTERFACE_ATEST_ITESTEX
        #define INTERFACE_ATEST_ITESTEX           struct tag_atest_iTestEx
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_ATEST_ITESTMULTI_IID
    #define INTERFACE_ATEST_ITESTMULTI_IID    "/atest/iTestMulti"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace atest {
    #define INTERFACE iTestMulti
    #define BASE_INTERFACE ::atest::iTestEx
    #ifndef INTERFACE_ATEST_ITESTMULTI
       #define INTERFACE_ATEST_ITESTMULTI    ::atest::iTestMulti
    #endif
#else /* C-like declaration */
    #define INTERFACE atest_iTestMulti
    // Only first interface declared as base
    #define BASE_INTERFACE atest_iTestEx
    #ifndef INTERFACE_ATEST_ITESTMULTI
       #define INTERFACE_ATEST_ITESTMULTI    atest_iTestMulti
    #endif
#endif

        CLI_DECLARE_INTERFACE2_(INTERFACE, BASE_INTERFACE, INTERFACE_ATEST_ITESTANOTHEREX)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::atest::iTestBase methods */
            CLIMETHOD(strBaseGet) (THIS_ CLISTR*           _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSet) (THIS_ const CLISTR*     _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(strBaseSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    ) PURE;
            CLIMETHOD(structSimpleGet) (THIS_ STRUCT_ATEST_ASTRUCT*    _structSimple /* [out] ::atest::AStruct _structSimple  */) PURE;
            CLIMETHOD(structSimpleSet) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structSimple /* [in,ref] ::atest::AStruct  _structSimple  */) PURE;
            CLIMETHOD(structV1Get) (THIS_ STRUCT_ATEST_ASTRUCT*    _structV1 /* [out] ::atest::AStruct _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Set) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structV1 /* [in,ref] ::atest::AStruct  _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Size) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Get) (THIS_ UNION_ATEST_AUNION*    _structV2 /* [out] ::atest::AUnion _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Set) (THIS_ const UNION_ATEST_AUNION*    _structV2 /* [in,ref] ::atest::AUnion  _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Size1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Size2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     ) PURE;
            
            /* interface ::atest::iTestEx methods */
            CLIMETHOD(strExGet) (THIS_ CLISTR*           _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSet) (THIS_ const CLISTR*     _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            
            /* interface ::atest::iTestAnotherEx methods */
            CLIMETHOD(doSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
            CLIMETHOD(strExGet) (THIS_ CLISTR*           _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSet) (THIS_ const CLISTR*     _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            
            /* interface ::atest::iTestMulti methods */
            CLIMETHOD(doSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
            CLIMETHOD(strExGet) (THIS_ CLISTR*           _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSet) (THIS_ const CLISTR*     _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest

    namespace cli{
        template<> struct CIidOfImpl< ::atest::iTestMulti >
           {
            static char const * getName() { return INTERFACE_ATEST_ITESTMULTI_IID; }
           };
        template<> struct CIidOfImpl< ::atest::iTestMulti* >
           {
            static char const * getName() { return CIidOfImpl< ::atest::iTestMulti > :: getName(); }
           };
    }; // namespace cli

    namespace atest {
        // interface ::atest::iTestMulti wrapper
        // generated from f:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_ATEST_ITESTMULTI >
                                      */
                 >
        class CiTestMultiWrapper
        {
            public:
        
                typedef  CiTestMultiWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestMultiWrapper() :
                   pif(0) {}
        
                CiTestMultiWrapper( iTestMulti *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTestMultiWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTestMultiWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTestMultiWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTestMultiWrapper(const CiTestMultiWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestMultiWrapper()  { }
        
                CiTestMultiWrapper& operator=(const CiTestMultiWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strBase( SIZE_T idx1
                                          , SIZE_T idx2
                                          )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strBaseGet( tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strBase( SIZE_T idx1
                                , SIZE_T idx2
                                , const ::std::wstring &_strBase
                                )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = strBaseSet( _strBase, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_strBase(  )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_strBase( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, ::std::wstring, strBase, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strBaseGet( ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_init( tmp__strBase );
                
                
                    RCODE res = pif->strBaseGet(&tmp__strBase, idx1, idx2);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strBase, tmp__strBase);
                       }
                    return res;
                   }
                
                RCODE strBaseSet( const ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_lightCopyTo( tmp__strBase, _strBase);
                
                
                    return pif->strBaseSet(&tmp__strBase, idx1, idx2);
                   }
                
                RCODE strBaseSize1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strBaseSize1(_size);
                   }
                
                RCODE strBaseSize2( SIZE_T*    _size /* [out] size_t _size  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
                   {
                
                
                    return pif->strBaseSize2(_size, idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structSimple( )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structSimpleGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structSimple( const STRUCT_ATEST_ASTRUCT &_structSimple
                                     )
                   {
                    RCODE res = structSimpleSet( _structSimple );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_ATEST_ASTRUCT, structSimple );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structSimpleGet( STRUCT_ATEST_ASTRUCT    &_structSimple /* [out] ::atest::AStruct _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleGet(&_structSimple);
                   }
                
                RCODE structSimpleSet( const STRUCT_ATEST_ASTRUCT    &_structSimple /* [in,ref] ::atest::AStruct  _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleSet(&_structSimple);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structV1( SIZE_T idx1 )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structV1Get( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV1( SIZE_T idx1 , const STRUCT_ATEST_ASTRUCT &_structV1
                                 )
                   { // MS style - index goes before value, need reorder
                    RCODE res = structV1Set( _structV1, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_structV1(  )
                   {
                    SIZE_T size;
                    RCODE res = structV1Size( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, STRUCT_ATEST_ASTRUCT, structV1, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV1Get( STRUCT_ATEST_ASTRUCT    &_structV1 /* [out] ::atest::AStruct _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Get(&_structV1, idx1);
                   }
                
                RCODE structV1Set( const STRUCT_ATEST_ASTRUCT    &_structV1 /* [in,ref] ::atest::AStruct  _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Set(&_structV1, idx1);
                   }
                
                RCODE structV1Size( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV1Size(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                UNION_ATEST_AUNION get_structV2( SIZE_T idx1
                                               , SIZE_T idx2
                                               )
                   {
                    UNION_ATEST_AUNION tmpVal;
                    RCODE res = structV2Get( &tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV2( SIZE_T idx1
                                 , SIZE_T idx2
                                 , UNION_ATEST_AUNION _structV2
                                 )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = structV2Set( _structV2, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_structV2(  )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_structV2( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, UNION_ATEST_AUNION, structV2, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV2Get( UNION_ATEST_AUNION    &_structV2 /* [out] ::atest::AUnion _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Get(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Set( const UNION_ATEST_AUNION    &_structV2 /* [in,ref] ::atest::AUnion  _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Set(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Size1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV2Size1(_size);
                   }
                
                RCODE structV2Size2( SIZE_T*    _size /* [out] size_t _size  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   )
                   {
                
                
                    return pif->structV2Size2(_size, idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strEx( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strExGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strEx( SIZE_T idx1 , const ::std::wstring &_strEx
                              )
                   { // MS style - index goes before value, need reorder
                    RCODE res = strExSet( _strEx, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_strEx(  )
                   {
                    SIZE_T size;
                    RCODE res = strExSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, strEx, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strExGet( ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_init( tmp__strEx );
                
                    RCODE res = pif->strExGet(&tmp__strEx, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strEx, tmp__strEx);
                       }
                    return res;
                   }
                
                RCODE strExSet( const ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_lightCopyTo( tmp__strEx, _strEx);
                
                    return pif->strExSet(&tmp__strEx, idx1);
                   }
                
                RCODE strExSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strExSize(_size);
                   }
                
                RCODE doSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->doSomething(some);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strEx( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strExGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strEx( SIZE_T idx1 , const ::std::wstring &_strEx
                              )
                   { // MS style - index goes before value, need reorder
                    RCODE res = strExSet( _strEx, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_strEx(  )
                   {
                    SIZE_T size;
                    RCODE res = strExSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, strEx, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strExGet( ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_init( tmp__strEx );
                
                    RCODE res = pif->strExGet(&tmp__strEx, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strEx, tmp__strEx);
                       }
                    return res;
                   }
                
                RCODE strExSet( const ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_lightCopyTo( tmp__strEx, _strEx);
                
                    return pif->strExSet(&tmp__strEx, idx1);
                   }
                
                RCODE strExSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strExSize(_size);
                   }
                
                RCODE doSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->doSomething(some);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strEx( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strExGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strEx( SIZE_T idx1 , const ::std::wstring &_strEx
                              )
                   { // MS style - index goes before value, need reorder
                    RCODE res = strExSet( _strEx, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_strEx(  )
                   {
                    SIZE_T size;
                    RCODE res = strExSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, strEx, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strExGet( ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_init( tmp__strEx );
                
                    RCODE res = pif->strExGet(&tmp__strEx, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strEx, tmp__strEx);
                       }
                    return res;
                   }
                
                RCODE strExSet( const ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_lightCopyTo( tmp__strEx, _strEx);
                
                    return pif->strExSet(&tmp__strEx, idx1);
                   }
                
                RCODE strExSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strExSize(_size);
                   }
                

        
        
        }; // class CiTestMultiWrapper
        
        typedef CiTestMultiWrapper< ::cli::CCliPtr< INTERFACE_ATEST_ITESTMULTI     > >  CiTestMulti;
        typedef CiTestMultiWrapper< ::cli::CFoolishPtr< INTERFACE_ATEST_ITESTMULTI > >  CiTestMulti_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace atest

#endif






/* ------------------------------------------------------ */
/* Interface: ::atest::iTestSingle1 */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_ATEST_ITESTSINGLE1_IID
    #define INTERFACE_ATEST_ITESTSINGLE1_IID    "/atest/iTestSingle1"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace atest {
    #define INTERFACE iTestSingle1
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_ATEST_ITESTSINGLE1
       #define INTERFACE_ATEST_ITESTSINGLE1    ::atest::iTestSingle1
    #endif
#else /* C-like declaration */
    #define INTERFACE atest_iTestSingle1
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_ATEST_ITESTSINGLE1
       #define INTERFACE_ATEST_ITESTSINGLE1    atest_iTestSingle1
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::atest::iTestSingle1 methods */
            CLIMETHOD(single1DoSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest

    namespace cli{
        template<> struct CIidOfImpl< ::atest::iTestSingle1 >
           {
            static char const * getName() { return INTERFACE_ATEST_ITESTSINGLE1_IID; }
           };
        template<> struct CIidOfImpl< ::atest::iTestSingle1* >
           {
            static char const * getName() { return CIidOfImpl< ::atest::iTestSingle1 > :: getName(); }
           };
    }; // namespace cli

    namespace atest {
        // interface ::atest::iTestSingle1 wrapper
        // generated from f:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_ATEST_ITESTSINGLE1 >
                                      */
                 >
        class CiTestSingle1Wrapper
        {
            public:
        
                typedef  CiTestSingle1Wrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestSingle1Wrapper() :
                   pif(0) {}
        
                CiTestSingle1Wrapper( iTestSingle1 *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTestSingle1Wrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTestSingle1Wrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTestSingle1Wrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTestSingle1Wrapper(const CiTestSingle1Wrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestSingle1Wrapper()  { }
        
                CiTestSingle1Wrapper& operator=(const CiTestSingle1Wrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE single1DoSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->single1DoSomething(some);
                   }
                

        
        
        }; // class CiTestSingle1Wrapper
        
        typedef CiTestSingle1Wrapper< ::cli::CCliPtr< INTERFACE_ATEST_ITESTSINGLE1     > >  CiTestSingle1;
        typedef CiTestSingle1Wrapper< ::cli::CFoolishPtr< INTERFACE_ATEST_ITESTSINGLE1 > >  CiTestSingle1_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace atest

#endif






/* ------------------------------------------------------ */
/* Interface: ::atest::iTestSingle2 */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_ATEST_ITESTSINGLE2_IID
    #define INTERFACE_ATEST_ITESTSINGLE2_IID    "/atest/iTestSingle2"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace atest {
    #define INTERFACE iTestSingle2
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_ATEST_ITESTSINGLE2
       #define INTERFACE_ATEST_ITESTSINGLE2    ::atest::iTestSingle2
    #endif
#else /* C-like declaration */
    #define INTERFACE atest_iTestSingle2
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_ATEST_ITESTSINGLE2
       #define INTERFACE_ATEST_ITESTSINGLE2    atest_iTestSingle2
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::atest::iTestSingle2 methods */
            CLIMETHOD(single2DoSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest

    namespace cli{
        template<> struct CIidOfImpl< ::atest::iTestSingle2 >
           {
            static char const * getName() { return INTERFACE_ATEST_ITESTSINGLE2_IID; }
           };
        template<> struct CIidOfImpl< ::atest::iTestSingle2* >
           {
            static char const * getName() { return CIidOfImpl< ::atest::iTestSingle2 > :: getName(); }
           };
    }; // namespace cli

    namespace atest {
        // interface ::atest::iTestSingle2 wrapper
        // generated from f:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_ATEST_ITESTSINGLE2 >
                                      */
                 >
        class CiTestSingle2Wrapper
        {
            public:
        
                typedef  CiTestSingle2Wrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestSingle2Wrapper() :
                   pif(0) {}
        
                CiTestSingle2Wrapper( iTestSingle2 *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTestSingle2Wrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTestSingle2Wrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTestSingle2Wrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTestSingle2Wrapper(const CiTestSingle2Wrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestSingle2Wrapper()  { }
        
                CiTestSingle2Wrapper& operator=(const CiTestSingle2Wrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE single2DoSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->single2DoSomething(some);
                   }
                

        
        
        }; // class CiTestSingle2Wrapper
        
        typedef CiTestSingle2Wrapper< ::cli::CCliPtr< INTERFACE_ATEST_ITESTSINGLE2     > >  CiTestSingle2;
        typedef CiTestSingle2Wrapper< ::cli::CFoolishPtr< INTERFACE_ATEST_ITESTSINGLE2 > >  CiTestSingle2_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace atest

#endif






/* ------------------------------------------------------ */
/* Interface: ::atest::iTestMulti2 */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace atest {
        interface                                iTestMulti;
        #ifndef INTERFACE_ATEST_ITESTMULTI
            #define INTERFACE_ATEST_ITESTMULTI        ::atest::iTestMulti
        #endif

        interface                                iTestSingle1;
        #ifndef INTERFACE_ATEST_ITESTSINGLE1
            #define INTERFACE_ATEST_ITESTSINGLE1      ::atest::iTestSingle1
        #endif

        interface                                iTestSingle2;
        #ifndef INTERFACE_ATEST_ITESTSINGLE2
            #define INTERFACE_ATEST_ITESTSINGLE2      ::atest::iTestSingle2
        #endif

    }; // namespace atest

#else /* C-like declarations */

    #ifndef INTERFACE_ATEST_ITESTMULTI_PREDECLARED
    #define INTERFACE_ATEST_ITESTMULTI_PREDECLARED
    typedef interface tag_atest_iTestMulti   atest_iTestMulti;
    #endif //INTERFACE_ATEST_ITESTMULTI
    #ifndef INTERFACE_ATEST_ITESTMULTI
        #define INTERFACE_ATEST_ITESTMULTI        struct tag_atest_iTestMulti
    #endif

    #ifndef INTERFACE_ATEST_ITESTSINGLE1_PREDECLARED
    #define INTERFACE_ATEST_ITESTSINGLE1_PREDECLARED
    typedef interface tag_atest_iTestSingle1 atest_iTestSingle1;
    #endif //INTERFACE_ATEST_ITESTSINGLE1
    #ifndef INTERFACE_ATEST_ITESTSINGLE1
        #define INTERFACE_ATEST_ITESTSINGLE1      struct tag_atest_iTestSingle1
    #endif

    #ifndef INTERFACE_ATEST_ITESTSINGLE2_PREDECLARED
    #define INTERFACE_ATEST_ITESTSINGLE2_PREDECLARED
    typedef interface tag_atest_iTestSingle2 atest_iTestSingle2;
    #endif //INTERFACE_ATEST_ITESTSINGLE2
    #ifndef INTERFACE_ATEST_ITESTSINGLE2
        #define INTERFACE_ATEST_ITESTSINGLE2      struct tag_atest_iTestSingle2
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_ATEST_ITESTMULTI2_IID
    #define INTERFACE_ATEST_ITESTMULTI2_IID    "/atest/iTestMulti2"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace atest {
    #define INTERFACE iTestMulti2
    #define BASE_INTERFACE ::atest::iTestMulti
    #ifndef INTERFACE_ATEST_ITESTMULTI2
       #define INTERFACE_ATEST_ITESTMULTI2    ::atest::iTestMulti2
    #endif
#else /* C-like declaration */
    #define INTERFACE atest_iTestMulti2
    // Only first interface declared as base
    #define BASE_INTERFACE atest_iTestMulti
    #ifndef INTERFACE_ATEST_ITESTMULTI2
       #define INTERFACE_ATEST_ITESTMULTI2    atest_iTestMulti2
    #endif
#endif

        CLI_DECLARE_INTERFACE3_(INTERFACE, BASE_INTERFACE, INTERFACE_ATEST_ITESTSINGLE1, INTERFACE_ATEST_ITESTSINGLE2)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::atest::iTestBase methods */
            CLIMETHOD(strBaseGet) (THIS_ CLISTR*           _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSet) (THIS_ const CLISTR*     _strBase
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  ) PURE;
            CLIMETHOD(strBaseSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(strBaseSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    ) PURE;
            CLIMETHOD(structSimpleGet) (THIS_ STRUCT_ATEST_ASTRUCT*    _structSimple /* [out] ::atest::AStruct _structSimple  */) PURE;
            CLIMETHOD(structSimpleSet) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structSimple /* [in,ref] ::atest::AStruct  _structSimple  */) PURE;
            CLIMETHOD(structV1Get) (THIS_ STRUCT_ATEST_ASTRUCT*    _structV1 /* [out] ::atest::AStruct _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Set) (THIS_ const STRUCT_ATEST_ASTRUCT*    _structV1 /* [in,ref] ::atest::AStruct  _structV1  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   ) PURE;
            CLIMETHOD(structV1Size) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Get) (THIS_ UNION_ATEST_AUNION*    _structV2 /* [out] ::atest::AUnion _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Set) (THIS_ const UNION_ATEST_AUNION*    _structV2 /* [in,ref] ::atest::AUnion  _structV2  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   ) PURE;
            CLIMETHOD(structV2Size1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(structV2Size2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     ) PURE;
            
            /* interface ::atest::iTestEx methods */
            CLIMETHOD(strExGet) (THIS_ CLISTR*           _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSet) (THIS_ const CLISTR*     _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            
            /* interface ::atest::iTestAnotherEx methods */
            CLIMETHOD(doSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
            CLIMETHOD(strExGet) (THIS_ CLISTR*           _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSet) (THIS_ const CLISTR*     _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            
            /* interface ::atest::iTestMulti methods */
            CLIMETHOD(doSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
            CLIMETHOD(strExGet) (THIS_ CLISTR*           _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSet) (THIS_ const CLISTR*     _strEx
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                ) PURE;
            CLIMETHOD(strExSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            
            /* interface ::atest::iTestSingle1 methods */
            CLIMETHOD(single1DoSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
            
            /* interface ::atest::iTestSingle2 methods */
            CLIMETHOD(single2DoSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
            
            /* interface ::atest::iTestMulti2 methods */
            CLIMETHOD(multi2DoSomething) (THIS_ SIZE_T    some /* [in] size_t  some  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace atest

    namespace cli{
        template<> struct CIidOfImpl< ::atest::iTestMulti2 >
           {
            static char const * getName() { return INTERFACE_ATEST_ITESTMULTI2_IID; }
           };
        template<> struct CIidOfImpl< ::atest::iTestMulti2* >
           {
            static char const * getName() { return CIidOfImpl< ::atest::iTestMulti2 > :: getName(); }
           };
    }; // namespace cli

    namespace atest {
        // interface ::atest::iTestMulti2 wrapper
        // generated from f:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_ATEST_ITESTMULTI2 >
                                      */
                 >
        class CiTestMulti2Wrapper
        {
            public:
        
                typedef  CiTestMulti2Wrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTestMulti2Wrapper() :
                   pif(0) {}
        
                CiTestMulti2Wrapper( iTestMulti2 *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTestMulti2Wrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTestMulti2Wrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTestMulti2Wrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTestMulti2Wrapper(const CiTestMulti2Wrapper &i) :
                    pif(i.pif) { }
        
                ~CiTestMulti2Wrapper()  { }
        
                CiTestMulti2Wrapper& operator=(const CiTestMulti2Wrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strBase( SIZE_T idx1
                                          , SIZE_T idx2
                                          )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strBaseGet( tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strBase( SIZE_T idx1
                                , SIZE_T idx2
                                , const ::std::wstring &_strBase
                                )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = strBaseSet( _strBase, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_strBase(  )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_strBase( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = strBaseSize2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, ::std::wstring, strBase, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strBaseGet( ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_init( tmp__strBase );
                
                
                    RCODE res = pif->strBaseGet(&tmp__strBase, idx1, idx2);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strBase, tmp__strBase);
                       }
                    return res;
                   }
                
                RCODE strBaseSet( const ::std::wstring    &_strBase
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                )
                   {
                    CCliStr tmp__strBase; CCliStr_lightCopyTo( tmp__strBase, _strBase);
                
                
                    return pif->strBaseSet(&tmp__strBase, idx1, idx2);
                   }
                
                RCODE strBaseSize1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strBaseSize1(_size);
                   }
                
                RCODE strBaseSize2( SIZE_T*    _size /* [out] size_t _size  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
                   {
                
                
                    return pif->strBaseSize2(_size, idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structSimple( )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structSimpleGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structSimple( const STRUCT_ATEST_ASTRUCT &_structSimple
                                     )
                   {
                    RCODE res = structSimpleSet( _structSimple );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_ATEST_ASTRUCT, structSimple );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structSimpleGet( STRUCT_ATEST_ASTRUCT    &_structSimple /* [out] ::atest::AStruct _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleGet(&_structSimple);
                   }
                
                RCODE structSimpleSet( const STRUCT_ATEST_ASTRUCT    &_structSimple /* [in,ref] ::atest::AStruct  _structSimple  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->structSimpleSet(&_structSimple);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                STRUCT_ATEST_ASTRUCT get_structV1( SIZE_T idx1 )
                   {
                    STRUCT_ATEST_ASTRUCT tmpVal;
                    RCODE res = structV1Get( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV1( SIZE_T idx1 , const STRUCT_ATEST_ASTRUCT &_structV1
                                 )
                   { // MS style - index goes before value, need reorder
                    RCODE res = structV1Set( _structV1, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_structV1(  )
                   {
                    SIZE_T size;
                    RCODE res = structV1Size( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, STRUCT_ATEST_ASTRUCT, structV1, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV1Get( STRUCT_ATEST_ASTRUCT    &_structV1 /* [out] ::atest::AStruct _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Get(&_structV1, idx1);
                   }
                
                RCODE structV1Set( const STRUCT_ATEST_ASTRUCT    &_structV1 /* [in,ref] ::atest::AStruct  _structV1  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
                   {
                
                
                    return pif->structV1Set(&_structV1, idx1);
                   }
                
                RCODE structV1Size( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV1Size(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                UNION_ATEST_AUNION get_structV2( SIZE_T idx1
                                               , SIZE_T idx2
                                               )
                   {
                    UNION_ATEST_AUNION tmpVal;
                    RCODE res = structV2Get( &tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_structV2( SIZE_T idx1
                                 , SIZE_T idx2
                                 , UNION_ATEST_AUNION _structV2
                                 )
                   { // MS style - indeces are before value, need reorder
                    RCODE res = structV2Set( _structV2, idx1, idx2 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size1_structV2(  )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_structV2( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = structV2Size2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, UNION_ATEST_AUNION, structV2, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE structV2Get( UNION_ATEST_AUNION    &_structV2 /* [out] ::atest::AUnion _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Get(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Set( const UNION_ATEST_AUNION    &_structV2 /* [in,ref] ::atest::AUnion  _structV2  (struct passed by ref in wrapper) */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
                   {
                
                
                
                    return pif->structV2Set(_structV2, idx1, idx2);
                   }
                
                RCODE structV2Size1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->structV2Size1(_size);
                   }
                
                RCODE structV2Size2( SIZE_T*    _size /* [out] size_t _size  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   )
                   {
                
                
                    return pif->structV2Size2(_size, idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strEx( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strExGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strEx( SIZE_T idx1 , const ::std::wstring &_strEx
                              )
                   { // MS style - index goes before value, need reorder
                    RCODE res = strExSet( _strEx, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_strEx(  )
                   {
                    SIZE_T size;
                    RCODE res = strExSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, strEx, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strExGet( ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_init( tmp__strEx );
                
                    RCODE res = pif->strExGet(&tmp__strEx, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strEx, tmp__strEx);
                       }
                    return res;
                   }
                
                RCODE strExSet( const ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_lightCopyTo( tmp__strEx, _strEx);
                
                    return pif->strExSet(&tmp__strEx, idx1);
                   }
                
                RCODE strExSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strExSize(_size);
                   }
                
                RCODE doSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->doSomething(some);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strEx( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strExGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strEx( SIZE_T idx1 , const ::std::wstring &_strEx
                              )
                   { // MS style - index goes before value, need reorder
                    RCODE res = strExSet( _strEx, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_strEx(  )
                   {
                    SIZE_T size;
                    RCODE res = strExSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, strEx, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strExGet( ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_init( tmp__strEx );
                
                    RCODE res = pif->strExGet(&tmp__strEx, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strEx, tmp__strEx);
                       }
                    return res;
                   }
                
                RCODE strExSet( const ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_lightCopyTo( tmp__strEx, _strEx);
                
                    return pif->strExSet(&tmp__strEx, idx1);
                   }
                
                RCODE strExSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strExSize(_size);
                   }
                
                RCODE doSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->doSomething(some);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_strEx( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = strExGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_strEx( SIZE_T idx1 , const ::std::wstring &_strEx
                              )
                   { // MS style - index goes before value, need reorder
                    RCODE res = strExSet( _strEx, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_strEx(  )
                   {
                    SIZE_T size;
                    RCODE res = strExSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, strEx, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE strExGet( ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_init( tmp__strEx );
                
                    RCODE res = pif->strExGet(&tmp__strEx, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _strEx, tmp__strEx);
                       }
                    return res;
                   }
                
                RCODE strExSet( const ::std::wstring    &_strEx
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
                   {
                    CCliStr tmp__strEx; CCliStr_lightCopyTo( tmp__strEx, _strEx);
                
                    return pif->strExSet(&tmp__strEx, idx1);
                   }
                
                RCODE strExSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->strExSize(_size);
                   }
                
                RCODE single1DoSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->single1DoSomething(some);
                   }
                
                RCODE single2DoSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->single2DoSomething(some);
                   }
                
                RCODE multi2DoSomething( SIZE_T    some /* [in] size_t  some  */)
                   {
                
                    return pif->multi2DoSomething(some);
                   }
                

        
        
        }; // class CiTestMulti2Wrapper
        
        typedef CiTestMulti2Wrapper< ::cli::CCliPtr< INTERFACE_ATEST_ITESTMULTI2     > >  CiTestMulti2;
        typedef CiTestMulti2Wrapper< ::cli::CFoolishPtr< INTERFACE_ATEST_ITESTMULTI2 > >  CiTestMulti2_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace atest

#endif





#endif /* CLI_ATEST_H */
