#ifndef CLI_PONCE_H
#define CLI_PONCE_H

/* add this lines to your src
#ifndef CLI_PONCE_H
    #include <cli/ponce.h>
#endif
*/

#if defined(__GNUC__) && ((__GNUC__ == 4  /* && __GNUC_MINOR__ >= 30 */ ) || (__GNUC__ > 4))
    #if defined(__arm__) || defined(__thumb__) /* GCC for arm often does not support pragma once */
        /*
        http://sourceforge.net/p/predef/wiki/Architectures/
        */
        #ifndef CLI_PRAGMA_ONCE_FORCE_DISABLE
            #define CLI_PRAGMA_ONCE_FORCE_DISABLE
        #endif
    #endif
#endif


#if ((defined(_MSC_VER) && _MSC_VER > 1000) || \
     (defined(__GNUC__) && ((__GNUC__ == 4  /* && __GNUC_MINOR__ >= 30 */ ) || (__GNUC__ > 4))) || \
     (defined(__ICC) && __ICC > 1000) \
    ) && !defined(CLI_PRAGMA_ONCE_FORCE_DISABLE)
    #define CLI_ONCE once
    #define CLI_PRAGMA_ONCE_SUPPORTED
#else
    //#define CLI_ONCE message("pragma once not supported")
#endif

/*
use 
#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif
*/
#endif /* CLI_PONCE_H */



