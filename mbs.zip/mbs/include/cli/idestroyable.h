#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IDESTROYABLE_H
#define CLI_IDESTROYABLE_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/idestroyable.h>", CLI_IDESTROYABLE_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IDESTROYABLE_H
    #include <cli/idestroyable.h>
#endif
*/

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iDestroyable */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IDESTROYABLE_IID
    #define INTERFACE_CLI_IDESTROYABLE_IID    "/cli/iDestroyable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iDestroyable
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IDESTROYABLE
       #define INTERFACE_CLI_IDESTROYABLE    ::cli::iDestroyable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iDestroyable
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IDESTROYABLE
       #define INTERFACE_CLI_IDESTROYABLE    cli_iDestroyable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDestroyable methods */
            CLIMETHOD_(VOID, destroy) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iDestroyable >
           {
            static char const * getName() { return INTERFACE_CLI_IDESTROYABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iDestroyable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iDestroyable > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif





#endif /* CLI_IDESTROYABLE_H */
