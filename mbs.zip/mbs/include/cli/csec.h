#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CSEC_H
#define CLI_CSEC_H

/*
#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif
*/

#ifndef CLI_YIELD_H
    #include <cli/yield.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif


#if defined(CLI_NO_SAFE_INTERLOCKED_FUNCTIONS) || defined(CLI_USE_PTHREAD_SPINLOCK)
    #include <cli/pthcsec.h>
#endif


#ifndef _WIN32
    #if !defined(_PTHREAD_H) && !defined(_PTHREAD_H_)
        #include <pthread.h>
    #endif
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif


#if defined(_MSC_VER) && _MSC_VER<=1200
    #pragma warning( push )
    #pragma warning( disable : 4786 ) // identifier was truncated to '255' characters
    #pragma warning( disable : 4503 ) // decorated name length exceeded, name was truncated
#endif

#if defined(CLI_USE_PTHREAD_SPINLOCK)
    #if defined(WIN32) || defined(_WIN32)
        #undef CLI_USE_PTHREAD_SPINLOCK
    #endif
#endif // CLI_USE_PTHREAD_SPINLOCK


#if defined(CLI_NO_SAFE_INTERLOCKED_FUNCTIONS) || defined(CLI_USE_PTHREAD_SPINLOCK)
    #ifndef CLI_PTHCSEC_H
        #include <cli/pthcsec.h>
    #endif
#else
#endif


#ifndef CLI_SPINCSEC_H
    #include <cli/spincsec.h>
#endif


namespace cli
{

#if defined(CLI_NO_SAFE_INTERLOCKED_FUNCTIONS) || defined(CLI_USE_PTHREAD_SPINLOCK)
    //typedef pth::CSpinLock              CCriticalSection;
    typedef pth::CMutexLock             CCriticalSection;
#else
    typedef CCriticalSectionSleepDriven CCriticalSection;
#endif


class CFictiveCriticalSection
{

    public:

        CFictiveCriticalSection( unsigned argSpinCount = 0
                               , bool forceSingleCpu = false)
           {};
        inline bool tryLock() const { return true; };
        inline void lock()    const {};
        inline void unlock()  const {};

}; // CFictiveCriticalSection


typedef CFictiveCriticalSection CFakeCriticalSection;




template <typename TCS=CCriticalSection>
class CAutoLocker
{
        const TCS &csec;
    public:
        CAutoLocker(const TCS &cs) : csec(cs) { csec.lock(); }
        ~CAutoLocker() { csec.unlock(); }
};


// ����. ���� ����������, ��������� ����������
class CInterlockedCounterWithPassTroughOnZero : public CSpinCountingBase
{
        ILVOLATILE ilint_t    counter;
        #ifdef CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
        CCriticalSection cs;
        #endif

        CInterlockedCounterWithPassTroughOnZero& operator=(const CInterlockedCounterWithPassTroughOnZero&) { return *this; }

        bool tryPassTrough()
           {
            #ifdef CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
            CAutoLocker<CCriticalSection> locker(cs);
            #endif
            bool bOk = (interlockedCompareExchange( &(counter), 1, 0) != 0);
            // counter now is 1
            if (bOk) interlockedDecrement(&counter); // set counter to initial state (0)
            return bOk;
           }

        bool tryPassTrough( unsigned cnt )
           {
            do {
                if (tryPassTrough()) return true;
               } while(cnt-->0);
            return false;
           }

    public:

        // counter state not copied
        // use this constructor only for initializing interlocked counter with specific
        // spin count and uniprocessor host flags
        CInterlockedCounterWithPassTroughOnZero(const CInterlockedCounterWithPassTroughOnZero &c)
           : CSpinCountingBase(c.spinCount, c.forceUniprocessorHost), counter(0)
           #ifdef CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
           , cs()
           #endif
           {}

        CInterlockedCounterWithPassTroughOnZero( unsigned _spinCount = 0
                                               , bool _forceUniprocessorHost = false
                                               )
           : CSpinCountingBase(_spinCount, _forceUniprocessorHost ), counter(0)
           #ifdef CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
           , cs()
           #endif
           {
           }

        int getValue() const
           {
            #ifdef CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
            CAutoLocker<CCriticalSection> locker(cs);
            #endif
            return (int)counter;
           }

        int increment()
           {
            #ifdef CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
            CAutoLocker<CCriticalSection> locker(cs);
            #endif
            return (int)interlockedIncrement(&counter);
           }

        int decrement()
           {
            #ifdef CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
            CAutoLocker<CCriticalSection> locker(cs);
            #endif
            return interlockedDecrement(&counter);
           }

        void passTrough()
           {
            // (getSpinCount())
            if (tryPassTrough(getSpinCount())) return;
            do{
               sleep();
              } while(tryPassTrough());
           }
}; // class CInterlockedCounterWithPassTroughOnZero


class CSpinWaitFlag : protected CInterlockedCounterWithPassTroughOnZero
{
        CSpinWaitFlag& operator=(const CSpinWaitFlag &f) { return *this; }

    public:

        CSpinWaitFlag(const CSpinWaitFlag &c)
          : CInterlockedCounterWithPassTroughOnZero(c.spinCount, c.forceUniprocessorHost)
          {}

        CSpinWaitFlag( unsigned _spinCount = 0
                     , bool _forceUniprocessorHost = false
                                               )
          : CInterlockedCounterWithPassTroughOnZero(_spinCount, _forceUniprocessorHost )
          {
          }

       int set()
          {
           return CInterlockedCounterWithPassTroughOnZero::increment();
          }

       int clear()
          {
           return CInterlockedCounterWithPassTroughOnZero::decrement();
          }

       void passTrough()
          {
           CInterlockedCounterWithPassTroughOnZero::passTrough();
          }

}; // class CSpinWaitFlag



}; // namespace cli


// need full qualification of types and names
#define CLI_AUTOLOCK_FQ(lockerName, csType, csecObj)  \
        ::cli::CAutoLocker< csType > lockerName(csecObj)

#define CLI_AUTOLOCK(csecObj)                  CLI_AUTOLOCK_FQ(cliAutoLocker, ::cli::CCriticalSection, csecObj)
#define CLI_AUTOLOCK_EX(lockerName, csecObj)   CLI_AUTOLOCK_FQ(lockerName, ::cli::CCriticalSection, csecObj)

#define CLI_SCOPED_LOCK_FQ(lockerName, csType, csecObj) CLI_AUTOLOCK_FQ(lockerName, csType, csecObj)
#define CLI_SCOPED_LOCK(csecObj)                        CLI_AUTOLOCK(csecObj)
#define CLI_SCOPED_LOCK_EX(lockerName, csecObj)         CLI_AUTOLOCK_EX(lockerName, csecObj)


#if defined(_MSC_VER) && _MSC_VER<=1200
    #pragma warning( pop )
#endif



#endif /* CLI_CSEC_H */

