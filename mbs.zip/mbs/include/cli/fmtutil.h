#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_FMTUTIL_H
#define CLI_FMTUTIL_H

/* add this lines to your src
#ifndef CLI_FMTUTIL_H
    #include <cli/fmtutil.h>
#endif
*/

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DATETIME_H
    #include <cli/dateTime.h>
#endif


// UINT, UINT64, INT, INT64 types definition header (<cli/podTypes.h>) must be included before this header

//#error "fmtutil included"

// ::cli::fmtutil::
namespace cli
{
namespace fmtutil
{



// works correct only with latin chars
template <typename CharType>
CharType toUpperCase( CharType ch )
   {
    if (ch>=(CharType)'a' && ch<=(CharType)'z') return ch - (CharType)'a' + (CharType)'A';
    return ch;
   }

template <typename CharType>
CharType toLowerCase( CharType ch )
   {
    if (ch>=(CharType)'A' && ch<=(CharType)'Z') return ch - (CharType)'A' + (CharType)'a';
    return ch;
   }

template <typename CharType, typename Traits, typename Allocator>
void toUpperCase( ::std::basic_string<CharType, Traits, Allocator> &str )
   {
    typename ::std::basic_string< CharType, Traits, Allocator>::iterator it = str.begin(), end = str.end();
    for( ; it != end; ++it )
       {
        *it = toUpperCase(*it);
       }
   }

template <typename CharType, typename Traits, typename Allocator>
void toLowerCase( ::std::basic_string<CharType, Traits, Allocator> &str )
   {
    typename ::std::basic_string< CharType, Traits, Allocator>::iterator it = str.begin(), end = str.end();
    for( ; it != end; ++it )
       {
        *it = toLowerCase(*it);
       }
   }

template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator> toUpperCaseCopy( const ::std::basic_string<CharType, Traits, Allocator> &_str )
   {
    ::std::basic_string<CharType, Traits, Allocator> str = _str;
    toUpperCase(str); return str;
   }

template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator> toLowerCaseCopy( const ::std::basic_string<CharType, Traits, Allocator> &_str )
   {
    ::std::basic_string<CharType, Traits, Allocator> str = _str;
    toLowerCase(str); return str;
   }

template <typename IntType, typename CharType>
CharType convertIntToDigit( IntType i, CharType firstAlphaDigit = (CharType)'A' )
   {
    if (i>9) return (CharType)(i-10) + firstAlphaDigit;
    return (CharType)(i) + (CharType)'0';
   }


template <typename IntType, typename CharType, typename Traits, typename Allocator>
void convertIntToString( ::std::basic_string<CharType, Traits, Allocator> &strTo
                       , IntType i, IntType base
                       , CharType firstAlphaDigit = (CharType)'A'
                       )
   {
    strTo.clear();
    while(i)
       {
        strTo.append( 1, convertIntToDigit( i%base, firstAlphaDigit ) );
        i /= base;
       }
    if (strTo.empty())
       strTo.append( 1, convertIntToDigit( (IntType)0, firstAlphaDigit ) );
    ::std::reverse( strTo.begin(), strTo.end() );
   }


template <typename IntType, typename CharType, typename Traits, typename Allocator>
void convertIntToStringEx( ::std::basic_string<CharType, Traits, Allocator> &strTo
                         , IntType i, IntType base
                         , SIZE_T minWidth
                         , CharType fillChar = (CharType)' '
                         , CharType firstAlphaDigit = (CharType)'A'
                       )
   {
    strTo.clear();
    while(i)
       {
        strTo.append( 1, convertIntToDigit( i%base, firstAlphaDigit ) );
        i /= base;
       }
    if (strTo.empty())
       strTo.append( 1, convertIntToDigit( (IntType)0, firstAlphaDigit ) );
    while(strTo.size() < minWidth)
       strTo.append( 1, fillChar );
    ::std::reverse( strTo.begin(), strTo.end() );
   }


template <typename IntType, typename CharType>
IntType digitToInt( CharType ch )
   {
    ch = toUpperCase( ch );
    if (ch>=(CharType)'0' && ch<=(CharType)'9') return (IntType)(ch - (CharType)'0');
    if (ch>=(CharType)'A' && ch<=(CharType)'Z') return (IntType)(ch - (CharType)'A') + 10;
    if (ch>=(CharType)'a' && ch<=(CharType)'z') return (IntType)(ch - (CharType)'a') + 10;
    return (IntType)-1;
   }

template <typename IntType, typename CharType, typename Traits, typename Allocator>
SIZE_T convertFromString( const ::std::basic_string<CharType, Traits, Allocator> &strFrom
                        , SIZE_T startPos
                        , IntType *pRes
                        , IntType base
                        , IntType *pSign = 0
                        )
   {
    //IntType num = 0;
    if (pRes) *pRes = 0;
    SIZE_T size = strFrom.size();
    bool bFirst = true;
    for(; startPos!=size; ++startPos)
       {
        IntType digit = digitToInt<IntType,CharType>(strFrom[startPos]);
        if (digit==(IntType)-1) 
           {
            if (bFirst && (strFrom[startPos]==(CharType)'-' || strFrom[startPos]==(CharType)'+'))
               {
                if (pSign)
                   {
                    if (strFrom[startPos]==(CharType)'-') *pSign = (IntType)-1;
                    else                                  *pSign = (IntType)1;
                   }
               }
            else
               return startPos;
           }
        if (digit>=base) return startPos;
        if (pRes) 
           {
            *pRes *= base;
            *pRes += digit;
           }
        bFirst = false;
       }
    return startPos;
   }

template <typename CharType, typename Traits, typename Allocator>
SIZE_T skipWhitespaces( const ::std::basic_string<CharType, Traits, Allocator> &strFrom, SIZE_T pos )
   {
    SIZE_T size = strFrom.size();
    for(; pos!=size; ++pos)
       {
        if (strFrom[pos]!=(CharType)' ' && strFrom[pos]!=(CharType)'\r' && strFrom[pos]!=(CharType)'\n' && strFrom[pos]!=(CharType)'\t')
           return pos;
       }
    return pos;
   }


template <typename IntType, typename CharType, typename Traits, typename Allocator >
void convertStringToInts( const ::std::basic_string<CharType, Traits, Allocator> &str
                 , ::std::vector< IntType > &vec
                 , IntType base = (IntType)10
                 )
   {
    IntType i = 0;
    SIZE_T pos = 0; 
    SIZE_T startPos = 0;
    SIZE_T size = str.size();
    for(; pos!=size; )
       {
        IntType sign = 0;
        startPos = pos;
        pos = convertFromString( str, startPos, &i, base, &sign );
        if (pos!=startPos) 
           {
            if (sign) i = i * sign;
            vec.push_back(i); // something was converted
           }
        if (pos!=size) ++pos;
        pos = skipWhitespaces( str, pos);
       }
   }


}; // namespace fmtutil
}; // namespace cli


/*
namespace cli
{
namespace fmtutil
{
}; // namespace fmtutil
}; // namespace cli


using namespace cli;
using namespace cli::fmtutil;
*/

#endif /* CLI_FMTUTIL_H */

