#ifndef NPL_OLD_PACK_STYLE

#if defined(_MSC_VER) || defined(__BORLANDC__)
    #include <poppack.h>
#elif defined(__GNUC__)
    #pragma pack(pop)
#else // add here other compilers support
    //#pragma message ("Warning: default alignment used")
    #error "Compiler not supported"
#endif

#else 

#if defined(WIN32) || defined(_WIN32) || defined(_WIN32_WINNT) || defined(__WIN32__)
    #if defined(_MSC_VER)
        #include <poppack.h>
    #elif defined(__BORLANDC__)
        #pragma warn -8059
        #pragma pack(pop)
    #endif
#endif

#endif /* NPL_OLD_PACK_STYLE */
