#ifndef NPL_OLD_PACK_STYLE

#if defined(_MSC_VER) || defined(__BORLANDC__)
    #include <pshpack8.h>
#elif defined(__GNUC__)
    #pragma pack(push,8)
#else // add here other compilers support
    //#pragma message ("Warning: default alignment used")
    #error "Compiler not supported"
#endif

#else 

#if defined(WIN32) || defined(_WIN32) || defined(_WIN32_WINNT) || defined(__WIN32__)
    /*#pragma message ("Info: included windows pshpack8.h header")*/
    #if defined(_MSC_VER)
        #include <pshpack8.h>
    #elif defined(__BORLANDC__)
        #pragma warn -8059
        #pragma pack(push, 8)
    #endif
#else
    //#pragma message ("Warning: default alignment used")
#endif

#endif /* NPL_OLD_PACK_STYLE */
