#ifndef CLI_IMPLHLP_H
#define CLI_IMPLHLP_H

/*
#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif
*/

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_REFCNT_H
    #include <cli/refcnt.h>
#endif

#ifndef CLI_CLIMOD_H
    #include <cli/climod.h>
#endif

#if defined(__cplusplus) && !defined(CLI_COMPONENTS_INFO_CPP_SORT_DISABLED)
    #define CLI_COMPONENTS_INFO_USE_CPP_SORT
#endif

#ifdef CLI_COMPONENTS_INFO_USE_CPP_SORT
    #if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
        #include <algorithm>
    #endif
#else
    #include <stdlib.h>
    #ifdef WIN32
        #include <search.h>
    #endif
#endif

#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif


#ifndef CLI_MONOLITHIC
    #ifndef CLI_CLIMOD_H
        #include <cli/climod.h>
    #endif
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif



#ifndef IIDSEP
    #define IIDSEP ";"
#endif

namespace cli
{

struct CDummyModule
{
        ULONG addRef()  { return 0; }
        ULONG release() { return 0; }
};

struct CDummyRefCounter
{
        ULONG addRef()  { return 1; }
        ULONG release() { return 1; }
};

}; // namespace cli



// when creating components in exe, TARGET_TYPE_EXE must be defined

// target type autodetect
#if defined(_WIN32) || defined(WIN32)
    #if defined(TARGET_TYPE_EXE) && defined(_WINDLL)
        #error "TARGET_TYPE_EXE define conflicts with _WINDLL define: for non-cli dll's use NOT_CLI_MODULE instead TARGET_TYPE_EXE"
    #endif
    
    #if !defined(CLI_MONOLITHIC) && !defined(TARGET_TYPE_EXE) && !defined(NOT_CLI_MODULE)
        #if defined(_WINDLL)
            // cli module (dll), to disable this, define NOT_CLI_MODULE
        #else
            #define TARGET_TYPE_EXE /* exe target, not dll */
        #endif
    #endif
#endif

#if !defined(CLI_MONOLITHIC) && !defined(TARGET_TYPE_EXE) && !defined(NOT_CLI_MODULE)
    #ifndef USE_CLI_MODULE
        #define USE_CLI_MODULE
    #endif
#else
#endif

#ifndef DEF_MODULE_TYPE
    #ifdef USE_CLI_MODULE
        #define DEF_MODULE_TYPE  ::cli::CModule
    #else
        #define DEF_MODULE_TYPE  ::cli::CDummyModule
    #endif
#endif

#ifndef DEF_MODULE
    #ifdef USE_CLI_MODULE
        #define DEF_MODULE       cliModule
    #else
        #define DEF_MODULE       
    #endif
#endif

//#define REFCOUNTER_TYPE  ::cli::CModule
#ifdef USE_CLI_MODULE
    extern ::cli::CModule cliModule;
#endif // CLI_MONOLITHIC


namespace cli
{

template < typename RefCounterType
         , typename CliModuleType
         >
class CComponentImplBase
{
    protected:
    
        RefCounterType refCounter;
        CliModuleType  &module;        

        CLIMETHOD_(VOID, destroy) (THIS) PURE;
        CComponentImplBase(const CComponentImplBase &b) : refCounter(), module(b.module) {}
        CComponentImplBase& operator=(const CComponentImplBase &b) { return *this; }
    
    public:

        CComponentImplBase(CliModuleType &m) : refCounter(1), module(m) 
           {
            module.addRef();
           }
        ULONG addRefImpl()    
           { 
            module.addRef();
            return (ilint_t)++refCounter;  
           }
        ULONG releaseImpl( bool doDestroyOnZeroRefCounter = true )
           {
            module.release();
            if (! --refCounter) 
               { 
                if (doDestroyOnZeroRefCounter) destroy(); 
                return 0;
               }
            return (ilint_t)refCounter;
           }

}; // CComponentImplBase


// ������������� ��� MONOLITHIC ������������
template < typename RefCounterType
         >
class CComponentImplBase< RefCounterType, ::cli::CDummyModule >
{
    protected:
    
        RefCounterType refCounter;
        CLIMETHOD_(VOID, destroy) (THIS) PURE;
       
        CComponentImplBase(const CComponentImplBase &b) : refCounter() {}
        CComponentImplBase& operator=(const CComponentImplBase &b) { return *this; }

    public:
    
        CComponentImplBase() : refCounter(1) {}
        ULONG addRefImpl()
           {
            return (ilint_t)++refCounter;
           }

        ULONG releaseImpl( bool doDestroyOnZeroRefCounter = true )
           {
            if (! --refCounter) 
               {
                if (doDestroyOnZeroRefCounter) destroy(); 
                return 0;
               }
            return (ilint_t)refCounter;
           }

}; // CComponentImplBase

// Usage:
// class impl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE>
// typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE> base_impl;
// impl() : base_impl(DEF_MODULE) {}

// Add to your implementation
//        void destroy() { delete this; }
//        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
//        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

// if you don't need reference counting, use ::cli::CFakeRefCounter

// if you don't need delete object on release, rewrite default implementation of destroy to do your own job


// property helpers

typedef CLISTR* CLISTR_PTR;
typedef const CLISTR* CONST_CLISTR_PTR;
typedef CLICSTR* CLICSTR_PTR;
typedef const CLICSTR* CONST_CLICSTR_PTR;


template <typename TVectorValueType>
RCODE propertyVectorGetSizeImpl(SIZE_T* size, const ::std::vector< TVectorValueType > &v)
   {
    if (!size) return EC_INVALID_PARAM;
    *size = v.size();
    return EC_OK;
   }

// same as propertyVectorGetSizeImpl
template <typename TVectorValueType>
RCODE propertyVectorGetSize1Impl(SIZE_T* size, const ::std::vector< TVectorValueType > &v)
   {
    if (!size) return EC_INVALID_PARAM;
    *size = v.size();
    return EC_OK;
   }

template <typename TVectorValueType>
RCODE propertyVectorGetSize2Impl(SIZE_T* size, SIZE_T idx1, const ::std::vector< ::std::vector< TVectorValueType > > &v)
   {
    if (idx1>=v.size()) return EC_OUT_OF_RANGE;
    if (!size) return EC_INVALID_PARAM;
    *size = v[idx1].size();
    return EC_OK;
   }


template <typename TPropertyType, typename TValueType>
RCODE propertyGetImpl( TPropertyType *pVal, const TValueType &m_val)
   {
    if (!pVal) return EC_INVALID_PARAM;
    *pVal = m_val;
    return EC_OK;   
   }

template <>
inline
//RCODE propertyGetImpl<CLISTR,const ::std::wstring&>( CLISTR *pVal, const ::std::wstring &m_val)
RCODE propertyGetImpl<CLISTR,::std::wstring>( CLISTR *pVal, const ::std::wstring &m_val)
   {
    if (!pVal) return EC_INVALID_PARAM;
    CCliStr_copyTo(pVal , m_val );
    return EC_OK;   
   }

template <>
inline
//RCODE propertyGetImpl<CLISTR,const ::std::wstring&>( CLISTR *pVal, const ::std::wstring &m_val)
RCODE propertyGetImpl<CLICSTR,::std::string>( CLICSTR *pVal, const ::std::string &m_val)
   {
    if (!pVal) return EC_INVALID_PARAM;
    CCliCStr_copyTo(pVal , m_val );
    return EC_OK;   
   }
/*
template <>
inline
RCODE propertyGetImpl<CLISTR,::std::wstring&>( CLISTR *pVal, ::std::wstring &m_val)
   {
    if (!pVal) return EC_INVALID_PARAM;
    CCliStr_copyTo(pVal , m_val );
    return EC_OK;   
   }
*/

template <typename TPropertyType, typename TVectorValueType>
RCODE propertyVectorGetImpl( SIZE_T idx, TPropertyType *pVal, const ::std::vector< TVectorValueType > &vec)
   {
    if (!pVal) return EC_INVALID_PARAM;
    if (idx>=vec.size()) return EC_OUT_OF_RANGE;
    //*pVal = *(vec.begin()+idx); //[idx];
    *pVal = vec[idx];
    return EC_OK;   
   }

template <>
inline
RCODE propertyVectorGetImpl<CLISTR,::std::wstring>( SIZE_T idx, CLISTR *pVal, const ::std::vector< ::std::wstring > &vec)
   {
    if (!pVal) return EC_INVALID_PARAM;
    if (idx>=vec.size()) return EC_OUT_OF_RANGE;
    //CCliStr_copyTo(pVal , *(vec.begin()+idx) /* vec[idx] */  );
    CCliStr_copyTo(pVal , vec[idx] );
    return EC_OK;   
   }

template <typename TPropertyType, typename TVectorValueType>
RCODE propertyVector2GetImpl( SIZE_T idx1, SIZE_T idx2, TPropertyType *pVal, const ::std::vector< ::std::vector< TVectorValueType > > &vec)
   {
    if (!pVal) return EC_INVALID_PARAM;
    if (idx1>=vec.size()) return EC_OUT_OF_RANGE;
    if (idx2>=vec[idx1].size()) return EC_OUT_OF_RANGE;
    //*pVal = *(vec.begin()+idx); //[idx];
    *pVal = vec[idx1][idx2];
    return EC_OK;   
   }

template <>
inline
RCODE propertyVector2GetImpl<CLISTR,::std::wstring>( SIZE_T idx1, SIZE_T idx2, CLISTR *pVal, const ::std::vector< ::std::vector< ::std::wstring > > &vec)
   {
    if (!pVal) return EC_INVALID_PARAM;
    if (idx1>=vec.size()) return EC_OUT_OF_RANGE;
    if (idx2>=vec[idx1].size()) return EC_OUT_OF_RANGE;
    //CCliStr_copyTo(pVal , *(vec.begin()+idx) /* vec[idx] */  );
    CCliStr_copyTo(pVal , vec[idx1][idx2] );
    return EC_OK;   
   }




template <typename TPropertyType, typename TValueType>
RCODE propertySetImpl( TPropertyType val, TValueType &m_val)
   {
    m_val = val;
    return EC_OK;   
   }

template <>
inline
RCODE propertySetImpl<CONST_CLISTR_PTR,::std::wstring>( CONST_CLISTR_PTR val, ::std::wstring &m_val)
   {
    if (!val) return EC_INVALID_PARAM;
    m_val = stdstr(val);
    return EC_OK;   
   }

template <>
inline
RCODE propertySetImpl<CONST_CLICSTR_PTR,::std::string>( CONST_CLICSTR_PTR val, ::std::string &m_val)
   {
    if (!val) return EC_INVALID_PARAM;
    m_val = stdstr(val);
    return EC_OK;   
   }

template <typename TPropertyType, typename TVectorValueType>
RCODE propertyVectorSetImpl( SIZE_T idx, TPropertyType val, ::std::vector< TVectorValueType > &vec)
   {
    if (idx>=vec.size()) 
       vec.push_back(val);
    else 
       vec[idx] = val;
    return EC_OK;   
   }

template <typename TPropertyType, typename TVectorValueType>
RCODE propertyVector2SetImpl( SIZE_T idx1, SIZE_T idx2, TPropertyType val, ::std::vector< ::std::vector< TVectorValueType > > &vec)
   {
    if (idx1>vec.size())
       {
        idx1 = vec.size();
        vec.push_back( ::std::vector< TVectorValueType >() );
       }

    if (idx2>=vec[idx1].size()) 
       vec[idx1].push_back(val);
    else 
       vec[idx1][idx2] = val;

    return EC_OK;   
   }

template <>
inline
RCODE propertyVectorSetImpl<CONST_CLISTR_PTR,::std::wstring>( SIZE_T idx, CONST_CLISTR_PTR val, ::std::vector< ::std::wstring > &vec)
   {
    ::std::wstring str = stdstr(val);
    if (idx>=vec.size()) 
       vec.push_back(str);
    else 
       vec[idx] = str;
    return EC_OK;   
   }

template <>
inline
RCODE propertyVector2SetImpl<CONST_CLISTR_PTR,::std::wstring>( SIZE_T idx1, SIZE_T idx2, CONST_CLISTR_PTR val, ::std::vector< ::std::vector< ::std::wstring > > &vec)
   {
    if (idx1>vec.size())
       {
        idx1 = vec.size();
        vec.push_back( ::std::vector< ::std::wstring >() );
       }

    if (idx2>=vec[idx1].size()) 
       vec[idx1].push_back(stdstr(val));
    else 
       vec[idx1][idx2] = stdstr(val);

    return EC_OK;   
   }










#define PROPERTY_IMPL_CALL_HANDLERS( propName, varName, afterSet, beforeGet )\
                 CLIMETHOD(propName##Get) (THIS_ UINT*    propName##_)       \
                    {                                                        \
                     if (!propName##_) return EC_INVALID_PARAM;              \
                     * propName##_ = varName;                                \
                     afterSet();                                             \
                     return EC_OK;                                           \
                    }                                                        \
                                                                             \
                 CLIMETHOD(propName##Set) (THIS_ UINT     propName##_)       \
                    {                                                        \
                     beforeGet();                                            \
                     varName = propName##_;                                  \
                     return EC_OK;                                           \
                    }

#define PROPERTY_IMPL( propName, varName, propType )                         \
                 CLIMETHOD(propName##Get) (THIS_ propType*    propName##_)   \
                    {                                                        \
                     return ::cli::propertyGetImpl(propName##_ , varName);   \
                    }                                                        \
                                                                             \
                 CLIMETHOD(propName##Set) (THIS_ propType     propName##_)   \
                    {                                                        \
                     return ::cli::propertySetImpl(propName##_ , varName);   \
                    }

#define PROPERTY_RW_IMPL( propName, varName, propType )   PROPERTY_IMPL( propName, varName, propType )

#define PROPERTY_RW_IMPL_EX( propName, varName, propType, afterSet, beforeGet )  \
                 CLIMETHOD(propName##Get) (THIS_ propType*    propName##_)   \
                    {                                                        \
                     RCODE res = beforeGet();                                \
                     if (res) return res;                                    \
                     return ::cli::propertyGetImpl(propName##_ , varName);   \
                    }                                                        \
                                                                             \
                 CLIMETHOD(propName##Set) (THIS_ propType     propName##_)   \
                    {                                                        \
                     RCODE res = ::cli::propertySetImpl(propName##_ , varName);   \
                     if (res) return res;                                    \
                     return afterSet();                                      \
                    }

#define PROPERTY_R_IMPL( propName, varName, propType )                       \
                 CLIMETHOD(propName##Get) (THIS_ UINT*    propName##_)       \
                    {                                                        \
                     return ::cli::propertyGetImpl(propName##_ , varName);   \
                    }

#define PROPERTY_W_IMPL( propName, varName, propType )                       \
                 CLIMETHOD(propName##Set) (THIS_ UINT     propName##_)       \
                    {                                                        \
                     return ::cli::propertySetImpl(propName##_ , varName);   \
                    }



}; // namespace cli



#ifndef COMPARE_COMPONENT_CREATION_INFO_PROC_IMPL

    #ifdef CLI_COMPONENTS_INFO_USE_CPP_SORT
        //#pragma message("C++ version of compareComponentCreationInfo")
        #define COMPARE_COMPONENT_CREATION_INFO_PROC_IMPL(a)\
                static                                      \
                bool compareComponentCreationInfo(const PCliComponentCreationInfo pci1, const PCliComponentCreationInfo pci2) \
                   {                                                   \
                    return strcmp(pci1->info.name, pci2->info.name)<0; \
                   }
    #else  /* !CLI_COMPONENTS_INFO_USE_CPP_SORT */
        //#pragma message("Plain C version of compareComponentCreationInfo")
        #define COMPARE_COMPONENT_CREATION_INFO_PROC_IMPL(a)\
                static                                      \
                int CDECL compareComponentCreationInfo(const void *p1, const void *p2)       \
                   {                                                                         \
                    const PCliComponentCreationInfo *pci1 = (PCliComponentCreationInfo*)p1;  \
                    const PCliComponentCreationInfo *pci2 = (PCliComponentCreationInfo*)p2;  \
                    return strcmp((*pci1)->info.name, (*pci2)->info.name);                   \
                   }
    #endif  /* CLI_COMPONENTS_INFO_USE_CPP_SORT */
#endif


#ifndef MAKE_COMPONENTS_INFO_SORTED_PROC_IMPL
    #ifdef CLI_COMPONENTS_INFO_USE_CPP_SORT
        #define MAKE_COMPONENTS_INFO_SORTED_PROC_IMPL(a)\
                static                                  \
                void makeComponentsInfoSorted(CCliComponentCreationInfo *pcci, PCliComponentCreationInfo *ord, SIZE_T size)  \
                   {                                                                                                         \
                    for(SIZE_T i=0; i!=size; ++i)                                                                            \
                        ord[i] = &pcci[i];                                                                                   \
                    std::sort(&ord[0], &ord[size], compareComponentCreationInfo);                                            \
                   }                                                                                                         \
                static PCliComponentCreationInfo a##Ordered[ARRAY_SIZE(a)] = { 0 }
    #else  /* !CLI_COMPONENTS_INFO_USE_CPP_SORT */
        #define MAKE_COMPONENTS_INFO_SORTED_PROC_IMPL(a)\
                static                                  \
                void makeComponentsInfoSorted(CCliComponentCreationInfo *pcci, PCliComponentCreationInfo *ord, SIZE_T size)  \
                   {                                                                                                         \
                    for(SIZE_T i=0; i!=size; ++i)                                                                            \
                        ord[i] = &pcci[i];                                                                                   \
                    qsort((void*)&ord[0], size, sizeof(ord[0]), &compareComponentCreationInfo);                              \
                   }                                                                                                         \
                PCliComponentCreationInfo a##Ordered[ARRAY_SIZE(a)] = { 0 }
    #endif  /* end CLI_COMPONENTS_INFO_USE_CPP_SORT */
#endif


#ifndef CHECK_INIT_COMPONENT_INFO
    #define CHECK_INIT_COMPONENT_INFO(arrayInfo, initFlag)                                      \
            if (!initFlag)                                                                      \
               do {                                                                             \
                makeComponentsInfoSorted(arrayInfo, arrayInfo##Ordered, ARRAY_SIZE(arrayInfo)); \
                initFlag = 1;                                                                   \
               } while(0)
#endif


#ifndef FIND_COMPONENTS_INFO_IMPL
    #ifdef CLI_COMPONENTS_INFO_USE_CPP_SORT
        #define FIND_COMPONENTS_INFO_IMPL(a)                                                                 \
                static                                                                                       \
                PCliComponentCreationInfo findComponentInfo(const CHAR *componentName)                       \
                   {                                                                                         \
                    CCliComponentCreationInfo ci = { { 0, 0, 0 }, 0 };                                       \
                    ci.info.name = (CHAR*)componentName;                                                     \
                    PCliComponentCreationInfo *pFound = cli::util::binary_find( &a##Ordered[0]               \
                                                                              , &a##Ordered[ARRAY_SIZE(a)]   \
                                                                              , &ci                          \
                                                                              , compareComponentCreationInfo \
                                                                              );                             \
                    if (pFound==&a##Ordered[ARRAY_SIZE(a)]) return 0;                                        \
                    return *pFound;                                                                          \
                   }
    #else
        #define FIND_COMPONENTS_INFO_IMPL(a)                                               \
                static                                                                     \
                PCliComponentCreationInfo findComponentInfo(const CHAR *componentName)     \
                   {                                                                       \
                    CCliComponentCreationInfo ci = { 0 };                                  \
                    ci.info.name = (CHAR*)componentName;                                   \
                                                                                           \
                    PCliComponentCreationInfo pci = &ci;                                   \
                                                                                           \
                    PCliComponentCreationInfo *pFoundPci =                                 \
                        (PCliComponentCreationInfo*)bsearch( (void*)&pci                   \
                                                           , (void*)&a##Ordered[0]         \
                                                           , ARRAY_SIZE(a)                 \
                                                           , sizeof(a##Ordered[0])         \
                                                           , &compareComponentCreationInfo \
                                                           );                              \
                    if (!pFoundPci)                                                        \
                       return 0;                                                           \
                                                                                           \
                    return *pFoundPci;                                                     \
                   }
    #endif
#endif


#ifndef CLI_ENUM_MODULE_COMPONENTS_IMPL
    #define CLI_ENUM_MODULE_COMPONENTS_IMPL(arrayInfo, initFlag)          \
            MODULE_ENTRY_IMPLEMENTATION                                   \
            MODULE_ENTRY_FUNC                                             \
            PCliComponentInfo                                             \
            CLICALL                                                       \
            cliEnumModuleComponents(SIZE_T idx, PCliComponentInfo pci)    \
               {                                                          \
                CHECK_INIT_COMPONENT_INFO(arrayInfo, initFlag);           \
                if (!pci || idx>=ARRAY_SIZE(arrayInfo)) return 0;         \
                *pci = arrayInfo##Ordered[idx]->info;                     \
                return pci;                                               \
               }
#endif

#ifndef CLI_CREATE_PROC_IMPL
    #define CLI_CREATE_PROC_IMPL(arrayInfo, initFlag)                     \
            MODULE_ENTRY_IMPLEMENTATION                                   \
            MODULE_ENTRY_FUNC                                             \
            GENERIC_OBJ_PTR                                               \
            CLICALL                                                       \
            cli_create_proc( CHAR const * componentId,                    \
                        CHAR const * interfaceId,                         \
                        CLI_IUNKNOWN_PTR outer)                           \
               {                                                          \
                CHECK_INIT_COMPONENT_INFO(arrayInfo, initFlag);           \
                PCliComponentCreationInfo foundPci = findComponentInfo(componentId);                               \
                if ( /* outer || */  !foundPci || !foundPci->factoryProc)                                          \
                   return 0;                                                                                       \
                /* TODO: add query_interface call here */                                                          \
                CLI_IUNKNOWN_PTR pTmpUnk = foundPci->factoryProc(outer);                                           \
                GENERIC_OBJ_PTR  pRes = 0;                                                                        \
                pTmpUnk->queryInterface(interfaceId, &pRes);                                                       \
                pTmpUnk->release(); /* if queryInterface above ailed, this line releases object */                 \
                return pRes;                                                                                       \
               }
#endif

#ifdef CLI_MONOLITHIC
    #define CLI_MONOLITHIC_REGISTER_MODULE(registerProcName, moduleId, enumProc, legacyProc, newStyleProc)     \
            EXTERN_C UINT registerProcName();                                                                  \
            UINT registerProcName()                                                                            \
               {                                                                                               \
                return cliRegisterModule(moduleId, enumProc, legacyProc, newStyleProc);                        \
               }
#else
    #define CLI_MONOLITHIC_REGISTER_MODULE(registerProcName, moduleId, enumProc, legacyProc, newStyleProc)
#endif

#define CLI_MONOLITHIC_REGISTER_MODULE_LEGACY(registerProcName, moduleId)                            \
        CLI_MONOLITHIC_REGISTER_MODULE(registerProcName, moduleId, cliEnumModuleComponents, cli_create_proc, 0)


#ifndef CLI_MONOLITHIC
#define DECLARE_CLI_MODULE_INFO(componentInfoArray, componentInfoInitializedFlag, monolithicRegisterProcName, monolithicModuleName)  \
                                ::cli::CModule cliModule;                             \
                                INIT_CLI_MODULE_NAME(cliModule, monolithicModuleName);\
                                COMPARE_COMPONENT_CREATION_INFO_PROC_IMPL(componentInfoArray);                                       \
                                MAKE_COMPONENTS_INFO_SORTED_PROC_IMPL(componentInfoArray);                                           \
                                FIND_COMPONENTS_INFO_IMPL(componentInfoArray);                                                       \
                                CLI_ENUM_MODULE_COMPONENTS_IMPL(componentInfoArray, componentInfoInitializedFlag);                   \
                                CLI_CREATE_PROC_IMPL(componentInfoArray, componentInfoInitializedFlag);                              \
                                CLI_MONOLITHIC_REGISTER_MODULE_LEGACY(monolithicRegisterProcName, monolithicModuleName);
#else // CLI_MONOLITHIC
#define DECLARE_CLI_MODULE_INFO(componentInfoArray, componentInfoInitializedFlag, monolithicRegisterProcName, monolithicModuleName)  \
                                COMPARE_COMPONENT_CREATION_INFO_PROC_IMPL(componentInfoArray);                                       \
                                MAKE_COMPONENTS_INFO_SORTED_PROC_IMPL(componentInfoArray);                                           \
                                FIND_COMPONENTS_INFO_IMPL(componentInfoArray);                                                       \
                                CLI_ENUM_MODULE_COMPONENTS_IMPL(componentInfoArray, componentInfoInitializedFlag);                   \
                                CLI_CREATE_PROC_IMPL(componentInfoArray, componentInfoInitializedFlag);                              \
                                CLI_MONOLITHIC_REGISTER_MODULE_LEGACY(monolithicRegisterProcName, monolithicModuleName);
#endif


#define CAST_TO_IUNKNOWN_TROUTH(iface, obj) \
                                static_cast<CLI_IUNKNOWN_PTR>( static_cast<iface*>( obj ) )



#define DECLARE_COMPONENT_CREATION_PROC( procName, className, baseInterface)                \
                                static                                       \
                                RCODE procName##_aux(CLI_IUNKNOWN_PTR *piu)  \
                                   {                                         \
                                    CLI_TRY{                                 \
                                            *piu = CAST_TO_IUNKNOWN_TROUTH( baseInterface , new className() ); \
                                           }                                 \
                                    CLI_CATCH_RETURN_CLI_EXCEPTION()         \
                                    CLI_CATCH_RETURN_STD_EXCEPTIONS()        \
                                    return EC_OK;                            \
                                   }                                         \
                                                                             \
                                static                                       \
                                CLI_IUNKNOWN_PTR CLICALL procName(CLI_IUNKNOWN_PTR outer) \
                                   {                                         \
                                    CLI_IUNKNOWN_PTR resultPtr = 0;          \
                                    RCODE res = procName##_aux( &resultPtr );\
                                    if (res) return 0;                       \
                                    return resultPtr;                        \
                                   }

#define CLI_COMPONENT_TABLE_ENTRY1( componentName, creationProc, componentIid, componentDescription ) \
        { { componentName, componentIid, componentDescription } , &creationProc }

#define CLI_COMPONENT_TABLE_ENTRY2( componentName, creationProc, componentIid1, componentIid2, componentDescription ) \
        { { componentName, componentIid1 IIDSEP componentIid2, componentDescription } , &creationProc }

#define CLI_COMPONENT_TABLE_ENTRY3( componentName, creationProc, componentIid1, componentIid2, componentIid3, componentDescription ) \
        { { componentName, componentIid1 IIDSEP componentIid2 IIDSEP componentIid3, componentDescription } , &creationProc }

#define CLI_COMPONENT_TABLE_ENTRY4( componentName, creationProc, componentIid1, componentIid2, componentIid3, componentIid4, componentDescription ) \
        { { componentName, componentIid1 IIDSEP componentIid2 IIDSEP componentIid3 IIDSEP componentIid4, componentDescription } , &creationProc }

#define CLI_COMPONENT_TABLE_ENTRY5( componentName, creationProc, componentIid1, componentIid2, componentIid3, componentIid4, componentIid5, componentDescription ) \
        { { componentName, componentIid1 IIDSEP componentIid2 IIDSEP componentIid3 IIDSEP componentIid4 IIDSEP componentIid5, componentDescription } , &creationProc }

#define CLI_COMPONENT_TABLE_ENTRY6( componentName, creationProc, componentIid1, componentIid2, componentIid3, componentIid4, componentIid5, componentIid6, componentDescription ) \
        { { componentName, componentIid1 IIDSEP componentIid2 IIDSEP componentIid3 IIDSEP componentIid4 IIDSEP componentIid5 IIDSEP componentIid6, componentDescription } , &creationProc }

#define CLI_COMPONENT_TABLE_ENTRY7( componentName, creationProc, componentIid1, componentIid2, componentIid3, componentIid4, componentIid5, componentIid6, componentIid7, componentDescription ) \
        { { componentName, componentIid1 IIDSEP componentIid2 IIDSEP componentIid3 IIDSEP componentIid4 IIDSEP componentIid5 IIDSEP componentIid6 IIDSEP componentIid7, componentDescription } , &creationProc }

#define CLI_COMPONENT_TABLE_ENTRY( componentName, creationProc, componentIid, componentDescription ) \
        CLI_COMPONENT_TABLE_ENTRY1( componentName, creationProc, componentIid, componentDescription )



#define CLI_BEGIN_COMPONENT_TABLE()                                \
                static unsigned infoInitialized = 0;               \
                static                                             \
                CCliComponentCreationInfo moduleComponentsInfo[] = \
                   {

#define CLI_END_COMPONENT_TABLE(monolithicRegisterProcName, monolithicModuleName)                                \
                   };                                                                                            \
                DECLARE_CLI_MODULE_INFO(moduleComponentsInfo, infoInitialized, monolithicRegisterProcName, monolithicModuleName)


#endif /* CLI_IMPLHLP_H */

