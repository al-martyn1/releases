#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLISTR_H
#define CLI_CLISTR_H

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_IALLOCATOR_H
    #include <cli/iallocator.h>
#endif

#ifndef CLI_CLIALLOC_H
    #include <cli/clialloc.h>
#endif

#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

/*

����� ����������
    ������ cliptr.h
           clistr.h

������� ��� ����� �� ������� OLESTR

*/

/* ---------------------------------------------------- */

#include <cli/pshpack4.h>
typedef struct tag_CLISTR
{
    SIZE_T                       reservedSize;      // 4/8  includes terminating zero, realy available space is reservedSize-1
    SIZE_T                       stringSize;        // 4/8
    INTERFACE_CLI_IALLOCATOR    *pAllocator;        // 4/8
    WCHAR                       *pData;             // 4/8
} CLISTR;
#include <cli/poppack.h>

#include <cli/pshpack4.h>
typedef struct tag_CLICSTR
{
    SIZE_T                       reservedSize;      // 4/8  includes terminating zero, realy available space is reservedSize-1
    SIZE_T                       stringSize;        // 4/8
    INTERFACE_CLI_IALLOCATOR    *pAllocator;        // 4/8
    CHAR                        *pData;             // 4/8
} CLICSTR;
#include <cli/poppack.h>

/* ---------------------------------------------------- */

#include <cli/pshpack1.h>
typedef struct tag_CLIPSTR
{
    SIZE_T                       strSize;        // 4/8
    WCHAR                        str[1];
} _CLIPSTR, *CLIPSTR;
#include <cli/poppack.h>

#include <cli/pshpack1.h>
typedef struct tag_CLIPCSTR
{
    SIZE_T                       strSize;        // 4/8
    CHAR                         str[1];
} _CLIPCSTR, *CLIPCSTR;
#include <cli/poppack.h>

/* ---------------------------------------------------- */

#ifndef SIZE_T_NPOS
    #if (defined(__WORDSIZE) && (__WORDSIZE == 64)) || (defined(_INTEGRAL_MAX_BITS) && (_INTEGRAL_MAX_BITS == 64))
        // 64 bit platform
        #define SIZE_T_NPOS    ((SIZE_T)-1LL)
    #else
        // 32 bit platform
        #define SIZE_T_NPOS    ((SIZE_T)-1L)
    #endif
#endif






#if defined(__cplusplus) && !defined(CINTERFACE)


#ifndef CLI_CLIALLOC_H
    #include <cli/clialloc.h>
#endif

#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif

#ifndef CLI_CLIASSERT_H

    #include <cli/cliassert.h>
#endif

template <typename TSTRUCT>
struct CLISTR_char_traits
{
       typedef int char_type;
       typedef INTERFACE_CLI_IALLOCATOR   allocator_interface_type;
       typedef INTERFACE_CLI_IALLOCATOR*  allocator_interface_ptr_type;
       typedef SIZE_T                     size_type;
};


template <>
struct CLISTR_char_traits<CLISTR>
{
       typedef WCHAR char_type;
       typedef INTERFACE_CLI_IALLOCATOR   allocator_interface_type;
       typedef INTERFACE_CLI_IALLOCATOR*  allocator_interface_ptr_type;
       typedef SIZE_T                     size_type;
};

template <>
struct CLISTR_char_traits<CLICSTR>
{
       typedef CHAR char_type;
       typedef INTERFACE_CLI_IALLOCATOR   allocator_interface_type;
       typedef INTERFACE_CLI_IALLOCATOR*  allocator_interface_ptr_type;
       typedef SIZE_T                     size_type;
};



template<typename TCLICSTR_STRUCT>
class CCliStrT : public TCLICSTR_STRUCT
{
    public:

        typedef typename CLISTR_char_traits<TCLICSTR_STRUCT>::char_type                         char_type;
        typedef typename CLISTR_char_traits<TCLICSTR_STRUCT>::allocator_interface_type          allocator_interface_type;
        typedef typename CLISTR_char_traits<TCLICSTR_STRUCT>::allocator_interface_ptr_type      allocator_interface_ptr_type;
        typedef typename CLISTR_char_traits<TCLICSTR_STRUCT>::size_type                         size_type;

        typedef char_type*                                                 char_type_pointer;
        typedef const char_type*                                           char_type_const_pointer;
        typedef ::std::basic_string< char_type,
                                     ::std::char_traits<char_type>,
                                     ::std::allocator<char_type> >         std_string_type;


        void init()
           {
            TCLICSTR_STRUCT :: reservedSize = TCLICSTR_STRUCT :: stringSize = 0;
            TCLICSTR_STRUCT :: pAllocator = 0;
            TCLICSTR_STRUCT :: pData = 0;
            /*
            ((TCLICSTR_STRUCT*)this)->reservedSize = ((TCLICSTR_STRUCT*)this)->stringSize = 0;
            ((TCLICSTR_STRUCT*)this)->pAllocator   = 0;
            ((TCLICSTR_STRUCT*)this)->pData        = 0;
            */
           }

        void uninit()
           {
            if (hasAllocator())
               {
                freeBuf();
                //((TCLICSTR_STRUCT*)this)->pAllocator->release();
                TCLICSTR_STRUCT :: pAllocator->release();
               }
            /* ((TCLICSTR_STRUCT*)this)->reservedSize = ((TCLICSTR_STRUCT*)this)->stringSize = 0;
             * ((TCLICSTR_STRUCT*)this)->pAllocator   = 0;
             * ((TCLICSTR_STRUCT*)this)->pData        = 0;
             */
            TCLICSTR_STRUCT :: reservedSize = TCLICSTR_STRUCT :: stringSize = 0;
            TCLICSTR_STRUCT :: pAllocator   = 0;
            TCLICSTR_STRUCT :: pData        = 0;
           }

    protected:

        static inline
        SIZE_T round2pow(SIZE_T size, SIZE_T startPow = 64)
           {
            while(size>=startPow) startPow <<= 1;
            return startPow;
           }

        void freeBuf()
           {
            if (hasAllocator())
               {
                //if (((TCLICSTR_STRUCT*)this)->pData) { ((TCLICSTR_STRUCT*)this)->pAllocator->deallocate((VOID*)((TCLICSTR_STRUCT*)this)->pData); }
                if (TCLICSTR_STRUCT::pData)
                   {
                    TCLICSTR_STRUCT::pAllocator->deallocate((VOID*)TCLICSTR_STRUCT::pData);
                   }
               }
            /* ((TCLICSTR_STRUCT*)this)->pData = 0;
             * ((TCLICSTR_STRUCT*)this)->reservedSize = ((TCLICSTR_STRUCT*)this)->stringSize = 0;
             */
            TCLICSTR_STRUCT :: pData = 0;
            TCLICSTR_STRUCT :: reservedSize = TCLICSTR_STRUCT :: stringSize = 0;
           }

        bool allocateBuf(SIZE_T nRequired)
           {
            CLIASSERT( hasAllocator() != false );
            /* ((TCLICSTR_STRUCT*)this)->reservedSize = round2pow(nRequired + 1);
             * ((TCLICSTR_STRUCT*)this)->pData = (char_type_pointer)((TCLICSTR_STRUCT*)this)->pAllocator->allocate( ((TCLICSTR_STRUCT*)this)->reservedSize * sizeof(char_type), 0, 0 );
             * if (!((TCLICSTR_STRUCT*)this)->pData) return false;
             */
            TCLICSTR_STRUCT :: reservedSize = round2pow(nRequired + 1);
            TCLICSTR_STRUCT :: pData = (char_type_pointer)TCLICSTR_STRUCT::pAllocator->allocate( TCLICSTR_STRUCT::reservedSize * sizeof(char_type), 0, 0 );
            if (!TCLICSTR_STRUCT::pData) return false;
            return true;
           }

    public:

        void setAllocator(INTERFACE_CLI_IALLOCATOR *pa)
           {
            CLIASSERT( hasAllocator() == false );
            /* ((TCLICSTR_STRUCT*)this)->pAllocator = pa;
             * if (((TCLICSTR_STRUCT*)this)->pAllocator)
             *    ((TCLICSTR_STRUCT*)this)->pAllocator->addRef();
             */
            TCLICSTR_STRUCT :: pAllocator = pa;
            if (TCLICSTR_STRUCT::pAllocator)
               TCLICSTR_STRUCT::pAllocator->addRef();
           }
           
        void createAllocator()
           {
            CLIASSERT( hasAllocator() == false );
            //RCODE res = cliCreateFastAllocator(&(((TCLICSTR_STRUCT*)this)->pAllocator));
            //RCODE res = cliCreateFastAllocator(&(TCLICSTR_STRUCT::pAllocator));
            TCLICSTR_STRUCT *pCliStr = (TCLICSTR_STRUCT*)this;
            RCODE res = cliCreateFastAllocator(&(pCliStr->pAllocator));
            if (RC_FAIL(res)) throw ::std::runtime_error("Failed to create allocator by cliCreateFastAllocator");
           }

        void releaseAllocator()
           {
            CLIASSERT( hasAllocator() != false );
            freeBuf();
            //((TCLICSTR_STRUCT*)this)->pAllocator->release(); ((TCLICSTR_STRUCT*)this)->pAllocator = 0;
            TCLICSTR_STRUCT::pAllocator->release();
            TCLICSTR_STRUCT::pAllocator = 0;
           }

        SIZE_T lenghtOf(char_type_const_pointer str) const
           {
            SIZE_T size = 0;
            if (!str) return size;
            for(; *str; ++str, ++size) {}
            return size;
           }

        //SIZE_T reserved()    const { return ((TCLICSTR_STRUCT*)this)->reservedSize ? ((TCLICSTR_STRUCT*)this)->reservedSize-1 : 0; }
        SIZE_T reserved()    const { return TCLICSTR_STRUCT::reservedSize ? TCLICSTR_STRUCT::reservedSize-1 : 0; }
        //SIZE_T size()        const { return ((TCLICSTR_STRUCT*)this)->stringSize;     }
        SIZE_T size()        const { return TCLICSTR_STRUCT::stringSize;     }
        //const char_type_pointer data()  const { return ((TCLICSTR_STRUCT*)this)->pData; }
        const char_type_pointer data()  const { return TCLICSTR_STRUCT::pData; }
        //const char_type_pointer c_str() const { return ((TCLICSTR_STRUCT*)this)->pData; }
        const char_type_pointer c_str() const { return TCLICSTR_STRUCT::pData; }

        bool isAllocator(INTERFACE_CLI_IALLOCATOR *pa) const
          {
           if (pa && ((UINT_PTR)pa)>0x100) return true;
           return false;
          }

        //bool hasAllocator() const { return isAllocator(((TCLICSTR_STRUCT*)this)->pAllocator); }
        bool hasAllocator(const TCLICSTR_STRUCT &cs) const { return isAllocator(cs.pAllocator); }
        bool hasAllocator() const { return isAllocator(TCLICSTR_STRUCT::pAllocator); }

        void swapReservedSize(size_type &s)
          {
           size_type tmp = TCLICSTR_STRUCT::reservedSize;
           TCLICSTR_STRUCT::reservedSize = s;
           s = tmp;
          }

        void swapStringSize(size_type &s)
          {
           size_type tmp = TCLICSTR_STRUCT::stringSize;
           TCLICSTR_STRUCT::stringSize = s;
           s = tmp;
          }

        void setStringSize(size_type s)
          {
           swapStringSize(s);
          }

        void swapAllocatorPtr(allocator_interface_ptr_type &p)
          {
           allocator_interface_ptr_type tmp = TCLICSTR_STRUCT::pAllocator;
           TCLICSTR_STRUCT::pAllocator = p;
           p = tmp;
          }

        void swapDataPtr(char_type_pointer &p)
          {
           char_type_pointer tmp = TCLICSTR_STRUCT::pData;
           TCLICSTR_STRUCT::pData = p;
           p = tmp;
          }

        void swap( CCliStrT< TCLICSTR_STRUCT>  &cliStr)
          {
           cliStr.swapReservedSize(TCLICSTR_STRUCT::reservedSize);
           cliStr.swapStringSize(TCLICSTR_STRUCT::stringSize);
           cliStr.swapAllocatorPtr(TCLICSTR_STRUCT::pAllocator);
           cliStr.swapDataPtr(TCLICSTR_STRUCT::pData);
          }

        bool reserve(SIZE_T nChars)
           {
            if (nChars<=reserved()) 
               {
                if (nChars) return true; // not need to realloc, current size is sufficient
                if (!hasAllocator()) createAllocator();
               }

            CLIASSERT( hasAllocator() != false );
            size_type newReserveSize = round2pow(nChars + 1);
            TCLICSTR_STRUCT::pData = (char_type_pointer)
                                     TCLICSTR_STRUCT::pAllocator->reallocate( TCLICSTR_STRUCT::pData
                                                                    , newReserveSize*sizeof(char_type)
                                                                    , 0
                                                                    , 0
                                                                    );
            if (!TCLICSTR_STRUCT::pData) return false;
            TCLICSTR_STRUCT::reservedSize = newReserveSize;
            return true;
           }

        void append( char_type_const_pointer str )
           {
            append( str, lenghtOf(str) );
           }

        void append( char_type_const_pointer str, SIZE_T strSize )
           {
            if (hasAllocator())
               {
                reserve( TCLICSTR_STRUCT::stringSize + strSize);
                if (str)
                   {
                    char_type* thisStrBegin = TCLICSTR_STRUCT::pData;
                    thisStrBegin += TCLICSTR_STRUCT::stringSize;
                    //memcpy( (void*)((char_type*)((TCLICSTR_STRUCT*)this)->pData + ((TCLICSTR_STRUCT*)this)->stringSize)
                    memcpy( (void*)thisStrBegin
                          , (void*)str
                          , sizeof(char_type)*strSize
                          );
                   }
                TCLICSTR_STRUCT::stringSize += strSize;
                TCLICSTR_STRUCT::pData[TCLICSTR_STRUCT::stringSize] = 0;  // add terminating zero
               }
            else
               {
                CCliStrT< TCLICSTR_STRUCT > tmpStr;
                //tmpStr.createAllocator();
                tmpStr.assign( this->data(), this->size() );
                tmpStr.append( str, strSize );
                swap(tmpStr);
               }
           }

        void assignLight( char_type_const_pointer str)
           {
            assignLight( str, lenghtOf(str) );
           }

        void assignLight( char_type_const_pointer str, SIZE_T strSize)
           {
            if (hasAllocator()) releaseAllocator();
            /* ((TCLICSTR_STRUCT*)this)->reservedSize = strSize+1; ((TCLICSTR_STRUCT*)this)->stringSize = strSize;
             * ((TCLICSTR_STRUCT*)this)->pData = (char_type_pointer)str;
             */
            TCLICSTR_STRUCT::reservedSize = strSize+1; TCLICSTR_STRUCT::stringSize = strSize;
            TCLICSTR_STRUCT::pData = (char_type_pointer)str;
           }

        void assign( char_type_const_pointer str )
           {
            assign( str, lenghtOf(str) );
           }


        void assign( char_type_const_pointer str, SIZE_T strSize)
           {
            if (!str && !strSize) // assign string to be null
               {
                freeBuf();
                return;
               }

            if (!hasAllocator())
               {
                createAllocator();
                /* ((TCLICSTR_STRUCT*)this)->reservedSize = 0;
                 * ((TCLICSTR_STRUCT*)this)->stringSize   = 0;
                 * ((TCLICSTR_STRUCT*)this)->pData        = 0;
                 */
                TCLICSTR_STRUCT::reservedSize = 0;
                TCLICSTR_STRUCT::stringSize   = 0;
                TCLICSTR_STRUCT::pData        = 0;
               }

            if (reserved()<(strSize+1))
               {
                freeBuf();
                if (!allocateBuf(strSize+1))
                   throw ::std::runtime_error("Not enough memory to hold string");
               }

            if (str)
               memcpy((void*)((TCLICSTR_STRUCT*)this)->pData, (void*)str, sizeof(char_type)*strSize);

            /* ((TCLICSTR_STRUCT*)this)->pData[strSize] = 0;  // add terminating zero
             * ((TCLICSTR_STRUCT*)this)->stringSize = strSize;
             */
            TCLICSTR_STRUCT::pData[strSize] = 0;  // add terminating zero
            TCLICSTR_STRUCT::stringSize = strSize;
           }

        void assign(const TCLICSTR_STRUCT &cs, bool bReuseAllocator = true)
           {
            if (&cs==(TCLICSTR_STRUCT*)this) return; // check and skip self assignment

            if (!hasAllocator())
               { // no own allocator
                if (hasAllocator(cs) && bReuseAllocator)
                   {// copy existing allocator object
                    /* ((TCLICSTR_STRUCT*)this)->pAllocator = cs.pAllocator;
                     * ((TCLICSTR_STRUCT*)this)->pAllocator->addRef();
                     * ((TCLICSTR_STRUCT*)this)->reservedSize = 0;
                     * ((TCLICSTR_STRUCT*)this)->stringSize   = 0;
                     * ((TCLICSTR_STRUCT*)this)->pData       = 0;
                     */
                    TCLICSTR_STRUCT::pAllocator    = cs.pAllocator;
                    if (TCLICSTR_STRUCT::pAllocator) TCLICSTR_STRUCT::pAllocator->addRef();
                    TCLICSTR_STRUCT::reservedSize  = 0;
                    TCLICSTR_STRUCT::stringSize    = 0;
                    TCLICSTR_STRUCT::pData         = 0;
                   }
               }

            assign(cs.pData, cs.stringSize);
           }

        void assign(const CCliStrT &cs, bool bReuseAllocator = true)
           {
            assign(*((TCLICSTR_STRUCT*)&cs), bReuseAllocator);
           }

        CCliStrT()  { init(); }
        ~CCliStrT() { uninit(); }
        CCliStrT(const TCLICSTR_STRUCT& s) { init(); assign(s); }
        CCliStrT(const CCliStrT& s) { init(); assign(s); }
        CCliStrT(const std_string_type& s) { init(); assign(s.data(), s.size()); }
        CCliStrT(char_type_const_pointer str, SIZE_T strSize) { init(); assign(str, strSize); }
        CCliStrT(char_type_const_pointer str)                 { init(); assign(str); }

        operator std_string_type() const
           {
            return std_string_type(data(), size());
           }

}; // CCliStrT

typedef CCliStrT<CLISTR>            CCliStr;
typedef CCliStrT<CLICSTR>           CCliCStr;

// dst, src
inline void CCliStr_init( CCliStr &dst)                                         {  /* do nothing, CCliStr has constructor */  }
inline void CCliStr_copyTo( CCliStr &dst, const ::std::wstring &src)
   {
    dst.assign(src.data(), src.size());
   }
inline void CCliStr_copyTo( CLISTR *dst, const ::std::wstring &src)
   {
    CCliStr_copyTo( *((CCliStr*)dst), src );
   }
inline void CCliStr_copyFrom(::std::wstring &dst, const CCliStr &src)
   {
    dst.assign( src.data(), src.size() );
   }
inline void CCliStr_lightCopyTo(CCliStr &dst, const ::std::wstring &src)
   {
    dst.assignLight(src.data(), src.size());
   }
inline void CCliStr_copyFromIfModified(::std::wstring &dst, const CCliStr &src)
   {
    if (!src.hasAllocator() && src.data()==dst.data() && src.size()==dst.size())
       return; // not modified
    if (!src.data() || !src.size())
       {
        dst.clear();
        return;
       }
    dst.assign( src.data(), src.size() );
   }

inline void CCliCStr_init( CCliCStr &dst)                                        {  /* do nothing, CCliCStr has constructor */  }
inline void CCliCStr_copyTo( CCliCStr &dst, const ::std::string &src)
   {
    dst.assign(src.data(), src.size());
   }
inline void CCliCStr_copyTo( CLICSTR *dst, const ::std::string &src)
   {
    CCliCStr_copyTo( *((CCliCStr*)dst), src );
   }
inline void CCliCStr_copyFrom(::std::string &dst, const CCliCStr &src)
   {
    dst.assign( src.data(), src.size() );
   }
inline void CCliCStr_lightCopyTo(CCliCStr &dst, const ::std::string &src)
   {
    dst.assignLight(src.data(), src.size());
   }
inline void CCliCStr_copyFromIfModified(::std::string &dst, const CCliCStr &src)
   {
    if (!src.hasAllocator() && src.data()==dst.data() && src.size()==dst.size()) return; // not modified
    if (!src.data() || !src.size())
       {
        dst.clear();
        return;
       }
    dst.assign( src.data(), src.size() );
   }

inline
::std::wstring stdstr(const WCHAR *pStr, SIZE_T strSize=SIZE_T_NPOS)
   {
    if (!pStr) return ::std::wstring();
    return (strSize==SIZE_T_NPOS ? ::std::wstring(pStr) : ::std::wstring(pStr, strSize));
   }

inline
::std::wstring stdstr(const ::std::wstring &w) { return w; }

inline
::std::string stdstr(const CHAR *pStr, SIZE_T strSize=SIZE_T_NPOS)
   {
    if (!pStr) return ::std::string();
    return (strSize==SIZE_T_NPOS ? ::std::string(pStr) : ::std::string(pStr, strSize));
   }

inline
::std::string stdstr(const ::std::string &s) { return s; }

inline
::std::wstring stdstr( const CLISTR &str )
   {
    return CCliStr(str);
   }

inline
::std::wstring stdstr( const CLISTR *str )
   {
    if (str) return CCliStr(*str);
    else return ::std::wstring();
   }

inline
::std::string stdstr( const CLICSTR &str )
   {
    return CCliCStr(str);
   }

inline
::std::string stdstr( const CLICSTR *str )
   {
    if (str) return CCliCStr(*str);
    else return ::std::string();
   }


/*
#include <cli/pshpack1.h>
typedef struct tag_CLIPSTR
{
    SIZE_T                       strSize;        // 4/8
    WCHAR                        str[1];
} _CLIPSTR, *CLIPSTR;
#include <cli/poppack.h>

#include <cli/pshpack1.h>
typedef struct tag_CLIPCSTR
{
    SIZE_T                       strSize;        // 4/8
    CHAR                         str[1];
} _CLIPCSTR, *CLIPCSTR;
#include <cli/poppack.h>
*/

/* ---------------------------------------------------- */


inline SIZE_T clipstr_size(const CLIPSTR str)
   {
    return str ? str->strSize : 0;
   }
inline SIZE_T clipstr_size(const CLIPCSTR str)
   {
    return str ? str->strSize : 0;
   }

inline const WCHAR* clipstr_c_str(const CLIPSTR str)
   {
    return str ? reinterpret_cast<const WCHAR*>(str->str) : 0;
   }
inline const CHAR*  clipstr_c_str(const CLIPCSTR str)
   {
    return str ? reinterpret_cast<const CHAR*> (str->str) : 0;
   }
inline const WCHAR* clipstr_data (const CLIPSTR str)
   {
    return str ? reinterpret_cast<const WCHAR*>(str->str) : 0;
   }
inline const CHAR*  clipstr_data (const CLIPCSTR str)
   {
    return str ? reinterpret_cast<const CHAR*> (str->str) : 0;
   }

inline SIZE_T clipstr_strLen(const WCHAR *str)
   {
    SIZE_T res = 0;
    while(*str++)
       ++res;
    return res;
   }
inline SIZE_T clipstr_strLen(const CHAR *str)
   {
    SIZE_T res = 0;
    while(*str++)
       ++res;
    return res;
   }


struct CCliPStrDummyConverter
{
    CLIPSTR                   pstr;
    CCliPStrDummyConverter( CLIPSTR p) : pstr(p) {}
    operator ::std::wstring() const
       {
        return ::std::wstring( clipstr_data(pstr), clipstr_size(pstr) );
       }
};

struct CCliPCStrDummyConverter
{
    CLIPCSTR                 pstr;
    CCliPCStrDummyConverter( CLIPCSTR p) : pstr(p) {}
    operator ::std::string() const
       {
        return ::std::string( clipstr_data(pstr), clipstr_size(pstr) );
       }
};


/*
inline WCHAR* clipstr_c_str(CLIPSTR str)               { return reinterpret_cast<WCHAR*>(str->str); }
inline CHAR*  clipstr_c_str(CLIPCSTR str)              { return reinterpret_cast<CHAR*> (str->str); }
inline WCHAR* clipstr_data (CLIPSTR str)               { return reinterpret_cast<WCHAR*>(str->str); }
inline  CHAR* clipstr_data (CLIPCSTR str)              { return reinterpret_cast<CHAR*> (str->str); }
*/

inline void clipstr_alloc( CLIPSTR *str, const WCHAR* chStr, SIZE_T strLen )
   {
    CLIASSERT(str!=0);

    *str = (CLIPSTR)::cli::getAllocator()->allocate( (strLen + 1) * sizeof(WCHAR) + sizeof(SIZE_T), 0, 0);
    if (!*str) return;

    (*str)->strSize = strLen;
    //memcpy((void*)&((*str)->str[0]), (void*)chStr, strLen * sizeof(WCHAR));
    memcpy((void*)clipstr_data(*str), (void*)chStr, strLen * sizeof(WCHAR));
    (*str)->str[strLen] = 0;
   }

inline void clipstr_alloc( CLIPSTR *pstr, const ::std::wstring &str )
   {
    clipstr_alloc( pstr, str.data(), str.size() );
   }

inline void clipstr_alloc( CLIPSTR *str, const WCHAR* chStr )
   {
    SIZE_T strLen = 0;
    if (chStr)
       strLen = clipstr_strLen(chStr);
    clipstr_alloc( str, chStr, strLen );
   }

inline void clipstr_alloc( CLIPSTR *dst, CLIPSTR str )
   {
    clipstr_alloc( dst, clipstr_data(str), clipstr_size(str) );
   }

inline void clipstr_alloc( CLIPCSTR *str, const CHAR* chStr, SIZE_T strLen )
   {
    CLIASSERT(str!=0);

    *str = (CLIPCSTR)::cli::getAllocator()->allocate( (strLen + 1) * sizeof(CHAR) + sizeof(SIZE_T), 0, 0);
    if (!*str) return;

    (*str)->strSize = strLen;
    //memcpy((void*)&((*str)->str[0]), (void*)chStr, strLen * sizeof(CHAR));
    memcpy((void*)clipstr_data(*str), (void*)chStr, strLen * sizeof(CHAR));
    (*str)->str[strLen] = 0;
   }

inline void clipstr_alloc( CLIPCSTR *pstr, const ::std::string &str )
   {
    clipstr_alloc( pstr, str.data(), str.size() );
   }


inline void clipstr_alloc( CLIPCSTR *str, const CHAR* chStr )
   {
    SIZE_T strLen = 0;
    if (chStr)
       strLen = clipstr_strLen(chStr);
    clipstr_alloc( str, chStr, strLen );
   }

inline void clipstr_alloc( CLIPCSTR *dst, CLIPCSTR str )
   {
    clipstr_alloc( dst, clipstr_data(str), clipstr_size(str) );
   }

inline void clipstr_free( CLIPSTR *str)
   {
    if (!str || !(*str)) return;
    ::cli::getAllocator()->deallocate((void*)*str );
    *str = 0;
   }

inline void clipstr_free( CLIPCSTR *str)
   {
    if (!str || !(*str)) return;
    ::cli::getAllocator()->deallocate((void*)*str );
    *str = 0;
   }

inline void clipstr_assign( CLIPSTR *str, const WCHAR* chStr, SIZE_T strLen )
   {
    CLIASSERT(str!=0);
    clipstr_free(str);
    clipstr_alloc( str, chStr, strLen );
   }

inline void clipstr_assign( CLIPCSTR *str, const CHAR* chStr, SIZE_T strLen )
   {
    CLIASSERT(str!=0);
    clipstr_free(str);
    clipstr_alloc( str, chStr, strLen );
   }

inline void clipstr_assign( CLIPSTR *str, const ::std::wstring &stdStr )
   {
    clipstr_assign(str, stdStr.data(), stdStr.size());
   }

inline void clipstr_assign( CLIPCSTR *str, const ::std::string &stdStr )
   {
    clipstr_assign(str, stdStr.data(), stdStr.size());
   }

inline void clipstr_assign( CLIPSTR *str, const WCHAR* chStr )
   {
    CLIASSERT(str!=0);
    clipstr_free(str);
    clipstr_alloc( str, chStr );
   }

inline void clipstr_assign( CLIPCSTR *str, const CHAR* chStr )
   {
    CLIASSERT(str!=0);
    clipstr_free(str);
    clipstr_alloc( str, chStr );
   }

inline void clipstr_assign( CLIPSTR *dst, CLIPSTR str )
   {
    clipstr_assign( dst, clipstr_data(str), clipstr_size(str) );
   }

inline void clipstr_assign( CLIPCSTR *dst, CLIPCSTR str )
   {
    clipstr_assign( dst, clipstr_data(str), clipstr_size(str) );
   }



inline void clipstr_append(CLIPSTR *str, const WCHAR* chStr, SIZE_T strLen)
   {
    CLIASSERT(str!=0);

    CLIPSTR resStr = (CLIPSTR)::cli::getAllocator()->allocate( (clipstr_size(*str) + strLen + 1) * sizeof(WCHAR) + sizeof(SIZE_T), 0, 0);
    if (resStr)
       {
        resStr->strSize = strLen;
        memcpy((void*)clipstr_data(resStr)                     , (void*)clipstr_data(*str), clipstr_size(*str)*sizeof(WCHAR));
        memcpy((void*)(clipstr_data(resStr)+clipstr_size(*str)), (void*)chStr             , strLen*sizeof(WCHAR));
        resStr->str[ clipstr_size(*str) + strLen ] = 0;
       }
    clipstr_free(str);
    *str = resStr;
   }

inline void clipstr_append(CLIPCSTR *str, const CHAR* chStr, SIZE_T strLen)
   {
    CLIASSERT(str!=0);

    CLIPCSTR resStr = (CLIPCSTR)::cli::getAllocator()->allocate( (clipstr_size(*str) + strLen + 1) * sizeof(CHAR) + sizeof(SIZE_T), 0, 0);
    if (resStr)
       {
        resStr->strSize = strLen;
        memcpy((void*)clipstr_data(resStr)                     , (void*)clipstr_data(*str), clipstr_size(*str)*sizeof(CHAR));
        memcpy((void*)(clipstr_data(resStr)+clipstr_size(*str)), (void*)chStr             , strLen*sizeof(CHAR));
        resStr->str[ clipstr_size(*str) + strLen ] = 0;
       }
    clipstr_free(str);
    *str = resStr;
   }

inline void clipstr_append(CLIPSTR *str, const WCHAR* chStr)
   {
    SIZE_T strLen = 0;
    if (chStr)
       strLen = clipstr_strLen(chStr);
    clipstr_append( str, chStr, strLen );
   }

inline void clipstr_append(CLIPCSTR *str, const CHAR* chStr)
   {
    SIZE_T strLen = 0;
    if (chStr)
       strLen = clipstr_strLen(chStr);
    clipstr_append( str, chStr, strLen );
   }

inline void clipstr_append( CLIPSTR *dst, CLIPSTR str )
   {
    clipstr_append( dst, clipstr_data(str), clipstr_size(str) );
   }

inline void clipstr_append( CLIPCSTR *dst, CLIPCSTR str )
   {
    clipstr_append( dst, clipstr_data(str), clipstr_size(str) );
   }





inline void CLIPSTR_init( CLIPSTR &dst)
   {
    *(&dst) = 0;
   }

inline void CLIPSTR_copyTo( CLIPSTR &dst, const ::std::wstring &src)
   { // assumes that dst is initialized
    clipstr_assign(&dst, src.data(), src.size());
   }

inline void CLIPSTR_copyFrom(::std::wstring &dst, CLIPSTR &src, bool bFree = true)
   {
    dst.assign( clipstr_data(src), clipstr_size(src) );
    if (bFree) clipstr_free(&src);
   }

inline void CLIPSTR_lightCopyTo(CLIPSTR &dst, const ::std::wstring &src)
   { // assumes that dst not initialized
    clipstr_alloc(&dst, src.data(), src.size());
   }

inline void CLIPSTR_copyFromIfModified(::std::wstring &dst, CLIPSTR &src, bool bFree = true)
   {
    dst.assign( clipstr_data(src), clipstr_size(src) );
    if (bFree) clipstr_free(&src);
   }


inline void CLIPCSTR_init( CLIPCSTR &dst)
   {
    *(&dst) = 0;
   }

inline void CLIPCSTR_copyTo( CLIPCSTR &dst, const ::std::string &src)
   { // assumes that dst is initialized
    clipstr_assign(&dst, src.data(), src.size());
   }

inline void CLIPCSTR_copyFrom(::std::string &dst, CLIPCSTR &src, bool bFree = true)
   {
    dst.assign( clipstr_data(src), clipstr_size(src) );
    if (bFree) clipstr_free(&src);
   }

inline void CLIPCSTR_lightCopyTo(CLIPCSTR &dst, const ::std::string &src)
   { // assumes that dst not initialized
    clipstr_alloc(&dst, src.data(), src.size());
   }

inline void CLIPCSTR_copyFromIfModified(::std::string &dst, CLIPCSTR &src, bool bFree = true)
   {
    dst.assign( clipstr_data(src), clipstr_size(src) );
    if (bFree) clipstr_free(&src);
   }




inline
::std::wstring stdstr( const CLIPSTR str )
   {
    return CCliPStrDummyConverter(str);
   }

inline
::std::string stdstr( const CLIPCSTR str )
   {
    return CCliPCStrDummyConverter(str);
   }

inline
::std::wstring stdstr( const CLIPSTR *pstr )
   {
    if (!pstr) return ::std::wstring();
    return CCliPStrDummyConverter(*pstr);
   }

inline
::std::string stdstr( const CLIPCSTR *pstr )
   {
    if (!pstr) return ::std::string();
    return CCliPCStrDummyConverter(*pstr);
   }



inline
CLIPSTR clipstr(const std::wstring &str)
   {
    CLIPSTR pstr = 0;
    clipstr_alloc( &pstr, str.data(), str.size() );
    return pstr;
   }

inline
CLIPCSTR clipstr(const std::string &str)
   {
    CLIPCSTR pstr = 0;
    clipstr_alloc( &pstr, str.data(), str.size() );
    return pstr;
   }

inline
CLIPSTR clipstr(const CLISTR &str)
   {
    CLIPSTR pstr = 0;
    clipstr_alloc( &pstr, str.pData, str.stringSize );
    return pstr;
   }

inline
CLIPCSTR clipstr(const CLICSTR &str)
   {
    CLIPCSTR pstr = 0;
    clipstr_alloc( &pstr, str.pData, str.stringSize );
    return pstr;
   }

// class for automatic CLIPSTR destruction
template< typename Str
        , typename CharType
        >
class CCliPStrBase
{
        Str     pstr;

        CCliPStrBase(const CCliPStrBase &) : pstr(0) {}
        CCliPStrBase& operator=(const CCliPStrBase &) { return *this; }

    public:
        typedef ::std::basic_string< CharType,
                                     ::std::char_traits<CharType>,
                                     ::std::allocator<CharType> >         std_string_type;

        CCliPStrBase() : pstr(0) {}
        // copy from plain type
        CCliPStrBase(Str s) : pstr(0)
           {
            clipstr_alloc(&pstr, clipstr_data(s), clipstr_size(s) );
           }

        CCliPStrBase(const std_string_type &s) : pstr(0)
           {
            clipstr_alloc(&pstr, s.data(), s.size() );
           }

        operator std_string_type() const
           {
            return std_string_type( clipstr_data(pstr), clipstr_size(pstr) );
           }

        CCliPStrBase& operator=(const std_string_type &s)
           {
            clipstr_assign(&pstr, s.data(), s.size() );
            return *this;
           }

        ~CCliPStrBase()
           {
            clipstr_free( &pstr );
           }

        operator Str()
           {
            return pstr;
           }

        Str* operator&()
           {
            return &pstr;
           }

        const Str* operator&() const
           {
            return &pstr;
           }

};

typedef CCliPStrBase < CLIPSTR , WCHAR > CCliPStr;
typedef CCliPStrBase < CLIPCSTR, CHAR  > CCliPCStr;

inline void CCliPStr_init( CCliPStr &dst)                                        {  /* do nothing, CCliPStr has constructor */  }
inline void CCliPStr_copyTo( CCliPStr &dst, const ::std::wstring &src)
   {
    dst = src;
   }
//inline void CCliPStr_copyTo( CLISTR *dst, const ::std::wstring &src)             { CCliStr_copyTo( *((CCliStr*)dst), src ); }
inline void CCliPStr_copyFrom(::std::wstring &dst, const CCliPStr &src)
   {
    dst = src;
   }
inline void CCliPStr_lightCopyTo(CCliPStr &dst, const ::std::wstring &src)
   {
    dst = src;
   }
inline void CCliPStr_copyFromIfModified(::std::wstring &dst, const CCliPStr &src)
   {
    dst = src;
   }

inline void CCliPCStr_init( CCliPCStr &dst)                                        {  /* do nothing, CCliPStr has constructor */  }
inline void CCliPCStr_copyTo( CCliPCStr &dst, const ::std::string &src)
   {
    dst = src;
   }
//inline void CCliPCStr_copyTo( CLISTR *dst, const ::std::wstring &src)             { CCliStr_copyTo( *((CCliStr*)dst), src ); }
inline void CCliPCStr_copyFrom(::std::string &dst, const CCliPCStr &src)
   {
    dst = src;
   }
inline void CCliPCStr_lightCopyTo(CCliPCStr &dst, const ::std::string &src)
   {
    dst = src;
   }
inline void CCliPCStr_copyFromIfModified(::std::string &dst, const CCliPCStr &src)
   {
    dst = src;
   }

/*
inline
::std::wstring stdstr( const CLISTR &str )
   {
    return CCliStr(str);
   }

inline
::std::string stdstr( const CLICSTR &str )
   {
    return CCliCStr(str);
   }
*/


#endif // defined(__cplusplus) && !defined(CINTERFACE)


#endif /* CLI_CLISTR_H */

