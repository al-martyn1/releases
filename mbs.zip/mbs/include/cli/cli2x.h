#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLI2X_H
#define CLI_CLI2X_H

/*
#ifndef CLI_CLI2X_H
    #include <cli/cli2x.h>
#endif
*/

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifdef WIN32
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else /* __GNUC__ */
     #include <alloca.h>
     #ifndef _alloca
         #define _alloca  alloca
     #endif
#endif


namespace cli
{

//-----------------------------------------------------------------------------
bool enumCategoryComponents(const ::std::string &category, SIZE_T componentsIdx, ::std::string &componentName)
   {
    if (category.empty()) return false;
    SIZE_T needChars = cliEnumCategoryComponents( category.c_str(), componentsIdx, 0, 0 );
    if (!needChars) return false;

    CHAR *buf = (CHAR*)_alloca(needChars);
    needChars = cliEnumCategoryComponents( category.c_str(), componentsIdx, needChars, buf );
    if (!needChars) return false;
   
    componentName = ::std::string(buf);
    return true;
   }
//-----------------------------------------------------------------------------
inline
bool enumComponentCategories(const ::std::string &componentId, SIZE_T categoryIdx, ::std::string &categoryName)
   {
    if (componentId.empty()) return false;
    SIZE_T needChars = cliEnumComponentCategories( componentId.c_str(), categoryIdx, 0, 0 );
    if (!needChars) return false;

    CHAR *buf = (CHAR*)_alloca(needChars);
    needChars = cliEnumComponentCategories( componentId.c_str(), categoryIdx, needChars, buf );
    if (!needChars) return false;
   
    categoryName = ::std::string(buf);
    return true;
   }

//-----------------------------------------------------------------------------
inline
bool enumCategories( SIZE_T categoryIdx, ::std::string &categoryName)
   {
    SIZE_T needChars = cliEnumCategories( categoryIdx, 0, 0 );
    if (!needChars) return false;

    CHAR *buf = (CHAR*)_alloca(needChars);
    needChars = cliEnumCategories( categoryIdx, needChars, buf );
    if (!needChars) return false;
   
    categoryName = ::std::string(buf);
    return true;
   }

#ifndef CLI_EMBEDDED

inline
bool matchMask(const ::std::string &name, const ::std::string &mask)
   {
    return cliMatchMaskC(name.c_str(), mask.c_str()) ? true : false;
   }

inline
bool matchMask(const ::std::wstring &name, const ::std::wstring &mask)
   {
    return cliMatchMaskW(name.c_str(), mask.c_str()) ? true : false;
   }

//-----------------------------------------------------------------------------
void getCategoriesByMask( const ::std::string &mask, ::std::vector< ::std::string > &categories)
   {
    SIZE_T idx = 0;
    ::std::string categoryName;

    while(::cli::enumCategories( idx, categoryName))
       {
        if (matchMask(categoryName, mask))
           categories.push_back(categoryName);
        ++idx;
       }
   }

//-----------------------------------------------------------------------------
void getCategoriesByMask( const ::std::vector< ::std::string > &maskList, ::std::vector< ::std::string > &categories)
   {
    SIZE_T idx = 0;
    ::std::string categoryName;

    while(::cli::enumCategories( idx, categoryName))
       {
        ::std::vector< ::std::string >::const_iterator mit = maskList.begin();
        for(; mit!=maskList.end(); ++mit)
           {
            if (matchMask(categoryName, *mit))
               {
                categories.push_back(categoryName);
                break;
               }
           }
        ++idx;
       }
   }
#endif


//-----------------------------------------------------------------------------




}; // namespace cli


#endif /* CLI_CLI2X_H */

