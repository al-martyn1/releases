#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLI2BASE_H
#define CLI_CLI2BASE_H

/* Add next lines to your C/C++ code
#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif
*/

#ifndef CLI_EMBED_H
    #include <cli/embed.h>
#endif

#ifndef CLI_DETECTTARGET_H
    #include <cli/detectTarget.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif



#ifdef __GNUC__
    #define CLI_DEPRECATED_IMPL(func) func __attribute__ ((deprecated))
#elif defined(_MSC_VER)
    #define CLI_DEPRECATED_IMPL(func) __declspec(deprecated) func
#else
    #define CLI_DEPRECATED_IMPL(func) func
#endif

/* allow to use deprecated functions in cli core */
#if defined(CLI_INTERNAL)
    #define CLI_DEPRECATED(func)   func
#else /* don't use it in client code */
    #define CLI_DEPRECATED(func)   CLI_DEPRECATED_IMPL(func)
#endif

/* function is deprecated for internal usage also */
#define CLI_INTERNAL_DEPRECATED(func)   CLI_DEPRECATED_IMPL(func)



#ifdef __cplusplus
    #if !defined(CLI_MONOLITHIC) && !defined(CLI_MONOLITH)
        #ifndef MARTY_LIBAPI_H
            #include <marty/libapi.h>
        #endif
    #endif
#endif

#ifndef ABSTRACT_MODULE_HANDLE_DEFINED

    #define ABSTRACT_MODULE_HANDLE_DEFINED

    #ifdef WIN32
        typedef HMODULE  ABSTRACT_MODULE_HANDLE;
    #else
        typedef void*    ABSTRACT_MODULE_HANDLE;
    #endif

#endif /* ABSTRACT_MODULE_HANDLE_DEFINED */


/* to avoid conflict with win32 objbase.h we test 'interface' macro existence */
#if !defined(interface)
    #if defined(__cplusplus) && !defined(CINTERFACE)
        #define __STRUCT__ struct
        #define interface __STRUCT__
    #else
        #define interface struct
    #endif
#endif


// Usage: typedef void (CLICALL *StdcallFnPtr)( );
#ifndef CLICALL
    #if defined(_MSC_VER) || defined(__BORLANDC__)
        #define CLICALL __stdcall
    #elif defined(__GNUC__)
        #if defined(MACHINE_ARM)
            #define CLICALL
        #else
            #define CLICALL __attribute__((stdcall))
        #endif
    #else
        #error "Unsupported compiler"
    #endif
#endif

// Usage: typedef void (CLICALLVA *CdeclFnPtr)( );
#ifndef CLICALLVA
    #if defined(_MSC_VER) || defined(__BORLANDC__)
        #define CLICALLVA __cdecl
    #elif defined(__GNUC__)
        #if defined(MACHINE_ARM)
            #define CLICALLVA __attribute__((cdecl))
        #else
            #define CLICALLVA
        #endif
    #else
        #error "Unsupported compiler"
    #endif
#endif

#ifndef STDCALL
    #define STDCALL CLICALL
#endif

#ifndef CDECL
    #define CDECL   CLICALLVA
#endif

#ifndef EXTERN_C
    #ifdef __cplusplus
        #define EXTERN_C   extern "C"
    #else
        #define EXTERN_C
    #endif
#endif


#ifndef MODULE_EXPORT
    #if defined(_MSC_VER) || defined(__BORLANDC__) || (defined(__GNUC__) && defined(_WIN32))
        #define MODULE_EXPORT __declspec(dllexport)
        #define MODULE_IMPORT __declspec(dllimport)
        #define MODULE_LOCAL
    #elif defined(__GNUC__)
        #ifdef HAVE_GCCVISIBILITYPATCH
          #define MODULE_EXPORT __attribute__ ((visibility("default")))
          #define MODULE_IMPORT __attribute__ ((visibility("default")))
          //#define MODULE_LOCAL __attribute__ ((visibility("hidden")))
          #define MODULE_LOCAL __attribute__ ((visibility("internal")))
        #else
          #define MODULE_EXPORT
          #define MODULE_IMPORT
          #define MODULE_LOCAL
        #endif
    #endif
#endif

#ifndef CLI_DEPRECATED
    #if defined(_MSC_VER) //  || defined(__BORLANDC__)
        #if (_MSC_VER>=1300)
            #define CLI_DEPRECATED  __declspec(deprecated)
        #else
            #define CLI_DEPRECATED
        #endif
    #elif defined(__GNUC__)
        #if ((__GNUC__ * 10000 + __GNUC_MINOR__ * 100) >= 30100)
            #define CLI_DEPRECATED  __attribute__ ((deprecated))
        #else
            #define CLI_DEPRECATED
        #endif
    #else
        #define CLI_DEPRECATED
    #endif
#endif

#ifndef CLI_DEPRECATED_MSG
    #if defined(_MSC_VER) //  || defined(__BORLANDC__)
        #if (_MSC_VER>=1300)
            #define CLI_DEPRECATED_MSG(msg)  __declspec(deprecated(msg))
        #else
            #define CLI_DEPRECATED_MSG(msg)
        #endif
    #elif defined(__GNUC__)
        #if ((__GNUC__ * 10000 + __GNUC_MINOR__ * 100) >= 40500)
            #define CLI_DEPRECATED_MSG(msg)  __attribute__ ((deprecated(msg)))
        #else
            #define CLI_DEPRECATED_MSG(msg)  CLI_DEPRECATED
        #endif
    #else
        #define CLI_DEPRECATED_MSG(msg)
    #endif
#endif





#ifndef STATIC
    #define STATIC static
#endif

#ifndef EXTERN_CLI
    #ifdef CLI_MONOLITHIC
        #define EXTERN_CLI  EXTERN_C
    #else
        #define EXTERN_CLI  EXTERN_C
    #endif
#endif




#ifndef MODULE_EXPORT_FUNC
    #define MODULE_EXPORT_FUNC MODULE_EXPORT
#endif

#ifndef MODULE_IMPORT_FUNC
    #define MODULE_IMPORT_FUNC MODULE_IMPORT
#endif

#ifndef MODULE_LOCAL_FUNC
    #define MODULE_LOCAL_FUNC MODULE_LOCAL
#endif

#ifndef MODULE_STATIC_FUNC
    #define MODULE_STATIC_FUNC STATIC
#endif

#ifndef MODULE_ENTRY_FUNC
    #if !defined(CLI_MONOLITHIC) && !defined(CLI_MONOLITH)
        #define MODULE_ENTRY_FUNC MODULE_EXPORT_FUNC
    #else
        #define MODULE_ENTRY_FUNC MODULE_STATIC_FUNC
    #endif
#endif

#ifndef MODULE_ENTRY_IMPLEMENTATION
    #if !defined(CLI_MONOLITHIC) && !defined(CLI_MONOLITH)
        #define MODULE_ENTRY_IMPLEMENTATION
    #else
        #define MODULE_ENTRY_IMPLEMENTATION  /* MODULE_STATIC_FUNC */
    #endif
#endif


#include <cli/ifdefs.h>
#include <cli/iidof.h>
#include <cli/iunknown.h>


#ifndef ARRAY_SIZE
   #define ARRAY_SIZE(a) (sizeof(a)/sizeof(a[0]))
#endif

#ifndef GENERIC_OBJ_PTR
    #define GENERIC_OBJ_PTR void*
#endif

#ifndef CLI_IUNKNOWN_PTR
    #define CLI_IUNKNOWN_PTR    INTERFACE_CLI_IUNKNOWN*
#endif

#ifndef GENERIC_OBJ_FACTORY_DECLARED
    #define GENERIC_OBJ_FACTORY_DECLARED
    typedef CLI_IUNKNOWN_PTR (CLICALL *genericObjFactoryProc)(CLI_IUNKNOWN_PTR outer);
#endif


// module must export this function
#if !defined(CLI_MONOLITHIC) || defined(NEED_CLI_CREATE_PROC_DECLARATION)
EXTERN_CLI
MODULE_ENTRY_FUNC
GENERIC_OBJ_PTR
CLICALL
cli_create_proc( CHAR const * componentId,
            CHAR const * interfaceId,
            CLI_IUNKNOWN_PTR outer);
#endif


typedef
GENERIC_OBJ_PTR
(CLICALL *cli_create_proc_t)( CHAR const * componentId,
            CHAR const * interfaceId,
            CLI_IUNKNOWN_PTR outer);

#ifndef OLD_CLICREATEPROCNAME
    #define OLD_CLICREATEPROCNAME "cli_create_proc"
#endif

#ifndef LEGACY_CLICREATEPROCNAME
    #define LEGACY_CLICREATEPROCNAME OLD_CLICREATEPROCNAME
#endif

typedef  GENERIC_OBJ_PTR   CliCreateProcT;
typedef  GENERIC_OBJ_PTR   CliCanUnloadProcT;


#if !defined(CLI_MONOLITHIC) || defined(NEED_CLI_CAN_UNLOAD_PROC_DECLARATION)
EXTERN_CLI
MODULE_ENTRY_FUNC
DWORD
CLICALL
cli_can_unload_proc( );
#endif


typedef
DWORD
(CLICALL *cli_can_unload_proc_t)( );

#ifndef OLD_CLICANUNLOADPROCNAME
    #define OLD_CLICANUNLOADPROCNAME "cli_can_unload_proc"
#endif

#ifndef LEGACY_CLICANUNLOADPROCNAME
    #define LEGACY_CLICANUNLOADPROCNAME OLD_CLICANUNLOADPROCNAME
#endif



//#if defined(__GNUC__) && _GNUC_VER>=40100
#if defined(__GNUC__) && (__GNUC__ * 10000 + __GNUC_MINOR__ * 100) >= 40100
    #define ARG_UNUSED  __attribute__((unused))
#else
    #define ARG_UNUSED
#endif

// __attribute__((format(printf, 2, 3)))

#if !defined(CLI2_INLINE_OR_STATIC)
    #if defined(__cplusplus)
        #define CLI2_INLINE_OR_STATIC  inline
    #else
        #define CLI2_INLINE_OR_STATIC  static
    #endif
#endif


/*#define CLI_ARG_USED(a) (void*)(&(a))*/
#define CLI_ARG_USED(a) (void)(a)
#define CLI_ARGUSED(a)  CLI_ARG_USED(a)


#endif /* CLI_CLI2BASE_H */

