#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_ICLIGUI_H
#define CLI_ICLIGUI_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/icligui.h>", CLI_ICLIGUI_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_ICLIGUI_H
    #include <cli/icligui.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_GUITYPES_H
    #include <cli/guitypes.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_GUI_ERRDLG_H
    #include <cli/gui/errdlg.h>
#endif

#endif /* CLI_ICLIGUI_H */
