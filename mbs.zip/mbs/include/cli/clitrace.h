#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLITRACE_H
#define CLI_CLITRACE_H

/*
#ifndef CLI_CLITRACE_H
    #include <cli/clitrace.h>
#endif
*/

#if defined(_DEBUG) || defined(DEBUG)

    #include <cli/formatx.h>
    #define CLITRACE(str)                  ::cli::format::cli_log::message( str )
    #define CLITRACE1(str,a1)              ::cli::format::cli_log::message( str, cli::format::arg(a1) )
    #define CLITRACE2(str,a1,a2)           ::cli::format::cli_log::message( str, cli::format::arg(a1) % (a2) )
    #define CLITRACE3(str,a1,a2,a3)        ::cli::format::cli_log::message( str, cli::format::arg(a1) % (a2) % (a3) )
    #define CLITRACE4(str,a1,a2,a3,a4)     ::cli::format::cli_log::message( str, cli::format::arg(a1) % (a2) % (a3) % (a4) )
    #define CLITRACE5(str,a1,a2,a3,a4,a5)  ::cli::format::cli_log::message( str, cli::format::arg(a1) % (a2) % (a3) % (a4) % (a5) )

#else

    #define CLITRACE(str)                  
    #define CLITRACE1(str,a1)              
    #define CLITRACE2(str,a1,a2)           
    #define CLITRACE3(str,a1,a2,a3)        
    #define CLITRACE4(str,a1,a2,a3,a4)     
    #define CLITRACE5(str,a1,a2,a3,a4,a5)  

#endif

#endif /* CLI_CLITRACE_H */

