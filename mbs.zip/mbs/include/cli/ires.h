#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IRES_H
#define CLI_IRES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/ires.h>", CLI_IRES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IRES_H
    #include <cli/ires.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_ITAG_H
    #include <cli/itag.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_IOBJLIST_H
    #include <cli/iobjlist.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::ERcManFindFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_ERCMANFINDFLAGS            DWORD
#else
    #define ENUM_CLI_ERCMANFINDFLAGS            DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDSTRINGDEFAULT
    #define CLI_ERCMANFINDFLAGS_RCFINDSTRINGDEFAULT           CONSTANT_DWORD(0x00000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDSTRINGDEFAULT */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDMESSAGEDEFAULT
    #define CLI_ERCMANFINDFLAGS_RCFINDMESSAGEDEFAULT          CONSTANT_DWORD(0x00000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDMESSAGEDEFAULT */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE
    #define CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE        CONSTANT_DWORD(0x01000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMMODULE */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDMESSAGEFROMMODULE
    #define CLI_ERCMANFINDFLAGS_RCFINDMESSAGEFROMMODULE       CONSTANT_DWORD(0x01000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDMESSAGEFROMMODULE */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMAPP
    #define CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMAPP           CONSTANT_DWORD(0x02000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDSTRINGFROMAPP */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDMESSAGEFROMAPP
    #define CLI_ERCMANFINDFLAGS_RCFINDMESSAGEFROMAPP          CONSTANT_DWORD(0x02000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDMESSAGEFROMAPP */

#ifndef CLI_ERCMANFINDFLAGS_RCUSESYSTEMLOCALE
    #define CLI_ERCMANFINDFLAGS_RCUSESYSTEMLOCALE             CONSTANT_DWORD(0x04000000)
#endif /* CLI_ERCMANFINDFLAGS_RCUSESYSTEMLOCALE */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDSTRINGUSESYSTEMLOCALE
    #define CLI_ERCMANFINDFLAGS_RCFINDSTRINGUSESYSTEMLOCALE   CONSTANT_DWORD(0x04000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDSTRINGUSESYSTEMLOCALE */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDMESSAGEUSESYSTEMLOCALE
    #define CLI_ERCMANFINDFLAGS_RCFINDMESSAGEUSESYSTEMLOCALE  CONSTANT_DWORD(0x04000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDMESSAGEUSESYSTEMLOCALE */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDFLAGUSESYSTEMLOCALE
    #define CLI_ERCMANFINDFLAGS_RCFINDFLAGUSESYSTEMLOCALE     CONSTANT_DWORD(0x04000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDFLAGUSESYSTEMLOCALE */

#ifndef CLI_ERCMANFINDFLAGS_RCUSEAPPCONFIG
    #define CLI_ERCMANFINDFLAGS_RCUSEAPPCONFIG                CONSTANT_DWORD(0x08000000)
#endif /* CLI_ERCMANFINDFLAGS_RCUSEAPPCONFIG */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDSTRINGUSEAPPCONFIG
    #define CLI_ERCMANFINDFLAGS_RCFINDSTRINGUSEAPPCONFIG      CONSTANT_DWORD(0x08000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDSTRINGUSEAPPCONFIG */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDMESSAGEUSEAPPCONFIG
    #define CLI_ERCMANFINDFLAGS_RCFINDMESSAGEUSEAPPCONFIG     CONSTANT_DWORD(0x08000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDMESSAGEUSEAPPCONFIG */

#ifndef CLI_ERCMANFINDFLAGS_RCSTRINGFLAGSMASK
    #define CLI_ERCMANFINDFLAGS_RCSTRINGFLAGSMASK             CONSTANT_DWORD(0xFF000000)
#endif /* CLI_ERCMANFINDFLAGS_RCSTRINGFLAGSMASK */

#ifndef CLI_ERCMANFINDFLAGS_RCMESSAGEFLAGSMASK
    #define CLI_ERCMANFINDFLAGS_RCMESSAGEFLAGSMASK            CONSTANT_DWORD(0xFF000000)
#endif /* CLI_ERCMANFINDFLAGS_RCMESSAGEFLAGSMASK */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDPREFFERFILES
    #define CLI_ERCMANFINDFLAGS_RCFINDPREFFERFILES            CONSTANT_DWORD(0x00000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDPREFFERFILES */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDPREFFERBUILTIN
    #define CLI_ERCMANFINDFLAGS_RCFINDPREFFERBUILTIN          CONSTANT_DWORD(0x00010000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDPREFFERBUILTIN */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDIGNOREFILES
    #define CLI_ERCMANFINDFLAGS_RCFINDIGNOREFILES             CONSTANT_DWORD(0x00020000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDIGNOREFILES */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTIN
    #define CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTIN           CONSTANT_DWORD(0x00040000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTIN */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDPATHFLAGSMASK
    #define CLI_ERCMANFINDFLAGS_RCFINDPATHFLAGSMASK           CONSTANT_DWORD(0x00700000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDPATHFLAGSMASK */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTINPATHS
    #define CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTINPATHS      CONSTANT_DWORD(0x00100000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDIGNOREBUILTINPATHS */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDPREFFERBUILTINPATHS
    #define CLI_ERCMANFINDFLAGS_RCFINDPREFFERBUILTINPATHS     CONSTANT_DWORD(0x00000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDPREFFERBUILTINPATHS */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDPREFFERUSERPATHS
    #define CLI_ERCMANFINDFLAGS_RCFINDPREFFERUSERPATHS        CONSTANT_DWORD(0x00200000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDPREFFERUSERPATHS */

#ifndef CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS
    #define CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS              CONSTANT_DWORD(0x00800000)
#endif /* CLI_ERCMANFINDFLAGS_RCIGNOREDEFFLAGS */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDDISABLERESOURCELOOKUP
    #define CLI_ERCMANFINDFLAGS_RCFINDDISABLERESOURCELOOKUP   CONSTANT_DWORD(0x01000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDDISABLERESOURCELOOKUP */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDCONFIGFILESONLY
    #define CLI_ERCMANFINDFLAGS_RCFINDCONFIGFILESONLY         CONSTANT_DWORD(0x01000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDCONFIGFILESONLY */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDDISABLECONFIGLOOKUP
    #define CLI_ERCMANFINDFLAGS_RCFINDDISABLECONFIGLOOKUP     CONSTANT_DWORD(0x02000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDDISABLECONFIGLOOKUP */

#ifndef CLI_ERCMANFINDFLAGS_RCFINDRESOURCEFILESONLY
    #define CLI_ERCMANFINDFLAGS_RCFINDRESOURCEFILESONLY       CONSTANT_DWORD(0x02000000)
#endif /* CLI_ERCMANFINDFLAGS_RCFINDRESOURCEFILESONLY */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace ERcManFindFlags {
                const DWORD rcFindStringDefault      = CONSTANT_DWORD(0x00000000);
                const DWORD rcFindMessageDefault     = CONSTANT_DWORD(0x00000000);
                const DWORD rcFindStringFromModule   = CONSTANT_DWORD(0x01000000);
                const DWORD rcFindMessageFromModule  = CONSTANT_DWORD(0x01000000);
                const DWORD rcFindStringFromApp      = CONSTANT_DWORD(0x02000000);
                const DWORD rcFindMessageFromApp     = CONSTANT_DWORD(0x02000000);
                const DWORD rcUseSystemLocale        = CONSTANT_DWORD(0x04000000);
                const DWORD rcFindStringUseSystemLocale      = CONSTANT_DWORD(0x04000000);
                const DWORD rcFindMessageUseSystemLocale     = CONSTANT_DWORD(0x04000000);
                const DWORD rcFindFlagUseSystemLocale        = CONSTANT_DWORD(0x04000000);
                const DWORD rcUseAppConfig   = CONSTANT_DWORD(0x08000000);
                const DWORD rcFindStringUseAppConfig = CONSTANT_DWORD(0x08000000);
                const DWORD rcFindMessageUseAppConfig        = CONSTANT_DWORD(0x08000000);
                const DWORD rcStringFlagsMask        = CONSTANT_DWORD(0xFF000000);
                const DWORD rcMessageFlagsMask       = CONSTANT_DWORD(0xFF000000);
                const DWORD rcFindPrefferFiles       = CONSTANT_DWORD(0x00000000);
                const DWORD rcFindPrefferBuiltin     = CONSTANT_DWORD(0x00010000);
                const DWORD rcFindIgnoreFiles        = CONSTANT_DWORD(0x00020000);
                const DWORD rcFindIgnoreBuiltin      = CONSTANT_DWORD(0x00040000);
                const DWORD rcFindPathFlagsMask      = CONSTANT_DWORD(0x00700000);
                const DWORD rcFindIgnoreBuiltinPaths = CONSTANT_DWORD(0x00100000);
                const DWORD rcFindPrefferBuiltinPaths        = CONSTANT_DWORD(0x00000000);
                const DWORD rcFindPrefferUserPaths   = CONSTANT_DWORD(0x00200000);
                const DWORD rcIgnoreDefFlags = CONSTANT_DWORD(0x00800000);
                const DWORD rcFindDisableResourceLookup      = CONSTANT_DWORD(0x01000000);
                const DWORD rcFindConfigFilesOnly    = CONSTANT_DWORD(0x01000000);
                const DWORD rcFindDisableConfigLookup        = CONSTANT_DWORD(0x02000000);
                const DWORD rcFindResourceFilesOnly  = CONSTANT_DWORD(0x02000000);
        }; // namespace ERcManFindFlags
    }; // namespace cli
    /* using namespace ::cli::ERcManFindFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::ERcManRegisterFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_ERCMANREGISTERFLAGS        DWORD
#else
    #define ENUM_CLI_ERCMANREGISTERFLAGS        DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_ERCMANREGISTERFLAGS_RCREGDEFAULT
    #define CLI_ERCMANREGISTERFLAGS_RCREGDEFAULT              CONSTANT_DWORD(0x0000)
#endif /* CLI_ERCMANREGISTERFLAGS_RCREGDEFAULT */

#ifndef CLI_ERCMANREGISTERFLAGS_RCREGCOPY
    #define CLI_ERCMANREGISTERFLAGS_RCREGCOPY                 CONSTANT_DWORD(0x0001)
#endif /* CLI_ERCMANREGISTERFLAGS_RCREGCOPY */

#ifndef CLI_ERCMANREGISTERFLAGS_RCTYPERESOURCE
    #define CLI_ERCMANREGISTERFLAGS_RCTYPERESOURCE            CONSTANT_DWORD(0x0000)
#endif /* CLI_ERCMANREGISTERFLAGS_RCTYPERESOURCE */

#ifndef CLI_ERCMANREGISTERFLAGS_RCTYPECONF
    #define CLI_ERCMANREGISTERFLAGS_RCTYPECONF                CONSTANT_DWORD(0x0010)
#endif /* CLI_ERCMANREGISTERFLAGS_RCTYPECONF */

#ifndef CLI_ERCMANREGISTERFLAGS_RCTYPEANY
    #define CLI_ERCMANREGISTERFLAGS_RCTYPEANY                 CONSTANT_DWORD(0x00F0)
#endif /* CLI_ERCMANREGISTERFLAGS_RCTYPEANY */

#ifndef CLI_ERCMANREGISTERFLAGS_RCTYPEMASK
    #define CLI_ERCMANREGISTERFLAGS_RCTYPEMASK                CONSTANT_DWORD(0x00F0)
#endif /* CLI_ERCMANREGISTERFLAGS_RCTYPEMASK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace ERcManRegisterFlags {
                const DWORD rcRegDefault     = CONSTANT_DWORD(0x0000);
                const DWORD rcRegCopy        = CONSTANT_DWORD(0x0001);
                const DWORD rcTypeResource   = CONSTANT_DWORD(0x0000);
                const DWORD rcTypeConf       = CONSTANT_DWORD(0x0010);
                const DWORD rcTypeAny        = CONSTANT_DWORD(0x00F0);
                const DWORD rcTypeMask       = CONSTANT_DWORD(0x00F0);
        }; // namespace ERcManRegisterFlags
    }; // namespace cli
    /* using namespace ::cli::ERcManRegisterFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Interface: ::cli::iLocaleEnumerator */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ILOCALEENUMERATOR_IID
    #define INTERFACE_CLI_ILOCALEENUMERATOR_IID    "/cli/iLocaleEnumerator"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iLocaleEnumerator
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ILOCALEENUMERATOR
       #define INTERFACE_CLI_ILOCALEENUMERATOR    ::cli::iLocaleEnumerator
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iLocaleEnumerator
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ILOCALEENUMERATOR
       #define INTERFACE_CLI_ILOCALEENUMERATOR    cli_iLocaleEnumerator
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iLocaleEnumerator methods */
            CLIMETHOD(onLocaleEnumerate) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                              , const WCHAR*    langAndLocaleName /* [in,flat] wchar  langAndLocaleName[]  */
                                         ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iLocaleEnumerator >
           {
            static char const * getName() { return INTERFACE_CLI_ILOCALEENUMERATOR_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iLocaleEnumerator* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iLocaleEnumerator > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iLocaleEnumerator wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ILOCALEENUMERATOR >
                                      */
                 >
        class CiLocaleEnumeratorWrapper
        {
            public:
        
                typedef  CiLocaleEnumeratorWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiLocaleEnumeratorWrapper() :
                   pif(0) {}
        
                CiLocaleEnumeratorWrapper( iLocaleEnumerator *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiLocaleEnumeratorWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiLocaleEnumeratorWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiLocaleEnumeratorWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiLocaleEnumeratorWrapper(const CiLocaleEnumeratorWrapper &i) :
                    pif(i.pif) { }
        
                ~CiLocaleEnumeratorWrapper()  { }
        
                CiLocaleEnumeratorWrapper& operator=(const CiLocaleEnumeratorWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE onLocaleEnumerate( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                       , const WCHAR*    langAndLocaleName /* [in,flat] wchar  langAndLocaleName[]  */
                                       )
                   {
                
                
                    return pif->onLocaleEnumerate(langAndLocale, langAndLocaleName);
                   }
                

        
        
        }; // class CiLocaleEnumeratorWrapper
        
        typedef CiLocaleEnumeratorWrapper< ::cli::CCliPtr< INTERFACE_CLI_ILOCALEENUMERATOR     > >  CiLocaleEnumerator;
        typedef CiLocaleEnumeratorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ILOCALEENUMERATOR > >  CiLocaleEnumerator_nrc; /* No ref counting for interface used */
        typedef CiLocaleEnumeratorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ILOCALEENUMERATOR > >  CiLocaleEnumerator_tmp; /* for temporary usage, same as CiLocaleEnumerator_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iResourceManager */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iArgList;
        #ifndef INTERFACE_CLI_IARGLIST
            #define INTERFACE_CLI_IARGLIST            ::cli::iArgList
        #endif

        interface                                iLocaleEnumerator;
        #ifndef INTERFACE_CLI_ILOCALEENUMERATOR
            #define INTERFACE_CLI_ILOCALEENUMERATOR   ::cli::iLocaleEnumerator
        #endif

        interface                                iObjectList;
        #ifndef INTERFACE_CLI_IOBJECTLIST
            #define INTERFACE_CLI_IOBJECTLIST         ::cli::iObjectList
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IARGLIST_PREDECLARED
    #define INTERFACE_CLI_IARGLIST_PREDECLARED
    typedef interface tag_cli_iArgList       cli_iArgList;
    #endif //INTERFACE_CLI_IARGLIST
    #ifndef INTERFACE_CLI_IARGLIST
        #define INTERFACE_CLI_IARGLIST            struct tag_cli_iArgList
    #endif

    #ifndef INTERFACE_CLI_ILOCALEENUMERATOR_PREDECLARED
    #define INTERFACE_CLI_ILOCALEENUMERATOR_PREDECLARED
    typedef interface tag_cli_iLocaleEnumerator                  cli_iLocaleEnumerator;
    #endif //INTERFACE_CLI_ILOCALEENUMERATOR
    #ifndef INTERFACE_CLI_ILOCALEENUMERATOR
        #define INTERFACE_CLI_ILOCALEENUMERATOR   struct tag_cli_iLocaleEnumerator
    #endif

    #ifndef INTERFACE_CLI_IOBJECTLIST_PREDECLARED
    #define INTERFACE_CLI_IOBJECTLIST_PREDECLARED
    typedef interface tag_cli_iObjectList    cli_iObjectList;
    #endif //INTERFACE_CLI_IOBJECTLIST
    #ifndef INTERFACE_CLI_IOBJECTLIST
        #define INTERFACE_CLI_IOBJECTLIST         struct tag_cli_iObjectList
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IRESOURCEMANAGER_IID
    #define INTERFACE_CLI_IRESOURCEMANAGER_IID    "/cli/iResourceManager"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iResourceManager
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IRESOURCEMANAGER
       #define INTERFACE_CLI_IRESOURCEMANAGER    ::cli::iResourceManager
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iResourceManager
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IRESOURCEMANAGER
       #define INTERFACE_CLI_IRESOURCEMANAGER    cli_iResourceManager
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iResourceManager methods */
            CLIMETHOD(defFindFlagsGet) (THIS_ ENUM_CLI_ERCMANFINDFLAGS*    _defFindFlags /* [out] ::cli::ERcManFindFlags _defFindFlags  */) PURE;
            CLIMETHOD(defFindFlagsSet) (THIS_ ENUM_CLI_ERCMANFINDFLAGS    _defFindFlags /* [in] ::cli::ERcManFindFlags  _defFindFlags  */) PURE;
            CLIMETHOD(searchPathsGet) (THIS_ CLISTR*           _searchPaths
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      ) PURE;
            CLIMETHOD(searchPathsSet) (THIS_ const CLISTR*     _searchPaths
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      ) PURE;
            CLIMETHOD(searchPathsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(defRcRootPathGet) (THIS_ CLISTR*           _defRcRootPath) PURE;
            CLIMETHOD(clearSearchPaths) (THIS) PURE;
            CLIMETHOD(addSearchPath) (THIS_ const CLISTR*     p) PURE;
            CLIMETHOD(addSearchPathChars) (THIS_ const WCHAR*    p /* [in,flat] wchar  p[]  */) PURE;
            CLIMETHOD(exportBuiltinResources) (THIS_ const CLISTR*     rootPath
                                                   , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                              ) PURE;
            CLIMETHOD(exportBuiltinResourcesChars) (THIS_ const WCHAR*    rootPath /* [in,flat] wchar  rootPath[]  */
                                                        , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                                   ) PURE;
            CLIMETHOD(getDefaultResourcesPath) (THIS_ CLISTR*           defPath
                                                    , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                               ) PURE;
            CLIMETHOD(getDefaultResourcesPathChars) (THIS_ WCHAR*    defPathBuf /* [out,flat,optional] wchar defPathBuf[]  */
                                                         , SIZE_T*    defPathBufSize /* [in,out] size_t defPathBufSize  */
                                                         , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                                    ) PURE;
            CLIMETHOD(logEnumBuiltinResources) (THIS) PURE;
            CLIMETHOD(findResourceFilesToList) (THIS_ const CLISTR*     langAndLocale
                                                    , const CLISTR*     fileName
                                                    , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                    , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                               ) PURE;
            CLIMETHOD(findResourceFilesToListChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                         , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                         , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                         , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                    ) PURE;
            CLIMETHOD(findResourceFiles) (THIS_ const CLISTR*     langAndLocale
                                              , const CLISTR*     fileName
                                              , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                              , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                         ) PURE;
            CLIMETHOD(findResourceFilesChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                   , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                   , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                                   , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                              ) PURE;
            CLIMETHOD(findBuiltinResourcesToList) (THIS_ const CLISTR*     langAndLocale
                                                       , const CLISTR*     fileName
                                                       , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                       , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                  ) PURE;
            CLIMETHOD(findBuiltinResourcesToListChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                            , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                            , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                            , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                       ) PURE;
            CLIMETHOD(findBuiltinResources) (THIS_ const CLISTR*     langAndLocale
                                                 , const CLISTR*     fileName
                                                 , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                                 , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                            ) PURE;
            CLIMETHOD(findBuiltinResourcesChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                      , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                      , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                                      , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                 ) PURE;
            CLIMETHOD(findResourcesToList) (THIS_ const CLISTR*     langAndLocale
                                                , const CLISTR*     fileName
                                                , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                           ) PURE;
            CLIMETHOD(findResourcesToListChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                     , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                     , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                     , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                ) PURE;
            CLIMETHOD(findResources) (THIS_ const CLISTR*     langAndLocale
                                          , const CLISTR*     fileName
                                          , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                          , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                     ) PURE;
            CLIMETHOD(findResourcesChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                               , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                               , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                               , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                          ) PURE;
            CLIMETHOD(registerResource) (THIS_ const CLISTR*     langAndLocale
                                             , const CLISTR*     fileName
                                             , const BYTE*    pRcData /* [in] byte*  pRcData  */
                                             , SIZE_T    rcLen /* [in] size_t  rcLen  */
                                             , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                        ) PURE;
            CLIMETHOD(registerResourceChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                  , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                  , const BYTE*    pRcData /* [in] byte*  pRcData  */
                                                  , SIZE_T    rcLen /* [in] size_t  rcLen  */
                                                  , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                             ) PURE;
            CLIMETHOD(unregisterResource) (THIS_ const CLISTR*     langAndLocale
                                               , const CLISTR*     fileName
                                          ) PURE;
            CLIMETHOD(unregisterResourceChars) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                    , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                               ) PURE;
            CLIMETHOD(getCurrentLocaleName) (THIS_ CLISTR*           langAndLocale
                                                 , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                            ) PURE;
            CLIMETHOD(getRealLocaleName) (THIS_ const CLISTR*     langAndLocaleOrAlias
                                              , CLISTR*           langAndLocale
                                              , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                         ) PURE;
            CLIMETHOD(getLocaleSearchOrderList) (THIS_ const CLISTR*     langAndLocaleOrAlias
                                                     , INTERFACE_CLI_IARGLIST*    pLocalesList /* [in] ::cli::iArgList*  pLocalesList  */
                                                     , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                ) PURE;
            CLIMETHOD(clearAllStringCache) (THIS) PURE;
            CLIMETHOD(clearStringCache) (THIS_ const CLISTR*     strTypeString) PURE;
            CLIMETHOD(findGenericString) (THIS_ CLISTR*           foundStr
                                              , const CLISTR*     strId
                                              , const CLISTR*     langAndLocale
                                              , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                              , const CLISTR*     moduleName
                                              , const CLISTR*     strTypeString
                                         ) PURE;
            CLIMETHOD(findStringEx) (THIS_ CLISTR*           foundStr
                                         , const CLISTR*     strId
                                         , const CLISTR*     langAndLocale
                                         , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                         , const CLISTR*     moduleName
                                    ) PURE;
            CLIMETHOD(findString) (THIS_ CLISTR*           foundStr
                                       , const CLISTR*     strId
                                       , const CLISTR*     langAndLocale
                                       , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                  ) PURE;
            CLIMETHOD(findMessageEx) (THIS_ CLISTR*           foundStr
                                          , RCODE    code /* [in] rcode  code  */
                                          , const CLISTR*     langAndLocale
                                          , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                          , const CLISTR*     moduleName
                                     ) PURE;
            CLIMETHOD(findMessage) (THIS_ CLISTR*           foundStr
                                        , RCODE    code /* [in] rcode  code  */
                                        , const CLISTR*     langAndLocale
                                        , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                   ) PURE;
            CLIMETHOD(setResourcesLocale) (THIS_ const CLISTR*     langAndLocale) PURE;
            CLIMETHOD(setResourcesLocaleStr) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */) PURE;
            CLIMETHOD(getResourcesLocale) (THIS_ CLISTR*           langAndLocale) PURE;
            CLIMETHOD(enumLocales) (THIS_ INTERFACE_CLI_ILOCALEENUMERATOR*    pEnumerator /* [in] ::cli::iLocaleEnumerator*  pEnumerator  */
                                        , const CLISTR*     langAndLocale
                                        , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                        , const CLISTR*     fileName
                                   ) PURE;
            CLIMETHOD(enumGenericStringLocales) (THIS_ INTERFACE_CLI_ILOCALEENUMERATOR*    pEnumerator /* [in] ::cli::iLocaleEnumerator*  pEnumerator  */
                                                     , const CLISTR*     langAndLocale
                                                     , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                     , const CLISTR*     moduleName
                                                     , const CLISTR*     strTypeString
                                                ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iResourceManager >
           {
            static char const * getName() { return INTERFACE_CLI_IRESOURCEMANAGER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iResourceManager* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iResourceManager > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iResourceManager wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IRESOURCEMANAGER >
                                      */
                 >
        class CiResourceManagerWrapper
        {
            public:
        
                typedef  CiResourceManagerWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiResourceManagerWrapper() :
                   pif(0) {}
        
                CiResourceManagerWrapper( iResourceManager *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiResourceManagerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiResourceManagerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiResourceManagerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiResourceManagerWrapper(const CiResourceManagerWrapper &i) :
                    pif(i.pif) { }
        
                ~CiResourceManagerWrapper()  { }
        
                CiResourceManagerWrapper& operator=(const CiResourceManagerWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ENUM_CLI_ERCMANFINDFLAGS get_defFindFlags( )
                   {
                    ENUM_CLI_ERCMANFINDFLAGS tmpVal;
                    RCODE res = defFindFlagsGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_defFindFlags( ENUM_CLI_ERCMANFINDFLAGS _defFindFlags
                                     )
                   {
                    RCODE res = defFindFlagsSet( _defFindFlags );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_ERCMANFINDFLAGS, defFindFlags );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE defFindFlagsGet( ENUM_CLI_ERCMANFINDFLAGS*    _defFindFlags /* [out] ::cli::ERcManFindFlags _defFindFlags  */)
                   {
                
                    return pif->defFindFlagsGet(_defFindFlags);
                   }
                
                RCODE defFindFlagsSet( ENUM_CLI_ERCMANFINDFLAGS    _defFindFlags /* [in] ::cli::ERcManFindFlags  _defFindFlags  */)
                   {
                
                    return pif->defFindFlagsSet(_defFindFlags);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_searchPaths( SIZE_T idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = searchPathsGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_searchPaths( SIZE_T idx1 , const ::std::wstring &_searchPaths
                                    )
                   { // MS style - index goes before value, need reorder
                    RCODE res = searchPathsSet( _searchPaths, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_searchPaths(  )
                   {
                    SIZE_T size;
                    RCODE res = searchPathsSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, searchPaths, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE searchPathsGet( ::std::wstring    &_searchPaths
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    )
                   {
                    CCliStr tmp__searchPaths; CCliStr_init( tmp__searchPaths );
                
                    RCODE res = pif->searchPathsGet(&tmp__searchPaths, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _searchPaths, tmp__searchPaths);
                       }
                    return res;
                   }
                
                RCODE searchPathsSet( const ::std::wstring    &_searchPaths
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    )
                   {
                    CCliStr tmp__searchPaths; CCliStr_lightCopyTo( tmp__searchPaths, _searchPaths);
                
                    return pif->searchPathsSet(&tmp__searchPaths, idx1);
                   }
                
                RCODE searchPathsSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->searchPathsSize(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_defRcRootPath( )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = defRcRootPathGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R(wrapper_type, ::std::wstring, defRcRootPath );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE defRcRootPathGet( ::std::wstring    &_defRcRootPath)
                   {
                    CCliStr tmp__defRcRootPath; CCliStr_init( tmp__defRcRootPath );
                    RCODE res = pif->defRcRootPathGet(&tmp__defRcRootPath);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _defRcRootPath, tmp__defRcRootPath);
                       }
                    return res;
                   }
                
                RCODE clearSearchPaths( )
                   {
                    return pif->clearSearchPaths();
                   }
                
                RCODE addSearchPath( const ::std::wstring    &p)
                   {
                    CCliStr tmp_p; CCliStr_lightCopyTo( tmp_p, p);
                    return pif->addSearchPath(&tmp_p);
                   }
                
                RCODE addSearchPathChars( const WCHAR*    p /* [in,flat] wchar  p[]  */)
                   {
                
                    return pif->addSearchPathChars(p);
                   }
                
                RCODE exportBuiltinResources( const ::std::wstring    &rootPath
                                            , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                            )
                   {
                    CCliStr tmp_rootPath; CCliStr_lightCopyTo( tmp_rootPath, rootPath);
                
                    return pif->exportBuiltinResources(&tmp_rootPath, flags);
                   }
                
                RCODE exportBuiltinResourcesChars( const WCHAR*    rootPath /* [in,flat] wchar  rootPath[]  */
                                                 , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                                 )
                   {
                
                
                    return pif->exportBuiltinResourcesChars(rootPath, flags);
                   }
                
                RCODE getDefaultResourcesPath( ::std::wstring    &defPath
                                             , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                             )
                   {
                    CCliStr tmp_defPath; CCliStr_init( tmp_defPath );
                
                    RCODE res = pif->getDefaultResourcesPath(&tmp_defPath, flags);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( defPath, tmp_defPath);
                       }
                    return res;
                   }
                
                RCODE getDefaultResourcesPathChars( WCHAR*    defPathBuf /* [out,flat,optional] wchar defPathBuf[]  */
                                                  , SIZE_T*    defPathBufSize /* [in,out] size_t defPathBufSize  */
                                                  , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                                  )
                   {
                
                
                
                    return pif->getDefaultResourcesPathChars(defPathBuf, defPathBufSize, flags);
                   }
                
                RCODE logEnumBuiltinResources( )
                   {
                    return pif->logEnumBuiltinResources();
                   }
                
                RCODE findResourceFilesToList( const ::std::wstring    &langAndLocale
                                             , const ::std::wstring    &fileName
                                             , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                             , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                             )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                
                
                    return pif->findResourceFilesToList(&tmp_langAndLocale, &tmp_fileName, pStreamList, flags);
                   }
                
                RCODE findResourceFilesToListChars( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                  , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                  , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                  , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                  )
                   {
                
                
                
                
                    return pif->findResourceFilesToListChars(langAndLocale, fileName, pStreamList, flags);
                   }
                
                RCODE findResourceFiles( const ::std::wstring    &langAndLocale
                                       , const ::std::wstring    &fileName
                                       , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                       , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                       )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                
                
                    return pif->findResourceFiles(&tmp_langAndLocale, &tmp_fileName, pStreamList, flags);
                   }
                
                RCODE findResourceFilesChars( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                            , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                            , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                            , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                            )
                   {
                
                
                
                
                    return pif->findResourceFilesChars(langAndLocale, fileName, pStreamList, flags);
                   }
                
                RCODE findBuiltinResourcesToList( const ::std::wstring    &langAndLocale
                                                , const ::std::wstring    &fileName
                                                , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                
                
                    return pif->findBuiltinResourcesToList(&tmp_langAndLocale, &tmp_fileName, pStreamList, flags);
                   }
                
                RCODE findBuiltinResourcesToListChars( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                                     , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                                     , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                                     , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                                     )
                   {
                
                
                
                
                    return pif->findBuiltinResourcesToListChars(langAndLocale, fileName, pStreamList, flags);
                   }
                
                RCODE findBuiltinResources( const ::std::wstring    &langAndLocale
                                          , const ::std::wstring    &fileName
                                          , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                          , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                          )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                
                
                    return pif->findBuiltinResources(&tmp_langAndLocale, &tmp_fileName, pStreamList, flags);
                   }
                
                RCODE findBuiltinResourcesChars( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                               , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                               , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                               , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                               )
                   {
                
                
                
                
                    return pif->findBuiltinResourcesChars(langAndLocale, fileName, pStreamList, flags);
                   }
                
                RCODE findResourcesToList( const ::std::wstring    &langAndLocale
                                         , const ::std::wstring    &fileName
                                         , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                         , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                         )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                
                
                    return pif->findResourcesToList(&tmp_langAndLocale, &tmp_fileName, pStreamList, flags);
                   }
                
                RCODE findResourcesToListChars( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                              , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                              , INTERFACE_CLI_IOBJECTLIST*    pStreamList /* [in] ::cli::iObjectList*  pStreamList  */
                                              , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                              )
                   {
                
                
                
                
                    return pif->findResourcesToListChars(langAndLocale, fileName, pStreamList, flags);
                   }
                
                RCODE findResources( const ::std::wstring    &langAndLocale
                                   , const ::std::wstring    &fileName
                                   , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                   , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                   )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                
                
                    return pif->findResources(&tmp_langAndLocale, &tmp_fileName, pStreamList, flags);
                   }
                
                RCODE findResourcesChars( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                        , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                        , INTERFACE_CLI_IOBJECTLIST**    pStreamList /* [out] ::cli::iObjectList* pStreamList  */
                                        , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                        )
                   {
                
                
                
                
                    return pif->findResourcesChars(langAndLocale, fileName, pStreamList, flags);
                   }
                
                RCODE registerResource( const ::std::wstring    &langAndLocale
                                      , const ::std::wstring    &fileName
                                      , const BYTE*    pRcData /* [in] byte*  pRcData  */
                                      , SIZE_T    rcLen /* [in] size_t  rcLen  */
                                      , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                      )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                
                
                
                    return pif->registerResource(&tmp_langAndLocale, &tmp_fileName, pRcData, rcLen, flags);
                   }
                
                RCODE registerResourceChars( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                           , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                           , const BYTE*    pRcData /* [in] byte*  pRcData  */
                                           , SIZE_T    rcLen /* [in] size_t  rcLen  */
                                           , ENUM_CLI_ERCMANREGISTERFLAGS    flags /* [in] ::cli::ERcManRegisterFlags  flags  */
                                           )
                   {
                
                
                
                
                
                    return pif->registerResourceChars(langAndLocale, fileName, pRcData, rcLen, flags);
                   }
                
                RCODE unregisterResource( const ::std::wstring    &langAndLocale
                                        , const ::std::wstring    &fileName
                                        )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                    return pif->unregisterResource(&tmp_langAndLocale, &tmp_fileName);
                   }
                
                RCODE unregisterResourceChars( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                             , const WCHAR*    fileName /* [in,flat] wchar  fileName[]  */
                                             )
                   {
                
                
                    return pif->unregisterResourceChars(langAndLocale, fileName);
                   }
                
                RCODE getCurrentLocaleName( ::std::wstring    &langAndLocale
                                          , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                          )
                   {
                    CCliStr tmp_langAndLocale; CCliStr_init( tmp_langAndLocale );
                
                    RCODE res = pif->getCurrentLocaleName(&tmp_langAndLocale, flags);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( langAndLocale, tmp_langAndLocale);
                       }
                    return res;
                   }
                
                RCODE getRealLocaleName( const ::std::wstring    &langAndLocaleOrAlias
                                       , ::std::wstring    &langAndLocale
                                       , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                       )
                   {
                    CCliStr tmp_langAndLocaleOrAlias; CCliStr_lightCopyTo( tmp_langAndLocaleOrAlias, langAndLocaleOrAlias);
                    CCliStr tmp_langAndLocale; CCliStr_init( tmp_langAndLocale );
                
                    RCODE res = pif->getRealLocaleName(&tmp_langAndLocaleOrAlias, &tmp_langAndLocale, flags);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( langAndLocale, tmp_langAndLocale);
                       }
                    return res;
                   }
                
                RCODE getLocaleSearchOrderList( const ::std::wstring    &langAndLocaleOrAlias
                                              , INTERFACE_CLI_IARGLIST*    pLocalesList /* [in] ::cli::iArgList*  pLocalesList  */
                                              , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                              )
                   {
                    CCliStr tmp_langAndLocaleOrAlias; CCliStr_lightCopyTo( tmp_langAndLocaleOrAlias, langAndLocaleOrAlias);
                
                
                    return pif->getLocaleSearchOrderList(&tmp_langAndLocaleOrAlias, pLocalesList, flags);
                   }
                
                RCODE clearAllStringCache( )
                   {
                    return pif->clearAllStringCache();
                   }
                
                RCODE clearStringCache( const ::std::wstring    &strTypeString)
                   {
                    CCliStr tmp_strTypeString; CCliStr_lightCopyTo( tmp_strTypeString, strTypeString);
                    return pif->clearStringCache(&tmp_strTypeString);
                   }
                
                RCODE findGenericString( ::std::wstring    &foundStr
                                       , const ::std::wstring    &strId
                                       , const ::std::wstring    &langAndLocale
                                       , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                       , const ::std::wstring    &moduleName
                                       , const ::std::wstring    &strTypeString
                                       )
                   {
                    CCliStr tmp_foundStr; CCliStr_init( tmp_foundStr );
                    CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                
                    CCliStr tmp_moduleName; CCliStr_lightCopyTo( tmp_moduleName, moduleName);
                    CCliStr tmp_strTypeString; CCliStr_lightCopyTo( tmp_strTypeString, strTypeString);
                    RCODE res = pif->findGenericString(&tmp_foundStr, &tmp_strId, &tmp_langAndLocale, flags, &tmp_moduleName, &tmp_strTypeString);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( foundStr, tmp_foundStr);
                       }
                    return res;
                   }
                
                RCODE findStringEx( ::std::wstring    &foundStr
                                  , const ::std::wstring    &strId
                                  , const ::std::wstring    &langAndLocale
                                  , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                  , const ::std::wstring    &moduleName
                                  )
                   {
                    CCliStr tmp_foundStr; CCliStr_init( tmp_foundStr );
                    CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                
                    CCliStr tmp_moduleName; CCliStr_lightCopyTo( tmp_moduleName, moduleName);
                    RCODE res = pif->findStringEx(&tmp_foundStr, &tmp_strId, &tmp_langAndLocale, flags, &tmp_moduleName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( foundStr, tmp_foundStr);
                       }
                    return res;
                   }
                
                RCODE findString( ::std::wstring    &foundStr
                                , const ::std::wstring    &strId
                                , const ::std::wstring    &langAndLocale
                                , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                )
                   {
                    CCliStr tmp_foundStr; CCliStr_init( tmp_foundStr );
                    CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                
                    RCODE res = pif->findString(&tmp_foundStr, &tmp_strId, &tmp_langAndLocale, flags);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( foundStr, tmp_foundStr);
                       }
                    return res;
                   }
                
                RCODE findMessageEx( ::std::wstring    &foundStr
                                   , RCODE    code /* [in] rcode  code  */
                                   , const ::std::wstring    &langAndLocale
                                   , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                   , const ::std::wstring    &moduleName
                                   )
                   {
                    CCliStr tmp_foundStr; CCliStr_init( tmp_foundStr );
                
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                
                    CCliStr tmp_moduleName; CCliStr_lightCopyTo( tmp_moduleName, moduleName);
                    RCODE res = pif->findMessageEx(&tmp_foundStr, code, &tmp_langAndLocale, flags, &tmp_moduleName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( foundStr, tmp_foundStr);
                       }
                    return res;
                   }
                
                RCODE findMessage( ::std::wstring    &foundStr
                                 , RCODE    code /* [in] rcode  code  */
                                 , const ::std::wstring    &langAndLocale
                                 , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                 )
                   {
                    CCliStr tmp_foundStr; CCliStr_init( tmp_foundStr );
                
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                
                    RCODE res = pif->findMessage(&tmp_foundStr, code, &tmp_langAndLocale, flags);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( foundStr, tmp_foundStr);
                       }
                    return res;
                   }
                
                RCODE setResourcesLocale( const ::std::wstring    &langAndLocale)
                   {
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                    return pif->setResourcesLocale(&tmp_langAndLocale);
                   }
                
                RCODE setResourcesLocaleStr( const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */)
                   {
                
                    return pif->setResourcesLocaleStr(langAndLocale);
                   }
                
                RCODE getResourcesLocale( ::std::wstring    &langAndLocale)
                   {
                    CCliStr tmp_langAndLocale; CCliStr_init( tmp_langAndLocale );
                    RCODE res = pif->getResourcesLocale(&tmp_langAndLocale);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( langAndLocale, tmp_langAndLocale);
                       }
                    return res;
                   }
                
                RCODE enumLocales( INTERFACE_CLI_ILOCALEENUMERATOR*    pEnumerator /* [in] ::cli::iLocaleEnumerator*  pEnumerator  */
                                 , const ::std::wstring    &langAndLocale
                                 , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                 , const ::std::wstring    &fileName
                                 )
                   {
                
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                
                    CCliStr tmp_fileName; CCliStr_lightCopyTo( tmp_fileName, fileName);
                    return pif->enumLocales(pEnumerator, &tmp_langAndLocale, flags, &tmp_fileName);
                   }
                
                RCODE enumGenericStringLocales( INTERFACE_CLI_ILOCALEENUMERATOR*    pEnumerator /* [in] ::cli::iLocaleEnumerator*  pEnumerator  */
                                              , const ::std::wstring    &langAndLocale
                                              , ENUM_CLI_ERCMANFINDFLAGS    flags /* [in] ::cli::ERcManFindFlags  flags  */
                                              , const ::std::wstring    &moduleName
                                              , const ::std::wstring    &strTypeString
                                              )
                   {
                
                    CCliStr tmp_langAndLocale; CCliStr_lightCopyTo( tmp_langAndLocale, langAndLocale);
                
                    CCliStr tmp_moduleName; CCliStr_lightCopyTo( tmp_moduleName, moduleName);
                    CCliStr tmp_strTypeString; CCliStr_lightCopyTo( tmp_strTypeString, strTypeString);
                    return pif->enumGenericStringLocales(pEnumerator, &tmp_langAndLocale, flags, &tmp_moduleName, &tmp_strTypeString);
                   }
                

        
        
        }; // class CiResourceManagerWrapper
        
        typedef CiResourceManagerWrapper< ::cli::CCliPtr< INTERFACE_CLI_IRESOURCEMANAGER     > >  CiResourceManager;
        typedef CiResourceManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IRESOURCEMANAGER > >  CiResourceManager_nrc; /* No ref counting for interface used */
        typedef CiResourceManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IRESOURCEMANAGER > >  CiResourceManager_tmp; /* for temporary usage, same as CiResourceManager_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IRES_H */
