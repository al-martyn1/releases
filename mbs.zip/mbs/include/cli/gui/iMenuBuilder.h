#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_IMENUBUILDER_H
#define CLI_GUI_IMENUBUILDER_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/iMenuBuilder.h>", CLI_GUI_IMENUBUILDER_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_IMENUBUILDER_H
    #include <cli/gui/iMenuBuilder.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_GUI_VK_H
    #include <cli/gui/vk.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif

#ifndef CLI_GUI_ICOMMAND_H
    #include <cli/gui/iCommand.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::gui::EAccelFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_EACCELFLAGS            WORD
#else
    #define ENUM_CLI_GUI_EACCELFLAGS            WORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_EACCELFLAGS_FVIRTKEY
    #define CLI_GUI_EACCELFLAGS_FVIRTKEY      CONSTANT_WORD(0x01)
#endif /* CLI_GUI_EACCELFLAGS_FVIRTKEY */

#ifndef CLI_GUI_EACCELFLAGS_FINVERT
    #define CLI_GUI_EACCELFLAGS_FINVERT       CONSTANT_WORD(0x02)
#endif /* CLI_GUI_EACCELFLAGS_FINVERT */

#ifndef CLI_GUI_EACCELFLAGS_FSHIFT
    #define CLI_GUI_EACCELFLAGS_FSHIFT        CONSTANT_WORD(0x04)
#endif /* CLI_GUI_EACCELFLAGS_FSHIFT */

#ifndef CLI_GUI_EACCELFLAGS_FCONTROL
    #define CLI_GUI_EACCELFLAGS_FCONTROL      CONSTANT_WORD(0x08)
#endif /* CLI_GUI_EACCELFLAGS_FCONTROL */

#ifndef CLI_GUI_EACCELFLAGS_FALT
    #define CLI_GUI_EACCELFLAGS_FALT          CONSTANT_WORD(0x10)
#endif /* CLI_GUI_EACCELFLAGS_FALT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace EAccelFlags {
                    const WORD fVirtKey         = CONSTANT_WORD(0x01);
                    const WORD fInvert          = CONSTANT_WORD(0x02);
                    const WORD fShift           = CONSTANT_WORD(0x04);
                    const WORD fControl         = CONSTANT_WORD(0x08);
                    const WORD fAlt             = CONSTANT_WORD(0x10);
            }; // namespace EAccelFlags
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::EAccelFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::EMenuItemFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_EMENUITEMFLAGS         DWORD
#else
    #define ENUM_CLI_GUI_EMENUITEMFLAGS         DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_EMENUITEMFLAGS_FHIDDEN
    #define CLI_GUI_EMENUITEMFLAGS_FHIDDEN    CONSTANT_DWORD(0x00000001)
#endif /* CLI_GUI_EMENUITEMFLAGS_FHIDDEN */

#ifndef CLI_GUI_EMENUITEMFLAGS_FDISABLED
    #define CLI_GUI_EMENUITEMFLAGS_FDISABLED  CONSTANT_DWORD(0x00000002)
#endif /* CLI_GUI_EMENUITEMFLAGS_FDISABLED */

#ifndef CLI_GUI_EMENUITEMFLAGS_FHIDDENDISABLED
    #define CLI_GUI_EMENUITEMFLAGS_FHIDDENDISABLED            CONSTANT_DWORD(0x00000003)
#endif /* CLI_GUI_EMENUITEMFLAGS_FHIDDENDISABLED */

#ifndef CLI_GUI_EMENUITEMFLAGS_FCHECKED
    #define CLI_GUI_EMENUITEMFLAGS_FCHECKED   CONSTANT_DWORD(0x00000008)
#endif /* CLI_GUI_EMENUITEMFLAGS_FCHECKED */

#ifndef CLI_GUI_EMENUITEMFLAGS_FSTATEMASK
    #define CLI_GUI_EMENUITEMFLAGS_FSTATEMASK                 CONSTANT_DWORD(0x0000000B)
#endif /* CLI_GUI_EMENUITEMFLAGS_FSTATEMASK */

#ifndef CLI_GUI_EMENUITEMFLAGS_FRADIO
    #define CLI_GUI_EMENUITEMFLAGS_FRADIO     CONSTANT_DWORD(0x00010000)
#endif /* CLI_GUI_EMENUITEMFLAGS_FRADIO */

#ifndef CLI_GUI_EMENUITEMFLAGS_FSUBMENU
    #define CLI_GUI_EMENUITEMFLAGS_FSUBMENU   CONSTANT_DWORD(0x00020000)
#endif /* CLI_GUI_EMENUITEMFLAGS_FSUBMENU */

#ifndef CLI_GUI_EMENUITEMFLAGS_FMENUSEPARATOR
    #define CLI_GUI_EMENUITEMFLAGS_FMENUSEPARATOR             CONSTANT_DWORD(0x00040000)
#endif /* CLI_GUI_EMENUITEMFLAGS_FMENUSEPARATOR */

#ifndef CLI_GUI_EMENUITEMFLAGS_FMENUBREAK
    #define CLI_GUI_EMENUITEMFLAGS_FMENUBREAK                 CONSTANT_DWORD(0x00080000)
#endif /* CLI_GUI_EMENUITEMFLAGS_FMENUBREAK */

#ifndef CLI_GUI_EMENUITEMFLAGS_FMENUBARBREAK
    #define CLI_GUI_EMENUITEMFLAGS_FMENUBARBREAK              CONSTANT_DWORD(0x00100000)
#endif /* CLI_GUI_EMENUITEMFLAGS_FMENUBARBREAK */

#ifndef CLI_GUI_EMENUITEMFLAGS_FQUET
    #define CLI_GUI_EMENUITEMFLAGS_FQUET      CONSTANT_DWORD(0x00200000)
#endif /* CLI_GUI_EMENUITEMFLAGS_FQUET */

#ifndef CLI_GUI_EMENUITEMFLAGS_FFORCETRYRESOURCE
    #define CLI_GUI_EMENUITEMFLAGS_FFORCETRYRESOURCE          CONSTANT_DWORD(0x10000000)
#endif /* CLI_GUI_EMENUITEMFLAGS_FFORCETRYRESOURCE */

#ifndef CLI_GUI_EMENUITEMFLAGS_FPUBLICFLAGSMASK
    #define CLI_GUI_EMENUITEMFLAGS_FPUBLICFLAGSMASK           CONSTANT_DWORD(0x1000000C)
#endif /* CLI_GUI_EMENUITEMFLAGS_FPUBLICFLAGSMASK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace EMenuItemFlags {
                    const DWORD fHidden          = CONSTANT_DWORD(0x00000001);
                    const DWORD fDisabled        = CONSTANT_DWORD(0x00000002);
                    const DWORD fHiddenDisabled  = CONSTANT_DWORD(0x00000003);
                    const DWORD fChecked         = CONSTANT_DWORD(0x00000008);
                    const DWORD fStateMask       = CONSTANT_DWORD(0x0000000B);
                    const DWORD fRadio           = CONSTANT_DWORD(0x00010000);
                    const DWORD fSubMenu         = CONSTANT_DWORD(0x00020000);
                    const DWORD fMenuSeparator   = CONSTANT_DWORD(0x00040000);
                    const DWORD fMenuBreak       = CONSTANT_DWORD(0x00080000);
                    const DWORD fMenuBarBreak    = CONSTANT_DWORD(0x00100000);
                    const DWORD fQuet            = CONSTANT_DWORD(0x00200000);
                    const DWORD fForceTryResource        = CONSTANT_DWORD(0x10000000);
                    const DWORD fPublicFlagsMask = CONSTANT_DWORD(0x1000000C);
            }; // namespace EMenuItemFlags
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::EMenuItemFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::EMenuInsertPos */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_EMENUINSERTPOS         DWORD
#else
    #define ENUM_CLI_GUI_EMENUINSERTPOS         DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_EMENUINSERTPOS_ATEND
    #define CLI_GUI_EMENUINSERTPOS_ATEND      CONSTANT_DWORD(0)
#endif /* CLI_GUI_EMENUINSERTPOS_ATEND */

#ifndef CLI_GUI_EMENUINSERTPOS_ATBEGIN
    #define CLI_GUI_EMENUINSERTPOS_ATBEGIN    1
#endif /* CLI_GUI_EMENUINSERTPOS_ATBEGIN */

#ifndef CLI_GUI_EMENUINSERTPOS_BEFOREBREAK
    #define CLI_GUI_EMENUINSERTPOS_BEFOREBREAK                2
#endif /* CLI_GUI_EMENUINSERTPOS_BEFOREBREAK */

#ifndef CLI_GUI_EMENUINSERTPOS_AFTERBREAK
    #define CLI_GUI_EMENUINSERTPOS_AFTERBREAK                 3
#endif /* CLI_GUI_EMENUINSERTPOS_AFTERBREAK */

#ifndef CLI_GUI_EMENUINSERTPOS_BEFORECOMMAND
    #define CLI_GUI_EMENUINSERTPOS_BEFORECOMMAND              4
#endif /* CLI_GUI_EMENUINSERTPOS_BEFORECOMMAND */

#ifndef CLI_GUI_EMENUINSERTPOS_AFTERCOMMAND
    #define CLI_GUI_EMENUINSERTPOS_AFTERCOMMAND               5
#endif /* CLI_GUI_EMENUINSERTPOS_AFTERCOMMAND */

#ifndef CLI_GUI_EMENUINSERTPOS_FIRSTBEFORECOMMAND
    #define CLI_GUI_EMENUINSERTPOS_FIRSTBEFORECOMMAND         6
#endif /* CLI_GUI_EMENUINSERTPOS_FIRSTBEFORECOMMAND */

#ifndef CLI_GUI_EMENUINSERTPOS_LASTAFTERCOMMAND
    #define CLI_GUI_EMENUINSERTPOS_LASTAFTERCOMMAND           7
#endif /* CLI_GUI_EMENUINSERTPOS_LASTAFTERCOMMAND */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace EMenuInsertPos {
                    const DWORD atEnd            = CONSTANT_DWORD(0);
                    const DWORD atBegin          = CONSTANT_DWORD(1);
                    const DWORD beforeBreak      = CONSTANT_DWORD(2);
                    const DWORD afterBreak       = CONSTANT_DWORD(3);
                    const DWORD beforeCommand    = CONSTANT_DWORD(4);
                    const DWORD afterCommand     = CONSTANT_DWORD(5);
                    const DWORD firstBeforeCommand       = CONSTANT_DWORD(6);
                    const DWORD lastAfterCommand = CONSTANT_DWORD(7);
            }; // namespace EMenuInsertPos
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::EMenuInsertPos; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::EMenuBuilderInvokeCommandFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS         UINT
#else
    #define ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS         UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTAPPCONFIG
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTAPPCONFIG       CONSTANT_UINT(0)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTAPPCONFIG */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTMENUBUILDER
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTMENUBUILDER     CONSTANT_UINT(0)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTMENUBUILDER */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTDATAOBJECT
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTDATAOBJECT      CONSTANT_UINT(0)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTDATAOBJECT */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTDATAPOINTER
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTDATAPOINTER     CONSTANT_UINT(0)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTDATAPOINTER */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTARGS
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTARGS            CONSTANT_UINT(0)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDEFAULTARGS */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEAPPCONFIG
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEAPPCONFIG              CONSTANT_UINT(0x0001)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEAPPCONFIG */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEMENUBUILDER
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEMENUBUILDER            CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEMENUBUILDER */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDATAOBJECT
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDATAOBJECT             CONSTANT_UINT(0x0004)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDATAOBJECT */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDATAPOINTER
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDATAPOINTER            CONSTANT_UINT(0x0008)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEDATAPOINTER */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEARGS
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEARGS   CONSTANT_UINT(0x0010)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FUSEARGS */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTAPPCONFIG
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTAPPCONFIG  CONSTANT_UINT(0x0100)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTAPPCONFIG */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTMENUBUILDER
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTMENUBUILDER                CONSTANT_UINT(0x0200)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTMENUBUILDER */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTDATAOBJECT
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTDATAOBJECT                 CONSTANT_UINT(0x0400)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTDATAOBJECT */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTDATAPOINTER
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTDATAPOINTER                CONSTANT_UINT(0x0800)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTDATAPOINTER */

#ifndef CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTARGS
    #define CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTARGS       CONSTANT_UINT(0x1000)
#endif /* CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS_FFORCEUSEDEFAULTARGS */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace EMenuBuilderInvokeCommandFlags {
                    const UINT fUseDefaultAppConfig     = CONSTANT_UINT(0);
                    const UINT fUseDefaultMenuBuilder   = CONSTANT_UINT(0);
                    const UINT fUseDefaultDataObject    = CONSTANT_UINT(0);
                    const UINT fUseDefaultDataPointer   = CONSTANT_UINT(0);
                    const UINT fUseDefaultArgs  = CONSTANT_UINT(0);
                    const UINT fUseAppConfig    = CONSTANT_UINT(0x0001);
                    const UINT fUseMenuBuilder  = CONSTANT_UINT(0x0002);
                    const UINT fUseDataObject   = CONSTANT_UINT(0x0004);
                    const UINT fUseDataPointer  = CONSTANT_UINT(0x0008);
                    const UINT fUseArgs         = CONSTANT_UINT(0x0010);
                    const UINT fForceUseDefaultAppConfig        = CONSTANT_UINT(0x0100);
                    const UINT fForceUseDefaultMenuBuilder      = CONSTANT_UINT(0x0200);
                    const UINT fForceUseDefaultDataObject       = CONSTANT_UINT(0x0400);
                    const UINT fForceUseDefaultDataPointer      = CONSTANT_UINT(0x0800);
                    const UINT fForceUseDefaultArgs     = CONSTANT_UINT(0x1000);
            }; // namespace EMenuBuilderInvokeCommandFlags
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::EMenuBuilderInvokeCommandFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::ETrackPopupMenuFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS                   UINT
#else
    #define ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS                   UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNLEFT
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNLEFT            CONSTANT_UINT(0x0000)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNLEFT */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNCENTER
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNCENTER          CONSTANT_UINT(0x0004)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNCENTER */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNRIGHT
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNRIGHT           CONSTANT_UINT(0x0008)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNRIGHT */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNTOP
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNTOP             CONSTANT_UINT(0x0000)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNTOP */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNVCENTER
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNVCENTER         CONSTANT_UINT(0x0010)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNVCENTER */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNBOTTOM
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNBOTTOM          CONSTANT_UINT(0x0020)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_ALIGNBOTTOM */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_PREFERVERTALIGN
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_PREFERVERTALIGN      CONSTANT_UINT(0x0040)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_PREFERVERTALIGN */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_USERIGHTBUTTON
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_USERIGHTBUTTON       CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_USERIGHTBUTTON */

#ifndef CLI_GUI_ETRACKPOPUPMENUFLAGS_USERTLREADING
    #define CLI_GUI_ETRACKPOPUPMENUFLAGS_USERTLREADING        CONSTANT_UINT(0x8000)
#endif /* CLI_GUI_ETRACKPOPUPMENUFLAGS_USERTLREADING */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace ETrackPopupMenuFlags {
                    const UINT alignLeft        = CONSTANT_UINT(0x0000);
                    const UINT alignCenter      = CONSTANT_UINT(0x0004);
                    const UINT alignRight       = CONSTANT_UINT(0x0008);
                    const UINT alignTop         = CONSTANT_UINT(0x0000);
                    const UINT alignVCenter     = CONSTANT_UINT(0x0010);
                    const UINT alignBottom      = CONSTANT_UINT(0x0020);
                    const UINT preferVertAlign  = CONSTANT_UINT(0x0040);
                    const UINT useRightButton   = CONSTANT_UINT(0x0002);
                    const UINT useRtlReading    = CONSTANT_UINT(0x8000);
            }; // namespace ETrackPopupMenuFlags
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::ETrackPopupMenuFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::ECategoryStdAtoms */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_ECATEGORYSTDATOMS      SIZE_T
#else
    #define ENUM_CLI_GUI_ECATEGORYSTDATOMS      SIZE_T
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_ECATEGORYSTDATOMS_COMMONITEMSCATEGORY
    #define CLI_GUI_ECATEGORYSTDATOMS_COMMONITEMSCATEGORY     CONSTANT_SIZE_T(0)
#endif /* CLI_GUI_ECATEGORYSTDATOMS_COMMONITEMSCATEGORY */

#ifndef CLI_GUI_ECATEGORYSTDATOMS_COMMONCOMMANDSCATEGORY
    #define CLI_GUI_ECATEGORYSTDATOMS_COMMONCOMMANDSCATEGORY  1
#endif /* CLI_GUI_ECATEGORYSTDATOMS_COMMONCOMMANDSCATEGORY */

#ifndef CLI_GUI_ECATEGORYSTDATOMS_COMMONMENUSCATEGORY
    #define CLI_GUI_ECATEGORYSTDATOMS_COMMONMENUSCATEGORY     2
#endif /* CLI_GUI_ECATEGORYSTDATOMS_COMMONMENUSCATEGORY */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace ECategoryStdAtoms {
                    const SIZE_T commonItemsCategory      = CONSTANT_SIZE_T(0);
                    const SIZE_T commonCommandsCategory   = CONSTANT_SIZE_T(1);
                    const SIZE_T commonMenusCategory      = CONSTANT_SIZE_T(2);
            }; // namespace ECategoryStdAtoms
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::ECategoryStdAtoms; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::gui::CAccel */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
    #define CLI_STRUCT_NAME                   CAccel
    #ifndef STRUCT_CLI_GUI_CACCEL_PREDECLARED
    #define STRUCT_CLI_GUI_CACCEL_PREDECLARED
        struct CAccel;
        #ifndef STRUCT_CLI_GUI_CACCEL
            #define STRUCT_CLI_GUI_CACCEL             ::cli::gui::CAccel
        #endif
    #endif // STRUCT_CLI_GUI_CACCEL_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_gui_CAccel
    #ifndef STRUCT_CLI_GUI_CACCEL_PREDECLARED
    #define STRUCT_CLI_GUI_CACCEL_PREDECLARED
        struct  tag_cli_gui_CAccel;
        typedef struct tag_cli_gui_CAccel cli_gui_CAccel;
        #ifndef STRUCT_CLI_GUI_CACCEL
            #define STRUCT_CLI_GUI_CACCEL             struct tag_cli_gui_CAccel
        #endif
    #endif // STRUCT_CLI_GUI_CACCEL_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_GUI_CACCEL_DEFINED
            #define STRUCT_CLI_GUI_CACCEL_DEFINED
            #include <cli/pshpack2.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                ENUM_CLI_GUI_EACCELFLAGS    flags;
                WORD                        key;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_GUI_CACCEL_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::gui::CMenuItemInfo */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
    #define CLI_STRUCT_NAME                   CMenuItemInfo
    #ifndef STRUCT_CLI_GUI_CMENUITEMINFO_PREDECLARED
    #define STRUCT_CLI_GUI_CMENUITEMINFO_PREDECLARED
        struct CMenuItemInfo;
        #ifndef STRUCT_CLI_GUI_CMENUITEMINFO
            #define STRUCT_CLI_GUI_CMENUITEMINFO      ::cli::gui::CMenuItemInfo
        #endif
    #endif // STRUCT_CLI_GUI_CMENUITEMINFO_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_gui_CMenuItemInfo
    #ifndef STRUCT_CLI_GUI_CMENUITEMINFO_PREDECLARED
    #define STRUCT_CLI_GUI_CMENUITEMINFO_PREDECLARED
        struct  tag_cli_gui_CMenuItemInfo;
        typedef struct tag_cli_gui_CMenuItemInfo cli_gui_CMenuItemInfo;
        #ifndef STRUCT_CLI_GUI_CMENUITEMINFO
            #define STRUCT_CLI_GUI_CMENUITEMINFO      struct tag_cli_gui_CMenuItemInfo
        #endif
    #endif // STRUCT_CLI_GUI_CMENUITEMINFO_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_GUI_CMENUITEMINFO_DEFINED
            #define STRUCT_CLI_GUI_CMENUITEMINFO_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                SIZE_T                      itemId;
                ENUM_CLI_GUI_EMENUITEMFLAGS             itemFlags;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_GUI_CMENUITEMINFO_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iMenuBuilder */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iArgList;
        #ifndef INTERFACE_CLI_IARGLIST
            #define INTERFACE_CLI_IARGLIST            ::cli::iArgList
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace app {
            interface                                iConfig;
            #ifndef INTERFACE_CLI_APP_ICONFIG
                #define INTERFACE_CLI_APP_ICONFIG         ::cli::app::iConfig
            #endif

        }; // namespace app
    }; // namespace cli
    namespace cli {
        namespace gui {
            interface                                iCommand;
            #ifndef INTERFACE_CLI_GUI_ICOMMAND
                #define INTERFACE_CLI_GUI_ICOMMAND        ::cli::gui::iCommand
            #endif

            interface                                iMenuBuilder;
            #ifndef INTERFACE_CLI_GUI_IMENUBUILDER
                #define INTERFACE_CLI_GUI_IMENUBUILDER    ::cli::gui::iMenuBuilder
            #endif

        }; // namespace gui
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IARGLIST_PREDECLARED
    #define INTERFACE_CLI_IARGLIST_PREDECLARED
    typedef interface tag_cli_iArgList       cli_iArgList;
    #endif //INTERFACE_CLI_IARGLIST
    #ifndef INTERFACE_CLI_IARGLIST
        #define INTERFACE_CLI_IARGLIST            struct tag_cli_iArgList
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_APP_ICONFIG_PREDECLARED
    #define INTERFACE_CLI_APP_ICONFIG_PREDECLARED
    typedef interface tag_cli_app_iConfig    cli_app_iConfig;
    #endif //INTERFACE_CLI_APP_ICONFIG
    #ifndef INTERFACE_CLI_APP_ICONFIG
        #define INTERFACE_CLI_APP_ICONFIG         struct tag_cli_app_iConfig
    #endif

    #ifndef INTERFACE_CLI_GUI_ICOMMAND_PREDECLARED
    #define INTERFACE_CLI_GUI_ICOMMAND_PREDECLARED
    typedef interface tag_cli_gui_iCommand   cli_gui_iCommand;
    #endif //INTERFACE_CLI_GUI_ICOMMAND
    #ifndef INTERFACE_CLI_GUI_ICOMMAND
        #define INTERFACE_CLI_GUI_ICOMMAND        struct tag_cli_gui_iCommand
    #endif

    #ifndef INTERFACE_CLI_GUI_IMENUBUILDER_PREDECLARED
    #define INTERFACE_CLI_GUI_IMENUBUILDER_PREDECLARED
    typedef interface tag_cli_gui_iMenuBuilder                   cli_gui_iMenuBuilder;
    #endif //INTERFACE_CLI_GUI_IMENUBUILDER
    #ifndef INTERFACE_CLI_GUI_IMENUBUILDER
        #define INTERFACE_CLI_GUI_IMENUBUILDER    struct tag_cli_gui_iMenuBuilder
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_IMENUBUILDER_IID
    #define INTERFACE_CLI_GUI_IMENUBUILDER_IID    "/cli/gui/iMenuBuilder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iMenuBuilder
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_IMENUBUILDER
       #define INTERFACE_CLI_GUI_IMENUBUILDER    ::cli::gui::iMenuBuilder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iMenuBuilder
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_IMENUBUILDER
       #define INTERFACE_CLI_GUI_IMENUBUILDER    cli_gui_iMenuBuilder
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iMenuBuilder methods */
                CLIMETHOD(commandsNamesGet) (THIS_ CLISTR*           _commandsNames
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                CLIMETHOD(commandsNamesSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(setFindResourceParams) (THIS_ DWORD    flags /* [in] dword  flags  */
                                                      , const WCHAR*    fromModule /* [in,flat] wchar  fromModule[]  */
                                                      , const WCHAR*    useLocale /* [in,flat] wchar  useLocale[]  */
                                                 ) PURE;
                CLIMETHOD(setCommandResourcePrefix) (THIS_ const WCHAR*    prefix /* [in,flat] wchar  prefix[]  */) PURE;
                CLIMETHOD(setCommandInfoResourcePrefix) (THIS_ const WCHAR*    prefix /* [in,flat] wchar  prefix[]  */) PURE;
                CLIMETHOD(setEmptyStringResourceId) (THIS_ const WCHAR*    rcId /* [in,flat] wchar  rcId[]  */) PURE;
                CLIMETHOD(setEmptyString) (THIS_ const WCHAR*    strEmpty /* [in,flat] wchar  strEmpty[]  */) PURE;
                CLIMETHOD(setAppConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in] ::cli::app::iConfig*  appConfig  */) PURE;
                CLIMETHOD(setAppDataObject) (THIS_ INTERFACE_CLI_IUNKNOWN*    iUnkAppData /* [in] ::cli::iUnknown*  iUnkAppData  */) PURE;
                CLIMETHOD(setAppDataPointer) (THIS_ const VOID*    pvData /* [in] void*  pvData  */) PURE;
                CLIMETHOD(setTrackPopupFlags) (THIS_ ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS    tpmFlags /* [in] ::cli::gui::ETrackPopupMenuFlags  tpmFlags  */) PURE;
                CLIMETHOD(getTrackPopupFlags) (THIS_ ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS*    tpmFlags /* [out] ::cli::gui::ETrackPopupMenuFlags tpmFlags  */) PURE;
                CLIMETHOD(createMenu) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                           , BOOL    dontShowAccels /* [in] bool  dontShowAccels  */
                                           , GENERIC_HMENU*    hm /* [out] hmenu hm  */
                                      ) PURE;
                CLIMETHOD(createMenuById) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                               , BOOL    dontShowAccels /* [in] bool  dontShowAccels  */
                                               , GENERIC_HMENU*    hm /* [out] hmenu hm  */
                                          ) PURE;
                CLIMETHOD(destroyMenu) (THIS_ GENERIC_HMENU    hm /* [in] hmenu  hm  */
                                            , BOOL    bFull /* [in] bool  bFull  */
                                       ) PURE;
                CLIMETHOD(getCommandId) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                             , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                        ) PURE;
                CLIMETHOD(getMenuId) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                          , SIZE_T*    menuId /* [out,optional] size_t menuId  */
                                     ) PURE;
                CLIMETHOD(getRadioGroupId) (THIS_ const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                                , SIZE_T*    radioGroupId /* [out,optional] size_t radioGroupId  */
                                           ) PURE;
                CLIMETHOD(getCommandInfoText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                   , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                                   , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                              ) PURE;
                CLIMETHOD(getCommandByIdInfoText) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                       , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                                       , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                                  ) PURE;
                CLIMETHOD(getCommandTextById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                   , WCHAR*    cmdNameTextBuf /* [out,flat,optional] wchar cmdNameTextBuf  */
                                                   , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                              ) PURE;
                CLIMETHOD(getCommandNameById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                   , WCHAR*    cmdNameTextBuf /* [out,flat,optional] wchar cmdNameTextBuf  */
                                                   , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                              ) PURE;
                CLIMETHOD(getMenuInfoText) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                                , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                                , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                           ) PURE;
                CLIMETHOD(getMenuByIdInfoText) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                                    , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                                    , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                               ) PURE;
                CLIMETHOD(getMenuTextById) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                                , WCHAR*    menuNameTextBuf /* [out,flat,optional] wchar menuNameTextBuf  */
                                                , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                           ) PURE;
                CLIMETHOD(getMenuNameById) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                                , WCHAR*    menuNameTextBuf /* [out,flat,optional] wchar menuNameTextBuf  */
                                                , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                           ) PURE;
                CLIMETHOD(getMenuIdByHandle) (THIS_ GENERIC_HMENU    menuHandle /* [in] hmenu  menuHandle  */
                                                  , SIZE_T*    menuId /* [out] size_t menuId  */
                                             ) PURE;
                CLIMETHOD(syncCommandUiState) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */) PURE;
                CLIMETHOD(syncCommandByIdUiState) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */) PURE;
                CLIMETHOD(syncCommandsUiState) (THIS) PURE;
                CLIMETHOD(getItemNameById) (THIS_ SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                                , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                                , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                           ) PURE;
                CLIMETHOD(getItemTextById) (THIS_ SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                                , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                                , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                           ) PURE;
                CLIMETHOD(getItemInfoTextById) (THIS_ SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                                    , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                                    , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                               ) PURE;
                CLIMETHOD(invokeExactParams) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                  , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                                  , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                                  , INTERFACE_CLI_IUNKNOWN*    pUnkAppdata /* [in,optional] ::cli::iUnknown*  pUnkAppdata  */
                                                  , const VOID*    pData /* [in,optional] void*  pData  */
                                                  , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                             ) PURE;
                CLIMETHOD(invokeByIdExactParams) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                      , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                                      , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                                      , INTERFACE_CLI_IUNKNOWN*    pUnkAppdata /* [in,optional] ::cli::iUnknown*  pUnkAppdata  */
                                                      , const VOID*    pData /* [in,optional] void*  pData  */
                                                      , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                 ) PURE;
                CLIMETHOD(invokeParams) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                             , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS    invokeFlags /* [in] ::cli::gui::EMenuBuilderInvokeCommandFlags  invokeFlags  */
                                             , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                             , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                             , INTERFACE_CLI_IUNKNOWN*    pUnkAppdata /* [in,optional] ::cli::iUnknown*  pUnkAppdata  */
                                             , const VOID*    pData /* [in,optional] void*  pData  */
                                             , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                        ) PURE;
                CLIMETHOD(invokeByIdParams) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                 , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS    invokeFlags /* [in] ::cli::gui::EMenuBuilderInvokeCommandFlags  invokeFlags  */
                                                 , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                                 , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                                 , INTERFACE_CLI_IUNKNOWN*    pUnkAppdata /* [in,optional] ::cli::iUnknown*  pUnkAppdata  */
                                                 , const VOID*    pData /* [in,optional] void*  pData  */
                                                 , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                            ) PURE;
                CLIMETHOD(invoke) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */) PURE;
                CLIMETHOD(invokeById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */) PURE;
                CLIMETHOD(invokeWithArgList) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                  , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                             ) PURE;
                CLIMETHOD(invokeByIdWithArgList) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                      , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                 ) PURE;
                CLIMETHOD(executeCommandLine) (THIS_ const WCHAR*    cmdLine /* [in,flat] wchar  cmdLine[]  */
                                                   , SIZE_T    cmdLineSize /* [in] size_t  cmdLineSize  */
                                              ) PURE;
                CLIMETHOD(trackPopup) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                           , INT    cx /* [in] int  cx  */
                                           , INT    cy /* [in] int  cy  */
                                      ) PURE;
                CLIMETHOD(addCommand) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                           , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                           , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                           , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                           , const WCHAR*    rcModuleName /* [in,flat,optional] wchar  rcModuleName[]  */
                                           , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                           , const WCHAR*    itemInfoText /* [in,flat,optional] wchar  itemInfoText[]  */
                                           , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat,optional] ::cli::gui::CAccel  accels[]  */
                                           , SIZE_T    numAccels /* [in] size_t  numAccels  */
                                           , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                           , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                      ) PURE;
                CLIMETHOD(addCommandAccel) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                , const STRUCT_CLI_GUI_CACCEL*    accel /* [in,ref] ::cli::gui::CAccel  accel  */
                                           ) PURE;
                CLIMETHOD(addCommandByIdAccel) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                    , const STRUCT_CLI_GUI_CACCEL*    accel /* [in,ref] ::cli::gui::CAccel  accel  */
                                               ) PURE;
                CLIMETHOD(modifyCommandAccels) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                    , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat] ::cli::gui::CAccel  accels[]  */
                                                    , SIZE_T    numAccels /* [in] size_t  numAccels  */
                                                    , BOOL    clearExisting /* [in] bool  clearExisting  */
                                               ) PURE;
                CLIMETHOD(modifyCommandByIdAccels) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                        , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat] ::cli::gui::CAccel  accels[]  */
                                                        , SIZE_T    numAccels /* [in] size_t  numAccels  */
                                                        , BOOL    clearExisting /* [in] bool  clearExisting  */
                                                   ) PURE;
                CLIMETHOD(enumCommandAccels) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                  , SIZE_T    accelNo /* [in] size_t  accelNo  */
                                                  , STRUCT_CLI_GUI_CACCEL*    accel /* [out] ::cli::gui::CAccel accel  */
                                             ) PURE;
                CLIMETHOD(enumCommandByIdAccels) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                      , SIZE_T    accelNo /* [in] size_t  accelNo  */
                                                      , STRUCT_CLI_GUI_CACCEL*    accel /* [out] ::cli::gui::CAccel accel  */
                                                 ) PURE;
                CLIMETHOD(addCommandSimple) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                 , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                 , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                 , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                            ) PURE;
                CLIMETHOD(addCommandSimpleText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                     , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                     , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                     , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                                     , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                                ) PURE;
                CLIMETHOD(addCommandWithArgs) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                   , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                   , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                   , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                   , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                              ) PURE;
                CLIMETHOD(addCommandWithArgsText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                       , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                       , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                       , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                       , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                                       , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                                  ) PURE;
                CLIMETHOD(addCommandRadio) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                                , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                           ) PURE;
                CLIMETHOD(addCommandRadioText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                    , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                    , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                    , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                                    , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                                    , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                               ) PURE;
                CLIMETHOD(addCommandRadioWithArgs) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                        , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                        , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                        , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                        , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                                        , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                                   ) PURE;
                CLIMETHOD(addCommandRadioWithArgsText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                            , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                            , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                            , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                            , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                                            , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                                            , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                                       ) PURE;
                CLIMETHOD(getCommandState) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                           ) PURE;
                CLIMETHOD(getCommandByIdState) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                    , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                               ) PURE;
                CLIMETHOD(setCommandState) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                           ) PURE;
                CLIMETHOD(setCommandByIdState) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                    , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                               ) PURE;
                CLIMETHOD(setCommandChecked) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                  , BOOL    checked /* [in] bool  checked  */
                                             ) PURE;
                CLIMETHOD(setCommandByIdChecked) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                      , BOOL    checked /* [in] bool  checked  */
                                                 ) PURE;
                CLIMETHOD(setCommandEnabled) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                  , BOOL    enabled /* [in] bool  enabled  */
                                             ) PURE;
                CLIMETHOD(setCommandByIdEnabled) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                      , BOOL    enabled /* [in] bool  enabled  */
                                                 ) PURE;
                CLIMETHOD(setCommandHidden) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                 , BOOL    hidden /* [in] bool  hidden  */
                                            ) PURE;
                CLIMETHOD(setCommandByIdHidden) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                     , BOOL    hidden /* [in] bool  hidden  */
                                                ) PURE;
                CLIMETHOD(getMenuState) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                             , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                        ) PURE;
                CLIMETHOD(getMenuByIdState) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                                 , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                            ) PURE;
                CLIMETHOD(setMenuState) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                             , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                        ) PURE;
                CLIMETHOD(setMenuByIdState) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                                 , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                            ) PURE;
                CLIMETHOD(setMenuHidden) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                              , BOOL    hidden /* [in] bool  hidden  */
                                         ) PURE;
                CLIMETHOD(setMenuByIdHidden) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                                  , BOOL    hidden /* [in] bool  hidden  */
                                             ) PURE;
                CLIMETHOD(addMenu) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                        , const WCHAR*    rcModuleName /* [in,flat,optional] wchar  rcModuleName[]  */
                                        , const WCHAR*    menuText /* [in,flat,optional] wchar  menuText[]  */
                                        , const WCHAR*    menuInfoText /* [in,flat,optional] wchar  menuInfoText[]  */
                                        , BOOL    bMainMenu /* [in] bool  bMainMenu  */
                                        , SIZE_T*    menuId /* [out,optional] size_t menuId  */
                                   ) PURE;
                CLIMETHOD(appendMenuItem) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                               , const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                          ) PURE;
                CLIMETHOD(insertMenuItem) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                               , const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                               , ENUM_CLI_GUI_EMENUINSERTPOS    howInsert /* [in] ::cli::gui::EMenuInsertPos  howInsert  */
                                               , SIZE_T    insertPos /* [in] size_t  insertPos  */
                                          ) PURE;
                CLIMETHOD(enumMenuItems) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                              , SIZE_T    itemIndex /* [in] size_t  itemIndex  */
                                              , STRUCT_CLI_GUI_CMENUITEMINFO*    itemInfo /* [out] ::cli::gui::CMenuItemInfo itemInfo  */
                                         ) PURE;
                CLIMETHOD(enumMenuByIdItems) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                                  , SIZE_T    itemIndex /* [in] size_t  itemIndex  */
                                                  , STRUCT_CLI_GUI_CMENUITEMINFO*    itemInfo /* [out] ::cli::gui::CMenuItemInfo itemInfo  */
                                             ) PURE;
                CLIMETHOD(getRadioIndex) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                              , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                              , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                         ) PURE;
                CLIMETHOD(getRadioIndexById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                  , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                                  , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                             ) PURE;
                CLIMETHOD(getRadioIndexById2) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                   , SIZE_T    radioGroupId /* [in] size_t  radioGroupId  */
                                                   , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                              ) PURE;
                CLIMETHOD(setRadioChecked) (THIS_ SIZE_T    radioIndex /* [in] size_t  radioIndex  */
                                                , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                           ) PURE;
                CLIMETHOD(setRadioCheckedById) (THIS_ SIZE_T    radioIndex /* [in] size_t  radioIndex  */
                                                    , SIZE_T    rgId /* [in] size_t  rgId  */
                                               ) PURE;
                CLIMETHOD(getRadioChecked) (THIS_ SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                                , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                           ) PURE;
                CLIMETHOD(getRadioCheckedById) (THIS_ SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                                    , SIZE_T    rgId /* [in] size_t  rgId  */
                                               ) PURE;
                CLIMETHOD(getCommandRadioGroup) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                     , SIZE_T*    rgId /* [out] size_t rgId  */
                                                ) PURE;
                CLIMETHOD(getCommandByIdRadioGroup) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                         , SIZE_T*    rgId /* [out] size_t rgId  */
                                                    ) PURE;
                CLIMETHOD(setCommandHandler) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                  , INTERFACE_CLI_GUI_ICOMMAND*    newHandler /* [in] ::cli::gui::iCommand*  newHandler  */
                                             ) PURE;
                CLIMETHOD(setCommandByIdHandler) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                      , INTERFACE_CLI_GUI_ICOMMAND*    newHandler /* [in] ::cli::gui::iCommand*  newHandler  */
                                                 ) PURE;
                CLIMETHOD(isMenuId) (THIS_ SIZE_T    id /* [in] size_t  id  */
                                         , BOOL*    isMenu /* [out] bool isMenu  */
                                    ) PURE;
                CLIMETHOD(addCommandCategory) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                   , SIZE_T*    categoryIdAtom /* [out] size_t categoryIdAtom  */
                                              ) PURE;
                CLIMETHOD(getCommandCategoryId) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                     , SIZE_T*    categoryIdAtom /* [out] size_t categoryIdAtom  */
                                                ) PURE;
                CLIMETHOD(getCommandCategoryName) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                       , WCHAR*    categoryIdNameBuf /* [out,flat,optional] wchar categoryIdNameBuf  */
                                                       , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                                  ) PURE;
                CLIMETHOD(enumCommandCategories) (THIS_ const WCHAR*    categoryIdMask /* [in,flat] wchar  categoryIdMask[]  */
                                                      , SIZE_T*    foundCategoryIdAtom /* [in,out] size_t foundCategoryIdAtom  */
                                                 ) PURE;
                CLIMETHOD(enumCommandCategoryItems) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                         , SIZE_T    idx /* [in] size_t  idx  */
                                                         , SIZE_T*    cmdId /* [out] size_t cmdId  */
                                                    ) PURE;
                CLIMETHOD(modifyCommandStateByCategory) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                             , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                             , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                                        ) PURE;
                CLIMETHOD(modifyCommandStateByCategoryId) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                               , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                               , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                                          ) PURE;
                CLIMETHOD(modifyCommandStateByCategoryMask) (THIS_ const WCHAR*    categoryIdMask /* [in,flat] wchar  categoryIdMask[]  */
                                                                 , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                                 , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                                            ) PURE;
                CLIMETHOD(addCommandToCategory) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                     , const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                                ) PURE;
                CLIMETHOD(addCommandToCategoryById) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                         , const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                                    ) PURE;
                CLIMETHOD(addCommandToCategoryById2) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                          , SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                     ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iMenuBuilder >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_IMENUBUILDER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iMenuBuilder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iMenuBuilder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iMenuBuilder wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_IMENUBUILDER >
                                          */
                     >
            class CiMenuBuilderWrapper
            {
                public:
            
                    typedef  CiMenuBuilderWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiMenuBuilderWrapper() :
                       pif(0) {}
            
                    CiMenuBuilderWrapper( iMenuBuilder *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiMenuBuilderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiMenuBuilderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiMenuBuilderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiMenuBuilderWrapper(const CiMenuBuilderWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiMenuBuilderWrapper()  { }
            
                    CiMenuBuilderWrapper& operator=(const CiMenuBuilderWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_commandsNames( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = commandsNamesGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_commandsNames(  )
                       {
                        SIZE_T size;
                        RCODE res = commandsNamesSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, commandsNames, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE commandsNamesGet( ::std::wstring    &_commandsNames
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                       {
                        CCliStr tmp__commandsNames; CCliStr_init( tmp__commandsNames );
                    
                        RCODE res = pif->commandsNamesGet(&tmp__commandsNames, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _commandsNames, tmp__commandsNames);
                           }
                        return res;
                       }
                    
                    RCODE commandsNamesSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->commandsNamesSize(_size);
                       }
                    
                    RCODE setFindResourceParams( DWORD    flags /* [in] dword  flags  */
                                               , const WCHAR*    fromModule /* [in,flat] wchar  fromModule[]  */
                                               , const WCHAR*    useLocale /* [in,flat] wchar  useLocale[]  */
                                               )
                       {
                    
                    
                    
                        return pif->setFindResourceParams(flags, fromModule, useLocale);
                       }
                    
                    RCODE setCommandResourcePrefix( const WCHAR*    prefix /* [in,flat] wchar  prefix[]  */)
                       {
                    
                        return pif->setCommandResourcePrefix(prefix);
                       }
                    
                    RCODE setCommandInfoResourcePrefix( const WCHAR*    prefix /* [in,flat] wchar  prefix[]  */)
                       {
                    
                        return pif->setCommandInfoResourcePrefix(prefix);
                       }
                    
                    RCODE setEmptyStringResourceId( const WCHAR*    rcId /* [in,flat] wchar  rcId[]  */)
                       {
                    
                        return pif->setEmptyStringResourceId(rcId);
                       }
                    
                    RCODE setEmptyString( const WCHAR*    strEmpty /* [in,flat] wchar  strEmpty[]  */)
                       {
                    
                        return pif->setEmptyString(strEmpty);
                       }
                    
                    RCODE setAppConfig( INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in] ::cli::app::iConfig*  appConfig  */)
                       {
                    
                        return pif->setAppConfig(appConfig);
                       }
                    
                    RCODE setAppDataObject( INTERFACE_CLI_IUNKNOWN*    iUnkAppData /* [in] ::cli::iUnknown*  iUnkAppData  */)
                       {
                    
                        return pif->setAppDataObject(iUnkAppData);
                       }
                    
                    RCODE setAppDataPointer( const VOID*    pvData /* [in] void*  pvData  */)
                       {
                    
                        return pif->setAppDataPointer(pvData);
                       }
                    
                    RCODE setTrackPopupFlags( ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS    tpmFlags /* [in] ::cli::gui::ETrackPopupMenuFlags  tpmFlags  */)
                       {
                    
                        return pif->setTrackPopupFlags(tpmFlags);
                       }
                    
                    RCODE getTrackPopupFlags( ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS*    tpmFlags /* [out] ::cli::gui::ETrackPopupMenuFlags tpmFlags  */)
                       {
                    
                        return pif->getTrackPopupFlags(tpmFlags);
                       }
                    
                    RCODE createMenu( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                    , BOOL    dontShowAccels /* [in] bool  dontShowAccels  */
                                    , GENERIC_HMENU*    hm /* [out] hmenu hm  */
                                    )
                       {
                    
                    
                    
                        return pif->createMenu(menuName, dontShowAccels, hm);
                       }
                    
                    RCODE createMenuById( SIZE_T    menuId /* [in] size_t  menuId  */
                                        , BOOL    dontShowAccels /* [in] bool  dontShowAccels  */
                                        , GENERIC_HMENU*    hm /* [out] hmenu hm  */
                                        )
                       {
                    
                    
                    
                        return pif->createMenuById(menuId, dontShowAccels, hm);
                       }
                    
                    RCODE destroyMenu( GENERIC_HMENU    hm /* [in] hmenu  hm  */
                                     , BOOL    bFull /* [in] bool  bFull  */
                                     )
                       {
                    
                    
                        return pif->destroyMenu(hm, bFull);
                       }
                    
                    RCODE getCommandId( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                      , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                      )
                       {
                    
                    
                        return pif->getCommandId(cmdName, commandId);
                       }
                    
                    RCODE getMenuId( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                   , SIZE_T*    menuId /* [out,optional] size_t menuId  */
                                   )
                       {
                    
                    
                        return pif->getMenuId(menuName, menuId);
                       }
                    
                    RCODE getRadioGroupId( const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                         , SIZE_T*    radioGroupId /* [out,optional] size_t radioGroupId  */
                                         )
                       {
                    
                    
                        return pif->getRadioGroupId(radioGroupName, radioGroupId);
                       }
                    
                    RCODE getCommandInfoText( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                            , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                            , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                            )
                       {
                    
                    
                    
                        return pif->getCommandInfoText(cmdName, infoTextBuf, bufSize);
                       }
                    
                    RCODE getCommandByIdInfoText( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                                , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                                )
                       {
                    
                    
                    
                        return pif->getCommandByIdInfoText(cmdId, infoTextBuf, bufSize);
                       }
                    
                    RCODE getCommandTextById( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                            , WCHAR*    cmdNameTextBuf /* [out,flat,optional] wchar cmdNameTextBuf  */
                                            , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                            )
                       {
                    
                    
                    
                        return pif->getCommandTextById(cmdId, cmdNameTextBuf, bufSize);
                       }
                    
                    RCODE getCommandNameById( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                            , WCHAR*    cmdNameTextBuf /* [out,flat,optional] wchar cmdNameTextBuf  */
                                            , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                            )
                       {
                    
                    
                    
                        return pif->getCommandNameById(cmdId, cmdNameTextBuf, bufSize);
                       }
                    
                    RCODE getMenuInfoText( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                         , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                         , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                         )
                       {
                    
                    
                    
                        return pif->getMenuInfoText(menuName, infoTextBuf, bufSize);
                       }
                    
                    RCODE getMenuByIdInfoText( SIZE_T    menuId /* [in] size_t  menuId  */
                                             , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                             , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                             )
                       {
                    
                    
                    
                        return pif->getMenuByIdInfoText(menuId, infoTextBuf, bufSize);
                       }
                    
                    RCODE getMenuTextById( SIZE_T    menuId /* [in] size_t  menuId  */
                                         , WCHAR*    menuNameTextBuf /* [out,flat,optional] wchar menuNameTextBuf  */
                                         , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                         )
                       {
                    
                    
                    
                        return pif->getMenuTextById(menuId, menuNameTextBuf, bufSize);
                       }
                    
                    RCODE getMenuNameById( SIZE_T    menuId /* [in] size_t  menuId  */
                                         , WCHAR*    menuNameTextBuf /* [out,flat,optional] wchar menuNameTextBuf  */
                                         , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                         )
                       {
                    
                    
                    
                        return pif->getMenuNameById(menuId, menuNameTextBuf, bufSize);
                       }
                    
                    RCODE getMenuIdByHandle( GENERIC_HMENU    menuHandle /* [in] hmenu  menuHandle  */
                                           , SIZE_T*    menuId /* [out] size_t menuId  */
                                           )
                       {
                    
                    
                        return pif->getMenuIdByHandle(menuHandle, menuId);
                       }
                    
                    RCODE syncCommandUiState( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */)
                       {
                    
                        return pif->syncCommandUiState(cmdName);
                       }
                    
                    RCODE syncCommandByIdUiState( SIZE_T    cmdId /* [in] size_t  cmdId  */)
                       {
                    
                        return pif->syncCommandByIdUiState(cmdId);
                       }
                    
                    RCODE syncCommandsUiState( )
                       {
                        return pif->syncCommandsUiState();
                       }
                    
                    RCODE getItemNameById( SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                         , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                         , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                         )
                       {
                    
                    
                    
                        return pif->getItemNameById(menuOrCmdId, nameTextBuf, bufSize);
                       }
                    
                    RCODE getItemTextById( SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                         , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                         , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                         )
                       {
                    
                    
                    
                        return pif->getItemTextById(menuOrCmdId, nameTextBuf, bufSize);
                       }
                    
                    RCODE getItemInfoTextById( SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                             , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                             , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                             )
                       {
                    
                    
                    
                        return pif->getItemInfoTextById(menuOrCmdId, nameTextBuf, bufSize);
                       }
                    
                    RCODE invokeExactParams( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                           , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                           , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                           , INTERFACE_CLI_IUNKNOWN*    pUnkAppdata /* [in,optional] ::cli::iUnknown*  pUnkAppdata  */
                                           , const VOID*    pData /* [in,optional] void*  pData  */
                                           , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                           )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->invokeExactParams(cmdName, pMenuBuilder, appConfig, pUnkAppdata, pData, pArgs);
                       }
                    
                    RCODE invokeByIdExactParams( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                               , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                               , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                               , INTERFACE_CLI_IUNKNOWN*    pUnkAppdata /* [in,optional] ::cli::iUnknown*  pUnkAppdata  */
                                               , const VOID*    pData /* [in,optional] void*  pData  */
                                               , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                               )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->invokeByIdExactParams(cmdId, pMenuBuilder, appConfig, pUnkAppdata, pData, pArgs);
                       }
                    
                    RCODE invokeParams( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                      , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS    invokeFlags /* [in] ::cli::gui::EMenuBuilderInvokeCommandFlags  invokeFlags  */
                                      , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                      , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                      , INTERFACE_CLI_IUNKNOWN*    pUnkAppdata /* [in,optional] ::cli::iUnknown*  pUnkAppdata  */
                                      , const VOID*    pData /* [in,optional] void*  pData  */
                                      , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                      )
                       {
                    
                    
                    
                    
                    
                    
                    
                        return pif->invokeParams(cmdName, invokeFlags, pMenuBuilder, appConfig, pUnkAppdata, pData, pArgs);
                       }
                    
                    RCODE invokeByIdParams( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                          , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS    invokeFlags /* [in] ::cli::gui::EMenuBuilderInvokeCommandFlags  invokeFlags  */
                                          , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                          , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                          , INTERFACE_CLI_IUNKNOWN*    pUnkAppdata /* [in,optional] ::cli::iUnknown*  pUnkAppdata  */
                                          , const VOID*    pData /* [in,optional] void*  pData  */
                                          , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                          )
                       {
                    
                    
                    
                    
                    
                    
                    
                        return pif->invokeByIdParams(cmdId, invokeFlags, pMenuBuilder, appConfig, pUnkAppdata, pData, pArgs);
                       }
                    
                    RCODE invoke( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */)
                       {
                    
                        return pif->invoke(cmdName);
                       }
                    
                    RCODE invokeById( SIZE_T    cmdId /* [in] size_t  cmdId  */)
                       {
                    
                        return pif->invokeById(cmdId);
                       }
                    
                    RCODE invokeWithArgList( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                           , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                           )
                       {
                    
                    
                        return pif->invokeWithArgList(cmdName, pArgs);
                       }
                    
                    RCODE invokeByIdWithArgList( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                               , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                               )
                       {
                    
                    
                        return pif->invokeByIdWithArgList(cmdId, pArgs);
                       }
                    
                    RCODE executeCommandLine( const WCHAR*    cmdLine /* [in,flat] wchar  cmdLine[]  */
                                            , SIZE_T    cmdLineSize /* [in] size_t  cmdLineSize  */
                                            )
                       {
                    
                    
                        return pif->executeCommandLine(cmdLine, cmdLineSize);
                       }
                    
                    RCODE trackPopup( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                    , INT    cx /* [in] int  cx  */
                                    , INT    cy /* [in] int  cy  */
                                    )
                       {
                    
                    
                    
                        return pif->trackPopup(menuName, cx, cy);
                       }
                    
                    RCODE addCommand( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                    , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                    , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                    , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                    , const WCHAR*    rcModuleName /* [in,flat,optional] wchar  rcModuleName[]  */
                                    , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                    , const WCHAR*    itemInfoText /* [in,flat,optional] wchar  itemInfoText[]  */
                                    , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat,optional] ::cli::gui::CAccel  accels[]  */
                                    , SIZE_T    numAccels /* [in] size_t  numAccels  */
                                    , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                    , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                    )
                       {
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                        return pif->addCommand(cmdName, flags, handler, pArgs, rcModuleName, itemText, itemInfoText, accels, numAccels, radioGroupName, commandId);
                       }
                    
                    RCODE addCommandAccel( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                         , const STRUCT_CLI_GUI_CACCEL    &accel /* [in,ref] ::cli::gui::CAccel  accel  (struct passed by ref in wrapper) */
                                         )
                       {
                    
                    
                        return pif->addCommandAccel(cmdName, &accel);
                       }
                    
                    RCODE addCommandByIdAccel( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                             , const STRUCT_CLI_GUI_CACCEL    &accel /* [in,ref] ::cli::gui::CAccel  accel  (struct passed by ref in wrapper) */
                                             )
                       {
                    
                    
                        return pif->addCommandByIdAccel(cmdId, &accel);
                       }
                    
                    RCODE modifyCommandAccels( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                             , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat] ::cli::gui::CAccel  accels[]  */
                                             , SIZE_T    numAccels /* [in] size_t  numAccels  */
                                             , BOOL    clearExisting /* [in] bool  clearExisting  */
                                             )
                       {
                    
                    
                    
                    
                        return pif->modifyCommandAccels(cmdName, accels, numAccels, clearExisting);
                       }
                    
                    RCODE modifyCommandByIdAccels( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                 , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat] ::cli::gui::CAccel  accels[]  */
                                                 , SIZE_T    numAccels /* [in] size_t  numAccels  */
                                                 , BOOL    clearExisting /* [in] bool  clearExisting  */
                                                 )
                       {
                    
                    
                    
                    
                        return pif->modifyCommandByIdAccels(cmdId, accels, numAccels, clearExisting);
                       }
                    
                    RCODE enumCommandAccels( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                           , SIZE_T    accelNo /* [in] size_t  accelNo  */
                                           , STRUCT_CLI_GUI_CACCEL    &accel /* [out] ::cli::gui::CAccel accel  (struct passed by ref in wrapper) */
                                           )
                       {
                    
                    
                    
                        return pif->enumCommandAccels(cmdName, accelNo, &accel);
                       }
                    
                    RCODE enumCommandByIdAccels( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                               , SIZE_T    accelNo /* [in] size_t  accelNo  */
                                               , STRUCT_CLI_GUI_CACCEL    &accel /* [out] ::cli::gui::CAccel accel  (struct passed by ref in wrapper) */
                                               )
                       {
                    
                    
                    
                        return pif->enumCommandByIdAccels(cmdId, accelNo, &accel);
                       }
                    
                    RCODE addCommandSimple( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                          , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                          , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                          , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                          )
                       {
                    
                    
                    
                    
                        return pif->addCommandSimple(cmdName, flags, handler, commandId);
                       }
                    
                    RCODE addCommandSimpleText( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                              , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                              , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                              , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                              , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                              )
                       {
                    
                    
                    
                    
                    
                        return pif->addCommandSimpleText(cmdName, flags, handler, itemText, commandId);
                       }
                    
                    RCODE addCommandWithArgs( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                            , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                            , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                            , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                            , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                            )
                       {
                    
                    
                    
                    
                    
                        return pif->addCommandWithArgs(cmdName, flags, handler, pArgs, commandId);
                       }
                    
                    RCODE addCommandWithArgsText( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                                , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                                )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->addCommandWithArgsText(cmdName, flags, handler, pArgs, itemText, commandId);
                       }
                    
                    RCODE addCommandRadio( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                         , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                         , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                         , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                         , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                         )
                       {
                    
                    
                    
                    
                    
                        return pif->addCommandRadio(cmdName, flags, handler, radioGroupName, commandId);
                       }
                    
                    RCODE addCommandRadioText( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                             , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                             , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                             , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                             , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                             , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                             )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->addCommandRadioText(cmdName, flags, handler, itemText, radioGroupName, commandId);
                       }
                    
                    RCODE addCommandRadioWithArgs( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                 , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                 , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                 , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                 , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                                 , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                                 )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->addCommandRadioWithArgs(cmdName, flags, handler, pArgs, radioGroupName, commandId);
                       }
                    
                    RCODE addCommandRadioWithArgsText( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                     , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                     , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                     , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                     , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                                     , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                                     , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                                     )
                       {
                    
                    
                    
                    
                    
                    
                    
                        return pif->addCommandRadioWithArgsText(cmdName, flags, handler, pArgs, itemText, radioGroupName, commandId);
                       }
                    
                    RCODE getCommandState( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                         , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                         )
                       {
                    
                    
                        return pif->getCommandState(cmdName, stateFlags);
                       }
                    
                    RCODE getCommandByIdState( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                             , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                             )
                       {
                    
                    
                        return pif->getCommandByIdState(cmdId, stateFlags);
                       }
                    
                    RCODE setCommandState( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                         , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                         )
                       {
                    
                    
                        return pif->setCommandState(cmdName, newStateFlags);
                       }
                    
                    RCODE setCommandByIdState( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                             , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                             )
                       {
                    
                    
                        return pif->setCommandByIdState(cmdId, newStateFlags);
                       }
                    
                    RCODE setCommandChecked( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                           , BOOL    checked /* [in] bool  checked  */
                                           )
                       {
                    
                    
                        return pif->setCommandChecked(cmdName, checked);
                       }
                    
                    RCODE setCommandByIdChecked( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                               , BOOL    checked /* [in] bool  checked  */
                                               )
                       {
                    
                    
                        return pif->setCommandByIdChecked(cmdId, checked);
                       }
                    
                    RCODE setCommandEnabled( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                           , BOOL    enabled /* [in] bool  enabled  */
                                           )
                       {
                    
                    
                        return pif->setCommandEnabled(cmdName, enabled);
                       }
                    
                    RCODE setCommandByIdEnabled( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                               , BOOL    enabled /* [in] bool  enabled  */
                                               )
                       {
                    
                    
                        return pif->setCommandByIdEnabled(cmdId, enabled);
                       }
                    
                    RCODE setCommandHidden( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                          , BOOL    hidden /* [in] bool  hidden  */
                                          )
                       {
                    
                    
                        return pif->setCommandHidden(cmdName, hidden);
                       }
                    
                    RCODE setCommandByIdHidden( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                              , BOOL    hidden /* [in] bool  hidden  */
                                              )
                       {
                    
                    
                        return pif->setCommandByIdHidden(cmdId, hidden);
                       }
                    
                    RCODE getMenuState( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                      , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                      )
                       {
                    
                    
                        return pif->getMenuState(menuName, stateFlags);
                       }
                    
                    RCODE getMenuByIdState( SIZE_T    menuId /* [in] size_t  menuId  */
                                          , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                          )
                       {
                    
                    
                        return pif->getMenuByIdState(menuId, stateFlags);
                       }
                    
                    RCODE setMenuState( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                      , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                      )
                       {
                    
                    
                        return pif->setMenuState(menuName, newStateFlags);
                       }
                    
                    RCODE setMenuByIdState( SIZE_T    menuId /* [in] size_t  menuId  */
                                          , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                          )
                       {
                    
                    
                        return pif->setMenuByIdState(menuId, newStateFlags);
                       }
                    
                    RCODE setMenuHidden( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                       , BOOL    hidden /* [in] bool  hidden  */
                                       )
                       {
                    
                    
                        return pif->setMenuHidden(menuName, hidden);
                       }
                    
                    RCODE setMenuByIdHidden( SIZE_T    menuId /* [in] size_t  menuId  */
                                           , BOOL    hidden /* [in] bool  hidden  */
                                           )
                       {
                    
                    
                        return pif->setMenuByIdHidden(menuId, hidden);
                       }
                    
                    RCODE addMenu( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                 , const WCHAR*    rcModuleName /* [in,flat,optional] wchar  rcModuleName[]  */
                                 , const WCHAR*    menuText /* [in,flat,optional] wchar  menuText[]  */
                                 , const WCHAR*    menuInfoText /* [in,flat,optional] wchar  menuInfoText[]  */
                                 , BOOL    bMainMenu /* [in] bool  bMainMenu  */
                                 , SIZE_T*    menuId /* [out,optional] size_t menuId  */
                                 )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->addMenu(menuName, rcModuleName, menuText, menuInfoText, bMainMenu, menuId);
                       }
                    
                    RCODE appendMenuItem( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                        , const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                        )
                       {
                    
                    
                        return pif->appendMenuItem(menuName, cmdName);
                       }
                    
                    RCODE insertMenuItem( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                        , const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                        , ENUM_CLI_GUI_EMENUINSERTPOS    howInsert /* [in] ::cli::gui::EMenuInsertPos  howInsert  */
                                        , SIZE_T    insertPos /* [in] size_t  insertPos  */
                                        )
                       {
                    
                    
                    
                    
                        return pif->insertMenuItem(menuName, cmdName, howInsert, insertPos);
                       }
                    
                    RCODE enumMenuItems( const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                       , SIZE_T    itemIndex /* [in] size_t  itemIndex  */
                                       , STRUCT_CLI_GUI_CMENUITEMINFO    &itemInfo /* [out] ::cli::gui::CMenuItemInfo itemInfo  (struct passed by ref in wrapper) */
                                       )
                       {
                    
                    
                    
                        return pif->enumMenuItems(menuName, itemIndex, &itemInfo);
                       }
                    
                    RCODE enumMenuByIdItems( SIZE_T    menuId /* [in] size_t  menuId  */
                                           , SIZE_T    itemIndex /* [in] size_t  itemIndex  */
                                           , STRUCT_CLI_GUI_CMENUITEMINFO    &itemInfo /* [out] ::cli::gui::CMenuItemInfo itemInfo  (struct passed by ref in wrapper) */
                                           )
                       {
                    
                    
                    
                        return pif->enumMenuByIdItems(menuId, itemIndex, &itemInfo);
                       }
                    
                    RCODE getRadioIndex( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                       , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                       , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                       )
                       {
                    
                    
                    
                        return pif->getRadioIndex(cmdName, radioGroupName, radioIndex);
                       }
                    
                    RCODE getRadioIndexById( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                           , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                           , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                           )
                       {
                    
                    
                    
                        return pif->getRadioIndexById(cmdId, radioGroupName, radioIndex);
                       }
                    
                    RCODE getRadioIndexById2( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                            , SIZE_T    radioGroupId /* [in] size_t  radioGroupId  */
                                            , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                            )
                       {
                    
                    
                    
                        return pif->getRadioIndexById2(cmdId, radioGroupId, radioIndex);
                       }
                    
                    RCODE setRadioChecked( SIZE_T    radioIndex /* [in] size_t  radioIndex  */
                                         , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                         )
                       {
                    
                    
                        return pif->setRadioChecked(radioIndex, radioGroupName);
                       }
                    
                    RCODE setRadioCheckedById( SIZE_T    radioIndex /* [in] size_t  radioIndex  */
                                             , SIZE_T    rgId /* [in] size_t  rgId  */
                                             )
                       {
                    
                    
                        return pif->setRadioCheckedById(radioIndex, rgId);
                       }
                    
                    RCODE getRadioChecked( SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                         , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                         )
                       {
                    
                    
                        return pif->getRadioChecked(radioIndex, radioGroupName);
                       }
                    
                    RCODE getRadioCheckedById( SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                             , SIZE_T    rgId /* [in] size_t  rgId  */
                                             )
                       {
                    
                    
                        return pif->getRadioCheckedById(radioIndex, rgId);
                       }
                    
                    RCODE getCommandRadioGroup( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                              , SIZE_T*    rgId /* [out] size_t rgId  */
                                              )
                       {
                    
                    
                        return pif->getCommandRadioGroup(cmdName, rgId);
                       }
                    
                    RCODE getCommandByIdRadioGroup( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                  , SIZE_T*    rgId /* [out] size_t rgId  */
                                                  )
                       {
                    
                    
                        return pif->getCommandByIdRadioGroup(cmdId, rgId);
                       }
                    
                    RCODE setCommandHandler( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                           , INTERFACE_CLI_GUI_ICOMMAND*    newHandler /* [in] ::cli::gui::iCommand*  newHandler  */
                                           )
                       {
                    
                    
                        return pif->setCommandHandler(cmdName, newHandler);
                       }
                    
                    RCODE setCommandByIdHandler( SIZE_T    cmdId /* [in] size_t  cmdId  */
                                               , INTERFACE_CLI_GUI_ICOMMAND*    newHandler /* [in] ::cli::gui::iCommand*  newHandler  */
                                               )
                       {
                    
                    
                        return pif->setCommandByIdHandler(cmdId, newHandler);
                       }
                    
                    RCODE isMenuId( SIZE_T    id /* [in] size_t  id  */
                                  , BOOL*    isMenu /* [out] bool isMenu  */
                                  )
                       {
                    
                    
                        return pif->isMenuId(id, isMenu);
                       }
                    
                    RCODE addCommandCategory( const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                            , SIZE_T*    categoryIdAtom /* [out] size_t categoryIdAtom  */
                                            )
                       {
                    
                    
                        return pif->addCommandCategory(categoryId, categoryIdAtom);
                       }
                    
                    RCODE getCommandCategoryId( const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                              , SIZE_T*    categoryIdAtom /* [out] size_t categoryIdAtom  */
                                              )
                       {
                    
                    
                        return pif->getCommandCategoryId(categoryId, categoryIdAtom);
                       }
                    
                    RCODE getCommandCategoryName( SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                , WCHAR*    categoryIdNameBuf /* [out,flat,optional] wchar categoryIdNameBuf  */
                                                , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                                )
                       {
                    
                    
                    
                        return pif->getCommandCategoryName(categoryIdAtom, categoryIdNameBuf, bufSize);
                       }
                    
                    RCODE enumCommandCategories( const WCHAR*    categoryIdMask /* [in,flat] wchar  categoryIdMask[]  */
                                               , SIZE_T*    foundCategoryIdAtom /* [in,out] size_t foundCategoryIdAtom  */
                                               )
                       {
                    
                    
                        return pif->enumCommandCategories(categoryIdMask, foundCategoryIdAtom);
                       }
                    
                    RCODE enumCommandCategoryItems( SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                  , SIZE_T    idx /* [in] size_t  idx  */
                                                  , SIZE_T*    cmdId /* [out] size_t cmdId  */
                                                  )
                       {
                    
                    
                    
                        return pif->enumCommandCategoryItems(categoryIdAtom, idx, cmdId);
                       }
                    
                    RCODE modifyCommandStateByCategory( const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                      , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                      , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                                      )
                       {
                    
                    
                    
                        return pif->modifyCommandStateByCategory(categoryId, clearFlags, setFlags);
                       }
                    
                    RCODE modifyCommandStateByCategoryId( SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                        , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                        , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                                        )
                       {
                    
                    
                    
                        return pif->modifyCommandStateByCategoryId(categoryIdAtom, clearFlags, setFlags);
                       }
                    
                    RCODE modifyCommandStateByCategoryMask( const WCHAR*    categoryIdMask /* [in,flat] wchar  categoryIdMask[]  */
                                                          , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                          , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                                          )
                       {
                    
                    
                    
                        return pif->modifyCommandStateByCategoryMask(categoryIdMask, clearFlags, setFlags);
                       }
                    
                    RCODE addCommandToCategory( const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                              , const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                              )
                       {
                    
                    
                        return pif->addCommandToCategory(categoryId, cmdId);
                       }
                    
                    RCODE addCommandToCategoryById( SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                  , const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                                  )
                       {
                    
                    
                        return pif->addCommandToCategoryById(categoryIdAtom, cmdId);
                       }
                    
                    RCODE addCommandToCategoryById2( SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                   , SIZE_T    cmdId /* [in] size_t  cmdId  */
                                                   )
                       {
                    
                    
                        return pif->addCommandToCategoryById2(categoryIdAtom, cmdId);
                       }
                    

            
            
            }; // class CiMenuBuilderWrapper
            
            typedef CiMenuBuilderWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_IMENUBUILDER     > >  CiMenuBuilder;
            typedef CiMenuBuilderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IMENUBUILDER > >  CiMenuBuilder_nrc; /* No ref counting for interface used */
            typedef CiMenuBuilderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IMENUBUILDER > >  CiMenuBuilder_tmp; /* for temporary usage, same as CiMenuBuilder_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iWin32WindowHolder */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER_IID
    #define INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER_IID    "/cli/gui/iWin32WindowHolder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iWin32WindowHolder
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER
       #define INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER    ::cli::gui::iWin32WindowHolder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iWin32WindowHolder
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER
       #define INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER    cli_gui_iWin32WindowHolder
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iWin32WindowHolder methods */
                CLIMETHOD(setWindow) (THIS_ HWND    hwnd /* [in] hwnd_win32  hwnd  */) PURE;
                CLIMETHOD(getWindow) (THIS_ HWND*    hwnd /* [out] hwnd_win32 hwnd  */) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iWin32WindowHolder >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iWin32WindowHolder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iWin32WindowHolder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iWin32WindowHolder wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER >
                                          */
                     >
            class CiWin32WindowHolderWrapper
            {
                public:
            
                    typedef  CiWin32WindowHolderWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiWin32WindowHolderWrapper() :
                       pif(0) {}
            
                    CiWin32WindowHolderWrapper( iWin32WindowHolder *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiWin32WindowHolderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiWin32WindowHolderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiWin32WindowHolderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiWin32WindowHolderWrapper(const CiWin32WindowHolderWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiWin32WindowHolderWrapper()  { }
            
                    CiWin32WindowHolderWrapper& operator=(const CiWin32WindowHolderWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE setWindow( HWND    hwnd /* [in] hwnd_win32  hwnd  */)
                       {
                    
                        return pif->setWindow(hwnd);
                       }
                    
                    RCODE getWindow( HWND*    hwnd /* [out] hwnd_win32 hwnd  */)
                       {
                    
                        return pif->getWindow(hwnd);
                       }
                    

            
            
            }; // class CiWin32WindowHolderWrapper
            
            typedef CiWin32WindowHolderWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER     > >  CiWin32WindowHolder;
            typedef CiWin32WindowHolderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER > >  CiWin32WindowHolder_nrc; /* No ref counting for interface used */
            typedef CiWin32WindowHolderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER > >  CiWin32WindowHolder_tmp; /* for temporary usage, same as CiWin32WindowHolder_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif





#endif /* CLI_GUI_IMENUBUILDER_H */
