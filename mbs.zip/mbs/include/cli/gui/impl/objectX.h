#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_IMPL_OBJECTX_H
#define CLI_GUI_IMPL_OBJECTX_H

/* add this lines to your src
#ifndef CLI_GUI_IMPL_OBJECTX_H
    #include <cli/gui/impl/objectX.h>
#endif
*/

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_GUI_IOBJECTX_H
    #include <cli/gui/iObjectX.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif



namespace cli
{
namespace gui
{
namespace impl
{



// not thread safe
class CObjectXImplBase : public INTERFACE_CLI_GUI_IOBJECTX
                       , public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
{

public:

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;


protected:

    struct CObjectDrawContextData
    {
         UINT    contextKey;
         UINT    contextWidth;
         UINT    contextHeight;
         VOID   *pContextData;  // use this to hold some data
         CObjectDrawContextData( UINT ck = 0, UINT cw = 0, UINT ch = 0, VOID *p = 0)
            : contextKey(ck), contextWidth(cw), contextHeight(ch), pContextData(p) {}

         bool operator< ( const CObjectDrawContextData &d ) const { return contextKey <  d.contextKey; }
         bool operator> ( const CObjectDrawContextData &d ) const { return contextKey >  d.contextKey; }
         bool operator==( const CObjectDrawContextData &d ) const { return contextKey == d.contextKey; }
         bool operator!=( const CObjectDrawContextData &d ) const { return contextKey == d.contextKey; }
    };

private:

    struct COwnerData
    {
        typedef ::cli::util::CAutoSortVector<CObjectDrawContextData>    autosort_vector_t;

        INTERFACE_CLI_GUI_IOWNEROBJECTX                           *pOwner;
        autosort_vector_t                                          contextData;

        COwnerData( INTERFACE_CLI_GUI_IOWNEROBJECTX *po ) : pOwner(po), contextData() {}
        COwnerData(const COwnerData &o) : pOwner(o.pOwner), contextData(o.contextData) {}

        COwnerData& operator=( const COwnerData &o )
           {
            if (&o==this) return *this;
            pOwner = o.pOwner;
            autosort_vector_t tmp(o.contextData);
            contextData.swap(tmp);
            return *this;
           }

        bool operator==(const COwnerData &o) const { return pOwner==o.pOwner; }
        bool operator!=(const COwnerData &o) const { return pOwner!=o.pOwner; }
        bool operator< (const COwnerData &o) const { return pOwner< o.pOwner; }
        bool operator> (const COwnerData &o) const { return pOwner> o.pOwner; }

        bool eraseContext( CObjectXImplBase *pOwnerDataHolder, UINT contextKey )
           {
            autosort_vector_t::iterator it = contextData.find( contextKey );
            if (it==contextData.end()) return false;
            if (pOwnerDataHolder) pOwnerDataHolder->onContextDelete( &(*it) );
            contextData.erase(it);
            return true;
           }

        bool eraseContextByPos( CObjectXImplBase *pOwnerDataHolder, SIZE_T pos )
           {
            if (pos>=contextData.size()) return false;
            if (pOwnerDataHolder) pOwnerDataHolder->onContextDelete( &contextData[pos] );
            contextData.erase(contextData.begin()+pos);
            return true;
           }

        CObjectDrawContextData* findContext( UINT contextKey )
           {
            autosort_vector_t::iterator it = contextData.find( contextKey );
            if (it==contextData.end()) return 0;
            return &(*it);
           }

        CObjectDrawContextData* addContext( CObjectXImplBase *pOwnerDataHolder, UINT contextKey, VOID *pData, bool *pCreatedNew = 0)
           {
            CObjectDrawContextData* pContext = findContext( contextKey );
            if (pContext) 
               {
                if (pCreatedNew) *pCreatedNew = false;
                return pContext;
               }
            //SIZE_T size = contextData.size();
            contextData.push_back( CObjectDrawContextData(contextKey, 0, 0, pData ) );
            if (pCreatedNew) *pCreatedNew = true;
            return findContext( contextKey );
           }
    };


    ::cli::util::CAutoSortVector< COwnerData >      owners;

protected:

    void clearOwnerContexts( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner )
       {
        ::cli::util::CAutoSortVector< COwnerData >::iterator it = owners.find( COwnerData(pOwner) );
        if (it==owners.end()) return;
        while(it->eraseContextByPos( this, 0 )) {}
       }

    void eraseOwner( INTERFACE_CLI_GUI_IOWNEROBJECTX* pOwner )
       {
        ::cli::util::CAutoSortVector< COwnerData >::iterator it = owners.find( COwnerData(pOwner) );
        if (it==owners.end()) return;
        while(it->eraseContextByPos( this, 0 )) {}
        owners.erase( it );
       }

    void eraseOwnerByPos( SIZE_T pos )
       {
        if (pos>=owners.size()) return;
        while(owners[pos].eraseContextByPos( this, 0 )) {}
        owners.erase( owners.begin() + pos );
       }

    void eraseContext( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner, UINT contextKey )
       {
        ::cli::util::CAutoSortVector< COwnerData >::iterator it = owners.find( COwnerData(pOwner) );
        if (it==owners.end()) return;
        it->eraseContext( this, contextKey );
       }

    void eraseContextByPos( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner, SIZE_T pos )
       {
        ::cli::util::CAutoSortVector< COwnerData >::iterator it = owners.find( COwnerData(pOwner) );
        if (it==owners.end()) return;
        it->eraseContextByPos( this, pos );
       }

    CObjectDrawContextData* findContext( INTERFACE_CLI_GUI_IOWNEROBJECTX* pOwner, UINT contextKey )
       {
        ::cli::util::CAutoSortVector< COwnerData >::iterator it = owners.find( COwnerData(pOwner) );
        if (it==owners.end()) return 0;
        return it->findContext( contextKey );
       }

    CObjectDrawContextData* addContext( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner, UINT contextKey, VOID *pData, bool *pCreatedNew = 0)
       {
        COwnerData od(pOwner);
        ::cli::util::CAutoSortVector< COwnerData >::iterator it = owners.find( od );
        if (it==owners.end())
           {
            if (pCreatedNew) *pCreatedNew = true;
            owners.push_back( od );
            it = owners.find( od );
           }
        return it->addContext( this, contextKey, pData, pCreatedNew );
       }

    void addOwner( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner, bool *pCreatedNew = 0)
       {
        COwnerData od(pOwner);
        ::cli::util::CAutoSortVector< COwnerData >::iterator it = owners.find( od );
        if (it==owners.end())
           {
            if (pCreatedNew) *pCreatedNew = true;
            owners.push_back( od );
            return;
           }
        if (pCreatedNew) *pCreatedNew = false;
       }

    SIZE_T ownersCount() const { return owners.size(); }

    void invalidateViews( BOOL forceRepaint = TRUE, INTERFACE_CLI_GUI_IOWNEROBJECTX *exceptOwner = 0 )
       {
        ::cli::util::CAutoSortVector< COwnerData >::const_iterator it = owners.begin();
        for(; it != owners.end(); ++it)
           {
            if (!it->pOwner) continue;
            if (it->pOwner==exceptOwner) continue;
            it->pOwner->invalidateObjectView( forceRepaint );
           }
       }

    //::cli::util::CKeyTuple<>

public:

    CObjectXImplBase() : INTERFACE_CLI_GUI_IOBJECTX(), base_impl(DEF_MODULE) {}
    ~CObjectXImplBase()
       {
        while(owners.size()) eraseOwnerByPos( 0 );
       }

    // CLIMETHOD(initObject) (THIS_ INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX*    pDefParser /* [in,optional] ::cli::gui::iDefinitionParserObjectX*  pDefParser  */)
    CLIMETHOD(addObjectOwner) (THIS_ INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */)
       {
        bool firstOwner = owners.empty();
        if (firstOwner) onFirstOwnerAdding( pOwner, false );
        addOwner( pOwner );
        if (firstOwner) onFirstOwnerAdding( pOwner, true  );
        return EC_OK;
       }

    CLIMETHOD(removeObjectOwner) (THIS_ INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */)
       {
        bool lastOwner = owners.size()==1;
        if (lastOwner) onLastOwnerRemoving( pOwner, false );
        eraseOwner(pOwner);
        if (lastOwner) onLastOwnerRemoving( pOwner, true );
        return EC_OK;
       }

    // implement in childs
    virtual void onContextDelete( CObjectDrawContextData* pContextData ) {}
    virtual void onFirstOwnerAdding( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner
                                   , bool fAfter // called twice, one time before object added, one time after
                                   ) {}
    virtual void onLastOwnerRemoving( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner
                                   , bool fAfter // called twice, one time before object removed, one time after
                                   ) {}




    #if 0
    CLIMETHOD(drawObject) (THIS_ INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */
                               , UINT    key /* [in] uint  key  */
                               , INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pDc /* [in] ::cli::drawing::iDrawContext1*  pDc  */
                          )
    #endif
};


}; // namespace impl
}; // namespace gui
}; // namespace cli


#endif /* CLI_GUI_IMPL_OBJECTX_H */

