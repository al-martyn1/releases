#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_WX_INPUT_H
#define CLI_GUI_WX_INPUT_H

/* add this lines to your src
#ifndef CLI_GUI_WX_INPUT_H
    #include <cli/gui/wx/input.h>
#endif
*/

#ifndef CLI_GUI_IINPUT_H
    #include <cli/gui/iinput.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#include <wx/utils.h>

// ::wxGetColourFromUser
#include <wx/colordlg.h>

// ::wxGetFontFromUser
#include <wx/fontdlg.h>

// ::wxGetMultipleChoices
#include <wx/choicdlg.h>

// ::wxGetNumberFromUser
#include <wx/numdlg.h>

// ::wxGetPasswordFromUser
// ::wxGetTextFromUser
#include <wx/textdlg.h>


// #include 

/*

::wxAboutBox
::wxBeginBusyCursor
::wxBell
::wxCreateFileTipProvider
::wxDirSelector
::wxFileSelector
::wxEndBusyCursor
::wxGenericAboutBox
::wxGetMultipleChoices
::wxGetNumberFromUser
::wxGetPasswordFromUser
::wxGetTextFromUser
::wxGetMultipleChoice
::wxGetSingleChoice
::wxGetSingleChoiceIndex
::wxGetSingleChoiceData
::wxIsBusy
::wxMessageBox
::wxShowTip

*/

// ::cli::gui::impl::wx::CSimpleInput

#define USE_CLI_GUI_SIMPLEINPUT()                                                                                     \
                    CLIMETHOD_(INTERFACE_CLI_GUI_ISIMPLEINPUT*, getSimpleInput) (THIS) { return &cli_gui_inputImpl; } \
                    ::cli::gui::impl::wx::CSimpleInput  cli_gui_inputImpl

#define INITIALIZE_CLI_GUI_SIMPLEINPUT() cli_gui_inputImpl(this)

//#define GET_CLI_GUI_SIMPLEINPUT()                                           \


namespace cli {
namespace gui {
namespace impl {
namespace wx {

struct CSimpleInput : public INTERFACE_CLI_GUI_ISIMPLEINPUT
{
    wxWindow *parent;
    //int       xPos;
    //int       yPos;

    CSimpleInput( wxWindow *p = 0) : INTERFACE_CLI_GUI_ISIMPLEINPUT(), parent(p) {}

    CLI_BEGIN_INTERFACE_MAP2(CSimpleInput, INTERFACE_CLI_GUI_ISIMPLEINPUT)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_ISIMPLEINPUT )
    CLI_END_INTERFACE_MAP(CSimpleInput)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return 1; }
    CLIMETHOD_(ULONG, release) (THIS)   { return 1; }

    wxString convertToWx( const ::std::wstring &str ) const
       {
        #if defined(UNICODE) || defined(_UNICODE)
        return wxString(str.c_str());
        #else
        return wxString(MARTY_CON::strToAnsi(str).c_str());
        #endif
       }

     ::std::wstring convertFromWx( const wxString &str ) const
       {
        #if defined(UNICODE) || defined(_UNICODE)
        return ::std::wstring(str.c_str());
        #else
        return ::std::wstring(MARTY_CON::strToWide(str.c_str()));
        #endif
       }

    CLIMETHOD(getTextFromUser) (THIS_ CLISTR*           text
                                    , const CLISTR*     message
                                    , const CLISTR*     title
                                    , const CLISTR*     defText
                                    , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                               )
       {
        CLI_TRY{
                ::std::wstring msg = stdstr(message);
                if (msg.empty()) msg = L"Enter text";
                ::std::wstring tit = stdstr(title);
                if (tit.empty()) tit = L"Text input";
                ::std::wstring def = stdstr(defText);

                wxString enteredText = ::wxGetTextFromUser( convertToWx(msg)
                                                          , convertToWx(tit)
                                                          , convertToWx(def)
                                                          , parent
                                                          , wxDefaultCoord
                                                          , wxDefaultCoord
                                                          , true
                                                          );
                if (enteredText.IsEmpty()) return EC_CANCEL;
                return ::cli::propertyGetImpl( text, convertFromWx(enteredText.c_str()) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getPasswordFromUser) (THIS_ CLISTR*           password
                                        , const CLISTR*     message
                                        , const CLISTR*     title
                                        , const CLISTR*     defPassword
                                        , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                                   )
       {
        CLI_TRY{
                ::std::wstring msg = stdstr(message);
                if (msg.empty()) msg = L"Enter password";
                ::std::wstring tit = stdstr(title);
                if (tit.empty()) tit = L"Password input";
                ::std::wstring def = stdstr(defPassword);

                wxString enteredText = ::wxGetPasswordFromUser( convertToWx(msg)
                                                              , convertToWx(tit)
                                                              , convertToWx(def)
                                                              , parent
                                                              , wxDefaultCoord
                                                              , wxDefaultCoord
                                                              , true
                                                              );
                if (enteredText.IsEmpty()) return EC_CANCEL;
                return ::cli::propertyGetImpl( password, convertFromWx(enteredText.c_str()) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getNumberFromUser) (THIS_ INT*    num /* [out] int num  */
                                      , const CLISTR*     message
                                      , const CLISTR*     title
                                      , INT    defVal /* [in] int  defVal  */
                                      , INT    minVal /* [in] int  minVal  */
                                      , INT    maxVal /* [in] int  maxVal  */
                                      , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                                 )
       {
        CLI_TRY{
                ::std::wstring msg = stdstr(message);
                if (msg.empty()) msg = L"Enter number";
                ::std::wstring tit = stdstr(title);
                if (tit.empty()) tit = L"Number input";

                INT val = ::wxGetNumberFromUser( convertToWx(msg)
                                               , wxString() // prompt
                                               , convertToWx(tit)
                                               , defVal
                                               , minVal
                                               , maxVal
                                               , parent
                                               , wxDefaultPosition
                                               );
                if (val<0) return EC_CANCEL;
                return ::cli::propertyGetImpl( num, val );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


// ::wxGetNumberFromUser
// ::wxGetPasswordFromUser
// ::wxGetTextFromUser


};



}; // namespace cli
}; // namespace gui
}; // namespace impl
}; // namespace wx



#endif /* CLI_GUI_WX_INPUT_H */

