#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_WX_TYPESHELPERS_H
#define CLI_GUI_WX_TYPESHELPERS_H

/* add this lines to your src
#ifndef CLI_GUI_WX_TYPESHELPERS_H
    #include <cli/gui/wx/typesHelpers.h>
#endif
*/

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

// requires WX headers must be allready included 

namespace cli
{
namespace gui
{
namespace wx
{

inline
void checkMiceButtonState( const wxMouseEvent& event, BYTE &btnState, int btn, bool downState )
   {
    if (event.ButtonDClick(btn))
       {
        btnState = CLI_GUI_EMICEBUTTONSTATE_DBLCLICK;
       }
    else if (event.Button(btn))
       {
        btnState = CLI_GUI_EMICEBUTTONSTATE_CLICK;
       }
    else if (event.ButtonDown(btn))
       {
        btnState = CLI_GUI_EMICEBUTTONSTATE_DOWN;
       }
    else if (event.ButtonUp(btn))
       {
        btnState = CLI_GUI_EMICEBUTTONSTATE_UP;
       }
    else if (downState)
       {
        btnState = CLI_GUI_EMICEBUTTONSTATE_FDOWN;
       }
    else
       btnState = CLI_GUI_EMICEBUTTONSTATE_CLEAR;
   }


inline
STRUCT_CLI_GUI_CMICEBUTTONSSTATE makeMiceButtonState( const wxMouseEvent& event )
   {
    STRUCT_CLI_GUI_CMICEBUTTONSSTATE btnState = { 0 };

    // test keyboard keys state
    if (event.AltDown()) // alt pressed or released
       {
        if (event.m_altDown)
           btnState.alt = CLI_GUI_EMICEBUTTONSTATE_DOWN;
        else
           btnState.alt = CLI_GUI_EMICEBUTTONSTATE_UP;
       }
    else // alt untouched
       {
        if (event.m_altDown)
           btnState.alt = CLI_GUI_EMICEBUTTONSTATE_FDOWN;
        else
           btnState.alt = CLI_GUI_EMICEBUTTONSTATE_CLEAR;       
       }

    if (event.ControlDown()) // ctrl pressed or released
       {
        if (event.m_controlDown)
           btnState.ctrl = CLI_GUI_EMICEBUTTONSTATE_DOWN;
        else
           btnState.ctrl = CLI_GUI_EMICEBUTTONSTATE_UP;
       }
    else // ctrl untouched
       {
        if (event.m_controlDown)
           btnState.ctrl = CLI_GUI_EMICEBUTTONSTATE_FDOWN;
        else
           btnState.ctrl = CLI_GUI_EMICEBUTTONSTATE_CLEAR;       
       }

    if (event.ShiftDown()) // shift pressed or released
       {
        if (event.m_shiftDown)
           btnState.shift = CLI_GUI_EMICEBUTTONSTATE_DOWN;
        else
           btnState.shift = CLI_GUI_EMICEBUTTONSTATE_UP;
       }
    else // shift untouched
       {
        if (event.m_shiftDown)
           btnState.shift = CLI_GUI_EMICEBUTTONSTATE_FDOWN;
        else
           btnState.shift = CLI_GUI_EMICEBUTTONSTATE_CLEAR;       
       }

    if (event.MetaDown()) // meta pressed or released
       {
        if (event.m_metaDown)
           btnState.meta = CLI_GUI_EMICEBUTTONSTATE_DOWN;
        else
           btnState.meta = CLI_GUI_EMICEBUTTONSTATE_UP;
       }
    else // meta untouched
       {
        if (event.m_metaDown)
           btnState.meta = CLI_GUI_EMICEBUTTONSTATE_FDOWN;
        else
           btnState.meta = CLI_GUI_EMICEBUTTONSTATE_CLEAR;       
       }

    // test mice buttons state
    checkMiceButtonState( event, btnState.left  , wxMOUSE_BTN_LEFT  , event.m_leftDown );
    checkMiceButtonState( event, btnState.right , wxMOUSE_BTN_RIGHT , event.m_rightDown );
    checkMiceButtonState( event, btnState.middle, wxMOUSE_BTN_MIDDLE, event.m_middleDown );

    btnState.reserved = CLI_GUI_EMICEBUTTONSTATE_CLEAR;
    return btnState;
   }

inline
STRUCT_CLI_GUI_CMICEWHEELSTATE
makeMiceWheelState( const wxMouseEvent& event )
   {
    STRUCT_CLI_GUI_CMICEWHEELSTATE wheelState;
    wheelState.distance  = event.GetWheelRotation();
    wheelState.delta     = event.GetWheelDelta();
    wheelState.lpa       = event.GetLinesPerAction();
    wheelState.reserved  = 0;
    return wheelState;
   }

}; // namespace wx
}; // namespace gui
}; // namespace cli



#endif /* CLI_GUI_WX_TYPESHELPERS_H */

