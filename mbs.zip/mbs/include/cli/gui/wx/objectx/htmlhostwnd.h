#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTWND_H
#define CLI_GUI_WX_OBJECTX_HTMLHOSTWND_H

/* add this lines to your src
#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTWND_H
    #include <cli/gui/wx/objectx/htmlhostwnd.h>
#endif
*/

#include <wx/html/htmlwin.h>

#include <wx/timer.h>

#ifndef CLI_GUI_IOBJECTX_H
    #include <cli/gui/iObjectX.h>
#endif

#ifndef CLI_GUI_WX_TYPESHELPERS_H
    #include <cli/gui/wx/typesHelpers.h>
#endif

#ifndef CLI_TIMER_H
    #include <cli/timer.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

//#include <cli/gui/wx/objectx/htmlhostcell.h>

namespace cli
{
namespace gui
{
namespace impl
{
namespace wx
{


//typedef ::cli::impl::CTimerImplAuto CWxHtmlTimerImpl;

// ::cli::gui::impl::wx::wxObjectXHtmlHostWindow

class  wxObjectXHtmlHostWindow;
class  wxObjectXHtmlCell;


struct CWxHtmlTimerImpl : public ::cli::impl::CTimerImplBase
{
    wxObjectXHtmlHostWindow *pOwnerHtml;

    CWxHtmlTimerImpl(wxObjectXHtmlHostWindow* poh) : ::cli::impl::CTimerImplBase(), pOwnerHtml(poh)
    {
    }

    CLI_BEGIN_INTERFACE_MAP(CWxHtmlTimerImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ITIMER )
    CLI_END_INTERFACE_MAP(CWxHtmlTimerImpl)

    // use this class as automatic object
    CLIMETHOD_(ULONG, addRef) (THIS)    { return 1; }
    CLIMETHOD_(ULONG, release) (THIS)   { return 1; }

    INTERFACE_CLI_ITIMER* getSelfInterface()
       {
        return static_cast<INTERFACE_CLI_ITIMER*>(this);
       }

    void checkStartOwnerTimer();
    void makeShot()
       {
        ::cli::impl::CTimerImplBase::makeShot();
        checkStartOwnerTimer();
       }

    CLIMETHOD(addTimerHandler) (THIS_ INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                    , SIZE_T    id /* [in] size_t  id  */
                                    , TICK_T    timeout /* [in] tick_t  timeout  */
                                    , BOOL    oneShot /* [in] bool  oneShot  */
                               )
       {
        RCODE res = ::cli::impl::CTimerImplBase::addTimerHandler( pHandler, id, timeout, oneShot );
        if (!res)
            checkStartOwnerTimer();
        return res;
       }

    CLIMETHOD(removeTimerHandler) (THIS_ INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                       , SIZE_T    id /* [in] size_t  id  */
                                  )
       {
        RCODE res = ::cli::impl::CTimerImplBase::removeTimerHandler( pHandler, id );
        if (!res)
            checkStartOwnerTimer();
        return res;
       }


}; // struct CWxTimerImplAuto






class  /* WXDLLIMPEXP_HTML */  wxObjectXHtmlHostWindow : public wxHtmlWindow
{
public:

    wxObjectXHtmlHostWindow() 
       : wxHtmlWindow()
       , pLastHoveredCell(0)
       , pTimer(0)
       , timerImpl( this )
       , objectsById()
       , uninitializedObjects()
       , autogenerateIdMap()
       {}

    wxObjectXHtmlHostWindow(wxWindow *parent, wxWindowID id = wxID_ANY,
                 const wxPoint& pos = wxDefaultPosition,
                 const wxSize& size = wxDefaultSize,
                 long style = wxHW_DEFAULT_STYLE,
                 const wxString& name = wxT("ObjectXHtmlHostWindow"))
       : wxHtmlWindow(parent,id,pos,size,style,name)
       , pLastHoveredCell(0)
       , pTimer(0)
       , timerImpl( this )
       , objectsById()
       , uninitializedObjects()
       , autogenerateIdMap()
       {}

    wxHtmlCell * FindCellByPos( int x, int y)
       {
        if (!m_Cell) return m_Cell;
        return m_Cell->FindCellByPos(x, y);
       }

    void stopTimer()
       {
        if (pTimer) pTimer->Stop();
        delete pTimer;
        pTimer = 0;
       }

    void startTimer()
       {
        if (!pTimer) pTimer = new wxTimer( this, wxID_ANY );
        pTimer->Start( 10, false );
       }

    void OnTimer(wxTimerEvent& event)
       {
        timerImpl.makeShot();
       }

    INTERFACE_CLI_ITIMER* getTimerInterface() { return &timerImpl; };


    virtual void getHighlightColorScaling( int *pMult, int *pDdiv ) const
       {
        if (pMult) *pMult = 115;
        if (pDdiv) *pDdiv = 100;        
       }


    ::std::wstring generateId( const ::std::wstring &xid, const ::std::wstring &objClassName)
       {
        if (!xid.empty()) return xid;
        ::std::map< ::std::wstring, SIZE_T >::iterator it = autogenerateIdMap.find(objClassName);
        if (it==autogenerateIdMap.end())
           {
            autogenerateIdMap[objClassName] = 1;
            return objClassName + ::std::wstring(L"0");
           }

        return ::cli::format::message(L"%1%2", ::cli::format::arg(objClassName) % (UINT)autogenerateIdMap[objClassName]++);
       }

    INTERFACE_CLI_GUI_IOBJECTX* findObjectById( const ::std::wstring &xid, SIZE_T *pDrawIdBase = 0)
       {
        ::cli::util::CAutoSortVector<CXIdInfo>::const_iterator it = objectsById.find(xid);
        if (it==objectsById.end()) return 0;
        if (*pDrawIdBase)
           *pDrawIdBase = it->drawIdBase;
        return it->pObject;
       }

    INTERFACE_CLI_GUI_IOBJECTX* findObjectByIdAndGenerateDrawId( const ::std::wstring &xid, SIZE_T *pDrawIdBase = 0)
       {
        ::cli::util::CAutoSortVector<CXIdInfo>::iterator it = objectsById.find(xid);
        if (it==objectsById.end()) return 0;
        it->drawIdBase += 16;
        if (*pDrawIdBase)
           *pDrawIdBase = it->drawIdBase;
        return it->pObject;
       }

    void addObjectWithId( const ::std::wstring &xid, INTERFACE_CLI_GUI_IOBJECTX *pObj )
       {
        objectsById.push_back( CXIdInfo(xid,pObj,0) );
       }

    void addUninitializedCell( const ::std::wstring &xrefTo, wxObjectXHtmlCell *pCell )
       {
        uninitializedObjects.push_back( CUninitializedObjectInfo(xrefTo,pCell));
       }

    void doPostParseInitialization();

protected:

    void doOnHtmlCellHover( wxHtmlCell *pCell
                          , const wxPoint &micePos
                          , const wxPoint &cellPos
                          , const STRUCT_CLI_GUI_CMICEBUTTONSSTATE &miceButtonState
                          , const STRUCT_CLI_GUI_CMICEWHEELSTATE   &miceWheelState
                          );

    void OnMouseEvent(wxMouseEvent& event)
       {
        event.Skip(true);

        int stx = 0, sty = 0;
        GetViewStart(&stx, &sty);
        int ppuX = 1, ppuY = 1;
        GetScrollPixelsPerUnit( &ppuX, &ppuY );        
        int posX = event.m_x + stx*ppuX; // '-' changed to '+'
        int posY = event.m_y + sty*ppuY;
        wxPoint pntMicePos(posX,posY);
        wxPoint pntCellPos = pntMicePos;
        wxHtmlCell *pCell = FindCellByPos(posX, posY);
        if (pCell)
           {
            wxPoint absPos = pCell->GetAbsPos();
            pntCellPos.x -= absPos.x;
            pntCellPos.y -= absPos.y;
           }

        doOnHtmlCellHover( pCell, pntMicePos, pntCellPos
                         , ::cli::gui::wx::makeMiceButtonState( event )
                         , ::cli::gui::wx::makeMiceWheelState ( event )
                         );
        //::cli::format::cli_log::message(L"wxMouseEvent   , point: %1,%2, cell coord: %3,%4", ::cli::format::arg(pntMicePos.x) % pntMicePos.y % pntCellPos.x % pntCellPos.y );

        //wxLogMessage(wxT("OnMouseEvent: mice: %d,%d; start: %d,%d; ppu: %d,%d; mapped mice: %d,%d")
        //            , event.m_x, event.m_y, stx, sty, ppuX, ppuY, posX, posY );

       }



private:
    // any class wishing to process wxWidgets events must use this macro
    DECLARE_EVENT_TABLE()

    wxHtmlCell      *pLastHoveredCell;
    wxTimer         *pTimer;

//protected:

    CWxHtmlTimerImpl timerImpl;

    struct CXIdInfo
    {
        ::std::wstring                    xid;
        INTERFACE_CLI_GUI_IOBJECTX       *pObject;
        SIZE_T                            drawIdBase;

        CXIdInfo( const ::std::wstring &_xid = ::std::wstring()
                , INTERFACE_CLI_GUI_IOBJECTX *po = 0
                , SIZE_T ctxBase = 0
                )
           : xid(_xid)
           , pObject(po)
           , drawIdBase(ctxBase)
           {}

        bool operator==(const CXIdInfo &idInfo ) const { return xid==idInfo.xid; }
        bool operator!=(const CXIdInfo &idInfo ) const { return xid!=idInfo.xid; }
        bool operator< (const CXIdInfo &idInfo ) const { return xid< idInfo.xid; }
        bool operator> (const CXIdInfo &idInfo ) const { return xid> idInfo.xid; }
                                                   
    };

    struct CUninitializedObjectInfo
    {
        ::std::wstring                    xid;   // x-ref to
        wxObjectXHtmlCell                *pCell;

        CUninitializedObjectInfo( const ::std::wstring &_xid = ::std::wstring(), wxObjectXHtmlCell *pc = 0)
           : xid(_xid), pCell(pc) {}

        bool operator==(const CUninitializedObjectInfo &idInfo ) const { return xid==idInfo.xid; }
        bool operator!=(const CUninitializedObjectInfo &idInfo ) const { return xid!=idInfo.xid; }
        bool operator< (const CUninitializedObjectInfo &idInfo ) const { return xid< idInfo.xid; }
        bool operator> (const CUninitializedObjectInfo &idInfo ) const { return xid> idInfo.xid; }
    };


    ::cli::util::CAutoSortVector<CXIdInfo>                  objectsById;  // all objects stored here, may be not unique
    //::cli::util::CAutoSortVector<CUninitializedObjectInfo>  uninitializedObjects;
    ::std::vector<CUninitializedObjectInfo>                 uninitializedObjects;
    ::std::map< ::std::wstring, SIZE_T >                    autogenerateIdMap;

}; // wxObjectXHtmlHostWindow





inline
void CWxHtmlTimerImpl::checkStartOwnerTimer()
   {
    if (isShotsNeeded())
       {
        if (pOwnerHtml) pOwnerHtml->startTimer();
       }
    else
       {
        if (pOwnerHtml) pOwnerHtml->stopTimer();
       }
   }



}; // namespace wx
}; // namespace impl
}; // namespace gui
}; // namespace cli


#endif /* CLI_GUI_WX_OBJECTX_HTMLHOSTWND_H */

