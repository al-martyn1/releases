
#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTCELL_H
#define CLI_GUI_WX_OBJECTX_HTMLHOSTCELL_H

/* add this lines to your src
#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTCELL_H
    #include <cli/gui/wx/objectx/htmlhostcell.h>
#endif
*/

#include <wx/html/htmlcell.h>

#ifndef CLI_GUI_IOBJECTX_H
    #include <cli/gui/iObjectX.h>
#endif

/*
#ifndef CLI_GUI_WX_OBJECTX_DEFPARSERTAGIMPL_H
    #include <cli/gui/wx/objectx/defparsertagimpl.h>
#endif
*/

#ifndef CLI_ITIMER_H
    #include <cli/itimer.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_DRAWING_DCAUTO_H
    #include <cli/drawing/dcauto.h>
#endif

#ifndef CLI_DRAWING_IMPL_DC1WIN_H
    #include <cli/drawing/impl/dc1wx.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif


#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTWND_H
    #include <cli/gui/wx/objectx/htmlhostwnd.h>
#endif


namespace cli
{
namespace gui
{
namespace impl
{
namespace wx
{

// ::cli::gui::impl::wx::wxObjectXHtmlCellBase

class  /* WXDLLIMPEXP_HTML */  wxObjectXHtmlCellBase : public wxHtmlCell
{
public:

    static const unsigned fHighlight = 1;
    static const unsigned fEnlarge   = 2;

    void initHelper( const wxSize &size )
       {
        if (m_Margins.left  <0) m_Margins.left   = 0;
        if (m_Margins.top   <0) m_Margins.top    = 0;
        if (m_Margins.right <0) m_Margins.right  = 0;
        if (m_Margins.bottom<0) m_Margins.bottom = 0;

        m_Width  = size.x;
        m_Height = size.y;
        //wxSize size = _size;
        if (m_Width  < (m_Margins.left + m_Margins.right ) ) m_Width  = (m_Margins.left + m_Margins.right);
        if (m_Height < (m_Margins.top  + m_Margins.bottom) ) m_Height = (m_Margins.top  + m_Margins.bottom);

        if (m_Animate<0) m_Animate = -m_Animate;
       }

    //wxObjectXHtmlCellBase(wxWindow *wnd, int w = 0);
    wxObjectXHtmlCellBase( wxWindow                  *pRenderWindow
                     , const wxSize                  &size
                     , const STRUCT_CLI_GUI_CMARGINS &Margins
                     , unsigned                      _flags
                     , int                           Animate
                     )
       : wxHtmlCell()
       , m_Margins(Margins)
       , flags(_flags)
       //, m_HoverHighLight(HoverHighLight)
       //, m_HoverEnlarge(HoverEnlarge)
       , m_hover(false)
       , m_Animate(Animate)
       , m_hoverChanging(false)
       , m_hoverChangingEnlarge(false)
       , m_pRenderWindow(pRenderWindow)
       //, highlightColorScaleMultiplier(100)
       //, highlightColorScaleDivisor(100)
       //, drawIdBase(0)
       //, cacheBitmap()
       {
        initHelper(size);
        //m_WidthFloat = 0;
       }

    virtual ~wxObjectXHtmlCellBase() {  /* m_Wnd->Destroy(); */  }

/*
    void setHighlightColorScaling( int mult, int div )
       {
        highlightColorScaleMultiplier = mult;
        highlightColorScaleDivisor    = div;
       }
*/
    void getCellSizes( bool bEnlarge
                     , int &relX
                     , int &relY
                     , int &w
                     , int &h
                     ) const
       {
        relX   = bEnlarge ? 0 : m_Margins.left ;
        relY   = bEnlarge ? 0 : m_Margins.top  ;
        w      = bEnlarge ? m_Width  : m_Width  - m_Margins.left - m_Margins.right;
        h      = bEnlarge ? m_Height : m_Height - m_Margins.top  - m_Margins.bottom;
       }

    void getCellSizesStep( int stepNo
                     , int &relX
                     , int &relY
                     , int &w
                     , int &h
                     ) const
       {
        relX   = m_Margins.left * (m_Animate-stepNo) / m_Animate;
        relY   = m_Margins.top  * (m_Animate-stepNo) / m_Animate;
        int min_width    = m_Width  - (m_Margins.left + m_Margins.right );
        int min_height   = m_Height - (m_Margins.top  + m_Margins.bottom);
        int delta_width  = (m_Width - min_width  ) * stepNo / m_Animate;
        int delta_height = (m_Height - min_height) * stepNo / m_Animate;
        w = min_width  + delta_width;
        h = min_height + delta_height;
       }

    virtual void DoDraw( wxDC& dc, int x, int y, int w, int h, bool drawHighlighted) = 0;

    virtual void Draw(wxDC& dc, int x, int y, int view_y1, int view_y2,
                      wxHtmlRenderingInfo& info)
       {
        /*
        int absx = 0, absy = 0, stx, sty;
        wxHtmlCell *c = this;
    
        while (c)
        {
            absx += c->GetPosX();
            absy += c->GetPosY();
            c = c->GetParent();
        }
        */
        wxPoint absPos = GetAbsPos();
        //bool bHighlight = m_hover && m_HoverHighLight;
        bool bEnlarge   = m_hover && (flags&fEnlarge); // m_HoverEnlarge;

        int relX   = 0; // bEnlarge ? 0 : m_Margins.left ;
        int relY   = 0; // bEnlarge ? 0 : m_Margins.top  ;
        int width  = 0; // bEnlarge ? m_Width  : m_Width  - m_Margins.left - m_Margins.right;
        int height = 0; // bEnlarge ? m_Height : m_Height - m_Margins.top  - m_Margins.bottom;

        #ifdef CLI_WX_XOBJECT_ALLOW_ANIMATE
        if (!m_hoverChanging || !m_Animate)
        #endif
           {
            getCellSizes( bEnlarge, relX, relY, width, height );
            DoDraw( dc, absPos.x + relX, absPos.y + relY, width, height, m_hover && (flags&fHighlight) );
            return;
           }

        #ifdef CLI_WX_XOBJECT_ALLOW_ANIMATE
        // animate changes        
        getCellSizes( m_hoverChangingEnlarge ? false : true, relX, relY, width, height );
        wxBitmap cacheBitmap( width, height );
        if (!cacheBitmap.Ok())
           {
            DoDraw( dc, absPos.x + relX, absPos.y + relY, width, height, m_hover && (flags&fHighlight) );
            return;
           }

        {
         wxMemoryDC tmpDc;
         tmpDc.SelectObject(cacheBitmap);
         tmpDc.Blit( 0  // xdest
                   , 0  // ydest
                   , width, height
                   , &dc
                   , absPos.x + relX  // xsrc
                   , absPos.y + relY  // ysrc
                   );
         tmpDc.SelectObject( wxNullBitmap );
        }

        if (m_hoverChangingEnlarge)
           { // enlarge
            for(int stepNo = 0; stepNo!=m_Animate; ++stepNo)
               {
                getCellSizesStep( stepNo, relX, relY, width, height );
                wxMemoryDC tmpDc;
                tmpDc.SelectObject( wxBitmap(cacheBitmap.ConvertToImage().Scale(width, height) ) );
                dc.Blit( absPos.x + relX, absPos.y + relY, width, height, &tmpDc, 0, 0 );
                tmpDc.SelectObject( wxNullBitmap );
                Sleep(200);
               }
           }
        else // reduce
           {
            for(int stepNo = m_Animate; stepNo!=0; --stepNo)
               {
                getCellSizesStep( stepNo, relX, relY, width, height );
                wxMemoryDC tmpDc;
                tmpDc.SelectObject( wxBitmap(cacheBitmap.ConvertToImage().Scale(width, height) ) );
                dc.Blit( absPos.x + relX, absPos.y + relY, width, height, &tmpDc, 0, 0 );
                tmpDc.SelectObject( wxNullBitmap );
                Sleep(200);
               }               
           }

        getCellSizes( m_hoverChangingEnlarge, relX, relY, width, height );
        DoDraw( dc, absPos.x + relX, absPos.y + relY, width, height, m_hover && (flags&fHighlight) );
        #endif
       }

    void getHighlightColorScaling( int *pMult, int *pDiv ) const
       {
        wxObjectXHtmlHostWindow *pHost = wxDynamicCast(m_pRenderWindow, wxObjectXHtmlHostWindow);
        if (pHost) pHost->getHighlightColorScaling( pMult, pDiv );
        else
           {
            if (pMult) *pMult = 100;
            if (pDiv) *pDiv = 100;
           }
       }

    void InvalidateCell( bool bForceRefresh = true)
       {
        if (!m_pRenderWindow) return;
        wxPoint absPos = GetAbsPos();

        int posX = absPos.x;
        int posY = absPos.y;

        wxScrolledWindow * pScrolledWindow = wxDynamicCast(m_pRenderWindow, wxScrolledWindow);
        if (pScrolledWindow)
           {
            int stx = 0, sty = 0;
            pScrolledWindow->GetViewStart(&stx, &sty);
            int ppuX = 1, ppuY = 1;
            pScrolledWindow->GetScrollPixelsPerUnit( &ppuX, &ppuY );
            posX -= (stx*ppuX);
            posY -= (sty*ppuY);
           }

        m_pRenderWindow->RefreshRect( wxRect( posX, posY, m_Width, m_Height ), true );
        //m_pRenderWindow->Refresh( true );
        if (bForceRefresh)
           m_pRenderWindow->Update();
       }

    void InvalidateAnimated( bool bBecomeEnlarge )
       {
        m_hoverChanging        = true;
        m_hoverChangingEnlarge = bBecomeEnlarge;
        InvalidateCell();
        m_hoverChanging = false;

        /*
        if (m_Animate)
           {

            ::cli::format::cli_log::message(L"-------------- InvalidateAnimated starts");
            m_hoverChangingEnlarge = bBecomeEnlarge;
            if (bBecomeEnlarge)
               {
                ::cli::format::cli_log::message(L"become enlarge");
                for(m_hoverChanging = 0; m_hoverChanging<=m_Animate; ++m_hoverChanging)
                   {
                    ::cli::format::cli_log::message(L"step: %1 from %2", ::cli::format::arg(m_hoverChanging) % m_Animate );
                    InvalidateCell();
                    Sleep(1500);
                   }
               }
            else
               {
                ::cli::format::cli_log::message(L"become reduce");
                for(m_hoverChanging = m_Animate; m_hoverChanging>=0; --m_hoverChanging)
                   {
                    ::cli::format::cli_log::message(L"step: %1 from %2", ::cli::format::arg(m_hoverChanging) % m_Animate );
                    InvalidateCell();
                    Sleep(1500);
                   }               
               }
            ::cli::format::cli_log::message(L"-------------- InvalidateAnimated ends");
            cacheBitmap = wxBitmap( 1, 1 );
            m_hoverChanging = -1;
           }
        else
           {
            InvalidateCell();
           }
        */
       }

    virtual void onMouseIn()
       {
        m_hover = true;
        InvalidateAnimated(true);
       }

    virtual void onMouseOver()
       {
       }

    virtual void onMouseOut()
       {
        m_hover = false;
        InvalidateAnimated(false);
       }

    virtual void DrawInvisible(wxDC& dc, int x, int y, wxHtmlRenderingInfo& info)
       {
       }
    //virtual void Layout(int w);

    // virtual void Refresh(bool eraseBackground = true, const wxRect* rect = NULL)
    // void RefreshRect(const wxRect& rect, bool eraseBackground = true)




/*
    virtual bool ProcessMouseClick(wxHtmlWindowInterface *window,
                                   const wxPoint& pos,
                                   const wxMouseEvent& event);
*/

protected:
    //wxWindow* m_Wnd;
    //int m_WidthFloat;
            // width float is used in adjustWidth (it is in percents)

    STRUCT_CLI_GUI_CMARGINS       m_Margins;
    unsigned                      flags;
    //bool           m_HoverHighLight;
    //bool           m_HoverEnlarge;
    bool           m_hover;
    int            m_Animate;
    bool           m_hoverChanging;
    bool           m_hoverChangingEnlarge;
    wxWindow      *m_pRenderWindow;
    //wxBitmap       cacheBitmap;

    int            highlightColorScaleMultiplier;
    int            highlightColorScaleDivisor;


public:

protected:

    DECLARE_ABSTRACT_CLASS(wxObjectXHtmlCellBase)
    DECLARE_NO_COPY_CLASS(wxObjectXHtmlCellBase)
};





class  /* WXDLLIMPEXP_HTML */  wxErrorXHtmlCell : public wxObjectXHtmlCellBase
{
public:

    wxErrorXHtmlCell( wxWindow                  *pRenderWindow
                     , const wxSize                  &size
                     , const STRUCT_CLI_GUI_CMARGINS &Margins
                     , unsigned                      _flags
                     , int                           Animate
                     , const wxString                &msg
                     )
       : wxObjectXHtmlCellBase(pRenderWindow, size, Margins, _flags, Animate )
       , errMessage(msg)
       {
       }

    void DoDraw( wxDC& dc, int x, int y, int w, int h, bool drawHighlighted)
       {
        wxColour drawColor = drawHighlighted ? wxColour(192, 0, 0) : wxColour(255, 0, 0);

        wxSize textSize = dc.GetTextExtent( errMessage );
        int textOffsetX = (w-textSize.x)/2;
        if (textOffsetX<0) textOffsetX = 0;
        int textOffsetY = (h-textSize.y)/2;
        if (textOffsetY<0) textOffsetY = 0;

        wxColour oldTextColor = dc.GetTextForeground();
        wxPen oldPen = dc.GetPen();

        dc.SetPen( wxPen(drawColor , 1, wxSOLID ) );
        dc.SetBrush(*wxTRANSPARENT_BRUSH);
        dc.SetTextForeground(drawColor);

        dc.DrawText( errMessage, x+textOffsetX, y+textOffsetY );
        dc.DrawLine( x, y, x+w, y+h );
        dc.DrawLine( x+w, y, x, y+h );
        dc.DrawRectangle( x, y, w, h );

        dc.SetTextForeground(oldTextColor);
        dc.SetPen( oldPen );
       }


protected:

    wxString    errMessage;
    DECLARE_ABSTRACT_CLASS(wxErrorXHtmlCell)
    DECLARE_NO_COPY_CLASS(wxErrorXHtmlCell)
};






class  /* WXDLLIMPEXP_HTML */  wxObjectXHtmlCell : public wxObjectXHtmlCellBase
                                                 , INTERFACE_CLI_GUI_IOWNEROBJECTX
                                                 , INTERFACE_CLI_ITIMER
{

    ::cli::gui::CiObjectX  ox;
    SIZE_T         drawIdBase;

public:

    CLI_BEGIN_INTERFACE_MAP2(wxObjectXHtmlCell, INTERFACE_CLI_GUI_IOWNEROBJECTX )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_IOWNEROBJECTX )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ITIMER )
    CLI_END_INTERFACE_MAP(wxObjectXHtmlCell)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return 1; }
    CLIMETHOD_(ULONG, release) (THIS)   { return 1; }

    CLIMETHOD(invalidateObjectView) (THIS_ BOOL    forceRepaint /* [in] bool  forceRepaint  */)
       {
        InvalidateCell( forceRepaint ? true : false );
        return EC_OK;
       }

    CLIMETHOD(getObjectById) (THIS_ const CLISTR*     id
                                  , INTERFACE_CLI_GUI_IOBJECTX**    pObject /* [out] ::cli::gui::iObjectX* pObject  */
                             )
       {
        if (!id || !pObject) return EC_INVALID_PARAM;
        wxObjectXHtmlHostWindow* pHost = wxDynamicCast(m_pRenderWindow, wxObjectXHtmlHostWindow);
        if (!pHost) return EC_NOT_SUPPORTED;
        ::std::wstring strId = stdstr(id);

        *pObject = pHost->findObjectById( strId, 0);
        if (*pObject) (*pObject)->addRef();

        return EC_OK;
       }

    CLIMETHOD(getObjectByIdChars) (THIS_ const WCHAR*    id /* [in,flat] wchar  id[]  */
                                       , INTERFACE_CLI_GUI_IOBJECTX**    pObject /* [out] ::cli::gui::iObjectX* pObject  */
                                  )
       {
        if (!id || !pObject) return EC_INVALID_PARAM;
        wxObjectXHtmlHostWindow* pHost = wxDynamicCast(m_pRenderWindow, wxObjectXHtmlHostWindow);
        if (!pHost) return EC_NOT_SUPPORTED;
        ::std::wstring strId = stdstr(id);

        *pObject = pHost->findObjectById( strId, 0);
        if (*pObject) (*pObject)->addRef();

        return EC_OK;
       }

    CLIMETHOD(generateNewDrawIdByObjectId) (THIS_ const CLISTR*     id
                                                , SIZE_T*    drawId /* [out] size_t drawId  */
                                           )
       {
        if (!id || !drawId) return EC_INVALID_PARAM;
        wxObjectXHtmlHostWindow* pHost = wxDynamicCast(m_pRenderWindow, wxObjectXHtmlHostWindow);
        if (!pHost) return EC_NOT_SUPPORTED;
        ::std::wstring strId = stdstr(id);

        if (pHost->findObjectByIdAndGenerateDrawId( strId, drawId ))
           return EC_OK;
        return EC_NOT_FOUND;
       }

    CLIMETHOD(generateNewDrawIdByObjectIdChars) (THIS_ const WCHAR*    id /* [in,flat] wchar  id[]  */
                                                     , SIZE_T*    drawId /* [out] size_t drawId  */
                                                )
       {
        if (!id || !drawId) return EC_INVALID_PARAM;
        wxObjectXHtmlHostWindow* pHost = wxDynamicCast(m_pRenderWindow, wxObjectXHtmlHostWindow);
        if (!pHost) return EC_NOT_SUPPORTED;
        ::std::wstring strId = stdstr(id);

        if (pHost->findObjectByIdAndGenerateDrawId( strId, drawId ))
           return EC_OK;
        return EC_NOT_FOUND;
       }

    CLIMETHOD(addTimerHandler) (THIS_ INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                    , SIZE_T    id /* [in] size_t  id  */
                                    , TICK_T    timeout /* [in] tick_t  timeout  */
                                    , BOOL    oneShot /* [in] bool  oneShot  */
                               )
       {
        wxObjectXHtmlHostWindow* pHost = wxDynamicCast(m_pRenderWindow, wxObjectXHtmlHostWindow);
        if (!pHost) return EC_NOT_SUPPORTED;
        return pHost->getTimerInterface()->addTimerHandler( pHandler, id, timeout, oneShot );
       }

    CLIMETHOD(removeTimerHandler) (THIS_ INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                       , SIZE_T    id /* [in] size_t  id  */
                                  )
       {
        wxObjectXHtmlHostWindow* pHost = wxDynamicCast(m_pRenderWindow, wxObjectXHtmlHostWindow);
        if (!pHost) return EC_NOT_SUPPORTED;
        return pHost->getTimerInterface()->removeTimerHandler( pHandler, id );
       }

    wxObjectXHtmlCell( wxWindow                  *pRenderWindow
                     , const wxSize                  &size
                     , const STRUCT_CLI_GUI_CMARGINS &Margins
                     , unsigned                      _flags
                     , int                           Animate
                     , INTERFACE_CLI_GUI_IOBJECTX   *pOx
                     , SIZE_T                        _drawIdBase
                     //, const wxString                &msg
                     )
       : wxObjectXHtmlCellBase(pRenderWindow, size, Margins, _flags, Animate )
       , INTERFACE_CLI_GUI_IOWNEROBJECTX()
       , INTERFACE_CLI_ITIMER()
       //, errMessage(msg)
       , ox(pOx)
       , drawIdBase(_drawIdBase)
       {
        ox.addObjectOwner( static_cast<INTERFACE_CLI_GUI_IOWNEROBJECTX*>(this) );
       }

    wxObjectXHtmlCell( wxWindow                  *pRenderWindow
                     , const wxSize                  &size
                     , const STRUCT_CLI_GUI_CMARGINS &Margins
                     , unsigned                      _flags
                     , int                           Animate
                     )
       : wxObjectXHtmlCellBase(pRenderWindow, size, Margins, _flags, Animate )
       , INTERFACE_CLI_GUI_IOWNEROBJECTX()
       , INTERFACE_CLI_ITIMER()
       //, errMessage(msg)
       , ox()
       , drawIdBase(0)
       {
       }

    void setObject( INTERFACE_CLI_GUI_IOBJECTX   *pOx, SIZE_T _drawIdBase )
       {
        if (pOx)  ox = pOx;
        if (!!ox) ox.addObjectOwner( static_cast<INTERFACE_CLI_GUI_IOWNEROBJECTX*>(this) );
        drawIdBase = _drawIdBase;
        InvalidateCell( true );
       }

    ~wxObjectXHtmlCell()
       {
        if (!!ox) ox.removeObjectOwner( static_cast<INTERFACE_CLI_GUI_IOWNEROBJECTX*>(this) );
       }

    void DoDraw( wxDC& dc, int x, int y, int w, int h, bool drawHighlighted)
       {
        if (!ox)
           {
            wxErrorXHtmlCell *pErrCell = new wxErrorXHtmlCell( m_pRenderWindow
                                                            , wxSize( m_Width+m_Margins.left+m_Margins.right, m_Height+m_Margins.top+m_Margins.bottom )
                                                            , m_Margins
                                                            , flags
                                                            , m_Animate
                                                            , wxString(wxT("<BAD X-REF>"))
                                                            );
            pErrCell->DoDraw( dc, x, y, w, h, drawHighlighted);
            delete pErrCell;
            return;
           }
        using namespace ::cli::drawing::impl::wx;

        ::cli::drawing::CPoint size, leftTop;
        leftTop.x = x;
        leftTop.y = y;
        size.x = w;
        size.y = h;

        CDrawContext1Impl<wxDC /* , wxdrawPanel */ > dcImpl;
        //dcImpl.attachClientDC(dc, this);
        dcImpl.attachDC(dc, leftTop, size );

        if (drawHighlighted)
           {
            int mult = 100;
            int div  = 100;
            getHighlightColorScaling( &mult, &div );
            dcImpl.setColorScaling( mult, div );
           }

        leftTop.x = 0;
        leftTop.y = 0;
        ::cli::drawing::dc::CAutoViewport vp( &dcImpl, leftTop, size );

        // drawHighlighted
        bool bEnlarge   = m_hover && (flags&fEnlarge); // m_HoverEnlarge;
        dcImpl.pushSetNullBrush( );
        ox.drawObject( static_cast<INTERFACE_CLI_GUI_IOWNEROBJECTX*>(this) // INTERFACE_CLI_GUI_IOWNEROBJECTX
                     , drawIdBase + (bEnlarge ? 1 : 0) // context key
                     , &dcImpl 
                     );
        dcImpl.popBrush();
        //if (pDrawer) pDrawer->drawSample(&dcImpl, bUseAppConfig ? &appConfig : 0);
        dcImpl.detachDC();
       }

    virtual void onMouseIn()
       {
        m_hover = true;
        InvalidateAnimated(true);
       }

    virtual void onMouseOver()
       {
       }

    virtual void onMouseOut()
       {
        m_hover = false;
        InvalidateAnimated(false);
       }

protected:

    DECLARE_ABSTRACT_CLASS(wxObjectXHtmlCell)
    DECLARE_NO_COPY_CLASS(wxObjectXHtmlCell)
};











}; // namespace wx
}; // namespace impl
}; // namespace gui
}; // namespace cli


#endif /* CLI_GUI_WX_OBJECTX_HTMLHOSTCELL_H */

