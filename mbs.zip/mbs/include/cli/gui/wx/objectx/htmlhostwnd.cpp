#ifndef CLI_GUI_WX_OBJECTX_HTMLHOST_H
    #include <cli/gui/wx/objectx/htmlhostwnd.h>
#endif

#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTCELL_H
    #include <cli/gui/wx/objectx/htmlhostcell.h>
#endif


// Add to your source
// #include <cli/gui/wx/objectx/htmlhostwnd.cpp>


namespace cli
{
namespace gui
{
namespace impl
{
namespace wx
{

void wxObjectXHtmlHostWindow::doPostParseInitialization()
   {
    ::std::vector<CUninitializedObjectInfo>::iterator unit = uninitializedObjects.begin();
    for(; unit != uninitializedObjects.end(); ++unit)
       {
        SIZE_T newDrawId = 0;
        INTERFACE_CLI_GUI_IOBJECTX* pObject = findObjectByIdAndGenerateDrawId( unit->xid, &newDrawId );
        unit->pCell->setObject( pObject, newDrawId );
       }
    uninitializedObjects.clear();
    autogenerateIdMap.clear();
   }

void wxObjectXHtmlHostWindow::doOnHtmlCellHover( wxHtmlCell *pCell
                      , const wxPoint &micePos
                      , const wxPoint &cellPos
                      , const STRUCT_CLI_GUI_CMICEBUTTONSSTATE &miceButtonState
                      , const STRUCT_CLI_GUI_CMICEWHEELSTATE   &miceWheelState
                      )
   {
    bool cellChanged = false;
    if (pLastHoveredCell!=pCell)
       { // send onMouseOut()
        cellChanged = true;
        if (pLastHoveredCell)
           {
            ::cli::gui::impl::wx::wxObjectXHtmlCell * pObjectCell = wxDynamicCast(pLastHoveredCell, ::cli::gui::impl::wx::wxObjectXHtmlCell);
            if (pObjectCell) pObjectCell->onMouseOut();
           }
       }

    pLastHoveredCell = pCell;

    if (pLastHoveredCell)
       {
        ::cli::gui::impl::wx::wxObjectXHtmlCell * pObjectCell = wxDynamicCast(pLastHoveredCell, ::cli::gui::impl::wx::wxObjectXHtmlCell);
        if (pObjectCell)
           {
            if (cellChanged)
               pObjectCell->onMouseIn();
            else
               pObjectCell->onMouseOver();
           }
       }
   }



BEGIN_EVENT_TABLE(wxObjectXHtmlHostWindow , wxHtmlWindow)
    //EVT_MOUSE_EVENTS(wxObjectXHtmlHostWindow::OnMouseEvent)
    //EVT_HTML_CELL_HOVER(wxID_ANY, wxObjectXHtmlHostWindow::OnHtmlCellHover)
    EVT_MOUSE_EVENTS(wxObjectXHtmlHostWindow::OnMouseEvent)
    EVT_TIMER(wxID_ANY, wxObjectXHtmlHostWindow::OnTimer)
END_EVENT_TABLE()

}; // namespace wx
}; // namespace impl
}; // namespace gui
}; // namespace cli
