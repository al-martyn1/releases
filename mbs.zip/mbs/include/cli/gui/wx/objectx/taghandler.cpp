//#ifndef CLI_GUI_WX_OBJECTX_TAGHANDLER_H
//#define CLI_GUI_WX_OBJECTX_TAGHANDLER_H

/* add this lines to your src
#ifndef CLI_GUI_WX_OBJECTX_TAGHANDLER_H
    #include <cli/gui/wx/objectx/taghandler.h>
#endif

#include <cli/gui/wx/objectx/taghandler.cpp>
*/

#include <wx/wx.h>
#include <wx/html/htmlwin.h>
#include "wx/html/m_templ.h"

#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTCELL_H
    #include <cli/gui/wx/objectx/htmlhostcell.h>
#endif

#ifndef CLI_GUI_WX_OBJECTX_DEFPARSERTAGIMPL_H
    #include <cli/gui/wx/objectx/defparsertagimpl.h>
#endif

#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTCELL_H
    #include <cli/gui/wx/objectx/htmlhostcell.h>
#endif

#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTWND_H
    #include <cli/gui/wx/objectx/htmlhostwnd.h>
#endif

#include <marty/concvt.h>



TAG_HANDLER_BEGIN(HTMLXOBJECT, "X-OBJECT")

bool GetAttributeIntValue(const wxHtmlTag& tag, const wxString &attrName, int &iVal )
{
    if (tag.HasParam(attrName)) 
       {
        int tmp = 0;
        if (tag.ScanParam(attrName, wxT("%i"), &tmp)) 
           {
            iVal = tmp;
            return true;
           }
       }
    return false;
}


::std::wstring wxToWide( const wxString &str )
{
   #if defined(UNICODE) || defined(_UNICODE)
   return ::std::wstring( str.c_str() );
   #else
   return MARTY_CON::strToWide( str.c_str() );
   #endif
}


TAG_HANDLER_PROC(tag)
{

    STRUCT_CLI_GUI_CMARGINS margins;
    int xmargin = 0;
    GetAttributeIntValue( tag, wxT("X-MARGIN"), xmargin );
    margins.left   = xmargin;
    margins.top    = xmargin;
    margins.right  = xmargin;
    margins.bottom = xmargin;

    GetAttributeIntValue( tag, wxT("X-MARGIN-LEFT")  , margins.left   );
    GetAttributeIntValue( tag, wxT("X-MARGIN-RIGHT") , margins.right  );
    GetAttributeIntValue( tag, wxT("X-MARGIN-TOP")   , margins.top    );
    GetAttributeIntValue( tag, wxT("X-MARGIN-BOTTOM"), margins.bottom );

    int hoverHighLight = 0;
    GetAttributeIntValue( tag, wxT("X-HOVER-HIGHLIGHT"), hoverHighLight );

    int hoverEnlarge = 0;
    GetAttributeIntValue( tag, wxT("X-HOVER-ENLARGE"), hoverEnlarge );

    int animate = 0;
    GetAttributeIntValue( tag, wxT("X-HOVER-ENLARGE-ANIMATE"), animate );


    wxSize size;
    size.x  = 0;
    GetAttributeIntValue( tag, wxT("WIDTH"), size.x );
    size.y = 0;
    GetAttributeIntValue( tag, wxT("HEIGHT"), size.y );

    unsigned flags = 0;
    if (hoverHighLight>0) flags |= ::cli::gui::impl::wx::wxObjectXHtmlCellBase::fHighlight;
    if (hoverEnlarge  >0) flags |= ::cli::gui::impl::wx::wxObjectXHtmlCellBase::fEnlarge;

    using ::cli::gui::impl::wx::wxObjectXHtmlHostWindow;

    wxObjectXHtmlHostWindow *pHostWnd = wxDynamicCast( m_WParser->GetWindowInterface()->GetHTMLWindow()
                                                     , wxObjectXHtmlHostWindow
                                                     );

    wxString wxComponentClassName = tag.GetParam(wxT("X-CLASS-NAME"));
    wxString wxObjectId           = tag.GetParam(wxT("X-ID"));
    wxString wxObjectXRef         = tag.GetParam(wxT("X-REF"));
    wxHtmlCell *pNewCell = 0;
    /*
    #if defined(UNICODE) || defined(_UNICODE)
    ::std::string componentClassName = MARTY_CON::strToAnsi(wxComponentClassName.c_str());
    #else
    ::std::string componentClassName = wxComponentClassName.c_str();
    #endif
    */
    try{
        if (wxComponentClassName.IsEmpty() && wxObjectXRef.IsEmpty())
           throw ::std::runtime_error("<UNDEFCLS>");

        if (!wxObjectXRef.empty())
           {
            ::std::wstring xRef = wxToWide( wxObjectXRef );
            ::cli::gui::impl::wx::wxObjectXHtmlCell *pXCell = new ::cli::gui::impl::wx::wxObjectXHtmlCell( m_WParser->GetWindowInterface()->GetHTMLWindow()
                                                 , size, margins, flags, 0 // Animate
                                                 );

            if (pHostWnd)
               pHostWnd->addUninitializedCell( xRef, pXCell );
            pNewCell = pXCell;
           }
        else
           {
            ::std::wstring objId;
            if (pHostWnd)
               objId = pHostWnd->generateId( wxToWide(wxObjectId), wxToWide(wxComponentClassName));

            #if defined(UNICODE) || defined(_UNICODE)
            ::cli::gui::CiObjectX objectX( MARTY_CON::strToAnsi(wxComponentClassName.c_str()).c_str() );
            #else
            ::cli::gui::CiObjectX objectX( wxComponentClassName.c_str() );
            #endif
    
            ::cli::gui::impl::wx::CTagDefinitionParser tdp( &tag );
    
            if (!objectX.initObject(&tdp))
               { // init ok
                pNewCell = new ::cli::gui::impl::wx::wxObjectXHtmlCell( m_WParser->GetWindowInterface()->GetHTMLWindow()
                                               , size, margins, flags, 0 // Animate
                                               , objectX.getIfPtr()
                                               , 0 // drawCtxId
                                               );
                if (pHostWnd)
                   pHostWnd->addObjectWithId( objId, objectX.getIfPtr() );
               }
           }
       }
    catch( const ::std::runtime_error &e )
       {
        pNewCell = new ::cli::gui::impl::wx::wxErrorXHtmlCell( m_WParser->GetWindowInterface()->GetHTMLWindow()
                                       , size, margins, flags, 0 // Animate
                                       #if defined(UNICODE) || defined(_UNICODE)
                                       , wxComponentClassName + wxString(wxT(" - ")) + wxString( MARTY_CON::strToWide( e.what() ).c_str() )
                                       #else
                                       , wxComponentClassName + wxString(wxT("- ")) + wxString( e.what() ) 
                                       #endif
                                       );
       }
    catch(...)
       {
        pNewCell = new ::cli::gui::impl::wx::wxErrorXHtmlCell( m_WParser->GetWindowInterface()->GetHTMLWindow()
                                       , size, margins, flags, 0 // Animate
                                       , wxComponentClassName
                                       );
       }

    if (pNewCell) m_WParser->GetContainer()->InsertCell( pNewCell );

    //wxString GetParam(const wxString& par, bool with_commas = false) const

/*

    wxHtmlObjectCell *newCell = new wxHtmlObjectCell( m_WParser->GetWindowInterface()->GetHTMLWindow()
                    , size, margins
                    , hoverHighLight>0 ? true : false
                    , hoverEnlarge  >0 ? true : false
                    , animate
                    );

    m_WParser->GetContainer()->InsertCell( newCell );
*/
    return false;
}

TAG_HANDLER_END(HTMLXOBJECT)



TAGS_MODULE_BEGIN(CliObjectXBind)

    TAGS_MODULE_ADD(HTMLXOBJECT)

TAGS_MODULE_END(CliObjectXBind)



//#endif /* CLI_GUI_WX_OBJECTX_TAGHANDLER_H */

