#ifndef CLI_GUI_WX_OBJECTX_DEFPARSERTAGIMPL_H
#define CLI_GUI_WX_OBJECTX_DEFPARSERTAGIMPL_H

/* add this lines to your src
#ifndef CLI_GUI_WX_OBJECTX_DEFPARSERTAGIMPL_H
    #include <cli/gui/wx/objectx/defparsertagimpl.h>
#endif
*/

#ifndef CLI_GUI_IOBJECTX_H
    #include <cli/gui/iObjectX.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

/*
#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif
*/

#ifndef CLI_DRAWING_IMPL_WXIMPLHLP_H
    #include<cli/drawing/impl/wximplhlp.h>
#endif


#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

// add to your source
// #include <wx/html/htmltag.h>

namespace cli
{
namespace gui
{
namespace impl
{
namespace wx
{

class CTagDefinitionParser : public INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX
{
    const wxHtmlTag  *pTag;

    public:
        //CLI_BEGIN_INTERFACE_MAP2(CTagDefinitionParser, INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX )
        CLI_BEGIN_INTERFACE_MAP(CTagDefinitionParser)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX )
        CLI_END_INTERFACE_MAP(CTagDefinitionParser)

        // use this class as automatic object
        CLIMETHOD_(ULONG, addRef) (THIS)    { return 1; }
        CLIMETHOD_(ULONG, release) (THIS)   { return 1; }

        CTagDefinitionParser(const wxHtmlTag *_pTag) : INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX(), pTag(_pTag) {}

        CLIMETHOD(getDefinitionText) (THIS_ CLISTR*           strText)
           {
            if (!strText) return EC_INVALID_PARAM;
            return ::cli::propertyGetImpl( strText, ::std::wstring(L"Not implemented"));
            /*
            int GetBeginPos() 
            int GetEndPos1() 
            bool HasEnding() 
            GetBeginPos
            */
           }

        CLIMETHOD_(BOOL, hasDefinitionValue) (THIS_ const WCHAR*    valName /* [in,flat] wchar  valName[]  */)
           {
            if (!valName) return FALSE;
            if (!pTag)    return FALSE;

            //::std::wstring(valName)
            #if defined(UNICODE) || defined(_UNICODE)
            if ( pTag->HasParam(wxString(valName)) ) return TRUE;
            #else
            if ( pTag->HasParam(wxString(MARTY_CON::w2ansi(valName).c_str())) ) return TRUE;
            #endif
            return FALSE;
           }

        CLIMETHOD_(BOOL, getDefinitionValue) (THIS_ const WCHAR*    valName /* [in,flat] wchar  valName[]  */
                                                  , INTERFACE_CLI_IVARIANT*    pValDst /* [in] ::cli::iVariant*  pValDst  */
                                                  //, ENUM_CLI_GUI_EDEFPARSERVALUETYPE    asType /* [in] ::cli::gui::EDefParserValueType  asType  */
                                             )
           {
            if (!valName) return FALSE;
            if (!pTag)    return FALSE;

            //if ()

            #if defined(UNICODE) || defined(_UNICODE)
            wxString wxValName(valName);
            #else
            wxString wxValName(MARTY_CON::w2ansi(valName).c_str());
            #endif

            /*
            switch(asType)
               {
                case CLI_GUI_EDEFPARSERVALUETYPE_ASINT:
                         {
                          int iVal = 0;
                          if (!pTag->GetParamAsInt(wxValName, &iVal) ) return FALSE; // non exist or convert failed
                          if (!pValDst) return TRUE; // ok, but nothing to return
                          pValDst->setInt(iVal);
                          return TRUE;
                         }
                        break;
                case CLI_GUI_EDEFPARSERVALUETYPE_ASCOLORREF:
                         {
                          wxColour clrVal(0,0,0);
                          if (!pTag->GetParamAsColour(wxValName, &clrVal) ) return FALSE; // non exist or convert failed
                          if (!pValDst) return TRUE; // ok, but nothing to return
                          pValDst->setUInt((UINT)::cli::drawing::impl::wx::fromWxColor(clrVal));
                          return TRUE;
                         }
                        break;

                default:

                         {
                          if (!pValDst) return TRUE;
                          //wxString wxResStr = pTag->GetParam(wxValName);
                          CiVariant_tmp variantTmp(pValDst);
                          #if defined(UNICODE) || defined(_UNICODE)
                          variantTmp.setString(::std::wstring(pTag->GetParam(wxValName).c_str()));
                          #else
                          variantTmp.setString(::std::wstring(MARTY_CON::a2wide(pTag->GetParam(wxValName).c_str())));
                          #endif
                          return TRUE;
                         }
               }
            */
            if (!pValDst) return TRUE;
            //wxString wxResStr = pTag->GetParam(wxValName);
            CiVariant_tmp variantTmp(pValDst);
            #if defined(UNICODE) || defined(_UNICODE)
            variantTmp.setString(::std::wstring(pTag->GetParam(wxValName).c_str()));
            #else
            variantTmp.setString(::std::wstring(MARTY_CON::a2wide(pTag->GetParam(wxValName).c_str())));
            #endif
            return TRUE;

           }


}; // class CTagDefinitionParser


}; // namespace wx
}; // namespace impl
}; // namespace gui
}; // namespace cli


#endif /* CLI_GUI_WX_OBJECTX_DEFPARSERTAGIMPL_H */

