#ifndef CLI_GUI_WX_OBJECTX_HTMLHOSTCELL_H
    #include <cli/gui/wx/objectx/htmlhostcell.h>
#endif

// Add to your source
// #include <cli/gui/wx/objectx/htmlhostcell.cpp>

namespace cli
{
namespace gui
{
namespace impl
{
namespace wx
{

IMPLEMENT_ABSTRACT_CLASS(wxObjectXHtmlCellBase, wxHtmlCell)
IMPLEMENT_ABSTRACT_CLASS(wxErrorXHtmlCell, wxObjectXHtmlCellBase)
IMPLEMENT_ABSTRACT_CLASS(wxObjectXHtmlCell, wxObjectXHtmlCellBase)


}; // namespace wx
}; // namespace impl
}; // namespace gui
}; // namespace cli
