#ifndef CLI_GUI_CELLGRID_H
#define CLI_GUI_CELLGRID_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/cellgrid.h>", CLI_GUI_CELLGRID_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_CELLGRID_H
    #include <cli/gui/cellgrid.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::ESetSizeResultFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS           UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS           UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMIN
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMIN         CONSTANT_UINT(0x01)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMIN */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMAX
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMAX         CONSTANT_UINT(0x02)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMAX */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMASK
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMASK        CONSTANT_UINT(0x03)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMASK */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMIN
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMIN         CONSTANT_UINT(0x10)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMIN */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMAX
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMAX         CONSTANT_UINT(0x20)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMAX */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMASK
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMASK        CONSTANT_UINT(0x30)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMASK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace ESetSizeResultFlags {
                        const UINT xMin             = CONSTANT_UINT(0x01);
                        const UINT xMax             = CONSTANT_UINT(0x02);
                        const UINT xMask            = CONSTANT_UINT(0x03);
                        const UINT yMin             = CONSTANT_UINT(0x10);
                        const UINT yMax             = CONSTANT_UINT(0x20);
                        const UINT yMask            = CONSTANT_UINT(0x30);
                }; /* namespace ESetSizeResultFlags */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::ESetSizeResultFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::ECellLimits */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_ECELLLIMITS                   UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_ECELLLIMITS                   UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX
    #define CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX             CONSTANT_UINT(0xFFFF)
#endif /* CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX */

#ifndef CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY
    #define CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY             CONSTANT_UINT(0xFFFF)
#endif /* CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace ECellLimits {
                        const UINT maxSizeX         = CONSTANT_UINT(0xFFFF);
                        const UINT maxSizeY         = CONSTANT_UINT(0xFFFF);
                }; /* namespace ECellLimits */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::ECellLimits; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::ECellHotTrack */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK                 UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK                 UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKNONE
    #define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKNONE       CONSTANT_UINT(0x0000)
#endif /* CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKNONE */

#ifndef CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT
    #define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT  CONSTANT_UINT(0x0001)
#endif /* CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT */

#ifndef CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND
    #define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND                 CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace ECellHotTrack {
                        const UINT hotTrackNone     = CONSTANT_UINT(0x0000);
                        const UINT hotTrackHighlight        = CONSTANT_UINT(0x0001);
                        const UINT hotTrackBackground       = CONSTANT_UINT(0x0002);
                }; /* namespace ECellHotTrack */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::ECellHotTrack; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::EMoveActiveCellFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS          UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS          UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVELEFT
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVELEFT    CONSTANT_UINT(0x00010000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVELEFT */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVERIGHT
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVERIGHT   CONSTANT_UINT(0x00020000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVERIGHT */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEUP
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEUP      CONSTANT_UINT(0x00040000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEUP */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEDOWN
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEDOWN    CONSTANT_UINT(0x00080000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEDOWN */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATE
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATE    CONSTANT_UINT(0x00100000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATE */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATEALTER
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATEALTER               CONSTANT_UINT(0x00200000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATEALTER */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace EMoveActiveCellFlags {
                        const UINT moveLeft         = CONSTANT_UINT(0x00010000);
                        const UINT moveRight        = CONSTANT_UINT(0x00020000);
                        const UINT moveUp           = CONSTANT_UINT(0x00040000);
                        const UINT moveDown         = CONSTANT_UINT(0x00080000);
                        const UINT activate         = CONSTANT_UINT(0x00100000);
                        const UINT activateAlter    = CONSTANT_UINT(0x00200000);
                }; /* namespace EMoveActiveCellFlags */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::EMoveActiveCellFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::EHitTestFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS                 UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS                 UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT            CONSTANT_UINT(0x0001)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING        CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWSPACING
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWSPACING         CONSTANT_UINT(0x0004)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWSPACING */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT             CONSTANT_UINT(0x0008)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING        CONSTANT_UINT(0x0010)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT            CONSTANT_UINT(0x0020)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace EHitTestFlags {
                        const UINT gridHit          = CONSTANT_UINT(0x0001);
                        const UINT gridSpacing      = CONSTANT_UINT(0x0002);
                        const UINT rowSpacing       = CONSTANT_UINT(0x0004);
                        const UINT rowHit           = CONSTANT_UINT(0x0008);
                        const UINT cellSpacing      = CONSTANT_UINT(0x0010);
                        const UINT cellHit          = CONSTANT_UINT(0x0020);
                }; /* namespace EHitTestFlags */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::EHitTestFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::EAlignment */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_EALIGNMENT    UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_EALIGNMENT    UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_VCENTER
    #define CLI_GUI_CELLGRID_EALIGNMENT_VCENTER               CONSTANT_UINT(0x0000)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_VCENTER */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_TOP
    #define CLI_GUI_CELLGRID_EALIGNMENT_TOP   CONSTANT_UINT(0x0001)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_TOP */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_BOTTOM
    #define CLI_GUI_CELLGRID_EALIGNMENT_BOTTOM                CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_BOTTOM */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_BASELINE
    #define CLI_GUI_CELLGRID_EALIGNMENT_BASELINE              CONSTANT_UINT(0x0004)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_BASELINE */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_VUNDEFINED
    #define CLI_GUI_CELLGRID_EALIGNMENT_VUNDEFINED            CONSTANT_UINT(0x0008)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_VUNDEFINED */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_VMASK
    #define CLI_GUI_CELLGRID_EALIGNMENT_VMASK                 CONSTANT_UINT(0x000F)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_VMASK */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_HCENTER
    #define CLI_GUI_CELLGRID_EALIGNMENT_HCENTER               CONSTANT_UINT(0x0000)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_HCENTER */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_LEFT
    #define CLI_GUI_CELLGRID_EALIGNMENT_LEFT  CONSTANT_UINT(0x0010)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_LEFT */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_RIGHT
    #define CLI_GUI_CELLGRID_EALIGNMENT_RIGHT                 CONSTANT_UINT(0x0020)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_RIGHT */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_HUNDEFINED
    #define CLI_GUI_CELLGRID_EALIGNMENT_HUNDEFINED            CONSTANT_UINT(0x0080)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_HUNDEFINED */

#ifndef CLI_GUI_CELLGRID_EALIGNMENT_HMASK
    #define CLI_GUI_CELLGRID_EALIGNMENT_HMASK                 CONSTANT_UINT(0x00F0)
#endif /* CLI_GUI_CELLGRID_EALIGNMENT_HMASK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace EAlignment {
                        const UINT vcenter          = CONSTANT_UINT(0x0000);
                        const UINT top              = CONSTANT_UINT(0x0001);
                        const UINT bottom           = CONSTANT_UINT(0x0002);
                        const UINT baseLine         = CONSTANT_UINT(0x0004);
                        const UINT vUndefined       = CONSTANT_UINT(0x0008);
                        const UINT vMask            = CONSTANT_UINT(0x000F);
                        const UINT hcenter          = CONSTANT_UINT(0x0000);
                        const UINT left             = CONSTANT_UINT(0x0010);
                        const UINT right            = CONSTANT_UINT(0x0020);
                        const UINT hUndefined       = CONSTANT_UINT(0x0080);
                        const UINT hMask            = CONSTANT_UINT(0x00F0);
                }; /* namespace EAlignment */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::EAlignment; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::gui::cellgrid::CSpacing */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define CLI_STRUCT_NAME                   CSpacing
    struct CSpacing;
    #ifndef STRUCT_CLI_GUI_CELLGRID_CSPACING
        #define STRUCT_CLI_GUI_CELLGRID_CSPACING  ::cli::gui::cellgrid::CSpacing
    #endif

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_gui_cellgrid_CSpacing
    struct  tag_cli_gui_cellgrid_CSpacing;
    #ifndef STRUCT_CLI_GUI_CELLGRID_CSPACING
        #define STRUCT_CLI_GUI_CELLGRID_CSPACING  struct tag_cli_gui_cellgrid_CSpacing
    #endif

#endif /* end of C-like declarations */

                #include <cli/pshpack4.h>
                CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                    UINT                        left;
                    UINT                        top;
                    UINT                        right;
                    UINT                        bottom;
                CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
                #include <cli/poppack.h>

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iRow */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; /* namespace cli */
    namespace cli {
        namespace app {
            interface                                iConfig;
            #ifndef INTERFACE_CLI_APP_ICONFIG
                #define INTERFACE_CLI_APP_ICONFIG         ::cli::app::iConfig
            #endif

        }; /* namespace app */
    }; /* namespace cli */
    namespace cli {
        namespace drawing {
            interface                                iDrawContext1;
            #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
                #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               ::cli::drawing::iDrawContext1
            #endif

        }; /* namespace drawing */
    }; /* namespace cli */
    namespace cli {
        namespace gui {
            namespace cellgrid {
                interface                                iCell;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_ICELL
                    #define INTERFACE_CLI_GUI_CELLGRID_ICELL  ::cli::gui::cellgrid::iCell
                #endif

                interface                                iGrid;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
                    #define INTERFACE_CLI_GUI_CELLGRID_IGRID  ::cli::gui::cellgrid::iGrid
                #endif

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    typedef interface tag_cli_app_iConfig    cli_app_iConfig;
    #ifndef INTERFACE_CLI_APP_ICONFIG
        #define INTERFACE_CLI_APP_ICONFIG         struct tag_cli_app_iConfig
    #endif

    typedef interface tag_cli_drawing_iDrawContext1              cli_drawing_iDrawContext1;
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
        #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               struct tag_cli_drawing_iDrawContext1
    #endif

    typedef interface tag_cli_gui_cellgrid_iCell                 cli_gui_cellgrid_iCell;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ICELL
        #define INTERFACE_CLI_GUI_CELLGRID_ICELL  struct tag_cli_gui_cellgrid_iCell
    #endif

    typedef interface tag_cli_gui_cellgrid_iGrid                 cli_gui_cellgrid_iGrid;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
        #define INTERFACE_CLI_GUI_CELLGRID_IGRID  struct tag_cli_gui_cellgrid_iGrid
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_IROW_IID
    #define INTERFACE_CLI_GUI_CELLGRID_IROW_IID    "/cli/gui/cellgrid/iRow"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iRow
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
       #define INTERFACE_CLI_GUI_CELLGRID_IROW    ::cli::gui::cellgrid::iRow
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iRow
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
       #define INTERFACE_CLI_GUI_CELLGRID_IROW    cli_gui_cellgrid_iRow
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iRow methods */
                    CLIMETHOD(cellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL**    _cells /* [out] ::cli::gui::cellgrid::iCell* _cells  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                    CLIMETHOD(cellsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(getIUnknownIndex) (THIS_ INTERFACE_CLI_IUNKNOWN*    pcell /* [in] ::cli::iUnknown*  pcell  */
                                                     , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                                ) PURE;
                    CLIMETHOD(getCellIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL*    pcell /* [in] ::cli::gui::cellgrid::iCell*  pcell  */
                                                 , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                            ) PURE;
                    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [out] ::cli::gui::cellgrid::CSpacing _spacing  */) PURE;
                    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _spacing  */) PURE;
                    CLIMETHOD(resetSpacing) (THIS_ SIZE_T    idx1 /* [in] size_t  idx1  */) PURE;
                    CLIMETHOD(cellSpacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _cellSpacing /* [out] ::cli::gui::cellgrid::CSpacing _cellSpacing  */) PURE;
                    CLIMETHOD(cellSpacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _cellSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _cellSpacing  */) PURE;
                    CLIMETHOD(resetCellSpacing) (THIS_ SIZE_T    idx1 /* [in] size_t  idx1  */) PURE;
                    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(ownerGridSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID*    _ownerGrid /* [in] ::cli::gui::cellgrid::iGrid*  _ownerGrid  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(ownerGridSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       ) PURE;
                    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       ) PURE;
                    CLIMETHOD(sizeSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(sizeXGet) (THIS_ UINT*    _sizeX /* [out] uint _sizeX  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                    CLIMETHOD(sizeXSet) (THIS_ UINT    _sizeX /* [in] uint  _sizeX  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                    CLIMETHOD(sizeXSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(sizeYGet) (THIS_ UINT*    _sizeY /* [out] uint _sizeY  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                    CLIMETHOD(sizeYSet) (THIS_ UINT    _sizeY /* [in] uint  _sizeY  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                    CLIMETHOD(sizeYSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool _drawBackground  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 ) PURE;
                    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  _drawBackground  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 ) PURE;
                    CLIMETHOD(drawBackgroundSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */
                                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  ) PURE;
                    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */
                                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  ) PURE;
                    CLIMETHOD(backgroundColorSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellBackgroundColorGet) (THIS_ COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */
                                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      ) PURE;
                    CLIMETHOD(cellBackgroundColorSet) (THIS_ COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */
                                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      ) PURE;
                    CLIMETHOD(cellBackgroundColorSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(activeCellBackgroundColorGet) (THIS_ COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */
                                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                            ) PURE;
                    CLIMETHOD(activeCellBackgroundColorSet) (THIS_ COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */
                                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                            ) PURE;
                    CLIMETHOD(activeCellBackgroundColorSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellAlignmentGet) (THIS_ ENUM_CLI_GUI_CELLGRID_EALIGNMENT*    _cellAlignment /* [out] ::cli::gui::cellgrid::EAlignment _cellAlignment  */) PURE;
                    CLIMETHOD(cellAlignmentSet) (THIS_ ENUM_CLI_GUI_CELLGRID_EALIGNMENT    _cellAlignment /* [in] ::cli::gui::cellgrid::EAlignment  _cellAlignment  */) PURE;
                    CLIMETHOD(cellsVisibleGet) (THIS_ BOOL*    _cellsVisible /* [out] bool _cellsVisible  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(cellsVisibleSet) (THIS_ BOOL    _cellsVisible /* [in] bool  _cellsVisible  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(cellsVisibleSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellsVisibleSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 ) PURE;
                    CLIMETHOD(getCellPosSize) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                                              ) PURE;
                    CLIMETHOD(cellSizeChangedNotify) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                          , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                          , BOOL    bRepaint /* [in] bool  bRepaint  */
                                                     ) PURE;
                    CLIMETHOD(allCellsSizeChangedNotify) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                              , BOOL    bRepaint /* [in] bool  bRepaint  */
                                                         ) PURE;
                    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               ) PURE;
                    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       ) PURE;
                    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           ) PURE;
                    CLIMETHOD(paintCell) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                              , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                              , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                              , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                         ) PURE;
                    CLIMETHOD(insertCell) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL*    pCell /* [in] ::cli::gui::cellgrid::iCell*  pCell  */
                                               , SIZE_T    atPos /* [in] size_t  atPos  */
                                          ) PURE;
                    CLIMETHOD(addCell) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL*    pCell /* [in] ::cli::gui::cellgrid::iCell*  pCell  */) PURE;
                    CLIMETHOD(removeCell) (THIS_ SIZE_T    atPos /* [in] size_t  atPos  */) PURE;
                    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         ) PURE;
                    CLIMETHOD(hitTest) (THIS_ SIZE_T    thisRowIndex /* [in] size_t  thisRowIndex  */
                                            , const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                            , SIZE_T*    hitCell /* [out] size_t hitCell  */
                                            , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                                       ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iRow >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_IROW_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iRow* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iRow > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iRow wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IROW >
                                              */
                         >
                class CiRowWrapper
                {
                    public:
                
                        typedef  CiRowWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiRowWrapper() :
                           pif(0) {}
                
                        CiRowWrapper( iRow *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiRowWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiRowWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiRowWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiRowWrapper(const CiRowWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiRowWrapper()  { }
                
                        CiRowWrapper& operator=(const CiRowWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_ICELL* get_cells( SIZE_T idx1 )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_ICELL* tmpVal;
                            RCODE res = cellsGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size_cells(  )
                           {
                            SIZE_T size;
                            RCODE res = cellsSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_ICELL*, cells, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsGet( INTERFACE_CLI_GUI_CELLGRID_ICELL**    _cells /* [out] ::cli::gui::cellgrid::iCell* _cells  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                           {
                        
                        
                            return pif->cellsGet(_cells, idx1);
                           }
                        
                        RCODE cellsSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellsSize(_size);
                           }
                        
                        RCODE getIUnknownIndex( INTERFACE_CLI_IUNKNOWN*    pcell /* [in] ::cli::iUnknown*  pcell  */
                                              , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                              )
                           {
                        
                        
                            return pif->getIUnknownIndex(pcell, idxFound);
                           }
                        
                        RCODE getCellIndex( INTERFACE_CLI_GUI_CELLGRID_ICELL*    pcell /* [in] ::cli::gui::cellgrid::iCell*  pcell  */
                                          , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                          )
                           {
                        
                        
                            return pif->getCellIndex(pcell, idxFound);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CELLGRID_CSPACING get_spacing( )
                           {
                            STRUCT_CLI_GUI_CELLGRID_CSPACING tmpVal;
                            RCODE res = spacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_spacing( const STRUCT_CLI_GUI_CELLGRID_CSPACING &_spacing
                                        )
                           {
                            RCODE res = spacingSet( _spacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CELLGRID_CSPACING, spacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE spacingGet( STRUCT_CLI_GUI_CELLGRID_CSPACING    &_spacing /* [out] ::cli::gui::cellgrid::CSpacing _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingGet(&_spacing);
                           }
                        
                        RCODE spacingSet( const STRUCT_CLI_GUI_CELLGRID_CSPACING    &_spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingSet(&_spacing);
                           }
                        
                        RCODE resetSpacing( SIZE_T    idx1 /* [in] size_t  idx1  */)
                           {
                        
                            return pif->resetSpacing(idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CELLGRID_CSPACING get_cellSpacing( )
                           {
                            STRUCT_CLI_GUI_CELLGRID_CSPACING tmpVal;
                            RCODE res = cellSpacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellSpacing( const STRUCT_CLI_GUI_CELLGRID_CSPACING &_cellSpacing
                                            )
                           {
                            RCODE res = cellSpacingSet( _cellSpacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CELLGRID_CSPACING, cellSpacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellSpacingGet( STRUCT_CLI_GUI_CELLGRID_CSPACING    &_cellSpacing /* [out] ::cli::gui::cellgrid::CSpacing _cellSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSpacingGet(&_cellSpacing);
                           }
                        
                        RCODE cellSpacingSet( const STRUCT_CLI_GUI_CELLGRID_CSPACING    &_cellSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _cellSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSpacingSet(&_cellSpacing);
                           }
                        
                        RCODE resetCellSpacing( SIZE_T    idx1 /* [in] size_t  idx1  */)
                           {
                        
                            return pif->resetCellSpacing(idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IGRID* get_ownerGrid( SIZE_T idx1 )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IGRID* tmpVal;
                            RCODE res = ownerGridGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ownerGrid( SIZE_T idx1 , INTERFACE_CLI_GUI_CELLGRID_IGRID* _ownerGrid
                                          )
                           { // MS style - index goes before value, need reorder
                            RCODE res = ownerGridSet( _ownerGrid, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_ownerGrid(  )
                           {
                            SIZE_T size;
                            RCODE res = ownerGridSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IGRID*, ownerGrid, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ownerGridGet( INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->ownerGridGet(_ownerGrid, idx1);
                           }
                        
                        RCODE ownerGridSet( INTERFACE_CLI_GUI_CELLGRID_IGRID*    _ownerGrid /* [in] ::cli::gui::cellgrid::iGrid*  _ownerGrid  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->ownerGridSet(_ownerGrid, idx1);
                           }
                        
                        RCODE ownerGridSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->ownerGridSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_size( SIZE_T idx1 )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = sizeGet( tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_size( SIZE_T idx1 , const STRUCT_CLI_DRAWING_CPOINT &_size
                                     )
                           { // MS style - index goes before value, need reorder
                            RCODE res = sizeSet( _size, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_size(  )
                           {
                            SIZE_T size;
                            RCODE res = sizeSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, size, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeGet( STRUCT_CLI_DRAWING_CPOINT    &_size /* [out] ::cli::drawing::CPoint _size  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
                           {
                        
                        
                            return pif->sizeGet(&_size, idx1);
                           }
                        
                        RCODE sizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_size /* [in,ref] ::cli::drawing::CPoint  _size  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
                           {
                        
                        
                            return pif->sizeSet(&_size, idx1);
                           }
                        
                        RCODE sizeSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->sizeSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        UINT get_sizeX( SIZE_T idx1 )
                           {
                            UINT tmpVal;
                            RCODE res = sizeXGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_sizeX( SIZE_T idx1 , UINT _sizeX
                                      )
                           { // MS style - index goes before value, need reorder
                            RCODE res = sizeXSet( _sizeX, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_sizeX(  )
                           {
                            SIZE_T size;
                            RCODE res = sizeXSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, UINT, sizeX, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeXGet( UINT*    _sizeX /* [out] uint _sizeX  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                           {
                        
                        
                            return pif->sizeXGet(_sizeX, idx1);
                           }
                        
                        RCODE sizeXSet( UINT    _sizeX /* [in] uint  _sizeX  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                           {
                        
                        
                            return pif->sizeXSet(_sizeX, idx1);
                           }
                        
                        RCODE sizeXSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->sizeXSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        UINT get_sizeY( SIZE_T idx1 )
                           {
                            UINT tmpVal;
                            RCODE res = sizeYGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_sizeY( SIZE_T idx1 , UINT _sizeY
                                      )
                           { // MS style - index goes before value, need reorder
                            RCODE res = sizeYSet( _sizeY, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_sizeY(  )
                           {
                            SIZE_T size;
                            RCODE res = sizeYSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, UINT, sizeY, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeYGet( UINT*    _sizeY /* [out] uint _sizeY  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                           {
                        
                        
                            return pif->sizeYGet(_sizeY, idx1);
                           }
                        
                        RCODE sizeYSet( UINT    _sizeY /* [in] uint  _sizeY  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                           {
                        
                        
                            return pif->sizeYSet(_sizeY, idx1);
                           }
                        
                        RCODE sizeYSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->sizeYSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_drawBackground( SIZE_T idx1 )
                           {
                            BOOL tmpVal;
                            RCODE res = drawBackgroundGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_drawBackground( SIZE_T idx1 , BOOL _drawBackground
                                               )
                           { // MS style - index goes before value, need reorder
                            RCODE res = drawBackgroundSet( _drawBackground, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_drawBackground(  )
                           {
                            SIZE_T size;
                            RCODE res = drawBackgroundSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, BOOL, drawBackground, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE drawBackgroundGet( BOOL*    _drawBackground /* [out] bool _drawBackground  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               )
                           {
                        
                        
                            return pif->drawBackgroundGet(_drawBackground, idx1);
                           }
                        
                        RCODE drawBackgroundSet( BOOL    _drawBackground /* [in] bool  _drawBackground  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               )
                           {
                        
                        
                            return pif->drawBackgroundSet(_drawBackground, idx1);
                           }
                        
                        RCODE drawBackgroundSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->drawBackgroundSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_backgroundColor( SIZE_T idx1 )
                           {
                            COLORREF tmpVal;
                            RCODE res = backgroundColorGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_backgroundColor( SIZE_T idx1 , COLORREF _backgroundColor
                                                )
                           { // MS style - index goes before value, need reorder
                            RCODE res = backgroundColorSet( _backgroundColor, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_backgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = backgroundColorSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, COLORREF, backgroundColor, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE backgroundColorGet( COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                )
                           {
                        
                        
                            return pif->backgroundColorGet(_backgroundColor, idx1);
                           }
                        
                        RCODE backgroundColorSet( COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                )
                           {
                        
                        
                            return pif->backgroundColorSet(_backgroundColor, idx1);
                           }
                        
                        RCODE backgroundColorSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->backgroundColorSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_cellBackgroundColor( SIZE_T idx1 )
                           {
                            COLORREF tmpVal;
                            RCODE res = cellBackgroundColorGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellBackgroundColor( SIZE_T idx1 , COLORREF _cellBackgroundColor
                                                    )
                           { // MS style - index goes before value, need reorder
                            RCODE res = cellBackgroundColorSet( _cellBackgroundColor, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_cellBackgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = cellBackgroundColorSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, COLORREF, cellBackgroundColor, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellBackgroundColorGet( COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    )
                           {
                        
                        
                            return pif->cellBackgroundColorGet(_cellBackgroundColor, idx1);
                           }
                        
                        RCODE cellBackgroundColorSet( COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    )
                           {
                        
                        
                            return pif->cellBackgroundColorSet(_cellBackgroundColor, idx1);
                           }
                        
                        RCODE cellBackgroundColorSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellBackgroundColorSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeCellBackgroundColor( SIZE_T idx1 )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeCellBackgroundColorGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCellBackgroundColor( SIZE_T idx1 , COLORREF _activeCellBackgroundColor
                                                          )
                           { // MS style - index goes before value, need reorder
                            RCODE res = activeCellBackgroundColorSet( _activeCellBackgroundColor, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_activeCellBackgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = activeCellBackgroundColorSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, COLORREF, activeCellBackgroundColor, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellBackgroundColorGet( COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */
                                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                          )
                           {
                        
                        
                            return pif->activeCellBackgroundColorGet(_activeCellBackgroundColor, idx1);
                           }
                        
                        RCODE activeCellBackgroundColorSet( COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */
                                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                          )
                           {
                        
                        
                            return pif->activeCellBackgroundColorSet(_activeCellBackgroundColor, idx1);
                           }
                        
                        RCODE activeCellBackgroundColorSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->activeCellBackgroundColorSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_CELLGRID_EALIGNMENT get_cellAlignment( )
                           {
                            ENUM_CLI_GUI_CELLGRID_EALIGNMENT tmpVal;
                            RCODE res = cellAlignmentGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellAlignment( ENUM_CLI_GUI_CELLGRID_EALIGNMENT _cellAlignment
                                              )
                           {
                            RCODE res = cellAlignmentSet( _cellAlignment );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_GUI_CELLGRID_EALIGNMENT, cellAlignment );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellAlignmentGet( ENUM_CLI_GUI_CELLGRID_EALIGNMENT*    _cellAlignment /* [out] ::cli::gui::cellgrid::EAlignment _cellAlignment  */)
                           {
                        
                            return pif->cellAlignmentGet(_cellAlignment);
                           }
                        
                        RCODE cellAlignmentSet( ENUM_CLI_GUI_CELLGRID_EALIGNMENT    _cellAlignment /* [in] ::cli::gui::cellgrid::EAlignment  _cellAlignment  */)
                           {
                        
                            return pif->cellAlignmentSet(_cellAlignment);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_cellsVisible( SIZE_T idx1
                                             , SIZE_T idx2
                                             )
                           {
                            BOOL tmpVal;
                            RCODE res = cellsVisibleGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellsVisible( SIZE_T idx1
                                             , SIZE_T idx2
                                             , BOOL _cellsVisible
                                             )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = cellsVisibleSet( _cellsVisible, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_cellsVisible(  )
                           {
                            SIZE_T size;
                            RCODE res = cellsVisibleSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_cellsVisible( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = cellsVisibleSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, cellsVisible, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsVisibleGet( BOOL*    _cellsVisible /* [out] bool _cellsVisible  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->cellsVisibleGet(_cellsVisible, idx1, idx2);
                           }
                        
                        RCODE cellsVisibleSet( BOOL    _cellsVisible /* [in] bool  _cellsVisible  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->cellsVisibleSet(_cellsVisible, idx1, idx2);
                           }
                        
                        RCODE cellsVisibleSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellsVisibleSize1(_size);
                           }
                        
                        RCODE cellsVisibleSize2( SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               )
                           {
                        
                        
                            return pif->cellsVisibleSize2(_size, idx1);
                           }
                        
                        RCODE getCellPosSize( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                            , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                                            )
                           {
                        
                        
                        
                        
                        
                        
                            return pif->getCellPosSize(rowIdx, cellIdx, ncLeftTop, ncWidthHeight, clientLeftTop, clientWidthHeight);
                           }
                        
                        RCODE cellSizeChangedNotify( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                   , BOOL    bRepaint /* [in] bool  bRepaint  */
                                                   )
                           {
                        
                        
                        
                            return pif->cellSizeChangedNotify(rowIdx, cellIdx, bRepaint);
                           }
                        
                        RCODE allCellsSizeChangedNotify( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                       , BOOL    bRepaint /* [in] bool  bRepaint  */
                                                       )
                           {
                        
                        
                            return pif->allCellsSizeChangedNotify(rowIdx, bRepaint);
                           }
                        
                        RCODE updateConfig( INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->updateConfig(appCfg, idx1);
                           }
                        
                        RCODE calculateLimits( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
                           {
                        
                        
                            return pif->calculateLimits(pdc, idx1);
                           }
                        
                        RCODE ncPaint( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                     , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
                           {
                        
                        
                        
                            return pif->ncPaint(pdc, &paintAreaSize, idx1);
                           }
                        
                        RCODE paintClient( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         )
                           {
                        
                        
                        
                            return pif->paintClient(pdc, &paintAreaSize, idx1);
                           }
                        
                        RCODE paintCell( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                       , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                       )
                           {
                        
                        
                        
                        
                            return pif->paintCell(pdc, &paintAreaSize, rowIdx, cellIdx);
                           }
                        
                        RCODE insertCell( INTERFACE_CLI_GUI_CELLGRID_ICELL*    pCell /* [in] ::cli::gui::cellgrid::iCell*  pCell  */
                                        , SIZE_T    atPos /* [in] size_t  atPos  */
                                        )
                           {
                        
                        
                            return pif->insertCell(pCell, atPos);
                           }
                        
                        RCODE addCell( INTERFACE_CLI_GUI_CELLGRID_ICELL*    pCell /* [in] ::cli::gui::cellgrid::iCell*  pCell  */)
                           {
                        
                            return pif->addCell(pCell);
                           }
                        
                        RCODE removeCell( SIZE_T    atPos /* [in] size_t  atPos  */)
                           {
                        
                            return pif->removeCell(atPos);
                           }
                        
                        RCODE getLimits( STRUCT_CLI_DRAWING_CPOINT    &minSize /* [out] ::cli::drawing::CPoint minSize  (struct passed by ref in wrapper) */
                                       , STRUCT_CLI_DRAWING_CPOINT    &maxSize /* [out] ::cli::drawing::CPoint maxSize  (struct passed by ref in wrapper) */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       )
                           {
                        
                        
                        
                            return pif->getLimits(&minSize, &maxSize, idx1);
                           }
                        
                        RCODE hitTest( SIZE_T    thisRowIndex /* [in] size_t  thisRowIndex  */
                                     , const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                     , SIZE_T*    hitCell /* [out] size_t hitCell  */
                                     , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                                     )
                           {
                        
                        
                        
                        
                            return pif->hitTest(thisRowIndex, &micePos, hitCell, resFlags);
                           }
                        

                
                
                }; // class CiRowWrapper
                
                typedef CiRowWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IROW     > >  CiRow;
                typedef CiRowWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_IROW > >  CiRow_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iGrid */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                interface                                iGridOwner;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER
                    #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER             ::cli::gui::cellgrid::iGridOwner
                #endif

                interface                                iRow;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
                    #define INTERFACE_CLI_GUI_CELLGRID_IROW   ::cli::gui::cellgrid::iRow
                #endif

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_gui_cellgrid_iGridOwner            cli_gui_cellgrid_iGridOwner;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER
        #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER             struct tag_cli_gui_cellgrid_iGridOwner
    #endif

    typedef interface tag_cli_gui_cellgrid_iRow                  cli_gui_cellgrid_iRow;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
        #define INTERFACE_CLI_GUI_CELLGRID_IROW   struct tag_cli_gui_cellgrid_iRow
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID_IID
    #define INTERFACE_CLI_GUI_CELLGRID_IGRID_IID    "/cli/gui/cellgrid/iGrid"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iGrid
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
       #define INTERFACE_CLI_GUI_CELLGRID_IGRID    ::cli::gui::cellgrid::iGrid
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iGrid
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
       #define INTERFACE_CLI_GUI_CELLGRID_IGRID    cli_gui_cellgrid_iGrid
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iGrid methods */
                    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [out] ::cli::gui::cellgrid::CSpacing _spacing  */) PURE;
                    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _spacing  */) PURE;
                    CLIMETHOD(rowSpacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _rowSpacing /* [out] ::cli::gui::cellgrid::CSpacing _rowSpacing  */) PURE;
                    CLIMETHOD(rowSpacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _rowSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _rowSpacing  */) PURE;
                    CLIMETHOD(cellSpacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _cellSpacing /* [out] ::cli::gui::cellgrid::CSpacing _cellSpacing  */) PURE;
                    CLIMETHOD(cellSpacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _cellSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _cellSpacing  */) PURE;
                    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */) PURE;
                    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */) PURE;
                    CLIMETHOD(sizeXGet) (THIS_ UINT*    _sizeX /* [out] uint _sizeX  */) PURE;
                    CLIMETHOD(sizeXSet) (THIS_ UINT    _sizeX /* [in] uint  _sizeX  */) PURE;
                    CLIMETHOD(sizeYGet) (THIS_ UINT*    _sizeY /* [out] uint _sizeY  */) PURE;
                    CLIMETHOD(sizeYSet) (THIS_ UINT    _sizeY /* [in] uint  _sizeY  */) PURE;
                    CLIMETHOD(rowsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW**    _rows /* [out] ::cli::gui::cellgrid::iRow* _rows  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       ) PURE;
                    CLIMETHOD(rowsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL**    _cells /* [out] ::cli::gui::cellgrid::iCell* _cells  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        ) PURE;
                    CLIMETHOD(cellsSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellsSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          ) PURE;
                    CLIMETHOD(activeRowGet) (THIS_ SIZE_T*    _activeRow /* [out] size_t _activeRow  */) PURE;
                    CLIMETHOD(activeCellGet) (THIS_ SIZE_T*    _activeCell /* [out] size_t _activeCell  */) PURE;
                    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool _drawBackground  */) PURE;
                    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  _drawBackground  */) PURE;
                    CLIMETHOD(rowDrawBackgroundGet) (THIS_ BOOL*    _rowDrawBackground /* [out] bool _rowDrawBackground  */) PURE;
                    CLIMETHOD(rowDrawBackgroundSet) (THIS_ BOOL    _rowDrawBackground /* [in] bool  _rowDrawBackground  */) PURE;
                    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */) PURE;
                    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */) PURE;
                    CLIMETHOD(rowBackgroundColorGet) (THIS_ COLORREF*    _rowBackgroundColor /* [out] colorref _rowBackgroundColor  */) PURE;
                    CLIMETHOD(rowBackgroundColorSet) (THIS_ COLORREF    _rowBackgroundColor /* [in] colorref  _rowBackgroundColor  */) PURE;
                    CLIMETHOD(cellBackgroundColorGet) (THIS_ COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */) PURE;
                    CLIMETHOD(cellBackgroundColorSet) (THIS_ COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellBackgroundColorGet) (THIS_ COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellBackgroundColorSet) (THIS_ COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */) PURE;
                    CLIMETHOD(cellAlignmentGet) (THIS_ ENUM_CLI_GUI_CELLGRID_EALIGNMENT*    _cellAlignment /* [out] ::cli::gui::cellgrid::EAlignment _cellAlignment  */) PURE;
                    CLIMETHOD(cellAlignmentSet) (THIS_ ENUM_CLI_GUI_CELLGRID_EALIGNMENT    _cellAlignment /* [in] ::cli::gui::cellgrid::EAlignment  _cellAlignment  */) PURE;
                    CLIMETHOD(disablePaintingGet) (THIS_ BOOL*    _disablePainting /* [out] bool _disablePainting  */) PURE;
                    CLIMETHOD(disablePaintingSet) (THIS_ BOOL    _disablePainting /* [in] bool  _disablePainting  */) PURE;
                    CLIMETHOD(cellsVisibleGet) (THIS_ BOOL*    _cellsVisible /* [out] bool _cellsVisible  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(cellsVisibleSet) (THIS_ BOOL    _cellsVisible /* [in] bool  _cellsVisible  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(cellsVisibleSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellsVisibleSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 ) PURE;
                    CLIMETHOD(getCellPosSize) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                                              ) PURE;
                    CLIMETHOD(setGridOwner) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER*    pGridOwner /* [in] ::cli::gui::cellgrid::iGridOwner*  pGridOwner  */
                                                 , SIZE_T    gridId /* [in] size_t  gridId  */
                                            ) PURE;
                    CLIMETHOD(getDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */) PURE;
                    CLIMETHOD(getDrawContextForRectUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                                , const STRUCT_CLI_DRAWING_CPOINT*    gridPosLeftTop /* [in,ref] ::cli::drawing::CPoint  gridPosLeftTop  */
                                                                , const STRUCT_CLI_DRAWING_CPOINT*    rectSize /* [in,ref] ::cli::drawing::CPoint  rectSize  */
                                                           ) PURE;
                    CLIMETHOD(getIUnknownIndex) (THIS_ INTERFACE_CLI_IUNKNOWN*    prow /* [in] ::cli::iUnknown*  prow  */
                                                     , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                                ) PURE;
                    CLIMETHOD(getRowIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    prow /* [in] ::cli::gui::cellgrid::iRow*  prow  */
                                                , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                           ) PURE;
                    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */) PURE;
                    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */) PURE;
                    CLIMETHOD(paint) (THIS) PURE;
                    CLIMETHOD(paintUpdate) (THIS_ SIZE_T    paintStartingRow /* [in] size_t  paintStartingRow  */) PURE;
                    CLIMETHOD(getCellDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                  ) PURE;
                    CLIMETHOD(paintCellOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                  ) PURE;
                    CLIMETHOD(paintCell) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                              , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                         ) PURE;
                    CLIMETHOD(rowSizeChangedNotify) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                         , BOOL    bRepaint /* [in] bool  bRepaint  */
                                                    ) PURE;
                    CLIMETHOD(allRowsSizeChangedNotify) (THIS_ BOOL    bRepaint /* [in] bool  bRepaint  */) PURE;
                    CLIMETHOD(insertRow) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                                              , SIZE_T    idx /* [in] size_t  idx  */
                                         ) PURE;
                    CLIMETHOD(addRow) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */) PURE;
                    CLIMETHOD(removeRow) (THIS_ SIZE_T    atPos /* [in] size_t  atPos  */) PURE;
                    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                                         ) PURE;
                    CLIMETHOD(hitTest) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                            , SIZE_T*    hitRow /* [out] size_t hitRow  */
                                            , SIZE_T*    hitCell /* [out] size_t hitCell  */
                                            , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                                       ) PURE;
                    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */) PURE;
                    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                            ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iGrid >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_IGRID_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iGrid* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iGrid > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iGrid wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IGRID >
                                              */
                         >
                class CiGridWrapper
                {
                    public:
                
                        typedef  CiGridWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiGridWrapper() :
                           pif(0) {}
                
                        CiGridWrapper( iGrid *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiGridWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiGridWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiGridWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiGridWrapper(const CiGridWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiGridWrapper()  { }
                
                        CiGridWrapper& operator=(const CiGridWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CELLGRID_CSPACING get_spacing( )
                           {
                            STRUCT_CLI_GUI_CELLGRID_CSPACING tmpVal;
                            RCODE res = spacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_spacing( const STRUCT_CLI_GUI_CELLGRID_CSPACING &_spacing
                                        )
                           {
                            RCODE res = spacingSet( _spacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CELLGRID_CSPACING, spacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE spacingGet( STRUCT_CLI_GUI_CELLGRID_CSPACING    &_spacing /* [out] ::cli::gui::cellgrid::CSpacing _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingGet(&_spacing);
                           }
                        
                        RCODE spacingSet( const STRUCT_CLI_GUI_CELLGRID_CSPACING    &_spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingSet(&_spacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CELLGRID_CSPACING get_rowSpacing( )
                           {
                            STRUCT_CLI_GUI_CELLGRID_CSPACING tmpVal;
                            RCODE res = rowSpacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_rowSpacing( const STRUCT_CLI_GUI_CELLGRID_CSPACING &_rowSpacing
                                           )
                           {
                            RCODE res = rowSpacingSet( _rowSpacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CELLGRID_CSPACING, rowSpacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowSpacingGet( STRUCT_CLI_GUI_CELLGRID_CSPACING    &_rowSpacing /* [out] ::cli::gui::cellgrid::CSpacing _rowSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->rowSpacingGet(&_rowSpacing);
                           }
                        
                        RCODE rowSpacingSet( const STRUCT_CLI_GUI_CELLGRID_CSPACING    &_rowSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _rowSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->rowSpacingSet(&_rowSpacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CELLGRID_CSPACING get_cellSpacing( )
                           {
                            STRUCT_CLI_GUI_CELLGRID_CSPACING tmpVal;
                            RCODE res = cellSpacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellSpacing( const STRUCT_CLI_GUI_CELLGRID_CSPACING &_cellSpacing
                                            )
                           {
                            RCODE res = cellSpacingSet( _cellSpacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CELLGRID_CSPACING, cellSpacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellSpacingGet( STRUCT_CLI_GUI_CELLGRID_CSPACING    &_cellSpacing /* [out] ::cli::gui::cellgrid::CSpacing _cellSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSpacingGet(&_cellSpacing);
                           }
                        
                        RCODE cellSpacingSet( const STRUCT_CLI_GUI_CELLGRID_CSPACING    &_cellSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _cellSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSpacingSet(&_cellSpacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_size( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = sizeGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_size( const STRUCT_CLI_DRAWING_CPOINT &_size
                                     )
                           {
                            RCODE res = sizeSet( _size );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, size );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeGet( STRUCT_CLI_DRAWING_CPOINT    &_size /* [out] ::cli::drawing::CPoint _size  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->sizeGet(&_size);
                           }
                        
                        RCODE sizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_size /* [in,ref] ::cli::drawing::CPoint  _size  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->sizeSet(&_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        UINT get_sizeX( )
                           {
                            UINT tmpVal;
                            RCODE res = sizeXGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_sizeX( UINT _sizeX
                                      )
                           {
                            RCODE res = sizeXSet( _sizeX );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, UINT, sizeX );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeXGet( UINT*    _sizeX /* [out] uint _sizeX  */)
                           {
                        
                            return pif->sizeXGet(_sizeX);
                           }
                        
                        RCODE sizeXSet( UINT    _sizeX /* [in] uint  _sizeX  */)
                           {
                        
                            return pif->sizeXSet(_sizeX);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        UINT get_sizeY( )
                           {
                            UINT tmpVal;
                            RCODE res = sizeYGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_sizeY( UINT _sizeY
                                      )
                           {
                            RCODE res = sizeYSet( _sizeY );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, UINT, sizeY );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeYGet( UINT*    _sizeY /* [out] uint _sizeY  */)
                           {
                        
                            return pif->sizeYGet(_sizeY);
                           }
                        
                        RCODE sizeYSet( UINT    _sizeY /* [in] uint  _sizeY  */)
                           {
                        
                            return pif->sizeYSet(_sizeY);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IROW* get_rows( SIZE_T idx1 )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IROW* tmpVal;
                            RCODE res = rowsGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size_rows(  )
                           {
                            SIZE_T size;
                            RCODE res = rowsSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IROW*, rows, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowsGet( INTERFACE_CLI_GUI_CELLGRID_IROW**    _rows /* [out] ::cli::gui::cellgrid::iRow* _rows  */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
                           {
                        
                        
                            return pif->rowsGet(_rows, idx1);
                           }
                        
                        RCODE rowsSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->rowsSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_ICELL* get_cells( SIZE_T idx1
                                                                   , SIZE_T idx2
                                                                   )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_ICELL* tmpVal;
                            RCODE res = cellsGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_cells(  )
                           {
                            SIZE_T size;
                            RCODE res = cellsSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_cells( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = cellsSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_ICELL*, cells, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsGet( INTERFACE_CLI_GUI_CELLGRID_ICELL**    _cells /* [out] ::cli::gui::cellgrid::iCell* _cells  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                      )
                           {
                        
                        
                        
                            return pif->cellsGet(_cells, idx1, idx2);
                           }
                        
                        RCODE cellsSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellsSize1(_size);
                           }
                        
                        RCODE cellsSize2( SIZE_T*    _size /* [out] size_t _size  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        )
                           {
                        
                        
                            return pif->cellsSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        SIZE_T get_activeRow( )
                           {
                            SIZE_T tmpVal;
                            RCODE res = activeRowGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, activeRow );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeRowGet( SIZE_T*    _activeRow /* [out] size_t _activeRow  */)
                           {
                        
                            return pif->activeRowGet(_activeRow);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        SIZE_T get_activeCell( )
                           {
                            SIZE_T tmpVal;
                            RCODE res = activeCellGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, activeCell );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellGet( SIZE_T*    _activeCell /* [out] size_t _activeCell  */)
                           {
                        
                            return pif->activeCellGet(_activeCell);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_drawBackground( )
                           {
                            BOOL tmpVal;
                            RCODE res = drawBackgroundGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_drawBackground( BOOL _drawBackground
                                               )
                           {
                            RCODE res = drawBackgroundSet( _drawBackground );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, drawBackground );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE drawBackgroundGet( BOOL*    _drawBackground /* [out] bool _drawBackground  */)
                           {
                        
                            return pif->drawBackgroundGet(_drawBackground);
                           }
                        
                        RCODE drawBackgroundSet( BOOL    _drawBackground /* [in] bool  _drawBackground  */)
                           {
                        
                            return pif->drawBackgroundSet(_drawBackground);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_rowDrawBackground( )
                           {
                            BOOL tmpVal;
                            RCODE res = rowDrawBackgroundGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_rowDrawBackground( BOOL _rowDrawBackground
                                                  )
                           {
                            RCODE res = rowDrawBackgroundSet( _rowDrawBackground );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, rowDrawBackground );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowDrawBackgroundGet( BOOL*    _rowDrawBackground /* [out] bool _rowDrawBackground  */)
                           {
                        
                            return pif->rowDrawBackgroundGet(_rowDrawBackground);
                           }
                        
                        RCODE rowDrawBackgroundSet( BOOL    _rowDrawBackground /* [in] bool  _rowDrawBackground  */)
                           {
                        
                            return pif->rowDrawBackgroundSet(_rowDrawBackground);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_backgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = backgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_backgroundColor( COLORREF _backgroundColor
                                                )
                           {
                            RCODE res = backgroundColorSet( _backgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, backgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE backgroundColorGet( COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */)
                           {
                        
                            return pif->backgroundColorGet(_backgroundColor);
                           }
                        
                        RCODE backgroundColorSet( COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */)
                           {
                        
                            return pif->backgroundColorSet(_backgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_rowBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = rowBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_rowBackgroundColor( COLORREF _rowBackgroundColor
                                                   )
                           {
                            RCODE res = rowBackgroundColorSet( _rowBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, rowBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowBackgroundColorGet( COLORREF*    _rowBackgroundColor /* [out] colorref _rowBackgroundColor  */)
                           {
                        
                            return pif->rowBackgroundColorGet(_rowBackgroundColor);
                           }
                        
                        RCODE rowBackgroundColorSet( COLORREF    _rowBackgroundColor /* [in] colorref  _rowBackgroundColor  */)
                           {
                        
                            return pif->rowBackgroundColorSet(_rowBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_cellBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = cellBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellBackgroundColor( COLORREF _cellBackgroundColor
                                                    )
                           {
                            RCODE res = cellBackgroundColorSet( _cellBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, cellBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellBackgroundColorGet( COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */)
                           {
                        
                            return pif->cellBackgroundColorGet(_cellBackgroundColor);
                           }
                        
                        RCODE cellBackgroundColorSet( COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */)
                           {
                        
                            return pif->cellBackgroundColorSet(_cellBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeCellBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeCellBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCellBackgroundColor( COLORREF _activeCellBackgroundColor
                                                          )
                           {
                            RCODE res = activeCellBackgroundColorSet( _activeCellBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeCellBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellBackgroundColorGet( COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */)
                           {
                        
                            return pif->activeCellBackgroundColorGet(_activeCellBackgroundColor);
                           }
                        
                        RCODE activeCellBackgroundColorSet( COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */)
                           {
                        
                            return pif->activeCellBackgroundColorSet(_activeCellBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_CELLGRID_EALIGNMENT get_cellAlignment( )
                           {
                            ENUM_CLI_GUI_CELLGRID_EALIGNMENT tmpVal;
                            RCODE res = cellAlignmentGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellAlignment( ENUM_CLI_GUI_CELLGRID_EALIGNMENT _cellAlignment
                                              )
                           {
                            RCODE res = cellAlignmentSet( _cellAlignment );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_GUI_CELLGRID_EALIGNMENT, cellAlignment );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellAlignmentGet( ENUM_CLI_GUI_CELLGRID_EALIGNMENT*    _cellAlignment /* [out] ::cli::gui::cellgrid::EAlignment _cellAlignment  */)
                           {
                        
                            return pif->cellAlignmentGet(_cellAlignment);
                           }
                        
                        RCODE cellAlignmentSet( ENUM_CLI_GUI_CELLGRID_EALIGNMENT    _cellAlignment /* [in] ::cli::gui::cellgrid::EAlignment  _cellAlignment  */)
                           {
                        
                            return pif->cellAlignmentSet(_cellAlignment);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_disablePainting( )
                           {
                            BOOL tmpVal;
                            RCODE res = disablePaintingGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_disablePainting( BOOL _disablePainting
                                                )
                           {
                            RCODE res = disablePaintingSet( _disablePainting );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, disablePainting );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE disablePaintingGet( BOOL*    _disablePainting /* [out] bool _disablePainting  */)
                           {
                        
                            return pif->disablePaintingGet(_disablePainting);
                           }
                        
                        RCODE disablePaintingSet( BOOL    _disablePainting /* [in] bool  _disablePainting  */)
                           {
                        
                            return pif->disablePaintingSet(_disablePainting);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_cellsVisible( SIZE_T idx1
                                             , SIZE_T idx2
                                             )
                           {
                            BOOL tmpVal;
                            RCODE res = cellsVisibleGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellsVisible( SIZE_T idx1
                                             , SIZE_T idx2
                                             , BOOL _cellsVisible
                                             )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = cellsVisibleSet( _cellsVisible, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_cellsVisible(  )
                           {
                            SIZE_T size;
                            RCODE res = cellsVisibleSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_cellsVisible( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = cellsVisibleSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, cellsVisible, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsVisibleGet( BOOL*    _cellsVisible /* [out] bool _cellsVisible  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->cellsVisibleGet(_cellsVisible, idx1, idx2);
                           }
                        
                        RCODE cellsVisibleSet( BOOL    _cellsVisible /* [in] bool  _cellsVisible  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->cellsVisibleSet(_cellsVisible, idx1, idx2);
                           }
                        
                        RCODE cellsVisibleSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellsVisibleSize1(_size);
                           }
                        
                        RCODE cellsVisibleSize2( SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               )
                           {
                        
                        
                            return pif->cellsVisibleSize2(_size, idx1);
                           }
                        
                        RCODE getCellPosSize( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                            , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                                            )
                           {
                        
                        
                        
                        
                        
                        
                            return pif->getCellPosSize(rowIdx, cellIdx, ncLeftTop, ncWidthHeight, clientLeftTop, clientWidthHeight);
                           }
                        
                        RCODE setGridOwner( INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER*    pGridOwner /* [in] ::cli::gui::cellgrid::iGridOwner*  pGridOwner  */
                                          , SIZE_T    gridId /* [in] size_t  gridId  */
                                          )
                           {
                        
                        
                            return pif->setGridOwner(pGridOwner, gridId);
                           }
                        
                        RCODE getDrawContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
                           {
                        
                            return pif->getDrawContext(pdc);
                           }
                        
                        RCODE getDrawContextForRectUpdate( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                         , const STRUCT_CLI_DRAWING_CPOINT    &gridPosLeftTop /* [in,ref] ::cli::drawing::CPoint  gridPosLeftTop  (struct passed by ref in wrapper) */
                                                         , const STRUCT_CLI_DRAWING_CPOINT    &rectSize /* [in,ref] ::cli::drawing::CPoint  rectSize  (struct passed by ref in wrapper) */
                                                         )
                           {
                        
                        
                        
                            return pif->getDrawContextForRectUpdate(pdc, &gridPosLeftTop, &rectSize);
                           }
                        
                        RCODE getIUnknownIndex( INTERFACE_CLI_IUNKNOWN*    prow /* [in] ::cli::iUnknown*  prow  */
                                              , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                              )
                           {
                        
                        
                            return pif->getIUnknownIndex(prow, idxFound);
                           }
                        
                        RCODE getRowIndex( INTERFACE_CLI_GUI_CELLGRID_IROW*    prow /* [in] ::cli::gui::cellgrid::iRow*  prow  */
                                         , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                         )
                           {
                        
                        
                            return pif->getRowIndex(prow, idxFound);
                           }
                        
                        RCODE updateConfig( INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */)
                           {
                        
                            return pif->updateConfig(appCfg);
                           }
                        
                        RCODE calculateLimits( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */)
                           {
                        
                            return pif->calculateLimits(pdc);
                           }
                        
                        RCODE paint( )
                           {
                            return pif->paint();
                           }
                        
                        RCODE paintUpdate( SIZE_T    paintStartingRow /* [in] size_t  paintStartingRow  */)
                           {
                        
                            return pif->paintUpdate(paintStartingRow);
                           }
                        
                        RCODE getCellDrawContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                )
                           {
                        
                        
                        
                            return pif->getCellDrawContext(pdc, rowIdx, cellIdx);
                           }
                        
                        RCODE paintCellOnContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                )
                           {
                        
                        
                        
                            return pif->paintCellOnContext(pdc, rowIdx, cellIdx);
                           }
                        
                        RCODE paintCell( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                       )
                           {
                        
                        
                            return pif->paintCell(rowIdx, cellIdx);
                           }
                        
                        RCODE rowSizeChangedNotify( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                  , BOOL    bRepaint /* [in] bool  bRepaint  */
                                                  )
                           {
                        
                        
                            return pif->rowSizeChangedNotify(rowIdx, bRepaint);
                           }
                        
                        RCODE allRowsSizeChangedNotify( BOOL    bRepaint /* [in] bool  bRepaint  */)
                           {
                        
                            return pif->allRowsSizeChangedNotify(bRepaint);
                           }
                        
                        RCODE insertRow( INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                                       , SIZE_T    idx /* [in] size_t  idx  */
                                       )
                           {
                        
                        
                            return pif->insertRow(pRow, idx);
                           }
                        
                        RCODE addRow( INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */)
                           {
                        
                            return pif->addRow(pRow);
                           }
                        
                        RCODE removeRow( SIZE_T    atPos /* [in] size_t  atPos  */)
                           {
                        
                            return pif->removeRow(atPos);
                           }
                        
                        RCODE getLimits( STRUCT_CLI_DRAWING_CPOINT    &minSize /* [out] ::cli::drawing::CPoint minSize  (struct passed by ref in wrapper) */
                                       , STRUCT_CLI_DRAWING_CPOINT    &maxSize /* [out] ::cli::drawing::CPoint maxSize  (struct passed by ref in wrapper) */
                                       )
                           {
                        
                        
                            return pif->getLimits(&minSize, &maxSize);
                           }
                        
                        RCODE hitTest( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                     , SIZE_T*    hitRow /* [out] size_t hitRow  */
                                     , SIZE_T*    hitCell /* [out] size_t hitCell  */
                                     , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                                     )
                           {
                        
                        
                        
                        
                            return pif->hitTest(&micePos, hitRow, hitCell, resFlags);
                           }
                        
                        RCODE onMouseMove( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->onMouseMove(&micePos);
                           }
                        
                        RCODE onMouseClick( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                          , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                          )
                           {
                        
                        
                            return pif->onMouseClick(&micePos, eventFlags);
                           }
                        

                
                
                }; // class CiGridWrapper
                
                typedef CiGridWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IGRID     > >  CiGrid;
                typedef CiGridWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_IGRID > >  CiGrid_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iCell */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_ICELL_IID
    #define INTERFACE_CLI_GUI_CELLGRID_ICELL_IID    "/cli/gui/cellgrid/iCell"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iCell
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ICELL
       #define INTERFACE_CLI_GUI_CELLGRID_ICELL    ::cli::gui::cellgrid::iCell
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iCell
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ICELL
       #define INTERFACE_CLI_GUI_CELLGRID_ICELL    cli_gui_cellgrid_iCell
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iCell methods */
                    CLIMETHOD(activeCellGet) (THIS_ BOOL*    _activeCell /* [out] bool _activeCell  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(activeCellSet) (THIS_ BOOL    _activeCell /* [in] bool  _activeCell  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(activeCellSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(activeCellSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               ) PURE;
                    CLIMETHOD(hotTrackedGet) (THIS_ BOOL*    _hotTracked /* [out] bool _hotTracked  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(hotTrackedSet) (THIS_ BOOL    _hotTracked /* [in] bool  _hotTracked  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(hotTrackedSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(hotTrackedSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               ) PURE;
                    CLIMETHOD(autoHotTrackGet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack _autoHotTrack  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(autoHotTrackSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(autoHotTrackSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 ) PURE;
                    CLIMETHOD(ownerRowGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* _ownerRow  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(ownerRowSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  _ownerRow  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(ownerRowSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(ownerRowSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             ) PURE;
                    CLIMETHOD(visibleGet) (THIS_ BOOL*    _visible /* [out] bool _visible  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(visibleSet) (THIS_ BOOL    _visible /* [in] bool  _visible  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(visibleSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(visibleSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [out] ::cli::gui::cellgrid::CSpacing _spacing  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _spacing  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(spacingSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(spacingSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(resetSpacing) (THIS_ SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                            ) PURE;
                    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool _drawBackground  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                 ) PURE;
                    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  _drawBackground  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                 ) PURE;
                    CLIMETHOD(drawBackgroundSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(drawBackgroundSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                   ) PURE;
                    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */
                                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                  ) PURE;
                    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */
                                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                  ) PURE;
                    CLIMETHOD(backgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(backgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    ) PURE;
                    CLIMETHOD(activeBackgroundColorGet) (THIS_ COLORREF*    _activeBackgroundColor /* [out] colorref _activeBackgroundColor  */
                                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                        ) PURE;
                    CLIMETHOD(activeBackgroundColorSet) (THIS_ COLORREF    _activeBackgroundColor /* [in] colorref  _activeBackgroundColor  */
                                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                        ) PURE;
                    CLIMETHOD(activeBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(activeBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                          ) PURE;
                    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                            ) PURE;
                    CLIMETHOD(ownerGridSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(ownerGridSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              ) PURE;
                    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                            ) PURE;
                    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       ) PURE;
                    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       ) PURE;
                    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       ) PURE;
                    CLIMETHOD(sizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(sizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         ) PURE;
                    CLIMETHOD(minSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [out] ::cli::drawing::CPoint _minSize  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(minSizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(minSizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(maxSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [out] ::cli::drawing::CPoint _maxSize  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(maxSizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(maxSizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         ) PURE;
                    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                                , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                           ) PURE;
                    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                                 , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                 , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                            ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iCell >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_ICELL_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iCell* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iCell > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iCell wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_ICELL >
                                              */
                         >
                class CiCellWrapper
                {
                    public:
                
                        typedef  CiCellWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiCellWrapper() :
                           pif(0) {}
                
                        CiCellWrapper( iCell *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiCellWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiCellWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiCellWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiCellWrapper(const CiCellWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiCellWrapper()  { }
                
                        CiCellWrapper& operator=(const CiCellWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_activeCell( SIZE_T idx1
                                           , SIZE_T idx2
                                           )
                           {
                            BOOL tmpVal;
                            RCODE res = activeCellGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCell( SIZE_T idx1
                                           , SIZE_T idx2
                                           , BOOL _activeCell
                                           )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = activeCellSet( _activeCell, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_activeCell(  )
                           {
                            SIZE_T size;
                            RCODE res = activeCellSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_activeCell( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = activeCellSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, activeCell, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellGet( BOOL*    _activeCell /* [out] bool _activeCell  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->activeCellGet(_activeCell, idx1, idx2);
                           }
                        
                        RCODE activeCellSet( BOOL    _activeCell /* [in] bool  _activeCell  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->activeCellSet(_activeCell, idx1, idx2);
                           }
                        
                        RCODE activeCellSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->activeCellSize1(_size);
                           }
                        
                        RCODE activeCellSize2( SIZE_T*    _size /* [out] size_t _size  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
                           {
                        
                        
                            return pif->activeCellSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_hotTracked( SIZE_T idx1
                                           , SIZE_T idx2
                                           )
                           {
                            BOOL tmpVal;
                            RCODE res = hotTrackedGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_hotTracked( SIZE_T idx1
                                           , SIZE_T idx2
                                           , BOOL _hotTracked
                                           )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = hotTrackedSet( _hotTracked, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_hotTracked(  )
                           {
                            SIZE_T size;
                            RCODE res = hotTrackedSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_hotTracked( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = hotTrackedSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, hotTracked, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE hotTrackedGet( BOOL*    _hotTracked /* [out] bool _hotTracked  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->hotTrackedGet(_hotTracked, idx1, idx2);
                           }
                        
                        RCODE hotTrackedSet( BOOL    _hotTracked /* [in] bool  _hotTracked  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->hotTrackedSet(_hotTracked, idx1, idx2);
                           }
                        
                        RCODE hotTrackedSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->hotTrackedSize1(_size);
                           }
                        
                        RCODE hotTrackedSize2( SIZE_T*    _size /* [out] size_t _size  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
                           {
                        
                        
                            return pif->hotTrackedSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK get_autoHotTrack( SIZE_T idx1
                                                                            , SIZE_T idx2
                                                                            )
                           {
                            ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK tmpVal;
                            RCODE res = autoHotTrackGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_autoHotTrack(  )
                           {
                            SIZE_T size;
                            RCODE res = autoHotTrackSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_autoHotTrack( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = autoHotTrackSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK, autoHotTrack, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE autoHotTrackGet( ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack _autoHotTrack  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->autoHotTrackGet(_autoHotTrack, idx1, idx2);
                           }
                        
                        RCODE autoHotTrackSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->autoHotTrackSize1(_size);
                           }
                        
                        RCODE autoHotTrackSize2( SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               )
                           {
                        
                        
                            return pif->autoHotTrackSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IROW* get_ownerRow( SIZE_T idx1
                                                                     , SIZE_T idx2
                                                                     )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IROW* tmpVal;
                            RCODE res = ownerRowGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ownerRow( SIZE_T idx1
                                         , SIZE_T idx2
                                         , INTERFACE_CLI_GUI_CELLGRID_IROW* _ownerRow
                                         )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = ownerRowSet( _ownerRow, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_ownerRow(  )
                           {
                            SIZE_T size;
                            RCODE res = ownerRowSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_ownerRow( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = ownerRowSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IROW*, ownerRow, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ownerRowGet( INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* _ownerRow  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                            return pif->ownerRowGet(_ownerRow, idx1, idx2);
                           }
                        
                        RCODE ownerRowSet( INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  _ownerRow  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                            return pif->ownerRowSet(_ownerRow, idx1, idx2);
                           }
                        
                        RCODE ownerRowSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->ownerRowSize1(_size);
                           }
                        
                        RCODE ownerRowSize2( SIZE_T*    _size /* [out] size_t _size  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           )
                           {
                        
                        
                            return pif->ownerRowSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_visible( SIZE_T idx1
                                        , SIZE_T idx2
                                        )
                           {
                            BOOL tmpVal;
                            RCODE res = visibleGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_visible( SIZE_T idx1
                                        , SIZE_T idx2
                                        , BOOL _visible
                                        )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = visibleSet( _visible, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_visible(  )
                           {
                            SIZE_T size;
                            RCODE res = visibleSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_visible( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = visibleSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, visible, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE visibleGet( BOOL*    _visible /* [out] bool _visible  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->visibleGet(_visible, idx1, idx2);
                           }
                        
                        RCODE visibleSet( BOOL    _visible /* [in] bool  _visible  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->visibleSet(_visible, idx1, idx2);
                           }
                        
                        RCODE visibleSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->visibleSize1(_size);
                           }
                        
                        RCODE visibleSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->visibleSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CELLGRID_CSPACING get_spacing( SIZE_T idx1
                                                                    , SIZE_T idx2
                                                                    )
                           {
                            STRUCT_CLI_GUI_CELLGRID_CSPACING tmpVal;
                            RCODE res = spacingGet( tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_spacing( SIZE_T idx1
                                        , SIZE_T idx2
                                        , const STRUCT_CLI_GUI_CELLGRID_CSPACING &_spacing
                                        )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = spacingSet( _spacing, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_spacing(  )
                           {
                            SIZE_T size;
                            RCODE res = spacingSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_spacing( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = spacingSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, STRUCT_CLI_GUI_CELLGRID_CSPACING, spacing, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE spacingGet( STRUCT_CLI_GUI_CELLGRID_CSPACING    &_spacing /* [out] ::cli::gui::cellgrid::CSpacing _spacing  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->spacingGet(&_spacing, idx1, idx2);
                           }
                        
                        RCODE spacingSet( const STRUCT_CLI_GUI_CELLGRID_CSPACING    &_spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  _spacing  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->spacingSet(&_spacing, idx1, idx2);
                           }
                        
                        RCODE spacingSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->spacingSize1(_size);
                           }
                        
                        RCODE spacingSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->spacingSize2(_size, idx1);
                           }
                        
                        RCODE resetSpacing( SIZE_T    idx1 /* [in] size_t  idx1  */
                                          , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          )
                           {
                        
                        
                            return pif->resetSpacing(idx1, idx2);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_drawBackground( SIZE_T idx1
                                               , SIZE_T idx2
                                               )
                           {
                            BOOL tmpVal;
                            RCODE res = drawBackgroundGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_drawBackground( SIZE_T idx1
                                               , SIZE_T idx2
                                               , BOOL _drawBackground
                                               )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = drawBackgroundSet( _drawBackground, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_drawBackground(  )
                           {
                            SIZE_T size;
                            RCODE res = drawBackgroundSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_drawBackground( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = drawBackgroundSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, drawBackground, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE drawBackgroundGet( BOOL*    _drawBackground /* [out] bool _drawBackground  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               )
                           {
                        
                        
                        
                            return pif->drawBackgroundGet(_drawBackground, idx1, idx2);
                           }
                        
                        RCODE drawBackgroundSet( BOOL    _drawBackground /* [in] bool  _drawBackground  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               )
                           {
                        
                        
                        
                            return pif->drawBackgroundSet(_drawBackground, idx1, idx2);
                           }
                        
                        RCODE drawBackgroundSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->drawBackgroundSize1(_size);
                           }
                        
                        RCODE drawBackgroundSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 )
                           {
                        
                        
                            return pif->drawBackgroundSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_backgroundColor( SIZE_T idx1
                                                    , SIZE_T idx2
                                                    )
                           {
                            COLORREF tmpVal;
                            RCODE res = backgroundColorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_backgroundColor( SIZE_T idx1
                                                , SIZE_T idx2
                                                , COLORREF _backgroundColor
                                                )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = backgroundColorSet( _backgroundColor, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_backgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = backgroundColorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_backgroundColor( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = backgroundColorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, COLORREF, backgroundColor, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE backgroundColorGet( COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                )
                           {
                        
                        
                        
                            return pif->backgroundColorGet(_backgroundColor, idx1, idx2);
                           }
                        
                        RCODE backgroundColorSet( COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                )
                           {
                        
                        
                        
                            return pif->backgroundColorSet(_backgroundColor, idx1, idx2);
                           }
                        
                        RCODE backgroundColorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->backgroundColorSize1(_size);
                           }
                        
                        RCODE backgroundColorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  )
                           {
                        
                        
                            return pif->backgroundColorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeBackgroundColor( SIZE_T idx1
                                                          , SIZE_T idx2
                                                          )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeBackgroundColorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeBackgroundColor( SIZE_T idx1
                                                      , SIZE_T idx2
                                                      , COLORREF _activeBackgroundColor
                                                      )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = activeBackgroundColorSet( _activeBackgroundColor, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_activeBackgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = activeBackgroundColorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_activeBackgroundColor( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = activeBackgroundColorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, COLORREF, activeBackgroundColor, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeBackgroundColorGet( COLORREF*    _activeBackgroundColor /* [out] colorref _activeBackgroundColor  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                      )
                           {
                        
                        
                        
                            return pif->activeBackgroundColorGet(_activeBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE activeBackgroundColorSet( COLORREF    _activeBackgroundColor /* [in] colorref  _activeBackgroundColor  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                      )
                           {
                        
                        
                        
                            return pif->activeBackgroundColorSet(_activeBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE activeBackgroundColorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->activeBackgroundColorSize1(_size);
                           }
                        
                        RCODE activeBackgroundColorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                        )
                           {
                        
                        
                            return pif->activeBackgroundColorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IGRID* get_ownerGrid( SIZE_T idx1
                                                                       , SIZE_T idx2
                                                                       )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IGRID* tmpVal;
                            RCODE res = ownerGridGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_ownerGrid(  )
                           {
                            SIZE_T size;
                            RCODE res = ownerGridSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_ownerGrid( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = ownerGridSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IGRID*, ownerGrid, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ownerGridGet( INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          )
                           {
                        
                        
                        
                            return pif->ownerGridGet(_ownerGrid, idx1, idx2);
                           }
                        
                        RCODE ownerGridSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->ownerGridSize1(_size);
                           }
                        
                        RCODE ownerGridSize2( SIZE_T*    _size /* [out] size_t _size  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            )
                           {
                        
                        
                            return pif->ownerGridSize2(_size, idx1);
                           }
                        
                        RCODE updateConfig( INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          )
                           {
                        
                        
                        
                            return pif->updateConfig(appCfg, idx1, idx2);
                           }
                        
                        RCODE calculateLimits( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->calculateLimits(pdc, idx1, idx2);
                           }
                        
                        RCODE ncPaint( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                     , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     , SIZE_T    idx2 /* [in] size_t  idx2  */
                                     )
                           {
                        
                        
                        
                        
                            return pif->ncPaint(pdc, &paintAreaSize, idx1, idx2);
                           }
                        
                        RCODE paintClient( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                        
                            return pif->paintClient(pdc, &paintAreaSize, idx1, idx2);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_size( SIZE_T idx1
                                                          , SIZE_T idx2
                                                          )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = sizeGet( tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_size( SIZE_T idx1
                                     , SIZE_T idx2
                                     , const STRUCT_CLI_DRAWING_CPOINT &_size
                                     )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = sizeSet( _size, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_size(  )
                           {
                            SIZE_T size;
                            RCODE res = sizeSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_size( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = sizeSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, size, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeGet( STRUCT_CLI_DRAWING_CPOINT    &_size /* [out] ::cli::drawing::CPoint _size  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     , SIZE_T    idx2 /* [in] size_t  idx2  */
                                     )
                           {
                        
                        
                        
                            return pif->sizeGet(&_size, idx1, idx2);
                           }
                        
                        RCODE sizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_size /* [in,ref] ::cli::drawing::CPoint  _size  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     , SIZE_T    idx2 /* [in] size_t  idx2  */
                                     )
                           {
                        
                        
                        
                            return pif->sizeSet(&_size, idx1, idx2);
                           }
                        
                        RCODE sizeSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->sizeSize1(_size);
                           }
                        
                        RCODE sizeSize2( SIZE_T*    _size /* [out] size_t _size  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       )
                           {
                        
                        
                            return pif->sizeSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_minSize( SIZE_T idx1
                                                             , SIZE_T idx2
                                                             )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = minSizeGet( tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_minSize(  )
                           {
                            SIZE_T size;
                            RCODE res = minSizeSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_minSize( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = minSizeSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, minSize, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE minSizeGet( STRUCT_CLI_DRAWING_CPOINT    &_minSize /* [out] ::cli::drawing::CPoint _minSize  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->minSizeGet(&_minSize, idx1, idx2);
                           }
                        
                        RCODE minSizeSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->minSizeSize1(_size);
                           }
                        
                        RCODE minSizeSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->minSizeSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_maxSize( SIZE_T idx1
                                                             , SIZE_T idx2
                                                             )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = maxSizeGet( tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_maxSize(  )
                           {
                            SIZE_T size;
                            RCODE res = maxSizeSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_maxSize( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = maxSizeSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, maxSize, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE maxSizeGet( STRUCT_CLI_DRAWING_CPOINT    &_maxSize /* [out] ::cli::drawing::CPoint _maxSize  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->maxSizeGet(&_maxSize, idx1, idx2);
                           }
                        
                        RCODE maxSizeSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->maxSizeSize1(_size);
                           }
                        
                        RCODE maxSizeSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->maxSizeSize2(_size, idx1);
                           }
                        
                        RCODE getLimits( STRUCT_CLI_DRAWING_CPOINT    &minSize /* [out] ::cli::drawing::CPoint minSize  (struct passed by ref in wrapper) */
                                       , STRUCT_CLI_DRAWING_CPOINT    &maxSize /* [out] ::cli::drawing::CPoint maxSize  (struct passed by ref in wrapper) */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       )
                           {
                        
                        
                        
                        
                            return pif->getLimits(&minSize, &maxSize, idx1, idx2);
                           }
                        
                        RCODE onMouseMove( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                         , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                         , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                         )
                           {
                        
                        
                        
                            return pif->onMouseMove(&micePos, rowIdx, cellIdx);
                           }
                        
                        RCODE onMouseClick( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                          , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                          , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                          , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                          )
                           {
                        
                        
                        
                        
                            return pif->onMouseClick(&micePos, rowIdx, cellIdx, eventFlags);
                           }
                        

                
                
                }; // class CiCellWrapper
                
                typedef CiCellWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_ICELL     > >  CiCell;
                typedef CiCellWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_ICELL > >  CiCell_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iGridOwner */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER_IID
    #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER_IID    "/cli/gui/cellgrid/iGridOwner"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iGridOwner
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER
       #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER    ::cli::gui::cellgrid::iGridOwner
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iGridOwner
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER
       #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER    cli_gui_cellgrid_iGridOwner
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iGridOwner methods */
                    CLIMETHOD(getDrawContext) (THIS_ SIZE_T    gridId /* [in] size_t  gridId  */
                                                   , INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                              ) PURE;
                    CLIMETHOD(getDrawContextForRectUpdate) (THIS_ SIZE_T    gridId /* [in] size_t  gridId  */
                                                                , INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                                , const STRUCT_CLI_DRAWING_CPOINT*    gridPosLeftTop /* [in,ref] ::cli::drawing::CPoint  gridPosLeftTop  */
                                                                , const STRUCT_CLI_DRAWING_CPOINT*    rectSize /* [in,ref] ::cli::drawing::CPoint  rectSize  */
                                                           ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iGridOwner >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iGridOwner* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iGridOwner > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iGridOwner wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER >
                                              */
                         >
                class CiGridOwnerWrapper
                {
                    public:
                
                        typedef  CiGridOwnerWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiGridOwnerWrapper() :
                           pif(0) {}
                
                        CiGridOwnerWrapper( iGridOwner *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiGridOwnerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiGridOwnerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiGridOwnerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiGridOwnerWrapper(const CiGridOwnerWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiGridOwnerWrapper()  { }
                
                        CiGridOwnerWrapper& operator=(const CiGridOwnerWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        RCODE getDrawContext( SIZE_T    gridId /* [in] size_t  gridId  */
                                            , INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                            )
                           {
                        
                        
                            return pif->getDrawContext(gridId, pdc);
                           }
                        
                        RCODE getDrawContextForRectUpdate( SIZE_T    gridId /* [in] size_t  gridId  */
                                                         , INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                         , const STRUCT_CLI_DRAWING_CPOINT    &gridPosLeftTop /* [in,ref] ::cli::drawing::CPoint  gridPosLeftTop  (struct passed by ref in wrapper) */
                                                         , const STRUCT_CLI_DRAWING_CPOINT    &rectSize /* [in,ref] ::cli::drawing::CPoint  rectSize  (struct passed by ref in wrapper) */
                                                         )
                           {
                        
                        
                        
                        
                            return pif->getDrawContextForRectUpdate(gridId, pdc, &gridPosLeftTop, &rectSize);
                           }
                        

                
                
                }; // class CiGridOwnerWrapper
                
                typedef CiGridOwnerWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER     > >  CiGridOwner;
                typedef CiGridOwnerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER > >  CiGridOwner_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif





#endif /* CLI_GUI_CELLGRID_H */
