#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_COMMANDIMPLBASE_H
#define CLI_GUI_COMMANDIMPLBASE_H

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_COMMANDIMPLBASE_H
    #include <cli/gui/commandImplBase.h>
#endif
*/

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_GUI_ICOMMAND_H
    #include <cli/gui/iCommand.h>
#endif

#ifndef CLI_GUI_IMENUBUILDER_H
    #include <cli/gui/iMenuBuilder.h>
#endif


namespace cli
{
namespace gui
{
namespace impl
{

inline
INTERFACE_CLI_GUI_ICOMMAND* reuseCommandHandler( INTERFACE_CLI_GUI_ICOMMAND *pHandler )
   {
    if (pHandler) pHandler->addRef();
    return pHandler;
   }


class CCommandImplBase : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_GUI_ICOMMAND
{

public:
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CLI_BEGIN_INTERFACE_MAP2(CCommandImplBase, INTERFACE_CLI_GUI_ICOMMAND)
    //CLI_BEGIN_INTERFACE_MAP(CCellImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_ICOMMAND )
    CLI_END_INTERFACE_MAP(CCommandImplBase)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    // define 'destroy' in descendants
    //void destroy() { delete this; }

    CCommandImplBase() : base_impl(DEF_MODULE) {}

    CLIMETHOD(syncItemUiState)(THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                              , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                              , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                              , INTERFACE_CLI_IUNKNOWN*    pUnkAppData /* [in,optional] ::cli::iUnknown*  iUnkAppData  */
                              , const VOID*    pvData /* [in,optional] void*  pvData  */
                              , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                         )
       {
        return EC_OK;
       }


}; // class CCommandImplBase

}; // namespace impl
}; // namespace gui
}; // namespace cli


#define BEGIN_IMPLEMENT_CLI_GUI_COMMANDHANDLER(className)                       \
        class className : public ::cli::gui::impl::CCommandImplBase     \
        {                                                               \
            public:                                                     \
                typedef ::cli::gui::impl::CCommandImplBase command_base_impl;                \
            CLIMETHOD(commandHandler) (THIS_ const WCHAR*    cmdName                         \
                                           , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder \
                                           , INTERFACE_CLI_APP_ICONFIG*    pAppConfig        \
                                           , INTERFACE_CLI_IUNKNOWN*    pUnkAppData          \
                                           , const VOID*    pvData                           \
                                           , INTERFACE_CLI_IARGLIST*    pArgs                \
                                      )


#define END_IMPLEMENT_CLI_GUI_COMMANDHANDLER(className)      \
            CLIMETHOD_(VOID, destroy) (THIS)                 \
               {                                             \
                delete this;                                 \
               }                                             \
            };


namespace cli
{
namespace gui
{
namespace impl
{


// deprecated: use CCommonCommandHandler instead
#include <cli/compspec/pdelnvdtoroff.h>
template <typename THandler>
BEGIN_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CCommandHandlerTemplate)
   {
    handler(); return EC_OK;
   }
CCommandHandlerTemplate( const THandler &th ) : handler(th) {}
THandler handler;
END_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CCommandHandlerTemplate)
#include <cli/compspec/pdelnvdtoron.h>

// similar to CCommandHandlerTemplate
#include <cli/compspec/pdelnvdtoroff.h>
template <typename THandler>
BEGIN_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CCommonCommandHandler)
   {
    handler(); return EC_OK;
   }
CCommonCommandHandler( const THandler &th ) : handler(th) {}
THandler handler;
END_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CCommonCommandHandler)
#include <cli/compspec/pdelnvdtoron.h>



template <typename THandler>
INTERFACE_CLI_GUI_ICOMMAND* createCommonCommandHandler( const THandler &handler )
   {
    return new CCommonCommandHandler< THandler >( handler );
   }

#include <cli/compspec/pdelnvdtoroff.h>
BEGIN_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CCommandDoNothingHandler) { return EC_OK; }
CCommandDoNothingHandler() {}
END_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CCommandDoNothingHandler)
#include <cli/compspec/pdelnvdtoron.h>


template <typename TOwner>
struct CSimpleMemberCommandHandler
{
    typedef void (TOwner::*handler_func_t)();

    TOwner          *pOwner;
    handler_func_t  func;
    CSimpleMemberCommandHandler( TOwner *po, handler_func_t f) : pOwner(po), func(f) {}
    void operator()()
       {
        (pOwner->*func)();
       }
};

template <typename TOwner>
INTERFACE_CLI_GUI_ICOMMAND* 
createSimpleMemberCommandHandler( TOwner *pOwner
                                , typename CSimpleMemberCommandHandler< TOwner > :: handler_func_t func
                                )
   {
    return createCommonCommandHandler( CSimpleMemberCommandHandler<TOwner>(pOwner, func) );
   }






//-----------------------------------------------------------------------------
#include <cli/compspec/pdelnvdtoroff.h>
BEGIN_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CBaseRadioItemHandler)
   {
    this->cmdName       = cmdName;
    this->pMenuBuilder  = pMenuBuilder;
    this->pAppConfig    = pAppConfig;
    this->pUnkAppData   = pUnkAppData;
    this->pvData        = pvData;
    this->pArgs         = pArgs;
 
    if (!pMenuBuilder) return EC_OK; // can't perform job
    if (pMenuBuilder->getCommandId( cmdName, &cmdId )) return EC_OK; // can't perform job
    if (pMenuBuilder->getCommandByIdRadioGroup( cmdId, &rgId )) return EC_OK; // can't perform job
 
    SIZE_T newRadioIndex = SIZE_T_NPOS;
    if (!pMenuBuilder->getRadioIndexById2( cmdId, rgId, &newRadioIndex ))
       {
        pMenuBuilder->setRadioCheckedById( newRadioIndex, rgId );
        applyRadioIndex(newRadioIndex);
       }
     return EC_OK;
   }

CLIMETHOD(syncItemUiState)(THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                          , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                          , INTERFACE_CLI_APP_ICONFIG*    pAppConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                          , INTERFACE_CLI_IUNKNOWN*    pUnkAppData /* [in,optional] ::cli::iUnknown*  iUnkAppData  */
                          , const VOID*    pvData /* [in,optional] void*  pvData  */
                          , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                     )
   {
    this->cmdName       = cmdName;
    this->pMenuBuilder  = pMenuBuilder;
    this->pAppConfig    = pAppConfig;
    this->pUnkAppData   = pUnkAppData;
    this->pvData        = pvData;
    this->pArgs         = pArgs;
    if (!this->cmdName || !this->pMenuBuilder) return EC_OK;
    syncState();
    return EC_OK;
   }

const WCHAR                       *cmdName;
INTERFACE_CLI_GUI_IMENUBUILDER    *pMenuBuilder;
INTERFACE_CLI_APP_ICONFIG         *pAppConfig;
INTERFACE_CLI_IUNKNOWN            *pUnkAppData;
const VOID                        *pvData;
INTERFACE_CLI_IARGLIST            *pArgs;
SIZE_T                             cmdId;
SIZE_T                             rgId;

virtual void applyRadioIndex( SIZE_T radioIndex ) = 0;
virtual void syncState( ) {}

END_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CBaseRadioItemHandler)
#include <cli/compspec/pdelnvdtoron.h>

//-----------------------------------------------------------------------------

#include <cli/compspec/pdelnvdtoroff.h>
BEGIN_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CBaseCheckItemHandler)
   {
    this->cmdName       = cmdName;
    this->pMenuBuilder  = pMenuBuilder;
    this->pAppConfig    = pAppConfig;
    this->pUnkAppData   = pUnkAppData;
    this->pvData        = pvData;
    this->pArgs         = pArgs;
 
    if (!pMenuBuilder) return EC_OK; // can't perform job
    if (pMenuBuilder->getCommandId( cmdName, &cmdId )) return EC_OK; // can't perform job
 
    ENUM_CLI_GUI_EMENUITEMFLAGS flags = 0;
    if (!pMenuBuilder->getCommandByIdState( cmdId, &flags ))
       {
        BOOL state = FALSE;
        if (flags&CLI_GUI_EMENUITEMFLAGS_FCHECKED) // currently checked
           {
            flags &= ~CLI_GUI_EMENUITEMFLAGS_FCHECKED;
            state = FALSE; // new state applied - unchecked
           }
        else
           {
            flags |= CLI_GUI_EMENUITEMFLAGS_FCHECKED;
            state = TRUE;
           }
        pMenuBuilder->setCommandByIdState( cmdId, flags );
        applyCheckState(state);
       }
    return EC_OK;
   }

CLIMETHOD(syncItemUiState)(THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                          , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                          , INTERFACE_CLI_APP_ICONFIG*    pAppConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                          , INTERFACE_CLI_IUNKNOWN*    iUnkAppData /* [in,optional] ::cli::iUnknown*  iUnkAppData  */
                          , const VOID*    pvData /* [in,optional] void*  pvData  */
                          , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                     )
   {
    this->cmdName       = cmdName;
    this->pMenuBuilder  = pMenuBuilder;
    this->pAppConfig    = pAppConfig;
    this->pUnkAppData   = pUnkAppData;
    this->pvData        = pvData;
    this->pArgs         = pArgs;
    if (!this->cmdName || !this->pMenuBuilder) return EC_OK;
    syncState();
    return EC_OK;
   }

const WCHAR                       *cmdName;
INTERFACE_CLI_GUI_IMENUBUILDER    *pMenuBuilder;
INTERFACE_CLI_APP_ICONFIG         *pAppConfig;
INTERFACE_CLI_IUNKNOWN            *pUnkAppData;
const VOID                        *pvData;
INTERFACE_CLI_IARGLIST            *pArgs;
SIZE_T                             cmdId;

virtual void applyCheckState(BOOL state ) = 0;
virtual void syncState( ) {}

END_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CBaseCheckItemHandler)
#include <cli/compspec/pdelnvdtoron.h>
//-----------------------------------------------------------------------------





}; // namespace impl
}; // namespace gui
}; // namespace cli


#define BEGIN_IMPLEMENT_CLI_GUI_RADIOHANDLER(className)                                 \
        class className : public ::cli::gui::impl::CBaseRadioItemHandler                \
        {                                                                               \
            public:                                                                     \
                typedef ::cli::gui::impl::CBaseRadioItemHandler command_base_impl;      \
                void applyRadioIndex( SIZE_T radioIndex )                               \

#define END_IMPLEMENT_CLI_GUI_RADIOHANDLER(className)          \
                CLIMETHOD_(VOID, destroy) (THIS)               \
                   {                                           \
                       delete this;                            \
                   }                                           \
        };


#define BEGIN_IMPLEMENT_CLI_GUI_CHECKHANDLER(className)                                 \
        class className : public ::cli::gui::impl::CBaseCheckItemHandler                \
        {                                                                               \
            public:                                                                     \
                typedef ::cli::gui::impl::CBaseCheckItemHandler command_base_impl;      \
                void applyCheckState(BOOL state )                                       \

#define END_IMPLEMENT_CLI_GUI_CHECKHANDLER(className)    \
                CLIMETHOD_(VOID, destroy) (THIS)         \
                   {                                     \
                       delete this;                      \
                   }                                     \
        };


#define IMPLEMENT_CLI_GUI_HANDLER_SYNCSTATE() \
        virtual void syncState( )




namespace cli
{
namespace gui
{
namespace impl
{

#include <cli/compspec/pdelnvdtoroff.h>
template <typename THANDLER>
BEGIN_IMPLEMENT_CLI_GUI_RADIOHANDLER(CRadioCommandHandlerTemplate)
   {
    handler(radioIndex); // SIZE_T radioIndex
   }
CRadioCommandHandlerTemplate( const THANDLER &th ) : handler(th) {}
THANDLER handler;
END_IMPLEMENT_CLI_GUI_RADIOHANDLER(CRadioCommandHandlerTemplate)
#include <cli/compspec/pdelnvdtoron.h>


#include <cli/compspec/pdelnvdtoroff.h>
template <typename THANDLER>
BEGIN_IMPLEMENT_CLI_GUI_CHECKHANDLER(CCheckCommandHandlerTemplate)
   {
    handler(state);
   }
CCheckCommandHandlerTemplate( const THANDLER &th ) : handler(th) {}
THANDLER handler;
IMPLEMENT_CLI_GUI_HANDLER_SYNCSTATE()
   {
    if (!pMenuBuilder) return; // can't perform job
    if (pMenuBuilder->getCommandId( cmdName, &cmdId )) return; // can't perform job
 
    ENUM_CLI_GUI_EMENUITEMFLAGS flags = 0;
    if (pMenuBuilder->getCommandByIdState( cmdId, &flags )) return; // can't perform job

    if ( handler() )
       flags |= CLI_GUI_EMENUITEMFLAGS_FCHECKED;
    else
       flags &= ~CLI_GUI_EMENUITEMFLAGS_FCHECKED;

    pMenuBuilder->setCommandByIdState( cmdId, flags );
    //applyCheckState(state);
   }
END_IMPLEMENT_CLI_GUI_CHECKHANDLER(CCheckCommandHandlerTemplate)
#include <cli/compspec/pdelnvdtoron.h>




template <typename THandler>
INTERFACE_CLI_GUI_ICOMMAND* createCheckCommandHandler( const THandler &handler )
   {
    return new CCheckCommandHandlerTemplate< THandler >( handler );
   }


template <typename TOwner>
struct CSimpleCheckMemberCommandHandler
{
    typedef void (TOwner::*handler_func_t)(BOOL state);
    typedef bool (TOwner::*state_func_t)();

    TOwner          *pOwner;
    handler_func_t   func;
    state_func_t     stateFunc;
    CSimpleCheckMemberCommandHandler( TOwner *po, handler_func_t f, state_func_t s) : pOwner(po), func(f), stateFunc(s) {}
    void operator()(BOOL state)
       {
        (pOwner->*func)(state);
       }
    BOOL operator()()
       {
        return (pOwner->*stateFunc)() ? TRUE : FALSE;
       }
};

template <typename TOwner>
INTERFACE_CLI_GUI_ICOMMAND* 
createSimpleCheckMemberCommandHandler( TOwner *pOwner
                                , typename CSimpleCheckMemberCommandHandler< TOwner > :: handler_func_t func
                                , typename CSimpleCheckMemberCommandHandler< TOwner > :: state_func_t   stateFunc
                                )
   {
    return createCheckCommandHandler( CSimpleCheckMemberCommandHandler<TOwner>(pOwner, func, stateFunc) );
   }

}; // namespace impl
}; // namespace gui
}; // namespace cli



#endif /* CLI_GUI_COMMANDIMPLBASE_H */
