#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_CELLGRIDHLP_H
#define CLI_GUI_CELLGRIDHLP_H

/*
#ifndef CLI_GUI_CELLGRIDHLP_H
    #include <cli/gui/cellgridhlp.h>
#endif
*/

#ifndef CLI_GUI_CELLGRID_H
    #include <cli/gui/cellgrid.h>
#endif

namespace cli {
namespace gui {
namespace cellgrid {


inline
STRUCT_CLI_GUI_CELLGRID_CSPACING makeSpacing( UINT top, UINT bottom, UINT left, UINT right )
   {
    STRUCT_CLI_GUI_CELLGRID_CSPACING spacing;
    spacing.top    = top;
    spacing.bottom = bottom;
    spacing.left   = left;
    spacing.right  = right;
    return spacing;
   }


}; /* namespace cellgrid */
}; /* namespace gui */
}; /* namespace cli */



#endif /* CLI_GUI_CELLGRIDHLP_H */

