#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_GUIPODS_H
#define CLI_GUI_GUIPODS_H

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif


typedef VOID*  GENERIC_HMENU;

#if defined(_WIN32) || defined(WIN32)
     // HMENU allready declared
     // HWND  allready declared
#else
    typedef GENERIC_HMENU  HMENU;
    typedef VOID*          HWND;
#endif


#ifndef WND_HANDLE_DEFINED

    // #define WND_HANDLE
    
    // try to detect Wx usage
    #ifndef __cli_WX_USED__
        //#error __cli_WX_USED__ not defined
        #if defined(__WX__) || defined(__WXX11__)
            #define __cli_WX_USED__
        #endif
    #endif
    
    // try to detect Qt usage
    #ifndef __cli_QT_USED__
        #if defined(QT_THREAD_SUPPORT) || \
            defined(QT_NO_DEBUG) ||       \
            defined(QT_DEBUG) ||          \
            defined(QT_CORE_LIB) ||       \
            defined(QT_GUI_LIB)
            #define __cli_QT_USED__
        #endif
    #endif
    
    
    #if defined(__cli_WX_USED__)
        #if !defined(_WIN32) || defined(CLI_GUI_FORCE_WX)
            #define WND_HANDLE_DEFINED
            //typedef wxWidget*   WND_HANDLE;
            typedef wxWindow*   WND_HANDLE;
            
        //#else
        #endif
    #elif defined(__cli_QT_USED__) 
        #if !defined(_WIN32) || defined(CLI_GUI_FORCE_WX)
            #define WND_HANDLE_DEFINED
            // class QWidget
            //typedef qtWidget*   WND_HANDLE;
            typedef QWidget*   WND_HANDLE;
        #endif
    #endif
    
    #ifdef _WIN32
        #ifndef WND_HANDLE_DEFINED
            #define WND_HANDLE_DEFINED
            // windows.h must be included first
            typedef HWND        WND_HANDLE;
        #endif
    #else // generic platorm
        // UNDONE: ��祬�-� �� ࠡ�⠥� ��⮤�⥪� �� __cli_WX_USED__
        #ifndef WND_HANDLE_DEFINED
            #define WND_HANDLE_DEFINED
            typedef void*        WND_HANDLE;
        #endif
    
    #endif
    
    #ifndef WND_HANDLE_DEFINED
        #error WND_HANDLE_DEFINED not defined
    #endif

#endif // ifndef WND_HANDLE_DEFINED

#endif /* CLI_GUI_GUIPODS_H */

