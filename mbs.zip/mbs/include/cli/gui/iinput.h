#ifndef CLI_GUI_IINPUT_H
#define CLI_GUI_IINPUT_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/iinput.h>", CLI_GUI_IINPUT_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_IINPUT_H
    #include <cli/gui/iinput.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iSimpleInput */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_ISIMPLEINPUT_IID
    #define INTERFACE_CLI_GUI_ISIMPLEINPUT_IID    "/cli/gui/iSimpleInput"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iSimpleInput
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_ISIMPLEINPUT
       #define INTERFACE_CLI_GUI_ISIMPLEINPUT    ::cli::gui::iSimpleInput
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iSimpleInput
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_ISIMPLEINPUT
       #define INTERFACE_CLI_GUI_ISIMPLEINPUT    cli_gui_iSimpleInput
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iSimpleInput methods */
                CLIMETHOD(getTextFromUser) (THIS_ CLISTR*           text
                                                , const CLISTR*     message
                                                , const CLISTR*     title
                                                , const CLISTR*     defText
                                                , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                                           ) PURE;
                CLIMETHOD(getPasswordFromUser) (THIS_ CLISTR*           password
                                                    , const CLISTR*     message
                                                    , const CLISTR*     title
                                                    , const CLISTR*     defPassword
                                                    , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                                               ) PURE;
                CLIMETHOD(getNumberFromUser) (THIS_ INT*    num /* [out] int num  */
                                                  , const CLISTR*     message
                                                  , const CLISTR*     title
                                                  , INT    defVal /* [in] int  defVal  */
                                                  , INT    minVal /* [in] int  minVal  */
                                                  , INT    maxVal /* [in] int  maxVal  */
                                                  , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                                             ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iSimpleInput >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_ISIMPLEINPUT_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iSimpleInput* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iSimpleInput > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iSimpleInput wrapper
            // generated from F:\work\pfs\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_ISIMPLEINPUT >
                                          */
                     >
            class CiSimpleInputWrapper
            {
                public:
            
                    typedef  CiSimpleInputWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiSimpleInputWrapper() :
                       pif(0) {}
            
                    CiSimpleInputWrapper( iSimpleInput *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiSimpleInputWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiSimpleInputWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiSimpleInputWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiSimpleInputWrapper(const CiSimpleInputWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiSimpleInputWrapper()  { }
            
                    CiSimpleInputWrapper& operator=(const CiSimpleInputWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE getTextFromUser( ::std::wstring    &text
                                         , const ::std::wstring    &message
                                         , const ::std::wstring    &title
                                         , const ::std::wstring    &defText
                                         , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                                         )
                       {
                        CCliStr tmp_text; CCliStr_init( tmp_text );
                        CCliStr tmp_message; CCliStr_lightCopyTo( tmp_message, message);
                        CCliStr tmp_title; CCliStr_lightCopyTo( tmp_title, title);
                        CCliStr tmp_defText; CCliStr_lightCopyTo( tmp_defText, defText);
                    
                        RCODE res = pif->getTextFromUser(&tmp_text, &tmp_message, &tmp_title, &tmp_defText, hint);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( text, tmp_text);
                           }
                        return res;
                       }
                    
                    RCODE getPasswordFromUser( ::std::wstring    &password
                                             , const ::std::wstring    &message
                                             , const ::std::wstring    &title
                                             , const ::std::wstring    &defPassword
                                             , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                                             )
                       {
                        CCliStr tmp_password; CCliStr_init( tmp_password );
                        CCliStr tmp_message; CCliStr_lightCopyTo( tmp_message, message);
                        CCliStr tmp_title; CCliStr_lightCopyTo( tmp_title, title);
                        CCliStr tmp_defPassword; CCliStr_lightCopyTo( tmp_defPassword, defPassword);
                    
                        RCODE res = pif->getPasswordFromUser(&tmp_password, &tmp_message, &tmp_title, &tmp_defPassword, hint);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( password, tmp_password);
                           }
                        return res;
                       }
                    
                    RCODE getNumberFromUser( INT*    num /* [out] int num  */
                                           , const ::std::wstring    &message
                                           , const ::std::wstring    &title
                                           , INT    defVal /* [in] int  defVal  */
                                           , INT    minVal /* [in] int  minVal  */
                                           , INT    maxVal /* [in] int  maxVal  */
                                           , const WCHAR*    hint /* [in,flat] wchar  hint[]  */
                                           )
                       {
                    
                        CCliStr tmp_message; CCliStr_lightCopyTo( tmp_message, message);
                        CCliStr tmp_title; CCliStr_lightCopyTo( tmp_title, title);
                    
                    
                    
                    
                        return pif->getNumberFromUser(num, &tmp_message, &tmp_title, defVal, minVal, maxVal, hint);
                       }
                    

            
            
            }; // class CiSimpleInputWrapper
            
            typedef CiSimpleInputWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_ISIMPLEINPUT     > >  CiSimpleInput;
            typedef CiSimpleInputWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_ISIMPLEINPUT > >  CiSimpleInput_nrc; /* No ref counting for interface used */
            typedef CiSimpleInputWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_ISIMPLEINPUT > >  CiSimpleInput_tmp; /* for temporary usage, same as CiSimpleInput_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif





#endif /* CLI_GUI_IINPUT_H */
