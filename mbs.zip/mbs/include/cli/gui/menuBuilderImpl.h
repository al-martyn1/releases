#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_MENUBUILDERIMPL_H
#define CLI_GUI_MENUBUILDERIMPL_H

#ifndef CLI_GUI_IMENUBUILDER_H
    #include <cli/gui/iMenuBuilder.h>
#endif

#ifndef CLI_MESSAGES_H
    #include <cli/messages.h>
#endif


#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STACK_) && !defined(_STLP_STACK) && !defined(__STD_STACK__) && !defined(_CPP_STACK) && !defined(_GLIBCXX_STACK)
    #include <stack>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#ifndef CLI_CLICMDLINE_H
    #include <cli/clicmdline.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif




#ifdef USE_CLI_MODULE
    extern ::cli::CModule cliModule;
#endif // CLI_MONOLITHIC


namespace cli {
namespace gui {

void makeAccelString( const cli::gui::CAccel &acc, ::std::string &strTo );
void makeAccelString( const cli::gui::CAccel &acc, ::std::wstring &strTo );


namespace impl {

//::cli::gui::CAccel ::cli::gui::impl::makeAccel(ENUM_CLI_GUI_EACCELFLAGS flags, WORD key)

inline
::cli::gui::CAccel makeAccel(ENUM_CLI_GUI_EACCELFLAGS flags, WORD key)
   {
    ::cli::gui::CAccel acc;
    acc.flags = flags;
    acc.key   = key;
    return acc;
   }


struct CMenuItem
{
    DWORD             itemFlags; // item, submenu, break or barbreak
    SIZE_T            commandId; // commandId for commands
                                 // menuId for submenus
    CMenuItem() : itemFlags(0), commandId(0) {}
    CMenuItem(DWORD f, SIZE_T id) : itemFlags(f), commandId(id) {}
};

struct CMenuBuilderImplBase;

struct CMenuInfo
{
    CMenuBuilderImplBase           *pOwnerBuilder;
    ::std::wstring                  menuName;
    ::std::wstring                  rcModuleName;
    ::std::wstring                  menuText;
    ::std::wstring                  menuInfo;
    BOOL                            mainMenu;  // if true, this is the main menu, else this is the popup menu
    ::std::vector<CMenuItem>        items;
    ::std::set<GENERIC_HMENU>       menusCreated;
    ::std::vector<SIZE_T>           usedInMenus;
    ENUM_CLI_GUI_EMENUITEMFLAGS     stateFlags;

    CMenuInfo( CMenuBuilderImplBase *pob) 
       : pOwnerBuilder(pob)
       , rcModuleName()
       , menuName()
       , menuText()
       , menuInfo()
       , mainMenu(FALSE)
       , items()
       , menusCreated()
       , usedInMenus()
       , stateFlags(0)
       {}

    ENUM_CLI_GUI_EMENUITEMFLAGS getCommandState(SIZE_T cmdId) const;
    ENUM_CLI_GUI_EMENUITEMFLAGS getMenuState(SIZE_T menuId) const;

    // next operations only update this class and don't update any menu objects
    void insertItem( SIZE_T atPos, const CMenuItem &item );
    SIZE_T findBreakPos( SIZE_T breakNo ) const;
    // find command/menu pos in menu definition
    SIZE_T findCommandPos( SIZE_T cmdId ) const;
    SIZE_T findNextBreakPos( SIZE_T idx ) const;
    SIZE_T findPrevBreakPos( SIZE_T idx ) const;
    SIZE_T findInsertPos( ENUM_CLI_GUI_EMENUINSERTPOS whatPos, SIZE_T cmdId /* or menuId or break index */) const;
    void insertItem( ENUM_CLI_GUI_EMENUINSERTPOS whatPos, SIZE_T refCmdId, const CMenuItem &item );
    // find command/menu pos in actual menus (that can be) created
    SIZE_T findCommandMenuPos( SIZE_T cmdId );

    void loadText();
    void loadInfo();

    template <typename TMenuBuilder>
    SIZE_T buildMenu( TMenuBuilder &builder) const
       {
        SIZE_T itemsAddedTotal = 0, itemsAddedFromLastBreak = 0;
        using namespace ::cli::gui::EMenuItemFlags;
        for(::std::vector<CMenuItem>::const_iterator it = items.begin(); it!=items.end(); ++it)
           {
            if (it->itemFlags&fMenuBreak)          
               { 
                if (itemsAddedFromLastBreak) { if (!builder.appendMenuBreak()) return itemsAddedTotal; ++itemsAddedTotal; } 
                itemsAddedFromLastBreak = 0;
               }
            else if (it->itemFlags&fMenuBarBreak)  
               { 
                if (itemsAddedFromLastBreak) { if (!builder.appendMenuBarBreak()) return itemsAddedTotal; ++itemsAddedTotal; } 
                itemsAddedFromLastBreak = 0;
               }
            else if (it->itemFlags&fMenuSeparator) 
               { 
                if (itemsAddedFromLastBreak) { if (!builder.appendMenuSeparator()) return itemsAddedTotal; ++itemsAddedTotal; } 
                itemsAddedFromLastBreak = 0;
               }
            else if (it->itemFlags&fSubMenu)       
               { 
                ENUM_CLI_GUI_EMENUITEMFLAGS menuState = getMenuState(it->commandId);
                if (!(menuState&CLI_GUI_EMENUITEMFLAGS_FHIDDEN))
                   { // non-hidden items allowed to add
                    if (!builder.appendSubMenu(it->commandId)) return itemsAddedTotal; 
                    ++itemsAddedTotal; 
                    ++itemsAddedFromLastBreak;
                   }
               }
            else
               {
                ENUM_CLI_GUI_EMENUITEMFLAGS cmdState = getCommandState(it->commandId);
                if (!(cmdState&CLI_GUI_EMENUITEMFLAGS_FHIDDEN))
                   { // non-hidden items allowed to add
                    if (!builder.appendItem(it->commandId)) return itemsAddedTotal;
                    ++itemsAddedTotal;
                    ++itemsAddedFromLastBreak;
                   }
               }
           }
        return itemsAddedTotal;
       }

    struct CItemIndexFinder
       {
            SIZE_T   cmdIdToFind; // or menu id
            SIZE_T   curPos;
            ::std::vector< SIZE_T > foundPositions;

            CItemIndexFinder(SIZE_T id) : cmdIdToFind(id), curPos(0) /*, bFound(false) */, foundPositions() {}
            bool appendMenuBarBreak()         { ++curPos; return true; }
            bool appendMenuBreak()            { ++curPos; return true; }
            bool appendMenuSeparator()        { ++curPos; return true; }
            bool appendSubMenu(SIZE_T menuId) { if (cmdIdToFind==menuId) { foundPositions.push_back(curPos); } ++curPos; return true; }
            bool appendItem(SIZE_T cmdId)     { if (cmdIdToFind==cmdId ) { foundPositions.push_back(curPos); } ++curPos; return true; }
       };

    // find command first position in actual displayed menu
    SIZE_T findCommandMenuPos( SIZE_T cmdId ) const
       {
        CItemIndexFinder finder( cmdId );
        buildMenu(finder);
        if (!finder.foundPositions.empty()) return finder.foundPositions[0];
        return SIZE_T_NPOS;
       }

    // find command first position in actual displayed menu
    SIZE_T findCommandMenuPositions( SIZE_T cmdId, ::std::vector< SIZE_T > &foundPositions ) const
       {
        CItemIndexFinder finder( cmdId );
        buildMenu(finder);
        finder.foundPositions.swap(foundPositions);
        if (!foundPositions.empty()) return foundPositions[0];
        return SIZE_T_NPOS;
       }

}; // struct CMenuInfo


struct CCommandInfoImplBase
{
    ENUM_CLI_GUI_EMENUITEMFLAGS                     stateFlags;
    ::std::stack<INTERFACE_CLI_GUI_ICOMMAND*>       handlersStack;
    ::std::stack<INTERFACE_CLI_IARGLIST*>           handlerArgs;
    ::std::wstring                                  rcModuleName;
    ::std::wstring                                  commandName;
    ::std::wstring                                  itemText;
    ::std::wstring                                  itemInfo;
    ::std::vector<STRUCT_CLI_GUI_CACCEL>            accels;
    SIZE_T                                          radioGroupId;
    ::std::vector<SIZE_T>                           usedInMenus;



    virtual std::wstring makeAccelText(const STRUCT_CLI_GUI_CACCEL &accel) = 0;
    virtual void updateMenusText(const std::wstring &newText, const std::wstring &accelText) = 0;

    CCommandInfoImplBase();
    CCommandInfoImplBase(const CCommandInfoImplBase &ci);
    CCommandInfoImplBase& operator=(const CCommandInfoImplBase &ci);
    void releaseOwnedObjects();
    std::wstring getAccelText();
    void setText( const std::wstring &t);
    void modifyAccels( BOOL bClearExisting, const STRUCT_CLI_GUI_CACCEL* newAccels, SIZE_T numNewAccels);
    bool checkStacksConsistence();
    void pushCommandHandler( INTERFACE_CLI_GUI_ICOMMAND*    newHandler );
    bool popCommandHandler();
    bool setCommandHandler( INTERFACE_CLI_GUI_ICOMMAND*    newHandler );
    bool setCommandArgs(INTERFACE_CLI_IARGLIST* newArgs);


}; // struct CCommandInfoImplBase



struct CRadioGroupInfo
{
    ::std::wstring          radioGroupName;
    ::std::vector<SIZE_T>   commands;
    SIZE_T                  radioGroupState;
    CRadioGroupInfo() : radioGroupName(), commands(), radioGroupState(SIZE_T_NPOS) {}
    CRadioGroupInfo( const ::std::wstring &n) : radioGroupName(n), commands(), radioGroupState(SIZE_T_NPOS) {}

}; // struct CRadioGroupInfo



struct CMenuBuilderImplBase : public virtual INTERFACE_CLI_GUI_IMENUBUILDER
{

    friend struct CMenuInfo;

    ::cli::CCriticalSection            cs;

    INTERFACE_CLI_APP_ICONFIG         *pAppConfig;
    INTERFACE_CLI_IUNKNOWN            *pUnkAppData;
    VOID                              *pvData;
    ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS trackPopupFlags;


    static const size_t menuIdOffset = 65536;
    //static const SIZE_T commonCategoryIdAtom = 0;

private:
    ::std::wstring cmdTextRcPrefix;
    ::std::wstring cmdInfoRcPrefix;
    ::std::wstring strEmptyRcId;
    ::std::wstring strEmpty;

    DWORD          rcFindFlags;
    ::std::wstring moduleName;
    ::std::wstring localeName;
    
    ::std::map< ::std::wstring, SIZE_T >              radioToId;
    ::std::vector< CRadioGroupInfo >                  radioGroups;

    ::std::map< ::std::wstring, SIZE_T >              menuToId;
    ::std::vector< CMenuInfo >                        menus;

    ::std::vector< ::std::wstring >                   categories;
    ::std::map< ::std::wstring, SIZE_T >              categoriesToId;
    ::std::map< SIZE_T, ::std::vector< SIZE_T > >     categoryItems;


protected:

    struct CHmenuInfo
    {
     SIZE_T    menuId;
     bool      noAccelText;
     CHmenuInfo() : menuId(SIZE_T_NPOS), noAccelText(false) {}
     CHmenuInfo( SIZE_T mid, bool a_noAccelText = false) : menuId(mid), noAccelText(a_noAccelText) {}
    };

    ::std::map< GENERIC_HMENU , CHmenuInfo>           createdMenus;



    SIZE_T getRadioGroupId( const ::std::wstring &rgName);
    SIZE_T addRadioGroupCommand( const ::std::wstring &rgName, SIZE_T cmdId); // returns radiogriup id
    bool getRadioGroupName( SIZE_T rid, ::std::wstring &name);
    bool getRadioGroupCommands( SIZE_T rid, ::std::vector<SIZE_T> &commands);
    CRadioGroupInfo* getRadioGroupInfo( SIZE_T rid );
    const CRadioGroupInfo* getRadioGroupInfo( SIZE_T rid ) const;


    // not thread safe
    RCODE addNewMenu( const ::std::wstring &menuName, SIZE_T *pMenuId, CMenuInfo **ppNewMenuInfo);
    bool isMenuId(SIZE_T id);
    RCODE findMenuId( const ::std::wstring &menuId, SIZE_T *pId );
    RCODE findMenuId( const WCHAR* cmdId, SIZE_T *pId );
    const CMenuInfo* getMenuInfo( SIZE_T menuId ) const;
    CMenuInfo* getMenuInfo( SIZE_T menuId );

    ::std::wstring getEmptyStringStr() const 
       { 
        if (strEmpty.empty()) return ::std::wstring(L"<empty>");
        return strEmpty;
       }

public:

    // constructor/destructor
    CMenuBuilderImplBase() 
       : cs()
       , pAppConfig(0), pUnkAppData(0), pvData(0), trackPopupFlags(0)
       , cmdTextRcPrefix(), cmdInfoRcPrefix(), strEmptyRcId(), strEmpty()
       , rcFindFlags(0), moduleName(), localeName()
       , radioToId(), radioGroups()
       , menuToId(), menus()
       , createdMenus()
       {
        #ifndef USE_CLI_MODULE
        ::cli::CAppModule cliModule;
        #endif        

        moduleName = cliModule.getName();

        cmdTextRcPrefix = L"menu";
        cmdInfoRcPrefix = L"menu-info";

        //NOTE: adding order depend on ECategoryStdAtoms enum values
        SIZE_T commonCategoryAtom = 0;
        addCommandCategory( L"common-items"   , &commonCategoryAtom );
        addCommandCategory( L"common-commands", &commonCategoryAtom );
        addCommandCategory( L"common-menus"   , &commonCategoryAtom );
       }

    ~CMenuBuilderImplBase()
       {
        if (pAppConfig)  pAppConfig->release();
        if (pUnkAppData) pUnkAppData->release();
       }

protected:

    virtual void updateAllTexts() = 0;
    virtual void updateInfoTextsOnly() = 0;
    virtual void setCommandUsedInMenu( SIZE_T cmdId, SIZE_T menuId ) = 0;

    virtual void notifyMenuChanged( const WCHAR* menuName )
       {
       }
    virtual void notifyAccelChanged( )
       {
       }

    // resource helpers
    RCODE findString( ::std::wstring a_moduleName, const ::std::wstring &strId, ::std::wstring &strFound)
       {
        // code copied from bool findString implementation
        // pAppConfig
        //CCliStr msgFound;
        //CCliStr_init( msgFound );
        if (a_moduleName.empty()) a_moduleName = moduleName;

        RCODE res = EC_OK;
        if (pAppConfig && (rcFindFlags&FIND_STRING_USE_APP_CONFIG)!=0)
           { // try to use app config
            CCliStr tmp_strId;
            CCliStr_lightCopyTo( tmp_strId, strId);
            CCliStr msgFound;
            CCliStr_init( msgFound );
            res = pAppConfig->getString(&tmp_strId, &msgFound);
            if (res) return res;
            CCliStr_copyFromIfModified( strFound, msgFound);
           }
        else
           {
            CLIPSTR msgFound;
            CLIPSTR_init( msgFound );
            CLI_SCOPED_LOCK(cs);
            res = ::cliFindString( reinterpret_cast<CLIPSTR*>(&msgFound)
                                 , (a_moduleName.empty() ? (WCHAR*)0 : a_moduleName.c_str() )
                                 , strId.c_str()
                                 , (localeName.empty() ? (WCHAR*)0 : localeName.c_str() )
                                 , rcFindFlags | (moduleName.empty() ? 0 : FIND_MESSAGE_FROM_MODULE)
                                 );
            if (res) return res;
            CLIPSTR_copyFrom( strFound, msgFound, true /* bFree */ );
           }
        return EC_OK;
       }

    RCODE findString( const ::std::wstring &a_moduleName, const ::std::wstring &strIdPrefix, const ::std::wstring &strIdSimple, ::std::wstring &strFound)
       {
        ::std::wstring strId;
        if (!strIdSimple.empty() && strIdSimple[0]==L'/')
           {
            strId = strIdSimple; // no prefix used
           }
        else
           {
            strId = strIdPrefix;
            if (strId.empty() || strId[strId.size()-1]!=L'/')
               strId.append(1, L'/');
            strId.append(strIdSimple);
           }

        return findString(a_moduleName, strId, strFound);
       }

    RCODE findCommandText( const ::std::wstring &a_moduleName, const ::std::wstring &cmdName, ::std::wstring &text)
       {
        return findString( a_moduleName, cmdTextRcPrefix, cmdName, text );
       }

    RCODE findCommandInfo( const ::std::wstring &a_moduleName, const ::std::wstring &cmdName, ::std::wstring &text)
       {
        return findString( a_moduleName, cmdInfoRcPrefix, cmdName, text );
       }

    ::std::wstring findCommandText(const ::std::wstring &a_moduleName, const ::std::wstring &cmdName)
       {
        ::std::wstring resStr;
        RCODE res = findCommandText( a_moduleName, cmdName, resStr );
        if (!res) return resStr;
        ::std::wstring::size_type pos = cmdName.find_last_of(L'/');
        if (pos==::std::wstring::npos) return cmdName;
        return ::std::wstring( cmdName, pos+1, ::std::wstring::npos);
       }

#ifdef _DEBUG
    ::std::wstring findCommandInfo(const ::std::wstring &a_moduleName, const ::std::wstring &cmdName, bool allowEmptyInfo = false)
#else
    ::std::wstring findCommandInfo(const ::std::wstring &a_moduleName, const ::std::wstring &cmdName, bool allowEmptyInfo = true)
#endif
       {
        ::std::wstring resStr;
        RCODE res = findCommandInfo( a_moduleName, cmdName, resStr );
        if (!res) return resStr;
        if (allowEmptyInfo) return ::std::wstring();
        return cmdName;
       }

    ::std::wstring getStrEmpty()
       {
        if (strEmpty.empty()) return L"Empty";
        return strEmpty;
       }

public:

    // common var methods

    CLIMETHOD(setFindResourceParams) (THIS_ DWORD    flags /* [in] dword  flags  */
                                          , const WCHAR*    fromModule /* [in,flat] wchar  fromModule[]  */
                                          , const WCHAR*    useLocale /* [in,flat] wchar  useLocale[]  */
                                     )
       {
        CLI_SCOPED_LOCK(cs);
        rcFindFlags = flags;
        ::std::wstring oldModuleName = moduleName;
        ::std::wstring oldLocaleName = localeName;
        if (fromModule) moduleName = fromModule;
        else            moduleName.clear();
        if (useLocale)  localeName = fromModule;
        else            localeName.clear();

        if (oldModuleName!=moduleName || oldLocaleName!=localeName)
           updateAllTexts();
        return EC_OK;
       }

    CLIMETHOD(setCommandResourcePrefix) (THIS_ const WCHAR*    prefix /* [in,flat] wchar  prefix[]  */)
       {
        CLI_SCOPED_LOCK(cs);
        ::std::wstring oldPrefix = cmdTextRcPrefix;
        if (!prefix) cmdTextRcPrefix.clear();
        else         cmdTextRcPrefix = prefix;
        if (oldPrefix!=cmdTextRcPrefix) updateAllTexts();
        return EC_OK;
       }

    CLIMETHOD(setCommandInfoResourcePrefix) (THIS_ const WCHAR*    prefix /* [in,flat] wchar  prefix[]  */)
       {
        CLI_SCOPED_LOCK(cs);
        ::std::wstring oldPrefix = cmdInfoRcPrefix;
        if (!prefix) cmdInfoRcPrefix.clear();
        else         cmdInfoRcPrefix = prefix;
        if (oldPrefix!=cmdInfoRcPrefix) updateInfoTextsOnly();
        return EC_OK;
       }

    CLIMETHOD(setEmptyStringResourceId) (THIS_ const WCHAR*    rcId /* [in,flat] wchar  prefix[]  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (!rcId) strEmptyRcId.clear();
        else       strEmptyRcId = rcId;

        ::std::wstring strFound;
        RCODE res = findString( moduleName, cmdTextRcPrefix, strEmptyRcId, strFound);
        if (res)
           {
            if (strEmpty.empty()) strEmpty = L"Empty";
            //else don't change
           }
        else strEmpty = strFound;
        return EC_OK;
       }

    CLIMETHOD(setEmptyString) (THIS_ const WCHAR*    newStrEmpty /* [in,flat] wchar  strEmpty[]  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (newStrEmpty)
           {
            strEmpty = newStrEmpty;
            return EC_OK; // overriding string found or not found by rcId
           }
        else // set default string
           {
            ::std::wstring tmp = strEmptyRcId;
            return setEmptyStringResourceId( (tmp.empty() ? (WCHAR*)0 : tmp.c_str()));
           }
       }


    CLIMETHOD(setAppConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in] ::cli::app::iConfig*  appConfig  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (pAppConfig) pAppConfig->release(); //release existing
        pAppConfig = appConfig;
        if (pAppConfig) pAppConfig->addRef();
        return EC_OK;
       }

    CLIMETHOD(setAppDataObject) (THIS_ INTERFACE_CLI_IUNKNOWN*    iUnkAppData /* [in] ::cli::iUnknown*  iUnkAppData  */)
       {
        CLI_SCOPED_LOCK(cs);
        if (pUnkAppData) pAppConfig->release(); //release existing
        pUnkAppData = iUnkAppData;
        if (pUnkAppData) pAppConfig->addRef();
        return EC_OK;
       }

    CLIMETHOD(setAppDataPointer) (THIS_ const VOID*    _pvData /* [in] void*  pvData  */)
       {
        CLI_SCOPED_LOCK(cs);
        pvData = const_cast<VOID*>(_pvData);
        return EC_OK;
       }

    CLIMETHOD(setTrackPopupFlags) (THIS_ ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS    tpmFlags /* [in] ::cli::gui::ETrackPopupMenuFlags  tpmFlags  */)
       {
        trackPopupFlags = tpmFlags;
        return EC_OK;
       }

    CLIMETHOD(getTrackPopupFlags) (THIS_ ENUM_CLI_GUI_ETRACKPOPUPMENUFLAGS*    tpmFlags /* [out] ::cli::gui::ETrackPopupMenuFlags tpmFlags  */)
       {
        if (tpmFlags) *tpmFlags = trackPopupFlags;
        return EC_OK;
       }

    CLIMETHOD(getMenuId) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                              , SIZE_T*    menuId /* [out,optional] size_t menuId  */
                         )
       {
        CLI_SCOPED_LOCK(cs);
        return findMenuId( menuName, menuId );
       }

    CLIMETHOD(getRadioGroupId) (THIS_ const WCHAR*    radioGroupName /* [in,flat] wchar  cmdName[]  */
                                    , SIZE_T*    radioGroupId /* [out,optional] size_t commandId  */
                               )
       {
        if (!radioGroupName) return EC_INVALID_PARAM;

        CLI_SCOPED_LOCK(cs);
        SIZE_T id = getRadioGroupId(radioGroupName);
        if (id==SIZE_T_NPOS) return EC_INVALID_PARAM;

        if (radioGroupId) *radioGroupId = id;
        return EC_OK;
       }

    CLIMETHOD(getCommandInfoText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                       , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                       , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                  )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId );
        if (res)
           {
            if (infoTextBuf && bufSize) infoTextBuf[0] = 0;
            return res;
           }
        return getCommandByIdInfoText( cmdId, infoTextBuf, bufSize );
       }

    CLIMETHOD(getMenuInfoText) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                    , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                    , SIZE_T    bufSize /* [in] size_t  bufSize  */
                               )
       {
        SIZE_T menuId = SIZE_T_NPOS;
        RCODE res = getMenuId( menuName, &menuId );
        if (res)
           {
            if (infoTextBuf && bufSize) infoTextBuf[0] = 0;
            return res;
           }
        return getMenuByIdInfoText( menuId, infoTextBuf, bufSize );
       }

    CLIMETHOD(getMenuByIdInfoText) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                        , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                        , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                   )
       {
        CLI_SCOPED_LOCK(cs);
        const CMenuInfo* pmi = getMenuInfo( menuId );
        if (!pmi) 
           {
            if (infoTextBuf && bufSize) infoTextBuf[0] = 0;
            return EC_COMMAND_UNKNOWN;
           }

        SIZE_T maxChars = bufSize-1;
        if (maxChars > pmi->menuInfo.size())
           maxChars = pmi->menuInfo.size();

        if (infoTextBuf)
           {
            pmi->menuInfo.copy( infoTextBuf, maxChars, 0 );
            infoTextBuf[maxChars] = 0;
           }

        return EC_OK;
       }

    CLIMETHOD(getMenuNameById) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                    , WCHAR*    menuNameTextBuf /* [out,flat,optional] wchar menuNameTextBuf  */
                                    , SIZE_T    bufSize /* [in] size_t  bufSize  */
                               )
       {       
        CLI_SCOPED_LOCK(cs);
        const CMenuInfo* pmi = getMenuInfo( menuId );
        if (!pmi) 
           {
            if (menuNameTextBuf && bufSize) menuNameTextBuf[0] = 0;
            return EC_COMMAND_UNKNOWN;
           }

        SIZE_T maxChars = bufSize-1;
        if (maxChars > pmi->menuName.size())
           maxChars = pmi->menuName.size();

        if (menuNameTextBuf)
           {
            pmi->menuName.copy( menuNameTextBuf, maxChars, 0 );
            menuNameTextBuf[maxChars] = 0;
           }

        return EC_OK;
       }

    CLIMETHOD(getMenuTextById) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                    , WCHAR*    menuNameTextBuf /* [out,flat,optional] wchar menuNameTextBuf  */
                                    , SIZE_T    bufSize /* [in] size_t  bufSize  */
                               )
       {       
        CLI_SCOPED_LOCK(cs);
        const CMenuInfo* pmi = getMenuInfo( menuId );
        if (!pmi) 
           {
            if (menuNameTextBuf && bufSize) menuNameTextBuf[0] = 0;
            return EC_COMMAND_UNKNOWN;
           }

        SIZE_T maxChars = bufSize-1;
        if (maxChars > pmi->menuText.size())
           maxChars = pmi->menuText.size();

        if (menuNameTextBuf)
           {
            pmi->menuText.copy( menuNameTextBuf, maxChars, 0 );
            menuNameTextBuf[maxChars] = 0;
           }

        return EC_OK;
       }

    CLIMETHOD(getItemNameById) (THIS_ SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                    , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                    , SIZE_T    bufSize /* [in] size_t  bufSize  */
                               )
       {
        if (isMenuId(menuOrCmdId)) return getMenuNameById( menuOrCmdId, nameTextBuf, bufSize );
        else                       return getCommandNameById( menuOrCmdId, nameTextBuf, bufSize );
       }

    CLIMETHOD(getItemTextById) (THIS_ SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                    , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                    , SIZE_T    bufSize /* [in] size_t  bufSize  */
                               )
       {
        if (isMenuId(menuOrCmdId)) return getMenuTextById( menuOrCmdId, nameTextBuf, bufSize );
        else                       return getCommandTextById( menuOrCmdId, nameTextBuf, bufSize );
       }

    CLIMETHOD(getItemInfoTextById) (THIS_ SIZE_T    menuOrCmdId /* [in] size_t  menuOrCmdId  */
                                    , WCHAR*    nameTextBuf /* [out,flat,optional] wchar nameTextBuf  */
                                    , SIZE_T    bufSize /* [in] size_t  bufSize  */
                               )
       {
        if (isMenuId(menuOrCmdId)) return getMenuByIdInfoText( menuOrCmdId, nameTextBuf, bufSize );
        else                       return getCommandByIdInfoText( menuOrCmdId, nameTextBuf, bufSize );
       }

    CLIMETHOD(getMenuIdByHandle) (THIS_ GENERIC_HMENU    menuHandle /* [in] hmenu  menuHandle  */
                                      , SIZE_T*    menuId /* [out] size_t menuId  */
                                 )
       {
        CLI_SCOPED_LOCK(cs);
        ::std::map< GENERIC_HMENU , CHmenuInfo>::const_iterator cmIt = createdMenus.find(menuHandle);
        if (cmIt==createdMenus.end())
           return EC_COMMAND_UNKNOWN;
        if (menuId) *menuId = cmIt->second.menuId;
        return EC_OK;
       }

    CLIMETHOD(syncCommandUiState) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */)
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId );
        if (res) return res;
        return syncCommandByIdUiState(cmdId);
       }
       
    // helper methods
    CLIMETHOD(invokeExactParams) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                      , INTERFACE_CLI_GUI_IMENUBUILDER*    a_iMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                                      , INTERFACE_CLI_APP_ICONFIG*    a_appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                      , INTERFACE_CLI_IUNKNOWN*    a_iUnkAppdata /* [in,optional] ::cli::iUnknown*  iUnkAppdata  */
                                      , const VOID*    a_pData /* [in,optional] void*  pData  */
                                      , INTERFACE_CLI_IARGLIST*    a_pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                 )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return invokeByIdExactParams(cmdId, a_iMenuBuilder, a_appConfig, a_iUnkAppdata, a_pData, a_pArgs);
       }

    CLIMETHOD(invokeParams) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                 , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS    invokeFlags /* [in] ::cli::gui::EMenuBuilderInvokeCommandFlags  invokeFlags  */
                                 , INTERFACE_CLI_GUI_IMENUBUILDER*    a_iMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                                 , INTERFACE_CLI_APP_ICONFIG*    a_appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                 , INTERFACE_CLI_IUNKNOWN*    a_iUnkAppdata /* [in,optional] ::cli::iUnknown*  iUnkAppdata  */
                                 , const VOID*    a_pData /* [in,optional] void*  pData  */
                                 , INTERFACE_CLI_IARGLIST*    a_pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                            )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return invokeByIdParams( cmdId, invokeFlags, a_iMenuBuilder, a_appConfig, a_iUnkAppdata, a_pData, a_pArgs);
       }

    CLIMETHOD(invoke) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */)
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return invokeById(cmdId);
       }

    CLIMETHOD(invokeById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */)
       {
        return invokeByIdParams(cmdId, 0, 0, 0, 0, 0, 0 );
       }

    CLIMETHOD(invokeWithArgList) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                      , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                 )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return invokeByIdWithArgList(cmdId,pArgs);
       }

    CLIMETHOD(invokeByIdWithArgList) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                          , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                     )
       {
        using namespace ::cli::gui::EMenuBuilderInvokeCommandFlags;
        return invokeByIdParams(cmdId, fUseArgs, 0, 0, 0, 0, pArgs );
       }

    CLIMETHOD(getCommandState) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdId[]  */
                                    , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                               )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return getCommandByIdState( cmdId, stateFlags );
       }

    CLIMETHOD(setCommandState) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdId[]  */
                                    , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                               )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return setCommandByIdState( cmdId, newStateFlags );
       }


    CLIMETHOD(getMenuState) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                 , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                            )
       {
        SIZE_T menuId = SIZE_T_NPOS;
        RCODE res = getMenuId( menuName, &menuId);
        if (res) return res;
        return getMenuByIdState( menuId, stateFlags );
       }

    CLIMETHOD(setMenuState) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                 , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                            )
       {
        SIZE_T menuId = SIZE_T_NPOS;
        RCODE res = getMenuId( menuName, &menuId);
        if (res) return res;
        return setMenuByIdState( menuId, newStateFlags );
       }

    CLIMETHOD(setMenuHidden) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                  , BOOL    hidden /* [in] bool  hidden  */
                             )
       {
        SIZE_T menuId = SIZE_T_NPOS;
        RCODE res = getMenuId( menuName, &menuId);
        if (res) return res;
        return setMenuByIdHidden( menuId, hidden );
       }

    CLIMETHOD(getMenuByIdState) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                     , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                )
       {
        CLI_SCOPED_LOCK(cs);
        const CMenuInfo* pMenuInfo = getMenuInfo( menuId );
        if (!pMenuInfo) return EC_COMMAND_UNKNOWN;
        if (stateFlags) *stateFlags = pMenuInfo->stateFlags;
        return EC_OK;
       }

    CLIMETHOD(setMenuByIdHidden) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                      , BOOL    hidden /* [in] bool  hidden  */
                                 )
       {
        ENUM_CLI_GUI_EMENUITEMFLAGS stateFlags = 0;
        RCODE res = getMenuByIdState(menuId, &stateFlags);
        if (res) return res;
        if (hidden) stateFlags |=  CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
        else        stateFlags &= ~CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
        return setMenuByIdState(menuId, stateFlags);
       }

protected:

    virtual RCODE updateMenuObjects( SIZE_T menuId ) = 0;


    void updateMenuParentMenus(const CMenuInfo *pMenuInfo)
       {
        ::std::vector<SIZE_T>::const_iterator uimIt = pMenuInfo->usedInMenus.begin();
        for(; uimIt!=pMenuInfo->usedInMenus.end(); ++uimIt)
           {
            //updateMenuObjects(*uimIt);
            const CMenuInfo* pMenuInfo = getMenuInfo( *uimIt );
            menuChangedImplementationNotify( pMenuInfo->menuName.c_str(), *uimIt );
           }
       }

public:


    CLIMETHOD(setMenuByIdState) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                     , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                )
       {
        CLI_SCOPED_LOCK(cs);
        CMenuInfo* pMenuInfo = getMenuInfo( menuId );
        if (!pMenuInfo) return EC_COMMAND_UNKNOWN;

        //newStateFlags &= CLI_GUI_EMENUITEMFLAGS_FSTATEMASK;
        newStateFlags &= CLI_GUI_EMENUITEMFLAGS_FHIDDEN; // for menus only hidden flag currently supported

        ENUM_CLI_GUI_EMENUITEMFLAGS oldFlags = pMenuInfo->stateFlags;
        pMenuInfo->stateFlags = newStateFlags;

        ENUM_CLI_GUI_EMENUITEMFLAGS diffFlags = ((~oldFlags)&(newStateFlags)) | ((oldFlags)&(~newStateFlags));

        if (diffFlags&CLI_GUI_EMENUITEMFLAGS_FHIDDEN)
           { 
            updateMenuParentMenus(pMenuInfo);
            notifyAccelChanged( );
           }
        return EC_OK;
       }




    CLIMETHOD(addCommandAccel) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                    , const STRUCT_CLI_GUI_CACCEL*    accel /* [in,ref] ::cli::gui::CAccel  accel  */
                               )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return addCommandByIdAccel( cmdId, accel );
       }

    CLIMETHOD(modifyCommandAccels) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                        , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat] ::cli::gui::CAccel  accels[]  */
                                        , SIZE_T    numAccels /* [in] size_t  numAccels  */
                                        , BOOL    clearExisting /* [in] bool  clearExisting  */
                                   )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return modifyCommandByIdAccels( cmdId, accels, numAccels, clearExisting );
       }

    CLIMETHOD(enumCommandAccels) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                      , SIZE_T    accelNo /* [in] size_t  accelNo  */
                                      , STRUCT_CLI_GUI_CACCEL*    accel /* [out] ::cli::gui::CAccel accel  */
                                 )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId);
        if (res) return res;
        return enumCommandByIdAccels( cmdId, accelNo, accel );
       }

    CLIMETHOD(addCommandSimple) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdId[]  */
                                     , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                     , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                     , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                )
       {
        return addCommand( cmdName, flags, handler, 0, 0, 0, 0, 0, 0, 0, commandId );       
       }

    CLIMETHOD(addCommandSimpleText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdId[]  */
                                         , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                         , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                         , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                         , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                    )
       {
        return addCommand( cmdName, flags, handler, 0, 0, itemText, 0, 0, 0, 0, commandId );       
       }

    CLIMETHOD(addCommandWithArgs) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                       , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                       , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                       , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                       , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                  )
       {
        return addCommand( cmdName, flags, handler, pArgs, 0, 0, 0, 0, 0, 0, commandId );       
       }

    CLIMETHOD(addCommandWithArgsText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                           , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                           , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                           , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                           , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                           , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                      )
       {
        return addCommand( cmdName, flags, handler, pArgs, 0, itemText, 0, 0, 0, 0, commandId );       
       }

    CLIMETHOD(addCommandRadio) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                    , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                    , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                    , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                    , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                               )
       {
        return addCommand( cmdName, flags, handler, 0, 0, 0, 0, 0, 0, radioGroupName, commandId );       
       }

    CLIMETHOD(addCommandRadioText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                        , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                        , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                        , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                        , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                        , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                   )
       {
        return addCommand( cmdName, flags, handler, 0, 0, itemText, 0, 0, 0, radioGroupName, commandId );       
       }

    CLIMETHOD(addCommandRadioWithArgs) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                            , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                            , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                            , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                            , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                            , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                       )
       {
        return addCommand( cmdName, flags, handler, pArgs, 0, 0, 0, 0, 0, radioGroupName, commandId );       
       }

    CLIMETHOD(addCommandRadioWithArgsText) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                                , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                                , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                                , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                                , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                                , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                                           )
       {
        return addCommand( cmdName, flags, handler, pArgs, 0, itemText, 0, 0, 0, radioGroupName, commandId );       
       }

    CLIMETHOD(addMenu) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                            , const WCHAR*    rcModuleName /* [in,flat,optional] wchar  rcModuleName[]  */
                            , const WCHAR*    menuText /* [in,flat,optional] wchar  menuText[]  */
                            , const WCHAR*    menuInfoText /* [in,flat,optional] wchar  menuInfoText[]  */
                            , BOOL    bMainMenu /* [in] bool  bMainMenu  */
                            , SIZE_T*    pMenuId /* [out,optional] size_t menuId  */
                       )
       {
        if (!menuName) return EC_COMMAND_INVALID_NAME;

        CLI_SCOPED_LOCK(cs);

        SIZE_T newMenuId = 0;
        CMenuInfo *pNewMenuInfo = 0;
        RCODE res = addNewMenu( menuName, &newMenuId, &pNewMenuInfo);
        if (res) return res;
        if (!pNewMenuInfo) return EC_UNKNOWN;

        pNewMenuInfo->mainMenu = bMainMenu;
        if (rcModuleName) pNewMenuInfo->rcModuleName = rcModuleName;

        if (menuText)
           pNewMenuInfo->menuText = menuText;
        if (pNewMenuInfo->menuText.empty()) pNewMenuInfo->loadText();

        if (menuInfoText)
           pNewMenuInfo->menuInfo = menuInfoText;
        if (pNewMenuInfo->menuInfo.empty()) pNewMenuInfo->loadInfo();

        if (pMenuId) *pMenuId = newMenuId;

        addCommandToCategoryById2( CLI_GUI_ECATEGORYSTDATOMS_COMMONITEMSCATEGORY, newMenuId );
        addCommandToCategoryById2( CLI_GUI_ECATEGORYSTDATOMS_COMMONMENUSCATEGORY, newMenuId );

        return EC_OK;
       }

/*
struct CMenuInfo
{
    CMenuBuilderImplBase      *pOwnerBuilder;
    ::std::wstring             menuName;
    ::std::wstring             menuText;
    ::std::wstring             menuInfo;
    BOOL                       mainMenu;  // if true, this is the main menu, else this is the popup menu
    ::std::vector<CMenuItem>   items;
    ::std::set<GENERIC_HMENU>  menusCreated;

    CMenuInfo( CMenuBuilderImplBase *pob) 
       : pOwnerBuilder(pob)
       , menuName()
       , menuText()
       , menuInfo()
       , mainMenu(FALSE)
       , items()
       , menusCreated()
       {}

    ENUM_CLI_GUI_EMENUITEMFLAGS getCommandState(SIZE_T cmdId) const;

    // next operations only update this class and don't update any menu objects
    void insertItem( SIZE_T atPos, const CMenuItem &item );
    SIZE_T findBreakPos( SIZE_T breakNo ) const;
    // find command/menu pos in menu definition
    SIZE_T findCommandPos( SIZE_T cmdId ) const;
    SIZE_T findNextBreakPos( SIZE_T idx ) const;
    SIZE_T findPrevBreakPos( SIZE_T idx ) const;
    SIZE_T findInsertPos( ENUM_CLI_GUI_EMENUINSERTPOS whatPos, SIZE_T cmdId ) const;
    void insertItem( ENUM_CLI_GUI_EMENUINSERTPOS whatPos, SIZE_T refCmdId, const CMenuItem &item );
    // find command/menu pos in actual menus (that can be) created
    SIZE_T findCommandMenuPos( SIZE_T cmdId );

*/

protected:

    virtual void menuChangedImplementationNotify( const WCHAR* menuName, SIZE_T menudId ) = 0;

public:

    CLIMETHOD(enumMenuItems) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                  , SIZE_T    itemIndex /* [in] size_t  itemIndex  */
                                  , STRUCT_CLI_GUI_CMENUITEMINFO*    itemInfo /* [out] ::cli::gui::CMenuItemInfo itemInfo  */
                             )
       {
        if (!menuName) return EC_COMMAND_INVALID_NAME;
        SIZE_T menuId = 0;
        RCODE res = getMenuId( menuName, &menuId );
        if (res) return res;
        return enumMenuByIdItems(menuId, itemIndex, itemInfo);
       }

    CLIMETHOD(enumMenuByIdItems) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                      , SIZE_T    itemIndex /* [in] size_t  itemIndex  */
                                      , STRUCT_CLI_GUI_CMENUITEMINFO*    itemInfo /* [out] ::cli::gui::CMenuItemInfo itemInfo  */
                                 )
       {
        CLI_SCOPED_LOCK(cs);

        CMenuInfo* pMenuInfo = getMenuInfo( menuId );
        if (!pMenuInfo) return EC_COMMAND_INVALID_NAME;

        if (itemIndex>=pMenuInfo->items.size())
           return EC_OUT_OF_RANGE;

        if (itemInfo)
           {
            itemInfo->itemId    = pMenuInfo->items[itemIndex].commandId;
            itemInfo->itemFlags = pMenuInfo->items[itemIndex].itemFlags;
           }
        return EC_OK;
       }

    CLIMETHOD(insertMenuItem) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                               , const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                               , ENUM_CLI_GUI_EMENUINSERTPOS    howInsert /* [in] ::cli::gui::EMenuInsertPos  howInsert  */
                               , SIZE_T    insertPos /* [in] size_t  insertPos  */
                          )
       {
        if (!menuName || !cmdName) return EC_COMMAND_INVALID_NAME;

        SIZE_T menuId = 0;
        RCODE res = getMenuId( menuName, &menuId );
        if (res) return res;

        CLI_SCOPED_LOCK(cs);

        CMenuInfo* pMenuInfo = getMenuInfo( menuId );
        if (!pMenuInfo) return EC_COMMAND_INVALID_NAME;

        using namespace ::cli::gui::EMenuItemFlags;

        ::std::wstring cmdNameStr = cmdName;
        if (cmdNameStr==L"-")
           {
            pMenuInfo->insertItem( howInsert, insertPos, CMenuItem(fMenuSeparator, 0) );
            return EC_OK;
           }
        else if (cmdNameStr==L"--")
           {
            pMenuInfo->insertItem( howInsert, insertPos, CMenuItem(fMenuBreak, 0) );
            return EC_OK;
           }
        else if (cmdNameStr==L"---")
           {
            pMenuInfo->insertItem( howInsert, insertPos, CMenuItem(fMenuBarBreak, 0) );
            return EC_OK;
           }

        ::std::wstring menuNameStr = menuName;
        if (menuNameStr!=cmdNameStr)
           {
            SIZE_T subMenuId = 0;
            if (!getMenuId( cmdName, &subMenuId ))
               {
                CMenuInfo* pSubMenuInfo = getMenuInfo( subMenuId );
                if (!pSubMenuInfo) return EC_COMMAND_INVALID_NAME;
                pMenuInfo->insertItem( howInsert, insertPos, CMenuItem(fSubMenu, subMenuId) );
                pSubMenuInfo->usedInMenus.push_back(menuId);
                menuChangedImplementationNotify( menuName, menuId );
                //usedInMenus
                return EC_OK;
               }
           }

        SIZE_T cmdId = 0;
        res = getCommandId( cmdName, &cmdId );
        if (res) return res;
        pMenuInfo->insertItem( howInsert, insertPos, CMenuItem(0, cmdId) );

        setCommandUsedInMenu( cmdId, menuId );
        menuChangedImplementationNotify( menuName, menuId );
        //usedInMenus
        return EC_OK;
       }

    CLIMETHOD(appendMenuItem) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                               , const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                          )
       {
        return insertMenuItem( menuName, cmdName, CLI_GUI_EMENUINSERTPOS_ATEND, 0);
       }


    CLIMETHOD(getRadioIndex) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                  , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                  , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                             )
       {
        SIZE_T cmdId = 0;
        RCODE res = getCommandId( cmdName, &cmdId );
        if (res) return res;

        return getRadioIndexById( cmdId, radioGroupName, radioIndex );
       }

    CLIMETHOD(getRadioIndexById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                      , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                                      , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                 )
       {
        if (!radioGroupName) return EC_INVALID_PARAM;

        CLI_SCOPED_LOCK(cs);
        SIZE_T rgId = getRadioGroupId( radioGroupName );
        if (rgId==SIZE_T_NPOS) return EC_RADIOGROUP_UNKNOWN;

        const CRadioGroupInfo* pRadioGroup = getRadioGroupInfo( rgId );
        if (!pRadioGroup) return EC_RADIOGROUP_UNKNOWN;

        ::std::vector<SIZE_T>::const_iterator it = pRadioGroup->commands.begin();
        for(; it!=pRadioGroup->commands.end(); ++it)
           {
            if (cmdId==*it) 
               {
                if (radioIndex) *radioIndex = it - pRadioGroup->commands.begin();
                return EC_OK;
               }
           }
        return EC_COMMAND_UNKNOWN;
       }

    CLIMETHOD(getRadioIndexById2) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                       , SIZE_T    radioGroupId /* [in] size_t  radioGroupId  */
                                       , SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                  )
       {
        CLI_SCOPED_LOCK(cs);
        const CRadioGroupInfo* pRadioGroup = getRadioGroupInfo( radioGroupId );
        if (!pRadioGroup) return EC_RADIOGROUP_UNKNOWN;

        ::std::vector<SIZE_T>::const_iterator it = pRadioGroup->commands.begin();
        for(; it!=pRadioGroup->commands.end(); ++it)
           {
            if (cmdId==*it) 
               {
                if (radioIndex) *radioIndex = it - pRadioGroup->commands.begin();
                return EC_OK;
               }
           }
        return EC_COMMAND_UNKNOWN;
       }

    CLIMETHOD(setRadioChecked) (THIS_ SIZE_T    radioIndex /* [in] size_t  radioIndex  */
                                    , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                               )
       {
        if (!radioGroupName) return EC_INVALID_PARAM;

        CLI_SCOPED_LOCK(cs);
        SIZE_T rgId = getRadioGroupId( radioGroupName );
        if (rgId==SIZE_T_NPOS) return EC_RADIOGROUP_UNKNOWN;

        return setRadioCheckedById( radioIndex, rgId );
       }

    CLIMETHOD(setRadioCheckedById) (THIS_ SIZE_T    radioIndex /* [in] size_t  radioIndex  */
                                        , SIZE_T    rgId /* [in] size_t  rgId  */
                                   )
       {
        const CRadioGroupInfo* pRadioGroup = getRadioGroupInfo( rgId );
        if (!pRadioGroup) return EC_RADIOGROUP_UNKNOWN;

        if (radioIndex>=pRadioGroup->commands.size()) return EC_COMMAND_UNKNOWN;
        SIZE_T cmdId = pRadioGroup->commands[radioIndex];

        ENUM_CLI_GUI_EMENUITEMFLAGS stateFlags = 0;
        RCODE res = getCommandByIdState( cmdId, &stateFlags );
        if (res) return res;
        return setCommandByIdState(cmdId, stateFlags|CLI_GUI_EMENUITEMFLAGS_FCHECKED);
       }

    CLIMETHOD(getRadioChecked) (THIS_ SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                    , const WCHAR*    radioGroupName /* [in,flat] wchar  radioGroupName[]  */
                               )
       {
        if (!radioGroupName) return EC_INVALID_PARAM;

        CLI_SCOPED_LOCK(cs);
        SIZE_T rgId = getRadioGroupId( radioGroupName );
        if (rgId==SIZE_T_NPOS) return EC_RADIOGROUP_UNKNOWN;

        return getRadioCheckedById( radioIndex, rgId );
       }

    CLIMETHOD(getRadioCheckedById) (THIS_ SIZE_T*    radioIndex /* [out] size_t radioIndex  */
                                        , SIZE_T    rgId /* [in] size_t  rgId  */
                                   )
       {
        const CRadioGroupInfo* pRadioGroup = getRadioGroupInfo( rgId );
        if (!pRadioGroup) return EC_RADIOGROUP_UNKNOWN;

        if (radioIndex) *radioIndex = pRadioGroup->radioGroupState;
        return EC_OK;
       }

    CLIMETHOD(getCommandRadioGroup) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                         , SIZE_T*    rgId /* [out] size_t rgId  */
                                    )
       {
        CLI_SCOPED_LOCK(cs);
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId );
        if (res) return res;
        return getCommandByIdRadioGroup( cmdId, rgId );
       }

    CLIMETHOD(setCommandChecked) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                      , BOOL    checked /* [in] bool  checked  */
                                 )
       {
        CLI_SCOPED_LOCK(cs);
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId );
        if (res) return res;
        return setCommandByIdChecked(cmdId, checked);
       }

    CLIMETHOD(setCommandByIdChecked) (THIS_ SIZE_T    cmdId /* [in,flat] size_t  cmdId  */
                                          , BOOL    checked /* [in] bool  checked  */
                                     )
       {
        CLI_SCOPED_LOCK(cs);
        ENUM_CLI_GUI_EMENUITEMFLAGS stateFlags = 0;
        RCODE res = getCommandByIdState( cmdId, &stateFlags );
        if (res) return res;
        if (checked) stateFlags |= CLI_GUI_EMENUITEMFLAGS_FCHECKED;
        else         stateFlags &= ~CLI_GUI_EMENUITEMFLAGS_FCHECKED;
        return setCommandByIdState( cmdId, stateFlags );
       }

    CLIMETHOD(setCommandEnabled) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                      , BOOL    enabled /* [in] bool  enabled  */
                                 )
       {
        CLI_SCOPED_LOCK(cs);
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId );
        if (res) return res;
        return setCommandByIdEnabled(cmdId, enabled);
       }

    CLIMETHOD(setCommandByIdEnabled) (THIS_ SIZE_T    cmdId /* [in,flat] size_t  cmdId  */
                                          , BOOL    enabled /* [in] bool  enabled  */
                                     )
       {
        CLI_SCOPED_LOCK(cs);
        ENUM_CLI_GUI_EMENUITEMFLAGS stateFlags = 0;
        RCODE res = getCommandByIdState( cmdId, &stateFlags );
        if (res) return res;
        if (!enabled) stateFlags |= CLI_GUI_EMENUITEMFLAGS_FDISABLED;
        else          stateFlags &= ~CLI_GUI_EMENUITEMFLAGS_FDISABLED;
        return setCommandByIdState( cmdId, stateFlags );
       }

    CLIMETHOD(setCommandHidden) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                     , BOOL    hidden /* [in] bool  enabled  */
                                )
       {
        CLI_SCOPED_LOCK(cs);
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId );
        if (res) return res;
        return setCommandByIdHidden(cmdId, hidden);
       }

    CLIMETHOD(setCommandByIdHidden) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                         , BOOL    hidden /* [in] bool  enabled  */
                                    )
       {
        CLI_SCOPED_LOCK(cs);
        ENUM_CLI_GUI_EMENUITEMFLAGS stateFlags = 0;
        RCODE res = getCommandByIdState( cmdId, &stateFlags );
        if (res) return res;
        if (hidden) stateFlags |= CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
        else        stateFlags &= ~CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
        return setCommandByIdState( cmdId, stateFlags );
       }

    CLIMETHOD(executeCommandLine) (THIS_ const WCHAR*    cmdLine /* [in,flat] wchar  cmdLine[]  */
                                       , SIZE_T    cmdLineSize /* [in] size_t  cmdLineSize  */
                                  )
       {
        if (!cmdLine) return EC_INVALID_PARAM;
        INTERFACE_CLI_IARGLIST* pArgList = ::cli::cmd_line::split( ::std::wstring(cmdLine, cmdLineSize ) );
        if (!pArgList) return EC_INVALID_COMMAND_LINE;
        if (pArgList->getCount()==0)
           {
            pArgList->release();
            return EC_INVALID_COMMAND_LINE;
           }

        ::cli::CiArgList args(pArgList); // args object now owns pArgList
        pArgList->release(); // we can release object by its ptr

        ::std::wstring cmdName;
        if (args.getString( 0, cmdName ) || cmdName.empty()) // first arg is command name
           {
            return EC_INVALID_COMMAND_LINE;
           }
        args.shiftArgs1();
        invokeWithArgList( cmdName.c_str(), args.getIfPtr() );
        return EC_OK;
       }

    CLIMETHOD(setCommandHandler) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdId[]  */
                                 , INTERFACE_CLI_GUI_ICOMMAND*    newHandler /* [in] ::cli::gui::iCommand*  newHandler  */
                                 )
       {
        CLI_SCOPED_LOCK(cs);
        SIZE_T cmdId = SIZE_T_NPOS;
        RCODE res = getCommandId( cmdName, &cmdId );
        if (res) return res;
        return setCommandByIdHandler(cmdId, newHandler);
       }


    CLIMETHOD(isMenuId) (THIS_ SIZE_T    id /* [in] size_t  id  */
                             , BOOL*    isMenu /* [out] bool isMenu  */
                        )
       {
        if (!isMenu) return EC_OK;
        if (isMenuId(id)) *isMenu = TRUE;
        else              *isMenu = FALSE;
        return EC_OK;
       }

    CLIMETHOD(addCommandCategory) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                       , SIZE_T*    categoryIdAtom /* [out] size_t categoryIdAtom  */
                                  )
       {
        if (!categoryId) return EC_INVALID_PARAM;
        CLI_SCOPED_LOCK(cs);
        ::std::map< ::std::wstring, SIZE_T >::const_iterator toIdIt = categoriesToId.find( categoryId );
        if (toIdIt != categoriesToId.end())
           {
            if (categoryIdAtom) *categoryIdAtom = toIdIt->second;
            return EC_OK;
           }

        SIZE_T newIdAtom = categories.size();
        categoriesToId[categoryId] = newIdAtom;
        categories.push_back(categoryId);
        if (categoryIdAtom) *categoryIdAtom = newIdAtom;
        return EC_OK;
       }

    CLIMETHOD(getCommandCategoryId) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                         , SIZE_T*    categoryIdAtom /* [out] size_t categoryIdAtom  */
                                    )
       {
        if (!categoryId) return EC_INVALID_PARAM;
        CLI_SCOPED_LOCK(cs);
        ::std::map< ::std::wstring, SIZE_T >::const_iterator toIdIt = categoriesToId.find( categoryId );
        if (toIdIt != categoriesToId.end())
           {
            if (categoryIdAtom) *categoryIdAtom = toIdIt->second;
            return EC_OK;
           }
        return EC_NOT_FOUND;
        //EC_COMMAND_UNKNOWN
       }

    CLIMETHOD(getCommandCategoryName) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                           , WCHAR*    categoryIdNameBuf /* [out,flat,optional] wchar categoryIdNameBuf  */
                                           , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                      )
       {
        //if (!categoryId) return EC_INVALID_PARAM;
        CLI_SCOPED_LOCK(cs);
        if (categoryIdAtom>=categories.size()) return EC_NOT_FOUND;

        SIZE_T maxChars = bufSize-1;
        if (maxChars > categories[categoryIdAtom].size())
           maxChars = categories[categoryIdAtom].size();

        if (categoryIdNameBuf)
           {
            categories[categoryIdAtom].copy( categoryIdNameBuf, maxChars, 0 );
            categoryIdNameBuf[maxChars] = 0;
           }

        return EC_OK;
       }

    CLIMETHOD(enumCommandCategories) (THIS_ const WCHAR*    categoryIdMask /* [in,flat] wchar  categoryIdMask[]  */
                                          , SIZE_T*    foundCategoryIdAtom /* [in,out] size_t foundCategoryIdAtom  */
                                     )
       {
        if (!foundCategoryIdAtom) return EC_INVALID_PARAM;
        SIZE_T idAtom = *foundCategoryIdAtom;
        CLI_SCOPED_LOCK(cs);
        while( idAtom < categories.size() )
           {
            if (categoryIdMask)
               {
                if ( MARTY_FILENAME::matchMaskE( categories[idAtom], ::std::wstring(categoryIdMask) ) )
                   { // match
                    *foundCategoryIdAtom = idAtom;
                    return EC_OK;
                   }
               }
            else
               {
                *foundCategoryIdAtom = idAtom;
                return EC_OK;
               }

            ++idAtom;
           }

        return EC_NOT_FOUND;
       }

    CLIMETHOD(enumCommandCategoryItems) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                             , SIZE_T    idx /* [in] size_t  idx  */
                                             , SIZE_T*   cmdId /* [out] size_t cmdId  */
                                        )
       {
        if (!cmdId) return EC_INVALID_PARAM;
        CLI_SCOPED_LOCK(cs);
        ::std::map< SIZE_T, ::std::vector< SIZE_T > >::const_iterator cit = categoryItems.find( categoryIdAtom );
        if (cit == categoryItems.end()) return EC_INVALID_PARAM;
        if (idx >= cit->second.size()) return EC_OUT_OF_RANGE;
        if (cmdId) *cmdId = cit->second[idx];
        return EC_OK;
       }

    CLIMETHOD(modifyCommandStateByCategoryId) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                                   , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                   , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                              )
       {
        CLI_SCOPED_LOCK(cs);
        SIZE_T cmdOrMenuId = SIZE_T_NPOS;
        SIZE_T idx = 0;
        RCODE res = enumCommandCategoryItems( categoryIdAtom, idx, &cmdOrMenuId);
        for(; !res; ++idx, res = enumCommandCategoryItems( categoryIdAtom, idx, &cmdOrMenuId) )
           {
            ENUM_CLI_GUI_EMENUITEMFLAGS stateFlags = 0;
            bool bMenu = isMenuId(cmdOrMenuId);
            if (bMenu) getMenuByIdState( cmdOrMenuId, &stateFlags );
            else       getCommandByIdState( cmdOrMenuId, &stateFlags );

            stateFlags &= ~clearFlags;
            stateFlags |= setFlags;

            if (bMenu) setMenuByIdState( cmdOrMenuId, stateFlags );
            else       setCommandByIdState( cmdOrMenuId, stateFlags );
           }
        if (res==EC_OUT_OF_RANGE) return EC_OK;
        return res;
       }

    CLIMETHOD(modifyCommandStateByCategory) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                 , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                 , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                            )
       {
        SIZE_T categoryIdAtom = SIZE_T_NPOS;
        RCODE res = getCommandCategoryId( categoryId, &categoryIdAtom );
        if (res) return res;
        return modifyCommandStateByCategoryId( categoryIdAtom, clearFlags, setFlags );
       }

    CLIMETHOD(modifyCommandStateByCategoryMask) (THIS_ const WCHAR*    categoryIdMask /* [in,flat] wchar  categoryIdMask[]  */
                                                     , ENUM_CLI_GUI_EMENUITEMFLAGS    clearFlags /* [in] ::cli::gui::EMenuItemFlags  clearFlags  */
                                                     , ENUM_CLI_GUI_EMENUITEMFLAGS    setFlags /* [in] ::cli::gui::EMenuItemFlags  setFlags  */
                                                )
       {
        SIZE_T categoryIdAtom = 0;
        RCODE res = enumCommandCategories( categoryIdMask, &categoryIdAtom );
        for(; !res; ++categoryIdAtom, res = enumCommandCategories( categoryIdMask, &categoryIdAtom ) )
           {
            modifyCommandStateByCategoryId( categoryIdAtom, clearFlags, setFlags );
           }
        if (res==EC_NOT_FOUND) return EC_OK;
        return res;
       }


    CLIMETHOD(addCommandToCategory) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                         , const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                    )
       {
        SIZE_T categoryIdAtom = SIZE_T_NPOS;
        RCODE res = getCommandCategoryId( categoryId, &categoryIdAtom );
        if (res) return res;

        SIZE_T cmdIdAtom = SIZE_T_NPOS;

        res = getCommandId( cmdId, &cmdIdAtom );
        if (res)
           res = getMenuId( cmdId, &cmdIdAtom );

        if (res) return res;

        CLI_SCOPED_LOCK(cs);
        categoryItems[categoryIdAtom].push_back(cmdIdAtom);
        return EC_OK;
       }

    CLIMETHOD(addCommandToCategoryById) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                             , const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                        )
       {
        SIZE_T cmdIdAtom = SIZE_T_NPOS;

        RCODE res = getCommandId( cmdId, &cmdIdAtom );
        if (res)
           res = getMenuId( cmdId, &cmdIdAtom );

        if (res) return res;

        CLI_SCOPED_LOCK(cs);
        if (categoryIdAtom >= categories.size()) return EC_NOT_FOUND;
        categoryItems[categoryIdAtom].push_back(cmdIdAtom);
        return EC_OK;
       }

    CLIMETHOD(addCommandToCategoryById2) (THIS_ SIZE_T    categoryIdAtom /* [in] size_t  categoryIdAtom  */
                                              , SIZE_T    cmdId /* [in] size_t  cmdId  */
                                         )
       {
        CLI_SCOPED_LOCK(cs);
        if (categoryIdAtom >= categories.size()) return EC_NOT_FOUND;
        categoryItems[categoryIdAtom].push_back(cmdId);
        return EC_OK;       
       }

/*
    ::std::vector< ::std::wstring >                   categories;
    ::std::map< ::std::wstring, SIZE_T >              categoriesToId;
    ::std::map< SIZE_T, ::std::vector< SIZE_T > >     categoryItems;
*/




    ////////////////////////////////////////////////////////
    // old version
    ////////////////////////////////////////////////////////

    #if 0
    CLIMETHOD(addCommandSimple) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                     , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                     , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                )
       {
        return addCommand( cmdId, flags, handler, 0, 0, 0, 0, 0 );
       }

    CLIMETHOD(addCommandSimpleText) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                         , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                         , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                         , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                    )
       {
        return addCommand( cmdId, flags, handler, 0, itemText, 0, 0, 0 );
       }

    CLIMETHOD(addCommandRadio) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                    , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                    , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                    , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                               )
       {
        return addCommand( cmdId, flags, handler, 0, 0, 0, 0, radioGroupName );
       }

    CLIMETHOD(addCommandRadioText) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                        , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                                        , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                                        , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                                        , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                                   )
       {
        return addCommand( cmdId, flags, handler, 0, itemText, 0, 0, radioGroupName );
       }

    CLIMETHOD(enableCommand) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                  , BOOL    bEnabled /* [in] bool  bEnabled  */
                             )
       {
        ENUM_CLI_GUI_EMENUITEMFLAGS curState;
        RCODE res = getCommandState( cmdId, &curState );
        if (!RC_OK(res)) return res;
        if (bEnabled) curState &= ~(CLI_GUI_EMENUITEMFLAGS_FDISABLED); // clear disabled flags
        else          curState |=  (CLI_GUI_EMENUITEMFLAGS_FDISABLED);
        return setCommandState( cmdId, curState );
       }

    CLIMETHOD(invertCommandEnabled) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */)
       {
        ENUM_CLI_GUI_EMENUITEMFLAGS curState;
        RCODE res = getCommandState( cmdId, &curState );
        if (!RC_OK(res)) return res;
        if (curState&CLI_GUI_EMENUITEMFLAGS_FDISABLED) curState &= ~(CLI_GUI_EMENUITEMFLAGS_FDISABLED);
        else                                           curState |=  (CLI_GUI_EMENUITEMFLAGS_FDISABLED);
        return setCommandState( cmdId, curState );
       }

    CLIMETHOD(setCommandChecked) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                      , BOOL    bChecked /* [in] bool  bchecked  */
                                 )
       {
        ENUM_CLI_GUI_EMENUITEMFLAGS curState;
        RCODE res = getCommandState( cmdId, &curState );
        if (!RC_OK(res)) return res;
        if (bChecked) curState |=  CLI_GUI_EMENUITEMFLAGS_FCHECKED;
        else          curState &= ~CLI_GUI_EMENUITEMFLAGS_FCHECKED;
        return setCommandState( cmdId, curState );
       }

    CLIMETHOD(invertCommandChecked) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */)
       {
        ENUM_CLI_GUI_EMENUITEMFLAGS curState;
        RCODE res = getCommandState( cmdId, &curState );
        if (!RC_OK(res)) return res;
        if (curState&CLI_GUI_EMENUITEMFLAGS_FCHECKED) curState &=  ~CLI_GUI_EMENUITEMFLAGS_FCHECKED;
        else                                          curState |=   CLI_GUI_EMENUITEMFLAGS_FCHECKED;
        return setCommandState( cmdId, curState );
       }

    CLIMETHOD(invertCommandHidden) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */)
       { // CLI_GUI_EMENUITEMFLAGS_FHIDDEN
        ENUM_CLI_GUI_EMENUITEMFLAGS curState;
        RCODE res = getCommandState( cmdId, &curState );
        if (!RC_OK(res)) return res;
        if (curState&CLI_GUI_EMENUITEMFLAGS_FHIDDEN) curState &=  ~CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
        else                                         curState |=   CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
        return setCommandState( cmdId, curState );
       }

    CLIMETHOD(setCommandHidden) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                     , BOOL    bHidden /* [in] bool  bChecked  */
                                )
       {
        ENUM_CLI_GUI_EMENUITEMFLAGS curState;
        RCODE res = getCommandState( cmdId, &curState );
        if (!RC_OK(res)) return res;
        if (bHidden)  curState |=  CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
        else          curState &= ~CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
        return setCommandState( cmdId, curState );
       }
    #endif
}; // struct CMenuBuilderImplBase










/*
struct CRadioGroupInfo
{
    ::std::wstring          radioGroupName;
    ::std::vector<SIZE_T>   commands;
    CRadioGroupInfo() : radioGroupName(), commands() {}
    CRadioGroupInfo( const ::std::wstring &n) : radioGroupName(n), commands() {}
}; // struct CRadioGroupInfo

    ::std::map< ::std::wstring, SIZE_T >              radioToId;
    ::std::vector< CRadioGroupInfo >                  radioGroups;

*/
//-----------------------------------------------------------------------------
inline
SIZE_T CMenuBuilderImplBase::getRadioGroupId( const ::std::wstring &rgName)
   {
    ::std::map< ::std::wstring, SIZE_T >::const_iterator it = radioToId.find(rgName);
    if (it!=radioToId.end()) return it->second;

    SIZE_T newId = radioGroups.size();
    radioGroups.push_back( CRadioGroupInfo(rgName) );

    radioToId[rgName] = newId;
    return newId;
   }

// returns radiogriup id
inline
SIZE_T CMenuBuilderImplBase::addRadioGroupCommand( const ::std::wstring &rgName, SIZE_T cmdId)
   {
    ::std::map< ::std::wstring, SIZE_T >::const_iterator it = radioToId.find(rgName);
    if (it!=radioToId.end()) 
       {
        // found existing radiogroup
        radioGroups[it->second].commands.push_back(cmdId);
        return it->second;
       }

    SIZE_T newId = radioGroups.size();
    radioGroups.push_back( CRadioGroupInfo(rgName) );
    radioGroups[newId].commands.push_back(cmdId);

    radioToId[rgName] = newId;
    return newId;
   }

inline
bool CMenuBuilderImplBase::getRadioGroupName( SIZE_T rid, ::std::wstring &name)
   {
    if (rid>=radioGroups.size()) return false;
    name = radioGroups[rid].radioGroupName;
    return true;
   }

inline
bool CMenuBuilderImplBase::getRadioGroupCommands( SIZE_T rid, ::std::vector<SIZE_T> &commands)
   {
    if (rid>=radioGroups.size()) return false;
    commands = radioGroups[rid].commands;
    return true;
   }

inline
CRadioGroupInfo* CMenuBuilderImplBase::getRadioGroupInfo( SIZE_T rid )
   {
    if (rid>=radioGroups.size()) return 0;
    return &radioGroups[rid];
   }

inline
const CRadioGroupInfo* CMenuBuilderImplBase::getRadioGroupInfo( SIZE_T rid ) const
   {
    if (rid>=radioGroups.size()) return 0;
    return &radioGroups[rid];
   }

inline
RCODE CMenuBuilderImplBase::addNewMenu( const ::std::wstring &menuName, SIZE_T *pMenuId, CMenuInfo **ppNewMenuInfo)
   {
    // EC_NO_MEM
    // EC_ERR_ALLREADY
    try{
        CLI_SCOPED_LOCK(cs);
        if (menuName.empty()) return EC_INVALID_PARAM;

        ::std::map< ::std::wstring, SIZE_T >::const_iterator it = menuToId.find(menuName);
        if (it!=menuToId.end()) return EC_ERR_ALLREADY;

        size_t newPos = menus.size();
        menus.push_back(CMenuInfo(this));

        size_t  newMenuId = newPos + menuIdOffset; // maximum number of commands
        menuToId[menuName]  = newMenuId;
        //idToMenu[newMenuId] = menuName;

        menus[newPos].menuName = menuName;

        if (pMenuId)       *pMenuId = newMenuId;
        if (ppNewMenuInfo) *ppNewMenuInfo = &menus[newPos];

        return EC_OK;
       }
    catch(...)
       {
        return EC_NO_MEM;
       }
   }

inline
bool CMenuBuilderImplBase::isMenuId(SIZE_T id)
   {
    if (id==SIZE_T_NPOS) return false;
    if (id<menuIdOffset)        return false;
    return true;
   }

inline
RCODE CMenuBuilderImplBase::findMenuId( const ::std::wstring &menuName, SIZE_T *pId )
   {
    if (menuName.empty()) return EC_COMMAND_INVALID_NAME; // empty names not allowed
    CLI_SCOPED_LOCK(cs);
    ::std::map< ::std::wstring, SIZE_T >::const_iterator it = menuToId.find(menuName);
    if (it==menuToId.end()) return EC_COMMAND_UNKNOWN;
    // Ok, was found
    if (pId) *pId = it->second;
    return EC_OK;
   }

inline
RCODE CMenuBuilderImplBase::findMenuId( const WCHAR* menuName, SIZE_T *pId )
   {
    if (!menuName) return EC_COMMAND_INVALID_NAME; // empty names not allowed
    return findMenuId(::std::wstring(menuName), pId);
   }

inline
const CMenuInfo* CMenuBuilderImplBase::getMenuInfo( SIZE_T menuId ) const
   {
    if (menuId==SIZE_T_NPOS) return 0;
    if (menuId<menuIdOffset) return 0;
    menuId -= menuIdOffset;
    CLI_SCOPED_LOCK(cs);
    if (menuId>=menus.size()) return 0;
    return &menus[menuId];
   }

inline
CMenuInfo* CMenuBuilderImplBase::getMenuInfo( SIZE_T menuId )
   {
    if (menuId==SIZE_T_NPOS) return 0;
    if (menuId<menuIdOffset) return 0;
    menuId -= menuIdOffset;
    CLI_SCOPED_LOCK(cs);
    if (menuId>=menus.size()) return 0;
    return &menus[menuId];
   }

//-----------------------------------------------------------------------------













//-----------------------------------------------------------------------------
inline
CCommandInfoImplBase::CCommandInfoImplBase()
   : stateFlags(0)
   , handlersStack()
   , handlerArgs()
   , rcModuleName()
   , commandName()
   , itemText()
   , itemInfo()
   , accels()
   , radioGroupId(0)
   , usedInMenus()
   {}

inline
CCommandInfoImplBase::CCommandInfoImplBase(const CCommandInfoImplBase &ci)
   : stateFlags(ci.stateFlags)
   , handlersStack(ci.handlersStack)
   , handlerArgs(ci.handlerArgs)
   , rcModuleName()
   , commandName(ci.commandName)
   , itemText(ci.itemText)
   , itemInfo(ci.itemInfo)
   , accels(ci.accels)
   , radioGroupId(ci.radioGroupId)
   , usedInMenus(ci.usedInMenus)
   {}

inline
CCommandInfoImplBase& CCommandInfoImplBase::operator=(const CCommandInfoImplBase &ci)
   {
    if (this==&ci) return *this;
    stateFlags      = ci.stateFlags;
    handlersStack   = ci.handlersStack;
    handlerArgs     = ci.handlerArgs;
    rcModuleName    = ci.rcModuleName;
    commandName     = ci.commandName;
    itemText        = ci.itemText;
    itemInfo        = ci.itemInfo;
    accels          = ci.accels;
    radioGroupId    = ci.radioGroupId;
    usedInMenus     = ci.usedInMenus;
    return *this;
   }

inline
void CCommandInfoImplBase::releaseOwnedObjects()
   {
    while(!handlersStack.empty() && popCommandHandler()) {}
   }

inline
std::wstring CCommandInfoImplBase::getAccelText()
   {
    if (accels.empty()) return std::wstring();
    return makeAccelText(accels[0]);
   }

inline
void CCommandInfoImplBase::setText( const std::wstring &t)
   {
    itemText = t;
    std::wstring accelText; // = L"";
    updateMenusText(itemText,getAccelText());
   }

inline
void CCommandInfoImplBase::modifyAccels( BOOL bClearExisting, const STRUCT_CLI_GUI_CACCEL* newAccels, SIZE_T numNewAccels)
   {
    bool bNeedUpdateText = bClearExisting ? true : false;
    if (bClearExisting) accels.clear();
    if (newAccels && numNewAccels)
       accels.insert( accels.end(), newAccels, newAccels+numNewAccels );
    if (!accels.empty())
       updateMenusText(itemText,makeAccelText(accels[0]));
   }

inline
bool CCommandInfoImplBase::checkStacksConsistence()
   {
    if (handlersStack.size() != handlerArgs.size()) return false;
    if (handlersStack.empty()) return false;
    return true;
   }

inline
void CCommandInfoImplBase::pushCommandHandler( INTERFACE_CLI_GUI_ICOMMAND*    newHandler )
   {
    handlersStack.push(newHandler);
    INTERFACE_CLI_IARGLIST* pArgs = 0;
    if (!handlerArgs.empty()) pArgs = handlerArgs.top();
    if (pArgs) pArgs->addRef();
    handlerArgs.push(pArgs);
   }

// return false if stacks corrupted or not in sync
inline
bool CCommandInfoImplBase::popCommandHandler()
   {
    if (!checkStacksConsistence()) return false;

    INTERFACE_CLI_GUI_ICOMMAND* pHandler = handlersStack.top();
    handlersStack.pop();

    INTERFACE_CLI_IARGLIST* pArgs = handlerArgs.top();
    handlerArgs.pop();

    if (pHandler) pHandler->release();
    if (pArgs)    pArgs->release();

    return true;
   }

inline
bool CCommandInfoImplBase::setCommandHandler( INTERFACE_CLI_GUI_ICOMMAND*    newHandler )
   {
    if (!checkStacksConsistence()) return false;
    if (handlersStack.empty()) return false;

    INTERFACE_CLI_GUI_ICOMMAND* pOldHandler = handlersStack.top();
    if (pOldHandler) pOldHandler->release();

    handlersStack.top() = newHandler;
    return true;
   }

inline
bool CCommandInfoImplBase::setCommandArgs(INTERFACE_CLI_IARGLIST* newArgs)
   {
    if (!checkStacksConsistence()) return false;
    if (handlerArgs.empty()) return false;

    INTERFACE_CLI_IARGLIST* pOldArgs = handlerArgs.top();
    if (!pOldArgs) pOldArgs->release();

    handlerArgs.top() = newArgs;
    return true;
   }
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
inline
ENUM_CLI_GUI_EMENUITEMFLAGS CMenuInfo::getMenuState(SIZE_T menuId) const
   {
    if (!pOwnerBuilder) return CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
    ENUM_CLI_GUI_EMENUITEMFLAGS stateFlags = 0;
    RCODE res = pOwnerBuilder->getMenuByIdState(menuId, &stateFlags);
    if (res) return CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
    return stateFlags;
   }

//-----------------------------------------------------------------------------
inline
ENUM_CLI_GUI_EMENUITEMFLAGS CMenuInfo::getCommandState(SIZE_T cmdId) const
   {
    if (!pOwnerBuilder) return CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
    ENUM_CLI_GUI_EMENUITEMFLAGS stateFlags = 0;
    RCODE res = pOwnerBuilder->getCommandByIdState(cmdId, &stateFlags);
    if (res) return CLI_GUI_EMENUITEMFLAGS_FHIDDEN;
    return stateFlags;
   }

inline
void CMenuInfo::insertItem( SIZE_T atPos, const CMenuItem &item )
   {
    if (atPos>items.size()) atPos = items.size(); // at end
    items.insert( items.begin()+atPos, item );
   }

inline
SIZE_T CMenuInfo::findBreakPos( SIZE_T breakNo ) const
   {
    using namespace ::cli::gui::EMenuItemFlags;
    ::std::vector<CMenuItem>::const_iterator it = items.begin();
    SIZE_T curBreakNo = 0;
    for(; it!=items.end(); ++it)
       {
        if (it->itemFlags&(fMenuSeparator|fMenuBreak|fMenuBarBreak))
           {
            ++curBreakNo;
            if (curBreakNo==breakNo) return it - items.begin();
           }
       }
    return SIZE_T_NPOS;
   }

inline
SIZE_T CMenuInfo::findCommandPos( SIZE_T cmdId ) const
   {
    using namespace ::cli::gui::EMenuItemFlags;
    ::std::vector<CMenuItem>::const_iterator it = items.begin();
    for(; it!=items.end(); ++it)
       {
        if (it->itemFlags&(fMenuSeparator|fMenuBreak|fMenuBarBreak)) continue;
        if (it->commandId==cmdId) return it - items.begin();
       }
    return SIZE_T_NPOS;
   }

inline
SIZE_T CMenuInfo::findNextBreakPos( SIZE_T idx ) const
   { // idx itself not checked
   using namespace ::cli::gui::EMenuItemFlags;
    if (idx>=items.size()) return SIZE_T_NPOS;
    SIZE_T i = idx+1;
    for(; i!=items.size(); ++i)
       {
        if (items[i].itemFlags&(fMenuSeparator|fMenuBreak|fMenuBarBreak)) return i;
       }
    return SIZE_T_NPOS;
   }

inline
SIZE_T CMenuInfo::findPrevBreakPos( SIZE_T idx ) const
   { // idx itself not checked
    using namespace ::cli::gui::EMenuItemFlags;
    if (idx>=items.size()) return SIZE_T_NPOS;
    if (!idx) return SIZE_T_NPOS; //?
    SIZE_T i = idx;
    for(; i!=0; --i)
       {
        if (items[i-1].itemFlags&(fMenuSeparator|fMenuBreak|fMenuBarBreak)) return i-1;
       }
    return SIZE_T_NPOS;
   }

inline
SIZE_T CMenuInfo::findInsertPos( ENUM_CLI_GUI_EMENUINSERTPOS whatPos, SIZE_T cmdId /* or menuId or break index */) const
   {
    using namespace ::cli::gui::EMenuInsertPos;
    switch(whatPos)
       {
        case atBegin:      return 0;
        case atEnd:        return items.size();
        case beforeBreak:  if (!cmdId) return 0;
                           {
                            SIZE_T breakPos = findBreakPos( cmdId );
                            if (breakPos==SIZE_T_NPOS) return items.size(); // not found, insert at end
                            return breakPos;
                           }
        case afterBreak:   if (!cmdId) return 0;
                           {
                            SIZE_T breakPos = findBreakPos( cmdId );
                            if (breakPos==SIZE_T_NPOS) return items.size(); // not found, insert at end
                            return breakPos+1;
                           }
        case beforeCommand:
                           {
                            SIZE_T cmdPos = findCommandPos( cmdId );
                            if (cmdPos==SIZE_T_NPOS) return items.size(); // not found, insert at end
                            return cmdPos;
                           }
        case afterCommand:
                           {
                            SIZE_T cmdPos = findCommandPos( cmdId );
                            if (cmdPos==SIZE_T_NPOS) return items.size(); // not found, insert at end
                            return cmdPos+1;
                           }
        case firstBeforeCommand:
                           {
                            SIZE_T cmdPos = findCommandPos( cmdId );
                            if (cmdPos==SIZE_T_NPOS) return items.size(); // not found, insert at end
                            if (!cmdPos) return 0; // found at pos 0, insert at begin
                            SIZE_T breakPos = findPrevBreakPos( cmdPos ); // lookup for prev break
                            if (breakPos==SIZE_T_NPOS) return 0; // insert at begin
                            return breakPos+1;
                           }
        case lastAfterCommand:
                           {
                            SIZE_T cmdPos = findCommandPos( cmdId );
                            if (cmdPos==SIZE_T_NPOS) return items.size(); // not found, insert at end
                            SIZE_T breakPos = findNextBreakPos( cmdPos ); // lookup for next break
                            if (breakPos==SIZE_T_NPOS) return items.size(); // not found, insert at end
                            return breakPos;
                           }
        default: return items.size();
       }
   }

inline
void CMenuInfo::insertItem( ENUM_CLI_GUI_EMENUINSERTPOS whatPos, SIZE_T refCmdId, const CMenuItem &item )
   {
    insertItem( findInsertPos(whatPos, refCmdId), item );
   }

inline
void CMenuInfo::loadText()
   {
    menuText = pOwnerBuilder->findCommandText(rcModuleName, menuName );
   }

inline
void CMenuInfo::loadInfo()
   {
    menuInfo = pOwnerBuilder->findCommandInfo(rcModuleName, menuName);
   }


}; // namespace cli
}; // namespace gui
}; // namespace impl



#endif /* CLI_GUI_MENUBUILDERIMPL_H */
