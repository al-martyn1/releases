#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_ERRDLG_H
#define CLI_GUI_ERRDLG_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/errdlg.h>", CLI_GUI_ERRDLG_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_ERRDLG_H
    #include <cli/gui/errdlg.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_GUITYPES_H
    #include <cli/guitypes.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::gui::ErrorDialogFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_ERRORDIALOGFLAGS       DWORD
#else
    #define ENUM_CLI_GUI_ERRORDIALOGFLAGS       DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON
    #define CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON                 CONSTANT_DWORD(0x00000001)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON
    #define CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON           CONSTANT_DWORD(0x00000002)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_YESNOBUTTON
    #define CLI_GUI_ERRORDIALOGFLAGS_YESNOBUTTON              CONSTANT_DWORD(0x00000003)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_YESNOBUTTON */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_YESCANCELBUTTON
    #define CLI_GUI_ERRORDIALOGFLAGS_YESCANCELBUTTON          CONSTANT_DWORD(0x00000004)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_YESCANCELBUTTON */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_YESNOCANCELBUTTON
    #define CLI_GUI_ERRORDIALOGFLAGS_YESNOCANCELBUTTON        CONSTANT_DWORD(0x00000005)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_YESNOCANCELBUTTON */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_RETRYCANCELBUTTON
    #define CLI_GUI_ERRORDIALOGFLAGS_RETRYCANCELBUTTON        CONSTANT_DWORD(0x00000006)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_RETRYCANCELBUTTON */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ABORTRETRYIGNOREBUTTON
    #define CLI_GUI_ERRORDIALOGFLAGS_ABORTRETRYIGNOREBUTTON   CONSTANT_DWORD(0x00000007)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ABORTRETRYIGNOREBUTTON */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_CANCELTRYCONTINUEBUTTON
    #define CLI_GUI_ERRORDIALOGFLAGS_CANCELTRYCONTINUEBUTTON  CONSTANT_DWORD(0x00000008)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_CANCELTRYCONTINUEBUTTON */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_BUTTONFLAGSMASK
    #define CLI_GUI_ERRORDIALOGFLAGS_BUTTONFLAGSMASK          CONSTANT_DWORD(0x000000FF)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_BUTTONFLAGSMASK */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON1
    #define CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON1               CONSTANT_DWORD(0x00000100)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON1 */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON2
    #define CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON2               CONSTANT_DWORD(0x00000200)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON2 */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON3
    #define CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON3               CONSTANT_DWORD(0x00000300)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON3 */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON4
    #define CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON4               CONSTANT_DWORD(0x00000400)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON4 */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTONFLAGSMASK
    #define CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTONFLAGSMASK       CONSTANT_DWORD(0x00000F00)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTONFLAGSMASK */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_NOERRROCHAINS
    #define CLI_GUI_ERRORDIALOGFLAGS_NOERRROCHAINS            CONSTANT_DWORD(0x00001000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_NOERRROCHAINS */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ONLYLASTERROR
    #define CLI_GUI_ERRORDIALOGFLAGS_ONLYLASTERROR            CONSTANT_DWORD(0x00002000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ONLYLASTERROR */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_USECLIERROR
    #define CLI_GUI_ERRORDIALOGFLAGS_USECLIERROR              CONSTANT_DWORD(0x00010000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_USECLIERROR */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_USECLIERRORLIST
    #define CLI_GUI_ERRORDIALOGFLAGS_USECLIERRORLIST          CONSTANT_DWORD(0x00020000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_USECLIERRORLIST */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE
    #define CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE          CONSTANT_DWORD(0x00040000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE
    #define CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE          CONSTANT_DWORD(0x00080000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_SOURCEAUTO
    #define CLI_GUI_ERRORDIALOGFLAGS_SOURCEAUTO               CONSTANT_DWORD(0x00100000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_SOURCEAUTO */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_SOURCEDBLCLICKOPEN
    #define CLI_GUI_ERRORDIALOGFLAGS_SOURCEDBLCLICKOPEN       CONSTANT_DWORD(0x00200000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_SOURCEDBLCLICKOPEN */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_HIDEMESSAGEDATA
    #define CLI_GUI_ERRORDIALOGFLAGS_HIDEMESSAGEDATA          CONSTANT_DWORD(0x00400000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_HIDEMESSAGEDATA */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_FNOSAVE
    #define CLI_GUI_ERRORDIALOGFLAGS_FNOSAVE  CONSTANT_DWORD(0x00800000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_FNOSAVE */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONSFLAGSMASK
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONSFLAGSMASK           CONSTANT_DWORD(0x00F000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONSFLAGSMASK */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONEXCLAMATION
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONEXCLAMATION          CONSTANT_DWORD(0x001000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONEXCLAMATION */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONWARNING
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONWARNING              CONSTANT_DWORD(0x001000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONWARNING */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION          CONSTANT_DWORD(0x002000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONASTERISK
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONASTERISK             CONSTANT_DWORD(0x002000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONASTERISK */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONQUESTION
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONQUESTION             CONSTANT_DWORD(0x003000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONQUESTION */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONERROR
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONERROR                CONSTANT_DWORD(0x004000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONERROR */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONSTOP
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONSTOP                 CONSTANT_DWORD(0x004000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONSTOP */

#ifndef CLI_GUI_ERRORDIALOGFLAGS_ICONHAND
    #define CLI_GUI_ERRORDIALOGFLAGS_ICONHAND                 CONSTANT_DWORD(0x004000000)
#endif /* CLI_GUI_ERRORDIALOGFLAGS_ICONHAND */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace ErrorDialogFlags {
                    const DWORD okButton         = CONSTANT_DWORD(0x00000001);
                    const DWORD okCancelButton   = CONSTANT_DWORD(0x00000002);
                    const DWORD yesNoButton      = CONSTANT_DWORD(0x00000003);
                    const DWORD yesCancelButton  = CONSTANT_DWORD(0x00000004);
                    const DWORD yesNoCancelButton        = CONSTANT_DWORD(0x00000005);
                    const DWORD retryCancelButton        = CONSTANT_DWORD(0x00000006);
                    const DWORD abortRetryIgnoreButton   = CONSTANT_DWORD(0x00000007);
                    const DWORD cancelTryContinueButton  = CONSTANT_DWORD(0x00000008);
                    const DWORD buttonFlagsMask  = CONSTANT_DWORD(0x000000FF);
                    const DWORD defButton1       = CONSTANT_DWORD(0x00000100);
                    const DWORD defButton2       = CONSTANT_DWORD(0x00000200);
                    const DWORD defButton3       = CONSTANT_DWORD(0x00000300);
                    const DWORD defButton4       = CONSTANT_DWORD(0x00000400);
                    const DWORD defButtonFlagsMask       = CONSTANT_DWORD(0x00000F00);
                    const DWORD noErrroChains    = CONSTANT_DWORD(0x00001000);
                    const DWORD onlyLastError    = CONSTANT_DWORD(0x00002000);
                    const DWORD useCliError      = CONSTANT_DWORD(0x00010000);
                    const DWORD useCliErrorList  = CONSTANT_DWORD(0x00020000);
                    const DWORD forceShowSource  = CONSTANT_DWORD(0x00040000);
                    const DWORD forceHideSource  = CONSTANT_DWORD(0x00080000);
                    const DWORD sourceAuto       = CONSTANT_DWORD(0x00100000);
                    const DWORD sourceDblClickOpen       = CONSTANT_DWORD(0x00200000);
                    const DWORD hideMessageData  = CONSTANT_DWORD(0x00400000);
                    const DWORD fNoSave          = CONSTANT_DWORD(0x00800000);
                    const DWORD iconsFlagsMask   = CONSTANT_DWORD(0x00F000000);
                    const DWORD iconExclamation  = CONSTANT_DWORD(0x001000000);
                    const DWORD iconWarning      = CONSTANT_DWORD(0x001000000);
                    const DWORD iconInformation  = CONSTANT_DWORD(0x002000000);
                    const DWORD iconAsterisk     = CONSTANT_DWORD(0x002000000);
                    const DWORD iconQuestion     = CONSTANT_DWORD(0x003000000);
                    const DWORD iconError        = CONSTANT_DWORD(0x004000000);
                    const DWORD iconStop         = CONSTANT_DWORD(0x004000000);
                    const DWORD iconHand         = CONSTANT_DWORD(0x004000000);
            }; // namespace ErrorDialogFlags
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::ErrorDialogFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::DialogResult */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_DIALOGRESULT           DWORD
#else
    #define ENUM_CLI_GUI_DIALOGRESULT           DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_DIALOGRESULT_OKBUTTON
    #define CLI_GUI_DIALOGRESULT_OKBUTTON     CONSTANT_DWORD(0x00000001)
#endif /* CLI_GUI_DIALOGRESULT_OKBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_CANCELBUTTON
    #define CLI_GUI_DIALOGRESULT_CANCELBUTTON                 CONSTANT_DWORD(0x00000002)
#endif /* CLI_GUI_DIALOGRESULT_CANCELBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_YESBUTTON
    #define CLI_GUI_DIALOGRESULT_YESBUTTON    CONSTANT_DWORD(0x00000003)
#endif /* CLI_GUI_DIALOGRESULT_YESBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_NOBUTTON
    #define CLI_GUI_DIALOGRESULT_NOBUTTON     CONSTANT_DWORD(0x00000004)
#endif /* CLI_GUI_DIALOGRESULT_NOBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_RETRYBUTTON
    #define CLI_GUI_DIALOGRESULT_RETRYBUTTON  CONSTANT_DWORD(0x00000005)
#endif /* CLI_GUI_DIALOGRESULT_RETRYBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_ABORTBUTTON
    #define CLI_GUI_DIALOGRESULT_ABORTBUTTON  CONSTANT_DWORD(0x00000006)
#endif /* CLI_GUI_DIALOGRESULT_ABORTBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_IGNOREBUTTON
    #define CLI_GUI_DIALOGRESULT_IGNOREBUTTON                 CONSTANT_DWORD(0x00000007)
#endif /* CLI_GUI_DIALOGRESULT_IGNOREBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_TRYBUTTON
    #define CLI_GUI_DIALOGRESULT_TRYBUTTON    CONSTANT_DWORD(0x00000008)
#endif /* CLI_GUI_DIALOGRESULT_TRYBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_CONTINUEBUTTON
    #define CLI_GUI_DIALOGRESULT_CONTINUEBUTTON               CONSTANT_DWORD(0x00000009)
#endif /* CLI_GUI_DIALOGRESULT_CONTINUEBUTTON */

#ifndef CLI_GUI_DIALOGRESULT_FAILED
    #define CLI_GUI_DIALOGRESULT_FAILED       CONSTANT_DWORD(0xC000000A)
#endif /* CLI_GUI_DIALOGRESULT_FAILED */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace DialogResult {
                    const DWORD okButton         = CONSTANT_DWORD(0x00000001);
                    const DWORD cancelButton     = CONSTANT_DWORD(0x00000002);
                    const DWORD yesButton        = CONSTANT_DWORD(0x00000003);
                    const DWORD noButton         = CONSTANT_DWORD(0x00000004);
                    const DWORD retryButton      = CONSTANT_DWORD(0x00000005);
                    const DWORD abortButton      = CONSTANT_DWORD(0x00000006);
                    const DWORD ignoreButton     = CONSTANT_DWORD(0x00000007);
                    const DWORD tryButton        = CONSTANT_DWORD(0x00000008);
                    const DWORD continueButton   = CONSTANT_DWORD(0x00000009);
                    const DWORD failed           = CONSTANT_DWORD(0xC000000A);
            }; // namespace DialogResult
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::DialogResult; */
    
#endif





/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iErrorDialog */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iErrorInfo;
        #ifndef INTERFACE_CLI_IERRORINFO
            #define INTERFACE_CLI_IERRORINFO          ::cli::iErrorInfo
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IERRORINFO_PREDECLARED
    #define INTERFACE_CLI_IERRORINFO_PREDECLARED
    typedef interface tag_cli_iErrorInfo     cli_iErrorInfo;
    #endif //INTERFACE_CLI_IERRORINFO
    #ifndef INTERFACE_CLI_IERRORINFO
        #define INTERFACE_CLI_IERRORINFO          struct tag_cli_iErrorInfo
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_IERRORDIALOG_IID
    #define INTERFACE_CLI_GUI_IERRORDIALOG_IID    "/cli/gui/iErrorDialog"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iErrorDialog
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_IERRORDIALOG
       #define INTERFACE_CLI_GUI_IERRORDIALOG    ::cli::gui::iErrorDialog
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iErrorDialog
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_IERRORDIALOG
       #define INTERFACE_CLI_GUI_IERRORDIALOG    cli_gui_iErrorDialog
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iErrorDialog methods */
                CLIMETHOD(showModal) (THIS_ ENUM_CLI_GUI_DIALOGRESULT*    res /* [out] ::cli::gui::DialogResult res  */
                                          , WND_HANDLE    parentWnd /* [in] pwnd  parentWnd  */
                                          , const WCHAR*    caption /* [in,flat] wchar  caption[]  */
                                          , SIZE_T    captionLen /* [in] size_t  captionLen  */
                                          , INTERFACE_CLI_IERRORINFO**    errList /* [in,flat] ::cli::iErrorInfo*  errList[]  */
                                          , SIZE_T    errListSize /* [in] size_t  errListSize  */
                                          , ENUM_CLI_GUI_ERRORDIALOGFLAGS    flags /* [in] ::cli::gui::ErrorDialogFlags  flags  */
                                          , const WCHAR*    locale /* [in] wchar*  locale  */
                                     ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iErrorDialog >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_IERRORDIALOG_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iErrorDialog* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iErrorDialog > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iErrorDialog wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_IERRORDIALOG >
                                          */
                     >
            class CiErrorDialogWrapper
            {
                public:
            
                    typedef  CiErrorDialogWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiErrorDialogWrapper() :
                       pif(0) {}
            
                    CiErrorDialogWrapper( iErrorDialog *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiErrorDialogWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiErrorDialogWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiErrorDialogWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiErrorDialogWrapper(const CiErrorDialogWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiErrorDialogWrapper()  { }
            
                    CiErrorDialogWrapper& operator=(const CiErrorDialogWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE showModal( ENUM_CLI_GUI_DIALOGRESULT*    res /* [out] ::cli::gui::DialogResult res  */
                                   , WND_HANDLE    parentWnd /* [in] pwnd  parentWnd  */
                                   , const WCHAR*    caption /* [in,flat] wchar  caption[]  */
                                   , SIZE_T    captionLen /* [in] size_t  captionLen  */
                                   , INTERFACE_CLI_IERRORINFO**    errList /* [in,flat] ::cli::iErrorInfo*  errList[]  */
                                   , SIZE_T    errListSize /* [in] size_t  errListSize  */
                                   , ENUM_CLI_GUI_ERRORDIALOGFLAGS    flags /* [in] ::cli::gui::ErrorDialogFlags  flags  */
                                   , const WCHAR*    locale /* [in] wchar*  locale  */
                                   )
                       {
                    
                    
                    
                    
                    
                    
                    
                    
                        return pif->showModal(res, parentWnd, caption, captionLen, errList, errListSize, flags, locale);
                       }
                    

            
            
            }; // class CiErrorDialogWrapper
            
            typedef CiErrorDialogWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_IERRORDIALOG     > >  CiErrorDialog;
            typedef CiErrorDialogWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IERRORDIALOG > >  CiErrorDialog_nrc; /* No ref counting for interface used */
            typedef CiErrorDialogWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IERRORDIALOG > >  CiErrorDialog_tmp; /* for temporary usage, same as CiErrorDialog_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iSimpleMessageBox */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX_IID
    #define INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX_IID    "/cli/gui/iSimpleMessageBox"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iSimpleMessageBox
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX
       #define INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX    ::cli::gui::iSimpleMessageBox
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iSimpleMessageBox
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX
       #define INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX    cli_gui_iSimpleMessageBox
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iSimpleMessageBox methods */
                CLIMETHOD(showModal) (THIS_ ENUM_CLI_GUI_DIALOGRESULT*    res /* [out] ::cli::gui::DialogResult res  */
                                          , WND_HANDLE    parentWnd /* [in] pwnd  parentWnd  */
                                          , const WCHAR*    caption /* [in,flat] wchar  caption[]  */
                                          , SIZE_T    captionLen /* [in] size_t  captionLen  */
                                          , const WCHAR*    message /* [in,flat] wchar  message[]  */
                                          , SIZE_T    messageLen /* [in] size_t  messageLen  */
                                          , ENUM_CLI_GUI_ERRORDIALOGFLAGS    flags /* [in] ::cli::gui::ErrorDialogFlags  flags  */
                                     ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iSimpleMessageBox >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iSimpleMessageBox* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iSimpleMessageBox > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iSimpleMessageBox wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX >
                                          */
                     >
            class CiSimpleMessageBoxWrapper
            {
                public:
            
                    typedef  CiSimpleMessageBoxWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiSimpleMessageBoxWrapper() :
                       pif(0) {}
            
                    CiSimpleMessageBoxWrapper( iSimpleMessageBox *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiSimpleMessageBoxWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiSimpleMessageBoxWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiSimpleMessageBoxWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiSimpleMessageBoxWrapper(const CiSimpleMessageBoxWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiSimpleMessageBoxWrapper()  { }
            
                    CiSimpleMessageBoxWrapper& operator=(const CiSimpleMessageBoxWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE showModal( ENUM_CLI_GUI_DIALOGRESULT*    res /* [out] ::cli::gui::DialogResult res  */
                                   , WND_HANDLE    parentWnd /* [in] pwnd  parentWnd  */
                                   , const WCHAR*    caption /* [in,flat] wchar  caption[]  */
                                   , SIZE_T    captionLen /* [in] size_t  captionLen  */
                                   , const WCHAR*    message /* [in,flat] wchar  message[]  */
                                   , SIZE_T    messageLen /* [in] size_t  messageLen  */
                                   , ENUM_CLI_GUI_ERRORDIALOGFLAGS    flags /* [in] ::cli::gui::ErrorDialogFlags  flags  */
                                   )
                       {
                    
                    
                    
                    
                    
                    
                    
                        return pif->showModal(res, parentWnd, caption, captionLen, message, messageLen, flags);
                       }
                    

            
            
            }; // class CiSimpleMessageBoxWrapper
            
            typedef CiSimpleMessageBoxWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX     > >  CiSimpleMessageBox;
            typedef CiSimpleMessageBoxWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX > >  CiSimpleMessageBox_nrc; /* No ref counting for interface used */
            typedef CiSimpleMessageBoxWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX > >  CiSimpleMessageBox_tmp; /* for temporary usage, same as CiSimpleMessageBox_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif





#endif /* CLI_GUI_ERRDLG_H */
