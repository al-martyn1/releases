#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_WTL_FRAMEHLP_H
#define CLI_GUI_WTL_FRAMEHLP_H

#include <marty/winapi.h>
#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef MARTY_WINAPI
    #ifdef WINAPI_IN_MARTY_NAMESPACE
        #define MARTY_WINAPI ::marty::winapi
    #else
        #define MARTY_WINAPI ::winapi
    #endif
#endif


namespace cli
{
namespace wtl
{

template <typename TFrame>
class CFrameHlp
{

public:

    typedef MARTY_WINAPI::tstring tstring;

    // helpers
    HWND getHwnd()
       {
        return ((TFrame*)this)->m_hWnd;
       }

    // do not set this string directly, use setters below
protected:
    tstring frameTitle;
    tstring frameDocument;

public:
    virtual tstring composeFrameTitle(const tstring &t, const tstring &d)
       {
        if (d.empty()) return t;
        return d + tstring(_T(" - ")) + t;
       }

    void setFrameTitle(const tstring &t)
       {
        frameTitle = t;
        ::SetWindowText( getHwnd(), composeFrameTitle(frameTitle,frameDocument).c_str() );
       }

    void setFrameDocumentName(const tstring &d)
       {
        frameDocument = d;
        ::SetWindowText( getHwnd(), composeFrameTitle(frameTitle,frameDocument).c_str() );
       }

    int messageBox( const tstring &msg, int flags = MB_OK)
       {
        return ::MessageBox( getHwnd(), msg.c_str(), frameTitle.c_str(), flags );
       }

    tstring toTstring(const ::std::wstring &_str)
       {
        #if defined(UNICODE) || defined(_UNICODE)
        return _str;
        #else
        return MARTY_CON_NS strToAnsi(_str);
        #endif    
       }

    tstring toTstring(const ::std::string &_str)
       {
        #if defined(UNICODE) || defined(_UNICODE)
        return MARTY_CON_NS strToWide(_str);
        #else
        return _str;
        #endif    
       }

    //using ::cli::format::arg;
    typedef ::cli::format::arg arg;

    int formatMessageBox(const ::std::wstring &msg, const arg &args, int flags = MB_OK)
       {
        using ::cli::format::message;
        return messageBox( toTstring( message(msg, args) ), flags);
       }


}; // CFrameHlp

}; // namespace wtl
}; // namespace cli




#endif /* CLI_GUI_WTL_FRAMEHLP_H */

