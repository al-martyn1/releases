#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_WTL_MENUBUILDERIMPL_H
#define CLI_GUI_WTL_MENUBUILDERIMPL_H

#ifndef CLI_GUI_WIN_MENUBUILDERIMPL_H
    #include <cli/gui/win/menuBuilderImpl.h>
#endif

namespace cli {
namespace gui {
namespace impl {
namespace wtl {


// TODO: http://www.codeproject.com/KB/vista/RibbonUI.aspx

inline
void setStatusBarSimpleText( HWND hWndStatusBar, BOOL bSimple, const WCHAR * text )
   {
    ::SendMessage( hWndStatusBar, SB_SIMPLE, bSimple, 0L );
    if (!bSimple) return;

    if (!text)
       {
        TCHAR buf[1]; buf[0] = 0;
        ::SendMessage( hWndStatusBar, SB_SETTEXT, (255 | SBT_NOBORDERS), (LPARAM)buf);
        return;
       }

    #if defined(UNICODE) || defined(_UNICODE)
    ::SendMessageW( hWndStatusBar, SB_SETTEXT, (255 | SBT_NOBORDERS), (LPARAM)text);
    #else
    CHAR ch_szBuff[1024];
    ch_szBuff[0] = 0;
    if (!::WideCharToMultiByte( CP_ACP,
                           WC_COMPOSITECHECK,
                           text,
                           -1,
                           ch_szBuff,
                           sizeof(ch_szBuff)/sizeof(ch_szBuff[0]),
                           0, 0
                           ))
       {
        ch_szBuff[0] = 0;
       }
    else
       {
       }
    ::SendMessageA(hWndStatusBar, SB_SETTEXT, (255 | SBT_NOBORDERS), (LPARAM)ch_szBuff);
    #endif
   }


class CMenuBuilderImpl : public ::cli::gui::impl::win::CMenuBuilderImplBase
{



}; // class CMenuBuilderImpl





/* How to use CMenuBuilderContainer with WTL window
1) Add CMenuBuilderContainer into base class list
    class CMainFrame : public CFrameWindowImpl<CMainFrame>
                     ...
                     , public ::cli::gui::impl::wtl::CMenuBuilderContainer<CMainFrame>

2) Be sure to call constructor and pass pointers to m_hWndStatusBar and m_hAccel
    CMainFrame()
       : CFrameWindowImpl<CMainFrame>()
       ...
       , CMenuBuilderContainer( &m_hWndStatusBar, &m_hAccel)
       {
       ...
       typedef ::cli::gui::impl::wtl::CMenuBuilderContainer<CMainFrame> CMenuBuilderContainer;


3) Chain message map after all others
    BEGIN_MSG_MAP(CMainFrame)
        MESSAGE_HANDLER(WM_CREATE, OnCreate)
        ...
        CHAIN_MSG_MAP(CMenuBuilderContainer)
    END_MSG_MAP()

4) 
    LRESULT CMainFrame::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
    {
        // a. set bHandled=FALSE in OnCreate handler
        bHandled = FALSE;

        // b. initialize CMenuBuilderContainer::m_menuBuilder
        //m_menuBuilder.setWindow(m_hWnd);
        m_menuBuilder.setEmptyStringResourceId(L"empty-string");

        // c. add commands and menus to m_menuBuilder
        // m_menuBuilder.addCommand
        // m_menuBuilder.addMenu
        // m_menuBuilder.appendMenuItem
    
        // d. Create main menu
        m_CmdBar.AttachMenu( m_menuBuilder.createMenu(L"main-menu", FALSE) );
        

5) Note: You must use 'Create' method for CMainFrame instedad of 'CreateEx' to prevent 
   m_hAccel to be overwriten.

    //if(wndFrame.CreateEx() == NULL) // Wrong usage (but is default)
    if(wndFrame.Create(0, 0, 0, 0, 0, 0, 0 ) == NULL)

6) if you use CMessageFilter, add PreTranslateMessage method:

    BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
    {
        if (m_hAccel != NULL && ::TranslateAccelerator(m_hWnd, m_hAccel, pMsg))
    
        if(CFrameWindowImpl<CMainFrame>::PreTranslateMessage(pMsg))
            return TRUE;
    
        if (CMenuBuilderContainer::PreTranslateMessage(pMsg))
           return TRUE;
    
        return m_view.PreTranslateMessage(pMsg);
    }

NOTE: if some other windows need to use the same menu builder, that windows must
handle WM_COMMAND and pass it to main window m_menuBuilder as show above:
    return m_menuBuilder.translateOnCommand(uMsg, wParam);

If other window need to show status message in status bar it need to process WM_MENUSELECT
and call main window processOnMenuSelect method
    LRESULT processOnMenuSelect(UINT uMsg, WPARAM wParam, LPARAM lParam
                               , HWND hwndStatusBar
                               )

If other window need to translate accelerators, it must call main m_menuBuilder builder translateMessage method

Than accelerators changed, there is no notification for other windows.
You can write class derived from CMenuBuilderContainer and override virtual method 
    void notifyAccelChanged( );
and write code to update accels for other windows



        if (m_menuBuilder.translateMessage(pMsg)) 
           return TRUE;

    BOOL PreTranslateMessage(MSG* pMsg)
       {
        if (m_menuBuilder.translateMessage(pMsg)) 
           return TRUE;
        return FALSE;
       }


If other window need to show popup menu, use next methods
    void trackPopup(HWND hwndPopup, const WCHAR* menuName, INT cx, INT cy );
    void trackPopup(HWND hwndPopup, const WCHAR* menuName );
instead of
    void trackPopup(const WCHAR* menuName );
    void trackPopup(const WCHAR* menuName, INT cx, INT cy );

*/




template <typename TCHILD, typename TMENUBUILDER = ::cli::gui::impl::wtl::CMenuBuilderImpl >
class CMenuBuilderContainer
{

    class CMenuBuilderImpl : public TMENUBUILDER
    {
        public:
            CMenuBuilderContainer< TCHILD, TMENUBUILDER > *pFrame;
            CMenuBuilderImpl( CMenuBuilderContainer< TCHILD, TMENUBUILDER > *pf = 0) : pFrame(pf) {}
    
        protected:

            void implementTrackPopup( HMENU hMenu, int x, int y, UINT tpmFlags )
               {
                if (!pFrame) return;
                if (!pFrame->m_phAccel) return;
                tpmFlags &= (TPM_NONOTIFY|TPM_RETURNCMD);
                HWND hwnd = pFrame->m_hwndPopup;
                //if (!hwnd) hwnd = pFrame->m_hWnd;

                if (x<0 && y<0)
                   { // use screen coordinates
                    ::TrackPopupMenu( hMenu, tpmFlags, -x, -y, 0, hwnd, 0 );
                   }
                else
                   { // x, y are client coordinates
                    POINT p; p.x = x; p.y = y;
                    ::ClientToScreen( hwnd, &p );
                    ::TrackPopupMenu( hMenu, tpmFlags, p.x, p.y, 0, hwnd, 0 );
                   }
               }
        
            void notifyAccelChanged( )
               {
                if (!pFrame) return;
                if (!pFrame->m_phAccel) return;
                HACCEL &hAccel = *(pFrame->m_phAccel);
                if (hAccel) destroyAcceleratorTable(hAccel);
                hAccel = createAcceleratorTable( FALSE );
                pFrame->notifyAccelChanged();
               }
    };



public:

    CMenuBuilderImpl     m_menuBuilder;
protected:

    HWND                *m_phWndStatusBar;
    HACCEL              *m_phAccel;

    HWND                 m_hwndPopup;

public:

    CMenuBuilderContainer( HWND   *phWndStatusBar = 0 
                         , HACCEL *phAccel = 0
                         ) 
                         : m_menuBuilder(this)
                         , m_phWndStatusBar(phWndStatusBar)
                         , m_phAccel(phAccel)
                         , m_hwndPopup(0)
                         {}

    BEGIN_MSG_MAP(CMenuBuilderContainer)
        MESSAGE_HANDLER(WM_CREATE, OnCreate)
        MESSAGE_HANDLER(WM_COMMAND, OnCommand)
        MESSAGE_HANDLER(WM_MENUSELECT, OnMenuSelect)
    END_MSG_MAP()

    virtual void notifyAccelChanged( )
       {
       }

    void trackPopup(const WCHAR* menuName, INT cx, INT cy )
       {
        if (!m_hwndPopup) m_hwndPopup = ((TCHILD*)this)->m_hWnd;
        m_menuBuilder.trackPopup( menuName, cx, cy );
       }

    void trackPopup(const WCHAR* menuName )
       {
        POINT p = { 0, 0 };
        ::GetCursorPos( &p );
        if (!m_hwndPopup) m_hwndPopup = ((TCHILD*)this)->m_hWnd;
        trackPopup( menuName, -p.x, -p.y );
       }

    void trackPopup(HWND hwndPopup, const WCHAR* menuName, INT cx, INT cy )
       {
        m_hwndPopup = hwndPopup;
        m_menuBuilder.trackPopup( menuName, cx, cy );
        m_hwndPopup = 0;
       }

    void trackPopup(HWND hwndPopup, const WCHAR* menuName )
       {
        POINT p = { 0, 0 };
        ::GetCursorPos( &p );
        trackPopup( hwndPopup, menuName, -p.x, -p.y );
       }

    BOOL PreTranslateMessage(MSG* pMsg)
       {
        if (m_menuBuilder.translateMessage(pMsg)) 
           return TRUE;
        return FALSE;
       }


    LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
       {
        bHandled = FALSE;
        if (!m_phAccel) return 0;
        HACCEL &hAccel = *m_phAccel;
        //if (hAccel) destroyAcceleratorTable(pMainFrame->m_hAccel);
        hAccel = m_menuBuilder.createAcceleratorTable( FALSE );
        return 0;
       }

    LRESULT OnCommand(UINT uMsg, WPARAM wParam, LPARAM /*lParam*/, BOOL&  /* bHandled */ )
       {
        return m_menuBuilder.translateOnCommand(uMsg, wParam);
       }

    LRESULT processOnMenuSelect(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam
                               , HWND hwndStatusBar
                               )
       {
        WORD wFlags = HIWORD(wParam);
        if (wFlags == 0xFFFF && lParam == NULL)   // menu closing
           {
            ::cli::gui::impl::wtl::setStatusBarSimpleText( hwndStatusBar, FALSE, 0 );
           }
        else
           {
            const SIZE_T cchBuff = 256;
            WCHAR szBuff[cchBuff];
            szBuff[0] = 0;
            m_menuBuilder.getMenuItemInfoTextOnMenuSelect( wParam, lParam, szBuff, cchBuff );
            ::cli::gui::impl::wtl::setStatusBarSimpleText( hwndStatusBar, TRUE, szBuff );
           }
        return 1;
       }

    LRESULT OnMenuSelect(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
       {
        bHandled = FALSE;
        if (!m_phWndStatusBar) return 1;
        HWND hWndStatusBar = *m_phWndStatusBar;
        if (hWndStatusBar == NULL) return 1;
        return processOnMenuSelect( uMsg, wParam, lParam, hWndStatusBar );
       }

}; // CMenuBuilderContainer




}; // namespace cli
}; // namespace gui
}; // namespace impl
}; // namespace wtl



#endif /* CLI_GUI_WTL_MENUBUILDERIMPL_H */

