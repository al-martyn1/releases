#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_VK_H
#define CLI_GUI_VK_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/vk.h>", CLI_GUI_VK_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_VK_H
    #include <cli/gui/vk.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::EVK */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EVK                        UINT
#else
    #define ENUM_CLI_EVK                        UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EVK_BACK
    #define CLI_EVK_BACK                      CONSTANT_UINT(0x08)
#endif /* CLI_EVK_BACK */

#ifndef CLI_EVK_TAB
    #define CLI_EVK_TAB                       CONSTANT_UINT(0x09)
#endif /* CLI_EVK_TAB */

#ifndef CLI_EVK_RET
    #define CLI_EVK_RET                       CONSTANT_UINT(0x0D)
#endif /* CLI_EVK_RET */

#ifndef CLI_EVK_PAUSE
    #define CLI_EVK_PAUSE                     CONSTANT_UINT(0x13)
#endif /* CLI_EVK_PAUSE */

#ifndef CLI_EVK_CAPITAL
    #define CLI_EVK_CAPITAL                   CONSTANT_UINT(0x14)
#endif /* CLI_EVK_CAPITAL */

#ifndef CLI_EVK_ESCAPE
    #define CLI_EVK_ESCAPE                    CONSTANT_UINT(0x1B)
#endif /* CLI_EVK_ESCAPE */

#ifndef CLI_EVK_SPACE
    #define CLI_EVK_SPACE                     CONSTANT_UINT(0x20)
#endif /* CLI_EVK_SPACE */

#ifndef CLI_EVK_NUMLOCK
    #define CLI_EVK_NUMLOCK                   CONSTANT_UINT(0x90)
#endif /* CLI_EVK_NUMLOCK */

#ifndef CLI_EVK_SCROLL
    #define CLI_EVK_SCROLL                    CONSTANT_UINT(0x91)
#endif /* CLI_EVK_SCROLL */

#ifndef CLI_EVK_NEXT
    #define CLI_EVK_NEXT                      CONSTANT_UINT(0x22)
#endif /* CLI_EVK_NEXT */

#ifndef CLI_EVK_PRIOR
    #define CLI_EVK_PRIOR                     CONSTANT_UINT(0x21)
#endif /* CLI_EVK_PRIOR */

#ifndef CLI_EVK_END
    #define CLI_EVK_END                       CONSTANT_UINT(0x23)
#endif /* CLI_EVK_END */

#ifndef CLI_EVK_HOME
    #define CLI_EVK_HOME                      CONSTANT_UINT(0x24)
#endif /* CLI_EVK_HOME */

#ifndef CLI_EVK_LEFT
    #define CLI_EVK_LEFT                      CONSTANT_UINT(0x25)
#endif /* CLI_EVK_LEFT */

#ifndef CLI_EVK_UP
    #define CLI_EVK_UP                        CONSTANT_UINT(0x26)
#endif /* CLI_EVK_UP */

#ifndef CLI_EVK_DOWN
    #define CLI_EVK_DOWN                      CONSTANT_UINT(0x28)
#endif /* CLI_EVK_DOWN */

#ifndef CLI_EVK_RIGHT
    #define CLI_EVK_RIGHT                     CONSTANT_UINT(0x27)
#endif /* CLI_EVK_RIGHT */

#ifndef CLI_EVK_SLEEP
    #define CLI_EVK_SLEEP                     CONSTANT_UINT(0x5F)
#endif /* CLI_EVK_SLEEP */

#ifndef CLI_EVK_SNAPSHOT
    #define CLI_EVK_SNAPSHOT                  CONSTANT_UINT(0x2C)
#endif /* CLI_EVK_SNAPSHOT */

#ifndef CLI_EVK_PRINTSCREEN
    #define CLI_EVK_PRINTSCREEN               CONSTANT_UINT(0x2C)
#endif /* CLI_EVK_PRINTSCREEN */

#ifndef CLI_EVK_INS
    #define CLI_EVK_INS                       CONSTANT_UINT(0x2D)
#endif /* CLI_EVK_INS */

#ifndef CLI_EVK_DEL
    #define CLI_EVK_DEL                       CONSTANT_UINT(0x2E)
#endif /* CLI_EVK_DEL */

#ifndef CLI_EVK_LWIN
    #define CLI_EVK_LWIN                      CONSTANT_UINT(0x5B)
#endif /* CLI_EVK_LWIN */

#ifndef CLI_EVK_RWIN
    #define CLI_EVK_RWIN                      CONSTANT_UINT(0x5C)
#endif /* CLI_EVK_RWIN */

#ifndef CLI_EVK_NUMPAD0
    #define CLI_EVK_NUMPAD0                   CONSTANT_UINT(0x60)
#endif /* CLI_EVK_NUMPAD0 */

#ifndef CLI_EVK_NUMPAD1
    #define CLI_EVK_NUMPAD1                   CONSTANT_UINT(0x61)
#endif /* CLI_EVK_NUMPAD1 */

#ifndef CLI_EVK_NUMPAD2
    #define CLI_EVK_NUMPAD2                   CONSTANT_UINT(0x62)
#endif /* CLI_EVK_NUMPAD2 */

#ifndef CLI_EVK_NUMPAD3
    #define CLI_EVK_NUMPAD3                   CONSTANT_UINT(0x63)
#endif /* CLI_EVK_NUMPAD3 */

#ifndef CLI_EVK_NUMPAD4
    #define CLI_EVK_NUMPAD4                   CONSTANT_UINT(0x64)
#endif /* CLI_EVK_NUMPAD4 */

#ifndef CLI_EVK_NUMPAD5
    #define CLI_EVK_NUMPAD5                   CONSTANT_UINT(0x65)
#endif /* CLI_EVK_NUMPAD5 */

#ifndef CLI_EVK_NUMPAD6
    #define CLI_EVK_NUMPAD6                   CONSTANT_UINT(0x66)
#endif /* CLI_EVK_NUMPAD6 */

#ifndef CLI_EVK_NUMPAD7
    #define CLI_EVK_NUMPAD7                   CONSTANT_UINT(0x67)
#endif /* CLI_EVK_NUMPAD7 */

#ifndef CLI_EVK_NUMPAD8
    #define CLI_EVK_NUMPAD8                   CONSTANT_UINT(0x68)
#endif /* CLI_EVK_NUMPAD8 */

#ifndef CLI_EVK_NUMPAD9
    #define CLI_EVK_NUMPAD9                   CONSTANT_UINT(0x69)
#endif /* CLI_EVK_NUMPAD9 */

#ifndef CLI_EVK_NUMPADMULTIPLY
    #define CLI_EVK_NUMPADMULTIPLY            CONSTANT_UINT(0x6A)
#endif /* CLI_EVK_NUMPADMULTIPLY */

#ifndef CLI_EVK_MULTIPLY
    #define CLI_EVK_MULTIPLY                  CONSTANT_UINT(0x6A)
#endif /* CLI_EVK_MULTIPLY */

#ifndef CLI_EVK_NUMPADADD
    #define CLI_EVK_NUMPADADD                 CONSTANT_UINT(0x6B)
#endif /* CLI_EVK_NUMPADADD */

#ifndef CLI_EVK_ADD
    #define CLI_EVK_ADD                       CONSTANT_UINT(0x6B)
#endif /* CLI_EVK_ADD */

#ifndef CLI_EVK_NUMPADSUBTRACT
    #define CLI_EVK_NUMPADSUBTRACT            CONSTANT_UINT(0x6D)
#endif /* CLI_EVK_NUMPADSUBTRACT */

#ifndef CLI_EVK_SUBTRACT
    #define CLI_EVK_SUBTRACT                  CONSTANT_UINT(0x6D)
#endif /* CLI_EVK_SUBTRACT */

#ifndef CLI_EVK_NUMPADDECIMAL
    #define CLI_EVK_NUMPADDECIMAL             CONSTANT_UINT(0x6E)
#endif /* CLI_EVK_NUMPADDECIMAL */

#ifndef CLI_EVK_DECIMAL
    #define CLI_EVK_DECIMAL                   CONSTANT_UINT(0x6E)
#endif /* CLI_EVK_DECIMAL */

#ifndef CLI_EVK_NUMPADDIVIDE
    #define CLI_EVK_NUMPADDIVIDE              CONSTANT_UINT(0x6F)
#endif /* CLI_EVK_NUMPADDIVIDE */

#ifndef CLI_EVK_DIVIDE
    #define CLI_EVK_DIVIDE                    CONSTANT_UINT(0x6F)
#endif /* CLI_EVK_DIVIDE */

#ifndef CLI_EVK_SEPARATOR
    #define CLI_EVK_SEPARATOR                 CONSTANT_UINT(0x6C)
#endif /* CLI_EVK_SEPARATOR */

#ifndef CLI_EVK_BACKSLASH
    #define CLI_EVK_BACKSLASH                 CONSTANT_UINT(0x6C)
#endif /* CLI_EVK_BACKSLASH */

#ifndef CLI_EVK_F1
    #define CLI_EVK_F1                        CONSTANT_UINT(0x70)
#endif /* CLI_EVK_F1 */

#ifndef CLI_EVK_F2
    #define CLI_EVK_F2                        CONSTANT_UINT(0x71)
#endif /* CLI_EVK_F2 */

#ifndef CLI_EVK_F3
    #define CLI_EVK_F3                        CONSTANT_UINT(0x72)
#endif /* CLI_EVK_F3 */

#ifndef CLI_EVK_F4
    #define CLI_EVK_F4                        CONSTANT_UINT(0x73)
#endif /* CLI_EVK_F4 */

#ifndef CLI_EVK_F5
    #define CLI_EVK_F5                        CONSTANT_UINT(0x74)
#endif /* CLI_EVK_F5 */

#ifndef CLI_EVK_F6
    #define CLI_EVK_F6                        CONSTANT_UINT(0x75)
#endif /* CLI_EVK_F6 */

#ifndef CLI_EVK_F7
    #define CLI_EVK_F7                        CONSTANT_UINT(0x76)
#endif /* CLI_EVK_F7 */

#ifndef CLI_EVK_F8
    #define CLI_EVK_F8                        CONSTANT_UINT(0x77)
#endif /* CLI_EVK_F8 */

#ifndef CLI_EVK_F9
    #define CLI_EVK_F9                        CONSTANT_UINT(0x78)
#endif /* CLI_EVK_F9 */

#ifndef CLI_EVK_F10
    #define CLI_EVK_F10                       CONSTANT_UINT(0x79)
#endif /* CLI_EVK_F10 */

#ifndef CLI_EVK_F11
    #define CLI_EVK_F11                       CONSTANT_UINT(0x7A)
#endif /* CLI_EVK_F11 */

#ifndef CLI_EVK_F12
    #define CLI_EVK_F12                       CONSTANT_UINT(0x7B)
#endif /* CLI_EVK_F12 */

#ifndef CLI_EVK_F13
    #define CLI_EVK_F13                       CONSTANT_UINT(0x7C)
#endif /* CLI_EVK_F13 */

#ifndef CLI_EVK_F14
    #define CLI_EVK_F14                       CONSTANT_UINT(0x7D)
#endif /* CLI_EVK_F14 */

#ifndef CLI_EVK_F15
    #define CLI_EVK_F15                       CONSTANT_UINT(0x7E)
#endif /* CLI_EVK_F15 */

#ifndef CLI_EVK_F16
    #define CLI_EVK_F16                       CONSTANT_UINT(0x7F)
#endif /* CLI_EVK_F16 */

#ifndef CLI_EVK_F17
    #define CLI_EVK_F17                       CONSTANT_UINT(0x80)
#endif /* CLI_EVK_F17 */

#ifndef CLI_EVK_F18
    #define CLI_EVK_F18                       CONSTANT_UINT(0x81)
#endif /* CLI_EVK_F18 */

#ifndef CLI_EVK_F19
    #define CLI_EVK_F19                       CONSTANT_UINT(0x82)
#endif /* CLI_EVK_F19 */

#ifndef CLI_EVK_F20
    #define CLI_EVK_F20                       CONSTANT_UINT(0x83)
#endif /* CLI_EVK_F20 */

#ifndef CLI_EVK_F21
    #define CLI_EVK_F21                       CONSTANT_UINT(0x84)
#endif /* CLI_EVK_F21 */

#ifndef CLI_EVK_F22
    #define CLI_EVK_F22                       CONSTANT_UINT(0x85)
#endif /* CLI_EVK_F22 */

#ifndef CLI_EVK_F23
    #define CLI_EVK_F23                       CONSTANT_UINT(0x86)
#endif /* CLI_EVK_F23 */

#ifndef CLI_EVK_F24
    #define CLI_EVK_F24                       CONSTANT_UINT(0x87)
#endif /* CLI_EVK_F24 */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EVK {
                const UINT back             = CONSTANT_UINT(0x08);
                const UINT tab              = CONSTANT_UINT(0x09);
                const UINT ret              = CONSTANT_UINT(0x0D);
                const UINT pause            = CONSTANT_UINT(0x13);
                const UINT capital          = CONSTANT_UINT(0x14);
                const UINT escape           = CONSTANT_UINT(0x1B);
                const UINT space            = CONSTANT_UINT(0x20);
                const UINT numlock          = CONSTANT_UINT(0x90);
                const UINT scroll           = CONSTANT_UINT(0x91);
                const UINT next             = CONSTANT_UINT(0x22);
                const UINT prior            = CONSTANT_UINT(0x21);
                const UINT end              = CONSTANT_UINT(0x23);
                const UINT home             = CONSTANT_UINT(0x24);
                const UINT left             = CONSTANT_UINT(0x25);
                const UINT up               = CONSTANT_UINT(0x26);
                const UINT down             = CONSTANT_UINT(0x28);
                const UINT right            = CONSTANT_UINT(0x27);
                const UINT sleep            = CONSTANT_UINT(0x5F);
                const UINT snapshot         = CONSTANT_UINT(0x2C);
                const UINT printScreen      = CONSTANT_UINT(0x2C);
                const UINT ins              = CONSTANT_UINT(0x2D);
                const UINT del              = CONSTANT_UINT(0x2E);
                const UINT lwin             = CONSTANT_UINT(0x5B);
                const UINT rwin             = CONSTANT_UINT(0x5C);
                const UINT numpad0          = CONSTANT_UINT(0x60);
                const UINT numpad1          = CONSTANT_UINT(0x61);
                const UINT numpad2          = CONSTANT_UINT(0x62);
                const UINT numpad3          = CONSTANT_UINT(0x63);
                const UINT numpad4          = CONSTANT_UINT(0x64);
                const UINT numpad5          = CONSTANT_UINT(0x65);
                const UINT numpad6          = CONSTANT_UINT(0x66);
                const UINT numpad7          = CONSTANT_UINT(0x67);
                const UINT numpad8          = CONSTANT_UINT(0x68);
                const UINT numpad9          = CONSTANT_UINT(0x69);
                const UINT numpadMultiply   = CONSTANT_UINT(0x6A);
                const UINT multiply         = CONSTANT_UINT(0x6A);
                const UINT numpadAdd        = CONSTANT_UINT(0x6B);
                const UINT add              = CONSTANT_UINT(0x6B);
                const UINT numpadSubtract   = CONSTANT_UINT(0x6D);
                const UINT subtract         = CONSTANT_UINT(0x6D);
                const UINT numpadDecimal    = CONSTANT_UINT(0x6E);
                const UINT decimal          = CONSTANT_UINT(0x6E);
                const UINT numpadDivide     = CONSTANT_UINT(0x6F);
                const UINT divide           = CONSTANT_UINT(0x6F);
                const UINT separator        = CONSTANT_UINT(0x6C);
                const UINT backSlash        = CONSTANT_UINT(0x6C);
                const UINT f1               = CONSTANT_UINT(0x70);
                const UINT f2               = CONSTANT_UINT(0x71);
                const UINT f3               = CONSTANT_UINT(0x72);
                const UINT f4               = CONSTANT_UINT(0x73);
                const UINT f5               = CONSTANT_UINT(0x74);
                const UINT f6               = CONSTANT_UINT(0x75);
                const UINT f7               = CONSTANT_UINT(0x76);
                const UINT f8               = CONSTANT_UINT(0x77);
                const UINT f9               = CONSTANT_UINT(0x78);
                const UINT f10              = CONSTANT_UINT(0x79);
                const UINT f11              = CONSTANT_UINT(0x7A);
                const UINT f12              = CONSTANT_UINT(0x7B);
                const UINT f13              = CONSTANT_UINT(0x7C);
                const UINT f14              = CONSTANT_UINT(0x7D);
                const UINT f15              = CONSTANT_UINT(0x7E);
                const UINT f16              = CONSTANT_UINT(0x7F);
                const UINT f17              = CONSTANT_UINT(0x80);
                const UINT f18              = CONSTANT_UINT(0x81);
                const UINT f19              = CONSTANT_UINT(0x82);
                const UINT f20              = CONSTANT_UINT(0x83);
                const UINT f21              = CONSTANT_UINT(0x84);
                const UINT f22              = CONSTANT_UINT(0x85);
                const UINT f23              = CONSTANT_UINT(0x86);
                const UINT f24              = CONSTANT_UINT(0x87);
        }; // namespace EVK
    }; // namespace cli
    /* using namespace ::cli::EVK; */
    
#endif




#endif /* CLI_GUI_VK_H */
