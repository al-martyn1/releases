#ifndef CLI_GUI_ICELLIMPL_H
#define CLI_GUI_ICELLIMPL_H

#ifndef CLI_GUI_CELLGRID_H
    #include <cli/gui/cellgrid.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_GUI_CELLGRIDHLP_H
    #include <cli/gui/cellgridhlp.h>
#endif


namespace cli
{
namespace gui
{
namespace cellgrid
{


class CCellImplBase : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_GUI_CELLGRID_ICELL
{

public:
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CLI_BEGIN_INTERFACE_MAP2(CCellImplBase, INTERFACE_CLI_GUI_CELLGRID_ICELL)
    //CLI_BEGIN_INTERFACE_MAP(CCellImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_ICELL )
    CLI_END_INTERFACE_MAP(CCellImplBase)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    // define 'destroy' in descendants
    //void destroy() { delete this; }

protected:

    SIZE_T activeCellRow ; // idx1
    SIZE_T activeCellCell; // idx2

    bool   hotTracked;

    // if iCell used for multiple cells, this autoHotTrack variable used for all of it.
    ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK   autoHotTrack;

    // use this method to detect that cell is on hot track focus
    bool isActiveCell( const SIZE_T &idx1 /* row */, const SIZE_T &idx2 /* col */ )
       {
        if (activeCellRow==idx1 && activeCellCell==idx2) return true;
        return false;
       }

    INTERFACE_CLI_GUI_CELLGRID_IROW*    ownerRow;

    STRUCT_CLI_GUI_CELLGRID_CSPACING    selfSpacing;
    bool                                selfSpacingUsed;

    BOOL                                drawBackground;
    COLORREF                            backgroundColor;
    COLORREF                            activeBackgroundColor;

    BOOL                                visible;



/*
    STRUCT_CLI_DRAWING_CPOINT           size;
    STRUCT_CLI_DRAWING_CPOINT           minSize;
    STRUCT_CLI_DRAWING_CPOINT           maxSize;
    INTERFACE_CLI_GUI_CELLGRID_IROW*    ownerRow;
*/

public:

    CCellImplBase()
       : base_impl(DEF_MODULE)
       , INTERFACE_CLI_GUI_CELLGRID_ICELL()
       , activeCellRow(SIZE_T_NPOS)
       , activeCellCell(SIZE_T_NPOS)
       , hotTracked(true)
       , autoHotTrack(CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKNONE)
       , ownerRow(0)
       , selfSpacing( makeSpacing(0, 0, 0, 0) )
       , selfSpacingUsed(false)
       , drawBackground(TRUE)
       , backgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , activeBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , visible(TRUE)
       {}


    CLIMETHOD(visibleGet) (THIS_ BOOL*    _visible /* [out] bool visible  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
        {
         if (_visible) *_visible = visible;
         return EC_OK;
        }

    CLIMETHOD(visibleSet) (THIS_ BOOL    _visible /* [in] bool  visible  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
        {
         BOOL oldVisible = visible;
         visible = _visible ? TRUE : FALSE;
         if (oldVisible!=visible && ownerRow) ownerRow->cellSizeChangedNotify(idx1, idx2, TRUE);
         return EC_OK;
        }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(visibleSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }
    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(visibleSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       { if (size) *size = 0; return EC_OK; }


    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* ownerGrid  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                            )
       {
        if (!ownerRow) return EC_NO_OBJECT;
        return ownerRow->ownerGridGet(ownerGrid, idx1);
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(ownerGridSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(ownerGridSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
       { if (size) *size = 0; return EC_OK; }

/*
     INTERFACE_CLI_GUI_CELLGRID_IGRID* implGetOwnerGrid()
        {
         if (!ownerRow) return 0;
        }
*/


    ~CCellImplBase()
       {
       }

    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool drawBackground  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
        {
        if (!_drawBackground) return EC_INVALID_PARAM;
        *_drawBackground = drawBackground ? TRUE : FALSE;
        return EC_OK;
        }

    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  drawBackground  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
        {
         drawBackground = _drawBackground;
        return EC_OK;
        }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(drawBackgroundSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(drawBackgroundSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   )
       { if (size) *size = 0; return EC_OK; }

    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref backgroundColor  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  )
       {
        if (!_backgroundColor) return EC_INVALID_PARAM;
        if (backgroundColor!=CLI_DRAWING_ECOLORREF_CONST_UNDEFINED || !ownerRow)
           {
            *_backgroundColor = backgroundColor;
            return EC_OK;
           }
        return ownerRow->cellBackgroundColorGet( _backgroundColor, idx1 );
       }

    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  backgroundColor  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  )
       {
        backgroundColor = _backgroundColor;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(backgroundColorSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(backgroundColorSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    )
       { if (size) *size = 0; return EC_OK; }

    CLIMETHOD(activeBackgroundColorGet) (THIS_ COLORREF*    _activeBackgroundColor /* [out] colorref activeBackgroundColor  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
       {
        if (!_activeBackgroundColor) return EC_INVALID_PARAM;
        if (activeBackgroundColor!=CLI_DRAWING_ECOLORREF_CONST_UNDEFINED || !ownerRow)
           {
            *_activeBackgroundColor = activeBackgroundColor;
            return EC_OK;
           }
        return ownerRow->activeCellBackgroundColorGet( _activeBackgroundColor, idx1 );
       }

    CLIMETHOD(activeBackgroundColorSet) (THIS_ COLORREF    _activeBackgroundColor /* [in] colorref  activeBackgroundColor  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
       {
        activeBackgroundColor = _activeBackgroundColor;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(activeBackgroundColorSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(activeBackgroundColorSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
       { if (size) *size = 0; return EC_OK; }

    // activeCell property methods

    CLIMETHOD(activeCellGet) (THIS_ BOOL*    activeCell /* [out] bool activeCell  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       {
        if (!activeCell) return EC_INVALID_PARAM;
        *activeCell = isActiveCell(idx1,idx2) ? TRUE : FALSE;
        return EC_OK;
       }

    CLIMETHOD(activeCellSet) (THIS_ BOOL    activeCell /* [in] bool  activeCell  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       {
        if (activeCell==FALSE)
           { // hot tracked flag cleared by owner
            // if manager don't check destination cell (that gets activeCell on) for 
            // hot tracking support, it clears prev activeCell, and we can't prevent this
            // (we don't know new cell, ant can't check it's hotTracked property)
            // but we can prevent to activate non-hottracking cell (see below)
            activeCellRow  = SIZE_T_NPOS;
            activeCellCell = SIZE_T_NPOS;
           }
        else // set hot tracked row/col to taken indeces
           {
            // setting of activeCell will fail, if cell does not support hot tracking
            // Hot tracking controled by hotTracked property, which is accessible by hotTrackedGet method.
            // hotTrackedGet method default realisation uses hotTracked impl class member, 
            // but can be overriden in 
            BOOL bHotTracked = FALSE;
            hotTrackedGet( &bHotTracked, idx1, idx2 );
            if (bHotTracked)
               { // hot tracking allowed by this cell
                activeCellRow  = idx1;
                activeCellCell = idx2;
               }
            else
               { // hot tracking not allowed by this cell, prevent to activate (clear activeCell)
                activeCellRow  = SIZE_T_NPOS;
                activeCellCell = SIZE_T_NPOS;
               }
           }
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(activeCellSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(activeCellSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
       { if (size) *size = 0; return EC_OK; }



    // hotTracked property methods
    CLIMETHOD(hotTrackedGet) (THIS_ BOOL*    _hotTracked /* [out] bool hotTracked  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       {
        if (!_hotTracked) return EC_INVALID_PARAM;
        *_hotTracked = hotTracked ? TRUE : FALSE;
        return EC_OK;
       }

    CLIMETHOD(hotTrackedSet) (THIS_ BOOL    _hotTracked /* [in] bool  hotTracked  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       {
        hotTracked = _hotTracked ? true : false;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(hotTrackedSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(hotTrackedSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
       { if (size) *size = 0; return EC_OK; }


    // autoHotTrack property

    CLIMETHOD(autoHotTrackGet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack autoHotTrack  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       {
        if (!_autoHotTrack) return EC_INVALID_PARAM;
        *_autoHotTrack = autoHotTrack;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(autoHotTrackSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(autoHotTrackSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
       { if (size) *size = 0; return EC_OK; }


    // ownerRow property

    CLIMETHOD(ownerRowGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* ownerRow  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       {
        if (!_ownerRow) return EC_INVALID_PARAM;
        *_ownerRow = ownerRow;
        return EC_OK;
       }

    CLIMETHOD(ownerRowSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  ownerRow  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       {
        ownerRow = _ownerRow;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(ownerRowSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(ownerRowSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                             )
       { if (size) *size = 0; return EC_OK; }


    // spacing property

    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [out] ::cli::gui::cellgrid::CSpacing spacing  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       {
        if (!_spacing) return EC_INVALID_PARAM;
        if (selfSpacingUsed || !ownerRow)
           {
            // self spacing used for all cell not depending on indeces
            // this behavior can be overriden by new implementation of spacingGet in childs
            *_spacing = selfSpacing; 
            return EC_OK;
           }

        return ownerRow->cellSpacingGet( _spacing );
       }

    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  spacing  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       {
        if (!_spacing) return EC_INVALID_PARAM;
        // indeces ignored
        selfSpacing = *_spacing;
        selfSpacingUsed = true;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(spacingSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { if (size) *size = 0; return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(spacingSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       { if (size) *size = 0; return EC_OK; }

    CLIMETHOD(resetSpacing) (THIS_ SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                            )
       {
        selfSpacingUsed = false;
        return EC_OK;
       }

    // Override in childs
    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                            )
       { return EC_OK; }

    // Need to be overriden in childs
    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    // Override in childs
    // by default, no non-client painting provided
    // override this method if custom frame needed to be drawn
    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                       )
       { return EC_OK; }

    // Override in childs
    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       { return EC_OK; }

    // Need to be overriden in childs
    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    size /* [out] ::cli::drawing::CPoint size  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                       )
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    // Need to be overriden in childs
    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    size /* [in,ref] ::cli::drawing::CPoint  size  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                       )
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(sizeSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(sizeSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                         )
       { return EC_OK; }

    // Need to be overriden in childs
    CLIMETHOD(minSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(minSizeSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(minSizeSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       { return EC_OK; }

    // Need to be overriden in childs
    CLIMETHOD(maxSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(maxSizeSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(maxSizeSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       { return EC_OK; }

    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint minSize  */
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              , SIZE_T    idx2 /* [in] size_t  idx2  */
                         )
       {
        RCODE res = minSizeGet(minSize, idx1, idx2);
        if (res) return res;
        return maxSizeGet(maxSize, idx1, idx2);
       }

    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                           )
       {
        return EC_OK;
       }

    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                 , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                 , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                            )
       {
        return EC_OK;
       }




}; // class CCellImpl



}; // namespace cellgrid
}; // namespace gui
}; // namespace cli



#endif /* CLI_GUI_ICELLIMPL_H */

