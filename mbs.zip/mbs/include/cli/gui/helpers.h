#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_HELPERS_H
#define CLI_GUI_HELPERS_H

/* add this lines to your scr
#ifndef CLI_GUI_HELPERS_H
    #include <cli/gui/helpers.h>
#endif
*/


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif



#ifndef CLI_GUI_IMENUBUILDER_H
    #include <cli/gui/iMenuBuilder.h>
#endif

#include <marty/concvt.h>

namespace cli
{
namespace gui
{

inline
void makeAccelString( const cli::gui::CAccel &accel, ::std::wstring &strTo )
   {
    using namespace ::cli::gui::EAccelFlags;
    // Ctrl+Alt+Shift+'X'
    std::wstring &res = strTo;
    if (accel.flags&fControl) res = L"Ctrl";
    if (accel.flags&fAlt)
       {
        if (!res.empty()) res.append(1, L'+');
        res.append(L"Alt");
       }
    if (accel.flags&fShift)
       {
        if (!res.empty()) res.append(1, L'+');
        res.append(L"Shift");
       }
    if (!res.empty()) res.append(1, L'+');

    //#ifdef VK_BACK
    switch(accel.key)
       {
        case CLI_EVK_BACK   :  res.append(L"Backspace"); break;     case CLI_EVK_TAB    :  res.append(L"Tab"); break;
        //case CLI_EVK_CLEAR:  res.append(L"Unknown"); break;
        case CLI_EVK_RET :  res.append(L"Enter"); break;         case CLI_EVK_PAUSE  :  res.append(L"Pause"); break;
        case CLI_EVK_CAPITAL:  res.append(L"Caps Lock"); break;     case CLI_EVK_ESCAPE :  res.append(L"Esc"); break;
        case CLI_EVK_SPACE  :  res.append(L"Space"); break;         case CLI_EVK_NUMLOCK:  res.append(L"Numlock"); break;
        case CLI_EVK_SCROLL :  res.append(L"Scroll Lock"); break;   case CLI_EVK_NEXT   :  res.append(L"Page Down"); break;
        case CLI_EVK_PRIOR  :  res.append(L"Page Up"); break;       case CLI_EVK_END    :  res.append(L"End"); break;
        case CLI_EVK_HOME   :  res.append(L"Home"); break;          case CLI_EVK_LEFT   :  res.append(L"Left"); break;
        case CLI_EVK_UP     :  res.append(L"Up"); break;            case CLI_EVK_RIGHT  :  res.append(L"Right"); break;
        case CLI_EVK_DOWN   :  res.append(L"Down"); break;

        case CLI_EVK_SLEEP :  res.append(L"Sleep"); break;
        //case CLI_EVK_SELECT :  res.append(L""); break;
        //case CLI_EVK_PRINT  :  res.append(L""); break;
        //case CLI_EVK_EXECUTE:  res.append(L""); break;
        case CLI_EVK_SNAPSHOT:  res.append(L"Print Screen"); break; case CLI_EVK_INS  :  res.append(L"Ins"); break;
        case CLI_EVK_DEL     :  res.append(L"Del"); break;
        //case CLI_EVK_HELP    :  res.append(L""); break;
        case CLI_EVK_LWIN    :  res.append(L"Left Win"); break;     case CLI_EVK_RWIN    :  res.append(L"Right Win"); break;
        //case CLI_EVK_APPS    :  res.append(L""); break;
        case CLI_EVK_NUMPAD0:  res.append(L"Numpad 0"); break;      case CLI_EVK_NUMPAD1:  res.append(L"Numpad 1"); break;
        case CLI_EVK_NUMPAD2:  res.append(L"Numpad 2"); break;      case CLI_EVK_NUMPAD3:  res.append(L"Numpad 3"); break;
        case CLI_EVK_NUMPAD4:  res.append(L"Numpad 4"); break;      case CLI_EVK_NUMPAD5:  res.append(L"Numpad 5"); break;
        case CLI_EVK_NUMPAD6:  res.append(L"Numpad 6"); break;      case CLI_EVK_NUMPAD7:  res.append(L"Numpad 7"); break;
        case CLI_EVK_NUMPAD8:  res.append(L"Numpad 8"); break;      case CLI_EVK_NUMPAD9:  res.append(L"Numpad 9"); break;
        case CLI_EVK_MULTIPLY :  res.append(L"Numpad *"); break;    case CLI_EVK_ADD      :  res.append(L"Numpad +"); break;
        case CLI_EVK_SUBTRACT :  res.append(L"Numpad -"); break;    case CLI_EVK_DECIMAL  :  res.append(L"Numpad ."); break;
        case CLI_EVK_DIVIDE   :  res.append(L"Numpad /"); break;
        case CLI_EVK_SEPARATOR:  res.append(L"\\"); break;

        case CLI_EVK_F1 : res.append(L"F1"); break;  case CLI_EVK_F2 : res.append(L"F2"); break;  case CLI_EVK_F3 : res.append(L"F3"); break;
        case CLI_EVK_F4 : res.append(L"F4"); break;  case CLI_EVK_F5 : res.append(L"F5"); break;  case CLI_EVK_F6 : res.append(L"F6"); break;
        case CLI_EVK_F7 : res.append(L"F7"); break;  case CLI_EVK_F8 : res.append(L"F8"); break;  case CLI_EVK_F9 : res.append(L"F9"); break;
        case CLI_EVK_F10: res.append(L"F10"); break; case CLI_EVK_F11: res.append(L"F11"); break; case CLI_EVK_F12: res.append(L"F12"); break;
        case CLI_EVK_F13: res.append(L"F13"); break; case CLI_EVK_F14: res.append(L"F14"); break; case CLI_EVK_F15: res.append(L"F15"); break;
        case CLI_EVK_F16: res.append(L"F16"); break; case CLI_EVK_F17: res.append(L"F17"); break; case CLI_EVK_F18: res.append(L"F18"); break;
        case CLI_EVK_F19: res.append(L"F19"); break; case CLI_EVK_F20: res.append(L"F20"); break; case CLI_EVK_F21: res.append(L"F21"); break;
        case CLI_EVK_F22: res.append(L"F22"); break; case CLI_EVK_F23: res.append(L"F23"); break; case CLI_EVK_F24: res.append(L"F24"); break;

        //case    :  res.append(L""); break;

        default: res.append(1, (WCHAR)accel.key); break;
       }
        /*
        #if(_WIN32_WINNT >= 0x0500)
        #define VK_BROWSER_BACK        0xA6
        #define VK_BROWSER_FORWARD     0xA7
        #define VK_BROWSER_REFRESH     0xA8
        #define VK_BROWSER_STOP        0xA9
        #define VK_BROWSER_SEARCH      0xAA
        #define VK_BROWSER_FAVORITES   0xAB
        #define VK_BROWSER_HOME        0xAC
        
        #define VK_VOLUME_MUTE         0xAD
        #define VK_VOLUME_DOWN         0xAE
        #define VK_VOLUME_UP           0xAF
        #define VK_MEDIA_NEXT_TRACK    0xB0
        #define VK_MEDIA_PREV_TRACK    0xB1
        #define VK_MEDIA_STOP          0xB2
        #define VK_MEDIA_PLAY_PAUSE    0xB3
        #define VK_LAUNCH_MAIL         0xB4
        #define VK_LAUNCH_MEDIA_SELECT 0xB5
        #define VK_LAUNCH_APP1         0xB6
        #define VK_LAUNCH_APP2         0xB7
        
        #endif
        */
   }


namespace helpers
{




inline
void makeAccelString( const cli::gui::CAccel &acc, ::std::string &strTo )
   {
    ::std::wstring tmp;
    makeAccelString(acc,tmp);
    strTo = MARTY_CON::strToAnsi(tmp);
   }

inline
void getCategoryName( INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder, SIZE_T categoryAtom, ::std::wstring &strTo )
   {
    wchar_t categoryNameBuf[1024];
    if ( pBuilder->getCommandCategoryName( categoryAtom, categoryNameBuf, sizeof(categoryNameBuf)/sizeof(categoryNameBuf[0]) ))
       strTo.clear();
    else
       strTo.assign(categoryNameBuf);   
   }

inline
void getCategoryName( INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder, SIZE_T categoryAtom, ::std::string &strTo )
   {
    ::std::wstring tmp;
    getCategoryName( pBuilder, categoryAtom, tmp );
    strTo = MARTY_CON::strToAnsi(tmp);   
   }

inline
void getMenuItemName( INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder, SIZE_T itemId, ::std::wstring &strTo)
   {
    wchar_t itemNameBuf[1024];
    if (pBuilder->getItemNameById( itemId, itemNameBuf, sizeof(itemNameBuf)/sizeof(itemNameBuf[0]) ))
       strTo.clear();
    else
       strTo.assign(itemNameBuf);   
   }

inline
void getMenuItemName( INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder, SIZE_T itemId, ::std::string &strTo)
   {
    ::std::wstring tmp;
    getMenuItemName( pBuilder, itemId, tmp );
    strTo = MARTY_CON::strToAnsi(tmp);   
   }

inline
void getMenuItemText( INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder, SIZE_T itemId, ::std::wstring &strTo)
   {
    wchar_t itemNameBuf[1024];
    if (pBuilder->getItemTextById( itemId, itemNameBuf, sizeof(itemNameBuf)/sizeof(itemNameBuf[0]) ))
       strTo.clear();
    else
       strTo.assign(itemNameBuf);   
   }

inline
void getMenuItemText( INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder, SIZE_T itemId, ::std::string &strTo)
   {
    ::std::wstring tmp;
    getMenuItemText( pBuilder, itemId, tmp );
    strTo = MARTY_CON::strToAnsi(tmp);   
   }

inline
void getMenuItemInfoText( INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder, SIZE_T itemId, ::std::wstring &strTo)
   {
    wchar_t itemNameBuf[1024];
    if (pBuilder->getItemInfoTextById( itemId, itemNameBuf, sizeof(itemNameBuf)/sizeof(itemNameBuf[0]) ))
       strTo.clear();
    else
       strTo.assign(itemNameBuf);   
   }

inline
void getMenuItemInfoText( INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder, SIZE_T itemId, ::std::string &strTo)
   {
    ::std::wstring tmp;
    getMenuItemInfoText( pBuilder, itemId, tmp );
    strTo = MARTY_CON::strToAnsi(tmp);   
   }

inline
::std::wstring removeAmp( const ::std::wstring &str )
   {
    // simple version, double amp removed also
    ::std::wstring res;
    res.reserve(str.size());
    ::std::wstring::const_iterator it = str.begin();
    for(; it != str.end(); ++it) 
       {
        if (*it=='&') continue;
        res.append(1,*it);
       }
    return res;
   }

inline
::std::string removeAmp( const ::std::string &str )
   {
    // simple version, double amp removed also
    ::std::string res;
    res.reserve(str.size());
    ::std::string::const_iterator it = str.begin();
    for(; it != str.end(); ++it) 
       {
        if (*it==L'&') continue;
        res.append(1,*it);
       }
    return res;
   }


/*
handler
startDocument
endDocument
startMenu // bool res, if false no menu processing
endMenu
startItem
endItem
*/

template <typename THandler>
void describeMenuHelper( const THandler &handler
                  , INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder
                  , bool bRecurse
                  , std::vector< ::std::wstring > &menusQue
                  , const ::std::wstring &menuName
                  )
   {
    //std::vector< ::std::wstring > menusQue;
    if (menuName.empty()) return;
    SIZE_T menuId = SIZE_T_NPOS;
    if (pBuilder->getMenuId( menuName.c_str(), &menuId))
       return; // can't get id for taken menu name

    ::std::wstring menuText, menuInfo;
    getMenuItemText( pBuilder, menuId, menuText);
    getMenuItemInfoText( pBuilder, menuId, menuInfo);

    if (!handler.startMenu( menuId, menuName, menuText, menuInfo )) return;

    SIZE_T itemIndex = 0;
    STRUCT_CLI_GUI_CMENUITEMINFO itemInfo;
    /*
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                SIZE_T                      itemId;
                ENUM_CLI_GUI_EMENUITEMFLAGS             itemFlags;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
    */
    while( EC_OK==pBuilder->enumMenuByIdItems(menuId, itemIndex++, &itemInfo) )
       {
        if (itemInfo.itemFlags&(CLI_GUI_EMENUITEMFLAGS_FQUET|CLI_GUI_EMENUITEMFLAGS_FMENUSEPARATOR|CLI_GUI_EMENUITEMFLAGS_FMENUBREAK|CLI_GUI_EMENUITEMFLAGS_FMENUBARBREAK))
           continue;

        if (itemInfo.itemFlags&CLI_GUI_EMENUITEMFLAGS_FSUBMENU)
           { // this is a submenu
            if (bRecurse)
               {
                ::std::wstring submenuName;
                getMenuItemName( pBuilder, itemInfo.itemId, submenuName);
                if (!submenuName.empty()) menusQue.push_back(submenuName);
               }
            //continue;
           }
        // this is an item
        ::std::wstring itemName, itemText, itemInfoText;
        getMenuItemName( pBuilder, itemInfo.itemId, itemName);
        getMenuItemText( pBuilder, itemInfo.itemId, itemText);
        getMenuItemInfoText( pBuilder, itemInfo.itemId, itemInfoText);

        handler.startItem( itemInfo.itemFlags, itemInfo.itemId, itemName, itemText, itemInfoText );
        handler.endItem();
       }
    handler.endMenu();
   }


template <typename THandler>
void describeMenus( const THandler &handler
                  , INTERFACE_CLI_GUI_IMENUBUILDER *pBuilder
                  , const ::std::wstring &docTitle
                  , const ::std::wstring &docId // optional id for all document
                  , bool bRecurse
                  , const std::vector< ::std::wstring > &menus
                  )
   {
    handler.startDocument( docId, docTitle );
    std::vector< ::std::wstring > menusQue;
    menusQue.insert(menusQue.end(), menus.begin(), menus.end());

    SIZE_T curMenuIndex = 0;
    for(; curMenuIndex!=menusQue.size(); ++curMenuIndex)
       {
        describeMenuHelper( handler, pBuilder, bRecurse, menusQue, menusQue[curMenuIndex]);
       }

    handler.endDocument( );
   }



template <typename TEncoder>
struct CMenuDescriberBase
{
    ::std::map< ::std::string, ::std::wstring >  optionalTexts;
    ::std::string                           encodingName;
    TEncoder                                encoder;
    mutable ::std::set< ::std::wstring >    describedMenus;
    //::std::wstring                          strMenu;
    //::std::wstring                          strSubmenu;

    mutable ::std::string                   &text;

    CMenuDescriberBase( const TEncoder &enc, const ::std::string &encName, const ::std::map< ::std::string, ::std::wstring > &ot, ::std::string &t)
       : encodingName(encName), encoder(enc), describedMenus(), optionalTexts(ot), text(t)
       {}


    ::std::wstring getOptText( const ::std::string &strId, const ::std::wstring &defStr ) const
       {
        ::std::map< ::std::string, ::std::wstring >::const_iterator it = optionalTexts.find(strId);
        if (it == optionalTexts.end()) return defStr;
        return it->second;
       }

    bool checkUpdateUsed( const ::std::wstring &menuName ) const
       {
        bool res = describedMenus.find(menuName)==describedMenus.end();
        describedMenus.insert(menuName);
        return res;
       }

    static 
    bool emptyStringOrEndsWithDot( const std::wstring &str)
       {
        if (str.empty()) return true;
        if (str[str.size()-1]==L'.') return true;
        return false;
       }

    //inline
    static
    ::std::string xmlEscape( const ::std::string &str )
       {
        ::std::string res;
        res.reserve(str.size());
        ::std::string::const_iterator it = str.begin();
        for(; it != str.end(); ++it) 
           {
            switch(*it)
               {
                case '&': res.append("&amp;"); break;
                case '<': res.append("&lt;"); break;
                case '>': res.append("&gt;"); break;
                case '\'': res.append("&apos;"); break;
                case '\"': res.append("&quot;"); break;
                //case '': res.append(""); break;
                default: res.append(1,*it);
               }
           }
        return res;
       }

};


/*
template <typename TEncoder>
struct CMenuDescriberTemplate : public CMenuDescriberBase<TEncoder>
{

    typedef CMenuDescriberBase<TEncoder> base_describer;

    CMenuDescriberTemplate( const TEncoder &enc, const ::std::string &encName, const ::std::map< ::std::string, ::std::wstring > &ot, ::std::string &t)
       : base_describer( enc, encName, ot, t )
       {}

    // implement in custom describer
    void startDocument( const ::std::wstring &docId, const ::std::wstring &docTitle) const
       {

       }

    void endDocument() const
       {

       }

    bool startMenu( SIZE_T menuId, const ::std::wstring &menuName, const ::std::wstring &menuText, const ::std::wstring &menuInfo ) const
       {
        if (!this->checkUpdateUsed( menuName )) return false;

       }

    void endMenu() const
       {

       }

    void startItem( DWORD flags, SIZE_T itemId, const ::std::wstring &itemName, const ::std::wstring &itemText, const ::std::wstring &itemInfo ) const
       {

       }

    void endItem() const
       {

       }
};
*/



struct CUtf8Encoder
{
    CUtf8Encoder() {}
    ::std::string operator()( const ::std::wstring &str ) const
       {
        return MARTY_UTF::toUtf8(str);
       }
    ::std::string operator()( const ::std::string &str ) const { return str; }
};

#if defined(_WIN32) || defined(WIN32)
struct CAnsiEncoder
{
    CAnsiEncoder() {}
    ::std::string operator()( const ::std::wstring &str ) const
       {
        return MARTY_CON::strToAnsi(str /* , CP_ACP */  );
       }
    ::std::string operator()( const ::std::string &str ) const { return str; }
};
#else
typedef CUtf8Encoder CAnsiEncoder;
#endif



template <typename TEncoder>
struct CMenuHtmlDescriber : public CMenuDescriberBase<TEncoder>
{
    bool makeUpLink;
    bool makeExecLinks;
    mutable bool bFirst;


    typedef CMenuDescriberBase<TEncoder> base_describer;

    CMenuHtmlDescriber( const TEncoder &enc, const ::std::string &encName, const ::std::map< ::std::string, ::std::wstring > &ot, ::std::string &t)
       : base_describer( enc, encName, ot, t )
       , makeUpLink(false)
       , makeExecLinks(false)
       , bFirst(true)
       {
        makeExecLinks = this->getOptText("make-exec-links", L"0") == ::std::wstring(L"1");
        if (this->getOptText("upref-text", L"") != ::std::wstring(L""))
           {
            makeUpLink = true;
           }
       }

    // implement in custom describer
    void startDocument( const ::std::wstring &docId, const ::std::wstring &docTitle) const
       {
        this->text.append("<html>\r\n<head>\r\n");
        if (!encodingName.empty())
           {
            this->text.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=");
            this->text.append(encodingName);
            this->text.append("\"></meta>\r\n");
           }        

        this->text.append("<title>");
        this->text.append(this->xmlEscape(this->encoder(docTitle)));
        this->text.append("</title>\r\n</head>\r\n<body bgcolor=\"");
        this->text.append( this->encoder(this->getOptText("bgcolor", L"FFFFFF")) );
        this->text.append("\">\r\n");
        if (makeUpLink)
           {
            this->text.append("<a name=\"_top_\"/a>");
           }
        //this->text.append( this->encoder(this->getOptText("bgcolor", L"FFFFFF")) );
       }

    void endDocument() const
       {
        this->text.append("\r\n</body>\r\n<html>\r\n");
       }

    bool startMenu( SIZE_T menuId, const ::std::wstring &menuName, const ::std::wstring &menuText, const ::std::wstring &menuInfo ) const
       {
        if (!this->checkUpdateUsed( menuName )) return false;

        #ifndef HTML_DESCRIBER_ANCHOR_AFTER_TITLE
        this->text.append("<a name=\"");
        this->text.append(this->xmlEscape(this->encoder(menuName)));
        this->text.append("\"/>");
        #endif

        this->text.append("<h3 id=\"");
        this->text.append(this->xmlEscape(this->encoder(menuName)));
        this->text.append("\">");
        bool bMainMenu = menuName==L"main-menu";
        if (!bMainMenu)
           {
            //::std::wstring strMenu = optionalTexts["menu"];
            //if (strMenu.empty()) strMenu = L"Menu";
            //::std::wstring this->getOptText( const ::std::string &strId, const ::std::wstring &defStr )
            this->text.append(this->xmlEscape(this->encoder(this->getOptText("menu", L"Menu"))));
            this->text.append(this->xmlEscape(this->encoder(L" ")));
            this->text.append(this->xmlEscape(this->encoder(L"\"")));
           }
        this->text.append(this->xmlEscape(this->encoder(removeAmp(menuText))));
        if (!bMainMenu)
            this->text.append(this->xmlEscape(this->encoder(L"\"")));

        if (makeUpLink && !bFirst)
           {
            this->text.append(" <sup><a href=\"#_top_\">");
            this->text.append(this->xmlEscape(this->encoder(this->getOptText("upref-text", L""))));
            this->text.append("</a></sup>");
           }

        this->text.append("</h3>");

        #ifdef HTML_DESCRIBER_ANCHOR_AFTER_TITLE
        this->text.append("<a name=\"");
        this->text.append(this->xmlEscape(this->encoder(menuName)));
        this->text.append("\"/>");
        #endif

        this->text.append("<p>");
        this->text.append(this->xmlEscape(this->encoder(menuInfo)));
        if (!this->emptyStringOrEndsWithDot(menuInfo))
           this->text.append(".");
        this->text.append("</p>\r\n");

        bFirst = false;

        return true;
       }

    void endMenu() const
       {
        this->text.append("\r\n<p></p>\r\n");
       }

    void startItem( DWORD flags, SIZE_T itemId, const ::std::wstring &itemName, const ::std::wstring &itemText, const ::std::wstring &itemInfo ) const
       {
        if (flags&CLI_GUI_EMENUITEMFLAGS_FSUBMENU)
           {
            this->text.append("<p><span id=\"submenu-info-");
            this->text.append(this->xmlEscape(this->encoder(itemName)));
            this->text.append("\">");
    
            //this->text.append("<span style=\"font-weight: bold\">");
            this->text.append("<span style=\"font-weight: bold;\">");

            this->text.append("<a href=\"#");
            this->text.append(this->xmlEscape(this->encoder(itemName)));
            this->text.append("\">");
            this->text.append(this->xmlEscape(this->encoder(removeAmp(itemText))));
            this->text.append("</a>");
            this->text.append("</span>\r\n");

            //this->text.append(this->xmlEscape(this->encoder(removeAmp(itemText))));
            //this->text.append("</span>\r\n");
            this->text.append(" - ");
            this->text.append(this->xmlEscape(this->encoder(itemInfo)));
            //this->text.append(this->xmlEscape(this->encoder(strSubmenu)));
            //this->text.append(this->xmlEscape(this->encoder(L" ")));
            //this->text.append("<a href=\"#");
            //this->text.append(this->xmlEscape(this->encoder(itemName)));
            //this->text.append("\">");
            //this->text.append(this->xmlEscape(this->encoder(removeAmp(itemText))));
            //this->text.append("</a>");
            //this->text.append(this->xmlEscape(this->encoder(removeAmp(menuText))));

            //this->text.append(this->xmlEscape(this->encoder(itemInfo)));
    
            this->text.append("</span></p>\r\n");
           }
        else
           {
            this->text.append("<p><span id=\"");
            this->text.append(this->xmlEscape(this->encoder(itemName)));
            this->text.append("\">");
    
            this->text.append("<span style=\"font-weight: bold;\">");
            if (makeExecLinks)
               {
                this->text.append("<a href=\"#exec-");
                this->text.append(this->xmlEscape(this->encoder(itemName)));
                this->text.append("\">");
               }

            this->text.append(this->xmlEscape(this->encoder(removeAmp(itemText))));
            if (makeExecLinks)
               this->text.append("</a>");

            this->text.append("</span>\r\n");
            this->text.append(" - ");
            this->text.append(this->xmlEscape(this->encoder(itemInfo)));
            if (!this->emptyStringOrEndsWithDot(itemInfo))
               this->text.append(".");
    
            this->text.append("</span></p>\r\n");
           }
       }

    void endItem() const
       {
       }
};


template <typename TEncoder>
struct CMenuDocbookDescriber : public CMenuDescriberBase<TEncoder>
{
    typedef CMenuDescriberBase<TEncoder> base_describer;

    CMenuDocbookDescriber( const TEncoder &enc, const ::std::string &encName, const ::std::map< ::std::string, ::std::wstring > &ot, ::std::string &t)
       : base_describer( enc, encName, ot, t )
       {}

    // implement in custom describer
    void startDocument( const ::std::wstring &docId, const ::std::wstring &docTitle) const
       {
        this->text.append("<?xml version=\"1.0\"");
        if (!encodingName.empty())
           {
            this->text.append(" encoding=\"");
            this->text.append(encodingName);
            this->text.append("\"");
           }        
        this->text.append("?>\r\n");

        this->text.append("<article xml:id=\"");
        this->text.append(this->xmlEscape(this->encoder(docId)));
        this->text.append("\" xmlns=\"http://docbook.org/ns/docbook\" version=\"5.0\" xmlns:xi=\"http://www.w3.org/2001/XInclude\">\r\n");
        //this->text.append("\r\n");
        this->text.append("<articleinfo>\r\n<title>");
        this->text.append(this->xmlEscape(this->encoder(docTitle)));
        this->text.append("</title>\r\n</articleinfo>\r\n");
       }

    void endDocument() const
       {
        this->text.append("</article>\r\n");
       }

    bool startMenu( SIZE_T menuId, const ::std::wstring &menuName, const ::std::wstring &menuText, const ::std::wstring &menuInfo ) const
       {
        if (!this->checkUpdateUsed( menuName )) return false;

        this->text.append("<sect1 id=\""); this->text.append(this->xmlEscape(this->encoder(menuName))); this->text.append("\">\r\n");
        this->text.append("<title>"); this->text.append(this->xmlEscape(this->encoder(removeAmp(menuText)))); this->text.append("</title>\r\n");
        this->text.append("<para>"); this->text.append(this->xmlEscape(this->encoder(menuInfo))); this->text.append("</para>\r\n");
        return true;
       }

    void endMenu() const
       {
        this->text.append("</sect1>\r\n");
       }

    void startItem( DWORD flags, SIZE_T itemId, const ::std::wstring &itemName, const ::std::wstring &itemText, const ::std::wstring &itemInfo ) const
       {
        /*
        if (flags&CLI_GUI_EMENUITEMFLAGS_FSUBMENU)
           this->text.append("<sect2 id=\"submenu-info-");
        else
           this->text.append("<sect2 id=\""); 
        this->text.append(this->xmlEscape(this->encoder(itemName))); this->text.append("\">\r\n");
        this->text.append("<title>"); this->text.append(this->xmlEscape(this->encoder(removeAmp(itemText)))); this->text.append("</title>\r\n");
        this->text.append("<para>"); this->text.append(this->xmlEscape(this->encoder(itemInfo))); this->text.append("</para>\r\n");
        */
        this->text.append("<para>");
        if (flags&CLI_GUI_EMENUITEMFLAGS_FSUBMENU)
           {
            this->text.append("<link linkend=\"");
            this->text.append(this->xmlEscape(this->encoder(itemName))); 
            this->text.append("\">");
            this->text.append(this->xmlEscape(this->encoder(removeAmp(itemText))));
            this->text.append("</link>");
           }
        else
           {
            //this->text.append(" id=\""); 
            this->text.append(this->xmlEscape(this->encoder(removeAmp(itemText))));
           }

        this->text.append(" - "); 
        this->text.append(this->xmlEscape(this->encoder(itemInfo))); 
        this->text.append("</para>\r\n");
        //<link linkend='nextsect'>this</link>
       }

    void endItem() const
       {
        //this->text.append("</sect2>\r\n");
       }

};









}; // namespace helpers



}; // namespace gui
}; // namespace cli

#endif /* CLI_GUI_HELPERS_H */

