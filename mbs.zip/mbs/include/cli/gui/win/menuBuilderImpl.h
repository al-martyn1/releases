#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_WIN_MENUBUILDERIMPL_H
#define CLI_GUI_WIN_MENUBUILDERIMPL_H

#ifndef CLI_GUI_MENUBUILDERIMPL_H
    #include <cli/gui/menuBuilderImpl.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STACK_) && !defined(_STLP_STACK) && !defined(__STD_STACK__) && !defined(_CPP_STACK) && !defined(_GLIBCXX_STACK)
    #include <stack>
#endif


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#ifndef CLI_GUI_COMMANDIMPLBASE_H
    #include <cli/gui/commandImplBase.h>
#endif


namespace cli {
namespace gui {
namespace impl {
namespace win {


BEGIN_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CFileExitCommand)
   {
    ::PostMessage(hwndMainWindow, WM_CLOSE, 0, 0 );
    return EC_OK;
   }

HWND hwndMainWindow;
CFileExitCommand(HWND hwndMain) : command_base_impl(), hwndMainWindow(hwndMain) {}
END_IMPLEMENT_CLI_GUI_COMMANDHANDLER(CFileExitCommand)


class CMenuBuilderImplBase;

struct CCommandInfo : public ::cli::gui::impl::CCommandInfoImplBase
{
    typedef ::cli::gui::impl::CCommandInfoImplBase base_impl;
    // members of ::cli::gui::impl::CCommandInfoImplBase
    // ENUM_CLI_GUI_EMENUITEMFLAGS                     stateFlags;
    // ::std::stack<INTERFACE_CLI_GUI_ICOMMAND*>       handlersStack;
    // ::std::stack<INTERFACE_CLI_IARGLIST*>           handlerArgs;
    // ::std::wstring                                  commandName;
    // ::std::wstring                                  itemTextId;
    // ::std::wstring                                  itemInfoId;
    // ::std::wstring                                  itemText;
    // ::std::wstring                                  itemInfo;
    // ::std::vector<STRUCT_CLI_GUI_CACCEL>            accels;
    // UINT                                            radioGroupId;
    CMenuBuilderImplBase    *pOwnerBuilder;
    WORD                     cmdSysId;
    ::std::vector<size_t>    menus; // list of menus where this command present

    CCommandInfo( CMenuBuilderImplBase *pown);
    CCommandInfo( const CCommandInfo &ci);
    CCommandInfo& operator=( const CCommandInfo &ci);
    virtual std::wstring makeAccelText(const STRUCT_CLI_GUI_CACCEL &accel);
    virtual void updateMenusText(const std::wstring &newText, const std::wstring &accelText)
       { // curently dynamic text update not implemented
       }

    void loadText();
    void loadInfo();


    //virtual void updateMenusText(const std::wstring &newText, const std::wstring &accelText) = 0;

}; // struct CCommandInfo







class CMenuBuilderImplBase : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public ::cli::gui::impl::CMenuBuilderImplBase
                    //, public INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER
{

    friend struct CCommandInfo;

    bool useRadioChecks;

protected:

    WORD curCmdId;
    //HWND hWndMainWindow;

    struct CCommandShortIdInfo
       {
        WORD     cmdSysId;
        size_t   commandIndex;
       };

    struct CCommandShortNameInfo
       {
        ::std::wstring  cmdName;
        size_t          commandIndex;
       };

    ::std::map< ::std::wstring, CCommandShortIdInfo > commandToId;
    ::std::map< WORD, CCommandShortNameInfo         > idToCommand;
    ::std::vector< CCommandInfo >                     commands;
    

    // not thread safe
    RCODE addNewCommand( const ::std::wstring &cmdName, SIZE_T *pIndex, WORD *pId, CCommandInfo **ppNewCommandInfo)
       {
        // EC_NO_MEM
        // EC_ERR_ALLREADY
        try{
            CLI_SCOPED_LOCK(cs);
            if (cmdName.empty()) return EC_INVALID_PARAM;
            ::std::map< ::std::wstring, CCommandShortIdInfo >::const_iterator it = commandToId.find(cmdName);
            if (it!=commandToId.end()) return EC_ERR_ALLREADY;

            size_t newPos = commands.size();
            commands.push_back(CCommandInfo(this));

            CCommandShortIdInfo shortIdInfo;
            shortIdInfo.cmdSysId       = curCmdId++;
            shortIdInfo.commandIndex   = newPos;

            CCommandShortNameInfo shortNameInfo;
            shortNameInfo.cmdName      = cmdName;
            shortNameInfo.commandIndex = newPos;

            commandToId[cmdName]              = shortIdInfo;
            idToCommand[shortIdInfo.cmdSysId] = shortNameInfo;

            if (pIndex) *pIndex = newPos;
            if (pId)    *pId    = shortIdInfo.cmdSysId;
            if (ppNewCommandInfo) *ppNewCommandInfo = &commands[newPos];

            // set up basics
            commands[newPos].cmdSysId    = shortIdInfo.cmdSysId;
            commands[newPos].commandName = cmdName;

            return EC_OK;
           }
        catch(...)
           {
            return EC_NO_MEM;
           }
       }

    RCODE findCommandId( const ::std::wstring &cmdName, SIZE_T *pId )
       {
        if (cmdName.empty()) return EC_COMMAND_INVALID_NAME; // empty names not allowed
        CLI_SCOPED_LOCK(cs);
        ::std::map< ::std::wstring, CCommandShortIdInfo >::const_iterator it = commandToId.find(cmdName);
        if (it == commandToId.end()) return EC_COMMAND_UNKNOWN;
        // Ok, was found
        if (pId) *pId = it->second.commandIndex;
        return EC_OK;
       }

    RCODE findCommandId( const WCHAR* cmdName, SIZE_T *pId )
       {
        if (!cmdName) return EC_COMMAND_INVALID_NAME; // empty names not allowed
        return findCommandId(::std::wstring(cmdName), pId);
       }

    bool testCommandIndex(SIZE_T cmdId) const
       {
        CLI_SCOPED_LOCK(cs);
        if (cmdId>=commands.size()) return false;
        return true;
       }

    //USAGE: 
    //if (!testCommandIndex(cmdId)) return EC_COMMAND_UNKNOWN;

    const CCommandInfo* getCommandInfo( SIZE_T cmdId ) const
       {
        if (!testCommandIndex(cmdId)) return 0;
        return &commands[cmdId];
       }

    CCommandInfo* getCommandInfo( SIZE_T cmdId )
       {
        if (!testCommandIndex(cmdId)) return 0;
        return &commands[cmdId];
       }

    void setCommandUsedInMenu( SIZE_T cmdId, SIZE_T menuId )
       {
        CCommandInfo* pCommandInfo = getCommandInfo( cmdId );
        if (!pCommandInfo) return;
        pCommandInfo->usedInMenus.push_back(menuId);
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    virtual void updateAllTexts()
       {
       }

    virtual void updateInfoTextsOnly()
       {
       }

    void clearCommands() 
       {
        ::std::vector< CCommandInfo >::iterator it = commands.begin();
        for(; it!=commands.end(); ++it)
           {
            it->releaseOwnedObjects();
           }
       }

public:
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef ::cli::gui::impl::CMenuBuilderImplBase mb_base_impl;

    CMenuBuilderImplBase()
       : base_impl(DEF_MODULE)
       , mb_base_impl()
       //, INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER()
       , useRadioChecks(false)
       , curCmdId(32900)
       //, hWndMainWindow(0)
       , commandToId()
       , idToCommand()
       , commands()
       {}

    ~CMenuBuilderImplBase()
       {
        clearCommands();
       }

    CLI_BEGIN_INTERFACE_MAP2(CMenuBuilderImplBase, INTERFACE_CLI_GUI_IMENUBUILDER )
    //CLI_BEGIN_INTERFACE_MAP2(CMenuBuilderImplBase, ::cli::gui::impl::CMenuBuilderImplBase )
    //CLI_BEGIN_INTERFACE_MAP2(CMenuBuilderImplBase, INTERFACE_CLI_GUI_IMENUBUILDER)
    //CLI_BEGIN_INTERFACE_MAP(CCellImpl)
        //CLI_IMPLEMENT_INTERFACE2(INTERFACE_CLI_GUI_IMENUBUILDERWIN, INTERFACE_CLI_GUI_IMENUBUILDERWIN32)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_IMENUBUILDER )
        //CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_IMENUBUILDERWIN32 )
        //CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_IWIN32WINDOWHOLDER )
    CLI_END_INTERFACE_MAP(CMenuBuilderImplBase)


/*
DECLARE_REGISTRY_RESOURCEID(IDR_ADDIN)
DECLARE_NOT_AGGREGATABLE(CConnect)

<%BEGIN VSCommand%>BEGIN_COM_MAP(CConnect)
    COM_INTERFACE_ENTRY(IDTExtensibility2)
    COM_INTERFACE_ENTRY(IDTCommandTarget)
    COM_INTERFACE_ENTRY2(IDispatch, IDTExtensibility2)
END_COM_MAP()<%END VSCommand%>
<%BEGIN NOT VSCommand%>BEGIN_COM_MAP(CConnect)
    COM_INTERFACE_ENTRY(IDispatch)
    COM_INTERFACE_ENTRY(IDTExtensibility2)
END_COM_MAP()<%END NOT VSCommand%>


    DECLARE_PROTECT_FINAL_CONSTRUCT()

*/


    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    // define 'destroy' in descendants

    #if 0
    CLIMETHOD(setWindow) (THIS_ HWND    hwnd /* [in] hwnd_win32  mainWindow  */)
       {
        hWndMainWindow = hwnd;
        return EC_OK;
       }

    CLIMETHOD(getWindow) (THIS_ HWND*    hwnd /* [out] hwnd_win32 mainWindow  */)
       {
        if (hwnd) *hwnd = hWndMainWindow;
        return EC_OK;
       }
    #endif

    CLIMETHOD(commandsNamesGet) (THIS_ CLISTR*           _commandsNames
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                )
       {
        if (!_commandsNames) return EC_INVALID_PARAM;
        if (idx1>=commands.size()) return EC_OUT_OF_RANGE;
        return ::cli::propertyGetImpl( _commandsNames, commands[idx1].commandName );
       }

    CLIMETHOD(commandsNamesSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = commands.size();
        return EC_OK;
       }
/*
/////////
    struct CCommandShortIdInfo
       {
        WORD     cmdSysId;
        size_t   commandIndex;
       };

    struct CCommandShortNameInfo
       {
        ::std::wstring  cmdName;
        size_t          commandIndex;
       };

    ::std::map< ::std::wstring, CCommandShortIdInfo > commandToId;
    ::std::map< WORD, CCommandShortNameInfo         > idToCommand;
    ::std::vector< CCommandInfo >                     commands;
////////
*/
    

    CLIMETHOD(getCommandId) (THIS_ const WCHAR*    cmdId /* [in,flat] wchar  cmdId[]  */
                                 , SIZE_T*    commandId /* [out,optional] size_t commandId  */
                            )
       {
        return findCommandId( cmdId, commandId );
       }

    CLIMETHOD(getCommandByIdRadioGroup) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                             , SIZE_T*    rgId /* [out] size_t rgId  */
                                        )
       {
        CLI_SCOPED_LOCK(cs);
        const CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) return EC_COMMAND_UNKNOWN;
        if (rgId) *rgId = pci->radioGroupId;
        return EC_OK;
       }

    CLIMETHOD(getCommandByIdInfoText) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                           , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                           , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                      )
       {
        CLI_SCOPED_LOCK(cs);
        const CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) 
           {
            if (infoTextBuf && bufSize) infoTextBuf[0] = 0;
            return EC_COMMAND_UNKNOWN;
           }

        SIZE_T maxChars = bufSize-1;
        if (maxChars > pci->itemInfo.size())
           maxChars = pci->itemInfo.size();

        if (infoTextBuf)
           {
            pci->itemInfo.copy( infoTextBuf, maxChars, 0 );
            infoTextBuf[maxChars] = 0;
           }

        return EC_OK;
       }

    CLIMETHOD(getCommandNameById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                       , WCHAR*    cmdNameTextBuf /* [out,flat,optional] wchar cmdNameTextBuf  */
                                       , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                  )
       {
        CLI_SCOPED_LOCK(cs);
        const CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) 
           {
            if (cmdNameTextBuf && bufSize) cmdNameTextBuf[0] = 0;
            return EC_COMMAND_UNKNOWN;
           }

        SIZE_T maxChars = bufSize-1;
        if (maxChars > pci->commandName.size())
           maxChars = pci->commandName.size();

        if (cmdNameTextBuf)
           {
            pci->commandName.copy( cmdNameTextBuf, maxChars, 0 );
            cmdNameTextBuf[maxChars] = 0;
           }

        return EC_OK;
       }

    CLIMETHOD(getCommandTextById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                       , WCHAR*    cmdNameTextBuf /* [out,flat,optional] wchar cmdNameTextBuf  */
                                       , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                  )
       {
        CLI_SCOPED_LOCK(cs);
        const CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) 
           {
            if (cmdNameTextBuf && bufSize) cmdNameTextBuf[0] = 0;
            return EC_COMMAND_UNKNOWN;
           }

        SIZE_T maxChars = bufSize-1;
        if (maxChars > pci->itemText.size())
           maxChars = pci->itemText.size();

        if (cmdNameTextBuf)
           {
            pci->itemText.copy( cmdNameTextBuf, maxChars, 0 );
            cmdNameTextBuf[maxChars] = 0;
           }

        return EC_OK;
       }

#if 0 // Old version

    CLIMETHOD(getCommandTextById) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                       , WCHAR*    cmdNameTextBuf /* [out,flat,optional] wchar cmdNameTextBuf  */
                                       , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                  )
       {
        CLI_SCOPED_LOCK(cs);
        const CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) 
           {
            if (cmdNameTextBuf && bufSize) cmdNameTextBuf[0] = 0;
            return EC_COMMAND_UNKNOWN;
           }

        SIZE_T maxChars = bufSize-1;
        if (maxChars > pci->commandName.size())
           maxChars = pci->commandName.size();

        if (cmdNameTextBuf)
           {
            pci->commandName.copy( cmdNameTextBuf, maxChars, 0 );
            cmdNameTextBuf[maxChars] = 0;
           }

        return EC_OK;
       }
#endif

    CLIMETHOD(syncCommandsUiState) (THIS)
       {
        CLI_SCOPED_LOCK(cs);
        //::std::map< WORD, CCommandShortNameInfo         >::const_iterator it = idToCommand.begin();
        ::std::map< ::std::wstring, CCommandShortIdInfo >::const_iterator cit = commandToId.begin();
        for(; cit != commandToId.end(); ++cit)
           {
            syncCommandByIdUiState(cit->second.commandIndex);
           }       
        return EC_OK;
       }

    CLIMETHOD(syncCommandByIdUiState) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */)
       {
         INTERFACE_CLI_GUI_ICOMMAND* pHandler    = 0;
         INTERFACE_CLI_IARGLIST    * cmd_argList = 0;
         ::std::wstring cmdName;
         {
           CLI_SCOPED_LOCK(cs);
           const CCommandInfo* pCmdInfo = getCommandInfo( cmdId );
           if (!pCmdInfo) return EC_COMMAND_UNKNOWN;
   
           if (pCmdInfo->handlersStack.empty()) return EC_COMMAND_NO_HANDLER;
           pHandler = pCmdInfo->handlersStack.top();
           if (!pHandler) return EC_COMMAND_NO_HANDLER;

           if (!pCmdInfo->handlerArgs.empty()) cmd_argList = pCmdInfo->handlerArgs.top();
   
           cmdName  = pCmdInfo->commandName;
         }

        return pHandler->syncItemUiState( cmdName.c_str()
                                        , static_cast<INTERFACE_CLI_GUI_IMENUBUILDER*>(this)
                                        , pAppConfig
                                        , pUnkAppData
                                        , pvData
                                        , cmd_argList
                                        );
       }

    CLIMETHOD(invokeByIdExactParams) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                          , INTERFACE_CLI_GUI_IMENUBUILDER*    a_iMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                                          , INTERFACE_CLI_APP_ICONFIG*    a_appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                          , INTERFACE_CLI_IUNKNOWN*    a_iUnkAppdata /* [in,optional] ::cli::iUnknown*  iUnkAppdata  */
                                          , const VOID*    a_pData /* [in,optional] void*  pData  */
                                          , INTERFACE_CLI_IARGLIST*    a_pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                     )
       {
         INTERFACE_CLI_GUI_ICOMMAND* pHandler = 0;
         ::std::wstring cmdName;
         {
           CLI_SCOPED_LOCK(cs);
           const CCommandInfo* pCmdInfo = getCommandInfo( cmdId );
           if (!pCmdInfo) return EC_COMMAND_UNKNOWN;
   
           if (pCmdInfo->handlersStack.empty()) return EC_COMMAND_NO_HANDLER;
           pHandler = pCmdInfo->handlersStack.top();
           if (!pHandler) return EC_COMMAND_NO_HANDLER;
   
           // execution of hidden commands allowed
           //if ( (pCmdInfo->stateFlags & (CLI_GUI_EMENUITEMFLAGS_FHIDDEN|CLI_GUI_EMENUITEMFLAGS_FDISABLED)) != 0 )
           if ( (pCmdInfo->stateFlags & (CLI_GUI_EMENUITEMFLAGS_FDISABLED)) != 0 )
              return EC_COMMAND_DISABLED;

           cmdName  = pCmdInfo->commandName;
         }

        //if (!pHandler)
        return
        pHandler->commandHandler( cmdName.c_str()
                                , a_iMenuBuilder
                                , a_appConfig
                                , a_iUnkAppdata
                                , a_pData
                                , a_pArgs
                                );
       }

    template<typename TPARAM>
    void
    implementInvokeFlagsRules( TPARAM &res 
                             , TPARAM defVal
                             , TPARAM argVal
                             , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS flags
                             , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS forceDefaultFlag
                             , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS useFlag
                             )
       {
        //INTERFACE_CLI_APP_ICONFIG *tmp_appConfig = 0;
        using namespace ::cli::gui::EMenuBuilderInvokeCommandFlags;
        if ((flags&forceDefaultFlag)==forceDefaultFlag)
           res = defVal;
        else
           {
            if ((flags&useFlag)==useFlag)
               res = argVal;
            else
               {
                if (argVal)
                   res = argVal;
                else
                   res = defVal;
               }
           }        
       }

    CLIMETHOD(invokeByIdParams) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                     , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS    invokeFlags /* [in] ::cli::gui::EMenuBuilderInvokeCommandFlags  invokeFlags  */
                                     , INTERFACE_CLI_GUI_IMENUBUILDER*    a_iMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                                     , INTERFACE_CLI_APP_ICONFIG*    a_appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                     , INTERFACE_CLI_IUNKNOWN*    a_iUnkAppdata /* [in,optional] ::cli::iUnknown*  iUnkAppdata  */
                                     , const VOID*    a_pData /* [in,optional] void*  pData  */
                                     , INTERFACE_CLI_IARGLIST*    a_pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                )
       {
        INTERFACE_CLI_APP_ICONFIG *tmp_appConfig = 0;
        INTERFACE_CLI_GUI_IMENUBUILDER* tmp_menuBuilder = 0;
        INTERFACE_CLI_IUNKNOWN* tmp_iUnkAppdata = 0;
        VOID* tmp_pvData = 0;
        INTERFACE_CLI_IARGLIST* tmp_argList = 0;

         {
          CLI_SCOPED_LOCK(cs);
          const CCommandInfo* pCmdInfo = getCommandInfo( cmdId );
          if (!pCmdInfo) return EC_COMMAND_UNKNOWN;
  
          using namespace ::cli::gui::EMenuBuilderInvokeCommandFlags;
  
          implementInvokeFlagsRules( tmp_appConfig, pAppConfig, a_appConfig, invokeFlags, fForceUseDefaultAppConfig, fUseAppConfig);
          //implementInvokeFlagsRules( tmp_menuBuilder, static_cast<INTERFACE_CLI_GUI_IMENUBUILDER*>(this), a_iMenuBuilder, invokeFlags, fForceUseDefaultMenuBuilder, fUseMenuBuilder);
          implementInvokeFlagsRules( tmp_menuBuilder
                                   //, static_cast<INTERFACE_CLI_GUI_IMENUBUILDER*>( static_cast<INTERFACE_CLI_GUI_IMENUBUILDERWIN32*>(this) )
                                   , static_cast<INTERFACE_CLI_GUI_IMENUBUILDER*>( this )
                                   , a_iMenuBuilder, invokeFlags
                                   , fForceUseDefaultMenuBuilder
                                   , fUseMenuBuilder
                                   );

          implementInvokeFlagsRules( tmp_iUnkAppdata, pUnkAppData, a_iUnkAppdata, invokeFlags, fForceUseDefaultDataObject, fUseDataObject);
          implementInvokeFlagsRules( tmp_pvData, pvData, (VOID*)a_pData, invokeFlags, fForceUseDefaultDataPointer, fUseDataPointer);
  
          INTERFACE_CLI_IARGLIST* cmd_argList = 0;
          if (!pCmdInfo->handlerArgs.empty()) cmd_argList = pCmdInfo->handlerArgs.top();
          implementInvokeFlagsRules( tmp_argList, cmd_argList, a_pArgs, invokeFlags, fForceUseDefaultArgs, fUseArgs);

          // prevent to freeing objects in another threads
          if (tmp_appConfig)   tmp_appConfig->addRef();
          if (tmp_menuBuilder) tmp_menuBuilder->addRef();
          if (tmp_iUnkAppdata) tmp_iUnkAppdata->addRef();
          if (tmp_argList)     tmp_argList->addRef();
         }

        // unloked code, objects protected by incrementing ref counter
        RCODE res = invokeByIdExactParams( cmdId
                                   , tmp_menuBuilder
                                   , tmp_appConfig
                                   , tmp_iUnkAppdata
                                   , tmp_pvData
                                   , tmp_argList
                                   );
        if (tmp_appConfig)   tmp_appConfig->release();
        if (tmp_menuBuilder) tmp_menuBuilder->release();
        if (tmp_iUnkAppdata) tmp_iUnkAppdata->release();
        if (tmp_argList)     tmp_argList->release();

        return res;
       }

    CLIMETHOD(setCommandByIdHandler) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                          , INTERFACE_CLI_GUI_ICOMMAND*    newHandler /* [in] ::cli::gui::iCommand*  newHandler  */
                                     )
       {
        CLI_SCOPED_LOCK(cs);
        CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) return EC_COMMAND_UNKNOWN;
        if (pci->setCommandHandler(newHandler)) return EC_COMMAND_NO_HANDLER;
        return EC_OK;
       }


protected:

    virtual void implementTrackPopup( HMENU hMenu, int x, int y, UINT tpmFlags ) = 0;

public:

    RCODE trackPopupMenuImpl(const WCHAR* menuName, int x, int y /* , SIZE_T *pCmdIdx */ )
       {
        GENERIC_HMENU ghMenu = 0;
        RCODE res = createMenu(menuName, TRUE, &ghMenu);
        if (res) return res;

        using namespace ::cli::gui::ETrackPopupMenuFlags;

        UINT uFlags = 0;

        if (trackPopupFlags&alignCenter)     uFlags |= TPM_CENTERALIGN;
        else if (trackPopupFlags&alignRight) uFlags |= TPM_RIGHTALIGN;

        if (trackPopupFlags&alignVCenter)     uFlags |= TPM_VCENTERALIGN;
        else if (trackPopupFlags&alignBottom) uFlags |= TPM_BOTTOMALIGN;

        if (trackPopupFlags&useRightButton) uFlags |= TPM_RIGHTBUTTON;

        if (trackPopupFlags&useRtlReading) uFlags |= 0x8000; // TPM_LAYOUTRTL       0x8000L

        implementTrackPopup( (HMENU)ghMenu, x, y, uFlags );

        destroyMenu(ghMenu, TRUE);
        return EC_OK;
       }

    #if 0
    CLIMETHOD(trackPopupExactParams) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                          , INT    cx /* [in] int  cx  */
                                          , INT    cy /* [in] int  cy  */
                                          , INTERFACE_CLI_GUI_IMENUBUILDER*    a_iMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                                          , INTERFACE_CLI_APP_ICONFIG*    a_appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                          , INTERFACE_CLI_IUNKNOWN*    a_iUnkAppdata /* [in,optional] ::cli::iUnknown*  iUnkAppdata  */
                                          , const VOID*    a_pData /* [in,optional] void*  pData  */
                                          , INTERFACE_CLI_IARGLIST*    a_pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                     )
       {
        SIZE_T commandIndex = SIZE_T_NPOS;
        RCODE res = trackPopupMenuImpl(menuName, cx, cy, &commandIndex);
        if (res) return res;
        if (commandIndex==SIZE_T_NPOS) return EC_OK; // no item selected
        res = invokeByIdExactParams( commandIndex, a_iMenuBuilder, a_appConfig, a_iUnkAppdata, a_pData, a_pArgs );
        #ifdef _DEBUG
        if (res) ::cli::format::cli_log::message( L"invokeByIdExactParams - Error: %2", ::cli::format::arg( res ) );
        #endif
        return res;
       }

    CLIMETHOD(trackPopupParams) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                     , INT    cx /* [in] int  cx  */
                                     , INT    cy /* [in] int  cy  */
                                     , ENUM_CLI_GUI_EMENUBUILDERINVOKECOMMANDFLAGS    invokeFlags /* [in] ::cli::gui::EMenuBuilderInvokeCommandFlags  invokeFlags  */
                                     , INTERFACE_CLI_GUI_IMENUBUILDER*    a_iMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  iMenuBuilder  */
                                     , INTERFACE_CLI_APP_ICONFIG*    a_appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                     , INTERFACE_CLI_IUNKNOWN*    a_iUnkAppdata /* [in,optional] ::cli::iUnknown*  iUnkAppdata  */
                                     , const VOID*    a_pData /* [in,optional] void*  pData  */
                                     , INTERFACE_CLI_IARGLIST*    a_pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                )
       {
        SIZE_T commandIndex = SIZE_T_NPOS;
        RCODE res = trackPopupMenuImpl(menuName, cx, cy, &commandIndex);
        if (res) return res;
        if (commandIndex==SIZE_T_NPOS) return EC_OK; // no item selected
        res = invokeByIdParams( commandIndex, invokeFlags, a_iMenuBuilder, a_appConfig, a_iUnkAppdata, a_pData, a_pArgs );
        #ifdef _DEBUG
        if (res) ::cli::format::cli_log::message( L"invokeByIdParams - Error: %2", ::cli::format::arg( res ) );
        #endif
        return res;
       }
    #endif
    

    CLIMETHOD(trackPopup) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                               , INT    cx /* [in] int  cx  */
                               , INT    cy /* [in] int  cy  */
                          )
       {
        return trackPopupMenuImpl(menuName, cx, cy );
        /*
        SIZE_T commandIndex = SIZE_T_NPOS;
        RCODE res = trackPopupMenuImpl(menuName, cx, cy, &commandIndex);
        if (res) return res;
        if (commandIndex==SIZE_T_NPOS) return EC_OK; // no item selected
        res = invokeById( commandIndex );
        #ifdef _DEBUG
        if (res) ::cli::format::cli_log::message( L"invokeById - Error: %2", ::cli::format::arg( res ) );
        #endif
        return res;
        */
       }

    #if 0
    CLIMETHOD(trackPopupWithArgList) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                                          , INT    cx /* [in] int  cx  */
                                          , INT    cy /* [in] int  cy  */
                                          , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                     )
       {
        SIZE_T commandIndex = SIZE_T_NPOS;
        RCODE res = trackPopupMenuImpl(menuName, cx, cy, &commandIndex);
        if (res) return res;
        if (commandIndex==SIZE_T_NPOS) return EC_OK; // no item selected
        res = invokeByIdWithArgList( commandIndex, pArgs );
        #ifdef _DEBUG
        if (res) ::cli::format::cli_log::message( L"invokeByIdWithArgList - Error: %2", ::cli::format::arg( res ) );
        #endif
        return res;
       }
    #endif

    CLIMETHOD(addCommand) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdId[]  */
                               , ENUM_CLI_GUI_EMENUITEMFLAGS    flags /* [in] ::cli::gui::EMenuItemFlags  flags  */
                               , INTERFACE_CLI_GUI_ICOMMAND*    handler /* [in] ::cli::gui::iCommand*  handler  */
                               , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                               , const WCHAR*    rcModuleName /* [in,flat,optional] wchar  rcModuleName[]  */
                               , const WCHAR*    itemText /* [in,flat,optional] wchar  itemText[]  */
                               , const WCHAR*    itemInfoText /* [in,flat,optional] wchar  itemInfoText[]  */
                               , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat,optional] ::cli::gui::CAccel  accels[]  */
                               , SIZE_T    numAccels /* [in] size_t  numAccels  */
                               , const WCHAR*    radioGroupName /* [in,flat,optional] wchar  radioGroupName[]  */
                               , SIZE_T*    pCommandId /* [out,optional] size_t commandId  */
                          )
       {
        CLI_TRY{
                if (!cmdName) return EC_COMMAND_INVALID_NAME;
                flags &= CLI_GUI_EMENUITEMFLAGS_FSTATEMASK; // clear all no-state flags
                
                CCommandInfo *pNewCommandInfo = 0;
                SIZE_T       cmdId;
                CLI_SCOPED_LOCK(cs);
                RCODE res = addNewCommand( ::std::wstring(cmdName), &cmdId, 0, &pNewCommandInfo);
                if (res) return res;

                if (!pNewCommandInfo) return EC_UNKNOWN;

                pNewCommandInfo->handlersStack.push(handler);
                pNewCommandInfo->handlerArgs.push(pArgs);

                if (rcModuleName)
                   pNewCommandInfo->rcModuleName = rcModuleName;

                if (itemText)
                   pNewCommandInfo->itemText = itemText;
                if (pNewCommandInfo->itemText.empty()) pNewCommandInfo->loadText(); // itemText = findCommandText(pNewCommandInfo->commandName);

                if (itemInfoText)
                   pNewCommandInfo->itemInfo = itemInfoText;
                if (pNewCommandInfo->itemInfo.empty()) pNewCommandInfo->loadInfo(); // itemInfo = findCommandInfo(pNewCommandInfo->commandName);

                pNewCommandInfo->modifyAccels( FALSE, accels, numAccels);
                if (accels && numAccels)
                   notifyAccelChanged( );

                if (radioGroupName)
                   {
                    pNewCommandInfo->radioGroupId = addRadioGroupCommand( radioGroupName, cmdId);
                    // getRadioGroupId(radioGroupName);
                   }
                else
                   {
                    pNewCommandInfo->radioGroupId = SIZE_T_NPOS;
                   }

                if (pCommandId) *pCommandId = cmdId;

                if (handler) handler->syncItemUiState( cmdName
                                                     , static_cast<INTERFACE_CLI_GUI_IMENUBUILDER*>(this)
                                                     , pAppConfig
                                                     , pUnkAppData
                                                     , pvData
                                                     , pArgs
                                                     );

                // add tp categories
                addCommandToCategoryById2( CLI_GUI_ECATEGORYSTDATOMS_COMMONITEMSCATEGORY   , cmdId );
                addCommandToCategoryById2( CLI_GUI_ECATEGORYSTDATOMS_COMMONCOMMANDSCATEGORY, cmdId );

                return EC_OK;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
       }

    
    CLIMETHOD(addCommandByIdAccel) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                        , const STRUCT_CLI_GUI_CACCEL*    accel /* [in,ref] ::cli::gui::CAccel  accel  */
                                   )
       {
        CLI_SCOPED_LOCK(cs);
        CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) return EC_COMMAND_UNKNOWN;
        pci->modifyAccels( FALSE, accel, 1);
        updateCommandMenus(pci);
        notifyAccelChanged( );
        return EC_OK;
       }

    CLIMETHOD(modifyCommandByIdAccels) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                            , const STRUCT_CLI_GUI_CACCEL*    accels /* [in,flat] ::cli::gui::CAccel  accels[]  */
                                            , SIZE_T    numAccels /* [in] size_t  numAccels  */
                                            , BOOL    clearExisting /* [in] bool  clearExisting  */
                                       )
       {
        CLI_SCOPED_LOCK(cs);
        CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) return EC_COMMAND_UNKNOWN;
        pci->modifyAccels( clearExisting, accels, numAccels);
        updateCommandMenus(pci);
        notifyAccelChanged( );
        return EC_OK;
       }

    CLIMETHOD(enumCommandByIdAccels) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                          , SIZE_T    accelNo /* [in] size_t  accelNo  */
                                          , STRUCT_CLI_GUI_CACCEL*    accel /* [out] ::cli::gui::CAccel accel  */
                                     )
       {
        CLI_SCOPED_LOCK(cs);
        CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) return EC_COMMAND_UNKNOWN;
        if (accelNo>=pci->accels.size()) return EC_OUT_OF_RANGE;
        if (accel) *accel = pci->accels[accelNo];
        return EC_OK;
       }

    CLIMETHOD(getCommandByIdState) (THIS_ SIZE_T    cmdId /* [in] size_t  cmdId  */
                                        , ENUM_CLI_GUI_EMENUITEMFLAGS*    stateFlags /* [out] ::cli::gui::EMenuItemFlags stateFlags  */
                                   )
       {
        CLI_SCOPED_LOCK(cs);
        const CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) return EC_COMMAND_UNKNOWN;
        if (stateFlags) *stateFlags = pci->stateFlags;
        return EC_OK;
       }

protected:

    void menuChangedImplementationNotify( const WCHAR* menuName, SIZE_T menudId )
       {
        updateMenuObjects( menudId );
        notifyMenuChanged( menuName );
       }

    void updateCommandMenus(CCommandInfo* pci)
       {
        ::std::vector<SIZE_T>::const_iterator uimIt = pci->usedInMenus.begin();
        for(; uimIt!=pci->usedInMenus.end(); ++uimIt)
           {
            //updateMenuObjects(*uimIt);
            const CMenuInfo* pMenuInfo = getMenuInfo( *uimIt );
            menuChangedImplementationNotify( pMenuInfo->menuName.c_str(), *uimIt );
           }
       }

public:

    CLIMETHOD(setCommandByIdState) (THIS_ SIZE_T    cmdId /* [in,flat] size_t  cmdId  */
                                        , ENUM_CLI_GUI_EMENUITEMFLAGS    newStateFlags /* [in] ::cli::gui::EMenuItemFlags  newStateFlags  */
                                   )
       {
        CLI_SCOPED_LOCK(cs);
        CCommandInfo* pci = getCommandInfo( cmdId );
        if (!pci) return EC_COMMAND_UNKNOWN;

        newStateFlags &= CLI_GUI_EMENUITEMFLAGS_FSTATEMASK;

        ENUM_CLI_GUI_EMENUITEMFLAGS oldFlags = pci->stateFlags;
        pci->stateFlags = newStateFlags;

        ENUM_CLI_GUI_EMENUITEMFLAGS diffFlags = ((~oldFlags)&(newStateFlags)) | ((oldFlags)&(~newStateFlags));
        if (diffFlags&CLI_GUI_EMENUITEMFLAGS_FHIDDEN)
           { 
            updateCommandMenus(pci);
            notifyAccelChanged( );
           }

        if (diffFlags&CLI_GUI_EMENUITEMFLAGS_FCHECKED)
           {
            if (pci->radioGroupId!=SIZE_T_NPOS)
               { // process radio group
                if ((newStateFlags&CLI_GUI_EMENUITEMFLAGS_FCHECKED))
                   { // radio item becomes checked, reset all other radioitems
                    CRadioGroupInfo* pRadioGroup = getRadioGroupInfo( pci->radioGroupId );
                    if (pRadioGroup)
                       {
                        ::std::vector<SIZE_T>::const_iterator it = pRadioGroup->commands.begin();
                        for(; it!=pRadioGroup->commands.end(); ++it)
                           {
                            ENUM_CLI_GUI_EMENUITEMFLAGS radioBuddyFlags = 0;
                            RCODE tmpRes = getCommandByIdState(*it, &radioBuddyFlags);
                            if (tmpRes) continue;
    
                            if (cmdId==*it) pRadioGroup->radioGroupState = it - pRadioGroup->commands.begin();
    
                            if (!(radioBuddyFlags&CLI_GUI_EMENUITEMFLAGS_FCHECKED))
                               continue; // not checked allready
                            // checked
                            if (cmdId==*it) continue; // item that becomes checked allready checked
                            radioBuddyFlags &= ~CLI_GUI_EMENUITEMFLAGS_FCHECKED; // clear 'checked' flag, don't touch others
                            setCommandByIdState(*it, radioBuddyFlags);
                           }
                       }
                   } // radio item buddies cleared
               }
            else // not a radioitem
               {
               }
           }

        if (!(pci->stateFlags&CLI_GUI_EMENUITEMFLAGS_FHIDDEN))
           { // item is not hidden, need to update menus
            if (diffFlags&(CLI_GUI_EMENUITEMFLAGS_FDISABLED|CLI_GUI_EMENUITEMFLAGS_FCHECKED))
               { // UNDONE: need to update command state in menus
                ::std::vector<SIZE_T>::const_iterator cmdMenusIt = pci->usedInMenus.begin();
                for(; cmdMenusIt!=pci->usedInMenus.end(); ++cmdMenusIt)
                   {
                    SIZE_T menuId = *cmdMenusIt;
                    const CMenuInfo* pMenuInfo = getMenuInfo( menuId );
                    if (!pMenuInfo) continue;

                    ::std::vector< SIZE_T > itemPositions;
                    pMenuInfo->findCommandMenuPositions( cmdId, itemPositions );

                    ::std::set<GENERIC_HMENU>::const_iterator menuIt = pMenuInfo->menusCreated.begin();
                    for(; menuIt!=pMenuInfo->menusCreated.end(); ++menuIt)
                       {
                        HMENU hmenu = (HMENU)*menuIt;
                        ::std::vector< SIZE_T >::const_iterator posIt = itemPositions.begin();
                        for(; posIt!=itemPositions.end(); ++posIt)
                           {
                            if (diffFlags&CLI_GUI_EMENUITEMFLAGS_FDISABLED)
                               {
                                UINT itemFlags = MF_BYPOSITION;
                                if (newStateFlags&CLI_GUI_EMENUITEMFLAGS_FDISABLED)
                                   itemFlags |= MF_DISABLED|MF_GRAYED;
                                else
                                   itemFlags |= MF_ENABLED;
                                ::EnableMenuItem( hmenu, (UINT)*posIt, itemFlags );
                               }
                            if (diffFlags&CLI_GUI_EMENUITEMFLAGS_FCHECKED)
                               {
                                UINT itemFlags = MF_BYPOSITION;
                                if (newStateFlags&CLI_GUI_EMENUITEMFLAGS_FCHECKED)
                                   itemFlags |= MF_CHECKED;
                                else
                                   itemFlags |= MF_UNCHECKED;

                                ::CheckMenuItem( hmenu, (UINT)*posIt, itemFlags );
                               }
                           }
                       }
                   }
               }
           }
        return EC_OK;
       }

protected:


/*
struct CMenuItem
{
    DWORD             itemFlags; // item, submenu, break or barbreak
    SIZE_T            commandId; // commandId for commands
                                 // menuId for submenus
};

struct CMenuBuilderImplBase;

struct CMenuInfo
{
    CMenuBuilderImplBase      *pOwnerBuilder;
    ::std::wstring             menuName;
    ::std::wstring             menuText;
    ::std::wstring             menuInfo;
    BOOL                       mainMenu;  // if true, this is the main menu, else this is the popup menu
    ::std::vector<CMenuItem>   items;
    ::std::set<GENERIC_HMENU>  menusCreated;
};

    struct CHmenuInfo
    {
     SIZE_T    menuId;
     bool      noAccelText;
     CHmenuInfo() : menuId(SIZE_T_NPOS), noAccelText(false) {}
     CHmenuInfo( SIZE_T mid, bool a_noAccelText = false) : menuId(mid), noAccelText(a_noAccelText) {}
    };

    ::std::map< GENERIC_HMENU , CHmenuInfo>           createdMenus;


*/
    // not safe
    RCODE createMenuImpl( HMENU *pHmenu, SIZE_T menuId, bool dontShowAccels, CMenuInfo **ppMenuInfo )
       {
        CMenuInfo *pMenuInfo = getMenuInfo( menuId );
        if (!pMenuInfo) return EC_UNKNOWN;

        if (ppMenuInfo) *ppMenuInfo = pMenuInfo;

        HMENU hMenu = 0;
        if (pMenuInfo->mainMenu) hMenu = ::CreateMenu();
        else                     hMenu = ::CreatePopupMenu();

        if (hMenu!=0)
           {
            pMenuInfo->menusCreated.insert( (GENERIC_HMENU)hMenu );
            createdMenus[(GENERIC_HMENU)hMenu] = CHmenuInfo( menuId, dontShowAccels );
           }

        if (pHmenu) *pHmenu = hMenu;
        if (hMenu)  return EC_OK;
        return EC_UNKNOWN;
       }

    struct CConcreteMenuBuilder
       {
        CMenuBuilderImplBase *pMainBuilder;
        HMENU hMenu;
        bool dontShowAccels;
        CConcreteMenuBuilder(CMenuBuilderImplBase *pmb, HMENU hm, bool dsa) : pMainBuilder(pmb), hMenu(hm), dontShowAccels(dsa) {}

        bool appendMenuBarBreak()   { ::AppendMenu( hMenu, MF_MENUBARBREAK, 0, 0 ); return true; }
        bool appendMenuBreak()      { ::AppendMenu( hMenu, MF_MENUBREAK, 0, 0 ); return true; }
        bool appendMenuSeparator()  { ::AppendMenu( hMenu, MF_SEPARATOR, 0, 0 ); return true; }
        bool appendSubMenu(SIZE_T menuId)
           {
            CMenuInfo *pMenuInfo = pMainBuilder->getMenuInfo( menuId );
            if (!pMenuInfo) return true; // continue;
            GENERIC_HMENU gm;
            if (pMainBuilder->createMenuById( menuId, (dontShowAccels ? TRUE : FALSE), &gm ))
               return true;

            ::AppendMenuW( hMenu, MF_POPUP, (UINT_PTR)(HMENU)gm, pMenuInfo->menuText.c_str() );
            return true;
           }         

        bool appendItem(SIZE_T cmdId)
           {
            CCommandInfo* pCmdInfo = pMainBuilder->getCommandInfo( cmdId );
            if (!pCmdInfo) return true;
            if (pCmdInfo->stateFlags&CLI_GUI_EMENUITEMFLAGS_FHIDDEN) return true;

            UINT amFlags = MF_STRING;

            if (pCmdInfo->stateFlags&CLI_GUI_EMENUITEMFLAGS_FDISABLED)
               amFlags |= MF_GRAYED | MF_DISABLED;
            else
               amFlags |= MF_ENABLED;

            if (pCmdInfo->stateFlags&CLI_GUI_EMENUITEMFLAGS_FCHECKED)
               amFlags |= MF_CHECKED;
            else
               amFlags |= MF_UNCHECKED;

            ::std::wstring itemText = pCmdInfo->itemText;
            if (!dontShowAccels)
               {
                ::std::wstring accelText = pCmdInfo->getAccelText();
                if (!accelText.empty())
                   {
                    itemText.append(1, L'\t');
                    itemText.append(accelText);
                   }
               }

            ::AppendMenuW( hMenu, amFlags, (UINT_PTR)pCmdInfo->cmdSysId, itemText.c_str() );
            if (pCmdInfo->radioGroupId!=SIZE_T_NPOS && pMainBuilder->useRadioChecks)
               {
                int numItems = ::GetMenuItemCount( hMenu );
                MENUITEMINFO mii = { 0 };
                mii.cbSize = sizeof(mii);
                mii.fMask  = MIIM_FTYPE;
                if (::GetMenuItemInfo( hMenu, numItems-1, TRUE, &mii))
                   {
                    mii.fType |= MFT_RADIOCHECK;
                    SetMenuItemInfo( hMenu, numItems-1, TRUE, &mii);
                   }
               }
            return true;
           }
       };


    RCODE fillMenu( HMENU hMenu /* empty (newly) created menu */, SIZE_T menuId, bool dontShowAccels, CMenuInfo *pMenuInfo )
       {
        CConcreteMenuBuilder cmb(this, hMenu, dontShowAccels);
        if (!pMenuInfo->buildMenu( cmb ))
           {
            //::AppendMenuW( hMenu, MF_STRING|MF_GRAYED|MF_DISABLED, (UINT_PTR)0, getEmptyStringStr().c_str() );
            ::AppendMenuW( hMenu, MF_STRING|MF_GRAYED|MF_DISABLED, (UINT_PTR)32899, getEmptyStringStr().c_str() );
            //::AppendMenuW( hMenu, MF_STRING, (UINT_PTR)32899, getEmptyStringStr().c_str() );
           }
        return EC_OK;
       }

public:

    CLIMETHOD(createMenu) (THIS_ const WCHAR*    menuName /* [in,flat] wchar  menuName[]  */
                               , BOOL    dontShowAccels /* [in] bool  dontShowAccels  */
                               , GENERIC_HMENU*    hm /* [out] hmenu hm  */
                          )
       {
        SIZE_T menuId = SIZE_T_NPOS;
        RCODE res = getMenuId( menuName, &menuId );
        if (res) return res;
        return createMenuById( menuId, dontShowAccels, hm );
       }

    CLIMETHOD(createMenuById) (THIS_ SIZE_T    menuId /* [in] size_t  menuId  */
                                   , BOOL    dontShowAccels /* [in] bool  dontShowAccels  */
                                   , GENERIC_HMENU*    hm /* [out] hmenu hm  */
                              )
       {
        if (menuId==SIZE_T_NPOS) return EC_COMMAND_UNKNOWN;
        if (!isMenuId(menuId)) return EC_COMMAND_UNKNOWN;

        CLI_SCOPED_LOCK(cs);
        HMENU hMenu = 0;
        CMenuInfo *pMenuInfo = 0;
        RCODE res = createMenuImpl( &hMenu, menuId, (dontShowAccels ? true : false), &pMenuInfo );
        if (res)
           return res;

        res = fillMenu( hMenu, menuId, (dontShowAccels ? true : false), pMenuInfo );
        if (hm) *hm = (GENERIC_HMENU)hMenu;
        return res;
       }

protected:
    // remove all items including submenus
    void clearMenu( HMENU hMenu )
       {
        int numItems = ::GetMenuItemCount( hMenu );
        while(numItems)
           {
            UINT itemFlags = ::GetMenuState( hMenu, 0, MF_BYPOSITION);
            if (itemFlags&MF_POPUP)
               { // destroy submenu
                MENUITEMINFO mii = { 0 };
                mii.cbSize = sizeof(mii);
                mii.fMask  = MIIM_SUBMENU;
                if (::GetMenuItemInfo( hMenu, 0, TRUE, &mii) && mii.hSubMenu)
                   {
                    destroyMenu( (GENERIC_HMENU)mii.hSubMenu, TRUE );
                   }
               }
            ::DeleteMenu( hMenu, 0, MF_BYPOSITION );
            numItems = ::GetMenuItemCount( hMenu );
           }
       }

    RCODE updateMenuObjects( SIZE_T menuId )
       {
        CMenuInfo *pMenuInfo = getMenuInfo( menuId );
        if (!pMenuInfo) return EC_UNKNOWN;

        ::std::set<GENERIC_HMENU> menusCreated       = pMenuInfo->menusCreated; // make copy
        ::std::set<GENERIC_HMENU>::const_iterator it = menusCreated.begin();
        for(; it!=menusCreated.end(); ++it)
           {
            GENERIC_HMENU gmenu = *it;
            ::std::map< GENERIC_HMENU , CHmenuInfo>::const_iterator git = createdMenus.find(gmenu);
            if (git==createdMenus.end()) continue; // not found in global info
            bool noAccelText = git->second.noAccelText;

            HMENU hmenu = (HMENU)gmenu;
            clearMenu( hmenu );

            fillMenu( hmenu, menuId, noAccelText, pMenuInfo );
           }
        return EC_OK;
       }

public:

    CLIMETHOD(destroyMenu) (THIS_ GENERIC_HMENU    hm /* [in] hmenu  hm  */
                                , BOOL    bFull /* [in] bool  bFull  */
                           )
       {
        CLI_SCOPED_LOCK(cs);

        ::std::map< GENERIC_HMENU, CHmenuInfo>::iterator createdMenusIt = createdMenus.find(hm);
        if (createdMenusIt==createdMenus.end()) return EC_OK; // not our menu

        //SIZE_T menuId = createdMenusIt->second.menuId;

        CMenuInfo *pMenuInfo = getMenuInfo( createdMenusIt->second.menuId );
        createdMenus.erase(createdMenusIt);
        if (!pMenuInfo) 
           {
            //createdMenus.erase(createdMenusIt);
            return EC_UNKNOWN;
           }

        ::std::set<GENERIC_HMENU>::iterator mcIt = pMenuInfo->menusCreated.find(hm);
        if (mcIt!=pMenuInfo->menusCreated.end()) pMenuInfo->menusCreated.erase(mcIt);

        if (!bFull) return EC_OK;

        clearMenu( (HMENU)hm );

        ::DestroyMenu( (HMENU)hm );

        return EC_OK;
       }


    // WinAPI implementation specific methods
    // Not the part of the interface

    BOOL translateMessage(MSG* pMsg)
       {
        if (pMsg->message!=WM_COMMAND)  return FALSE;
        //if (pMsg->hwnd!=hWndMainWindow) return FALSE;
        WORD itemId = LOWORD(pMsg->wParam);

        SIZE_T cmdIdx = SIZE_T_NPOS;

        {
         CLI_SCOPED_LOCK(cs);
         ::std::map< WORD, CCommandShortNameInfo >::const_iterator it = idToCommand.find(itemId);
         if (it==idToCommand.end()) return FALSE;
         cmdIdx = it->second.commandIndex;
        }

        //it->commandIndex
        RCODE res = invokeById( cmdIdx );
        #ifdef _DEBUG
        if (res) ::cli::format::cli_log::message( L"invokeById - Error: %2", ::cli::format::arg( res ) );
        #endif

        return TRUE;
       }

    LRESULT translateOnCommand(UINT uMsg, WPARAM wParam)
       {
        if (uMsg!=WM_COMMAND) return TRUE;
        WORD itemId = LOWORD(wParam);

        SIZE_T cmdIdx = SIZE_T_NPOS;
        {
         CLI_SCOPED_LOCK(cs);
         ::std::map< WORD, CCommandShortNameInfo >::const_iterator it = idToCommand.find(itemId);
         if (it==idToCommand.end()) return FALSE;
         cmdIdx = it->second.commandIndex;
        }

        //it->commandIndex
        RCODE res = invokeById( cmdIdx );
        #ifdef _DEBUG
        if (res) ::cli::format::cli_log::message( L"invokeById - Error: %2", ::cli::format::arg( res ) );
        #endif

        return 0;
       }

    HMENU createMenu( const WCHAR* menuName, BOOL dontShowAccels )
       {
        GENERIC_HMENU hMenu = 0;
        createMenu( menuName, FALSE, &hMenu );
        return (HMENU)hMenu;
       }


    ACCEL convertAccel( const STRUCT_CLI_GUI_CACCEL &accel, WORD cmd )
       {
        ACCEL accRes;
        accRes.fVirt = 0;

        if (accel.flags&CLI_GUI_EACCELFLAGS_FVIRTKEY)   accRes.fVirt |= FVIRTKEY;
        if (accel.flags&CLI_GUI_EACCELFLAGS_FSHIFT)     accRes.fVirt |= FSHIFT;
        if (accel.flags&CLI_GUI_EACCELFLAGS_FCONTROL)   accRes.fVirt |= FCONTROL;
        if (accel.flags&CLI_GUI_EACCELFLAGS_FALT)       accRes.fVirt |= FALT;
        if (!(accel.flags&CLI_GUI_EACCELFLAGS_FINVERT)) accRes.fVirt |= FNOINVERT;

        accRes.key = accel.key;
        accRes.cmd = cmd;
        //accRes.pad = 0;

        return accRes;
       }
    

    HACCEL createAcceleratorTable( BOOL addHiddenCommands )
       {
        ::std::vector< ACCEL > winAccels;

        CLI_SCOPED_LOCK(cs);
        ::std::vector< CCommandInfo >::const_iterator cmdIt = commands.begin();
        for(; cmdIt!=commands.end(); ++cmdIt)
           {
            if ((cmdIt->stateFlags&CLI_GUI_EMENUITEMFLAGS_FHIDDEN) && !addHiddenCommands) continue;
            ::std::vector<STRUCT_CLI_GUI_CACCEL>::const_iterator acIt = cmdIt->accels.begin();
            for(; acIt!=cmdIt->accels.end(); ++acIt)
               {
                winAccels.push_back( convertAccel(*acIt, cmdIt->cmdSysId) );
               }
           }

        if (winAccels.empty())
           return (HACCEL)0;

        return ::CreateAcceleratorTable( &winAccels[0], (int)winAccels.size() );
       }

    BOOL destroyAcceleratorTable( HACCEL hAccel )
       {
        return ::DestroyAcceleratorTable(hAccel);
       }

    CLIMETHOD(getCommandBySysIdInfoText) (THIS_ WORD   sysId /* [in] size_t  cmdId  */
                                           , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                           , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                      )
       {
        SIZE_T cmdId = SIZE_T_NPOS;
         {
          CLI_SCOPED_LOCK(cs);  
          ::std::map< WORD, CCommandShortNameInfo >::const_iterator it = idToCommand.find(sysId);
          if (it==idToCommand.end())
             {
              if (infoTextBuf && bufSize) infoTextBuf[0] = 0;
              return EC_COMMAND_UNKNOWN;
             }
          cmdId = it->second.commandIndex;
         }
        return getCommandByIdInfoText( cmdId, infoTextBuf, bufSize );
       }

    CLIMETHOD(getMenuItemInfoTextOnMenuSelect) (THIS_ WPARAM wParam
                                               , LPARAM lParam
                                               , WCHAR*    infoTextBuf /* [out,flat,optional] wchar infoTextBuf  */
                                               , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                               )
       {
        WORD wFlags = HIWORD(wParam);
        if (!(wFlags & MF_POPUP))
           {
            WORD wID = LOWORD(wParam);
            if (getCommandBySysIdInfoText( wID, infoTextBuf, bufSize ))
               {
                if (infoTextBuf && bufSize) infoTextBuf[0] = 0;
                return EC_COMMAND_UNKNOWN;
               }
           }
        else
           { // popup menu
            WORD itemNo = LOWORD(wParam);
            HMENU hMainMenu = (HMENU)lParam;
            HMENU hSubMenu = ::GetSubMenu( hMainMenu, itemNo );

            SIZE_T menuId = SIZE_T_NPOS;
            if (  getMenuIdByHandle((GENERIC_HMENU)hSubMenu, &menuId) 
               || getMenuByIdInfoText( menuId, infoTextBuf, bufSize )
               )
               {
                if (infoTextBuf && bufSize) infoTextBuf[0] = 0;
                return EC_COMMAND_UNKNOWN;
               }
           }
        return EC_OK;
       }



}; // CMenuBuilderImplBase
























//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
inline
void CCommandInfo::loadText()
   {
    itemText = pOwnerBuilder->findCommandText(rcModuleName, commandName);
   }

//-----------------------------------------------------------------------------
inline
void CCommandInfo::loadInfo()
   {
    itemInfo = pOwnerBuilder->findCommandInfo(rcModuleName, commandName);
   }

//-----------------------------------------------------------------------------
inline
CCommandInfo::CCommandInfo( CMenuBuilderImplBase *pown)
   : CCommandInfo::base_impl()
   , pOwnerBuilder(pown)
   , cmdSysId(0) 
   , menus()
   {}

inline
CCommandInfo::CCommandInfo( const CCommandInfo &ci)
   : CCommandInfo::base_impl(ci)
   , pOwnerBuilder(ci.pOwnerBuilder)
   , cmdSysId(ci.cmdSysId) 
   , menus(ci.menus)
   {}

inline
CCommandInfo& CCommandInfo::operator=( const CCommandInfo &ci)
   {
    if (this==&ci) return *this;
    CCommandInfo::base_impl::operator=(ci);
    pOwnerBuilder = ci.pOwnerBuilder;
    cmdSysId = ci.cmdSysId;
    menus = ci.menus;
    return *this;
   }

inline
std::wstring CCommandInfo::makeAccelText(const STRUCT_CLI_GUI_CACCEL &accel)
   {
    using namespace ::cli::gui::EAccelFlags;
    // Ctrl+Alt+Shift+'X'
    std::wstring res;
    if (accel.flags&fControl) res = L"Ctrl";
    if (accel.flags&fAlt)
       {
        if (!res.empty()) res.append(1, L'+');
        res.append(L"Alt");
       }
    if (accel.flags&fShift)
       {
        if (!res.empty()) res.append(1, L'+');
        res.append(L"Shift");
       }
    if (!res.empty()) res.append(1, L'+');

    switch(accel.key)
       {
        case CLI_EVK_BACK   :  res.append(L"Backspace"); break;     case CLI_EVK_TAB    :  res.append(L"Tab"); break;
        //case CLI_EVK_CLEAR:  res.append(L"Unknown"); break;
        case CLI_EVK_RET    :  res.append(L"Enter"); break;         case CLI_EVK_PAUSE  :  res.append(L"Pause"); break;
        case CLI_EVK_CAPITAL:  res.append(L"Caps Lock"); break;     case CLI_EVK_ESCAPE :  res.append(L"Esc"); break;
        case CLI_EVK_SPACE  :  res.append(L"Space"); break;         case CLI_EVK_NUMLOCK:  res.append(L"Numlock"); break;
        case CLI_EVK_SCROLL :  res.append(L"Scroll Lock"); break;   case CLI_EVK_NEXT   :  res.append(L"Page Down"); break;
        case CLI_EVK_PRIOR  :  res.append(L"Page Up"); break;       case CLI_EVK_END    :  res.append(L"End"); break;
        case CLI_EVK_HOME   :  res.append(L"Home"); break;          case CLI_EVK_LEFT   :  res.append(L"Left"); break;
        case CLI_EVK_UP     :  res.append(L"Up"); break;            case CLI_EVK_RIGHT  :  res.append(L"Right"); break;
        case CLI_EVK_DOWN   :  res.append(L"Down"); break;

        case CLI_EVK_SLEEP :  res.append(L"Sleep"); break;
        //case CLI_EVK_SELECT :  res.append(L""); break;
        //case CLI_EVK_PRINT  :  res.append(L""); break;
        //case CLI_EVK_EXECUTE:  res.append(L""); break;
        case CLI_EVK_SNAPSHOT:  res.append(L"Print Screen"); break; case CLI_EVK_INS  :  res.append(L"Ins"); break;
        case CLI_EVK_DEL     :  res.append(L"Del"); break;
        //case CLI_EVK_HELP    :  res.append(L""); break;
        case CLI_EVK_LWIN    :  res.append(L"Left Win"); break;     case CLI_EVK_RWIN    :  res.append(L"Right Win"); break;
        //case CLI_EVK_APPS    :  res.append(L""); break;
        case CLI_EVK_NUMPAD0:  res.append(L"Numpad 0"); break;      case CLI_EVK_NUMPAD1:  res.append(L"Numpad 1"); break;
        case CLI_EVK_NUMPAD2:  res.append(L"Numpad 2"); break;      case CLI_EVK_NUMPAD3:  res.append(L"Numpad 3"); break;
        case CLI_EVK_NUMPAD4:  res.append(L"Numpad 4"); break;      case CLI_EVK_NUMPAD5:  res.append(L"Numpad 5"); break;
        case CLI_EVK_NUMPAD6:  res.append(L"Numpad 6"); break;      case CLI_EVK_NUMPAD7:  res.append(L"Numpad 7"); break;
        case CLI_EVK_NUMPAD8:  res.append(L"Numpad 8"); break;      case CLI_EVK_NUMPAD9:  res.append(L"Numpad 9"); break;
        case CLI_EVK_MULTIPLY :  res.append(L"Numpad *"); break;    case CLI_EVK_ADD      :  res.append(L"Numpad +"); break;
        case CLI_EVK_SUBTRACT :  res.append(L"Numpad -"); break;    case CLI_EVK_DECIMAL  :  res.append(L"Numpad ."); break;
        case CLI_EVK_DIVIDE   :  res.append(L"Numpad /"); break;
        case CLI_EVK_SEPARATOR:  res.append(L"\\"); break;

        case CLI_EVK_F1 : res.append(L"F1"); break;  case CLI_EVK_F2 : res.append(L"F2"); break;  case CLI_EVK_F3 : res.append(L"F3"); break;
        case CLI_EVK_F4 : res.append(L"F4"); break;  case CLI_EVK_F5 : res.append(L"F5"); break;  case CLI_EVK_F6 : res.append(L"F6"); break;
        case CLI_EVK_F7 : res.append(L"F7"); break;  case CLI_EVK_F8 : res.append(L"F8"); break;  case CLI_EVK_F9 : res.append(L"F9"); break;
        case CLI_EVK_F10: res.append(L"F10"); break; case CLI_EVK_F11: res.append(L"F11"); break; case CLI_EVK_F12: res.append(L"F12"); break;
        case CLI_EVK_F13: res.append(L"F13"); break; case CLI_EVK_F14: res.append(L"F14"); break; case CLI_EVK_F15: res.append(L"F15"); break;
        case CLI_EVK_F16: res.append(L"F16"); break; case CLI_EVK_F17: res.append(L"F17"); break; case CLI_EVK_F18: res.append(L"F18"); break;
        case CLI_EVK_F19: res.append(L"F19"); break; case CLI_EVK_F20: res.append(L"F20"); break; case CLI_EVK_F21: res.append(L"F21"); break;
        case CLI_EVK_F22: res.append(L"F22"); break; case CLI_EVK_F23: res.append(L"F23"); break; case CLI_EVK_F24: res.append(L"F24"); break;

        //case    :  res.append(L""); break;

        default: res.append(1, (WCHAR)accel.key); break;
       }
        /*
        #if(_WIN32_WINNT >= 0x0500)
        #define VK_BROWSER_BACK        0xA6
        #define VK_BROWSER_FORWARD     0xA7
        #define VK_BROWSER_REFRESH     0xA8
        #define VK_BROWSER_STOP        0xA9
        #define VK_BROWSER_SEARCH      0xAA
        #define VK_BROWSER_FAVORITES   0xAB
        #define VK_BROWSER_HOME        0xAC
        
        #define VK_VOLUME_MUTE         0xAD
        #define VK_VOLUME_DOWN         0xAE
        #define VK_VOLUME_UP           0xAF
        #define VK_MEDIA_NEXT_TRACK    0xB0
        #define VK_MEDIA_PREV_TRACK    0xB1
        #define VK_MEDIA_STOP          0xB2
        #define VK_MEDIA_PLAY_PAUSE    0xB3
        #define VK_LAUNCH_MAIL         0xB4
        #define VK_LAUNCH_MEDIA_SELECT 0xB5
        #define VK_LAUNCH_APP1         0xB6
        #define VK_LAUNCH_APP2         0xB7
        
        #endif
        */

    return res;
   }





}; // namespace cli
}; // namespace gui
}; // namespace impl
}; // namespace win





#endif /* CLI_GUI_WIN_MENUBUILBERIMPL_H */

