#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_ICOMMAND_H
#define CLI_GUI_ICOMMAND_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/iCommand.h>", CLI_GUI_ICOMMAND_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_ICOMMAND_H
    #include <cli/gui/iCommand.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iCommand */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iArgList;
        #ifndef INTERFACE_CLI_IARGLIST
            #define INTERFACE_CLI_IARGLIST            ::cli::iArgList
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace app {
            interface                                iConfig;
            #ifndef INTERFACE_CLI_APP_ICONFIG
                #define INTERFACE_CLI_APP_ICONFIG         ::cli::app::iConfig
            #endif

        }; // namespace app
    }; // namespace cli
    namespace cli {
        namespace gui {
            interface                                iMenuBuilder;
            #ifndef INTERFACE_CLI_GUI_IMENUBUILDER
                #define INTERFACE_CLI_GUI_IMENUBUILDER    ::cli::gui::iMenuBuilder
            #endif

        }; // namespace gui
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IARGLIST_PREDECLARED
    #define INTERFACE_CLI_IARGLIST_PREDECLARED
    typedef interface tag_cli_iArgList       cli_iArgList;
    #endif //INTERFACE_CLI_IARGLIST
    #ifndef INTERFACE_CLI_IARGLIST
        #define INTERFACE_CLI_IARGLIST            struct tag_cli_iArgList
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_APP_ICONFIG_PREDECLARED
    #define INTERFACE_CLI_APP_ICONFIG_PREDECLARED
    typedef interface tag_cli_app_iConfig    cli_app_iConfig;
    #endif //INTERFACE_CLI_APP_ICONFIG
    #ifndef INTERFACE_CLI_APP_ICONFIG
        #define INTERFACE_CLI_APP_ICONFIG         struct tag_cli_app_iConfig
    #endif

    #ifndef INTERFACE_CLI_GUI_IMENUBUILDER_PREDECLARED
    #define INTERFACE_CLI_GUI_IMENUBUILDER_PREDECLARED
    typedef interface tag_cli_gui_iMenuBuilder                   cli_gui_iMenuBuilder;
    #endif //INTERFACE_CLI_GUI_IMENUBUILDER
    #ifndef INTERFACE_CLI_GUI_IMENUBUILDER
        #define INTERFACE_CLI_GUI_IMENUBUILDER    struct tag_cli_gui_iMenuBuilder
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_ICOMMAND_IID
    #define INTERFACE_CLI_GUI_ICOMMAND_IID    "/cli/gui/iCommand"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iCommand
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_ICOMMAND
       #define INTERFACE_CLI_GUI_ICOMMAND    ::cli::gui::iCommand
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iCommand
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_ICOMMAND
       #define INTERFACE_CLI_GUI_ICOMMAND    cli_gui_iCommand
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iCommand methods */
                CLIMETHOD(commandHandler) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                               , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                               , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                               , INTERFACE_CLI_IUNKNOWN*    pUnkAppData /* [in,optional] ::cli::iUnknown*  pUnkAppData  */
                                               , const VOID*    pvData /* [in,optional] void*  pvData  */
                                               , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                          ) PURE;
                CLIMETHOD(syncItemUiState) (THIS_ const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                                , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                                , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                                , INTERFACE_CLI_IUNKNOWN*    pUnkAppData /* [in,optional] ::cli::iUnknown*  pUnkAppData  */
                                                , const VOID*    pvData /* [in,optional] void*  pvData  */
                                                , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                           ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iCommand >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_ICOMMAND_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iCommand* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iCommand > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iCommand wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_ICOMMAND >
                                          */
                     >
            class CiCommandWrapper
            {
                public:
            
                    typedef  CiCommandWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiCommandWrapper() :
                       pif(0) {}
            
                    CiCommandWrapper( iCommand *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiCommandWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiCommandWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiCommandWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiCommandWrapper(const CiCommandWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiCommandWrapper()  { }
            
                    CiCommandWrapper& operator=(const CiCommandWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE commandHandler( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                        , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                        , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                        , INTERFACE_CLI_IUNKNOWN*    pUnkAppData /* [in,optional] ::cli::iUnknown*  pUnkAppData  */
                                        , const VOID*    pvData /* [in,optional] void*  pvData  */
                                        , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                        )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->commandHandler(cmdName, pMenuBuilder, appConfig, pUnkAppData, pvData, pArgs);
                       }
                    
                    RCODE syncItemUiState( const WCHAR*    cmdName /* [in,flat] wchar  cmdName[]  */
                                         , INTERFACE_CLI_GUI_IMENUBUILDER*    pMenuBuilder /* [in,optional] ::cli::gui::iMenuBuilder*  pMenuBuilder  */
                                         , INTERFACE_CLI_APP_ICONFIG*    appConfig /* [in,optional] ::cli::app::iConfig*  appConfig  */
                                         , INTERFACE_CLI_IUNKNOWN*    pUnkAppData /* [in,optional] ::cli::iUnknown*  pUnkAppData  */
                                         , const VOID*    pvData /* [in,optional] void*  pvData  */
                                         , INTERFACE_CLI_IARGLIST*    pArgs /* [in,optional] ::cli::iArgList*  pArgs  */
                                         )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->syncItemUiState(cmdName, pMenuBuilder, appConfig, pUnkAppData, pvData, pArgs);
                       }
                    

            
            
            }; // class CiCommandWrapper
            
            typedef CiCommandWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_ICOMMAND     > >  CiCommand;
            typedef CiCommandWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_ICOMMAND > >  CiCommand_nrc; /* No ref counting for interface used */
            typedef CiCommandWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_ICOMMAND > >  CiCommand_tmp; /* for temporary usage, same as CiCommand_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif





#endif /* CLI_GUI_ICOMMAND_H */
