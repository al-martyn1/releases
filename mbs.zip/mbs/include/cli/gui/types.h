#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_GUI_TYPES_H
#define CLI_GUI_TYPES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/types.h>", CLI_GUI_TYPES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::gui::EMiceClickFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_EMICECLICKFLAGS        UINT
#else
    #define ENUM_CLI_GUI_EMICECLICKFLAGS        UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONDOWN
    #define CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONDOWN            CONSTANT_UINT(0001)
#endif /* CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONDOWN */

#ifndef CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONUP
    #define CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONUP              CONSTANT_UINT(0002)
#endif /* CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONUP */

#ifndef CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONCLICKFLAG
    #define CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONCLICKFLAG       CONSTANT_UINT(0004)
#endif /* CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONCLICKFLAG */

#ifndef CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONDBLFLAG
    #define CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONDBLFLAG         CONSTANT_UINT(0001)
#endif /* CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONDBLFLAG */

#ifndef CLI_GUI_EMICECLICKFLAGS_LEFTCLICK
    #define CLI_GUI_EMICECLICKFLAGS_LEFTCLICK                 CONSTANT_UINT(0004)
#endif /* CLI_GUI_EMICECLICKFLAGS_LEFTCLICK */

#ifndef CLI_GUI_EMICECLICKFLAGS_LEFTDBLCLICK
    #define CLI_GUI_EMICECLICKFLAGS_LEFTDBLCLICK              CONSTANT_UINT(0005)
#endif /* CLI_GUI_EMICECLICKFLAGS_LEFTDBLCLICK */

#ifndef CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONDOWN
    #define CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONDOWN           CONSTANT_UINT(0010)
#endif /* CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONDOWN */

#ifndef CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONUP
    #define CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONUP             CONSTANT_UINT(0020)
#endif /* CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONUP */

#ifndef CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONCLICKFLAG
    #define CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONCLICKFLAG      CONSTANT_UINT(0040)
#endif /* CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONCLICKFLAG */

#ifndef CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONDBLFLAG
    #define CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONDBLFLAG        CONSTANT_UINT(0010)
#endif /* CLI_GUI_EMICECLICKFLAGS_RIGHTBUTTONDBLFLAG */

#ifndef CLI_GUI_EMICECLICKFLAGS_RIGHTCLICK
    #define CLI_GUI_EMICECLICKFLAGS_RIGHTCLICK                CONSTANT_UINT(0040)
#endif /* CLI_GUI_EMICECLICKFLAGS_RIGHTCLICK */

#ifndef CLI_GUI_EMICECLICKFLAGS_RIGHTDBLCLICK
    #define CLI_GUI_EMICECLICKFLAGS_RIGHTDBLCLICK             CONSTANT_UINT(0050)
#endif /* CLI_GUI_EMICECLICKFLAGS_RIGHTDBLCLICK */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONDOWN
    #define CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONDOWN          CONSTANT_UINT(0100)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONDOWN */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDBUTTONDOWN
    #define CLI_GUI_EMICECLICKFLAGS_MIDBUTTONDOWN             CONSTANT_UINT(0100)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDBUTTONDOWN */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONUP
    #define CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONUP            CONSTANT_UINT(0200)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONUP */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDBUTTONUP
    #define CLI_GUI_EMICECLICKFLAGS_MIDBUTTONUP               CONSTANT_UINT(0200)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDBUTTONUP */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONCLICKFLAG
    #define CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONCLICKFLAG     CONSTANT_UINT(0400)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONCLICKFLAG */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDBUTTONCLICKFLAG
    #define CLI_GUI_EMICECLICKFLAGS_MIDBUTTONCLICKFLAG        CONSTANT_UINT(0400)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDBUTTONCLICKFLAG */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONDBLFLAG
    #define CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONDBLFLAG       CONSTANT_UINT(0100)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDDLEBUTTONDBLFLAG */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDBUTTONDBLFLAG
    #define CLI_GUI_EMICECLICKFLAGS_MIDBUTTONDBLFLAG          CONSTANT_UINT(0100)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDBUTTONDBLFLAG */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDDLECLICK
    #define CLI_GUI_EMICECLICKFLAGS_MIDDLECLICK               CONSTANT_UINT(0400)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDDLECLICK */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDCLICK
    #define CLI_GUI_EMICECLICKFLAGS_MIDCLICK  CONSTANT_UINT(0400)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDCLICK */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDDLEDBLCLICK
    #define CLI_GUI_EMICECLICKFLAGS_MIDDLEDBLCLICK            CONSTANT_UINT(0500)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDDLEDBLCLICK */

#ifndef CLI_GUI_EMICECLICKFLAGS_MIDDBLCLICK
    #define CLI_GUI_EMICECLICKFLAGS_MIDDBLCLICK               CONSTANT_UINT(0500)
#endif /* CLI_GUI_EMICECLICKFLAGS_MIDDBLCLICK */

#ifndef CLI_GUI_EMICECLICKFLAGS_FLEFTBUTTONEVENT
    #define CLI_GUI_EMICECLICKFLAGS_FLEFTBUTTONEVENT          CONSTANT_UINT(0007)
#endif /* CLI_GUI_EMICECLICKFLAGS_FLEFTBUTTONEVENT */

#ifndef CLI_GUI_EMICECLICKFLAGS_FRIGHTBUTTONEVENT
    #define CLI_GUI_EMICECLICKFLAGS_FRIGHTBUTTONEVENT         CONSTANT_UINT(0070)
#endif /* CLI_GUI_EMICECLICKFLAGS_FRIGHTBUTTONEVENT */

#ifndef CLI_GUI_EMICECLICKFLAGS_FMIDDLEBUTTONEVENT
    #define CLI_GUI_EMICECLICKFLAGS_FMIDDLEBUTTONEVENT        CONSTANT_UINT(0700)
#endif /* CLI_GUI_EMICECLICKFLAGS_FMIDDLEBUTTONEVENT */

#ifndef CLI_GUI_EMICECLICKFLAGS_FMIDBUTTONEVENT
    #define CLI_GUI_EMICECLICKFLAGS_FMIDBUTTONEVENT           CONSTANT_UINT(0700)
#endif /* CLI_GUI_EMICECLICKFLAGS_FMIDBUTTONEVENT */

#ifndef CLI_GUI_EMICECLICKFLAGS_FMICECLICKFLAGSMASK
    #define CLI_GUI_EMICECLICKFLAGS_FMICECLICKFLAGSMASK       CONSTANT_UINT(0777)
#endif /* CLI_GUI_EMICECLICKFLAGS_FMICECLICKFLAGSMASK */

#ifndef CLI_GUI_EMICECLICKFLAGS_FMICEFLAGSMASK
    #define CLI_GUI_EMICECLICKFLAGS_FMICEFLAGSMASK            CONSTANT_UINT(0777)
#endif /* CLI_GUI_EMICECLICKFLAGS_FMICEFLAGSMASK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace EMiceClickFlags {
                    const UINT leftButtonDown   = CONSTANT_UINT(0001);
                    const UINT leftButtonUp     = CONSTANT_UINT(0002);
                    const UINT leftButtonClickFlag      = CONSTANT_UINT(0004);
                    const UINT leftButtonDblFlag        = CONSTANT_UINT(0001);
                    const UINT leftClick        = CONSTANT_UINT(0004);
                    const UINT leftDblClick     = CONSTANT_UINT(0005);
                    const UINT rightButtonDown  = CONSTANT_UINT(0010);
                    const UINT rightButtonUp    = CONSTANT_UINT(0020);
                    const UINT rightButtonClickFlag     = CONSTANT_UINT(0040);
                    const UINT rightButtonDblFlag       = CONSTANT_UINT(0010);
                    const UINT rightClick       = CONSTANT_UINT(0040);
                    const UINT rightDblClick    = CONSTANT_UINT(0050);
                    const UINT middleButtonDown = CONSTANT_UINT(0100);
                    const UINT midButtonDown    = CONSTANT_UINT(0100);
                    const UINT middleButtonUp   = CONSTANT_UINT(0200);
                    const UINT midButtonUp      = CONSTANT_UINT(0200);
                    const UINT middleButtonClickFlag    = CONSTANT_UINT(0400);
                    const UINT midButtonClickFlag       = CONSTANT_UINT(0400);
                    const UINT middleButtonDblFlag      = CONSTANT_UINT(0100);
                    const UINT midButtonDblFlag = CONSTANT_UINT(0100);
                    const UINT middleClick      = CONSTANT_UINT(0400);
                    const UINT midClick         = CONSTANT_UINT(0400);
                    const UINT middleDblClick   = CONSTANT_UINT(0500);
                    const UINT midDblClick      = CONSTANT_UINT(0500);
                    const UINT fLeftButtonEvent = CONSTANT_UINT(0007);
                    const UINT fRightButtonEvent        = CONSTANT_UINT(0070);
                    const UINT fMiddleButtonEvent       = CONSTANT_UINT(0700);
                    const UINT fMidButtonEvent  = CONSTANT_UINT(0700);
                    const UINT fMiceClickFlagsMask      = CONSTANT_UINT(0777);
                    const UINT fMiceFlagsMask   = CONSTANT_UINT(0777);
            }; // namespace EMiceClickFlags
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::EMiceClickFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::EMiceButtonState */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_EMICEBUTTONSTATE       BYTE
#else
    #define ENUM_CLI_GUI_EMICEBUTTONSTATE       BYTE
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_EMICEBUTTONSTATE_FSTATECHANGED
    #define CLI_GUI_EMICEBUTTONSTATE_FSTATECHANGED            CONSTANT_BYTE(0x01)
#endif /* CLI_GUI_EMICEBUTTONSTATE_FSTATECHANGED */

#ifndef CLI_GUI_EMICEBUTTONSTATE_FDOWN
    #define CLI_GUI_EMICEBUTTONSTATE_FDOWN    CONSTANT_BYTE(0x02)
#endif /* CLI_GUI_EMICEBUTTONSTATE_FDOWN */

#ifndef CLI_GUI_EMICEBUTTONSTATE_FCLICK
    #define CLI_GUI_EMICEBUTTONSTATE_FCLICK   CONSTANT_BYTE(0x04)
#endif /* CLI_GUI_EMICEBUTTONSTATE_FCLICK */

#ifndef CLI_GUI_EMICEBUTTONSTATE_FDOUBLE
    #define CLI_GUI_EMICEBUTTONSTATE_FDOUBLE  CONSTANT_BYTE(0x08)
#endif /* CLI_GUI_EMICEBUTTONSTATE_FDOUBLE */

#ifndef CLI_GUI_EMICEBUTTONSTATE_CLEAR
    #define CLI_GUI_EMICEBUTTONSTATE_CLEAR    CONSTANT_BYTE(0x00)
#endif /* CLI_GUI_EMICEBUTTONSTATE_CLEAR */

#ifndef CLI_GUI_EMICEBUTTONSTATE_DOWN
    #define CLI_GUI_EMICEBUTTONSTATE_DOWN     CONSTANT_BYTE(0x03)
#endif /* CLI_GUI_EMICEBUTTONSTATE_DOWN */

#ifndef CLI_GUI_EMICEBUTTONSTATE_UP
    #define CLI_GUI_EMICEBUTTONSTATE_UP       CONSTANT_BYTE(0x01)
#endif /* CLI_GUI_EMICEBUTTONSTATE_UP */

#ifndef CLI_GUI_EMICEBUTTONSTATE_CLICK
    #define CLI_GUI_EMICEBUTTONSTATE_CLICK    CONSTANT_BYTE(0x05)
#endif /* CLI_GUI_EMICEBUTTONSTATE_CLICK */

#ifndef CLI_GUI_EMICEBUTTONSTATE_DBLCLICK
    #define CLI_GUI_EMICEBUTTONSTATE_DBLCLICK                 CONSTANT_BYTE(0x0D)
#endif /* CLI_GUI_EMICEBUTTONSTATE_DBLCLICK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace EMiceButtonState {
                    const BYTE fStateChanged    = CONSTANT_BYTE(0x01);
                    const BYTE fDown            = CONSTANT_BYTE(0x02);
                    const BYTE fClick           = CONSTANT_BYTE(0x04);
                    const BYTE fDouble          = CONSTANT_BYTE(0x08);
                    const BYTE clear            = CONSTANT_BYTE(0x00);
                    const BYTE down             = CONSTANT_BYTE(0x03);
                    const BYTE up               = CONSTANT_BYTE(0x01);
                    const BYTE click            = CONSTANT_BYTE(0x05);
                    const BYTE dblClick         = CONSTANT_BYTE(0x0D);
            }; // namespace EMiceButtonState
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::EMiceButtonState; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::EAlignment */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_EALIGNMENT             UINT
#else
    #define ENUM_CLI_GUI_EALIGNMENT             UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_EALIGNMENT_VCENTER
    #define CLI_GUI_EALIGNMENT_VCENTER        CONSTANT_UINT(0x0000)
#endif /* CLI_GUI_EALIGNMENT_VCENTER */

#ifndef CLI_GUI_EALIGNMENT_TOP
    #define CLI_GUI_EALIGNMENT_TOP            CONSTANT_UINT(0x0001)
#endif /* CLI_GUI_EALIGNMENT_TOP */

#ifndef CLI_GUI_EALIGNMENT_BOTTOM
    #define CLI_GUI_EALIGNMENT_BOTTOM         CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_EALIGNMENT_BOTTOM */

#ifndef CLI_GUI_EALIGNMENT_BASELINE
    #define CLI_GUI_EALIGNMENT_BASELINE       CONSTANT_UINT(0x0004)
#endif /* CLI_GUI_EALIGNMENT_BASELINE */

#ifndef CLI_GUI_EALIGNMENT_VUNDEFINED
    #define CLI_GUI_EALIGNMENT_VUNDEFINED     CONSTANT_UINT(0x0008)
#endif /* CLI_GUI_EALIGNMENT_VUNDEFINED */

#ifndef CLI_GUI_EALIGNMENT_VMASK
    #define CLI_GUI_EALIGNMENT_VMASK          CONSTANT_UINT(0x000F)
#endif /* CLI_GUI_EALIGNMENT_VMASK */

#ifndef CLI_GUI_EALIGNMENT_HCENTER
    #define CLI_GUI_EALIGNMENT_HCENTER        CONSTANT_UINT(0x0000)
#endif /* CLI_GUI_EALIGNMENT_HCENTER */

#ifndef CLI_GUI_EALIGNMENT_LEFT
    #define CLI_GUI_EALIGNMENT_LEFT           CONSTANT_UINT(0x0010)
#endif /* CLI_GUI_EALIGNMENT_LEFT */

#ifndef CLI_GUI_EALIGNMENT_RIGHT
    #define CLI_GUI_EALIGNMENT_RIGHT          CONSTANT_UINT(0x0020)
#endif /* CLI_GUI_EALIGNMENT_RIGHT */

#ifndef CLI_GUI_EALIGNMENT_HUNDEFINED
    #define CLI_GUI_EALIGNMENT_HUNDEFINED     CONSTANT_UINT(0x0080)
#endif /* CLI_GUI_EALIGNMENT_HUNDEFINED */

#ifndef CLI_GUI_EALIGNMENT_HMASK
    #define CLI_GUI_EALIGNMENT_HMASK          CONSTANT_UINT(0x00F0)
#endif /* CLI_GUI_EALIGNMENT_HMASK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace EAlignment {
                    const UINT vcenter          = CONSTANT_UINT(0x0000);
                    const UINT top              = CONSTANT_UINT(0x0001);
                    const UINT bottom           = CONSTANT_UINT(0x0002);
                    const UINT baseLine         = CONSTANT_UINT(0x0004);
                    const UINT vUndefined       = CONSTANT_UINT(0x0008);
                    const UINT vMask            = CONSTANT_UINT(0x000F);
                    const UINT hcenter          = CONSTANT_UINT(0x0000);
                    const UINT left             = CONSTANT_UINT(0x0010);
                    const UINT right            = CONSTANT_UINT(0x0020);
                    const UINT hUndefined       = CONSTANT_UINT(0x0080);
                    const UINT hMask            = CONSTANT_UINT(0x00F0);
            }; // namespace EAlignment
        }; // namespace gui
    }; // namespace cli
    /* using namespace ::cli::gui::EAlignment; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::gui::CMiceButtonsState */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
    #define CLI_STRUCT_NAME                   CMiceButtonsState
    #ifndef STRUCT_CLI_GUI_CMICEBUTTONSSTATE_PREDECLARED
    #define STRUCT_CLI_GUI_CMICEBUTTONSSTATE_PREDECLARED
        struct CMiceButtonsState;
        #ifndef STRUCT_CLI_GUI_CMICEBUTTONSSTATE
            #define STRUCT_CLI_GUI_CMICEBUTTONSSTATE  ::cli::gui::CMiceButtonsState
        #endif
    #endif // STRUCT_CLI_GUI_CMICEBUTTONSSTATE_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_gui_CMiceButtonsState
    #ifndef STRUCT_CLI_GUI_CMICEBUTTONSSTATE_PREDECLARED
    #define STRUCT_CLI_GUI_CMICEBUTTONSSTATE_PREDECLARED
        struct  tag_cli_gui_CMiceButtonsState;
        typedef struct tag_cli_gui_CMiceButtonsState cli_gui_CMiceButtonsState;
        #ifndef STRUCT_CLI_GUI_CMICEBUTTONSSTATE
            #define STRUCT_CLI_GUI_CMICEBUTTONSSTATE  struct tag_cli_gui_CMiceButtonsState
        #endif
    #endif // STRUCT_CLI_GUI_CMICEBUTTONSSTATE_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_GUI_CMICEBUTTONSSTATE_DEFINED
            #define STRUCT_CLI_GUI_CMICEBUTTONSSTATE_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                ENUM_CLI_GUI_EMICEBUTTONSTATE           left;
                ENUM_CLI_GUI_EMICEBUTTONSTATE           right;
                ENUM_CLI_GUI_EMICEBUTTONSTATE           middle;
                ENUM_CLI_GUI_EMICEBUTTONSTATE           reserved;
                ENUM_CLI_GUI_EMICEBUTTONSTATE           alt;
                ENUM_CLI_GUI_EMICEBUTTONSTATE           ctrl;
                ENUM_CLI_GUI_EMICEBUTTONSTATE           shift;
                ENUM_CLI_GUI_EMICEBUTTONSTATE           meta;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_GUI_CMICEBUTTONSSTATE_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::gui::CMiceWheelState */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
    #define CLI_STRUCT_NAME                   CMiceWheelState
    #ifndef STRUCT_CLI_GUI_CMICEWHEELSTATE_PREDECLARED
    #define STRUCT_CLI_GUI_CMICEWHEELSTATE_PREDECLARED
        struct CMiceWheelState;
        #ifndef STRUCT_CLI_GUI_CMICEWHEELSTATE
            #define STRUCT_CLI_GUI_CMICEWHEELSTATE    ::cli::gui::CMiceWheelState
        #endif
    #endif // STRUCT_CLI_GUI_CMICEWHEELSTATE_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_gui_CMiceWheelState
    #ifndef STRUCT_CLI_GUI_CMICEWHEELSTATE_PREDECLARED
    #define STRUCT_CLI_GUI_CMICEWHEELSTATE_PREDECLARED
        struct  tag_cli_gui_CMiceWheelState;
        typedef struct tag_cli_gui_CMiceWheelState cli_gui_CMiceWheelState;
        #ifndef STRUCT_CLI_GUI_CMICEWHEELSTATE
            #define STRUCT_CLI_GUI_CMICEWHEELSTATE    struct tag_cli_gui_CMiceWheelState
        #endif
    #endif // STRUCT_CLI_GUI_CMICEWHEELSTATE_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_GUI_CMICEWHEELSTATE_DEFINED
            #define STRUCT_CLI_GUI_CMICEWHEELSTATE_DEFINED
            #include <cli/pshpack4.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                INT                         distance;
                INT                         delta;
                INT                         lpa;
                INT                         reserved;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_GUI_CMICEWHEELSTATE_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::gui::CSpacing */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
    #define CLI_STRUCT_NAME                   CSpacing
    #ifndef STRUCT_CLI_GUI_CSPACING_PREDECLARED
    #define STRUCT_CLI_GUI_CSPACING_PREDECLARED
        struct CSpacing;
        #ifndef STRUCT_CLI_GUI_CSPACING
            #define STRUCT_CLI_GUI_CSPACING           ::cli::gui::CSpacing
        #endif
        #ifndef STRUCT_CLI_GUI_CMARGINS
            #define STRUCT_CLI_GUI_CMARGINS           ::cli::gui::CMargins
        #endif
        typedef STRUCT_CLI_GUI_CSPACING           CMargins;

    #endif // STRUCT_CLI_GUI_CSPACING_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_gui_CSpacing
    #ifndef STRUCT_CLI_GUI_CSPACING_PREDECLARED
    #define STRUCT_CLI_GUI_CSPACING_PREDECLARED
        struct  tag_cli_gui_CSpacing;
        typedef struct tag_cli_gui_CSpacing cli_gui_CSpacing;
        #ifndef STRUCT_CLI_GUI_CSPACING
            #define STRUCT_CLI_GUI_CSPACING           struct tag_cli_gui_CSpacing
        #endif
        #ifndef STRUCT_CLI_GUI_CMARGINS
            #define STRUCT_CLI_GUI_CMARGINS           cli_gui_CMargins
        #endif
        typedef STRUCT_CLI_GUI_CSPACING           cli_gui_CMargins;

    #endif // STRUCT_CLI_GUI_CSPACING_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_GUI_CSPACING_DEFINED
            #define STRUCT_CLI_GUI_CSPACING_DEFINED
            #include <cli/pshpack4.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                INT                         left;
                INT                         top;
                INT                         right;
                INT                         bottom;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_GUI_CSPACING_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli
#endif

#endif /* CLI_GUI_TYPES_H */
