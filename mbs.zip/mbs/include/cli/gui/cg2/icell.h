#ifndef CLI_GUI_CG2_ICELL_H
#define CLI_GUI_CG2_ICELL_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/cg2/icell.h>", CLI_GUI_CG2_ICELL_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_CG2_ICELL_H
    #include <cli/gui/cg2/icell.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

#ifndef CLI_GUI_CG2_TYPES_H
    #include <cli/gui/cg2/types.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::EVisibilityControledAuto */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO      UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO      UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_NONE
    #define CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_NONE    CONSTANT_UINT(0)
#endif /* CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_NONE */

#ifndef CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_ROW
    #define CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_ROW     1
#endif /* CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_ROW */

#ifndef CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_CELL
    #define CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_CELL    2
#endif /* CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_CELL */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace EVisibilityControledAuto {
                        const UINT none             = CONSTANT_UINT(0);
                        const UINT row              = CONSTANT_UINT(1);
                        const UINT cell             = CONSTANT_UINT(2);
                }; /* namespace EVisibilityControledAuto */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::EVisibilityControledAuto; */
    
#endif





/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iSimpleCell */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; /* namespace cli */
    namespace cli {
        namespace app {
            interface                                iConfig;
            #ifndef INTERFACE_CLI_APP_ICONFIG
                #define INTERFACE_CLI_APP_ICONFIG         ::cli::app::iConfig
            #endif

        }; /* namespace app */
    }; /* namespace cli */
    namespace cli {
        namespace drawing {
            interface                                iDrawContext1;
            #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
                #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               ::cli::drawing::iDrawContext1
            #endif

        }; /* namespace drawing */
    }; /* namespace cli */
    namespace cli {
        namespace gui {
        }; /* namespace gui */
    }; /* namespace cli */
    namespace cli {
        namespace gui {
            namespace cellgrid {
                interface                                iGrid;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
                    #define INTERFACE_CLI_GUI_CELLGRID_IGRID  ::cli::gui::cellgrid::iGrid
                #endif

                interface                                iRow;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
                    #define INTERFACE_CLI_GUI_CELLGRID_IROW   ::cli::gui::cellgrid::iRow
                #endif

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    typedef interface tag_cli_app_iConfig    cli_app_iConfig;
    #ifndef INTERFACE_CLI_APP_ICONFIG
        #define INTERFACE_CLI_APP_ICONFIG         struct tag_cli_app_iConfig
    #endif

    typedef interface tag_cli_drawing_iDrawContext1              cli_drawing_iDrawContext1;
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
        #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               struct tag_cli_drawing_iDrawContext1
    #endif

    typedef interface tag_cli_gui_cellgrid_iGrid                 cli_gui_cellgrid_iGrid;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
        #define INTERFACE_CLI_GUI_CELLGRID_IGRID  struct tag_cli_gui_cellgrid_iGrid
    #endif

    typedef interface tag_cli_gui_cellgrid_iRow                  cli_gui_cellgrid_iRow;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
        #define INTERFACE_CLI_GUI_CELLGRID_IROW   struct tag_cli_gui_cellgrid_iRow
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL_IID
    #define INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL_IID    "/cli/gui/cellgrid/iSimpleCell"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iSimpleCell
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL
       #define INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL    ::cli::gui::cellgrid::iSimpleCell
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iSimpleCell
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL
       #define INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL    cli_gui_cellgrid_iSimpleCell
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iSimpleCell methods */
                    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */) PURE;
                    CLIMETHOD(ownerRowGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* _ownerRow  */) PURE;
                    CLIMETHOD(ownerRowSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  _ownerRow  */) PURE;
                    CLIMETHOD(activeCellGet) (THIS_ BOOL*    _activeCell /* [out] bool _activeCell  */) PURE;
                    CLIMETHOD(activeCellSet) (THIS_ BOOL    _activeCell /* [in] bool  _activeCell  */) PURE;
                    CLIMETHOD(hotTrackedGet) (THIS_ BOOL*    _hotTracked /* [out] bool _hotTracked  */) PURE;
                    CLIMETHOD(hotTrackedSet) (THIS_ BOOL    _hotTracked /* [in] bool  _hotTracked  */) PURE;
                    CLIMETHOD(autoHotTrackGet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack _autoHotTrack  */) PURE;
                    CLIMETHOD(autoHotTrackSet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK    _autoHotTrack /* [in] ::cli::gui::cellgrid::ECellHotTrack  _autoHotTrack  */) PURE;
                    CLIMETHOD(visibleGet) (THIS_ BOOL*    _visible /* [out] bool _visible  */) PURE;
                    CLIMETHOD(visibleSet) (THIS_ BOOL    _visible /* [in] bool  _visible  */) PURE;
                    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _spacing /* [out] ::cli::gui::CSpacing _spacing  */) PURE;
                    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  */) PURE;
                    CLIMETHOD(ncDrawBackgroundGet) (THIS_ BOOL*    _ncDrawBackground /* [out] bool _ncDrawBackground  */) PURE;
                    CLIMETHOD(ncDrawBackgroundSet) (THIS_ BOOL    _ncDrawBackground /* [in] bool  _ncDrawBackground  */) PURE;
                    CLIMETHOD(ncBackgroundColorGet) (THIS_ COLORREF*    _ncBackgroundColor /* [out] colorref _ncBackgroundColor  */) PURE;
                    CLIMETHOD(ncBackgroundColorSet) (THIS_ COLORREF    _ncBackgroundColor /* [in] colorref  _ncBackgroundColor  */) PURE;
                    CLIMETHOD(ncActiveBackgroundColorGet) (THIS_ COLORREF*    _ncActiveBackgroundColor /* [out] colorref _ncActiveBackgroundColor  */) PURE;
                    CLIMETHOD(ncActiveBackgroundColorSet) (THIS_ COLORREF    _ncActiveBackgroundColor /* [in] colorref  _ncActiveBackgroundColor  */) PURE;
                    CLIMETHOD(ncCurrentBackgroundColorGet) (THIS_ COLORREF*    _ncCurrentBackgroundColor /* [out] colorref _ncCurrentBackgroundColor  */) PURE;
                    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool _drawBackground  */) PURE;
                    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  _drawBackground  */) PURE;
                    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */) PURE;
                    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */) PURE;
                    CLIMETHOD(activeBackgroundColorGet) (THIS_ COLORREF*    _activeBackgroundColor /* [out] colorref _activeBackgroundColor  */) PURE;
                    CLIMETHOD(activeBackgroundColorSet) (THIS_ COLORREF    _activeBackgroundColor /* [in] colorref  _activeBackgroundColor  */) PURE;
                    CLIMETHOD(currentBackgroundColorGet) (THIS_ COLORREF*    _currentBackgroundColor /* [out] colorref _currentBackgroundColor  */) PURE;
                    CLIMETHOD(colorGet) (THIS_ COLORREF*    _color /* [out] colorref _color  */) PURE;
                    CLIMETHOD(colorSet) (THIS_ COLORREF    _color /* [in] colorref  _color  */) PURE;
                    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */) PURE;
                    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */) PURE;
                    CLIMETHOD(sizeXGet) (THIS_ INT*    _sizeX /* [out] int _sizeX  */) PURE;
                    CLIMETHOD(sizeXSet) (THIS_ INT    _sizeX /* [in] int  _sizeX  */) PURE;
                    CLIMETHOD(sizeYGet) (THIS_ INT*    _sizeY /* [out] int _sizeY  */) PURE;
                    CLIMETHOD(sizeYSet) (THIS_ INT    _sizeY /* [in] int  _sizeY  */) PURE;
                    CLIMETHOD(minSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [out] ::cli::drawing::CPoint _minSize  */) PURE;
                    CLIMETHOD(minSizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [in,ref] ::cli::drawing::CPoint  _minSize  */) PURE;
                    CLIMETHOD(maxSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [out] ::cli::drawing::CPoint _maxSize  */) PURE;
                    CLIMETHOD(maxSizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [in,ref] ::cli::drawing::CPoint  _maxSize  */) PURE;
                    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                                         ) PURE;
                    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                            ) PURE;
                    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       ) PURE;
                    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(updatePaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                            ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iSimpleCell >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iSimpleCell* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iSimpleCell > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iSimpleCell wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL >
                                              */
                         >
                class CiSimpleCellWrapper
                {
                    public:
                
                        typedef  CiSimpleCellWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiSimpleCellWrapper() :
                           pif(0) {}
                
                        CiSimpleCellWrapper( iSimpleCell *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiSimpleCellWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiSimpleCellWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiSimpleCellWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiSimpleCellWrapper(const CiSimpleCellWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiSimpleCellWrapper()  { }
                
                        CiSimpleCellWrapper& operator=(const CiSimpleCellWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IGRID* get_ownerGrid( )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IGRID* tmpVal;
                            RCODE res = ownerGridGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IGRID*, ownerGrid );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ownerGridGet( INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */)
                           {
                        
                            return pif->ownerGridGet(_ownerGrid);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IROW* get_ownerRow( )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IROW* tmpVal;
                            RCODE res = ownerRowGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ownerRow( INTERFACE_CLI_GUI_CELLGRID_IROW* _ownerRow
                                         )
                           {
                            RCODE res = ownerRowSet( _ownerRow );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IROW*, ownerRow );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ownerRowGet( INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* _ownerRow  */)
                           {
                        
                            return pif->ownerRowGet(_ownerRow);
                           }
                        
                        RCODE ownerRowSet( INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  _ownerRow  */)
                           {
                        
                            return pif->ownerRowSet(_ownerRow);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_activeCell( )
                           {
                            BOOL tmpVal;
                            RCODE res = activeCellGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCell( BOOL _activeCell
                                           )
                           {
                            RCODE res = activeCellSet( _activeCell );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, activeCell );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellGet( BOOL*    _activeCell /* [out] bool _activeCell  */)
                           {
                        
                            return pif->activeCellGet(_activeCell);
                           }
                        
                        RCODE activeCellSet( BOOL    _activeCell /* [in] bool  _activeCell  */)
                           {
                        
                            return pif->activeCellSet(_activeCell);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_hotTracked( )
                           {
                            BOOL tmpVal;
                            RCODE res = hotTrackedGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_hotTracked( BOOL _hotTracked
                                           )
                           {
                            RCODE res = hotTrackedSet( _hotTracked );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, hotTracked );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE hotTrackedGet( BOOL*    _hotTracked /* [out] bool _hotTracked  */)
                           {
                        
                            return pif->hotTrackedGet(_hotTracked);
                           }
                        
                        RCODE hotTrackedSet( BOOL    _hotTracked /* [in] bool  _hotTracked  */)
                           {
                        
                            return pif->hotTrackedSet(_hotTracked);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK get_autoHotTrack( )
                           {
                            ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK tmpVal;
                            RCODE res = autoHotTrackGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_autoHotTrack( ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK _autoHotTrack
                                             )
                           {
                            RCODE res = autoHotTrackSet( _autoHotTrack );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK, autoHotTrack );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE autoHotTrackGet( ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack _autoHotTrack  */)
                           {
                        
                            return pif->autoHotTrackGet(_autoHotTrack);
                           }
                        
                        RCODE autoHotTrackSet( ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK    _autoHotTrack /* [in] ::cli::gui::cellgrid::ECellHotTrack  _autoHotTrack  */)
                           {
                        
                            return pif->autoHotTrackSet(_autoHotTrack);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_visible( )
                           {
                            BOOL tmpVal;
                            RCODE res = visibleGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_visible( BOOL _visible
                                        )
                           {
                            RCODE res = visibleSet( _visible );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, visible );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE visibleGet( BOOL*    _visible /* [out] bool _visible  */)
                           {
                        
                            return pif->visibleGet(_visible);
                           }
                        
                        RCODE visibleSet( BOOL    _visible /* [in] bool  _visible  */)
                           {
                        
                            return pif->visibleSet(_visible);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CSPACING get_spacing( )
                           {
                            STRUCT_CLI_GUI_CSPACING tmpVal;
                            RCODE res = spacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_spacing( const STRUCT_CLI_GUI_CSPACING &_spacing
                                        )
                           {
                            RCODE res = spacingSet( _spacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CSPACING, spacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE spacingGet( STRUCT_CLI_GUI_CSPACING    &_spacing /* [out] ::cli::gui::CSpacing _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingGet(&_spacing);
                           }
                        
                        RCODE spacingSet( const STRUCT_CLI_GUI_CSPACING    &_spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingSet(&_spacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_ncDrawBackground( )
                           {
                            BOOL tmpVal;
                            RCODE res = ncDrawBackgroundGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncDrawBackground( BOOL _ncDrawBackground
                                                 )
                           {
                            RCODE res = ncDrawBackgroundSet( _ncDrawBackground );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, ncDrawBackground );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncDrawBackgroundGet( BOOL*    _ncDrawBackground /* [out] bool _ncDrawBackground  */)
                           {
                        
                            return pif->ncDrawBackgroundGet(_ncDrawBackground);
                           }
                        
                        RCODE ncDrawBackgroundSet( BOOL    _ncDrawBackground /* [in] bool  _ncDrawBackground  */)
                           {
                        
                            return pif->ncDrawBackgroundSet(_ncDrawBackground);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_ncBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = ncBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncBackgroundColor( COLORREF _ncBackgroundColor
                                                  )
                           {
                            RCODE res = ncBackgroundColorSet( _ncBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, ncBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncBackgroundColorGet( COLORREF*    _ncBackgroundColor /* [out] colorref _ncBackgroundColor  */)
                           {
                        
                            return pif->ncBackgroundColorGet(_ncBackgroundColor);
                           }
                        
                        RCODE ncBackgroundColorSet( COLORREF    _ncBackgroundColor /* [in] colorref  _ncBackgroundColor  */)
                           {
                        
                            return pif->ncBackgroundColorSet(_ncBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_ncActiveBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = ncActiveBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncActiveBackgroundColor( COLORREF _ncActiveBackgroundColor
                                                        )
                           {
                            RCODE res = ncActiveBackgroundColorSet( _ncActiveBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, ncActiveBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncActiveBackgroundColorGet( COLORREF*    _ncActiveBackgroundColor /* [out] colorref _ncActiveBackgroundColor  */)
                           {
                        
                            return pif->ncActiveBackgroundColorGet(_ncActiveBackgroundColor);
                           }
                        
                        RCODE ncActiveBackgroundColorSet( COLORREF    _ncActiveBackgroundColor /* [in] colorref  _ncActiveBackgroundColor  */)
                           {
                        
                            return pif->ncActiveBackgroundColorSet(_ncActiveBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_ncCurrentBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = ncCurrentBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, COLORREF, ncCurrentBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncCurrentBackgroundColorGet( COLORREF*    _ncCurrentBackgroundColor /* [out] colorref _ncCurrentBackgroundColor  */)
                           {
                        
                            return pif->ncCurrentBackgroundColorGet(_ncCurrentBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_drawBackground( )
                           {
                            BOOL tmpVal;
                            RCODE res = drawBackgroundGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_drawBackground( BOOL _drawBackground
                                               )
                           {
                            RCODE res = drawBackgroundSet( _drawBackground );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, drawBackground );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE drawBackgroundGet( BOOL*    _drawBackground /* [out] bool _drawBackground  */)
                           {
                        
                            return pif->drawBackgroundGet(_drawBackground);
                           }
                        
                        RCODE drawBackgroundSet( BOOL    _drawBackground /* [in] bool  _drawBackground  */)
                           {
                        
                            return pif->drawBackgroundSet(_drawBackground);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_backgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = backgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_backgroundColor( COLORREF _backgroundColor
                                                )
                           {
                            RCODE res = backgroundColorSet( _backgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, backgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE backgroundColorGet( COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */)
                           {
                        
                            return pif->backgroundColorGet(_backgroundColor);
                           }
                        
                        RCODE backgroundColorSet( COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */)
                           {
                        
                            return pif->backgroundColorSet(_backgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeBackgroundColor( COLORREF _activeBackgroundColor
                                                      )
                           {
                            RCODE res = activeBackgroundColorSet( _activeBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeBackgroundColorGet( COLORREF*    _activeBackgroundColor /* [out] colorref _activeBackgroundColor  */)
                           {
                        
                            return pif->activeBackgroundColorGet(_activeBackgroundColor);
                           }
                        
                        RCODE activeBackgroundColorSet( COLORREF    _activeBackgroundColor /* [in] colorref  _activeBackgroundColor  */)
                           {
                        
                            return pif->activeBackgroundColorSet(_activeBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_currentBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = currentBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, COLORREF, currentBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE currentBackgroundColorGet( COLORREF*    _currentBackgroundColor /* [out] colorref _currentBackgroundColor  */)
                           {
                        
                            return pif->currentBackgroundColorGet(_currentBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_color( )
                           {
                            COLORREF tmpVal;
                            RCODE res = colorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_color( COLORREF _color
                                      )
                           {
                            RCODE res = colorSet( _color );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, color );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE colorGet( COLORREF*    _color /* [out] colorref _color  */)
                           {
                        
                            return pif->colorGet(_color);
                           }
                        
                        RCODE colorSet( COLORREF    _color /* [in] colorref  _color  */)
                           {
                        
                            return pif->colorSet(_color);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_size( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = sizeGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_size( const STRUCT_CLI_DRAWING_CPOINT &_size
                                     )
                           {
                            RCODE res = sizeSet( _size );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, size );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeGet( STRUCT_CLI_DRAWING_CPOINT    &_size /* [out] ::cli::drawing::CPoint _size  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->sizeGet(&_size);
                           }
                        
                        RCODE sizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_size /* [in,ref] ::cli::drawing::CPoint  _size  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->sizeSet(&_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INT get_sizeX( )
                           {
                            INT tmpVal;
                            RCODE res = sizeXGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_sizeX( INT _sizeX
                                      )
                           {
                            RCODE res = sizeXSet( _sizeX );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, INT, sizeX );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeXGet( INT*    _sizeX /* [out] int _sizeX  */)
                           {
                        
                            return pif->sizeXGet(_sizeX);
                           }
                        
                        RCODE sizeXSet( INT    _sizeX /* [in] int  _sizeX  */)
                           {
                        
                            return pif->sizeXSet(_sizeX);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INT get_sizeY( )
                           {
                            INT tmpVal;
                            RCODE res = sizeYGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_sizeY( INT _sizeY
                                      )
                           {
                            RCODE res = sizeYSet( _sizeY );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, INT, sizeY );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeYGet( INT*    _sizeY /* [out] int _sizeY  */)
                           {
                        
                            return pif->sizeYGet(_sizeY);
                           }
                        
                        RCODE sizeYSet( INT    _sizeY /* [in] int  _sizeY  */)
                           {
                        
                            return pif->sizeYSet(_sizeY);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_minSize( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = minSizeGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_minSize( const STRUCT_CLI_DRAWING_CPOINT &_minSize
                                        )
                           {
                            RCODE res = minSizeSet( _minSize );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, minSize );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE minSizeGet( STRUCT_CLI_DRAWING_CPOINT    &_minSize /* [out] ::cli::drawing::CPoint _minSize  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->minSizeGet(&_minSize);
                           }
                        
                        RCODE minSizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_minSize /* [in,ref] ::cli::drawing::CPoint  _minSize  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->minSizeSet(&_minSize);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_maxSize( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = maxSizeGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_maxSize( const STRUCT_CLI_DRAWING_CPOINT &_maxSize
                                        )
                           {
                            RCODE res = maxSizeSet( _maxSize );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, maxSize );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE maxSizeGet( STRUCT_CLI_DRAWING_CPOINT    &_maxSize /* [out] ::cli::drawing::CPoint _maxSize  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->maxSizeGet(&_maxSize);
                           }
                        
                        RCODE maxSizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_maxSize /* [in,ref] ::cli::drawing::CPoint  _maxSize  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->maxSizeSet(&_maxSize);
                           }
                        
                        RCODE getLimits( STRUCT_CLI_DRAWING_CPOINT    &minSize /* [out] ::cli::drawing::CPoint minSize  (struct passed by ref in wrapper) */
                                       , STRUCT_CLI_DRAWING_CPOINT    &maxSize /* [out] ::cli::drawing::CPoint maxSize  (struct passed by ref in wrapper) */
                                       )
                           {
                        
                        
                            return pif->getLimits(&minSize, &maxSize);
                           }
                        
                        RCODE updateConfig( INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          )
                           {
                        
                        
                        
                            return pif->updateConfig(appCfg, idx1, idx2);
                           }
                        
                        RCODE calculateLimits( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->calculateLimits(pdc, idx1, idx2);
                           }
                        
                        RCODE ncPaint( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                     , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     , SIZE_T    idx2 /* [in] size_t  idx2  */
                                     )
                           {
                        
                        
                        
                        
                            return pif->ncPaint(pdc, &paintAreaSize, idx1, idx2);
                           }
                        
                        RCODE paintClient( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                        
                            return pif->paintClient(pdc, &paintAreaSize, idx1, idx2);
                           }
                        
                        RCODE updatePaint( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                        
                            return pif->updatePaint(pdc, &paintAreaSize, idx1, idx2);
                           }
                        
                        RCODE onMouseMove( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                            return pif->onMouseMove(&micePos, idx1, idx2);
                           }
                        
                        RCODE onMouseClick( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                          )
                           {
                        
                        
                        
                        
                            return pif->onMouseClick(&micePos, idx1, idx2, eventFlags);
                           }
                        

                
                
                }; // class CiSimpleCellWrapper
                
                typedef CiSimpleCellWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL     > >  CiSimpleCell;
                typedef CiSimpleCellWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL > >  CiSimpleCell_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iMultiCell */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_IMULTICELL_IID
    #define INTERFACE_CLI_GUI_CELLGRID_IMULTICELL_IID    "/cli/gui/cellgrid/iMultiCell"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iMultiCell
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IMULTICELL
       #define INTERFACE_CLI_GUI_CELLGRID_IMULTICELL    ::cli::gui::cellgrid::iMultiCell
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iMultiCell
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IMULTICELL
       #define INTERFACE_CLI_GUI_CELLGRID_IMULTICELL    cli_gui_cellgrid_iMultiCell
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iMultiCell methods */
                    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */) PURE;
                    CLIMETHOD(ownerRowGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* _ownerRow  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(ownerRowSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  _ownerRow  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(ownerRowSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(ownerRowSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             ) PURE;
                    CLIMETHOD(activeCellGet) (THIS_ BOOL*    _activeCell /* [out] bool _activeCell  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(activeCellSet) (THIS_ BOOL    _activeCell /* [in] bool  _activeCell  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(activeCellSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(activeCellSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               ) PURE;
                    CLIMETHOD(hotTrackedGet) (THIS_ BOOL*    _hotTracked /* [out] bool _hotTracked  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(hotTrackedSet) (THIS_ BOOL    _hotTracked /* [in] bool  _hotTracked  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(hotTrackedSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(hotTrackedSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               ) PURE;
                    CLIMETHOD(autoHotTrackGet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack _autoHotTrack  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(autoHotTrackSet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK    _autoHotTrack /* [in] ::cli::gui::cellgrid::ECellHotTrack  _autoHotTrack  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(autoHotTrackSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(autoHotTrackSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 ) PURE;
                    CLIMETHOD(visibleGet) (THIS_ BOOL*    _visible /* [out] bool _visible  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(visibleSet) (THIS_ BOOL    _visible /* [in] bool  _visible  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(visibleSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(visibleSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _spacing /* [out] ::cli::gui::CSpacing _spacing  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(spacingSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(spacingSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(ncDrawBackgroundGet) (THIS_ BOOL*    _ncDrawBackground /* [out] bool _ncDrawBackground  */
                                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                   ) PURE;
                    CLIMETHOD(ncDrawBackgroundSet) (THIS_ BOOL    _ncDrawBackground /* [in] bool  _ncDrawBackground  */
                                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                   ) PURE;
                    CLIMETHOD(ncDrawBackgroundSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(ncDrawBackgroundSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                     ) PURE;
                    CLIMETHOD(ncBackgroundColorGet) (THIS_ COLORREF*    _ncBackgroundColor /* [out] colorref _ncBackgroundColor  */
                                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                    ) PURE;
                    CLIMETHOD(ncBackgroundColorSet) (THIS_ COLORREF    _ncBackgroundColor /* [in] colorref  _ncBackgroundColor  */
                                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                    ) PURE;
                    CLIMETHOD(ncBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(ncBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      ) PURE;
                    CLIMETHOD(ncActiveBackgroundColorGet) (THIS_ COLORREF*    _ncActiveBackgroundColor /* [out] colorref _ncActiveBackgroundColor  */
                                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                          ) PURE;
                    CLIMETHOD(ncActiveBackgroundColorSet) (THIS_ COLORREF    _ncActiveBackgroundColor /* [in] colorref  _ncActiveBackgroundColor  */
                                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                          ) PURE;
                    CLIMETHOD(ncActiveBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(ncActiveBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                            ) PURE;
                    CLIMETHOD(ncCurrentBackgroundColorGet) (THIS_ COLORREF*    _ncCurrentBackgroundColor /* [out] colorref _ncCurrentBackgroundColor  */
                                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                           ) PURE;
                    CLIMETHOD(ncCurrentBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(ncCurrentBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                             ) PURE;
                    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool _drawBackground  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                 ) PURE;
                    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  _drawBackground  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                 ) PURE;
                    CLIMETHOD(drawBackgroundSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(drawBackgroundSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                   ) PURE;
                    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */
                                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                  ) PURE;
                    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */
                                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                  ) PURE;
                    CLIMETHOD(backgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(backgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    ) PURE;
                    CLIMETHOD(activeBackgroundColorGet) (THIS_ COLORREF*    _activeBackgroundColor /* [out] colorref _activeBackgroundColor  */
                                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                        ) PURE;
                    CLIMETHOD(activeBackgroundColorSet) (THIS_ COLORREF    _activeBackgroundColor /* [in] colorref  _activeBackgroundColor  */
                                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                        ) PURE;
                    CLIMETHOD(activeBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(activeBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                          ) PURE;
                    CLIMETHOD(currentBackgroundColorGet) (THIS_ COLORREF*    _currentBackgroundColor /* [out] colorref _currentBackgroundColor  */
                                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                              , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                         ) PURE;
                    CLIMETHOD(currentBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(currentBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                           ) PURE;
                    CLIMETHOD(colorGet) (THIS_ COLORREF*    _color /* [out] colorref _color  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        ) PURE;
                    CLIMETHOD(colorSet) (THIS_ COLORREF    _color /* [in] colorref  _color  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        ) PURE;
                    CLIMETHOD(colorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(colorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          ) PURE;
                    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       ) PURE;
                    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       ) PURE;
                    CLIMETHOD(sizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(sizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         ) PURE;
                    CLIMETHOD(sizeXGet) (THIS_ INT*    _sizeX /* [out] int _sizeX  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        ) PURE;
                    CLIMETHOD(sizeXSet) (THIS_ INT    _sizeX /* [in] int  _sizeX  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        ) PURE;
                    CLIMETHOD(sizeXSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(sizeXSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          ) PURE;
                    CLIMETHOD(sizeYGet) (THIS_ INT*    _sizeY /* [out] int _sizeY  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        ) PURE;
                    CLIMETHOD(sizeYSet) (THIS_ INT    _sizeY /* [in] int  _sizeY  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        ) PURE;
                    CLIMETHOD(sizeYSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(sizeYSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          ) PURE;
                    CLIMETHOD(minSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [out] ::cli::drawing::CPoint _minSize  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(minSizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [in,ref] ::cli::drawing::CPoint  _minSize  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(minSizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(minSizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(maxSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [out] ::cli::drawing::CPoint _maxSize  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(maxSizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [in,ref] ::cli::drawing::CPoint  _maxSize  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          ) PURE;
                    CLIMETHOD(maxSizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(maxSizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         ) PURE;
                    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                            ) PURE;
                    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       ) PURE;
                    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(updatePaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           ) PURE;
                    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                            ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iMultiCell >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_IMULTICELL_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iMultiCell* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iMultiCell > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iMultiCell wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IMULTICELL >
                                              */
                         >
                class CiMultiCellWrapper
                {
                    public:
                
                        typedef  CiMultiCellWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiMultiCellWrapper() :
                           pif(0) {}
                
                        CiMultiCellWrapper( iMultiCell *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiMultiCellWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiMultiCellWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiMultiCellWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiMultiCellWrapper(const CiMultiCellWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiMultiCellWrapper()  { }
                
                        CiMultiCellWrapper& operator=(const CiMultiCellWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IGRID* get_ownerGrid( )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IGRID* tmpVal;
                            RCODE res = ownerGridGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IGRID*, ownerGrid );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ownerGridGet( INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */)
                           {
                        
                            return pif->ownerGridGet(_ownerGrid);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IROW* get_ownerRow( SIZE_T idx1
                                                                     , SIZE_T idx2
                                                                     )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IROW* tmpVal;
                            RCODE res = ownerRowGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ownerRow( SIZE_T idx1
                                         , SIZE_T idx2
                                         , INTERFACE_CLI_GUI_CELLGRID_IROW* _ownerRow
                                         )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = ownerRowSet( _ownerRow, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_ownerRow(  )
                           {
                            SIZE_T size;
                            RCODE res = ownerRowSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_ownerRow( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = ownerRowSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IROW*, ownerRow, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ownerRowGet( INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* _ownerRow  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                            return pif->ownerRowGet(_ownerRow, idx1, idx2);
                           }
                        
                        RCODE ownerRowSet( INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  _ownerRow  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                            return pif->ownerRowSet(_ownerRow, idx1, idx2);
                           }
                        
                        RCODE ownerRowSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->ownerRowSize1(_size);
                           }
                        
                        RCODE ownerRowSize2( SIZE_T*    _size /* [out] size_t _size  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           )
                           {
                        
                        
                            return pif->ownerRowSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_activeCell( SIZE_T idx1
                                           , SIZE_T idx2
                                           )
                           {
                            BOOL tmpVal;
                            RCODE res = activeCellGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCell( SIZE_T idx1
                                           , SIZE_T idx2
                                           , BOOL _activeCell
                                           )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = activeCellSet( _activeCell, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_activeCell(  )
                           {
                            SIZE_T size;
                            RCODE res = activeCellSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_activeCell( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = activeCellSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, activeCell, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellGet( BOOL*    _activeCell /* [out] bool _activeCell  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->activeCellGet(_activeCell, idx1, idx2);
                           }
                        
                        RCODE activeCellSet( BOOL    _activeCell /* [in] bool  _activeCell  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->activeCellSet(_activeCell, idx1, idx2);
                           }
                        
                        RCODE activeCellSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->activeCellSize1(_size);
                           }
                        
                        RCODE activeCellSize2( SIZE_T*    _size /* [out] size_t _size  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
                           {
                        
                        
                            return pif->activeCellSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_hotTracked( SIZE_T idx1
                                           , SIZE_T idx2
                                           )
                           {
                            BOOL tmpVal;
                            RCODE res = hotTrackedGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_hotTracked( SIZE_T idx1
                                           , SIZE_T idx2
                                           , BOOL _hotTracked
                                           )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = hotTrackedSet( _hotTracked, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_hotTracked(  )
                           {
                            SIZE_T size;
                            RCODE res = hotTrackedSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_hotTracked( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = hotTrackedSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, hotTracked, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE hotTrackedGet( BOOL*    _hotTracked /* [out] bool _hotTracked  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->hotTrackedGet(_hotTracked, idx1, idx2);
                           }
                        
                        RCODE hotTrackedSet( BOOL    _hotTracked /* [in] bool  _hotTracked  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->hotTrackedSet(_hotTracked, idx1, idx2);
                           }
                        
                        RCODE hotTrackedSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->hotTrackedSize1(_size);
                           }
                        
                        RCODE hotTrackedSize2( SIZE_T*    _size /* [out] size_t _size  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
                           {
                        
                        
                            return pif->hotTrackedSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK get_autoHotTrack( SIZE_T idx1
                                                                            , SIZE_T idx2
                                                                            )
                           {
                            ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK tmpVal;
                            RCODE res = autoHotTrackGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_autoHotTrack( SIZE_T idx1
                                             , SIZE_T idx2
                                             , ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK _autoHotTrack
                                             )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = autoHotTrackSet( _autoHotTrack, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_autoHotTrack(  )
                           {
                            SIZE_T size;
                            RCODE res = autoHotTrackSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_autoHotTrack( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = autoHotTrackSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK, autoHotTrack, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE autoHotTrackGet( ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack _autoHotTrack  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->autoHotTrackGet(_autoHotTrack, idx1, idx2);
                           }
                        
                        RCODE autoHotTrackSet( ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK    _autoHotTrack /* [in] ::cli::gui::cellgrid::ECellHotTrack  _autoHotTrack  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->autoHotTrackSet(_autoHotTrack, idx1, idx2);
                           }
                        
                        RCODE autoHotTrackSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->autoHotTrackSize1(_size);
                           }
                        
                        RCODE autoHotTrackSize2( SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               )
                           {
                        
                        
                            return pif->autoHotTrackSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_visible( SIZE_T idx1
                                        , SIZE_T idx2
                                        )
                           {
                            BOOL tmpVal;
                            RCODE res = visibleGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_visible( SIZE_T idx1
                                        , SIZE_T idx2
                                        , BOOL _visible
                                        )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = visibleSet( _visible, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_visible(  )
                           {
                            SIZE_T size;
                            RCODE res = visibleSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_visible( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = visibleSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, visible, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE visibleGet( BOOL*    _visible /* [out] bool _visible  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->visibleGet(_visible, idx1, idx2);
                           }
                        
                        RCODE visibleSet( BOOL    _visible /* [in] bool  _visible  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->visibleSet(_visible, idx1, idx2);
                           }
                        
                        RCODE visibleSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->visibleSize1(_size);
                           }
                        
                        RCODE visibleSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->visibleSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CSPACING get_spacing( SIZE_T idx1
                                                           , SIZE_T idx2
                                                           )
                           {
                            STRUCT_CLI_GUI_CSPACING tmpVal;
                            RCODE res = spacingGet( tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_spacing( SIZE_T idx1
                                        , SIZE_T idx2
                                        , const STRUCT_CLI_GUI_CSPACING &_spacing
                                        )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = spacingSet( _spacing, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_spacing(  )
                           {
                            SIZE_T size;
                            RCODE res = spacingSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_spacing( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = spacingSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, STRUCT_CLI_GUI_CSPACING, spacing, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE spacingGet( STRUCT_CLI_GUI_CSPACING    &_spacing /* [out] ::cli::gui::CSpacing _spacing  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->spacingGet(&_spacing, idx1, idx2);
                           }
                        
                        RCODE spacingSet( const STRUCT_CLI_GUI_CSPACING    &_spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->spacingSet(&_spacing, idx1, idx2);
                           }
                        
                        RCODE spacingSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->spacingSize1(_size);
                           }
                        
                        RCODE spacingSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->spacingSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_ncDrawBackground( SIZE_T idx1
                                                 , SIZE_T idx2
                                                 )
                           {
                            BOOL tmpVal;
                            RCODE res = ncDrawBackgroundGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncDrawBackground( SIZE_T idx1
                                                 , SIZE_T idx2
                                                 , BOOL _ncDrawBackground
                                                 )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = ncDrawBackgroundSet( _ncDrawBackground, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_ncDrawBackground(  )
                           {
                            SIZE_T size;
                            RCODE res = ncDrawBackgroundSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_ncDrawBackground( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = ncDrawBackgroundSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, ncDrawBackground, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncDrawBackgroundGet( BOOL*    _ncDrawBackground /* [out] bool _ncDrawBackground  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                 )
                           {
                        
                        
                        
                            return pif->ncDrawBackgroundGet(_ncDrawBackground, idx1, idx2);
                           }
                        
                        RCODE ncDrawBackgroundSet( BOOL    _ncDrawBackground /* [in] bool  _ncDrawBackground  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                 )
                           {
                        
                        
                        
                            return pif->ncDrawBackgroundSet(_ncDrawBackground, idx1, idx2);
                           }
                        
                        RCODE ncDrawBackgroundSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->ncDrawBackgroundSize1(_size);
                           }
                        
                        RCODE ncDrawBackgroundSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                   )
                           {
                        
                        
                            return pif->ncDrawBackgroundSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_ncBackgroundColor( SIZE_T idx1
                                                      , SIZE_T idx2
                                                      )
                           {
                            COLORREF tmpVal;
                            RCODE res = ncBackgroundColorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncBackgroundColor( SIZE_T idx1
                                                  , SIZE_T idx2
                                                  , COLORREF _ncBackgroundColor
                                                  )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = ncBackgroundColorSet( _ncBackgroundColor, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_ncBackgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = ncBackgroundColorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_ncBackgroundColor( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = ncBackgroundColorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, COLORREF, ncBackgroundColor, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncBackgroundColorGet( COLORREF*    _ncBackgroundColor /* [out] colorref _ncBackgroundColor  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                  )
                           {
                        
                        
                        
                            return pif->ncBackgroundColorGet(_ncBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE ncBackgroundColorSet( COLORREF    _ncBackgroundColor /* [in] colorref  _ncBackgroundColor  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                  )
                           {
                        
                        
                        
                            return pif->ncBackgroundColorSet(_ncBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE ncBackgroundColorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->ncBackgroundColorSize1(_size);
                           }
                        
                        RCODE ncBackgroundColorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    )
                           {
                        
                        
                            return pif->ncBackgroundColorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_ncActiveBackgroundColor( SIZE_T idx1
                                                            , SIZE_T idx2
                                                            )
                           {
                            COLORREF tmpVal;
                            RCODE res = ncActiveBackgroundColorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncActiveBackgroundColor( SIZE_T idx1
                                                        , SIZE_T idx2
                                                        , COLORREF _ncActiveBackgroundColor
                                                        )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = ncActiveBackgroundColorSet( _ncActiveBackgroundColor, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_ncActiveBackgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = ncActiveBackgroundColorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_ncActiveBackgroundColor( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = ncActiveBackgroundColorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, COLORREF, ncActiveBackgroundColor, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncActiveBackgroundColorGet( COLORREF*    _ncActiveBackgroundColor /* [out] colorref _ncActiveBackgroundColor  */
                                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                        )
                           {
                        
                        
                        
                            return pif->ncActiveBackgroundColorGet(_ncActiveBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE ncActiveBackgroundColorSet( COLORREF    _ncActiveBackgroundColor /* [in] colorref  _ncActiveBackgroundColor  */
                                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                        )
                           {
                        
                        
                        
                            return pif->ncActiveBackgroundColorSet(_ncActiveBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE ncActiveBackgroundColorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->ncActiveBackgroundColorSize1(_size);
                           }
                        
                        RCODE ncActiveBackgroundColorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                          )
                           {
                        
                        
                            return pif->ncActiveBackgroundColorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_ncCurrentBackgroundColor( SIZE_T idx1
                                                             , SIZE_T idx2
                                                             )
                           {
                            COLORREF tmpVal;
                            RCODE res = ncCurrentBackgroundColorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_ncCurrentBackgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = ncCurrentBackgroundColorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_ncCurrentBackgroundColor( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = ncCurrentBackgroundColorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, COLORREF, ncCurrentBackgroundColor, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncCurrentBackgroundColorGet( COLORREF*    _ncCurrentBackgroundColor /* [out] colorref _ncCurrentBackgroundColor  */
                                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                         )
                           {
                        
                        
                        
                            return pif->ncCurrentBackgroundColorGet(_ncCurrentBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE ncCurrentBackgroundColorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->ncCurrentBackgroundColorSize1(_size);
                           }
                        
                        RCODE ncCurrentBackgroundColorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                           )
                           {
                        
                        
                            return pif->ncCurrentBackgroundColorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_drawBackground( SIZE_T idx1
                                               , SIZE_T idx2
                                               )
                           {
                            BOOL tmpVal;
                            RCODE res = drawBackgroundGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_drawBackground( SIZE_T idx1
                                               , SIZE_T idx2
                                               , BOOL _drawBackground
                                               )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = drawBackgroundSet( _drawBackground, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_drawBackground(  )
                           {
                            SIZE_T size;
                            RCODE res = drawBackgroundSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_drawBackground( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = drawBackgroundSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, drawBackground, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE drawBackgroundGet( BOOL*    _drawBackground /* [out] bool _drawBackground  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               )
                           {
                        
                        
                        
                            return pif->drawBackgroundGet(_drawBackground, idx1, idx2);
                           }
                        
                        RCODE drawBackgroundSet( BOOL    _drawBackground /* [in] bool  _drawBackground  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               )
                           {
                        
                        
                        
                            return pif->drawBackgroundSet(_drawBackground, idx1, idx2);
                           }
                        
                        RCODE drawBackgroundSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->drawBackgroundSize1(_size);
                           }
                        
                        RCODE drawBackgroundSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 )
                           {
                        
                        
                            return pif->drawBackgroundSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_backgroundColor( SIZE_T idx1
                                                    , SIZE_T idx2
                                                    )
                           {
                            COLORREF tmpVal;
                            RCODE res = backgroundColorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_backgroundColor( SIZE_T idx1
                                                , SIZE_T idx2
                                                , COLORREF _backgroundColor
                                                )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = backgroundColorSet( _backgroundColor, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_backgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = backgroundColorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_backgroundColor( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = backgroundColorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, COLORREF, backgroundColor, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE backgroundColorGet( COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                )
                           {
                        
                        
                        
                            return pif->backgroundColorGet(_backgroundColor, idx1, idx2);
                           }
                        
                        RCODE backgroundColorSet( COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                )
                           {
                        
                        
                        
                            return pif->backgroundColorSet(_backgroundColor, idx1, idx2);
                           }
                        
                        RCODE backgroundColorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->backgroundColorSize1(_size);
                           }
                        
                        RCODE backgroundColorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  )
                           {
                        
                        
                            return pif->backgroundColorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeBackgroundColor( SIZE_T idx1
                                                          , SIZE_T idx2
                                                          )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeBackgroundColorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeBackgroundColor( SIZE_T idx1
                                                      , SIZE_T idx2
                                                      , COLORREF _activeBackgroundColor
                                                      )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = activeBackgroundColorSet( _activeBackgroundColor, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_activeBackgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = activeBackgroundColorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_activeBackgroundColor( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = activeBackgroundColorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, COLORREF, activeBackgroundColor, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeBackgroundColorGet( COLORREF*    _activeBackgroundColor /* [out] colorref _activeBackgroundColor  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                      )
                           {
                        
                        
                        
                            return pif->activeBackgroundColorGet(_activeBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE activeBackgroundColorSet( COLORREF    _activeBackgroundColor /* [in] colorref  _activeBackgroundColor  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                      )
                           {
                        
                        
                        
                            return pif->activeBackgroundColorSet(_activeBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE activeBackgroundColorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->activeBackgroundColorSize1(_size);
                           }
                        
                        RCODE activeBackgroundColorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                        )
                           {
                        
                        
                            return pif->activeBackgroundColorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_currentBackgroundColor( SIZE_T idx1
                                                           , SIZE_T idx2
                                                           )
                           {
                            COLORREF tmpVal;
                            RCODE res = currentBackgroundColorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_currentBackgroundColor(  )
                           {
                            SIZE_T size;
                            RCODE res = currentBackgroundColorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_currentBackgroundColor( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = currentBackgroundColorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, COLORREF, currentBackgroundColor, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE currentBackgroundColorGet( COLORREF*    _currentBackgroundColor /* [out] colorref _currentBackgroundColor  */
                                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                                       )
                           {
                        
                        
                        
                            return pif->currentBackgroundColorGet(_currentBackgroundColor, idx1, idx2);
                           }
                        
                        RCODE currentBackgroundColorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->currentBackgroundColorSize1(_size);
                           }
                        
                        RCODE currentBackgroundColorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                         )
                           {
                        
                        
                            return pif->currentBackgroundColorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_color( SIZE_T idx1
                                          , SIZE_T idx2
                                          )
                           {
                            COLORREF tmpVal;
                            RCODE res = colorGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_color( SIZE_T idx1
                                      , SIZE_T idx2
                                      , COLORREF _color
                                      )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = colorSet( _color, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_color(  )
                           {
                            SIZE_T size;
                            RCODE res = colorSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_color( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = colorSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, COLORREF, color, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE colorGet( COLORREF*    _color /* [out] colorref _color  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                      )
                           {
                        
                        
                        
                            return pif->colorGet(_color, idx1, idx2);
                           }
                        
                        RCODE colorSet( COLORREF    _color /* [in] colorref  _color  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                      )
                           {
                        
                        
                        
                            return pif->colorSet(_color, idx1, idx2);
                           }
                        
                        RCODE colorSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->colorSize1(_size);
                           }
                        
                        RCODE colorSize2( SIZE_T*    _size /* [out] size_t _size  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        )
                           {
                        
                        
                            return pif->colorSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_size( SIZE_T idx1
                                                          , SIZE_T idx2
                                                          )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = sizeGet( tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_size( SIZE_T idx1
                                     , SIZE_T idx2
                                     , const STRUCT_CLI_DRAWING_CPOINT &_size
                                     )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = sizeSet( _size, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_size(  )
                           {
                            SIZE_T size;
                            RCODE res = sizeSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_size( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = sizeSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, size, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeGet( STRUCT_CLI_DRAWING_CPOINT    &_size /* [out] ::cli::drawing::CPoint _size  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     , SIZE_T    idx2 /* [in] size_t  idx2  */
                                     )
                           {
                        
                        
                        
                            return pif->sizeGet(&_size, idx1, idx2);
                           }
                        
                        RCODE sizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_size /* [in,ref] ::cli::drawing::CPoint  _size  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     , SIZE_T    idx2 /* [in] size_t  idx2  */
                                     )
                           {
                        
                        
                        
                            return pif->sizeSet(&_size, idx1, idx2);
                           }
                        
                        RCODE sizeSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->sizeSize1(_size);
                           }
                        
                        RCODE sizeSize2( SIZE_T*    _size /* [out] size_t _size  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       )
                           {
                        
                        
                            return pif->sizeSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INT get_sizeX( SIZE_T idx1
                                     , SIZE_T idx2
                                     )
                           {
                            INT tmpVal;
                            RCODE res = sizeXGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_sizeX( SIZE_T idx1
                                      , SIZE_T idx2
                                      , INT _sizeX
                                      )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = sizeXSet( _sizeX, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_sizeX(  )
                           {
                            SIZE_T size;
                            RCODE res = sizeXSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_sizeX( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = sizeXSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, INT, sizeX, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeXGet( INT*    _sizeX /* [out] int _sizeX  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                      )
                           {
                        
                        
                        
                            return pif->sizeXGet(_sizeX, idx1, idx2);
                           }
                        
                        RCODE sizeXSet( INT    _sizeX /* [in] int  _sizeX  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                      )
                           {
                        
                        
                        
                            return pif->sizeXSet(_sizeX, idx1, idx2);
                           }
                        
                        RCODE sizeXSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->sizeXSize1(_size);
                           }
                        
                        RCODE sizeXSize2( SIZE_T*    _size /* [out] size_t _size  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        )
                           {
                        
                        
                            return pif->sizeXSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INT get_sizeY( SIZE_T idx1
                                     , SIZE_T idx2
                                     )
                           {
                            INT tmpVal;
                            RCODE res = sizeYGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_sizeY( SIZE_T idx1
                                      , SIZE_T idx2
                                      , INT _sizeY
                                      )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = sizeYSet( _sizeY, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_sizeY(  )
                           {
                            SIZE_T size;
                            RCODE res = sizeYSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_sizeY( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = sizeYSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, INT, sizeY, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeYGet( INT*    _sizeY /* [out] int _sizeY  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                      )
                           {
                        
                        
                        
                            return pif->sizeYGet(_sizeY, idx1, idx2);
                           }
                        
                        RCODE sizeYSet( INT    _sizeY /* [in] int  _sizeY  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                      )
                           {
                        
                        
                        
                            return pif->sizeYSet(_sizeY, idx1, idx2);
                           }
                        
                        RCODE sizeYSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->sizeYSize1(_size);
                           }
                        
                        RCODE sizeYSize2( SIZE_T*    _size /* [out] size_t _size  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        )
                           {
                        
                        
                            return pif->sizeYSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_minSize( SIZE_T idx1
                                                             , SIZE_T idx2
                                                             )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = minSizeGet( tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_minSize( SIZE_T idx1
                                        , SIZE_T idx2
                                        , const STRUCT_CLI_DRAWING_CPOINT &_minSize
                                        )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = minSizeSet( _minSize, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_minSize(  )
                           {
                            SIZE_T size;
                            RCODE res = minSizeSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_minSize( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = minSizeSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, minSize, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE minSizeGet( STRUCT_CLI_DRAWING_CPOINT    &_minSize /* [out] ::cli::drawing::CPoint _minSize  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->minSizeGet(&_minSize, idx1, idx2);
                           }
                        
                        RCODE minSizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_minSize /* [in,ref] ::cli::drawing::CPoint  _minSize  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->minSizeSet(&_minSize, idx1, idx2);
                           }
                        
                        RCODE minSizeSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->minSizeSize1(_size);
                           }
                        
                        RCODE minSizeSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->minSizeSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_maxSize( SIZE_T idx1
                                                             , SIZE_T idx2
                                                             )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = maxSizeGet( tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_maxSize( SIZE_T idx1
                                        , SIZE_T idx2
                                        , const STRUCT_CLI_DRAWING_CPOINT &_maxSize
                                        )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = maxSizeSet( _maxSize, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_maxSize(  )
                           {
                            SIZE_T size;
                            RCODE res = maxSizeSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_maxSize( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = maxSizeSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, maxSize, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE maxSizeGet( STRUCT_CLI_DRAWING_CPOINT    &_maxSize /* [out] ::cli::drawing::CPoint _maxSize  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->maxSizeGet(&_maxSize, idx1, idx2);
                           }
                        
                        RCODE maxSizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_maxSize /* [in,ref] ::cli::drawing::CPoint  _maxSize  (struct passed by ref in wrapper) */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
                           {
                        
                        
                        
                            return pif->maxSizeSet(&_maxSize, idx1, idx2);
                           }
                        
                        RCODE maxSizeSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->maxSizeSize1(_size);
                           }
                        
                        RCODE maxSizeSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->maxSizeSize2(_size, idx1);
                           }
                        
                        RCODE getLimits( STRUCT_CLI_DRAWING_CPOINT    &minSize /* [out] ::cli::drawing::CPoint minSize  (struct passed by ref in wrapper) */
                                       , STRUCT_CLI_DRAWING_CPOINT    &maxSize /* [out] ::cli::drawing::CPoint maxSize  (struct passed by ref in wrapper) */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                       )
                           {
                        
                        
                        
                        
                            return pif->getLimits(&minSize, &maxSize, idx1, idx2);
                           }
                        
                        RCODE updateConfig( INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          )
                           {
                        
                        
                        
                            return pif->updateConfig(appCfg, idx1, idx2);
                           }
                        
                        RCODE calculateLimits( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->calculateLimits(pdc, idx1, idx2);
                           }
                        
                        RCODE ncPaint( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                     , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     , SIZE_T    idx2 /* [in] size_t  idx2  */
                                     )
                           {
                        
                        
                        
                        
                            return pif->ncPaint(pdc, &paintAreaSize, idx1, idx2);
                           }
                        
                        RCODE paintClient( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                        
                            return pif->paintClient(pdc, &paintAreaSize, idx1, idx2);
                           }
                        
                        RCODE updatePaint( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                        
                            return pif->updatePaint(pdc, &paintAreaSize, idx1, idx2);
                           }
                        
                        RCODE onMouseMove( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
                           {
                        
                        
                        
                            return pif->onMouseMove(&micePos, idx1, idx2);
                           }
                        
                        RCODE onMouseClick( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                          )
                           {
                        
                        
                        
                        
                            return pif->onMouseClick(&micePos, idx1, idx2, eventFlags);
                           }
                        

                
                
                }; // class CiMultiCellWrapper
                
                typedef CiMultiCellWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IMULTICELL     > >  CiMultiCell;
                typedef CiMultiCellWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_IMULTICELL > >  CiMultiCell_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iVisibilityController */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER_IID
    #define INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER_IID    "/cli/gui/cellgrid/iVisibilityController"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iVisibilityController
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER
       #define INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER    ::cli::gui::cellgrid::iVisibilityController
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iVisibilityController
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER
       #define INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER    cli_gui_cellgrid_iVisibilityController
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iVisibilityController methods */
                    CLIMETHOD(autoVisibilityGet) (THIS_ ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO*    _autoVisibility /* [out] ::cli::gui::cellgrid::EVisibilityControledAuto _autoVisibility  */) PURE;
                    CLIMETHOD(autoVisibilitySet) (THIS_ ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO    _autoVisibility /* [in] ::cli::gui::cellgrid::EVisibilityControledAuto  _autoVisibility  */) PURE;
                    CLIMETHOD(rowGet) (THIS_ SIZE_T*    _row /* [out] size_t _row  */) PURE;
                    CLIMETHOD(rowSet) (THIS_ SIZE_T    _row /* [in] size_t  _row  */) PURE;
                    CLIMETHOD(cellGet) (THIS_ SIZE_T*    _cell /* [out] size_t _cell  */) PURE;
                    CLIMETHOD(cellSet) (THIS_ SIZE_T    _cell /* [in] size_t  _cell  */) PURE;
                    CLIMETHOD(slaveVisibleGet) (THIS_ BOOL*    _slaveVisible /* [out] bool _slaveVisible  */) PURE;
                    CLIMETHOD(slaveVisibleSet) (THIS_ BOOL    _slaveVisible /* [in] bool  _slaveVisible  */) PURE;
                    CLIMETHOD(slaveShow) (THIS) PURE;
                    CLIMETHOD(slaveHide) (THIS) PURE;
                    CLIMETHOD(slaveToggle) (THIS) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iVisibilityController >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iVisibilityController* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iVisibilityController > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iVisibilityController wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER >
                                              */
                         >
                class CiVisibilityControllerWrapper
                {
                    public:
                
                        typedef  CiVisibilityControllerWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiVisibilityControllerWrapper() :
                           pif(0) {}
                
                        CiVisibilityControllerWrapper( iVisibilityController *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiVisibilityControllerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiVisibilityControllerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiVisibilityControllerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiVisibilityControllerWrapper(const CiVisibilityControllerWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiVisibilityControllerWrapper()  { }
                
                        CiVisibilityControllerWrapper& operator=(const CiVisibilityControllerWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO get_autoVisibility( )
                           {
                            ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO tmpVal;
                            RCODE res = autoVisibilityGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_autoVisibility( ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO _autoVisibility
                                               )
                           {
                            RCODE res = autoVisibilitySet( _autoVisibility );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO, autoVisibility );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE autoVisibilityGet( ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO*    _autoVisibility /* [out] ::cli::gui::cellgrid::EVisibilityControledAuto _autoVisibility  */)
                           {
                        
                            return pif->autoVisibilityGet(_autoVisibility);
                           }
                        
                        RCODE autoVisibilitySet( ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO    _autoVisibility /* [in] ::cli::gui::cellgrid::EVisibilityControledAuto  _autoVisibility  */)
                           {
                        
                            return pif->autoVisibilitySet(_autoVisibility);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        SIZE_T get_row( )
                           {
                            SIZE_T tmpVal;
                            RCODE res = rowGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_row( SIZE_T _row
                                    )
                           {
                            RCODE res = rowSet( _row );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, row );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowGet( SIZE_T*    _row /* [out] size_t _row  */)
                           {
                        
                            return pif->rowGet(_row);
                           }
                        
                        RCODE rowSet( SIZE_T    _row /* [in] size_t  _row  */)
                           {
                        
                            return pif->rowSet(_row);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        SIZE_T get_cell( )
                           {
                            SIZE_T tmpVal;
                            RCODE res = cellGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cell( SIZE_T _cell
                                     )
                           {
                            RCODE res = cellSet( _cell );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, cell );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellGet( SIZE_T*    _cell /* [out] size_t _cell  */)
                           {
                        
                            return pif->cellGet(_cell);
                           }
                        
                        RCODE cellSet( SIZE_T    _cell /* [in] size_t  _cell  */)
                           {
                        
                            return pif->cellSet(_cell);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_slaveVisible( )
                           {
                            BOOL tmpVal;
                            RCODE res = slaveVisibleGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_slaveVisible( BOOL _slaveVisible
                                             )
                           {
                            RCODE res = slaveVisibleSet( _slaveVisible );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, slaveVisible );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE slaveVisibleGet( BOOL*    _slaveVisible /* [out] bool _slaveVisible  */)
                           {
                        
                            return pif->slaveVisibleGet(_slaveVisible);
                           }
                        
                        RCODE slaveVisibleSet( BOOL    _slaveVisible /* [in] bool  _slaveVisible  */)
                           {
                        
                            return pif->slaveVisibleSet(_slaveVisible);
                           }
                        
                        RCODE slaveShow( )
                           {
                            return pif->slaveShow();
                           }
                        
                        RCODE slaveHide( )
                           {
                            return pif->slaveHide();
                           }
                        
                        RCODE slaveToggle( )
                           {
                            return pif->slaveToggle();
                           }
                        

                
                
                }; // class CiVisibilityControllerWrapper
                
                typedef CiVisibilityControllerWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER     > >  CiVisibilityController;
                typedef CiVisibilityControllerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER > >  CiVisibilityController_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iLabelCell */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace font {
            }; /* namespace font */
        }; /* namespace drawing */
    }; /* namespace cli */

#else /* C-like declarations */


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_ILABELCELL_IID
    #define INTERFACE_CLI_GUI_CELLGRID_ILABELCELL_IID    "/cli/gui/cellgrid/iLabelCell"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iLabelCell
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ILABELCELL
       #define INTERFACE_CLI_GUI_CELLGRID_ILABELCELL    ::cli::gui::cellgrid::iLabelCell
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iLabelCell
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ILABELCELL
       #define INTERFACE_CLI_GUI_CELLGRID_ILABELCELL    cli_gui_cellgrid_iLabelCell
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iLabelCell methods */
                    CLIMETHOD(textGet) (THIS_ CLISTR*           _text) PURE;
                    CLIMETHOD(textSet) (THIS_ const CLISTR*     _text) PURE;
                    CLIMETHOD(fontGet) (THIS_ STRUCT_CLI_DRAWING_FONT_PROPERTIES*    _font /* [out] ::cli::drawing::font::Properties _font  */) PURE;
                    CLIMETHOD(fontSet) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    _font /* [in,ref] ::cli::drawing::font::Properties  _font  */) PURE;
                    CLIMETHOD(fontFaceGet) (THIS_ CLISTR*           _fontFace) PURE;
                    CLIMETHOD(fontFaceSet) (THIS_ const CLISTR*     _fontFace) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iLabelCell >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_ILABELCELL_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iLabelCell* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iLabelCell > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iLabelCell wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_ILABELCELL >
                                              */
                         >
                class CiLabelCellWrapper
                {
                    public:
                
                        typedef  CiLabelCellWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiLabelCellWrapper() :
                           pif(0) {}
                
                        CiLabelCellWrapper( iLabelCell *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiLabelCellWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiLabelCellWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiLabelCellWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiLabelCellWrapper(const CiLabelCellWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiLabelCellWrapper()  { }
                
                        CiLabelCellWrapper& operator=(const CiLabelCellWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ::std::wstring get_text( )
                           {
                            ::std::wstring tmpVal;
                            RCODE res = textGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_text( const ::std::wstring &_text
                                     )
                           {
                            RCODE res = textSet( _text );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, text );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE textGet( ::std::wstring    &_text)
                           {
                            CCliStr tmp__text; CCliStr_init( tmp__text );
                            RCODE res = pif->textGet(&tmp__text);
                            if (RCOK(res))
                               {
                                CCliStr_copyFromIfModified( _text, tmp__text);
                               }
                            return res;
                           }
                        
                        RCODE textSet( const ::std::wstring    &_text)
                           {
                            CCliStr tmp__text; CCliStr_lightCopyTo( tmp__text, _text);
                            return pif->textSet(&tmp__text);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_FONT_PROPERTIES get_font( )
                           {
                            STRUCT_CLI_DRAWING_FONT_PROPERTIES tmpVal;
                            RCODE res = fontGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_font( const STRUCT_CLI_DRAWING_FONT_PROPERTIES &_font
                                     )
                           {
                            RCODE res = fontSet( _font );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_DRAWING_FONT_PROPERTIES, font );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE fontGet( STRUCT_CLI_DRAWING_FONT_PROPERTIES    &_font /* [out] ::cli::drawing::font::Properties _font  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->fontGet(&_font);
                           }
                        
                        RCODE fontSet( const STRUCT_CLI_DRAWING_FONT_PROPERTIES    &_font /* [in,ref] ::cli::drawing::font::Properties  _font  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->fontSet(&_font);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ::std::wstring get_fontFace( )
                           {
                            ::std::wstring tmpVal;
                            RCODE res = fontFaceGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_fontFace( const ::std::wstring &_fontFace
                                         )
                           {
                            RCODE res = fontFaceSet( _fontFace );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, fontFace );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE fontFaceGet( ::std::wstring    &_fontFace)
                           {
                            CCliStr tmp__fontFace; CCliStr_init( tmp__fontFace );
                            RCODE res = pif->fontFaceGet(&tmp__fontFace);
                            if (RCOK(res))
                               {
                                CCliStr_copyFromIfModified( _fontFace, tmp__fontFace);
                               }
                            return res;
                           }
                        
                        RCODE fontFaceSet( const ::std::wstring    &_fontFace)
                           {
                            CCliStr tmp__fontFace; CCliStr_lightCopyTo( tmp__fontFace, _fontFace);
                            return pif->fontFaceSet(&tmp__fontFace);
                           }
                        

                
                
                }; // class CiLabelCellWrapper
                
                typedef CiLabelCellWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_ILABELCELL     > >  CiLabelCell;
                typedef CiLabelCellWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_ILABELCELL > >  CiLabelCell_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif





#endif /* CLI_GUI_CG2_ICELL_H */
