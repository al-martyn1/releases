#ifndef CLI_GUI_CG2_IROW_H
#define CLI_GUI_CG2_IROW_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/cg2/irow.h>", CLI_GUI_CG2_IROW_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_CG2_IROW_H
    #include <cli/gui/cg2/irow.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

#ifndef CLI_GUI_CG2_TYPES_H
    #include <cli/gui/cg2/types.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iRow */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; /* namespace cli */
    namespace cli {
        namespace app {
            interface                                iConfig;
            #ifndef INTERFACE_CLI_APP_ICONFIG
                #define INTERFACE_CLI_APP_ICONFIG         ::cli::app::iConfig
            #endif

        }; /* namespace app */
    }; /* namespace cli */
    namespace cli {
        namespace drawing {
            interface                                iDrawContext1;
            #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
                #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               ::cli::drawing::iDrawContext1
            #endif

        }; /* namespace drawing */
    }; /* namespace cli */
    namespace cli {
        namespace gui {
        }; /* namespace gui */
    }; /* namespace cli */
    namespace cli {
        namespace gui {
            namespace cellgrid {
                interface                                iGrid;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
                    #define INTERFACE_CLI_GUI_CELLGRID_IGRID  ::cli::gui::cellgrid::iGrid
                #endif

                interface                                iMultiCell;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IMULTICELL
                    #define INTERFACE_CLI_GUI_CELLGRID_IMULTICELL             ::cli::gui::cellgrid::iMultiCell
                #endif

                interface                                iSimpleCell;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL
                    #define INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL            ::cli::gui::cellgrid::iSimpleCell
                #endif

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    typedef interface tag_cli_app_iConfig    cli_app_iConfig;
    #ifndef INTERFACE_CLI_APP_ICONFIG
        #define INTERFACE_CLI_APP_ICONFIG         struct tag_cli_app_iConfig
    #endif

    typedef interface tag_cli_drawing_iDrawContext1              cli_drawing_iDrawContext1;
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
        #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               struct tag_cli_drawing_iDrawContext1
    #endif

    typedef interface tag_cli_gui_cellgrid_iGrid                 cli_gui_cellgrid_iGrid;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
        #define INTERFACE_CLI_GUI_CELLGRID_IGRID  struct tag_cli_gui_cellgrid_iGrid
    #endif

    typedef interface tag_cli_gui_cellgrid_iMultiCell            cli_gui_cellgrid_iMultiCell;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IMULTICELL
        #define INTERFACE_CLI_GUI_CELLGRID_IMULTICELL             struct tag_cli_gui_cellgrid_iMultiCell
    #endif

    typedef interface tag_cli_gui_cellgrid_iSimpleCell           cli_gui_cellgrid_iSimpleCell;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL
        #define INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL            struct tag_cli_gui_cellgrid_iSimpleCell
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_IROW_IID
    #define INTERFACE_CLI_GUI_CELLGRID_IROW_IID    "/cli/gui/cellgrid/iRow"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iRow
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
       #define INTERFACE_CLI_GUI_CELLGRID_IROW    ::cli::gui::cellgrid::iRow
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iRow
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
       #define INTERFACE_CLI_GUI_CELLGRID_IROW    cli_gui_cellgrid_iRow
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iRow methods */
                    CLIMETHOD(getIUnknownIndex) (THIS_ INTERFACE_CLI_IUNKNOWN*    pcell /* [in] ::cli::iUnknown*  pcell  */
                                                     , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                                ) PURE;
                    CLIMETHOD(getCellIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                                 , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                            ) PURE;
                    CLIMETHOD(getMultiCellIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IMULTICELL*    pcell /* [in] ::cli::gui::cellgrid::iMultiCell*  pcell  */
                                                      , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                                 ) PURE;
                    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */) PURE;
                    CLIMETHOD(ownerGridSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID*    _ownerGrid /* [in] ::cli::gui::cellgrid::iGrid*  _ownerGrid  */) PURE;
                    CLIMETHOD(cellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL**    _cells /* [out] ::cli::gui::cellgrid::iSimpleCell* _cells  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                    CLIMETHOD(cellsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(multiCellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    _multiCells /* [out] ::cli::gui::cellgrid::iMultiCell* _multiCells  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             ) PURE;
                    CLIMETHOD(multiCellsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(addCell) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */) PURE;
                    CLIMETHOD(addCellToRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                 , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                            ) PURE;
                    CLIMETHOD(insertCell) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                               , SIZE_T    atPos /* [in] size_t  atPos  */
                                          ) PURE;
                    CLIMETHOD(insertCellToRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                    , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                                    , SIZE_T    atPos /* [in] size_t  atPos  */
                                               ) PURE;
                    CLIMETHOD(removeCell) (THIS_ SIZE_T    atPos /* [in] size_t  atPos  */) PURE;
                    CLIMETHOD(removeCellFromRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                      , SIZE_T    atPos /* [in] size_t  atPos  */
                                                 ) PURE;
                    CLIMETHOD(cellsClear) (THIS) PURE;
                    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _spacing /* [out] ::cli::gui::CSpacing _spacing  */) PURE;
                    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  */) PURE;
                    CLIMETHOD(ncDrawBackgroundGet) (THIS_ BOOL*    _ncDrawBackground /* [out] bool _ncDrawBackground  */) PURE;
                    CLIMETHOD(ncDrawBackgroundSet) (THIS_ BOOL    _ncDrawBackground /* [in] bool  _ncDrawBackground  */) PURE;
                    CLIMETHOD(ncBackgroundColorGet) (THIS_ COLORREF*    _ncBackgroundColor /* [out] colorref _ncBackgroundColor  */) PURE;
                    CLIMETHOD(ncBackgroundColorSet) (THIS_ COLORREF    _ncBackgroundColor /* [in] colorref  _ncBackgroundColor  */) PURE;
                    CLIMETHOD(ncActiveBackgroundColorGet) (THIS_ COLORREF*    _ncActiveBackgroundColor /* [out] colorref _ncActiveBackgroundColor  */) PURE;
                    CLIMETHOD(ncActiveBackgroundColorSet) (THIS_ COLORREF    _ncActiveBackgroundColor /* [in] colorref  _ncActiveBackgroundColor  */) PURE;
                    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool _drawBackground  */) PURE;
                    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  _drawBackground  */) PURE;
                    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */) PURE;
                    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */) PURE;
                    CLIMETHOD(activeBackgroundColorGet) (THIS_ COLORREF*    _activeBackgroundColor /* [out] colorref _activeBackgroundColor  */) PURE;
                    CLIMETHOD(activeBackgroundColorSet) (THIS_ COLORREF    _activeBackgroundColor /* [in] colorref  _activeBackgroundColor  */) PURE;
                    CLIMETHOD(cellSpacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _cellSpacing /* [out] ::cli::gui::CSpacing _cellSpacing  */) PURE;
                    CLIMETHOD(cellSpacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _cellSpacing /* [in,ref] ::cli::gui::CSpacing  _cellSpacing  */) PURE;
                    CLIMETHOD(cellNcBackgroundColorGet) (THIS_ COLORREF*    _cellNcBackgroundColor /* [out] colorref _cellNcBackgroundColor  */) PURE;
                    CLIMETHOD(cellNcBackgroundColorSet) (THIS_ COLORREF    _cellNcBackgroundColor /* [in] colorref  _cellNcBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellNcBackgroundColorGet) (THIS_ COLORREF*    _activeCellNcBackgroundColor /* [out] colorref _activeCellNcBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellNcBackgroundColorSet) (THIS_ COLORREF    _activeCellNcBackgroundColor /* [in] colorref  _activeCellNcBackgroundColor  */) PURE;
                    CLIMETHOD(cellBackgroundColorGet) (THIS_ COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */) PURE;
                    CLIMETHOD(cellBackgroundColorSet) (THIS_ COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellBackgroundColorGet) (THIS_ COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellBackgroundColorSet) (THIS_ COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */) PURE;
                    CLIMETHOD(alignmentGet) (THIS_ ENUM_CLI_GUI_EALIGNMENT*    _alignment /* [out] ::cli::gui::EAlignment _alignment  */) PURE;
                    CLIMETHOD(alignmentSet) (THIS_ ENUM_CLI_GUI_EALIGNMENT    _alignment /* [in] ::cli::gui::EAlignment  _alignment  */) PURE;
                    CLIMETHOD(cellSizesGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _cellSizes /* [out] ::cli::drawing::CPoint _cellSizes  */) PURE;
                    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */) PURE;
                    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */) PURE;
                    CLIMETHOD(visibleGet) (THIS_ BOOL*    _visible /* [out] bool _visible  */) PURE;
                    CLIMETHOD(visibleSet) (THIS_ BOOL    _visible /* [in] bool  _visible  */) PURE;
                    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            ) PURE;
                    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                    , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                               ) PURE;
                    CLIMETHOD(invalidateRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                  , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                             ) PURE;
                    CLIMETHOD(invalidate) (THIS_ ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */) PURE;
                    CLIMETHOD(invalidateCellPtr) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                                      , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                                 ) PURE;
                    CLIMETHOD(invalidateCellIdx) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                      , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                      , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                                 ) PURE;
                    CLIMETHOD(cellNotifyIdx) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                  , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                  , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                                  , UINT    param /* [in] uint  param  */
                                             ) PURE;
                    CLIMETHOD(cellNotifyPtr) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                                  , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                                  , UINT    param /* [in] uint  param  */
                                             ) PURE;
                    CLIMETHOD(getCellPosSize) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                                   , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                                              ) PURE;
                    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       ) PURE;
                    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iRow >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_IROW_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iRow* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iRow > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iRow wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IROW >
                                              */
                         >
                class CiRowWrapper
                {
                    public:
                
                        typedef  CiRowWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiRowWrapper() :
                           pif(0) {}
                
                        CiRowWrapper( iRow *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiRowWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiRowWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiRowWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiRowWrapper(const CiRowWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiRowWrapper()  { }
                
                        CiRowWrapper& operator=(const CiRowWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        RCODE getIUnknownIndex( INTERFACE_CLI_IUNKNOWN*    pcell /* [in] ::cli::iUnknown*  pcell  */
                                              , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                              )
                           {
                        
                        
                            return pif->getIUnknownIndex(pcell, idxFound);
                           }
                        
                        RCODE getCellIndex( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                          , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                          )
                           {
                        
                        
                            return pif->getCellIndex(pcell, idxFound);
                           }
                        
                        RCODE getMultiCellIndex( INTERFACE_CLI_GUI_CELLGRID_IMULTICELL*    pcell /* [in] ::cli::gui::cellgrid::iMultiCell*  pcell  */
                                               , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                               )
                           {
                        
                        
                            return pif->getMultiCellIndex(pcell, idxFound);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IGRID* get_ownerGrid( )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IGRID* tmpVal;
                            RCODE res = ownerGridGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ownerGrid( INTERFACE_CLI_GUI_CELLGRID_IGRID* _ownerGrid
                                          )
                           {
                            RCODE res = ownerGridSet( _ownerGrid );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IGRID*, ownerGrid );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ownerGridGet( INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* _ownerGrid  */)
                           {
                        
                            return pif->ownerGridGet(_ownerGrid);
                           }
                        
                        RCODE ownerGridSet( INTERFACE_CLI_GUI_CELLGRID_IGRID*    _ownerGrid /* [in] ::cli::gui::cellgrid::iGrid*  _ownerGrid  */)
                           {
                        
                            return pif->ownerGridSet(_ownerGrid);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL* get_cells( SIZE_T idx1 )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL* tmpVal;
                            RCODE res = cellsGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size_cells(  )
                           {
                            SIZE_T size;
                            RCODE res = cellsSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*, cells, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsGet( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL**    _cells /* [out] ::cli::gui::cellgrid::iSimpleCell* _cells  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                           {
                        
                        
                            return pif->cellsGet(_cells, idx1);
                           }
                        
                        RCODE cellsSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellsSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL* get_multiCells( SIZE_T idx1 )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IMULTICELL* tmpVal;
                            RCODE res = multiCellsGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size_multiCells(  )
                           {
                            SIZE_T size;
                            RCODE res = multiCellsSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IMULTICELL*, multiCells, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE multiCellsGet( INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    _multiCells /* [out] ::cli::gui::cellgrid::iMultiCell* _multiCells  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           )
                           {
                        
                        
                            return pif->multiCellsGet(_multiCells, idx1);
                           }
                        
                        RCODE multiCellsSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->multiCellsSize(_size);
                           }
                        
                        RCODE addCell( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */)
                           {
                        
                            return pif->addCell(pCell);
                           }
                        
                        RCODE addCellToRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                          , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                          )
                           {
                        
                        
                            return pif->addCellToRow(rowIdx, pCell);
                           }
                        
                        RCODE insertCell( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                        , SIZE_T    atPos /* [in] size_t  atPos  */
                                        )
                           {
                        
                        
                            return pif->insertCell(pCell, atPos);
                           }
                        
                        RCODE insertCellToRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                             , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                             , SIZE_T    atPos /* [in] size_t  atPos  */
                                             )
                           {
                        
                        
                        
                            return pif->insertCellToRow(rowIdx, pCell, atPos);
                           }
                        
                        RCODE removeCell( SIZE_T    atPos /* [in] size_t  atPos  */)
                           {
                        
                            return pif->removeCell(atPos);
                           }
                        
                        RCODE removeCellFromRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                               , SIZE_T    atPos /* [in] size_t  atPos  */
                                               )
                           {
                        
                        
                            return pif->removeCellFromRow(rowIdx, atPos);
                           }
                        
                        RCODE cellsClear( )
                           {
                            return pif->cellsClear();
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CSPACING get_spacing( )
                           {
                            STRUCT_CLI_GUI_CSPACING tmpVal;
                            RCODE res = spacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_spacing( const STRUCT_CLI_GUI_CSPACING &_spacing
                                        )
                           {
                            RCODE res = spacingSet( _spacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CSPACING, spacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE spacingGet( STRUCT_CLI_GUI_CSPACING    &_spacing /* [out] ::cli::gui::CSpacing _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingGet(&_spacing);
                           }
                        
                        RCODE spacingSet( const STRUCT_CLI_GUI_CSPACING    &_spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingSet(&_spacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_ncDrawBackground( )
                           {
                            BOOL tmpVal;
                            RCODE res = ncDrawBackgroundGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncDrawBackground( BOOL _ncDrawBackground
                                                 )
                           {
                            RCODE res = ncDrawBackgroundSet( _ncDrawBackground );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, ncDrawBackground );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncDrawBackgroundGet( BOOL*    _ncDrawBackground /* [out] bool _ncDrawBackground  */)
                           {
                        
                            return pif->ncDrawBackgroundGet(_ncDrawBackground);
                           }
                        
                        RCODE ncDrawBackgroundSet( BOOL    _ncDrawBackground /* [in] bool  _ncDrawBackground  */)
                           {
                        
                            return pif->ncDrawBackgroundSet(_ncDrawBackground);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_ncBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = ncBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncBackgroundColor( COLORREF _ncBackgroundColor
                                                  )
                           {
                            RCODE res = ncBackgroundColorSet( _ncBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, ncBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncBackgroundColorGet( COLORREF*    _ncBackgroundColor /* [out] colorref _ncBackgroundColor  */)
                           {
                        
                            return pif->ncBackgroundColorGet(_ncBackgroundColor);
                           }
                        
                        RCODE ncBackgroundColorSet( COLORREF    _ncBackgroundColor /* [in] colorref  _ncBackgroundColor  */)
                           {
                        
                            return pif->ncBackgroundColorSet(_ncBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_ncActiveBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = ncActiveBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_ncActiveBackgroundColor( COLORREF _ncActiveBackgroundColor
                                                        )
                           {
                            RCODE res = ncActiveBackgroundColorSet( _ncActiveBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, ncActiveBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE ncActiveBackgroundColorGet( COLORREF*    _ncActiveBackgroundColor /* [out] colorref _ncActiveBackgroundColor  */)
                           {
                        
                            return pif->ncActiveBackgroundColorGet(_ncActiveBackgroundColor);
                           }
                        
                        RCODE ncActiveBackgroundColorSet( COLORREF    _ncActiveBackgroundColor /* [in] colorref  _ncActiveBackgroundColor  */)
                           {
                        
                            return pif->ncActiveBackgroundColorSet(_ncActiveBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_drawBackground( )
                           {
                            BOOL tmpVal;
                            RCODE res = drawBackgroundGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_drawBackground( BOOL _drawBackground
                                               )
                           {
                            RCODE res = drawBackgroundSet( _drawBackground );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, drawBackground );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE drawBackgroundGet( BOOL*    _drawBackground /* [out] bool _drawBackground  */)
                           {
                        
                            return pif->drawBackgroundGet(_drawBackground);
                           }
                        
                        RCODE drawBackgroundSet( BOOL    _drawBackground /* [in] bool  _drawBackground  */)
                           {
                        
                            return pif->drawBackgroundSet(_drawBackground);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_backgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = backgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_backgroundColor( COLORREF _backgroundColor
                                                )
                           {
                            RCODE res = backgroundColorSet( _backgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, backgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE backgroundColorGet( COLORREF*    _backgroundColor /* [out] colorref _backgroundColor  */)
                           {
                        
                            return pif->backgroundColorGet(_backgroundColor);
                           }
                        
                        RCODE backgroundColorSet( COLORREF    _backgroundColor /* [in] colorref  _backgroundColor  */)
                           {
                        
                            return pif->backgroundColorSet(_backgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeBackgroundColor( COLORREF _activeBackgroundColor
                                                      )
                           {
                            RCODE res = activeBackgroundColorSet( _activeBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeBackgroundColorGet( COLORREF*    _activeBackgroundColor /* [out] colorref _activeBackgroundColor  */)
                           {
                        
                            return pif->activeBackgroundColorGet(_activeBackgroundColor);
                           }
                        
                        RCODE activeBackgroundColorSet( COLORREF    _activeBackgroundColor /* [in] colorref  _activeBackgroundColor  */)
                           {
                        
                            return pif->activeBackgroundColorSet(_activeBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CSPACING get_cellSpacing( )
                           {
                            STRUCT_CLI_GUI_CSPACING tmpVal;
                            RCODE res = cellSpacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellSpacing( const STRUCT_CLI_GUI_CSPACING &_cellSpacing
                                            )
                           {
                            RCODE res = cellSpacingSet( _cellSpacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CSPACING, cellSpacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellSpacingGet( STRUCT_CLI_GUI_CSPACING    &_cellSpacing /* [out] ::cli::gui::CSpacing _cellSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSpacingGet(&_cellSpacing);
                           }
                        
                        RCODE cellSpacingSet( const STRUCT_CLI_GUI_CSPACING    &_cellSpacing /* [in,ref] ::cli::gui::CSpacing  _cellSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSpacingSet(&_cellSpacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_cellNcBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = cellNcBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellNcBackgroundColor( COLORREF _cellNcBackgroundColor
                                                      )
                           {
                            RCODE res = cellNcBackgroundColorSet( _cellNcBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, cellNcBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellNcBackgroundColorGet( COLORREF*    _cellNcBackgroundColor /* [out] colorref _cellNcBackgroundColor  */)
                           {
                        
                            return pif->cellNcBackgroundColorGet(_cellNcBackgroundColor);
                           }
                        
                        RCODE cellNcBackgroundColorSet( COLORREF    _cellNcBackgroundColor /* [in] colorref  _cellNcBackgroundColor  */)
                           {
                        
                            return pif->cellNcBackgroundColorSet(_cellNcBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeCellNcBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeCellNcBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCellNcBackgroundColor( COLORREF _activeCellNcBackgroundColor
                                                            )
                           {
                            RCODE res = activeCellNcBackgroundColorSet( _activeCellNcBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeCellNcBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellNcBackgroundColorGet( COLORREF*    _activeCellNcBackgroundColor /* [out] colorref _activeCellNcBackgroundColor  */)
                           {
                        
                            return pif->activeCellNcBackgroundColorGet(_activeCellNcBackgroundColor);
                           }
                        
                        RCODE activeCellNcBackgroundColorSet( COLORREF    _activeCellNcBackgroundColor /* [in] colorref  _activeCellNcBackgroundColor  */)
                           {
                        
                            return pif->activeCellNcBackgroundColorSet(_activeCellNcBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_cellBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = cellBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellBackgroundColor( COLORREF _cellBackgroundColor
                                                    )
                           {
                            RCODE res = cellBackgroundColorSet( _cellBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, cellBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellBackgroundColorGet( COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */)
                           {
                        
                            return pif->cellBackgroundColorGet(_cellBackgroundColor);
                           }
                        
                        RCODE cellBackgroundColorSet( COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */)
                           {
                        
                            return pif->cellBackgroundColorSet(_cellBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeCellBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeCellBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCellBackgroundColor( COLORREF _activeCellBackgroundColor
                                                          )
                           {
                            RCODE res = activeCellBackgroundColorSet( _activeCellBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeCellBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellBackgroundColorGet( COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */)
                           {
                        
                            return pif->activeCellBackgroundColorGet(_activeCellBackgroundColor);
                           }
                        
                        RCODE activeCellBackgroundColorSet( COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */)
                           {
                        
                            return pif->activeCellBackgroundColorSet(_activeCellBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_EALIGNMENT get_alignment( )
                           {
                            ENUM_CLI_GUI_EALIGNMENT tmpVal;
                            RCODE res = alignmentGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_alignment( ENUM_CLI_GUI_EALIGNMENT _alignment
                                          )
                           {
                            RCODE res = alignmentSet( _alignment );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_GUI_EALIGNMENT, alignment );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE alignmentGet( ENUM_CLI_GUI_EALIGNMENT*    _alignment /* [out] ::cli::gui::EAlignment _alignment  */)
                           {
                        
                            return pif->alignmentGet(_alignment);
                           }
                        
                        RCODE alignmentSet( ENUM_CLI_GUI_EALIGNMENT    _alignment /* [in] ::cli::gui::EAlignment  _alignment  */)
                           {
                        
                            return pif->alignmentSet(_alignment);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_cellSizes( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = cellSizesGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, cellSizes );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellSizesGet( STRUCT_CLI_DRAWING_CPOINT    &_cellSizes /* [out] ::cli::drawing::CPoint _cellSizes  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSizesGet(&_cellSizes);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_size( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = sizeGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_size( const STRUCT_CLI_DRAWING_CPOINT &_size
                                     )
                           {
                            RCODE res = sizeSet( _size );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, size );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeGet( STRUCT_CLI_DRAWING_CPOINT    &_size /* [out] ::cli::drawing::CPoint _size  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->sizeGet(&_size);
                           }
                        
                        RCODE sizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_size /* [in,ref] ::cli::drawing::CPoint  _size  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->sizeSet(&_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_visible( )
                           {
                            BOOL tmpVal;
                            RCODE res = visibleGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_visible( BOOL _visible
                                        )
                           {
                            RCODE res = visibleSet( _visible );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, visible );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE visibleGet( BOOL*    _visible /* [out] bool _visible  */)
                           {
                        
                            return pif->visibleGet(_visible);
                           }
                        
                        RCODE visibleSet( BOOL    _visible /* [in] bool  _visible  */)
                           {
                        
                            return pif->visibleSet(_visible);
                           }
                        
                        RCODE updateConfig( INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
                           {
                        
                        
                            return pif->updateConfig(appCfg, idx1);
                           }
                        
                        RCODE calculateLimits( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                             , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                             )
                           {
                        
                        
                            return pif->calculateLimits(pdc, rowIdx);
                           }
                        
                        RCODE invalidateRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                           , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                           )
                           {
                        
                        
                            return pif->invalidateRow(rowIdx, invalidateType);
                           }
                        
                        RCODE invalidate( ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */)
                           {
                        
                            return pif->invalidate(invalidateType);
                           }
                        
                        RCODE invalidateCellPtr( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                               , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                               )
                           {
                        
                        
                            return pif->invalidateCellPtr(pcell, invalidateType);
                           }
                        
                        RCODE invalidateCellIdx( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                               , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                               , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                               )
                           {
                        
                        
                        
                            return pif->invalidateCellIdx(rowIdx, cellIdx, invalidateType);
                           }
                        
                        RCODE cellNotifyIdx( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                           , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                           , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                           , UINT    param /* [in] uint  param  */
                                           )
                           {
                        
                        
                        
                        
                            return pif->cellNotifyIdx(rowIdx, cellIdx, eventType, param);
                           }
                        
                        RCODE cellNotifyPtr( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                           , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                           , UINT    param /* [in] uint  param  */
                                           )
                           {
                        
                        
                        
                            return pif->cellNotifyPtr(pcell, eventType, param);
                           }
                        
                        RCODE getCellPosSize( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                            , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                                            )
                           {
                        
                        
                        
                        
                        
                        
                            return pif->getCellPosSize(rowIdx, cellIdx, ncLeftTop, ncWidthHeight, clientLeftTop, clientWidthHeight);
                           }
                        
                        RCODE ncPaint( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                     , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
                           {
                        
                        
                        
                            return pif->ncPaint(pdc, &paintAreaSize, idx1);
                           }
                        
                        RCODE paintClient( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  (struct passed by ref in wrapper) */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         )
                           {
                        
                        
                        
                            return pif->paintClient(pdc, &paintAreaSize, idx1);
                           }
                        

                
                
                }; // class CiRowWrapper
                
                typedef CiRowWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IROW     > >  CiRow;
                typedef CiRowWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_IROW > >  CiRow_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif





#endif /* CLI_GUI_CG2_IROW_H */
