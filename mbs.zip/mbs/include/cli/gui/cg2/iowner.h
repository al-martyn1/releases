#ifndef CLI_GUI_CG2_IOWNER_H
#define CLI_GUI_CG2_IOWNER_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/cg2/iowner.h>", CLI_GUI_CG2_IOWNER_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_CG2_IOWNER_H
    #include <cli/gui/cg2/iowner.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

#ifndef CLI_GUI_CG2_TYPES_H
    #include <cli/gui/cg2/types.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iGridOwner */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; /* namespace cli */
    namespace cli {
        namespace drawing {
            interface                                iDrawContext1;
            #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
                #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               ::cli::drawing::iDrawContext1
            #endif

        }; /* namespace drawing */
    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    typedef interface tag_cli_drawing_iDrawContext1              cli_drawing_iDrawContext1;
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
        #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               struct tag_cli_drawing_iDrawContext1
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER_IID
    #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER_IID    "/cli/gui/cellgrid/iGridOwner"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iGridOwner
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER
       #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER    ::cli::gui::cellgrid::iGridOwner
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iGridOwner
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER
       #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER    cli_gui_cellgrid_iGridOwner
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iGridOwner methods */
                    CLIMETHOD(getDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */) PURE;
                    CLIMETHOD(getDrawContextForRectUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                                , const STRUCT_CLI_DRAWING_CPOINT*    gridPosLeftTop /* [in,ref] ::cli::drawing::CPoint  gridPosLeftTop  */
                                                                , const STRUCT_CLI_DRAWING_CPOINT*    rectSize /* [in,ref] ::cli::drawing::CPoint  rectSize  */
                                                           ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iGridOwner >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iGridOwner* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iGridOwner > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iGridOwner wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER >
                                              */
                         >
                class CiGridOwnerWrapper
                {
                    public:
                
                        typedef  CiGridOwnerWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiGridOwnerWrapper() :
                           pif(0) {}
                
                        CiGridOwnerWrapper( iGridOwner *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiGridOwnerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiGridOwnerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiGridOwnerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiGridOwnerWrapper(const CiGridOwnerWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiGridOwnerWrapper()  { }
                
                        CiGridOwnerWrapper& operator=(const CiGridOwnerWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        RCODE getDrawContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
                           {
                        
                            return pif->getDrawContext(pdc);
                           }
                        
                        RCODE getDrawContextForRectUpdate( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                         , const STRUCT_CLI_DRAWING_CPOINT    &gridPosLeftTop /* [in,ref] ::cli::drawing::CPoint  gridPosLeftTop  (struct passed by ref in wrapper) */
                                                         , const STRUCT_CLI_DRAWING_CPOINT    &rectSize /* [in,ref] ::cli::drawing::CPoint  rectSize  (struct passed by ref in wrapper) */
                                                         )
                           {
                        
                        
                        
                            return pif->getDrawContextForRectUpdate(pdc, &gridPosLeftTop, &rectSize);
                           }
                        

                
                
                }; // class CiGridOwnerWrapper
                
                typedef CiGridOwnerWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER     > >  CiGridOwner;
                typedef CiGridOwnerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER > >  CiGridOwner_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif





#endif /* CLI_GUI_CG2_IOWNER_H */
