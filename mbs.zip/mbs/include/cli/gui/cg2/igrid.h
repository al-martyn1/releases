#ifndef CLI_GUI_CG2_IGRID_H
#define CLI_GUI_CG2_IGRID_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/cg2/igrid.h>", CLI_GUI_CG2_IGRID_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_CG2_IGRID_H
    #include <cli/gui/cg2/igrid.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

#ifndef CLI_GUI_CG2_TYPES_H
    #include <cli/gui/cg2/types.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::gui::cellgrid::iGrid */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; /* namespace cli */
    namespace cli {
        namespace app {
            interface                                iConfig;
            #ifndef INTERFACE_CLI_APP_ICONFIG
                #define INTERFACE_CLI_APP_ICONFIG         ::cli::app::iConfig
            #endif

        }; /* namespace app */
    }; /* namespace cli */
    namespace cli {
        namespace drawing {
            interface                                iDrawContext1;
            #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
                #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               ::cli::drawing::iDrawContext1
            #endif

        }; /* namespace drawing */
    }; /* namespace cli */
    namespace cli {
        namespace gui {
        }; /* namespace gui */
    }; /* namespace cli */
    namespace cli {
        namespace gui {
            namespace cellgrid {
                interface                                iGridOwner;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER
                    #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER             ::cli::gui::cellgrid::iGridOwner
                #endif

                interface                                iMultiCell;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IMULTICELL
                    #define INTERFACE_CLI_GUI_CELLGRID_IMULTICELL             ::cli::gui::cellgrid::iMultiCell
                #endif

                interface                                iRow;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
                    #define INTERFACE_CLI_GUI_CELLGRID_IROW   ::cli::gui::cellgrid::iRow
                #endif

                interface                                iSimpleCell;
                #ifndef INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL
                    #define INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL            ::cli::gui::cellgrid::iSimpleCell
                #endif

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    typedef interface tag_cli_app_iConfig    cli_app_iConfig;
    #ifndef INTERFACE_CLI_APP_ICONFIG
        #define INTERFACE_CLI_APP_ICONFIG         struct tag_cli_app_iConfig
    #endif

    typedef interface tag_cli_drawing_iDrawContext1              cli_drawing_iDrawContext1;
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
        #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               struct tag_cli_drawing_iDrawContext1
    #endif

    typedef interface tag_cli_gui_cellgrid_iGridOwner            cli_gui_cellgrid_iGridOwner;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER
        #define INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER             struct tag_cli_gui_cellgrid_iGridOwner
    #endif

    typedef interface tag_cli_gui_cellgrid_iMultiCell            cli_gui_cellgrid_iMultiCell;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IMULTICELL
        #define INTERFACE_CLI_GUI_CELLGRID_IMULTICELL             struct tag_cli_gui_cellgrid_iMultiCell
    #endif

    typedef interface tag_cli_gui_cellgrid_iRow                  cli_gui_cellgrid_iRow;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IROW
        #define INTERFACE_CLI_GUI_CELLGRID_IROW   struct tag_cli_gui_cellgrid_iRow
    #endif

    typedef interface tag_cli_gui_cellgrid_iSimpleCell           cli_gui_cellgrid_iSimpleCell;
    #ifndef INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL
        #define INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL            struct tag_cli_gui_cellgrid_iSimpleCell
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID_IID
    #define INTERFACE_CLI_GUI_CELLGRID_IGRID_IID    "/cli/gui/cellgrid/iGrid"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
            namespace cellgrid {
    #define INTERFACE iGrid
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
       #define INTERFACE_CLI_GUI_CELLGRID_IGRID    ::cli::gui::cellgrid::iGrid
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_cellgrid_iGrid
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_CELLGRID_IGRID
       #define INTERFACE_CLI_GUI_CELLGRID_IGRID    cli_gui_cellgrid_iGrid
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::gui::cellgrid::iGrid methods */
                    CLIMETHOD(gridOwnerGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER**    _gridOwner /* [out] ::cli::gui::cellgrid::iGridOwner* _gridOwner  */) PURE;
                    CLIMETHOD(gridOwnerSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER*    _gridOwner /* [in] ::cli::gui::cellgrid::iGridOwner*  _gridOwner  */) PURE;
                    CLIMETHOD(cellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL**    _cells /* [out] ::cli::gui::cellgrid::iSimpleCell* _cells  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        ) PURE;
                    CLIMETHOD(cellsSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellsSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          ) PURE;
                    CLIMETHOD(multiCellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    _multiCells /* [out] ::cli::gui::cellgrid::iMultiCell* _multiCells  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             ) PURE;
                    CLIMETHOD(multiCellsSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(multiCellsSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               ) PURE;
                    CLIMETHOD(rowsVisibleGet) (THIS_ BOOL*    _rowsVisible /* [out] bool _rowsVisible  */
                                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              ) PURE;
                    CLIMETHOD(rowsVisibleSet) (THIS_ BOOL    _rowsVisible /* [in] bool  _rowsVisible  */
                                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              ) PURE;
                    CLIMETHOD(rowsVisibleSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellsVisibleGet) (THIS_ BOOL*    _cellsVisible /* [out] bool _cellsVisible  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(cellsVisibleSet) (THIS_ BOOL    _cellsVisible /* [in] bool  _cellsVisible  */
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                                               ) PURE;
                    CLIMETHOD(cellsVisibleSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellsVisibleSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 ) PURE;
                    CLIMETHOD(cellsActiveGet) (THIS_ BOOL*    _cellsActive /* [out] bool _cellsActive  */
                                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                   , SIZE_T    idx2 /* [in] size_t  idx2  */
                                              ) PURE;
                    CLIMETHOD(cellsActiveSet) (THIS_ BOOL    _cellsActive /* [in] bool  _cellsActive  */
                                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                   , SIZE_T    idx2 /* [in] size_t  idx2  */
                                              ) PURE;
                    CLIMETHOD(cellsActiveSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                    CLIMETHOD(cellsActiveSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                ) PURE;
                    CLIMETHOD(resetActiveCell) (THIS) PURE;
                    CLIMETHOD(getIUnknownIndex) (THIS_ INTERFACE_CLI_IUNKNOWN*    pRow /* [in] ::cli::iUnknown*  pRow  */
                                                     , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                                ) PURE;
                    CLIMETHOD(getRowIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                                                , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                           ) PURE;
                    CLIMETHOD(lockUpdateGet) (THIS_ BOOL*    _lockUpdate /* [out] bool _lockUpdate  */) PURE;
                    CLIMETHOD(lockUpdateSet) (THIS_ BOOL    _lockUpdate /* [in] bool  _lockUpdate  */) PURE;
                    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _spacing /* [out] ::cli::gui::CSpacing _spacing  */) PURE;
                    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  */) PURE;
                    CLIMETHOD(rowSpacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _rowSpacing /* [out] ::cli::gui::CSpacing _rowSpacing  */) PURE;
                    CLIMETHOD(rowSpacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _rowSpacing /* [in,ref] ::cli::gui::CSpacing  _rowSpacing  */) PURE;
                    CLIMETHOD(cellSpacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _cellSpacing /* [out] ::cli::gui::CSpacing _cellSpacing  */) PURE;
                    CLIMETHOD(cellSpacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _cellSpacing /* [in,ref] ::cli::gui::CSpacing  _cellSpacing  */) PURE;
                    CLIMETHOD(gridNcBackgroundColorGet) (THIS_ COLORREF*    _gridNcBackgroundColor /* [out] colorref _gridNcBackgroundColor  */) PURE;
                    CLIMETHOD(gridNcBackgroundColorSet) (THIS_ COLORREF    _gridNcBackgroundColor /* [in] colorref  _gridNcBackgroundColor  */) PURE;
                    CLIMETHOD(gridBackgroundColorGet) (THIS_ COLORREF*    _gridBackgroundColor /* [out] colorref _gridBackgroundColor  */) PURE;
                    CLIMETHOD(gridBackgroundColorSet) (THIS_ COLORREF    _gridBackgroundColor /* [in] colorref  _gridBackgroundColor  */) PURE;
                    CLIMETHOD(rowNcBackgroundColorGet) (THIS_ COLORREF*    _rowNcBackgroundColor /* [out] colorref _rowNcBackgroundColor  */) PURE;
                    CLIMETHOD(rowNcBackgroundColorSet) (THIS_ COLORREF    _rowNcBackgroundColor /* [in] colorref  _rowNcBackgroundColor  */) PURE;
                    CLIMETHOD(activeRowNcBackgroundColorGet) (THIS_ COLORREF*    _activeRowNcBackgroundColor /* [out] colorref _activeRowNcBackgroundColor  */) PURE;
                    CLIMETHOD(activeRowNcBackgroundColorSet) (THIS_ COLORREF    _activeRowNcBackgroundColor /* [in] colorref  _activeRowNcBackgroundColor  */) PURE;
                    CLIMETHOD(rowBackgroundColorGet) (THIS_ COLORREF*    _rowBackgroundColor /* [out] colorref _rowBackgroundColor  */) PURE;
                    CLIMETHOD(rowBackgroundColorSet) (THIS_ COLORREF    _rowBackgroundColor /* [in] colorref  _rowBackgroundColor  */) PURE;
                    CLIMETHOD(activeRowBackgroundColorGet) (THIS_ COLORREF*    _activeRowBackgroundColor /* [out] colorref _activeRowBackgroundColor  */) PURE;
                    CLIMETHOD(activeRowBackgroundColorSet) (THIS_ COLORREF    _activeRowBackgroundColor /* [in] colorref  _activeRowBackgroundColor  */) PURE;
                    CLIMETHOD(cellNcBackgroundColorGet) (THIS_ COLORREF*    _cellNcBackgroundColor /* [out] colorref _cellNcBackgroundColor  */) PURE;
                    CLIMETHOD(cellNcBackgroundColorSet) (THIS_ COLORREF    _cellNcBackgroundColor /* [in] colorref  _cellNcBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellNcBackgroundColorGet) (THIS_ COLORREF*    _activeCellNcBackgroundColor /* [out] colorref _activeCellNcBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellNcBackgroundColorSet) (THIS_ COLORREF    _activeCellNcBackgroundColor /* [in] colorref  _activeCellNcBackgroundColor  */) PURE;
                    CLIMETHOD(cellBackgroundColorGet) (THIS_ COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */) PURE;
                    CLIMETHOD(cellBackgroundColorSet) (THIS_ COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellBackgroundColorGet) (THIS_ COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */) PURE;
                    CLIMETHOD(activeCellBackgroundColorSet) (THIS_ COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */) PURE;
                    CLIMETHOD(cellsAlignmentGet) (THIS_ ENUM_CLI_GUI_EALIGNMENT*    _cellsAlignment /* [out] ::cli::gui::EAlignment _cellsAlignment  */) PURE;
                    CLIMETHOD(cellsAlignmentSet) (THIS_ ENUM_CLI_GUI_EALIGNMENT    _cellsAlignment /* [in] ::cli::gui::EAlignment  _cellsAlignment  */) PURE;
                    CLIMETHOD(rowsAlignmentGet) (THIS_ ENUM_CLI_GUI_EALIGNMENT*    _rowsAlignment /* [out] ::cli::gui::EAlignment _rowsAlignment  */) PURE;
                    CLIMETHOD(rowsAlignmentSet) (THIS_ ENUM_CLI_GUI_EALIGNMENT    _rowsAlignment /* [in] ::cli::gui::EAlignment  _rowsAlignment  */) PURE;
                    CLIMETHOD(rowSizesGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _rowSizes /* [out] ::cli::drawing::CPoint _rowSizes  */) PURE;
                    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */) PURE;
                    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */) PURE;
                    CLIMETHOD(fullSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _fullSize /* [out] ::cli::drawing::CPoint _fullSize  */) PURE;
                    CLIMETHOD(activeRowGet) (THIS_ SIZE_T*    _activeRow /* [out] size_t _activeRow  */) PURE;
                    CLIMETHOD(activeCellGet) (THIS_ SIZE_T*    _activeCell /* [out] size_t _activeCell  */) PURE;
                    CLIMETHOD(activateOnClickGet) (THIS_ BOOL*    _activateOnClick /* [out] bool _activateOnClick  */) PURE;
                    CLIMETHOD(activateOnClickSet) (THIS_ BOOL    _activateOnClick /* [in] bool  _activateOnClick  */) PURE;
                    CLIMETHOD(setCapture) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                               , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                          ) PURE;
                    CLIMETHOD(clearCapture) (THIS) PURE;
                    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */) PURE;
                    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */) PURE;
                    CLIMETHOD(insertRow) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                                              , SIZE_T    atPos /* [in] size_t  atPos  */
                                         ) PURE;
                    CLIMETHOD(addRow) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */) PURE;
                    CLIMETHOD(removeRow) (THIS_ SIZE_T    atPos /* [in] size_t  atPos  */) PURE;
                    CLIMETHOD(rowsClear) (THIS) PURE;
                    CLIMETHOD(insertCellToRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                    , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                                    , SIZE_T    atPos /* [in] size_t  atPos  */
                                               ) PURE;
                    CLIMETHOD(addCellToRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                 , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                            ) PURE;
                    CLIMETHOD(removeCellFromRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                      , SIZE_T    atPos /* [in] size_t  atPos  */
                                                 ) PURE;
                    CLIMETHOD(rowCellsClear) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */) PURE;
                    CLIMETHOD(invalidateRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                  , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                             ) PURE;
                    CLIMETHOD(invalidateCell) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                   , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                              ) PURE;
                    CLIMETHOD(updatePaint) (THIS) PURE;
                    CLIMETHOD(getDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */) PURE;
                    CLIMETHOD(partialPaintOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                          , SIZE_T    firstRowIdx /* [in] size_t  firstRowIdx  */
                                                          , SIZE_T    firstRowCellIdx /* [in] size_t  firstRowCellIdx  */
                                                          , SIZE_T    lastRowIdx /* [in] size_t  lastRowIdx  */
                                                          , SIZE_T    lastRowCellIdx /* [in] size_t  lastRowCellIdx  */
                                                     ) PURE;
                    CLIMETHOD(partialPaint) (THIS_ SIZE_T    firstRowIdx /* [in] size_t  firstRowIdx  */
                                                 , SIZE_T    firstRowCellIdx /* [in] size_t  firstRowCellIdx  */
                                                 , SIZE_T    lastRowIdx /* [in] size_t  lastRowIdx  */
                                                 , SIZE_T    lastRowCellIdx /* [in] size_t  lastRowCellIdx  */
                                            ) PURE;
                    CLIMETHOD(paintOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */) PURE;
                    CLIMETHOD(paint) (THIS) PURE;
                    CLIMETHOD(paintCellOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                  ) PURE;
                    CLIMETHOD(paintRowOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                      , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                 ) PURE;
                    CLIMETHOD(paintCell) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                              , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                         ) PURE;
                    CLIMETHOD(paintRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */) PURE;
                    CLIMETHOD(hitTest) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                            , SIZE_T*    hitRow /* [out] size_t hitRow  */
                                            , SIZE_T*    hitCell /* [out] size_t hitCell  */
                                            , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                                            , STRUCT_CLI_DRAWING_CPOINT*    translatedMicePos /* [out] ::cli::drawing::CPoint translatedMicePos  */
                                            , INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    pCell /* [out] ::cli::gui::cellgrid::iMultiCell* pCell  */
                                       ) PURE;
                    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */) PURE;
                    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                            ) PURE;
                    CLIMETHOD(getRowNcDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                        , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                   ) PURE;
                    CLIMETHOD(getRowDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                      , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                 ) PURE;
                    CLIMETHOD(getCellNcDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                         , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                         , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                    ) PURE;
                    CLIMETHOD(getCellDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                  ) PURE;
                    CLIMETHOD(rowNotifyIdx) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                 , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                 , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                                 , UINT    param /* [in] uint  param  */
                                            ) PURE;
                    CLIMETHOD(getRowPosSize) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                  , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                                  , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                                  , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                                  , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                                             ) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iGrid >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_CELLGRID_IGRID_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::cellgrid::iGrid* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::cellgrid::iGrid > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            namespace cellgrid {
                // interface ::cli::gui::cellgrid::iGrid wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IGRID >
                                              */
                         >
                class CiGridWrapper
                {
                    public:
                
                        typedef  CiGridWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiGridWrapper() :
                           pif(0) {}
                
                        CiGridWrapper( iGrid *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiGridWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiGridWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiGridWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiGridWrapper(const CiGridWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiGridWrapper()  { }
                
                        CiGridWrapper& operator=(const CiGridWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER* get_gridOwner( )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER* tmpVal;
                            RCODE res = gridOwnerGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_gridOwner( INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER* _gridOwner
                                          )
                           {
                            RCODE res = gridOwnerSet( _gridOwner );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER*, gridOwner );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE gridOwnerGet( INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER**    _gridOwner /* [out] ::cli::gui::cellgrid::iGridOwner* _gridOwner  */)
                           {
                        
                            return pif->gridOwnerGet(_gridOwner);
                           }
                        
                        RCODE gridOwnerSet( INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER*    _gridOwner /* [in] ::cli::gui::cellgrid::iGridOwner*  _gridOwner  */)
                           {
                        
                            return pif->gridOwnerSet(_gridOwner);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL* get_cells( SIZE_T idx1
                                                                         , SIZE_T idx2
                                                                         )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL* tmpVal;
                            RCODE res = cellsGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_cells(  )
                           {
                            SIZE_T size;
                            RCODE res = cellsSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_cells( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = cellsSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*, cells, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsGet( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL**    _cells /* [out] ::cli::gui::cellgrid::iSimpleCell* _cells  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                      )
                           {
                        
                        
                        
                            return pif->cellsGet(_cells, idx1, idx2);
                           }
                        
                        RCODE cellsSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellsSize1(_size);
                           }
                        
                        RCODE cellsSize2( SIZE_T*    _size /* [out] size_t _size  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        )
                           {
                        
                        
                            return pif->cellsSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL* get_multiCells( SIZE_T idx1
                                                                             , SIZE_T idx2
                                                                             )
                           {
                            INTERFACE_CLI_GUI_CELLGRID_IMULTICELL* tmpVal;
                            RCODE res = multiCellsGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        SIZE_T size1_multiCells(  )
                           {
                            SIZE_T size;
                            RCODE res = multiCellsSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_multiCells( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = multiCellsSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, INTERFACE_CLI_GUI_CELLGRID_IMULTICELL*, multiCells, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE multiCellsGet( INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    _multiCells /* [out] ::cli::gui::cellgrid::iMultiCell* _multiCells  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
                           {
                        
                        
                        
                            return pif->multiCellsGet(_multiCells, idx1, idx2);
                           }
                        
                        RCODE multiCellsSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->multiCellsSize1(_size);
                           }
                        
                        RCODE multiCellsSize2( SIZE_T*    _size /* [out] size_t _size  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
                           {
                        
                        
                            return pif->multiCellsSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_rowsVisible( SIZE_T idx1 )
                           {
                            BOOL tmpVal;
                            RCODE res = rowsVisibleGet( &tmpVal, idx1);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_rowsVisible( SIZE_T idx1 , BOOL _rowsVisible
                                            )
                           { // MS style - index goes before value, need reorder
                            RCODE res = rowsVisibleSet( _rowsVisible, idx1 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size_rowsVisible(  )
                           {
                            SIZE_T size;
                            RCODE res = rowsVisibleSize( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, BOOL, rowsVisible, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowsVisibleGet( BOOL*    _rowsVisible /* [out] bool _rowsVisible  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            )
                           {
                        
                        
                            return pif->rowsVisibleGet(_rowsVisible, idx1);
                           }
                        
                        RCODE rowsVisibleSet( BOOL    _rowsVisible /* [in] bool  _rowsVisible  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            )
                           {
                        
                        
                            return pif->rowsVisibleSet(_rowsVisible, idx1);
                           }
                        
                        RCODE rowsVisibleSize( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->rowsVisibleSize(_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_cellsVisible( SIZE_T idx1
                                             , SIZE_T idx2
                                             )
                           {
                            BOOL tmpVal;
                            RCODE res = cellsVisibleGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellsVisible( SIZE_T idx1
                                             , SIZE_T idx2
                                             , BOOL _cellsVisible
                                             )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = cellsVisibleSet( _cellsVisible, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_cellsVisible(  )
                           {
                            SIZE_T size;
                            RCODE res = cellsVisibleSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_cellsVisible( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = cellsVisibleSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, cellsVisible, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsVisibleGet( BOOL*    _cellsVisible /* [out] bool _cellsVisible  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->cellsVisibleGet(_cellsVisible, idx1, idx2);
                           }
                        
                        RCODE cellsVisibleSet( BOOL    _cellsVisible /* [in] bool  _cellsVisible  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                             )
                           {
                        
                        
                        
                            return pif->cellsVisibleSet(_cellsVisible, idx1, idx2);
                           }
                        
                        RCODE cellsVisibleSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellsVisibleSize1(_size);
                           }
                        
                        RCODE cellsVisibleSize2( SIZE_T*    _size /* [out] size_t _size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               )
                           {
                        
                        
                            return pif->cellsVisibleSize2(_size, idx1);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_cellsActive( SIZE_T idx1
                                            , SIZE_T idx2
                                            )
                           {
                            BOOL tmpVal;
                            RCODE res = cellsActiveGet( &tmpVal, idx1, idx2);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellsActive( SIZE_T idx1
                                            , SIZE_T idx2
                                            , BOOL _cellsActive
                                            )
                           { // MS style - indeces are before value, need reorder
                            RCODE res = cellsActiveSet( _cellsActive, idx1, idx2 );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        SIZE_T size1_cellsActive(  )
                           {
                            SIZE_T size;
                            RCODE res = cellsActiveSize1( &size );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        SIZE_T size2_cellsActive( SIZE_T idx1 )
                           {
                            SIZE_T size;
                            RCODE res = cellsActiveSize2( &size, idx1 );
                            CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                            return size;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW_IDX2(wrapper_type, BOOL, cellsActive, SIZE_T, SIZE_T );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsActiveGet( BOOL*    _cellsActive /* [out] bool _cellsActive  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                            )
                           {
                        
                        
                        
                            return pif->cellsActiveGet(_cellsActive, idx1, idx2);
                           }
                        
                        RCODE cellsActiveSet( BOOL    _cellsActive /* [in] bool  _cellsActive  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                                            )
                           {
                        
                        
                        
                            return pif->cellsActiveSet(_cellsActive, idx1, idx2);
                           }
                        
                        RCODE cellsActiveSize1( SIZE_T*    _size /* [out] size_t _size  */)
                           {
                        
                            return pif->cellsActiveSize1(_size);
                           }
                        
                        RCODE cellsActiveSize2( SIZE_T*    _size /* [out] size_t _size  */
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              )
                           {
                        
                        
                            return pif->cellsActiveSize2(_size, idx1);
                           }
                        
                        RCODE resetActiveCell( )
                           {
                            return pif->resetActiveCell();
                           }
                        
                        RCODE getIUnknownIndex( INTERFACE_CLI_IUNKNOWN*    pRow /* [in] ::cli::iUnknown*  pRow  */
                                              , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                              )
                           {
                        
                        
                            return pif->getIUnknownIndex(pRow, idxFound);
                           }
                        
                        RCODE getRowIndex( INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                                         , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                         )
                           {
                        
                        
                            return pif->getRowIndex(pRow, idxFound);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_lockUpdate( )
                           {
                            BOOL tmpVal;
                            RCODE res = lockUpdateGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_lockUpdate( BOOL _lockUpdate
                                           )
                           {
                            RCODE res = lockUpdateSet( _lockUpdate );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, lockUpdate );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE lockUpdateGet( BOOL*    _lockUpdate /* [out] bool _lockUpdate  */)
                           {
                        
                            return pif->lockUpdateGet(_lockUpdate);
                           }
                        
                        RCODE lockUpdateSet( BOOL    _lockUpdate /* [in] bool  _lockUpdate  */)
                           {
                        
                            return pif->lockUpdateSet(_lockUpdate);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CSPACING get_spacing( )
                           {
                            STRUCT_CLI_GUI_CSPACING tmpVal;
                            RCODE res = spacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_spacing( const STRUCT_CLI_GUI_CSPACING &_spacing
                                        )
                           {
                            RCODE res = spacingSet( _spacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CSPACING, spacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE spacingGet( STRUCT_CLI_GUI_CSPACING    &_spacing /* [out] ::cli::gui::CSpacing _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingGet(&_spacing);
                           }
                        
                        RCODE spacingSet( const STRUCT_CLI_GUI_CSPACING    &_spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->spacingSet(&_spacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CSPACING get_rowSpacing( )
                           {
                            STRUCT_CLI_GUI_CSPACING tmpVal;
                            RCODE res = rowSpacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_rowSpacing( const STRUCT_CLI_GUI_CSPACING &_rowSpacing
                                           )
                           {
                            RCODE res = rowSpacingSet( _rowSpacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CSPACING, rowSpacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowSpacingGet( STRUCT_CLI_GUI_CSPACING    &_rowSpacing /* [out] ::cli::gui::CSpacing _rowSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->rowSpacingGet(&_rowSpacing);
                           }
                        
                        RCODE rowSpacingSet( const STRUCT_CLI_GUI_CSPACING    &_rowSpacing /* [in,ref] ::cli::gui::CSpacing  _rowSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->rowSpacingSet(&_rowSpacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_GUI_CSPACING get_cellSpacing( )
                           {
                            STRUCT_CLI_GUI_CSPACING tmpVal;
                            RCODE res = cellSpacingGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellSpacing( const STRUCT_CLI_GUI_CSPACING &_cellSpacing
                                            )
                           {
                            RCODE res = cellSpacingSet( _cellSpacing );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_GUI_CSPACING, cellSpacing );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellSpacingGet( STRUCT_CLI_GUI_CSPACING    &_cellSpacing /* [out] ::cli::gui::CSpacing _cellSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSpacingGet(&_cellSpacing);
                           }
                        
                        RCODE cellSpacingSet( const STRUCT_CLI_GUI_CSPACING    &_cellSpacing /* [in,ref] ::cli::gui::CSpacing  _cellSpacing  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->cellSpacingSet(&_cellSpacing);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_gridNcBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = gridNcBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_gridNcBackgroundColor( COLORREF _gridNcBackgroundColor
                                                      )
                           {
                            RCODE res = gridNcBackgroundColorSet( _gridNcBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, gridNcBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE gridNcBackgroundColorGet( COLORREF*    _gridNcBackgroundColor /* [out] colorref _gridNcBackgroundColor  */)
                           {
                        
                            return pif->gridNcBackgroundColorGet(_gridNcBackgroundColor);
                           }
                        
                        RCODE gridNcBackgroundColorSet( COLORREF    _gridNcBackgroundColor /* [in] colorref  _gridNcBackgroundColor  */)
                           {
                        
                            return pif->gridNcBackgroundColorSet(_gridNcBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_gridBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = gridBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_gridBackgroundColor( COLORREF _gridBackgroundColor
                                                    )
                           {
                            RCODE res = gridBackgroundColorSet( _gridBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, gridBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE gridBackgroundColorGet( COLORREF*    _gridBackgroundColor /* [out] colorref _gridBackgroundColor  */)
                           {
                        
                            return pif->gridBackgroundColorGet(_gridBackgroundColor);
                           }
                        
                        RCODE gridBackgroundColorSet( COLORREF    _gridBackgroundColor /* [in] colorref  _gridBackgroundColor  */)
                           {
                        
                            return pif->gridBackgroundColorSet(_gridBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_rowNcBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = rowNcBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_rowNcBackgroundColor( COLORREF _rowNcBackgroundColor
                                                     )
                           {
                            RCODE res = rowNcBackgroundColorSet( _rowNcBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, rowNcBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowNcBackgroundColorGet( COLORREF*    _rowNcBackgroundColor /* [out] colorref _rowNcBackgroundColor  */)
                           {
                        
                            return pif->rowNcBackgroundColorGet(_rowNcBackgroundColor);
                           }
                        
                        RCODE rowNcBackgroundColorSet( COLORREF    _rowNcBackgroundColor /* [in] colorref  _rowNcBackgroundColor  */)
                           {
                        
                            return pif->rowNcBackgroundColorSet(_rowNcBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeRowNcBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeRowNcBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeRowNcBackgroundColor( COLORREF _activeRowNcBackgroundColor
                                                           )
                           {
                            RCODE res = activeRowNcBackgroundColorSet( _activeRowNcBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeRowNcBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeRowNcBackgroundColorGet( COLORREF*    _activeRowNcBackgroundColor /* [out] colorref _activeRowNcBackgroundColor  */)
                           {
                        
                            return pif->activeRowNcBackgroundColorGet(_activeRowNcBackgroundColor);
                           }
                        
                        RCODE activeRowNcBackgroundColorSet( COLORREF    _activeRowNcBackgroundColor /* [in] colorref  _activeRowNcBackgroundColor  */)
                           {
                        
                            return pif->activeRowNcBackgroundColorSet(_activeRowNcBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_rowBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = rowBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_rowBackgroundColor( COLORREF _rowBackgroundColor
                                                   )
                           {
                            RCODE res = rowBackgroundColorSet( _rowBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, rowBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowBackgroundColorGet( COLORREF*    _rowBackgroundColor /* [out] colorref _rowBackgroundColor  */)
                           {
                        
                            return pif->rowBackgroundColorGet(_rowBackgroundColor);
                           }
                        
                        RCODE rowBackgroundColorSet( COLORREF    _rowBackgroundColor /* [in] colorref  _rowBackgroundColor  */)
                           {
                        
                            return pif->rowBackgroundColorSet(_rowBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeRowBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeRowBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeRowBackgroundColor( COLORREF _activeRowBackgroundColor
                                                         )
                           {
                            RCODE res = activeRowBackgroundColorSet( _activeRowBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeRowBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeRowBackgroundColorGet( COLORREF*    _activeRowBackgroundColor /* [out] colorref _activeRowBackgroundColor  */)
                           {
                        
                            return pif->activeRowBackgroundColorGet(_activeRowBackgroundColor);
                           }
                        
                        RCODE activeRowBackgroundColorSet( COLORREF    _activeRowBackgroundColor /* [in] colorref  _activeRowBackgroundColor  */)
                           {
                        
                            return pif->activeRowBackgroundColorSet(_activeRowBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_cellNcBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = cellNcBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellNcBackgroundColor( COLORREF _cellNcBackgroundColor
                                                      )
                           {
                            RCODE res = cellNcBackgroundColorSet( _cellNcBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, cellNcBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellNcBackgroundColorGet( COLORREF*    _cellNcBackgroundColor /* [out] colorref _cellNcBackgroundColor  */)
                           {
                        
                            return pif->cellNcBackgroundColorGet(_cellNcBackgroundColor);
                           }
                        
                        RCODE cellNcBackgroundColorSet( COLORREF    _cellNcBackgroundColor /* [in] colorref  _cellNcBackgroundColor  */)
                           {
                        
                            return pif->cellNcBackgroundColorSet(_cellNcBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeCellNcBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeCellNcBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCellNcBackgroundColor( COLORREF _activeCellNcBackgroundColor
                                                            )
                           {
                            RCODE res = activeCellNcBackgroundColorSet( _activeCellNcBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeCellNcBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellNcBackgroundColorGet( COLORREF*    _activeCellNcBackgroundColor /* [out] colorref _activeCellNcBackgroundColor  */)
                           {
                        
                            return pif->activeCellNcBackgroundColorGet(_activeCellNcBackgroundColor);
                           }
                        
                        RCODE activeCellNcBackgroundColorSet( COLORREF    _activeCellNcBackgroundColor /* [in] colorref  _activeCellNcBackgroundColor  */)
                           {
                        
                            return pif->activeCellNcBackgroundColorSet(_activeCellNcBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_cellBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = cellBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellBackgroundColor( COLORREF _cellBackgroundColor
                                                    )
                           {
                            RCODE res = cellBackgroundColorSet( _cellBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, cellBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellBackgroundColorGet( COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */)
                           {
                        
                            return pif->cellBackgroundColorGet(_cellBackgroundColor);
                           }
                        
                        RCODE cellBackgroundColorSet( COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */)
                           {
                        
                            return pif->cellBackgroundColorSet(_cellBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        COLORREF get_activeCellBackgroundColor( )
                           {
                            COLORREF tmpVal;
                            RCODE res = activeCellBackgroundColorGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activeCellBackgroundColor( COLORREF _activeCellBackgroundColor
                                                          )
                           {
                            RCODE res = activeCellBackgroundColorSet( _activeCellBackgroundColor );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, activeCellBackgroundColor );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellBackgroundColorGet( COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */)
                           {
                        
                            return pif->activeCellBackgroundColorGet(_activeCellBackgroundColor);
                           }
                        
                        RCODE activeCellBackgroundColorSet( COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */)
                           {
                        
                            return pif->activeCellBackgroundColorSet(_activeCellBackgroundColor);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_EALIGNMENT get_cellsAlignment( )
                           {
                            ENUM_CLI_GUI_EALIGNMENT tmpVal;
                            RCODE res = cellsAlignmentGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_cellsAlignment( ENUM_CLI_GUI_EALIGNMENT _cellsAlignment
                                               )
                           {
                            RCODE res = cellsAlignmentSet( _cellsAlignment );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_GUI_EALIGNMENT, cellsAlignment );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE cellsAlignmentGet( ENUM_CLI_GUI_EALIGNMENT*    _cellsAlignment /* [out] ::cli::gui::EAlignment _cellsAlignment  */)
                           {
                        
                            return pif->cellsAlignmentGet(_cellsAlignment);
                           }
                        
                        RCODE cellsAlignmentSet( ENUM_CLI_GUI_EALIGNMENT    _cellsAlignment /* [in] ::cli::gui::EAlignment  _cellsAlignment  */)
                           {
                        
                            return pif->cellsAlignmentSet(_cellsAlignment);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        ENUM_CLI_GUI_EALIGNMENT get_rowsAlignment( )
                           {
                            ENUM_CLI_GUI_EALIGNMENT tmpVal;
                            RCODE res = rowsAlignmentGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_rowsAlignment( ENUM_CLI_GUI_EALIGNMENT _rowsAlignment
                                              )
                           {
                            RCODE res = rowsAlignmentSet( _rowsAlignment );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_GUI_EALIGNMENT, rowsAlignment );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowsAlignmentGet( ENUM_CLI_GUI_EALIGNMENT*    _rowsAlignment /* [out] ::cli::gui::EAlignment _rowsAlignment  */)
                           {
                        
                            return pif->rowsAlignmentGet(_rowsAlignment);
                           }
                        
                        RCODE rowsAlignmentSet( ENUM_CLI_GUI_EALIGNMENT    _rowsAlignment /* [in] ::cli::gui::EAlignment  _rowsAlignment  */)
                           {
                        
                            return pif->rowsAlignmentSet(_rowsAlignment);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_rowSizes( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = rowSizesGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, rowSizes );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE rowSizesGet( STRUCT_CLI_DRAWING_CPOINT    &_rowSizes /* [out] ::cli::drawing::CPoint _rowSizes  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->rowSizesGet(&_rowSizes);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_size( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = sizeGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_size( const STRUCT_CLI_DRAWING_CPOINT &_size
                                     )
                           {
                            RCODE res = sizeSet( _size );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, size );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE sizeGet( STRUCT_CLI_DRAWING_CPOINT    &_size /* [out] ::cli::drawing::CPoint _size  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->sizeGet(&_size);
                           }
                        
                        RCODE sizeSet( const STRUCT_CLI_DRAWING_CPOINT    &_size /* [in,ref] ::cli::drawing::CPoint  _size  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->sizeSet(&_size);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        STRUCT_CLI_DRAWING_CPOINT get_fullSize( )
                           {
                            STRUCT_CLI_DRAWING_CPOINT tmpVal;
                            RCODE res = fullSizeGet( tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, STRUCT_CLI_DRAWING_CPOINT, fullSize );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE fullSizeGet( STRUCT_CLI_DRAWING_CPOINT    &_fullSize /* [out] ::cli::drawing::CPoint _fullSize  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->fullSizeGet(&_fullSize);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        SIZE_T get_activeRow( )
                           {
                            SIZE_T tmpVal;
                            RCODE res = activeRowGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, activeRow );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeRowGet( SIZE_T*    _activeRow /* [out] size_t _activeRow  */)
                           {
                        
                            return pif->activeRowGet(_activeRow);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        SIZE_T get_activeCell( )
                           {
                            SIZE_T tmpVal;
                            RCODE res = activeCellGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, activeCell );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activeCellGet( SIZE_T*    _activeCell /* [out] size_t _activeCell  */)
                           {
                        
                            return pif->activeCellGet(_activeCell);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        BOOL get_activateOnClick( )
                           {
                            BOOL tmpVal;
                            RCODE res = activateOnClickGet( &tmpVal);
                            CLI_CHECK_GET_PROPERTY_RESULT(res);
                            return tmpVal;
                           }
                        
                        void set_activateOnClick( BOOL _activateOnClick
                                                )
                           {
                            RCODE res = activateOnClickSet( _activateOnClick );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, activateOnClick );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE activateOnClickGet( BOOL*    _activateOnClick /* [out] bool _activateOnClick  */)
                           {
                        
                            return pif->activateOnClickGet(_activateOnClick);
                           }
                        
                        RCODE activateOnClickSet( BOOL    _activateOnClick /* [in] bool  _activateOnClick  */)
                           {
                        
                            return pif->activateOnClickSet(_activateOnClick);
                           }
                        
                        RCODE setCapture( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                        , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                        )
                           {
                        
                        
                            return pif->setCapture(rowIdx, cellIdx);
                           }
                        
                        RCODE clearCapture( )
                           {
                            return pif->clearCapture();
                           }
                        
                        RCODE updateConfig( INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */)
                           {
                        
                            return pif->updateConfig(appCfg);
                           }
                        
                        RCODE calculateLimits( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */)
                           {
                        
                            return pif->calculateLimits(pdc);
                           }
                        
                        RCODE insertRow( INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                                       , SIZE_T    atPos /* [in] size_t  atPos  */
                                       )
                           {
                        
                        
                            return pif->insertRow(pRow, atPos);
                           }
                        
                        RCODE addRow( INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */)
                           {
                        
                            return pif->addRow(pRow);
                           }
                        
                        RCODE removeRow( SIZE_T    atPos /* [in] size_t  atPos  */)
                           {
                        
                            return pif->removeRow(atPos);
                           }
                        
                        RCODE rowsClear( )
                           {
                            return pif->rowsClear();
                           }
                        
                        RCODE insertCellToRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                             , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                             , SIZE_T    atPos /* [in] size_t  atPos  */
                                             )
                           {
                        
                        
                        
                            return pif->insertCellToRow(rowIdx, pCell, atPos);
                           }
                        
                        RCODE addCellToRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                          , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                          )
                           {
                        
                        
                            return pif->addCellToRow(rowIdx, pCell);
                           }
                        
                        RCODE removeCellFromRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                               , SIZE_T    atPos /* [in] size_t  atPos  */
                                               )
                           {
                        
                        
                            return pif->removeCellFromRow(rowIdx, atPos);
                           }
                        
                        RCODE rowCellsClear( SIZE_T    rowIdx /* [in] size_t  rowIdx  */)
                           {
                        
                            return pif->rowCellsClear(rowIdx);
                           }
                        
                        RCODE invalidateRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                           , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                           )
                           {
                        
                        
                            return pif->invalidateRow(rowIdx, invalidateType);
                           }
                        
                        RCODE invalidateCell( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                            , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                            , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                            )
                           {
                        
                        
                        
                            return pif->invalidateCell(rowIdx, cellIdx, invalidateType);
                           }
                        
                        RCODE updatePaint( )
                           {
                            return pif->updatePaint();
                           }
                        
                        RCODE getDrawContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
                           {
                        
                            return pif->getDrawContext(pdc);
                           }
                        
                        RCODE partialPaintOnContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                   , SIZE_T    firstRowIdx /* [in] size_t  firstRowIdx  */
                                                   , SIZE_T    firstRowCellIdx /* [in] size_t  firstRowCellIdx  */
                                                   , SIZE_T    lastRowIdx /* [in] size_t  lastRowIdx  */
                                                   , SIZE_T    lastRowCellIdx /* [in] size_t  lastRowCellIdx  */
                                                   )
                           {
                        
                        
                        
                        
                        
                            return pif->partialPaintOnContext(pdc, firstRowIdx, firstRowCellIdx, lastRowIdx, lastRowCellIdx);
                           }
                        
                        RCODE partialPaint( SIZE_T    firstRowIdx /* [in] size_t  firstRowIdx  */
                                          , SIZE_T    firstRowCellIdx /* [in] size_t  firstRowCellIdx  */
                                          , SIZE_T    lastRowIdx /* [in] size_t  lastRowIdx  */
                                          , SIZE_T    lastRowCellIdx /* [in] size_t  lastRowCellIdx  */
                                          )
                           {
                        
                        
                        
                        
                            return pif->partialPaint(firstRowIdx, firstRowCellIdx, lastRowIdx, lastRowCellIdx);
                           }
                        
                        RCODE paintOnContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */)
                           {
                        
                            return pif->paintOnContext(pdc);
                           }
                        
                        RCODE paint( )
                           {
                            return pif->paint();
                           }
                        
                        RCODE paintCellOnContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                                , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                )
                           {
                        
                        
                        
                            return pif->paintCellOnContext(pdc, rowIdx, cellIdx);
                           }
                        
                        RCODE paintRowOnContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                               , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                               )
                           {
                        
                        
                            return pif->paintRowOnContext(pdc, rowIdx);
                           }
                        
                        RCODE paintCell( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                       )
                           {
                        
                        
                            return pif->paintCell(rowIdx, cellIdx);
                           }
                        
                        RCODE paintRow( SIZE_T    rowIdx /* [in] size_t  rowIdx  */)
                           {
                        
                            return pif->paintRow(rowIdx);
                           }
                        
                        RCODE hitTest( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                     , SIZE_T*    hitRow /* [out] size_t hitRow  */
                                     , SIZE_T*    hitCell /* [out] size_t hitCell  */
                                     , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                                     , STRUCT_CLI_DRAWING_CPOINT    &translatedMicePos /* [out] ::cli::drawing::CPoint translatedMicePos  (struct passed by ref in wrapper) */
                                     , INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    pCell /* [out] ::cli::gui::cellgrid::iMultiCell* pCell  */
                                     )
                           {
                        
                        
                        
                        
                        
                        
                            return pif->hitTest(&micePos, hitRow, hitCell, resFlags, &translatedMicePos, pCell);
                           }
                        
                        RCODE onMouseMove( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->onMouseMove(&micePos);
                           }
                        
                        RCODE onMouseClick( const STRUCT_CLI_DRAWING_CPOINT    &micePos /* [in,ref] ::cli::drawing::CPoint  micePos  (struct passed by ref in wrapper) */
                                          , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                                          )
                           {
                        
                        
                            return pif->onMouseClick(&micePos, eventFlags);
                           }
                        
                        RCODE getRowNcDrawContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                 , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                 )
                           {
                        
                        
                            return pif->getRowNcDrawContext(pdc, rowIdx);
                           }
                        
                        RCODE getRowDrawContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                               , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                               )
                           {
                        
                        
                            return pif->getRowDrawContext(pdc, rowIdx);
                           }
                        
                        RCODE getCellNcDrawContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                  , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                  , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                  )
                           {
                        
                        
                        
                            return pif->getCellNcDrawContext(pdc, rowIdx, cellIdx);
                           }
                        
                        RCODE getCellDrawContext( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                                , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                                )
                           {
                        
                        
                        
                            return pif->getCellDrawContext(pdc, rowIdx, cellIdx);
                           }
                        
                        RCODE rowNotifyIdx( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                          , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                          , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                          , UINT    param /* [in] uint  param  */
                                          )
                           {
                        
                        
                        
                        
                            return pif->rowNotifyIdx(rowIdx, cellIdx, eventType, param);
                           }
                        
                        RCODE getRowPosSize( SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                           , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                           , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                           , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                           , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                                           )
                           {
                        
                        
                        
                        
                        
                            return pif->getRowPosSize(rowIdx, ncLeftTop, ncWidthHeight, clientLeftTop, clientWidthHeight);
                           }
                        

                
                
                }; // class CiGridWrapper
                
                typedef CiGridWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_CELLGRID_IGRID     > >  CiGrid;
                typedef CiGridWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_CELLGRID_IGRID > >  CiGrid_nrc; /* No ref counting for interface used */
                
                
                
                
                
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */

#endif





#endif /* CLI_GUI_CG2_IGRID_H */
