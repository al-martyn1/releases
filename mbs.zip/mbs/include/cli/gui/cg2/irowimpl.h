#ifndef CLI_GUI_CG2_IROWIMPL_H
#define CLI_GUI_CG2_IROWIMPL_H

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_GUI_CG2_IGRID_H
    #include <cli/gui/cg2/igrid.h>
#endif

#ifndef CLI_GUI_CG2_IROW_H
    #include <cli/gui/cg2/irow.h>
#endif

#ifndef CLI_GUI_CG2_ICELL_H
    #include <cli/gui/cg2/icell.h>
#endif

#ifndef CLI_GUI_CG2_CELLGRIDHLP_H
    #include <cli/gui/cg2/cellgridhlp.h>
#endif

#ifndef CLI_GUI_CG2_ICGIMPLHLP_H
    #include <cli/gui/cg2/icgimplhlp.h>
#endif
    

namespace cli
{
namespace gui
{
namespace cellgrid
{

using ::cli::drawing::makePoint;
using ::cli::drawing::zeroPoint;
using ::cli::drawing::absPoint;
using ::cli::gui::makeSpacing;
using ::cli::gui::makeInvalidSpacing;
using ::cli::gui::makeZeroSpacing;
using ::cli::gui::isValidSpacing;
using ::cli::gui::isSpacingEqual;






class CRowImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
               , public INTERFACE_CLI_GUI_CELLGRID_IROW

{

public:

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CLI_BEGIN_INTERFACE_MAP2(CRowImpl, INTERFACE_CLI_GUI_CELLGRID_IROW)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_IROW )
    CLI_END_INTERFACE_MAP(CRowImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    // reimplement 'destroy' in descendants
    void destroy() { delete this; }

    typedef ::cli::gui::cellgrid::CiGrid_nrc CGrid;

protected:

    CGrid                                                    ownerGrid;
    BOOL                                                     visible;
    ::std::vector< INTERFACE_CLI_GUI_CELLGRID_IMULTICELL* >  cells;
    STRUCT_CLI_GUI_CSPACING                                  spacing;
    STRUCT_CLI_GUI_CSPACING                                  cellSpacing;
    BOOL                                                     ncDrawBackground;
    COLORREF                                                 ncBackgroundColor;
    COLORREF                                                 ncActiveBackgroundColor;
    BOOL                                                     drawBackground;
    COLORREF                                                 backgroundColor;
    COLORREF                                                 activeBackgroundColor;

    COLORREF                                                 cellNcBackgroundColor;
    COLORREF                                                 activeCellNcBackgroundColor;
    COLORREF                                                 cellBackgroundColor;
    COLORREF                                                 activeCellBackgroundColor;

    ::std::vector< CCellPosSize >                            cachedCellSizes;

    ENUM_CLI_GUI_EALIGNMENT                                  alignment;

    STRUCT_CLI_DRAWING_CPOINT                                rowSize;

public:

    CRowImpl()
       : base_impl(DEF_MODULE)
       , INTERFACE_CLI_GUI_CELLGRID_IROW()
       , ownerGrid()
       , visible(TRUE)
       , cells()
       , spacing(makeInvalidSpacing())
       , cellSpacing(makeInvalidSpacing())
       , ncDrawBackground(TRUE)
       , ncBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , ncActiveBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , drawBackground(TRUE)
       , backgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , activeBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , cellNcBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , activeCellNcBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , cellBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , activeCellBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , cachedCellSizes()
       , alignment(CLI_GUI_EALIGNMENT_VUNDEFINED|CLI_GUI_EALIGNMENT_HUNDEFINED)
       , rowSize(makePoint(-1, -1))
       {}

    ~CRowImpl()
       {
        cellsClear();
       }

    RCODE rowNotifyIdx( ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType
                      , UINT    param = 0
                      , SIZE_T  rowIdx = SIZE_T_NPOS
                      , SIZE_T  cellIdx = SIZE_T_NPOS
                      )
       {
        if (!ownerGrid) return EC_OK; // no owner grid - nothing to do
        if (rowIdx==SIZE_T_NPOS)
           {
            ownerGrid.getRowIndex(this, &rowIdx);
           }
        return ownerGrid.rowNotifyIdx( rowIdx, cellIdx, eventType, param );
       }

//STRUCT_CLI_DRAWING_CPOINT
    void buildCellSizesCacheAux( SIZE_T thisRowIdx
                               , ::std::vector< CCellPosSize > &sizes
                               , ENUM_CLI_GUI_EALIGNMENT _alignment
                               , STRUCT_CLI_DRAWING_CPOINT newRowSize
                               )
       {
        //ENUM_CLI_GUI_CELLGRID_EALIGNMENT rowCellAlignment = 0;
        //cellAlignmentGet( &rowCellAlignment );
        //rowCellAlignment &= CLI_GUI_CELLGRID_EALIGNMENT_VMASK;
        //alignment &= CLI_GUI_EALIGNMENT_VMASK;

        ENUM_CLI_GUI_EALIGNMENT hAlignment = _alignment & CLI_GUI_EALIGNMENT_HMASK;
        ENUM_CLI_GUI_EALIGNMENT vAlignment = _alignment & CLI_GUI_EALIGNMENT_VMASK;

        INT maxHeight = 0;
        //cachedCellSizes.clear();
        if (newRowSize.x<0 || newRowSize.y<0)
           {
            newRowSize.x = 0;
            newRowSize.y = 0;
           }

        INT cellLeft = 0;
        INT summWidth = 0;
        SIZE_T cellIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IMULTICELL*>::iterator it = cells.begin();
        for(; it!=cells.end(); ++it, ++cellIdx) 
           {
            BOOL cellVisible = TRUE;
            (*it)->visibleGet( &cellVisible, thisRowIdx, cellIdx );

            STRUCT_CLI_GUI_CSPACING cellSpacing = makeSpacing(0,0,0,0);
            if (cellVisible)
               (*it)->spacingGet( &cellSpacing, thisRowIdx, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT cellSize = makePoint( 0, 0 );
            if (cellVisible)
               (*it)->sizeGet( &cellSize, thisRowIdx, cellIdx );

            // nc size and pos
            STRUCT_CLI_DRAWING_CPOINT leftTop     = makePoint( cellLeft, 0 );
            STRUCT_CLI_DRAWING_CPOINT ncWidthHeight = cellSize;
            ncWidthHeight.x += cellSpacing.left + cellSpacing.right;
            ncWidthHeight.y += cellSpacing.top  + cellSpacing.bottom;

            summWidth += ncWidthHeight.x;

            if (maxHeight < ncWidthHeight.y) maxHeight = ncWidthHeight.y;

            CPosSize ncPosSize(leftTop, ncWidthHeight);

            leftTop.x += cellSpacing.left;
            leftTop.y += cellSpacing.top;

            //CPosSize clientPosSize(leftTop, cellSize);
            sizes.push_back( CCellPosSize(ncPosSize, CPosSize(leftTop, cellSize) ) );

            cellLeft += ncWidthHeight.x;
           }

        INT xShift = 0;
        if (hAlignment==CLI_GUI_EALIGNMENT_HCENTER)
           {
            xShift = (newRowSize.x - summWidth) / 2;
           }
        else if (hAlignment==CLI_GUI_EALIGNMENT_RIGHT)
           {
            xShift = (newRowSize.x - summWidth);
           }
        if (xShift<0) xShift = 0;

        if (xShift)
           {
            ::std::vector< CCellPosSize >::iterator csIt = sizes.begin();
            for(; csIt!=sizes.end(); ++csIt)
               {
                csIt->ncPosSize.leftTop.x     += xShift;
                csIt->clientPosSize.leftTop.x += xShift;
               }
           }

        //if (vAlignment==CLI_GUI_EALIGNMENT_TOP) return; // do nothing, allready top aligned
        //if (maxHeight < newRowSize.y) maxHeight = newRowSize.y;
        if (newRowSize.y) maxHeight = newRowSize.y;

        ::std::vector< CCellPosSize >::iterator csIt = sizes.begin();
        for(; csIt!=sizes.end(); ++csIt)
           {
            INT curDeltaH = maxHeight - csIt->ncPosSize.widthHeight.y;
            if (curDeltaH<0) curDeltaH = 0;
            if (vAlignment==CLI_GUI_EALIGNMENT_BOTTOM)
               {
                csIt->ncPosSize.leftTop.y     += curDeltaH;
                csIt->clientPosSize.leftTop.y += curDeltaH;
               }
            else if (vAlignment==CLI_GUI_EALIGNMENT_BASELINE)
               {
                //INT baseLineMax   = maxHeight*3/4;
                //INT cellBaseLine  = csIt->ncPosSize.leftTop.y*3/4;
                //INT baseLineDelta = baseLineMax - cellBaseLine;
                //INT baseLineDelta = (maxHeight - csIt->ncPosSize.leftTop.y)*3/4;
                csIt->ncPosSize.leftTop.y     += curDeltaH*3/4;
                csIt->clientPosSize.leftTop.y += curDeltaH*3/4;
               }
            else if (vAlignment==CLI_GUI_EALIGNMENT_VCENTER)
               {
                csIt->ncPosSize.leftTop.y     += curDeltaH/2;
                csIt->clientPosSize.leftTop.y += curDeltaH/2;
               }
            else // top alignment, do nothing
               {               
               }
           }
       }


    bool buildCellSizesCache(SIZE_T thisRowIdx, SIZE_T *firstDiffCellIdx)
       {
        ENUM_CLI_GUI_EALIGNMENT thisRowCellAlignment = 0;
        alignmentGet( &thisRowCellAlignment );

        ::std::vector< CCellPosSize > newSizes;

        buildCellSizesCacheAux(thisRowIdx, newSizes, thisRowCellAlignment, rowSize);

        cachedCellSizes.swap(newSizes);

        //SIZE_T *firstDiffCellIdx

        ::std::vector< CCellPosSize >::const_iterator citNew = cachedCellSizes.begin();
        ::std::vector< CCellPosSize >::const_iterator citOld = newSizes.begin();
        for(; citNew!=cachedCellSizes.end() && citOld!=newSizes.end(); ++citNew, ++citOld)
           {
            if (*citNew!=*citOld)
               {
                if (firstDiffCellIdx) *firstDiffCellIdx = citOld - newSizes.begin();
                return true; // found difference
               }
           }

        if (cachedCellSizes.size()!=newSizes.size())
           {
            if (firstDiffCellIdx)
               {
                if (cachedCellSizes.size()>newSizes.size())
                   *firstDiffCellIdx = newSizes.size();
                else 
                   *firstDiffCellIdx = cachedCellSizes.size();
               }
            return true; // found difference - sizes are different
           }
        return false;
       }


    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* ownerGrid  */)
       {
        if (!_ownerGrid) return EC_INVALID_PARAM;
        *_ownerGrid = ownerGrid.getIfPtr();
        return EC_OK;
       }

    CLIMETHOD(ownerGridSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID*    _ownerGrid /* [in] ::cli::gui::cellgrid::iGrid*  ownerGrid  */)
       {
        ownerGrid = _ownerGrid;
        return EC_OK;
       }

    CLIMETHOD(cellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL**    _cells /* [out] ::cli::gui::cellgrid::iSimpleCell* _cells  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                        )
       {
        if (!_cells) return EC_INVALID_PARAM;
        if (idx1>=cells.size()) return EC_OUT_OF_RANGE;
        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pMultiCell = cells[idx1];
        RCODE res = pMultiCell->queryInterface( ::cli::iidOf(*_cells), (VOID**)_cells );
        if (res) return res;
        if (*_cells) (*_cells)->release(); // we don't add reference to returned cell
        return EC_OK;
       }

    CLIMETHOD(cellsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = cells.size();
        return EC_OK;
       }

    CLIMETHOD(multiCellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    _multiCells /* [out] ::cli::gui::cellgrid::iMultiCell* _multiCells  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                             )
       {
        if (!_multiCells) return EC_INVALID_PARAM;
        if (idx1>=cells.size()) return EC_OUT_OF_RANGE;
        *_multiCells = cells[idx1];
        return EC_OK;
       }

    CLIMETHOD(multiCellsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = cells.size();
        return EC_OK;
       }

    CLIMETHOD(addCell) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */)
       {
        return insertCell(pCell, SIZE_T_NPOS);
       }

    CLIMETHOD(addCellToRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                 , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                            )
       {
        return insertCellToRow(rowIdx, pCell, SIZE_T_NPOS);
       }

    CLIMETHOD(insertCell) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                               , SIZE_T    atPos /* [in] size_t  atPos  */
                          )
       {
        if (!pCell)     return EC_INVALID_PARAM;
        // row must be added to grid first
        //if (!ownerGrid) return EC_NO_OWNER;

        //::cli::gui::cellgrid::CiSimpleCell_nrc smpCell(pCell);
        ::cli::gui::cellgrid::CiSimpleCell smpCell(pCell);
        ::cli::gui::cellgrid::CiMultiCell multiCell;
        if (smpCell.queryInterface(multiCell)) return EC_INCOMPATIBLE_OBJECT;

        SIZE_T rowIdx = 0;
        if (!!ownerGrid)
           {
            RCODE res = ownerGrid.getRowIndex(this, &rowIdx);
            if (res) return res;
           }

        CLI_TRY{
                if (atPos >= cells.size() )
                   {
                    atPos = cells.size(); // correct insert pos value
                    cells.push_back(multiCell.getIfPtr());
                   }
                else
                   cells.insert( cells.begin()+atPos, multiCell.getIfPtr() );

                multiCell.ownerRow[rowIdx][atPos] = this;

                INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc = 0;
                if (!!ownerGrid) ownerGrid.getDrawContext(&pdc);
                if (pdc) 
                   {
                    multiCell.calculateLimits( pdc, rowIdx, atPos );
                    pdc->release();
                   }
                multiCell.getIfPtr()->addRef();                
                
                SIZE_T firstDiffCellIdx = SIZE_T_NPOS;
                buildCellSizesCache( rowIdx,  &firstDiffCellIdx );
                rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE, 0, rowIdx, firstDiffCellIdx );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(insertCellToRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                    , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                    , SIZE_T    atPos /* [in] size_t  atPos  */
                               )
       {
        if (!pCell)     return EC_INVALID_PARAM;
        // row must be added to grid first
        //if (!ownerGrid) return EC_NO_OWNER;

        //::cli::gui::cellgrid::CiSimpleCell_nrc smpCell(pCell);
        ::cli::gui::cellgrid::CiSimpleCell smpCell(pCell);
        ::cli::gui::cellgrid::CiMultiCell multiCell;
        if (smpCell.queryInterface(multiCell)) return EC_INCOMPATIBLE_OBJECT;

        CLI_TRY{
                if (atPos >= cells.size() )
                   {
                    atPos = cells.size(); // correct insert pos value
                    cells.push_back(multiCell.getIfPtr());
                   }
                else
                   cells.insert( cells.begin()+atPos, multiCell.getIfPtr() );

                multiCell.ownerRow[rowIdx][atPos] = this;

                INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc = 0;
                if (!!ownerGrid) ownerGrid.getDrawContext(&pdc);
                if (pdc) 
                   {
                    multiCell.calculateLimits( pdc, rowIdx, atPos );
                    pdc->release();
                   }
                multiCell.getIfPtr()->addRef();                
                
                SIZE_T firstDiffCellIdx = SIZE_T_NPOS;
                buildCellSizesCache( rowIdx,  &firstDiffCellIdx );
                rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE, 0, rowIdx, firstDiffCellIdx );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(removeCell) (THIS_ SIZE_T    atPos /* [in] size_t  atPos  */)
       {
        if (atPos>=cells.size()) return EC_INVALID_PARAM;
        SIZE_T rowIdx = 0;
        //RCODE res = 
        if (!!ownerGrid) ownerGrid.getRowIndex(this, &rowIdx);
        //if (res) return res;

        CLI_TRY{
                INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pMultiCell = cells[atPos];
                pMultiCell->ownerRowSet(0, rowIdx, atPos);
                cells.erase( cells.begin() + atPos );
                pMultiCell->release();

                SIZE_T firstDiffCellIdx = SIZE_T_NPOS;
                buildCellSizesCache( rowIdx,  &firstDiffCellIdx );
                rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE, 0, rowIdx, firstDiffCellIdx );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(removeCellFromRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                      , SIZE_T    atPos /* [in] size_t  atPos  */
                                 )
       {
        if (atPos>=cells.size()) return EC_INVALID_PARAM;

        CLI_TRY{
                INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pMultiCell = cells[atPos];
                pMultiCell->ownerRowSet(0, rowIdx, atPos);
                cells.erase( cells.begin() + atPos );
                pMultiCell->release();

                SIZE_T firstDiffCellIdx = SIZE_T_NPOS;
                buildCellSizesCache( rowIdx,  &firstDiffCellIdx );
                rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE, 0, rowIdx, firstDiffCellIdx );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(cellsClear) (THIS)
       {
        SIZE_T rowIdx = 0;
        //RCODE res = 
        if (!!ownerGrid) ownerGrid.getRowIndex(this, &rowIdx);

        CLI_TRY{
                ::std::vector< INTERFACE_CLI_GUI_CELLGRID_IMULTICELL* >::iterator cit = cells.begin();
                for(; cit!=cells.end(); ++cit)
                   {
                    INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pMultiCell = *cit;
                    pMultiCell->ownerRowSet(0, rowIdx, (SIZE_T)(cit-cells.begin()) );
                    pMultiCell->release();
                   }
                cells.clear();
                SIZE_T firstDiffCellIdx = SIZE_T_NPOS;
                buildCellSizesCache( rowIdx,  &firstDiffCellIdx );
                rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE, 0, rowIdx, firstDiffCellIdx );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getIUnknownIndex) (THIS_ INTERFACE_CLI_IUNKNOWN*    pcell /* [in] ::cli::iUnknown*  pcell  */
                                     , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                )
       {
        if (!pcell || !idxFound) return EC_INVALID_PARAM;
        SIZE_T curIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IMULTICELL*>::iterator it = cells.begin();
        for(; it!=cells.end(); ++it, ++curIdx)
           {
            if (::cli::isObjectEqualTo( *it, pcell ))
               {
                *idxFound = curIdx;
                return EC_OK;
               }
           }
        return EC_NOT_FOUND;
       }

    CLIMETHOD(getCellIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                 , SIZE_T*    idxFound /* [out] size_t idxFound  */
                            )
       {
        if (!pcell || !idxFound) return EC_INVALID_PARAM;

        ::cli::iUnknown *punk = 0;

        RCODE res = pcell->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), (VOID**)&punk);
        if (res) return res; // queryInterface failed

        res = getIUnknownIndex( punk, idxFound );
        punk->release();

        return res;
       }

    CLIMETHOD(getMultiCellIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IMULTICELL*    pcell /* [in] ::cli::gui::cellgrid::iMultiCell*  pcell  */
                                      , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                 )
       {
        if (!pcell || !idxFound) return EC_INVALID_PARAM;

        ::cli::iUnknown *punk = 0;

        RCODE res = pcell->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), (VOID**)&punk);
        if (res) return res; // queryInterface failed

        res = getIUnknownIndex( punk, idxFound );
        punk->release();

        return res;
       }

    //-----------------------------------
    // Properties - spacing and colors
    //-----------------------------------

    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _spacing /* [out] ::cli::gui::CSpacing _spacing  */)
       {
        if (!_spacing) return EC_INVALID_PARAM;
        if (isValidSpacing(spacing)) // self spacing is valid - was explicitly set
           {
            *_spacing = spacing;
            return EC_OK;
           }
        if (!!ownerGrid)
           { // try to return owner's row cellSpacing
            *_spacing = ownerGrid.rowSpacing;
            if (!isValidSpacing(*_spacing)) // if owner cellSpacing invalid, return zero
               *_spacing = makeZeroSpacing();
            return EC_OK;
           }
        *_spacing = makeZeroSpacing();
        return EC_OK;
       }

    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  */)
       {
        if (!_spacing) return EC_INVALID_PARAM;
        STRUCT_CLI_GUI_CSPACING prevSpacing = spacing;
        spacing = *_spacing;
        if (!isSpacingEqual(prevSpacing, spacing))
           {
            rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_SPACINGCHANGED, 0 );
           }
        return EC_OK;
       }

    CLIMETHOD(cellSpacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _cellSpacing /* [out] ::cli::gui::CSpacing _cellSpacing  */)
       {
        if (!_cellSpacing) return EC_INVALID_PARAM;
        if (!!ownerGrid)
           { // try to return owner's grid cellSpacing
            *_cellSpacing = ownerGrid.cellSpacing;
            return EC_OK;
           }
        *_cellSpacing = cellSpacing;
        return EC_OK;
       }

    CLIMETHOD(cellSpacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _cellSpacing /* [in,ref] ::cli::gui::CSpacing  _cellSpacing  */)
       {
        if (!_cellSpacing) return EC_INVALID_PARAM;
        cellSpacing = *_cellSpacing;

        SIZE_T rowIdx = 0;
        if (!!ownerGrid && !ownerGrid.getRowIndex(this, &rowIdx))
           {
            SIZE_T firstDiffCellIdx = SIZE_T_NPOS;
            if (buildCellSizesCache( rowIdx,  &firstDiffCellIdx ))
               rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE, 0, rowIdx, firstDiffCellIdx );
           }
        return EC_OK;
       }

    CLIMETHOD(ncDrawBackgroundGet) (THIS_ BOOL*    _ncDrawBackground /* [out] bool ncDrawBackground  */)
       {
        if (!_ncDrawBackground) return EC_INVALID_PARAM;
        *_ncDrawBackground = ncDrawBackground;
        return EC_OK;
       }

    CLIMETHOD(ncDrawBackgroundSet) (THIS_ BOOL    _ncDrawBackground /* [in] bool  ncDrawBackground  */)
       {
        BOOL prevDrawBg = ncDrawBackground;
        ncDrawBackground = _ncDrawBackground;
        if (prevDrawBg!=ncDrawBackground)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGDRAWCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool drawBackground  */)
       {
        if (!_drawBackground) return EC_INVALID_PARAM;
        *_drawBackground = drawBackground;
        return EC_OK;
       }

    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  drawBackground  */)
       {
        BOOL prevDrawBg = drawBackground;
        drawBackground = _drawBackground;
        if (prevDrawBg!=drawBackground)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_BGDRAWCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(ncBackgroundColorGet) (THIS_ COLORREF*    _ncBackgroundColor /* [out] colorref ncBackgroundColor  */)
       {
        if (!_ncBackgroundColor) return EC_INVALID_PARAM;
        if (ncBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return grid's value
            if (!!ownerGrid) *_ncBackgroundColor = ownerGrid.rowNcBackgroundColor;
            else             *_ncBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_ncBackgroundColor = ncBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(ncBackgroundColorSet) (THIS_ COLORREF    _ncBackgroundColor /* [in] colorref  ncBackgroundColor  */)
       {
        COLORREF prevBgColor = ncBackgroundColor;
        ncBackgroundColor = _ncBackgroundColor;
        if (prevBgColor!=ncBackgroundColor)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(ncActiveBackgroundColorGet) (THIS_ COLORREF*    _ncActiveBackgroundColor /* [out] colorref ncActiveBackgroundColor  */)
       {
        if (!_ncActiveBackgroundColor) return EC_INVALID_PARAM;
        if (ncActiveBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return row's value
            if (!!ownerGrid) *_ncActiveBackgroundColor = ownerGrid.activeRowNcBackgroundColor;
            else            *_ncActiveBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_ncActiveBackgroundColor = ncActiveBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(ncActiveBackgroundColorSet) (THIS_ COLORREF    _ncActiveBackgroundColor /* [in] colorref  ncActiveBackgroundColor  */)
       {
        COLORREF prevBgColor = ncActiveBackgroundColor;
        ncActiveBackgroundColor = _ncActiveBackgroundColor;
        if (prevBgColor!=ncActiveBackgroundColor)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTACTIVEBGCOLORCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref backgroundColor  */)
       {
        if (!_backgroundColor) return EC_INVALID_PARAM;
        if (backgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return grid's value
            if (!!ownerGrid) *_backgroundColor = ownerGrid.rowBackgroundColor;
            else            *_backgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_backgroundColor = backgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  backgroundColor  */)
       {
        COLORREF prevBgColor = backgroundColor;
        backgroundColor = _backgroundColor;
        if (prevBgColor!=backgroundColor)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_BGCOLORCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(activeBackgroundColorGet) (THIS_ COLORREF*    _activeBackgroundColor /* [out] colorref activeBackgroundColor  */)
       {
        if (!_activeBackgroundColor) return EC_INVALID_PARAM;
        if (activeBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return grid's value
            if (!!ownerGrid) *_activeBackgroundColor = ownerGrid.activeRowBackgroundColor;
            else            *_activeBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_activeBackgroundColor = activeBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(activeBackgroundColorSet) (THIS_ COLORREF    _activeBackgroundColor /* [in] colorref  activeBackgroundColor  */)
       {
        COLORREF prevBgColor = activeBackgroundColor;
        activeBackgroundColor = _activeBackgroundColor;
        if (prevBgColor!=activeBackgroundColor)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED, 0);
        return EC_OK;
       }


    CLIMETHOD(cellNcBackgroundColorGet) (THIS_ COLORREF*    _cellNcBackgroundColor /* [out] colorref _cellNcBackgroundColor  */)
       {
        if (!_cellNcBackgroundColor) return EC_INVALID_PARAM;
        if (cellNcBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return grid's value
            if (!!ownerGrid) *_cellNcBackgroundColor = ownerGrid.cellNcBackgroundColor;
            else             *_cellNcBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_cellNcBackgroundColor = cellNcBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(cellNcBackgroundColorSet) (THIS_ COLORREF    _cellNcBackgroundColor /* [in] colorref  _cellNcBackgroundColor  */)
       {
        COLORREF prevBgColor = cellNcBackgroundColor;
        cellNcBackgroundColor = _cellNcBackgroundColor;
        if (prevBgColor!=cellNcBackgroundColor)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(activeCellNcBackgroundColorGet) (THIS_ COLORREF*    _activeCellNcBackgroundColor /* [out] colorref _activeCellNcBackgroundColor  */)
       {
        if (!_activeCellNcBackgroundColor) return EC_INVALID_PARAM;
        if (activeCellNcBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return grid's value
            if (!!ownerGrid) *_activeCellNcBackgroundColor = ownerGrid.activeCellNcBackgroundColor;
            else            *_activeCellNcBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_activeCellNcBackgroundColor = activeCellNcBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(activeCellNcBackgroundColorSet) (THIS_ COLORREF    _activeCellNcBackgroundColor /* [in] colorref  _activeCellNcBackgroundColor  */)
       {
        COLORREF prevBgColor = activeCellNcBackgroundColor;
        activeCellNcBackgroundColor = _activeCellNcBackgroundColor;
        if (prevBgColor!=activeCellNcBackgroundColor)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(cellBackgroundColorGet) (THIS_ COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */)
       {
        if (!_cellBackgroundColor) return EC_INVALID_PARAM;
        if (cellBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return grid's value
            if (!!ownerGrid) *_cellBackgroundColor = ownerGrid.cellBackgroundColor;
            else             *_cellBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_cellBackgroundColor = cellBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(cellBackgroundColorSet) (THIS_ COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */)
       {
        COLORREF prevBgColor = cellBackgroundColor;
        cellBackgroundColor = _cellBackgroundColor;
        if (prevBgColor!=cellBackgroundColor)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(activeCellBackgroundColorGet) (THIS_ COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */)
       {
        if (!_activeCellBackgroundColor) return EC_INVALID_PARAM;
        if (activeCellBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return grid's value
            if (!!ownerGrid) *_activeCellBackgroundColor = ownerGrid.activeCellBackgroundColor;
            else            *_activeCellBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_activeCellBackgroundColor = activeCellBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(activeCellBackgroundColorSet) (THIS_ COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */)
       {
        COLORREF prevBgColor = activeCellBackgroundColor;
        activeCellBackgroundColor = _activeCellBackgroundColor;
        if (prevBgColor!=activeCellBackgroundColor)
           rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED, 0);
        return EC_OK;
       }

    CLIMETHOD(alignmentGet) (THIS_ ENUM_CLI_GUI_EALIGNMENT*    _alignment /* [out] ::cli::gui::cellgrid::EAlignment cellAlignment  */)
       {
        CLI_TRY{
                if (!_alignment) return EC_INVALID_PARAM;
                ENUM_CLI_GUI_EALIGNMENT gridAlignment = CLI_GUI_EALIGNMENT_TOP|CLI_GUI_EALIGNMENT_LEFT;
        
                if (!!ownerGrid) gridAlignment = ownerGrid.cellsAlignment;
        
                ENUM_CLI_GUI_EALIGNMENT resAlignment = alignment;
        
                if ((resAlignment&CLI_GUI_EALIGNMENT_VMASK) == CLI_GUI_EALIGNMENT_VUNDEFINED)
                   {
                    resAlignment &= ~CLI_GUI_EALIGNMENT_VMASK; // clear vert alignment
                    resAlignment |= gridAlignment&CLI_GUI_EALIGNMENT_VMASK;
                   }
                if ((resAlignment&CLI_GUI_EALIGNMENT_HMASK) == CLI_GUI_EALIGNMENT_HUNDEFINED)
                   {
                    resAlignment &= ~CLI_GUI_EALIGNMENT_HMASK; // clear hor alignment
                    resAlignment |= gridAlignment&CLI_GUI_EALIGNMENT_HMASK;
                   }
                *_alignment = resAlignment;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(alignmentSet) (THIS_ ENUM_CLI_GUI_EALIGNMENT    _alignment /* [in] ::cli::gui::cellgrid::EAlignment  cellAlignment  */)
       {
        alignment = _alignment;
        SIZE_T rowIdx = 0;
        if (!!ownerGrid) ownerGrid.getRowIndex(this, &rowIdx);
        buildCellSizesCache(rowIdx, 0);
        rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE, 0, rowIdx );
        return EC_OK;
       }

    CLIMETHOD(cellSizesGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _cellsSize /* [out] ::cli::drawing::CPoint _cellsSize  */)
       {
        if (!_cellsSize) return EC_INVALID_PARAM;
        ::std::vector< CCellPosSize >::const_iterator it = cachedCellSizes.begin();
        INT maxHeight = 0;
        INT width     = 0;
        for(; it!=cachedCellSizes.end(); ++it)
           {
            width += it->ncPosSize.widthHeight.x;
            if (maxHeight<it->ncPosSize.widthHeight.y) maxHeight = it->ncPosSize.widthHeight.y;
           }
        _cellsSize->x = width;
        _cellsSize->y = maxHeight;
        return EC_OK;
       }

    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        if (rowSize.x<0 || rowSize.y<0)
           {
            return cellSizesGet(_size);
           }
        *_size = rowSize;
        return EC_OK;
       }

    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        STRUCT_CLI_DRAWING_CPOINT prevRowSize = rowSize;
        rowSize = *_size;
        if (rowSize.x!=prevRowSize.x || rowSize.y!=prevRowSize.y)
           {
            if (!!ownerGrid)
               {
                SIZE_T rowIdx = 0;
                ownerGrid.getRowIndex(this, &rowIdx);
                buildCellSizesCache( rowIdx,  0 );
                rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE, 0, rowIdx );
               }
           }
        return EC_OK;
       }

    CLIMETHOD(invalidate) (THIS_ ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */)
       {
        if (!ownerGrid) return EC_OK; // nothing to do

        SIZE_T rowIdx = 0;
        RCODE res = ownerGrid.getRowIndex(this, &rowIdx);
        if (res) return res;

        return invalidateRow(rowIdx, invalidateType);
       }

    CLIMETHOD(invalidateRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                  , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                             )
       {
        if (!ownerGrid) return EC_OK; // nothing to do
        return ownerGrid.invalidateRow(rowIdx, invalidateType);
       }

    CLIMETHOD(invalidateCellPtr) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                      , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                 )
       {
        SIZE_T cellIdx = 0;
        RCODE res = getCellIndex( pcell, &cellIdx );
        if (res) return res;

        SIZE_T rowIdx = 0;
        res = ownerGrid.getRowIndex(this, &rowIdx);
        if (res) return res;

        return this->invalidateCellIdx( rowIdx, cellIdx, invalidateType );
       }

    CLIMETHOD(invalidateCellIdx) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                      , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                      , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                                 )
       {
        if (!ownerGrid) return EC_OK; // nothing to do
        return ownerGrid.invalidateCell( rowIdx, cellIdx, invalidateType );
       }

    CLIMETHOD(cellNotifyPtr) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pcell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pcell  */
                                  , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                  , UINT    param /* [in] uint  param  */
                             )
       {
        if (!ownerGrid) return EC_OK; // nothing to do

        SIZE_T cellIdx = 0;
        RCODE res = getCellIndex( pcell, &cellIdx );
        if (res) return res;

        SIZE_T rowIdx = 0;
        res = ownerGrid.getRowIndex(this, &rowIdx);
        if (res) return res;

        return this->cellNotifyIdx( rowIdx, cellIdx, eventType, param );
       }

    CLIMETHOD(getCellPosSize) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                              )
       {
        if (cellIdx>=cells.size()) return EC_OUT_OF_RANGE;
        if (cells.size()!=cachedCellSizes.size()) // unconsistent state
           {
            SIZE_T rowIdx = 0;
            if (!!ownerGrid) ownerGrid.getRowIndex(this, &rowIdx);
            buildCellSizesCache(rowIdx, 0);
           }

        if (cellIdx>=cachedCellSizes.size()) return EC_OUT_OF_RANGE;

        ::std::vector< CCellPosSize >::const_iterator it = cachedCellSizes.begin() + cellIdx;
        if (ncLeftTop        ) *ncLeftTop         = it->ncPosSize.leftTop;
        if (ncWidthHeight    ) *ncWidthHeight     = it->ncPosSize.widthHeight;
        if (clientLeftTop    ) *clientLeftTop     = it->clientPosSize.leftTop;
        if (clientWidthHeight) *clientWidthHeight = it->clientPosSize.widthHeight;

        return EC_OK;
       }


    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                       )
       {
        return EC_OK;
       }

    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                           )
       {
        return EC_OK;
       }

    CLIMETHOD(visibleGet) (THIS_ BOOL*    _visible /* [out] bool visible  */)
       {
        if (!_visible) return EC_INVALID_PARAM;
        *_visible = visible;
        return EC_OK;
       }

    CLIMETHOD(visibleSet) (THIS_ BOOL    _visible /* [in] bool  visible  */)
       {
        BOOL prevVisible = visible;
        visible = _visible;
        if (prevVisible!=visible)
           { // need to notify parent grid
            rowNotifyIdx(CLI_GUI_CELLGRID_ENOTIFYEVENT_VISIBLECHANGED, (ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT)visible );
           }
        return EC_OK;
       }

    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                    , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                               )
       {
        ::std::vector< INTERFACE_CLI_GUI_CELLGRID_IMULTICELL* >::iterator cit = cells.begin();
        for(; cit!=cells.end(); ++cit)
           {
            (*cit)->calculateLimits( pdc, rowIdx, cit - cells.begin() );
           }
        buildCellSizesCache(rowIdx, 0);
        return EC_OK;
       }

    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       {
        // UNDONE: update cells config
        return EC_OK;
       }

    CLIMETHOD(cellNotifyIdx) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                  , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                  , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                  , UINT    param /* [in] uint  param  */
                             )
       {       
        switch(eventType)
           {
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVATE:  
                 return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid

            case CLI_GUI_CELLGRID_ENOTIFYEVENT_VISIBLECHANGED:  
                 buildCellSizesCache(rowIdx, 0);
                 return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid

            case CLI_GUI_CELLGRID_ENOTIFYEVENT_SPACINGCHANGED:  
                 buildCellSizesCache(rowIdx, 0);
                 return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid

            case CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGDRAWCHANGED:  
                 return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid

            case CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED:                      
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTACTIVEBGCOLORCHANGED:                      
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_BGDRAWCHANGED:                      
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_BGCOLORCHANGED:                      
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED:  
                 return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid
                    
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED: 
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE:  
                 buildCellSizesCache(rowIdx, 0);
                 return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid
           }
        return EC_OK;
       }

}; // class CRowImpl



}; // namespace cellgrid
}; // namespace gui
}; // namespace cli



#endif // CLI_GUI_CG2_IROWIMPL_H

