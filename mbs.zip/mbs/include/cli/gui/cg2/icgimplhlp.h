#ifndef CLI_GUI_CG2_ICGIMPLHLP_H
#define CLI_GUI_CG2_ICGIMPLHLP_H


#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_GUI_CG2_CELLGRIDHLP_H
    #include <cli/gui/cg2/cellgridhlp.h>
#endif



namespace cli
{
namespace gui
{
namespace cellgrid
{

struct CPosSize
{
    STRUCT_CLI_DRAWING_CPOINT  leftTop;
    STRUCT_CLI_DRAWING_CPOINT  widthHeight;
    CPosSize() : leftTop(), widthHeight() {}
    CPosSize( const STRUCT_CLI_DRAWING_CPOINT &lt, const STRUCT_CLI_DRAWING_CPOINT &wh)
       : leftTop(lt), widthHeight(wh)
       { }

    bool operator==(const CPosSize &ps) const
       {
        return leftTop.x    ==ps.leftTop.x     && leftTop.y    ==ps.leftTop.y &&
               widthHeight.x==ps.widthHeight.x && widthHeight.y==ps.widthHeight.y;
       }
    bool operator!=(const CPosSize &ps) const
       {
        return !operator==(ps);
       }
};


struct CCellPosSize
{
    CPosSize ncPosSize;
    CPosSize clientPosSize;

    CCellPosSize() : ncPosSize(), clientPosSize() {}
    CCellPosSize(const CPosSize &nc, const CPosSize &client) : ncPosSize(nc), clientPosSize(client) { }

    bool operator==(const CCellPosSize &cps) const
       {
        return ncPosSize==cps.ncPosSize && clientPosSize==cps.clientPosSize;
       }
    bool operator!=(const CCellPosSize &cps) const
       {
        return !operator==(cps);
       }
};

typedef CCellPosSize CRowPosSize;


inline 
bool isEmptySpacing( const STRUCT_CLI_GUI_CSPACING &spacing )
   {
    UINT maxsp = ::cli::gui::maxSpacing( spacing );
    if (!maxsp) return true;
    return false;
   }

inline
bool testWhHit( const STRUCT_CLI_DRAWING_CPOINT        &pos
                , const STRUCT_CLI_DRAWING_CPOINT        &testSize // rect size
                )
   {
    if (pos.x<0 || pos.x>=testSize.x) return false;
    if (pos.y<0 || pos.y>=testSize.y) return false;
    return true;
   }

inline
bool testSpacingHit( const STRUCT_CLI_DRAWING_CPOINT        &pos
                   , const STRUCT_CLI_DRAWING_CPOINT        &testSize
                   , const STRUCT_CLI_GUI_CSPACING          &testSpacing
                   )
   {
    STRUCT_CLI_DRAWING_CPOINT woSpacingPos = pos;
    woSpacingPos.x -= testSpacing.left;
    woSpacingPos.y -= testSpacing.top;

    STRUCT_CLI_DRAWING_CPOINT withSpacingTestSize = testSize;
    withSpacingTestSize.x += testSpacing.left + testSpacing.right;
    withSpacingTestSize.y += testSpacing.top  + testSpacing.bottom;

    return testWhHit(pos, withSpacingTestSize) && !testWhHit(woSpacingPos, testSize);
   }



}; // namespace cellgrid
}; // namespace gui
}; // namespace cli


#endif /* CLI_GUI_CG2_ICGIMPLHLP_H */

