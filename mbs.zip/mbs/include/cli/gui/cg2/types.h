#ifndef CLI_GUI_CG2_TYPES_H
#define CLI_GUI_CG2_TYPES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/cg2/types.h>", CLI_GUI_CG2_TYPES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_CG2_TYPES_H
    #include <cli/gui/cg2/types.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::ESetSizeResultFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS           UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS           UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMIN
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMIN         CONSTANT_UINT(0x01)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMIN */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMAX
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMAX         CONSTANT_UINT(0x02)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMAX */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMASK
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMASK        CONSTANT_UINT(0x03)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMASK */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMIN
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMIN         CONSTANT_UINT(0x10)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMIN */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMAX
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMAX         CONSTANT_UINT(0x20)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMAX */

#ifndef CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMASK
    #define CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMASK        CONSTANT_UINT(0x30)
#endif /* CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMASK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace ESetSizeResultFlags {
                        const UINT xMin             = CONSTANT_UINT(0x01);
                        const UINT xMax             = CONSTANT_UINT(0x02);
                        const UINT xMask            = CONSTANT_UINT(0x03);
                        const UINT yMin             = CONSTANT_UINT(0x10);
                        const UINT yMax             = CONSTANT_UINT(0x20);
                        const UINT yMask            = CONSTANT_UINT(0x30);
                }; /* namespace ESetSizeResultFlags */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::ESetSizeResultFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::ECellLimits */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_ECELLLIMITS                   UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_ECELLLIMITS                   UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX
    #define CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX             CONSTANT_UINT(0xFFFF)
#endif /* CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX */

#ifndef CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY
    #define CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY             CONSTANT_UINT(0xFFFF)
#endif /* CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace ECellLimits {
                        const UINT maxSizeX         = CONSTANT_UINT(0xFFFF);
                        const UINT maxSizeY         = CONSTANT_UINT(0xFFFF);
                }; /* namespace ECellLimits */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::ECellLimits; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::ECellHotTrack */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK                 UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK                 UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKNONE
    #define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKNONE       CONSTANT_UINT(0x0000)
#endif /* CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKNONE */

#ifndef CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT
    #define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT  CONSTANT_UINT(0x0001)
#endif /* CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT */

#ifndef CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND
    #define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND                 CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace ECellHotTrack {
                        const UINT hotTrackNone     = CONSTANT_UINT(0x0000);
                        const UINT hotTrackHighlight        = CONSTANT_UINT(0x0001);
                        const UINT hotTrackBackground       = CONSTANT_UINT(0x0002);
                }; /* namespace ECellHotTrack */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::ECellHotTrack; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::EMoveActiveCellFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS          UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS          UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVELEFT
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVELEFT    CONSTANT_UINT(0x00010000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVELEFT */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVERIGHT
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVERIGHT   CONSTANT_UINT(0x00020000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVERIGHT */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEUP
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEUP      CONSTANT_UINT(0x00040000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEUP */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEDOWN
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEDOWN    CONSTANT_UINT(0x00080000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_MOVEDOWN */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATE
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATE    CONSTANT_UINT(0x00100000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATE */

#ifndef CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATEALTER
    #define CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATEALTER               CONSTANT_UINT(0x00200000)
#endif /* CLI_GUI_CELLGRID_EMOVEACTIVECELLFLAGS_ACTIVATEALTER */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace EMoveActiveCellFlags {
                        const UINT moveLeft         = CONSTANT_UINT(0x00010000);
                        const UINT moveRight        = CONSTANT_UINT(0x00020000);
                        const UINT moveUp           = CONSTANT_UINT(0x00040000);
                        const UINT moveDown         = CONSTANT_UINT(0x00080000);
                        const UINT activate         = CONSTANT_UINT(0x00100000);
                        const UINT activateAlter    = CONSTANT_UINT(0x00200000);
                }; /* namespace EMoveActiveCellFlags */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::EMoveActiveCellFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::EHitTestFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS                 UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS                 UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT            CONSTANT_UINT(0x0001)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING        CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWSPACING
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWSPACING         CONSTANT_UINT(0x0004)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWSPACING */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT             CONSTANT_UINT(0x0008)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING        CONSTANT_UINT(0x0010)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING */

#ifndef CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT
    #define CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT            CONSTANT_UINT(0x0020)
#endif /* CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace EHitTestFlags {
                        const UINT gridHit          = CONSTANT_UINT(0x0001);
                        const UINT gridSpacing      = CONSTANT_UINT(0x0002);
                        const UINT rowSpacing       = CONSTANT_UINT(0x0004);
                        const UINT rowHit           = CONSTANT_UINT(0x0008);
                        const UINT cellSpacing      = CONSTANT_UINT(0x0010);
                        const UINT cellHit          = CONSTANT_UINT(0x0020);
                }; /* namespace EHitTestFlags */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::EHitTestFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::ENotifyEvent */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT                  UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT                  UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVATE
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVATE            CONSTANT_UINT(0x0001)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVATE */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_VISIBLECHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_VISIBLECHANGED      CONSTANT_UINT(0x0002)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_VISIBLECHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_SPACINGCHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_SPACINGCHANGED      CONSTANT_UINT(0x0003)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_SPACINGCHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGDRAWCHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGDRAWCHANGED              CONSTANT_UINT(0x0004)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGDRAWCHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED             CONSTANT_UINT(0x0005)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTACTIVEBGCOLORCHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTACTIVEBGCOLORCHANGED       CONSTANT_UINT(0x0006)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTACTIVEBGCOLORCHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_BGDRAWCHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_BGDRAWCHANGED       CONSTANT_UINT(0x0007)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_BGDRAWCHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_BGCOLORCHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_BGCOLORCHANGED      CONSTANT_UINT(0x0008)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_BGCOLORCHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED                CONSTANT_UINT(0x0009)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED         CONSTANT_UINT(0x000A)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED */

#ifndef CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE
    #define CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE          CONSTANT_UINT(0x000B)
#endif /* CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace ENotifyEvent {
                        const UINT activate         = CONSTANT_UINT(0x0001);
                        const UINT visibleChanged   = CONSTANT_UINT(0x0002);
                        const UINT spacingChanged   = CONSTANT_UINT(0x0003);
                        const UINT nonClientBgDrawChanged   = CONSTANT_UINT(0x0004);
                        const UINT nonClientBgColorChanged  = CONSTANT_UINT(0x0005);
                        const UINT nonClientActiveBgColorChanged    = CONSTANT_UINT(0x0006);
                        const UINT bgDrawChanged    = CONSTANT_UINT(0x0007);
                        const UINT bgColorChanged   = CONSTANT_UINT(0x0008);
                        const UINT activeBgColorChanged     = CONSTANT_UINT(0x0009);
                        const UINT sizeChanged      = CONSTANT_UINT(0x000A);
                        const UINT needUpdate       = CONSTANT_UINT(0x000B);
                }; /* namespace ENotifyEvent */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::ENotifyEvent; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::gui::cellgrid::EInvalidateType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE               UINT
#else
    #define ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE               UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID            CONSTANT_UINT(0)
#endif /* CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID */

#ifndef CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDUPDATE
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDUPDATE             1
#endif /* CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDUPDATE */

#ifndef CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT            2
#endif /* CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT */

#ifndef CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLNEEDREPAINT
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLNEEDREPAINT  4
#endif /* CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLNEEDREPAINT */

#ifndef CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT   8
#endif /* CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            namespace cellgrid {
                namespace EInvalidateType {
                        const UINT valid            = CONSTANT_UINT(0);
                        const UINT cellClientNeedUpdate     = CONSTANT_UINT(1);
                        const UINT cellClientNeedRepaint    = CONSTANT_UINT(2);
                        const UINT cellNeedRepaint  = CONSTANT_UINT(4);
                        const UINT rowNeedRepaint   = CONSTANT_UINT(8);
                }; /* namespace EInvalidateType */
            }; /* namespace cellgrid */
        }; /* namespace gui */
    }; /* namespace cli */
    /* using namespace ::cli::gui::cellgrid::EInvalidateType; */
    
#endif




#endif /* CLI_GUI_CG2_TYPES_H */
