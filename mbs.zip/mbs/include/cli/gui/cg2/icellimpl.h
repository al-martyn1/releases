#ifndef CLI_GUI_CG2_ICELLIMPL_H
#define CLI_GUI_CG2_ICELLIMPL_H

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_GUI_CG2_IGRID_H
    #include <cli/gui/cg2/igrid.h>
#endif

#ifndef CLI_GUI_CG2_IROW_H
    #include <cli/gui/cg2/irow.h>
#endif

#ifndef CLI_GUI_CG2_ICELL_H
    #include <cli/gui/cg2/icell.h>
#endif

#ifndef CLI_GUI_CG2_CELLGRIDHLP_H
    #include <cli/gui/cg2/cellgridhlp.h>
#endif
    

namespace cli
{
namespace gui
{
namespace cellgrid
{

using ::cli::drawing::makePoint;
using ::cli::drawing::zeroPoint;
using ::cli::drawing::absPoint;
using ::cli::gui::makeSpacing;
using ::cli::gui::makeInvalidSpacing;
using ::cli::gui::makeZeroSpacing;
using ::cli::gui::isValidSpacing;
using ::cli::gui::isSpacingEqual;


class CSimpleCellImplBase : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL
                    , public INTERFACE_CLI_GUI_CELLGRID_IMULTICELL

{

public:

/*
    using ::cli::gui::makeSpacing;
    using ::cli::gui::makeInvalidSpacing;
    using ::cli::gui::makeZeroSpacing;
    using ::cli::gui::isValidSpacing;
    using ::cli::gui::isSpacingEqual;
*/


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CLI_BEGIN_INTERFACE_MAP2(CSimpleCellImplBase, INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_IMULTICELL  )
    CLI_END_INTERFACE_MAP(CSimpleCellImplBase)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    // reimplement 'destroy' in descendants
    void destroy() { delete this; }

    typedef ::cli::gui::cellgrid::CiRow_nrc CRow;

protected:

    CRow                                    ownerRow;
    BOOL                                    activeCell;
    BOOL                                    allowHotTracking;
    ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK     autoHotTrack;
    BOOL                                    visible;
    STRUCT_CLI_GUI_CSPACING                 spacing;
    BOOL                                    ncDrawBackground;
    COLORREF                                ncBackgroundColor;
    COLORREF                                ncActiveBackgroundColor;
    BOOL                                    drawBackground;
    COLORREF                                backgroundColor;
    COLORREF                                activeBackgroundColor;

    COLORREF                                color; //

    STRUCT_CLI_DRAWING_CPOINT               size;



    /*
    STRUCT_CLI_DRAWING_CPOINT maxS = makePoint(CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX, CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX)
    STRUCT_CLI_DRAWING_CPOINT minS = makePoint(0, 0)
    STRUCT_CLI_DRAWING_CPOINT               minSize;
    STRUCT_CLI_DRAWING_CPOINT               maxSize;
    */


public:

    CSimpleCellImplBase()
       : base_impl(DEF_MODULE)
       , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL()
       , INTERFACE_CLI_GUI_CELLGRID_IMULTICELL ()
       , ownerRow()
       , activeCell(FALSE)
       , allowHotTracking(TRUE)
       , autoHotTrack(CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT|CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND)
       , visible(TRUE)
       , spacing(makeInvalidSpacing())
       , ncDrawBackground(TRUE)
       , ncBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , ncActiveBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , drawBackground(TRUE)
       , backgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , activeBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , color(CLI_DRAWING_ECOLORREF_CONST_BLACK)
       , size(makePoint(0, 0))
       //, minSize()
       //, maxSize()
       {}

//private:
    bool isActiveCell( )
       {
        return activeCell ? true : false;
       }

    bool isActiveCell( const SIZE_T &idx1 /* row */, const SIZE_T &idx2 /* col */ )
       {
        return activeCell ? true : false;
       }

    CLIMETHOD(ncCurrentBackgroundColorGet) (THIS_ COLORREF*    _ncCurrentBackgroundColor /* [out] colorref _ncCurrentBackgroundColor  */)
       {
        if (!isActiveCell() || !allowHotTracking || !(autoHotTrack&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND))
           return ncBackgroundColorGet(_ncCurrentBackgroundColor);
        else
           return ncActiveBackgroundColorGet(_ncCurrentBackgroundColor);
       }

    CLIMETHOD(ncCurrentBackgroundColorGet) (THIS_ COLORREF*    _ncCurrentBackgroundColor /* [out] colorref _ncCurrentBackgroundColor  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                                           )
       {
        //BOOL                                    allowHotTracking;
        //ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK     autoHotTrack;
        //#define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKNONE       CONSTANT_UINT(0x0000)
        //#define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT  CONSTANT_UINT(0x0001)
        //#define CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND                 CONSTANT_UINT(0x0002)

        if (!isActiveCell(idx1,idx2) || !allowHotTracking || !(autoHotTrack&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND))
           return ncBackgroundColorGet(_ncCurrentBackgroundColor, idx1, idx2);
        else
           return ncActiveBackgroundColorGet(_ncCurrentBackgroundColor, idx1, idx2);
       }

    CLIMETHOD(ncCurrentBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(ncCurrentBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(currentBackgroundColorGet) (THIS_ COLORREF*    _currentBackgroundColor /* [out] colorref _currentBackgroundColor  */)
       {
        if (!isActiveCell() || !allowHotTracking || !(autoHotTrack&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND))
           return backgroundColorGet(_currentBackgroundColor);
        else
           return activeBackgroundColorGet(_currentBackgroundColor);
       }


    CLIMETHOD(currentBackgroundColorGet) (THIS_ COLORREF*    _currentBackgroundColor /* [out] colorref _currentBackgroundColor  */
                                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                                              , SIZE_T    idx2 /* [in] size_t  idx2  */
                                         )
       {
        if (!isActiveCell(idx1,idx2) || !allowHotTracking || !(autoHotTrack&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND))
           return backgroundColorGet(_currentBackgroundColor, idx1, idx2);
        else
           return activeBackgroundColorGet(_currentBackgroundColor, idx1, idx2);
       }

    CLIMETHOD(currentBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(currentBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(colorGet) (THIS_ COLORREF*    _color /* [out] colorref _color  */)
       {
        if (!_color) return EC_INVALID_PARAM;
        *_color = color;
        return EC_OK;
       }

    CLIMETHOD(colorSet) (THIS_ COLORREF    _color /* [in] colorref  _color  */)
       {
        color = _color;
        return EC_OK;
       }

    CLIMETHOD(colorGet) (THIS_ COLORREF*    _color /* [out] colorref _color  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                        )
       { return colorGet(_color); }

    CLIMETHOD(colorSet) (THIS_ COLORREF    _color /* [in] colorref  _color  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                        )
       { return colorSet(_color); }

    CLIMETHOD(colorSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       { if (_size) *_size = 1; return EC_OK; }
    CLIMETHOD(colorSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                          )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* ownerGrid  */)
       {
        if (!_ownerGrid) return EC_INVALID_PARAM;
        if (!ownerRow)   return EC_NO_OWNER;
        *_ownerGrid = ownerRow.ownerGrid;
        return EC_OK;
       }

    // iSimple
    CLIMETHOD(ownerRowGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* ownerRow  */)
       {
        if (!_ownerRow) return EC_INVALID_PARAM;
        *_ownerRow = ownerRow.getIfPtr();
        return EC_OK;
       }

    CLIMETHOD(ownerRowSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  ownerRow  */)
       {
        // don't need notify row that cell owner changed, row allready knows about this
        ownerRow = CRow(_ownerRow);
        return EC_OK;
       }

    // iMulti
    CLIMETHOD(ownerRowGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW**    _ownerRow /* [out] ::cli::gui::cellgrid::iRow* ownerRow  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       { return ownerRowGet(_ownerRow); }

    CLIMETHOD(ownerRowSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    _ownerRow /* [in] ::cli::gui::cellgrid::iRow*  ownerRow  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       { return ownerRowSet(_ownerRow); }

    CLIMETHOD(ownerRowSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(ownerRowSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                             )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(activeCellGet) (THIS_ BOOL*    _activeCell /* [out] bool activeCell  */)
       {
        if (!_activeCell) return EC_INVALID_PARAM;
        *_activeCell = activeCell;
        return EC_OK;
       }

    CLIMETHOD(activeCellSet) (THIS_ BOOL    _activeCell /* [in] bool  activeCell  */)
       {
        BOOL prevActive = activeCell;
        activeCell = _activeCell;
        if (prevActive!=activeCell)
           { // need to notify parent row
            if (!!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVATE, (ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT)activeCell );
           }
        return EC_OK;
       }

    CLIMETHOD(hotTrackedGet) (THIS_ BOOL*    _hotTracked /* [out] bool hotTracked  */)
       {
        if (!_hotTracked) return EC_INVALID_PARAM;
        *_hotTracked = allowHotTracking;
        return EC_OK;
       }

    CLIMETHOD(hotTrackedSet) (THIS_ BOOL    hotTracked /* [in] bool  hotTracked  */)
       {
        allowHotTracking = hotTracked;
        return EC_OK;
       }

    CLIMETHOD(activeCellGet) (THIS_ BOOL*    _activeCell /* [out] bool activeCell  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       { return activeCellGet(_activeCell); }

    CLIMETHOD(activeCellSet) (THIS_ BOOL    _activeCell /* [in] bool  activeCell  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       {
        BOOL prevActive = activeCell;
        activeCell = _activeCell;
        if (prevActive!=activeCell)
           { // need to notify parent row
            if (!!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVATE, (ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT)activeCell );
           }
        return EC_OK;
       }

    CLIMETHOD(activeCellSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(activeCellSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(hotTrackedGet) (THIS_ BOOL*    _hotTracked /* [out] bool hotTracked  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       { return hotTrackedGet(_hotTracked); }

    CLIMETHOD(hotTrackedSet) (THIS_ BOOL    _hotTracked /* [in] bool  hotTracked  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       { return hotTrackedSet(_hotTracked); }

    CLIMETHOD(hotTrackedSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(hotTrackedSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
       { if (_size) *_size = 1; return EC_OK; }


    CLIMETHOD(autoHotTrackGet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack autoHotTrack  */)
       {
        if (!_autoHotTrack) return EC_INVALID_PARAM;
        *_autoHotTrack = autoHotTrack;
        return EC_OK;
       }

    CLIMETHOD(autoHotTrackSet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK    _autoHotTrack /* [in] ::cli::gui::cellgrid::ECellHotTrack  autoHotTrack  */)
       {
        autoHotTrack = _autoHotTrack;
        return EC_OK;
       }

    CLIMETHOD(autoHotTrackGet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK*    _autoHotTrack /* [out] ::cli::gui::cellgrid::ECellHotTrack autoHotTrack  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       { return autoHotTrackGet(_autoHotTrack); }

    CLIMETHOD(autoHotTrackSet) (THIS_ ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK    _autoHotTrack /* [in] ::cli::gui::cellgrid::ECellHotTrack  autoHotTrack  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       { return autoHotTrackSet(_autoHotTrack); }

    CLIMETHOD(autoHotTrackSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(autoHotTrackSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
       { if (_size) *_size = 1; return EC_OK; }


    CLIMETHOD(visibleGet) (THIS_ BOOL*    _visible /* [out] bool visible  */)
       {
        if (!_visible) return EC_INVALID_PARAM;
        *_visible = visible;
        return EC_OK;
       }

    CLIMETHOD(visibleSet) (THIS_ BOOL    _visible /* [in] bool  visible  */)
       {
        BOOL prevVisible = visible;
        visible = _visible;
        if (prevVisible!=visible)
           { // need to notify parent row
            if (!!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_VISIBLECHANGED, (ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT)visible );
           }
        return EC_OK;
       }

    CLIMETHOD(visibleGet) (THIS_ BOOL*    _visible /* [out] bool visible  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       { return visibleGet(_visible); }

    CLIMETHOD(visibleSet) (THIS_ BOOL    _visible /* [in] bool  visible  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       {
        BOOL prevVisible = visible;
        visible = _visible;
        if (prevVisible!=visible)
           { // need to notify parent row
            if (!!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_VISIBLECHANGED, (ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT)visible );
           }
        return EC_OK;
       }

    CLIMETHOD(visibleSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(visibleSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _spacing /* [out] ::cli::gui::CSpacing spacing  */)
       {
        if (!_spacing) return EC_INVALID_PARAM;
        if (isValidSpacing(spacing)) // self spacing is valid - was explicitly set
           {
            *_spacing = spacing;
            return EC_OK;
           }
        if (!!ownerRow)
           { // try to return owner's row cellSpacing
            *_spacing = ownerRow.cellSpacing;
            if (!isValidSpacing(*_spacing)) // if owner cellSpacing invalid, return zero
               *_spacing = makeZeroSpacing();
            return EC_OK;
           }
        *_spacing = makeZeroSpacing();
        return EC_OK;
       }

    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _spacing /* [in,ref] ::cli::gui::CSpacing  spacing  */)
       {
        if (!_spacing) return EC_INVALID_PARAM;
        STRUCT_CLI_GUI_CSPACING prevSpacing = spacing;
        spacing = *_spacing;
        if (!isSpacingEqual(prevSpacing, spacing))
           {
            if (!!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_SPACINGCHANGED, 0 );
           }
        return EC_OK;
       }

    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _spacing /* [out] ::cli::gui::CSpacing spacing  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       { return spacingGet(_spacing); }

    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _spacing /* [in,ref] ::cli::gui::CSpacing  spacing  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       {
        if (!_spacing) return EC_INVALID_PARAM;
        STRUCT_CLI_GUI_CSPACING prevSpacing = spacing;
        spacing = *_spacing;
        if (!isSpacingEqual(prevSpacing, spacing))
           {
            if (!!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_SPACINGCHANGED, 0 );
           }
        return EC_OK;
       }

    CLIMETHOD(spacingSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(spacingSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       { if (_size) *_size = 1; return EC_OK; }



    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool drawBackground  */)
       {
        if (!_drawBackground) return EC_INVALID_PARAM;
        *_drawBackground = drawBackground;
        return EC_OK;
       }

    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  drawBackground  */)
       {
        BOOL prevDrawBg = drawBackground;
        drawBackground = _drawBackground;
        if (prevDrawBg!=drawBackground && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_BGDRAWCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref backgroundColor  */)
       {
        if (!_backgroundColor) return EC_INVALID_PARAM;
        if (backgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return row's value
            if (!!ownerRow) *_backgroundColor = ownerRow.cellBackgroundColor;
            else            *_backgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_backgroundColor = backgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  backgroundColor  */)
       {
        COLORREF prevBgColor = backgroundColor;
        backgroundColor = _backgroundColor;
        if (prevBgColor!=backgroundColor && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_BGCOLORCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(activeBackgroundColorGet) (THIS_ COLORREF*    _activeBackgroundColor /* [out] colorref activeBackgroundColor  */)
       {
        if (!_activeBackgroundColor) return EC_INVALID_PARAM;
        if (activeBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return row's value
            if (!!ownerRow) *_activeBackgroundColor = ownerRow.activeCellBackgroundColor;
            else            *_activeBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_activeBackgroundColor = activeBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(activeBackgroundColorSet) (THIS_ COLORREF    _activeBackgroundColor /* [in] colorref  activeBackgroundColor  */)
       {
        COLORREF prevBgColor = activeBackgroundColor;
        activeBackgroundColor = _activeBackgroundColor;
        if (prevBgColor!=activeBackgroundColor && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool drawBackground  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
       { return drawBackgroundGet(_drawBackground); }

    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  drawBackground  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 )
       {
        BOOL prevDrawBg = drawBackground;
        drawBackground = _drawBackground;
        if (prevDrawBg!=drawBackground && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_BGDRAWCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(drawBackgroundSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(drawBackgroundSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref backgroundColor  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  )
       { return backgroundColorGet(_backgroundColor); }

    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  backgroundColor  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       , SIZE_T    idx2 /* [in] size_t  idx2  */
                                  )
       {
        COLORREF prevBgColor = backgroundColor;
        backgroundColor = _backgroundColor;
        if (prevBgColor!=backgroundColor && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_BGCOLORCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(backgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(backgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(activeBackgroundColorGet) (THIS_ COLORREF*    _activeBackgroundColor /* [out] colorref activeBackgroundColor  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
       { return activeBackgroundColorGet(_activeBackgroundColor); }

    CLIMETHOD(activeBackgroundColorSet) (THIS_ COLORREF    _activeBackgroundColor /* [in] colorref  activeBackgroundColor  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                                        )
       {
        COLORREF prevBgColor = activeBackgroundColor;
        activeBackgroundColor = _activeBackgroundColor;
        if (prevBgColor!=activeBackgroundColor && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(activeBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(activeBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                          )
       { if (_size) *_size = 1; return EC_OK; }


    CLIMETHOD(ncDrawBackgroundGet) (THIS_ BOOL*    _ncDrawBackground /* [out] bool ncDrawBackground  */)
       {
        if (!_ncDrawBackground) return EC_INVALID_PARAM;
        *_ncDrawBackground = ncDrawBackground;
        return EC_OK;
       }

    CLIMETHOD(ncDrawBackgroundSet) (THIS_ BOOL    _ncDrawBackground /* [in] bool  ncDrawBackground  */)
       {
        BOOL prevDrawBg = ncDrawBackground;
        ncDrawBackground = _ncDrawBackground;
        if (prevDrawBg!=ncDrawBackground && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGDRAWCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(ncBackgroundColorGet) (THIS_ COLORREF*    _ncBackgroundColor /* [out] colorref ncBackgroundColor  */)
       {
        if (!_ncBackgroundColor) return EC_INVALID_PARAM;
        if (ncBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return row's value
            if (!!ownerRow) *_ncBackgroundColor = ownerRow.cellNcBackgroundColor;
            else            *_ncBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_ncBackgroundColor = ncBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(ncBackgroundColorSet) (THIS_ COLORREF    _ncBackgroundColor /* [in] colorref  ncBackgroundColor  */)
       {
        COLORREF prevBgColor = ncBackgroundColor;
        ncBackgroundColor = _ncBackgroundColor;
        if (prevBgColor!=ncBackgroundColor && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(ncActiveBackgroundColorGet) (THIS_ COLORREF*    _ncActiveBackgroundColor /* [out] colorref ncActiveBackgroundColor  */)
       {
        if (!_ncActiveBackgroundColor) return EC_INVALID_PARAM;
        if (ncActiveBackgroundColor==CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
           { // return row's value
            if (!!ownerRow) *_ncActiveBackgroundColor = ownerRow.activeCellNcBackgroundColor;
            else            *_ncActiveBackgroundColor = CLI_DRAWING_ECOLORREF_CONST_WHITE;
           }
        else
           {
            *_ncActiveBackgroundColor = ncActiveBackgroundColor;
           }
        return EC_OK;
       }

    CLIMETHOD(ncActiveBackgroundColorSet) (THIS_ COLORREF    _ncActiveBackgroundColor /* [in] colorref  ncActiveBackgroundColor  */)
       {
        COLORREF prevBgColor = ncActiveBackgroundColor;
        ncActiveBackgroundColor = _ncActiveBackgroundColor;
        if (prevBgColor!=ncActiveBackgroundColor && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTACTIVEBGCOLORCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(ncDrawBackgroundGet) (THIS_ BOOL*    _ncDrawBackground /* [out] bool ncDrawBackground  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   )
       { return ncDrawBackgroundGet(_ncDrawBackground); }

    CLIMETHOD(ncDrawBackgroundSet) (THIS_ BOOL    _ncDrawBackground /* [in] bool  ncDrawBackground  */
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        , SIZE_T    idx2 /* [in] size_t  idx2  */
                                   )
       {
        BOOL prevDrawBg = ncDrawBackground;
        ncDrawBackground = _ncDrawBackground;
        if (prevDrawBg!=ncDrawBackground && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGDRAWCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(ncDrawBackgroundSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(ncDrawBackgroundSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(ncBackgroundColorGet) (THIS_ COLORREF*    _ncBackgroundColor /* [out] colorref ncBackgroundColor  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                    )
       { return ncBackgroundColorGet(_ncBackgroundColor); }

    CLIMETHOD(ncBackgroundColorSet) (THIS_ COLORREF    _ncBackgroundColor /* [in] colorref  ncBackgroundColor  */
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                         , SIZE_T    idx2 /* [in] size_t  idx2  */
                                    )
       {
        COLORREF prevBgColor = ncBackgroundColor;
        ncBackgroundColor = _ncBackgroundColor;
        if (prevBgColor!=ncBackgroundColor && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(ncBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(ncBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(ncActiveBackgroundColorGet) (THIS_ COLORREF*    _ncActiveBackgroundColor /* [out] colorref ncActiveBackgroundColor  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          )
       { return ncActiveBackgroundColorGet(_ncActiveBackgroundColor); }

    CLIMETHOD(ncActiveBackgroundColorSet) (THIS_ COLORREF    _ncActiveBackgroundColor /* [in] colorref  ncActiveBackgroundColor  */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                                          )
       {
        COLORREF prevBgColor = ncActiveBackgroundColor;
        ncActiveBackgroundColor = _ncActiveBackgroundColor;
        if (prevBgColor!=ncActiveBackgroundColor && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTACTIVEBGCOLORCHANGED, 0 );
        return EC_OK;
       }

    CLIMETHOD(ncActiveBackgroundColorSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(ncActiveBackgroundColorSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = size;
        return EC_OK;
       }

    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        STRUCT_CLI_DRAWING_CPOINT prevSize = size;
        size = absPoint(*_size);

        UINT changedFlags = 0;
        if (prevSize.x!=size.x) changedFlags |= 1;
        if (prevSize.y!=size.y) changedFlags |= 2;

        if (changedFlags && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED, changedFlags );
        return EC_OK;
       }


    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint size  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                       )
       { return sizeGet(_size); }

    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  size  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                       )
       {
        if (!_size) return EC_INVALID_PARAM;
        STRUCT_CLI_DRAWING_CPOINT prevSize = size;
        size = absPoint(*_size);

        UINT changedFlags = 0;
        if (prevSize.x!=size.x) changedFlags |= 1;
        if (prevSize.y!=size.y) changedFlags |= 2;

        if (changedFlags && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED, changedFlags );
        return EC_OK;
       }

    CLIMETHOD(sizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(sizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                         )
       { if (_size) *_size = 1; return EC_OK; }


    CLIMETHOD(sizeXGet) (THIS_ INT*    _sizeX /* [out] int sizeX  */)
       {
        if (!_sizeX) return EC_INVALID_PARAM;
        *_sizeX = size.x;
        return EC_OK;
       }

    CLIMETHOD(sizeXSet) (THIS_ INT    _sizeX /* [in] int  sizeX  */)
       {
        if (!_sizeX) return EC_INVALID_PARAM;
        INT prevX = size.x;
        size.x = _sizeX>0 ? _sizeX : -_sizeX;

        UINT changedFlags = 0;
        if (prevX!=size.x) changedFlags |= 1;

        if (changedFlags && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED, changedFlags );
        return EC_OK;
       }

    CLIMETHOD(sizeXGet) (THIS_ INT*    _sizeX /* [out] int sizeX  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                        )
       { return sizeXGet(_sizeX); }

    CLIMETHOD(sizeXSet) (THIS_ INT    _sizeX /* [in] int  sizeX  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                        )
       {
        if (!_sizeX) return EC_INVALID_PARAM;
        INT prevX = size.x;
        size.x = _sizeX>0 ? _sizeX : -_sizeX;

        UINT changedFlags = 0;
        if (prevX!=size.x) changedFlags |= 1;

        if (changedFlags && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED, changedFlags );
        return EC_OK;
       }

    CLIMETHOD(sizeXSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(sizeXSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                          )
       { if (_size) *_size = 1; return EC_OK; }


    CLIMETHOD(sizeYGet) (THIS_ INT*    _sizeY /* [out] int sizeY  */)
       {
        if (!_sizeY) return EC_INVALID_PARAM;
        *_sizeY = size.y;
        return EC_OK;
       }

    CLIMETHOD(sizeYSet) (THIS_ INT    _sizeY /* [in] int  sizeY  */)
       {
        if (!_sizeY) return EC_INVALID_PARAM;
        INT prevY = size.y;
        size.y = _sizeY>0 ? _sizeY : -_sizeY;

        UINT changedFlags = 0;
        if (prevY!=size.y) changedFlags |= 2;

        if (changedFlags && !!ownerRow) ownerRow.cellNotifyPtr( this, CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED, changedFlags );
        return EC_OK;
       }

    CLIMETHOD(sizeYGet) (THIS_ INT*    _sizeY /* [out] int sizeY  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                        )
       { return sizeYGet(_sizeY); }

    CLIMETHOD(sizeYSet) (THIS_ INT    _sizeY /* [in] int  sizeY  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                        )
       {
        if (!_sizeY) return EC_INVALID_PARAM;
        INT prevY = size.y;
        size.y = _sizeY>0 ? _sizeY : -_sizeY;

        UINT changedFlags = 0;
        if (prevY!=size.y) changedFlags |= 2;

        if (changedFlags && !!ownerRow) ownerRow.cellNotifyIdx( idx1, idx2, CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED, changedFlags );
        return EC_OK;
       }

    CLIMETHOD(sizeYSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(sizeYSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                          )
       { if (_size) *_size = 1; return EC_OK; }


    // reimplement in childs, if needed
    CLIMETHOD(minSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [out] ::cli::drawing::CPoint minSize  */)
       {
        if (!_minSize) return EC_INVALID_PARAM;
        *_minSize = zeroPoint();
        return EC_OK;
       }

    CLIMETHOD(minSizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [in,ref] ::cli::drawing::CPoint  minSize  */)
       {
        if (!_minSize) return EC_INVALID_PARAM;
        // do nothing
        return EC_OK;
       }

    CLIMETHOD(maxSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [out] ::cli::drawing::CPoint maxSize  */)
       {
        if (!_maxSize) return EC_INVALID_PARAM;
        *_maxSize = makePoint(CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX, CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX);
        return EC_OK;
       }

    CLIMETHOD(maxSizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [in,ref] ::cli::drawing::CPoint  maxSize  */)
       {
        if (!_maxSize) return EC_INVALID_PARAM;
        // do nothing
        return EC_OK;
       }

    CLIMETHOD(minSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [out] ::cli::drawing::CPoint minSize  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       { return minSizeGet(_minSize); }

    CLIMETHOD(minSizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _minSize /* [in,ref] ::cli::drawing::CPoint  minSize  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       { return minSizeSet(_minSize); }

    CLIMETHOD(minSizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(minSizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(maxSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       { return maxSizeGet(_maxSize); }

    CLIMETHOD(maxSizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _maxSize /* [in,ref] ::cli::drawing::CPoint  maxSize  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               , SIZE_T    idx2 /* [in] size_t  idx2  */
                          )
       { return maxSizeSet(_maxSize); }

    CLIMETHOD(maxSizeSize1) (THIS_ SIZE_T*    _size /* [out] size_t size  */)
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(maxSizeSize2) (THIS_ SIZE_T*    _size /* [out] size_t size  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       { if (_size) *_size = 1; return EC_OK; }

    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                         )
       {
        RCODE res = minSizeGet(minSize);
        if (res) return res;
        return maxSizeGet(maxSize);
       }

    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                              , SIZE_T    idx2 /* [in] size_t  idx2  */
                         )
       {
        RCODE res = minSizeGet(minSize, idx1, idx2);
        if (res) return res;
        return maxSizeGet(maxSize, idx1, idx2);
       }

    // reimplement in childs

    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                            )
       { return EC_OK; }

    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       { return EC_OK; }

    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                            , SIZE_T    idx2 /* [in] size_t  idx2  */
                       )
       { return EC_OK; }

    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       { return EC_OK; }

    CLIMETHOD(updatePaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       { return paintClient(pdc, paintAreaSize, idx1, idx2); }

    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       { return EC_OK; }

    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                            )
       { return EC_OK; }




}; // class CSimpleCellImplBase



class CVisibilityControllerCellImpl : public CSimpleCellImplBase
                                    , public INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER

{

public:

/*
    using ::cli::gui::makeSpacing;
    using ::cli::gui::makeInvalidSpacing;
    using ::cli::gui::makeZeroSpacing;
    using ::cli::gui::isValidSpacing;
    using ::cli::gui::isSpacingEqual;
*/


    CLI_BEGIN_INTERFACE_MAP2(CVisibilityControllerCellImpl, INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_IMULTICELL  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER )
    CLI_END_INTERFACE_MAP(CVisibilityControllerCellImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return CSimpleCellImplBase::addRef() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return CSimpleCellImplBase::release(); }

    // reimplement 'destroy' in descendants
    void destroy() { delete this; }

    typedef ::cli::gui::cellgrid::CiRow_nrc CRow;

protected:

    ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO       autoVisibility;
    SIZE_T                                               controlledRow;
    SIZE_T                                               controlledCell;

    typedef ::cli::gui::cellgrid::CiGrid_nrc CGrid;

public:
     CVisibilityControllerCellImpl() 
       : CSimpleCellImplBase()
       , autoVisibility(CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_NONE)
       , controlledRow(SIZE_T_NPOS)
       , controlledCell(SIZE_T_NPOS)
       {}

    CLIMETHOD(autoVisibilityGet) (THIS_ ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO*    _autoVisibility /* [out] ::cli::gui::cellgrid::EVisibilityControledAuto _autoVisibility  */)
       {
        if (!_autoVisibility) return EC_INVALID_PARAM;
        *_autoVisibility = autoVisibility;
        return EC_OK;
       }

    CLIMETHOD(autoVisibilitySet) (THIS_ ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO    _autoVisibility /* [in] ::cli::gui::cellgrid::EVisibilityControledAuto  _autoVisibility  */)
       {
        ENUM_CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO prevAutoVisibility = autoVisibility;
        autoVisibility = _autoVisibility;
        if (prevAutoVisibility!=autoVisibility)
           {
            //UNDONE: need repaint
           }
        return EC_OK;
       }

    CLIMETHOD(rowGet) (THIS_ SIZE_T*    _row /* [out] size_t _row  */)
       {
        if (!_row) return EC_INVALID_PARAM;
        *_row = controlledRow;
        return EC_OK;
       }

    CLIMETHOD(rowSet) (THIS_ SIZE_T    _row /* [in] size_t  _row  */)
       {
        SIZE_T prevRow = controlledRow;
        controlledRow = _row;
        if (prevRow!=controlledRow)
           {
            //UNDONE: need repaint
           }
        return EC_OK;
       }

    CLIMETHOD(cellGet) (THIS_ SIZE_T*    _cell /* [out] size_t _cell  */)
       {
        if (!_cell) return EC_INVALID_PARAM;
        *_cell = controlledCell;
        return EC_OK;
       }

    CLIMETHOD(cellSet) (THIS_ SIZE_T    _cell /* [in] size_t  _cell  */)
       {
        SIZE_T prevCell = controlledCell;
        controlledCell = _cell;
        if (prevCell!=controlledCell)
           {
            //UNDONE: need repaint
           }
        return EC_OK;
       }

/*
    #define CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_NONE    CONSTANT_UINT(0)
    #define CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_ROW     1
    #define CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_CELL    2
*/
    void getControlledPos( SIZE_T *posRow, SIZE_T *posCell )
       {
        if (autoVisibility==CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_NONE)
           { // no automatic behavior
            if (posRow)  *posRow  = controlledRow;
            if (posCell) *posCell = controlledCell;
            return;
           }

        if (!ownerRow)
           { // can't control
            if (posRow)  *posRow  = SIZE_T_NPOS;
            if (posCell) *posCell = SIZE_T_NPOS;
            return;           
           }

        INTERFACE_CLI_GUI_CELLGRID_IGRID* pOwnerGrid = 0;
        RCODE res = this->ownerGridGet( &pOwnerGrid );
        if (res)
           { // can't control
            if (posRow)  *posRow  = SIZE_T_NPOS;
            if (posCell) *posCell = SIZE_T_NPOS;
            return;           
           }

        CGrid ownerGrid(pOwnerGrid);
        SIZE_T rowIdxFound  = SIZE_T_NPOS;

        if (ownerGrid.getRowIndex( ownerRow.getIfPtr(), &rowIdxFound))
           { // can't control
            if (posRow)  *posRow  = SIZE_T_NPOS;
            if (posCell) *posCell = SIZE_T_NPOS;
            return;           
           }

        if (autoVisibility==CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_ROW)
           {
            if (posRow)  *posRow  = rowIdxFound+1;
            if (posCell) *posCell = SIZE_T_NPOS;
            return;
           }

        SIZE_T cellIdxFound = SIZE_T_NPOS;
        if (ownerRow.getCellIndex( static_cast<INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*>(this), &cellIdxFound))
           { // can't control
            if (posRow)  *posRow  = SIZE_T_NPOS;
            if (posCell) *posCell = SIZE_T_NPOS;
            return;           
           }

        // autoVisibility==CLI_GUI_CELLGRID_EVISIBILITYCONTROLEDAUTO_CELL
        if (posRow)  *posRow  = rowIdxFound;
        if (posCell) *posCell = cellIdxFound+1;
        return;
       }

    CLIMETHOD(slaveVisibleGet) (THIS_ BOOL*    _visibleState /* [out] bool _visibleState  */)
       {
        if (!_visibleState) return EC_INVALID_PARAM;

        SIZE_T posRow = SIZE_T_NPOS, posCell = SIZE_T_NPOS;
        getControlledPos( &posRow, &posCell );
        if (posRow==SIZE_T_NPOS) return EC_NO_SLAVE; // nothing to do

        INTERFACE_CLI_GUI_CELLGRID_IGRID* pOwnerGrid = 0;
        RCODE res = this->ownerGridGet( &pOwnerGrid );
        if (res) return res;

        if (!pOwnerGrid) return EC_NO_OWNER;

        CGrid ownerGrid(pOwnerGrid);

        if (posCell==SIZE_T_NPOS)
           *_visibleState = ownerGrid.rowsVisible[posRow];
        else
           *_visibleState = ownerGrid.cellsVisible[posRow][posCell];
        return EC_OK;
       }

    CLIMETHOD(slaveVisibleSet) (THIS_ BOOL    _visibleState /* [in] bool  _visibleState  */)
       {
        SIZE_T posRow = SIZE_T_NPOS, posCell = SIZE_T_NPOS;
        getControlledPos( &posRow, &posCell );
        if (posRow==SIZE_T_NPOS) return EC_NO_SLAVE; // nothing to do

        INTERFACE_CLI_GUI_CELLGRID_IGRID* pOwnerGrid = 0;
        RCODE res = this->ownerGridGet( &pOwnerGrid );
        if (res) return res;

        if (!pOwnerGrid) return EC_NO_OWNER;

        CGrid ownerGrid(pOwnerGrid);

        if (posCell==SIZE_T_NPOS)
           ownerGrid.rowsVisible[posRow] = _visibleState;
        else
           ownerGrid.cellsVisible[posRow][posCell] = _visibleState;
        return EC_OK;
       }

    CLIMETHOD(slaveShow) (THIS)
       {
        return slaveVisibleSet(TRUE);
       }

    CLIMETHOD(slaveHide) (THIS)
       {
        return slaveVisibleSet(FALSE);
       }

    CLIMETHOD(slaveToggle) (THIS)
       {
        BOOL v = FALSE;
        RCODE res = slaveVisibleGet(&v);
        if (res) return res;
        return slaveVisibleSet( v ? FALSE : TRUE );
       }

    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       { 
        if (!paintAreaSize) return EC_OK;
        if (!pdc) return EC_OK;

        BOOL bState = FALSE;
        RCODE res = slaveVisibleGet(&bState);
        if (res) return res;

        int x = paintAreaSize->x / 2;
        int y = paintAreaSize->y / 2;

        int left = 0;
        int right = paintAreaSize->x;
        if (paintAreaSize->x>4) 
           {
            left = 1; 
            right = paintAreaSize->x - 1;
           }

        int top = 0;
        int bottom = paintAreaSize->y;
        if (paintAreaSize->y>4) 
           {
            top = 1; 
            bottom = paintAreaSize->y - 1;
           }

        /*
        COLORREF color = 0; // black
        if (!activeCell)
           ncBackgroundColorGet( &color );
        else
           ncActiveBackgroundColorGet( &color );
        */
        pdc->pushSetPen( color, 1, CLI_DRAWING_EPENSTYLE_SOLID );

        pdc->drawLine( left, y, right, y );
        if (!bState)
           pdc->drawLine( x, top, x, bottom );

        pdc->popPen();

        return EC_OK;
       }

    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                , SIZE_T    idx2 /* [in] size_t  idx2  */
                           )
       { 
        // UNDONE: invalidate cell
        INTERFACE_CLI_GUI_CELLGRID_IGRID* pOwnerGrid = 0;
        RCODE res = this->ownerGridGet( &pOwnerGrid );
        if (res) return res;
        if (!pOwnerGrid) return EC_NO_OWNER;

        CGrid ownerGrid(pOwnerGrid);
        ownerGrid.invalidateCell(idx1, idx2, CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT);
        //ownerGrid.paintCell(idx1, idx2);
        return EC_OK;
       }

    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 , SIZE_T    idx2 /* [in] size_t  idx2  */
                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                            )
       { 
        if (eventFlags!=CLI_GUI_EMICECLICKFLAGS_LEFTBUTTONDOWN) return EC_OK;

        // UNDONE: invalidate cell
        INTERFACE_CLI_GUI_CELLGRID_IGRID* pOwnerGrid = 0;
        RCODE res = this->ownerGridGet( &pOwnerGrid );
        if (!res && pOwnerGrid) 
           {
            CGrid ownerGrid(pOwnerGrid);
            ownerGrid.invalidateCell(idx1, idx2, CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT);
           }

        return slaveToggle();
       }


}; // class CVisibilityControllerCellImpl














}; // namespace cellgrid
}; // namespace gui
}; // namespace cli



#endif // CLI_GUI_CG2_ICELLIMPL_H

