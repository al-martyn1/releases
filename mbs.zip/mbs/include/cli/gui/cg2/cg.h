#ifndef CLI_GUI_CG2_CG_H
#define CLI_GUI_CG2_CG_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/cg2/cg.h>", CLI_GUI_CG2_CG_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_CG2_CG_H
    #include <cli/gui/cg2/cg.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_GUI_CG2_IGRID_H
    #include <cli/gui/cg2/igrid.h>
#endif

#ifndef CLI_GUI_CG2_IROW_H
    #include <cli/gui/cg2/irow.h>
#endif

#ifndef CLI_GUI_CG2_ICELL_H
    #include <cli/gui/cg2/icell.h>
#endif

#ifndef CLI_GUI_CG2_IOWNER_H
    #include <cli/gui/cg2/iowner.h>
#endif

#endif /* CLI_GUI_CG2_CG_H */
