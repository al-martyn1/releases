#ifndef CLI_GUI_CG2_CELLGRIDHLP_H
#define CLI_GUI_CG2_CELLGRIDHLP_H

/*
#ifndef CLI_GUI_CELLGRIDHLP_H
    #include <cli/gui/cellgridhlp.h>
#endif
*/

#ifndef CLI_GUI_CG2_TYPES_H
    #include <cli/gui/cg2/types.h>
#endif

namespace cli {
namespace gui {


template <typename T> T max2( T t1, T t2 )             { return t1>t2 ? t1 : t2; }
template <typename T> T max3( T t1, T t2, T t3 )       { return max2( t1, max2(t2, t3)); }
template <typename T> T max4( T t1, T t2, T t3, T t4 ) { return max2( max2(t1, t2), max2(t3, t4)); }

inline
UINT maxSpacing( const STRUCT_CLI_GUI_CSPACING &spacing)
   {
    return max4(spacing.left, spacing.top, spacing.right, spacing.bottom );
   }

template <typename T> T min2( T t1, T t2 )             { return t1<t2 ? t1 : t2; }
template <typename T> T min3( T t1, T t2, T t3 )       { return min2( t1, min2(t2, t3)); }
template <typename T> T min4( T t1, T t2, T t3, T t4 ) { return min2( min2(t1, t2), min2(t3, t4)); }

inline
UINT minSpacing( const STRUCT_CLI_GUI_CSPACING &spacing)
   {
    return min4(spacing.left, spacing.top, spacing.right, spacing.bottom );
   }



inline
STRUCT_CLI_GUI_CSPACING makeSpacing( UINT left, UINT top, UINT right, UINT bottom )
   {
    STRUCT_CLI_GUI_CSPACING spacing;
    spacing.top    = top;
    spacing.bottom = bottom;
    spacing.left   = left;
    spacing.right  = right;
    return spacing;
   }

inline
STRUCT_CLI_GUI_CSPACING makeInvalidSpacing( )
   {
    STRUCT_CLI_GUI_CSPACING spacing;
    spacing.top    = (UINT)-1;
    spacing.bottom = (UINT)-1;
    spacing.left   = (UINT)-1;
    spacing.right  = (UINT)-1;
    return spacing;
   }

inline
STRUCT_CLI_GUI_CSPACING makeZeroSpacing( )
   {
    STRUCT_CLI_GUI_CSPACING spacing;
    spacing.top    = 0;
    spacing.bottom = 0;
    spacing.left   = 0;
    spacing.right  = 0;
    return spacing;
   }

inline
STRUCT_CLI_GUI_CSPACING zeroSpacing( ) { return makeZeroSpacing( ); }


bool isValidSpacing( const STRUCT_CLI_GUI_CSPACING &spacing )
   {
    if ( spacing.top    == (UINT)-1
       ||spacing.bottom == (UINT)-1
       ||spacing.left   == (UINT)-1
       ||spacing.right  == (UINT)-1
       ) return false; // invalid spacing
    return true; // valid
   }

bool isSpacingEqual( const STRUCT_CLI_GUI_CSPACING &spacing1, const STRUCT_CLI_GUI_CSPACING &spacing2 )
   {
    return
    spacing1.top    == spacing2.top    &&
    spacing1.bottom == spacing2.bottom &&
    spacing1.left   == spacing2.left   &&
    spacing1.right  == spacing2.right   ;
   }


}; /* namespace gui */
}; /* namespace cli */



#endif /* CLI_GUI_CG2_CELLGRIDHLP_H */

