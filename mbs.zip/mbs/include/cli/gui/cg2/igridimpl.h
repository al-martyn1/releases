#ifndef CLI_GUI_CG2_IGRIDIMPL_H
#define CLI_GUI_CG2_IGRIDIMPL_H

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_GUI_CG2_IGRID_H
    #include <cli/gui/cg2/igrid.h>
#endif

#ifndef CLI_GUI_CG2_IROW_H
    #include <cli/gui/cg2/irow.h>
#endif

#ifndef CLI_GUI_CG2_ICELL_H
    #include <cli/gui/cg2/icell.h>
#endif

#ifndef CLI_GUI_CG2_CELLGRIDHLP_H
    #include <cli/gui/cg2/cellgridhlp.h>
#endif

#ifndef CLI_GUI_CG2_ICGIMPLHLP_H
    #include <cli/gui/cg2/icgimplhlp.h>
#endif

#include <cli/gui/cg2/iowner.h>

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_DRAWING_DCAUTO_H
    #include <cli/drawing/dcauto.h>
#endif

#ifndef CLI_CLITRACE_H
    #include <cli/clitrace.h>
#endif

    

namespace cli
{
namespace gui
{
namespace cellgrid
{

using ::cli::drawing::makePoint;
using ::cli::drawing::zeroPoint;
using ::cli::drawing::absPoint;
using ::cli::gui::makeSpacing;
using ::cli::gui::makeInvalidSpacing;
using ::cli::gui::makeZeroSpacing;
using ::cli::gui::isValidSpacing;
using ::cli::gui::isSpacingEqual;


#ifndef CLI_GUI_SIZE
    #define CLI_GUI_SIZE STRUCT_CLI_DRAWING_CPOINT
#endif

#ifndef CLI_GUI_POINT
    #define CLI_GUI_POINT STRUCT_CLI_DRAWING_CPOINT
#endif


struct CRowValidInfo
{
    ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE                    fullRowInvalid;
    ::std::vector< ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE >   cellsInvalid;
    //CRowValidInfo() : fullRowInvalid(CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID), cellsInvalid() {}

    CRowValidInfo(ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE invalid = CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID
                 , size_t numCells = 0) 
       : fullRowInvalid(invalid), cellsInvalid(numCells, invalid) 
       {
       }
};



class CGridImpl;

class CAutoLockUpdate
{
        CGridImpl *pLockOwner; // lockUpdate
        BOOL       prevLockUpdate;
    public: 
        CAutoLockUpdate(CGridImpl *plo, BOOL newLockState=TRUE);
        ~CAutoLockUpdate();
};


class CGridImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                , public INTERFACE_CLI_GUI_CELLGRID_IGRID

{

    friend class CAutoLockUpdate;

public:

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CLI_BEGIN_INTERFACE_MAP2(CGridImpl, INTERFACE_CLI_GUI_CELLGRID_IGRID)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_IGRID )
    CLI_END_INTERFACE_MAP(CgridImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    // reimplement 'destroy' in descendants
    void destroy() { delete this; }

    //typedef ::cli::gui::cellgrid::CiGrid_nrc CGrid;
    typedef ::cli::gui::cellgrid::CiGridOwner COwner;
    

protected:

    COwner                                                  owner;
    ::std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>         rows;
    ::std::vector< CCellPosSize >                           cachedRowSizes;

    BOOL                                                    lockUpdate;
    STRUCT_CLI_GUI_CSPACING                                 spacing;
    STRUCT_CLI_GUI_CSPACING                                 rowSpacing;
    STRUCT_CLI_GUI_CSPACING                                 cellSpacing;

    COLORREF                                                gridNcBackgroundColor;
    COLORREF                                                gridBackgroundColor;
    COLORREF                                                rowNcBackgroundColor;
    COLORREF                                                activeRowNcBackgroundColor;
    COLORREF                                                rowBackgroundColor;
    COLORREF                                                activeRowBackgroundColor;
    COLORREF                                                cellNcBackgroundColor;
    COLORREF                                                activeCellNcBackgroundColor;
    COLORREF                                                cellBackgroundColor;
    COLORREF                                                activeCellBackgroundColor;

    ENUM_CLI_GUI_EALIGNMENT                                 cellsAlignment;
    ENUM_CLI_GUI_EALIGNMENT                                 rowsAlignment;

    STRUCT_CLI_DRAWING_CPOINT                               gridSize;

    SIZE_T                                                  activeRow;
    SIZE_T                                                  activeCell;

    BOOL                                                    activateOnClick;

    SIZE_T                                                  captureRow;
    SIZE_T                                                  captureCell;

    enum EActiveCellChangeType
       {
        defaultValue   = 0,
        noChanges      = 1,
        cellChanged    = 2,
        rowCellChanged = 3,
        clearActive    = 4 // no new active cell
       };

    EActiveCellChangeType                                   activeCellChangeType;

    bool                                                    ignoreActiveCellChangedNotify;

    ::std::vector< CRowValidInfo >                          validInfo;


public:

    CGridImpl()
       : base_impl(DEF_MODULE)
       , INTERFACE_CLI_GUI_CELLGRID_IGRID()
       , owner()
       , rows()
       , lockUpdate(FALSE)
       , spacing(makeZeroSpacing())
       , rowSpacing(makeZeroSpacing())
       , cellSpacing(makeZeroSpacing())

       , gridNcBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_BLACK)
       , gridBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_WHITE)
       , rowNcBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_BLACK)
       , activeRowNcBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_WHITE)
       , rowBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_WHITE)
       , activeRowBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_WHITE)
       , cellNcBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_BLACK)
       , activeCellNcBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_WHITE)
       , cellBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_WHITE)
       , activeCellBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_WHITE)

       , cellsAlignment(CLI_GUI_EALIGNMENT_LEFT|CLI_GUI_EALIGNMENT_TOP)
       , rowsAlignment(CLI_GUI_EALIGNMENT_LEFT)

       , gridSize(makePoint(-1, -1))

       , activeRow(SIZE_T_NPOS)
       , activeCell(SIZE_T_NPOS)

       , activateOnClick(FALSE)
       , captureRow(SIZE_T_NPOS)
       , captureCell(SIZE_T_NPOS)
       //, ownerGrid()
       , activeCellChangeType(defaultValue)
       , ignoreActiveCellChangedNotify(false)

       , validInfo()
       {}

    ~CGridImpl()
       {
        //cellsClear();
        rowsClear();
       }

    void updatePaintComplete()
       {
        validInfo.clear();
       }

    void expandValidInfo( size_t rowIdx )
       {
        if (rowIdx<validInfo.size()) return; // expanding not needed
        //::std::vector< CRowValidInfo >::size_type numberOfRowsToAdd = rowIdx - validInfo.size() + 1;
        validInfo.insert( validInfo.end(), rowIdx - validInfo.size() + 1, CRowValidInfo());
       }

    void setRowValidInfo( size_t rowIdx, ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE invalidateType )
       {
        expandValidInfo( rowIdx );
        if (!invalidateType || invalidateType>validInfo[rowIdx].fullRowInvalid)
           validInfo[rowIdx].fullRowInvalid = invalidateType;
       }

    void expandCellValidInfo( size_t rowIdx, size_t cellIdx )
       {
        expandValidInfo(rowIdx);
        if (cellIdx<validInfo[rowIdx].cellsInvalid.size()) return; // expanding not needed
        validInfo[rowIdx].cellsInvalid.insert( validInfo[rowIdx].cellsInvalid.end(), cellIdx - validInfo[rowIdx].cellsInvalid.size() + 1, CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID);
       }

    void setCellValidInfo( size_t rowIdx, size_t cellIdx, ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE invalidateType )
       {
        expandCellValidInfo( rowIdx, cellIdx );
        if (!invalidateType || invalidateType>validInfo[rowIdx].cellsInvalid[cellIdx])
           validInfo[rowIdx].cellsInvalid[cellIdx] = invalidateType;
       }

    ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE isRowNeedRepaint( size_t rowIdx )
       {
        if (rowIdx>=validInfo.size()) return CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID; // no info, by default row is valid
        if (validInfo[rowIdx].fullRowInvalid==CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT) 
           return CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT; // row invalid at all
        
        ::std::vector< ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE >::const_iterator cit = validInfo[rowIdx].cellsInvalid.begin();
        //ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE cellsMinValue = CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT;
        bool allCellsNeedRepaint    = true;
        bool allCellsLeaveUntouched = true;

        for(; cit!=validInfo[rowIdx].cellsInvalid.end(); ++cit)
           {
            if (*cit>CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID)           allCellsLeaveUntouched = false;
            if (*cit<CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLNEEDREPAINT) allCellsNeedRepaint = false;
           }

        if (allCellsNeedRepaint)    return CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT;
        if (allCellsLeaveUntouched) return CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID;
        return CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLNEEDREPAINT; // some cells need client update, client repain or cull cell repaint needed
       }

    ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE isCellNeedRepaint( size_t rowIdx, size_t cellIdx )
       {
        if (rowIdx >=validInfo.size()) return CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID; // no info, by default row is valid
        if (cellIdx>=validInfo[rowIdx].cellsInvalid.size()) return CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID; // no info, by default row is valid
        return validInfo[rowIdx].cellsInvalid[cellIdx];
       }

/*

struct CRowValidInfo
{
    ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE                    fullRowInvalid;
    ::std::vector< ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE >   cellsInvalid;
    CRowValidInfo() : fullRowInvalid(CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID), cellsValid() {}

    CRowValidInfo(ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE invalid = CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID
                 , size_t numCells = 0) 
       : fullRowInvalid(invalid), cellsValid(numCells, invalid) 
       {
       }
};
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDUPDATE             1
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT            2
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLNEEDREPAINT  4
    #define CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT   8
    */

    CLIMETHOD(invalidateRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                  , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                             )
       {
        if (rowIdx==SIZE_T_NPOS) return EC_INVALID_PARAM;
        // currently invalidateType is ignored for row
        setRowValidInfo( rowIdx, CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT );
        return EC_OK;
       }

    CLIMETHOD(invalidateCell) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                   , ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE    invalidateType /* [in] ::cli::gui::cellgrid::EInvalidateType  invalidateType  */
                              )
       {
        if (rowIdx==SIZE_T_NPOS || cellIdx==SIZE_T_NPOS) return EC_INVALID_PARAM;
        if (!invalidateType) return EC_OK; // user can't clear invalidation type
        if (invalidateType<=CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT)
           setCellValidInfo( rowIdx, cellIdx, invalidateType );
        else
           setCellValidInfo( rowIdx, cellIdx, CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT );
        
        return EC_OK;
       }



/*
struct CRowValidInfo
{
    bool                   fullRowInvalid;
    ::std::vector< bool >  cellsValid;
    CRowValidInfo() : fullRowInvalid(false), cellsValid() {}
};
    ::std::vector< CRowValidInfo >                          validInfo;
*/


    CLIMETHOD(gridOwnerGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER**    _gridOwner /* [out] ::cli::gui::cellgrid::iGridOwner* _gridOwner  */)
       {
        if (!_gridOwner) return EC_INVALID_PARAM;
        *_gridOwner = owner.getIfPtr();;
        return EC_OK;
       }

    CLIMETHOD(cellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL**    _cells /* [out] ::cli::gui::cellgrid::iSimpleCell* _cells  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                        )
       {
        if (!_cells) return EC_INVALID_PARAM;
        if (idx1>=rows.size()) return EC_OUT_OF_RANGE;
        // this checks are in cellsGet too
        //SIZE_T numCells = 0;
        //RCODE res = rows[idx1]->cellsSize(&numCells);
        //if (res) return res;
        //if (idx2>=numCells) return EC_OUT_OF_RANGE;
        return rows[idx1]->cellsGet(_cells, idx2);
       }

    CLIMETHOD(cellsSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = rows.size();
        return EC_OK;
       }

    CLIMETHOD(cellsSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                          )
       {
        if (!_size) return EC_INVALID_PARAM;
        if (idx1>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[idx1]->cellsSize(_size);
       }

    CLIMETHOD(multiCellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    _multiCells /* [out] ::cli::gui::cellgrid::iMultiCell* _multiCells  */
                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
       {
        if (!_multiCells) return EC_INVALID_PARAM;
        if (idx1>=rows.size()) return EC_OUT_OF_RANGE;
        // this checks are in cellsGet too
        //SIZE_T numCells = 0;
        //RCODE res = rows[idx1]->multiCellsSize(&numCells);
        //if (res) return res;
        //if (idx2>=numCells) return EC_OUT_OF_RANGE;
        return rows[idx1]->multiCellsGet(_multiCells, idx2);
       }

    CLIMETHOD(multiCellsSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = rows.size();
        return EC_OK;
       }

    CLIMETHOD(multiCellsSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
       {
        if (!_size) return EC_INVALID_PARAM;
        if (idx1>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[idx1]->cellsSize(_size);
       }

    CLIMETHOD(rowsVisibleGet) (THIS_ BOOL*    _rowsVisible /* [out] bool _rowsVisible  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
       {
        if (!_rowsVisible) return EC_INVALID_PARAM;
        if (idx1>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[idx1]->visibleGet(_rowsVisible);
       }

    CLIMETHOD(rowsVisibleSet) (THIS_ BOOL    _rowsVisible /* [in] bool  _rowsVisible  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
       {
        if (idx1>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[idx1]->visibleSet(_rowsVisible);
       }

    CLIMETHOD(rowsVisibleSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = rows.size();
        return EC_OK;
       }

    CLIMETHOD(cellsVisibleGet) (THIS_ BOOL*    _cellsVisible /* [out] bool _cellsVisible  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       {
        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;
        RCODE res = multiCellsGet( &pCell, idx1, idx2 );
        if (res) return res;
        if (!pCell) return EC_INVALID_OBJECT_PTR;
        return pCell->visibleGet(_cellsVisible, idx1, idx2);
       }

    CLIMETHOD(cellsVisibleSet) (THIS_ BOOL    _cellsVisible /* [in] bool  _cellsVisible  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       {
        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;
        RCODE res = multiCellsGet( &pCell, idx1, idx2 );
        if (res) return res;
        if (!pCell) return EC_INVALID_OBJECT_PTR;
        return pCell->visibleSet(_cellsVisible, idx1, idx2);
       }

    CLIMETHOD(cellsVisibleSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = rows.size();
        return EC_OK;
       }

    CLIMETHOD(cellsVisibleSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
       {
        if (!_size) return EC_INVALID_PARAM;
        if (idx1>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[idx1]->cellsSize(_size);
       }

    CLIMETHOD(cellsActiveGet) (THIS_ BOOL*    _cellsActive /* [out] bool _cellsActive  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   , SIZE_T    idx2 /* [in] size_t  idx2  */
                              )
       {
        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;
        RCODE res = multiCellsGet( &pCell, idx1, idx2 );
        if (res) return res;
        if (!pCell) return EC_INVALID_OBJECT_PTR;
        return pCell->activeCellGet(_cellsActive, idx1, idx2);
       }

    CLIMETHOD(cellsActiveSet) (THIS_ BOOL    _cellsActive /* [in] bool  _cellsActive  */
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   , SIZE_T    idx2 /* [in] size_t  idx2  */
                              )
       {
        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;
        RCODE res = multiCellsGet( &pCell, idx1, idx2 );
        if (res) return res;
        if (!pCell) return EC_INVALID_OBJECT_PTR;
        return pCell->activeCellSet(_cellsActive, idx1, idx2);
       }

  //activeRow  = rowIdx;
  //activeCell = cellIdx;
/*
    enum EActiveCellChangeType
       {
        defaultValue   = 0
        noChanges      = 1,
        cellChanged    = 2,
        rowCellChanged = 3,
        clearActive    = 4 // no new active cell
       };
*/

    CLIMETHOD(cellsActiveSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        *_size = rows.size();
        return EC_OK;
       }

    CLIMETHOD(cellsActiveSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                )
       {
        if (!_size) return EC_INVALID_PARAM;
        if (idx1>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[idx1]->cellsSize(_size);
       }

    CLIMETHOD(resetActiveCell) (THIS)
       {
        if (activeRow==SIZE_T_NPOS || activeCell==SIZE_T_NPOS)
           { // nothing to do
            activeRow  = SIZE_T_NPOS;
            activeCell = SIZE_T_NPOS;
            return EC_OK;
           }
        return cellsActiveSet( FALSE /* clear active */, activeRow, activeCell );
       }



    void buildRowSizesCacheAux( ::std::vector< CCellPosSize > &sizes
                              , ENUM_CLI_GUI_EALIGNMENT _alignment
                              , STRUCT_CLI_DRAWING_CPOINT newGridSize
                              )
       {
        ENUM_CLI_GUI_EALIGNMENT vAlignment = _alignment & CLI_GUI_EALIGNMENT_VMASK;
        ENUM_CLI_GUI_EALIGNMENT hAlignment = _alignment & CLI_GUI_EALIGNMENT_HMASK;

        INT maxWidth = 0;
        //cachedCellSizes.clear();
        if (newGridSize.x<0 || newGridSize.y<0)
           {
            newGridSize.x = 0;
            newGridSize.y = 0;
           }

        INT rowTop = 0;
        INT summHeight = 0;
        SIZE_T rowIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rows.begin();
        for(; it!=rows.end(); ++it, ++rowIdx) 
           {
            BOOL rowVisible = TRUE;
            (*it)->visibleGet( &rowVisible );

            STRUCT_CLI_GUI_CSPACING rowSpacing = makeSpacing(0,0,0,0);
            if (rowVisible)
               (*it)->spacingGet( &rowSpacing );

            STRUCT_CLI_DRAWING_CPOINT rowSize = makePoint( 0, 0 );
            if (rowVisible)
               (*it)->sizeGet( &rowSize );

            // nc size and pos
            STRUCT_CLI_DRAWING_CPOINT leftTop     = makePoint( 0, rowTop );
            STRUCT_CLI_DRAWING_CPOINT ncWidthHeight = rowSize;
            ncWidthHeight.x += rowSpacing.left + rowSpacing.right;
            ncWidthHeight.y += rowSpacing.top  + rowSpacing.bottom;

            summHeight += ncWidthHeight.y;

            if (maxWidth < ncWidthHeight.x) maxWidth = ncWidthHeight.x;

            CPosSize ncPosSize(leftTop, ncWidthHeight);

            leftTop.x += rowSpacing.left;
            leftTop.y += rowSpacing.top;

            //CPosSize clientPosSize(leftTop, cellSize);
            sizes.push_back( CCellPosSize(ncPosSize, CPosSize(leftTop, rowSize) ) );

            rowTop += ncWidthHeight.y;
           }

        ::std::vector< CCellPosSize >::iterator rowIt = sizes.begin();
        for(; rowIt!=sizes.end(); ++rowIt)
           {
            INT xShift = 0;
            if (hAlignment==CLI_GUI_EALIGNMENT_HCENTER)
               {
                xShift = (newGridSize.x - rowIt->ncPosSize.widthHeight.x) / 2;
               }
            else if (hAlignment==CLI_GUI_EALIGNMENT_RIGHT)
               {
                xShift = (newGridSize.x - rowIt->ncPosSize.widthHeight.x);
               }
            if (xShift<0) xShift = 0;
            if (!xShift) continue;
            rowIt->ncPosSize.leftTop.x     += xShift;
            rowIt->clientPosSize.leftTop.x += xShift;
           }

        INT yShift = 0;
        if (vAlignment==CLI_GUI_EALIGNMENT_VCENTER)
           {
            yShift = (newGridSize.y - summHeight) / 2;
           }
        else if (vAlignment==CLI_GUI_EALIGNMENT_BOTTOM)
           {
            yShift = (newGridSize.y - summHeight);
           }
        else if (vAlignment==CLI_GUI_EALIGNMENT_BASELINE)
           {
            yShift = (newGridSize.y - summHeight)*3/4;
           }
        if (yShift<0) yShift = 0;

        if (yShift)
           {
            ::std::vector< CCellPosSize >::iterator rowIt = sizes.begin();
            for(; rowIt!=sizes.end(); ++rowIt)
               {
                rowIt->ncPosSize.leftTop.y     += yShift;
                rowIt->clientPosSize.leftTop.y += yShift;
               }
           }
       }

    bool buildRowSizesCache(SIZE_T *firstDiffRowIdx)
       {
        ENUM_CLI_GUI_EALIGNMENT thisAlignment = 0;
        rowsAlignmentGet( &thisAlignment );

        ::std::vector< CCellPosSize > newSizes;

        buildRowSizesCacheAux(newSizes, thisAlignment, gridSize);

        cachedRowSizes.swap(newSizes);
        ///////

        //SIZE_T *firstDiffCellIdx

        ::std::vector< CCellPosSize >::const_iterator citNew = cachedRowSizes.begin();
        ::std::vector< CCellPosSize >::const_iterator citOld = newSizes.begin();
        for(; citNew!=cachedRowSizes.end() && citOld!=newSizes.end(); ++citNew, ++citOld)
           {
            if (*citNew!=*citOld)
               {
                if (firstDiffRowIdx) *firstDiffRowIdx = citOld - newSizes.begin();
                return true; // found difference
               }
           }

        if (cachedRowSizes.size()!=newSizes.size())
           {
            if (firstDiffRowIdx)
               {
                if (cachedRowSizes.size()>newSizes.size())
                   *firstDiffRowIdx = newSizes.size();
                else 
                   *firstDiffRowIdx = cachedRowSizes.size();
               }
            return true; // found difference - sizes are different
           }
        return false;
       }

    bool checkBuildRowSizesCache(SIZE_T *firstDiffRowIdx)
       {
        if (cachedRowSizes.size()!=rows.size())
           return  buildRowSizesCache(firstDiffRowIdx);
        return false;
       }

    CLIMETHOD(rowSizesGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _rowSizes /* [out] ::cli::drawing::CPoint _cellsSize  */)
       {
        if (!_rowSizes) return EC_INVALID_PARAM;
        ::std::vector< CCellPosSize >::const_iterator it = cachedRowSizes.begin();
        INT maxWidth = 0;
        INT height     = 0;
        for(; it!=cachedRowSizes.end(); ++it)
           {
            height += it->ncPosSize.widthHeight.y;
            if (maxWidth<it->ncPosSize.widthHeight.x) maxWidth = it->ncPosSize.widthHeight.x;
           }
        _rowSizes->x = maxWidth;
        _rowSizes->y = height;
        return EC_OK;
       }

    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        if (gridSize.x<0 || gridSize.y<0)
           {
            return rowSizesGet(_size);
           }
        *_size = gridSize;
        return EC_OK;
       }

    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    _size /* [in,ref] ::cli::drawing::CPoint  _size  */)
       {
        if (!_size) return EC_INVALID_PARAM;
        STRUCT_CLI_DRAWING_CPOINT prevGridSize = gridSize;
        gridSize = *_size;
        if (gridSize.x!=prevGridSize.x || gridSize.y!=prevGridSize.y)
           {
            buildRowSizesCache( 0 );
            paint();
           }
        return EC_OK;
       }

    CLIMETHOD(fullSizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _fullSize /* [out] ::cli::drawing::CPoint _fullSize  */)
       {
        RCODE res = sizeGet(_fullSize);
        if (res) return res;
        _fullSize->x += spacing.left + spacing.right;
        _fullSize->y += spacing.top  + spacing.bottom;
        return EC_OK;
       }

    CLIMETHOD(gridOwnerSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER*    _gridOwner /* [in] ::cli::gui::cellgrid::iGridOwner*  _gridOwner  */)
       {
        if (!_gridOwner) return EC_INVALID_PARAM;
        owner = _gridOwner;
        // UNDONE: need update or not, that is the question
        return EC_OK;
       }

    CLIMETHOD(getIUnknownIndex) (THIS_ INTERFACE_CLI_IUNKNOWN*    pRow /* [in] ::cli::iUnknown*  pcell  */
                                     , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                )
       {
        if (!pRow || !idxFound) return EC_INVALID_PARAM;
        SIZE_T curIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rows.begin();
        for(; it!=rows.end(); ++it, ++curIdx)
           {
            if (::cli::isObjectEqualTo( *it, pRow ))
               {
                *idxFound = curIdx;
                return EC_OK;
               }
           }
        return EC_NOT_FOUND;
       }

    CLIMETHOD(getRowIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                                , SIZE_T*    idxFound /* [out] size_t idxFound  */
                           )
       {
        if (!pRow || !idxFound) return EC_INVALID_PARAM;

        ::cli::iUnknown *punk = 0;

        RCODE res = pRow->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), (VOID**)&punk);
        if (res) return res; // queryInterface failed

        res = getIUnknownIndex( punk, idxFound );
        punk->release();

        return res;
       }

    CLIMETHOD(lockUpdateGet) (THIS_ BOOL*    _lockUpdate /* [out] bool _lockUpdate  */)
       {
        if (!_lockUpdate) return EC_INVALID_PARAM;
        *_lockUpdate = lockUpdate;
        return EC_OK;
       }

    CLIMETHOD(lockUpdateSet) (THIS_ BOOL    _lockUpdate /* [in] bool  _lockUpdate  */)
       {
        if (!_lockUpdate) return EC_INVALID_PARAM;
        BOOL prevLockUpdate = lockUpdate;
        lockUpdate = _lockUpdate;
        if (prevLockUpdate!=lockUpdate && !lockUpdate)
           {
            buildRowSizesCache( 0 );
            paint();
           }
        return EC_OK;
       }

    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _spacing /* [out] ::cli::gui::CSpacing _spacing  */)
       {
        if (!_spacing) return EC_INVALID_PARAM;
        *_spacing = spacing;
        return EC_OK;
       }

    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _spacing /* [in,ref] ::cli::gui::CSpacing  _spacing  */)
       {
        if (!_spacing) return EC_INVALID_PARAM;
        STRUCT_CLI_GUI_CSPACING prevSpacing = spacing;
        spacing = *_spacing;
        if (!isSpacingEqual(prevSpacing, spacing))
           {
            buildRowSizesCache( 0 );
            paint();
           }
        return EC_OK;
       }

    CLIMETHOD(rowSpacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _rowSpacing /* [out] ::cli::gui::CSpacing _rowSpacing  */)
       {
        if (!_rowSpacing) return EC_INVALID_PARAM;
        *_rowSpacing = rowSpacing;
        return EC_OK;
       }

    CLIMETHOD(rowSpacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _rowSpacing /* [in,ref] ::cli::gui::CSpacing  _rowSpacing  */)
       {
        if (!_rowSpacing) return EC_INVALID_PARAM;
        STRUCT_CLI_GUI_CSPACING prevSpacing = rowSpacing;
        rowSpacing = *_rowSpacing;
        if (!isSpacingEqual(prevSpacing, rowSpacing))
           {
            buildRowSizesCache( 0 );
            paint();
           }
        return EC_OK;
       }

    CLIMETHOD(cellSpacingGet) (THIS_ STRUCT_CLI_GUI_CSPACING*    _cellSpacing /* [out] ::cli::gui::CSpacing _cellSpacing  */)
       {
        if (!_cellSpacing) return EC_INVALID_PARAM;
        *_cellSpacing = cellSpacing;
        return EC_OK;
       }

    CLIMETHOD(cellSpacingSet) (THIS_ const STRUCT_CLI_GUI_CSPACING*    _cellSpacing /* [in,ref] ::cli::gui::CSpacing  _cellSpacing  */)
       {
        if (!_cellSpacing) return EC_INVALID_PARAM;
        STRUCT_CLI_GUI_CSPACING prevSpacing = cellSpacing;
        cellSpacing = *_cellSpacing;
        if (!isSpacingEqual(prevSpacing, cellSpacing))
           {
            buildRowSizesCache( 0 );
            paint();
           }
        return EC_OK;
       }

    RCODE colorGetImpl(COLORREF *pColor, const COLORREF &color)
       {
        if (!pColor) return EC_INVALID_PARAM;
        *pColor = color;
        return EC_OK;
       }

    RCODE colorSetImpl(COLORREF _color, COLORREF &color)
       {
        COLORREF prevColor = color;
        color = _color;
        if (prevColor!=color)
           {
            paint();
           }
        return EC_OK;
       }

    CLIMETHOD(gridNcBackgroundColorGet) (THIS_ COLORREF*    _gridNcBackgroundColor /* [out] colorref _gridNcBackgroundColor  */)
       { return colorGetImpl( _gridNcBackgroundColor, gridNcBackgroundColor); }

    CLIMETHOD(gridNcBackgroundColorSet) (THIS_ COLORREF    _gridNcBackgroundColor /* [in] colorref  _gridNcBackgroundColor  */)
       { return colorSetImpl( _gridNcBackgroundColor, gridNcBackgroundColor); }

    CLIMETHOD(gridBackgroundColorGet) (THIS_ COLORREF*    _gridBackgroundColor /* [out] colorref _gridBackgroundColor  */)
       { return colorGetImpl( _gridBackgroundColor, gridBackgroundColor); }

    CLIMETHOD(gridBackgroundColorSet) (THIS_ COLORREF    _gridBackgroundColor /* [in] colorref  _gridBackgroundColor  */)
       { return colorSetImpl( _gridBackgroundColor, gridBackgroundColor); }

    CLIMETHOD(rowNcBackgroundColorGet) (THIS_ COLORREF*    _rowNcBackgroundColor /* [out] colorref _rowNcBackgroundColor  */)
       { return colorGetImpl( _rowNcBackgroundColor, rowNcBackgroundColor); }

    CLIMETHOD(rowNcBackgroundColorSet) (THIS_ COLORREF    _rowNcBackgroundColor /* [in] colorref  _rowNcBackgroundColor  */)
       { return colorSetImpl( _rowNcBackgroundColor, rowNcBackgroundColor); }

    CLIMETHOD(activeRowNcBackgroundColorGet) (THIS_ COLORREF*    _activeRowNcBackgroundColor /* [out] colorref _activeRowNcBackgroundColor  */)
       { return colorGetImpl( _activeRowNcBackgroundColor, activeRowNcBackgroundColor); }

    CLIMETHOD(activeRowNcBackgroundColorSet) (THIS_ COLORREF    _activeRowNcBackgroundColor /* [in] colorref  _activeRowNcBackgroundColor  */)
       { return colorSetImpl( _activeRowNcBackgroundColor, activeRowNcBackgroundColor); }

    CLIMETHOD(rowBackgroundColorGet) (THIS_ COLORREF*    _rowBackgroundColor /* [out] colorref _rowBackgroundColor  */)
       { return colorGetImpl( _rowBackgroundColor, rowBackgroundColor); }

    CLIMETHOD(rowBackgroundColorSet) (THIS_ COLORREF    _rowBackgroundColor /* [in] colorref  _rowBackgroundColor  */)
       { return colorSetImpl( _rowBackgroundColor, rowBackgroundColor); }

    CLIMETHOD(activeRowBackgroundColorGet) (THIS_ COLORREF*    _activeRowBackgroundColor /* [out] colorref _activeRowBackgroundColor  */)
       { return colorGetImpl( _activeRowBackgroundColor, activeRowBackgroundColor); }

    CLIMETHOD(activeRowBackgroundColorSet) (THIS_ COLORREF    _activeRowBackgroundColor /* [in] colorref  _activeRowBackgroundColor  */)
       { return colorSetImpl( _activeRowBackgroundColor, activeRowBackgroundColor); }

    CLIMETHOD(cellNcBackgroundColorGet) (THIS_ COLORREF*    _cellNcBackgroundColor /* [out] colorref _cellNcBackgroundColor  */)
       { return colorGetImpl( _cellNcBackgroundColor, cellNcBackgroundColor); }

    CLIMETHOD(cellNcBackgroundColorSet) (THIS_ COLORREF    _cellNcBackgroundColor /* [in] colorref  _cellNcBackgroundColor  */)
       { return colorSetImpl( _cellNcBackgroundColor, cellNcBackgroundColor); }

    CLIMETHOD(activeCellNcBackgroundColorGet) (THIS_ COLORREF*    _activeCellNcBackgroundColor /* [out] colorref _activeCellNcBackgroundColor  */)
       { return colorGetImpl( _activeCellNcBackgroundColor, activeCellNcBackgroundColor); }

    CLIMETHOD(activeCellNcBackgroundColorSet) (THIS_ COLORREF    _activeCellNcBackgroundColor /* [in] colorref  _activeCellNcBackgroundColor  */)
       { return colorSetImpl( _activeCellNcBackgroundColor, activeCellNcBackgroundColor); }

    CLIMETHOD(cellBackgroundColorGet) (THIS_ COLORREF*    _cellBackgroundColor /* [out] colorref _cellBackgroundColor  */)
       { return colorGetImpl( _cellBackgroundColor, cellBackgroundColor); }

    CLIMETHOD(cellBackgroundColorSet) (THIS_ COLORREF    _cellBackgroundColor /* [in] colorref  _cellBackgroundColor  */)
       { return colorSetImpl( _cellBackgroundColor, cellBackgroundColor); }

    CLIMETHOD(activeCellBackgroundColorGet) (THIS_ COLORREF*    _activeCellBackgroundColor /* [out] colorref _activeCellBackgroundColor  */)
       { return colorGetImpl( _activeCellBackgroundColor, activeCellBackgroundColor); }

    CLIMETHOD(activeCellBackgroundColorSet) (THIS_ COLORREF    _activeCellBackgroundColor /* [in] colorref  _activeCellBackgroundColor  */)
       { return colorSetImpl( _activeCellBackgroundColor, activeCellBackgroundColor); }

    CLIMETHOD(cellsAlignmentGet) (THIS_ ENUM_CLI_GUI_EALIGNMENT*    _cellsAlignment /* [out] ::cli::gui::EAlignment _alignment  */)
       {
        if (!_cellsAlignment) return EC_INVALID_PARAM;
        *_cellsAlignment = cellsAlignment;
        return EC_OK;
       }

    CLIMETHOD(cellsAlignmentSet) (THIS_ ENUM_CLI_GUI_EALIGNMENT    _cellsAlignment /* [in] ::cli::gui::EAlignment  _alignment  */)
       {
        ENUM_CLI_GUI_EALIGNMENT prevAlignment = cellsAlignment;
        cellsAlignment = _cellsAlignment;
        if (prevAlignment!=cellsAlignment)
           {
            buildRowSizesCache( 0 );
            paint();
           }
        return EC_OK;
       }

    CLIMETHOD(rowsAlignmentGet) (THIS_ ENUM_CLI_GUI_EALIGNMENT*    _rowsAlignment /* [out] ::cli::gui::EAlignment _rowsAlignment  */)
       {
        if (!_rowsAlignment) return EC_INVALID_PARAM;
        *_rowsAlignment = rowsAlignment;
        return EC_OK;
       }

    CLIMETHOD(rowsAlignmentSet) (THIS_ ENUM_CLI_GUI_EALIGNMENT    _rowsAlignment /* [in] ::cli::gui::EAlignment  _rowsAlignment  */)
       {
        ENUM_CLI_GUI_EALIGNMENT prevAlignment = rowsAlignment;
        rowsAlignment = _rowsAlignment;
        if (prevAlignment!=rowsAlignment)
           {
            buildRowSizesCache( 0 );
            paint();
           }
        return EC_OK;
       }

    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */)
       {
        CLI_TRY{
                SIZE_T rowIdx = 0;
                std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rows.begin();
                for(; it!=rows.end(); ++it, ++rowIdx) 
                   {
                    (*it)->calculateLimits(pdc, rowIdx);
                   }
        
                buildRowSizesCache( 0 /* firstDiffRowIdx */ );
                //paint();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(insertRow) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                              , SIZE_T    atPos /* [in] size_t  idx  */
                         )
       {
        CLI_TRY{
                if (!pRow) return EC_INVALID_PARAM;
                if (atPos >= rows.size() )
                   {
                    atPos = rows.size(); // correct insert pos value
                    rows.push_back(pRow);
                   }
                else
                   rows.insert( rows.begin()+atPos, pRow );
        
                INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc = 0;
                getDrawContext(&pdc);
                if (pdc) 
                   {
                    pRow->calculateLimits( pdc, atPos );
                    pdc->release();
                   }
                pRow->addRef();
                pRow->ownerGridSet(this);
                buildRowSizesCache(0);
                partialPaint( atPos, 0, SIZE_T_NPOS, SIZE_T_NPOS);

                // UNDONE: repaint grid
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(addRow) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */)
       {
        return insertRow(pRow, SIZE_T_NPOS);
       }

    CLIMETHOD(removeRow) (THIS_ SIZE_T    atPos /* [in] size_t  atPos  */)
       {
        if (atPos>=rows.size()) return EC_OUT_OF_RANGE;
        CLI_TRY{
                INTERFACE_CLI_GUI_CELLGRID_IROW *pRow = rows[atPos];
                pRow->ownerGridSet(0);
                rows.erase( rows.begin() + atPos );
                pRow->release();
                buildRowSizesCache(0);
                partialPaint( atPos, 0, SIZE_T_NPOS, SIZE_T_NPOS);
                // UNDONE: repaint grid
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(rowsClear) (THIS)
       {
        SIZE_T rowIdx = 0;
        CLI_TRY{
                ::std::vector< INTERFACE_CLI_GUI_CELLGRID_IROW* >::iterator rit = rows.begin();
                for(; rit!=rows.end(); ++rit, ++rowIdx)
                   {
                    INTERFACE_CLI_GUI_CELLGRID_IROW *pRow = *rit;
                    pRow->ownerGridSet(0);
                    pRow->release();
                   }
                rows.clear();
                buildRowSizesCache(0);
                paint();
                // UNDONE: repaint grid
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(insertCellToRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                    , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                                    , SIZE_T    atPos /* [in] size_t  atPos  */
                               )
       {
        if (rowIdx>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[rowIdx]->insertCell(pCell, atPos);
       }

    CLIMETHOD(addCellToRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                 , INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL*    pCell /* [in] ::cli::gui::cellgrid::iSimpleCell*  pCell  */
                            )
       {
        return insertCellToRow(rowIdx, pCell, SIZE_T_NPOS);
       }

    CLIMETHOD(removeCellFromRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                      , SIZE_T    atPos /* [in] size_t  atPos  */
                                 )
       {
        if (rowIdx>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[rowIdx]->removeCell(atPos);
       }

    CLIMETHOD(rowCellsClear) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */)
       {
        if (rowIdx>=rows.size()) return EC_OUT_OF_RANGE;
        return rows[rowIdx]->cellsClear();
       }

    CLIMETHOD(getDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
       {
        if (!pdc) return EC_INVALID_PARAM;
        if (!owner)
           {
            *pdc = 0;
            return EC_NO_OBJECT;
           }
        //return owner.getDrawContext( 0 /* gridId */ , pdc );
        return owner.getDrawContext( pdc );
       }

/*
    // in grid coordinates
    CLIMETHOD(getRowNcPosSize) ( const STRUCT_CLI_DRAWING_CPOINT*    rowPosLeftTop
                               , const STRUCT_CLI_DRAWING_CPOINT*    rowNcSize
                               )
       {
       
       }
*/

    CLIMETHOD(getDrawContextForRectUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    gridPosLeftTop /* [in,ref] ::cli::drawing::CPoint  gridPosLeftTop  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    rectSize /* [in,ref] ::cli::drawing::CPoint  rectSize  */
                                           )
       {
        if (!pdc) return EC_INVALID_PARAM;
        if (!owner)
           {
            *pdc = 0;
            return EC_NO_OBJECT;
           }
        return owner.getDrawContextForRectUpdate( pdc, *gridPosLeftTop, *rectSize );
       }

    CLIMETHOD(getDrawContextForUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                           )
       {
        if (!pdc) return EC_INVALID_PARAM;
        if (!owner)
           {
            *pdc = 0;
            return EC_NO_OBJECT;
           }
        return owner.getIfPtr()->getDrawContextForRectUpdate( pdc, 0, 0);
       }


    CLIMETHOD(activeRowGet) (THIS_ SIZE_T*    _activeRow /* [out] size_t _activeRow  */)
       {
        if (!_activeRow) return EC_INVALID_PARAM;
        *_activeRow = activeRow;
        return EC_OK;
       }

    CLIMETHOD(activeCellGet) (THIS_ SIZE_T*    _activeCell /* [out] size_t _activeCell  */)
       {
        if (!_activeCell) return EC_INVALID_PARAM;
        *_activeCell = activeCell;
        return EC_OK;
       }

    CLIMETHOD(rowNotifyIdx) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                 , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                 , ENUM_CLI_GUI_CELLGRID_ENOTIFYEVENT    eventType /* [in] ::cli::gui::cellgrid::ENotifyEvent  eventType  */
                                 , UINT    param /* [in] uint  param  */
                            )
       {
        switch(eventType)
           {
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVATE:  
                 {
                  if (ignoreActiveCellChangedNotify)
                     return EC_OK;

                  if (!param) // active state cleared for cell
                     {
                      activeRow  = SIZE_T_NPOS;
                      activeCell = SIZE_T_NPOS;
                      if (!lockUpdate) // paint locked
                         {
                          return paintRow(rowIdx);
                         }
                      return EC_OK;
                     }
                  // activeCell is set for cell

                  SIZE_T prevActiveRow  = activeRow;
                  SIZE_T prevActiveCell = activeCell;
                  bool rowChanged  = prevActiveRow!=rowIdx;
                  bool cellChanged = (prevActiveCell!=cellIdx) || rowChanged;
                  if (!rowChanged && !cellChanged) 
                     {
                      return EC_OK; // no changes
                     }

                  // reset prev active if set
                  ignoreActiveCellChangedNotify = true;
                  resetActiveCell(); 
                  ignoreActiveCellChangedNotify = false;

                  activeRow  = rowIdx;
                  activeCell = cellIdx;

                  if (lockUpdate) return EC_OK;
                  if (rowChanged) 
                     { 
                      if (prevActiveRow!=SIZE_T_NPOS) invalidateRow(prevActiveRow, CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT);
                      if (activeRow!=SIZE_T_NPOS)     invalidateRow(activeRow, CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT);
                     }
                  else
                     {
                      if (prevActiveRow!=SIZE_T_NPOS && prevActiveCell!=SIZE_T_NPOS) invalidateCell(prevActiveRow, prevActiveCell, CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT);
                      if (activeRow!=SIZE_T_NPOS     && activeCell!=SIZE_T_NPOS)     invalidateCell(activeRow    , activeCell    , CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT);
                     }
                  return updatePaint();

                  /*
                  INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc = 0;
                  RCODE res = getDrawContext( &pdc );
                  if (res) return res;
                  if (!pdc) return EC_INVALID_OBJECT_PTR;
                  
                  if (rowChanged)
                     {
                      paintRowOnContext( pdc, prevActiveRow );
                      paintRowOnContext( pdc, activeRow );
                     }
                  else
                     {
                      paintCellOnContext( pdc, prevActiveRow, prevActiveCell );
                      paintCellOnContext( pdc, activeRow, activeCell );
                     }
                  pdc->release();
                  return res;
                  */
                  
                 }
                 //return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid

            case CLI_GUI_CELLGRID_ENOTIFYEVENT_VISIBLECHANGED:  
                 buildRowSizesCache(0);
                 // UNDONE: small optimization needed
                 // if non-first row size changed, not need to repaint all grid
                 paint();
                 //partialPaint( atPos, 0, SIZE_T_NPOS, SIZE_T_NPOS);
                 break;

            case CLI_GUI_CELLGRID_ENOTIFYEVENT_SPACINGCHANGED:  
                 buildRowSizesCache(0);
                 paint();
                 //buildCellSizesCache(rowIdx, 0);
                 //return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid
                 break;

            case CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGDRAWCHANGED:  
                 paint();
                 //return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid
                 break;

            case CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTBGCOLORCHANGED:                      
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_NONCLIENTACTIVEBGCOLORCHANGED:                      
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_BGDRAWCHANGED:                      
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_BGCOLORCHANGED:                      
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_ACTIVEBGCOLORCHANGED:  
                 paint();
                 //return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid
                    
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_SIZECHANGED: 
            case CLI_GUI_CELLGRID_ENOTIFYEVENT_NEEDUPDATE:  
                 buildRowSizesCache(0);
                 paint();
                 //buildCellSizesCache(rowIdx, 0);
                 //return rowNotifyIdx( eventType, param, rowIdx, cellIdx ); // simple pass event to grid
                 break;
           }
        return EC_OK;       
       }

    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */)
       {
        // UNDONE: update row config
        return EC_OK;
       }

    CLIMETHOD(getRowPosSize) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                  , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                  , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                  , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                  , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                             )
       {
        if (rowIdx>=rows.size()) return EC_OUT_OF_RANGE;
        checkBuildRowSizesCache(0);

        if (rowIdx>=cachedRowSizes.size()) return EC_OUT_OF_RANGE;

        ::std::vector< CCellPosSize >::const_iterator it = cachedRowSizes.begin() + rowIdx;
        if (ncLeftTop        ) *ncLeftTop         = it->ncPosSize.leftTop;
        if (ncWidthHeight    ) *ncWidthHeight     = it->ncPosSize.widthHeight;
        if (clientLeftTop    ) *clientLeftTop     = it->clientPosSize.leftTop;
        if (clientWidthHeight) *clientWidthHeight = it->clientPosSize.widthHeight;

        return EC_OK;
       }

    CLIMETHOD(paint) (THIS)
       {
        if (lockUpdate) return EC_OK;
        INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc = 0;
        RCODE res = getDrawContext( &pdc );
        if (res) return res;
        if (!pdc) return EC_INVALID_OBJECT_PTR;
        //RCODE 
        res = paintOnContext(pdc);
        pdc->release();

        updatePaintComplete(); // clears invalidation

        return res;
       }

    CLIMETHOD(paintOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */)
       {
        if (lockUpdate) return EC_OK;
        //return 
        RCODE res = partialPaintOnContext( pdc, 0, 0, SIZE_T_NPOS, SIZE_T_NPOS);
        updatePaintComplete(); // clears invalidation
        return res;
       }

    CLIMETHOD(paintCellOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                  )
       {
        return partialPaintOnContext(pdc, rowIdx, cellIdx, rowIdx, cellIdx);
       }

    CLIMETHOD(paintRowOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                      , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                 )
       {
        return partialPaintOnContext(pdc, rowIdx, 0, rowIdx, SIZE_T_NPOS);
       }

    CLIMETHOD(paintCell) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                              , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                         )
       {
        if (rowIdx>=rows.size())  return EC_OUT_OF_RANGE;

        if (lockUpdate) return EC_OK;

        checkBuildRowSizesCache(0);

        CLI_GUI_SIZE  cellNcLeftTop, cellNcWidthHeight /* , cellClientLeftTop , cellClientWidthHeight */ ;
        RCODE res = rows[rowIdx]->getCellPosSize(rowIdx, cellIdx, &cellNcLeftTop, &cellNcWidthHeight, 0 /* &cellClientLeftTop */ , 0 /* &cellClientWidthHeight */  );
        if (res) return res;

        CLI_GUI_SIZE cellNcPos = makePoint(spacing.left, spacing.top) + cachedRowSizes[rowIdx].clientPosSize.leftTop + cellNcLeftTop;
        INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc = 0;
        res = getDrawContextForRectUpdate( &pdc, &cellNcPos, &cellNcWidthHeight);
        if (res) return res;
        if (!pdc) return EC_NO_OBJECT;

        res = paintCellOnContext(pdc, rowIdx, cellIdx);
        pdc->release();
        return res;
       }

    CLIMETHOD(paintRow) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */)
       {
        if (lockUpdate) return EC_OK;

        checkBuildRowSizesCache(0);
        CLI_GUI_SIZE rowNcPos = makePoint(spacing.left, spacing.top) + cachedRowSizes[rowIdx].ncPosSize.leftTop;
        INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc = 0;
        RCODE res = getDrawContextForRectUpdate( &pdc, &rowNcPos, &cachedRowSizes[rowIdx].ncPosSize.widthHeight);
        if (res) return res;
        if (!pdc) return EC_INVALID_OBJECT_PTR;

        res = paintRowOnContext(pdc, rowIdx);
        pdc->release();
        return res;
       }

    CLIMETHOD(partialPaint) (THIS_ SIZE_T    firstRowIdx /* [in] size_t  firstRowIdx  */
                                 , SIZE_T    firstRowCellIdx /* [in] size_t  firstRowCellIdx  */
                                 , SIZE_T    lastRowIdx /* [in] size_t  lastRowIdx  */
                                 , SIZE_T    lastRowCellIdx /* [in] size_t  lastRowCellIdx  */
                            )
       {
        if (lockUpdate) return EC_OK;
        INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc = 0;
        RCODE res = getDrawContext( &pdc );
        if (res) return res;
        if (!pdc) return EC_INVALID_OBJECT_PTR;
        res = partialPaintOnContext( pdc, firstRowIdx, firstRowCellIdx, lastRowIdx, lastRowCellIdx );
        pdc->release();
        return res;
       }

    CLIMETHOD(partialPaintOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                          , SIZE_T    firstRowIdx /* [in] size_t  firstRowIdx  */
                                          , SIZE_T    firstRowCellIdx /* [in] size_t  firstRowCellIdx  */
                                          , SIZE_T    lastRowIdx /* [in] size_t  lastRowIdx  */
                                          , SIZE_T    lastRowCellIdx /* [in] size_t  lastRowCellIdx  */
                                     )
       {
        return partialPaintOnContextAux(pdc, firstRowIdx, firstRowCellIdx, lastRowIdx, lastRowCellIdx, false);
       }

    CLIMETHOD(partialPaintOnContextAux) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                          , SIZE_T    firstRowIdx /* [in] size_t  firstRowIdx  */
                                          , SIZE_T    firstRowCellIdx /* [in] size_t  firstRowCellIdx  */
                                          , SIZE_T    lastRowIdx /* [in] size_t  lastRowIdx  */
                                          , SIZE_T    lastRowCellIdx /* [in] size_t  lastRowCellIdx  */
                                          , bool callCellUpdatePaint
                                     )


       {
        if (lockUpdate) return EC_OK;
        if (!pdc) return EC_INVALID_PARAM;
        checkBuildRowSizesCache(0);

        using ::cli::drawing::dc::CAutoPen      ;
        using ::cli::drawing::dc::CAutoBrush    ;
        using ::cli::drawing::dc::CAutoFont     ;
        using ::cli::drawing::dc::CAutoClipRect ;
        using ::cli::drawing::dc::CAutoViewport ;

        //CLITRACE5(L"pPOnContextAux, fRowIdx: %1, fRowCellIdx: %2, lRowIdx: %3, lRowCellIdx: %4, bUpdatePaint: %5", (UINT)firstRowIdx, (UINT)firstRowCellIdx, (UINT)lastRowIdx, (UINT)lastRowCellIdx, (UINT)callCellUpdatePaint);

        if (firstRowIdx>rows.size()) firstRowIdx = rows.size();
        if (lastRowIdx>=rows.size())  lastRowIdx  = rows.size()-1;
        //else lastRowIdx;

        bool fullPaint = true;
        if (firstRowIdx>0 || firstRowCellIdx>0) fullPaint = false;

        SIZE_T lastRowCellNumber = 0;
        if (lastRowIdx<rows.size())
           {
            rows[lastRowIdx]->multiCellsSize(&lastRowCellNumber);
           }
        if (lastRowCellIdx>=lastRowCellNumber) lastRowCellIdx = lastRowCellNumber-1;

        if (lastRowIdx!=rows.size()-1 || lastRowCellIdx!=lastRowCellNumber-1)
           fullPaint = false;

        COLORREF lastRectColor = 0;

        CLI_GUI_POINT zeroPnt      = zeroPoint();
        CLI_GUI_SIZE  gridFullSize = zeroPnt;

        // draw background here
        if (!fullSizeGet(&gridFullSize))
           { // fills grid background
            if (fullPaint)
               {
                CAutoBrush ab(pdc, gridNcBackgroundColor);
                pdc->fillRectWH( &zeroPnt, &gridFullSize );
                lastRectColor = gridNcBackgroundColor;
               }
           }

        CLI_GUI_POINT gridClientLeftTop = makePoint(spacing.left, spacing.top);
        gridFullSize = zeroPnt;
        if (!sizeGet(&gridFullSize))
           {
            if (gridBackgroundColor!=lastRectColor && fullPaint)
               { // fills grid background
                CAutoBrush ab(pdc, gridBackgroundColor);
                pdc->fillRectWH( &gridClientLeftTop, &gridFullSize );
                lastRectColor = gridBackgroundColor;
               }
           }

        ::std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::const_iterator rit = rows.begin() + firstRowIdx;
        ::std::vector< CCellPosSize >::iterator                         sit = cachedRowSizes.begin() + firstRowIdx;
        ::std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::const_iterator ritEnd = rows.begin() + lastRowIdx + 1;
        ::std::vector< CCellPosSize >::iterator                         sitEnd = cachedRowSizes.begin() + lastRowIdx + 1;

        for(; rit!=ritEnd && sit!=sitEnd; ++rit, ++sit)
           {
            SIZE_T rowIdx = rit - rows.begin();

            BOOL rowVisible = TRUE;
            (*rit)->visibleGet( &rowVisible );
            if (!rowVisible) continue;

            SIZE_T rowCellNumber = 0;
            (*rit)->multiCellsSize(&rowCellNumber);

            bool drawRowBackgrounds = true;

            // drawing starts on non-first cell, prevent erasing background
            if ((rowIdx==firstRowIdx && firstRowCellIdx!=0) || (rowIdx==lastRowIdx && lastRowCellIdx!=rowCellNumber-1))
               drawRowBackgrounds = false;

            CLI_GUI_POINT rowNcLeftTop = sit->ncPosSize.leftTop + gridClientLeftTop;
            CLI_GUI_POINT rowLeftTop = sit->clientPosSize.leftTop + gridClientLeftTop;

            //CLITRACE4(L"Row pos     , nc: %1x%2, client: %3x%4", rowNcLeftTop.x, rowNcLeftTop.y, rowLeftTop.x, rowLeftTop.y);

            if (drawRowBackgrounds)
               {
                // drawing row background
                BOOL drawRowNcBackground = TRUE;
                (*rit)->ncDrawBackgroundGet(&drawRowNcBackground);
                bool emptyNcArea = true;
                if (sit->ncPosSize!=sit->clientPosSize)
                   emptyNcArea = false;

                if (drawRowNcBackground && !emptyNcArea)
                   {
                    COLORREF color = 0;
                    if (rowIdx==activeRow)
                       (*rit)->ncActiveBackgroundColorGet(&color);
                    else
                       (*rit)->ncBackgroundColorGet(&color);
                    if (lastRectColor!=color) //different color used
                       {
                        CAutoBrush ab(pdc, color);
                        pdc->fillRectWH( &rowNcLeftTop, &sit->ncPosSize.widthHeight );
                        lastRectColor = color;
                       }
                   }
    
                // drawint rect nc area
                   {
                    CAutoViewport rectNcAvp(pdc, rowNcLeftTop, sit->ncPosSize.widthHeight);
                    (*rit)->ncPaint( pdc, &sit->ncPosSize.widthHeight, rowIdx);
                   }
    
                BOOL drawRowBackground = TRUE;
                (*rit)->drawBackgroundGet(&drawRowBackground);
                if (drawRowBackground)
                   {
                    COLORREF color = 0;
                    if (rowIdx==activeRow)
                       (*rit)->activeBackgroundColorGet(&color);
                    else
                       (*rit)->backgroundColorGet(&color);
                    if (lastRectColor!=color) //different color used
                       {
                        CAutoBrush ab(pdc, color);
                        pdc->fillRectWH( &rowLeftTop, &sit->clientPosSize.widthHeight );
                        lastRectColor = color;
                       }
                   }
    
                // drawint rect client area
                   {
                    CAutoViewport rectClientAvp(pdc, rowLeftTop, sit->clientPosSize.widthHeight);
                    (*rit)->paintClient( pdc, &sit->clientPosSize.widthHeight, rowIdx);
                   }
               }

            SIZE_T cellIdx = 0;
            if (rowIdx==firstRowIdx)   cellIdx = firstRowCellIdx;
            if (cellIdx>rowCellNumber) cellIdx = rowCellNumber;

            SIZE_T endCellIdx = rowCellNumber;
            if (rowIdx==lastRowIdx)
               endCellIdx = lastRowCellIdx;
            if (endCellIdx>rowCellNumber) endCellIdx = rowCellNumber-1;

            for(; cellIdx!=endCellIdx+1; ++cellIdx)
               {
                INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;
                if ((*rit)->multiCellsGet( &pCell, cellIdx) || !pCell) continue;

                BOOL cellVisible = TRUE;
                pCell->visibleGet( &cellVisible, rowIdx, cellIdx );
                if (!cellVisible) continue;

                CLI_GUI_SIZE cellNcLeftTop, cellNcWidthHeight, cellClientLeftTop, cellClientWidthHeight;
                if ((*rit)->getCellPosSize(rowIdx, cellIdx, &cellNcLeftTop, &cellNcWidthHeight, &cellClientLeftTop, &cellClientWidthHeight))
                   continue;

                /*
                if (!cellIdx)
                   {
                    CLITRACE4(L"Row pos  (2), nc: %1x%2, client: %3x%4", rowNcLeftTop.x, rowNcLeftTop.y, rowLeftTop.x, rowLeftTop.y);
                    CLITRACE4(L"Cell pos    , nc: %1x%2, client: %3x%4", cellNcLeftTop.x, cellNcLeftTop.y, cellClientLeftTop.x, cellClientLeftTop.y);
                   }
                */
                cellNcLeftTop     += rowLeftTop;
                cellClientLeftTop += rowLeftTop;

                //if (!cellIdx)
                //   CLITRACE4(L"Cell pos (2), nc: %1x%2, client: %3x%4", cellNcLeftTop.x, cellNcLeftTop.y, cellClientLeftTop.x, cellClientLeftTop.y);

                COLORREF cellLastRectColor = lastRectColor;

                bool cellEmptyNc = false;
                if (CPosSize(cellNcLeftTop, cellNcWidthHeight)==CPosSize(cellClientLeftTop, cellClientWidthHeight))
                   cellEmptyNc = true;

                BOOL cellDrawNcBg = TRUE;
                pCell->ncDrawBackgroundGet( &cellDrawNcBg, rowIdx, cellIdx);
                if (cellDrawNcBg && !cellEmptyNc)
                   {
                    if (!callCellUpdatePaint)
                       {
                        COLORREF color = 0;
                        pCell->ncCurrentBackgroundColorGet(&color, rowIdx, cellIdx);
                        /*
                        if (rowIdx==activeRow && cellIdx==activeCell)
                           pCell->ncActiveBackgroundColorGet(&color, rowIdx, cellIdx);
                        else
                           pCell->ncBackgroundColorGet(&color, rowIdx, cellIdx);
                        */
                        if (cellLastRectColor!=color) //different color used
                           {
                            CAutoBrush ab(pdc, color);
                            pdc->fillRectWH( &cellNcLeftTop, &cellNcWidthHeight );
                            cellLastRectColor = color;
                           }
                       }
                   }

                // drawing cell nc area
                if (!callCellUpdatePaint)
                   {
                    CAutoViewport cellNcAvp(pdc, cellNcLeftTop, cellNcWidthHeight);
                    pCell->ncPaint( pdc, &cellNcWidthHeight, rowIdx, cellIdx);
                   }

                BOOL cellDrawBg = TRUE;
                pCell->drawBackgroundGet( &cellDrawBg, rowIdx, cellIdx);
                if (cellDrawBg)
                   {
                    if (!callCellUpdatePaint)
                       {
                        COLORREF color = 0;
                        pCell->currentBackgroundColorGet(&color, rowIdx, cellIdx);
                        /*
                        if (rowIdx==activeRow && cellIdx==activeCell)
                           pCell->activeBackgroundColorGet(&color, rowIdx, cellIdx);
                        else
                           pCell->backgroundColorGet(&color, rowIdx, cellIdx);
                        */
                        if (cellLastRectColor!=color) //different color used
                           {
                            CAutoBrush ab(pdc, color);
                            pdc->fillRectWH( &cellClientLeftTop, &cellClientWidthHeight );
                            cellLastRectColor = color;
                           }                   
                       }
                   }

                // drawing cell client area
                   {
                    //if (!cellIdx)
                    //   CLITRACE4(L"Cell pos (3), nc: %1x%2, client: %3x%4", cellNcLeftTop.x, cellNcLeftTop.y, cellClientLeftTop.x, cellClientLeftTop.y);
                    CAutoViewport cellClientAvp(pdc, cellClientLeftTop, cellClientWidthHeight);
                    if (!callCellUpdatePaint)
                       pCell->paintClient( pdc, &cellClientWidthHeight, rowIdx, cellIdx);
                    else
                       pCell->updatePaint( pdc, &cellClientWidthHeight, rowIdx, cellIdx);
                   }
               }
           }
        return EC_OK;
       }

    CLIMETHOD(activateOnClickGet) (THIS_ BOOL*    _activateOnClick /* [out] bool _activateOnClick  */)
       {
        if (!_activateOnClick) return EC_INVALID_PARAM;
        *_activateOnClick = activateOnClick;
        return EC_OK;
       }

    CLIMETHOD(activateOnClickSet) (THIS_ BOOL    _activateOnClick /* [in] bool  _activateOnClick  */)
       {
        activateOnClick = _activateOnClick;
        return EC_OK;
       }

    CLIMETHOD(setCapture) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                               , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                          )
       {
        if (rowIdx==SIZE_T_NPOS || cellIdx==SIZE_T_NPOS)
           {
            captureRow  = SIZE_T_NPOS;
            captureCell = SIZE_T_NPOS;
            return EC_OK;
           }

        if (rowIdx>=rows.size())
           return EC_OUT_OF_RANGE;

        SIZE_T rowCellNumber = 0;
        RCODE res = rows[rowIdx]->multiCellsSize(&rowCellNumber);
        if (res) return res;

        if (cellIdx>=rowCellNumber)
           return EC_OUT_OF_RANGE;

        captureRow  = rowIdx;
        captureCell = cellIdx;
        return EC_OK;
       }

    CLIMETHOD(clearCapture) (THIS)
       {
        return setCapture( SIZE_T_NPOS, SIZE_T_NPOS );
       }

    CLIMETHOD(hitTest) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    pMicePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                            , SIZE_T*    hitRow /* [out] size_t hitRow  */
                            , SIZE_T*    hitCell /* [out] size_t hitCell  */
                            , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    _resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                            , STRUCT_CLI_DRAWING_CPOINT*    translatedMicePos /* [out] ::cli::drawing::CPoint translatedMicePos  */
                            , INTERFACE_CLI_GUI_CELLGRID_IMULTICELL**    pCellFound /* [out] ::cli::gui::cellgrid::iMultiCell* pCell  */
                       )
       {
        CLI_TRY{
                if (!pMicePos || !hitCell || !hitRow) return EC_INVALID_PARAM;
                checkBuildRowSizesCache(0);
        
                *hitCell = SIZE_T_NPOS;
                *hitRow  = SIZE_T_NPOS;
                ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS resFlags = 0;
                //if (resFlags) *resFlags = 0;

                CLI_GUI_POINT zeroPnt      = zeroPoint();
                CLI_GUI_SIZE  gridFullSize = zeroPnt;
                fullSizeGet(&gridFullSize);

                if (testWhHit( *pMicePos, gridFullSize ))
                   {
                    resFlags = CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING;
                   }
                else
                   {
                    return EC_TEST_FAILED;
                   }

                CLI_GUI_POINT gridClientLeftTop = makePoint(spacing.left, spacing.top);
                sizeGet(&gridFullSize);
                CLI_GUI_POINT micePos = *pMicePos - gridClientLeftTop;
                //micePos.x -= spacing.left;
                //micePos.y -= spacing.top;
                if (testWhHit( micePos, gridFullSize ))
                   {
                    resFlags = CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT;
                   }
                else
                   {
                    if (_resFlags) *_resFlags = resFlags;
                    //if (resFlags&CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING) 
                    if (translatedMicePos) *translatedMicePos = *pMicePos;
                    return EC_OK;
                    //return EC_TEST_FAILED;
                   }

                ::std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::const_iterator rit = rows.begin();
                ::std::vector< CCellPosSize >::iterator                         sit = cachedRowSizes.begin();
                ::std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::const_iterator ritEnd = rows.end();
                ::std::vector< CCellPosSize >::iterator                         sitEnd = cachedRowSizes.end();

                for(; rit!=ritEnd && sit!=sitEnd; ++rit, ++sit)
                   {
                    SIZE_T rowIdx = rit - rows.begin();
                    ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS rowResFlags = resFlags;

                    CLI_GUI_POINT rowMicePos = micePos - sit->ncPosSize.leftTop;
                    if (testWhHit( rowMicePos, sit->ncPosSize.widthHeight ))
                       {
                        rowResFlags = CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWSPACING;
                        *hitRow = rowIdx;
                       }
                    else
                       {
                        continue; // not hit to cur row
                       }

                    CLI_GUI_POINT rowMicePosClient = micePos - sit->clientPosSize.leftTop;

                    //rowMicePos = micePos - sit->clientPosSize.leftTop;
                    if (testWhHit( rowMicePosClient, sit->clientPosSize.widthHeight ))
                       {
                        rowResFlags = CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT;
                       }
                    else
                       { // not hit to row client area
                        if (_resFlags) *_resFlags = rowResFlags;
                        if (translatedMicePos) *translatedMicePos = rowMicePos;
                        return EC_OK;
                       }

                    // lookup though cells
                    SIZE_T cellIdx = 0;
                    SIZE_T rowCellNumber = 0;
                    (*rit)->multiCellsSize(&rowCellNumber);

                    for(; cellIdx!=rowCellNumber; ++cellIdx)
                       {
                        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;
                        if ((*rit)->multiCellsGet( &pCell, cellIdx) || !pCell) continue;
        
                        BOOL cellVisible = TRUE;
                        pCell->visibleGet( &cellVisible, rowIdx, cellIdx );
                        if (!cellVisible) continue;
                        
                        CLI_GUI_SIZE cellNcLeftTop, cellNcWidthHeight, cellClientLeftTop, cellClientWidthHeight;
                        if ((*rit)->getCellPosSize(rowIdx, cellIdx, &cellNcLeftTop, &cellNcWidthHeight, &cellClientLeftTop, &cellClientWidthHeight))
                           continue;
        
                        ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS cellResFlags = 0;

                        CLI_GUI_POINT cellMicePos = rowMicePosClient - cellNcLeftTop;
                        if (!testWhHit( cellMicePos, cellNcWidthHeight ))
                           {
                            continue; // not hit to cur cell
                           }

                        cellResFlags = CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING;
                        *hitCell = cellIdx;

                        CLI_GUI_POINT cellMicePosClient = rowMicePosClient - cellClientLeftTop;
                        if (testWhHit( cellMicePosClient, cellClientWidthHeight ))
                           {
                            cellResFlags = CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT;
                            if (translatedMicePos) *translatedMicePos = cellMicePosClient;
                           }
                        else
                           {
                            if (translatedMicePos) *translatedMicePos = cellMicePos;
                           }
                        if (_resFlags) *_resFlags = cellResFlags;
                        //res = 
                        if (pCellFound) *pCellFound = pCell;
                        return EC_OK;
                       } // for(; cellIdx!=rowCellNumber; ++cellIdx)

                    if (_resFlags) *_resFlags = rowResFlags;
                    //if (translatedMicePos) *translatedMicePos = rowMicePos;
                    if (translatedMicePos) *translatedMicePos = rowMicePosClient;
                    return EC_OK;
                   } // for(; rit!=ritEnd && sit!=sitEnd; ++rit, ++sit)

                if (_resFlags) *_resFlags = resFlags;
                if (translatedMicePos) *translatedMicePos = micePos;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getRowNcDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                        , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                   )
       {
        if (rowIdx>=rows.size())  return EC_OUT_OF_RANGE;
        checkBuildRowSizesCache(0);

        CLI_GUI_SIZE rowNcPos = makePoint(spacing.left, spacing.top) + cachedRowSizes[rowIdx].ncPosSize.leftTop;

        RCODE res = getDrawContextForRectUpdate( pdc, &rowNcPos, &cachedRowSizes[rowIdx].ncPosSize.widthHeight);
        if (res) return res;

        if (!*pdc) return EC_NO_OBJECT;

        (*pdc)->setViewportWH( &rowNcPos, &cachedRowSizes[rowIdx].ncPosSize.widthHeight );
        return EC_OK;
       }

    CLIMETHOD(getRowDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                      , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                 )
       {
        if (rowIdx>=rows.size())  return EC_OUT_OF_RANGE;
        checkBuildRowSizesCache(0);

        CLI_GUI_SIZE rowClientPos = makePoint(spacing.left, spacing.top) + cachedRowSizes[rowIdx].clientPosSize.leftTop;

        RCODE res = getDrawContextForRectUpdate( pdc, &rowClientPos, &cachedRowSizes[rowIdx].clientPosSize.widthHeight);
        if (res) return res;

        if (!*pdc) return EC_NO_OBJECT;

        (*pdc)->setViewportWH( &rowClientPos, &cachedRowSizes[rowIdx].clientPosSize.widthHeight );
        return EC_OK;
       }

    CLIMETHOD(getCellNcDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                         , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                         , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                    )
       {
        if (rowIdx>=rows.size())  return EC_OUT_OF_RANGE;
        checkBuildRowSizesCache(0);

        CLI_GUI_SIZE  cellNcLeftTop, cellNcWidthHeight /* , cellClientLeftTop , cellClientWidthHeight */ ;
        RCODE res = rows[rowIdx]->getCellPosSize(rowIdx, cellIdx, &cellNcLeftTop, &cellNcWidthHeight, 0 /* &cellClientLeftTop */ , 0 /* &cellClientWidthHeight */  );
        if (res) return res;

        CLI_GUI_SIZE cellNcPos = makePoint(spacing.left, spacing.top) + cachedRowSizes[rowIdx].clientPosSize.leftTop + cellNcLeftTop;

        res = getDrawContextForRectUpdate( pdc, &cellNcPos, &cellNcWidthHeight);
        if (res) return res;

        if (!*pdc) return EC_NO_OBJECT;

        (*pdc)->setViewportWH( &cellNcPos, &cellNcWidthHeight );
        return EC_OK;
       }

    CLIMETHOD(getCellDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                  )
       {
        if (rowIdx>=rows.size())  return EC_OUT_OF_RANGE;
        checkBuildRowSizesCache(0);

        CLI_GUI_SIZE  /* cellNcLeftTop, cellNcWidthHeight,  */ cellClientLeftTop , cellClientWidthHeight;
        RCODE res = rows[rowIdx]->getCellPosSize(rowIdx, cellIdx, 0 /* &cellNcLeftTop */ , 0 /* &cellNcWidthHeight */ , &cellClientLeftTop, &cellClientWidthHeight );
        if (res) return res;

        CLI_GUI_SIZE cellClientPos = makePoint(spacing.left, spacing.top) + cachedRowSizes[rowIdx].clientPosSize.leftTop + cellClientLeftTop;

        res = getDrawContextForRectUpdate( pdc, &cellClientPos, &cellClientWidthHeight);
        if (res) return res;

        if (!*pdc) return EC_NO_OBJECT;

        (*pdc)->setViewportWH( &cellClientPos, &cellClientWidthHeight );
        return EC_OK;
       }




    CLIMETHOD(translatePosIntoCell) (THIS_ const STRUCT_CLI_DRAWING_CPOINT* pMicePos
                                         , SIZE_T rowIdx
                                         , SIZE_T cellIdx
                                         , STRUCT_CLI_DRAWING_CPOINT* translatedMicePos
                                         , INTERFACE_CLI_GUI_CELLGRID_IMULTICELL **pCell
                                    )
       {
        if (!pMicePos) return EC_INVALID_PARAM;

        if (rowIdx>=rows.size())  return EC_OUT_OF_RANGE;

        SIZE_T rowCellNumber = 0;
        RCODE res = rows[rowIdx]->multiCellsSize(&rowCellNumber);
        if (res) return res;

        if (cellIdx>=rowCellNumber) return EC_OUT_OF_RANGE;

        checkBuildRowSizesCache(0);

        CLI_GUI_SIZE  /* cellNcLeftTop, cellNcWidthHeight,  */ cellClientLeftTop /* , cellClientWidthHeight */ ;
        res = rows[rowIdx]->getCellPosSize(rowIdx, cellIdx, 0 /* &cellNcLeftTop */ , 0 /* &cellNcWidthHeight */ , &cellClientLeftTop, 0 /* &cellClientWidthHeight */ );
        if (res) return res;

        //CLI_GUI_POINT gridClientLeftTop = makePoint(spacing.left, spacing.top);
        //CLI_GUI_POINT micePos = *pMicePos - makePoint(spacing.left, spacing.top) /* gridClientLeftTop */ ;
        //CLI_GUI_POINT rowMicePosClient = (*pMicePos - makePoint(spacing.left, spacing.top) /* gridClientLeftTop */ ) /* micePos */  - cachedRowSizes[rowIdx].clientPosSize.leftTop;
        //CLI_GUI_POINT cellMicePosClient = ((*pMicePos - makePoint(spacing.left, spacing.top) /* gridClientLeftTop */ ) /* micePos */  - cachedRowSizes[rowIdx].clientPosSize.leftTop) /* rowMicePosClient */  - cellClientLeftTop;
        //CLI_GUI_POINT cellMicePosClient = *pMicePos - makePoint(spacing.left, spacing.top) - cachedRowSizes[rowIdx].clientPosSize.leftTop - cellClientLeftTop;
        if (pCell)
           {
            res = rows[rowIdx]->multiCellsGet( pCell, cellIdx );
            if (res) return res;
           }
        if (translatedMicePos) *translatedMicePos = *pMicePos - makePoint(spacing.left, spacing.top) - cachedRowSizes[rowIdx].clientPosSize.leftTop - cellClientLeftTop;

        return EC_OK;
       }

    CLIMETHOD(onMouseMoveAux) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                   , INTERFACE_CLI_GUI_CELLGRID_IMULTICELL **_ppCell
                                   , SIZE_T *_pHitRow
                                   , SIZE_T *_pHitCell
                                   , STRUCT_CLI_DRAWING_CPOINT* _pTranslatedMicePos
                                   )
       {
        if (captureRow!=SIZE_T_NPOS && captureCell!=SIZE_T_NPOS)
           { // capture mode is on
            CLI_GUI_POINT translatedMicePos;
            INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;
            RCODE res = translatePosIntoCell( micePos, captureRow, captureCell, &translatedMicePos, &pCell);
            if (res) return res;
            if (!pCell) return EC_INVALID_OBJECT_PTR;
            
            if (_ppCell) *_ppCell = pCell;
            if (_pHitRow)  *_pHitRow  = captureRow;
            if (_pHitCell) *_pHitCell = captureCell;
            if (_pTranslatedMicePos) *_pTranslatedMicePos = translatedMicePos;

            return pCell->onMouseMove( &translatedMicePos, captureRow, captureCell );
           }
        // capture mode is off

        ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS resFlags = 0;
        SIZE_T    hitRow  = SIZE_T_NPOS;
        SIZE_T    hitCell = SIZE_T_NPOS;

        STRUCT_CLI_DRAWING_CPOINT cellMicePos;
        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;

        RCODE res = hitTest( micePos, &hitRow, &hitCell, &resFlags, &cellMicePos, &pCell );
        if (_ppCell)   *_ppCell   = pCell;
        if (_pHitRow)  *_pHitRow  = hitRow;
        if (_pHitCell) *_pHitCell = hitCell;
        if (_pTranslatedMicePos) *_pTranslatedMicePos = cellMicePos;

        if (res) return res;

        // activation changed only if on mice click event
        if (activateOnClick && (resFlags&CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT))
           { // active cell changed only on click 
             // but we translate event into cell
            if (pCell)
               return pCell->onMouseMove( &cellMicePos, hitRow, hitCell );
            return EC_OK;
           }

        // activation changed on mouse moving

        //, activeRow(SIZE_T_NPOS)
        //, activeCell(SIZE_T_NPOS)
        if (resFlags&CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT)
           { // mice over the cell
            if (activeRow!=hitRow || activeCell!=hitCell)
               { // and cell changed
                cellsActiveSet(TRUE, hitRow, hitCell);
               }
            if (pCell)
               return pCell->onMouseMove( &cellMicePos, hitRow, hitCell );
           }
        else
           {
            if (!activateOnClick)
               resetActiveCell(); // no hit on cell
           }
        return EC_OK;
       }

    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */)
       {
        RCODE res = onMouseMoveAux( micePos, 0, 0, 0, 0 );
        updatePaint();
        return res;
       }

    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                            )
       {
        INTERFACE_CLI_GUI_CELLGRID_IMULTICELL *pCell = 0;
        SIZE_T hitRow = 0, hitCell = 0;
        STRUCT_CLI_DRAWING_CPOINT translatedMicePos = zeroPoint();

        BOOL savedActivateOnClick = activateOnClick;
        activateOnClick = FALSE; // onMouseMoveAux activates cell
        onMouseMoveAux( micePos, &pCell, &hitRow, &hitCell, &translatedMicePos );
        activateOnClick = savedActivateOnClick;
        if (!pCell) return EC_OK;

        //return 
        RCODE clickRes = pCell->onMouseClick( &translatedMicePos, hitRow, hitCell, eventFlags );
        updatePaint();
        return clickRes;

        /*
        //savedActivateOnClick = activateOnClick;
        activateOnClick = FALSE; // onMouseMoveAux activates cell
        onMouseMoveAux( micePos, 0, 0, 0, 0 );
        activateOnClick = savedActivateOnClick;
        return clickRes;
        */
       }

    CLIMETHOD(updatePaint) (THIS)
       {
        // determine that painting needed at all
        //bool needSomePainting = false;
        ::std::vector< ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE > rowInvalidates;
        SIZE_T iRow = 0;
        //CLI_GUI_POINT leftTop = zeroPoint(), widthheight = zeroPoint; // makePoint(spacing.left, spacing.top)
        SIZE_T firstPaintRowIndex = SIZE_T_NPOS;
        SIZE_T numOfRowsToPaint = 0;
        for(; iRow!=rows.size(); ++iRow)
           {
            ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE iType = isRowNeedRepaint(iRow);
            if (iType>CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID) 
               {
                if (!numOfRowsToPaint)
                   {
                    firstPaintRowIndex = iRow;
                    // first row needed paint, possible it is single
                    //leftTop     = cachedRowSizes[iRow].ncPosSize.leftTop;
                    //widthheight = cachedRowSizes[iRow].ncPosSize.widthHeight;
                   }
                ++numOfRowsToPaint;
               }             
            rowInvalidates.push_back(iType); // cache row paint flags
           }

        if (!numOfRowsToPaint) return EC_OK; // no painting needed

        INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc = 0;
        RCODE res = EC_OK;
        if (numOfRowsToPaint<2)
           { // only one row need painting
            CLI_GUI_SIZE rowNcPos = makePoint(spacing.left, spacing.top) + cachedRowSizes[firstPaintRowIndex].ncPosSize.leftTop;
    
            //RCODE 
            res = getDrawContextForRectUpdate( &pdc, &rowNcPos, &cachedRowSizes[firstPaintRowIndex].ncPosSize.widthHeight);
            //if (res) return res;    
            //if (!*pdc) return EC_NO_OBJECT;
    
            //res = getRowNcDrawContext(&pdc, firstPaintRowIndex);
           }
        else
           { // multiple rows need painting
            res = getDrawContextForUpdate(&pdc);
           }

        if (res) return res;
        if (!pdc) return EC_INVALID_OBJECT_PTR;

        iRow = 0;
        for(; iRow!=rows.size(); ++iRow)
           {
            if (rowInvalidates[iRow]==CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID) continue;
            if (rowInvalidates[iRow]==CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT)
               {
                //CLITRACE1( L"paint row, row: %1\n", iRow );
                paintRowOnContext( pdc, iRow );
               }
            else
               {
                if (iRow>=rows.size()) continue; // invalid index
                SIZE_T numOfCells = 0;
                rows[iRow]->cellsSize(&numOfCells);
                SIZE_T iCell = 0;
                for(; iCell!=numOfCells; ++iCell)
                   {
                    ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE iTypeCell = isCellNeedRepaint(iRow, iCell);
                    switch(iTypeCell)
                       {
                        case CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID:  break;
                        case CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLNEEDREPAINT:
                        case CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT:
                             partialPaintOnContextAux(pdc, iRow, iCell, iRow, iCell, false);
                             //CLITRACE2( L"paint cell, row: %1, cell: %2\n", iRow, iCell );
                             break;
                        case CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDUPDATE:
                             partialPaintOnContextAux(pdc, iRow, iCell, iRow, iCell, true);
                             //CLITRACE2( L"update cell, row: %1, cell: %2\n", iRow, iCell );
                             break;
                        //default:            
                       }
                   }
               }
           }
        pdc->release();
        /*
        #define CLI_GUI_CELLGRID_EINVALIDATETYPE_VALID                            0
        #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDUPDATE             1
        #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLCLIENTNEEDREPAINT            2
        #define CLI_GUI_CELLGRID_EINVALIDATETYPE_CELLNEEDREPAINT  4
        #define CLI_GUI_CELLGRID_EINVALIDATETYPE_ROWNEEDREPAINT   8
        */
        //ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE isRowNeedRepaint( size_t rowIdx )
        //ENUM_CLI_GUI_CELLGRID_EINVALIDATETYPE isCellNeedRepaint( size_t rowIdx, size_t cellIdx )

        updatePaintComplete();

        return EC_OK;
       }



}; // class CGridImpl


//----------------------
// class CAutoLockUpdate
inline
CAutoLockUpdate::CAutoLockUpdate(CGridImpl *plo, BOOL newLockState) : pLockOwner(plo), prevLockUpdate(plo->lockUpdate)
   {
    pLockOwner->lockUpdate = newLockState;
   }

inline
CAutoLockUpdate::~CAutoLockUpdate()
   {
    pLockOwner->lockUpdate = prevLockUpdate;
   }

}; // namespace cellgrid
}; // namespace gui
}; // namespace cli



#endif // CLI_GUI_CG2_IGRIDIMPL_H

