#ifndef CLI_GUI_IOBJECTX_H
#define CLI_GUI_IOBJECTX_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/gui/iObjectX.h>", CLI_GUI_IOBJECTX_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_GUI_IOBJECTX_H
    #include <cli/gui/iObjectX.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iObjectX */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace drawing {
            interface                                iDrawContext1;
            #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
                #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               ::cli::drawing::iDrawContext1
            #endif

        }; // namespace drawing
    }; // namespace cli
    namespace cli {
        namespace gui {
            interface                                iDefinitionParserObjectX;
            #ifndef INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX
                #define INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX        ::cli::gui::iDefinitionParserObjectX
            #endif

            interface                                iOwnerObjectX;
            #ifndef INTERFACE_CLI_GUI_IOWNEROBJECTX
                #define INTERFACE_CLI_GUI_IOWNEROBJECTX   ::cli::gui::iOwnerObjectX
            #endif

        }; // namespace gui
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_PREDECLARED
    #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_PREDECLARED
    typedef interface tag_cli_drawing_iDrawContext1              cli_drawing_iDrawContext1;
    #endif //INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
        #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               struct tag_cli_drawing_iDrawContext1
    #endif

    #ifndef INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX_PREDECLARED
    #define INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX_PREDECLARED
    typedef interface tag_cli_gui_iDefinitionParserObjectX       cli_gui_iDefinitionParserObjectX;
    #endif //INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX
    #ifndef INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX
        #define INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX        struct tag_cli_gui_iDefinitionParserObjectX
    #endif

    #ifndef INTERFACE_CLI_GUI_IOWNEROBJECTX_PREDECLARED
    #define INTERFACE_CLI_GUI_IOWNEROBJECTX_PREDECLARED
    typedef interface tag_cli_gui_iOwnerObjectX                  cli_gui_iOwnerObjectX;
    #endif //INTERFACE_CLI_GUI_IOWNEROBJECTX
    #ifndef INTERFACE_CLI_GUI_IOWNEROBJECTX
        #define INTERFACE_CLI_GUI_IOWNEROBJECTX   struct tag_cli_gui_iOwnerObjectX
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_IOBJECTX_IID
    #define INTERFACE_CLI_GUI_IOBJECTX_IID    "/cli/gui/iObjectX"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iObjectX
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_IOBJECTX
       #define INTERFACE_CLI_GUI_IOBJECTX    ::cli::gui::iObjectX
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iObjectX
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_IOBJECTX
       #define INTERFACE_CLI_GUI_IOBJECTX    cli_gui_iObjectX
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iObjectX methods */
                CLIMETHOD(initObject) (THIS_ INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX*    pDefParser /* [in,optional] ::cli::gui::iDefinitionParserObjectX*  pDefParser  */) PURE;
                CLIMETHOD(addObjectOwner) (THIS_ INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */) PURE;
                CLIMETHOD(removeObjectOwner) (THIS_ INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */) PURE;
                CLIMETHOD(drawObject) (THIS_ INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */
                                           , UINT    key /* [in] uint  key  */
                                           , INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pDc /* [in] ::cli::drawing::iDrawContext1*  pDc  */
                                      ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iObjectX >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_IOBJECTX_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iObjectX* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iObjectX > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iObjectX wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_IOBJECTX >
                                          */
                     >
            class CiObjectXWrapper
            {
                public:
            
                    typedef  CiObjectXWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiObjectXWrapper() :
                       pif(0) {}
            
                    CiObjectXWrapper( iObjectX *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiObjectXWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiObjectXWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiObjectXWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiObjectXWrapper(const CiObjectXWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiObjectXWrapper()  { }
            
                    CiObjectXWrapper& operator=(const CiObjectXWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE initObject( INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX*    pDefParser /* [in,optional] ::cli::gui::iDefinitionParserObjectX*  pDefParser  */)
                       {
                    
                        return pif->initObject(pDefParser);
                       }
                    
                    RCODE addObjectOwner( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */)
                       {
                    
                        return pif->addObjectOwner(pOwner);
                       }
                    
                    RCODE removeObjectOwner( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */)
                       {
                    
                        return pif->removeObjectOwner(pOwner);
                       }
                    
                    RCODE drawObject( INTERFACE_CLI_GUI_IOWNEROBJECTX*    pOwner /* [in] ::cli::gui::iOwnerObjectX*  pOwner  */
                                    , UINT    key /* [in] uint  key  */
                                    , INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pDc /* [in] ::cli::drawing::iDrawContext1*  pDc  */
                                    )
                       {
                    
                    
                    
                        return pif->drawObject(pOwner, key, pDc);
                       }
                    

            
            
            }; // class CiObjectXWrapper
            
            typedef CiObjectXWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_IOBJECTX     > >  CiObjectX;
            typedef CiObjectXWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IOBJECTX > >  CiObjectX_nrc; /* No ref counting for interface used */
            typedef CiObjectXWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IOBJECTX > >  CiObjectX_tmp; /* for temporary usage, same as CiObjectX_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iOwnerObjectX */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace gui {
            interface                                iObjectX;
            #ifndef INTERFACE_CLI_GUI_IOBJECTX
                #define INTERFACE_CLI_GUI_IOBJECTX        ::cli::gui::iObjectX
            #endif

        }; // namespace gui
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_GUI_IOBJECTX_PREDECLARED
    #define INTERFACE_CLI_GUI_IOBJECTX_PREDECLARED
    typedef interface tag_cli_gui_iObjectX   cli_gui_iObjectX;
    #endif //INTERFACE_CLI_GUI_IOBJECTX
    #ifndef INTERFACE_CLI_GUI_IOBJECTX
        #define INTERFACE_CLI_GUI_IOBJECTX        struct tag_cli_gui_iObjectX
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_IOWNEROBJECTX_IID
    #define INTERFACE_CLI_GUI_IOWNEROBJECTX_IID    "/cli/gui/iOwnerObjectX"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iOwnerObjectX
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_IOWNEROBJECTX
       #define INTERFACE_CLI_GUI_IOWNEROBJECTX    ::cli::gui::iOwnerObjectX
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iOwnerObjectX
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_IOWNEROBJECTX
       #define INTERFACE_CLI_GUI_IOWNEROBJECTX    cli_gui_iOwnerObjectX
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iOwnerObjectX methods */
                CLIMETHOD(invalidateObjectView) (THIS_ BOOL    forceRepaint /* [in] bool  forceRepaint  */) PURE;
                CLIMETHOD(getObjectById) (THIS_ const CLISTR*     id
                                              , INTERFACE_CLI_GUI_IOBJECTX**    pObject /* [out] ::cli::gui::iObjectX* pObject  */
                                         ) PURE;
                CLIMETHOD(getObjectByIdChars) (THIS_ const WCHAR*    id /* [in,flat] wchar  id[]  */
                                                   , INTERFACE_CLI_GUI_IOBJECTX**    pObject /* [out] ::cli::gui::iObjectX* pObject  */
                                              ) PURE;
                CLIMETHOD(generateNewDrawIdByObjectId) (THIS_ const CLISTR*     id
                                                            , SIZE_T*    drawId /* [out] size_t drawId  */
                                                       ) PURE;
                CLIMETHOD(generateNewDrawIdByObjectIdChars) (THIS_ const WCHAR*    id /* [in,flat] wchar  id[]  */
                                                                 , SIZE_T*    drawId /* [out] size_t drawId  */
                                                            ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iOwnerObjectX >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_IOWNEROBJECTX_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iOwnerObjectX* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iOwnerObjectX > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iOwnerObjectX wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_IOWNEROBJECTX >
                                          */
                     >
            class CiOwnerObjectXWrapper
            {
                public:
            
                    typedef  CiOwnerObjectXWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiOwnerObjectXWrapper() :
                       pif(0) {}
            
                    CiOwnerObjectXWrapper( iOwnerObjectX *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiOwnerObjectXWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiOwnerObjectXWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiOwnerObjectXWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiOwnerObjectXWrapper(const CiOwnerObjectXWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiOwnerObjectXWrapper()  { }
            
                    CiOwnerObjectXWrapper& operator=(const CiOwnerObjectXWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE invalidateObjectView( BOOL    forceRepaint /* [in] bool  forceRepaint  */)
                       {
                    
                        return pif->invalidateObjectView(forceRepaint);
                       }
                    
                    RCODE getObjectById( const ::std::wstring    &id
                                       , INTERFACE_CLI_GUI_IOBJECTX**    pObject /* [out] ::cli::gui::iObjectX* pObject  */
                                       )
                       {
                        CCliStr tmp_id; CCliStr_lightCopyTo( tmp_id, id);
                    
                        return pif->getObjectById(&tmp_id, pObject);
                       }
                    
                    RCODE getObjectByIdChars( const WCHAR*    id /* [in,flat] wchar  id[]  */
                                            , INTERFACE_CLI_GUI_IOBJECTX**    pObject /* [out] ::cli::gui::iObjectX* pObject  */
                                            )
                       {
                    
                    
                        return pif->getObjectByIdChars(id, pObject);
                       }
                    
                    RCODE generateNewDrawIdByObjectId( const ::std::wstring    &id
                                                     , SIZE_T*    drawId /* [out] size_t drawId  */
                                                     )
                       {
                        CCliStr tmp_id; CCliStr_lightCopyTo( tmp_id, id);
                    
                        return pif->generateNewDrawIdByObjectId(&tmp_id, drawId);
                       }
                    
                    RCODE generateNewDrawIdByObjectIdChars( const WCHAR*    id /* [in,flat] wchar  id[]  */
                                                          , SIZE_T*    drawId /* [out] size_t drawId  */
                                                          )
                       {
                    
                    
                        return pif->generateNewDrawIdByObjectIdChars(id, drawId);
                       }
                    

            
            
            }; // class CiOwnerObjectXWrapper
            
            typedef CiOwnerObjectXWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_IOWNEROBJECTX     > >  CiOwnerObjectX;
            typedef CiOwnerObjectXWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IOWNEROBJECTX > >  CiOwnerObjectX_nrc; /* No ref counting for interface used */
            typedef CiOwnerObjectXWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IOWNEROBJECTX > >  CiOwnerObjectX_tmp; /* for temporary usage, same as CiOwnerObjectX_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::gui::iDefinitionParserObjectX */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iVariant;
        #ifndef INTERFACE_CLI_IVARIANT
            #define INTERFACE_CLI_IVARIANT            ::cli::iVariant
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IVARIANT_PREDECLARED
    #define INTERFACE_CLI_IVARIANT_PREDECLARED
    typedef interface tag_cli_iVariant       cli_iVariant;
    #endif //INTERFACE_CLI_IVARIANT
    #ifndef INTERFACE_CLI_IVARIANT
        #define INTERFACE_CLI_IVARIANT            struct tag_cli_iVariant
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX_IID
    #define INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX_IID    "/cli/gui/iDefinitionParserObjectX"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace gui {
    #define INTERFACE iDefinitionParserObjectX
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX
       #define INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX    ::cli::gui::iDefinitionParserObjectX
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_gui_iDefinitionParserObjectX
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX
       #define INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX    cli_gui_iDefinitionParserObjectX
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::gui::iDefinitionParserObjectX methods */
                CLIMETHOD_(BOOL, hasDefinitionValue) (THIS_ const WCHAR*    valName /* [in,flat] wchar  valName[]  */) PURE;
                CLIMETHOD_(BOOL, getDefinitionValue) (THIS_ const WCHAR*    valName /* [in,flat] wchar  valName[]  */
                                                          , INTERFACE_CLI_IVARIANT*    pValDst /* [in] ::cli::iVariant*  pValDst  */
                                                     ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace gui
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::gui::iDefinitionParserObjectX >
           {
            static char const * getName() { return INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX_IID; }
           };
        template<> struct CIidOfImpl< ::cli::gui::iDefinitionParserObjectX* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::gui::iDefinitionParserObjectX > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace gui {
            // interface ::cli::gui::iDefinitionParserObjectX wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX >
                                          */
                     >
            class CiDefinitionParserObjectXWrapper
            {
                public:
            
                    typedef  CiDefinitionParserObjectXWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiDefinitionParserObjectXWrapper() :
                       pif(0) {}
            
                    CiDefinitionParserObjectXWrapper( iDefinitionParserObjectX *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiDefinitionParserObjectXWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiDefinitionParserObjectXWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiDefinitionParserObjectXWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiDefinitionParserObjectXWrapper(const CiDefinitionParserObjectXWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiDefinitionParserObjectXWrapper()  { }
            
                    CiDefinitionParserObjectXWrapper& operator=(const CiDefinitionParserObjectXWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    BOOL hasDefinitionValue( const WCHAR*    valName /* [in,flat] wchar  valName[]  */)
                       {
                    
                        return pif->hasDefinitionValue(valName);
                       }
                    
                    BOOL getDefinitionValue( const WCHAR*    valName /* [in,flat] wchar  valName[]  */
                                           , INTERFACE_CLI_IVARIANT*    pValDst /* [in] ::cli::iVariant*  pValDst  */
                                           )
                       {
                    
                    
                        return pif->getDefinitionValue(valName, pValDst);
                       }
                    

            
            
            }; // class CiDefinitionParserObjectXWrapper
            
            typedef CiDefinitionParserObjectXWrapper< ::cli::CCliPtr< INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX     > >  CiDefinitionParserObjectX;
            typedef CiDefinitionParserObjectXWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX > >  CiDefinitionParserObjectX_nrc; /* No ref counting for interface used */
            typedef CiDefinitionParserObjectXWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_GUI_IDEFINITIONPARSEROBJECTX > >  CiDefinitionParserObjectX_tmp; /* for temporary usage, same as CiDefinitionParserObjectX_nrc */
            
            
            
            
            
        }; // namespace gui
    }; // namespace cli

#endif





#endif /* CLI_GUI_IOBJECTX_H */
