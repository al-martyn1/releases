#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_ISAX_H
#define CLI_XML_ISAX_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/xml/isax.h>", CLI_XML_ISAX_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_XML_ISAX_H
    #include <cli/xml/isax.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IDESTROYABLE_H
    #include <cli/idestroyable.h>
#endif

#ifndef CLI_PFSTYPES_H
    #include <cli/pfsTypes.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iSaxHandler */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iDestroyable;
        #ifndef INTERFACE_CLI_IDESTROYABLE
            #define INTERFACE_CLI_IDESTROYABLE        ::cli::iDestroyable
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IDESTROYABLE_PREDECLARED
    #define INTERFACE_CLI_IDESTROYABLE_PREDECLARED
    typedef interface tag_cli_iDestroyable   cli_iDestroyable;
    #endif //INTERFACE_CLI_IDESTROYABLE
    #ifndef INTERFACE_CLI_IDESTROYABLE
        #define INTERFACE_CLI_IDESTROYABLE        struct tag_cli_iDestroyable
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISAXHANDLER_IID
    #define INTERFACE_CLI_ISAXHANDLER_IID    "/cli/iSaxHandler"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iSaxHandler
    #define BASE_INTERFACE ::cli::iDestroyable
    #ifndef INTERFACE_CLI_ISAXHANDLER
       #define INTERFACE_CLI_ISAXHANDLER    ::cli::iSaxHandler
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iSaxHandler
    #define BASE_INTERFACE cli_iDestroyable
    #ifndef INTERFACE_CLI_ISAXHANDLER
       #define INTERFACE_CLI_ISAXHANDLER    cli_iSaxHandler
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDestroyable methods */
            CLIMETHOD(destroy) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iSaxHandler >
           {
            static char const * getName() { return INTERFACE_CLI_ISAXHANDLER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iSaxHandler* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iSaxHandler > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif





#endif /* CLI_XML_ISAX_H */
