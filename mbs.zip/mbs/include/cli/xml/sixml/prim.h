#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

/* Node data manipulations methods - sixml serializer internal header file
 * Designed by Andrey Martynov
 * mailto:rek@.rsdn.ru
 * Rewritten by Alex Martinov (amart@mail.ru), 2004.
 */
#ifndef CLI_XML_SIXML_PRIM_H
#define CLI_XML_SIXML_PRIM_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_XML_SIXML_INODE_H
    #include <cli/xml/sixml/inode.h>
#endif

#ifndef CLI_XML_SIXML_6MLEXCEP_H
    #include <cli/xml/sixml/6mlexcep.h>
#endif

#if !defined(_MAP_) && !defined(__STD_MAP__)
    #include <map>
#endif

#if !defined(_INC_FLOAT) && !defined(__FLOAT_H)
    #include <float.h>
#endif

#ifndef CLI_XML_SIXML_UTILS_H
    #include <cli/xml/sixml/util.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef CLI_XML_SIXML_PRIMUTIL_H
    #include <cli/xml/sixml/primutil.h>
#endif

#if !defined(_LIMITS_) && !defined(_STLP_LIMITS) && !defined(__STD_LIMITS__) && !defined(_CPP_LIMITS) && !defined(_GLIBCXX_LIMITS)
    #include <limits>
#endif

/*
#ifndef __SIXML_SIXMLEXCEP_H_INCLUDED__
    #include <sixml/6mlexcep.h>
#endif
*/

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_TYPEDEF_H
    #include <cli/typedef.h>
#endif

#ifndef CLI_VARIANT_H
    #include <cli/variant.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifdef min
    #undef min
    #define CLI_XML_SIXML_PRIM_RESTORE_WIN_MIN
#endif

#ifdef max
    #undef max
    #define CLI_XML_SIXML_PRIM_RESTORE_WIN__MAX
#endif



// ::sixml::serializer::types

namespace sixml{

namespace serializer{
//namespace util {};
namespace types{


#include <cli/pshpack1.h>
CLI_STRONG_TYPEDEF_EX(COLORREF,colorref_t,0);
/*
struct colorref_t                                        
{                                                     
    typedef  COLORREF value_type;                      
    value_type       value;                           
                                                      
    colorref_t() : value(0) {}                      
    colorref_t(COLORREF v) : value(v) {}                  
    operator COLORREF () const { return value; }       
    colorref_t& operator=( const colorref_t &r )            
       {                                              
        if (&r!=this) value = r.value;                
        return *this;                                 
       }                                              
    colorref_t& operator=( COLORREF v )                   
       {                                              
        value = v;                                    
        return *this;                                 
       }                                              
};
*/
#include <cli/poppack.h>



typedef unsigned int  uint;
typedef signed int    sint;
typedef        int    Iint;

typedef unsigned short int  ushort;
typedef   signed short int  sshort;
typedef          short int  Ishort;

typedef unsigned long  int  ulong;
typedef   signed long  int  slong;
typedef          long  int  Ilong;

typedef unsigned char  uchar;

typedef UINT64   uint64;
typedef  INT64    int64;


/*
#if defined(__BORLANDC__)
    #define __SOMEONE_LIKE_BORLANDC__
#endif

#if defined(__SOMEONE_LIKE_BORLANDC__)
    #define    FLAGSTSPEC
#else
    #define    FLAGSTSPEC
#endif


#define _T
#if defined(__BORLANDC__) || defined(__SOMEONELIKEBORLANDC__)
#undef  _T
#define _T  <T>
#endif 
*/


template <typename IntType>
class flags_t
{

protected:

    IntType        m_f;

public:

    //typedef typename IntType int_type;
    typedef IntType int_type;

    // ������������
    flags_t() : m_f(0) {}  // �� ���������
    flags_t(const IntType f) : m_f(f) {}  // ����������� �� ����������� ����
    flags_t(const flags_t &ft) : m_f(ft.m_f) {}  // �����������
    // ���������
    // ���������� ����
    operator IntType () const { return m_f; } 
    // ������������
    flags_t& operator =(const IntType f)   { m_f = f; return *this;}
    flags_t& operator =(const flags_t &ft) { m_f = ft.m_f; return *this;}

    // ��������������
    flags_t& operator +=(const IntType f)          { m_f += f;      return (*this); }
    //flags_t& operator +=(const flags_t &ft)        { m_f += ft.m_f; return (*this); }
    //IntType  operator +(const IntType f)     const { return (m_f+f); }
    //IntType  operator +(const flags_t &ft)   const { return (m_f+ft.m_f); }
    //friend IntType operator +(const IntType f, const flags_t<IntType> &ft)
    //       { return (f+ft.m_f); }
    flags_t& operator ++()    { m_f++; return *this; }
    IntType  operator ++(int) { flags_t tmp(*this); m_f++; return tmp; }
    
    flags_t& operator -=(const IntType f)          { m_f -= f;      return (*this); }
    //flags_t& operator -=(const flags_t &ft)        { m_f -= ft.m_f; return (*this); }
    //IntType  operator -(const IntType f)     const { return (m_f-f); }
    //IntType  operator -(const flags_t &ft)   const { return (m_f-ft.m_f); }
    //friend IntType operator -(const IntType f, const flags_t<IntType> &ft)
    //       { return (f-ft.m_f); }
    flags_t& operator --()    { m_f--; return *this; }
    IntType  operator --(int) { flags_t tmp(*this); m_f--; return tmp; }
    
    flags_t& operator *=(const IntType f)          { m_f *= f;      return (*this); }
    //flags_t& operator *=(const flags_t &ft)        { m_f *= ft.m_f; return (*this); }
    //IntType  operator *(const IntType f)     const { return (m_f*f); }
    //IntType  operator *(const flags_t &ft)   const { return (m_f*ft.m_f); }
    //friend IntType operator *(const IntType f, const flags_t<IntType> &ft)
    //       { return (f*ft.m_f); }
    
    flags_t& operator /=(const IntType f)          { m_f /= f;      return (*this); }
    //flags_t& operator /=(const flags_t &ft)        { m_f /= ft.m_f; return (*this); }
    //IntType  operator /(const IntType f)     const { return (m_f/f); }
    //IntType  operator /(const flags_t &ft)   const { return (m_f/ft.m_f); }
    //friend IntType operator +(const IntType f, const flags_t<IntType> &ft)
    //       { return (f/ft.m_f); }
    
    flags_t& operator %=(const IntType f)          { m_f %= f;      return (*this); }
    //flags_t& operator %=(const flags_t &ft)        { m_f %= ft.m_f; return (*this); }
    //IntType  operator %(const IntType f)     const { return (m_f%f); }
    //IntType  operator %(const flags_t &ft)   const { return (m_f%ft.m_f); }
    //friend IntType operator +(const IntType f, const flags_t<IntType> &ft)
    //       { return (f%ft.m_f); }

    // ����������
    //bool operator !() const { return m_f ? true : false; };

    // ���������
    IntType operator~() const { return ~m_f; }
    flags_t& operator <<=(const IntType f)  { m_f <<= f; return (*this); }
    flags_t& operator >>=(const IntType f)  { m_f >>= f; return (*this); }
    flags_t& operator &=(const IntType f)  { m_f &= f; return (*this); }
    flags_t& operator ^=(const IntType f)  { m_f ^= f; return (*this); }
    flags_t& operator |=(const IntType f)  { m_f |= f; return (*this); }

};

}; // namespace types


template <typename Type>
struct primitive
{
    static ::sixml::util::tstring to_string(const Type &, const ::sixml::util::tstring &attrOrTagName)
        {
         CLI_STATIC_CHECK(0, Template_struct_primitive_not_specialized_for_this_type)
         //throw not_specialised("Template primitive not specialised");
         return ::sixml::util::tstring();
        }
    static Type from_string(const ::sixml::util::tstring &, const ::sixml::util::tstring &attrOrTagName)
        {
         CLI_STATIC_CHECK(0, Template_struct_primitive_not_specialized_for_this_type)
         //throw not_specialised("Template primitive not specialised");
         return ::sixml::util::tstring();
        }
};

#ifndef SIXML_MACROTOSTR
    #define SIXML_MACROTOSTR(arg) #arg
#endif

#define INT_PRIMITIVE_SPECIALISATION(prim_type, normal_name, low_lim, high_lim)   \
template <>                                                                   \
struct primitive< prim_type >                                                 \
{                                                                             \
    static const bool allowEmptyInput = false;                                \
    static ::sixml::util::tstring to_string(const prim_type &v, const ::sixml::util::tstring &attrOrTagName) \
        { /* no range checks than saving data */                              \
         return sixml::util::i64totstr(v, attrOrTagName);                                    \
        }                                                                     \
    static prim_type from_string(const ::sixml::util::tstring &s, const ::sixml::util::tstring &attrOrTagName) \
        {                                                                     \
         prim_type valueConverted;                                            \
         /*::sixml::util::tstringToIntType< prim_type , low_lim, high_lim >( ::sixml::util::trim_copy(s), valueConverted, #normal_name ); */ \
         /* ::sixml::util::tstringToIntType< prim_type , low_lim, high_lim >( s, valueConverted, attrOrTagName, _T(#normal_name) ); */ /* exceptions can be trown here */ \
         ::sixml::util::tstringToIntType< prim_type , low_lim, high_lim >( ::sixml::util::trim_copy(s), valueConverted, attrOrTagName, _T(#normal_name) ); /* exceptions can be trown here */ \
         return valueConverted;                                               \
        }                                                                     \
};


// keep in sync with metadata initialization with DEFAULT_PRIM_METADATA in metaclas.h

INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::uint    , unsigned int       , 0         , UINT_MAX  ) // LONG_MIN, LONG_MAX, ULONG_MAX
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::sint    , signed   int       , INT_MIN   , INT_MAX   )
//INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::Iint    ,          int       , INT_MIN   , INT_MAX   )
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::ushort  , unsigned short int , 0         , USHRT_MAX )
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::sshort  , signed   short int , SHRT_MIN  , SHRT_MAX  )
//INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::Ishort  ,          short int , SHRT_MIN  , SHRT_MAX  )
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::ulong   , unsigned long  int , 0         , ULONG_MAX )
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::slong   , signed   long  int , LONG_MIN  , LONG_MAX  )
//INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::Ilong   ,          long  int , SHRT_MIN  , SHRT_MAX  )
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::uchar   , unsigned char      , 0         , UCHAR_MAX )

#if _UI64_MAX!=ULONG_MAX
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types:: int64  ,  INT64             , _I64_MAX  , _I64_MIN  )
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::uint64  , UINT64             , 0         , _UI64_MAX )
#endif

#if UINT_MAX != ULONG_MAX
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::uint    , unsigned  int , 0         , UINT_MAX )
INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::slong   , signed    int , INT_MIN  , INT_MAX  )
#endif



//INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::schar, signed char  , SCHAR_MIN, SCHAR_MAX)
//INT_PRIMITIVE_SPECIALISATION(char,         char         , l, h)

//INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::, , l, h)
//INT_PRIMITIVE_SPECIALISATION(sixml::serializer::types::, , l, h)

template <>
struct primitive< ::std::string >
{
    static const bool allowEmptyInput = true;
    static ::sixml::util::tstring to_string(const ::std::string &s, const ::sixml::util::tstring &attrOrTagName)
        {
         #if defined(UNICODE) || defined(_UNICODE)
         return MARTY_CON::a2wide(::sixml::util::trim_copy(s));
         //return MARTY_CON::a2wide(s);
         #else
         return ::sixml::util::trim_copy(s);
         //return s;
         #endif
        }
    static ::std::string from_string(const ::sixml::util::tstring &s, const ::sixml::util::tstring &attrOrTagName)
        {
         #if defined(UNICODE) || defined(_UNICODE)
         return MARTY_CON::w2ansi(s);
         #else
         return s;
         #endif
        }
};

template <>
struct primitive< ::std::wstring >
{
    static const bool allowEmptyInput = true;
    static ::sixml::util::tstring to_string(const ::std::wstring &s, const ::sixml::util::tstring &attrOrTagName)
        {
         #if defined(UNICODE) || defined(_UNICODE)
         return ::sixml::util::trim_copy(s);
         //return s;
         #else
         return MARTY_CON::w2ansi(::sixml::util::trim_copy(s));
         //return MARTY_CON::w2ansi(s);
         #endif
        }
    static ::std::wstring from_string(const ::sixml::util::tstring &s, const ::sixml::util::tstring &attrOrTagName)
        {
         #if defined(UNICODE) || defined(_UNICODE)
         return s;
         #else
         return MARTY_CON::a2wide(s);
         #endif
        }
};

template <>
struct primitive< char > : public primitive< ::std::string >
{
    static const bool allowEmptyInput = false;
    typedef struct primitive< ::std::string > base_impl;
    static ::sixml::util::tstring to_string( const char &ch, const ::sixml::util::tstring &attrOrTagName)
        {
         return base_impl::to_string( ::std::string(1, ch), attrOrTagName );
        }
    static char from_string(const ::sixml::util::tstring &s, const ::sixml::util::tstring &attrOrTagName)
        {
         ::std::string str = base_impl::from_string(s, attrOrTagName);
         if (str.empty() && !allowEmptyInput)
            sixml::throw_invalid_char_format_error( s, _T("char"), attrOrTagName );
         if (str.empty()) return ' '; // by default space char used
         return str[0];
        }
};

template <>
struct primitive< wchar_t > : public primitive< ::std::wstring >
{
    static const bool allowEmptyInput = false;
    typedef struct primitive< ::std::wstring > base_impl;
    static ::sixml::util::tstring to_string( const wchar_t &ch, const ::sixml::util::tstring &attrOrTagName)
        {
         return base_impl::to_string( ::std::wstring(1, ch), attrOrTagName );
        }
    static wchar_t from_string(const ::sixml::util::tstring &s, const ::sixml::util::tstring &attrOrTagName)
        {
         ::std::wstring str = base_impl::from_string(s, attrOrTagName);
         if (str.empty() && !allowEmptyInput)
            sixml::throw_invalid_char_format_error( s, _T("wchar_t"), attrOrTagName );
         if (str.empty()) return L' '; // by default space char used
         return str[0];
        }
};




template <>
struct primitive<bool>
{
    static const bool allowEmptyInput = false;
    static ::sixml::util::tstring to_string(const bool &b, const ::sixml::util::tstring &attrOrTagName)
        {
         //return b ? _T("true") : _T("false");
         return b ? _T("1") : _T("0");
        }
    static bool from_string(const ::sixml::util::tstring &_s, const ::sixml::util::tstring &attrOrTagName)
        {
         ::sixml::util::tstring s = ::sixml::util::lowerCopy(::sixml::util::trim_copy(_s));
         if (s==_T("true")) return true;
         else if (s==_T("1")) return true;
         else if (s==_T("yes")) return true;
         else if (s==_T("false")) return false;
         else if (s==_T("0")) return false;
         else if (s==_T("no")) return false;
         /*
         if (sixml::util::EqualCI(s, _T("true"))) return true;
         else if (sixml::util::EqualCI(s, _T("1"))) return true;
         else if (sixml::util::EqualCI(s, _T("yes"))) return true;
         else if (sixml::util::EqualCI(s, _T("false"))) return false;
         else if (sixml::util::EqualCI(s, _T("0"))) return false;
         else if (sixml::util::EqualCI(s, _T("no"))) return false;
         */
         sixml::throw_num_format_error( s, _T("bool"), attrOrTagName );
         return true;
        }
};

template <>
struct primitive<float>
{
    static const bool allowEmptyInput = false;
    static ::sixml::util::tstring to_string(const float& f, const ::sixml::util::tstring &attrOrTagName)
        { 
         if (f>=  ::std::numeric_limits<float>::infinity())
            return _T("+INF");
         if (f<= -::std::numeric_limits<float>::infinity())
            return _T("-INF");
         if (f!=f)
            return _T("NAN");

         return sixml::util::FtoT(f, attrOrTagName);
        }

    static float from_string(const ::sixml::util::tstring& _s, const ::sixml::util::tstring &attrOrTagName)
       { 
        ::sixml::util::tstring s = ::sixml::util::upperCopy(_s);
        if (s==_T("+INF") || s==_T("INF")) return ::std::numeric_limits<float>::infinity();
        if (s==_T("-INF")) return -::std::numeric_limits<float>::infinity();
        if (s==_T("SNAN")) return ::std::numeric_limits<float>::signaling_NaN();
        if (s==_T("NAN") || s==_T("QNAN")) return ::std::numeric_limits<float>::quiet_NaN();
        
        double d = sixml::util::tstringtod(::sixml::util::trim_copy(s), _T("float"), attrOrTagName);
        /*
        if (d > ::std::numeric_limits<float>::max())
           return ::std::numeric_limits<float>::infinity();
        if (d < ::std::numeric_limits<float>::min())
           return -::std::numeric_limits<float>::infinity();
        */
        if (d > ::std::numeric_limits<float>::max())
           sixml::throw_num_format_range_overflow(s,_T("float"), attrOrTagName);
        if (d < ::std::numeric_limits<float>::min())
           sixml::throw_num_format_range_underflow(s,_T("float"), attrOrTagName);
        return (float)d;
    }
};
//----------------------------------------------------------)

template <>
struct primitive<double>
{
    static const bool allowEmptyInput = false;
    static ::sixml::util::tstring to_string(const double& f, const ::sixml::util::tstring &attrOrTagName)
       { 
        if (f>=  ::std::numeric_limits<double>::infinity())
           return _T("+INF");
        if (f<= -::std::numeric_limits<double>::infinity())
           return _T("-INF");
        if (f!=f)
           return _T("NAN");
        return sixml::util::FtoT(f, attrOrTagName);
       }

    static double from_string(const ::sixml::util::tstring& _s, const ::sixml::util::tstring &attrOrTagName)
       {
        ::sixml::util::tstring s = ::sixml::util::upperCopy(_s);
        if (s==_T("+INF") || s==_T("INF")) return ::std::numeric_limits<double>::infinity();
        if (s==_T("-INF")) return -::std::numeric_limits<double>::infinity();
        if (s==_T("SNAN")) return ::std::numeric_limits<double>::signaling_NaN();
        if (s==_T("NAN") || s==_T("QNAN")) return ::std::numeric_limits<double>::quiet_NaN();

        return sixml::util::tstringtod( ::sixml::util::trim_copy(s), _T("double"), attrOrTagName);/*_tstof(s.c_str());*/
       }
};
//----------------------------------------------------------)

template <>
struct primitive< sixml::serializer::types::colorref_t >
{
    static const bool allowEmptyInput = false;
    static ::sixml::util::tstring to_string(const sixml::serializer::types::colorref_t& c, const ::sixml::util::tstring &attrOrTagName)
       {
        ::cli::CiVariant v(cliGetVariant(), true);
        if (!v) return ::sixml::util::tstring();

        v.setColorref(c);
        ::std::wstring strColorref;
        v.getString(strColorref);
        return MARTY_CON::toTstr(strColorref);
       }

    static sixml::serializer::types::colorref_t from_string(const ::sixml::util::tstring& _s, const ::sixml::util::tstring &attrOrTagName)
       {
        ::cli::CiVariant v(cliGetVariant(), true);
        if (!v) return sixml::serializer::types::colorref_t();

        v.setString(MARTY_CON::strToWide(_s));
        sixml::serializer::types::colorref_t c;
        v.getColorref(&c.value);
        return c;
       }
};
//----------------------------------------------------------)






/*
template <>
struct primitive<int>
{
    static tstring to_string(const Type &v)
        {
         tchar buf[128];
         _itot(v, buf, 10);
         return tstring(buf);         
        }
    static Type from_string(const tstring &s)
        {
         return _ttoi(s.c_str());
        }
};
*/



// UNDONE


template <typename EnumType>
struct enum_meta_data 
{
protected:
    typedef std::map<EnumType, ::sixml::util::tstring> NameMap;
    typedef std::map< ::sixml::util::tstring, EnumType> ValueMap;

    virtual const TCHAR *getEnumTypeName() const = 0 ;

public:
    ::sixml::util::tstring to_string(EnumType e, const ::sixml::util::tstring &attrOrTagName) const
    {
        typename NameMap::const_iterator it = names.find(e);
        //ASSERT(it != names.end());
        if (it == names.end())
           sixml::throw_not_enum_member( (UINT64)e, getEnumTypeName(), attrOrTagName );
        return it->second;
    }

    EnumType from_string(const ::sixml::util::tstring& name, const ::sixml::util::tstring &attrOrTagName) const
    {
        typename ValueMap::const_iterator it = values.find(::sixml::util::trim_copy(name));
        /*ValueMap::const_iterator it = values.find(Upper(name));*/
        if (it == values.end())
           {
            sixml::throw_unknown_enum_value( name, getEnumTypeName(), attrOrTagName );
           }    
        return it->second;
    }
protected:
/*
    void enumerate(const tstring& name, EnumType e)
    {
        tstring stdName = Upper(name);
        values[stdName] = e;
        names [e] = stdName;
*/
    void enumerate(EnumType e, const ::sixml::util::tstring& name)
    {
     values[name] = e;
     names [e] = name;
    }

    void enumerate( EnumType e, 
                    const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2)
    {
     values[name1] = e; values[name2] = e;
     names [e] = name1;
    }

    void enumerate( EnumType e, 
                    const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2, const ::sixml::util::tstring& name3)
    {
     values[name1] = e; values[name2] = e; values[name3] = e;
     names [e] = name1;
    }

    void enumerate( EnumType e, 
                    const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2, const ::sixml::util::tstring& name3,
                    const ::sixml::util::tstring& name4)
    {
     values[name1] = e; values[name2] = e; values[name3] = e;
     values[name4] = e;
     names [e] = name1;
    }

    void enumerate( EnumType e, 
                    const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2, const ::sixml::util::tstring& name3,
                    const ::sixml::util::tstring& name4, const ::sixml::util::tstring& name5)
    {
     values[name1] = e; values[name2] = e; values[name3] = e;
     values[name4] = e; values[name5] = e;
     names [e] = name1;
    }

    void enumerate( EnumType e, 
                    const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2, const ::sixml::util::tstring& name3,
                    const ::sixml::util::tstring& name4, const ::sixml::util::tstring& name5, const ::sixml::util::tstring& name6)
    {
     values[name1] = e; values[name2] = e; values[name3] = e;
     values[name4] = e; values[name5] = e; values[name6] = e;
     names [e] = name1;
    }

    void enumerate( EnumType e, 
                    const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2, const ::sixml::util::tstring& name3,
                    const ::sixml::util::tstring& name4, const ::sixml::util::tstring& name5, const ::sixml::util::tstring& name6,
                    const ::sixml::util::tstring& name7)
    {
     values[name1] = e; values[name2] = e; values[name3] = e;
     values[name4] = e; values[name5] = e; values[name6] = e;
     values[name7] = e;
     names [e] = name1;
    }

    void enumerate( EnumType e, 
                    const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2, const ::sixml::util::tstring& name3,
                    const ::sixml::util::tstring& name4, const ::sixml::util::tstring& name5, const ::sixml::util::tstring& name6,
                    const ::sixml::util::tstring& name7, const ::sixml::util::tstring& name8)
    {
     values[name1] = e; values[name2] = e; values[name3] = e;
     values[name4] = e; values[name5] = e; values[name6] = e;
     values[name7] = e; values[name8] = e;
     names [e] = name1;
    }

    void enumerate( EnumType e, 
                    const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2, const ::sixml::util::tstring& name3,
                    const ::sixml::util::tstring& name4, const ::sixml::util::tstring& name5, const ::sixml::util::tstring& name6,
                    const ::sixml::util::tstring& name7, const ::sixml::util::tstring& name8, const ::sixml::util::tstring& name9)
    {
     values[name1] = e; values[name2] = e; values[name3] = e;
     values[name4] = e; values[name5] = e; values[name6] = e;
     values[name7] = e; values[name8] = e; values[name9] = e;
     names [e] = name1;
    }


    ValueMap values;
    NameMap  names;
};


//-------------------------------------------------------------------
#define ENUM_METADATA(EnumType, EnumMetaData) \
 \
namespace sixml{      \
namespace serializer{ \
                      \
static const EnumMetaData& EnumData_Instance_##EnumMetaData(void) \
{ \
    static EnumMetaData _; \
    return _; \
} \
 \
template <> \
struct  /* ::sixml::serializer:: */ primitive< EnumType > \
{ \
    static const bool allowEmptyInput = false;                  \
    static ::sixml::util::tstring to_string(const EnumType& e, const ::sixml::util::tstring &attrOrTagName)  \
    { return EnumData_Instance_##EnumMetaData().to_string(e, attrOrTagName); } \
 \
    static EnumType from_string(const ::sixml::util::tstring& s, const ::sixml::util::tstring &attrOrTagName) \
    {  return EnumData_Instance_##EnumMetaData().from_string(s, attrOrTagName);  } \
}; /* struct primitive< EnumType > */ \
 \
/*!!!*/\
template <> /* if static disabled, that cause linker error - duplicate symbol */ \
 static /*!!!*/ const ::sixml::serializer::meta_class< EnumType >& default_meta_class< EnumType >() \
    { static ::sixml::serializer::prim_meta_class< EnumType > _; return _; } \
}; /* namespace serializer */ \
}; /* namespace sixml */
//---------------------------------
#define BEGIN_ENUM_META_DATA(enum_type)  \
struct _EnumMetaData_##enum_type         \
     : public ::sixml::serializer::enum_meta_data< enum_type >  \
{                                        \
    const TCHAR *getEnumTypeName() const \
       {                                 \
        return _T(#enum_type);           \
       }                                 \
                                         \
    _EnumMetaData_##enum_type()          \
    {
//---------------------------------
#define END_ENUM_META_DATA(enum_type)    \
    }                                    \
};                                       \
ENUM_METADATA(enum_type, _EnumMetaData_##enum_type)
//-------------------------------------------------------------------




//-------------------------------------------------------------------
#define ENUM_METADATA_NS1(ns1, EnumType, EnumMetaData) \
 \
namespace sixml{      \
namespace serializer{ \
                      \
static const EnumMetaData& EnumData_Instance_##EnumMetaData(void) \
{ \
    static EnumMetaData _; \
    return _; \
} \
 \
template <> \
struct  /* ::sixml::serializer:: */ primitive<ns1:: EnumType> \
{ \
    static ::sixml::util::tstring to_string(const ns1:: EnumType& e, const ::sixml::util::tstring &attrOrTagName) \
    { return EnumData_Instance_##EnumMetaData().to_string(e, attrOrTagName); } \
 \
    static ns1:: EnumType from_string(const ::sixml::util::tstring& s, const ::sixml::util::tstring &attrOrTagName) \
    {  return EnumData_Instance_##EnumMetaData().from_string(s, attrOrTagName);  } \
};  /* template <> struct primitive<ns1:: EnumType> */  \
 \
template <> \
static const ::sixml::serializer::meta_class<ns1:: EnumType>& default_meta_class<ns1:: EnumType>() \
    { static ::sixml::serializer::prim_meta_class<ns1:: EnumType> _; return _; } \
}; /* namespace serializer */ \
}; /* namespace sixml */
//---------------------------------
#define BEGIN_ENUM_META_DATA_NS1(ns1, enum_type)  \
struct _EnumMetaData_##ns1##_##enum_type         \
     : public ::sixml::serializer::enum_meta_data<ns1:: enum_type>  \
{                                        \
    _EnumMetaData_##ns1##_##enum_type()          \
    {
//---------------------------------
#define END_ENUM_META_DATA_NS1(ns1, enum_type)    \
    }                                    \
};                                       \
ENUM_METADATA_NS1(ns1, enum_type, _EnumMetaData_##ns1##_##enum_type)
//-------------------------------------------------------------------







template <typename IntType>
struct flags_meta_data 
{
protected:
    typedef std::map<IntType, ::sixml::util::tstring> NameMap;
    typedef std::map< ::sixml::util::tstring, IntType> ValueMap;

public:

    virtual const TCHAR *getFlagsTypeName() const = 0 ;

    ::sixml::util::tstring to_string_aux(sixml::serializer::types::flags_t<IntType> e, const ::sixml::util::tstring& separator, const ::sixml::util::tstring& attrOrTagName) const
    {
        if (e==0) return ::sixml::util::tstring(_T("0"));

        size_t size = sizeof(e)*CHAR_BIT;
        IntType mask = 1;
        //size_t i;
        //for (i=0; i<size-1; i++) mask<<=1;
        //CLIASSERT(mask);
        ::sixml::util::tstring res;
        //for(size_t i=0; i<size; i++, mask>>=1)
        for(size_t i=0; i<size && mask; i++, mask<<=1)
           {
            IntType val = e&mask;
            if (!val) continue;
            typename NameMap::const_iterator it = names.find(val);
            //ASSERT(it != names.end());
            if (!res.empty()) res.append(separator);
            if (it != names.end())
               res.append(it->second);
            else
               sixml::throw_not_flag(val, getFlagsTypeName(), attrOrTagName );
               //sixml::throw_unknown_flag_value(val, getFlagsTypeName() );
           }
        return res;
    }

    ::sixml::util::tstring to_string(sixml::serializer::types::flags_t<IntType> e, const ::sixml::util::tstring &attrOrTagName) const
    {
     return to_string_aux(e, _T("|"), attrOrTagName);
    }

    sixml::serializer::types::flags_t<IntType> from_string(const ::sixml::util::tstring& n, const ::sixml::util::tstring &attrOrTagName) const
    {
        if (::sixml::util::trim_copy(n)==_T("0")) return sixml::serializer::types::flags_t<IntType>(0);
        std::vector< ::sixml::util::tstring> str_flags;
        ::sixml::util::tstring name = n;
        std::for_each(name.begin(), name.end(), replace_to_comma());

        sixml::util::split_string(str_flags, name, _T(','));
        sixml::serializer::types::flags_t<IntType> res = 0;
        std::vector< ::sixml::util::tstring>::iterator it = str_flags.begin();
        for (; it!=str_flags.end(); it++)
            {
             ::sixml::util::trim(*it);
             typename ValueMap::const_iterator vit = values.find(*it);
             if (vit == values.end())
                {
                 throw_unknown_flag_value(*it, getFlagsTypeName(), attrOrTagName);
                 //sixml::throw_not_flag(*it, getFlagsTypeName() );
                }
             res |= vit->second;
            }
        return res;
    }

    struct replace_to_comma
    {
           replace_to_comma() {};
           void operator() (TCHAR &ch)
           {
            if (ch==_T(';') || ch==_T('|') || ch==_T('+')) ch = _T(',');
           }

    };

protected:

    void flag( const sixml::serializer::types::flags_t<IntType> &e, const ::sixml::util::tstring& name)
    {
     values[name] = e;
     names [e] = name;
    }

    void flag( const sixml::serializer::types::flags_t<IntType> &e, 
               const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2)
    {
     values[name1] = e; values[name2] = e;
     names [e] = name1;
    }

    void flag( const sixml::serializer::types::flags_t<IntType> &e, 
               const ::sixml::util::tstring& name1, const ::sixml::util::tstring& name2, const ::sixml::util::tstring& name3)
    {
     values[name1] = e; values[name2] = e; values[name3] = e;
     names [e] = name1;
    }

    ValueMap values;
    NameMap  names;
};




#define DECLARE_FLAGS_TYPE(type_name, pod_type)                                                \
                                                                                               \
struct type_name : public sixml::serializer::types::flags_t< pod_type >                        \
{                                                                                              \
    typedef sixml::serializer::types::flags_t< pod_type > base_flags_t;                        \
    typedef base_flags_t::int_type                        int_type;                            \
                                                                                               \
    /* ������������ */                                                                         \
    type_name() : base_flags_t() {}                                                            \
    type_name(const type_name& t) : base_flags_t(t) {}                                         \
    type_name(const base_flags_t& t) : base_flags_t(t) {}                                      \
    type_name( pod_type t) : base_flags_t(t) {}                                                \
                                                                                               \
    /* ��������� */                                                                            \
    /* ���������� ���� */                                                                      \
    operator pod_type () const { return m_f; }                                                 \
    operator base_flags_t () const { return type_name(base_flags_t(m_f)); }                    \
                                                                                               \
    /* ������������ */                                                                         \
    type_name& operator =(const pod_type f)   { base_flags_t::operator=(f) ; return *this; }   \
    type_name& operator =(const base_flags_t &ft)  { base_flags_t::operator=(ft); return *this; }   \
                                                                                               \
    /* �������������� */                                                                       \
    type_name& operator +=(const pod_type f)   { base_flags_t::operator+=(f); return *this; }  \
    /* type_name& operator +=(const base_flags_t f)   { base_flags_t::operator+=(f); } */           \
    /* IntType  operator +(const IntType f)     const { return (m_f+f); }                */    \
    /* IntType  operator +(const base_flags_t &ft)   const { return (m_f+ft.m_f); }           */    \
    /* friend IntType operator +(const IntType f, const base_flags_t<IntType> &ft)            */    \
    /*       { return (f+ft.m_f); }                                                      */    \
                                                                                               \
    type_name& operator ++()    { m_f++; return *this; }                                       \
    pod_type  operator ++(int)   { base_flags_t tmp(*this); m_f++; return tmp; }                    \
                                                                                               \
    type_name& operator -=(const pod_type f)  { base_flags_t::operator-=(f); return *this; }   \
    /* base_flags_t& operator -=(const base_flags_t &ft)        { m_f -= ft.m_f; return (*this); } */    \
    /* IntType  operator -(const IntType f)     const { return (m_f-f); }                */    \
    /* IntType  operator -(const base_flags_t &ft)   const { return (m_f-ft.m_f); }           */    \
    /* friend IntType operator -(const IntType f, const base_flags_t<IntType> &ft)            */    \
    /*        { return (f-ft.m_f); }                                                     */    \
    type_name& operator --()    { m_f--; return *this; }                                       \
    pod_type   operator --(int) { base_flags_t tmp(*this); m_f--; return tmp; }                     \
                                                                                               \
    type_name& operator *=(const pod_type f)          { base_flags_t::operator*=(f); return *this; } \
    /* base_flags_t& operator *=(const base_flags_t &ft)        { m_f *= ft.m_f; return (*this); } */    \
    /* IntType  operator *(const IntType f)     const { return (m_f*f); }                */    \
    /* IntType  operator *(const base_flags_t &ft)   const { return (m_f*ft.m_f); }           */    \
    /* friend IntType operator *(const IntType f, const base_flags_t<IntType> &ft)            */    \
    /*        { return (f*ft.m_f); }                                                     */    \
                                                                                               \
    type_name& operator /=(const pod_type f)          { base_flags_t::operator/=(f); return *this; } \
    /* base_flags_t& operator /=(const base_flags_t &ft)        { m_f /= ft.m_f; return (*this); }  */   \
    /* IntType  operator /(const IntType f)     const { return (m_f/f); }                 */   \
    /* IntType  operator /(const base_flags_t &ft)   const { return (m_f/ft.m_f); }            */   \
    /* friend IntType operator +(const IntType f, const base_flags_t<IntType> &ft)             */   \
    /*        { return (f/ft.m_f); }                                                      */   \
                                                                                               \
    type_name& operator %=(const pod_type f)          { base_flags_t::operator%=(f); return *this; } \
    /* base_flags_t& operator %=(const base_flags_t &ft)        { m_f %= ft.m_f; return (*this); }   */  \
    /* IntType  operator %(const IntType f)     const { return (m_f%f); }                  */  \
    /* IntType  operator %(const base_flags_t &ft)   const { return (m_f%ft.m_f); }             */  \
    /* friend IntType operator +(const IntType f, const base_flags_t<IntType> &ft)              */  \
    /*        { return (f%ft.m_f); }                                                       */  \
                                                                                               \
    /* ���������� */                                                                           \
    /*bool operator !() const { return m_f ? true : false; }; */                               \
                                                                                               \
    /* ��������� */                                                                            \
    pod_type operator~() const { return ~m_f; }                                                \
    type_name& operator <<=(const pod_type f)  { m_f <<= f; return (*this); }                  \
    type_name& operator >>=(const pod_type f)  { m_f >>= f; return (*this); }                  \
    type_name& operator &=(const pod_type f)  { m_f &= f; return (*this); }                    \
    type_name& operator ^=(const pod_type f)  { m_f ^= f; return (*this); }                    \
    type_name& operator |=(const pod_type f)  { m_f |= f; return (*this); }                    \
                                                                                               \
};



#define FLAGS_METADATA(FlagsType, FlagsMetaData) \
 \
namespace sixml{            \
                            \
namespace serializer{       \
                            \
static const FlagsMetaData& FlagsData_Instance_##FlagsMetaData(void) \
{                           \
    static FlagsMetaData _; \
    return _;               \
}                           \
                            \
template <>                 \
struct  /* sixml::serializer:: */ primitive< FlagsType > \
{                                                        \
     static const bool allowEmptyInput = false;          \
    /*static ::sixml::util::tstring to_string  (const FlagsType& e, const ::sixml::util::tstring &attrOrTagName);*/ \
    /*static FlagsType              from_string(const ::sixml::util::tstring& s, const ::sixml::util::tstring &attrOrTagName);*/ \
    static ::sixml::util::tstring to_string  (const FlagsType& e, const ::sixml::util::tstring &attrOrTagName)   \
    { return FlagsData_Instance_##FlagsMetaData().to_string(e,attrOrTagName); }                                \
    static FlagsType              from_string(const ::sixml::util::tstring& s, const ::sixml::util::tstring &attrOrTagName) \
    {  return FlagsData_Instance_##FlagsMetaData().from_string(s,attrOrTagName);  }                            \
};  /* template <> struct primitive< FlagsType >  */                          \
/*                                                                              \
template <> \
::sixml::util::tstring primitive< FlagsType > :: to_string  (const FlagsType& e, const ::sixml::util::tstring &attrOrTagName)   \
{ return FlagsData_Instance_##FlagsMetaData().to_string(e,attrOrTagName); }                                \
                                                                                                           \
template <> \
FlagsType              primitive< FlagsType > :: from_string(const ::sixml::util::tstring& s, const ::sixml::util::tstring &attrOrTagName) \
{  return FlagsData_Instance_##FlagsMetaData().from_string(s,attrOrTagName);  }                            \
*/                                                                              \
template <> /* if static disabled, that cause linker error - duplicate symbol */  \
static const sixml::serializer::meta_class< FlagsType >&                      \
default_meta_class< FlagsType >()                   \
    { static sixml::serializer::prim_meta_class< FlagsType > _; return _; }   \
                                                                              \
}; /* namespace serializer */                                                 \
}; /* namespace sixml */


#define BEGIN_FLAGS_META_DATA(flags_type)  \
struct _FlagsMetaData_##flags_type         \
     : public sixml::serializer::flags_meta_data< flags_type :: int_type >  \
{                                          \
    const TCHAR *getFlagsTypeName() const  \
       {                                   \
        return _T( #flags_type );          \
       }                                   \
                                           \
    _FlagsMetaData_##flags_type()          \
    {


#define END_FLAGS_META_DATA(flags_type)    \
    }                                    \
};                                       \
FLAGS_METADATA(flags_type, _FlagsMetaData_##flags_type)



}; // namespace serializer

}; // namespace sixml


#ifdef CLI_XML_SIXML_PRIM_RESTORE_WIN__MAX /*max*/
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifdef CLI_XML_SIXML_PRIM_RESTORE_WIN_MIN /*min*/
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif




#endif /* CLI_XML_SIXML_PRIM_H */

