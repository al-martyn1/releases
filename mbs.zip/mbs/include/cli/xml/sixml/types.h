#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_TYPES_H
#define CLI_XML_SIXML_TYPES_H

/* add this lines to your scr
#ifndef CLI_XML_SIXML_TYPES_H
    #include <cli/xml/sixml/types.h>
#endif
*/

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_XML_SIXML_NODEHELPERS_H
    #include <cli/xml/sixml/nodeHelpers.h>
#endif

#ifndef CLI_XML_SIXML_PRIMUTIL_H
    #include <cli/xml/sixml/primutil.h>
#endif

#ifndef CLI_XML_SIXML_PRIM_H
    #include <cli/xml/sixml/prim.h>
#endif

#endif /* CLI_XML_SIXML_TYPES_H */

