#ifdef USE_TINY_XML
    #ifndef TIXML_USE_STL
        #include <cli/xml/sixml/tinyxml/tinystr.cpp>
    #endif
    #include <cli/xml/sixml/tinyxml/tinyxml.cpp>
    #include <cli/xml/sixml/tinyxml/tinyxmlerror.cpp>
    #include <cli/xml/sixml/tinyxml/tinyxmlparser.cpp>    
#else
    #include <cli/xml/sixml/pugixml/pugixml.cpp>
#endif


