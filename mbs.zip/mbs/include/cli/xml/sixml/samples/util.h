#ifndef UTIL_H
#define UTIL_H
#include <iostream>
#include <fstream>
#include <string>

namespace util
{

inline
::std::string normalizeInputLinefeeds( const ::std::string &str)
   {
    //return str;
    ::std::string res;
    res.reserve(str.size());
    ::std::string::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        if (str[i]=='\r') continue;
        res.append(1,str[i]);
       }
    return res;
   }

inline
::std::string readfile( ::std::istream &in )
   {
    ::std::string resultString;
    if (!in) return resultString;
    char buf[4096];
    //while(!!in.read( &buf[0], sizeof(buf)))
    do
       {
        in.read( &buf[0], sizeof(buf));
        resultString.append( &buf[0], in.gcount( ) );
       } while(in);
    //return resultString; //normalizeInputLinefeeds(resultString);
    return normalizeInputLinefeeds(resultString);
   }

inline
::std::string readfile( const char* fileName )
   {
    ::std::ifstream in(fileName);
    return readfile(in);
   }

inline
::std::string readfile( const ::std::string &fileName )
   {
    return readfile(fileName.c_str());
   }

inline
void writefile( ::std::ostream &out, const ::std::string &data)
   {
    out.write( data.data(), data.size() );
   }

inline
void writefile( const char* fileName, const ::std::string &data)
   {
    ::std::ofstream out(fileName);
    writefile( out, data );
   }

inline
void writefile( const ::std::string &fileName, const ::std::string &data)
   {
    writefile( fileName.c_str(), data );
   }

}; // namespace util

#endif
