#ifndef XMLIMPL_H
#define XMLIMPL_H

#ifdef USE_TINY_XML
    #define XML_ENGINE_NAME "tinyxml"
    #include <cli/xml/sixml/tinyxml/serializer.h>
#else
    #define XML_ENGINE_NAME "pugixml"
    #include <cli/xml/sixml/pugixml/serializer.h>
#endif

#endif // XMLIMPL_H