#include <string>
#include <vector>
#include <cli/clicmdline.h>
#include <cli/cliexcept.h>

#include "util.h"
#include "xmlimpl.h"



struct CPlatformInfo
{
    ::std::string platformName;

    STRUCT_LAYOUT_DEFAULT(CPlatformInfo)
    attribute(_T("Name"), &CPlatformInfo::platformName ); // mandatory
    END_STRUCT_LAYOUT()
};

struct CToolInfo
{
    ::std::string   Name;
    STRUCT_LAYOUT_DEFAULT(CToolInfo)
    attribute(_T("Name"), &CToolInfo::Name ); // mandatory
    END_STRUCT_LAYOUT()
};


struct CProjectConfiguration
{
    ::std::string   Name;
    ::std::string   OutputDirectory;
    ::std::string   IntermediateDirectory;
    ::std::string   ConfigurationType;
    //::std::string   CharacterSet;
    unsigned        CharacterSet;
    ::std::vector<CToolInfo> tools;

    STRUCT_LAYOUT_DEFAULT(CProjectConfiguration)
    attribute(_T("Name")                 , &CProjectConfiguration::Name ); // mandatory
    attribute(_T("OutputDirectory")      , &CProjectConfiguration::OutputDirectory, ::std::string() );
    attribute(_T("IntermediateDirectory"), &CProjectConfiguration::IntermediateDirectory, ::std::string() );
    attribute(_T("ConfigurationType")    , &CProjectConfiguration::ConfigurationType, ::std::string() );
    attribute(_T("CharacterSet")         , &CProjectConfiguration::CharacterSet, unsigned(0) );
    array    (0                          , &CProjectConfiguration::tools, _T("Tool") );
    END_STRUCT_LAYOUT()
}; // CProjectConfiguration


struct CFile
{
    ::std::string      RelativePath;
    STRUCT_LAYOUT_DEFAULT(CFile)
    attribute(_T("RelativePath") , &CFile::RelativePath ); // mandatory
    END_STRUCT_LAYOUT()
}; // struct CFile


struct CFies;

struct CFilter
{
    ::std::string                        Name;
    ::std::vector< ::std::string >       Filter;
    ::std::string                        UniqueIdentifier;
    ::std::vector< CFile >               Files;
    ::std::vector< CFilter >             Filters;

    STRUCT_LAYOUT_DEFAULT(CFilter)
    attribute(_T("Name")                 , &CFilter::Name ); // mandatory
    array_attribute(_T("Filter")         , &CFilter::Filter );
    attribute(_T("UniqueIdentifier")     , &CFilter::UniqueIdentifier, ::std::string() );
    array    ( 0                         , &CFilter::Files, _T("File") );
    array    ( 0                         , &CFilter::Filters, _T("Filter") );
    END_STRUCT_LAYOUT()
};

struct CFiles
{
    ::std::vector< CFile >               Files;
    ::std::vector< CFilter >             Filters;
    CFiles() : Files(), Filters() {}

    STRUCT_LAYOUT_DEFAULT(CFiles)
    array    ( 0                         , &CFiles::Files, _T("File") );
    array    ( 0                         , &CFiles::Filters, _T("Filter") );
    END_STRUCT_LAYOUT()
};


struct CVisualStudioProjectsType1
{
    ::std::vector<CPlatformInfo>            platforms;
    ::std::vector<CProjectConfiguration>    configurations;
    CFiles                                  Files;

    STRUCT_LAYOUT_DEFAULT(CVisualStudioProjectsType1)
    array(_T("Platforms")         , &CVisualStudioProjectsType1::platforms, _T("Platform") );
    array(_T("Configurations")    , &CVisualStudioProjectsType1::configurations, _T("Configuration") );
    complex( _T("Files")          , &CVisualStudioProjectsType1::Files, CFiles() ); // optional
    END_STRUCT_LAYOUT()

    INLINE_SIXML_SIMPLE_LOAD_METHOD( load, "VisualStudioProject" )
    INLINE_SIXML_SIMPLE_SAVE_METHOD( save, "VisualStudioProject" )

};

struct CPlatformsInfo
{
    ::std::vector<CPlatformInfo>    platforms;
    CPlatformsInfo() : platforms() {}

    STRUCT_LAYOUT_DEFAULT(CPlatformsInfo)
    array( 0 /* no array tag */, &CPlatformsInfo::platforms, _T("Platform") );
    END_STRUCT_LAYOUT()
};

struct CConfigurations
{
    ::std::vector<CProjectConfiguration>    configurations;
    CConfigurations() : configurations() {}

    STRUCT_LAYOUT_DEFAULT(CConfigurations)
    array( 0, &CConfigurations::configurations, _T("Configuration") );
    END_STRUCT_LAYOUT()
};


struct CVisualStudioProjectsType2
{
    CPlatformsInfo                  platformsInfo;
    CConfigurations                 configurations;
    CFiles                                  Files;

    STRUCT_LAYOUT_DEFAULT(CVisualStudioProjectsType2)
    complex( _T("Platforms")     , &CVisualStudioProjectsType2::platformsInfo , CPlatformsInfo()  ); // optional
    complex( _T("Configurations"), &CVisualStudioProjectsType2::configurations, CConfigurations() ); // optional
    complex( _T("Files")         , &CVisualStudioProjectsType2::Files, CFiles() ); // optional
    END_STRUCT_LAYOUT()

    INLINE_SIXML_SIMPLE_LOAD_METHOD( load, "VisualStudioProject" )
    INLINE_SIXML_SIMPLE_SAVE_METHOD( save, "VisualStudioProject" )

};


CLI_MAIN( /* argList */ ) // argList - command line arguments
   {
    std::cout<<"Used "<< XML_ENGINE_NAME << " engine\n";
    RCODE res;
    ::std::string vcprojXml = util::readfile( "data\\sample01.vcproj" );
    #ifdef VERBOSE
    std::cout<<"Readed "<< (unsigned)vcprojXml.size() <<" bytes\n";
    #endif

    //util::writefile( std::cout, vcprojXml );

    CVisualStudioProjectsType1 type1;
    res = type1.load( vcprojXml );   if (res) return res;

    #ifdef VERBOSE
    std::cout<<"Type1 loaded\n";
    #endif
    ::std::string type1Xml;
    res = type1.save( type1Xml );    if (res) return res;
    #ifdef VERBOSE
    std::cout<<"Type1 saved\n";
    #endif
    util::writefile("vcproj01_01.xml", type1Xml );

    ::std::vector<CProjectConfiguration>::const_iterator prjConfIt = type1.configurations.begin();
    for(; prjConfIt != type1.configurations.end(); ++prjConfIt)
       {
        std::cout<<"Found configuration: "<< prjConfIt->Name<<"\n";
       }

    CVisualStudioProjectsType2 type2;
    res = type2.load( vcprojXml );   if (res) return res;
    #ifdef VERBOSE
    std::cout<<"Type2 loaded\n";
    #endif
    ::std::string type2Xml;
    res = type2.save( type2Xml );    if (res) return res;
    #ifdef VERBOSE
    std::cout<<"Type2 saved\n";
    #endif
    util::writefile("vcproj01_02.xml", type2Xml );

    CVisualStudioProjectsType2 type2_2;
    res = type2_2.load(type1Xml);    if (res) return res;
    #ifdef VERBOSE
    std::cout<<"Type2/2 loaded\n";
    #endif
    ::std::string type2Xml2;
    res = type2_2.save(type2Xml2);   if (res) return res;
    #ifdef VERBOSE
    std::cout<<"Type2/2 saved\n";
    #endif
    util::writefile("vcproj01_02_2.xml", type2Xml2 );

    CVisualStudioProjectsType1 type1_2;
    res = type1_2.load(type2Xml);    if (res) return res;
    #ifdef VERBOSE
    std::cout<<"Type1/2 loaded\n";
    #endif
    ::std::string type1Xml2;
    res = type1_2.save(type1Xml2);   if (res) return res;
    #ifdef VERBOSE
    std::cout<<"Type1/2 saved\n";
    #endif
    util::writefile("vcproj01_01_2.xml", type1Xml2 );

    std::cout<<"All tests passed\n";

    return 0;

   }


