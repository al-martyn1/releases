#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

/* Metaclasses - sixml serializer internal header file
 * Designed by Andrey Martynov
 * mailto:rek@.rsdn.ru
 * Rewritten by Alex Martinov (amart@mail.ru), 2004.
 */
#ifndef CLI_XML_SIXML_METACLAS_H
#define CLI_XML_SIXML_METACLAS_H

namespace sixml{

namespace serializer{


template <typename DataType>
struct meta_class
{
    virtual DataType read_node(INTERFACE_CLI_SIXML_INODE* pNode) const = 0;
    virtual void     read_node(INTERFACE_CLI_SIXML_INODE* pNode, DataType &v ) const = 0;
    virtual void     write_node(INTERFACE_CLI_SIXML_INODE* pNode, const DataType& data) const = 0;
    //virtual void   update_node(i_sixml_node* node, const DataType& data) const = 0;
};


template <typename StructType> struct layout;
template <typename StructType> struct field_attribute;

template <typename PrimType>
struct prim_meta_class
    : public meta_class<PrimType>
{

    void read_node(INTERFACE_CLI_SIXML_INODE* pNode, PrimType &v) const 
       {
        CLIASSERT(pNode);
   
        ::sixml::util::tstring strVal;
        if (::sixml::helpers::readNodeText(pNode, strVal))
           {
            throw_mandatory_field_missing( ::sixml::helpers::getFieldUsedName(pNode, 0), false);
           }
   
        if (!primitive<PrimType>::allowEmptyInput)
           {
            //::sixml::util::tstring strValCopy;
            ::sixml::util::tstring strValCopy = ::sixml::util::trim_copy(strVal);
            //NOTE: trim
            if (strValCopy.empty())
               {
                throw_mandatory_field_missing( ::sixml::helpers::getFieldUsedName(pNode, 0), false);
               }
           }
   
        v =  primitive<PrimType>::from_string( strVal, ::sixml::helpers::getFieldUsedName(pNode, 0, false) ); 
   
        /*
        CLIASSERT(node);
        ::sixml::util::tstring strVal; // = node->get_all_text();
   
        if (!node->getText( strVal ))
           {
            ::sixml::util::tstring usedFieldName;
            node->getName( usedFieldName );
            throw_mandatory_field_missing(usedFieldName, false);
           }
   
        if (!primitive<PrimType>::allowEmptyInput)
           {
            strVal = ::sixml::util::trim_copy(strVal);
            if (strVal.empty())
               {
                ::sixml::util::tstring usedFieldName;
                node->getName( usedFieldName );
                throw_mandatory_field_missing(usedFieldName, false);
               }
           }     
   
        v =  primitive<PrimType>::from_string( strVal ); 
        */
       }


    PrimType read_node(INTERFACE_CLI_SIXML_INODE* pNode) const 
       {
        CLIASSERT(pNode);
   
        ::sixml::util::tstring strVal;
        if (::sixml::helpers::readNodeText(pNode, strVal))
           {
            throw_mandatory_field_missing( ::sixml::helpers::getFieldUsedName(pNode, 0), false);
           }
   
        if (!primitive<PrimType>::allowEmptyInput)
           {
            //strVal = ::sixml::util::trim_copy(strVal);
            //NOTE: trim
            ::sixml::util::tstring strValCopy = ::sixml::util::trim_copy(strVal);
            if (strValCopy.empty())
               {
                throw_mandatory_field_missing( ::sixml::helpers::getFieldUsedName(pNode, 0), false);
               }
           }
   
        return primitive<PrimType>::from_string( strVal, ::sixml::helpers::getFieldUsedName(pNode, 0, false) ); 

        /*
        CLIASSERT(node);
        ::sixml::util::tstring strVal; // = node->get_all_text();
   
        if (!node->getText( strVal ))
           {
            ::sixml::util::tstring usedFieldName;
            node->getName( usedFieldName );
            throw_mandatory_field_missing(usedFieldName, false);
           }
   
        if (!primitive<PrimType>::allowEmptyInput)
           {
            strVal = ::sixml::util::trim_copy(strVal);
            if (strVal.empty())
               {
                ::sixml::util::tstring usedFieldName;
                node->getName( usedFieldName );
                throw_mandatory_field_missing(usedFieldName, false);
               }
           }     
   
        return primitive<PrimType>::from_string( strVal );
        */
       }

    void write_node(INTERFACE_CLI_SIXML_INODE* pNode, const PrimType& data) const 
       {
        CLIASSERT(pNode);
        ::sixml::helpers::setNodeText( pNode, primitive<PrimType>::to_string(data, ::sixml::helpers::getFieldUsedName(pNode, 0, false)) );
        /*
        CLIASSERT(node);
        //tstring text = primitive<PrimType>::to_string(data);
        //text_set(node, text.c_str());   
        //text_set(node, primitive<PrimType>::to_string(data));
        node->setText( primitive<PrimType>::to_string(data) );
        */
       }
/*/
    void update_node(i_sixml_node* node, const PrimType& data) const 
    {
     CLIASSERT(node);
     tstring text = primitive<PrimType>::to_string(data);
     text_set(node, text.c_str());   
    }
*/
};



template <typename StructType>
struct struct_meta_class
    : public meta_class<StructType>
{
protected:
    const layout<StructType>& m_layout;

public:
    struct_meta_class(const layout<StructType>& l
           /* = DefaultLayout<StructType>()*/)
        : m_layout(l)
    {}

    void read_node(INTERFACE_CLI_SIXML_INODE* pNode, StructType &data) const 
       {
        CLIASSERT(pNode);
        std::for_each(m_layout.begin(), m_layout.end(), read_field(pNode, &data));
       }

    StructType read_node(INTERFACE_CLI_SIXML_INODE* pNode) const 
    {
        CLIASSERT(pNode);
        StructType data;
        std::for_each(m_layout.begin(), m_layout.end(), read_field(pNode, &data));
        return data;
    }

    void write_node(INTERFACE_CLI_SIXML_INODE* pNode, const StructType& data) const 
    {
        CLIASSERT(pNode);
        std::for_each(m_layout.begin(), m_layout.end() , write_field(pNode, data));
    }

protected:

    struct_meta_class& operator=(const struct_meta_class& smc)
    { smc; THROW_CNA(struct_meta_class_is_not_copyable); return *this; }

    struct read_field
       {
        protected:
            INTERFACE_CLI_SIXML_INODE* pNode;
            StructType*                pData;
            read_field& operator=(const read_field& r)
            { r; THROW_CNA(struct_meta_class_is_not_copyable); return *this; }
        public:
            read_field(INTERFACE_CLI_SIXML_INODE* _pNode, StructType* pD) : pNode(_pNode), pData(pD) 
               { CLIASSERT(pNode); }
    
            void operator() (const sixml::util::CPtrShared<field_attribute<StructType> >& pField) 
               { 
                pField->read_field(pNode, pData);
               }
       }; 

    struct write_field
       {
        protected:
            INTERFACE_CLI_SIXML_INODE* pNode;
            const StructType           &data;
            write_field& operator=(const write_field& r)
            { r; THROW_CNA(struct_meta_class_is_not_copyable); return *this; }
        public:
            write_field(INTERFACE_CLI_SIXML_INODE* _pNode, const StructType& d) : pNode(_pNode), data(d) 
               { CLIASSERT(pNode); }
    
            void operator() (const sixml::util::CPtrShared<field_attribute<StructType> >& pField) 
               { 
                pField->write_field(pNode, data);
               }
       }; 

};


template <typename ItemType>
struct vector_meta_class
    : public meta_class<std::vector<ItemType> >
{
protected:
    const TCHAR                 *array_item_name; 
    const meta_class<ItemType>  &item_meta;

public:
    vector_meta_class( const TCHAR* ain, 
                       const meta_class<ItemType>& im)
          : array_item_name(ain), item_meta(im) {};

    void read_node(INTERFACE_CLI_SIXML_INODE* pNode, std::vector<ItemType> &res) const 
       {
        CLIASSERT(pNode);
        CLIASSERT(array_item_name);
        ::std::vector< ::cli::sixml::CiNode > nodes;
        ::sixml::helpers::findTags( nodes, pNode, array_item_name );
        res.clear(); // clear previous data if exist
        res.reserve(nodes.size());
        std::for_each(nodes.begin(), nodes.end(), read_item(res, item_meta));

        /*
        std::vector<i_sixml_node*> nodes;
        //find_tags( nodes, node, array_item_name, false);
        node->findTags( array_item_name, nodes );
        std::for_each(nodes.begin(), nodes.end(), read_item(res, item_meta));
        ::sixml::util::release(nodes);
        */
       }

    std::vector<ItemType> read_node(INTERFACE_CLI_SIXML_INODE* pNode) const 
       {
        CLIASSERT(pNode);
        CLIASSERT(array_item_name);
        ::std::vector< ::cli::sixml::CiNode > nodes;
        ::sixml::helpers::findTags( nodes, pNode, array_item_name );
        std::vector<ItemType> res;
        res.reserve(nodes.size());
        std::for_each(nodes.begin(), nodes.end(), read_item(res, item_meta));
        return res;
        /*
        CLIASSERT(node);
        std::vector<ItemType> res;
        std::vector<i_sixml_node*> nodes;
        //find_tags( nodes, node, array_item_name, false);
        node->findTags( array_item_name, nodes );
        std::for_each(nodes.begin(), nodes.end(), read_item(res, item_meta));
        ::sixml::util::release(nodes);
        return res;
        */
       }

    void write_node(INTERFACE_CLI_SIXML_INODE* pNode, const std::vector<ItemType> &vec) const 
       {
        CLIASSERT(pNode);
        CLIASSERT(array_item_name);
        std::for_each( vec.begin(), vec.end(), 
                       write_item(pNode, array_item_name, item_meta));
        /*
        CLIASSERT(node);
        std::for_each( vec.begin(), vec.end(), 
                       write_item(node, array_item_name, item_meta));
        */
       }

protected:

    vector_meta_class& operator=(const vector_meta_class &v)
        { v; THROW_CNA(vector_meta_class_is_not_copyable); return *this; }

    struct read_item
       {
        protected:
            std::vector<ItemType>       &vec;
            const meta_class<ItemType>  &item_meta;
            read_item& operator=(const read_item &r) { r; THROW_CNA(vector_meta_class_is_not_copyable); return *this; }

        public:
            read_item( std::vector<ItemType> &v, const meta_class<ItemType>& im) 
               : vec(v), item_meta(im) {};
            void operator() (INTERFACE_CLI_SIXML_INODE* pNode) 
                { 
                 vec.push_back(item_meta.read_node(pNode)); 
                };
            void operator() ( ::cli::sixml::CiNode &node) 
                { 
                 vec.push_back(item_meta.read_node(node.getIfPtr())); 
                };
       }; 

    struct write_item
       {
        protected:
            const TCHAR                 *array_item_name; 
            INTERFACE_CLI_SIXML_INODE   *pNode;
            const meta_class<ItemType>  &item_meta;
            write_item& operator=(const write_item &w) { w; THROW_CNA(vector_meta_class_is_not_copyable); return *this; }

        public:
            write_item( INTERFACE_CLI_SIXML_INODE* _pNode, 
                        const TCHAR *ain,
                        const meta_class<ItemType>& im)
                      : array_item_name(ain), pNode(_pNode), item_meta(im) { CLIASSERT(pNode); };
    
            void operator() (const ItemType &i) 
                {
                 //CLIASSERT(array_item_name);
                 ::cli::sixml::CiNode node;
                 if (::sixml::helpers::createNode( node, pNode, array_item_name ) || !node) return ;
                 item_meta.write_node(node.getIfPtr(), i);
                 /*
                 i_sixml_node* ncn = node->createChild(array_item_name);
                 if (ncn) item_meta.write_node(ncn, i);
                 ncn->release();
                 */
                };
       };
};



template <typename PrimType>
struct attribute_vector_meta_class
    : public meta_class<std::vector<PrimType> >
{
protected:
    const TCHAR                 *attr_name; 
    const TCHAR                 items_separator; 

    struct replace_to
    {
           TCHAR chSep;
           replace_to( TCHAR chs) : chSep(chs) {};
           void operator() (TCHAR &ch)
           {
            if (ch==_T(';')  /* || ch==_T('|') || ch==_T('+') */  || ch==_T(',')) ch = chSep;
           }
    };


public:
    attribute_vector_meta_class( const TCHAR* attribute_name, 
                                 const TCHAR is)
          : attr_name(attribute_name), items_separator(is) {};

    void read_node(INTERFACE_CLI_SIXML_INODE* pNode, std::vector<PrimType> &res) const 
       {
        CLIASSERT(pNode);
        CLIASSERT(attr_name);
        res.clear();

        ::sixml::util::tstring attrText;
        if (::sixml::helpers::readChildText( pNode, attrText, attr_name, true))
            return;

        std::for_each(attrText.begin(), attrText.end(), replace_to(items_separator));

        std::vector< ::sixml::util::tstring > strings;
        sixml::util::split_string(strings, attrText, items_separator);
        res.reserve( strings.size() );
        std::for_each(strings.begin(), strings.end(), read_item(res /* , pNode */, attr_name /* tag_name */  ));
        /*
        ::sixml::util::tstring attrText;
        if (!node->getAttrText( attr_name, attrText ))
           {
            res = std::vector<PrimType>();
            return;
           }

        std::vector< ::sixml::util::tstring > strings;
        sixml::util::split_string(strings, attrText, items_separator);
        std::for_each(strings.begin(), strings.end(), read_item(res, node));
        */
       }

    std::vector<PrimType> read_node(INTERFACE_CLI_SIXML_INODE* pNode) const 
       {
        CLIASSERT(pNode);
        CLIASSERT(attr_name);

        std::vector<PrimType> res;
        ::sixml::util::tstring attrText;
        if (::sixml::helpers::readChildText( pNode, attrText, attr_name, true))
           {
            //res = std::vector<PrimType>();
            return res;
           }

        std::for_each(attrText.begin(), attrText.end(), replace_to(items_separator));

        std::vector< ::sixml::util::tstring > strings;
        sixml::util::split_string(strings, attrText, items_separator);
        res.reserve( strings.size() );
        std::for_each(strings.begin(), strings.end(), read_item(res /* , pNode */, attr_name /* tag_name */  ));
        return res;

        /*
        ::sixml::util::tstring attrText;
        if (!node->getAttrText( attr_name, attrText )) return std::vector<PrimType>();

        std::vector< ::sixml::util::tstring > strings;
        sixml::util::split_string(strings, attrText, items_separator);

        std::vector<PrimType> res;
        std::for_each(strings.begin(), strings.end(), read_item(res, node));
        return res;
        */
       }

    void write_node(INTERFACE_CLI_SIXML_INODE* pNode, const std::vector<PrimType> &vec) const 
    {
        CLIASSERT(pNode);
        CLIASSERT(attr_name);

        ::sixml::util::tstring str;
        std::for_each( vec.begin(), vec.end(), write_item(str, items_separator, attr_name /* tag_name */ ));
        ::sixml::helpers::setNodeOrChildText( pNode, str, attr_name, true );

        /*
        ::sixml::util::tstring str;
        std::for_each( vec.begin(), vec.end(), write_item(str, items_separator));
        node->addAttr(attr_name, str);
        */
        //attr_set_val
        /*
        size_t attr_it = node->attr_find(attr_name);
        if (attr_it!=node->attr_end())
           {
            node->attr_set_val(attr_it, str.c_str());
           }
        else
           {
            node->attr_add( attr_name, str.c_str());
           }
        */
    }
/*
    void update_node(i_sixml_node* node, const std::vector<PrimType> &vec) const 
    {
        CLIASSERT(node);
        write_node(node, vec);
    }
*/
protected:

    attribute_vector_meta_class& operator=(const attribute_vector_meta_class& av)
        { av; THROW_CNA(attribute_vector_meta_class_is_not_copyable); return *this; }

    struct read_item
       {
        protected:
            std::vector<PrimType>       &vec;
            const TCHAR                 *attr_name; // tag_name; 

            //INTERFACE_CLI_SIXML_INODE  *pNode;
            read_item&operator=(const read_item& r)
            { r; THROW_CNA(attribute_vector_meta_class_is_not_copyable); return *this; }

        public:
            read_item( std::vector<PrimType> &v /* , INTERFACE_CLI_SIXML_INODE* _pNode */ 
                     , const TCHAR *tn ) 
                     : vec(v), attr_name /* tag_name */ (tn) /* , pNode(_pNode) */  {  /* CLIASSERT(node); */  };
            void operator() (const ::sixml::util::tstring &str) 
                { 
                 vec.push_back(primitive<PrimType>::from_string(str, ::sixml::helpers::getFieldUsedName((INTERFACE_CLI_SIXML_INODE*)0, attr_name, true)));
                };
       }; 

    struct write_item
       {
        protected:
            ::sixml::util::tstring     &str;
            const TCHAR                 sep; 
            const TCHAR                 *attr_name;//tag_name; 

            write_item&operator=(const write_item& w)
            { w; THROW_CNA(attribute_vector_meta_class_is_not_copyable); return *this; }

        public:
            write_item( ::sixml::util::tstring &res_str
                      , const TCHAR separator
                      , const TCHAR *tn
                      )
                      : str(res_str), sep(separator), attr_name /* tag_name */ (tn) { };
            void operator() (const PrimType &i) 
                {
                 if (!str.empty()) str += sep;
                 str.append(primitive<PrimType>::to_string(i, ::sixml::helpers::getFieldUsedName((INTERFACE_CLI_SIXML_INODE*)0, attr_name, true)));
                };
       };
};





template <typename PrimType>
struct simple_vector_meta_class
    : public meta_class<std::vector<PrimType> >
{
protected:
    const TCHAR                 *tag_name; 
    const TCHAR                 items_separator; 

    struct replace_to
    {
           TCHAR chSep;
           replace_to( TCHAR chs) : chSep(chs) {};
           void operator() (TCHAR &ch)
           {
            if (ch==_T(';')  /* || ch==_T('|') || ch==_T('+') */  || ch==_T(',')) ch = chSep;
           }
    };


public:
    simple_vector_meta_class( const TCHAR* _tag_name, 
                                 const TCHAR is)
          : tag_name(_tag_name), items_separator(is) {};

    void read_node(INTERFACE_CLI_SIXML_INODE* pNode, std::vector<PrimType> &res) const 
       {
        CLIASSERT(pNode);
        CLIASSERT(tag_name);
        res.clear();

        ::sixml::util::tstring attrText;
        if (::sixml::helpers::readChildText( pNode, attrText, tag_name, false))
            return;

        std::for_each(attrText.begin(), attrText.end(), replace_to(items_separator));

        std::vector< ::sixml::util::tstring > strings;
        sixml::util::split_string(strings, attrText, items_separator);
        res.reserve( strings.size() );
        std::for_each(strings.begin(), strings.end(), read_item(res /* , pNode */, tag_name ));
        /*
        ::sixml::util::tstring attrText;
        if (!node->getAttrText( attr_name, attrText ))
           {
            res = std::vector<PrimType>();
            return;
           }

        std::vector< ::sixml::util::tstring > strings;
        sixml::util::split_string(strings, attrText, items_separator);
        std::for_each(strings.begin(), strings.end(), read_item(res, node));
        */
       }

    std::vector<PrimType> read_node(INTERFACE_CLI_SIXML_INODE* pNode) const 
       {
        CLIASSERT(pNode);
        CLIASSERT(tag_name);

        std::vector<PrimType> res;
        ::sixml::util::tstring attrText;
        if (::sixml::helpers::readChildText( pNode, attrText, tag_name, false))
           {
            //res = std::vector<PrimType>();
            return res;
           }

        std::for_each(attrText.begin(), attrText.end(), replace_to(items_separator));

        std::vector< ::sixml::util::tstring > strings;
        sixml::util::split_string(strings, attrText, items_separator);
        res.reserve( strings.size() );
        std::for_each(strings.begin(), strings.end(), read_item(res /* , pNode */, tag_name ));
        return res;

        /*
        ::sixml::util::tstring attrText;
        if (!node->getAttrText( attr_name, attrText )) return std::vector<PrimType>();

        std::vector< ::sixml::util::tstring > strings;
        sixml::util::split_string(strings, attrText, items_separator);

        std::vector<PrimType> res;
        std::for_each(strings.begin(), strings.end(), read_item(res, node));
        return res;
        */
       }

    void write_node(INTERFACE_CLI_SIXML_INODE* pNode, const std::vector<PrimType> &vec) const 
    {
        CLIASSERT(pNode);
        CLIASSERT(tag_name);

        ::sixml::util::tstring str;
        std::for_each( vec.begin(), vec.end(), write_item(str, items_separator, tag_name));
        ::sixml::helpers::setNodeOrChildText( pNode, str, tag_name, false );

        /*
        ::sixml::util::tstring str;
        std::for_each( vec.begin(), vec.end(), write_item(str, items_separator));
        node->addAttr(attr_name, str);
        */
        //attr_set_val
        /*
        size_t attr_it = node->attr_find(attr_name);
        if (attr_it!=node->attr_end())
           {
            node->attr_set_val(attr_it, str.c_str());
           }
        else
           {
            node->attr_add( attr_name, str.c_str());
           }
        */
    }
/*
    void update_node(i_sixml_node* node, const std::vector<PrimType> &vec) const 
    {
        CLIASSERT(node);
        write_node(node, vec);
    }
*/
protected:

    simple_vector_meta_class& operator=(const simple_vector_meta_class& av)
        { av; THROW_CNA(simple_vector_meta_class_is_not_copyable); return *this; }

    struct read_item
       {
        protected:
            std::vector<PrimType>       &vec;
            //INTERFACE_CLI_SIXML_INODE  *pNode;
            const TCHAR                 *tag_name; 

            read_item&operator=(const read_item& r)
            { r; THROW_CNA(simple_vector_meta_class_is_not_copyable); return *this; }

        public:
            read_item( std::vector<PrimType> &v /* , INTERFACE_CLI_SIXML_INODE* _pNode */ 
                     , const TCHAR *tn
                     ) 
                     : vec(v), tag_name(tn) /* , pNode(_pNode) */  {  /* CLIASSERT(node); */  };
            void operator() (const ::sixml::util::tstring &str) 
                { 
                 vec.push_back(primitive<PrimType>::from_string(str, ::sixml::helpers::getFieldUsedName((INTERFACE_CLI_SIXML_INODE*)0, tag_name, false)));
                };
       }; 

    struct write_item
       {
        protected:
            ::sixml::util::tstring     &str;
            const TCHAR                 sep; 
            const TCHAR                 *tag_name; 

            write_item&operator=(const write_item& w)
            { w; THROW_CNA(simple_vector_meta_class_is_not_copyable); return *this; }

        public:
            write_item( ::sixml::util::tstring &res_str
                      , const TCHAR separator
                      , const TCHAR *tn
                      )
                      : str(res_str), sep(separator), tag_name(tn)
                      { };
            void operator() (const PrimType &i) 
                {
                 if (!str.empty()) str += sep;
                 str.append(primitive<PrimType>::to_string(i, ::sixml::helpers::getFieldUsedName((INTERFACE_CLI_SIXML_INODE*)0, tag_name, false)));
                };
       };
};











template <typename Data>
const meta_class<Data>& default_meta_class()
{
    static struct_meta_class<Data> _anon( ::sixml::serializer::default_layout<Data>());
    return _anon;
}

template <typename ArrayItemType>
const meta_class<std::vector<ArrayItemType> >& default_vector_meta_class(const TCHAR *array_item_name)
{
    static vector_meta_class<ArrayItemType> _anon(array_item_name, default_meta_class<ArrayItemType>());
    return _anon;
}

template <typename ArrayItemType>
const meta_class<std::vector<ArrayItemType> >& default_attribute_vector_meta_class(const TCHAR *attribute_name, const TCHAR separator)
{
    static attribute_vector_meta_class<ArrayItemType> _anon(attribute_name, separator);
    return _anon;
}




#define DEFAULT_PRIM_METADATA(prim) \
template <> \
inline      \
const meta_class< prim >& default_meta_class < prim >  () \
{ \
    static prim_meta_class < prim > _anon; \
    return _anon; \
} \
template <> \
inline \
const meta_class<std::vector< prim > >& default_meta_class<std::vector< prim > >() \
{ \
    static vector_meta_class< prim > _anon(_T( #prim ), default_meta_class< prim >()); \
    /* static vector_meta_class< prim > _anon( #prim, default_meta_class< prim >()); */ \
    return _anon; \
}


DEFAULT_PRIM_METADATA(unsigned int)
DEFAULT_PRIM_METADATA(signed int)
DEFAULT_PRIM_METADATA(unsigned short int)
DEFAULT_PRIM_METADATA(signed short int)
DEFAULT_PRIM_METADATA(unsigned long int)
DEFAULT_PRIM_METADATA(signed long int)

#if UINT_MAX != ULONG_MAX
DEFAULT_PRIM_METADATA(unsigned int)
DEFAULT_PRIM_METADATA(signed int)
#endif

#if _UI64_MAX!=ULONG_MAX
DEFAULT_PRIM_METADATA(INT64)
DEFAULT_PRIM_METADATA(UINT64)
#endif

DEFAULT_PRIM_METADATA(unsigned char)
DEFAULT_PRIM_METADATA( char)
DEFAULT_PRIM_METADATA( wchar_t )
DEFAULT_PRIM_METADATA( ::std::string )
DEFAULT_PRIM_METADATA( ::std::wstring )
DEFAULT_PRIM_METADATA(bool)
DEFAULT_PRIM_METADATA(float)
DEFAULT_PRIM_METADATA(double)
//DEFAULT_PRIM_METADATA()

}; // namespace serializer

}; // namespace sixml


#endif /* CLI_XML_SIXML_METACLAS_H */
