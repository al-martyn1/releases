#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_6MLEXCEP_H
#define CLI_XML_SIXML_6MLEXCEP_H

/*
#ifndef CLI_XML_SIXML_6MLEXCEP_H
    #include <cli\xml\sixml\6mlexcep.h>
#endif
*/

#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif


namespace sixml{

namespace util{

#ifndef SIXML_UTIL_TSTRING_DEFINED
#define SIXML_UTIL_TSTRING_DEFINED
typedef std::basic_string<TCHAR>  tstring;
// using ::sixml::util::::sixml::util::tstring
#endif /* SIXML_UTIL_TSTRING_DEFINED */

}; // namespace util

#define BEGIN_SIXML_EXCEPTION_ASSIGN_OP(thisClass, baseClass) \
    thisClass& operator=( const thisClass &e )                \
       {                                                      \
        baseClass::operator=(e);

#define END_SIXML_EXCEPTION_ASSIGN_OP() \
        return *this;                   \
       }



#define BEGIN_SIXML_EXCEPTION_COPY_CTOR(thisClass, baseClass) \
       thisClass( const thisClass &e ) : baseClass(e)

#define END_SIXML_EXCEPTION_COPY_CTOR() {}


#define SIXML_EXCEPTION_EMPTY_CLASS_CTOR_AND_ASSIGN(thisClass, baseClass) \
        BEGIN_SIXML_EXCEPTION_COPY_CTOR(thisClass, baseClass)             \
        END_SIXML_EXCEPTION_COPY_CTOR()                                   \
        BEGIN_SIXML_EXCEPTION_ASSIGN_OP(thisClass, baseClass)             \
        END_SIXML_EXCEPTION_ASSIGN_OP()


// #define NO_THROW()   throw ()
#define EXEPT_THROW_SPEC()   throw ()
//  throw()
//    virtual 
//    ~runtime_error() throw();

//    virtual __CLR_OR_THIS_CALL ~runtime_error() _THROW0()
//        {   // destroy the object
//        }
// #define _THROW0()  throw ()


#ifndef THROW_CNA
    #define THROW_CNA(msg)  CLI_STATIC_CHECK(0, msg)
#endif



class CException : public ::std::runtime_error // exception
{
    public:
        typedef ::sixml::util::tstring     tstring;

    protected:
        static ::std::string charStr( const tstring &str)
           {
            return MARTY_CON::strToAnsi(str);
           }

        static tstring toString(UINT64 i, unsigned int radix)
           {
            return ::cli::util::smpInt2Str(i, radix);
           }
        static tstring toString(INT64 i, unsigned int radix)
           {
            return ::cli::util::smpInt2Str(i, radix);
           }

    public:

        static tstring tstr( const char* str)
           {
            #if defined(UNICODE) || defined(_UNICODE)
            return MARTY_CON::strToWide(str);
            #else
            return tstring(str);
            #endif
           }



        //CException( const ::std::string &str ) : ::std::exception(str.c_str()) {}
        CException() : ::std::runtime_error("unknow (description not defined for this error) error") {} // exception() {}
        CException( const tstring &str ) : ::std::runtime_error( (::std::string("SiXML: ")+charStr(str)).c_str()) {} //exception(charStr(str).c_str()) {}

        //SIXML_EXCEPTION_EMPTY_CLASS_CTOR_AND_ASSIGN(CException, ::std::exception)
        SIXML_EXCEPTION_EMPTY_CLASS_CTOR_AND_ASSIGN(CException, ::std::runtime_error)

        ~CException() EXEPT_THROW_SPEC() {}
};


class CTypeExceptionBase : public CException
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        tstring      typeName;
        tstring      tagAttrName;

        CTypeExceptionBase( const tstring &msg, const tstring &tn, const tstring &taName)
           : CException(msg), typeName(tn), tagAttrName(taName) {}

        BEGIN_SIXML_EXCEPTION_COPY_CTOR( CTypeExceptionBase, CException )
             ,typeName(e.typeName)
             ,tagAttrName(e.tagAttrName)
        END_SIXML_EXCEPTION_COPY_CTOR()

        BEGIN_SIXML_EXCEPTION_ASSIGN_OP( CTypeExceptionBase, CException )
              typeName = e.typeName;
              tagAttrName = e.tagAttrName;
        END_SIXML_EXCEPTION_ASSIGN_OP()

        ~CTypeExceptionBase() EXEPT_THROW_SPEC() {}
};


class CTagExceptionBase : public CException
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        tstring      tagName;
        bool         isAttr;

        CTagExceptionBase( const tstring &msg, const tstring &tn, bool isa)
           : CException(msg), tagName(tn), isAttr(isa) {}

        BEGIN_SIXML_EXCEPTION_COPY_CTOR( CTagExceptionBase, CException )
             ,tagName(e.tagName)
             ,isAttr(e.isAttr)
        END_SIXML_EXCEPTION_COPY_CTOR()

        BEGIN_SIXML_EXCEPTION_ASSIGN_OP( CTagExceptionBase, CException )
              tagName = e.tagName;
              isAttr  = e.isAttr;
        END_SIXML_EXCEPTION_ASSIGN_OP()

        ~CTagExceptionBase() EXEPT_THROW_SPEC() {}
};


class CMandatoryFieldMissing : public CTagExceptionBase
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        CMandatoryFieldMissing( const tstring &tn, bool isa )
           : CTagExceptionBase( tstr("Mandatory ") + tstr(isa?"attribute":"tag") + tstr(" '") + tn + tstr("' missing")
                              , tn, isa
                              )
           {}
        SIXML_EXCEPTION_EMPTY_CLASS_CTOR_AND_ASSIGN(CMandatoryFieldMissing, CTagExceptionBase)

        ~CMandatoryFieldMissing() EXEPT_THROW_SPEC() {}
};

class CWrongRootTag : public CTagExceptionBase
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        tstring      foundTagName;
        CWrongRootTag( const tstring &expectedTn, const tstring &foundTn )
           : CTagExceptionBase( tstr("Wrong root tag, expected '") + expectedTn + tstr("', but found '") + foundTn + tstr("'")
                              , expectedTn, false
                              )
           , foundTagName(foundTn) {}

        BEGIN_SIXML_EXCEPTION_COPY_CTOR( CWrongRootTag, CTagExceptionBase )
             ,foundTagName(e.foundTagName)
        END_SIXML_EXCEPTION_COPY_CTOR()

        BEGIN_SIXML_EXCEPTION_ASSIGN_OP( CWrongRootTag, CTagExceptionBase )
              foundTagName = e.foundTagName;
        END_SIXML_EXCEPTION_ASSIGN_OP()

        ~CWrongRootTag() EXEPT_THROW_SPEC() {}
};

class CFieldAllreadyDefined : public CTagExceptionBase
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        CFieldAllreadyDefined( const tstring &tn, bool isa )
           : CTagExceptionBase( tstr(isa?"Attribute":"Tag") + tstr(" '") + tn + tstr("' allready defined")
                              , tn, isa
                              )
           {}
        SIXML_EXCEPTION_EMPTY_CLASS_CTOR_AND_ASSIGN(CFieldAllreadyDefined, CTagExceptionBase)

        ~CFieldAllreadyDefined() EXEPT_THROW_SPEC() {}
};





// thrown while saving
class CNotMemberEnumOrFlags : public CTypeExceptionBase
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        UINT64                      uintValue;
        ::sixml::util::tstring      strValue;
        ::sixml::util::tstring      typeTypeName;

        CNotMemberEnumOrFlags( const tstring &tn, const tstring &taName, const tstring &_typeTypeName, UINT64 v)
           : CTypeExceptionBase( tstr("Value '0x") + toString(v, 16) + tstr("' is not a member of ") + tn + tstr(" ") + _typeTypeName + tstr(" (") + taName + tstr(")")
                               , tn, taName
                               )
           , uintValue(v)
           , strValue( /* ::sixml::util::tstring */ tstr("0x") + ::cli::util::smpInt2Str(v, 16))
           , typeTypeName(_typeTypeName)
           {}

        BEGIN_SIXML_EXCEPTION_COPY_CTOR( CNotMemberEnumOrFlags, CTypeExceptionBase )
             , uintValue(e.uintValue)
             , strValue (e.strValue)
             , typeTypeName(e.typeTypeName)
        END_SIXML_EXCEPTION_COPY_CTOR()

        BEGIN_SIXML_EXCEPTION_ASSIGN_OP( CNotMemberEnumOrFlags, CTypeExceptionBase )
              uintValue = e.uintValue;
              strValue  = e.strValue;
              typeTypeName = e.typeTypeName;
        END_SIXML_EXCEPTION_ASSIGN_OP()

        ~CNotMemberEnumOrFlags() EXEPT_THROW_SPEC() {}
};

// thrown while parsing
class CUnknownEnumOrFlagValue : public CTypeExceptionBase
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        tstring      strValue;
        tstring      typeTypeName;

        CUnknownEnumOrFlagValue( const tstring &tn, const tstring &taName, const tstring &_typeTypeName, const tstring &v)
           : CTypeExceptionBase( tstr("Unknown ") + _typeTypeName + tstr(" ") + tn + tstr(" value: '") + v + tstr("'") + tstr(" (") + taName + tstr(")")
                               , tn, taName
                               )
           , strValue( v )
           , typeTypeName(_typeTypeName)
           {}

        BEGIN_SIXML_EXCEPTION_COPY_CTOR( CUnknownEnumOrFlagValue, CTypeExceptionBase )
             , strValue (e.strValue)
             , typeTypeName(e.typeTypeName)
        END_SIXML_EXCEPTION_COPY_CTOR()

        BEGIN_SIXML_EXCEPTION_ASSIGN_OP( CUnknownEnumOrFlagValue, CTypeExceptionBase )
              strValue  = e.strValue;
              typeTypeName = e.typeTypeName;
        END_SIXML_EXCEPTION_ASSIGN_OP()

        ~CUnknownEnumOrFlagValue() EXEPT_THROW_SPEC() {}
};


class CFormatError : public CTypeExceptionBase
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        tstring      strValue;

        CFormatError( const tstring &tn, const tstring &taName, const tstring &v)
           : CTypeExceptionBase( tstr("Type '") + tn + tstr("' format error while converting value '") + v + tstr("'") + tstr(" (") + taName + tstr(")")
                               , tn, taName
                               )
           , strValue( v )
           {}

        CFormatError( const tstring &tn, const tstring &taName, const tstring &v, const tstring &msg)
           : CTypeExceptionBase( msg, tn, taName )
           , strValue( v )
           {}

        BEGIN_SIXML_EXCEPTION_COPY_CTOR( CFormatError, CTypeExceptionBase )
             , strValue (e.strValue)
        END_SIXML_EXCEPTION_COPY_CTOR()

        BEGIN_SIXML_EXCEPTION_ASSIGN_OP( CFormatError, CTypeExceptionBase )
              strValue  = e.strValue;
        END_SIXML_EXCEPTION_ASSIGN_OP()

        ~CFormatError() EXEPT_THROW_SPEC() {}
};


class CRangeError : public CFormatError
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:
        INT64        valueMin;
        UINT64       valueMax;
        tstring      strMin;
        tstring      strMax;

        CRangeError( const tstring &tn, const tstring &taName, const tstring &v, INT64 vMin, UINT64 vMax )
           : CFormatError( tn, taName, v
                         , tstr("Type '") + tn + tstr("' - range error while converting value '") 
                         + v + tstr("' - value must be in range from ") 
                         + toString(vMin, 10) + tstr("' to ") + toString(vMax, 10) + tstr("'") 
                         + tstr("'") + tstr(" (") + taName + tstr(")")
                         )
           , valueMin(vMin)
           , valueMax(vMax)
           , strMin(toString(vMin, 10))
           , strMax(toString(vMax, 10))
           {}

        CRangeError( const tstring &tn, const tstring &taName, const tstring &v )
           : CFormatError( tn, taName, v
                         , tstr("Type '") + tn + tstr("' - range error while converting value '") 
                         + v + tstr("'") 
                         + tstr("'") + tstr(" (") + taName + tstr(")")
                         )
           , valueMin(0)
           , valueMax(0)
           , strMin(_T("0"))
           , strMax(_T("0"))
           {}

        CRangeError( const tstring &tn, const tstring &taName, const tstring &v
                   , INT64 vMin, UINT64 vMax
                   , const tstring &msg 
                   )
           : CFormatError( tn, taName, v, msg )
           , valueMin(vMin)
           , valueMax(vMax)
           , strMin(toString(vMin, 10))
           , strMax(toString(vMax, 10))
           {}

        BEGIN_SIXML_EXCEPTION_COPY_CTOR( CRangeError, CFormatError )
             , valueMin(e.valueMin)
             , valueMax(e.valueMax)
             , strMin(e.strMin)
             , strMax(e.strMax)
        END_SIXML_EXCEPTION_COPY_CTOR()

        BEGIN_SIXML_EXCEPTION_ASSIGN_OP( CRangeError, CFormatError )
              valueMin = e.valueMin;
              valueMax = e.valueMax;
              strMin = e.strMin;
              strMax = e.strMax;
        END_SIXML_EXCEPTION_ASSIGN_OP()

        ~CRangeError() EXEPT_THROW_SPEC() {}
};


class CRangeUnderflow : public CRangeError
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:

        CRangeUnderflow( const tstring &tn, const tstring &taName, const tstring &v, INT64 vMin )
           : CRangeError( tn, taName, v, vMin, 0
                         , tstr("Type '") + tn + tstr("' - range error while converting value '") 
                         + v + tstr("' - value must be less or equal to '") + toString(vMin, 10) + tstr("'")
                         + tstr("'") + tstr(" (") + taName + tstr(")")
                         )
           {}

        CRangeUnderflow( const tstring &tn, const tstring &taName, const tstring &v )
           : CRangeError( tn, taName, v, 0, 0
                        , tstr("Type '") + tn + tstr("' - range underflow while converting value '") + v + tstr("'")
                          + tstr("'") + tstr(" (") + taName + tstr(")")
                        )
           {}

        SIXML_EXCEPTION_EMPTY_CLASS_CTOR_AND_ASSIGN( CRangeUnderflow, CRangeError )

        ~CRangeUnderflow() EXEPT_THROW_SPEC() {}
};

class CRangeOverflow : public CRangeError
{
    public:
        typedef ::sixml::util::tstring     tstring;

    public:

        CRangeOverflow( const tstring &tn, const tstring &taName, const tstring &v, UINT64 vMax )
           : CRangeError( tn, taName, v, 0, vMax
                        , tstr("Type '") + tn + tstr("' range error while converting value '") 
                        + v + tstr("' - value must be greater or equal to '") + toString(vMax, 10) + tstr("'")
                        + tstr("'") + tstr(" (") + taName + tstr(")")
                        )
           {}

        CRangeOverflow( const tstring &tn, const tstring &taName, const tstring &v )
           : CRangeError( tn, taName, v, 0, 0
                        , tstr("Type '") + tn + tstr("' range overflow while converting value '") + v + tstr("'")
                          + tstr("'") + tstr(" (") + taName + tstr(")")
                        )
           {}

        SIXML_EXCEPTION_EMPTY_CLASS_CTOR_AND_ASSIGN( CRangeOverflow, CRangeError )

        ~CRangeOverflow() EXEPT_THROW_SPEC() {}
};


class CXmlStorageException : public CException
{
    public:
        typedef ::sixml::util::tstring     tstring;

        static tstring posToString(int pos)
           {
            if (pos<0) return _T("?");
            return ::cli::util::smpInt2Str((INT64)pos, 10);
           }

        static tstring formatPosMsg(int l, int p)
           {
            tstring str = tstr("XML format error");
            if (l>=0)
               {
                str += tstr(", line ") + posToString(l);
                if (p>=0)
                   {
                    str += tstr(", pos ") + posToString(p);
                   }
               }
            return str + tstr(": ");
           }

        static tstring formatExceptionMsg(RCODE c, int l, int p)
           {
            switch(c)
               {
                case EC_XML_OK                 :  return formatPosMsg(l, p) + tstr("No error");
                case EC_FILE_NOT_FOUND         :  return formatPosMsg(l, p) + tstr("File not found");
                case EC_IO_ERROR               :  return formatPosMsg(l, p) + tstr("File/stream IO operation failed");
                case EC_XML_INTERNAL_ERROR     :  return formatPosMsg(l, p) + tstr("XML Engine internal error");
                case EC_XML_BAD_TAG            :  return formatPosMsg(l, p) + tstr("Parser could not determine tag type");
                case EC_XML_BAD_PI             :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing document declaration/processing instruction (<?...?>)");
                case EC_XML_BAD_COMMENT        :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing comment (<!--...-->)");
                case EC_XML_BAD_CDATA          :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing CDATA section (<![CDATA[...]]>)");
                case EC_XML_BAD_DOCTYPE        :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing document type declaration");
                case EC_XML_BAD_PCDATA         :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing PCDATA section (>...<)");
                case EC_XML_BAD_START_ELEMENT  :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing start element tag (<name ...>)");
                case EC_XML_BAD_ATTRIBUTE      :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing element attribute");
                case EC_XML_BAD_END_ELEMENT    :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing end element tag (</name>)");
                case EC_XML_TAG_MISMATCH       :  return formatPosMsg(l, p) + tstr("There was a mismatch of start-end tags (closing tag had incorrect name, some tag was not closed or there was an excessive closing tag)");
                case EC_XML_BAD_ELEMENT        :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing element");
                case EC_XML_BAD_ELEMENT_NAME   :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing element name");
                case EC_XML_BAD_ELEMENT_VALUE  :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing element value");
                case EC_XML_BAD_DECLARATION    :  return formatPosMsg(l, p) + tstr("Parsing error occured while parsing document declaration");
                case EC_XML_DOCUMENT_EMPTY     :  return formatPosMsg(l, p) + tstr("XML document is empty");
                case EC_XML_UNEXPECTED_END     :  return formatPosMsg(l, p) + tstr("Unexpected end of data found");
                //case :  return formatPosMsg(l, p) + tstr("");
                case EC_XML_UNKNOWN_ERROR:  
                default:            return formatPosMsg(l, p) + tstr("XML Engine unknown error");
               }
           }

    public:
        int          line;
        int          pos;
        RCODE        errCode;
        tstring      strLine;
        tstring      strPos;

        CXmlStorageException( RCODE code, int l, int p )
           : CException( formatExceptionMsg( code, l, p) )
           , line(l)
           , pos(p)
           , errCode(0)
           , strLine( posToString(l) )
           , strPos( posToString(p) )
           {}

        BEGIN_SIXML_EXCEPTION_COPY_CTOR( CXmlStorageException, CException )
             , line    (e.line)
             , pos     (e.pos)
             , errCode (e.errCode)
             , strLine (e.strLine)
             , strPos  (e.strPos)
        END_SIXML_EXCEPTION_COPY_CTOR()

        BEGIN_SIXML_EXCEPTION_ASSIGN_OP( CXmlStorageException, CException )
              line    = e.line;
              pos     = e.pos;
              errCode = e.errCode;
              strLine = e.strLine;
              strPos  = e.strPos;
        END_SIXML_EXCEPTION_ASSIGN_OP()

        ~CXmlStorageException() EXEPT_THROW_SPEC() {}
};





//-----------------------------------------------------------------------------
inline void throw_num_format_empty_string_error( const ::sixml::util::tstring &tryConvertToType
                                               , const ::sixml::util::tstring &attrOrTagName
                                               )
   {
    throw CException(::sixml::util::tstring(_T("Convert empty string to '")) + tryConvertToType + ::sixml::util::tstring(_T("'")) + CException::tstr(" (") + attrOrTagName + CException::tstr(")") );
   }

//-----------------------------------------------------------------------------
inline void throw_num_format_error( const ::sixml::util::tstring &parsedStr
                                  , const ::sixml::util::tstring &tryConvertToType
                                  , const ::sixml::util::tstring &attrOrTagName
                                  )
   {
    throw CFormatError( tryConvertToType, attrOrTagName, parsedStr );
   }

//-----------------------------------------------------------------------------
inline void throw_num_format_range_error( const ::sixml::util::tstring &parsedStr
                                        , const ::sixml::util::tstring &tryConvertToType
                                        , const ::sixml::util::tstring &attrOrTagName
                                        )
   {
    throw CRangeError( tryConvertToType, attrOrTagName, parsedStr );
   }

//-----------------------------------------------------------------------------
inline void throw_int_format_range_error( const ::sixml::util::tstring &parsedStr
                                        , const ::sixml::util::tstring &tryConvertToType
                                        , INT64 lowLim, UINT64 highLim
                                        , const ::sixml::util::tstring &attrOrTagName
                                        )
   {
    throw CRangeError( tryConvertToType, attrOrTagName, parsedStr, lowLim, highLim );
   }

//-----------------------------------------------------------------------------
inline void throw_int_format_range_underflow( const ::sixml::util::tstring &parsedStr
                                            , const ::sixml::util::tstring &tryConvertToType
                                            , INT64 lim
                                            , const ::sixml::util::tstring &attrOrTagName
                                            )
   {
    throw CRangeUnderflow( tryConvertToType, attrOrTagName, parsedStr, lim );
   }

//-----------------------------------------------------------------------------
inline void throw_int_format_range_overflow( const ::sixml::util::tstring &parsedStr
                                           , const ::sixml::util::tstring &tryConvertToType
                                           , UINT64 highLim
                                           , const ::sixml::util::tstring &attrOrTagName
                                           )
   {
    CRangeOverflow( tryConvertToType, attrOrTagName, parsedStr, highLim );
   }

//-----------------------------------------------------------------------------
inline void throw_num_format_range_underflow( const ::sixml::util::tstring &parsedStr
                                            , const ::sixml::util::tstring &tryConvertToType
                                            , const ::sixml::util::tstring &attrOrTagName
                                            )
   {
    throw CRangeUnderflow( tryConvertToType, attrOrTagName, parsedStr );
   }

//-----------------------------------------------------------------------------
inline void throw_num_format_range_overflow( const ::sixml::util::tstring &parsedStr
                                           , const ::sixml::util::tstring &tryConvertToType
                                           , const ::sixml::util::tstring &attrOrTagName
                                           )
   {
    CRangeOverflow( tryConvertToType, attrOrTagName, parsedStr );
   }

//-----------------------------------------------------------------------------
inline void throw_num_to_string_format_error( const ::sixml::util::tstring &attrOrTagName )
   {
    throw CException( ::sixml::util::tstring(_T("Convert integer to string failed (")) + attrOrTagName + ::sixml::util::tstring(_T(")")));
    // never be called - I think that int-to-string conversion is always be good action
   }

//-----------------------------------------------------------------------------
inline void throw_invalid_char_format_error( const ::sixml::util::tstring &parsedStr
                                           , const ::sixml::util::tstring &tryConvertToType
                                           , const ::sixml::util::tstring &attrOrTagName
                                           )
   {
    throw CFormatError( tryConvertToType, attrOrTagName, parsedStr );
   }

//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
inline void throw_not_enum_member( UINT64 val, const ::sixml::util::tstring &enumType
                                 , const ::sixml::util::tstring &attrOrTagName 
                                 )
   {
    throw CNotMemberEnumOrFlags( enumType, attrOrTagName, _T("enum"), val);
   }

//-----------------------------------------------------------------------------
inline void throw_unknown_enum_value( const ::sixml::util::tstring &parsedStr
                                    , const ::sixml::util::tstring &enumType
                                    , const ::sixml::util::tstring &attrOrTagName
                                    )
   {
    throw CUnknownEnumOrFlagValue( enumType, attrOrTagName, _T("enum"), parsedStr);
   }

//-----------------------------------------------------------------------------
inline void throw_not_flag( UINT64 val, const ::sixml::util::tstring &flagsType
                          , const ::sixml::util::tstring &attrOrTagName
                          )
   {
    throw CNotMemberEnumOrFlags( flagsType, attrOrTagName, _T("flag"), val);
   }
   
//-----------------------------------------------------------------------------
inline void throw_unknown_flag_value( const ::sixml::util::tstring &parsedStr
                          , const ::sixml::util::tstring &attrOrTagName
                          , const ::sixml::util::tstring &flagsType
                          )
   {
    throw CUnknownEnumOrFlagValue( flagsType, attrOrTagName, _T("flag"), parsedStr);
   }

//-----------------------------------------------------------------------------
inline void throw_mandatory_field_missing( const ::sixml::util::tstring &tagOrAttrName, bool bAttr
                                         //, const ::sixml::util::tstring &attrOrTagName
                                         )
   {
    throw CMandatoryFieldMissing(  tagOrAttrName, bAttr );
   }

//-----------------------------------------------------------------------------
inline void throw_wrong_root_tag( const ::sixml::util::tstring &expectedTagName
                                , const ::sixml::util::tstring &foundTagName
                                //, const ::sixml::util::tstring &attrOrTagName
                                )
   {
    throw CWrongRootTag( expectedTagName, foundTagName );
   }

//-----------------------------------------------------------------------------
inline void throw_allready_defined( const ::sixml::util::tstring &tagOrAttrName, bool bAttr
                                  //, const ::sixml::util::tstring &attrOrTagName
                                  )
   {
    throw CFieldAllreadyDefined(tagOrAttrName, bAttr);
   }

//-----------------------------------------------------------------------------
inline void throw_parse_error( RCODE err, int line, int pos
                             //, const ::sixml::util::tstring &attrOrTagName
                             )
   {
    //throw CFieldAllreadyDefined(tagOrAttrName, bAttr);
    throw CXmlStorageException( err, line, pos );
   }

//-----------------------------------------------------------------------------



}; // namespace sixml

#endif /* CLI_XML_SIXML_6MLEXCEP_H */

