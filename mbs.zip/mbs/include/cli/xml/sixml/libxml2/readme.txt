Installing libxml2
  Win32
      Download Win32 binary packages from http://www.zlatkovic.com/libxml.en.html
      (see also http://www.xmlsoft.org/ - project home)
      iconv-1.9.2.win32.zip
      libxml2-2.7.6.win32.zip
      libxslt-1.1.26.win32.zip
      zlib-1.2.3.win32.zip
      or another apropriate version.

      Also your can use libxml++ from http://libxmlplusplus.sourceforge.net/

      Unpack libxml2-2.7.6.win32.zip to d:\libxml2:
      d:\libxml2
          bin
              xmlcatalog.exe
              xmllint.exe
              libxml2.dll         
          include
              libxml
                  ...
          lib
              libxml2.lib
              libxml2_a.lib
              libxml2_a_dll.lib
          readme.txt

      Unpack iconv-1.9.2.win32.zip (if you want misc encodings support)
      and libxslt-1.1.26.win32.zip (if you want XSLT processing)
      into same location to obtain directory tree listed below:
      d:\libxml2
          bin
              iconv.exe
              xmlcatalog.exe
              xmllint.exe
              xsltproc.exe
              iconv.dll
              libexslt.dll
              libxml2.dll
              libxslt.dll    
          include
              libexslt
                  ...
              libxml
                  ...
              libxslt
                  ...
              iconv.h
          lib
              iconv.lib
              iconv_a.lib
              libexslt.lib
              libexslt_a.lib
              libxml2.lib
              libxml2_a.lib
              libxml2_a_dll.lib
              libxslt.lib
              libxslt_a.lib
          readme.txt

      Add d:\libxml2\include to your compiler include path
      Add d:\libxml2\lib     to your compiler library path
      Also, might be, required copying libxml2.lib to xml2.lib.

      Use libxml2 in C++ sources as:
      #include <libxml/...>

      define LIBXML_ICONV_ENABLED macro if you want misc encodings support.

      Add d:\libxml2\bin into your system path




  Linux
      run (for Debian-based distributives)
        apt-get install libxml2 
      or use your system package manager

      add /usr/include/libxml2 path to your compiler include path

      Use libxml2 in C++ sources as:
      #include <libxml/...>
