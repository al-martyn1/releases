#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_LIBXML2_HELPERS_H
#define CLI_XML_SIXML_LIBXML2_HELPERS_H

/* Add following lines into your code
#ifndef CLI_XML_SIXML_LIBXML2_HELPERS_H
    #include <cli/xml/sixml/libxml2/helpers.h>
#endif
*/

/*
// headers below must be included by outer header, which use this header

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#include <libxml/tree.h>

*/

#ifndef CLIASSERT
    #define CLIASSERT(a)
#endif


namespace libxml2_helpers
{
    // traverce childs and get their texts concatenation
    inline
    void getNodeText( xmlNode * aNode, ::std::string &resStr, bool bRecur = false)
       {
        CLIASSERT(aNode);
        for (xmlNode * cur_node = aNode->children; cur_node; cur_node = cur_node->next)
            {
             if (cur_node->type==XML_TEXT_NODE || cur_node->type==XML_CDATA_SECTION_NODE)
                {
                 if (cur_node->content) resStr.append((const char*)cur_node->content);
                }
             else if (cur_node->type==XML_ELEMENT_NODE && bRecur)
                {
                 getNodeText( cur_node, resStr, true);
                }
            }       
       }

    inline
    ::std::string getNodeText( xmlNode * aNode, bool bRecur = false)
       {
        ::std::string res;
        getNodeText( aNode, res, bRecur );
        return res;
       }

    inline
    ::std::string getDbgNodeName( xmlNode * aNode )
       {
        CLIASSERT(aNode);
        if (!aNode->name) return ::std::string("<NULL>");
        return ::std::string((const char*)aNode->name);
       }

    inline
    ::std::string getNodeName( xmlNode * aNode )
       {
        CLIASSERT(aNode);
        if (!aNode->name) return ::std::string();
        return ::std::string((const char*)aNode->name);
       }

    inline
    ::std::string getDbgAttrName( xmlAttr * aAttr )
       {
        CLIASSERT(aAttr);
        if (!aAttr->name) return ::std::string("<NULL>");
        return ::std::string((const char*)aAttr->name);
       }

    inline
    ::std::string getAttrName( xmlAttr * aAttr )
       {
        CLIASSERT(aAttr);
        if (!aAttr->name) return ::std::string();
        return ::std::string((const char*)aAttr->name);
       }

    inline
    ::std::string getAttrValue( xmlAttr * aAttr )
       {
        CLIASSERT(aAttr);
        if (!aAttr->children) return ::std::string();
        if (aAttr->children->type!=XML_TEXT_NODE) return ::std::string();
        if (!aAttr->children->content) return ::std::string();
        return ::std::string((const char*)aAttr->children->content);
       }

}; // namespace libxml2_helpers


#endif /* CLI_XML_SIXML_LIBXML2_HELPERS_H */

