#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_NODEIMPLTPL_H
#define CLI_XML_SIXML_NODEIMPLTPL_H

// This file contains code template for implementing iNode class.
// Use it if you want add support for some other XML engine
// Create directory <engine> in cli/xml/sixml
// copy this file into newly created directory (see command line below)
//      copy cli/xml/sixml/NodeImplTpl.h cli/xml/sixml/<engine>/NodeImpl.h
// Add your code into class methods 


#ifndef LIBXML_TREE_ENABLED
    #define LIBXML_TREE_ENABLED
#endif

#ifndef CLI_XML_SIXML_NODEIMPLBASE_H
    #include <cli/xml/sixml/NodeImplBase.h>
#endif

#ifndef CLI_XML_SIXML_NODESETIMPL_H
    #include <cli/xml/sixml/NodeSetImpl.h>
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#include <libxml/xmlversion.h>

#ifndef LIBXML_TREE_ENABLED
    #define LIBXML_TREE_ENABLED
#endif

#ifndef LIBXML_LEGACY_ENABLED
    #define LIBXML_LEGACY_ENABLED
#endif

#ifndef LIBXML_TREE_ENABLED
    //#error "LIBXML_TREE_ENABLED not defined (1)"
#else
    //#error "LIBXML_TREE_ENABLED defined (1)"
#endif

#include <libxml/parser.h>
#include <libxml/tree.h>
//#include <libxml/xinclude.h>

#ifndef LIBXML_TREE_ENABLED
    //#error "LIBXML_TREE_ENABLED not defined (2)"
#else
    //#error "LIBXML_TREE_ENABLED defined (2)"
#endif


#ifndef CLI_XML_SIXML_LIBXML2_HELPERS_H
    #include <cli/xml/sixml/libxml2/helpers.h>
#endif

#define WSTR2XMLSTR(str)  MARTY_UTF::toUtf8(str)
#define WSTR2XML(str)     ( BAD_CAST MARTY_UTF::toUtf8(str).c_str())
#define XML2WSTR(str)     MARTY_UTF::fromUtf8(str)



namespace cli {
namespace sixml {
namespace impl {

struct CNodeImpl : public CNodeImplBase
{

        xmlNodePtr   pNode;
        xmlDocPtr    pDoc;

        CNodeImpl(xmlNodePtr pn) : CNodeImplBase(), pNode(pn), pDoc(0) {}
        CNodeImpl(xmlNodePtr pn, xmlDocPtr pd) : CNodeImplBase(), pNode(pn), pDoc(pd) {}
        ~CNodeImpl()
           {
            if (pDoc)
               {
                xmlFreeDoc(pDoc);
                //xmlCleanupParser();
               }
           }


        // Interface map - queryInterface implementation

        CLI_BEGIN_INTERFACE_MAP2(CNodeImplBase, INTERFACE_CLI_SIXML_INODE)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_SIXML_INODE )
        CLI_END_INTERFACE_MAP(CNodeImplBase)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

        // final implementation
        CLIMETHOD_(VOID, destroy) (THIS)
           {
            #include <cli/compspec/delthis.h>
           }
        
        CLIMETHOD_(VOID*, getDocPtr) (THIS)
           {
            return (VOID*)pDoc;
           }

        // GENERATOR: METHOD - attributesGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#attributesGet@OVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(attributesGet) (THIS_ CLISTR*           _attributes
                                      , const CLISTR*     idx1
                                 )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _attributes not an optional ptr or ref
                    if (!_attributes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_attributes" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here
                    ::std::string utfAttrName = WSTR2XMLSTR(stdstr(idx1));
                    xmlAttrPtr pAttr = pNode->properties;
                    for(; pAttr; pAttr = pAttr->next)
                       {
                        if (!pAttr->name) continue;
                        if (strcmp(utfAttrName.c_str(), (const char*)pAttr->name)) continue;
                        return ::cli::propertyGetImpl( _attributes, XML2WSTR(libxml2_helpers::getAttrValue( pAttr )) );
                       }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
            //return EC_NOT_IMPLEMENTED;
           }

        // GENERATOR: METHOD - attributesSet
        // GENERATOR: METHOD SIGNATURE - G!P0R#attributesSet@IVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(attributesSet) (THIS_ const CLISTR*     _attributes
                                      , const CLISTR*     idx1
                                 )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _attributes not an optional ptr or ref
                    if (!_attributes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_attributes" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here
                    xmlNewProp(pNode, WSTR2XML(stdstr(idx1)), WSTR2XML(stdstr(_attributes)));
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK; // EC_ERR_ALLREADY
           }

        // GENERATOR: METHOD - getAttributeByIndex
        // GENERATOR: METHOD SIGNATURE - G!P0R#getAttributeByIndex@OVS!P0G@OVS!P0G@IVS!P0T@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(getAttributeByIndex) (THIS_ CLISTR*           attrName
                                            , CLISTR*           attrVal
                                            , SIZE_T    idx /* [in] size_t  idx  */
                                       )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // attrName not an optional ptr or ref
                    if (!attrName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"attrName" );  }
                    
                    // attrVal not an optional ptr or ref
                    if (!attrVal) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"attrVal" );  }
                    
                    // method code goes here
                    SIZE_T curIdx = 0;
                    xmlAttrPtr pAttr = pNode->properties;
                    for(; pAttr; pAttr = pAttr->next, ++curIdx)
                       {
                         if (curIdx==idx)
                            {
                             ::cli::propertyGetImpl( attrName, XML2WSTR(libxml2_helpers::getAttrName( pAttr )) );
                             ::cli::propertyGetImpl( attrVal , XML2WSTR(libxml2_helpers::getAttrValue( pAttr )) );
                             return EC_OK;
                            }
                       }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OUT_OF_RANGE;
           }

        // GENERATOR: METHOD - nameGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#nameGet@OVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(nameGet) (THIS_ CLISTR*           _name)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _name not an optional ptr or ref
                    if (!_name) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_name" );  }
                    
                    // method code goes here
                    return ::cli::propertyGetImpl(_name, XML2WSTR(libxml2_helpers::getNodeName( pNode )) );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_NOT_IMPLEMENTED;
            //return EC_OK;
           }

        // GENERATOR: METHOD - textGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#textGet@OVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(textGet) (THIS_ CLISTR*           _text)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _text not an optional ptr or ref
                    if (!_text) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_text" );  }
                    
                    // method code goes here
                    return ::cli::propertyGetImpl(_text, XML2WSTR(libxml2_helpers::getNodeText( pNode )) );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_NOT_IMPLEMENTED;
            //return EC_OK;
           }

        // GENERATOR: METHOD - textSet
        // GENERATOR: METHOD SIGNATURE - G!P0R#textSet@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(textSet) (THIS_ const CLISTR*     _text)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _text not an optional ptr or ref
                    if (!_text) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_text" );  }
                    
                    // method code goes here
                    //xmlNodePtr pNewNode = xmlNewText( WSTR2XML(stdstr(_text)) );
                    xmlAddChild( pNode, xmlNewText( WSTR2XML(stdstr(_text)) ) );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - createChildNode
        // GENERATOR: METHOD SIGNATURE - G!P0R#createChildNode@IVS!P0G@OVS!P1?__cli__sixml__iNode@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(createChildNode) (THIS_ const CLISTR*     nodeTagName
                                        , ::cli::sixml::iNode**    pNewChildNode /* [out] ::cli::sixml::iNode* pNewChildNode  */
                                   )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // nodeTagName not an optional ptr or ref
                    if (!nodeTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"nodeTagName" );  }
                    
                    // pNewChildNode not an optional ptr or ref
                    if (!pNewChildNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pNewChildNode" );  }

                    // method code goes here
                    xmlNodePtr pNewXmlNode = xmlNewNode( 0 /* ns */ , WSTR2XML(stdstr(nodeTagName)) );
                    xmlAddChild( pNode, pNewXmlNode );
                    CNodeImpl *pNewNode = new CNodeImpl( pNewXmlNode );
                    (*pNewChildNode) = static_cast< ::cli::sixml::iNode* >(pNewNode);
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - createChildNodeWithText
        // GENERATOR: METHOD SIGNATURE - G!P0R#createChildNodeWithText@IVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(createChildNodeWithText) (THIS_ const CLISTR*     nodeTagName
                                                , const CLISTR*     nodeText
                                           )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // nodeTagName not an optional ptr or ref
                    if (!nodeTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"nodeTagName" );  }
                    
                    // nodeText not an optional ptr or ref
                    if (!nodeText) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"nodeText" );  }
                    
                    // method code goes here
                    xmlNewTextChild(pNode, 0 /*ns*/, WSTR2XML(stdstr(nodeTagName)), WSTR2XML(stdstr(nodeText)) );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - findChild
        // GENERATOR: METHOD SIGNATURE - G!P0R#findChild@IVS!P0G@OVS!P1?__cli__sixml__iNode@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(findChild) (THIS_ const CLISTR*     childTagName
                                  , ::cli::sixml::iNode**    pChildNode /* [out] ::cli::sixml::iNode* pChildNode  */
                             )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // childTagName not an optional ptr or ref
                    if (!childTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"childTagName" );  }
                    
                    // pChildNode not an optional ptr or ref
                    if (!pChildNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pChildNode" );  }

                    // method code goes here
                    ::std::string utfChildNodeName = WSTR2XMLSTR(stdstr(childTagName));
                    xmlNode *cur_node = pNode->children;
                    for (; cur_node; cur_node = cur_node->next)
                        {
                         if (!cur_node->name) continue;
                         //const char* nodeName = c.name();
                         //if (!nodeName) continue;
                         if (strcmp(utfChildNodeName.c_str(), (const char*)cur_node->name)) continue;

                         CNodeImpl *pNewNode = new CNodeImpl( cur_node );
                         (*pChildNode) = static_cast< ::cli::sixml::iNode* >(pNewNode);
                         return EC_OK;
                        }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
            //return EC_NOT_IMPLEMENTED;
           }

        // GENERATOR: METHOD - childTextGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#childTextGet@OVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(childTextGet) (THIS_ CLISTR*           _childText
                                     , const CLISTR*     idx1
                                )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _childText not an optional ptr or ref
                    if (!_childText) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_childText" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here
                    ::std::string utfChildNodeName = WSTR2XMLSTR(stdstr(idx1));
                    xmlNode *cur_node = pNode->children;
                    for (; cur_node; cur_node = cur_node->next)
                        {
                         if (!cur_node->name) continue;
                         if (strcmp(utfChildNodeName.c_str(), (const char*)cur_node->name)) continue;
                         return ::cli::propertyGetImpl(_childText, XML2WSTR(libxml2_helpers::getNodeText( cur_node )) );
                        }
                    //
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
            //return EC_OK;
           }

        // GENERATOR: METHOD - findChildNodes
        // GENERATOR: METHOD SIGNATURE - G!P0R#findChildNodes@IVS!P0G@OVS!P1?__cli__sixml__iNodeSet@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(findChildNodes) (THIS_ const CLISTR*     childsTagName
                                       , ::cli::sixml::iNodeSet**    pNodeSet /* [out] ::cli::sixml::iNodeSet* pNodeSet  */
                                  )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // childsTagName not an optional ptr or ref
                    if (!childsTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"childsTagName" );  }
                    
                    // pNodeSet not an optional ptr or ref
                    if (!pNodeSet) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pNodeSet" );  }
                    
                    // method code goes here
                    (*pNodeSet) = 0;
                    
                    // CLIASSERT(tag_name);
                    ::std::string childName = WSTR2XMLSTR( stdstr(childsTagName) );
                    xmlNode *cur_node = pNode->children;
                    for (; cur_node; cur_node = cur_node->next)
                        {
                         if (!cur_node->name) continue;
                         if (strcmp(childName.c_str(), (const char*)cur_node->name)) continue;
                         if (!(*pNodeSet))
                            *pNodeSet = new CNodeSetImpl();

                         CNodeImpl *pNodeImpl = new CNodeImpl( cur_node );
                         (*pNodeSet)->pushNode( pNodeImpl );
                         pNodeImpl->release();
                        }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }



}; // struct CNodeImpl



}; // namespace impl
}; // namespace sixml
}; // namespace cli



#endif /* CLI_XML_SIXML_NODEIMPLTPL_H */

