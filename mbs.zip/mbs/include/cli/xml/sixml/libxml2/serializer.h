#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_LIBXML2_SERIALIZER_H
#define CLI_XML_SIXML_LIBXML2_SERIALIZER_H


#ifndef CLI_XML_SIXML_SERIALIZERCOMMON_H
    #include <cli/xml/sixml/serializerCommon.h>
#endif

#ifndef CLI_XML_SIXML_LIBXML2_NODEIMPLTPL_H
    #include <cli/xml/sixml/libxml2/NodeImpl.h>
#endif

#include <libxml/xmlversion.h>

#ifndef LIBXML_XINCLUDE_ENABLED
    #define LIBXML_XINCLUDE_ENABLED
#endif

#include <libxml/xinclude.h>

// http://www.xmlsoft.org/tree.html

#ifdef _MSC_VER
    #pragma comment( lib, "libxml2" )
#endif


// ::sixml::
// ::sixml::serializer::
// ::sixml::serializer::libxml2::
namespace sixml
{
namespace serializer
{

void serializeToXmlString( ::std::string &xmlString
                                  , INTERFACE_CLI_SIXML_INODE* pNode
                                  , unsigned int flags = 0
                                  );

namespace libxml2
{

// load xml code
    /*
    int parseOptions = XML_PARSE_NOENT|XML_PARSE_NOBLANKS|XML_PARSE_NONET|XML_PARSE_NOXINCNODE|XML_PARSE_HUGE|XML_PARSE_NOCDATA;

    xmlDocPtr doc;
    //doc = xmlReadFile(filename, NULL, parseOptions);
    doc = xmlReadMemory(xmlString.data(), (int)xmlString.size(), "noname.xml", NULL, parseOptions);
    if (!doc)
       {
        // handle error
        xmlCleanupParser();
        return;
       }

    xmlNode *root_element = xmlDocGetRootElement(doc);

    #if defined(UNICODE) || defined(_UNICODE)
    ::std::string strRootTag = MARTY_UTF::toUtf8(rootTag);
    #else
    const ::std::string &strRootTag = rootTag;
    #endif

    ::std::string actualRootTagName = libxml2_helpers::getNodeName(root_element);
    */

class CXmlEngineGlobalInitializer
{
    public:
        CXmlEngineGlobalInitializer()
           {
            xmlInitParser();
           }
        ~CXmlEngineGlobalInitializer()
           {
            xmlCleanupParser();
           }
};


//typename CAfterLoadProcessingPred = CDoNothing<DataType>
//template <typename DataType >
inline
INTERFACE_CLI_SIXML_INODE* loadToSixmlDomNode( const ::std::string &xmlString
                                             , const ::sixml::util::tstring &rootTag
                                             , ::sixml::util::tstring *pReadedRootTag
                                             , unsigned int flags = 0
                                             , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
                                             )
   {
    xmlInitParser();

    int parseOptions = XML_PARSE_NOENT|XML_PARSE_NOBLANKS|XML_PARSE_NONET|XML_PARSE_NOXINCNODE|XML_PARSE_HUGE|XML_PARSE_NOCDATA;
    if (flags&rfUseXInclude)
       parseOptions |= XML_PARSE_XINCLUDE;

    #if defined(UNICODE) || defined(_UNICODE)
    ::std::string url = MARTY_UTF::toUtf8(baseFile);
    #else
    ::std::string url = baseFile;
    #endif
    if (url.empty()) url = "noname.xml";
    xmlDocPtr doc = xmlReadMemory(xmlString.data(), (int)xmlString.size(), url.c_str(), NULL, parseOptions);
    if (!doc)
       {
        // undone : handle error
        //xmlCleanupParser();
        //return 0;
        throw ::std::runtime_error("libxml2: parsing XML error");
       }

    if (flags&rfUseXInclude)
       { 
        xmlXIncludeProcess(doc);
        //if (xmlXIncludeProcess(doc)<0)
        //   std::cerr<<"Warning: XInclude processing failed (--xinclude option)\n";
       }

    xmlNode *root_element = xmlDocGetRootElement(doc);

    ::std::string rootElementNameStr = libxml2_helpers::getNodeName( root_element );

    if (pReadedRootTag)
       #if defined(UNICODE) || defined(_UNICODE)
       *pReadedRootTag = MARTY_UTF::fromUtf8(rootElementNameStr);
       #else
       *pReadedRootTag = rootElementNameStr;
       #endif

    if (!(flags&rfSkipCheckRoot))
       {
        #if defined(UNICODE) || defined(_UNICODE)
        ::std::string strRootTag = MARTY_UTF::toUtf8(rootTag);
        #else
        const ::std::string &strRootTag = rootTag;
        #endif

        if (rootElementNameStr != strRootTag)
           {
            xmlFreeDoc(doc);
            //xmlCleanupParser();
            #if defined(UNICODE) || defined(_UNICODE)
            ::sixml::throw_wrong_root_tag( rootTag, MARTY_UTF::fromUtf8(rootElementNameStr) );
            #else
            ::sixml::throw_wrong_root_tag( rootTag, rootElementNameStr );
            #endif
           }
       }
    return new ::cli::sixml::impl::CNodeImpl( root_element, doc );
   }


/*! ���������� �������������� (��������) ������ �� XML-�������.
*/
template <typename DataType, typename CAfterLoadProcessingPred >
void loadEx( const ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag
         , const CAfterLoadProcessingPred &processingPred
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = ::sixml::serializer::default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
   {
    ::cli::sixml::CiNode nodeImpl( loadToSixmlDomNode( xmlString
                                                     , rootTag
                                                     , pReadedRootTag
                                                     , flags
                                                     , baseFile
                                                     )
                                 , true // no addRef
                                 ); 
    ::sixml::serializer::parseSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    //read_node( nodeImpl.getIfPtr(), data, dmc );
    //processingPred( nodeImpl.getIfPtr(), data );
    //xmlFreeDoc(doc);
    //xmlCleanupParser();
   }


template <typename DataType>
void load( const ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag = 0
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = ::sixml::serializer::default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
    {
     ::sixml::serializer::libxml2::loadEx( xmlString, rootTag, data, pReadedRootTag, ::sixml::serializer::CDoNothing<DataType>(), flags, dmc, baseFile );
    }


// create new node for saving xml
inline
INTERFACE_CLI_SIXML_INODE* createSixmlDocumentRootForWriting( const ::sixml::util::tstring &rootTag
                                             , unsigned int flags = 0
                                             )
   {
    xmlInitParser();

    if (!(flags&wfCondenced))
       xmlIndentTreeOutput = 4;
    else
       xmlIndentTreeOutput = 0;

    xmlIndentTreeOutput = 1;
    //xmlIndentTreeOutput = format?1:0;
    //xmlKeepBlanksDefault(0);

    xmlDocPtr doc = xmlNewDoc(BAD_CAST "1.0");

    #if defined(UNICODE) || defined(_UNICODE)
    xmlNodePtr root_node = xmlNewNode(0 /*ns*/, BAD_CAST MARTY_UTF::toUtf8(rootTag).c_str() );
    #else
    xmlNodePtr root_node = xmlNewNode(0 /*ns*/, BAD_CAST rootTag.c_str() );
    #endif

    xmlDocSetRootElement(doc, root_node);

    return new ::cli::sixml::impl::CNodeImpl( root_node, doc );
   }



inline
void serializeToXmlString( ::std::string &xmlString
                                      , INTERFACE_CLI_SIXML_INODE* pNode
                                      , unsigned int flags = 0
                                      )
   {
    xmlDocPtr doc = (xmlDocPtr)pNode->getDocPtr();
    if (!doc)
       {
        return; // not a root node
       }

    xmlChar *pMem    = 0;
    int      memSize = 0;
    // format = 1 aplied only if xmlIndentTreeOutput = 1 or xmlKeepBlanksDefault(0) was called
    //xmlDocDumpFormatMemory( doc, &pMem, &memSize, 1 /* format */ );
    //xmlDocDumpFormatMemory( doc, &pMem, &memSize, (flags&wfCondenced ? 0 : 1 ) /* format */ );
    //xmlDocDumpFormatMemoryEnc( doc, &pMem, &memSize, "UTF-8", 1 );
    xmlDocDumpFormatMemoryEnc( doc , &pMem, &memSize, "UTF-8", (flags&wfCondenced ? 0 : 1 ) );
 
    if (flags&wfBom)
       {
        xmlString.append( 1, (char)(unsigned char)0xefU);
        xmlString.append( 1, (char)(unsigned char)0xbbU);
        xmlString.append( 1, (char)(unsigned char)0xbfU);
        xmlString.append( (const char*)pMem, (size_t)memSize );
       }
    else
       {
        xmlString.assign( (const char*)pMem, (size_t)memSize );
       }
    xmlFree(pMem);

    if (!(flags&wfCondenced))
       ::sixml::helpers::replaceInplace( xmlString, "><", ">\n<");

    //::std::string replaceTo = "<?xml version=\"1.0\" encoding=\"UTF-8\"";
    if (flags&wfStandalone) 
       {
        ::std::string replaceStr = "<?xml version=\"1.0\" encoding=\"UTF-8\">";
        ::std::string replaceTo = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"";
        ::sixml::helpers::replaceFirstInplace( xmlString, replaceStr, replaceTo);
       }

    //xmlFreeDoc(doc);
   
   }



template <typename DataType, typename CBeforeSaveProcessingPred>
void saveEx( ::std::string &xmlString
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , const CBeforeSaveProcessingPred &processingPred
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = ::sixml::serializer::default_meta_class<DataType>()
          )
   {
    ::cli::sixml::CiNode nodeImpl( createSixmlDocumentRootForWriting( rootTag, flags ), true ); // no addRef
    ::sixml::serializer::serializeToSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    ::sixml::serializer::serializeToXmlString( xmlString, nodeImpl.getIfPtr(), flags );
   }

template <typename DataType>
void save( ::std::string &xmlString
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
   {
    ::sixml::serializer::libxml2::saveEx( xmlString, rootTag, data, ::sixml::serializer::CDoNothing<DataType>(), flags, dmc );
   }


}; // namespace libxml2
}; // namespace serializer
}; // namespace sixml


#if !defined(CLI_SIXML_ALLOW_MIX_ENGINES)
// publish libxml2 functions in common ::sixml::serializer namespace
    #ifdef CLI_XML_SIXML_ENGINE
        #undef CLI_XML_SIXML_ENGINE
    #endif // CLI_XML_SIXML_ENGINE
    #define CLI_XML_SIXML_ENGINE    libxml2
    #include "../publishEngine.h"
#endif // CLI_SIXML_ALLOW_MIX_ENGINES



#endif /* CLI_XML_SIXML_LIBXML2_SERIALIZER_H */

