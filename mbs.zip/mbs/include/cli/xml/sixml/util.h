#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

/* Utility functions and classes - sixml serializer internal header file
 * Designed by Andrey Martynov
 * mailto:rek@.rsdn.ru
 * Rewritten by Alex Martinov (amart@mail.ru), 2004.
 */
#ifndef CLI_XML_SIXML_UTIL_H
#define CLI_XML_SIXML_UTIL_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_XML_SIXML_6MLEXCEP_H
    #include <cli/xml/sixml/6mlexcep.h>
#endif

#if !defined(_STRING_) && !defined(__STD_STRING__) && !defined(__STD_STRING)
    #include <string>
#endif

/*
#if !defined(_INC_TCHAR) && !defined(__TCHAR_H)    
    #include <tchar.h>
#endif
*/

#if !defined(_INC_LIMITS) && !defined(__LIMITS_H)    
    #include <limits.h>
#endif

#ifndef CLI_XML_SIXML_PRIMUTIL_H
    #include <cli/xml/sixml/primutil.h>
#endif


namespace sixml{
namespace util{


#ifndef SIXML_UTIL_TSTRING_DEFINED
#define SIXML_UTIL_TSTRING_DEFINED
typedef std::basic_string<TCHAR>  tstring;
// using ::sixml::util::tstring
#endif /* SIXML_UTIL_TSTRING_DEFINED */



template <typename RefcountedType>
class CPtrShared
{
public:
    typedef CPtrShared<RefcountedType> my_t;

    CPtrShared(const CPtrShared&);
    CPtrShared(RefcountedType* = 0);
    ~CPtrShared();

    CPtrShared<RefcountedType>& operator=(CPtrShared<RefcountedType>& _Right);
    CPtrShared<RefcountedType>& operator=(RefcountedType*);

    bool operator == (const my_t&    ) const;
    bool operator == (RefcountedType*) const;
    bool operator != (const my_t&    ) const;
    bool operator != (RefcountedType*) const;

    operator RefcountedType* ()   const { return m_p; }
    RefcountedType* operator ->() const { return m_p; }

    #define SIXML_DISABLE_CPTRSHARED_OPERATOR_AMP
    #ifndef SIXML_DISABLE_CPTRSHARED_OPERATOR_AMP
    RefcountedType** operator&(); //
    #endif

    void CopyTo(RefcountedType** pp)
        { *pp = m_p; m_p->AddRef(); }
private:
    RefcountedType* m_p;
};


class CRefcounted
{
public:
    CLIMETHOD_(ULONG,AddRef) ();
    CLIMETHOD_(ULONG,Release) ();

    CRefcounted();
    virtual ~CRefcounted() ;
    //virtual void destroy() = 0;
    CLIMETHOD_(VOID, destroy) (THIS) PURE;
    // void destroy() { delete this; }

#ifdef _DEBUG
    long  Counter() const;
#endif // _DEBUG

private:
    // long m_cRef;
    ::cli::CRefCounter m_cRef;
};


template <class T> inline
CPtrShared<T>::CPtrShared(T* p)
    : m_p( p )
{
    if (m_p != 0)
        m_p->AddRef();
}


template <class T> inline
CPtrShared<T>::CPtrShared(const CPtrShared<T>& p)
    : m_p(p.m_p)
{
    if (m_p != 0)
        m_p->AddRef();
}


template <class Type> inline
CPtrShared<Type>::~CPtrShared()
{
    if (m_p != NULL)
        m_p->Release();
}


template <class T> inline
CPtrShared<T>& CPtrShared<T>::operator=(CPtrShared<T>& a)
{
    if (*this != a)
    {   
        if (m_p != 0)
            m_p->Release();

        m_p = a.m_p; 

        if (m_p != 0)
            m_p->AddRef();
    }
    return *this; 
}


template <class T> inline
CPtrShared<T>& CPtrShared<T>::operator=(T* p)
{
    if (m_p != p)
    {   
        if (m_p != 0)
            m_p->Release();

        m_p = p; 

        if (m_p != 0)
            m_p->AddRef();
    }
    return *this; 
}

#ifndef SIXML_DISABLE_CPTRSHARED_OPERATOR_AMP
template <class T> inline
T** CPtrShared<T>::operator&()
{
    if (m_p!=0)
    {
        m_p->Release();
        m_p = 0;
    }
    return &m_p;
}
#endif // SIXML_DISABLE_CPTRSHARED_OPERATOR_AMP



template <class T> inline
bool CPtrShared<T>::operator == (const CPtrShared<T>& p) const
    { return m_p == p.m_p; }

template <class T> inline
bool CPtrShared<T>::operator == (T* p) const
    { return m_p == p; }

template <class T> inline
bool CPtrShared<T>::operator != (const CPtrShared<T>& p) const
    { return m_p != p.m_p; }

template <class T> inline
bool CPtrShared<T>::operator != (T* p) const
    { return m_p != p; }



//-----------------------------------------------------------------------------
//                      CRefcounted
//-----------------------------------------------------------------------------

inline CRefcounted::CRefcounted()
    : m_cRef(0)
    {}

inline CRefcounted::~CRefcounted()
    { /*ASSERT(m_cRef == 0);*/ }

inline ULONG CRefcounted::AddRef()
    { 
     //return InterlockedIncrement(&m_cRef) ;
     return (ULONG)(ilint_t)++m_cRef;
    }

inline ULONG CRefcounted::Release()
{
    if (! --m_cRef) 
       { 
        //delete this;
        destroy();
        return 0; 
       }  
    return (ULONG)(ilint_t)m_cRef;
    /*
    InterlockedDecrement(&m_cRef) ;
    if (m_cRef == 0)
    {
        delete this;
        return 0;
    }
    return m_cRef ;
    */
}
#ifdef _DEBUG
inline long  CRefcounted::Counter() const
    { 
        return (ULONG)(ilint_t)m_cRef; 
    }
#endif // _DEBUG

}; // namespace sixml

}; // nameespace util

#endif /* CLI_XML_SIXML_UTIL_H */

