#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_NODEIMPLTPL_H
#define CLI_XML_SIXML_NODEIMPLTPL_H

// This file contains code template for implementing iNode class.
// Use it if you want add support for some other XML engine
// Create directory <engine> in cli/xml/sixml
// copy this file into newly created directory (see command line below)
//      copy cli/xml/sixml/NodeImplTpl.h cli/xml/sixml/<engine>/NodeImpl.h
// Add your code into class methods 


#ifndef CLI_XML_SIXML_NODEIMPLBASE_H
    #include <cli/xml/sixml/NodeImplBase.h>
#endif

#ifndef CLI_XML_SIXML_NODESETIMPL_H
    #include <cli/xml/sixml/NodeSetImpl.h>
#endif

// Ours strings are always wide
// PUGIXML strings are always char (utf8)
#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

/*
#if defined(UNICODE) || defined(_UNICODE)
    #ifndef MARTY_UTF_H
        #include <marty/utf.h>
    #endif
   #define TSTR2PUGISTR(str)  MARTY_UTF::toUtf8(str)
   #define TSTR2PUGI(str)  MARTY_UTF::toUtf8(str).c_str()
   #define PUGI2TSTR(str)  MARTY_UTF::fromUtf8(str)
#else
   #define TSTR2PUGISTR(str)  str
   #define TSTR2PUGI(str)  str.c_str()
   #define PUGI2TSTR(str)  str
#endif
*/

#define WSTR2TINYSTR(str)  MARTY_UTF::toUtf8(str)
#define WSTR2TINY(str)  MARTY_UTF::toUtf8(str).c_str()
#define TINY2WSTR(str)  MARTY_UTF::fromUtf8(str)


#ifndef TINYXML_INCLUDED
    #include <cli/xml/sixml/tinyxml/tinyxml.h>
#endif


namespace cli {
namespace sixml {
namespace impl {


namespace helpers
{

    void getNodeText( TiXmlElement*  pNode, ::std::string &resStr, bool bRecur = false)
       {
        CLIASSERT(pNode);
        for(TiXmlNode * cur_node = pNode->FirstChild(); cur_node; cur_node = cur_node->NextSibling())
           {
            int nodeType = cur_node->Type();
            if (nodeType==(int)TiXmlNode::TEXT)
               {
                const TiXmlText *pTextNode = cur_node->ToText(); // dynamic_cast<TiXmlText*>(asNode);               
                if (pTextNode)
                   {
                    const char *pv = pTextNode->Value();
                    if (pv) resStr.append(pv);
                   }
               }
            else if (nodeType==(int)TiXmlNode::ELEMENT && bRecur)
               {
                TiXmlElement *pElem = cur_node->ToElement();
                if (pElem)
                   getNodeText( pElem, resStr, true);
               }
           }
       }

}; // namespace helpers

struct CNodeImpl : public CNodeImplBase
{
        TiXmlElement*  pNode;
        TiXmlDocument *pDoc;
        CNodeImpl(TiXmlElement* pn) : CNodeImplBase(), pNode(pn), pDoc(0) {}
        CNodeImpl(TiXmlElement* pn, TiXmlDocument *pd) : CNodeImplBase(), pNode(pn), pDoc(pd) {}
        ~CNodeImpl()
           {
            if (pDoc) delete pDoc;
           }

        // Interface map - queryInterface implementation

        CLI_BEGIN_INTERFACE_MAP2(CNodeImplBase, INTERFACE_CLI_SIXML_INODE)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_SIXML_INODE )
        CLI_END_INTERFACE_MAP(CNodeImplBase)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

        // final implementation
        CLIMETHOD_(VOID, destroy) (THIS)
            {
             #include <cli/compspec/delthis.h>
            }

        CLIMETHOD_(VOID*, getDocPtr) (THIS)
           {
            return (VOID*)pDoc;
           }

        // GENERATOR: METHOD - attributesGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#attributesGet@OVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(attributesGet) (THIS_ CLISTR*           _attributes
                                      , const CLISTR*     idx1
                                 )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _attributes not an optional ptr or ref
                    if (!_attributes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_attributes" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here
                    const char *attrValTiny = pNode->Attribute( WSTR2TINY(stdstr(idx1)));
                    if (!attrValTiny) return EC_NOT_FOUND;
                    return ::cli::propertyGetImpl( _attributes, ( TINY2WSTR(attrValTiny) ) );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - attributesSet
        // GENERATOR: METHOD SIGNATURE - G!P0R#attributesSet@IVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(attributesSet) (THIS_ const CLISTR*     _attributes
                                      , const CLISTR*     idx1
                                 )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _attributes not an optional ptr or ref
                    if (!_attributes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_attributes" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here
                    //WSTR2TINY
                    ::std::string strAttrName = WSTR2TINYSTR(stdstr(idx1));
                    RCODE resCode = EC_OK; 
                    if ( pNode->Attribute( strAttrName.c_str() ) )
                       resCode = EC_ALLREADY;

                    pNode->SetAttribute( strAttrName.c_str(), WSTR2TINY(stdstr(_attributes)) );
                    return resCode;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - getAttributeByIndex
        // GENERATOR: METHOD SIGNATURE - G!P0R#getAttributeByIndex@OVS!P0G@OVS!P0G@IVS!P0T@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(getAttributeByIndex) (THIS_ CLISTR*           attrName
                                            , CLISTR*           attrVal
                                            , SIZE_T    idx /* [in] size_t  idx  */
                                       )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // attrName not an optional ptr or ref
                    if (!attrName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"attrName" );  }
                    
                    // attrVal not an optional ptr or ref
                    if (!attrVal) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"attrVal" );  }
                    
                    // method code goes here
                    SIZE_T curIdx = 0;
                    TiXmlAttribute *a = pNode->FirstAttribute();
                    for ( ; a ; a = a->Next(), ++curIdx)
                        {
                         if (curIdx==idx)
                            {
                             const char *attrNameTiny = a->Name();
                             const char *attrValTiny  = a->Value();
                             ::cli::propertyGetImpl( attrName, TINY2WSTR(attrNameTiny?attrNameTiny:"") );
                             ::cli::propertyGetImpl( attrVal , TINY2WSTR(attrValTiny?attrValTiny:"") );
                             return EC_OK;
                            }
                        }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_NOT_IMPLEMENTED;
            return EC_OUT_OF_RANGE;
           }

        // GENERATOR: METHOD - nameGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#nameGet@OVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(nameGet) (THIS_ CLISTR*           _name)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _name not an optional ptr or ref
                    if (!_name) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_name" );  }
                    
                    // method code goes here
                    const char *tinyTagName = pNode->Value();
                    if (!tinyTagName)
                       return ::cli::propertyGetImpl( _name, ::std::wstring(L"") );
                    return ::cli::propertyGetImpl( _name, TINY2WSTR(tinyTagName) );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - textGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#textGet@OVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(textGet) (THIS_ CLISTR*           _text)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _text not an optional ptr or ref
                    if (!_text) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_text" );  }
                    
                    // method code goes here
                    //const char *pText = pNode->GetText();
                    ::std::string textStr;
                    helpers::getNodeText( pNode, textStr, false /* true */ );
                    //if (!pText)
                    //   return ::cli::propertyGetImpl( _text, ::std::wstring(L"") );
                    return ::cli::propertyGetImpl( _text, TINY2WSTR(textStr) );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - textSet
        // GENERATOR: METHOD SIGNATURE - G!P0R#textSet@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(textSet) (THIS_ const CLISTR*     _text)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _text not an optional ptr or ref
                    if (!_text) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_text" );  }
                    // method code goes here
                    pNode->LinkEndChild( new TiXmlText( WSTR2TINY(stdstr(_text)) ) ); 
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - createChildNode
        // GENERATOR: METHOD SIGNATURE - G!P0R#createChildNode@IVS!P0G@OVS!P1?__cli__sixml__iNode@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(createChildNode) (THIS_ const CLISTR*     nodeTagName
                                        , ::cli::sixml::iNode**    pNewChildNode /* [out] ::cli::sixml::iNode* pNewChildNode  */
                                   )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // nodeTagName not an optional ptr or ref
                    if (!nodeTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"nodeTagName" );  }
                    
                    // pNewChildNode not an optional ptr or ref
                    if (!pNewChildNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pNewChildNode" );  }
                    
                    // method code goes here
                    TiXmlElement *pNewTiNode = new TiXmlElement( WSTR2TINY(stdstr(nodeTagName)) );
                    pNode->LinkEndChild( pNewTiNode );
                    CNodeImpl *pNewNode = new CNodeImpl( pNewTiNode );
                    (*pNewChildNode) = static_cast< ::cli::sixml::iNode* >(pNewNode);
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - createChildNodeWithText
        // GENERATOR: METHOD SIGNATURE - G!P0R#createChildNodeWithText@IVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(createChildNodeWithText) (THIS_ const CLISTR*     nodeTagName
                                                , const CLISTR*     nodeText
                                           )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // nodeTagName not an optional ptr or ref
                    if (!nodeTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"nodeTagName" );  }
                    
                    // nodeText not an optional ptr or ref
                    if (!nodeText) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"nodeText" );  }

                    // method code goes here
                    TiXmlElement * pNewNode = new TiXmlElement( WSTR2TINY(stdstr(nodeTagName)) );
                    pNewNode->LinkEndChild( new TiXmlText( WSTR2TINY(stdstr(nodeText)) ));  
                    pNode->LinkEndChild( pNewNode );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - findChild
        // GENERATOR: METHOD SIGNATURE - G!P0R#findChild@IVS!P0G@OVS!P1?__cli__sixml__iNode@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(findChild) (THIS_ const CLISTR*     childTagName
                                  , ::cli::sixml::iNode**    pChildNode /* [out] ::cli::sixml::iNode* pChildNode  */
                             )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // childTagName not an optional ptr or ref
                    if (!childTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"childTagName" );  }
                    
                    // pChildNode not an optional ptr or ref
                    if (!pChildNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pChildNode" );  }
                    
                    // method code goes here
                    ::std::string childName = WSTR2TINYSTR( stdstr(childTagName) );
                    for(TiXmlNode * cur_node = pNode->FirstChild(); cur_node; cur_node = cur_node->NextSibling())
                       {
                        int nodeType = cur_node->Type();
                        if (nodeType!=(int)TiXmlNode::ELEMENT) continue;
                        TiXmlElement *pElem = cur_node->ToElement();
                        if (!pElem) continue;

                        const char *tinyTagName = pElem->Value();
                        if (!tinyTagName) continue;
                            if (strcmp(tinyTagName, childName.c_str())) continue;

                        CNodeImpl *pNewNode = new CNodeImpl( pElem );
                        (*pChildNode) = static_cast< ::cli::sixml::iNode* >(pNewNode);

                        return EC_OK;
                       }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
           }

        // GENERATOR: METHOD - childTextGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#childTextGet@OVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(childTextGet) (THIS_ CLISTR*           _childText
                                     , const CLISTR*     idx1
                                )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _childText not an optional ptr or ref
                    if (!_childText) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_childText" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here
                    std::string childNameTiny = WSTR2TINYSTR(stdstr(idx1));
                    TiXmlElement *childElement = pNode->FirstChildElement(childNameTiny.c_str()); 
                    if (!childElement)
                       return EC_NOT_FOUND;

                    ::std::string textStr;
                    helpers::getNodeText( childElement, textStr, false /* true */ );
                    return ::cli::propertyGetImpl( _childText, TINY2WSTR(textStr) );
                    /*
                    const char *pText = childElement->GetText();
                    if (!pText)
                       return ::cli::propertyGetImpl( _childText, ::std::wstring(L"") );
                    return ::cli::propertyGetImpl( _childText, TINY2WSTR(pText) );
                    */
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - findChildNodes
        // GENERATOR: METHOD SIGNATURE - G!P0R#findChildNodes@IVS!P0G@OVS!P1?__cli__sixml__iNodeSet@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(findChildNodes) (THIS_ const CLISTR*     childsTagName
                                       , ::cli::sixml::iNodeSet**    pNodeSet /* [out] ::cli::sixml::iNodeSet* pNodeSet  */
                                  )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // childsTagName not an optional ptr or ref
                    if (!childsTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"childsTagName" );  }
                    
                    // pNodeSet not an optional ptr or ref
                    if (!pNodeSet) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pNodeSet" );  }
                    
                    // method code goes here
                    (*pNodeSet) = 0;

                    ::std::string childsTagNameTiny = WSTR2TINYSTR(stdstr(childsTagName));
                    for(TiXmlElement * cur_node = pNode->FirstChildElement(); cur_node; cur_node = cur_node->NextSiblingElement())
                       {
                        if (cur_node->Type()!=(int)TiXmlNode::ELEMENT) continue;
                        const char *tinyTagName = cur_node->Value();
                        if (!tinyTagName) continue;
                        if (strcmp(childsTagNameTiny.c_str(), tinyTagName)) continue;
                        if (!(*pNodeSet))
                           *pNodeSet = new CNodeSetImpl();

                        CNodeImpl *pNodeImpl = new CNodeImpl( cur_node );
                        (*pNodeSet)->pushNode( pNodeImpl );
                        pNodeImpl->release();
                       }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }



}; // struct CNodeImpl



}; // namespace impl
}; // namespace sixml
}; // namespace cli



#endif /* CLI_XML_SIXML_NODEIMPLTPL_H */

