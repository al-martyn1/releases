#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_TINY_SERIALIZER_H
#define CLI_XML_SIXML_TINY_SERIALIZER_H

#ifndef CLI_XML_SIXML_SERIALIZERCOMMON_H
    #include <cli/xml/sixml/serializerCommon.h>
#endif

#ifndef CLI_XML_SIXML_TINYXML_NODEIMPLTPL_H
    #include <cli/xml/sixml/tinyxml/NodeImpl.h>
#endif

#ifndef TINYXML_INCLUDED
    #include <cli/xml/sixml/tinyxml/tinyxml.h>
#endif


// ::sixml::
// ::sixml::serializer::
// ::sixml::serializer::tinyxml::

namespace sixml
{
namespace serializer
{

void serializeToXmlString( ::std::string &xmlString
                                  , INTERFACE_CLI_SIXML_INODE* pNode
                                  , unsigned int flags = 0
                                  );


//#define WSTR2TINYSTR(str)  MARTY_UTF::toUtf8(str)
//#define WSTR2TINY(str)  MARTY_UTF::toUtf8(str).c_str()
//#define TINY2WSTR(str)  MARTY_UTF::fromUtf8(str)

namespace tiny_helpers{

// pugi_helpers::pugi2rcode
RCODE tiny2rcode( int status )
   {   
    switch(status)
       {
        case TiXmlBase::TIXML_NO_ERROR                           : return EC_XML_OK;                  // "No error"
        case TiXmlBase::TIXML_ERROR_OPENING_FILE                 : return EC_FILE_NOT_FOUND;          // "Failed to open file"
        //case pugi::status_io_error                             : return EC_IO_ERROR;  // has no equivalent
        case TiXmlBase::TIXML_ERROR_OUT_OF_MEMORY                : return EC_NOT_ENOUGH_MEM;          // "Memory allocation failed."
        case TiXmlBase::TIXML_ERROR                              : return EC_XML_INTERNAL_ERROR;      // "Error"
        case TiXmlBase::TIXML_ERROR_PARSING_ELEMENT              : return EC_XML_BAD_ELEMENT;         // !
        case TiXmlBase::TIXML_ERROR_FAILED_TO_READ_ELEMENT_NAME  : return EC_XML_BAD_ELEMENT_NAME;    // !
        case TiXmlBase::TIXML_ERROR_READING_ELEMENT_VALUE        : return EC_XML_BAD_ELEMENT_VALUE;   // !

        case TiXmlBase::TIXML_ERROR_PARSING_EMPTY                : return EC_XML_BAD_TAG;
        case TiXmlBase::TIXML_ERROR_PARSING_UNKNOWN              : return EC_XML_BAD_TAG;
        case TiXmlBase::TIXML_ERROR_PARSING_DECLARATION          : return EC_XML_BAD_DECLARATION;     // !
        case TiXmlBase::TIXML_ERROR_DOCUMENT_EMPTY               : return EC_XML_DOCUMENT_EMPTY;      // !
        case TiXmlBase::TIXML_ERROR_EMBEDDED_NULL                : return EC_XML_UNEXPECTED_END;      // !
        //case pugi::status_bad_pi               :  return EC_XML_BAD_PI;
        case TiXmlBase::TIXML_ERROR_PARSING_COMMENT              : return EC_XML_BAD_COMMENT;
        case TiXmlBase::TIXML_ERROR_PARSING_CDATA                : return EC_XML_BAD_CDATA;
        case TiXmlBase::TIXML_ERROR_DOCUMENT_TOP_ONLY            : return EC_XML_INTERNAL_ERROR;
        //case pugi::status_bad_doctype          :  return EC_XML_BAD_DOCTYPE;
        //case pugi::status_bad_pcdata           :  return EC_XML_BAD_PCDATA;
        //case pugi::status_bad_start_element    :  return EC_XML_BAD_START_ELEMENT;
        case TiXmlBase::TIXML_ERROR_READING_ATTRIBUTES        :  return EC_XML_BAD_ATTRIBUTE;
        case TiXmlBase::TIXML_ERROR_READING_END_TAG      :  return EC_XML_BAD_END_ELEMENT;
        //case pugi::status_end_element_mismatch :  return EC_XML_TAG_MISMATCH;
        //case pugi:: :  return ;
        default:            return EC_XML_UNKNOWN_ERROR;
       }
   }

}; // namespace tiny_helpers



#if 0
virtual const char* Parse( const char* p, TiXmlParsingData* data = 0, TiXmlEncoding encoding = TIXML_DEFAULT_ENCODING );
#endif


namespace tinyxml
{


class CXmlEngineGlobalInitializer
{
    public:
        CXmlEngineGlobalInitializer()
           {
           }
        ~CXmlEngineGlobalInitializer()
           {
           }
};


inline
INTERFACE_CLI_SIXML_INODE* loadToSixmlDomNode( const ::std::string &xmlString
                                             , const ::sixml::util::tstring &rootTag
                                             , ::sixml::util::tstring *pReadedRootTag
                                             , unsigned int flags = 0
                                             , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
                                             )
   {
    TiXmlDocument *pDoc = new TiXmlDocument();
    pDoc->SetTabSize( 4 );
    pDoc->SetCondenseWhiteSpace(false);

    const char * parseRes = pDoc->Parse( xmlString.c_str() );
    if (pDoc->Error())
       {
        int row = pDoc->ErrorRow();
        int col = pDoc->ErrorCol();
        RCODE resCode = tiny_helpers::tiny2rcode( pDoc->ErrorId() );
        delete pDoc;
        ::sixml::throw_parse_error( resCode, row, col ); //line, pos );
       }

    TiXmlElement* pRootNode = pDoc->RootElement();
    //TiXmlNode* pRootNode = doc.RootElement();

    const char *tinyRootTagName = pRootNode->Value();
    if (!tinyRootTagName)
       {
        delete pDoc;
        ::sixml::throw_wrong_root_tag( rootTag, _T("") );
       }
    #if defined(UNICODE) || defined(_UNICODE)
    //::sixml::util::tstring rootTagNameTStr = MARTY_UTF::toUtf8(::cli::sixml::impl::pugi_helpers::getNodeNameHelper(rootNode));
    ::sixml::util::tstring rootTagNameTStr = MARTY_UTF::fromUtf8(tinyRootTagName);
    #else
    //::sixml::util::tstring rootTagNameTStr = ::cli::sixml::impl::pugi_helpers::getNodeNameHelper(rootNode);
    ::sixml::util::tstring rootTagNameTStr = tinyRootTagName;
    #endif

    if (pReadedRootTag)
       *pReadedRootTag = rootTagNameTStr;

    if (!(flags&rfSkipCheckRoot))
       {
        if (rootTagNameTStr!=rootTag)
           {
            delete pDoc;
            ::sixml::throw_wrong_root_tag( rootTag, rootTagNameTStr );
           }
       }
    return new ::cli::sixml::impl::CNodeImpl( pRootNode, pDoc );
   }

/*! ���������� �������������� (��������) ������ �� XML-�������.
*/
template < typename DataType
         , typename CAfterLoadProcessingPred
         >
void loadEx( const ::std::string &xmlString        /*!< ������, ���������� ������� ������ � ������� XML */
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag
         , const CAfterLoadProcessingPred &processingPred
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
   {
    ::cli::sixml::CiNode nodeImpl( loadToSixmlDomNode( xmlString
                                                     , rootTag
                                                     , pReadedRootTag
                                                     , flags
                                                     , baseFile
                                                     )
                                 , true // no addRef
                                 ); 
    parseSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    //read_node( nodeImpl.getIfPtr(), data, dmc );
    //processingPred( nodeImpl.getIfPtr(), data );
   }


template <typename DataType>
void load( const ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag = 0
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
    {
     ::sixml::serializer::tinyxml::loadEx( xmlString, rootTag, data, pReadedRootTag, CDoNothing<DataType>(), flags, dmc, baseFile );
    }


inline
INTERFACE_CLI_SIXML_INODE* createSixmlDocumentRootForWriting( const ::sixml::util::tstring &rootTag
                                             , unsigned int flags = 0
                                             )
   {
    TiXmlDocument *pDoc = new TiXmlDocument();
    if (!(flags&wfNoDeclaration))
       {
        TiXmlDeclaration * commonDecl = new TiXmlDeclaration( "1.0", "UTF-8", ((flags&wfStandalone) ? "yes" : "") );
        pDoc->LinkEndChild( commonDecl );
       }

    #if defined(UNICODE) || defined(_UNICODE)
    TiXmlElement * pRootNode = new TiXmlElement( WSTR2TINY(rootTag) );  
    #else
    TiXmlElement * pRootNode = new TiXmlElement( rootTag.c_str() );  
    #endif
    pDoc->LinkEndChild( pRootNode );
    return new ::cli::sixml::impl::CNodeImpl( pRootNode, pDoc );
   }


inline
void serializeToXmlString( ::std::string &xmlString
                                      , INTERFACE_CLI_SIXML_INODE* pNode
                                      , unsigned int flags = 0
                                      )
   {
    TiXmlDocument *pDoc = (TiXmlDocument*)pNode->getDocPtr();
    if (!pDoc)
       {
        return; // not a root node
       }
    if (flags&wfBom)
       {
        xmlString.append( 1, (char)(unsigned char)0xefU);
        xmlString.append( 1, (char)(unsigned char)0xbbU);
        xmlString.append( 1, (char)(unsigned char)0xbfU);
       }

    TiXmlPrinter printer;
    if (flags&wfCondenced)
       {
        printer.SetIndent( "" );
        printer.SetLineBreak( "" ); // no line breaks
       }
    else
       {
        printer.SetIndent( "    " );
       }

    pDoc->Accept( &printer );
    xmlString.append( printer.CStr() );
   }

template <typename DataType, typename CBeforeSaveProcessingPred>
void saveEx( ::std::string &xmlString
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , const CBeforeSaveProcessingPred &processingPred
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
   {
    ::cli::sixml::CiNode nodeImpl( createSixmlDocumentRootForWriting( rootTag, flags ), true ); // no addRef
    ::sixml::serializer::serializeToSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    ::sixml::serializer::serializeToXmlString( xmlString, nodeImpl.getIfPtr(), flags );
   }

template <typename DataType>
void save( ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , const DataType& data
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         )
   {
    ::sixml::serializer::tinyxml::saveEx( xmlString, rootTag, data, CDoNothing<DataType>(), flags, dmc );
   }

}; // namespace tinyxml
}; // namespace serializer
}; // namespace sixml


#if !defined(CLI_SIXML_ALLOW_MIX_ENGINES)
// publish libxml2 functions in common ::sixml::serializer namespace
    #ifdef CLI_XML_SIXML_ENGINE
        #undef CLI_XML_SIXML_ENGINE
    #endif // CLI_XML_SIXML_ENGINE
    #define CLI_XML_SIXML_ENGINE    tinyxml
    #include "../publishEngine.h"
#endif // CLI_SIXML_ALLOW_MIX_ENGINES


#endif /* CLI_XML_SIXML_TINY_SERIALIZER_H */

