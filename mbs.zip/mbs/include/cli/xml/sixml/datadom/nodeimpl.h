#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_DATADOM_NODEIMPLTPL_H
#define CLI_XML_SIXML_DATADOM_NODEIMPLTPL_H

// This file contains code template for implementing iNode class.
// Use it if you want add support for some other XML engine
// Create directory <engine> in cli/xml/sixml
// copy this file into newly created directory (see command line below)
//      copy cli/xml/sixml/NodeImplTpl.h cli/xml/sixml/<engine>/NodeImpl.h
// Add your code into class methods 


#ifndef CLI_XML_SIXML_NODEIMPLBASE_H
    #include <cli/xml/sixml/NodeImplBase.h>
#endif

#ifndef CLI_XML_SIXML_NODESETIMPL_H
    #include <cli/xml/sixml/NodeSetImpl.h>
#endif

#ifndef CLI_IDATADOM_H
    #include <cli/idatadom.h>
#endif


namespace cli {
namespace sixml {
namespace impl {

struct CNodeImpl : public CNodeImplBase
{
        //INTERFACE_CLI_IDATANODE *pNode;
        ::cli::CiDataNode   m_node;

        //CNodeImpl() : CNodeImplBase() {}
        CNodeImpl( INTERFACE_CLI_IDATANODE *pNode, bool noAddRef=false ) : CNodeImplBase(), m_node(pNode,noAddRef) {}
        ~CNodeImpl()
           {
           }

        // Interface map - queryInterface implementation

        CLI_BEGIN_INTERFACE_MAP2(CNodeImplBase, INTERFACE_CLI_SIXML_INODE)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_SIXML_INODE )
        CLI_END_INTERFACE_MAP(CNodeImplBase)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

        // final implementation
        CLIMETHOD_(VOID, destroy) (THIS)
               {
                #include <cli/compspec/delthis.h>
               }
        
        CLIMETHOD_(VOID*, getDocPtr) (THIS)
           {
            return (VOID*)m_node.getIfPtr();
           }

        // GENERATOR: METHOD - attributesGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#attributesGet@OVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(attributesGet) (THIS_ CLISTR*           _attributes
                                      , const CLISTR*     idx1
                                 )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _attributes not an optional ptr or ref
                    if (!_attributes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_attributes" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }

                    ::cli::CiDataNodeList nodeList;
                    m_node.getChildNodes(nodeList.getPP());
                    if (!nodeList) return EC_NOT_FOUND;
                    SIZE_T listSize = nodeList.listSize;

                    ::std::wstring attrName = stdstr(idx1);
                    if (attrName.empty()) return EC_NOT_FOUND;

                    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                       {
                        ::cli::CiDataNode childNode;
                        nodeList.getDataNode(childNode.getPP(), nodeIndex);
                        if (!childNode) continue;
                        if ( childNode.compareNameTypeChars(attrName.c_str(), CLI_EDATANODETYPE_ATTRIBUTE) )
                           { // found attr
                            ::std::wstring strValue;
                            childNode.getString(strValue);
                            return ::cli::propertyGetImpl( _attributes, strValue );
                           }
                       }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
           }

        // GENERATOR: METHOD - attributesSet
        // GENERATOR: METHOD SIGNATURE - G!P0R#attributesSet@IVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(attributesSet) (THIS_ const CLISTR*     _attributes // attr value
                                      , const CLISTR*     idx1 // name of attr
                                 )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _attributes not an optional ptr or ref
                    if (!_attributes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_attributes" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here

                    ::cli::CiDataNodeList nodeList;
                    m_node.getChildNodes(nodeList.getPP());
                    if (!nodeList) return EC_NOT_FOUND;
                    SIZE_T listSize = nodeList.listSize;

                    ::std::wstring attrName = stdstr(idx1);
                    if (attrName.empty()) return EC_NOT_FOUND;

                    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                       {
                        ::cli::CiDataNode childNode;
                        nodeList.getDataNode(childNode.getPP(), nodeIndex);
                        if (!childNode) continue;
                        if ( childNode.compareNameTypeChars(attrName.c_str(), CLI_EDATANODETYPE_ATTRIBUTE) )
                           { // found attr
                            ::std::wstring strValue = stdstr(_attributes);
                            childNode.setString(strValue);
                            return EC_ERR_ALLREADY;
                           }
                       }

                    // not found attr with specified name
                    ::cli::CiDataNode childNode; // create new
                    m_node.createChildDataNode( childNode.getPP()
                                              , CLI_EDATANODETYPE_ATTRIBUTE
                                              , attrName
                                              , 0 // pValue
                                              );

                    if (!!childNode)
                       {
                        childNode.getIfPtr()->setString(_attributes);
                       }
                    //return EC_OK;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - getAttributeByIndex
        // GENERATOR: METHOD SIGNATURE - G!P0R#getAttributeByIndex@OVS!P0G@OVS!P0G@IVS!P0T@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(getAttributeByIndex) (THIS_ CLISTR*           attrName
                                            , CLISTR*           attrVal
                                            , SIZE_T    idx /* [in] size_t  idx  */
                                       )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // attrName not an optional ptr or ref
                    if (!attrName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"attrName" );  }
                    
                    // attrVal not an optional ptr or ref
                    if (!attrVal) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"attrVal" );  }
                    
                    // method code goes here
                    ::cli::CiDataNodeList nodeList;
                    m_node.getChildNodes(nodeList.getPP());
                    if (!nodeList) return EC_NOT_FOUND;
                    SIZE_T listSize = nodeList.listSize;

                    //::std::wstring attrName = stdstr(_attrName);
                    //if (attrName.empty()) return EC_NOT_FOUND;

                    SIZE_T curIdx = 0;

                    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                       {
                        ::cli::CiDataNode childNode;
                        nodeList.getDataNode(childNode.getPP(), nodeIndex);
                        if (!childNode) continue;
                        if ( childNode.compareNameTypeChars(L"*",CLI_EDATANODETYPE_ATTRIBUTE) )
                           { // found some attr
                            if (curIdx==idx)
                               {
                                ::std::wstring _attrName = childNode.nodeName;
                                ::std::wstring _attrVal; 
                                childNode.getString(_attrVal);

                                ::cli::propertyGetImpl( attrName, _attrName );
                                ::cli::propertyGetImpl( attrVal , _attrVal  );
                                return EC_OK;
                               }
                            ++curIdx;
                           }
                       }

                    //return EC_OUT_OF_RANGE;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OUT_OF_RANGE;
           }

        // GENERATOR: METHOD - nameGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#nameGet@OVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(nameGet) (THIS_ CLISTR*           _name)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _name not an optional ptr or ref
                    if (!_name) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_name" );  }
                  
                    // method code goes here
                    // name_BeforeGet(name);
                    ::std::wstring nodeName = m_node.nodeName;
                    return ::cli::propertyGetImpl(_name, nodeName );
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - textGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#textGet@OVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(textGet) (THIS_ CLISTR*           _text)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _text not an optional ptr or ref
                    if (!_text) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_text" );  }
                    
                    // method code goes here
                    // text_BeforeGet(text);
                    // Assumed that text is a class member
                    ::std::wstring strValue;
                    m_node.getString(strValue);
                    return ::cli::propertyGetImpl(_text, strValue );
                    // text_AfterGet(text);
                    // return res;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - textSet
        // GENERATOR: METHOD SIGNATURE - G!P0R#textSet@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(textSet) (THIS_ const CLISTR*     _text)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _text not an optional ptr or ref
                    if (!_text) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_text" );  }
                    
                    // method code goes here
                    // text_BeforeSet(text);
                    // Assumed that text is a class member
                    m_node.setString(stdstr(_text));
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - createChildNode
        // GENERATOR: METHOD SIGNATURE - G!P0R#createChildNode@IVS!P0G@OVS!P1?__cli__sixml__iNode@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(createChildNode) (THIS_ const CLISTR*     nodeTagName
                                        , ::cli::sixml::iNode**    pNewChildNode /* [out] ::cli::sixml::iNode* pNewChildNode  */
                                   )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // nodeTagName not an optional ptr or ref
                    if (!nodeTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"nodeTagName" );  }
                    
                    // pNewChildNode not an optional ptr or ref
                    if (!pNewChildNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pNewChildNode" );  }
                    
                    // method code goes here
                    ::cli::CiDataNode newChildNode;
                    m_node.getIfPtr()->createChildDataNode( newChildNode.getPP(), CLI_EDATANODETYPE_NODE, nodeTagName, 0 );

                    CNodeImpl *pNewNode = new CNodeImpl( newChildNode.getIfPtr() );
                    (*pNewChildNode) = static_cast< ::cli::sixml::iNode* >(pNewNode);

                    //return EC_OK;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - createChildNodeWithText
        // GENERATOR: METHOD SIGNATURE - G!P0R#createChildNodeWithText@IVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(createChildNodeWithText) (THIS_ const CLISTR*     nodeTagName
                                                , const CLISTR*     nodeText
                                           )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // nodeTagName not an optional ptr or ref
                    if (!nodeTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"nodeTagName" );  }
                    
                    // nodeText not an optional ptr or ref
                    if (!nodeText) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"nodeText" );  }
                    
                    // method code goes here
                    ::cli::CiDataNode newChildNode;
                    m_node.getIfPtr()->createChildDataNode( newChildNode.getPP(), CLI_EDATANODETYPE_NODE, nodeTagName, 0 );
                    newChildNode.getIfPtr()->setString(nodeText);
                    //return EC_OK;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - findChild
        // GENERATOR: METHOD SIGNATURE - G!P0R#findChild@IVS!P0G@OVS!P1?__cli__sixml__iNode@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(findChild) (THIS_ const CLISTR*     childTagName
                                  , ::cli::sixml::iNode**    pChildNode /* [out] ::cli::sixml::iNode* pChildNode  */
                             )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // childTagName not an optional ptr or ref
                    if (!childTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"childTagName" );  }
                    
                    // pChildNode not an optional ptr or ref
                    if (!pChildNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pChildNode" );  }
                    
                    // method code goes here
                    ::cli::CiDataNodeList nodeList;
                    m_node.getChildNodes(nodeList.getPP());
                    if (!nodeList) return EC_NOT_FOUND;
                    SIZE_T listSize = nodeList.listSize;

                    ::std::wstring childName = stdstr(childTagName);
                    if (childName.empty()) return EC_NOT_FOUND;

                    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                       {
                        ::cli::CiDataNode childNode;
                        nodeList.getDataNode(childNode.getPP(), nodeIndex);
                        if (!childNode) continue;
                        if ( childNode.compareNameTypeChars(childName.c_str(),CLI_EDATANODETYPE_NODE) )
                           { // found child
                            //::std::wstring strValue;
                            //childNode.getString(strValue);
                            CNodeImpl *pNewNode = new CNodeImpl( childNode.getIfPtr() );
                            (*pChildNode) = static_cast< ::cli::sixml::iNode* >(pNewNode);
                            return EC_OK;
                           }
                       }
                    //return EC_NOT_FOUND;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
           }

        // GENERATOR: METHOD - childTextGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#childTextGet@OVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(childTextGet) (THIS_ CLISTR*           _childText
                                     , const CLISTR*     idx1
                                )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _childText not an optional ptr or ref
                    if (!_childText) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_childText" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here
                    // childText_BeforeGet(childText);
                    // Assumed that childText is a vector class member
                    ::cli::CiDataNodeList nodeList;
                    m_node.getChildNodes(nodeList.getPP());
                    if (!nodeList) return EC_NOT_FOUND;
                    SIZE_T listSize = nodeList.listSize;

                    ::std::wstring childName = stdstr(idx1);
                    if (childName.empty()) return EC_NOT_FOUND;

                    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                       {
                        ::cli::CiDataNode childNode;
                        nodeList.getDataNode(childNode.getPP(), nodeIndex);
                        if (!childNode) continue;
                        if ( childNode.compareNameTypeChars(childName.c_str(),CLI_EDATANODETYPE_NODE) )
                           { // found child
                            ::std::wstring strValue;
                            childNode.getString(strValue);
                            return ::cli::propertyGetImpl( _childText, strValue );
                           }
                       }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
           }

        // GENERATOR: METHOD - findChildNodes
        // GENERATOR: METHOD SIGNATURE - G!P0R#findChildNodes@IVS!P0G@OVS!P1?__cli__sixml__iNodeSet@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(findChildNodes) (THIS_ const CLISTR*     childsTagName
                                       , ::cli::sixml::iNodeSet**    pNodeSet /* [out] ::cli::sixml::iNodeSet* pNodeSet  */
                                  )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // childsTagName not an optional ptr or ref
                    if (!childsTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"childsTagName" );  }
                    
                    // pNodeSet not an optional ptr or ref
                    if (!pNodeSet) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pNodeSet" );  }

                    // method code goes here
                    (*pNodeSet) = 0;
                    
                    // CLIASSERT(tag_name);
                    ::cli::CiDataNodeList nodeList;
                    m_node.getChildNodes(nodeList.getPP());
                    if (!nodeList) return EC_NOT_FOUND;
                    SIZE_T listSize = nodeList.listSize;

                    ::std::wstring childName = stdstr(childsTagName);
                    if (childName.empty()) return EC_NOT_FOUND;

                    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                       {
                        ::cli::CiDataNode childNode;
                        nodeList.getDataNode(childNode.getPP(), nodeIndex);
                        if (!childNode) continue;
                        if ( childNode.compareNameTypeChars(childName.c_str(),CLI_EDATANODETYPE_NODE) )
                           { // found child
                            //::std::wstring strValue;
                            //childNode.getString(strValue);
                            CNodeImpl *pNewNode = new CNodeImpl( childNode.getIfPtr() );
                            (*pNodeSet)->pushNode( pNewNode );
                            pNewNode->release();
                           }
                       }
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }



}; // struct CNodeImpl



}; // namespace impl
}; // namespace sixml
}; // namespace cli



#endif /* CLI_XML_SIXML_DATADOM_NODEIMPLTPL_H */

