#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_DATADOM_SERIALIZER_H
#define CLI_XML_SIXML_DATADOM_SERIALIZER_H

/*
#ifndef CLI_XML_SIXML_DATADOM_SERIALIZER_H
    #include <cli/xml/sixml/datadom/serializer.h>
#endif
*/

#ifndef CLI_XML_SIXML_SERIALIZERCOMMON_H
    #include <cli/xml/sixml/serializerCommon.h>
#endif

#ifndef CLI_XML_SIXML_DATADOM_NODEIMPLTPL_H
    #include <cli/xml/sixml/datadom/nodeimpl.h>
#endif

// ::sixml::
// ::sixml::serializer::
// ::sixml::serializer::pugixml::

namespace sixml
{
namespace serializer
{


void serializeToXmlString( ::std::string &xmlString
                                  , INTERFACE_CLI_SIXML_INODE* pNode
                                  , unsigned int flags = 0
                                  );


namespace datadom
{

class CXmlEngineGlobalInitializer
{
    public:
        CXmlEngineGlobalInitializer()
           {
           }
        ~CXmlEngineGlobalInitializer()
           {
           }
};


inline
INTERFACE_CLI_SIXML_INODE* createSixmlNodeOnExistingDataDomNode( INTERFACE_CLI_IDATANODE *pDataDomNode
                                             )
   {
    return new ::cli::sixml::impl::CNodeImpl( pDataDomNode );
   }


inline
INTERFACE_CLI_SIXML_INODE* loadToSixmlDomNode( const ::std::string &xmlString
                                             , const ::sixml::util::tstring &rootTag
                                             , ::sixml::util::tstring *pReadedRootTag
                                             , unsigned int flags = 0
                                             , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
                                             )
   {
    ::cli::CiDataNode rootNode("/cli/datanode");
    rootNode.deserializeXml(xmlString, CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME );

    #if defined(UNICODE) || defined(_UNICODE)
    ::std::wstring rootNodeName;
    rootNodeName = rootNode.name;
    #else
    ::std::string rootNodeName;
      {
       ::std::wstring rootNodeNameTmp;
       rootNodeNameTmp = rootNode.nodeName;
       rootNodeName = MARTY_UTF::toUtf8(rootNodeNameTmp);
      }
    #endif

    //::sixml::util::tstring rootTagNameTStr = ::cli::sixml::impl::pugi_helpers::getNodeNameHelper(rootNode);
    if (pReadedRootTag)
       *pReadedRootTag = rootNodeName;

    if (!(flags&rfSkipCheckRoot))
       {
        if (rootNodeName!=rootTag)
           {
            ::sixml::throw_wrong_root_tag( rootTag, rootNodeName );
           }
       }

    return new ::cli::sixml::impl::CNodeImpl( rootNode.getIfPtr() );
   }



/*! ���������� �������������� (��������) ������ �� XML-�������.
*/
template <typename DataType, typename CAfterLoadProcessingPred >
void loadEx( const ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag
         , const CAfterLoadProcessingPred &processingPred
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
   {
    ::cli::sixml::CiNode nodeImpl( loadToSixmlDomNode( xmlString
                                                     , rootTag
                                                     , pReadedRootTag
                                                     , flags
                                                     , baseFile
                                                     )
                                 , true // no addRef
                                 ); 
    parseSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    //read_node( nodeImpl.getIfPtr(), data, dmc );
    //processingPred( nodeImpl.getIfPtr(), data );
   }


template <typename DataType>
void load( const ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag = 0
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
    {
     ::sixml::serializer::datadom::loadEx( xmlString, rootTag, data, pReadedRootTag, CDoNothing<DataType>(), flags, dmc, baseFile );
    }


template <typename DataType, typename CAfterLoadProcessingPred >
void loadEx( INTERFACE_CLI_IDATANODE *pDataDomNode
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag
         , const CAfterLoadProcessingPred &processingPred
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
   {
    ::cli::sixml::CiNode nodeImpl( createSixmlNodeOnExistingDataDomNode( pRootDataNode )
                                 , true // no addRef
                                 ); 
    parseSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    //read_node( nodeImpl.getIfPtr(), data, dmc );
    //processingPred( nodeImpl.getIfPtr(), data );
   }

template <typename DataType>
void load( INTERFACE_CLI_IDATANODE *pDataDomNode
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag = 0
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
    {
     ::sixml::serializer::datadom::loadEx( xmlString, rootTag, data, pReadedRootTag, CDoNothing<DataType>(), flags, dmc, baseFile );
    }

inline
INTERFACE_CLI_SIXML_INODE* createSixmlDocumentRootForWriting( const ::sixml::util::tstring &rootTag
                                             , unsigned int flags = 0
                                             )
   {
    ::cli::CiDataNode rootNode("/cli/datanode");
    #if defined(UNICODE) ||defined(_UNICODE)
    rootNode.nodeName = rootTag;
    #else
    rootNode.nodeName = MARTY_UTF::fromUtf8(rootTag);
    #endif
    return new ::cli::sixml::impl::CNodeImpl( rootNode.getIfPtr() );
   }


inline
void serializeToXmlString( ::std::string &xmlString
                                      , INTERFACE_CLI_SIXML_INODE* pNode
                                      , unsigned int flags = 0
                                      )
   {
    INTERFACE_CLI_IDATANODE *pRootDataNode = (INTERFACE_CLI_IDATANODE*)pNode->getDocPtr();
    if (!pRootDataNode)
       {
        return; // not a root node
       }

    ENUM_CLI_EDATANODESERIALIZEFLAG serializeFlags = CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO; // 0;
    //CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO

    unsigned int pugiFlags = 0;
    if (flags&wfBom)           serializeFlags |= CLI_EDATANODESERIALIZEFLAG_WRITEBOM;
    if (flags&wfNoDeclaration) serializeFlags |= CLI_EDATANODESERIALIZEFLAG_NOXMLDECLARATION;
    if (flags&wfCondenced)     serializeFlags |= CLI_EDATANODESERIALIZEFLAG_WRITECONDENCED;
    //CLI_EDATANODESERIALIZEFLAG_XMLSTANDALONE

    ::cli::CiDataNode_tmp tmpRootNode(pRootDataNode);
    tmpRootNode.serializeXml( xmlString, serializeFlags );
   }




template <typename DataType, typename CBeforeSaveProcessingPred>
void saveEx( ::std::string &xmlString
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , const CBeforeSaveProcessingPred &processingPred
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
   {
    ::cli::sixml::CiNode nodeImpl( createSixmlDocumentRootForWriting( rootTag, flags ), true ); // no addRef
    ::sixml::serializer::serializeToSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    ::sixml::serializer::serializeToXmlString( xmlString, nodeImpl.getIfPtr(), flags );
   }

template <typename DataType>
void save( ::std::string &xmlString
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
   {
    ::sixml::serializer::datadom::saveEx( xmlString, rootTag, data, CDoNothing<DataType>(), flags, dmc );
   }


// ���������� �������� ������ �� �������� � ������ Data Dom
template <typename DataType, typename CBeforeSaveProcessingPred>
void saveEx( INTERFACE_CLI_IDATANODE *pRootDataNode
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , const CBeforeSaveProcessingPred &processingPred
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
   {
    ::cli::sixml::CiNode nodeImpl( createSixmlNodeOnExistingDataDomNode( pRootDataNode ), true ); // no addRef
    ::sixml::serializer::serializeToSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
   }

template <typename DataType>
void save( INTERFACE_CLI_IDATANODE *pRootDataNode
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
   {
    ::sixml::serializer::datadom::saveEx( pRootDataNode, rootTag, data, CDoNothing<DataType>(), flags, dmc );
   }


}; // namespace datadom
}; // namespace serializer
}; // namespace sixml


#if !defined(CLI_SIXML_ALLOW_MIX_ENGINES)
// publish libxml2 functions in common ::sixml::serializer namespace
    #ifdef CLI_XML_SIXML_ENGINE
        #undef CLI_XML_SIXML_ENGINE
    #endif // CLI_XML_SIXML_ENGINE
    #define CLI_XML_SIXML_ENGINE    datadom
    #include "../publishEngine.h"
#endif // CLI_SIXML_ALLOW_MIX_ENGINES



#endif /* CLI_XML_SIXML_DATADOM_SERIALIZER_H */

