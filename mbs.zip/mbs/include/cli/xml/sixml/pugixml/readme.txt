PUGIXML to CLI/SIXML binding
PUGIXML sources and headers allready included.
Download the latest version of PUGIXML from http://code.google.com/p/pugixml/  if you need.
