#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_PUGIXML_NODEIMPLTPL_H
#define CLI_XML_SIXML_PUGIXML_NODEIMPLTPL_H

// This file contains code template for implementing iNode class.
// Use it if you want add support for some other XML engine
// Create directory <engine> in cli/xml/sixml
// copy this file into newly created directory (see command line below)
//      copy cli/xml/sixml/NodeImplTpl.h cli/xml/sixml/<engine>/NodeImpl.h
// Add your code into class methods 


#ifndef CLI_XML_SIXML_NODEIMPLBASE_H
    #include <cli/xml/sixml/NodeImplBase.h>
#endif

#ifndef CLI_XML_SIXML_NODESETIMPL_H
    #include <cli/xml/sixml/NodeSetImpl.h>
#endif

#include "pugixml.hpp"

// Ours strings are always wide
// PUGIXML strings are always char (utf8)
#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef CLI_XML_SIXML_PUGIXML_HELPERS_H
    #include <cli/xml/sixml/pugixml/helpers.h>
#endif

/*
#if defined(UNICODE) || defined(_UNICODE)
    #ifndef MARTY_UTF_H
        #include <marty/utf.h>
    #endif
   #define TSTR2PUGISTR(str)  MARTY_UTF::toUtf8(str)
   #define TSTR2PUGI(str)  MARTY_UTF::toUtf8(str).c_str()
   #define PUGI2TSTR(str)  MARTY_UTF::fromUtf8(str)
#else
   #define TSTR2PUGISTR(str)  str
   #define TSTR2PUGI(str)  str.c_str()
   #define PUGI2TSTR(str)  str
#endif
*/
#ifndef TSTR2PUGISTR
    #define TSTR2PUGISTR(str)  MARTY_UTF::toUtf8(str)
#endif

#ifndef TSTR2PUGI
    #define TSTR2PUGI(str)  MARTY_UTF::toUtf8(str).c_str()
#endif

#ifndef PUGI2TSTR
    #define PUGI2TSTR(str)  MARTY_UTF::fromUtf8(str)
#endif


namespace cli {
namespace sixml {
namespace impl {

/*
namespace pugi_helpers{

// good both for nodes and attrs
template <typename TNode>
//::sixml::util::tstring getNodeNameHelper( const TNode &node )
::std::wstring getNodeNameHelper( const TNode &node )
   {
    const char* nodeName = node.name();
    if (!nodeName) return ::std::wstring();
    return PUGI2TSTR(nodeName);
   }

inline
::std::wstring getNodeTextHelper( const pugi::xml_node &node )
   {
    const char* nodeValue = node.child_value();
    //const char* nodeValue = node.value();
    if (!nodeValue) return ::std::wstring();
    return PUGI2TSTR(nodeValue);
   }

inline
::std::wstring getNodeTextHelper( const pugi::xml_attribute &attr )
   {
    //const char* nodeValue = node.child_value();
    const char* nodeValue = attr.value();
    if (!nodeValue) return ::std::wstring();
    return PUGI2TSTR(nodeValue);
   }

}; // namespace pugi_helpers
*/




struct CNodeImpl : public CNodeImplBase
{

        pugi::xml_node       m_node;
        pugi::xml_document  *m_pDoc;


        //CNodeImpl() : CNodeImplBase() {}
        CNodeImpl( const pugi::xml_node &n ) : CNodeImplBase(), m_node(n), m_pDoc(0) {}
        CNodeImpl( const pugi::xml_node &n, pugi::xml_document  *pDoc ) : CNodeImplBase(), m_node(n), m_pDoc(pDoc) {}
        ~CNodeImpl()
           {
            if (m_pDoc) delete m_pDoc;
           }

        // Interface map - queryInterface implementation

        CLI_BEGIN_INTERFACE_MAP2(CNodeImplBase, INTERFACE_CLI_SIXML_INODE)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_SIXML_INODE )
        CLI_END_INTERFACE_MAP(CNodeImplBase)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

        // final implementation
        CLIMETHOD_(VOID, destroy) (THIS)
            {
             #include <cli/compspec/delthis.h>
            }
        
        CLIMETHOD_(VOID*, getDocPtr) (THIS)
           {
            return (VOID*)m_pDoc;
           }

        // GENERATOR: METHOD - attributesGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#attributesGet@OVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(attributesGet) (THIS_ CLISTR*           _attributes
                                      , const CLISTR*     idx1
                                 )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _attributes not an optional ptr or ref
                    if (!_attributes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_attributes" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here

                    // get attr
                    // pNode->attributesGet( attrVal, "name" )
                    // return EC_OK if attr exist or EC_NOT_FOUND if attr absent

                    // idx1 - string containing attr name

                    ::std::string attrNamePugi = WSTR2PUGISTR( stdstr(idx1) );
                    for (pugi::xml_attribute a = m_node.first_attribute(); a; a = a.next_attribute())
                        {
                         const char* attrName = a.name();
                         if (!attrName) continue;
                         if (strcmp(attrNamePugi.c_str(), attrName)) continue;
                         return ::cli::propertyGetImpl( _attributes, ::sixml::serializer::pugi_helpers::getNodeTextHelper( a ) );
                         // attrVal = pugi_helpers::getNodeTextHelper( a );
                         // return EC_OK;
                        }
                    //return EC_NOT_FOUND;
                    // return res;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
           }

        // GENERATOR: METHOD - attributesSet
        // GENERATOR: METHOD SIGNATURE - G!P0R#attributesSet@IVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(attributesSet) (THIS_ const CLISTR*     _attributes // attr value
                                      , const CLISTR*     idx1 // name of attr
                                 )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _attributes not an optional ptr or ref
                    if (!_attributes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_attributes" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here

                    // set attr
                    // pNode->attributesSet( attrVal, "name" )
                    // return EC_OK for newly created attribute
                    // return EC_ERR_ALLREADY (Allready exist), but attribute was set to newly taken value 
                    // Other errors can be returned depending on underlaying xml implementation

                    bool allreadyExist = false;
                    ::std::string attrNamePugi = WSTR2PUGISTR( stdstr(idx1) );
                    pugi::xml_attribute a = m_node.first_attribute();
                    for ( ; a; a = a.next_attribute())
                        {
                         const char* attrName = a.name();
                         if (!attrName) continue;
                         if (strcmp(attrNamePugi.c_str(), attrName)) continue;
                         allreadyExist = true;
                         break;
                        }

                    if (allreadyExist)
                       {
                        a.set_value( WSTR2PUGI( stdstr(_attributes) ) );
                        return EC_ERR_ALLREADY;
                       }

                    m_node.append_attribute(  attrNamePugi.c_str() ).set_value(WSTR2PUGI( stdstr(_attributes) ));
                    //m_node.append_attribute( TSTR2PUGI( attrNamePugi.c_str() ) ).set_value(TSTR2PUGI( stdstr(_attributes) ));
                    //return EC_OK;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - getAttributeByIndex
        // GENERATOR: METHOD SIGNATURE - G!P0R#getAttributeByIndex@OVS!P0G@OVS!P0G@IVS!P0T@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(getAttributeByIndex) (THIS_ CLISTR*           attrName
                                            , CLISTR*           attrVal
                                            , SIZE_T    idx /* [in] size_t  idx  */
                                       )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // attrName not an optional ptr or ref
                    if (!attrName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"attrName" );  }
                    
                    // attrVal not an optional ptr or ref
                    if (!attrVal) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"attrVal" );  }
                    
                    // method code goes here

                    //::std::string attrNamePugi = TSTR2PUGISTR(idx1);
                    SIZE_T curIdx = 0;
                    pugi::xml_attribute a = m_node.first_attribute();
                    for ( ; a ; a = a.next_attribute(), ++curIdx)
                        {
                         if (curIdx==idx)
                            {
                             ::cli::propertyGetImpl( attrName, ::sixml::serializer::pugi_helpers::getNodeNameHelper( a ) );
                             ::cli::propertyGetImpl( attrVal , ::sixml::serializer::pugi_helpers::getNodeTextHelper( a ) );
                             return EC_OK;
                            }
                        }
                    //return EC_OUT_OF_RANGE;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OUT_OF_RANGE;
           }

        // GENERATOR: METHOD - nameGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#nameGet@OVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(nameGet) (THIS_ CLISTR*           _name)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _name not an optional ptr or ref
                    if (!_name) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_name" );  }
                    
                    // method code goes here
                    // name_BeforeGet(name);
                    // Assumed that name is a class member
                    return ::cli::propertyGetImpl(_name, ::sixml::serializer::pugi_helpers::getNodeNameHelper( m_node ) );
                    // name_AfterGet(name);
                    // return res;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - textGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#textGet@OVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(textGet) (THIS_ CLISTR*           _text)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _text not an optional ptr or ref
                    if (!_text) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_text" );  }
                    
                    // method code goes here
                    // text_BeforeGet(text);
                    // Assumed that text is a class member
                    return ::cli::propertyGetImpl(_text, ::sixml::serializer::pugi_helpers::getNodeTextHelper( m_node ) );
                    // text_AfterGet(text);
                    // return res;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            //return EC_OK;
           }

        // GENERATOR: METHOD - textSet
        // GENERATOR: METHOD SIGNATURE - G!P0R#textSet@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(textSet) (THIS_ const CLISTR*     _text)
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _text not an optional ptr or ref
                    if (!_text) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_text" );  }
                    
                    // method code goes here
                    // text_BeforeSet(text);
                    // Assumed that text is a class member
                    // return ::cli::propertySetImpl(_text, text);
                    m_node.append_child(pugi::node_pcdata).set_value(WSTR2PUGI( stdstr(_text) ));
                    // text_AfterSet(text);
                    // return res;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - createChildNode
        // GENERATOR: METHOD SIGNATURE - G!P0R#createChildNode@IVS!P0G@OVS!P1?__cli__sixml__iNode@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(createChildNode) (THIS_ const CLISTR*     nodeTagName
                                        , ::cli::sixml::iNode**    pNewChildNode /* [out] ::cli::sixml::iNode* pNewChildNode  */
                                   )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // nodeTagName not an optional ptr or ref
                    if (!nodeTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"nodeTagName" );  }
                    
                    // pNewChildNode not an optional ptr or ref
                    if (!pNewChildNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pNewChildNode" );  }
                    
                    // method code goes here
                    CNodeImpl *pNewNode = new CNodeImpl( m_node.append_child(pugi::node_element) );
                    pNewNode->m_node.set_name(WSTR2PUGI( stdstr(nodeTagName) ));
                    (*pNewChildNode) = static_cast< ::cli::sixml::iNode* >(pNewNode);

                    //return EC_OK;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - createChildNodeWithText
        // GENERATOR: METHOD SIGNATURE - G!P0R#createChildNodeWithText@IVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(createChildNodeWithText) (THIS_ const CLISTR*     nodeTagName
                                                , const CLISTR*     nodeText
                                           )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // nodeTagName not an optional ptr or ref
                    if (!nodeTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"nodeTagName" );  }
                    
                    // nodeText not an optional ptr or ref
                    if (!nodeText) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"nodeText" );  }
                    
                    // method code goes here
                    pugi::xml_node n = m_node.append_child(pugi::node_element);
                    n.set_name(WSTR2PUGI( stdstr(nodeTagName) ));
                    n.append_child(pugi::node_pcdata).set_value(WSTR2PUGI( stdstr(nodeText) ));
                    //return EC_OK;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }

        // GENERATOR: METHOD - findChild
        // GENERATOR: METHOD SIGNATURE - G!P0R#findChild@IVS!P0G@OVS!P1?__cli__sixml__iNode@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(findChild) (THIS_ const CLISTR*     childTagName
                                  , ::cli::sixml::iNode**    pChildNode /* [out] ::cli::sixml::iNode* pChildNode  */
                             )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // childTagName not an optional ptr or ref
                    if (!childTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"childTagName" );  }
                    
                    // pChildNode not an optional ptr or ref
                    if (!pChildNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pChildNode" );  }
                    
                    // method code goes here

                    ::std::string childName = WSTR2PUGISTR( stdstr(childTagName) );
                    for (pugi::xml_node c = m_node.first_child(); c; c = c.next_sibling())
                        {
                         const char* nodeName = c.name();
                         if (!nodeName) continue;
                         if (strcmp(childName.c_str(), nodeName)) continue;

                         CNodeImpl *pNewNode = new CNodeImpl( c );
                         (*pChildNode) = static_cast< ::cli::sixml::iNode* >(pNewNode);

                         return EC_OK;
                        }
                    //return EC_NOT_FOUND;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
           }

        // GENERATOR: METHOD - childTextGet
        // GENERATOR: METHOD SIGNATURE - G!P0R#childTextGet@OVS!P0G@IVS!P0G@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(childTextGet) (THIS_ CLISTR*           _childText
                                     , const CLISTR*     idx1
                                )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // _childText not an optional ptr or ref
                    if (!_childText) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"_childText" );  }
                    
                    // idx1 not an optional ptr or ref
                    if (!idx1) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"idx1" );  }
                    
                    // method code goes here
                    // childText_BeforeGet(childText);
                    // Assumed that childText is a vector class member

                    ::std::string childName = WSTR2PUGISTR( stdstr(idx1) );
                    for (pugi::xml_node c = m_node.first_child(); c; c = c.next_sibling())
                        {
                         const char* nodeName = c.name();
                         if (!nodeName) continue;
                         if (strcmp(childName.c_str(), nodeName)) continue;
                         //tagVal = pugi_helpers::getNodeTextHelper( c );
                         //return ::cli::propertyVectorGetImpl( idx1, _childText, childText);
                         return ::cli::propertyGetImpl( _childText, ::sixml::serializer::pugi_helpers::getNodeTextHelper( c ) );
                        }
                    //return EC_NOT_FOUND;
                    // childText_AfterGet(childText);
                    // return res;
                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_NOT_FOUND;
           }

        // GENERATOR: METHOD - findChildNodes
        // GENERATOR: METHOD SIGNATURE - G!P0R#findChildNodes@IVS!P0G@OVS!P1?__cli__sixml__iNodeSet@
        // GENERATOR: INTERFACE - ::cli::sixml::iNode
        CLIMETHOD(findChildNodes) (THIS_ const CLISTR*     childsTagName
                                       , ::cli::sixml::iNodeSet**    pNodeSet /* [out] ::cli::sixml::iNodeSet* pNodeSet  */
                                  )
           {
            CLI_TRY{
                    // GENERATOR: MEMBER CODE - GOES HERE
                    // childsTagName not an optional ptr or ref
                    if (!childsTagName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"childsTagName" );  }
                    
                    // pNodeSet not an optional ptr or ref
                    if (!pNodeSet) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2 ) % L"pNodeSet" );  }

                    // method code goes here
                    (*pNodeSet) = 0;
                    
                    // CLIASSERT(tag_name);
                    ::std::string childName = WSTR2PUGISTR( stdstr(childsTagName) );
                    for (pugi::xml_node c = m_node.first_child(); c; c = c.next_sibling())
                        {
                         const char* nodeName = c.name();
                         if (!nodeName) continue;
                         if (strcmp(childName.c_str(), nodeName)) continue;
                         if (!(*pNodeSet))
                            *pNodeSet = new CNodeSetImpl();

                         CNodeImpl *pNodeImpl = new CNodeImpl( c );
                         (*pNodeSet)->pushNode( pNodeImpl );
                         pNodeImpl->release();
                         //res_set.push_back(new i_sixml_node_impl( c ));
                        }

                    // GENERATOR: MEMBER CODE - END
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }



}; // struct CNodeImpl



}; // namespace impl
}; // namespace sixml
}; // namespace cli



#endif /* CLI_XML_SIXML_PUGIXML_NODEIMPLTPL_H */

