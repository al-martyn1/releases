#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_PUGIXML_SERIALIZER_H
#define CLI_XML_SIXML_PUGIXML_SERIALIZER_H

#ifndef CLI_XML_SIXML_SERIALIZERCOMMON_H
    #include <cli/xml/sixml/serializerCommon.h>
#endif

#ifndef CLI_XML_SIXML_PUGIXML_NODEIMPLTPL_H
    #include <cli/xml/sixml/pugixml/nodeimpl.h>
#endif

#ifndef CLI_XML_SIXML_PUGIXML_HELPERS_H
    #include <cli/xml/sixml/pugixml/helpers.h>
#endif

// ::sixml::
// ::sixml::serializer::
// ::sixml::serializer::pugixml::

namespace sixml
{
namespace serializer
{

void serializeToXmlString( ::std::string &xmlString
                                  , INTERFACE_CLI_SIXML_INODE* pNode
                                  , unsigned int flags = 0
                                  );

namespace pugixml
{


class CXmlEngineGlobalInitializer
{
    public:
        CXmlEngineGlobalInitializer()
           {
           }
        ~CXmlEngineGlobalInitializer()
           {
           }
};



inline
INTERFACE_CLI_SIXML_INODE* loadToSixmlDomNode( const ::std::string &xmlString
                                             , const ::sixml::util::tstring &rootTag
                                             , ::sixml::util::tstring *pReadedRootTag
                                             , unsigned int flags = 0
                                             , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
                                             )
   {
    pugi::xml_document * pDoc = new pugi::xml_document();
    size_t xmlStringSize = xmlString.size();
    char* strCopy = new char[xmlStringSize+1];
    xmlString.copy( strCopy, xmlStringSize );
    strCopy[xmlStringSize] = 0;
    pugi::xml_parse_result parseResult = pDoc->parse( pugi::transfer_ownership_tag(), strCopy
                                                  , pugi::parse_pi  | pugi::parse_cdata | pugi::parse_escapes 
                                                  | pugi::parse_eol | pugi::parse_wnorm_attribute 
                                                  | pugi::parse_wconv_attribute | pugi::parse_declaration
                                                  );

    if (parseResult.status!=pugi::status_ok)
       {
        int line = 0, pos = 0;
        pugi_helpers::getLinePos( xmlString, parseResult.offset, line, pos);
        delete pDoc;
        ::sixml::throw_parse_error( pugi_helpers::pugi2rcode(parseResult.status)
                                  , line, pos );  /* no line pos info provided */
       }

    pugi::xml_node rootNode = pDoc->root();

    for(pugi::xml_node node = rootNode.first_child(); node; node = node.next_sibling())
       {
        if (node.type()==pugi::node_element)
           {
            rootNode = node;
            break;
           }
       }

    #if defined(UNICODE) || defined(_UNICODE)
    //::sixml::util::tstring rootTagNameTStr = MARTY_UTF::toUtf8(::cli::sixml::impl::pugi_helpers::getNodeNameHelper(rootNode));
    ::sixml::util::tstring rootTagNameTStr = MARTY_UTF::fromUtf8(rootNode.name());
    #else
    //::sixml::util::tstring rootTagNameTStr = ::cli::sixml::impl::pugi_helpers::getNodeNameHelper(rootNode);
    ::sixml::util::tstring rootTagNameTStr = rootNode.name();
    #endif

    if (pReadedRootTag)
       *pReadedRootTag = rootTagNameTStr;

    if (!(flags&rfSkipCheckRoot))
       {
        if (rootTagNameTStr!=rootTag)
           {
            delete pDoc;
            ::sixml::throw_wrong_root_tag( rootTag, rootTagNameTStr );
           }
       }

    return new ::cli::sixml::impl::CNodeImpl( rootNode, pDoc );
   }



/*! ���������� �������������� (��������) ������ �� XML-�������.
*/
template <typename DataType, typename CAfterLoadProcessingPred >
void loadEx( const ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag
         , const CAfterLoadProcessingPred &processingPred
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
   {
    ::cli::sixml::CiNode nodeImpl( loadToSixmlDomNode( xmlString
                                                     , rootTag
                                                     , pReadedRootTag
                                                     , flags
                                                     , baseFile
                                                     )
                                 , true // no addRef
                                 ); 
    parseSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    //read_node( nodeImpl.getIfPtr(), data, dmc );
    //processingPred( nodeImpl.getIfPtr(), data );
   }


template <typename DataType>
void load( const ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , ::sixml::util::tstring *pReadedRootTag = 0
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
         )
    {
     ::sixml::serializer::pugixml::loadEx( xmlString, rootTag, data, pReadedRootTag, CDoNothing<DataType>(), flags, dmc, baseFile );
    }



inline
INTERFACE_CLI_SIXML_INODE* createSixmlDocumentRootForWriting( const ::sixml::util::tstring &rootTag
                                             , unsigned int flags = 0
                                             )
   {
    pugi::xml_document *pDoc = new pugi::xml_document();
    pugi::xml_node pugiNode = pDoc->append_child(pugi::node_element);
    #if defined(UNICODE) || defined(_UNICODE)
    pugiNode.set_name(TSTR2PUGI( rootTag ));
    #else
    pugiNode.set_name( rootTag.c_str() );
    #endif

    return new ::cli::sixml::impl::CNodeImpl( pugiNode, pDoc );
   }

inline
void serializeToXmlString( ::std::string &xmlString
                                      , INTERFACE_CLI_SIXML_INODE* pNode
                                      , unsigned int flags = 0
                                      )
   {
    pugi::xml_document *pDoc = (pugi::xml_document*)pNode->getDocPtr();
    if (!pDoc)
       {
        return; // not a root node
       }
    unsigned int pugiFlags = 0;
    if (flags&wfBom)           pugiFlags |= pugi::format_write_bom_utf8;
    if (flags&wfNoDeclaration) pugiFlags |= pugi::format_no_declaration;
    if (flags&wfCondenced)     pugiFlags |= pugi::format_raw;
    else                       pugiFlags |= pugi::format_indent;

    pugi_helpers::xml_string_writer stringWriter(xmlString);
    //pugi::xml_parse_result parseResult = 
    pDoc->save( stringWriter, (flags&wfCondenced ? "" : "    "), pugiFlags);

    ::std::string replaceTo = "<?xml version=\"1.0\" encoding=\"UTF-8\"";
    if (flags&wfStandalone) replaceTo.append(" standalone=\"yes\"");
    replaceTo.append(" ?>");
    ::sixml::helpers::replaceFirstInplace( xmlString, "<?xml version=\"1.0\"?>", replaceTo);
   }


template <typename DataType, typename CBeforeSaveProcessingPred>
void saveEx( ::std::string &xmlString
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , const CBeforeSaveProcessingPred &processingPred
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
   {
    ::cli::sixml::CiNode nodeImpl( createSixmlDocumentRootForWriting( rootTag, flags ), true ); // no addRef
    ::sixml::serializer::serializeToSixmlNodeEx( nodeImpl.getIfPtr(), data, processingPred, dmc );
    ::sixml::serializer::serializeToXmlString( xmlString, nodeImpl.getIfPtr(), flags );
   }

template <typename DataType>
void save( ::std::string &xmlString
          , const ::sixml::util::tstring &rootTag
          , const DataType& data
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
   {
    ::sixml::serializer::pugixml::saveEx( xmlString, rootTag, data, CDoNothing<DataType>(), flags, dmc );
   }


}; // namespace pugixml
}; // namespace serializer
}; // namespace sixml


#if !defined(CLI_SIXML_ALLOW_MIX_ENGINES)
// publish libxml2 functions in common ::sixml::serializer namespace
    #ifdef CLI_XML_SIXML_ENGINE
        #undef CLI_XML_SIXML_ENGINE
    #endif // CLI_XML_SIXML_ENGINE
    #define CLI_XML_SIXML_ENGINE    pugixml
    #include "../publishEngine.h"
#endif // CLI_SIXML_ALLOW_MIX_ENGINES



#endif /* CLI_XML_SIXML_PUGIXML_SERIALIZER_H */

