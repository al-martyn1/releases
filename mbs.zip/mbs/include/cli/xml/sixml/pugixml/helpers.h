#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_PUGIXML_HELPERS_H
#define CLI_XML_SIXML_PUGIXML_HELPERS_H

/* add this lines to your src
#ifndef CLI_XML_SIXML_PUGIXML_HELPERS_H
    #include <cli/xml/sixml/pugixml/helpers.h>
#endif
*/


// ::sixml::serializer::pugi_helpers

#ifndef CLI_XML_SIXML_BINDCOMMON_H
    #include <cli/xml/sixml/bindcommon.h>
#endif

#include <cli/xml/sixml/util.h>
//#include <cli/xml/sixml/serializ.h>



#if defined(UNICODE) || defined(_UNICODE)
    #ifndef MARTY_UTF_H
        #include <marty/utf.h>
    #endif
   #define TSTR2PUGISTR(str)  MARTY_UTF::toUtf8(str)
   #define TSTR2PUGI(str)  MARTY_UTF::toUtf8(str).c_str()
   #define PUGI2TSTR(str)  MARTY_UTF::fromUtf8(str) /* incorrect name, actually str converted to wide string */
#else
   #define TSTR2PUGISTR(str)  str
   #define TSTR2PUGI(str)  str.c_str()
   #define PUGI2TSTR(str)  str
#endif

#define WSTR2PUGISTR(str)  MARTY_UTF::toUtf8(str)
#define WSTR2PUGI(str)     MARTY_UTF::toUtf8(str).c_str()
#define PUGI2WSTR(str)     MARTY_UTF::fromUtf8(str)

namespace sixml
{
namespace serializer
{
namespace pugi_helpers
{


inline
RCODE pugi2rcode( pugi::xml_parse_status status )
   {   
    switch(status)
       {
        case pugi::status_ok                   :  return EC_XML_OK;
        case pugi::status_file_not_found       :  return EC_FILE_NOT_FOUND;
        case pugi::status_io_error             :  return EC_IO_ERROR;
        case pugi::status_out_of_memory        :  return EC_NOT_ENOUGH_MEM;
        case pugi::status_internal_error       :  return EC_XML_INTERNAL_ERROR;
        case pugi::status_unrecognized_tag     :  return EC_XML_BAD_TAG;
        case pugi::status_bad_pi               :  return EC_XML_BAD_PI;
        case pugi::status_bad_comment          :  return EC_XML_BAD_COMMENT;
        case pugi::status_bad_cdata            :  return EC_XML_BAD_CDATA;
        case pugi::status_bad_doctype          :  return EC_XML_BAD_DOCTYPE;
        case pugi::status_bad_pcdata           :  return EC_XML_BAD_PCDATA;
        case pugi::status_bad_start_element    :  return EC_XML_BAD_START_ELEMENT;
        case pugi::status_bad_attribute        :  return EC_XML_BAD_ATTRIBUTE;
        case pugi::status_bad_end_element      :  return EC_XML_BAD_END_ELEMENT;
        case pugi::status_end_element_mismatch :  return EC_XML_TAG_MISMATCH;
        //case pugi:: :  return ;
        default:            return EC_XML_UNKNOWN_ERROR;
       }
   }

inline // , ::std::string &strWhereErr
void getLinePos( const ::std::string &data, size_t errOffset, int &line, int &pos)
   {
    line = 0; pos = 0;
    size_t i = 0, size = data.size();
    for(; i!=errOffset && i!=size; ++i)
       {
        if (data[i]=='\n')
           {
            ++line;
            pos = 0;
           }
        else ++pos;
       }
    if (i>=size)
       {
        line = -1; pos = -1;
       }
    else
       {
        ++line; ++pos;
       }
   }


class PUGIXML_CLASS xml_string_writer : public pugi::xml_writer
{
    protected:
        ::std::string  &str;
    public:
        xml_string_writer(::std::string &s) : str(s) {}
        void write(const void* data, size_t size)
           {
            str.append( (const char*)data, size );
           }
};


// good both for nodes and attrs
template <typename TNode>
//::sixml::util::tstring getNodeNameHelper( const TNode &node )
::std::wstring getNodeNameHelper( const TNode &node )
   {
    const char* nodeName = node.name();
    if (!nodeName) return ::std::wstring();
    //#if defined(UNICODE) || defined(_UNICODE)
    return MARTY_UTF::fromUtf8(nodeName);
    //#else
    //return ::std::wstring(nodeName);
    //#endif
   }

inline
::std::wstring getNodeTextHelper( const pugi::xml_node &node )
   {
    const char* nodeValue = node.child_value();
    //const char* nodeValue = node.value();
    if (!nodeValue) return ::std::wstring();
    //#if defined(UNICODE) || defined(_UNICODE)
    return MARTY_UTF::fromUtf8(nodeValue);
    //#else
    //return ::std::wstring(nodeValue);
    //#endif
   }

inline
::std::wstring getNodeTextHelperEx( const pugi::xml_node &node )
   {
    ::std::wstring resStr;
    for (pugi::xml_node c = node.first_child(); c; c = c.next_sibling())
        {
         if (c.type()!= ::pugi::node_pcdata && c.type()!= ::pugi::node_cdata)
            continue;
         const char* nodeValue = c.value();
         if (!nodeValue) continue;
         resStr += MARTY_UTF::fromUtf8(nodeValue);
        }
    return resStr;
   }

inline
::std::wstring getNodeTextHelper( const pugi::xml_attribute &attr )
   {
    //const char* nodeValue = node.child_value();
    const char* nodeValue = attr.value();
    if (!nodeValue) return ::std::wstring();
    //#if defined(UNICODE) || defined(_UNICODE)
    return MARTY_UTF::fromUtf8(nodeValue);
    //#else
    //return ::std::wstring(nodeValue);
    //#endif
   }





}; // namespace pugi_helpers
}; // namespace serializer
}; // namespace sixml



#endif /* CLI_XML_SIXML_PUGIXML_HELPERS_H */

