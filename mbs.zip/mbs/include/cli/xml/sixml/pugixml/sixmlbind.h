#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_PUGIXML_SIXMLBIND_H
#define CLI_XML_SIXML_PUGIXML_SIXMLBIND_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#include "pugixml.hpp"

#ifndef CLI_XML_SIXML_BINDCOMMON_H
    #include <cli/xml/sixml/bindcommon.h>
#endif

#include <cli/xml/sixml/util.h>
//#include <cli/xml/sixml/serializ.h>



//#define TSTR2PUGIC(str)  TSTR2PUGI(str)

// deprecated helper functions
// set_attr_text
// create_sixml_node_ex
// create_sixml_plain_node_ex
// void text_set(i_sixml_node* node, ::sixml::util::tstring )
// bool set_attr_text(i_sixml_node* node, const ::sixml::util::tstring &text, const TCHAR* name)
// bool set_node_text(i_sixml_node* node, const ::sixml::util::tstring &text, const TCHAR* name)


//::sixml::util::tstring pugi_helpers::getNodeNameHelper( pugi::xml_node &node )
//::sixml::util::tstring pugi_helpers::getNodeTextHelper( pugi::xml_node &node )


struct i_sixml_node_impl : public i_sixml_node_impl_base
{
    protected:
        CLIMETHOD_(VOID, destroy) (THIS)
            {
             #include <cli/compspec/delthis.h>
            }

        pugi::xml_node       m_node;

    public:

        //i_sixml_node() : i_sixml_node_base(), m_node() {}
        i_sixml_node_impl( pugi::xml_node &n ) : i_sixml_node_impl_base(), m_node(n) {}

        // same as
        void setText(const ::sixml::util::tstring &text)
           {
            m_node.append_child(pugi::node_pcdata).set_value(TSTR2PUGI(text));
           }

        bool getText( ::sixml::util::tstring &tagVal )
           {
            tagVal = pugi_helpers::getNodeTextHelper( m_node );
            return true;
           }

        i_sixml_node* createChild( const ::sixml::util::tstring &tagName )
           {
            i_sixml_node_impl* newNode = new i_sixml_node_impl( m_node.append_child(pugi::node_element) );
            newNode->m_node.set_name(TSTR2PUGI(tagName));
            return newNode;
           }

        void addAttr(const ::sixml::util::tstring &attrName, const ::sixml::util::tstring &attrVal)
           {
            m_node.append_attribute( TSTR2PUGI(attrName) ) = TSTR2PUGI(attrVal);
           }

        void addChildWithText(const ::sixml::util::tstring &tagName, const ::sixml::util::tstring &val)
           {
            pugi::xml_node n = m_node.append_child(pugi::node_element);
            n.set_name(TSTR2PUGI(tagName));
            n.append_child(pugi::node_pcdata).set_value(TSTR2PUGI(val));
           }

        bool getAttrText( const ::sixml::util::tstring &attrName, ::sixml::util::tstring &attrVal )
           {
            ::std::string attrNamePugi = TSTR2PUGISTR(attrName);
            for (pugi::xml_attribute a = m_node.first_attribute(); a; a = a.next_attribute())
                {
                 const char* nodeName = a.name();
                 if (!nodeName) continue;
                 if (strcmp(attrNamePugi.c_str(), nodeName)) continue;
                 attrVal = pugi_helpers::getNodeTextHelper( a );
                 return true;
                }
            return false;
           }

        bool getChildText( const ::sixml::util::tstring &tagName, ::sixml::util::tstring &tagVal )
           {
            ::std::string childName = TSTR2PUGISTR(tagName);
            for (pugi::xml_node c = m_node.first_child(); c; c = c.next_sibling())
                {
                 const char* nodeName = c.name();
                 if (!nodeName) continue;
                 if (strcmp(childName.c_str(), nodeName)) continue;
                 tagVal = pugi_helpers::getNodeTextHelper( c );
                 return true;
                }
            return false;
           }

        i_sixml_node* findChildNode( const ::sixml::util::tstring &aChildName )
           {
            ::std::string childName = TSTR2PUGISTR(aChildName);
            for (pugi::xml_node c = m_node.first_child(); c; c = c.next_sibling())
                {
                 const char* nodeName = c.name();
                 if (!nodeName) continue;
                 if (strcmp(childName.c_str(), nodeName)) continue;
                 return new i_sixml_node_impl( c );
                }
            return 0;
           }

        bool getName( ::sixml::util::tstring &tagName )
           {
            tagName = pugi_helpers::getNodeNameHelper( m_node );
            return true;
           }

        void findTags( const TCHAR* tag_name, ::std::vector<i_sixml_node*> &res_set)
           {
            CLIASSERT(tag_name);
            ::std::string childName = TSTR2PUGISTR(tag_name);
            for (pugi::xml_node c = m_node.first_child(); c; c = c.next_sibling())
                {
                 const char* nodeName = c.name();
                 if (!nodeName) continue;
                 if (strcmp(childName.c_str(), nodeName)) continue;
                 res_set.push_back(new i_sixml_node_impl( c ));
                }
           }


//::sixml::util::tstring pugi_helpers::getNodeNameHelper( pugi::xml_node &node )
//::sixml::util::tstring pugi_helpers::getNodeTextHelper( pugi::xml_node &node )

};


// legacy utility functions used in code

/*
inline
void find_tags( ::std::vector<i_sixml_node*> &res_set, 
                i_sixml_node* doc,
                const TCHAR* tag_name, 
                bool recurce)
   {
   }
*/

i_sixml_node* findNode(i_sixml_node* node, const TCHAR* tag_name)
   {
    if (!tag_name) { node->addRef(); return node; }
    return node->findChildNode(tag_name);
   }
// field_name ? 


//-----------------------------------------------------------------
// used
inline
bool read_text(i_sixml_node* node, ::sixml::util::tstring &text, const TCHAR* name, bool as_attr)
{
    CLIASSERT(node);
    if (as_attr) 
        return node->getAttrText( name, text );
    else
        return node->getChildText( name, text );

//    if (as_attr) return read_attr_text(node, text, name);
//    else         return read_node_text(node, text, name);
}

//-----------------------------------------------------------------
// used
inline
bool set_text(i_sixml_node* node, const ::sixml::util::tstring &text, const TCHAR* name, bool as_attr /* else as child */)
   {
    CLIASSERT(node);
    if (as_attr) 
        node->addAttr( name, text );
    else
        node->addChildWithText( name, text );
    return true;
   }




#ifndef CLI_XML_SIXML_PRIM_H
    #include <cli/xml/sixml/prim.h>
#endif

#ifndef CLI_XML_SIXML_METACLAS_H
    #include <cli/xml/sixml/metaclas.h>
#endif

#ifndef CLI_XML_SIXML_LAYOUT_H
    #include <cli/xml/sixml/layout.h>
#endif


namespace sixml{
namespace serializer{


template <typename DataType>
void read_node( i_sixml_node* node, 
                DataType& data,
                const meta_class<DataType>& dataMeta = default_meta_class<DataType>())
{
    dataMeta.read_node(node, data);
};


template <typename DataType>
void write_node( i_sixml_node* node, 
                const DataType& data,
                const meta_class<DataType>& dataMeta = default_meta_class<DataType>())
{
    dataMeta.write_node(node, data);
};


const unsigned int rfSkipCheckRoot   = 1; // don't perform root tag name checking

/*
inline
void dumpNode( const pugi::xml_node &node, const ::std::string &indent )
   {
    std::cout<<indent<<"Node: "<<node.name()<<"\n";
    std::cout<<indent<<"Text: "<<node.value()<<"\n";
    for(pugi::xml_node c = node.first_child(); c; c = c.next_sibling())
       {
        dumpNode( c, indent + ::std::string(4, ' '));
       }
   }
*/

template <class DataType>
void load( const ::std::string &xmlString
         , const ::sixml::util::tstring &rootTag
         , DataType &data
         , unsigned int flags = 0
         , const meta_class<DataType>& dmc = default_meta_class<DataType>()
         )
   {
    pugi::xml_document doc;
    size_t xmlStringSize = xmlString.size();
    char* strCopy = new char[xmlStringSize+1];
    xmlString.copy( strCopy, xmlStringSize );
    strCopy[xmlStringSize] = 0;
    doc.parse( pugi::transfer_ownership_tag(), strCopy
             , pugi::parse_pi | pugi::parse_cdata | pugi::parse_escapes | pugi::parse_eol
             | pugi::parse_wnorm_attribute | pugi::parse_wconv_attribute | pugi::parse_declaration
             );

    pugi::xml_node rootNode = doc.child( TSTR2PUGI(rootTag) );
    if (!(flags&rfSkipCheckRoot))
       {
        ::sixml::util::tstring rootTagNameTStr = pugi_helpers::getNodeNameHelper(rootNode);
        if (rootTagNameTStr!=rootTag)
           ::sixml::throw_wrong_root_tag( rootTag, rootTagNameTStr );
       }
/*
    //{
     unsigned int pugiFlags = pugi::format_no_declaration|pugi::format_indent;
     ::std::string tmp;
     doc.save( xml_string_writer(tmp), "    ", pugiFlags);
    //}
     std::cout<<"--- Dumping loaded document ---\n";
     dumpNode( rootNode, ::std::string() );
     std::cout<<"--- End of dump ---\n";
*/

    i_sixml_node* node = new i_sixml_node_impl( rootNode );
    read_node( node, data, dmc );
    node->release();
   }

// int res = write_xml(file, node, wm, human_readable, forceUtf8, standalone);

const unsigned int wfBom            = 1;
const unsigned int wfNoDeclaration  = 2;
const unsigned int wfCondenced      = 4;


class PUGIXML_CLASS xml_string_writer : public pugi::xml_writer
{
    protected:
        ::std::string  &str;
    public:
        xml_string_writer(::std::string &s) : str(s) {}
        void write(const void* data, size_t size)
           {
            str.append( (const char*)data, size );
           }
};



template <typename DataType>
void save( ::std::string &xmlString
          , const TCHAR* rootTag
          , const DataType& data
          , unsigned int flags = 0
          , const meta_class<DataType>& dmc = default_meta_class<DataType>()
          )
{
    pugi::xml_document doc;
    pugi::xml_node pugiNode = doc.append_child(pugi::node_element);
    pugiNode.set_name(TSTR2PUGI( ::sixml::util::tstring(rootTag) ));

    i_sixml_node* node = new i_sixml_node_impl( pugiNode );
    write_node( node, data, dmc );
    node->release();

    unsigned int pugiFlags = 0;
    if (flags&wfBom)           pugiFlags |= pugi::format_write_bom_utf8;
    if (flags&wfNoDeclaration) pugiFlags |= pugi::format_no_declaration;
    if (flags&wfCondenced)     pugiFlags |= pugi::format_raw;
    else                       pugiFlags |= pugi::format_indent;

    doc.save( xml_string_writer(xmlString), (flags&wfCondenced ? "" : "    "), pugiFlags);
};


}; // namespace serializer
}; // namespace sixml





#endif /* CLI_XML_SIXML_PUGIXML_SIXMLBIND_H */

