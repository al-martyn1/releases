#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_BINDCOMMON_H
#define CLI_XML_SIXML_BINDCOMMON_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_XML_SIXML_PRIMUTIL_H
    #include <cli/xml/sixml/primutil.h>
#endif


struct i_sixml_node
{
    public:
        virtual ULONG addRef()   = 0;
        virtual ULONG addref()   = 0;
        virtual ULONG add_ref()  = 0;
        virtual ULONG release()  = 0;
        //virtual ::sixml::util::tstring get_all_text() = 0;
        //virtual void attr_add( const ::sixml::util::tstring &name, const ::sixml::util::tstring &text ) = 0;
        //virtual size_t attr_find( const ::sixml::util::tstring &name ) = 0; // deprecated
        //virtual size_t attr_end() = 0;// deprecated
        //virtual bool getAttrValue( const ::sixml::util::tstring &attrName, const ::sixml::util::tstring &text ) = 0;
        //virtual void addText(const ::sixml::util::tstring &text) = 0;
        virtual void setText(const ::sixml::util::tstring &text) = 0;
        //virtual i_sixml_node* createChild( ) = 0;
        virtual i_sixml_node* createChild( const ::sixml::util::tstring &tagName ) = 0;
        virtual void addAttr(const ::sixml::util::tstring &attrName, const ::sixml::util::tstring &attrVal) = 0;
        virtual void addChildWithText(const ::sixml::util::tstring &tagName, const ::sixml::util::tstring &val) = 0;
        virtual bool getAttrText( const ::sixml::util::tstring &attrName, ::sixml::util::tstring &attrVal ) = 0;
        virtual bool getChildText( const ::sixml::util::tstring &tagName, ::sixml::util::tstring &tagVal ) = 0;
        virtual i_sixml_node* findChildNode( const ::sixml::util::tstring &childName ) = 0;
        virtual bool getText( ::sixml::util::tstring &tagVal ) = 0;
        virtual bool getName( ::sixml::util::tstring &tagName ) = 0;

        virtual void findTags( const TCHAR* tag_name, ::std::vector<i_sixml_node*> &res_set) = 0;



};

struct i_sixml_node_impl_base : public i_sixml_node
   {
    protected:
        ::cli::CRefCounter     refCounter;

        virtual void destroy() = 0;
        ULONG addRefImpl()    { return (ilint_t)++refCounter;  }
        ULONG releaseImpl()   { if (! --refCounter) { destroy(); return 0; }  return (ilint_t)refCounter; }

    public:

        i_sixml_node_impl_base() : i_sixml_node(), refCounter(1) {}
        ULONG addRef()  { return addRefImpl();  }
        ULONG addref()  { return addRefImpl();  }
        ULONG add_ref() { return addRefImpl();  }
        ULONG release() { return releaseImpl(); }

   };





#endif /* CLI_XML_SIXML_BINDCOMMON_H */

