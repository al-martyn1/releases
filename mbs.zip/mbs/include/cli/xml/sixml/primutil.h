#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

/* Utility functions and classes - sixml serializer internal header file
 * Designed by Andrey Martynov
 * mailto:rek@.rsdn.ru
 * Rewritten by Alex Martinov (amart@mail.ru), 2004.
 */
#ifndef CLI_XML_SIXML_PRIMUTIL_H
#define CLI_XML_SIXML_PRIMUTIL_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_XML_SIXML_6MLEXCEP_H
    #include <cli/xml/sixml/6mlexcep.h>
#endif

#include <wchar.h>

#if !defined(_STRING_) && !defined(__STD_STRING__) && !defined(__STD_STRING)
    #include <string>
#endif

/*
#if !defined(_INC_TCHAR) && !defined(__TCHAR_H)    
    #include <tchar.h>
#endif
*/

#if !defined(_LIMITS_) && !defined(_STLP_LIMITS) && !defined(__STD_LIMITS__) && !defined(_CPP_LIMITS) && !defined(_GLIBCXX_LIMITS)
    #include <limits>
#endif

#if !defined(_INC_LIMITS) && !defined(__LIMITS_H)    
    #include <limits.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#if !defined(_LOCALE_) && !defined(_STLP_LOCALE) && !defined(__STD_LOCALE__) && !defined(_CPP_LOCALE) && !defined(_GLIBCXX_LOCALE)
    #include <locale>
#endif

//  #if defined(WIN32) && 
#if defined(__GNUC__)
    #include <math.h>
#endif


// Undefine Win32 macrosses min/max

#ifdef min
    #undef min
    #define CLI_XML_SIXML_PRIMUTIL_RESTORE_WIN_MIN
#endif

#ifdef max
    #undef max
    #define CLI_XML_SIXML_PRIMUTIL_RESTORE_WIN__MAX
#endif



namespace sixml{
namespace util{

#ifndef SIXML_UTIL_TSTRING_DEFINED
#define SIXML_UTIL_TSTRING_DEFINED
typedef std::basic_string<TCHAR>  tstring;
// using ::sixml::util::tstring
#endif /* SIXML_UTIL_TSTRING_DEFINED */


template< typename CharType >
struct CIsSpace
{
    bool operator()(const CharType ch) const
       {
        if ( ch==(CharType)' '
           ||ch==(CharType)'\r'
           ||ch==(CharType)'\n'
           ||ch==(CharType)'\t'
           ) return true;
        return false;
       }
};

//-----------------------------------------------------------------------------
template< typename CharType, typename Traits, typename Allocator >
void ltrim(::std::basic_string<CharType, Traits, Allocator> &str)
   {
    //return 
    ::cli::util::ltrim( str, ::cli::util::CIsSpace<CharType>() );
   }

//-----------------------------------------------------------------------------
template< typename CharType, typename Traits, typename Allocator >
void rtrim(::std::basic_string<CharType, Traits, Allocator> &str)
   {
    //return 
    ::cli::util::rtrim( str, ::cli::util::CIsSpace<CharType>() );
   }

//-----------------------------------------------------------------------------
template< typename CharType, typename Traits, typename Allocator >
void trim(::std::basic_string<CharType, Traits, Allocator> &str)
   {
    //return 
    ::cli::util::trim( str, ::cli::util::CIsSpace<CharType>() );
   }

//-----------------------------------------------------------------------------
template< typename CharType, typename Traits, typename Allocator >
::std::basic_string<CharType, Traits, Allocator>
ltrim_copy(const ::std::basic_string<CharType, Traits, Allocator> &str)
   {
    return ::cli::util::ltrim_copy( str, ::cli::util::CIsSpace<CharType>() );
   }

//-----------------------------------------------------------------------------
template< typename CharType, typename Traits, typename Allocator >
::std::basic_string<CharType, Traits, Allocator>
rtrim_copy(const ::std::basic_string<CharType, Traits, Allocator> &str)
   {
    return ::cli::util::rtrim_copy( str, ::cli::util::CIsSpace<CharType>() );
   }

//-----------------------------------------------------------------------------
template< typename CharType, typename Traits, typename Allocator >
::std::basic_string<CharType, Traits, Allocator>
trim_copy(const ::std::basic_string<CharType, Traits, Allocator> &str)
   {
    return ::cli::util::trim_copy( str, ::cli::util::CIsSpace<CharType>() );
   }

//-----------------------------------------------------------------------------


// utility for old compilers that has no std::(w)string::clear method
inline
void clear(tstring &str)
   {
    #if defined(_MSC_VER) && (_MSC_VER < 0x0700)
        str.erase(0, tstring::npos);
    #else
        str.clear();
    #endif
   }

template <typename T, typename Iter>
std::vector<T>& append(std::vector<T> &vec, Iter first, Iter last)
{
    if (vec.empty())
       {
        //vec = std::vector<T>(first, last);
        vec.assign(first, last);
       }
    else
       {
        vec.reserve(vec.size() + (last - first));
        vec.insert( vec.end(), first, last );
        //for (; first!=last; first++) 
        //    vec.push_back(*first);
       }
    return vec;
}

/* ����������� ���-�� ������ ��� ��������� �� b �� e */
template <class _II>
void add_ref(_II b, _II e) { for(; b!=e; b++) { (*b)->add_ref(); } };

/* ����������� ���-�� ������ ��� ���� ��������� �������, 
 * ��. ���������� */
template <class C>
void add_ref(std::vector<C*> &v) { add_ref(v.begin(), v.end()); };

/* ��������� ���-�� ������ ��� ��������� �� b �� e */
template <class _II>
void release(_II b, _II e) { for(; b!=e; b++) { (*b)->release(); } };

/* ��������� ���-�� ������ ��� ���� ��������� �������
 * ��. ���������� */
template <class C>
void release(std::vector<C*> &v) { release(v.begin(), v.end()); };




inline
void split_string(std::vector<tstring> &res, const tstring& str, const TCHAR ch)
    {
     //std::for_each(str.begin(), str.end(), split_string_functor(res, ch));
     ::cli::util::splitString( str, res, ::cli::util::CIsExactCharVar<TCHAR>(ch) );
    }


/*
#define LLONG_MAX 9223372036854775807LL
#define LLONG_MIN (-LLONG_MAX - 1)
#define ULLONG_MAX (2ULL * LLONG_MAX + 1)
*/
inline
void tstringToI64(const tstring &str, INT64 &i, const ::sixml::util::tstring &attrOrTagName, const TCHAR *toType = _T("INT64"))
   {
    //::sixml::util::trim_copy
    if (str.empty()) ::sixml::throw_num_format_empty_string_error( toType, attrOrTagName );
    if (!::cli::util::str2Int( str, i ))
       ::sixml::throw_num_format_error( str, toType, attrOrTagName );

    //if ((i==_I64_MAX || i==_I64_MIN) && errno==ERANGE)
    if ((i==::std::numeric_limits<INT64>::max() || i==::std::numeric_limits<INT64>::min()) && errno==ERANGE)
       ::sixml::throw_num_format_range_error( str, toType, attrOrTagName );
   }

inline
void tstringToI64(const tstring &str, UINT64 &i, const ::sixml::util::tstring &attrOrTagName, const TCHAR *toType = _T("UINT64"))
   {
    if (str.empty()) ::sixml::throw_num_format_empty_string_error( toType, attrOrTagName );
    if (!::cli::util::str2Int( str, i ))
       ::sixml::throw_num_format_error( str, toType, attrOrTagName );

    if (i==::std::numeric_limits<UINT64>::max() && errno==ERANGE)
       ::sixml::throw_num_format_range_error( str, toType, attrOrTagName );
   }

template< typename IntType, INT64 lowLim, UINT64 highLim>
void tstringToIntType(const tstring &str, IntType &i, const ::sixml::util::tstring &attrOrTagName, const TCHAR *toType )
   {
    if (lowLim < 0) // signed type
       {
        INT64 tmpInt;
        tstringToI64( str, tmpInt, attrOrTagName, toType ? toType : _T("UNKNOWN") ); // base range checks goes here
        if (sizeof(IntType) < sizeof(INT64) )
           { // this type range is smaller than INT64 range
            if (tmpInt <        lowLim )  ::sixml::throw_int_format_range_underflow( str, toType, lowLim, attrOrTagName  );
            if (tmpInt > (INT64)highLim) ::sixml::throw_int_format_range_overflow ( str, toType, highLim, attrOrTagName );
           }
        i = (IntType)tmpInt;
       }
    else // unsigned type
       {
        UINT64 tmpInt;
        tstringToI64( str, tmpInt, attrOrTagName, toType ? toType : _T("UNKNOWN") ); // base range checks goes here
        if (sizeof(IntType) < sizeof(UINT64) )
           { // this type range is smaller than INT64 range
            if ((INT64)tmpInt < lowLim )  ::sixml::throw_int_format_range_underflow( str, toType, lowLim, attrOrTagName ); // low lim can be greater than zero
            if (tmpInt        > highLim) ::sixml::throw_int_format_range_overflow ( str, toType, highLim, attrOrTagName );
           }
        i = (IntType)tmpInt;
       }
   }


//template <typename IntType >
inline tstring i64totstr_(INT64 i, const ::sixml::util::tstring &attrOrTagName)
   {
    tstring res;
    if (!::cli::util::int2Str( i, res, 10 ))
       ::sixml::throw_num_to_string_format_error( attrOrTagName );
    return res;
   }

inline tstring i64totstr_(UINT64 i, const ::sixml::util::tstring &attrOrTagName)
   {
    tstring res;
    if (!::cli::util::int2Str( i, res, 10 ))
       ::sixml::throw_num_to_string_format_error( attrOrTagName );
    return res;
   }

template <typename IntType>
struct CIToStr
{
    tstring operator()( IntType i)
        {
         CLI_STATIC_CHECK(0, Template_struct_CIToStr_not_specialized_for_this_type)
         return tstring();
        }
};

#define SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_SIGNED( TypeName )        \
template <> struct CIToStr< TypeName >                                 \
{                                                                      \
    tstring operator()( TypeName i, const ::sixml::util::tstring &attrOrTagName) { return i64totstr_((INT64)i, attrOrTagName); }   \
};

#define SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_UNSIGNED( TypeName )      \
template <> struct CIToStr< TypeName >                                 \
{                                                                      \
    tstring operator()( TypeName i, const ::sixml::util::tstring &attrOrTagName) { return i64totstr_((UINT64)i, attrOrTagName); }  \
};



// keep in sync with metadata initialization with INT_PRIMITIVE_SPECIALISATION in prim.h

SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_UNSIGNED(unsigned int  )
SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_SIGNED(  signed int    )
//SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_SIGNED(  int           )

SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_UNSIGNED(unsigned long int  )
SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_SIGNED(  signed long int    )
//SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_SIGNED(  long int           )

SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_UNSIGNED(unsigned short)
SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_SIGNED(  signed short  )
//SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_SIGNED(         short  )

SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_UNSIGNED  (unsigned char)

SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_SIGNED(INT64)
SIXML_PRIMUTIL_INTCONVERT_SPECIALIZE_UNSIGNED(UINT64)

template <typename IntType>
tstring i64totstr( IntType i, const ::sixml::util::tstring &attrOrTagName)
   {
    //CIToStr<IntType> itos;
    //return itos(i);
    return CIToStr<IntType>()(i,attrOrTagName);
   }


inline tstring upperCopy(const tstring& str)
    {
     return MARTY_FILENAME::utils::upperCaseCopy( str );
    }

inline tstring lowerCopy(const tstring& str)
    {
     return MARTY_FILENAME::utils::lowerCaseCopy( str );
    }

inline bool EqualCI(const tstring& s1, const tstring& s2) 
    {
     return upperCopy(s1)==upperCopy(s2);
    }


//sixml::util::trim(*it);
inline
double tstringtod(const tstring &str, const TCHAR *totype, const ::sixml::util::tstring &attrOrTagName)
{
    tstring s = ::sixml::util::trim_copy(str);
    if (s.empty()) ::sixml::throw_num_format_error(str, totype, attrOrTagName);

    TCHAR *endptr = (TCHAR*)s.c_str();
    #if defined(WIN32)
        #if defined(_MSC_VER) && _MSC_VER>=1400 // 2005
        //double res = _tcstod_l( s.c_str(), &endptr, ::std::locale("C") );
        double res = _tcstod( s.c_str(), &endptr );
        #else  // other Win32 compilers
        double res = _tcstod( s.c_str(), &endptr );
        #endif
    #else
        #if defined(UNICODE) || defined(_UNICODE)
        double res = wcstod ( s.c_str(), &endptr );
        #else
        double res = strtod ( s.c_str(), &endptr );
        #endif
    #endif

    if ( *endptr!=_T('\0'))
       ::sixml::throw_num_format_error(str, totype, attrOrTagName);

    if ((res== + HUGE_VAL) || (res== - HUGE_VAL))
       ::sixml::throw_num_format_range_error(str, totype, attrOrTagName);

    return res;
}


inline tstring FtoT(double d, const ::sixml::util::tstring &attrOrTagName)
    {
     char buf[128];
     #if defined(_MSC_VER) && _MSC_VER>=1400
     //int fmtRes = _snprintf_s_l( buf, sizeof(buf)/sizeof(buf[0])-1, _TRUNCATE, "%0.12f", ::std::locale("C"), d );
     int fmtRes = _snprintf_s( buf, sizeof(buf)/sizeof(buf[0])-1, _TRUNCATE, "%0.12f", d );
     #else
     int fmtRes =  snprintf    ( buf, sizeof(buf)/sizeof(buf[0])-1, "%0.12f", d );
     #endif
     if (fmtRes<0)
        throw_num_to_string_format_error( attrOrTagName );
     buf[fmtRes] = 0;
    
     #if defined(UNICODE) || defined(_UNICODE)
     return MARTY_CON::a2wide(buf);
     #else
     return tstring(buf);
     #endif
    }

inline tstring FtoT(float d, const ::sixml::util::tstring &attrOrTagName)
    {
     char buf[128];
     #if defined(_MSC_VER) && _MSC_VER>=1400
     //int fmtRes = _snprintf_s_l( buf, sizeof(buf)/sizeof(buf[0])-1, _TRUNCATE, "%0.6f", ::std::locale("C"), d );
     int fmtRes = _snprintf_s( buf, sizeof(buf)/sizeof(buf[0])-1, _TRUNCATE, "%0.6f", d );
     #else
     int fmtRes =  snprintf    ( buf, sizeof(buf)/sizeof(buf[0])-1, "%0.6f", d );
     #endif
     if (fmtRes<0)
        throw_num_to_string_format_error(attrOrTagName);
     buf[fmtRes] = 0;
    
     #if defined(UNICODE) || defined(_UNICODE)
     return MARTY_CON::a2wide(buf);
     #else
     return tstring(buf);
     #endif
    }

}; // namespace util

}; // nameespace sixml


#ifdef CLI_XML_SIXML_PRIMUTIL_RESTORE_WIN__MAX /*max*/
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifdef CLI_XML_SIXML_PRIMUTIL_RESTORE_WIN_MIN /*min*/
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif



#endif /* CLI_XML_SIXML_PRIMUTIL_H */

