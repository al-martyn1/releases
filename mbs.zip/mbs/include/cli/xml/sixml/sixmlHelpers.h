#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_SIXMLHELPERS_H
#define CLI_XML_SIXML_SIXMLHELPERS_H
/* add this lines to your src
#ifndef CLI_XML_SIXML_SIXMLHELPERS_H
    #include <cli/xml/sixml/sixmlHelpers.h>
#endif
*/

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


namespace sixml
{

namespace helpers
{

inline
::std::string replace(const ::std::string &str, const ::std::string &strWhat, const std::string &strReplaceWith)
   {
    std::string res = str;
    std::string::size_type pos = res.find(strWhat);
    while(pos!=std::string::npos)
       {
        res.replace(pos, strWhat.size(), strReplaceWith);
        pos += strReplaceWith.size();
        pos = res.find(strWhat, pos);
       }
    return res;
   }

inline
void replaceInplace(::std::string &str, const ::std::string &strWhat, const std::string &strReplaceWith)
   {
    std::string &res = str;
    std::string::size_type pos = res.find(strWhat);
    while(pos!=std::string::npos)
       {
        res.replace(pos, strWhat.size(), strReplaceWith);
        pos += strReplaceWith.size();
        pos = res.find(strWhat, pos);
       }
   }

inline
::std::string replaceFirst(const ::std::string &str, const ::std::string &strWhat, const std::string &strReplaceWith)
   {
    std::string res = str;
    std::string::size_type pos = res.find(strWhat);
    if(pos!=std::string::npos)
       {
        res.replace(pos, strWhat.size(), strReplaceWith);
       }
    return res;
   }

inline
void replaceFirstInplace(::std::string &str, const ::std::string &strWhat, const std::string &strReplaceWith)
   {
    std::string &res = str;
    std::string::size_type pos = res.find(strWhat);
    if(pos!=std::string::npos)
       {
        res.replace(pos, strWhat.size(), strReplaceWith);
       }
   }

}; // namespace helpers

}; // namespace sixml


#endif // CLI_XML_SIXML_SIXMLHELPERS_H

