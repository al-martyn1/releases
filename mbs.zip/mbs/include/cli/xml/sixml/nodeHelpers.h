#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_NODEHELPERS_H
#define CLI_XML_SIXML_NODEHELPERS_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_XML_SIXML_INODE_H
    #include <cli/xml/sixml/inode.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef CLI_XML_SIXML_PRIMUTIL_H
    #include <cli/xml/sixml/primutil.h>
#endif


//-----------------------------------------------------------------
// ::sixml::helpers::
namespace sixml
{

namespace helpers
{

using ::sixml::util::tstring;

/*
MARTY_CON::strToAnsi
MARTY_CON::strToWide
#if defined(UNICODE) || defined(_UNICODE)
#else
#endif
*/

//-----------------------------------------------------------------------------
inline
RCODE readChildText( ::cli::sixml::CiNode &node, std::wstring &text, const std::wstring &tagOrAttrName, bool asAttr)
   {
    if (asAttr)
       return node.attributesGet( text, tagOrAttrName );
    else
       return node.childTextGet( text, tagOrAttrName );
   }

inline
RCODE readChildText( INTERFACE_CLI_SIXML_INODE *pNode, std::wstring &text, const std::wstring &tagOrAttrName, bool asAttr)
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return readChildText( node, text, tagOrAttrName, asAttr );
   }

// non-wide versions of readChildText
inline
RCODE readChildText( ::cli::sixml::CiNode &node, std::string &text, const std::string &tagOrAttrName, bool asAttr)
   {
    std::wstring resText;
    RCODE res = readChildText( node, resText, MARTY_CON::strToWide(tagOrAttrName), asAttr );
    if (!res) text = MARTY_CON::strToAnsi(resText);
    return res;
   }

inline
RCODE readChildText( INTERFACE_CLI_SIXML_INODE *pNode, std::string &text, const std::string &tagOrAttrName, bool asAttr)
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return readChildText( node, text, tagOrAttrName, asAttr );
   }

//-----------------------------------------------------------------------------
inline
RCODE readNodeText( ::cli::sixml::CiNode &node, ::std::wstring &text )
   {
    return node.textGet( text );
   }

inline
RCODE readNodeText( INTERFACE_CLI_SIXML_INODE *pNode, ::std::wstring &text )
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return node.textGet( text );
   }

inline
RCODE readNodeText( ::cli::sixml::CiNode &node, ::std::string &text )
   {
    std::wstring resText;
    RCODE res = node.textGet( resText );
    if (!res) text = MARTY_CON::strToAnsi(resText);
    return res;
   }

inline
RCODE readNodeText( INTERFACE_CLI_SIXML_INODE *pNode, ::std::string &text )
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return readNodeText(node, text );
   }

//-----------------------------------------------------------------------------
template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
RCODE readNodeOrChildText( ::cli::sixml::CiNode &node
                         , ::std::basic_string<CharType, Traits, Allocator> &text
                         , const CharType *nodeOrAttrName
                         , bool asAttr
                         )
   {
    if (nodeOrAttrName)
       return readChildText( node, text, nodeOrAttrName, asAttr); // get text of child node or attribute
    else
       return readNodeText( node, text ); // get text of self
   }

template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
RCODE readNodeOrChildText( INTERFACE_CLI_SIXML_INODE *pNode
                         , ::std::basic_string<CharType, Traits, Allocator> &text
                         , const CharType *nodeOrAttrName
                         , bool asAttr
                         )
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return readNodeOrChildText( node, text, nodeOrAttrName, asAttr);
   }

//-----------------------------------------------------------------------------
inline 
RCODE getNodeName( ::cli::sixml::CiNode &node, ::std::wstring &name )
   {
    return node.nameGet( name );
   }

inline 
RCODE getNodeName( INTERFACE_CLI_SIXML_INODE *pNode, ::std::wstring &name )
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return node.nameGet( name );
   }

inline 
RCODE getNodeName( ::cli::sixml::CiNode &node, ::std::string &name )
   {
    std::wstring resName;
    RCODE res = node.nameGet( resName );
    if (!res) name = MARTY_CON::strToAnsi(resName);
    return res;
   }

inline 
RCODE getNodeName( INTERFACE_CLI_SIXML_INODE *pNode, ::std::string &name )
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    std::wstring resName;
    RCODE res = node.nameGet( resName );
    if (!res) name = MARTY_CON::strToAnsi(resName);
    return res;
   }

//-----------------------------------------------------------------------------
// serialization error reporting helper
template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
RCODE getFieldUsedName( ::cli::sixml::CiNode &node
                      , ::std::basic_string<CharType, Traits, Allocator> &usedName
                      , const CharType *fieldName
                      )
   {
    if (fieldName) { usedName = fieldName; return EC_OK; }
    return getNodeName( node, usedName );
   }

template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
RCODE getFieldUsedName( INTERFACE_CLI_SIXML_INODE *pNode
                      , ::std::basic_string<CharType, Traits, Allocator> &usedName
                      , const CharType *fieldName
                      )
   {
    if (fieldName) { usedName = fieldName; return EC_OK; }
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return getNodeName( node, usedName );
   }

inline 
tstring getFieldUsedName( ::cli::sixml::CiNode &node, const TCHAR *fieldName )
   {
    tstring usedName;
    RCODE res = getFieldUsedName( node, usedName, fieldName );
    if (res) return tstring(_T("<UNDEFINED>"));
    return usedName;
   }

inline 
tstring getFieldUsedName( INTERFACE_CLI_SIXML_INODE *pNode, const TCHAR *fieldName )
   {
    tstring usedName;
    RCODE res = getFieldUsedName( pNode, usedName, fieldName );
    if (res) return tstring(_T("<UNDEFINED>"));
    return usedName;
   }

inline 
tstring getFieldUsedName( ::cli::sixml::CiNode &node, const TCHAR *fieldName, bool bAttr )
   {
    tstring usedName = bAttr ? tstring(_T("attribute: ")) : tstring(_T("tag: "));
    return usedName + getFieldUsedName( node, fieldName );
   }

inline 
tstring getFieldUsedName( INTERFACE_CLI_SIXML_INODE *pNode, const TCHAR *fieldName, bool bAttr )
   {
    tstring usedName = bAttr ? tstring(_T("attribute: ")) : tstring(_T("tag: "));
    return usedName + getFieldUsedName( pNode, fieldName );
   }


//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
inline
RCODE setChildText( ::cli::sixml::CiNode &node, const std::wstring &text, const std::wstring &tagOrAttrName, bool asAttr)
   {
    if (asAttr)
       return node.attributesSet( text, tagOrAttrName );
    else
       return node.createChildNodeWithText( tagOrAttrName, text );
   }

inline
RCODE setChildText( INTERFACE_CLI_SIXML_INODE *pNode, const std::wstring &text, const std::wstring &tagOrAttrName, bool asAttr)
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return setChildText( node, text, tagOrAttrName, asAttr );
   }

// non-wide versions of setChildText
inline
RCODE setChildText( ::cli::sixml::CiNode &node, const std::string &text, const std::string &tagOrAttrName, bool asAttr)
   {
    return setChildText( node, MARTY_CON::strToWide(text), MARTY_CON::strToWide(tagOrAttrName), asAttr );
   }

inline
RCODE setChildText( INTERFACE_CLI_SIXML_INODE *pNode, const std::string &text, const std::string &tagOrAttrName, bool asAttr)
   {
    return setChildText( pNode, MARTY_CON::strToWide(text), MARTY_CON::strToWide(tagOrAttrName), asAttr );
   }

//-----------------------------------------------------------------------------
inline
RCODE setNodeText( ::cli::sixml::CiNode &node, const ::std::wstring &text )
   {
    return node.textSet( text );
   }

inline
RCODE setNodeText( INTERFACE_CLI_SIXML_INODE *pNode, const ::std::wstring &text )
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return node.textSet( text );
   }

inline
RCODE setNodeText( ::cli::sixml::CiNode &node, const ::std::string &text )
   {
    return node.textSet( MARTY_CON::strToWide(text) );
   }

inline
RCODE setNodeText( INTERFACE_CLI_SIXML_INODE *pNode, const ::std::string &text )
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return node.textSet( MARTY_CON::strToWide(text) );
   }

//-----------------------------------------------------------------------------
template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
RCODE setNodeOrChildText( ::cli::sixml::CiNode &node
                         , const ::std::basic_string<CharType, Traits, Allocator> &text
                         , const CharType *nodeOrAttrName
                         , bool asAttr
                         )
   {
    if (nodeOrAttrName)
       return setChildText( node, text, nodeOrAttrName, asAttr); // get text of child node or attribute
    else
       return setNodeText( node, text ); // get text of self
   }

template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
RCODE setNodeOrChildText( INTERFACE_CLI_SIXML_INODE *pNode
                         , const ::std::basic_string<CharType, Traits, Allocator> &text
                         , const CharType *nodeOrAttrName
                         , bool asAttr
                         )
   {
    CLIASSERT(pNode);
    ::cli::sixml::CiNode node(pNode);
    return setNodeOrChildText( node, text, nodeOrAttrName, asAttr);
   }

//-----------------------------------------------------------------------------
inline
RCODE findNode( ::cli::sixml::CiNode &nodeChild, ::cli::sixml::CiNode &nodeCurrent, const wchar_t *nodeName )
   {
    if (!nodeName) { nodeChild = nodeCurrent; return EC_OK; }
    return nodeCurrent.findChild( nodeName, nodeChild.getPP() );
   }

inline
RCODE findNode( ::cli::sixml::CiNode &nodeChild, INTERFACE_CLI_SIXML_INODE *pNodeCurrent, const wchar_t *nodeName )
   {
    CLIASSERT(pNodeCurrent);
    ::cli::sixml::CiNode nodeCurrent(pNodeCurrent);
    return findNode( nodeChild, nodeCurrent, nodeName );
   }

inline
RCODE findNode( ::cli::sixml::CiNode &nodeChild, ::cli::sixml::CiNode &nodeCurrent, const char *nodeName )
   {
    if (!nodeName) { nodeChild = nodeCurrent; return EC_OK; }
    return nodeCurrent.findChild( MARTY_CON::strToWide(nodeName), nodeChild.getPP() );
   }

inline
RCODE findNode( ::cli::sixml::CiNode &nodeChild, INTERFACE_CLI_SIXML_INODE *pNodeCurrent, const char *nodeName )
   {
    CLIASSERT(pNodeCurrent);
    ::cli::sixml::CiNode nodeCurrent(pNodeCurrent);
    return findNode( nodeChild, nodeCurrent, nodeName );
   }

//-----------------------------------------------------------------------------
inline
RCODE createNode( ::cli::sixml::CiNode &nodeChild, ::cli::sixml::CiNode &nodeCurrent, const wchar_t *nodeName )
   {
    if (!nodeName) { nodeChild = nodeCurrent; return EC_OK; }
    return nodeCurrent.createChildNode( nodeName, nodeChild.getPP() );
   }

inline
RCODE createNode( ::cli::sixml::CiNode &nodeChild, INTERFACE_CLI_SIXML_INODE *pNodeCurrent, const wchar_t *nodeName )
   {
    CLIASSERT(pNodeCurrent);
    ::cli::sixml::CiNode nodeCurrent(pNodeCurrent);
    return createNode( nodeChild, nodeCurrent, nodeName );
   }

inline
RCODE createNode( ::cli::sixml::CiNode &nodeChild, ::cli::sixml::CiNode &nodeCurrent, const char *nodeName )
   {
    if (!nodeName) { nodeChild = nodeCurrent; return EC_OK; }
    return nodeCurrent.createChildNode( MARTY_CON::strToWide(nodeName), nodeChild.getPP() );
   }

inline
RCODE createNode( ::cli::sixml::CiNode &nodeChild, INTERFACE_CLI_SIXML_INODE *pNodeCurrent, const char *nodeName )
   {
    CLIASSERT(pNodeCurrent);
    ::cli::sixml::CiNode nodeCurrent(pNodeCurrent);
    return createNode( nodeChild, nodeCurrent, nodeName );
   }

//-----------------------------------------------------------------------------
inline
RCODE findTags( ::std::vector< ::cli::sixml::CiNode > &nodes, ::cli::sixml::CiNode &nodeCurrent, const wchar_t *nodeName)
   {
    if (!nodeName)
       {
        nodes.push_back(nodeCurrent);
        return EC_OK;
       }

    ::cli::sixml::CiNodeSet nodeSet;
    RCODE res = nodeCurrent.findChildNodes( nodeName, nodeSet.getPP() );
    if (res || !nodeSet) return EC_OK;

    SIZE_T nodeSetSize = 0;
    nodeSet.nodesSize( &nodeSetSize );
    nodes.reserve( nodeSetSize );

    for( SIZE_T i = 0; i!=nodeSetSize; ++i)
       {
        ::cli::sixml::CiNode node;
        if (nodeSet.nodesGet( node.getPP(), i ) || !node) continue;
        nodes.push_back( node );
       }
    return EC_OK;
   }

inline
RCODE findTags( ::std::vector< ::cli::sixml::CiNode > &nodes, INTERFACE_CLI_SIXML_INODE *pNodeCurrent, const wchar_t *nodeName)
   {
    CLIASSERT(pNodeCurrent);
    ::cli::sixml::CiNode nodeCurrent(pNodeCurrent);
    return findTags( nodes, nodeCurrent, nodeName );
   }

inline
RCODE findTags( ::std::vector< ::cli::sixml::CiNode > &nodes, ::cli::sixml::CiNode &nodeCurrent, const char *nodeName)
   {
    if (!nodeName)
       {
        nodes.push_back(nodeCurrent);
        return EC_OK;
       }
    return findTags( nodes, nodeCurrent, MARTY_CON::strToWide(nodeName).c_str() );
   }

inline
RCODE findTags( ::std::vector< ::cli::sixml::CiNode > &nodes, INTERFACE_CLI_SIXML_INODE *pNodeCurrent, const char *nodeName)
   {
    CLIASSERT(pNodeCurrent);
    ::cli::sixml::CiNode nodeCurrent(pNodeCurrent);
    return findTags( nodes, nodeCurrent, nodeName );
   }

//-----------------------------------------------------------------------------







}; // namespace helpers
}; // namespace sixml




#endif /* CLI_XML_SIXML_NODEHELPERS_H */

