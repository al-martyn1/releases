#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XML_SIXML_SERIALIZERCOMMON_H
#define CLI_XML_SIXML_SERIALIZERCOMMON_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_XML_SIXML_NODEHELPERS_H
    #include <cli/xml/sixml/nodeHelpers.h>
#endif

#ifndef CLI_XML_SIXML_PRIMUTIL_H
    #include <cli/xml/sixml/primutil.h>
#endif

#ifndef CLI_XML_SIXML_PRIM_H
    #include <cli/xml/sixml/prim.h>
#endif

#ifndef CLI_XML_SIXML_LAYOUT_H
    #include <cli/xml/sixml/layout.h>
#endif

#ifndef CLI_XML_SIXML_METACLAS_H
    #include <cli/xml/sixml/metaclas.h>
#endif

#ifndef CLI_XML_SIXML_SIXMLHELPERS_H
    #include <cli/xml/sixml/sixmlHelpers.h>
#endif


#define SIXML_DECLARE_CONST_FINDBY_TEMPLATE( fnName, memberName)                  \
template < typename TVector, typename TMember >                                            \
typename TVector::const_pointer fnName( const TVector &vec, const TMember &cmp )  \
   {                                                                              \
    typename TVector::const_iterator it = vec.begin();                            \
    for(;it != vec.end(); ++it)                                                   \
       {                                                                          \
        if (it -> memberName == cmp) return &(*it);                               \
       }                                                                          \
    return 0;                                                                     \
   }

#define SIXML_DECLARE_FINDBY_TEMPLATE( fnName, memberName)                        \
template < typename TVector, typename TMember >                                            \
typename TVector::pointer fnName( const TVector &vec, const TMember &cmp )        \
   {                                                                              \
    typename TVector::iterator it = vec.begin();                                  \
    for(;it != vec.end(); ++it)                                                   \
       {                                                                          \
        if (it -> memberName == cmp) return &(*it);                               \
       }                                                                          \
    return 0;                                                                     \
   }

#define SIXML_DECLARE_CONST_FINDBY_MEMBER_TEMPLATE( fnName, memberName)           \
template < typename TVector, typename TMember >                                            \
typename TVector::const_pointer fnName( const TVector &vec, const TMember &cmp ) const \
   {                                                                              \
    typename TVector::const_iterator it = vec.begin();                            \
    for(;it != vec.end(); ++it)                                                   \
       {                                                                          \
        if (it -> memberName == cmp) return &(*it);                               \
       }                                                                          \
    return 0;                                                                     \
   }

/*
#define SIXML_DECLARE_CONST_FINDBY_MEMBER( fnName, memberName, memberVectorName )
    SIXML_DECLARE_CONST_FINDBY_TEMPLATE( impl#fnName, memberName )
    template < typename TVector, TMember >
    typename TVector::const_pointer fnName( const TMember &cmp ) const
       {
        return impl#fnName( )
       }
*/

namespace sixml
{

// utiliti
/*
template < typename TVector, TMember >
typename TVector::const_pointer findByName( const TVector &vec, const TMember &cmp )
   {
    typename TVector::const_iterator it = vec.begin();
    for(;it != vec.end(); ++it)
       {
        if (it->name==cmp) return &(*it);
       }
    return 0;
   }
*/



namespace serializer
{

template<typename DataType> 
struct CDoNothing // stub predicat 
    {
     // modify data after loading
     void operator()( INTERFACE_CLI_SIXML_INODE *pRootNode, DataType &data ) const
        {}
     // modify xml tree before saving
     void operator()( INTERFACE_CLI_SIXML_INODE *pRootNode, const DataType &data ) const
        {}
    };


template <typename DataType>
void read_node( INTERFACE_CLI_SIXML_INODE *pNode
              , DataType& data
              , const meta_class<DataType>& dataMeta = default_meta_class<DataType>()
              )
   {
    dataMeta.read_node(pNode, data);
   }

template <typename DataType>
void write_node( INTERFACE_CLI_SIXML_INODE *pNode
               , const DataType& data
               , const meta_class<DataType>& dataMeta = default_meta_class<DataType>()
               )
   {
    dataMeta.write_node(pNode, data);
   }


template <typename DataType, typename CAfterLoadProcessingPred >
void parseSixmlNodeEx( INTERFACE_CLI_SIXML_INODE* pDomNode
                 , DataType &data
                 , const CAfterLoadProcessingPred &processingPred
                 , const meta_class<DataType>& dmc = default_meta_class<DataType>()
                 )
   {
    read_node( pDomNode, data, dmc );
    processingPred( pDomNode, data );
   }

template <typename DataType >
void parseSixmlNode( INTERFACE_CLI_SIXML_INODE* pDomNode
                 , DataType &data
                 , const meta_class<DataType>& dmc = default_meta_class<DataType>()
                 )
   {
    read_node( pDomNode, data, dmc );
   }

template <typename DataType, typename CAfterLoadProcessingPred >
void serializeToSixmlNodeEx( INTERFACE_CLI_SIXML_INODE* pDomNode
                 , const DataType &data
                 , const CAfterLoadProcessingPred &processingPred
                 , const meta_class<DataType>& dmc = default_meta_class<DataType>()
                 )
   {
    write_node( pDomNode, data, dmc );
    processingPred( pDomNode, data );
   }

template <typename DataType >
void serializeToSixmlNode( INTERFACE_CLI_SIXML_INODE* pDomNode
                 , const DataType &data
                 , const meta_class<DataType>& dmc = default_meta_class<DataType>()
                 )
   {
    write_node( pDomNode, data, dmc );
    processingPred( pDomNode, data );
   }





// Read Flags - some of them may be not implemented in separate implementations
const unsigned int rfSkipCheckRoot   = 1; // don't perform root tag name checking

const unsigned int rfUseXInclude     = 2; // supported by libxml2, msxml(?)



// Write Flags - some of them may be not implemented in separate implementations
const unsigned int wfBom            = 1;
const unsigned int wfNoDeclaration  = 2;
const unsigned int wfCondenced      = 4;
const unsigned int wfStandalone     = 8;


}; // namespace serializer
}; // namespace sixml


// serialization to/from string simple methods implementation

#define DECLARE_SIXML_SIMPLE_LOAD_METHOD( methodName )  \
                        RCODE methodName ( const ::std::string & xmlData );

#define IMPLEMENT_SIXML_SIMPLE_LOAD_METHOD( className, methodName, tagName )                    \
                        RCODE className :: methodName( const ::std::string & xmlData )          \
                           {                                                                    \
                            CLI_TRY{                                                            \
                                    ::sixml::serializer::load( xmlData, _T( tagName ), *this ); \
                                   }                                                            \
                            CLI_CATCH_RETURN_CLI_EXCEPTION()                                    \
                            CLI_CATCH_RETURN_STD_EXCEPTIONS()                                   \
                            return EC_OK;                                                       \
                           }

#define INLINE_SIXML_SIMPLE_LOAD_METHOD( methodName, tagName )                                  \
                        RCODE methodName( const ::std::string & xmlData )                       \
                           {                                                                    \
                            CLI_TRY{                                                            \
                                    ::sixml::serializer::load( xmlData, _T( tagName ), *this ); \
                                   }                                                            \
                            CLI_CATCH_RETURN_CLI_EXCEPTION()                                    \
                            CLI_CATCH_RETURN_STD_EXCEPTIONS()                                   \
                            return EC_OK;                                                       \
                           }


#define DECLARE_SIXML_SIMPLE_SAVE_METHOD( methodName )  \
                        RCODE methodName ( const ::std::string & xmlData ) const;

#define IMPLEMENT_SIXML_SIMPLE_SAVE_METHOD( className, methodName, tagName )                    \
                        RCODE className :: methodName ( ::std::string & xmlData ) const         \
                           {                                                                    \
                            CLI_TRY{                                                            \
                                    ::sixml::serializer::save( xmlData, _T( tagName ), *this ); \
                                   }                                                            \
                            CLI_CATCH_RETURN_CLI_EXCEPTION()                                    \
                            CLI_CATCH_RETURN_STD_EXCEPTIONS()                                   \
                            return EC_OK;                                                       \
                           }

#define INLINE_SIXML_SIMPLE_SAVE_METHOD( methodName, tagName )                                  \
                        RCODE methodName ( ::std::string & xmlData ) const                      \
                           {                                                                    \
                            CLI_TRY{                                                            \
                                    ::sixml::serializer::save( xmlData, _T( tagName ), *this ); \
                                   }                                                            \
                            CLI_CATCH_RETURN_CLI_EXCEPTION()                                    \
                            CLI_CATCH_RETURN_STD_EXCEPTIONS()                                   \
                            return EC_OK;                                                       \
                           }

#define INLINE_SIXML_SIMPLE_SAVELOAD_METHODS_EX( nameLoad, nameSave, tagName ) \
                INLINE_SIXML_SIMPLE_LOAD_METHOD( nameLoad, tagName )           \
                INLINE_SIXML_SIMPLE_SAVE_METHOD( nameSave, tagName )

#define INLINE_SIXML_SIMPLE_SAVELOAD_METHODS( tagName )  INLINE_SIXML_SIMPLE_SAVELOAD_METHODS_EX( load, save, tagName )




#endif /* CLI_XML_SIXML_SERIALIZERCOMMON_H */

