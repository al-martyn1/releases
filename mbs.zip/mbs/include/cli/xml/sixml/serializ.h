#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

/* Serialization from/to SiXML tree
 * Designed by Andrey Martynov
 * mailto:rek@.rsdn.ru
 * Rewritten by Alex Martinov (amart@mail.ru), 2004.
 */
#ifndef CLI_XML_SIXML_SERIALIZ_H
#define CLI_XML_SIXML_SERIALIZ_H

#ifndef __cplusplus
    #error <sixml/serializ.h> requires C++ compilation (use '.cpp' file name extention)
#endif

/*
#ifndef __SIXML_STDINC_H_INLUDED__
    #include <sixml/stdinc.h>
#endif 
*/

/*/
#ifndef CLI_XML_SIXML_SIXMLX_H
    #include <sixml/sixmlx.h>
#endif 

#ifndef __SIXML_SIXMLEXCEP_H_INCLUDED__
    #include <sixml/6mlexcep.h>
#endif
*/

namespace sixml {
    namespace serializer{
        namespace types{
        };
    };
};

/*
#ifndef __SIXML_SIXMLEXCEP_H_INCLUDED__
    #include <sixml/6mlexcep.h>
#endif 

#ifndef CLI_XML_SIXML_NODEMANI_H
    #include <sixml/nodemani.h>
#endif
*/

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_XML_SIXML_6MLEXCEP_H
    #include <cli/xml/sixml/6mlexcep.h>
#endif

#ifndef CLI_XML_SIXML_UTILS_H
    #include <cli/xml/sixml/util.h>
#endif

#ifndef CLI_XML_SIXML_PRIM_H
    #include <cli/xml/sixml/prim.h>
#endif

#ifndef CLI_XML_SIXML_METACLAS_H
    #include <cli/xml/sixml/metaclas.h>
#endif

#ifndef CLI_XML_SIXML_LAYOUT_H
    #include <cli/xml/sixml/layout.h>
#endif


#ifndef _6MLNS
    #define _6MLNS sixml::
#endif

#ifndef _STDNS
    #define _STDNS ::std::
#endif



namespace sixml{
namespace util{

    #ifndef SIXML_UTIL_TSTRING_DEFINED
    #define SIXML_UTIL_TSTRING_DEFINED
    typedef std::basic_string<TCHAR>  tstring;
    // using ::sixml::util::tstring
    #endif /* SIXML_UTIL_TSTRING_DEFINED */

}; // namespace util
}; // namespace sixml



namespace sixml {


namespace serializer{



template <typename DataType>
void read_node( i_sixml_node* node, 
                DataType& data,
                const meta_class<DataType>& dmc = default_meta_class<DataType>())
{
    data = dmc.read_node(node);
};


template <typename DataType>
void write_node( i_sixml_node* node, 
                const DataType& data,
                const meta_class<DataType>& dmc = default_meta_class<DataType>())
{
    dmc.write_node(node, data);
};

template <typename DataType>
void update_node( i_sixml_node* node, 
                const DataType& data,
                const meta_class<DataType>& dmc = default_meta_class<DataType>())
{
    dmc.update_node(node, data);
};





//---------------------------------------------------------
/*

template <class IParser, class IValidator>
int load_xml( const TCHAR* file, 
              IParser *iparser, 
              IValidator *ivalidator);

template <class IParser, class IValidator>
i_sixml_node* load_xml( const TCHAR* file, 
                        int *err_code, 
                        IParser *iparser, 
                        IValidator *ivalidator);

i_sixml_node* load_xml(const TCHAR* file, int *err_code);

*/

/* return <0 if api error, > 0 if parser error */
template <class IParser, class IValidator>
int load_xml( const TCHAR* file, 
              IParser *iparser, 
              IValidator *ivalidator)
{
    if (!file || !iparser || !ivalidator)
       {
        SetLastError(ERROR_INVALID_PARAMETER);
        return -1;
       }
    iparser->set_file_name(file);
    iparser->init(ivalidator);
    HANDLE hfile_in = CreateFile( file, GENERIC_READ, 
                                  FILE_SHARE_READ, 0, OPEN_EXISTING,
                                  0, 0 );
    if (hfile_in==INVALID_HANDLE_VALUE) { return -3; }
    // -3 ����� � �������. (�� ����� ���� �� ������, �� ��� �� �����).
    // ��� ���������� <0 ������� �������� ��� ������ ����� GetLastError
    // ������ ������� ����� ���� �� 0 (��� ������), �� 20. 
    // (�� ������ ������ - 07/26/04)

    int res; char buf[4096]; DWORD readed;
    BOOL read_res = ReadFile( hfile_in, buf, sizeof(buf), &readed, 0);
    while (read_res)
      {
       if (!readed) 
          { break; }
       else
          {
           int err = 0;
           res = iparser->put(buf, readed, 0);
           if (res<0) { res = iparser->restore(); err = iparser->get_error(); }
           if (res<0) { CloseHandle(hfile_in); return err; }
          }
       read_res = ReadFile( hfile_in, buf, sizeof(buf), &readed, 0);
      }
    iparser->end();
    CloseHandle(hfile_in);
    return 0;
}
//---------------------------------------------------------
/* Place result code onto *err_code if (err_code) */
/* return <0 if api error, > 0 if parser error */
template <class IParser, class IValidator>
i_sixml_node* load_xml( const TCHAR* file, 
                        int *err_code, 
                        IParser *iparser, 
                        IValidator *ivalidator)
{
    int res = load_xml<IParser, IValidator>(file, iparser, ivalidator);
    if (res)
       { /* loading failed, free objects, store result and return zero document pointer */
        if (err_code) *err_code = res;
        return 0;
       }
    i_sixml_node* doc = iparser->get_document();
    doc->add_ref();
    return doc;
}
//---------------------------------------------------------
inline
i_sixml_node* load_xml(const TCHAR* file, int *err_code)
{
    i_sixml_parser *i_parser = create_sixml_parser();
    if (!i_parser)
       {
        SetLastError(ERROR_MOD_NOT_FOUND);
        if (err_code) *err_code = -1;
        return 0;
       }
    simple_validator smp(i_parser);
//    int res = load_xml<i_sixml_parser, i_sixml_validator>(file, i_parser, &smp);    
    int res = load_xml(file, i_parser, &smp);    
    if (res)
       { // loading failed, free objects, store result and return zero document pointer
        if (err_code) *err_code = res;
        i_parser->release();
        return 0;
       }
    i_sixml_node* doc = i_parser->get_document();
    doc->add_ref();
    i_parser->release();
    return doc;
}
//---------------------------------------------------------
template <class IParser, class IValidator, class DataType>
void load_xml( const TCHAR* file, 
              IParser *iparser, 
              IValidator *ivalidator,
              DataType &dt,
              const meta_class<DataType>& dmc = default_meta_class<DataType>())
{
    int err;
    i_sixml_node* document = load_xml<IParser, IValidator>( file, &err, iparser, ivalidator);
    if (!document)
       {
        if (err<0) throw winapi_error();
        else throw parser_error(iparser, file);
       }
    //read_node( document, dt/*, struct_meta_class<test>(test::layout_default())*/);
    read_node( document, dt, dmc);
}
//---------------------------------------------------------
template <class DataType>
void load_xml( const TCHAR* file, 
              DataType &dt,
              const meta_class<DataType>& dmc = default_meta_class<DataType>())
{
    cliptr_t<i_sixml_parser> i_parser(create_sixml_parser());
    if (!i_parser)
       { SetLastError(ERROR_MOD_NOT_FOUND); throw winapi_error(); }
    simple_validator smp(i_parser.get());
    load_xml(file, i_parser.get(), &smp, dt, dmc);
}
//---------------------------------------------------------
template <class DataType>
void load_xml( const TCHAR* file, 
              DataType &dt,
              const TCHAR *root_tag,
              const meta_class<DataType>& dmc = default_meta_class<DataType>())
{
    cliptr_t<i_sixml_parser> i_parser(create_sixml_parser());
    if (!i_parser)
       { SetLastError(ERROR_MOD_NOT_FOUND); throw winapi_error(); }
    simple_validator smp(i_parser.get(), root_tag);
    load_xml(file, i_parser.get(), &smp, dt, dmc);
}
//---------------------------------------------------------
//---------------------------------------------------------
//---------------------------------------------------------
/* return > 0 if parser error */
template <class IParser, class IValidator>
int load_xml_from_string( const char *data, 
                          size_t data_len, 
                          IParser *iparser, 
                          IValidator *ivalidator)
{
    if (!data_len) return 2; // unexpected eof
    if (!data) return 3; // invalid param
    if (!iparser || !ivalidator)
       {
        SetLastError(ERROR_INVALID_PARAMETER);
        return -1;
       }
    iparser->init(ivalidator);
    int res = iparser->put(data, data_len, 0);
    if (res<0) return iparser->get_error();
    iparser->end();
    return 0;
}
//---------------------------------------------------------
template <class IParser, class IValidator>
int load_xml_from_string( const std::string &str, 
                          IParser *iparser, 
                          IValidator *ivalidator)
{
    //if (str.empty()) return 2; // unexpected eof
    return load_xml_from_string(str.c_str(), str.size(), iparser, ivalidator);
}


//---------------------------------------------------------
/* Place result code onto *err_code if (err_code) */
/* return <0 if api error, > 0 if parser error */
template <class IParser, class IValidator>
i_sixml_node* load_xml_from_string( const char *data,                                     
                                    size_t data_len, 
                                    int *err_code, 
                                    IParser *iparser, 
                                    IValidator *ivalidator)
{
    if (!data_len) 
       {
        if (*err_code) *err_code = 2; // unexpected eof
        return 0; 
       }
    if (!data) 
       {
        if (*err_code) *err_code = 3; // invalid param
        return 0; 
       }
    int res = load_xml_from_string<IParser, IValidator>(data, data_len, iparser, ivalidator);
    if (res)
       { /* loading failed, free objects, store result and return zero document pointer */
        if (err_code) *err_code = res;
        return 0;
       }
    i_sixml_node* doc = iparser->get_document();
    doc->add_ref();
    return doc;
}
//---------------------------------------------------------
template <class IParser, class IValidator>
i_sixml_node* load_xml_from_string( const std::string &str, 
                                    int *err_code, 
                                    IParser *iparser, 
                                    IValidator *ivalidator)
{
    //if (str.empty()) return 2; // unexpected eof
    return load_xml_from_string<IParser, IValidator>(str.c_str(), str.size(), err_code, iparser, ivalidator);
}


//---------------------------------------------------------
inline
i_sixml_node* load_xml_from_string( const char *data, 
                                    size_t data_len, 
                                    int *err_code)
{
    if (!data_len) 
       {
        if (*err_code) *err_code = 2; // unexpected eof
        return 0; 
       }
    if (!data) 
       {
        if (*err_code) *err_code = 3; // invalid param
        return 0; 
       }
    i_sixml_parser *i_parser = create_sixml_parser();
    if (!i_parser)
       {
        SetLastError(ERROR_MOD_NOT_FOUND);
        if (err_code) *err_code = -1;
        return 0;
       }
    simple_validator smp(i_parser);
    int res = load_xml_from_string(data, data_len, i_parser, &smp);    
    if (res)
       { // loading failed, free objects, store result and return zero document pointer
        if (err_code) *err_code = res;
        i_parser->release();
        return 0;
       }
    i_sixml_node* doc = i_parser->get_document();
    doc->add_ref();
    i_parser->release();
    return doc;
}
//---------------------------------------------------------
inline
i_sixml_node* load_xml_from_string( const std::string &str, 
                                    int *err_code)
{
    //if (str.empty()) return 2; // unexpected eof
    return load_xml_from_string(str.c_str(), str.size(), err_code);
}
//---------------------------------------------------------
//---------------------------------------------------------
//---------------------------------------------------------



//---------------------------------------------------------
//---------------------------------------------------------
//---------------------------------------------------------
/* return <0 if api error */
namespace write_attr{
enum write_method{
     default_method = 0,
     more_indent = 1,
     less_indent = 2
    };
};

inline
void write_xml_to_string( std::string &str, 
                          i_sixml_node* doc, 
                          sixml::serializer::write_attr::write_method wm=sixml::serializer::write_attr::default_method,
                          bool human_readable=false,
                          bool forceUtf8 = false,
                          bool standalone = false
                        )
{

//    size_t size = get_child_count(doc);
//    str.reserve(str.size() + size*16);
//    printf("Reserved size: %d\n", size*16);
    
    PCTSTR __enc_name = doc->get_enc();
    ::sixml::util::tstring enc_name;
    if (!__enc_name)
       enc_name = _T("");
    else
       enc_name = __enc_name;
    //#if defined(UNICODE) || defined(_UNICODE)    
    if (enc_name.empty())
       {
        #if defined(UNICODE) || defined(_UNICODE)
        enc_name = _T("UTF-8");
        #else
        if (forceUtf8)
           enc_name = _T("UTF-8");
        else
           enc_name = _T("Windows-1251");
        #endif
        doc->set_enc(enc_name.c_str(), 1);
       }
    
    str.reserve(str.size() + get_child_count(doc)*32);
    i_string_wrap_ostream_imp ostrs(str);
    size_t written;
    static char *xml_pi = "<?xml version=\"1.0\"";
    static char *enc_attr = " encoding=\"";
    static char *standalone_str = "\" standalone=\"yes";
    static char *dq_str = "\"";
    ostrs.write(xml_pi, strlen(xml_pi), &written);
    //PCSTR enc_name = doc->get_enc();
    //if (enc_name && strlen(enc_name))
    //   {
        ostrs.write(enc_attr, strlen(enc_attr), &written);
        ostrs.write(__to_ansi(enc_name).c_str(), enc_name.size(), &written);
        if (standalone)
           ostrs.write(standalone_str, strlen(standalone_str), &written);
        ostrs.write(dq_str, strlen(dq_str), &written);
    //   }
    ostrs.write("?>\r\n", strlen("?>\r\n"), &written);

    if (human_readable) 
       {
        sixml::format_readable(doc);
       }
    else
       {
        wm = write_attr::default_method;
       }

    char buf[1024] = { 0 };
    if (wm==write_attr::more_indent)
       doc->write_xml2(&ostrs, buf, sizeof(buf), 0);
    else if (wm==write_attr::less_indent)
       doc->write_xml2(&ostrs, buf, sizeof(buf), 1);
    else
        doc->write_xml(&ostrs, 0, 0, 0);    
}
//---------------------------------------------------------
/* return <0 if api error */
inline
int write_xml( const TCHAR* file, 
               i_sixml_node* doc, 
               sixml::serializer::write_attr::write_method wm=sixml::serializer::write_attr::default_method,
               bool human_readable=false,
               bool forceUtf8 = false,
               bool standalone = false
               )
{
    HANDLE hfile =   CreateFile( file, GENERIC_WRITE, 
                                  FILE_SHARE_READ, 0, 
                                  /*OPEN_ALWAYS*/CREATE_ALWAYS,
                                  0, 0 );
    if (hfile==INVALID_HANDLE_VALUE) { return -3; }
    // -3 ����� � �������. (�� ����� ���� �� ������, �� ��� �� �����).
    // ��� ���������� <0 ������� �������� ��� ������ ����� GetLastError
    // ������ ������� ����� ���� �� 0 (��� ������), �� 20. 
    // (�� ������ ������ - 07/26/04)

    std::string str;
    write_xml_to_string(str, doc, wm, human_readable, forceUtf8, standalone);
    DWORD dw_written;
    if (!WriteFile(hfile, str.c_str(), (DWORD)str.size(), &dw_written, 0))
       {
        DWORD err = GetLastError();
        CloseHandle(hfile);
        SetLastError(err);
        return -3;
       }
    CloseHandle(hfile);
    return 0;
}
//---------------------------------------------------------
template <typename DataType>
int write_xml( const TCHAR* file,
                const TCHAR* root_tag,
                const DataType& data,
                sixml::serializer::write_attr::write_method wm=sixml::serializer::write_attr::default_method,
                bool human_readable=false,
                bool forceUtf8 = false,
                bool standalone = false,
                const meta_class<DataType>& dmc = default_meta_class<DataType>())
{
    i_sixml_node* node = create_sixml_node_ex(root_tag, 0);
    write_node( node, data, dmc );
    int res = write_xml(file, node, wm, human_readable, forceUtf8, standalone);
    node->release();
    return res;
};









}; // namespace serializer


    }; // namespace ::sixml


#endif /* CLI_XML_SIXML_SERIALIZ_H */
