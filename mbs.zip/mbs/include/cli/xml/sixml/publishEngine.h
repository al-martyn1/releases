//#ifndef CLI_XML_SIXML_PUBLISHENGINE_H
//#define CLI_XML_SIXML_PUBLISHENGINE_H

// internal header file, include guard not needed

#ifndef CLI_XML_SIXML_ENGINE
    #error "publishEngine.h internal header must be included with defined CLI_XML_SIXML_ENGINE macro"
#endif

namespace sixml
{
namespace serializer
{

    typedef CLI_XML_SIXML_ENGINE::CXmlEngineGlobalInitializer   CXmlEngineGlobalInitializer;

    inline
    INTERFACE_CLI_SIXML_INODE* loadToSixmlDomNode( const ::std::string &xmlString
                                                 , const ::sixml::util::tstring &rootTag
                                                 , ::sixml::util::tstring *pReadedRootTag
                                                 , unsigned int flags = 0
                                                 , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
                                                 )
       {
        return CLI_XML_SIXML_ENGINE::loadToSixmlDomNode( xmlString, rootTag, pReadedRootTag, flags, baseFile );
       }

    template <typename DataType, typename CAfterLoadProcessingPred >
    void loadEx( const ::std::string &xmlString
             , const ::sixml::util::tstring &rootTag
             , DataType &data
             , ::sixml::util::tstring *pReadedRootTag
             , const CAfterLoadProcessingPred &processingPred
             , unsigned int flags = 0
             , const meta_class<DataType>& dmc =  /* ::sixml::serializer:: */ default_meta_class<DataType>()
             , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
             )
       {
        CLI_XML_SIXML_ENGINE::loadEx( xmlString, rootTag, data, pReadedRootTag, processingPred, flags, dmc, baseFile );
       }

    template <typename DataType>
    void load( const ::std::string &xmlString
             , const ::sixml::util::tstring &rootTag
             , DataType &data
             , ::sixml::util::tstring *pReadedRootTag = 0
             , unsigned int flags = 0
             , const meta_class<DataType>& dmc =  /* ::sixml::serializer:: */ default_meta_class<DataType>()
             , const ::sixml::util::tstring &baseFile = ::sixml::util::tstring()
             )
       {
        CLI_XML_SIXML_ENGINE::load( xmlString, rootTag, data, pReadedRootTag, flags, dmc, baseFile );
       }

    inline
    INTERFACE_CLI_SIXML_INODE* createSixmlDocumentRootForWriting( const ::sixml::util::tstring &rootTag
                                                 , unsigned int flags = 0
                                                 )
       {
        return CLI_XML_SIXML_ENGINE::createSixmlDocumentRootForWriting( rootTag, flags );
       }

    inline
    void serializeToXmlString( ::std::string &xmlString
                                          , INTERFACE_CLI_SIXML_INODE* pNode
                                          , unsigned int flags// = 0
                                          )
       {                                         
        CLI_XML_SIXML_ENGINE::serializeToXmlString( xmlString, pNode, flags );
       }

    template <typename DataType, typename CBeforeSaveProcessingPred>
    void saveEx( ::std::string &xmlString
              , const ::sixml::util::tstring &rootTag
              , const DataType& data
              , const CBeforeSaveProcessingPred &processingPred
              , unsigned int flags = 0
              , const meta_class<DataType>& dmc =  /* ::sixml::serializer:: */ default_meta_class<DataType>()
              )
       {
        CLI_XML_SIXML_ENGINE::saveEx( xmlString, rootTag, data, processingPred, flags, dmc );
       }

    template <typename DataType>
    void save( ::std::string &xmlString
              , const ::sixml::util::tstring &rootTag
              , const DataType& data
              , unsigned int flags = 0
              , const meta_class<DataType>& dmc =  /* ::sixml::serializer:: */ default_meta_class<DataType>()
              )
       {
        CLI_XML_SIXML_ENGINE::save( xmlString, rootTag, data, flags, dmc );
       }

}; // namespace serializer
}; // namespace sixml


// #endif // CLI_XML_SIXML_PUBLISHENGINE_H


