#ifndef DBG_ASAX_AUTOMATA_H
#define DBG_ASAX_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */



#ifndef CLI_SAX_CSAXPARSERBASE_LOGGING_USED
#define CLI_SAX_CSAXPARSERBASE_LOGGING_USED
#endif




namespace cli {
namespace sax {

class CSaxParserBase {

    private:    int                  lvl         ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state
    public:     static const int     ST_cDATA     = 0x00000001; //!< CDATA
    public:     static const int     ST_cDATA1    = 0x00000002; //!< CDATA1
    public:     static const int     ST_cDATA2    = 0x00000003; //!< CDATA2
    public:     static const int     ST_cDATA3    = 0x00000004; //!< CDATA3
    public:     static const int     ST_cDATA4    = 0x00000005; //!< CDATA4
    public:     static const int     ST_cDATA5    = 0x00000006; //!< CDATA5
    public:     static const int     ST_cDATA6    = 0x00000007; //!< CDATA6
    public:     static const int     ST_cDATAE1   = 0x00000008; //!< CDATAE1
    public:     static const int     ST_cDATAE2   = 0x00000009; //!< CDATAE2
    public:     static const int     ST_cOMMENT   = 0x0000000A; //!< COMMENT
    public:     static const int     ST_cOMMENT1  = 0x0000000B; //!< COMMENT1
    public:     static const int     ST_cOMMENT2  = 0x0000000C; //!< COMMENT2
    public:     static const int     ST_cOMMENTE1 = 0x0000000D; //!< COMMENTE1
    public:     static const int     ST_cOMMENTE2 = 0x0000000E; //!< COMMENTE2
    public:     static const int     ST_eFail     = 0x8000000F; //!< E_FAIL
    public:     static const int     ST_eFail2    = 0x80000010; //!< E_FAIL2
    public:     static const int     ST_eFail3    = 0x80000011; //!< E_FAIL3
    public:     static const int     ST_eOk       = 0x80000012; //!< E_OK
    public:     static const int     ST_readAttrName = 0x00000013; //!< READ_ATTR_NAME
    public:     static const int     ST_readAvapos = 0x00000014; //!< READ_AVAPOS
    public:     static const int     ST_readAvquot = 0x00000015; //!< READ_AVQUOT
    public:     static const int     ST_readAvUnquot = 0x00000016; //!< READ_AV_UNQUOT
    public:     static const int     ST_readDtd   = 0x00000017; //!< READ_DTD
    public:     static const int     ST_readPi    = 0x00000018; //!< READ_PI
    public:     static const int     ST_readTagName = 0x00000019; //!< READ_TAG_NAME
    public:     static const int     ST_readTagNameEnd = 0x0000001A; //!< READ_TAG_NAME_END
    public:     static const int     ST_readTagNameEndSpaces                                      = 0x0000001B; //!< READ_TAG_NAME_END_SPACES
    public:     static const int     ST_tagAloneEnd = 0x0000001C; //!< TAG_ALONE_END
    public:     static const int     ST_tagAloneEnd2 = 0x0000001D; //!< TAG_ALONE_END2
    public:     static const int     ST_waitAttrName = 0x0000001E; //!< WAIT_ATTR_NAME
    public:     static const int     ST_waitAttrVal = 0x0000001F; //!< WAIT_ATTR_VAL
    public:     static const int     ST_waitEq    = 0x00000020; //!< WAIT_EQ
    public:     static const int     ST_waitNextAttrName = 0x00000021; //!< WAIT_NEXT_ATTR_NAME
    public:     static const int     ST_waitPiEnd = 0x00000022; //!< WAIT_PI_END
    public:     static const int     ST_waitTagName = 0x00000023; //!< WAIT_TAG_NAME
    public:     static const int     ST_waitTagNameEnd = 0x00000024; //!< WAIT_TAG_NAME_END
    public:     static const int     ST_waitTagStart = 0x00000025; //!< WAIT_TAG_START
    public:     static const int     ST_waitTagStart0 = 0x00000026; //!< WAIT_TAG_START0
    public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__


    public:     
        void
        putChar
               ( char  ch          
               )
           {
            /* guard variable - ch */
            switch(this->curState)
               {
                case ST_cDATA:    /* CDATA */
                        if (ch==L']') /* Guard: [']'] */
                           {
                            this->logEvent( 0, ST_cDATA, ST_cDATAE1, "Transition from CDATA to CDATAE1 on putChar, guard: ']'" );
                               /* State CDATA - exit_action empty */
                               /* Transition from CDATA to CDATAE1 actions */
                               /* State CDATAE1 - entry_action empty */
                            this->curState = ST_cDATAE1;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATA, ST_cDATA, "Transition from CDATA to CDATA on putChar, default transition" );
                               /* State CDATA - exit_action empty */
                               /* Transition from CDATA to CDATA actions */
                               this->logEvent( 0x0202, ST_cDATA, ST_cDATA, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State CDATA - entry_action empty */
                            this->curState = ST_cDATA;
                           }
                     break;
                case ST_cDATA1:    /* CDATA1 */
                        if (ch==L'C') /* Guard: ['C'] */
                           {
                            this->logEvent( 0, ST_cDATA1, ST_cDATA2, "Transition from CDATA1 to CDATA2 on putChar, guard: 'C'" );
                               /* State CDATA1 - exit_action empty */
                               /* Transition from CDATA1 to CDATA2 actions */
                               /* State CDATA2 - entry_action empty */
                            this->curState = ST_cDATA2;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATA1, ST_eFail3, "Transition from CDATA1 to E_FAIL3 on putChar, default transition" );
                               /* State CDATA1 - exit_action empty */
                               /* Transition from CDATA1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA2:    /* CDATA2 */
                        if (ch==L'D') /* Guard: ['D'] */
                           {
                            this->logEvent( 0, ST_cDATA2, ST_cDATA3, "Transition from CDATA2 to CDATA3 on putChar, guard: 'D'" );
                               /* State CDATA2 - exit_action empty */
                               /* Transition from CDATA2 to CDATA3 actions */
                               /* State CDATA3 - entry_action empty */
                            this->curState = ST_cDATA3;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATA2, ST_eFail3, "Transition from CDATA2 to E_FAIL3 on putChar, default transition" );
                               /* State CDATA2 - exit_action empty */
                               /* Transition from CDATA2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA3:    /* CDATA3 */
                        if (ch==L'A') /* Guard: ['A'] */
                           {
                            this->logEvent( 0, ST_cDATA3, ST_cDATA4, "Transition from CDATA3 to CDATA4 on putChar, guard: 'A'" );
                               /* State CDATA3 - exit_action empty */
                               /* Transition from CDATA3 to CDATA4 actions */
                               /* State CDATA4 - entry_action empty */
                            this->curState = ST_cDATA4;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATA3, ST_eFail3, "Transition from CDATA3 to E_FAIL3 on putChar, default transition" );
                               /* State CDATA3 - exit_action empty */
                               /* Transition from CDATA3 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA4:    /* CDATA4 */
                        if (ch==L'T') /* Guard: ['T'] */
                           {
                            this->logEvent( 0, ST_cDATA4, ST_cDATA5, "Transition from CDATA4 to CDATA5 on putChar, guard: 'T'" );
                               /* State CDATA4 - exit_action empty */
                               /* Transition from CDATA4 to CDATA5 actions */
                               /* State CDATA5 - entry_action empty */
                            this->curState = ST_cDATA5;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATA4, ST_eFail3, "Transition from CDATA4 to E_FAIL3 on putChar, default transition" );
                               /* State CDATA4 - exit_action empty */
                               /* Transition from CDATA4 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA5:    /* CDATA5 */
                        if (ch==L'A') /* Guard: ['A'] */
                           {
                            this->logEvent( 0, ST_cDATA5, ST_cDATA6, "Transition from CDATA5 to CDATA6 on putChar, guard: 'A'" );
                               /* State CDATA5 - exit_action empty */
                               /* Transition from CDATA5 to CDATA6 actions */
                               /* State CDATA6 - entry_action empty */
                            this->curState = ST_cDATA6;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATA5, ST_eFail3, "Transition from CDATA5 to E_FAIL3 on putChar, default transition" );
                               /* State CDATA5 - exit_action empty */
                               /* Transition from CDATA5 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA6:    /* CDATA6 */
                        if (ch==L'[') /* Guard: ['['] */
                           {
                            this->logEvent( 0, ST_cDATA6, ST_cDATA, "Transition from CDATA6 to CDATA on putChar, guard: '['" );
                               /* State CDATA6 - exit_action empty */
                               /* Transition from CDATA6 to CDATA actions */
                               /* State CDATA - entry_action empty */
                            this->curState = ST_cDATA;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATA6, ST_eFail3, "Transition from CDATA6 to E_FAIL3 on putChar, default transition" );
                               /* State CDATA6 - exit_action empty */
                               /* Transition from CDATA6 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATAE1:    /* CDATAE1 */
                        if (ch==L']') /* Guard: [']'] */
                           {
                            this->logEvent( 0, ST_cDATAE1, ST_cDATAE2, "Transition from CDATAE1 to CDATAE2 on putChar, guard: ']'" );
                               /* State CDATAE1 - exit_action empty */
                               /* Transition from CDATAE1 to CDATAE2 actions */
                               /* State CDATAE2 - entry_action empty */
                            this->curState = ST_cDATAE2;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATAE1, ST_cDATA, "Transition from CDATAE1 to CDATA on putChar, default transition" );
                               /* State CDATAE1 - exit_action empty */
                               /* Transition from CDATAE1 to CDATA actions */
                               this->logEvent( 0x0202, ST_cDATAE1, ST_cDATA, "storeChar(']');storeChar(GUARDVAR)" );
                               { storeChar(']');storeChar(ch); }
                               /* State CDATA - entry_action empty */
                            this->curState = ST_cDATA;
                           }
                     break;
                case ST_cDATAE2:    /* CDATAE2 */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_cDATAE2, ST_waitTagStart, "Transition from CDATAE2 to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State CDATAE2 - exit_action empty */
                               /* Transition from CDATAE2 to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_cDATAE2, ST_waitTagStart, "callCdata();" );
                               { callCdata(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cDATAE2, ST_cDATA, "Transition from CDATAE2 to CDATA on putChar, default transition" );
                               /* State CDATAE2 - exit_action empty */
                               /* Transition from CDATAE2 to CDATA actions */
                               this->logEvent( 0x0202, ST_cDATAE2, ST_cDATA, "storeChar(']');storeChar(']');storeChar(GUARDVAR)" );
                               { storeChar(']');storeChar(']');storeChar(ch); }
                               /* State CDATA - entry_action empty */
                            this->curState = ST_cDATA;
                           }
                     break;
                case ST_cOMMENT:    /* COMMENT */
                        if (ch==L'-') /* Guard: ['-'] */
                           {
                            this->logEvent( 0, ST_cOMMENT, ST_cOMMENTE1, "Transition from COMMENT to COMMENTE1 on putChar, guard: '-'" );
                               /* State COMMENT - exit_action empty */
                               /* Transition from COMMENT to COMMENTE1 actions */
                               /* State COMMENTE1 - entry_action empty */
                            this->curState = ST_cOMMENTE1;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cOMMENT, ST_cOMMENT, "Transition from COMMENT to COMMENT on putChar, default transition" );
                               /* State COMMENT - exit_action empty */
                               /* Transition from COMMENT to COMMENT actions */
                               this->logEvent( 0x0202, ST_cOMMENT, ST_cOMMENT, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State COMMENT - entry_action empty */
                            this->curState = ST_cOMMENT;
                           }
                     break;
                case ST_cOMMENT1:    /* COMMENT1 */
                        if ((isLatinAlpha(ch))) /* Guard: [(isLatinAlpha(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_cOMMENT1, ST_readDtd, "Transition from COMMENT1 to READ_DTD on putChar, guard: (isLatinAlpha(GUARDVAR))" );
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to READ_DTD actions */
                               this->logEvent( 0x0202, ST_cOMMENT1, ST_readDtd, "storeChar(GUARDVAR); lvl=0;" );
                               { storeChar(ch); lvl=0; }
                               /* State READ_DTD - entry_action empty */
                            this->curState = ST_readDtd;
                           }
                        else if (ch==L'[') /* Guard: ['['] */
                           {
                            this->logEvent( 0, ST_cOMMENT1, ST_cDATA1, "Transition from COMMENT1 to CDATA1 on putChar, guard: '['" );
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to CDATA1 actions */
                               /* State CDATA1 - entry_action empty */
                            this->curState = ST_cDATA1;
                           }
                        else if (ch==L'-') /* Guard: ['-'] */
                           {
                            this->logEvent( 0, ST_cOMMENT1, ST_cOMMENT2, "Transition from COMMENT1 to COMMENT2 on putChar, guard: '-'" );
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to COMMENT2 actions */
                               /* State COMMENT2 - entry_action empty */
                            this->curState = ST_cOMMENT2;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cOMMENT1, ST_eFail3, "Transition from COMMENT1 to E_FAIL3 on putChar, default transition" );
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENT2:    /* COMMENT2 */
                        if (ch==L'-') /* Guard: ['-'] */
                           {
                            this->logEvent( 0, ST_cOMMENT2, ST_cOMMENT, "Transition from COMMENT2 to COMMENT on putChar, guard: '-'" );
                               /* State COMMENT2 - exit_action empty */
                               /* Transition from COMMENT2 to COMMENT actions */
                               /* State COMMENT - entry_action empty */
                            this->curState = ST_cOMMENT;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cOMMENT2, ST_eFail3, "Transition from COMMENT2 to E_FAIL3 on putChar, default transition" );
                               /* State COMMENT2 - exit_action empty */
                               /* Transition from COMMENT2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENTE1:    /* COMMENTE1 */
                        if (ch==L'-') /* Guard: ['-'] */
                           {
                            this->logEvent( 0, ST_cOMMENTE1, ST_cOMMENTE2, "Transition from COMMENTE1 to COMMENTE2 on putChar, guard: '-'" );
                               /* State COMMENTE1 - exit_action empty */
                               /* Transition from COMMENTE1 to COMMENTE2 actions */
                               /* State COMMENTE2 - entry_action empty */
                            this->curState = ST_cOMMENTE2;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cOMMENTE1, ST_cOMMENT, "Transition from COMMENTE1 to COMMENT on putChar, default transition" );
                               /* State COMMENTE1 - exit_action empty */
                               /* Transition from COMMENTE1 to COMMENT actions */
                               this->logEvent( 0x0202, ST_cOMMENTE1, ST_cOMMENT, "storeChar('-');storeChar(GUARDVAR)" );
                               { storeChar('-');storeChar(ch); }
                               /* State COMMENT - entry_action empty */
                            this->curState = ST_cOMMENT;
                           }
                     break;
                case ST_cOMMENTE2:    /* COMMENTE2 */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_cOMMENTE2, ST_waitTagStart, "Transition from COMMENTE2 to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State COMMENTE2 - exit_action empty */
                               /* Transition from COMMENTE2 to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_cOMMENTE2, ST_waitTagStart, "callComment();" );
                               { callComment(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                            this->logEvent( 0, ST_cOMMENTE2, ST_cOMMENT, "Transition from COMMENTE2 to COMMENT on putChar, default transition" );
                               /* State COMMENTE2 - exit_action empty */
                               /* Transition from COMMENTE2 to COMMENT actions */
                               this->logEvent( 0x0202, ST_cOMMENTE2, ST_cOMMENT, "storeChar('-');storeChar('-');storeChar(GUARDVAR)" );
                               { storeChar('-');storeChar('-');storeChar(ch); }
                               /* State COMMENT - entry_action empty */
                            this->curState = ST_cOMMENT;
                           }
                     break;
                case ST_readAttrName:    /* READ_ATTR_NAME */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_readAttrName, ST_waitEq, "Transition from READ_ATTR_NAME to WAIT_EQ on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to WAIT_EQ actions */
                               this->logEvent( 0x0202, ST_readAttrName, ST_waitEq, "callAttr()" );
                               { callAttr(); }
                               /* State WAIT_EQ - entry_action empty */
                            this->curState = ST_waitEq;
                           }
                        else if ((isAttrChar(ch))) /* Guard: [(isAttrChar(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_readAttrName, ST_readAttrName, "Transition from READ_ATTR_NAME to READ_ATTR_NAME on putChar, guard: (isAttrChar(GUARDVAR))" );
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to READ_ATTR_NAME actions */
                               this->logEvent( 0x0202, ST_readAttrName, ST_readAttrName, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_ATTR_NAME - entry_action empty */
                            this->curState = ST_readAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_readAttrName, ST_waitTagStart, "Transition from READ_ATTR_NAME to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_readAttrName, ST_waitTagStart, "callAttr(); attrEnd();" );
                               { callAttr(); attrEnd(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'=') /* Guard: ['='] */
                           {
                            this->logEvent( 0, ST_readAttrName, ST_waitAttrVal, "Transition from READ_ATTR_NAME to WAIT_ATTR_VAL on putChar, guard: '='" );
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to WAIT_ATTR_VAL actions */
                               this->logEvent( 0x0202, ST_readAttrName, ST_waitAttrVal, "callAttr()" );
                               { callAttr(); }
                               /* State WAIT_ATTR_VAL - entry_action empty */
                            this->curState = ST_waitAttrVal;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                            this->logEvent( 0, ST_readAttrName, ST_tagAloneEnd2, "Transition from READ_ATTR_NAME to TAG_ALONE_END2 on putChar, guard: '/'" );
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to TAG_ALONE_END2 actions */
                               this->logEvent( 0x0202, ST_readAttrName, ST_tagAloneEnd2, "callAttr()" );
                               { callAttr(); }
                               /* State TAG_ALONE_END2 - entry_action empty */
                            this->curState = ST_tagAloneEnd2;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readAttrName, ST_eFail, "Transition from READ_ATTR_NAME to E_FAIL on putChar, default transition" );
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readAvapos:    /* READ_AVAPOS */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                            this->logEvent( 0, ST_readAvapos, ST_waitNextAttrName, "Transition from READ_AVAPOS to WAIT_NEXT_ATTR_NAME on putChar, guard: '\''" );
                               /* State READ_AVAPOS - exit_action empty */
                               /* Transition from READ_AVAPOS to WAIT_NEXT_ATTR_NAME actions */
                               this->logEvent( 0x0202, ST_readAvapos, ST_waitNextAttrName, "callAttrVal()" );
                               { callAttrVal(); }
                               /* State WAIT_NEXT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitNextAttrName;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readAvapos, ST_readAvapos, "Transition from READ_AVAPOS to READ_AVAPOS on putChar, default transition" );
                               /* State READ_AVAPOS - exit_action empty */
                               /* Transition from READ_AVAPOS to READ_AVAPOS actions */
                               this->logEvent( 0x0202, ST_readAvapos, ST_readAvapos, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_AVAPOS - entry_action empty */
                            this->curState = ST_readAvapos;
                           }
                     break;
                case ST_readAvquot:    /* READ_AVQUOT */
                        if (ch==L'\"') /* Guard: ['\"'] */
                           {
                            this->logEvent( 0, ST_readAvquot, ST_waitNextAttrName, "Transition from READ_AVQUOT to WAIT_NEXT_ATTR_NAME on putChar, guard: '\"'" );
                               /* State READ_AVQUOT - exit_action empty */
                               /* Transition from READ_AVQUOT to WAIT_NEXT_ATTR_NAME actions */
                               this->logEvent( 0x0202, ST_readAvquot, ST_waitNextAttrName, "callAttrVal()" );
                               { callAttrVal(); }
                               /* State WAIT_NEXT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitNextAttrName;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readAvquot, ST_readAvquot, "Transition from READ_AVQUOT to READ_AVQUOT on putChar, default transition" );
                               /* State READ_AVQUOT - exit_action empty */
                               /* Transition from READ_AVQUOT to READ_AVQUOT actions */
                               this->logEvent( 0x0202, ST_readAvquot, ST_readAvquot, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_AVQUOT - entry_action empty */
                            this->curState = ST_readAvquot;
                           }
                     break;
                case ST_readAvUnquot:    /* READ_AV_UNQUOT */
                        if ((((!isSpace(ch))) && (ch!='/')) && (ch!='>')) /* Guard: [(!isSpace(GUARDVAR)),(GUARDVAR!='/'),(GUARDVAR!='>')] */
                           {
                            this->logEvent( 0, ST_readAvUnquot, ST_readAvUnquot, "Transition from READ_AV_UNQUOT to READ_AV_UNQUOT on putChar, guard: (!isSpace(GUARDVAR)),(GUARDVAR!='/'),(GUARDVAR!='>')" );
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to READ_AV_UNQUOT actions */
                               this->logEvent( 0x0202, ST_readAvUnquot, ST_readAvUnquot, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_AV_UNQUOT - entry_action empty */
                            this->curState = ST_readAvUnquot;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_readAvUnquot, ST_waitTagStart, "Transition from READ_AV_UNQUOT to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_readAvUnquot, ST_waitTagStart, "callAttrVal(); attrEnd();endElem()" );
                               { callAttrVal(); attrEnd();endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                            this->logEvent( 0, ST_readAvUnquot, ST_tagAloneEnd2, "Transition from READ_AV_UNQUOT to TAG_ALONE_END2 on putChar, guard: '/'" );
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to TAG_ALONE_END2 actions */
                               this->logEvent( 0x0202, ST_readAvUnquot, ST_tagAloneEnd2, "callAttrVal()" );
                               { callAttrVal(); }
                               /* State TAG_ALONE_END2 - entry_action empty */
                            this->curState = ST_tagAloneEnd2;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readAvUnquot, ST_waitNextAttrName, "Transition from READ_AV_UNQUOT to WAIT_NEXT_ATTR_NAME on putChar, default transition" );
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to WAIT_NEXT_ATTR_NAME actions */
                               this->logEvent( 0x0202, ST_readAvUnquot, ST_waitNextAttrName, "callAttrVal()" );
                               { callAttrVal(); }
                               /* State WAIT_NEXT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitNextAttrName;
                           }
                     break;
                case ST_readDtd:    /* READ_DTD */
                        if ((ch==L'>') && (lvl)) /* Guard: ['>', (lvl)] */
                           {
                            this->logEvent( 0, ST_readDtd, ST_readDtd, "Transition from READ_DTD to READ_DTD on putChar, guard: '>', (lvl)" );
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to READ_DTD actions */
                               this->logEvent( 0x0202, ST_readDtd, ST_readDtd, "storeChar(GUARDVAR); --lvl;" );
                               { storeChar(ch); --lvl; }
                               /* State READ_DTD - entry_action empty */
                            this->curState = ST_readDtd;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_readDtd, ST_waitTagStart, "Transition from READ_DTD to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_readDtd, ST_waitTagStart, "callDTD()" );
                               { callDTD(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'<') /* Guard: ['<'] */
                           {
                            this->logEvent( 0, ST_readDtd, ST_readDtd, "Transition from READ_DTD to READ_DTD on putChar, guard: '<'" );
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to READ_DTD actions */
                               this->logEvent( 0x0202, ST_readDtd, ST_readDtd, "storeChar(GUARDVAR); ++lvl;" );
                               { storeChar(ch); ++lvl; }
                               /* State READ_DTD - entry_action empty */
                            this->curState = ST_readDtd;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readDtd, ST_readDtd, "Transition from READ_DTD to READ_DTD on putChar, default transition" );
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to READ_DTD actions */
                               this->logEvent( 0x0202, ST_readDtd, ST_readDtd, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_DTD - entry_action empty */
                            this->curState = ST_readDtd;
                           }
                     break;
                case ST_readPi:    /* READ_PI */
                        if (ch==L'?') /* Guard: ['?'] */
                           {
                            this->logEvent( 0, ST_readPi, ST_waitPiEnd, "Transition from READ_PI to WAIT_PI_END on putChar, guard: '?'" );
                               /* State READ_PI - exit_action empty */
                               /* Transition from READ_PI to WAIT_PI_END actions */
                               /* State WAIT_PI_END - entry_action empty */
                            this->curState = ST_waitPiEnd;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readPi, ST_readPi, "Transition from READ_PI to READ_PI on putChar, default transition" );
                               /* State READ_PI - exit_action empty */
                               /* Transition from READ_PI to READ_PI actions */
                               this->logEvent( 0x0202, ST_readPi, ST_readPi, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_PI - entry_action empty */
                            this->curState = ST_readPi;
                           }
                     break;
                case ST_readTagName:    /* READ_TAG_NAME */
                        if ((isTagChar(ch))) /* Guard: [(isTagChar(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_readTagName, ST_readTagName, "Transition from READ_TAG_NAME to READ_TAG_NAME on putChar, guard: (isTagChar(GUARDVAR))" );
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to READ_TAG_NAME actions */
                               this->logEvent( 0x0202, ST_readTagName, ST_readTagName, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_TAG_NAME - entry_action empty */
                            this->curState = ST_readTagName;
                           }
                        else if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_readTagName, ST_waitAttrName, "Transition from READ_TAG_NAME to WAIT_ATTR_NAME on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to WAIT_ATTR_NAME actions */
                               /* State WAIT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_readTagName, ST_waitTagStart, "Transition from READ_TAG_NAME to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_readTagName, ST_waitTagStart, "startElem(); attrEnd()" );
                               { startElem(); attrEnd(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                            this->logEvent( 0, ST_readTagName, ST_tagAloneEnd, "Transition from READ_TAG_NAME to TAG_ALONE_END on putChar, guard: '/'" );
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to TAG_ALONE_END actions */
                               /* State TAG_ALONE_END - entry_action empty */
                            this->curState = ST_tagAloneEnd;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readTagName, ST_eFail, "Transition from READ_TAG_NAME to E_FAIL on putChar, default transition" );
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagNameEnd:    /* READ_TAG_NAME_END */
                        if ((isTagChar(ch))) /* Guard: [(isTagChar(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_readTagNameEnd, ST_readTagNameEnd, "Transition from READ_TAG_NAME_END to READ_TAG_NAME_END on putChar, guard: (isTagChar(GUARDVAR))" );
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to READ_TAG_NAME_END actions */
                               this->logEvent( 0x0202, ST_readTagNameEnd, ST_readTagNameEnd, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_TAG_NAME_END - entry_action empty */
                            this->curState = ST_readTagNameEnd;
                           }
                        else if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_readTagNameEnd, ST_readTagNameEndSpaces, "Transition from READ_TAG_NAME_END to READ_TAG_NAME_END_SPACES on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to READ_TAG_NAME_END_SPACES actions */
                               /* State READ_TAG_NAME_END_SPACES - entry_action empty */
                            this->curState = ST_readTagNameEndSpaces;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_readTagNameEnd, ST_waitTagStart, "Transition from READ_TAG_NAME_END to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_readTagNameEnd, ST_waitTagStart, "endElem()" );
                               { endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readTagNameEnd, ST_eFail, "Transition from READ_TAG_NAME_END to E_FAIL on putChar, default transition" );
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagNameEndSpaces:    /* READ_TAG_NAME_END_SPACES */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_readTagNameEndSpaces, ST_readTagNameEndSpaces, "Transition from READ_TAG_NAME_END_SPACES to READ_TAG_NAME_END_SPACES on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State READ_TAG_NAME_END_SPACES - exit_action empty */
                               /* Transition from READ_TAG_NAME_END_SPACES to READ_TAG_NAME_END_SPACES actions */
                               /* State READ_TAG_NAME_END_SPACES - entry_action empty */
                            this->curState = ST_readTagNameEndSpaces;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_readTagNameEndSpaces, ST_waitTagStart, "Transition from READ_TAG_NAME_END_SPACES to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State READ_TAG_NAME_END_SPACES - exit_action empty */
                               /* Transition from READ_TAG_NAME_END_SPACES to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_readTagNameEndSpaces, ST_waitTagStart, "endElem()" );
                               { endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                            this->logEvent( 0, ST_readTagNameEndSpaces, ST_eFail, "Transition from READ_TAG_NAME_END_SPACES to E_FAIL on putChar, default transition" );
                               /* State READ_TAG_NAME_END_SPACES - exit_action empty */
                               /* Transition from READ_TAG_NAME_END_SPACES to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_tagAloneEnd:    /* TAG_ALONE_END */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_tagAloneEnd, ST_waitTagStart, "Transition from TAG_ALONE_END to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State TAG_ALONE_END - exit_action empty */
                               /* Transition from TAG_ALONE_END to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_tagAloneEnd, ST_waitTagStart, "startElem();attrEnd();endElem()" );
                               { startElem();attrEnd();endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                            this->logEvent( 0, ST_tagAloneEnd, ST_eFail, "Transition from TAG_ALONE_END to E_FAIL on putChar, default transition" );
                               /* State TAG_ALONE_END - exit_action empty */
                               /* Transition from TAG_ALONE_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_tagAloneEnd2:    /* TAG_ALONE_END2 */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_tagAloneEnd2, ST_waitTagStart, "Transition from TAG_ALONE_END2 to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State TAG_ALONE_END2 - exit_action empty */
                               /* Transition from TAG_ALONE_END2 to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_tagAloneEnd2, ST_waitTagStart, "attrEnd();endElem();" );
                               { attrEnd();endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                            this->logEvent( 0, ST_tagAloneEnd2, ST_eFail, "Transition from TAG_ALONE_END2 to E_FAIL on putChar, default transition" );
                               /* State TAG_ALONE_END2 - exit_action empty */
                               /* Transition from TAG_ALONE_END2 to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitAttrName:    /* WAIT_ATTR_NAME */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitAttrName, ST_waitAttrName, "Transition from WAIT_ATTR_NAME to WAIT_ATTR_NAME on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to WAIT_ATTR_NAME actions */
                               /* State WAIT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitAttrName;
                           }
                        else if ((isAttrStartChar(ch))) /* Guard: [(isAttrStartChar(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitAttrName, ST_readAttrName, "Transition from WAIT_ATTR_NAME to READ_ATTR_NAME on putChar, guard: (isAttrStartChar(GUARDVAR))" );
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to READ_ATTR_NAME actions */
                               this->logEvent( 0x0202, ST_waitAttrName, ST_readAttrName, "startElem(); storeChar(GUARDVAR)" );
                               { startElem(); storeChar(ch); }
                               /* State READ_ATTR_NAME - entry_action empty */
                            this->curState = ST_readAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_waitAttrName, ST_waitTagStart, "Transition from WAIT_ATTR_NAME to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_waitAttrName, ST_waitTagStart, "startElem()" );
                               { startElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                            this->logEvent( 0, ST_waitAttrName, ST_tagAloneEnd, "Transition from WAIT_ATTR_NAME to TAG_ALONE_END on putChar, guard: '/'" );
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to TAG_ALONE_END actions */
                               /* State TAG_ALONE_END - entry_action empty */
                            this->curState = ST_tagAloneEnd;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitAttrName, ST_eFail, "Transition from WAIT_ATTR_NAME to E_FAIL on putChar, default transition" );
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitAttrVal:    /* WAIT_ATTR_VAL */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitAttrVal, ST_waitAttrVal, "Transition from WAIT_ATTR_VAL to WAIT_ATTR_VAL on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to WAIT_ATTR_VAL actions */
                               /* State WAIT_ATTR_VAL - entry_action empty */
                            this->curState = ST_waitAttrVal;
                           }
                        else if ((((((!isSpace(ch))) && (ch!='\'')) && (ch!='\"')) && (ch!='/')) && (ch!='>')) /* Guard: [(!isSpace(GUARDVAR)),(GUARDVAR!='\''),(GUARDVAR!='\"'),(GUARDVAR!='/'),(GUARDVAR!='>')] */
                           {
                            this->logEvent( 0, ST_waitAttrVal, ST_readAvUnquot, "Transition from WAIT_ATTR_VAL to READ_AV_UNQUOT on putChar, guard: (!isSpace(GUARDVAR)),(GUARDVAR!='\''),(GUARDVAR!='\"'),(GUARDVAR!='/'),(GUARDVAR!='>')" );
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to READ_AV_UNQUOT actions */
                               this->logEvent( 0x0202, ST_waitAttrVal, ST_readAvUnquot, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_AV_UNQUOT - entry_action empty */
                            this->curState = ST_readAvUnquot;
                           }
                        else if (ch==L'\'') /* Guard: ['\''] */
                           {
                            this->logEvent( 0, ST_waitAttrVal, ST_readAvapos, "Transition from WAIT_ATTR_VAL to READ_AVAPOS on putChar, guard: '\''" );
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to READ_AVAPOS actions */
                               /* State READ_AVAPOS - entry_action empty */
                            this->curState = ST_readAvapos;
                           }
                        else if (ch==L'\"') /* Guard: ['\"'] */
                           {
                            this->logEvent( 0, ST_waitAttrVal, ST_readAvquot, "Transition from WAIT_ATTR_VAL to READ_AVQUOT on putChar, guard: '\"'" );
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to READ_AVQUOT actions */
                               /* State READ_AVQUOT - entry_action empty */
                            this->curState = ST_readAvquot;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitAttrVal, ST_eFail, "Transition from WAIT_ATTR_VAL to E_FAIL on putChar, default transition" );
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitEq:    /* WAIT_EQ */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitEq, ST_waitEq, "Transition from WAIT_EQ to WAIT_EQ on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to WAIT_EQ actions */
                               /* State WAIT_EQ - entry_action empty */
                            this->curState = ST_waitEq;
                           }
                        else if ((isAttrStartChar(ch))) /* Guard: [(isAttrStartChar(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitEq, ST_waitAttrName, "Transition from WAIT_EQ to WAIT_ATTR_NAME on putChar, guard: (isAttrStartChar(GUARDVAR))" );
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to WAIT_ATTR_NAME actions */
                               this->logEvent( 0x0202, ST_waitEq, ST_waitAttrName, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State WAIT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_waitEq, ST_waitTagStart, "Transition from WAIT_EQ to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_waitEq, ST_waitTagStart, "attrEnd()" );
                               { attrEnd(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'=') /* Guard: ['='] */
                           {
                            this->logEvent( 0, ST_waitEq, ST_waitAttrVal, "Transition from WAIT_EQ to WAIT_ATTR_VAL on putChar, guard: '='" );
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to WAIT_ATTR_VAL actions */
                               /* State WAIT_ATTR_VAL - entry_action empty */
                            this->curState = ST_waitAttrVal;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                            this->logEvent( 0, ST_waitEq, ST_tagAloneEnd2, "Transition from WAIT_EQ to TAG_ALONE_END2 on putChar, guard: '/'" );
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to TAG_ALONE_END2 actions */
                               /* State TAG_ALONE_END2 - entry_action empty */
                            this->curState = ST_tagAloneEnd2;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitEq, ST_eFail, "Transition from WAIT_EQ to E_FAIL on putChar, default transition" );
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitNextAttrName:    /* WAIT_NEXT_ATTR_NAME */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitNextAttrName, ST_waitNextAttrName, "Transition from WAIT_NEXT_ATTR_NAME to WAIT_NEXT_ATTR_NAME on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to WAIT_NEXT_ATTR_NAME actions */
                               /* State WAIT_NEXT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitNextAttrName;
                           }
                        else if ((isAttrStartChar(ch))) /* Guard: [(isAttrStartChar(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitNextAttrName, ST_readAttrName, "Transition from WAIT_NEXT_ATTR_NAME to READ_ATTR_NAME on putChar, guard: (isAttrStartChar(GUARDVAR))" );
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to READ_ATTR_NAME actions */
                               this->logEvent( 0x0202, ST_waitNextAttrName, ST_readAttrName, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_ATTR_NAME - entry_action empty */
                            this->curState = ST_readAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_waitNextAttrName, ST_waitTagStart, "Transition from WAIT_NEXT_ATTR_NAME to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_waitNextAttrName, ST_waitTagStart, "attrEnd()" );
                               { attrEnd(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                            this->logEvent( 0, ST_waitNextAttrName, ST_tagAloneEnd2, "Transition from WAIT_NEXT_ATTR_NAME to TAG_ALONE_END2 on putChar, guard: '/'" );
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to TAG_ALONE_END2 actions */
                               /* State TAG_ALONE_END2 - entry_action empty */
                            this->curState = ST_tagAloneEnd2;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitNextAttrName, ST_eFail2, "Transition from WAIT_NEXT_ATTR_NAME to E_FAIL2 on putChar, default transition" );
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_waitPiEnd:    /* WAIT_PI_END */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                            this->logEvent( 0, ST_waitPiEnd, ST_waitTagStart, "Transition from WAIT_PI_END to WAIT_TAG_START on putChar, guard: '>'" );
                               /* State WAIT_PI_END - exit_action empty */
                               /* Transition from WAIT_PI_END to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_waitPiEnd, ST_waitTagStart, "callPi(); clrBuf();" );
                               { callPi(); clrBuf(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitPiEnd, ST_eFail, "Transition from WAIT_PI_END to E_FAIL on putChar, default transition" );
                               /* State WAIT_PI_END - exit_action empty */
                               /* Transition from WAIT_PI_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagName:    /* WAIT_TAG_NAME */
                        if ((isTagStartChar(ch))) /* Guard: [(isTagStartChar(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitTagName, ST_readTagName, "Transition from WAIT_TAG_NAME to READ_TAG_NAME on putChar, guard: (isTagStartChar(GUARDVAR))" );
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to READ_TAG_NAME actions */
                               this->logEvent( 0x0202, ST_waitTagName, ST_readTagName, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_TAG_NAME - entry_action empty */
                            this->curState = ST_readTagName;
                           }
                        else if (ch==L'?') /* Guard: ['?'] */
                           {
                            this->logEvent( 0, ST_waitTagName, ST_readPi, "Transition from WAIT_TAG_NAME to READ_PI on putChar, guard: '?'" );
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to READ_PI actions */
                               /* State READ_PI - entry_action empty */
                            this->curState = ST_readPi;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                            this->logEvent( 0, ST_waitTagName, ST_waitTagNameEnd, "Transition from WAIT_TAG_NAME to WAIT_TAG_NAME_END on putChar, guard: '/'" );
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to WAIT_TAG_NAME_END actions */
                               /* State WAIT_TAG_NAME_END - entry_action empty */
                            this->curState = ST_waitTagNameEnd;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                            this->logEvent( 0, ST_waitTagName, ST_cOMMENT1, "Transition from WAIT_TAG_NAME to COMMENT1 on putChar, guard: '!'" );
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to COMMENT1 actions */
                               /* State COMMENT1 - entry_action empty */
                            this->curState = ST_cOMMENT1;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitTagName, ST_eFail, "Transition from WAIT_TAG_NAME to E_FAIL on putChar, default transition" );
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagNameEnd:    /* WAIT_TAG_NAME_END */
                        if ((isTagStartChar(ch))) /* Guard: [(isTagStartChar(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitTagNameEnd, ST_readTagNameEnd, "Transition from WAIT_TAG_NAME_END to READ_TAG_NAME_END on putChar, guard: (isTagStartChar(GUARDVAR))" );
                               /* State WAIT_TAG_NAME_END - exit_action empty */
                               /* Transition from WAIT_TAG_NAME_END to READ_TAG_NAME_END actions */
                               this->logEvent( 0x0202, ST_waitTagNameEnd, ST_readTagNameEnd, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State READ_TAG_NAME_END - entry_action empty */
                            this->curState = ST_readTagNameEnd;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitTagNameEnd, ST_eFail, "Transition from WAIT_TAG_NAME_END to E_FAIL on putChar, default transition" );
                               /* State WAIT_TAG_NAME_END - exit_action empty */
                               /* Transition from WAIT_TAG_NAME_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagStart:    /* WAIT_TAG_START */
                        if (ch==L'<') /* Guard: ['<'] */
                           {
                            this->logEvent( 0, ST_waitTagStart, ST_waitTagName, "Transition from WAIT_TAG_START to WAIT_TAG_NAME on putChar, guard: '<'" );
                               /* State WAIT_TAG_START - exit_action empty */
                               /* Transition from WAIT_TAG_START to WAIT_TAG_NAME actions */
                               this->logEvent( 0x0202, ST_waitTagStart, ST_waitTagName, "callText()" );
                               { callText(); }
                               /* State WAIT_TAG_NAME - entry_action empty */
                            this->curState = ST_waitTagName;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitTagStart, ST_waitTagStart, "Transition from WAIT_TAG_START to WAIT_TAG_START on putChar, default transition" );
                               /* State WAIT_TAG_START - exit_action empty */
                               /* Transition from WAIT_TAG_START to WAIT_TAG_START actions */
                               this->logEvent( 0x0202, ST_waitTagStart, ST_waitTagStart, "storeChar(GUARDVAR)" );
                               { storeChar(ch); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                     break;
                case ST_waitTagStart0:    /* WAIT_TAG_START0 */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                            this->logEvent( 0, ST_waitTagStart0, ST_waitTagStart0, "Transition from WAIT_TAG_START0 to WAIT_TAG_START0 on putChar, guard: (isSpace(GUARDVAR))" );
                               /* State WAIT_TAG_START0 - exit_action empty */
                               /* Transition from WAIT_TAG_START0 to WAIT_TAG_START0 actions */
                               /* State WAIT_TAG_START0 - entry_action empty */
                            this->curState = ST_waitTagStart0;
                           }
                        else if (ch==L'<') /* Guard: ['<'] */
                           {
                            this->logEvent( 0, ST_waitTagStart0, ST_waitTagName, "Transition from WAIT_TAG_START0 to WAIT_TAG_NAME on putChar, guard: '<'" );
                               /* State WAIT_TAG_START0 - exit_action empty */
                               /* Transition from WAIT_TAG_START0 to WAIT_TAG_NAME actions */
                               this->logEvent( 0x0202, ST_waitTagStart0, ST_waitTagName, "startDoc();" );
                               { startDoc(); }
                               /* State WAIT_TAG_NAME - entry_action empty */
                            this->curState = ST_waitTagName;
                           }
                        else
                           {
                            this->logEvent( 0, ST_waitTagStart0, ST_eFail, "Transition from WAIT_TAG_START0 to E_FAIL on putChar, default transition" );
                               /* State WAIT_TAG_START0 - exit_action empty */
                               /* Transition from WAIT_TAG_START0 to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
               };

           }

    public:     
        void
        eod
           ( 
           )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_cDATA:    /* CDATA */
                                       {
                            this->logEvent( 0, ST_cDATA, ST_eFail3, "Transition from CDATA to E_FAIL3 on eod, default transition" );
                               /* State CDATA - exit_action empty */
                               /* Transition from CDATA to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA1:    /* CDATA1 */
                                       {
                            this->logEvent( 0, ST_cDATA1, ST_eFail3, "Transition from CDATA1 to E_FAIL3 on eod, default transition" );
                               /* State CDATA1 - exit_action empty */
                               /* Transition from CDATA1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA2:    /* CDATA2 */
                                       {
                            this->logEvent( 0, ST_cDATA2, ST_eFail3, "Transition from CDATA2 to E_FAIL3 on eod, default transition" );
                               /* State CDATA2 - exit_action empty */
                               /* Transition from CDATA2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA3:    /* CDATA3 */
                                       {
                            this->logEvent( 0, ST_cDATA3, ST_eFail3, "Transition from CDATA3 to E_FAIL3 on eod, default transition" );
                               /* State CDATA3 - exit_action empty */
                               /* Transition from CDATA3 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA4:    /* CDATA4 */
                                       {
                            this->logEvent( 0, ST_cDATA4, ST_eFail3, "Transition from CDATA4 to E_FAIL3 on eod, default transition" );
                               /* State CDATA4 - exit_action empty */
                               /* Transition from CDATA4 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA5:    /* CDATA5 */
                                       {
                            this->logEvent( 0, ST_cDATA5, ST_eFail3, "Transition from CDATA5 to E_FAIL3 on eod, default transition" );
                               /* State CDATA5 - exit_action empty */
                               /* Transition from CDATA5 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA6:    /* CDATA6 */
                                       {
                            this->logEvent( 0, ST_cDATA6, ST_eFail3, "Transition from CDATA6 to E_FAIL3 on eod, default transition" );
                               /* State CDATA6 - exit_action empty */
                               /* Transition from CDATA6 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATAE1:    /* CDATAE1 */
                                       {
                            this->logEvent( 0, ST_cDATAE1, ST_eFail3, "Transition from CDATAE1 to E_FAIL3 on eod, default transition" );
                               /* State CDATAE1 - exit_action empty */
                               /* Transition from CDATAE1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATAE2:    /* CDATAE2 */
                                       {
                            this->logEvent( 0, ST_cDATAE2, ST_eFail3, "Transition from CDATAE2 to E_FAIL3 on eod, default transition" );
                               /* State CDATAE2 - exit_action empty */
                               /* Transition from CDATAE2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENT:    /* COMMENT */
                                       {
                            this->logEvent( 0, ST_cOMMENT, ST_eFail3, "Transition from COMMENT to E_FAIL3 on eod, default transition" );
                               /* State COMMENT - exit_action empty */
                               /* Transition from COMMENT to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENT1:    /* COMMENT1 */
                                       {
                            this->logEvent( 0, ST_cOMMENT1, ST_eFail3, "Transition from COMMENT1 to E_FAIL3 on eod, default transition" );
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENT2:    /* COMMENT2 */
                                       {
                            this->logEvent( 0, ST_cOMMENT2, ST_eFail3, "Transition from COMMENT2 to E_FAIL3 on eod, default transition" );
                               /* State COMMENT2 - exit_action empty */
                               /* Transition from COMMENT2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENTE1:    /* COMMENTE1 */
                                       {
                            this->logEvent( 0, ST_cOMMENTE1, ST_eFail3, "Transition from COMMENTE1 to E_FAIL3 on eod, default transition" );
                               /* State COMMENTE1 - exit_action empty */
                               /* Transition from COMMENTE1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENTE2:    /* COMMENTE2 */
                                       {
                            this->logEvent( 0, ST_cOMMENTE2, ST_eFail3, "Transition from COMMENTE2 to E_FAIL3 on eod, default transition" );
                               /* State COMMENTE2 - exit_action empty */
                               /* Transition from COMMENTE2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_readAttrName:    /* READ_ATTR_NAME */
                                       {
                            this->logEvent( 0, ST_readAttrName, ST_eFail, "Transition from READ_ATTR_NAME to E_FAIL on eod, default transition" );
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readAvapos:    /* READ_AVAPOS */
                                       {
                            this->logEvent( 0, ST_readAvapos, ST_eFail2, "Transition from READ_AVAPOS to E_FAIL2 on eod, default transition" );
                               /* State READ_AVAPOS - exit_action empty */
                               /* Transition from READ_AVAPOS to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_readAvquot:    /* READ_AVQUOT */
                                       {
                            this->logEvent( 0, ST_readAvquot, ST_eFail2, "Transition from READ_AVQUOT to E_FAIL2 on eod, default transition" );
                               /* State READ_AVQUOT - exit_action empty */
                               /* Transition from READ_AVQUOT to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_readAvUnquot:    /* READ_AV_UNQUOT */
                                       {
                            this->logEvent( 0, ST_readAvUnquot, ST_eFail2, "Transition from READ_AV_UNQUOT to E_FAIL2 on eod, default transition" );
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_readDtd:    /* READ_DTD */
                                       {
                            this->logEvent( 0, ST_readDtd, ST_eFail3, "Transition from READ_DTD to E_FAIL3 on eod, default transition" );
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_readPi:    /* READ_PI */
                                       {
                            this->logEvent( 0, ST_readPi, ST_eFail, "Transition from READ_PI to E_FAIL on eod, default transition" );
                               /* State READ_PI - exit_action empty */
                               /* Transition from READ_PI to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagName:    /* READ_TAG_NAME */
                                       {
                            this->logEvent( 0, ST_readTagName, ST_eFail, "Transition from READ_TAG_NAME to E_FAIL on eod, default transition" );
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagNameEnd:    /* READ_TAG_NAME_END */
                                       {
                            this->logEvent( 0, ST_readTagNameEnd, ST_eFail, "Transition from READ_TAG_NAME_END to E_FAIL on eod, default transition" );
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagNameEndSpaces:    /* READ_TAG_NAME_END_SPACES */
                                       {
                            this->logEvent( 0, ST_readTagNameEndSpaces, ST_eFail, "Transition from READ_TAG_NAME_END_SPACES to E_FAIL on eod, default transition" );
                               /* State READ_TAG_NAME_END_SPACES - exit_action empty */
                               /* Transition from READ_TAG_NAME_END_SPACES to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_tagAloneEnd:    /* TAG_ALONE_END */
                                       {
                            this->logEvent( 0, ST_tagAloneEnd, ST_eFail, "Transition from TAG_ALONE_END to E_FAIL on eod, default transition" );
                               /* State TAG_ALONE_END - exit_action empty */
                               /* Transition from TAG_ALONE_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_tagAloneEnd2:    /* TAG_ALONE_END2 */
                                       {
                            this->logEvent( 0, ST_tagAloneEnd2, ST_eFail, "Transition from TAG_ALONE_END2 to E_FAIL on eod, default transition" );
                               /* State TAG_ALONE_END2 - exit_action empty */
                               /* Transition from TAG_ALONE_END2 to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitAttrName:    /* WAIT_ATTR_NAME */
                                       {
                            this->logEvent( 0, ST_waitAttrName, ST_eFail, "Transition from WAIT_ATTR_NAME to E_FAIL on eod, default transition" );
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitAttrVal:    /* WAIT_ATTR_VAL */
                                       {
                            this->logEvent( 0, ST_waitAttrVal, ST_eFail, "Transition from WAIT_ATTR_VAL to E_FAIL on eod, default transition" );
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitEq:    /* WAIT_EQ */
                                       {
                            this->logEvent( 0, ST_waitEq, ST_eFail, "Transition from WAIT_EQ to E_FAIL on eod, default transition" );
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitNextAttrName:    /* WAIT_NEXT_ATTR_NAME */
                                       {
                            this->logEvent( 0, ST_waitNextAttrName, ST_eFail2, "Transition from WAIT_NEXT_ATTR_NAME to E_FAIL2 on eod, default transition" );
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_waitPiEnd:    /* WAIT_PI_END */
                                       {
                            this->logEvent( 0, ST_waitPiEnd, ST_eFail, "Transition from WAIT_PI_END to E_FAIL on eod, default transition" );
                               /* State WAIT_PI_END - exit_action empty */
                               /* Transition from WAIT_PI_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagName:    /* WAIT_TAG_NAME */
                                       {
                            this->logEvent( 0, ST_waitTagName, ST_eFail, "Transition from WAIT_TAG_NAME to E_FAIL on eod, default transition" );
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagNameEnd:    /* WAIT_TAG_NAME_END */
                                       {
                            this->logEvent( 0, ST_waitTagNameEnd, ST_eFail, "Transition from WAIT_TAG_NAME_END to E_FAIL on eod, default transition" );
                               /* State WAIT_TAG_NAME_END - exit_action empty */
                               /* Transition from WAIT_TAG_NAME_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagStart:    /* WAIT_TAG_START */
                                       {
                            this->logEvent( 0, ST_waitTagStart, ST_eOk, "Transition from WAIT_TAG_START to E_OK on eod, default transition" );
                               /* State WAIT_TAG_START - exit_action empty */
                               /* Transition from WAIT_TAG_START to E_OK actions */
                               this->logEvent( 0x0202, ST_waitTagStart, ST_eOk, "endDoc();" );
                               { endDoc(); }
                               /* End state E_OK - entry_action empty */
                            this->curState = ST_eOk;
                           }
                     break;
                case ST_waitTagStart0:    /* WAIT_TAG_START0 */
                                       {
                            this->logEvent( 0, ST_waitTagStart0, ST_eFail, "Transition from WAIT_TAG_START0 to E_FAIL on eod, default transition" );
                               /* State WAIT_TAG_START0 - exit_action empty */
                               /* Transition from WAIT_TAG_START0 to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
               };

           }

    protected:  
        virtual
        void
        storeChar
                 ( const char  ch          
                 ) = 0;

    protected:  
        virtual
        void
        clrBuf
              ( 
              ) = 0;

    protected:  
        virtual
        void
        callText
                ( 
                ) = 0;

    protected:  
        virtual
        void
        startDoc
                ( 
                ) = 0;

    protected:  
        virtual
        void
        endDoc
              ( 
              ) = 0;

    protected:  
        virtual
        void
        startElem
                 ( 
                 ) = 0;

    protected:  
        virtual
        void
        singleElem
                  ( 
                  ) = 0;

    protected:  
        virtual
        void
        endElem
               ( 
               ) = 0;

    protected:  
        virtual
        void
        callPi
              ( 
              ) = 0;

    protected:  
        virtual
        void
        callAttr
                ( 
                ) = 0;

    protected:  
        virtual
        void
        callAttrVal
                   ( 
                   ) = 0;

    protected:  
        unsigned
        isLatinAlpha
                    ( char  ch          
                    )
           {
            if (ch>='a' && ch<='z') return 1;
            if (ch>='A' && ch<='Z') return 1;
            return 0;
           }

    protected:  
        virtual
        unsigned
        isTagStartChar
                      ( const char  ch          
                      )
           {
            if (isLatinAlpha(ch)) return 1;
            if (ch=='_' || ch==':') return 1;
            return 0;
           }

    protected:  
        virtual
        unsigned
        isTagChar
                 ( const char  ch          
                 )
           {
            if (isLatinAlpha(ch)) return 1;
            if (ch>='0' && ch<='9') return 1;
            if (ch=='_' || ch==':') return 1;
            if (ch=='.' || ch=='-') return 1;
            return 0;
           }

    protected:  
        virtual
        unsigned
        isAttrStartChar
                       ( const char  ch          
                       )
           {
            return isTagStartChar(ch);
           }

    protected:  
        virtual
        unsigned
        isAttrChar
                  ( const char  ch          
                  )
           {
            return isTagChar(ch);
           }

    protected:  
        unsigned
        isSpace
               ( const char  ch          
               )
           {
            return ch==' ' || ch=='\r' || ch=='\n' || ch=='\t';
           }

    protected:  
        virtual
        void
        callComment
                   ( 
                   ) = 0;

    protected:  
        virtual
        void
        callCdata
                 ( 
                 ) = 0;

    protected:  
        virtual
        void
        attrEnd
               ( 
               ) = 0;

    protected:  
        virtual
        void
        callSpace
                 ( 
                 ) = 0;

    protected:  
        virtual
        void
        callDTD
               ( 
               ) = 0;

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->customResetAutomata(  );
            this->curState = ST_waitTagStart0;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return 0;
           }

    protected:  
        virtual
        void
        logEvent
                ( int         eventTypeCode //!< 0x0100 - event info flag, 0x0200 - action info flag, 0 - event message, 0x0010 - guard variable (C++ only, if -GL2|-GL+ command line options used), 2 - event message on inadmissible event, 0x0101 - from, 0x0102 - to, 0x0103 - event, 0x0104 - quard, 0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                , int         fromState    //!< transition start state, can be used for event filtration
                , int         toState      //!< transition end state, can be used for event filtration
                , const char *eventMsg     //!< from/to state name, event name, guard condition, entry/trigger/do/exit action text or info message
                ) = 0;


};


}; // namespace sax {
}; // namespace cli {

#endif /* DBG_ASAX_AUTOMATA_H */
