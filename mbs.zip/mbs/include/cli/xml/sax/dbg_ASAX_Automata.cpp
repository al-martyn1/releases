/* Warning! Automaticaly generated file, do not edit */

#include "dbg_ASAX_Automata.h"


#ifndef CLI_SAX_CSAXPARSERBASE_LOGGING_USED
#define CLI_SAX_CSAXPARSERBASE_LOGGING_USED
#endif




namespace cli {
namespace sax {



}; // namespace sax {
}; // namespace cli {

