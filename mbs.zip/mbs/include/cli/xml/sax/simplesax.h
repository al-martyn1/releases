#ifndef CLI_XML_SAX_SIMPLESAX_H
#define CLI_XML_SAX_SIMPLESAX_H

/* add this lines to your scr
#ifndef CLI_XML_SAX_SIMPLESAX_H
    #include <cli/xml/sax/simplesax.h>
#endif
*/

// http://allxml.h1.ru/articles/XML-RPC%20Specification.htm
// http://www.oxygenxml.com/archives/xml-dev/199912/msg00117.html
// http://www.saxproject.org/apidoc/org/xml/sax/helpers/DefaultHandler.html

#if !defined(_INC_STDDEF) && !defined(_STDDEF_H_) && !defined(_STDDEF_H)
    #include <stddef.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif


#if defined(DEBUG) || defined(_DEBUG)
#include "dbg_ASAX_Automata.h"
#else
#include "rel_ASAX_Automata.h"
#endif

#if !defined(CLI_SAX_CSAXPARSERBASE_LOGGING_USED) 
    #if defined(ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING)
        #undef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
    #endif
#endif


namespace cli{
namespace sax{


inline
size_t wideCharToUtf8(unsigned uch, char *buf, size_t bufLen)
   {
    //unsigned char buf[6];
    size_t count = 0;
    size_t maxCount = 0;
    unsigned char  orMask = 0;

    if (uch>=0x04000000)      { maxCount = 6; orMask = 0xFC; }
    else if (uch>=0x00200000) { maxCount = 5; orMask = 0xF8; }
    else if (uch>=0x00010000) { maxCount = 4; orMask = 0xF0; }
    else if (uch>=0x00000800) { maxCount = 3; orMask = 0xE0; }
    else if (uch>=0x00000080) { maxCount = 2; orMask = 0xC0; }
    else                      { maxCount = 1; orMask = 0x00; }
    if (maxCount>bufLen) maxCount = bufLen;

    while(count!=maxCount)
       {
        count++;               // most significant bits
        if (count==maxCount) { buf[count-1] = (uch | orMask); }
        else                 { buf[count-1] = ((uch&0x3F) | 0x80); uch>>=6; }
       }
    //buf[count] = 0;
    return count;
    //for(count=maxCount; count>0; --count)  handler(buf[count-1]);
   }

struct CSaxHandler
{
    virtual void characters( const char *pchars, size_t len ) = 0;
    virtual void cdataSection( const char *pchars, size_t len ) = 0;
    virtual void dtd( const char *pchars, size_t len ) = 0;
    virtual void comment( const char *pchars, size_t len ) = 0;
    virtual void startDocument()  = 0;
    virtual void endDocument()  = 0;
    virtual void startElement( const char *ns, size_t nsLen
                           , const char *elem, size_t elemLen
                           , const char *elemFull, size_t elemFullLen // ns:tag
                           )  = 0;
    virtual void endElement( const char *ns, size_t nsLen
                           , const char *elem, size_t elemLen
                           , const char *elemFull, size_t elemFullLen // ns:tag
                           )  = 0;
    virtual void processingInstruction( const char *pi, size_t piLen )  = 0;
    virtual void attribute( const char *ns, size_t nsLen
                           , const char *attr, size_t attrLen
                           , const char *attrFull, size_t attrFullLen // ns:attr
                           )  = 0;

    virtual void attributeValue( const char *attrVal, size_t attrValLen )  = 0;
    virtual void attributesEnd( )  = 0;
    // not used
    virtual void spaceChar( char ch )  {}

    virtual void resolveEntity( const char *entityName   , size_t entityNameSize
                      ,       char *entityTextBuf, size_t entityTextBufSize 
                      , size_t *pEntityTextSize
                      ) = 0;
    virtual void encodeWideChar( unsigned charCode, char *bufTo, size_t bufToLen, size_t *pLenEncoded )
       {
        if (pLenEncoded) *pLenEncoded = wideCharToUtf8( charCode, bufTo, bufToLen );
        wideCharToUtf8( charCode, bufTo, bufToLen );
       }
};

struct CSaxDefaultHandler : public CSaxHandler
{
    void characters( const char *pchars, size_t len ) {}
    void cdataSection( const char *pchars, size_t len ) {}
    void dtd( const char *pchars, size_t len ) {}
    void comment( const char *pchars, size_t len ) {}
    void startDocument() {}
    void endDocument() {}
    void startElement( const char *ns, size_t nsLen
                   , const char *elem, size_t elemLen
                   , const char *elemFull, size_t elemFullLen // ns:tag
                   ) {}
    void endElement( const char *ns, size_t nsLen
                   , const char *elem, size_t elemLen
                   , const char *elemFull, size_t elemFullLen // ns:tag
                   ) {}
    void processingInstruction( const char *pi, size_t piLen ) {}
    void attribute( const char *ns, size_t nsLen
                   , const char *attr, size_t attrLen
                   , const char *attrFull, size_t attrFullLen // ns:attr
                   ) {}

    void attributeValue( const char *attrVal, size_t attrValLen ) {}
    void attributesEnd( ) {}

    void resolveEntity( const char *entityName   , size_t entityNameSize
                      ,       char *entityTextBuf, size_t entityTextBufSize 
                      , size_t *pEntityTextSize
                      ) {}
};


struct CAttribute
{

protected:

    ::std::string  ns;
    bool           hasNs;
    ::std::string  name;
    ::std::string  value;
    bool           valueTaken;

public:

    CAttribute() : ns(), hasNs(false), name(), value(), valueTaken(false) {} 
    CAttribute( const ::std::string &n ) : ns(), hasNs(false), name(n), value(), valueTaken(false) {}
    CAttribute( const ::std::string &n, const ::std::string &v ) : ns(), hasNs(false), name(n), value(v), valueTaken(true) {}

    void          setName(   const ::std::string &n )           { name = n; }
    void          setName(   const char *attr, size_t attrLen ) { name = ::std::string(attr, attrLen); }
    ::std::string getName()  const                              { return name; }

    void          setNamespace( const ::std::string &n )        { ns = n; hasNs = true; }
    ::std::string getNamespace()  const                         { return ns; }
    bool          hasNamespace()  const                         { return hasNs; }

    void          setValue(  const ::std::string &v )           { value = v; valueTaken = true; }
    ::std::string getValue() const                              { return value; }
    bool          hasValue() const                              { return valueTaken; }
    void          reset()                                       { ns.clear(); name.clear(); value.clear(); valueTaken = false; hasNs = false; }

    ::std::string getFullName() const
       {
        ::std::string fullName;
        if (hasNamespace())
           {
            fullName = ns;
            fullName.append(1,':');
           }
        return fullName + name;
       }

};


struct CSaxHandlerEx
{    
    virtual void characters( const ::std::string &str ) = 0;
    virtual void cdataSection( const ::std::string &str ) = 0;
    virtual void dtd( const ::std::string &str ) = 0;
    virtual void comment( const ::std::string &str ) = 0;
    virtual void startDocument()  = 0;
    virtual void endDocument()  = 0;
    virtual void startElement( bool hasNs, const ::std::string &ns
                             , const ::std::string &elem
                             , const ::std::string &elemFullName
                             , const ::std::vector< CAttribute > &attributes
                             )  = 0;
    virtual void endElement( bool hasNs, const ::std::string &ns
                           , bool elemNameTaken 
                           , const ::std::string &elem
                           , const ::std::string &elemFullName
                           ) = 0;

    virtual void processingInstruction( const ::std::string &str )  = 0;
    // not used
    virtual void spaceChar( char ch ) {}

    virtual void resolveEntity( const ::std::string &entityName
                              , ::std::string &entityText
                              ) = 0;

    virtual void encodeWideChar( unsigned charCode, ::std::string &bufTo )
       {
        char buf[64];
        size_t encodedLen = wideCharToUtf8( charCode, buf, sizeof(buf) );
        bufTo = ::std::string( buf, encodedLen );
       }

};


struct CSaxDefaultHandlerEx : public CSaxHandlerEx
{    

    void characters( const ::std::string &str ) {}
    void cdataSection( const ::std::string &str ) {}
    void dtd( const ::std::string &str ) {}
    void comment( const ::std::string &str ) {}
    void startDocument() {}
    void endDocument() {}
    void startElement( bool hasNs, const ::std::string &ns
                             , const ::std::string &elem
                             , const ::std::string &elemFullName
                             , const ::std::vector< CAttribute > &attributes
                             ) {}
    void endElement( bool hasNs, const ::std::string &ns
                           , bool elemNameTaken 
                           , const ::std::string &elem
                           , const ::std::string &elemFullName
                           ) = 0;

    void processingInstruction( const ::std::string &str )  {}

    void resolveEntity( const ::std::string &entityName
                              , ::std::string &entityText
                              ) {}
};



struct CSaxHandlerToExConverter : public CSaxHandler
{
    CSaxHandlerEx *pSaxHandlerEx;
    ::std::string savedStartTag;
    ::std::string savedStartTagNs;
    bool          startTagHasNs;
    ::std::vector< CAttribute > attributes;
    CAttribute                  curAttr;
    CSaxHandlerToExConverter( CSaxHandlerEx *p = 0) 
       : pSaxHandlerEx(p)
       , savedStartTag() 
       , savedStartTagNs()
       , startTagHasNs(false)
       , attributes()
       , curAttr()
       {}

    void characters( const char *pchars, size_t len )
       {
        if (pSaxHandlerEx && pchars) pSaxHandlerEx->characters( ::std::string(pchars, len) );
       }

    void cdataSection( const char *pchars, size_t len )
       {
        if (pSaxHandlerEx && pchars) pSaxHandlerEx->cdataSection( ::std::string(pchars, len) );
       }

    void dtd( const char *pchars, size_t len )
       {
        if (pSaxHandlerEx && pchars) pSaxHandlerEx->dtd( ::std::string(pchars, len) );
       }

    void comment( const char *pchars, size_t len )
       {
        if (pSaxHandlerEx && pchars) pSaxHandlerEx->comment( ::std::string(pchars, len) );
       }

    void startDocument()
       {
        if (pSaxHandlerEx) pSaxHandlerEx->startDocument( );
       }

    void endDocument()
       {
        if (pSaxHandlerEx) pSaxHandlerEx->endDocument( );
       }

    void startElement( const char *ns, size_t nsLen
                           , const char *elem, size_t elemLen
                           , const char *elemFull, size_t elemFullLen // ns:tag
                           )
       {
        attributes.clear();
        curAttr.reset();
        savedStartTagNs.clear();
        startTagHasNs = false;
        if (ns)
           {
            savedStartTagNs = ::std::string( ns, nsLen );
            startTagHasNs = true;
           }
        if (elem)
           savedStartTag = ::std::string( elem, elemLen );
        else
           savedStartTag.clear();
       }                    
                             
    void endElement( const char *ns, size_t nsLen
                           , const char *elem, size_t elemLen
                           , const char *elemFull, size_t elemFullLen // ns:tag
                           )
       {
        bool hasNs = false;
        
        ::std::string nsName;
        if (ns)
           {
            hasNs = true;
            nsName = ::std::string( ns, nsLen );
           }
        ::std::string fullName;
        if (elemFull) fullName = ::std::string( elemFull, elemFullLen );
        ::std::string elemName;
        if (elem) elemName = ::std::string( elem, elemLen );

        if (pSaxHandlerEx) pSaxHandlerEx->endElement( hasNs, nsName, !elemName.empty(), elemName, fullName );
       }

    void processingInstruction( const char *pi, size_t piLen )
       {
        if (pSaxHandlerEx) pSaxHandlerEx->processingInstruction( ::std::string(pi, piLen) );
       }

    void attribute( const char *ns, size_t nsLen
                           , const char *attr, size_t attrLen
                           , const char *attrFull, size_t attrFullLen // ns:attr
                           )
       {
        if (!curAttr.getName().empty()) 
           {
            attributes.push_back( curAttr );
           }
        curAttr.reset();
        if (ns)   curAttr.setNamespace( ::std::string(ns, nsLen) );
        if (attr) curAttr.setName     ( ::std::string(attr, attrLen) );
       }

    void attributeValue( const char *attrVal, size_t attrValLen )
       {
        curAttr.setValue( ::std::string(attrVal, attrValLen) );
        if (!curAttr.getName().empty()) 
           {
            attributes.push_back( curAttr );
           }
        curAttr.reset();
       }

    void attributesEnd( )
       {
        if (!curAttr.getName().empty()) 
           {
            attributes.push_back( curAttr );
           }

        if (pSaxHandlerEx)
           {
            ::std::string fullName;
            if (startTagHasNs)
               fullName = savedStartTagNs + ::std::string(":");
            fullName.append( savedStartTag, 0, savedStartTag.npos );

            pSaxHandlerEx->startElement( startTagHasNs, savedStartTagNs, savedStartTag, fullName, attributes );
           }
       }

    void spaceChar( char ch )
       {
        if (pSaxHandlerEx) pSaxHandlerEx->spaceChar(ch);
       }

    void resolveEntity( const char *entityName   , size_t entityNameSize
                      ,       char *entityTextBuf, size_t entityTextBufSize 
                      , size_t *pEntityTextSize
                      )
       {
        ::std::string entityText;
        if (pSaxHandlerEx) pSaxHandlerEx->resolveEntity( ::std::string(entityName, entityNameSize ), entityText );
        size_t numCharToCopy = entityText.size();
        if (numCharToCopy>entityTextBufSize) numCharToCopy = entityTextBufSize;
        entityText.copy( entityTextBuf, numCharToCopy, 0 );
        if (pEntityTextSize) *pEntityTextSize = numCharToCopy;
       }

     void encodeWideChar( unsigned charCode, char *bufTo, size_t bufToLen, size_t *pLenEncoded )
       {
        ::std::string encTo;
        if (pSaxHandlerEx) pSaxHandlerEx->encodeWideChar(charCode,encTo);
        size_t numCharToCopy = encTo.size();
        if (numCharToCopy>bufToLen) numCharToCopy = bufToLen;
        encTo.copy( bufTo, numCharToCopy, 0 );
        if (pLenEncoded) *pLenEncoded = numCharToCopy;
       }
};












struct CSaxStdStringBuffer
{
    ::std::string  buf;

    void appendChar(char ch) { buf.append(1,ch); }
    void clearBuf()          { buf.clear(); }
    unsigned findColon( size_t *pColonPos )
       {
        ::std::string::size_type pos = buf.find(':');
        if (pos==::std::string::npos) return 0;
        if (pColonPos) *pColonPos = (size_t)pos;
        return 1;
       }
    size_t getSize() { return (size_t)buf.size(); }
    const char* getData() { return buf.data(); }
};


template< typename TBuf = CSaxStdStringBuffer>
class CSimpleSaxParser : public CSaxParserBase
{
    CSaxHandler *pHandler;
    TBuf         buf;

public:

    CSimpleSaxParser( CSaxHandler *ph = 0) : pHandler(ph), buf() {}
    ~CSimpleSaxParser()
       {
        //if (pHandler) delete pHandler;
       }

    void setHandler( CSaxHandler *ph )
       {
        //if (pHandler) delete pHandler;
        pHandler = ph;
       }

    CSaxHandler* releaseHandler( )
       {
        CSaxHandler* tmp = pHandler;
        pHandler = 0;
        return tmp;
       }

protected:

    size_t copyStrToBuf( char *buf, size_t bufSize
                       , const char *str
                       )
       {
        size_t i = 0;
        for(; i!=bufSize && *str; ++i )
           {
            *buf++ = *str++;
           }
        return i; // num bytes copied
       }

    template <typename IntType, typename CharType>
    IntType digitToInt( CharType ch )
       {
        //ch = toUpperCase( ch );
        if (ch>=(CharType)'0' && ch<=(CharType)'9') return (IntType)(ch - (CharType)'0');
        if (ch>=(CharType)'A' && ch<=(CharType)'Z') return (IntType)(ch - (CharType)'A') + 10;
        if (ch>=(CharType)'a' && ch<=(CharType)'z') return (IntType)(ch - (CharType)'a') + 10;
        return (IntType)-1;
       }

    void doResolveEntity( const char *entityName   , size_t entityNameSize
                      ,       char *entityTextBuf, size_t entityTextBufSize 
                      , size_t *pEntityTextSize
                      )
       {
        if (!entityName || !entityNameSize)
           {
            if (entityTextBuf && entityTextBufSize)
               *entityTextBuf = 0;
            if (pEntityTextSize) *pEntityTextSize = 0;
            return;
           }

        ::std::string entityNameStr( entityName, entityNameSize );
        const char *pText = 0;
        char numericEntityBuf[32];
        if (entityNameStr=="amp")       pText = "&";
        else if (entityNameStr=="quot") pText = "\"";
        else if (entityNameStr=="apos") pText = "\'";
        else if (entityNameStr=="lt")   pText = "<";
        else if (entityNameStr=="gt")   pText = ">";
        else if (!entityNameStr.empty() && entityNameStr[0]=='#')
           {
            ::std::string::size_type pos = 1, size = entityNameStr.size();
            unsigned base = 10;
            unsigned val = 0;
            if (pos<size && (entityNameStr[pos]=='x' || entityNameStr[pos]=='X'))
               {
                ++pos;
                base = 16;
               }
            for(; pos!=size; ++pos)
               {
                int digit = digitToInt<int,char>( entityNameStr[pos] );
                if (digit<0) break;
                val *= base;
                val += (unsigned)digit;
               }
            numericEntityBuf[0] = 0;
            size_t encodedLen = 0;
            pHandler->encodeWideChar( val, numericEntityBuf, sizeof(numericEntityBuf), &encodedLen );
            numericEntityBuf[encodedLen] = 0;
            //toUtf8(val, numericEntityBuf);
            pText = numericEntityBuf;
           }

        if (!pText)
           {
            if (pHandler) pHandler->resolveEntity( entityName, entityNameSize
                                                 , entityTextBuf, entityTextBufSize
                                                 , pEntityTextSize
                                                 );
           }
        else
           {
            if (pEntityTextSize) *pEntityTextSize = copyStrToBuf( entityTextBuf, entityTextBufSize, pText );
            else copyStrToBuf( entityTextBuf, entityTextBufSize, pText );
           }
       }


    void doCallText()
       {
        const char *ptr = buf.getData();
        size_t bufSize = buf.getSize();
        const char *ptrEnd = ptr + bufSize;

        //size_t i = 0;
        for( ; ptr!=ptrEnd && isSpace(*ptr); ++ptr ) {}
        for( ; ptrEnd!=ptr; --ptrEnd)
           {
            if (!isSpace(*ptrEnd)) break;
           }

        char tmpBuf[1024];
        size_t tmpPos = 0;
        for(; ptr!=ptrEnd; )
           {
            if (*ptr=='&')
               { // found entity
                if ( tmpPos>=(sizeof(tmpBuf)/sizeof(tmpBuf[0]))-256 ) // 256 - max entity text len 
                   { // flush tmp buf
                    #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
                    std::cout<< ::std::string( tmpBuf, tmpPos )<<"\n";
                    #endif
                    pHandler->characters( tmpBuf, tmpPos );
                    tmpPos = 0;
                   }
                ++ptr;
                const char *pEntityName = ptr;
                size_t entLen = 0;
                for(; ptr!=ptrEnd && *ptr!=';'; ++ptr) ++entLen;
                if (ptr!=ptrEnd) ++ptr; // skip ';'
                size_t entTextLen = 0;
                doResolveEntity( pEntityName, entLen
                               , &tmpBuf[tmpPos], (sizeof(tmpBuf)/sizeof(tmpBuf[0])) - tmpPos
                               , &entTextLen
                               );
                tmpPos += entTextLen;
               }
            else // normal char
               {
                if (tmpPos>=(sizeof(tmpBuf)/sizeof(tmpBuf[0])))
                   { // flush tmp buf
                    #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
                    std::cout<< ::std::string( tmpBuf, tmpPos )<<"\n";
                    #endif
                    pHandler->characters( tmpBuf, tmpPos);
                    tmpPos = 0;
                   }
                tmpBuf[tmpPos++] = *ptr++;
               }
           }
        if (tmpPos)
           { // flush tmp buf
            #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
            std::cout<< ::std::string( tmpBuf, tmpPos )<<"\n";
            #endif
            pHandler->characters( tmpBuf, tmpPos);
            tmpPos = 0;
           }
       }


    void doCallAttributeValue()
       {
        const char *ptr = buf.getData();
        size_t bufSize = buf.getSize();
        const char *ptrEnd = ptr + bufSize;

        //size_t i = 0;
        //for( ; ptr!=ptrEnd && (*ptr==' ' || *ptr=='\r' || *ptr=='\n') ; ++ptr ) {}
        char tmpBuf[1024];
        size_t tmpPos = 0;
        for(; ptr!=ptrEnd; )
           {
            if (*ptr=='&')
               { // found entity
                if ( tmpPos>=(sizeof(tmpBuf)/sizeof(tmpBuf[0]))-256 ) // 256 - max entity text len 
                   { // flush tmp buf
                    #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
                    std::cout<< ::std::string( tmpBuf, tmpPos )<<"\n";
                    #endif
                    pHandler->attributeValue( tmpBuf, tmpPos);
                    tmpPos = 0;
                   }
                ++ptr;
                const char *pEntityName = ptr;
                size_t entLen = 0;
                for(; ptr!=ptrEnd && *ptr!=';'; ++ptr) ++entLen;
                if (ptr!=ptrEnd) ++ptr; // skip ';'
                size_t entTextLen = 0;
                doResolveEntity( pEntityName, entLen
                               , &tmpBuf[tmpPos], (sizeof(tmpBuf)/sizeof(tmpBuf[0])) - tmpPos
                               , &entTextLen
                               );
                tmpPos += entTextLen;
               }
            else // normal char
               {
                if (tmpPos>=(sizeof(tmpBuf)/sizeof(tmpBuf[0])))
                   { // flush tmp buf
                    #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
                    std::cout<< ::std::string( tmpBuf, tmpPos )<<"\n";
                    #endif
                    pHandler->attributeValue( tmpBuf, tmpPos);
                    tmpPos = 0;
                   }
                tmpBuf[tmpPos++] = *ptr++;
               }
           }
        if (tmpPos)
           { // flush tmp buf
            #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
            std::cout<< ::std::string( tmpBuf, tmpPos )<<"\n";
            #endif
            pHandler->attributeValue( tmpBuf, tmpPos);
            tmpPos = 0;
           }
       }

        void
        storeChar
                 ( const char  ch          
                 )
           {
            if (ch!='\r')
               buf.appendChar(ch);
           }

        void
        clrBuf
              ( 
              )
           {
            buf.clearBuf();
           }

        void
        callText
                ( 
                )
           {
            if (!pHandler) { clrBuf(); return; }
            /*
            const char *ptr = buf.getData();
            size_t size = buf.getSize();
            size_t i = 0;
            for( ; i!=size && (*ptr==' ' || *ptr=='\r' || *ptr=='\n') ; ++ptr, ++i) {}
            if (i!=size) 
               pHandler->characters( ptr, size-i);
            */
            doCallText();
            clrBuf();
           }

        void
        startDoc
                ( 
                )
           {
            if (!pHandler) { clrBuf(); return; }
            pHandler->startDocument();
            clrBuf();
           }

        void
        endDoc
              ( 
              )
           {
            if (!pHandler) { clrBuf(); return; }
            pHandler->endDocument();
            clrBuf();
           }

        void
        singleElem
                  ( 
                  )
           {
            //if (!pHandler) return;
            //startElem();
            //endElem();
            if (!pHandler) { clrBuf(); return; }
            const char *pData = buf.getData();
            size_t dataSize   = buf.getSize();
            size_t colonPos = 0;
            if (buf.findColon(&colonPos))
               {
                #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
                std::cout<< ::std::string( pData, dataSize )<<"\n";
                #endif
                pHandler->startElement( pData, colonPos, pData+colonPos+1, dataSize-1-colonPos, pData, dataSize);
                pHandler->endElement  ( pData, colonPos, pData+colonPos+1, dataSize-1-colonPos, pData, dataSize);
               }
            else
               {
                pHandler->startElement( 0, 0, pData, dataSize, pData, dataSize);
                pHandler->endElement  ( 0, 0, pData, dataSize, pData, dataSize);
               }
            clrBuf();
           }

        void
        startElem
                 ( 
                 )
           {
            if (!pHandler) { clrBuf(); return; }
            const char *pData = buf.getData();
            size_t dataSize   = buf.getSize();
            size_t colonPos = 0;
            #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
            std::cout<< ::std::string( pData, dataSize )<<"\n";
            #endif
            if (buf.findColon(&colonPos))
               pHandler->startElement( pData, colonPos, pData+colonPos+1, dataSize-1-colonPos, pData, dataSize);
            else
               pHandler->startElement( 0, 0, pData, dataSize, pData, dataSize);
            clrBuf();
           }

        void
        endElem
               ( 
               )
           {
            if (!pHandler) { clrBuf(); return; }
            const char *pData = buf.getData();
            size_t dataSize   = buf.getSize();
            size_t colonPos = 0;
            #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
            std::cout<< ::std::string( pData, dataSize )<<"\n";
            #endif
            if (buf.findColon(&colonPos))
               pHandler->endElement( pData, colonPos, pData+colonPos+1, dataSize-1-colonPos, pData, dataSize);
            else
               pHandler->endElement( 0, 0, pData, dataSize, pData, dataSize);
            clrBuf();
           }

        void
        callPi
              ( 
              )
           {
            if (!pHandler) { clrBuf(); return; }
            pHandler->processingInstruction( buf.getData(), buf.getSize() );
            clrBuf();
           }

        void
        callComment
                   ( 
                   )
           {
            if (!pHandler) { clrBuf(); return; }
            pHandler->comment( buf.getData(), buf.getSize() );
            clrBuf();
           }

        void
        callCdata
                 ( 
                 )
           {
            if (!pHandler) { clrBuf(); return; }
            pHandler->cdataSection( buf.getData(), buf.getSize() );
            clrBuf();
           }


        void
        callAttr
                ( 
                )
           {
            if (!pHandler) { clrBuf(); return; }
            const char *pData = buf.getData();
            size_t dataSize   = buf.getSize();
            size_t colonPos = 0;
            #ifdef ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING
            std::cout<< ::std::string( pData, dataSize )<<"\n";
            #endif
            if (buf.findColon(&colonPos))
               pHandler->attribute( pData, colonPos, pData+colonPos+1, dataSize-1-colonPos, pData, dataSize);
            else
               pHandler->attribute( 0, 0, pData, dataSize, pData, dataSize);
            clrBuf();
           }

        void
        callAttrVal
                   ( 
                   )
           {
            if (!pHandler) { clrBuf(); return; }
            //pHandler->attributeValue( buf.getData(), buf.getSize() );
            doCallAttributeValue();
            clrBuf();
           }

        void
        attrEnd
               ( 
               )
           {
            pHandler->attributesEnd();
           }

        void
        callDTD
               ( 
               )
           {
            if (!pHandler) { clrBuf(); return; }
            pHandler->dtd( buf.getData(), buf.getSize() );
            clrBuf();
           }

        void
        callSpace
                 ( 
                 )
           {}


#if defined(CLI_SAX_CSAXPARSERBASE_LOGGING_USED) 
        void
        logEvent
                ( int         eventTypeCode //!< 0x0100 - event info flag, 0x0200 - action info flag, 0 - event message, 0x0010 - guard variable (C++ only, if -GL2|-GL+ command line options used), 2 - event message on inadmissible event, 0x0101 - from, 0x0102 - to, 0x0103 - event, 0x0104 - quard, 0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
                , int         fromState    //!< transition start state, can be used for event filtration
                , int         toState      //!< transition end state, can be used for event filtration
                , const char *eventMsg     //!< from/to state name, event name, guard condition, entry/trigger/do/exit action text or info message
                )
           {
            #if defined(ENABLE_CLI_SAX_CSAXPARSERBASE_LOGGING)
            std::cout<<eventMsg<<"\n";
            #endif
           }
#endif

};


template<typename TParser>
int parse( TParser *parser, CSaxHandler *pHandler, const ::std::string &strData )
   {
    if (!parser) return -1;
    if (!pHandler) return -1;
    parser->setHandler( pHandler );
    parser->resetAutomata();

    //parser->startDoc();

    ::std::string::size_type pos = 0, size = strData.size();
    for(; pos!=size; ++pos)
       {
        parser->putChar(strData[pos]);
        if (parser->isInFinalState())
           {
            parser->releaseHandler( );
            return -1;
           }
       }
    parser->eod();
    if (!parser->isInFinalState())
       {
        parser->releaseHandler( );
        return -1;
       }

    if (parser->getCurState()!=CSaxParserBase::ST_eOk)
       {
        parser->releaseHandler( );
        return -1;
       }

    //parser->endDoc();

    parser->releaseHandler( );

    return 0;
   }

template<typename TParser>
int parse( TParser *parser, CSaxHandlerEx *pHandler, const ::std::string &strData )
   {
    CSaxHandlerToExConverter converter(pHandler);
    return parse< TParser >( parser, static_cast<CSaxHandler*>(&converter), strData );
   }


}; // namespace sax
}; // namespace cli


#endif // CLI_XML_SAX_SIMPLESAX_H

