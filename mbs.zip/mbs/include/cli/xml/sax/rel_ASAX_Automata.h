#ifndef REL_ASAX_AUTOMATA_H
#define REL_ASAX_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */






namespace cli {
namespace sax {

class CSaxParserBase {

    private:    int                  lvl         ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state
    public:     static const int     ST_cDATA     = 0x00000001; //!< CDATA
    public:     static const int     ST_cDATA1    = 0x00000002; //!< CDATA1
    public:     static const int     ST_cDATA2    = 0x00000003; //!< CDATA2
    public:     static const int     ST_cDATA3    = 0x00000004; //!< CDATA3
    public:     static const int     ST_cDATA4    = 0x00000005; //!< CDATA4
    public:     static const int     ST_cDATA5    = 0x00000006; //!< CDATA5
    public:     static const int     ST_cDATA6    = 0x00000007; //!< CDATA6
    public:     static const int     ST_cDATAE1   = 0x00000008; //!< CDATAE1
    public:     static const int     ST_cDATAE2   = 0x00000009; //!< CDATAE2
    public:     static const int     ST_cOMMENT   = 0x0000000A; //!< COMMENT
    public:     static const int     ST_cOMMENT1  = 0x0000000B; //!< COMMENT1
    public:     static const int     ST_cOMMENT2  = 0x0000000C; //!< COMMENT2
    public:     static const int     ST_cOMMENTE1 = 0x0000000D; //!< COMMENTE1
    public:     static const int     ST_cOMMENTE2 = 0x0000000E; //!< COMMENTE2
    public:     static const int     ST_eFail     = 0x8000000F; //!< E_FAIL
    public:     static const int     ST_eFail2    = 0x80000010; //!< E_FAIL2
    public:     static const int     ST_eFail3    = 0x80000011; //!< E_FAIL3
    public:     static const int     ST_eOk       = 0x80000012; //!< E_OK
    public:     static const int     ST_readAttrName = 0x00000013; //!< READ_ATTR_NAME
    public:     static const int     ST_readAvapos = 0x00000014; //!< READ_AVAPOS
    public:     static const int     ST_readAvquot = 0x00000015; //!< READ_AVQUOT
    public:     static const int     ST_readAvUnquot = 0x00000016; //!< READ_AV_UNQUOT
    public:     static const int     ST_readDtd   = 0x00000017; //!< READ_DTD
    public:     static const int     ST_readPi    = 0x00000018; //!< READ_PI
    public:     static const int     ST_readTagName = 0x00000019; //!< READ_TAG_NAME
    public:     static const int     ST_readTagNameEnd = 0x0000001A; //!< READ_TAG_NAME_END
    public:     static const int     ST_readTagNameEndSpaces                                      = 0x0000001B; //!< READ_TAG_NAME_END_SPACES
    public:     static const int     ST_tagAloneEnd = 0x0000001C; //!< TAG_ALONE_END
    public:     static const int     ST_tagAloneEnd2 = 0x0000001D; //!< TAG_ALONE_END2
    public:     static const int     ST_waitAttrName = 0x0000001E; //!< WAIT_ATTR_NAME
    public:     static const int     ST_waitAttrVal = 0x0000001F; //!< WAIT_ATTR_VAL
    public:     static const int     ST_waitEq    = 0x00000020; //!< WAIT_EQ
    public:     static const int     ST_waitNextAttrName = 0x00000021; //!< WAIT_NEXT_ATTR_NAME
    public:     static const int     ST_waitPiEnd = 0x00000022; //!< WAIT_PI_END
    public:     static const int     ST_waitTagName = 0x00000023; //!< WAIT_TAG_NAME
    public:     static const int     ST_waitTagNameEnd = 0x00000024; //!< WAIT_TAG_NAME_END
    public:     static const int     ST_waitTagStart = 0x00000025; //!< WAIT_TAG_START
    public:     static const int     ST_waitTagStart0 = 0x00000026; //!< WAIT_TAG_START0
    public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__


    public:     
        void
        putChar
               ( char  ch          
               )
           {
            /* guard variable - ch */
            switch(this->curState)
               {
                case ST_cDATA:    /* CDATA */
                        if (ch==L']') /* Guard: [']'] */
                           {
                               /* State CDATA - exit_action empty */
                               /* Transition from CDATA to CDATAE1 actions */
                               /* State CDATAE1 - entry_action empty */
                            this->curState = ST_cDATAE1;
                           }
                        else
                           {
                               /* State CDATA - exit_action empty */
                               /* Transition from CDATA to CDATA actions */
                               { storeChar(ch); }
                               /* State CDATA - entry_action empty */
                            this->curState = ST_cDATA;
                           }
                     break;
                case ST_cDATA1:    /* CDATA1 */
                        if (ch==L'C') /* Guard: ['C'] */
                           {
                               /* State CDATA1 - exit_action empty */
                               /* Transition from CDATA1 to CDATA2 actions */
                               /* State CDATA2 - entry_action empty */
                            this->curState = ST_cDATA2;
                           }
                        else
                           {
                               /* State CDATA1 - exit_action empty */
                               /* Transition from CDATA1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA2:    /* CDATA2 */
                        if (ch==L'D') /* Guard: ['D'] */
                           {
                               /* State CDATA2 - exit_action empty */
                               /* Transition from CDATA2 to CDATA3 actions */
                               /* State CDATA3 - entry_action empty */
                            this->curState = ST_cDATA3;
                           }
                        else
                           {
                               /* State CDATA2 - exit_action empty */
                               /* Transition from CDATA2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA3:    /* CDATA3 */
                        if (ch==L'A') /* Guard: ['A'] */
                           {
                               /* State CDATA3 - exit_action empty */
                               /* Transition from CDATA3 to CDATA4 actions */
                               /* State CDATA4 - entry_action empty */
                            this->curState = ST_cDATA4;
                           }
                        else
                           {
                               /* State CDATA3 - exit_action empty */
                               /* Transition from CDATA3 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA4:    /* CDATA4 */
                        if (ch==L'T') /* Guard: ['T'] */
                           {
                               /* State CDATA4 - exit_action empty */
                               /* Transition from CDATA4 to CDATA5 actions */
                               /* State CDATA5 - entry_action empty */
                            this->curState = ST_cDATA5;
                           }
                        else
                           {
                               /* State CDATA4 - exit_action empty */
                               /* Transition from CDATA4 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA5:    /* CDATA5 */
                        if (ch==L'A') /* Guard: ['A'] */
                           {
                               /* State CDATA5 - exit_action empty */
                               /* Transition from CDATA5 to CDATA6 actions */
                               /* State CDATA6 - entry_action empty */
                            this->curState = ST_cDATA6;
                           }
                        else
                           {
                               /* State CDATA5 - exit_action empty */
                               /* Transition from CDATA5 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA6:    /* CDATA6 */
                        if (ch==L'[') /* Guard: ['['] */
                           {
                               /* State CDATA6 - exit_action empty */
                               /* Transition from CDATA6 to CDATA actions */
                               /* State CDATA - entry_action empty */
                            this->curState = ST_cDATA;
                           }
                        else
                           {
                               /* State CDATA6 - exit_action empty */
                               /* Transition from CDATA6 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATAE1:    /* CDATAE1 */
                        if (ch==L']') /* Guard: [']'] */
                           {
                               /* State CDATAE1 - exit_action empty */
                               /* Transition from CDATAE1 to CDATAE2 actions */
                               /* State CDATAE2 - entry_action empty */
                            this->curState = ST_cDATAE2;
                           }
                        else
                           {
                               /* State CDATAE1 - exit_action empty */
                               /* Transition from CDATAE1 to CDATA actions */
                               { storeChar(']');storeChar(ch); }
                               /* State CDATA - entry_action empty */
                            this->curState = ST_cDATA;
                           }
                     break;
                case ST_cDATAE2:    /* CDATAE2 */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State CDATAE2 - exit_action empty */
                               /* Transition from CDATAE2 to WAIT_TAG_START actions */
                               { callCdata(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                               /* State CDATAE2 - exit_action empty */
                               /* Transition from CDATAE2 to CDATA actions */
                               { storeChar(']');storeChar(']');storeChar(ch); }
                               /* State CDATA - entry_action empty */
                            this->curState = ST_cDATA;
                           }
                     break;
                case ST_cOMMENT:    /* COMMENT */
                        if (ch==L'-') /* Guard: ['-'] */
                           {
                               /* State COMMENT - exit_action empty */
                               /* Transition from COMMENT to COMMENTE1 actions */
                               /* State COMMENTE1 - entry_action empty */
                            this->curState = ST_cOMMENTE1;
                           }
                        else
                           {
                               /* State COMMENT - exit_action empty */
                               /* Transition from COMMENT to COMMENT actions */
                               { storeChar(ch); }
                               /* State COMMENT - entry_action empty */
                            this->curState = ST_cOMMENT;
                           }
                     break;
                case ST_cOMMENT1:    /* COMMENT1 */
                        if ((isLatinAlpha(ch))) /* Guard: [(isLatinAlpha(GUARDVAR))] */
                           {
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to READ_DTD actions */
                               { storeChar(ch); lvl=0; }
                               /* State READ_DTD - entry_action empty */
                            this->curState = ST_readDtd;
                           }
                        else if (ch==L'[') /* Guard: ['['] */
                           {
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to CDATA1 actions */
                               /* State CDATA1 - entry_action empty */
                            this->curState = ST_cDATA1;
                           }
                        else if (ch==L'-') /* Guard: ['-'] */
                           {
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to COMMENT2 actions */
                               /* State COMMENT2 - entry_action empty */
                            this->curState = ST_cOMMENT2;
                           }
                        else
                           {
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENT2:    /* COMMENT2 */
                        if (ch==L'-') /* Guard: ['-'] */
                           {
                               /* State COMMENT2 - exit_action empty */
                               /* Transition from COMMENT2 to COMMENT actions */
                               /* State COMMENT - entry_action empty */
                            this->curState = ST_cOMMENT;
                           }
                        else
                           {
                               /* State COMMENT2 - exit_action empty */
                               /* Transition from COMMENT2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENTE1:    /* COMMENTE1 */
                        if (ch==L'-') /* Guard: ['-'] */
                           {
                               /* State COMMENTE1 - exit_action empty */
                               /* Transition from COMMENTE1 to COMMENTE2 actions */
                               /* State COMMENTE2 - entry_action empty */
                            this->curState = ST_cOMMENTE2;
                           }
                        else
                           {
                               /* State COMMENTE1 - exit_action empty */
                               /* Transition from COMMENTE1 to COMMENT actions */
                               { storeChar('-');storeChar(ch); }
                               /* State COMMENT - entry_action empty */
                            this->curState = ST_cOMMENT;
                           }
                     break;
                case ST_cOMMENTE2:    /* COMMENTE2 */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State COMMENTE2 - exit_action empty */
                               /* Transition from COMMENTE2 to WAIT_TAG_START actions */
                               { callComment(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                               /* State COMMENTE2 - exit_action empty */
                               /* Transition from COMMENTE2 to COMMENT actions */
                               { storeChar('-');storeChar('-');storeChar(ch); }
                               /* State COMMENT - entry_action empty */
                            this->curState = ST_cOMMENT;
                           }
                     break;
                case ST_readAttrName:    /* READ_ATTR_NAME */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to WAIT_EQ actions */
                               { callAttr(); }
                               /* State WAIT_EQ - entry_action empty */
                            this->curState = ST_waitEq;
                           }
                        else if ((isAttrChar(ch))) /* Guard: [(isAttrChar(GUARDVAR))] */
                           {
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to READ_ATTR_NAME actions */
                               { storeChar(ch); }
                               /* State READ_ATTR_NAME - entry_action empty */
                            this->curState = ST_readAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to WAIT_TAG_START actions */
                               { callAttr(); attrEnd(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'=') /* Guard: ['='] */
                           {
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to WAIT_ATTR_VAL actions */
                               { callAttr(); }
                               /* State WAIT_ATTR_VAL - entry_action empty */
                            this->curState = ST_waitAttrVal;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to TAG_ALONE_END2 actions */
                               { callAttr(); }
                               /* State TAG_ALONE_END2 - entry_action empty */
                            this->curState = ST_tagAloneEnd2;
                           }
                        else
                           {
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readAvapos:    /* READ_AVAPOS */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State READ_AVAPOS - exit_action empty */
                               /* Transition from READ_AVAPOS to WAIT_NEXT_ATTR_NAME actions */
                               { callAttrVal(); }
                               /* State WAIT_NEXT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitNextAttrName;
                           }
                        else
                           {
                               /* State READ_AVAPOS - exit_action empty */
                               /* Transition from READ_AVAPOS to READ_AVAPOS actions */
                               { storeChar(ch); }
                               /* State READ_AVAPOS - entry_action empty */
                            this->curState = ST_readAvapos;
                           }
                     break;
                case ST_readAvquot:    /* READ_AVQUOT */
                        if (ch==L'\"') /* Guard: ['\"'] */
                           {
                               /* State READ_AVQUOT - exit_action empty */
                               /* Transition from READ_AVQUOT to WAIT_NEXT_ATTR_NAME actions */
                               { callAttrVal(); }
                               /* State WAIT_NEXT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitNextAttrName;
                           }
                        else
                           {
                               /* State READ_AVQUOT - exit_action empty */
                               /* Transition from READ_AVQUOT to READ_AVQUOT actions */
                               { storeChar(ch); }
                               /* State READ_AVQUOT - entry_action empty */
                            this->curState = ST_readAvquot;
                           }
                     break;
                case ST_readAvUnquot:    /* READ_AV_UNQUOT */
                        if ((((!isSpace(ch))) && (ch!='/')) && (ch!='>')) /* Guard: [(!isSpace(GUARDVAR)),(GUARDVAR!='/'),(GUARDVAR!='>')] */
                           {
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to READ_AV_UNQUOT actions */
                               { storeChar(ch); }
                               /* State READ_AV_UNQUOT - entry_action empty */
                            this->curState = ST_readAvUnquot;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to WAIT_TAG_START actions */
                               { callAttrVal(); attrEnd();endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to TAG_ALONE_END2 actions */
                               { callAttrVal(); }
                               /* State TAG_ALONE_END2 - entry_action empty */
                            this->curState = ST_tagAloneEnd2;
                           }
                        else
                           {
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to WAIT_NEXT_ATTR_NAME actions */
                               { callAttrVal(); }
                               /* State WAIT_NEXT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitNextAttrName;
                           }
                     break;
                case ST_readDtd:    /* READ_DTD */
                        if ((ch==L'>') && (lvl)) /* Guard: ['>', (lvl)] */
                           {
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to READ_DTD actions */
                               { storeChar(ch); --lvl; }
                               /* State READ_DTD - entry_action empty */
                            this->curState = ST_readDtd;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to WAIT_TAG_START actions */
                               { callDTD(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'<') /* Guard: ['<'] */
                           {
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to READ_DTD actions */
                               { storeChar(ch); ++lvl; }
                               /* State READ_DTD - entry_action empty */
                            this->curState = ST_readDtd;
                           }
                        else
                           {
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to READ_DTD actions */
                               { storeChar(ch); }
                               /* State READ_DTD - entry_action empty */
                            this->curState = ST_readDtd;
                           }
                     break;
                case ST_readPi:    /* READ_PI */
                        if (ch==L'?') /* Guard: ['?'] */
                           {
                               /* State READ_PI - exit_action empty */
                               /* Transition from READ_PI to WAIT_PI_END actions */
                               /* State WAIT_PI_END - entry_action empty */
                            this->curState = ST_waitPiEnd;
                           }
                        else
                           {
                               /* State READ_PI - exit_action empty */
                               /* Transition from READ_PI to READ_PI actions */
                               { storeChar(ch); }
                               /* State READ_PI - entry_action empty */
                            this->curState = ST_readPi;
                           }
                     break;
                case ST_readTagName:    /* READ_TAG_NAME */
                        if ((isTagChar(ch))) /* Guard: [(isTagChar(GUARDVAR))] */
                           {
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to READ_TAG_NAME actions */
                               { storeChar(ch); }
                               /* State READ_TAG_NAME - entry_action empty */
                            this->curState = ST_readTagName;
                           }
                        else if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to WAIT_ATTR_NAME actions */
                               /* State WAIT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to WAIT_TAG_START actions */
                               { startElem(); attrEnd(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to TAG_ALONE_END actions */
                               /* State TAG_ALONE_END - entry_action empty */
                            this->curState = ST_tagAloneEnd;
                           }
                        else
                           {
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagNameEnd:    /* READ_TAG_NAME_END */
                        if ((isTagChar(ch))) /* Guard: [(isTagChar(GUARDVAR))] */
                           {
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to READ_TAG_NAME_END actions */
                               { storeChar(ch); }
                               /* State READ_TAG_NAME_END - entry_action empty */
                            this->curState = ST_readTagNameEnd;
                           }
                        else if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to READ_TAG_NAME_END_SPACES actions */
                               /* State READ_TAG_NAME_END_SPACES - entry_action empty */
                            this->curState = ST_readTagNameEndSpaces;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to WAIT_TAG_START actions */
                               { endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagNameEndSpaces:    /* READ_TAG_NAME_END_SPACES */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State READ_TAG_NAME_END_SPACES - exit_action empty */
                               /* Transition from READ_TAG_NAME_END_SPACES to READ_TAG_NAME_END_SPACES actions */
                               /* State READ_TAG_NAME_END_SPACES - entry_action empty */
                            this->curState = ST_readTagNameEndSpaces;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State READ_TAG_NAME_END_SPACES - exit_action empty */
                               /* Transition from READ_TAG_NAME_END_SPACES to WAIT_TAG_START actions */
                               { endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                               /* State READ_TAG_NAME_END_SPACES - exit_action empty */
                               /* Transition from READ_TAG_NAME_END_SPACES to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_tagAloneEnd:    /* TAG_ALONE_END */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State TAG_ALONE_END - exit_action empty */
                               /* Transition from TAG_ALONE_END to WAIT_TAG_START actions */
                               { startElem();attrEnd();endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                               /* State TAG_ALONE_END - exit_action empty */
                               /* Transition from TAG_ALONE_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_tagAloneEnd2:    /* TAG_ALONE_END2 */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State TAG_ALONE_END2 - exit_action empty */
                               /* Transition from TAG_ALONE_END2 to WAIT_TAG_START actions */
                               { attrEnd();endElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                               /* State TAG_ALONE_END2 - exit_action empty */
                               /* Transition from TAG_ALONE_END2 to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitAttrName:    /* WAIT_ATTR_NAME */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to WAIT_ATTR_NAME actions */
                               /* State WAIT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitAttrName;
                           }
                        else if ((isAttrStartChar(ch))) /* Guard: [(isAttrStartChar(GUARDVAR))] */
                           {
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to READ_ATTR_NAME actions */
                               { startElem(); storeChar(ch); }
                               /* State READ_ATTR_NAME - entry_action empty */
                            this->curState = ST_readAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to WAIT_TAG_START actions */
                               { startElem(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to TAG_ALONE_END actions */
                               /* State TAG_ALONE_END - entry_action empty */
                            this->curState = ST_tagAloneEnd;
                           }
                        else
                           {
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitAttrVal:    /* WAIT_ATTR_VAL */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to WAIT_ATTR_VAL actions */
                               /* State WAIT_ATTR_VAL - entry_action empty */
                            this->curState = ST_waitAttrVal;
                           }
                        else if ((((((!isSpace(ch))) && (ch!='\'')) && (ch!='\"')) && (ch!='/')) && (ch!='>')) /* Guard: [(!isSpace(GUARDVAR)),(GUARDVAR!='\''),(GUARDVAR!='\"'),(GUARDVAR!='/'),(GUARDVAR!='>')] */
                           {
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to READ_AV_UNQUOT actions */
                               { storeChar(ch); }
                               /* State READ_AV_UNQUOT - entry_action empty */
                            this->curState = ST_readAvUnquot;
                           }
                        else if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to READ_AVAPOS actions */
                               /* State READ_AVAPOS - entry_action empty */
                            this->curState = ST_readAvapos;
                           }
                        else if (ch==L'\"') /* Guard: ['\"'] */
                           {
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to READ_AVQUOT actions */
                               /* State READ_AVQUOT - entry_action empty */
                            this->curState = ST_readAvquot;
                           }
                        else
                           {
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitEq:    /* WAIT_EQ */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to WAIT_EQ actions */
                               /* State WAIT_EQ - entry_action empty */
                            this->curState = ST_waitEq;
                           }
                        else if ((isAttrStartChar(ch))) /* Guard: [(isAttrStartChar(GUARDVAR))] */
                           {
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to WAIT_ATTR_NAME actions */
                               { storeChar(ch); }
                               /* State WAIT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to WAIT_TAG_START actions */
                               { attrEnd(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'=') /* Guard: ['='] */
                           {
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to WAIT_ATTR_VAL actions */
                               /* State WAIT_ATTR_VAL - entry_action empty */
                            this->curState = ST_waitAttrVal;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to TAG_ALONE_END2 actions */
                               /* State TAG_ALONE_END2 - entry_action empty */
                            this->curState = ST_tagAloneEnd2;
                           }
                        else
                           {
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitNextAttrName:    /* WAIT_NEXT_ATTR_NAME */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to WAIT_NEXT_ATTR_NAME actions */
                               /* State WAIT_NEXT_ATTR_NAME - entry_action empty */
                            this->curState = ST_waitNextAttrName;
                           }
                        else if ((isAttrStartChar(ch))) /* Guard: [(isAttrStartChar(GUARDVAR))] */
                           {
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to READ_ATTR_NAME actions */
                               { storeChar(ch); }
                               /* State READ_ATTR_NAME - entry_action empty */
                            this->curState = ST_readAttrName;
                           }
                        else if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to WAIT_TAG_START actions */
                               { attrEnd(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to TAG_ALONE_END2 actions */
                               /* State TAG_ALONE_END2 - entry_action empty */
                            this->curState = ST_tagAloneEnd2;
                           }
                        else
                           {
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_waitPiEnd:    /* WAIT_PI_END */
                        if (ch==L'>') /* Guard: ['>'] */
                           {
                               /* State WAIT_PI_END - exit_action empty */
                               /* Transition from WAIT_PI_END to WAIT_TAG_START actions */
                               { callPi(); clrBuf(); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                        else
                           {
                               /* State WAIT_PI_END - exit_action empty */
                               /* Transition from WAIT_PI_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagName:    /* WAIT_TAG_NAME */
                        if ((isTagStartChar(ch))) /* Guard: [(isTagStartChar(GUARDVAR))] */
                           {
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to READ_TAG_NAME actions */
                               { storeChar(ch); }
                               /* State READ_TAG_NAME - entry_action empty */
                            this->curState = ST_readTagName;
                           }
                        else if (ch==L'?') /* Guard: ['?'] */
                           {
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to READ_PI actions */
                               /* State READ_PI - entry_action empty */
                            this->curState = ST_readPi;
                           }
                        else if (ch==L'/') /* Guard: ['/'] */
                           {
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to WAIT_TAG_NAME_END actions */
                               /* State WAIT_TAG_NAME_END - entry_action empty */
                            this->curState = ST_waitTagNameEnd;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to COMMENT1 actions */
                               /* State COMMENT1 - entry_action empty */
                            this->curState = ST_cOMMENT1;
                           }
                        else
                           {
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagNameEnd:    /* WAIT_TAG_NAME_END */
                        if ((isTagStartChar(ch))) /* Guard: [(isTagStartChar(GUARDVAR))] */
                           {
                               /* State WAIT_TAG_NAME_END - exit_action empty */
                               /* Transition from WAIT_TAG_NAME_END to READ_TAG_NAME_END actions */
                               { storeChar(ch); }
                               /* State READ_TAG_NAME_END - entry_action empty */
                            this->curState = ST_readTagNameEnd;
                           }
                        else
                           {
                               /* State WAIT_TAG_NAME_END - exit_action empty */
                               /* Transition from WAIT_TAG_NAME_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagStart:    /* WAIT_TAG_START */
                        if (ch==L'<') /* Guard: ['<'] */
                           {
                               /* State WAIT_TAG_START - exit_action empty */
                               /* Transition from WAIT_TAG_START to WAIT_TAG_NAME actions */
                               { callText(); }
                               /* State WAIT_TAG_NAME - entry_action empty */
                            this->curState = ST_waitTagName;
                           }
                        else
                           {
                               /* State WAIT_TAG_START - exit_action empty */
                               /* Transition from WAIT_TAG_START to WAIT_TAG_START actions */
                               { storeChar(ch); }
                               /* State WAIT_TAG_START - entry_action empty */
                            this->curState = ST_waitTagStart;
                           }
                     break;
                case ST_waitTagStart0:    /* WAIT_TAG_START0 */
                        if ((isSpace(ch))) /* Guard: [(isSpace(GUARDVAR))] */
                           {
                               /* State WAIT_TAG_START0 - exit_action empty */
                               /* Transition from WAIT_TAG_START0 to WAIT_TAG_START0 actions */
                               /* State WAIT_TAG_START0 - entry_action empty */
                            this->curState = ST_waitTagStart0;
                           }
                        else if (ch==L'<') /* Guard: ['<'] */
                           {
                               /* State WAIT_TAG_START0 - exit_action empty */
                               /* Transition from WAIT_TAG_START0 to WAIT_TAG_NAME actions */
                               { startDoc(); }
                               /* State WAIT_TAG_NAME - entry_action empty */
                            this->curState = ST_waitTagName;
                           }
                        else
                           {
                               /* State WAIT_TAG_START0 - exit_action empty */
                               /* Transition from WAIT_TAG_START0 to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
               };

           }

    public:     
        void
        eod
           ( 
           )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_cDATA:    /* CDATA */
                                       {
                               /* State CDATA - exit_action empty */
                               /* Transition from CDATA to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA1:    /* CDATA1 */
                                       {
                               /* State CDATA1 - exit_action empty */
                               /* Transition from CDATA1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA2:    /* CDATA2 */
                                       {
                               /* State CDATA2 - exit_action empty */
                               /* Transition from CDATA2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA3:    /* CDATA3 */
                                       {
                               /* State CDATA3 - exit_action empty */
                               /* Transition from CDATA3 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA4:    /* CDATA4 */
                                       {
                               /* State CDATA4 - exit_action empty */
                               /* Transition from CDATA4 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA5:    /* CDATA5 */
                                       {
                               /* State CDATA5 - exit_action empty */
                               /* Transition from CDATA5 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATA6:    /* CDATA6 */
                                       {
                               /* State CDATA6 - exit_action empty */
                               /* Transition from CDATA6 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATAE1:    /* CDATAE1 */
                                       {
                               /* State CDATAE1 - exit_action empty */
                               /* Transition from CDATAE1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cDATAE2:    /* CDATAE2 */
                                       {
                               /* State CDATAE2 - exit_action empty */
                               /* Transition from CDATAE2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENT:    /* COMMENT */
                                       {
                               /* State COMMENT - exit_action empty */
                               /* Transition from COMMENT to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENT1:    /* COMMENT1 */
                                       {
                               /* State COMMENT1 - exit_action empty */
                               /* Transition from COMMENT1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENT2:    /* COMMENT2 */
                                       {
                               /* State COMMENT2 - exit_action empty */
                               /* Transition from COMMENT2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENTE1:    /* COMMENTE1 */
                                       {
                               /* State COMMENTE1 - exit_action empty */
                               /* Transition from COMMENTE1 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_cOMMENTE2:    /* COMMENTE2 */
                                       {
                               /* State COMMENTE2 - exit_action empty */
                               /* Transition from COMMENTE2 to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_readAttrName:    /* READ_ATTR_NAME */
                                       {
                               /* State READ_ATTR_NAME - exit_action empty */
                               /* Transition from READ_ATTR_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readAvapos:    /* READ_AVAPOS */
                                       {
                               /* State READ_AVAPOS - exit_action empty */
                               /* Transition from READ_AVAPOS to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_readAvquot:    /* READ_AVQUOT */
                                       {
                               /* State READ_AVQUOT - exit_action empty */
                               /* Transition from READ_AVQUOT to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_readAvUnquot:    /* READ_AV_UNQUOT */
                                       {
                               /* State READ_AV_UNQUOT - exit_action empty */
                               /* Transition from READ_AV_UNQUOT to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_readDtd:    /* READ_DTD */
                                       {
                               /* State READ_DTD - exit_action empty */
                               /* Transition from READ_DTD to E_FAIL3 actions */
                               /* End state E_FAIL3 - entry_action empty */
                            this->curState = ST_eFail3;
                           }
                     break;
                case ST_readPi:    /* READ_PI */
                                       {
                               /* State READ_PI - exit_action empty */
                               /* Transition from READ_PI to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagName:    /* READ_TAG_NAME */
                                       {
                               /* State READ_TAG_NAME - exit_action empty */
                               /* Transition from READ_TAG_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagNameEnd:    /* READ_TAG_NAME_END */
                                       {
                               /* State READ_TAG_NAME_END - exit_action empty */
                               /* Transition from READ_TAG_NAME_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_readTagNameEndSpaces:    /* READ_TAG_NAME_END_SPACES */
                                       {
                               /* State READ_TAG_NAME_END_SPACES - exit_action empty */
                               /* Transition from READ_TAG_NAME_END_SPACES to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_tagAloneEnd:    /* TAG_ALONE_END */
                                       {
                               /* State TAG_ALONE_END - exit_action empty */
                               /* Transition from TAG_ALONE_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_tagAloneEnd2:    /* TAG_ALONE_END2 */
                                       {
                               /* State TAG_ALONE_END2 - exit_action empty */
                               /* Transition from TAG_ALONE_END2 to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitAttrName:    /* WAIT_ATTR_NAME */
                                       {
                               /* State WAIT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_ATTR_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitAttrVal:    /* WAIT_ATTR_VAL */
                                       {
                               /* State WAIT_ATTR_VAL - exit_action empty */
                               /* Transition from WAIT_ATTR_VAL to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitEq:    /* WAIT_EQ */
                                       {
                               /* State WAIT_EQ - exit_action empty */
                               /* Transition from WAIT_EQ to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitNextAttrName:    /* WAIT_NEXT_ATTR_NAME */
                                       {
                               /* State WAIT_NEXT_ATTR_NAME - exit_action empty */
                               /* Transition from WAIT_NEXT_ATTR_NAME to E_FAIL2 actions */
                               /* End state E_FAIL2 - entry_action empty */
                            this->curState = ST_eFail2;
                           }
                     break;
                case ST_waitPiEnd:    /* WAIT_PI_END */
                                       {
                               /* State WAIT_PI_END - exit_action empty */
                               /* Transition from WAIT_PI_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagName:    /* WAIT_TAG_NAME */
                                       {
                               /* State WAIT_TAG_NAME - exit_action empty */
                               /* Transition from WAIT_TAG_NAME to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagNameEnd:    /* WAIT_TAG_NAME_END */
                                       {
                               /* State WAIT_TAG_NAME_END - exit_action empty */
                               /* Transition from WAIT_TAG_NAME_END to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
                case ST_waitTagStart:    /* WAIT_TAG_START */
                                       {
                               /* State WAIT_TAG_START - exit_action empty */
                               /* Transition from WAIT_TAG_START to E_OK actions */
                               { endDoc(); }
                               /* End state E_OK - entry_action empty */
                            this->curState = ST_eOk;
                           }
                     break;
                case ST_waitTagStart0:    /* WAIT_TAG_START0 */
                                       {
                               /* State WAIT_TAG_START0 - exit_action empty */
                               /* Transition from WAIT_TAG_START0 to E_FAIL actions */
                               /* End state E_FAIL - entry_action empty */
                            this->curState = ST_eFail;
                           }
                     break;
               };

           }

    protected:  
        virtual
        void
        storeChar
                 ( const char  ch          
                 ) = 0;

    protected:  
        virtual
        void
        clrBuf
              ( 
              ) = 0;

    protected:  
        virtual
        void
        callText
                ( 
                ) = 0;

    protected:  
        virtual
        void
        startDoc
                ( 
                ) = 0;

    protected:  
        virtual
        void
        endDoc
              ( 
              ) = 0;

    protected:  
        virtual
        void
        startElem
                 ( 
                 ) = 0;

    protected:  
        virtual
        void
        singleElem
                  ( 
                  ) = 0;

    protected:  
        virtual
        void
        endElem
               ( 
               ) = 0;

    protected:  
        virtual
        void
        callPi
              ( 
              ) = 0;

    protected:  
        virtual
        void
        callAttr
                ( 
                ) = 0;

    protected:  
        virtual
        void
        callAttrVal
                   ( 
                   ) = 0;

    protected:  
        unsigned
        isLatinAlpha
                    ( char  ch          
                    )
           {
            if (ch>='a' && ch<='z') return 1;
            if (ch>='A' && ch<='Z') return 1;
            return 0;
           }

    protected:  
        virtual
        unsigned
        isTagStartChar
                      ( const char  ch          
                      )
           {
            if (isLatinAlpha(ch)) return 1;
            if (ch=='_' || ch==':') return 1;
            return 0;
           }

    protected:  
        virtual
        unsigned
        isTagChar
                 ( const char  ch          
                 )
           {
            if (isLatinAlpha(ch)) return 1;
            if (ch>='0' && ch<='9') return 1;
            if (ch=='_' || ch==':') return 1;
            if (ch=='.' || ch=='-') return 1;
            return 0;
           }

    protected:  
        virtual
        unsigned
        isAttrStartChar
                       ( const char  ch          
                       )
           {
            return isTagStartChar(ch);
           }

    protected:  
        virtual
        unsigned
        isAttrChar
                  ( const char  ch          
                  )
           {
            return isTagChar(ch);
           }

    protected:  
        unsigned
        isSpace
               ( const char  ch          
               )
           {
            return ch==' ' || ch=='\r' || ch=='\n' || ch=='\t';
           }

    protected:  
        virtual
        void
        callComment
                   ( 
                   ) = 0;

    protected:  
        virtual
        void
        callCdata
                 ( 
                 ) = 0;

    protected:  
        virtual
        void
        attrEnd
               ( 
               ) = 0;

    protected:  
        virtual
        void
        callSpace
                 ( 
                 ) = 0;

    protected:  
        virtual
        void
        callDTD
               ( 
               ) = 0;

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->customResetAutomata(  );
            this->curState = ST_waitTagStart0;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return 0;
           }


};


}; // namespace sax {
}; // namespace cli {

#endif /* REL_ASAX_AUTOMATA_H */
