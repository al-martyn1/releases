#ifndef CLI_ISTRAPI_H
#define CLI_ISTRAPI_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/istrapi.h>", CLI_ISTRAPI_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_ISTRAPI_H
    #include <cli/istrapi.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::stringHelper */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifndef INTERFACE_CLI_STRINGHELPER_IID
    #define INTERFACE_CLI_STRINGHELPER_IID    "/cli/stringHelper"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE stringHelper
    #ifndef INTERFACE_CLI_STRINGHELPER
       #define INTERFACE_CLI_STRINGHELPER    ::cli::stringHelper
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_stringHelper
    #ifndef INTERFACE_CLI_STRINGHELPER
       #define INTERFACE_CLI_STRINGHELPER    cli_stringHelper
    #endif
#endif

        CLI_DECLARE_INTERFACE(INTERFACE)
        {
            
            /* interface ::cli::stringHelper methods */
            CLIMETHOD_(SIZE_T, size) (THIS_ const CLISTR*     cliStr) PURE;
            CLIMETHOD_(CONST_PWCHAR, c_str) (THIS_ const CLISTR*     cliStr) PURE;
            CLIMETHOD_(CONST_PWCHAR, data) (THIS_ const CLISTR*     cliStr) PURE;
            CLIMETHOD(alloc) (THIS_ CLISTR*           cliStr
                                  , const WCHAR*    str /* [in,flat] wchar  str[]  */
                             ) PURE;
            CLIMETHOD(allocLen) (THIS_ CLISTR*           cliStr
                                     , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                     , SIZE_T    strLen /* [in] size_t  strLen  */
                                ) PURE;
            CLIMETHOD(free) (THIS_ CLISTR*           cliStr) PURE;
            CLIMETHOD(assign) (THIS_ CLISTR*           cliStr
                                   , const WCHAR*    str /* [in,flat] wchar  str[]  */
                              ) PURE;
            CLIMETHOD(assignLen) (THIS_ CLISTR*           cliStr
                                      , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                      , SIZE_T    strLen /* [in] size_t  strLen  */
                                 ) PURE;
            CLIMETHOD(append) (THIS_ CLISTR*           cliStr
                                   , const WCHAR*    str /* [in,flat] wchar  str[]  */
                              ) PURE;
            CLIMETHOD(appendLen) (THIS_ CLISTR*           cliStr
                                      , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                      , SIZE_T    strLen /* [in] size_t  strLen  */
                                 ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::cstringHelper */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifndef INTERFACE_CLI_CSTRINGHELPER_IID
    #define INTERFACE_CLI_CSTRINGHELPER_IID    "/cli/cstringHelper"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE cstringHelper
    #ifndef INTERFACE_CLI_CSTRINGHELPER
       #define INTERFACE_CLI_CSTRINGHELPER    ::cli::cstringHelper
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_cstringHelper
    #ifndef INTERFACE_CLI_CSTRINGHELPER
       #define INTERFACE_CLI_CSTRINGHELPER    cli_cstringHelper
    #endif
#endif

        CLI_DECLARE_INTERFACE(INTERFACE)
        {
            
            /* interface ::cli::cstringHelper methods */
            CLIMETHOD_(SIZE_T, size) (THIS_ const CLICSTR*    cliStr) PURE;
            CLIMETHOD_(CONST_PCHAR, c_str) (THIS_ const CLICSTR*    cliStr) PURE;
            CLIMETHOD_(CONST_PCHAR, data) (THIS_ const CLICSTR*    cliStr) PURE;
            CLIMETHOD(alloc) (THIS_ CLICSTR*          cliStr
                                  , const CHAR*    str /* [in,flat] char  str[]  */
                             ) PURE;
            CLIMETHOD(allocLen) (THIS_ CLICSTR*          cliStr
                                     , const CHAR*    str /* [in,flat] char  str[]  */
                                     , SIZE_T    strLen /* [in] size_t  strLen  */
                                ) PURE;
            CLIMETHOD(free) (THIS_ CLICSTR*          cliStr) PURE;
            CLIMETHOD(assign) (THIS_ CLICSTR*          cliStr
                                   , const CHAR*    str /* [in,flat] char  str[]  */
                              ) PURE;
            CLIMETHOD(assignLen) (THIS_ CLICSTR*          cliStr
                                      , const CHAR*    str /* [in,flat] char  str[]  */
                                      , SIZE_T    strLen /* [in] size_t  strLen  */
                                 ) PURE;
            CLIMETHOD(append) (THIS_ CLICSTR*          cliStr
                                   , const CHAR*    str /* [in,flat] char  str[]  */
                              ) PURE;
            CLIMETHOD(appendLen) (THIS_ CLICSTR*          cliStr
                                      , const CHAR*    str /* [in,flat] char  str[]  */
                                      , SIZE_T    strLen /* [in] size_t  strLen  */
                                 ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::pstringHelper */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifndef INTERFACE_CLI_PSTRINGHELPER_IID
    #define INTERFACE_CLI_PSTRINGHELPER_IID    "/cli/pstringHelper"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE pstringHelper
    #ifndef INTERFACE_CLI_PSTRINGHELPER
       #define INTERFACE_CLI_PSTRINGHELPER    ::cli::pstringHelper
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_pstringHelper
    #ifndef INTERFACE_CLI_PSTRINGHELPER
       #define INTERFACE_CLI_PSTRINGHELPER    cli_pstringHelper
    #endif
#endif

        CLI_DECLARE_INTERFACE(INTERFACE)
        {
            
            /* interface ::cli::pstringHelper methods */
            CLIMETHOD_(SIZE_T, size) (THIS_ CLIPSTR           cliStr) PURE;
            CLIMETHOD_(CONST_PWCHAR, c_str) (THIS_ CLIPSTR           cliStr) PURE;
            CLIMETHOD_(CONST_PWCHAR, data) (THIS_ CLIPSTR           cliStr) PURE;
            CLIMETHOD(alloc) (THIS_ CLIPSTR*          cliStr
                                  , const WCHAR*    str /* [in,flat] wchar  str[]  */
                             ) PURE;
            CLIMETHOD(allocLen) (THIS_ CLIPSTR*          cliStr
                                     , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                     , SIZE_T    strLen /* [in] size_t  strLen  */
                                ) PURE;
            CLIMETHOD(free) (THIS_ CLIPSTR*          cliStr) PURE;
            CLIMETHOD(assign) (THIS_ CLIPSTR*          cliStr
                                   , const WCHAR*    str /* [in,flat] wchar  str[]  */
                              ) PURE;
            CLIMETHOD(assignLen) (THIS_ CLIPSTR*          cliStr
                                      , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                      , SIZE_T    strLen /* [in] size_t  strLen  */
                                 ) PURE;
            CLIMETHOD(append) (THIS_ CLIPSTR*          cliStr
                                   , const WCHAR*    str /* [in,flat] wchar  str[]  */
                              ) PURE;
            CLIMETHOD(appendLen) (THIS_ CLIPSTR*          cliStr
                                      , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                      , SIZE_T    strLen /* [in] size_t  strLen  */
                                 ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::pcstringHelper */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifndef INTERFACE_CLI_PCSTRINGHELPER_IID
    #define INTERFACE_CLI_PCSTRINGHELPER_IID    "/cli/pcstringHelper"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE pcstringHelper
    #ifndef INTERFACE_CLI_PCSTRINGHELPER
       #define INTERFACE_CLI_PCSTRINGHELPER    ::cli::pcstringHelper
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_pcstringHelper
    #ifndef INTERFACE_CLI_PCSTRINGHELPER
       #define INTERFACE_CLI_PCSTRINGHELPER    cli_pcstringHelper
    #endif
#endif

        CLI_DECLARE_INTERFACE(INTERFACE)
        {
            
            /* interface ::cli::pcstringHelper methods */
            CLIMETHOD_(SIZE_T, size) (THIS_ CLIPCSTR          cliStr) PURE;
            CLIMETHOD_(CONST_PCHAR, c_str) (THIS_ CLIPCSTR          cliStr) PURE;
            CLIMETHOD_(CONST_PCHAR, data) (THIS_ CLIPCSTR          cliStr) PURE;
            CLIMETHOD(alloc) (THIS_ CLIPCSTR*         cliStr
                                  , const CHAR*    str /* [in,flat] char  str[]  */
                             ) PURE;
            CLIMETHOD(allocLen) (THIS_ CLIPCSTR*         cliStr
                                     , const CHAR*    str /* [in,flat] char  str[]  */
                                     , SIZE_T    strLen /* [in] size_t  strLen  */
                                ) PURE;
            CLIMETHOD(free) (THIS_ CLIPCSTR*         cliStr) PURE;
            CLIMETHOD(assign) (THIS_ CLIPCSTR*         cliStr
                                   , const CHAR*    str /* [in,flat] char  str[]  */
                              ) PURE;
            CLIMETHOD(assignLen) (THIS_ CLIPCSTR*         cliStr
                                      , const CHAR*    str /* [in,flat] char  str[]  */
                                      , SIZE_T    strLen /* [in] size_t  strLen  */
                                 ) PURE;
            CLIMETHOD(append) (THIS_ CLIPCSTR*         cliStr
                                   , const CHAR*    str /* [in,flat] char  str[]  */
                              ) PURE;
            CLIMETHOD(appendLen) (THIS_ CLIPCSTR*         cliStr
                                      , const CHAR*    str /* [in,flat] char  str[]  */
                                      , SIZE_T    strLen /* [in] size_t  strLen  */
                                 ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif





#endif /* CLI_ISTRAPI_H */
