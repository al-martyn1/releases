#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLIEXCEPT_H
#define CLI_CLIEXCEPT_H

/* Add next lines to your C/C++ code
#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif
*/

#ifdef __cplusplus

#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#if !defined(_TYPEINFO_) && !defined(_TYPEINFO) && !defined(__TYPEINFO__) && !defined(_STLP_TYPEINFO)
    #include <typeinfo>
#endif


#ifndef CLI_IERRINFO_H
    #include <cli/ierrinfo.h>
#endif

#ifndef CLI_CLIMOD_H
    #include <cli/climod.h>
#endif


#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#ifndef CLI_MESSAGES_H
    #include <cli/messages.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef CLI_CLIGUI_H
    #include <cli/cligui.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#include <marty/utf.h>



#if !defined(CLI_MONOLITHIC) && !defined(TARGET_TYPE_EXE) && !defined(NOT_CLI_MODULE)
    #ifndef USE_CLI_MODULE
        #define USE_CLI_MODULE
    #endif
#else
#endif

#ifdef USE_CLI_MODULE
    extern ::cli::CModule cliModule;
#endif




namespace cli
{

class CException : public ::std::exception
{
    protected:

        mutable ::cli::CiErrorInfo    errInfo;
        mutable ::std::wstring        msgTextWide;
        mutable ::std::string         msgTextStr;

    public:

        // � ����������� �� ������-����������
        // �������� ����� ������������� ���������� �� ������, ��������� ����� cliGetErrorInfo
        // � ������� ��������� ���������� �� ������
        CException( bool getSysErrInfo = true, bool clearSysErrInfo = true)
           : ::std::exception()
           , errInfo()
           , msgTextWide(), msgTextStr()
           {
            if (getSysErrInfo)
               {
                :: cliGetErrorInfo( errInfo.getPP() );
                if (clearSysErrInfo)
                   {
                    :: cliClearErrorInfo();
                   }
               }
           }

        CException(const CException &ex)
           : ::std::exception(ex)
           , errInfo(ex.errInfo)
           , msgTextWide(), msgTextStr()
           {
           }

        CException( INTERFACE_CLI_IERRORINFO* pei)
           : ::std::exception()
           , errInfo(pei)
           , msgTextWide(), msgTextStr()
           {
           }

        CException& operator=(const CException &ex)
           {
            if (&ex==this) return *this;
            ::std::exception::operator=(ex);
            errInfo = ex.errInfo;
            return *this;
           }

        #if defined(WIN32) || defined(_WIN32)
            #if defined(_MSC_VER)
                virtual __CLR_OR_THIS_CALL ~CException() _THROW0()
            #elif defined(__GNUC__)
                ~CException() throw()
            #else
                #error "Unsupported compiler"
            #endif
        #else // POSIX/*nix
            #if defined(__GNUC__)
                ~CException() throw()
            #else
                #error "Unsupported compiler"
            #endif
        #endif
           {
           }


    protected:

        INTERFACE_CLI_IERRORINFO* createErrorInfo( RCODE err
                                                 , const char *srcFileName        = 0
                                                 , UINT  srcFileLine              = 0
                                                 , INTERFACE_CLI_IARGLIST* args   = 0
                                                 )
           {
            INTERFACE_CLI_IERRORINFO *pei = 0; INTERFACE_CLI_ICREATEERRORINFO *pCreateInfo = 0;

            ::cliCreateErrorInfo( &pei, &pCreateInfo );
            if (!pCreateInfo) { if (pei) pei->release(); return 0; }

            pCreateInfo->setErrorCode(err);

            if (args)
               pCreateInfo->setArgList(args);

            using MARTY_CON_NS a2wide;

            #ifdef MBS_PROJECT_NAME
            const char *moduleInternalName = MBS_PROJECT_NAME;
            ::std::wstring wModuleInternalName = a2wide(moduleInternalName);
            pCreateInfo->setModuleInternalNameChars(wModuleInternalName.data(), wModuleInternalName.size() );
            #endif

            #ifdef USE_CLI_MODULE
            pCreateInfo->setModuleFileNameChars(cliModule.getFileName(), SIZE_T_NPOS );
            #endif

            if (srcFileName)
               {
                ::std::wstring srcFile = a2wide(srcFileName);
                pCreateInfo->setSourceFileLineChars( srcFile.data(), srcFile.size(), srcFileLine );
               }

            pCreateInfo->release();
            return pei;
           }

    public:

        // ��������� ����� ������ errInfo �� ���� ������ � ��������� ����������
        // ��� ������������ ��� �������������
        // ���� � �������������� ����� �� ��� ������, �� �������, ��� ��� ��� � ����, ����� ������ �������
        CException( bool tryUseAllreadySettedInfo
                  , RCODE err
                  , const char *srcFileName        = 0
                  , UINT  srcFileLine              = 0
                  , INTERFACE_CLI_IARGLIST* args   = 0
                  )
           : ::std::exception()
           , errInfo()
           , msgTextWide(), msgTextStr()
           {
            if (tryUseAllreadySettedInfo)
               {
                INTERFACE_CLI_IERRORINFO *pSysErrInfo = 0;
                :: cliGetErrorInfo( &pSysErrInfo );
                if (pSysErrInfo)
                   {
                    if (pSysErrInfo->getErrorCode( )==err)
                       {
                        errInfo = ::cli::CiErrorInfo(pSysErrInfo);
                        pSysErrInfo->release();
                        return; // ���������� ��������� errInfo
                       }
                    //pSysErrInfo->release(); // ����������
                    //pSysErrInfo = 0;
                    INTERFACE_CLI_IERRORINFO* pNewErrInfo = createErrorInfo( err, srcFileName, srcFileLine, args );
                    :: cliClearErrorInfo(); // ���������� ��������� errInfo,�� ���� ��� �������� � pSysErrInfo
                    pNewErrInfo->chainErrorInfo(pSysErrInfo);
                    pSysErrInfo->release(); // ���������� ����� ���������� ���������
                    errInfo = ::cli::CiErrorInfo(pNewErrInfo);
                    pNewErrInfo->release();
                    return;
                   }
                // ��������� ���������� ���
               }

            // ��������� ���������� ���
            // ��� �� ������������� �� ���������
            INTERFACE_CLI_IERRORINFO* pNewErrInfo = createErrorInfo( err, srcFileName, srcFileLine, args );
            errInfo = ::cli::CiErrorInfo(pNewErrInfo);
            pNewErrInfo->release();
           }


        CException( RCODE err
                  , const char *srcFileName        = 0
                  , UINT  srcFileLine              = 0
                  , INTERFACE_CLI_IARGLIST* args   = 0
                  )
           : ::std::exception()
           , errInfo()
           , msgTextWide(), msgTextStr()
           { // ��������� ���������� �� �������, ������� ����
            INTERFACE_CLI_IERRORINFO* pNewErrInfo = createErrorInfo( err, srcFileName, srcFileLine, args );
            errInfo = ::cli::CiErrorInfo(pNewErrInfo);
            pNewErrInfo->release();
           }

    protected:

        ::std::wstring printErrorInfoAux( INTERFACE_CLI_IERRORINFO* pi
                                        , SIZE_T chainIndent = 0
                                        , ENUM_CLI_GUI_ERRORDIALOGFLAGS flags = 0
                                        ) const
           {
            flags &= ~(CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE|CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE|CLI_GUI_ERRORDIALOGFLAGS_SOURCEAUTO);
            #ifdef _DEBUG
            flags |= CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE;
            //flags |= CLI_GUI_ERRORDIALOGFLAGS_SOURCEAUTO;
            //flags |= CLI_GUI_ERRORDIALOGFLAGS_SOURCEDBLCLICKOPEN;
            #else
            flags |= CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE;
            #endif

            /*
            if (flags&CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE)
               flags &= ~CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE;

            if (  flags&CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE
               || flags&CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE
               )
               { // forced show or hide
               }
            else if (flags&CLI_GUI_ERRORDIALOGFLAGS_SOURCEAUTO)
               {
                #ifdef _DEBUG
                flags |= CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE;
                flags &= ~CLI_GUI_ERRORDIALOGFLAGS_HIDEMESSAGEDATA;
                #else
                flags &= ~CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE;
                flags |= CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE;
                flags |= CLI_GUI_ERRORDIALOGFLAGS_HIDEMESSAGEDATA;
                #endif
               }
            */
            ::std::wstring str;
            ::std::wstring indent;
            ::cli::CiErrorInfo ie(pi);
            while(!!ie)
               {
                RCODE code = ie.getErrorCode( );

                ::std::wstring moduleName;
                ie.getModuleName( moduleName );

                ::std::wstring srcFile; UINT srcLine = 0;
                ie.getSourceFileLine( srcFile, &srcLine );

                INTERFACE_CLI_IARGLIST* arglist = 0;
                ie.getArgList( &arglist );
                if (arglist) arglist->addRef();

                str.append(indent);

                switch(code&EC_SOURCE_MASK)
                   {
                    case EC_SOURCE_CLI:
                            str.append( ::cli::format::message(L"%1!#08X!", ::cli::format::arg((UINT)code) ) );
                            break;
                    case EC_SOURCE_COM:
                            str.append( ::cli::format::message(L"%1!#08X! (HRESULT: %2!#08X!)", ::cli::format::arg((UINT)code) % (UINT)RC2HR(code) ) );
                            break;
                    case EC_SOURCE_WIN32:
                            str.append( ::cli::format::message(L"%1!#08X! (Win32: %2)", ::cli::format::arg((UINT)code) % (UINT)RC2WIN(code) ) );
                            break;
                    case EC_SOURCE_POSIX:
                            str.append( ::cli::format::message(L"%1!#08X! (Posix/Crt: %2)", ::cli::format::arg((UINT)code) % (INT)RC2POSIX(code) ) );
                            break;
                    //default:
                   }

                str.append( 1, L' ');
                str.append( ::cli::formatErrorMessage( (moduleName.empty() ? 0 : moduleName.c_str())
                                                     , code
                                                     , 0 // locale
                                                     , 0 // /* FMF_AUTO_APPEND_LF| */ FMF_IGNORE_FORMAT_LF
                                                     , ::cli::format::arg(arglist)
                                                     )
                          );



                str.append(L"\n");

                if (flags&CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE)
                   {
                    if (!srcFile.empty())
                       {
                        str.append(indent);
                        str.append( ::cli::format::messageEx( L"File: %1, line: %2"
                                                            , ::cli::format::arg(srcFile) % srcLine
                                                            , FMF_AUTO_APPEND_LF|FMF_IGNORE_FORMAT_LF
                                                            )
                                  );
                       }
                   }

                if (!(flags & CLI_GUI_ERRORDIALOGFLAGS_HIDEMESSAGEDATA))
                   {
                    if (arglist && arglist->getCount()>0)
                       {
                        SIZE_T maxArgs = arglist->getCount();
                        for(SIZE_T i=0; i<maxArgs; ++i )
                           {
                            CCliStr tmp_str; CCliStr_init( tmp_str );
                            arglist->getString( i , &tmp_str );
                            ::std::wstring dataStr;
                            CCliStr_copyFromIfModified( dataStr, tmp_str);

                            ::std::wstring fmtDataStr = ::cli::format::message(L"[%1] %2", ::cli::format::arg(int(i+1)) % dataStr );
                            str.append(indent);
                            str.append(fmtDataStr);
                            str.append(1, L'\n');
                           }
                       }
                   }

                if (arglist)
                   arglist->release();

                //indent.append(4, L' ');
                indent.append(chainIndent, L' ');

                INTERFACE_CLI_IERRORINFO* pTmp = 0;
                ie.getChainErrorInfo( &pTmp );
                if (pTmp) pTmp->release();
                ie = pTmp;
               }

            //cliWriteLogStringW( str.c_str() );
            return str;
           }

        static
        ::std::wstring
        makeErrorInfoXML1( ::cli::CiErrorInfo &ie
                         , const ::std::wstring &indent
                         )
           {
            RCODE code = ie.getErrorCode( );

            INTERFACE_CLI_IARGLIST* arglist = 0;
            ie.getArgList( &arglist );
            if (arglist) arglist->addRef();

            ::std::wstring srcFile; UINT srcLine = 0;
            ie.getSourceFileLine( srcFile, &srcLine );

            ::std::wstring moduleName;
            ie.getModuleName( moduleName );

            ::std::wstring msg = ::cli::formatErrorMessage( (moduleName.empty() ? 0 : moduleName.c_str())
                                                     , code
                                                     , 0 // locale
                                                     ,  /* FMF_AUTO_APPEND_LF| */ FMF_IGNORE_FORMAT_LF
                                                     , ::cli::format::arg(arglist)
                                                     );

            ::std::wstring res = ::cli::format::messageEx( L"%1<error code=\"%2\" src=\"%3\" native=\"%4\">\n"
                                                         L"%1    <message>%5</message>\n"
                                                         L"%1    <source file=\"%6\" line=\"%7\"/>\n"
                                                       , ::cli::format::arg(indent)
                                                         % ::cli::format::resultOnlyCode(code) % ::cli::format::resultCodeSource(code) % ::cli::format::resultCodeNative(code)
                                                         % msg % srcFile % srcLine
                                                       , FMF_AUTO_APPEND_LF|FMF_ALLOW_ASCII_CTRL_CHARS
                                                       );

            //::std::vector< ::std::wstring > argLines;

            if (arglist && arglist->getCount()>0)
               {
                res.append(indent);
                res.append(L"    <error-data>\n");
                SIZE_T maxArgs = arglist->getCount();
                for(SIZE_T i=0; i<maxArgs; ++i )
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    arglist->getString( i , &tmp_str );
                    ::std::wstring dataStr;
                    CCliStr_copyFromIfModified( dataStr, tmp_str);
                    WCHAR typeBuf[128];
                    SIZE_T typeBufSize = sizeof(typeBuf) / sizeof(typeBuf[0]);
                    arglist->getTypeStringChars( i, typeBuf, &typeBufSize );
                    ::std::wstring fmtDataStr = ::cli::format::messageEx( L"%3        <data index=\"%1\" type=\"%4\">%2</data>\n"
                                                                        , ::cli::format::arg(int(i+1)) % dataStr % indent % ::std::wstring(typeBuf)
                                                                        , FMF_AUTO_APPEND_LF|FMF_ALLOW_ASCII_CTRL_CHARS
                                                                        );
                    res.append(fmtDataStr);
                   }
                res.append(indent);
                res.append(L"    </error-data>\n");
               }

            if (arglist)
               arglist->release();

            return res;
           }


        static
        ::std::wstring
        makeErrorInfoXML( INTERFACE_CLI_IERRORINFO            *pei
                   )
           {
            ::std::wstring  resStr;
            //int idx = 0;
            ::cli::CiErrorInfo ie(pei);
            //bool bFirst = true;
            //::std::wstring closingTags;
            ::std::vector< ::std::wstring > closingTags;
            ::std::wstring indent;
            ::std::wstring res;

            while(!!ie)
               {
                res.append(
                           makeErrorInfoXML1( ie, indent )
                          );

                ::std::wstring str = indent;
                //closingTags.append(indent);
                str.append(L"</error>\n");
                closingTags.push_back(str);
                indent.append(8, L' ');
                //++idx;
                INTERFACE_CLI_IERRORINFO* pTmp = 0;
                ie.getChainErrorInfo( &pTmp );
                if (pTmp) pTmp->release();
                ie = pTmp;
               }

            ::std::vector< ::std::wstring >::const_reverse_iterator rit = closingTags.rbegin(), rend = closingTags.rend();
            //for(; rit!=closingTags.rend(); ++rit)
            for(; rit!=rend; ++rit)
               {
                res.append(*rit);
               }
            //res.append(closingTags);

            return res;
           }


    public:

        RCODE getCode() const
           {
            RCODE res = EC_UNKNOWN;
            if (!!errInfo) res = errInfo.getErrorCode( );
            return res;
           }

        RCODE setCliErrorInfo() const
           {
            ::cli::errinfo::clear();
            RCODE res = 0;
            if (!!errInfo) res = errInfo.getErrorCode( );
            ::cli::errinfo::chain(errInfo.getIfPtr());
            return res;
           }

        virtual
        ::std::string whatXml() const
           {
            ::std::wstring res(L"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<cli-error-info>\n");
            //INTERFACE_CLI_IERRORINFO *pSysErrInfo = 0;
            //::cliGetErrorInfo( &pSysErrInfo );
            //errInfo.getIfPtr();

            //INTERFACE_CLI_IERRORINFO**    errList
            //for( SIZE_T i=0; i!=errorInfosSize; ++i)
               {
                res.append(
                           makeErrorInfoXML(errInfo.getIfPtr())
                          );
               }

            res.append(L"</cli-error-info>");

            //::std::string utfStr = MARTY_UTF_NS toUtf8(res);
            return MARTY_UTF_NS toUtf8(res);
           }

        virtual
        const wchar_t* whatWide( size_t indent = 0) const
           {
            try{
                msgTextWide = printErrorInfoAux(errInfo.getIfPtr(), indent);
                return msgTextWide.c_str();
               }
            catch(...)
               {
                static const wchar_t *tmp = L"Exception occurs while formatting previous exception";
                return tmp;
               }
           }

        virtual
        const char* whatEx( bool bToConsole = false, size_t indent = 0 ) const
           {
            try{
                using MARTY_CON_NS str2con;
                using MARTY_CON_NS w2ansi;
                msgTextStr = (bToConsole ? str2con( whatWide(indent) ) : w2ansi(whatWide(indent)));
                return msgTextStr.c_str();
               }
            catch(...)
               {
                static const char *tmp = "Exception occurs while formatting previous exception";
                return tmp;
               }
           }

        /*
        // MinGW, GCC 3.3, 3.4, 4.1
        virtual const char*
        what() const throw();

        // MSC
        virtual const char *__CLR_OR_THIS_CALL what() const _THROW0()

        */

        #if defined(WIN32) || defined(_WIN32)
            #if defined(_MSC_VER)
                virtual const char *__CLR_OR_THIS_CALL what() const _THROW0()
            #elif defined(__GNUC__)
                virtual const char*
                what() const throw()
            #else
                #error "Unsupported compiler"
            #endif
        #else // POSIX/*nix
            #if defined(__GNUC__)
                virtual const char*
                what() const throw()
            #else
                #error "Unsupported compiler"
            #endif
        #endif
                   {
                    return whatEx( true, 0 );
                   }

        ENUM_CLI_GUI_DIALOGRESULT showInfoDialog( const std::wstring &caption = L""
                            , ENUM_CLI_GUI_ERRORDIALOGFLAGS flags = CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON | CLI_GUI_ERRORDIALOGFLAGS_SOURCEDBLCLICKOPEN
                            , WND_HANDLE parentWnd = 0
                            ) const
           {
            INTERFACE_CLI_IERRORINFO* errList[1];
            errList[0] = errInfo.getIfPtr();

            flags &= ~(CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE|CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE|CLI_GUI_ERRORDIALOGFLAGS_SOURCEAUTO);
            #ifdef _DEBUG
            flags |= CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE;
            //flags |= CLI_GUI_ERRORDIALOGFLAGS_SOURCEAUTO;
            //flags |= CLI_GUI_ERRORDIALOGFLAGS_SOURCEDBLCLICKOPEN;
            #else
            flags |= CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE;
            #endif

            ENUM_CLI_GUI_DIALOGRESULT res = CLI_GUI_DIALOGRESULT_FAILED;

            if (caption.empty())
               res = cliGuiErrorDialog( parentWnd, 0, 0, &errList[0], 1, flags, 0 );
            else
               res = cliGuiErrorDialog( parentWnd, caption.c_str(), caption.size(), &errList[0], 1 /* list len*/, flags, 0 /* locale */ );

            #if defined(WIN32) || defined(_WIN32)
            if (res==CLI_GUI_DIALOGRESULT_FAILED)
               {
                MessageBox( 0, _T("Gui Error Dialog component creation failed. Is windlg module compiled and linked properly?"), _T("Showing CLI error dialog failed, see cli log for details"), 0);
               }
            #endif
            return res;
           }

        void log2cli( SIZE_T chainIndent = 0 ) const
           {
            ::cli::errinfo::log( errInfo.getIfPtr(), chainIndent );
           }



}; // class CException



inline
RCODE createErrorInfoOnStdException( RCODE stdExceptionCode
                                   , const char *what
                                   , const char *srcFileName        = 0
                                   , UINT  srcFileLine              = 0
                                   )
   {
    INTERFACE_CLI_IERRORINFO *pei = 0; INTERFACE_CLI_ICREATEERRORINFO *pCreateInfo = 0;

    //RCODE createRes =
    ::cliCreateErrorInfo( &pei, &pCreateInfo );
    if (!pCreateInfo) { if (pei) pei->release(); return stdExceptionCode; }

    pCreateInfo->setErrorCode(stdExceptionCode);

    using MARTY_CON_NS a2wide;

    #ifdef MBS_PROJECT_NAME
    const char *moduleInternalName = MBS_PROJECT_NAME;
    ::std::wstring wModuleInternalName = a2wide(moduleInternalName);
    pCreateInfo->setModuleInternalNameChars(wModuleInternalName.data(), wModuleInternalName.size() );
    #endif

    #ifdef USE_CLI_MODULE
    pCreateInfo->setModuleFileNameChars(cliModule.getFileName(), SIZE_T_NPOS );
    #endif

    if (srcFileName)
       {
        ::std::wstring srcFile = a2wide(srcFileName);
        pCreateInfo->setSourceFileLineChars( srcFile.data(), srcFile.size(), srcFileLine );
       }
    else
       {

       }


    if (what)
       {
        INTERFACE_CLI_IARGLIST* argList = cliGetArgList( );
        if (argList)
           {
            argList->putStringChars( a2wide(what).c_str(), SIZE_T_NPOS );
            pCreateInfo->setArgList(argList);
           }
       }
    else
       {

       }

    pCreateInfo->release();
    cliChainErrorInfo(pei);
    pei->release();
    return stdExceptionCode;
   }






}; // namespace cli





/* �������-�������� ���������� */
#define CLI_THROW_EX_ARGS(code, className, args)         throw className( true /*tryUseSysInfo*/, code, __FILE__, __LINE__, args )
#define CLI_THROW_IF_FAIL_EX_ARGS(code, className, args) if (RC_FAIL(code)) CLI_THROW_EX_ARGS(code, className, args)
#define CLI_THROW_IF_NOK_EX_ARGS(code, className, args)  if (code) CLI_THROW_EX_ARGS(code, className, args)

#define CLI_THROW_EX(code, className)                    throw className( true /*tryUseSysInfo*/, code, __FILE__, __LINE__, 0 )
#define CLI_THROW_IF_FAIL_EX(code, className)            if (RC_FAIL(code)) CLI_THROW_EX(code, className)
#define CLI_THROW_IF_NOK_EX(code, className)             if (code) CLI_THROW_EX(code, className)

#define CLI_THROW_ARGS(code, args)                       CLI_THROW_EX_ARGS(code, ::cli::CException, args)
#define CLI_THROW_IF_FAIL_ARGS(code, args)               CLI_THROW_IF_FAIL_EX_ARGS(code, ::cli::CException, args)
#define CLI_THROW_IF_NOK_ARGS(code, args)                CLI_THROW_IF_NOK_EX_ARGS(code, ::cli::CException, args)

#define CLI_THROW(code)                                  CLI_THROW_EX(code, ::cli::CException)
#define CLI_THROW_IF_FAIL(code)                          CLI_THROW_IF_FAIL_EX(code, ::cli::CException)
#define CLI_THROW_IF_NOK(code)                           CLI_THROW_IF_NOK_EX(code, ::cli::CException)


namespace cli
{

// init cli runtime
inline
void init()
   {
    if (cliInit())
       {
        throw std::runtime_error("CLI initialization failed - possible not enough memory for components database. For monolithic configurations you must call cliInitMonolithic first and call registerModule for all used modules");
       }
   }

}; // namespace cli


/*
CLI_CATCH_RETURN_EX        - clear err info, set new and return
CLI_CATCH_CHAIN_RETURN_EX  - chain err info and return
CLI_CATCH_CHAIN_EX         - only chain err info
*/
/* ������������ ����������� ���������� - �������� errorInfo �� ���� ����������� ���������� */

#define CLI_CATCH_RETURN_EX( exceptType, retCode ) catch( const exceptType &e )                \
                                                      {                                        \
                                                       cliClearErrorInfo();                    \
                                                       return                                  \
                                                       ::cli::createErrorInfoOnStdException( retCode  \
                                                                                    , e.what() \
                                                                                    , __FILE__ \
                                                                                    , __LINE__ \
                                                                                    );         \
                                                      }

#define CLI_CATCH_CHAIN_RETURN_EX( exceptType, retCode ) catch( const exceptType &e )                \
                                                      {                                        \
                                                       return                                  \
                                                       ::cli::createErrorInfoOnStdException( retCode  \
                                                                                    , e.what() \
                                                                                    , __FILE__ \
                                                                                    , __LINE__ \
                                                                                    );         \
                                                      }

#define CLI_CATCH_CHAIN_EX( exceptType, retCode )  catch( const exceptType &e )                \
                                                      {                                        \
                                                       /* no return, ::cli::createErrorInfoOnStdException chains exception error info*/\
                                                       ::cli::createErrorInfoOnStdException( retCode  \
                                                                                    , e.what() \
                                                                                    , __FILE__ \
                                                                                    , __LINE__ \
                                                                                    );         \
                                                      }

#define CLI_CATCH_RETURN_UNKNOWN()                 catch(...)                                  \
                                                      {                                        \
                                                       cliClearErrorInfo();                    \
                                                       return                                  \
                                                       ::cli::createErrorInfoOnStdException( EC_CXX_UNKNOWN \
                                                                                    , 0 /* what */   \
                                                                                    , __FILE__ \
                                                                                    , __LINE__ \
                                                                                    );         \
                                                      }

#define CLI_CATCH_CHAIN_RETURN_UNKNOWN()           catch(...)                                  \
                                                      {                                        \
                                                       return                                  \
                                                       ::cli::createErrorInfoOnStdException( EC_CXX_UNKNOWN \
                                                                                    , 0 /* what */   \
                                                                                    , __FILE__ \
                                                                                    , __LINE__ \
                                                                                    );         \
                                                      }

#define CLI_CATCH_CHAIN_UNKNOWN()                  catch(...)                                  \
                                                      {                                        \
                                                        /* return */                                   \
                                                       ::cli::createErrorInfoOnStdException( EC_CXX_UNKNOWN \
                                                                                    , 0 /* what */   \
                                                                                    , __FILE__ \
                                                                                    , __LINE__ \
                                                                                    );         \
                                                      }

#define CLI_CATCH_RETURN_CLI_EXCEPTION()           catch( const ::cli::CException &e ) \
                                                      {                                \
                                                       cliClearErrorInfo();            \
                                                       return e.setCliErrorInfo();     \
                                                      }

#define CLI_CATCH_CHAIN_RETURN_CLI_EXCEPTION()     catch( const ::cli::CException &e ) \
                                                      {                                \
                                                       return e.setCliErrorInfo();     \
                                                      }

// this macros does not chain errInfo - its clear old errInfo and set new
#define CLI_CATCH_CHAIN_CLI_EXCEPTION()            catch( const ::cli::CException &e ) \
                                                      {                                \
                                                       /* no return */                 \
                                                       e.setCliErrorInfo();            \
                                                      }



#define CLI_CATCH_RETURN_EXCEPTION()         CLI_CATCH_RETURN_EX( ::std::exception, EC_CXX_EXCEPTION )
#define CLI_CATCH_CHAIN_RETURN_EXCEPTION()   CLI_CATCH_CHAIN_RETURN_EX( ::std::exception, EC_CXX_EXCEPTION )
#define CLI_CATCH_CHAIN_EXCEPTION()          CLI_CATCH_CHAIN_EX ( ::std::exception, EC_CXX_EXCEPTION )

#define CLI_CATCH_RETURN_BAD_ALLOC()         CLI_CATCH_RETURN_EX( ::std::bad_alloc , EC_CXX_BAD_ALLOC )
#define CLI_CATCH_CHAIN_RETURN_BAD_ALLOC()   CLI_CATCH_CHAIN_RETURN_EX( ::std::bad_alloc , EC_CXX_BAD_ALLOC )
#define CLI_CATCH_CHAIN_BAD_ALLOC()          CLI_CATCH_CHAIN_EX ( ::std::bad_alloc , EC_CXX_BAD_ALLOC )

#define CLI_CATCH_RETURN_BAD_EXCEPTION()     CLI_CATCH_RETURN_EX( ::std::bad_exception , EC_CXX_BAD_EXCEPTION )
#define CLI_CATCH_CHAIN_RETURN_BAD_EXCEPTION() CLI_CATCH_CHAIN_RETURN_EX( ::std::bad_exception , EC_CXX_BAD_EXCEPTION )
#define CLI_CATCH_CHAIN_BAD_EXCEPTION()      CLI_CATCH_CHAIN_EX ( ::std::bad_exception , EC_CXX_BAD_EXCEPTION )

#define CLI_CATCH_RETURN_IOS_BASE_FAILURE()  CLI_CATCH_RETURN_EX( ::std::ios_base::failure , EC_CXX_IOS_BASE_FAILURE )
#define CLI_CATCH_CHAIN_RETURN_IOS_BASE_FAILURE() CLI_CATCH_CHAIN_RETURN_EX( ::std::ios_base::failure , EC_CXX_IOS_BASE_FAILURE )
#define CLI_CATCH_CHAIN_IOS_BASE_FAILURE()   CLI_CATCH_CHAIN_EX ( ::std::ios_base::failure , EC_CXX_IOS_BASE_FAILURE )

#define CLI_CATCH_RETURN_BAD_TYPEID()        CLI_CATCH_RETURN_EX( ::std::bad_typeid , EC_CXX_BAD_TYPEID )
#define CLI_CATCH_CHAIN_RETURN_BAD_TYPEID()  CLI_CATCH_CHAIN_RETURN_EX( ::std::bad_typeid , EC_CXX_BAD_TYPEID )
#define CLI_CATCH_CHAIN_BAD_TYPEID()         CLI_CATCH_CHAIN_EX ( ::std::bad_typeid , EC_CXX_BAD_TYPEID )

#define CLI_CATCH_RETURN_BAD_CAST()          CLI_CATCH_RETURN_EX( ::std::bad_cast , EC_CXX_BAD_CAST )
#define CLI_CATCH_CHAIN_RETURN_BAD_CAST()    CLI_CATCH_CHAIN_RETURN_EX( ::std::bad_cast , EC_CXX_BAD_CAST )
#define CLI_CATCH_CHAIN_BAD_CAST()           CLI_CATCH_CHAIN_EX ( ::std::bad_cast , EC_CXX_BAD_CAST )

#define CLI_CATCH_RETURN_LOGIC_ERROR()       CLI_CATCH_RETURN_EX( ::std::logic_error , EC_CXX_LOGIC_ERROR )
#define CLI_CATCH_CHAIN_RETURN_LOGIC_ERROR() CLI_CATCH_CHAIN_RETURN_EX( ::std::logic_error , EC_CXX_LOGIC_ERROR )
#define CLI_CATCH_CHAIN_LOGIC_ERROR()        CLI_CATCH_CHAIN_EX ( ::std::logic_error , EC_CXX_LOGIC_ERROR )

#define CLI_CATCH_RETURN_LENGTH_ERROR()      CLI_CATCH_RETURN_EX( ::std::length_error , EC_CXX_LENGTH_ERROR )
#define CLI_CATCH_CHAIN_RETURN_LENGTH_ERROR() CLI_CATCH_CHAIN_RETURN_EX( ::std::length_error , EC_CXX_LENGTH_ERROR )
#define CLI_CATCH_CHAIN_LENGTH_ERROR()       CLI_CATCH_CHAIN_EX ( ::std::length_error , EC_CXX_LENGTH_ERROR )

#define CLI_CATCH_RETURN_DOMAIN_ERROR()      CLI_CATCH_RETURN_EX( ::std::domain_error , EC_CXX_DOMAIN_ERROR )
#define CLI_CATCH_CHAIN_RETURN_DOMAIN_ERROR() CLI_CATCH_CHAIN_RETURN_EX( ::std::domain_error , EC_CXX_DOMAIN_ERROR )
#define CLI_CATCH_CHAIN_DOMAIN_ERROR()       CLI_CATCH_CHAIN_EX ( ::std::domain_error , EC_CXX_DOMAIN_ERROR )

#define CLI_CATCH_RETURN_OUT_OF_RANGE()      CLI_CATCH_RETURN_EX( ::std::out_of_range , EC_CXX_OUT_OF_RANGE )
#define CLI_CATCH_CHAIN_RETURN_OUT_OF_RANGE() CLI_CATCH_CHAIN_RETURN_EX( ::std::out_of_range , EC_CXX_OUT_OF_RANGE )
#define CLI_CATCH_CHAIN_OUT_OF_RANGE()       CLI_CATCH_CHAIN_EX ( ::std::out_of_range , EC_CXX_OUT_OF_RANGE )

#define CLI_CATCH_RETURN_INVALID_ARGUMENT()  CLI_CATCH_RETURN_EX( ::std::invalid_argument , EC_CXX_INVALID_ARGUMENT )
#define CLI_CATCH_CHAIN_RETURN_INVALID_ARGUMENT() CLI_CATCH_CHAIN_RETURN_EX( ::std::invalid_argument , EC_CXX_INVALID_ARGUMENT )
#define CLI_CATCH_CHAIN_INVALID_ARGUMENT()   CLI_CATCH_CHAIN_EX ( ::std::invalid_argument , EC_CXX_INVALID_ARGUMENT )

#define CLI_CATCH_RETURN_RUNTIME_ERROR()     CLI_CATCH_RETURN_EX( ::std::runtime_error , EC_CXX_RUNTIME_ERROR )
#define CLI_CATCH_CHAIN_RETURN_RUNTIME_ERROR() CLI_CATCH_CHAIN_RETURN_EX( ::std::runtime_error , EC_CXX_RUNTIME_ERROR )
#define CLI_CATCH_CHAIN_RUNTIME_ERROR()      CLI_CATCH_CHAIN_EX ( ::std::runtime_error , EC_CXX_RUNTIME_ERROR )

#define CLI_CATCH_RETURN_RANGE_ERROR()       CLI_CATCH_RETURN_EX( ::std::range_error , EC_CXX_RANGE_ERROR )
#define CLI_CATCH_CHAIN_RETURN_RANGE_ERROR() CLI_CATCH_CHAIN_RETURN_EX( ::std::range_error , EC_CXX_RANGE_ERROR )
#define CLI_CATCH_CHAIN_RANGE_ERROR()        CLI_CATCH_CHAIN_EX ( ::std::range_error , EC_CXX_RANGE_ERROR )

#define CLI_CATCH_RETURN_OVERFLOW_ERROR()    CLI_CATCH_RETURN_EX( ::std::overflow_error , EC_CXX_OVERFLOW_ERROR )
#define CLI_CATCH_CHAIN_RETURN_OVERFLOW_ERROR() CLI_CATCH_CHAIN_RETURN_EX( ::std::overflow_error , EC_CXX_OVERFLOW_ERROR )
#define CLI_CATCH_CHAIN_OVERFLOW_ERROR()     CLI_CATCH_CHAIN_EX ( ::std::overflow_error , EC_CXX_OVERFLOW_ERROR )

#define CLI_CATCH_RETURN_UNDERFLOW_ERROR()   CLI_CATCH_RETURN_EX( ::std::underflow_error , EC_CXX_UNDERFLOW_ERROR )
#define CLI_CATCH_CHAIN_RETURN_UNDERFLOW_ERROR() CLI_CATCH_CHAIN_RETURN_EX( ::std::underflow_error , EC_CXX_UNDERFLOW_ERROR )
#define CLI_CATCH_CHAIN_UNDERFLOW_ERROR()    CLI_CATCH_CHAIN_EX ( ::std::underflow_error , EC_CXX_UNDERFLOW_ERROR )

// #define CLI_CATCH_RETURN_()   CLI_CATCH_RETURN_EX( ::std:: , EC_CXX_ )
// #define CLI_CATCH_CHAIN_()    CLI_CATCH_CHAIN_EX( ::std:: , EC_CXX_ )


#define CLI_CATCH_RETURN_STD_EXCEPTIONS()                    \
                         CLI_CATCH_RETURN_IOS_BASE_FAILURE() \
                         CLI_CATCH_RETURN_RANGE_ERROR()      \
                         CLI_CATCH_RETURN_OVERFLOW_ERROR()   \
                         CLI_CATCH_RETURN_UNDERFLOW_ERROR()  \
                         CLI_CATCH_RETURN_RUNTIME_ERROR()    \
                                                             \
                         CLI_CATCH_RETURN_INVALID_ARGUMENT() \
                         CLI_CATCH_RETURN_OUT_OF_RANGE()     \
                         CLI_CATCH_RETURN_DOMAIN_ERROR()     \
                         CLI_CATCH_RETURN_LENGTH_ERROR()     \
                         CLI_CATCH_RETURN_LOGIC_ERROR()      \
                                                             \
                         CLI_CATCH_RETURN_BAD_CAST()         \
                         CLI_CATCH_RETURN_BAD_TYPEID()       \
                         CLI_CATCH_RETURN_BAD_EXCEPTION()    \
                         CLI_CATCH_RETURN_BAD_ALLOC()        \
                         CLI_CATCH_RETURN_EXCEPTION()        \
                                                             \
                         CLI_CATCH_RETURN_UNKNOWN()


#define CLI_CATCH_CHAIN_RETURN_STD_EXCEPTIONS()                    \
                         CLI_CATCH_CHAIN_RETURN_IOS_BASE_FAILURE() \
                         CLI_CATCH_CHAIN_RETURN_RANGE_ERROR()      \
                         CLI_CATCH_CHAIN_RETURN_OVERFLOW_ERROR()   \
                         CLI_CATCH_CHAIN_RETURN_UNDERFLOW_ERROR()  \
                         CLI_CATCH_CHAIN_RETURN_RUNTIME_ERROR()    \
                                                             \
                         CLI_CATCH_CHAIN_RETURN_INVALID_ARGUMENT() \
                         CLI_CATCH_CHAIN_RETURN_OUT_OF_RANGE()     \
                         CLI_CATCH_CHAIN_RETURN_DOMAIN_ERROR()     \
                         CLI_CATCH_CHAIN_RETURN_LENGTH_ERROR()     \
                         CLI_CATCH_CHAIN_RETURN_LOGIC_ERROR()      \
                                                             \
                         CLI_CATCH_CHAIN_RETURN_BAD_CAST()         \
                         CLI_CATCH_CHAIN_RETURN_BAD_TYPEID()       \
                         CLI_CATCH_CHAIN_RETURN_BAD_EXCEPTION()    \
                         CLI_CATCH_CHAIN_RETURN_BAD_ALLOC()        \
                         CLI_CATCH_CHAIN_RETURN_EXCEPTION()        \
                                                             \
                         CLI_CATCH_CHAIN_RETURN_UNKNOWN()



#define CLI_CATCH_CHAIN_STD_EXCEPTIONS()                    \
                         CLI_CATCH_CHAIN_IOS_BASE_FAILURE() \
                         CLI_CATCH_CHAIN_RANGE_ERROR()      \
                         CLI_CATCH_CHAIN_OVERFLOW_ERROR()   \
                         CLI_CATCH_CHAIN_UNDERFLOW_ERROR()  \
                         CLI_CATCH_CHAIN_RUNTIME_ERROR()    \
                                                            \
                         CLI_CATCH_CHAIN_INVALID_ARGUMENT() \
                         CLI_CATCH_CHAIN_OUT_OF_RANGE()     \
                         CLI_CATCH_CHAIN_DOMAIN_ERROR()     \
                         CLI_CATCH_CHAIN_LENGTH_ERROR()     \
                         CLI_CATCH_CHAIN_LOGIC_ERROR()      \
                                                            \
                         CLI_CATCH_CHAIN_BAD_CAST()         \
                         CLI_CATCH_CHAIN_BAD_TYPEID()       \
                         CLI_CATCH_CHAIN_BAD_EXCEPTION()    \
                         CLI_CATCH_CHAIN_BAD_ALLOC()        \
                         CLI_CATCH_CHAIN_EXCEPTION()        \
                                                            \
                         CLI_CATCH_CHAIN_UNKNOWN()


#define CLI_ERRCLR_TRY   cliClearErrorInfo(); try
#define CLI_TRY          try

/*
    // usage
    // variant 1 - set exception info (not chain) and return
    CLI_TRY{
            // ...
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;

    // variant 2 - chain err info and return
    CLI_TRY{
            // when error occurs, code must manualy clear ErrInfo
           }
    CLI_CATCH_CHAIN_RETURN_CLI_EXCEPTION()
    CLI_CATCH_CHAIN_RETURN_STD_EXCEPTIONS()
    return EC_OK;

    // variant 3 - chain err info and continue execution
    CLI_TRY{
            // when error occurs, code must manualy clear ErrInfo
           }
    CLI_CATCH_CHAIN_CLI_EXCEPTION()
    CLI_CATCH_CHAIN_STD_EXCEPTIONS()

    // variant 3 - chain err info and continue execution
    CLI_ERRCLR_TRY{
            // code able not clear err info, it's allready clear
           }
    ...
*/



/* flags */
#define CLI_APP_DONT_REPORT_TO_CLI_LOG  0x0001
#define CLI_APP_REPORT_DIALOG           0x0002
#define CLI_APP_REPORT_TO_CONSOLE       0x0000


#define CLI_BEGIN_APP_CODE()                                                          \
                                                RCODE appExecutionResult = EC_UNKNOWN;\
                                                CLI_TRY{                              \
                                                        ::cli::init();


// resetResult set to 1 if you want to handle exceptions only
//             set to 0 if you want to handle return code
#define CLI_END_APP_CODE_EX2(howToCatchErrors, resetResult, stream )                                                         \
                                                        if (resetResult)                                                     \
                                                           appExecutionResult = EC_OK; /* execution normal flow ends here */ \
                                                        CLI_THROW_IF_FAIL(appExecutionResult);                               \
                                                        if (RC_SUCCESS(appExecutionResult)) appExecutionResult = EC_OK;      \
                                                       }                                         \
                                                CLI_CATCH_CHAIN_CLI_EXCEPTION()                  \
                                                CLI_CATCH_CHAIN_STD_EXCEPTIONS()                 \
                                                if (!appExecutionResult) return 0;               \
                                                                                                 \
                                                ::cli::CException except;                        \
                                                                                                 \
                                                if (!((howToCatchErrors) & CLI_APP_DONT_REPORT_TO_CLI_LOG))\
                                                   {                                             \
                                                    except.log2cli();                            \
                                                   }                                             \
                                                if ((howToCatchErrors) & CLI_APP_REPORT_DIALOG)    \
                                                   {                                             \
                                                    except.showInfoDialog();                     \
                                                   }                                             \
                                                else /* CLI_APP_REPORT_TO_CONSOLE */             \
                                                   {                                             \
                                                    stream <<except.what()<<"\n";            \
                                                   }                                             \
                                                                                                 \
                                                return except.getCode();

#define CLI_END_APP_CODE_EX(howToCatchErrors, resetResult )     CLI_END_APP_CODE_EX2(howToCatchErrors, resetResult, std::cerr )

#define CLI_END_APP_CODE(howToCatchErrors )    CLI_END_APP_CODE_EX(howToCatchErrors, 1 /* reset result code means */)


#define CLIMETHOD_IMPL_BEGIN()       CLI_TRY{ do {} while(0)
#define CLIMETHOD_IMPL_END_EX(code)  } CLI_CATCH_RETURN_CLI_EXCEPTION() CLI_CATCH_RETURN_STD_EXCEPTIONS() return code
#define CLIMETHOD_IMPL_END()         CLIMETHOD_IMPL_END_EX(EC_OK)


#define CLIMETHOD_IMPL_STRINGIZE_HLP(name)            #name
#define CLIMETHOD_IMPL_STRINGIZE(name)                CLIMETHOD_IMPL_STRINGIZE_HLP(name)

#define CLIMETHOD_IMPL_STRINGIZE_TO_WIDE_HLP2(name)    L##name
#define CLIMETHOD_IMPL_STRINGIZE_TO_WIDE_HLP1(name)    CLIMETHOD_IMPL_STRINGIZE_TO_WIDE_HLP2(name)
#define CLIMETHOD_IMPL_STRINGIZE_TO_WIDE(name)         CLIMETHOD_IMPL_STRINGIZE_TO_WIDE_HLP1(CLIMETHOD_IMPL_STRINGIZE(name))


#define CLIMETHOD_IMPL_THROW_ERROR( errCode )                         throw ::cli::CException( false, errCode, __FILE__, __LINE__ )
#define CLIMETHOD_IMPL_THROW_ERROR_ARGS( errCode, errArgs )           { using ::cli::format::arg; throw ::cli::CException( false, errCode, __FILE__, __LINE__, errArgs ); } do {} while(0)

#define CLIMETHOD_IMPL_THROW_PARAM_ERROR( argNo, argName, errCode )   throw ::cli::CException( false, errCode, __FILE__, __LINE__, ::cli::format::arg( argNo ) % CLIMETHOD_IMPL_STRINGIZE_TO_WIDE(argName) )

                                                                      // throw ::cli::CException( false, EC_INVALID_PARAM  , __FILE__, __LINE__, ::cli::format::arg( argNo ) % CLIMETHOD_IMPL_STRINGIZE_TO_WIDE(argName) )
#define CLIMETHOD_IMPL_THROW_INVALID_PARAM( argNo, argName )          CLIMETHOD_IMPL_THROW_PARAM_ERROR(argNo, argName, EC_INVALID_PARAM )
                                                                      //throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( argNo ) % CLIMETHOD_IMPL_STRINGIZE_TO_WIDE(argName) )
#define CLIMETHOD_IMPL_THROW_INVALID_OUT_PTR( argNo, argName )        CLIMETHOD_IMPL_THROW_PARAM_ERROR(argNo, argName, EC_INVALID_OUT_PTR )

#define CLIMETHOD_IMPL_THROW_OUT_OF_RANGE( argNo, argName )           CLIMETHOD_IMPL_THROW_PARAM_ERROR(argNo, argName, EC_OUT_OF_RANGE )

#define CLIMETHOD_IMPL_CHECK_PARAM( argNo, failCondition, argName )            if (failCondition) CLIMETHOD_IMPL_THROW_INVALID_PARAM( argNo, argName )

#define CLIMETHOD_IMPL_CHECK_PARAM_PTR_EX( argNo, inputPtrName, argName )      CLIMETHOD_IMPL_CHECK_PARAM( argNo, !inputPtrName, argName )
#define CLIMETHOD_IMPL_CHECK_PARAM_PTR( argNo, inputPtrName )                  CLIMETHOD_IMPL_CHECK_PARAM_PTR_EX( argNo, inputPtrName, inputPtrName )

#define CLIMETHOD_IMPL_CHECK_OUT_PTR( argNo, OutPtrName )                      if (!OutPtrName) CLIMETHOD_IMPL_THROW_INVALID_OUT_PTR( argNo, OutPtrName )

#define CLIMETHOD_IMPL_CHECK_PARAM_UNSIGNED_INDEX_RANGE( argNo, inputVar, maxVal )   if ((inputVar) >= (maxVal) ) CLIMETHOD_IMPL_THROW_OUT_OF_RANGE( argNo, inputVar )
                                                                                          // throw ::cli::CException( false, EC_OUT_OF_RANGE, __FILE__, __LINE__, ::cli::format::arg( argNo ) % CLIMETHOD_IMPL_STRINGIZE_TO_WIDE(inputVar) )
#define CLIMETHOD_IMPL_CHECK_PARAM_INDEX_RANGE( argNo, inputVar, maxVal )      CLIMETHOD_IMPL_CHECK_PARAM_UNSIGNED_INDEX_RANGE( argNo, inputVar, maxVal )

#define CLIMETHOD_IMPL_CHECK_PARAM_SIGNED_INDEX_RANGE( argNo, inputVar, minVal, maxVal )  if ((inputVar) < (minVal) || (inputVar) >= (maxVal) ) CLIMETHOD_IMPL_THROW_OUT_OF_RANGE( argNo, inputVar )
                                                                                          // throw ::cli::CException( false, EC_OUT_OF_RANGE, __FILE__, __LINE__, ::cli::format::arg( argNo ) % CLIMETHOD_IMPL_STRINGIZE_TO_WIDE(inputVar) )


#endif /* __cplusplus */


#endif /* CLI_CLIEXCEPT_H */

