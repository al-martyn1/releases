#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLI2CI_H
#define CLI_CLI2CI_H

/* Components information miscelaneous data structs and calls/
 */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

/*
#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif
*/


/*
#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif
*/

#ifndef CLICOMPONENTINFO_CONST_FIELD
    #define CLICOMPONENTINFO_CONST_FIELD const
#endif

#include <cli/pshpack8.h>
//#pragma message ("CCliComponentInfo declared")
typedef struct tag_CCliComponentInfo
{
    CLICOMPONENTINFO_CONST_FIELD CHAR *name;
    CLICOMPONENTINFO_CONST_FIELD CHAR *categories;   // (semi)colon separated list
    CLICOMPONENTINFO_CONST_FIELD CHAR *description;  // (semi)colon separated list

} CCliComponentInfo, *PCliComponentInfo;
#include <cli/poppack.h>



/* If ok, return pci pointer, 0 if enum ends */
/* Each module must export this fn */
#if !defined(CLI_MONOLITHIC) || defined(NEED_CLIENUMMODULECOMPONENTS_DECLARATION)
EXTERN_CLI
MODULE_ENTRY_FUNC
PCliComponentInfo
CLICALL
cliEnumModuleComponents(SIZE_T idx, PCliComponentInfo pci);
#endif

typedef
PCliComponentInfo
(CLICALL * cliEnumModuleComponentsProcT)(SIZE_T idx, PCliComponentInfo pci);

#ifndef CLIENUMMODULECOMPONENTSPROCNAME
    #define CLIENUMMODULECOMPONENTSPROCNAME "cliEnumModuleComponents"
#endif

#include <cli/pshpack8.h>
//#pragma message ("CCliComponentCreationInfo declared")
typedef struct tag_CCliComponentCreationInfo
{
    CCliComponentInfo         info;
    genericObjFactoryProc     factoryProc;

} CCliComponentCreationInfo, *PCliComponentCreationInfo;
#include <cli/poppack.h>


//#ifdef INIT_MODULE_IMPL
//genericObjFactory


#include <cli/pshpack8.h>
//#pragma message ("CCliComponentCreationInfo declared")
typedef struct tag_CCliModuleComponentInfo
{
    CCliComponentInfo        info;
    cli_create_proc_t        cli_create;         // module entry
    cli_can_unload_proc_t    cli_can_unload;     // module entry

} CCliModuleComponentInfo, *PCliModuleComponentInfo;
#include <cli/poppack.h>







#endif /* CLI_CLI2CI_H */

