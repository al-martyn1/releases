#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DATADOM_H
#define CLI_DATADOM_H

/* add this lines to your src
#ifndef CLI_DATADOM_H
    #include <cli/datadom.h>
#endif
*/

#ifndef CLI_IDATADOM_H
    #include <cli/idatadom.h>
#endif

#ifndef CLI_VARIANT_H
    #include <cli/variant.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

namespace cli
{
namespace datadom
{


struct CDataNodeChildsLocker
{
    INTERFACE_CLI_IDATANODE *pNode;
    CDataNodeChildsLocker( INTERFACE_CLI_IDATANODE *p) : pNode(p) { pNode->lockChildNodes(); }
    ~CDataNodeChildsLocker() { pNode->unlockChildNodes(); }
};

#define CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( pNode, LockVarName ) ::cli::datadom::CDataNodeChildsLocker LockVarName(pNode)
#define CLI_DATADOM_CHILD_LIST_SCOPED_LOCK( pNode )                 CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( pNode, childListLocker )




inline
INTERFACE_CLI_IDATAEVENTHANDLER*
setHandlerByXPath( INTERFACE_CLI_IDATAROOT *pDataRoot
                      , INTERFACE_CLI_IVARIANTMAP *pVarMap
                      , const ::std::wstring &xpathExpr
                      , INTERFACE_CLI_IDATAEVENTHANDLER *pHandler
                      , ENUM_CLI_EDATANODEEVENTMASK eventMask
                      )
{
    ::cli::CiDataRoot       documentRoot(pDataRoot);
    ::cli::CiDataNode       documentRootNode;
    documentRoot.queryInterface(documentRootNode.getPP());

    ::cli::CiDataXPathQuery query("/cli/dataxpathquery");
    RCODE res = query.setQueryString( xpathExpr );
    CLI_THROW_IF_NOK(res);

    ::cli::CiDataNodeList resultNodeList("/cli/datanodelist");
    query.executeQuery( documentRootNode.getIfPtr(), pVarMap, resultNodeList.getPP() );

    SIZE_T listSize = resultNodeList.listSize;
    SIZE_T idx = 0;
    for(; idx!=listSize; ++idx)
       {
        ::cli::CiDataNode curNode;
        resultNodeList.getDataNode( curNode.getPP(), idx );
        if (!curNode) continue;
        curNode.addEventHandler( pHandler, eventMask );
       }

    return pHandler;
}



inline
INTERFACE_CLI_IDATAEVENTHANDLER*
setHandlerByXPath( INTERFACE_CLI_IDATANODE *pDataNode
                      , INTERFACE_CLI_IVARIANTMAP *pVarMap
                      , const ::std::wstring &xpathExpr
                      , INTERFACE_CLI_IDATAEVENTHANDLER *pHandler
                      , ENUM_CLI_EDATANODEEVENTMASK eventMask
                      )
{
    ::cli::CiDataNode_tmp   documentRootNode(pDataNode);

    ::cli::CiDataXPathQuery query("/cli/dataxpathquery");
    RCODE res = query.setQueryString( xpathExpr );
    CLI_THROW_IF_NOK(res);

    ::cli::CiDataNodeList resultNodeList("/cli/datanodelist");
    query.executeQuery( documentRootNode.getIfPtr(), pVarMap, resultNodeList.getPP() );

    SIZE_T listSize = resultNodeList.listSize;
    SIZE_T idx = 0;
    for(; idx!=listSize; ++idx)
       {
        ::cli::CiDataNode curNode;
        resultNodeList.getDataNode( curNode.getPP(), idx );
        if (!curNode) continue;
        curNode.addEventHandler( pHandler, eventMask );
       }

    return pHandler;
}

inline
RCODE findOrCreateChild( INTERFACE_CLI_IDATAXPATHQUERY *pQuery
                      , INTERFACE_CLI_IDATANODE **pNodeChild
                      , INTERFACE_CLI_IDATANODE *pNode
                      , const ::std::wstring &queryString
                      , INTERFACE_CLI_IVARIANTMAP *pVarMap
                      )
   {
    ::cli::CiDataXPathQuery_tmp queryObj(pQuery);
    RCODE res = queryObj.setQueryString( queryString );
    if (res) return res;

    //::cli::CiDataNode satStatTreeNode;
    if (queryObj.executeQuerySingleNodeResult( pNode, pVarMap, false /* not copy */ , pNodeChild ))
       { // not found
        queryObj.executeCreationQuery( pNode, pVarMap );
        return queryObj.executeQuerySingleNodeResult( pNode, pVarMap, false /* not copy */, pNodeChild );
       }
    return EC_OK;
   }

inline
RCODE findOrCreateChild( INTERFACE_CLI_IDATAXPATHQUERY *pQuery
                      , INTERFACE_CLI_IDATANODE **pNodeChild
                      , INTERFACE_CLI_IDATANODE *pNode
                      , const ::std::wstring &queryString
                      , INTERFACE_CLI_IVARIANTMAP *pVarMap
                      , const ::std::wstring &varName
                      , UINT varValue
                      )
   {
    ::cli::CiDataXPathQuery_tmp queryObj(pQuery);
    ::cli::CiVariantMap_tmp vm(pVarMap);
    ::cli::CiVariant variantTmp;
    if (!vm.queryValueByName(varName,variantTmp.getPP()) && !!variantTmp)
       {
        variantTmp.setUInt( varValue );
       }
    else
       {
        variantTmp.create("/cli/variant");
        variantTmp.setUInt( varValue );
        vm.insertValue( varName, TRUE  /* overwriteExisting */, FALSE  /* not copyValue */, variantTmp.getIfPtr() );
       }
    return findOrCreateChild( pQuery, pNodeChild, pNode, queryString, pVarMap );
   }

inline
RCODE findOrCreateChild( INTERFACE_CLI_IDATANODE **pNodeChild
                      , INTERFACE_CLI_IDATANODE *pNode
                      , const ::std::wstring &name
                      , ENUM_CLI_EDATANODETYPE type
                      )
   {
    SIZE_T childIdx = pNode->getChildIndexByNameTypeChars( name.c_str(), type );
    if (childIdx==SIZE_T_NPOS)
       {
        pNode->createChildDataNodeChars( pNodeChild, type, name.c_str(), 0 );
       }
    else
       {
        pNode->getChildNodeByIndex( pNodeChild, childIdx );
       }
    return EC_OK;
   }

inline
RCODE createChild( INTERFACE_CLI_IDATANODE **pNodeChild
                      , INTERFACE_CLI_IDATANODE *pNode
                      , const ::std::wstring &name
                      , ENUM_CLI_EDATANODETYPE type
                      )
   {
    pNode->createChildDataNodeChars( pNodeChild, type, name.c_str(), 0 );
    return EC_OK;
   }


inline
RCODE findChild( INTERFACE_CLI_IDATANODE **pNodeChild
                      , INTERFACE_CLI_IDATANODE *pNode
                      , const ::std::wstring &name
                      , ENUM_CLI_EDATANODETYPE type
                      )
   {
    SIZE_T childIdx = pNode->getChildIndexByNameTypeChars( name.c_str(), type );
    if (childIdx==SIZE_T_NPOS)
       {
        return EC_NOT_FOUND;
       }
    else
       {
        if (pNodeChild) pNode->getChildNodeByIndex( pNodeChild, childIdx );
       }
    return EC_OK;
   }


struct CDataEventHandlerBaseImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IDATAEVENTHANDLER
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CDataEventHandlerBaseImpl() : base_impl(DEF_MODULE) {}

    CLI_BEGIN_INTERFACE_MAP2(CDataEventHandlerBaseImpl, INTERFACE_CLI_IDATAEVENTHANDLER )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IDATAEVENTHANDLER )
    CLI_END_INTERFACE_MAP(CDataEventHandlerBaseImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    
       { 
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }

};



}; // namespace datadom
}; // namespace cli


#endif /* CLI_DATADOM_H */

