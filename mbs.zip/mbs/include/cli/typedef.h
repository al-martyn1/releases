#ifndef CLI_TYPEDEF_H
#define CLI_TYPEDEF_H

// strong typedef

/* add this lines to your scr
#ifndef CLI_TYPEDEF_H
    #include <cli/typedef.h>
#endif
*/

//typedef int myint;

#define CLI_STRONG_TYPEDEF_EX(orgType,newType,defVal) \
struct newType                                        \
{                                                     \
    typedef  orgType value_type;                      \
    value_type       value;                           \
                                                      \
    newType() : value(defVal) {}                      \
    newType(orgType v) : value(v) {}                  \
    operator orgType () const { return value; }       \
    newType& operator=( const newType &r )            \
       {                                              \
        if (&r!=this) value = r.value;                \
        return *this;                                 \
       }                                              \
    newType& operator=( orgType v )                   \
       {                                              \
        value = v;                                    \
        return *this;                                 \
       }                                              \
}

#define CLI_STRONG_TYPEDEF(orgType,newType)           \
struct newType                                        \
{                                                     \
    typedef  orgType value_type;                      \
    value_type       value;                           \
                                                      \
    newType() : value() {}                            \
    newType(orgType v) : value(v) {}                  \
    operator orgType () const { return value; }       \
    newType& operator=( const newType &r )            \
       {                                              \
        if (&r!=this) value = r.value;                \
        return *this;                                 \
       }                                              \
    newType& operator=( orgType v )                   \
       {                                              \
        value = v;                                    \
        return *this;                                 \
       }                                              \
}





namespace cli
{




}; // namespace cli


#endif /* CLI_TYPEDEF_H */

