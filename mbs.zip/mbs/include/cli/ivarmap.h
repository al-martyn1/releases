#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IVARMAP_H
#define CLI_IVARMAP_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/ivarmap.h>", CLI_IVARMAP_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IVARMAP_H
    #include <cli/ivarmap.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iVariantMap */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

        interface                                iVariant;
        #ifndef INTERFACE_CLI_IVARIANT
            #define INTERFACE_CLI_IVARIANT            ::cli::iVariant
        #endif

        interface                                iVariantMap;
        #ifndef INTERFACE_CLI_IVARIANTMAP
            #define INTERFACE_CLI_IVARIANTMAP         ::cli::iVariantMap
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_IVARIANT_PREDECLARED
    #define INTERFACE_CLI_IVARIANT_PREDECLARED
    typedef interface tag_cli_iVariant       cli_iVariant;
    #endif //INTERFACE_CLI_IVARIANT
    #ifndef INTERFACE_CLI_IVARIANT
        #define INTERFACE_CLI_IVARIANT            struct tag_cli_iVariant
    #endif

    #ifndef INTERFACE_CLI_IVARIANTMAP_PREDECLARED
    #define INTERFACE_CLI_IVARIANTMAP_PREDECLARED
    typedef interface tag_cli_iVariantMap    cli_iVariantMap;
    #endif //INTERFACE_CLI_IVARIANTMAP
    #ifndef INTERFACE_CLI_IVARIANTMAP
        #define INTERFACE_CLI_IVARIANTMAP         struct tag_cli_iVariantMap
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IVARIANTMAP_IID
    #define INTERFACE_CLI_IVARIANTMAP_IID    "/cli/iVariantMap"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iVariantMap
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IVARIANTMAP
       #define INTERFACE_CLI_IVARIANTMAP    ::cli::iVariantMap
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iVariantMap
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IVARIANTMAP
       #define INTERFACE_CLI_IVARIANTMAP    cli_iVariantMap
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iVariantMap methods */
            CLIMETHOD(cloneMap) (THIS_ INTERFACE_CLI_IVARIANTMAP**    pVarMap /* [out] ::cli::iVariantMap* pVarMap  */) PURE;
            CLIMETHOD(clearMap) (THIS) PURE;
            CLIMETHOD(insertValue) (THIS_ const CLISTR*     name
                                        , BOOL    overwriteExisting /* [in] bool  overwriteExisting  */
                                        , BOOL    copyValue /* [in] bool  copyValue  */
                                        , INTERFACE_CLI_IVARIANT*    pValue /* [in,optional] ::cli::iVariant*  pValue  */
                                   ) PURE;
            CLIMETHOD(insertValueChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                             , BOOL    overwriteExisting /* [in] bool  overwriteExisting  */
                                             , BOOL    copyValue /* [in] bool  copyValue  */
                                             , INTERFACE_CLI_IVARIANT*    pValue /* [in,optional] ::cli::iVariant*  pValue  */
                                        ) PURE;
            CLIMETHOD(queryValueByName) (THIS_ const CLISTR*     name
                                             , INTERFACE_CLI_IVARIANT**    pValue /* [out] ::cli::iVariant* pValue  */
                                        ) PURE;
            CLIMETHOD(queryValueByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                  , INTERFACE_CLI_IVARIANT**    pValue /* [out] ::cli::iVariant* pValue  */
                                             ) PURE;
            CLIMETHOD(queryValueByNameTo) (THIS_ const CLISTR*     name
                                               , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                          ) PURE;
            CLIMETHOD(queryValueByNameCharsTo) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                    , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                               ) PURE;
            CLIMETHOD(eraseByName) (THIS_ const CLISTR*     name) PURE;
            CLIMETHOD(eraseByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */) PURE;
            CLIMETHOD(getFirstKey) (THIS_ CLISTR*           firstKey) PURE;
            CLIMETHOD(getNextKey) (THIS_ const CLISTR*     key
                                       , CLISTR*           nextKey
                                  ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iVariantMap >
           {
            static char const * getName() { return INTERFACE_CLI_IVARIANTMAP_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iVariantMap* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iVariantMap > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iVariantMap wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IVARIANTMAP >
                                      */
                 >
        class CiVariantMapWrapper
        {
            public:
        
                typedef  CiVariantMapWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiVariantMapWrapper() :
                   pif(0) {}
        
                CiVariantMapWrapper( iVariantMap *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiVariantMapWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiVariantMapWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiVariantMapWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiVariantMapWrapper(const CiVariantMapWrapper &i) :
                    pif(i.pif) { }
        
                ~CiVariantMapWrapper()  { }
        
                CiVariantMapWrapper& operator=(const CiVariantMapWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE cloneMap( INTERFACE_CLI_IVARIANTMAP**    pVarMap /* [out] ::cli::iVariantMap* pVarMap  */)
                   {
                
                    return pif->cloneMap(pVarMap);
                   }
                
                RCODE clearMap( )
                   {
                    return pif->clearMap();
                   }
                
                RCODE insertValue( const ::std::wstring    &name
                                 , BOOL    overwriteExisting /* [in] bool  overwriteExisting  */
                                 , BOOL    copyValue /* [in] bool  copyValue  */
                                 , INTERFACE_CLI_IVARIANT*    pValue /* [in,optional] ::cli::iVariant*  pValue  */
                                 )
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                
                
                
                    return pif->insertValue(&tmp_name, overwriteExisting, copyValue, pValue);
                   }
                
                RCODE insertValueChars( const WCHAR*    name /* [in,flat] wchar  name[]  */
                                      , BOOL    overwriteExisting /* [in] bool  overwriteExisting  */
                                      , BOOL    copyValue /* [in] bool  copyValue  */
                                      , INTERFACE_CLI_IVARIANT*    pValue /* [in,optional] ::cli::iVariant*  pValue  */
                                      )
                   {
                
                
                
                
                    return pif->insertValueChars(name, overwriteExisting, copyValue, pValue);
                   }
                
                RCODE queryValueByName( const ::std::wstring    &name
                                      , INTERFACE_CLI_IVARIANT**    pValue /* [out] ::cli::iVariant* pValue  */
                                      )
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                
                    return pif->queryValueByName(&tmp_name, pValue);
                   }
                
                RCODE queryValueByNameChars( const WCHAR*    name /* [in,flat] wchar  name[]  */
                                           , INTERFACE_CLI_IVARIANT**    pValue /* [out] ::cli::iVariant* pValue  */
                                           )
                   {
                
                
                    return pif->queryValueByNameChars(name, pValue);
                   }
                
                RCODE queryValueByNameTo( const ::std::wstring    &name
                                        , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                        )
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                
                    return pif->queryValueByNameTo(&tmp_name, pValue);
                   }
                
                RCODE queryValueByNameCharsTo( const WCHAR*    name /* [in,flat] wchar  name[]  */
                                             , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                             )
                   {
                
                
                    return pif->queryValueByNameCharsTo(name, pValue);
                   }
                
                RCODE eraseByName( const ::std::wstring    &name)
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                    return pif->eraseByName(&tmp_name);
                   }
                
                RCODE eraseByNameChars( const WCHAR*    name /* [in,flat] wchar  name[]  */)
                   {
                
                    return pif->eraseByNameChars(name);
                   }
                
                RCODE getFirstKey( ::std::wstring    &firstKey)
                   {
                    CCliStr tmp_firstKey; CCliStr_init( tmp_firstKey );
                    RCODE res = pif->getFirstKey(&tmp_firstKey);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( firstKey, tmp_firstKey);
                       }
                    return res;
                   }
                
                RCODE getNextKey( const ::std::wstring    &key
                                , ::std::wstring    &nextKey
                                )
                   {
                    CCliStr tmp_key; CCliStr_lightCopyTo( tmp_key, key);
                    CCliStr tmp_nextKey; CCliStr_init( tmp_nextKey );
                    RCODE res = pif->getNextKey(&tmp_key, &tmp_nextKey);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( nextKey, tmp_nextKey);
                       }
                    return res;
                   }
                

        
        
        }; // class CiVariantMapWrapper
        
        typedef CiVariantMapWrapper< ::cli::CCliPtr< INTERFACE_CLI_IVARIANTMAP     > >  CiVariantMap;
        typedef CiVariantMapWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IVARIANTMAP > >  CiVariantMap_nrc; /* No ref counting for interface used */
        typedef CiVariantMapWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IVARIANTMAP > >  CiVariantMap_tmp; /* for temporary usage, same as CiVariantMap_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IVARMAP_H */
