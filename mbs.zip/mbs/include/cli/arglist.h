#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_ARGLIST_H
#define CLI_ARGLIST_H

/* Add next lines to your C/C++ code
#ifndef CLI_ARGLIST_H
    #include <cli/arglist.h>
#endif
*/

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIME_H
    #include <cli/dateTime.h>
#endif

#ifndef CLI_NUMERIC_H
    #include <cli/numeric.h>
#endif

#include <marty/concvt.h>



#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif



#define cliCreateArgList cliGetArgList

EXTERN_CLI
CLIAPIENTRY
INTERFACE_CLI_IARGLIST*
CLICALL
cliGetArgList( );


#ifdef __cplusplus

namespace cli
{


class CArgList : public CiArgList
{
    public:
        CArgList( iArgList *_pi, bool noAddRef=false)
           : CiArgList(_pi, noAddRef)
           {}

        CArgList( const CiArgList &ca ) : CiArgList( const_cast< CiArgList& >(ca).getIfPtr(), false ) {}

        CArgList() : CiArgList(cliGetArgList( ), true) {}

        template < typename T >
        void getValue( SIZE_T idx, T &t)
           {
            CLI_STATIC_CHECK(0, CArgList_getValue_must_be_specialized_for_this_type);
           }

        template < typename T >
        void convertToVector( ::std::vector< T > &v )
           {
            SIZE_T numArgs = getCount( );
            for( SIZE_T i = 0; i!=numArgs; ++i )
               {
                T t;
                getValue( i, t );
                v.push_back( t );
               }
           }

        template < typename T1, typename T2 >
        void convertToPairsVector( ::std::vector< ::std::pair< T1, T2 > > &v )
           {
            SIZE_T numArgs = getCount( );
            for( SIZE_T i = 0; i<numArgs; ++i )
               {
                ::std::pair< T1, T2 > pair;
                getValue( i, pair.first );
                ++i;
                if (i<numArgs)
                   {
                    getValue( i, pair.second );
                   }
                v.push_back( pair );
               }
           }

        void getString( SIZE_T idx, std::string &s)
           {
            std::wstring wstr;
            CiArgList::getString(idx,wstr);
            s = MARTY_CON::strToAnsi(wstr);
           }

        void getString( SIZE_T idx, std::wstring &s)
           {
            CiArgList::getString(idx,s);
           }

/*
        void getValue( SIZE_T idx, std::string &s)
           {
            std::wstring wstr;
            CiArgList::getString(idx,wstr);
            s = MARTY_CON::strToAnsi(wstr);
           }

        void getValue( SIZE_T idx, std::wstring &s)
           {
            getString(idx,s);
           }

        void getString( SIZE_T idx, std::string &s)
           {
            getValue(idx,s);
           }

        void getString( SIZE_T idx, std::wstring &s)
           {
            getValue(idx,s);
           }
*/



}; // CArgList


#define CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR(TYPE, Method)             \
            template <>                                                \
            inline                                                     \
            void CArgList::getValue<TYPE>( SIZE_T idx, TYPE &v)        \
               {                                                       \
                Method(idx, &v);                                       \
               }

#define CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR_REF(TYPE, Method)         \
            template <>                                                \
            inline                                                     \
            void CArgList::getValue< TYPE >( SIZE_T idx, TYPE &v)      \
               {                                                       \
                Method(idx, v) ;                                       \
               }

CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( CHAR , getChar)
#if !defined(_MSC_VER) || defined(_NATIVE_WCHAR_T_DEFINED)
    CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( WCHAR, getWChar)
#endif

// For MSVC go to project settings - C/C++ - Language, set "Threat wchar_t as Built-in Type" to "Yes"
// UPD: Fixed above with checking _NATIVE_WCHAR_T_DEFINED macro
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( SHORT, getShort)
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( USHORT, getUShort)

//#ifndef INT_PTR_EQUAL_TO_INT
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( INT, getInt)
//#endif

//#ifndef UINT_PTR_NOT_EQUAL_TO_UINT
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( UINT, getUInt)
//#endif

//#ifndef INT_PTR_EQUAL_TO_INT64
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( INT64, getInt64 )
//#endif

//#ifdef UINT_PTR_NOT_EQUAL_TO_UINT64
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( UINT64, getUInt64)
//#endif

//CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( INT_PTR, getIntPtr)
//CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( UINT_PTR, getUIntPtr)
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( FLOAT, getFloat)
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( DOUBLE, getDouble)
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( VOID*, getPtr)
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR_REF( ::std::wstring , getString)
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR_REF( ::std::string  , getString)
CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR_REF( STRUCT_CLI_CLISYSTEMTIME, getDate)
//CLI_CARGLIST_GETVALUE_SPECIALIZE_FOR( , )


template < typename T >
void arglistToVector( INTERFACE_CLI_IARGLIST* pArgList, ::std::vector< T > &v )
   {
    if (!pArgList) return;
    CArgList argList(pArgList);
    argList.convertToVector( v );
   }

template < typename T1, typename T2 >
void arglistToPairsVector( INTERFACE_CLI_IARGLIST* pArgList, ::std::vector< ::std::pair< T1, T2 > > &v )
   {
    if (!pArgList) return;
    CArgList argList(pArgList);
    argList.convertToPairsVector( v );
   }



// arglist and helpers

namespace args
{

typedef ::cli::numeric::extended_int128_t extended_int;
typedef ::cli::numeric::rational_number_t rational;


struct dump
{
    const BYTE   *data;
    SIZE_T        dumpSize;

    dump() : data(0), dumpSize(0) {}
    dump(const BYTE *d, SIZE_T ds) : data(d), dumpSize(ds) {}
    dump(const char *d, SIZE_T ds) : data((const BYTE*)d), dumpSize(ds) {}
    dump(const dump &dmp) : data(dmp.data), dumpSize(dmp.dumpSize) {}
    dump& operator=(const dump &dmp)
       {
        data = dmp.data;
        dumpSize = dmp.dumpSize;
        return *this;
       }
}; // struct dump



struct ascii
{
    static const unsigned int hexBase     = 1; // hex by default
    static const unsigned int quoteQuotes = 2; // quote " sign as \"
    static const unsigned int quoteApos = 4; // quote " sign as \"
    static const unsigned int upperCase   = 8; // quote " sign as \"


private:

    ::std::string str;

    static char digit2hex(unsigned int digit, bool upperCase)
       {
        if (digit<10) return '0' + (digit);
        digit -= 10;
        if (upperCase) return 'A' + (digit);
        else           return 'a' + (digit);
       }

    static ::std::string toStr(unsigned int i, unsigned int flags)
       {
        ::std::string res; // = "\\";
        unsigned int base = 8;
        if (flags&hexBase) base = 16;
        //else res.append(1,'x');
        while(i)
           {
            unsigned dig = (unsigned)(i%base);
            res.append(1, digit2hex(dig, flags&upperCase ? true : false ) );
            i /= base;
           }
        if (res.empty()) res.append(1, '0');

        if (flags&hexBase) res.append(1, 'x');
        res.append(1, '\\');

        //if (res.size()<(SIZE_T)width)
        //   res.append((SIZE_T)width-res.size(), fillChar);
        ::std::reverse(res.begin(), res.end());
        return res;
       }

    static ::std::string makeAscii( const ::std::string &s, unsigned int flags )
       {
        ::std::string res; res.reserve(s.size());
        ::std::string::size_type i = 0, size = s.size();
        for(; i!=size; ++i)
           {
            unsigned char ch = (unsigned char)s[i];
            switch(ch)
               {
                case '\n':  res.append("\\n"); break;
                case '\t':  res.append("\\t"); break;
                case '\v':  res.append("\\v"); break;
                case '\b':  res.append("\\b"); break;
                case '\r':  res.append("\\r"); break;
                case '\f':  res.append("\\f"); break;
                case '\a':  res.append("\\a"); break;
                case '\\':  res.append("\\\\"); break;
                case '\"':  if (flags&quoteQuotes)
                               res.append("\\\"");
                            else
                               res.append("\"");
                            break;
                case '\'':  if (flags&quoteApos)
                               res.append("\\\'");
                            else
                               res.append("'");
                            break;
                default:    if (ch<' ' || ch>126)
                               {
                                res += toStr( (unsigned)ch, flags );
                               }
                            else
                               {
                                res.append(1, (char)ch);
                               }
               }
           }
        return res;
       }

    static ::std::string makeAscii( const ::std::wstring &s, unsigned int flags )
       {
        ::std::string res; res.reserve(s.size());
        ::std::wstring::size_type i = 0, size = s.size();
        for(; i!=size; ++i)
           {
            wchar_t ch = (unsigned char)s[i];
            switch(ch)
               {
                case '\n':  res.append("\\n"); break;
                case '\t':  res.append("\\t"); break;
                case '\v':  res.append("\\v"); break;
                case '\b':  res.append("\\b"); break;
                case '\r':  res.append("\\r"); break;
                case '\f':  res.append("\\f"); break;
                case '\a':  res.append("\\a"); break;
                case '\\':  res.append("\\\\"); break;
                case '\"':  if (flags&quoteQuotes)
                               res.append("\\\"");
                            else
                               res.append("\"");
                            break;
                case '\'':  if (flags&quoteApos)
                               res.append("\\\'");
                            else
                               res.append("'");
                            break;
                default:    if (ch<' ' || ch>126)
                               {
                                res += toStr( (unsigned)ch, flags );
                               }
                            else
                               {
                                res.append(1, (char)(unsigned char)ch);
                               }
               }
           }
        return res;
       }

public:

//::std::string makeAscii( const ::std::wstring &s, unsigned int flags )
    ascii() : str() {}
    ascii(const BYTE *d, SIZE_T ds, unsigned int flags = 0)
       : str(makeAscii(::std::string((const char*)d, ds), flags)) {}
    ascii(const char *d, SIZE_T ds, unsigned int flags = 0)
       : str(makeAscii(::std::string((const char*)d, ds), flags)) {}
    ascii(const ::std::string s, unsigned int flags = 0)
       : str(makeAscii( s, flags )) {}
    ascii(const ::std::wstring s, unsigned int flags = 0)
       : str(makeAscii( s, flags )) {}

    ascii& operator=(const ascii &a)
       {
        str = a.str;
        return *this;
       }

    operator ::std::string() const
       {
        return str;
       }


}; // struct ascii


struct empty
{
    //int dummy;
    DWORD                           vtType;
    UNION_CLI_VARIANTVALUE          val;
    ::std::wstring                  str;

    empty() : vtType(CLI_VARIANTTYPE_VT_EMPTY), str() {}

    // methods below allow to use operator ? with 'empty' class
    // such as: (!val ? empty() : val)
    void pushTo( INTERFACE_CLI_IARGLIST *pArgList ) const
       {
        switch(vtType)
           {
            case CLI_VARIANTTYPE_VT_PSTRING   : pArgList->putStringChars(str.data(), str.size() );   break;
            case CLI_VARIANTTYPE_VT_CHAR      : pArgList->putChar(val.vChar);      break;
            case CLI_VARIANTTYPE_VT_WCHAR     : pArgList->putWChar(val.vWChar);    break;
            case CLI_VARIANTTYPE_VT_SHORT     : pArgList->putShort(val.vShort);    break;
            case CLI_VARIANTTYPE_VT_USHORT    : pArgList->putUShort(val.vUShort);  break;
            case CLI_VARIANTTYPE_VT_INT       : pArgList->putInt(val.vInt);        break;
            case CLI_VARIANTTYPE_VT_UINT      : pArgList->putUInt(val.vUInt);      break;
            case CLI_VARIANTTYPE_VT_INT64     : pArgList->putInt64(val.vInt64);    break;
            case CLI_VARIANTTYPE_VT_UINT64    : pArgList->putUInt64(val.vUInt64);  break;
            case CLI_VARIANTTYPE_VT_FLOAT     : pArgList->putFloat (val.vFloat );  break;
            case CLI_VARIANTTYPE_VT_DOUBLE    : pArgList->putDouble(val.vDouble);  break;
            case CLI_VARIANTTYPE_VT_DATETIME  : pArgList->putDate(&val.vDatetime);  break;
            case CLI_VARIANTTYPE_VT_BIGINT    : pArgList->putBigInteger(&val.vBigint);  break;
            case CLI_VARIANTTYPE_VT_RATIONAL  :pArgList->putRationalNumber(&val.vRational);  break;
            //case : pArgList->   break;
            case CLI_VARIANTTYPE_VT_EMPTY     : pArgList->putEmpty();              break;
            default: CLIASSERT( 0 );
           }
       }

    // copy
    empty( const empty &e ) : vtType(e.vtType), str(e.str) { val = e.val; }

    // casts
    empty( const wchar_t *pstr ) : vtType(CLI_VARIANTTYPE_VT_PSTRING), str(pstr) {}
    empty( const ::std::wstring &w ) : vtType(CLI_VARIANTTYPE_VT_PSTRING), str(w) {}

    empty( const char *pstr ) : vtType(CLI_VARIANTTYPE_VT_PSTRING), str()         { str = MARTY_CON_NS strToWide( pstr ); }
    empty( const ::std::string &s ) : vtType(CLI_VARIANTTYPE_VT_PSTRING), str()   { str = MARTY_CON_NS strToWide( s ); }

    empty( char    ch ) : vtType(CLI_VARIANTTYPE_VT_CHAR) , str() { val.vChar  = ch; }
    empty( wchar_t ch ) : vtType(CLI_VARIANTTYPE_VT_WCHAR), str() { val.vWChar = ch; }

    empty( SHORT v   ) : vtType(CLI_VARIANTTYPE_VT_SHORT) , str() { val.vShort  = v; }

    #ifndef WCHAR_IS_TYPEDEF_TO_USHORT
    empty( USHORT v  ) : vtType(CLI_VARIANTTYPE_VT_USHORT), str() { val.vUShort = v; }
    #endif

    empty( INT v   ) : vtType(CLI_VARIANTTYPE_VT_INT) , str() { val.vInt  = v; }
    empty( UINT v  ) : vtType(CLI_VARIANTTYPE_VT_UINT), str() { val.vUInt = v; }

    empty( INT64 v ) : vtType(CLI_VARIANTTYPE_VT_INT64) , str() { val.vInt64  = v; }
    empty( UINT64 v) : vtType(CLI_VARIANTTYPE_VT_UINT64), str() { val.vUInt64 = v; }

    empty( FLOAT v ) : vtType(CLI_VARIANTTYPE_VT_FLOAT) , str() { val.vFloat  = v; }
    empty( DOUBLE v) : vtType(CLI_VARIANTTYPE_VT_DOUBLE), str() { val.vDouble = v; }
    empty( const STRUCT_CLI_CLISYSTEMTIME &v)          : vtType(CLI_VARIANTTYPE_VT_DATETIME), str() { val.vDatetime = v; }
    empty( const CDateTime &v)                         : vtType(CLI_VARIANTTYPE_VT_DATETIME), str() { val.vDatetime = v; }
    empty( const STRUCT_CLI_BIGINTEGER &v)             : vtType(CLI_VARIANTTYPE_VT_BIGINT)  , str() { val.vBigint = v; }
    empty( const ::cli::numeric::extended_int128_t &v) : vtType(CLI_VARIANTTYPE_VT_BIGINT)  , str() { ::cli::numeric::toCliBigInteger( v, val.vBigint ); }
    empty( const STRUCT_CLI_RATIONALNUMBER &v)         : vtType(CLI_VARIANTTYPE_VT_RATIONAL), str() { val.vRational = v; }
    empty( const ::cli::numeric::rational_number_t &v) : vtType(CLI_VARIANTTYPE_VT_RATIONAL), str() { ::cli::numeric::toCliRational( v, val.vRational ); }

/*
    empty( const empty &e ) : dummy(0) {}
    empty( char ch ) : dummy(0) {}
    empty( wchar_t ch ) : dummy(0) {}
    arg(INT_PTR i)   : pArgs(cliGetArgList()) { pArgs->putIntPtr(i); }
    arg(UINT_PTR i)  : pArgs(cliGetArgList()) { pArgs->putUIntPtr(i); }

    arg(INT64 i)     : pArgs(cliGetArgList()) { pArgs->putInt64(i); }
    arg(UINT64 i)    : pArgs(cliGetArgList()) { pArgs->putUInt64(i); }

    arg(float f)     : pArgs(cliGetArgList()) { pArgs->putFloat(f); }
    arg(double d)    : pArgs(cliGetArgList()) { pArgs->putDouble(d); }

    arg(void *ptr)   : pArgs(cliGetArgList()) { pArgs->putPtr(ptr); }
    arg( const ::std::wstring &str) : pArgs(cliGetArgList()) { pArgs->putStringChars(str.data(), str.size() ); }
    arg( const WCHAR *pstr) : pArgs(cliGetArgList())
    arg( const ::std::string &str) : pArgs(cliGetArgList())
    arg( const CHAR *pstr) : pArgs(cliGetArgList())
*/
}; // struct empty


}; // namespace args


class arglist
{
    //INTERFACE_CLI_IARGLIST*     pArgs;
    ::cli::CCliPtr<INTERFACE_CLI_IARGLIST> pArgs;

public:
    arglist() : pArgs(cliGetArgList(), true /* noAddRef */) {}
    arglist(INTERFACE_CLI_IARGLIST* pa) : pArgs(pa) {}

    template <typename PtrType>
    arglist(PtrType *ptr): pArgs(cliGetArgList()) { pArgs->putPtr((void*)ptr); }

    arglist(void *ptr)   : pArgs(cliGetArgList()) { pArgs->putPtr(ptr); }

    arglist(const arglist& a) : pArgs(a.pArgs) {}
    arglist& operator=(const arglist& a) { pArgs = a.pArgs; return *this; }

    operator INTERFACE_CLI_IARGLIST*() const
       {
        arglist * pthis = const_cast<arglist*>(this);
        //INTERFACE_CLI_IARGLIST** pp = pArgs.getPP();
        //INTERFACE_CLI_IARGLIST* p = *pp;
        //INTERFACE_CLI_IARGLIST* p = *(pthis->pArgs.getPP());
        //if (p) p->addRef();
        INTERFACE_CLI_IARGLIST* p = pthis->pArgs.getIfPtr();
        return p;
       }

    arglist(char ch)     : pArgs(cliGetArgList()) { pArgs->putChar(ch); }
    arglist(wchar_t ch)  : pArgs(cliGetArgList()) { pArgs->putWChar(ch); }

    arglist(INT_PTR i)   : pArgs(cliGetArgList()) { pArgs->putIntPtr(i); }
    arglist(UINT_PTR i)  : pArgs(cliGetArgList()) { pArgs->putUIntPtr(i); }

    #if defined(INT_PTR_EQUAL_TO_INT64) && INT_PTR_EQUAL_TO_INT64==1
    arglist(INT i)     : pArgs(cliGetArgList()) { pArgs->putInt(i); }
    arglist(UINT i)    : pArgs(cliGetArgList()) { pArgs->putUInt(i); }
    #else
    arglist(INT64 i)     : pArgs(cliGetArgList()) { pArgs->putInt64(i); }
    arglist(UINT64 i)    : pArgs(cliGetArgList()) { pArgs->putUInt64(i); }
    #endif

    arglist(DWORD d)     : pArgs(cliGetArgList()) { pArgs->putUInt(d); }


    #ifndef _MSC_VER
    //arg(int i)          : pArgs(cliGetArgList()) { pArgs->putInt(i); }
    //arg(unsigned int i) : pArgs(cliGetArgList()) { pArgs->putUInt(i); }
    #endif

    //#ifdef _MSC_VER
    #ifdef _WIN32
    //arg(RCODE r       ) : pArgs(cliGetArgList()) { pArgs->putUInt(r); }
    #endif // gcc reports error

/*
    arg(INT64 i)     : pArgs(cliGetArgList()) { pArgs->putInt64(i); return *this; }
    arg(UINT64 i)    : pArgs(cliGetArgList()) { pArgs->putUInt64(i); return *this; }
*/
/*
    arg(INT_PTR i)   : pArgs(cliGetArgList()) { pArgs->putIntPtr(i); return *this; }
    arg(UINT_PTR i)  : pArgs(cliGetArgList()) { pArgs->putUIntPtr(i); return *this; }
*/
    //arg(float f)     : pArgs(cliGetArgList()) { pArgs->putFloat(f); }
    arglist(double d)    : pArgs(cliGetArgList()) { pArgs->putDouble(d); }

    arglist( const ::std::wstring &str) : pArgs(cliGetArgList()) { pArgs->putStringChars(str.data(), str.size() ); }
    arglist( const WCHAR *pstr) : pArgs(cliGetArgList())
       {
        if (pstr) pArgs->putStringChars(pstr, wcslen(pstr) );
        else      pArgs->putStringChars(0, 0 );
       }

    arglist( const ::std::string &str) : pArgs(cliGetArgList())
       {
        ::std::wstring wstr = MARTY_CON_NS strToWide( str );
        pArgs->putStringChars(wstr.data(), wstr.size() );
       }

    arglist( const CHAR *pstr) : pArgs(cliGetArgList())
       {
        if (pstr)
           {
            ::std::wstring wstr = MARTY_CON_NS strToWide( ::std::string(pstr) );
            pArgs->putStringChars(wstr.data(), wstr.size() );
           }
        else
           {
            pArgs->putStringChars(0, 0 );
           }
       }


/*
    arg( const ::std::wstring &str) : pArgs(cliGetArgList())
       {
        pArgs->putStringChars(str.data(), str.size() );
       }
*/
    arglist(const args::dump &d)  : pArgs(cliGetArgList()) { pArgs->putDump(d.data, d.dumpSize); }

    //arg(const empty &d)  : pArgs(cliGetArgList()) { pArgs->putEmpty(); }
    arglist(const args::empty &e)  : pArgs(cliGetArgList()) { e.pushTo(pArgs); }

    arglist(const STRUCT_CLI_CLISYSTEMTIME &dt) : pArgs(cliGetArgList()) { pArgs->putDate(&dt); }
    arglist(const ::cli::CDateTime &cdt) : pArgs(cliGetArgList())
       {
        //STRUCT_CLI_CLISYSTEMTIME dt = cdt;
        pArgs->putDate(&cdt);
       }

    arglist(const STRUCT_CLI_BIGINTEGER &v) : pArgs(cliGetArgList())
       {
        pArgs->putBigInteger(&v);
       }

    arglist(::cli::numeric::extended_int128_t &v) : pArgs(cliGetArgList())
       {
        STRUCT_CLI_BIGINTEGER b;
        ::cli::numeric::toCliBigInteger( v, b );
        pArgs->putBigInteger(&b);
       }

    arglist(const STRUCT_CLI_RATIONALNUMBER &v) : pArgs(cliGetArgList())
       {
        pArgs->putRationalNumber(&v);
       }

    arglist(::cli::numeric::rational_number_t &v) : pArgs(cliGetArgList())
       {
        STRUCT_CLI_RATIONALNUMBER r;
        ::cli::numeric::toCliRational( v, r );
        pArgs->putRationalNumber(&r);
       }


    //----------------------------------------------------------------------------
    // Operators
    //----------------------------------------------------------------------------

    arglist& operator %(char ch)     { pArgs->putChar(ch); return *this; }
    arglist& operator %(wchar_t ch)  { pArgs->putWChar(ch); return *this; }

    #ifndef _MSC_VER
    arglist& operator %(short int i) { pArgs->putShort(i); return *this; }
    arglist& operator %(unsigned short int i) { pArgs->putUShort(i); return *this; }
    #endif

    arglist& operator %(INT_PTR i)     { pArgs->putIntPtr(i); return *this; }
    arglist& operator %(UINT_PTR i)    { pArgs->putUIntPtr(i); return *this; }
    #if defined(INT_PTR_EQUAL_TO_INT64) && INT_PTR_EQUAL_TO_INT64==1
    arglist& operator %(INT i)         { pArgs->putInt(i); return *this; }
    arglist& operator %(UINT i)        { pArgs->putUInt(i); return *this; }
    #else
    arglist& operator %(INT64 i)       { pArgs->putInt64(i); return *this; }
    arglist& operator %(UINT64 i)      { pArgs->putUInt64(i); return *this; }
    #endif

    arglist& operator %(DWORD d)       { pArgs->putUInt(d); return *this; }


    #ifndef _MSC_VER
    //arg& operator %(int i)          { pArgs->putInt(i); return *this; }
    //arg& operator %(unsigned int i) { pArgs->putUInt(i); return *this; }
    #endif

    //#ifdef _MSC_VER
    #ifdef _WIN32
    //arg& operator %(RCODE r       ) { pArgs->putUInt(r); return *this; }
    #endif // gcc reports error


/*
    arg& operator %(INT64 i)     { pArgs->putInt64(i); return *this; }
    arg& operator %(UINT64 i)    { pArgs->putUInt64(i); return *this; }
*/
/*
    arg& operator %(INT_PTR i)   { pArgs->putIntPtr(i); return *this; }
    arg& operator %(UINT_PTR i)  { pArgs->putUIntPtr(i); return *this; }
*/
    //arg& operator %(float f)     { pArgs->putFloat(f); return *this; }
    arglist& operator %(double d)    { pArgs->putDouble(d); return *this; }

    arglist& operator %(void *ptr)   { pArgs->putPtr(ptr); return *this; }

    template <typename PtrType>
    arglist& operator %(PtrType *ptr){ pArgs->putPtr((void*)ptr); return *this; }

    arglist& operator %( const ::std::wstring &str) { pArgs->putStringChars(str.data(), str.size() ); return *this; }
    arglist& operator %( const WCHAR *pstr)
       {
        if (pstr) pArgs->putStringChars(pstr, wcslen(pstr) );
        else      pArgs->putStringChars(0, 0 );
        return *this;
       }

    arglist& operator %( const ::std::string &str)
       {
        ::std::wstring wstr = MARTY_CON_NS strToWide( str );
        pArgs->putStringChars(wstr.data(), wstr.size() );
        return *this;
       }

    arglist& operator %( const CHAR *pstr)
       {
        if (pstr)
           {
            ::std::wstring wstr = MARTY_CON_NS strToWide( ::std::string(pstr) );
            pArgs->putStringChars(wstr.data(), wstr.size() );
           }
        else
           {
            pArgs->putStringChars(0, 0 );
           }
        return *this;
       }

/*
    arg& operator %( const ::std::wstring &str)
       {
        pArgs->putStringChars(str.data(), str.size() );
       }
*/
    arglist& operator %( const args::dump &d)
       {
        pArgs->putDump(d.data, d.dumpSize);
        return *this;
       }

    arglist& operator %( const args::empty &e)
       {
        //pArgs->putEmpty();
        e.pushTo(pArgs);
        return *this;
       }

    arglist& operator %(const STRUCT_CLI_CLISYSTEMTIME &dt)
       {
        pArgs->putDate(&dt);
        return *this;
       }

    arglist& operator %(const ::cli::CDateTime &cdt)
       {
        //STRUCT_CLI_CLISYSTEMTIME dt = cdt;
        pArgs->putDate(&cdt);
        return *this;
       }

    arglist& operator %(const STRUCT_CLI_BIGINTEGER &v)
       {
        pArgs->putBigInteger(&v);
        return *this;
       }

    arglist& operator %(const ::cli::numeric::extended_int128_t &v)
       {
        STRUCT_CLI_BIGINTEGER b;
        ::cli::numeric::toCliBigInteger( v, b );
        pArgs->putBigInteger(&b);
        return *this;
       }

    arglist& operator %(const STRUCT_CLI_RATIONALNUMBER &v)
       {
        pArgs->putRationalNumber(&v);
        return *this;
       }

    arglist& operator %(const ::cli::numeric::rational_number_t &v)
       {
        STRUCT_CLI_RATIONALNUMBER r;
        ::cli::numeric::toCliRational( v, r );
        pArgs->putRationalNumber(&r);
        return *this;
       }


}; // class arg




}; // namespace cli


#endif // __cplusplus


#endif /* CLI_ARGLIST_H */

