#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IERRINFO_H
#define CLI_IERRINFO_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/ierrinfo.h>", CLI_IERRINFO_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IERRINFO_H
    #include <cli/ierrinfo.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iErrorInfo */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iArgList;
        #ifndef INTERFACE_CLI_IARGLIST
            #define INTERFACE_CLI_IARGLIST            ::cli::iArgList
        #endif

        interface                                iErrorInfo;
        #ifndef INTERFACE_CLI_IERRORINFO
            #define INTERFACE_CLI_IERRORINFO          ::cli::iErrorInfo
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IARGLIST_PREDECLARED
    #define INTERFACE_CLI_IARGLIST_PREDECLARED
    typedef interface tag_cli_iArgList       cli_iArgList;
    #endif //INTERFACE_CLI_IARGLIST
    #ifndef INTERFACE_CLI_IARGLIST
        #define INTERFACE_CLI_IARGLIST            struct tag_cli_iArgList
    #endif

    #ifndef INTERFACE_CLI_IERRORINFO_PREDECLARED
    #define INTERFACE_CLI_IERRORINFO_PREDECLARED
    typedef interface tag_cli_iErrorInfo     cli_iErrorInfo;
    #endif //INTERFACE_CLI_IERRORINFO
    #ifndef INTERFACE_CLI_IERRORINFO
        #define INTERFACE_CLI_IERRORINFO          struct tag_cli_iErrorInfo
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IERRORINFO_IID
    #define INTERFACE_CLI_IERRORINFO_IID    "/cli/iErrorInfo"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iErrorInfo
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IERRORINFO
       #define INTERFACE_CLI_IERRORINFO    ::cli::iErrorInfo
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iErrorInfo
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IERRORINFO
       #define INTERFACE_CLI_IERRORINFO    cli_iErrorInfo
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iErrorInfo methods */
            CLIMETHOD(getErrorCode) (THIS) PURE;
            CLIMETHOD(getModuleFileName) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(getModuleInternalName) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(getModuleName) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(getSourceFileLine) (THIS_ CLISTR*           str
                                              , UINT*    line /* [out] uint line  */
                                         ) PURE;
            CLIMETHOD(getArgList) (THIS_ INTERFACE_CLI_IARGLIST**    arglist /* [out] ::cli::iArgList* arglist  */) PURE;
            CLIMETHOD(getChainErrorInfo) (THIS_ INTERFACE_CLI_IERRORINFO**    pei /* [out] ::cli::iErrorInfo* pei  */) PURE;
            CLIMETHOD(chainErrorInfo) (THIS_ INTERFACE_CLI_IERRORINFO*    pei /* [in] ::cli::iErrorInfo*  pei  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iErrorInfo >
           {
            static char const * getName() { return INTERFACE_CLI_IERRORINFO_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iErrorInfo* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iErrorInfo > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iErrorInfo wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IERRORINFO >
                                      */
                 >
        class CiErrorInfoWrapper
        {
            public:
        
                typedef  CiErrorInfoWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiErrorInfoWrapper() :
                   pif(0) {}
        
                CiErrorInfoWrapper( iErrorInfo *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiErrorInfoWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiErrorInfoWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiErrorInfoWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiErrorInfoWrapper(const CiErrorInfoWrapper &i) :
                    pif(i.pif) { }
        
                ~CiErrorInfoWrapper()  { }
        
                CiErrorInfoWrapper& operator=(const CiErrorInfoWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE getErrorCode( )
                   {
                    return pif->getErrorCode();
                   }
                
                RCODE getModuleFileName( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getModuleFileName(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getModuleInternalName( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getModuleInternalName(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getModuleName( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getModuleName(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getSourceFileLine( ::std::wstring    &str
                                       , UINT*    line /* [out] uint line  */
                                       )
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                
                    RCODE res = pif->getSourceFileLine(&tmp_str, line);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getArgList( INTERFACE_CLI_IARGLIST**    arglist /* [out] ::cli::iArgList* arglist  */)
                   {
                
                    return pif->getArgList(arglist);
                   }
                
                RCODE getChainErrorInfo( INTERFACE_CLI_IERRORINFO**    pei /* [out] ::cli::iErrorInfo* pei  */)
                   {
                
                    return pif->getChainErrorInfo(pei);
                   }
                
                RCODE chainErrorInfo( INTERFACE_CLI_IERRORINFO*    pei /* [in] ::cli::iErrorInfo*  pei  */)
                   {
                
                    return pif->chainErrorInfo(pei);
                   }
                

        
        
        }; // class CiErrorInfoWrapper
        
        typedef CiErrorInfoWrapper< ::cli::CCliPtr< INTERFACE_CLI_IERRORINFO     > >  CiErrorInfo;
        typedef CiErrorInfoWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IERRORINFO > >  CiErrorInfo_nrc; /* No ref counting for interface used */
        typedef CiErrorInfoWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IERRORINFO > >  CiErrorInfo_tmp; /* for temporary usage, same as CiErrorInfo_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iCreateErrorInfo */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ICREATEERRORINFO_IID
    #define INTERFACE_CLI_ICREATEERRORINFO_IID    "/cli/iCreateErrorInfo"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iCreateErrorInfo
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ICREATEERRORINFO
       #define INTERFACE_CLI_ICREATEERRORINFO    ::cli::iCreateErrorInfo
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iCreateErrorInfo
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ICREATEERRORINFO
       #define INTERFACE_CLI_ICREATEERRORINFO    cli_iCreateErrorInfo
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iCreateErrorInfo methods */
            CLIMETHOD(setErrorCode) (THIS_ RCODE    code /* [in] rcode  code  */) PURE;
            CLIMETHOD(setModuleFileName) (THIS_ const CLISTR*     name) PURE;
            CLIMETHOD(setModuleFileNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                   , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                              ) PURE;
            CLIMETHOD(setModuleInternalName) (THIS_ const CLISTR*     name) PURE;
            CLIMETHOD(setModuleInternalNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                       , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                                  ) PURE;
            CLIMETHOD(setSourceFileLine) (THIS_ const CLISTR*     srcName
                                              , UINT    line /* [in] uint  line  */
                                         ) PURE;
            CLIMETHOD(setSourceFileLineChars) (THIS_ const WCHAR*    srcName /* [in,flat] wchar  srcName[]  */
                                                   , SIZE_T    srcNameSize /* [in] size_t  srcNameSize  */
                                                   , UINT    line /* [in] uint  line  */
                                              ) PURE;
            CLIMETHOD(setArgList) (THIS_ INTERFACE_CLI_IARGLIST*    arglist /* [in] ::cli::iArgList*  arglist  */) PURE;
            CLIMETHOD(chainErrorInfo) (THIS_ INTERFACE_CLI_IERRORINFO*    pei /* [in] ::cli::iErrorInfo*  pei  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iCreateErrorInfo >
           {
            static char const * getName() { return INTERFACE_CLI_ICREATEERRORINFO_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iCreateErrorInfo* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iCreateErrorInfo > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iCreateErrorInfo wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ICREATEERRORINFO >
                                      */
                 >
        class CiCreateErrorInfoWrapper
        {
            public:
        
                typedef  CiCreateErrorInfoWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiCreateErrorInfoWrapper() :
                   pif(0) {}
        
                CiCreateErrorInfoWrapper( iCreateErrorInfo *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiCreateErrorInfoWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiCreateErrorInfoWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiCreateErrorInfoWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiCreateErrorInfoWrapper(const CiCreateErrorInfoWrapper &i) :
                    pif(i.pif) { }
        
                ~CiCreateErrorInfoWrapper()  { }
        
                CiCreateErrorInfoWrapper& operator=(const CiCreateErrorInfoWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE setErrorCode( RCODE    code /* [in] rcode  code  */)
                   {
                
                    return pif->setErrorCode(code);
                   }
                
                RCODE setModuleFileName( const ::std::wstring    &name)
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                    return pif->setModuleFileName(&tmp_name);
                   }
                
                RCODE setModuleFileNameChars( const WCHAR*    name /* [in,flat] wchar  name[]  */
                                            , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                            )
                   {
                
                
                    return pif->setModuleFileNameChars(name, nameSize);
                   }
                
                RCODE setModuleInternalName( const ::std::wstring    &name)
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                    return pif->setModuleInternalName(&tmp_name);
                   }
                
                RCODE setModuleInternalNameChars( const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                                )
                   {
                
                
                    return pif->setModuleInternalNameChars(name, nameSize);
                   }
                
                RCODE setSourceFileLine( const ::std::wstring    &srcName
                                       , UINT    line /* [in] uint  line  */
                                       )
                   {
                    CCliStr tmp_srcName; CCliStr_lightCopyTo( tmp_srcName, srcName);
                
                    return pif->setSourceFileLine(&tmp_srcName, line);
                   }
                
                RCODE setSourceFileLineChars( const WCHAR*    srcName /* [in,flat] wchar  srcName[]  */
                                            , SIZE_T    srcNameSize /* [in] size_t  srcNameSize  */
                                            , UINT    line /* [in] uint  line  */
                                            )
                   {
                
                
                
                    return pif->setSourceFileLineChars(srcName, srcNameSize, line);
                   }
                
                RCODE setArgList( INTERFACE_CLI_IARGLIST*    arglist /* [in] ::cli::iArgList*  arglist  */)
                   {
                
                    return pif->setArgList(arglist);
                   }
                
                RCODE chainErrorInfo( INTERFACE_CLI_IERRORINFO*    pei /* [in] ::cli::iErrorInfo*  pei  */)
                   {
                
                    return pif->chainErrorInfo(pei);
                   }
                

        
        
        }; // class CiCreateErrorInfoWrapper
        
        typedef CiCreateErrorInfoWrapper< ::cli::CCliPtr< INTERFACE_CLI_ICREATEERRORINFO     > >  CiCreateErrorInfo;
        typedef CiCreateErrorInfoWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICREATEERRORINFO > >  CiCreateErrorInfo_nrc; /* No ref counting for interface used */
        typedef CiCreateErrorInfoWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICREATEERRORINFO > >  CiCreateErrorInfo_tmp; /* for temporary usage, same as CiCreateErrorInfo_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IERRINFO_H */
