#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
#define CLI_DRAWING_DRAWTYPES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/drawing/drawtypes.h>", CLI_DRAWING_DRAWTYPES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::EColorref */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_ECOLORREF          COLORREF
#else
    #define ENUM_CLI_DRAWING_ECOLORREF          COLORREF
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_ECOLORREF_CONST_UNDEFINED
    #define CLI_DRAWING_ECOLORREF_CONST_UNDEFINED             CONSTANT_COLORREF(0xFFFFFFFF)
#endif /* CLI_DRAWING_ECOLORREF_CONST_UNDEFINED */

#ifndef CLI_DRAWING_ECOLORREF_CONST_TRANSPARENTWHITE
    #define CLI_DRAWING_ECOLORREF_CONST_TRANSPARENTWHITE      CONSTANT_COLORREF(0xFFFFFFFF)
#endif /* CLI_DRAWING_ECOLORREF_CONST_TRANSPARENTWHITE */

#ifndef CLI_DRAWING_ECOLORREF_CONST_WHITE
    #define CLI_DRAWING_ECOLORREF_CONST_WHITE                 CONSTANT_COLORREF(0x00FFFFFF)
#endif /* CLI_DRAWING_ECOLORREF_CONST_WHITE */

#ifndef CLI_DRAWING_ECOLORREF_CONST_BLACK
    #define CLI_DRAWING_ECOLORREF_CONST_BLACK                 CONSTANT_COLORREF(0x00000000)
#endif /* CLI_DRAWING_ECOLORREF_CONST_BLACK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace EColorref {
                    const COLORREF const_undefined  = CONSTANT_COLORREF(0xFFFFFFFF);
                    const COLORREF const_transparentWhite   = CONSTANT_COLORREF(0xFFFFFFFF);
                    const COLORREF const_white      = CONSTANT_COLORREF(0x00FFFFFF);
                    const COLORREF const_black      = CONSTANT_COLORREF(0x00000000);
            }; // namespace EColorref
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::EColorref; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::EPenStyle */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_EPENSTYLE          DWORD
#else
    #define ENUM_CLI_DRAWING_EPENSTYLE          DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_EPENSTYLE_NULL
    #define CLI_DRAWING_EPENSTYLE_NULL        CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_EPENSTYLE_NULL */

#ifndef CLI_DRAWING_EPENSTYLE_SOLID
    #define CLI_DRAWING_EPENSTYLE_SOLID       1
#endif /* CLI_DRAWING_EPENSTYLE_SOLID */

#ifndef CLI_DRAWING_EPENSTYLE_DASH
    #define CLI_DRAWING_EPENSTYLE_DASH        2
#endif /* CLI_DRAWING_EPENSTYLE_DASH */

#ifndef CLI_DRAWING_EPENSTYLE_DOT
    #define CLI_DRAWING_EPENSTYLE_DOT         3
#endif /* CLI_DRAWING_EPENSTYLE_DOT */

#ifndef CLI_DRAWING_EPENSTYLE_DASHDOT
    #define CLI_DRAWING_EPENSTYLE_DASHDOT     4
#endif /* CLI_DRAWING_EPENSTYLE_DASHDOT */

#ifndef CLI_DRAWING_EPENSTYLE_DASHDOTDOT
    #define CLI_DRAWING_EPENSTYLE_DASHDOTDOT  5
#endif /* CLI_DRAWING_EPENSTYLE_DASHDOTDOT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace EPenStyle {
                    const DWORD null             = CONSTANT_DWORD(0);
                    const DWORD solid            = CONSTANT_DWORD(1);
                    const DWORD dash             = CONSTANT_DWORD(2);
                    const DWORD dot              = CONSTANT_DWORD(3);
                    const DWORD dashdot          = CONSTANT_DWORD(4);
                    const DWORD dashdotdot       = CONSTANT_DWORD(5);
            }; // namespace EPenStyle
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::EPenStyle; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::EPenCapStyle */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_EPENCAPSTYLE       DWORD
#else
    #define ENUM_CLI_DRAWING_EPENCAPSTYLE       DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_EPENCAPSTYLE_ROUND
    #define CLI_DRAWING_EPENCAPSTYLE_ROUND    CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_EPENCAPSTYLE_ROUND */

#ifndef CLI_DRAWING_EPENCAPSTYLE_SQUARE
    #define CLI_DRAWING_EPENCAPSTYLE_SQUARE   1
#endif /* CLI_DRAWING_EPENCAPSTYLE_SQUARE */

#ifndef CLI_DRAWING_EPENCAPSTYLE_FLAT
    #define CLI_DRAWING_EPENCAPSTYLE_FLAT     2
#endif /* CLI_DRAWING_EPENCAPSTYLE_FLAT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace EPenCapStyle {
                    const DWORD round            = CONSTANT_DWORD(0);
                    const DWORD square           = CONSTANT_DWORD(1);
                    const DWORD flat             = CONSTANT_DWORD(2);
            }; // namespace EPenCapStyle
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::EPenCapStyle; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::EPenJoinStyle */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_EPENJOINSTYLE      DWORD
#else
    #define ENUM_CLI_DRAWING_EPENJOINSTYLE      DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_EPENJOINSTYLE_ROUND
    #define CLI_DRAWING_EPENJOINSTYLE_ROUND   CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_EPENJOINSTYLE_ROUND */

#ifndef CLI_DRAWING_EPENJOINSTYLE_BEVEL
    #define CLI_DRAWING_EPENJOINSTYLE_BEVEL   1
#endif /* CLI_DRAWING_EPENJOINSTYLE_BEVEL */

#ifndef CLI_DRAWING_EPENJOINSTYLE_MITER
    #define CLI_DRAWING_EPENJOINSTYLE_MITER   2
#endif /* CLI_DRAWING_EPENJOINSTYLE_MITER */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace EPenJoinStyle {
                    const DWORD round            = CONSTANT_DWORD(0);
                    const DWORD bevel            = CONSTANT_DWORD(1);
                    const DWORD miter            = CONSTANT_DWORD(2);
            }; // namespace EPenJoinStyle
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::EPenJoinStyle; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::DeviceType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_DEVICETYPE         DWORD
#else
    #define ENUM_CLI_DRAWING_DEVICETYPE         DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_DEVICETYPE_RASTERDISPAY
    #define CLI_DRAWING_DEVICETYPE_RASTERDISPAY               CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_DEVICETYPE_RASTERDISPAY */

#ifndef CLI_DRAWING_DEVICETYPE_RASTERPRINTER
    #define CLI_DRAWING_DEVICETYPE_RASTERPRINTER              1
#endif /* CLI_DRAWING_DEVICETYPE_RASTERPRINTER */

#ifndef CLI_DRAWING_DEVICETYPE_PLOTTER
    #define CLI_DRAWING_DEVICETYPE_PLOTTER    2
#endif /* CLI_DRAWING_DEVICETYPE_PLOTTER */

#ifndef CLI_DRAWING_DEVICETYPE_METAFILE
    #define CLI_DRAWING_DEVICETYPE_METAFILE   3
#endif /* CLI_DRAWING_DEVICETYPE_METAFILE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace DeviceType {
                    const DWORD rasterDispay     = CONSTANT_DWORD(0);
                    const DWORD rasterPrinter    = CONSTANT_DWORD(1);
                    const DWORD plotter          = CONSTANT_DWORD(2);
                    const DWORD metafile         = CONSTANT_DWORD(3);
            }; // namespace DeviceType
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::DeviceType; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::DeviceColorType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_DEVICECOLORTYPE    DWORD
#else
    #define ENUM_CLI_DRAWING_DEVICECOLORTYPE    DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_DEVICECOLORTYPE_BLACKWHITE
    #define CLI_DRAWING_DEVICECOLORTYPE_BLACKWHITE            CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_DEVICECOLORTYPE_BLACKWHITE */

#ifndef CLI_DRAWING_DEVICECOLORTYPE_MONOCHROME
    #define CLI_DRAWING_DEVICECOLORTYPE_MONOCHROME            1
#endif /* CLI_DRAWING_DEVICECOLORTYPE_MONOCHROME */

#ifndef CLI_DRAWING_DEVICECOLORTYPE_FULLCOLORED
    #define CLI_DRAWING_DEVICECOLORTYPE_FULLCOLORED           2
#endif /* CLI_DRAWING_DEVICECOLORTYPE_FULLCOLORED */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace DeviceColorType {
                    const DWORD blackWhite       = CONSTANT_DWORD(0);
                    const DWORD monochrome       = CONSTANT_DWORD(1);
                    const DWORD fullColored      = CONSTANT_DWORD(2);
            }; // namespace DeviceColorType
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::DeviceColorType; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::DeviceRenderFlag */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_DEVICERENDERFLAG                   DWORD
#else
    #define ENUM_CLI_DRAWING_DEVICERENDERFLAG                   DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_DEVICERENDERFLAG_DRAWDEFAULT
    #define CLI_DRAWING_DEVICERENDERFLAG_DRAWDEFAULT          CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_DEVICERENDERFLAG_DRAWDEFAULT */

#ifndef CLI_DRAWING_DEVICERENDERFLAG_USEDEFAULT
    #define CLI_DRAWING_DEVICERENDERFLAG_USEDEFAULT           CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_DEVICERENDERFLAG_USEDEFAULT */

#ifndef CLI_DRAWING_DEVICERENDERFLAG_ANTIALIASING
    #define CLI_DRAWING_DEVICERENDERFLAG_ANTIALIASING         1
#endif /* CLI_DRAWING_DEVICERENDERFLAG_ANTIALIASING */

#ifndef CLI_DRAWING_DEVICERENDERFLAG_ANTIALIASINGTEXT
    #define CLI_DRAWING_DEVICERENDERFLAG_ANTIALIASINGTEXT     2
#endif /* CLI_DRAWING_DEVICERENDERFLAG_ANTIALIASINGTEXT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace DeviceRenderFlag {
                    const DWORD drawDefault      = CONSTANT_DWORD(0);
                    const DWORD useDefault       = CONSTANT_DWORD(0);
                    const DWORD antialiasing     = CONSTANT_DWORD(1);
                    const DWORD antialiasingText = CONSTANT_DWORD(2);
            }; // namespace DeviceRenderFlag
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::DeviceRenderFlag; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::BkMode */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_BKMODE             DWORD
#else
    #define ENUM_CLI_DRAWING_BKMODE             DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_BKMODE_TRANSPARENT
    #define CLI_DRAWING_BKMODE_TRANSPARENT    1
#endif /* CLI_DRAWING_BKMODE_TRANSPARENT */

#ifndef CLI_DRAWING_BKMODE_OPAQUE
    #define CLI_DRAWING_BKMODE_OPAQUE         2
#endif /* CLI_DRAWING_BKMODE_OPAQUE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace BkMode {
                    const DWORD transparent      = CONSTANT_DWORD(1);
                    const DWORD opaque           = CONSTANT_DWORD(2);
            }; // namespace BkMode
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::BkMode; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::GradientFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_GRADIENTFLAGS      DWORD
#else
    #define ENUM_CLI_DRAWING_GRADIENTFLAGS      DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_GRADIENTFLAGS_DRAWDEFAULT
    #define CLI_DRAWING_GRADIENTFLAGS_DRAWDEFAULT             CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_GRADIENTFLAGS_DRAWDEFAULT */

#ifndef CLI_DRAWING_GRADIENTFLAGS_USEDEFAULT
    #define CLI_DRAWING_GRADIENTFLAGS_USEDEFAULT              CONSTANT_DWORD(0)
#endif /* CLI_DRAWING_GRADIENTFLAGS_USEDEFAULT */

#ifndef CLI_DRAWING_GRADIENTFLAGS_NOCURRENTPENBORDER
    #define CLI_DRAWING_GRADIENTFLAGS_NOCURRENTPENBORDER      1
#endif /* CLI_DRAWING_GRADIENTFLAGS_NOCURRENTPENBORDER */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace GradientFlags {
                    const DWORD drawDefault      = CONSTANT_DWORD(0);
                    const DWORD useDefault       = CONSTANT_DWORD(0);
                    const DWORD noCurrentPenBorder       = CONSTANT_DWORD(1);
            }; // namespace GradientFlags
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::GradientFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::font::Flags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_FONT_FLAGS         BYTE
#else
    #define ENUM_CLI_DRAWING_FONT_FLAGS         BYTE
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_FONT_FLAGS_NORMAL
    #define CLI_DRAWING_FONT_FLAGS_NORMAL     CONSTANT_BYTE(0x00)
#endif /* CLI_DRAWING_FONT_FLAGS_NORMAL */

#ifndef CLI_DRAWING_FONT_FLAGS_ITALIC
    #define CLI_DRAWING_FONT_FLAGS_ITALIC     CONSTANT_BYTE(0x01)
#endif /* CLI_DRAWING_FONT_FLAGS_ITALIC */

#ifndef CLI_DRAWING_FONT_FLAGS_UNDERLINED
    #define CLI_DRAWING_FONT_FLAGS_UNDERLINED                 CONSTANT_BYTE(0x02)
#endif /* CLI_DRAWING_FONT_FLAGS_UNDERLINED */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace font {
                namespace Flags {
                        const BYTE normal           = CONSTANT_BYTE(0x00);
                        const BYTE italic           = CONSTANT_BYTE(0x01);
                        const BYTE underlined       = CONSTANT_BYTE(0x02);
                }; // namespace Flags
            }; // namespace font
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::font::Flags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::font::Precision */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_FONT_PRECISION     BYTE
#else
    #define ENUM_CLI_DRAWING_FONT_PRECISION     BYTE
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_FONT_PRECISION_USEDEFAULT
    #define CLI_DRAWING_FONT_PRECISION_USEDEFAULT             CONSTANT_BYTE(0x00)
#endif /* CLI_DRAWING_FONT_PRECISION_USEDEFAULT */

#ifndef CLI_DRAWING_FONT_PRECISION_NOANTIALIAS
    #define CLI_DRAWING_FONT_PRECISION_NOANTIALIAS            CONSTANT_BYTE(0x01)
#endif /* CLI_DRAWING_FONT_PRECISION_NOANTIALIAS */

#ifndef CLI_DRAWING_FONT_PRECISION_PREFERANTIALIAS
    #define CLI_DRAWING_FONT_PRECISION_PREFERANTIALIAS        CONSTANT_BYTE(0x02)
#endif /* CLI_DRAWING_FONT_PRECISION_PREFERANTIALIAS */

#ifndef CLI_DRAWING_FONT_PRECISION_PREFERDEVICE
    #define CLI_DRAWING_FONT_PRECISION_PREFERDEVICE           CONSTANT_BYTE(0x04)
#endif /* CLI_DRAWING_FONT_PRECISION_PREFERDEVICE */

#ifndef CLI_DRAWING_FONT_PRECISION_PREFERRASTER
    #define CLI_DRAWING_FONT_PRECISION_PREFERRASTER           CONSTANT_BYTE(0x08)
#endif /* CLI_DRAWING_FONT_PRECISION_PREFERRASTER */

#ifndef CLI_DRAWING_FONT_PRECISION_PREFEROUTLINE
    #define CLI_DRAWING_FONT_PRECISION_PREFEROUTLINE          CONSTANT_BYTE(0x10)
#endif /* CLI_DRAWING_FONT_PRECISION_PREFEROUTLINE */

#ifndef CLI_DRAWING_FONT_PRECISION_PREFERMATCH
    #define CLI_DRAWING_FONT_PRECISION_PREFERMATCH            CONSTANT_BYTE(0x20)
#endif /* CLI_DRAWING_FONT_PRECISION_PREFERMATCH */

#ifndef CLI_DRAWING_FONT_PRECISION_PREFERQUALITY
    #define CLI_DRAWING_FONT_PRECISION_PREFERQUALITY          CONSTANT_BYTE(0x40)
#endif /* CLI_DRAWING_FONT_PRECISION_PREFERQUALITY */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace font {
                namespace Precision {
                        const BYTE useDefault       = CONSTANT_BYTE(0x00);
                        const BYTE noAntialias      = CONSTANT_BYTE(0x01);
                        const BYTE preferAntialias  = CONSTANT_BYTE(0x02);
                        const BYTE preferDevice     = CONSTANT_BYTE(0x04);
                        const BYTE preferRaster     = CONSTANT_BYTE(0x08);
                        const BYTE preferOutline    = CONSTANT_BYTE(0x10);
                        const BYTE preferMatch      = CONSTANT_BYTE(0x20);
                        const BYTE preferQuality    = CONSTANT_BYTE(0x40);
                }; // namespace Precision
            }; // namespace font
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::font::Precision; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::font::Weight */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_FONT_WEIGHT        BYTE
#else
    #define ENUM_CLI_DRAWING_FONT_WEIGHT        BYTE
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_FONT_WEIGHT_DONTCARE
    #define CLI_DRAWING_FONT_WEIGHT_DONTCARE  CONSTANT_BYTE(0)
#endif /* CLI_DRAWING_FONT_WEIGHT_DONTCARE */

#ifndef CLI_DRAWING_FONT_WEIGHT_EXTRALIGHT
    #define CLI_DRAWING_FONT_WEIGHT_EXTRALIGHT                1
#endif /* CLI_DRAWING_FONT_WEIGHT_EXTRALIGHT */

#ifndef CLI_DRAWING_FONT_WEIGHT_LIGHT
    #define CLI_DRAWING_FONT_WEIGHT_LIGHT     2
#endif /* CLI_DRAWING_FONT_WEIGHT_LIGHT */

#ifndef CLI_DRAWING_FONT_WEIGHT_NORMAL
    #define CLI_DRAWING_FONT_WEIGHT_NORMAL    3
#endif /* CLI_DRAWING_FONT_WEIGHT_NORMAL */

#ifndef CLI_DRAWING_FONT_WEIGHT_DEMIBOLD
    #define CLI_DRAWING_FONT_WEIGHT_DEMIBOLD  4
#endif /* CLI_DRAWING_FONT_WEIGHT_DEMIBOLD */

#ifndef CLI_DRAWING_FONT_WEIGHT_SEMIBOLD
    #define CLI_DRAWING_FONT_WEIGHT_SEMIBOLD  4
#endif /* CLI_DRAWING_FONT_WEIGHT_SEMIBOLD */

#ifndef CLI_DRAWING_FONT_WEIGHT_BOLD
    #define CLI_DRAWING_FONT_WEIGHT_BOLD      5
#endif /* CLI_DRAWING_FONT_WEIGHT_BOLD */

#ifndef CLI_DRAWING_FONT_WEIGHT_EXTRABOLD
    #define CLI_DRAWING_FONT_WEIGHT_EXTRABOLD                 6
#endif /* CLI_DRAWING_FONT_WEIGHT_EXTRABOLD */

#ifndef CLI_DRAWING_FONT_WEIGHT_BLACK
    #define CLI_DRAWING_FONT_WEIGHT_BLACK     7
#endif /* CLI_DRAWING_FONT_WEIGHT_BLACK */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace font {
                namespace Weight {
                        const BYTE dontCare         = CONSTANT_BYTE(0);
                        const BYTE extraLight       = CONSTANT_BYTE(1);
                        const BYTE light            = CONSTANT_BYTE(2);
                        const BYTE normal           = CONSTANT_BYTE(3);
                        const BYTE demibold         = CONSTANT_BYTE(4);
                        const BYTE semibold         = CONSTANT_BYTE(4);
                        const BYTE bold             = CONSTANT_BYTE(5);
                        const BYTE extraBold        = CONSTANT_BYTE(6);
                        const BYTE black            = CONSTANT_BYTE(7);
                }; // namespace Weight
            }; // namespace font
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::font::Weight; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::font::Pitch */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_FONT_PITCH         BYTE
#else
    #define ENUM_CLI_DRAWING_FONT_PITCH         BYTE
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_FONT_PITCH_USEDEFAULT
    #define CLI_DRAWING_FONT_PITCH_USEDEFAULT                 CONSTANT_BYTE(0)
#endif /* CLI_DRAWING_FONT_PITCH_USEDEFAULT */

#ifndef CLI_DRAWING_FONT_PITCH_FIXED
    #define CLI_DRAWING_FONT_PITCH_FIXED      1
#endif /* CLI_DRAWING_FONT_PITCH_FIXED */

#ifndef CLI_DRAWING_FONT_PITCH_VARIABLE
    #define CLI_DRAWING_FONT_PITCH_VARIABLE   2
#endif /* CLI_DRAWING_FONT_PITCH_VARIABLE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace font {
                namespace Pitch {
                        const BYTE useDefault       = CONSTANT_BYTE(0);
                        const BYTE fixed            = CONSTANT_BYTE(1);
                        const BYTE variable         = CONSTANT_BYTE(2);
                }; // namespace Pitch
            }; // namespace font
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::font::Pitch; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::drawing::font::Family */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_DRAWING_FONT_FAMILY        BYTE
#else
    #define ENUM_CLI_DRAWING_FONT_FAMILY        BYTE
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_DRAWING_FONT_FAMILY_DONTCARE
    #define CLI_DRAWING_FONT_FAMILY_DONTCARE  CONSTANT_BYTE(0)
#endif /* CLI_DRAWING_FONT_FAMILY_DONTCARE */

#ifndef CLI_DRAWING_FONT_FAMILY_ROMAN
    #define CLI_DRAWING_FONT_FAMILY_ROMAN     CONSTANT_BYTE(0x0010)
#endif /* CLI_DRAWING_FONT_FAMILY_ROMAN */

#ifndef CLI_DRAWING_FONT_FAMILY_SWISS
    #define CLI_DRAWING_FONT_FAMILY_SWISS     CONSTANT_BYTE(0x0020)
#endif /* CLI_DRAWING_FONT_FAMILY_SWISS */

#ifndef CLI_DRAWING_FONT_FAMILY_MODERN
    #define CLI_DRAWING_FONT_FAMILY_MODERN    CONSTANT_BYTE(0x0030)
#endif /* CLI_DRAWING_FONT_FAMILY_MODERN */

#ifndef CLI_DRAWING_FONT_FAMILY_SCRIPT
    #define CLI_DRAWING_FONT_FAMILY_SCRIPT    CONSTANT_BYTE(0x0040)
#endif /* CLI_DRAWING_FONT_FAMILY_SCRIPT */

#ifndef CLI_DRAWING_FONT_FAMILY_DECORATIVE
    #define CLI_DRAWING_FONT_FAMILY_DECORATIVE                CONSTANT_BYTE(0x0050)
#endif /* CLI_DRAWING_FONT_FAMILY_DECORATIVE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace font {
                namespace Family {
                        const BYTE dontCare         = CONSTANT_BYTE(0);
                        const BYTE roman            = CONSTANT_BYTE(0x0010);
                        const BYTE swiss            = CONSTANT_BYTE(0x0020);
                        const BYTE modern           = CONSTANT_BYTE(0x0030);
                        const BYTE script           = CONSTANT_BYTE(0x0040);
                        const BYTE decorative       = CONSTANT_BYTE(0x0050);
                }; // namespace Family
            }; // namespace font
        }; // namespace drawing
    }; // namespace cli
    /* using namespace ::cli::drawing::font::Family; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::drawing::CPoint */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
    #define CLI_STRUCT_NAME                   CPoint
    #ifndef STRUCT_CLI_DRAWING_CPOINT_PREDECLARED
    #define STRUCT_CLI_DRAWING_CPOINT_PREDECLARED
        struct CPoint;
        #ifndef STRUCT_CLI_DRAWING_CPOINT
            #define STRUCT_CLI_DRAWING_CPOINT         ::cli::drawing::CPoint
        #endif
        #ifndef STRUCT_CLI_DRAWING_CSIZE
            #define STRUCT_CLI_DRAWING_CSIZE          ::cli::drawing::CSize
        #endif
        typedef STRUCT_CLI_DRAWING_CPOINT         CSize;

    #endif // STRUCT_CLI_DRAWING_CPOINT_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_drawing_CPoint
    #ifndef STRUCT_CLI_DRAWING_CPOINT_PREDECLARED
    #define STRUCT_CLI_DRAWING_CPOINT_PREDECLARED
        struct  tag_cli_drawing_CPoint;
        typedef struct tag_cli_drawing_CPoint cli_drawing_CPoint;
        #ifndef STRUCT_CLI_DRAWING_CPOINT
            #define STRUCT_CLI_DRAWING_CPOINT         struct tag_cli_drawing_CPoint
        #endif
        #ifndef STRUCT_CLI_DRAWING_CSIZE
            #define STRUCT_CLI_DRAWING_CSIZE          cli_drawing_CSize
        #endif
        typedef STRUCT_CLI_DRAWING_CPOINT         cli_drawing_CSize;

    #endif // STRUCT_CLI_DRAWING_CPOINT_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_DRAWING_CPOINT_DEFINED
            #define STRUCT_CLI_DRAWING_CPOINT_DEFINED
            #include <cli/pshpack4.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                INT                         x;
                INT                         y;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_DRAWING_CPOINT_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace drawing
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::drawing::CColorPoint */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
    #define CLI_STRUCT_NAME                   CColorPoint
    #ifndef STRUCT_CLI_DRAWING_CCOLORPOINT_PREDECLARED
    #define STRUCT_CLI_DRAWING_CCOLORPOINT_PREDECLARED
        struct CColorPoint;
        #ifndef STRUCT_CLI_DRAWING_CCOLORPOINT
            #define STRUCT_CLI_DRAWING_CCOLORPOINT    ::cli::drawing::CColorPoint
        #endif
    #endif // STRUCT_CLI_DRAWING_CCOLORPOINT_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_drawing_CColorPoint
    #ifndef STRUCT_CLI_DRAWING_CCOLORPOINT_PREDECLARED
    #define STRUCT_CLI_DRAWING_CCOLORPOINT_PREDECLARED
        struct  tag_cli_drawing_CColorPoint;
        typedef struct tag_cli_drawing_CColorPoint cli_drawing_CColorPoint;
        #ifndef STRUCT_CLI_DRAWING_CCOLORPOINT
            #define STRUCT_CLI_DRAWING_CCOLORPOINT    struct tag_cli_drawing_CColorPoint
        #endif
    #endif // STRUCT_CLI_DRAWING_CCOLORPOINT_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_DRAWING_CCOLORPOINT_DEFINED
            #define STRUCT_CLI_DRAWING_CCOLORPOINT_DEFINED
            #include <cli/pshpack4.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_DRAWING_CPOINT               point;
                COLORREF                    color;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_DRAWING_CCOLORPOINT_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace drawing
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::drawing::CRect */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
    #define CLI_STRUCT_NAME                   CRect
    #ifndef STRUCT_CLI_DRAWING_CRECT_PREDECLARED
    #define STRUCT_CLI_DRAWING_CRECT_PREDECLARED
        struct CRect;
        #ifndef STRUCT_CLI_DRAWING_CRECT
            #define STRUCT_CLI_DRAWING_CRECT          ::cli::drawing::CRect
        #endif
    #endif // STRUCT_CLI_DRAWING_CRECT_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_drawing_CRect
    #ifndef STRUCT_CLI_DRAWING_CRECT_PREDECLARED
    #define STRUCT_CLI_DRAWING_CRECT_PREDECLARED
        struct  tag_cli_drawing_CRect;
        typedef struct tag_cli_drawing_CRect cli_drawing_CRect;
        #ifndef STRUCT_CLI_DRAWING_CRECT
            #define STRUCT_CLI_DRAWING_CRECT          struct tag_cli_drawing_CRect
        #endif
    #endif // STRUCT_CLI_DRAWING_CRECT_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_DRAWING_CRECT_DEFINED
            #define STRUCT_CLI_DRAWING_CRECT_DEFINED
            #include <cli/pshpack4.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                INT                         left;
                INT                         top;
                INT                         right;
                INT                         bottom;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_DRAWING_CRECT_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace drawing
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::drawing::CPenParams */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
    #define CLI_STRUCT_NAME                   CPenParams
    #ifndef STRUCT_CLI_DRAWING_CPENPARAMS_PREDECLARED
    #define STRUCT_CLI_DRAWING_CPENPARAMS_PREDECLARED
        struct CPenParams;
        #ifndef STRUCT_CLI_DRAWING_CPENPARAMS
            #define STRUCT_CLI_DRAWING_CPENPARAMS     ::cli::drawing::CPenParams
        #endif
    #endif // STRUCT_CLI_DRAWING_CPENPARAMS_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_drawing_CPenParams
    #ifndef STRUCT_CLI_DRAWING_CPENPARAMS_PREDECLARED
    #define STRUCT_CLI_DRAWING_CPENPARAMS_PREDECLARED
        struct  tag_cli_drawing_CPenParams;
        typedef struct tag_cli_drawing_CPenParams cli_drawing_CPenParams;
        #ifndef STRUCT_CLI_DRAWING_CPENPARAMS
            #define STRUCT_CLI_DRAWING_CPENPARAMS     struct tag_cli_drawing_CPenParams
        #endif
    #endif // STRUCT_CLI_DRAWING_CPENPARAMS_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_DRAWING_CPENPARAMS_DEFINED
            #define STRUCT_CLI_DRAWING_CPENPARAMS_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                COLORREF                    clr;
                INT                         width;
                ENUM_CLI_DRAWING_EPENSTYLE              style;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_DRAWING_CPENPARAMS_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace drawing
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::drawing::CDeviceColorInfo */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
    #define CLI_STRUCT_NAME                   CDeviceColorInfo
    #ifndef STRUCT_CLI_DRAWING_CDEVICECOLORINFO_PREDECLARED
    #define STRUCT_CLI_DRAWING_CDEVICECOLORINFO_PREDECLARED
        struct CDeviceColorInfo;
        #ifndef STRUCT_CLI_DRAWING_CDEVICECOLORINFO
            #define STRUCT_CLI_DRAWING_CDEVICECOLORINFO               ::cli::drawing::CDeviceColorInfo
        #endif
    #endif // STRUCT_CLI_DRAWING_CDEVICECOLORINFO_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_drawing_CDeviceColorInfo
    #ifndef STRUCT_CLI_DRAWING_CDEVICECOLORINFO_PREDECLARED
    #define STRUCT_CLI_DRAWING_CDEVICECOLORINFO_PREDECLARED
        struct  tag_cli_drawing_CDeviceColorInfo;
        typedef struct tag_cli_drawing_CDeviceColorInfo cli_drawing_CDeviceColorInfo;
        #ifndef STRUCT_CLI_DRAWING_CDEVICECOLORINFO
            #define STRUCT_CLI_DRAWING_CDEVICECOLORINFO               struct tag_cli_drawing_CDeviceColorInfo
        #endif
    #endif // STRUCT_CLI_DRAWING_CDEVICECOLORINFO_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_DRAWING_CDEVICECOLORINFO_DEFINED
            #define STRUCT_CLI_DRAWING_CDEVICECOLORINFO_DEFINED
            #include <cli/pshpack8.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                INT                         numOfColorPlanes;
                INT                         bitDepth;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_DRAWING_CDEVICECOLORINFO_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace drawing
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::drawing::font::NFProperties */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace font {
    #define CLI_STRUCT_NAME                   NFProperties
    #ifndef STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_PREDECLARED
    #define STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_PREDECLARED
        struct NFProperties;
        #ifndef STRUCT_CLI_DRAWING_FONT_NFPROPERTIES
            #define STRUCT_CLI_DRAWING_FONT_NFPROPERTIES              ::cli::drawing::font::NFProperties
        #endif
    #endif // STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_drawing_font_NFProperties
    #ifndef STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_PREDECLARED
    #define STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_PREDECLARED
        struct  tag_cli_drawing_font_NFProperties;
        typedef struct tag_cli_drawing_font_NFProperties cli_drawing_font_NFProperties;
        #ifndef STRUCT_CLI_DRAWING_FONT_NFPROPERTIES
            #define STRUCT_CLI_DRAWING_FONT_NFPROPERTIES              struct tag_cli_drawing_font_NFProperties
        #endif
    #endif // STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_PREDECLARED

#endif /* end of C-like declarations */

                #ifndef STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_DEFINED
                #define STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_DEFINED
                #include <cli/pshpack1.h>
                CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                    FONT_SIZE_T                 height;
                    ENUM_CLI_DRAWING_FONT_WEIGHT            weight;
                    ENUM_CLI_DRAWING_FONT_FLAGS             flags;
                    ENUM_CLI_DRAWING_FONT_PRECISION         precision;
                    ENUM_CLI_DRAWING_FONT_PITCH             pitch;
                    ENUM_CLI_DRAWING_FONT_FAMILY            family;
                    BYTE                        reserved;
                CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
                #include <cli/poppack.h>
                #endif // STRUCT_CLI_DRAWING_FONT_NFPROPERTIES_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; // namespace font
        }; // namespace drawing
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::drawing::font::Properties */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace drawing {
            namespace font {
    #define CLI_STRUCT_NAME                   Properties
    #ifndef STRUCT_CLI_DRAWING_FONT_PROPERTIES_PREDECLARED
    #define STRUCT_CLI_DRAWING_FONT_PROPERTIES_PREDECLARED
        struct Properties;
        #ifndef STRUCT_CLI_DRAWING_FONT_PROPERTIES
            #define STRUCT_CLI_DRAWING_FONT_PROPERTIES                ::cli::drawing::font::Properties
        #endif
    #endif // STRUCT_CLI_DRAWING_FONT_PROPERTIES_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_drawing_font_Properties
    #ifndef STRUCT_CLI_DRAWING_FONT_PROPERTIES_PREDECLARED
    #define STRUCT_CLI_DRAWING_FONT_PROPERTIES_PREDECLARED
        struct  tag_cli_drawing_font_Properties;
        typedef struct tag_cli_drawing_font_Properties cli_drawing_font_Properties;
        #ifndef STRUCT_CLI_DRAWING_FONT_PROPERTIES
            #define STRUCT_CLI_DRAWING_FONT_PROPERTIES                struct tag_cli_drawing_font_Properties
        #endif
    #endif // STRUCT_CLI_DRAWING_FONT_PROPERTIES_PREDECLARED

#endif /* end of C-like declarations */

                #ifndef STRUCT_CLI_DRAWING_FONT_PROPERTIES_DEFINED
                #define STRUCT_CLI_DRAWING_FONT_PROPERTIES_DEFINED
                #include <cli/pshpack1.h>
                CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                    FONT_SIZE_T                 height;
                    ENUM_CLI_DRAWING_FONT_WEIGHT            weight;
                    ENUM_CLI_DRAWING_FONT_FLAGS             flags;
                    ENUM_CLI_DRAWING_FONT_PRECISION         precision;
                    ENUM_CLI_DRAWING_FONT_PITCH             pitch;
                    ENUM_CLI_DRAWING_FONT_FAMILY            family;
                    BYTE                        reserved;
                    WCHAR                       faceName[32];
                CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
                #include <cli/poppack.h>
                #endif // STRUCT_CLI_DRAWING_FONT_PROPERTIES_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; // namespace font
        }; // namespace drawing
    }; // namespace cli
#endif

#endif /* CLI_DRAWING_DRAWTYPES_H */
