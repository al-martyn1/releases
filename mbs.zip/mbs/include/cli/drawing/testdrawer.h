#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_TESTDRAWER_H
#define CLI_DRAWING_TESTDRAWER_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/drawing/testdrawer.h>", CLI_DRAWING_TESTDRAWER_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_TESTDRAWER_H
    #include <cli/drawing/testdrawer.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_DRAWING_DCOWNER_H
    #include <cli/drawing/dcowner.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::drawing::test::iTestDrawer */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace app {
            interface                                iConfig;
            #ifndef INTERFACE_CLI_APP_ICONFIG
                #define INTERFACE_CLI_APP_ICONFIG         ::cli::app::iConfig
            #endif

        }; // namespace app
    }; // namespace cli
    namespace cli {
        namespace drawing {
            interface                                iDcOwner;
            #ifndef INTERFACE_CLI_DRAWING_IDCOWNER
                #define INTERFACE_CLI_DRAWING_IDCOWNER    ::cli::drawing::iDcOwner
            #endif

            interface                                iDrawContext1;
            #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
                #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               ::cli::drawing::iDrawContext1
            #endif

        }; // namespace drawing
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_APP_ICONFIG_PREDECLARED
    #define INTERFACE_CLI_APP_ICONFIG_PREDECLARED
    typedef interface tag_cli_app_iConfig    cli_app_iConfig;
    #endif //INTERFACE_CLI_APP_ICONFIG
    #ifndef INTERFACE_CLI_APP_ICONFIG
        #define INTERFACE_CLI_APP_ICONFIG         struct tag_cli_app_iConfig
    #endif

    #ifndef INTERFACE_CLI_DRAWING_IDCOWNER_PREDECLARED
    #define INTERFACE_CLI_DRAWING_IDCOWNER_PREDECLARED
    typedef interface tag_cli_drawing_iDcOwner                   cli_drawing_iDcOwner;
    #endif //INTERFACE_CLI_DRAWING_IDCOWNER
    #ifndef INTERFACE_CLI_DRAWING_IDCOWNER
        #define INTERFACE_CLI_DRAWING_IDCOWNER    struct tag_cli_drawing_iDcOwner
    #endif

    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_PREDECLARED
    #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_PREDECLARED
    typedef interface tag_cli_drawing_iDrawContext1              cli_drawing_iDrawContext1;
    #endif //INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
        #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               struct tag_cli_drawing_iDrawContext1
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER_IID
    #define INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER_IID    "/cli/drawing/test/iTestDrawer"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace drawing {
            namespace test {
    #define INTERFACE iTestDrawer
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER
       #define INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER    ::cli::drawing::test::iTestDrawer
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_drawing_test_iTestDrawer
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER
       #define INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER    cli_drawing_test_iTestDrawer
    #endif
#endif

                CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                {
                    
                    /* interface ::cli::iUnknown methods */
                    CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                   , VOID**    ifPtr /* [out] void* ifPtr  */
                                              ) PURE;
                    CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                    CLIMETHOD_(ULONG, release) (THIS) PURE;
                    
                    /* interface ::cli::drawing::test::iTestDrawer methods */
                    CLIMETHOD(drawSample) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                               , INTERFACE_CLI_APP_ICONFIG*    iAppConfig /* [in] ::cli::app::iConfig*  iAppConfig  */
                                          ) PURE;
                    CLIMETHOD_(BOOL, hitTest) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    hitPoint /* [in,ref] ::cli::drawing::CPoint  hitPoint  */) PURE;
                    CLIMETHOD_(BOOL, miceClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    hitPoint /* [in,ref] ::cli::drawing::CPoint  hitPoint  */
                                                     , BOOL    bRightClick /* [in] bool  bRightClick  */
                                                     , BOOL    bUp /* [in] bool  bUp  */
                                                     , BOOL    bDoubleClick /* [in] bool  bDoubleClick  */
                                                ) PURE;
                    CLIMETHOD(dcOwnerSet) (THIS_ INTERFACE_CLI_DRAWING_IDCOWNER*    _dcOwner /* [in] ::cli::drawing::iDcOwner*  _dcOwner  */) PURE;
                };

#if defined(__cplusplus) && !defined(CINTERFACE)

            }; // namespace test
        }; // namespace drawing
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::drawing::test::iTestDrawer >
           {
            static char const * getName() { return INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::drawing::test::iTestDrawer* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::drawing::test::iTestDrawer > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace drawing {
            namespace test {
                // interface ::cli::drawing::test::iTestDrawer wrapper
                // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
                template <
                          typename smartPtrType
                                              /*
                                              =
                                                  ::cli::CCliPtr< INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER >
                                              */
                         >
                class CiTestDrawerWrapper
                {
                    public:
                
                        typedef  CiTestDrawerWrapper< smartPtrType >           wrapper_type;
                        typedef  typename smartPtrType::interface_type              interface_type;
                        typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                        typedef  typename smartPtrType::pointer_type                pointer_type;
                
                    protected:
                
                        // pointer to interface variable name
                        // allways must be pif - autogeneration depends on this name
                        smartPtrType                pif;
                
                    public:
                
                        CiTestDrawerWrapper() :
                           pif(0) {}
                
                        CiTestDrawerWrapper( iTestDrawer *_pi, bool noAddRef=false) :
                           pif(_pi, noAddRef)
                          { }
                
                        operator bool() const { return bool(pif); }
                        bool operator!() const { return pif.operator!(); }
                        interface_pointer_type* getPP() { return pif.getPP(); }
                
                        interface_pointer_type getIfPtr()
                           {
                            interface_pointer_type* ptrPtr = pif.getPP();
                            if (!ptrPtr) return 0;
                            return *ptrPtr;
                           }
                
                        void release()
                           {
                            pif.release();
                           }
                
                        CiTestDrawerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           RCODE res = pif.createObject( componentId, pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                        CiTestDrawerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                           pif(0)
                          {
                           if (componentId.empty())
                              throw ::std::runtime_error("Empty component name taken");
                           RCODE res = pif.createObject( componentId.c_str(), pOuter );
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Failed to create requiested component");
                          }
                
                       CiTestDrawerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                           pif(0)
                          {
                           ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                           RCODE res = tmpPtr.queryInterface(pif);
                           if (RC_FAIL(res))
                              throw ::std::runtime_error("Requested interface not supported by object");
                          }
                
                        CiTestDrawerWrapper(const CiTestDrawerWrapper &i) :
                            pif(i.pif) { }
                
                        ~CiTestDrawerWrapper()  { }
                
                        CiTestDrawerWrapper& operator=(const CiTestDrawerWrapper &i)
                           {
                            if (&i!=this) pif = i.pif;
                            return *this;
                           }
                
                        template <typename T>
                        RCODE queryInterface( T **t)
                          {
                           return pif.queryInterface(t);
                          }
                
                        template <typename T>
                        RCODE queryInterface( T &t)
                          {
                           t.release();
                           return pif.queryInterface(t.getPP());
                          }
                
                        RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                           {
                            return pif.createObject(componentId, pOuter);
                           }
                
                
                        // Automaticaly generated methods code goes here
                
                        RCODE drawSample( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                        , INTERFACE_CLI_APP_ICONFIG*    iAppConfig /* [in] ::cli::app::iConfig*  iAppConfig  */
                                        )
                           {
                        
                        
                            return pif->drawSample(pdc, iAppConfig);
                           }
                        
                        BOOL hitTest( const STRUCT_CLI_DRAWING_CPOINT    &hitPoint /* [in,ref] ::cli::drawing::CPoint  hitPoint  (struct passed by ref in wrapper) */)
                           {
                        
                            return pif->hitTest(&hitPoint);
                           }
                        
                        BOOL miceClick( const STRUCT_CLI_DRAWING_CPOINT    &hitPoint /* [in,ref] ::cli::drawing::CPoint  hitPoint  (struct passed by ref in wrapper) */
                                      , BOOL    bRightClick /* [in] bool  bRightClick  */
                                      , BOOL    bUp /* [in] bool  bUp  */
                                      , BOOL    bDoubleClick /* [in] bool  bDoubleClick  */
                                      )
                           {
                        
                        
                        
                        
                            return pif->miceClick(&hitPoint, bRightClick, bUp, bDoubleClick);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                        
                        void set_dcOwner( INTERFACE_CLI_DRAWING_IDCOWNER* _dcOwner
                                        )
                           {
                            RCODE res = dcOwnerSet( _dcOwner );
                            CLI_CHECK_SET_PROPERTY_RESULT(res);
                           }
                        
                        #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                        /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                           By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                        CLI_DECLARE_PROPERTY_W(wrapper_type, INTERFACE_CLI_DRAWING_IDCOWNER*, dcOwner );
                        #endif /* CLI_WRAPPER_NO_PROPERTIES */
                        
                        #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                        
                        
                        RCODE dcOwnerSet( INTERFACE_CLI_DRAWING_IDCOWNER*    _dcOwner /* [in] ::cli::drawing::iDcOwner*  _dcOwner  */)
                           {
                        
                            return pif->dcOwnerSet(_dcOwner);
                           }
                        

                
                
                }; // class CiTestDrawerWrapper
                
                typedef CiTestDrawerWrapper< ::cli::CCliPtr< INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER     > >  CiTestDrawer;
                typedef CiTestDrawerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER > >  CiTestDrawer_nrc; /* No ref counting for interface used */
                typedef CiTestDrawerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_DRAWING_TEST_ITESTDRAWER > >  CiTestDrawer_tmp; /* for temporary usage, same as CiTestDrawer_nrc */
                
                
                
                
                
            }; // namespace test
        }; // namespace drawing
    }; // namespace cli

#endif





#endif /* CLI_DRAWING_TESTDRAWER_H */
