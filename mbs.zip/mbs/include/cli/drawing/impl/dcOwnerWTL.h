#ifndef CLI_DRAWING_IMPL_DCOWNERWIN32_H
#define CLI_DRAWING_IMPL_DCOWNERWIN32_H

/*
#ifndef CLI_DRAWING_IMPL_DCOWNERWTL_H
    #include <cli/drawing/impl/dcOwnerWTL.h>
#endif
*/

#ifndef CLI_DRAWING_IMPL_DCOWNERBASE_H
    #include <cli/drawing/impl/dcownerbase.h>
#endif

#ifndef CLI_DRAWING_IMPL_DC1WIN_H
    #include <cli/drawing/impl/dc1win.h>
#endif

/*
#ifndef __ATLGDIX_H__
   #error "dcOwnerWTL.h requires atlgdix.h to be included first. Atlgdix.h was wroten by Bjarke Viksoe (bjarke@viksoe.dk), see http://www.viksoe.dk/code/atlgdix.htm"
#endif
*/
namespace cli {
namespace drawing {
namespace impl{
namespace wtl{


// Based on Bjarke's Viksoe (bjarke@viksoe.dk) COffscreenDraw class, see http://www.viksoe.dk/code/atlgdix.htm
class COffscreenPartialDC : public WTL::CDC
{
   // self dc - managed
public:
   WTL::CDC /* Handle */      m_dc;          // Owner DC                    // unmanaged
   CBitmap       m_bitmap;      // Offscreen bitmap            // managed
   CBitmapHandle m_hOldBitmap;  // Originally selected bitmap  // unmanaged
   RECT          m_rc;          // Rectangle of drawing area

   bool useUpdateRect;
   RECT updateRect;

   int getUpdateWidth() const  { return updateRect.right - updateRect.left; }
   int getUpdateHeight() const { return updateRect.bottom - updateRect.top; }

   COffscreenPartialDC( HWND _hwnd // HDC hDC
                      , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate = 0
                      , bool bForUpdate = false
                      )
   {
      //ATLASSERT(hDC!=NULL);
      //m_dc = hDC;

      m_dc = ::GetDC( _hwnd );

      RECT clientRect;
      ::GetClientRect( _hwnd, &clientRect );
      m_rc = clientRect;

      if (!rectForUpdate)
         {
          useUpdateRect = false;
         }
      else
         {
          useUpdateRect = true;
          updateRect.left   = rectForUpdate->left  ;
          updateRect.top    = rectForUpdate->top   ;
          updateRect.right  = rectForUpdate->right ;
          updateRect.bottom = rectForUpdate->bottom;
         }

      CreateCompatibleDC(m_dc);
      ::LPtoDP(m_dc, (LPPOINT) &m_rc, sizeof(RECT) / sizeof(POINT));
      m_bitmap.CreateCompatibleBitmap(m_dc, m_rc.right - m_rc.left, m_rc.bottom - m_rc.top);
      m_hOldBitmap = SelectBitmap(m_bitmap);
      ::DPtoLP(m_dc, (LPPOINT) &m_rc, sizeof(RECT) / sizeof(POINT));
      SetWindowOrg(m_rc.left, m_rc.top);
      
      if (useUpdateRect)
         {
          BitBlt(updateRect.left, updateRect.top, getUpdateWidth(), getUpdateHeight(),
                 m_dc.m_hDC, updateRect.left, updateRect.top, SRCCOPY);
         }
      else if (bForUpdate)
         {
          BitBlt(m_rc.left, m_rc.top, m_rc.right - m_rc.left, m_rc.bottom - m_rc.top,
                 m_dc.m_hDC, m_rc.left, m_rc.top, SRCCOPY);
         }
      
   }

   ~COffscreenPartialDC()
   {
      // Copy the offscreen bitmap onto the screen.
      if (useUpdateRect)
      //if (false)
         {
          m_dc.BitBlt(updateRect.left, updateRect.top, getUpdateWidth(), getUpdateHeight(),
                      m_hDC, updateRect.left, updateRect.top, SRCCOPY);
         }
      else
         {
          m_dc.BitBlt(m_rc.left, m_rc.top, m_rc.right - m_rc.left, m_rc.bottom - m_rc.top,
                      m_hDC, m_rc.left, m_rc.top, SRCCOPY);
         }
      // Swap back the original bitmap.
      SelectBitmap(m_hOldBitmap);
   }
}; // class COffscreenPartialDC




class CDrawContext1Partial : public ::cli::drawing::impl::win::CDrawContext1Impl
{
    public:
        COffscreenPartialDC  partialDC;

        CDrawContext1Partial(HWND hwnd, const STRUCT_CLI_DRAWING_CRECT* rectForUpdate = 0, bool bForUpdate = false)
           : ::cli::drawing::impl::win::CDrawContext1Impl()
           , partialDC(hwnd, rectForUpdate, bForUpdate)
           {
            useRefCounting = true;
            attachClientDC( partialDC.m_hDC, hwnd);
           }
        ~CDrawContext1Partial()
           {}

        CLIMETHOD_(VOID, destroy) (THIS)
           {
           if (BaseImpl::useRefCounting)
           #include <cli/compspec/delthis.h>
           }
        

}; // class CDrawContext1Partial




class CDCOwnerImpl : public CDCOwnerImplBase
{
    HWND hwndOwner;

public:

    CDCOwnerImpl( HWND hwnd = 0 )  : hwndOwner(hwnd) { }
    void setOwnerWindow(HWND hwnd) { hwndOwner = hwnd; }

    CLIMETHOD(dcCreateForPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
       {
        CLI_TRY{
                CDrawContext1Partial *pdcImpl = new CDrawContext1Partial(hwndOwner);
                RCODE res = pdcImpl->queryInterface( ::cli::iidOf(*pdc), (VOID**)pdc );
                pdcImpl->release();
                return res;
               }
        catch(...)
               {
                return EC_UNKNOWN_INTERFACE;
               }
        //CLI_CATCH_RETURN_CLI_EXCEPTION()
        //CLI_CATCH_RETURN_STD_EXCEPTIONS()
       }

    CLIMETHOD(dcCreateForUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                   , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate /* [in,ref,optional] ::cli::drawing::CRect  rectForUpdate  */
                              )
       {
        CLI_TRY{
                CDrawContext1Partial *pdcImpl = new CDrawContext1Partial(hwndOwner, rectForUpdate, true);
                RCODE res = pdcImpl->queryInterface( ::cli::iidOf(*pdc), (VOID**)pdc );
                pdcImpl->release();
                return res;
               }
        catch(...)
               {
                return EC_UNKNOWN_INTERFACE;
               }
       }

    #if 0
    CLIMETHOD(posToScreen) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    pos /* [in,ref] ::cli::drawing::CPoint  pos  */
                                , STRUCT_CLI_DRAWING_CPOINT*    screenPos /* [out] ::cli::drawing::CPoint screenPos  */
                           )
       {
        if (!pos || !screenPos) return EC_INVALID_PARAM;
        POINT ps; ps.x = pos->x; ps.y = pos->y;
        ::ClientToScreen( hwndOwner, &ps );
        screenPos->x = ps.x; screenPos->y = ps.y;
        return EC_OK;
       }
    #endif


}; // class CDCOwnerImpl



}; /* namespace wtl */
}; /* namespace impl */
}; /* namespace drawing */
}; /* namespace cli */




#endif /* CLI_DRAWING_IMPL_DCOWNERWIN32_H */

