#ifndef CLI_DRAWING_IMPL_DCOWNERWIN32_H
#define CLI_DRAWING_IMPL_DCOWNERWIN32_H

/*
#ifndef CLI_DRAWING_IMPL_DCOWNERWTL_H
    #include <cli/drawing/impl/dcOwnerWTL.h>
#endif
*/

#ifndef CLI_DRAWING_IMPL_DCOWNERBASE_H
    #include <cli/drawing/impl/dcownerbase.h>
#endif

#ifndef CLI_DRAWING_IMPL_DC1WX_H
    #include <cli/drawing/impl/dc1wx.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#include <wx/dcclient.h>
#include <wx/dcmemory.h>



namespace cli {
namespace drawing {
namespace impl{
namespace wx{

/*
int sizeX = 0, sizeY = 0;
//this->GetSize(&sizeX, &sizeY);
_pwnd->GetClientSize(&sizeX, &sizeY);

    wxSize s = GetClientSize();
    if((m_bitmap->GetWidth() != s.GetWidth()) ||
      (m_bitmap->GetHeight() != s.GetHeight())) {
       m_bitmap->Create(s.x,s.y);
    }
    wxMemoryDC dc;
    dc.SelectObject(*m_bitmap);

    wxBrush brush(this->GetBackgroundColour(), wxSOLID);
    dc.SetBackground(brush);
    dc.Clear();

    if(m_state == awxLED_BLINK) dc.DrawIcon(*m_icons[m_blink],m_x,m_y);
    else dc.DrawIcon(*m_icons[m_state & 1],m_x,m_y);

    dc.SelectObject(wxNullBitmap);
*/

template <typename TWND>
class COffscreenPartialDC
{
public:
   TWND         *pwnd;
   wxClientDC    clientDc;
   wxMemoryDC    memDc;
   wxBitmap      bitmap;
   wxSize        clientSize;

   bool useUpdateRect;
   STRUCT_CLI_DRAWING_CRECT updateRect;

   int getUpdateWidth() const  { return updateRect.right - updateRect.left; }
   int getUpdateHeight() const { return updateRect.bottom - updateRect.top; }

   COffscreenPartialDC( TWND *pw
                      , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate = 0
                      )
      : pwnd(pw)
      , clientDc(pw)
      , memDc()
      , bitmap()
      , clientSize()
      , useUpdateRect(false)
      , updateRect()
      {
       if (rectForUpdate)
          {
           updateRect = *rectForUpdate;
           useUpdateRect = true;
          }

       clientSize = pwnd->GetClientSize();
       bitmap.Create(clientSize.x, clientSize.y);
       memDc.SelectObject(bitmap);

       if (useUpdateRect)
          { // copy only part of client view
           memDc.Blit( updateRect.left, updateRect.top, getUpdateWidth(), getUpdateHeight(), &clientDc, updateRect.left, updateRect.top, wxCOPY, false, -1, -1 );
          }
       else
          { // copy all client surface
           memDc.Blit( 0, 0, clientSize.x, clientSize.y, &clientDc, 0, 0, wxCOPY, false, -1, -1 );
          }
      }

   ~COffscreenPartialDC()
      {
       // Copy the offscreen bitmap onto the screen.
       if (useUpdateRect)
          {
           clientDc.Blit( updateRect.left, updateRect.top, getUpdateWidth(), getUpdateHeight(), &memDc, updateRect.left, updateRect.top, wxCOPY, false, -1, -1 );
          }
       else
          {
           clientDc.Blit( 0, 0, clientSize.x, clientSize.y, &memDc, 0, 0, wxCOPY, false, -1, -1 );
          }
       memDc.SelectObject(wxNullBitmap);
      }

}; // class COffscreenPartialDC



// : public ::cli::drawing::impl::wx::CDrawContext1Impl<wxMemoryDC>
//class CDrawContext1Partial : public ::cli::drawing::impl::wx::CDrawContext1Impl<wxClientDC>
class CDrawContext1Partial : public ::cli::drawing::impl::wx::CDrawContext1Impl<wxMemoryDC>
{
    public:
        COffscreenPartialDC<wxWindow>  partialDC;

        CDrawContext1Partial(wxWindow *pwnd, const STRUCT_CLI_DRAWING_CRECT* rectForUpdate = 0)
           : ::cli::drawing::impl::wx::CDrawContext1Impl<wxMemoryDC>()
           //: ::cli::drawing::impl::wx::CDrawContext1Impl<wxClientDC>()
           , partialDC(pwnd, rectForUpdate)
           {
            useRefCounting = true;
            attachClientDC( partialDC.memDc, pwnd);
            //attachClientDC( partialDC.clientDc, pwnd);
           }
        ~CDrawContext1Partial()
           {}

        CLIMETHOD_(VOID, destroy) (THIS)
           {
           if (BaseImpl::useRefCounting)
           #include <cli/compspec/delthis.h>
           }
        

}; // class CDrawContext1Partial




class CDCOwnerImpl : public CDCOwnerImplBase
{
    wxWindow *wndOwner;

public:

    CDCOwnerImpl( wxWindow *pwnd = 0 )  : wndOwner(pwnd) { }
    void setOwnerWindow(wxWindow *pwnd) { wndOwner = pwnd; }

    CLIMETHOD(dcCreateForPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
       {
        CLI_TRY{
                CLIASSERT(wndOwner!=0);
                CDrawContext1Partial *pdcImpl = new CDrawContext1Partial(wndOwner);
                RCODE res = pdcImpl->queryInterface( ::cli::iidOf(*pdc), (VOID**)pdc );
                pdcImpl->release();
                return res;
               }
        catch(...)
               {
                return EC_UNKNOWN_INTERFACE;
               }
        //CLI_CATCH_RETURN_CLI_EXCEPTION()
        //CLI_CATCH_RETURN_STD_EXCEPTIONS()
       }

    CLIMETHOD(dcCreateForUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                   , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate /* [in,ref,optional] ::cli::drawing::CRect  rectForUpdate  */
                              )
       {
        CLI_TRY{
                CLIASSERT(wndOwner!=0);
                CDrawContext1Partial *pdcImpl = new CDrawContext1Partial(wndOwner, rectForUpdate);
                RCODE res = pdcImpl->queryInterface( ::cli::iidOf(*pdc), (VOID**)pdc );
                pdcImpl->release();
                return res;
               }
        catch(...)
               {
                return EC_UNKNOWN_INTERFACE;
               }
       }


}; // class CDCOwnerImpl



}; /* namespace wx */
}; /* namespace impl */
}; /* namespace drawing */
}; /* namespace cli */




#endif /* CLI_DRAWING_IMPL_DCOWNERWIN32_H */

