#ifndef CLI_DRAWING_IMPL_DBMWIN_H
#define CLI_DRAWING_IMPL_DBMWIN_H

#ifndef CLI_DRAWING_IMPL_IMPLHLP_H
    #include <cli/drawing/impl/implhlp.h>
#endif

#if !defined(_WINDOWS_)
    #include <windows.h>
#endif


namespace cli {
namespace drawing {
namespace impl {
namespace win {

class CDeviceBitmap : public ::cli::CComponentImplBase< ::cli::CRefCounter, ::cli::CDummyModule > // DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_DRAWING_IDEVICEBITMAP
                    , public INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP
{

        HBITMAP  hBitmap;
        STRUCT_CLI_DRAWING_CPOINT size;

    public:

        typedef ::cli::CComponentImplBase< ::cli::CRefCounter, ::cli::CDummyModule > base_impl;

        // create compatible with dc
        CDeviceBitmap( HDC hdc, int width, int height ) : hBitmap(0), size()
           {
            if (width<0)  width  = -width;
            if (height<0) height = -height;
            size = ::cli::drawing::impl::makePoint( width, height );
            hBitmap = ::CreateCompatibleBitmap( hdc, width, height );
           }
    
        // create compatible with dc and copies data from dc
        CDeviceBitmap( HDC hdc, int width, int height, int left, int top ) : hBitmap(0), size()
           {
            if (width<0)  width  = -width;
            if (height<0) height = -height;
            size = ::cli::drawing::impl::makePoint( width, height );
            hBitmap = ::CreateCompatibleBitmap( hdc, width, height );
    
            HDC hMemDc = ::CreateCompatibleDC(hdc);
    
            //RECT rect;
            //rect.left = left; rect.top = top; rect.right = left + width; rect.bottom = top + height;
            //::LPtoDP(hdc, (LPPOINT)&rect, sizeof(RECT) / sizeof(POINT));
            HBITMAP hOldBitmap = (HBITMAP)::SelectObject(hMemDc, (HGDIOBJ)hBitmap);
            ::BitBlt( hMemDc, 0, 0, width, height, hdc, left, top, SRCCOPY );
            ::SelectObject(hMemDc, (HGDIOBJ)hOldBitmap);
    
            ::DeleteDC(hMemDc);
           }
    
        ~CDeviceBitmap()
           {
            ::DeleteObject( (HGDIOBJ)hBitmap );
           }
    
        CLI_BEGIN_INTERFACE_MAP2(CDeviceBitmap, INTERFACE_CLI_DRAWING_IDEVICEBITMAP)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_DRAWING_IDEVICEBITMAP )
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP )
        CLI_END_INTERFACE_MAP(CDeviceBitmap)
    
        CLIMETHOD_(ULONG, addRef) (THIS)  { return addRefImpl(); }
        CLIMETHOD_(ULONG, release) (THIS) { return releaseImpl();}
    
        CLIMETHOD_(VOID, destroy) (THIS)
           {
           #include <cli/compspec/delthis.h>
           }

        CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint size  */)
           {
            if (_size) *_size = size;
            return EC_OK;
           }

        CLIMETHOD(getHandle) (THIS_ CLI_DRAWING_GENERIC_HANDLE*    dbmHandle /* [out] cli_drawing_generic_handle dbmHandle  */)
           {
            if (dbmHandle) *dbmHandle = (CLI_DRAWING_GENERIC_HANDLE)hBitmap;
            return EC_OK;
           }

        //::DeleteObject function to delete it.
}; // class CDeviceBitmap

/*
BLACKNESS Fills the destination rectangle using the color associated with index 0 in the physical palette. 
This color is black for the default physical palette.
 
DSTINVERT Inverts the destination rectangle. 
MERGECOPY Merges the colors of the source rectangle with the specified pattern by using the Boolean AND operator. 
MERGEPAINT Merges the colors of the inverted source rectangle with the colors of the destination rectangle by using the Boolean OR operator. 
NOTSRCCOPY Copies the inverted source rectangle to the destination. 
NOTSRCERASE Combines the colors of the source and destination rectangles by using the Boolean OR operator and then inverts the resultant color. 
PATCOPY Copies the specified pattern into the destination bitmap. 
PATINVERT Combines the colors of the specified pattern with the colors of the destination rectangle by using the Boolean XOR operator. 
PATPAINT Combines the colors of the pattern with the colors of the inverted source rectangle by using the Boolean OR operator. 
The result of this operation is combined with the colors of the destination rectangle by using the Boolean OR operator.
 
SRCAND Combines the colors of the source and destination rectangles by using the Boolean AND operator. 
SRCCOPY Copies the source rectangle directly to the destination rectangle. 
SRCERASE Combines the inverted colors of the destination rectangle with the colors of the source rectangle by using the Boolean AND operator. 
SRCINVERT Combines the colors of the source and destination rectangles by using the Boolean XOR operator. 
SRCPAINT Combines the colors of the source and destination rectangles by using the Boolean OR operator. 
WHITENESS 
*/

}; // namespace cli
}; // namespace drawing
}; // namespace impl
}; // namespace win





#endif /* CLI_DRAWING_IMPL_DBMWIN_H */

