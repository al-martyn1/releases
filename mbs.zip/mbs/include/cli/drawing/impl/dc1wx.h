#ifndef CLI_DRAWING_IMPL_DC1WX_H
#define CLI_DRAWING_IMPL_DC1WX_H

/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_IMPL_DC1WX_H
    #include <cli/drawing/impl/dc1wx.h>
#endif
*/

/*
#ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
#endif

#if !defined(_WINDOWS_)
    #include <windows.h>
#endif
*/

#ifndef CLI_DRAWING_DC1IMPLBASE_H
    #include <cli/drawing/impl/dc1implbase.h>
#endif

#ifndef wxUSE_UNICODE
    #include <wx/strconv.h>
#endif

#if defined(_WIN32) && !defined(WX_DISABLE_NATIVE_WIN32_DRAWING)
    #define WX_NATIVE_WIN32_DRAWING_ENABLED  1
#endif

#ifdef WX_NATIVE_WIN32_DRAWING_ENABLED
    #include <wx/msw/private.h>
    #ifndef CLI_DRAWING_IMPL_WIN32IMPLHLP_H
        #include <cli/drawing/impl/win32implhlp.h>
    #endif
#endif

#ifndef CLI_DRAWING_IMPL_WXIMPLHLP_H
    #include <cli/drawing/impl/wximplhlp.h>
#endif

#ifndef CLI_DRAWING_IMPL_DBMWX_H
    #include <cli/drawing/impl/dbmwx.h>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#if !defined(_INC_MATH) && !defined(_MATH_H_) && !defined(_MATH_H)
    #include <math.h>
#endif

#ifndef M_PI
    #define M_PI       3.14159265358979323846
#endif

/*
wxWidgets web resources
http://www.wxwidgets.info/

Docking windows
http://www.wxwidgets.info/wxaui_tutorial_1_ru
http://www.wxwidgets.info/wxaui_tutorial_2_ru


bat file for building wxWidgets samples
call "C:\Program Files\Microsoft Visual Studio 8\VC\bin\vcvars32.bat" 
nmake -NOLOGO -I -f makefile.vc USE_GUI=1 BUILD=release SHARED=0 MONOLITHIC=1 DEBUG_INFO=0 DEBUG_RUNTIME_LIBS=0 RUNTIME_LIBS=static USE_RTTI=1 USE_EXCEPTIONS=1 > make_log.txt


wxDC
wxPostScriptDC 
wxMetafileDC

http://begemotov.net/wxwidgets/common/wxwidgets-vs-qt-statistika-navevaet-na-razmyishleni/#comments

*/

namespace cli {
    namespace drawing {
        namespace impl {
            namespace wx {

// ::cli::drawing::impl::wx


                // wx double buffering - http://www.wxwidgets.info/painting_optimization_ru
                template < typename TDC
                         //, typename TWND
                         >
                class CDrawContext1Impl : public ::cli::drawing::impl::CDrawContext1ImplBase
                {
                    public:
        
                    protected:
        
                        TDC     *pdc;
                        //TWND    *pwnd;
                        DWORD    devType;
                        //int      wxFontWeightFlag;

                        ::std::stack< wxPen   > penStack;
                        ::std::stack< wxBrush > brushStack;
                        ::std::stack< wxFont  > fontStack;

                        COLORREF textColor;
                        COLORREF bkColor;
                        static const COLORREF uninitializedBkColor = 0xFF000000;

                        //wxColour toWxColor( COLORREF clr)
                        //COLORREF fromWxColor(const wxColour &wxclr)

                        
                        COLORREF fromWxColor(const wxColour &wxclr) const
                           {
                            return RGB( wxclr.Red(), wxclr.Green(), wxclr.Blue() ); // Alpha()
                           }

                        wxColour toWxColor( COLORREF clr) const
                           {
                            wxColour wxclr; wxclr.Set(adjustColor(fastScaleColor(clr))); return wxclr;
                           }

                        //int penStyleToImpl(ENUM_CLI_DRAWING_EPENSTYLE ps) const
                        //int penCapStyleToImpl(ENUM_CLI_DRAWING_EPENCAPSTYLE ps) const
                        //int penJoinStyleToImpl(ENUM_CLI_DRAWING_EPENJOINSTYLE ps) const
                        int penStyleToImpl(ENUM_CLI_DRAWING_EPENSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenStyle;
                            switch(ps)
                               {
                                case null      : return wxTRANSPARENT;
                                case solid     : return wxSOLID;
                                case dash      : return wxLONG_DASH;
                                case dot       : return wxDOT;
                                case dashdot   : return wxDOT_DASH;
                                case dashdotdot: return wxDOT_DASH;
                                default        : return wxSOLID;
                               }
                           }

                        int penCapStyleToImpl(ENUM_CLI_DRAWING_EPENCAPSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenCapStyle;
                            switch(ps)
                               {
                                case square    : return wxCAP_PROJECTING ;
                                case round     : return wxCAP_ROUND      ;
                                case flat      : return wxCAP_BUTT       ;
                                default        : return wxCAP_ROUND      ;
                               }
                           }

                        int penJoinStyleToImpl(ENUM_CLI_DRAWING_EPENJOINSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenJoinStyle;
                            switch(ps)
                               {
                                case bevel     : return wxJOIN_BEVEL    ;
                                case miter     : return wxJOIN_MITER    ;
                                case round     : return wxJOIN_ROUND    ;
                                default        : return wxJOIN_ROUND    ;
                               }
                           }

                        /*
                        int toImplFontWeight(DWORD weight, int &flag) const
                           {
                            flag &= ~(wxFONTFLAG_LIGHT|wxFONTFLAG_BOLD);
                            using namespace ::cli::drawing::font::Weight;
                            switch(weight)
                               {
                                case extraLight: flag = wxFONTFLAG_LIGHT; return wxFONTWEIGHT_LIGHT;
                                case light     :                          return wxFONTWEIGHT_LIGHT;
                                case normal    :                          return wxFONTWEIGHT_NORMAL;
                                //case demibol   : 
                                case semibold  : flag = wxFONTFLAG_BOLD;  return wxFONTWEIGHT_NORMAL
                                case bold      :                          return wxFONTWEIGHT_BOLD;
                                case extraBold : flag = wxFONTFLAG_BOLD;  return wxFONTWEIGHT_BOLD;
                                case black     :                          return wxFONTWEIGHT_MAX
                                default:                                  return wxFONTWEIGHT_NORMAL;
                               }                            
                           }
                        */
                        int toImplFontWeight(DWORD weight) const
                           {
                            using namespace ::cli::drawing::font::Weight;
                            switch(weight)
                               {
                                case extraLight: 
                                case light     :   return wxFONTWEIGHT_LIGHT;
                                case normal    :   return wxFONTWEIGHT_NORMAL;
                                //case demibol   : 
                                case semibold  :   
                                case bold      :   return wxFONTWEIGHT_BOLD;
                                case extraBold :   
                                case black     :   return wxFONTWEIGHT_BOLD;
                                                   return wxFONTWEIGHT_MAX;
                                default:           return wxFONTWEIGHT_NORMAL;
                               }                            
                           }

                        /*
                        DWORD fromImplFontWeight(int weight, int flag) const
                           {
                            using namespace ::cli::drawing::font::Weight;

                            switch()
                               {
                                case wxFONTWEIGHT_LIGHT:   if (flag&wxFONTFLAG_LIGHT) return extraLight;
                                                           else                       return light;
                                case wxFONTWEIGHT_NORMAL:  if (flag&wxFONTFLAG_BOLD)  return semibold;
                                                           else                       return normal;
                                case wxFONTWEIGHT_BOLD:    if (flag&wxFONTFLAG_BOLD)  return extraBold;
                                                           else                       return bold;
                                case wxFONTWEIGHT_MAX:                                return black;
                                default:                                              return normal;
                               }
                           }
                        */

                        DWORD fromImplFontWeight(int weight) const
                           {
                            using namespace ::cli::drawing::font::Weight;

                            switch(weight)
                               {
                                case wxFONTWEIGHT_LIGHT:   return light;
                                case wxFONTWEIGHT_NORMAL:  return normal;
                                case wxFONTWEIGHT_BOLD:    return bold;
                                case wxFONTWEIGHT_MAX:     return black;
                                default:                   return normal;
                               }
                           }

                        wxFontFamily toImplFamilyAndPitch(DWORD family, DWORD pitch) const
                           {
                            // under Wx we ignoring pitch
                            using namespace ::cli::drawing::font::Family;
                            switch(family)
                               {
                                case dontCare:   return wxFONTFAMILY_DEFAULT   ;
                                case roman:      return wxFONTFAMILY_ROMAN     ;
                                case swiss:      return wxFONTFAMILY_SWISS     ;
                                case modern:     return wxFONTFAMILY_MODERN    ;
                                case script:     return wxFONTFAMILY_SCRIPT    ;
                                case decorative: return wxFONTFAMILY_DECORATIVE;
                                default:         return wxFONTFAMILY_DEFAULT;
                               }
                           }

                        wxFont implCreateFont(const STRUCT_CLI_DRAWING_FONT_PROPERTIES* props /* , int angle tenths of degree */) const
                           {
                            #ifdef WX_NATIVE_WIN32_DRAWING_ENABLED
                            LOGFONT logfont;
                            win32implFillLogFont((HDC)pdc->GetHDC(), props, logfont);
                            //HFONG hfont = win32implCreateFont(props);

                            // hack - wxCreateFontFromLogFont is private function
                            return wxCreateFontFromLogFont(&logfont);
                            #else

                            using namespace ::cli::drawing::font;

                            int wxFontFlags = wxFONTFLAG_DEFAULT;
                            if (props->flags&Flags::italic)                          wxFontFlags |= wxFONTSTYLE_ITALIC;
                            if (props->flags&Flags::underlined)                      wxFontFlags |= wxFONTFLAG_UNDERLINED;

                            int implFontWeight = toImplFontWeight(props->weight);
                            if (implFontWeight==wxFONTWEIGHT_LIGHT)
                               {
                                wxFontFlags |= wxFONTFLAG_LIGHT;
                               }
                            else if (implFontWeight==wxFONTWEIGHT_BOLD || implFontWeight==wxFONTWEIGHT_MAX)
                               {
                                wxFontFlags |= wxFONTFLAG_BOLD;
                               }

                            if (props->precision & Precision::noAntialias)           wxFontFlags |= wxFONTFLAG_NOT_ANTIALIASED;
                            else if (props->precision & Precision::preferAntialias)  wxFontFlags |= wxFONTFLAG_ANTIALIASED;

                            wxFont *pf = wxFont::New( props->height  /* pointSize */
                                                    , toImplFamilyAndPitch(props->family, props->pitch) /*  family */ 
                                                    , wxFontFlags
                                                    , toWxString(props->faceName)
                                                     /* wxFontEncoding encoding = wxFONTENCODING_DEFAULT */ 
                                                    );
                            return *pf;
                            #endif
                           }

                    public:

                        CDrawContext1Impl() : ::cli::drawing::impl::CDrawContext1ImplBase(), pdc(0)
                                            //, pwnd(0)
                                            , devType( ::cli::drawing::DeviceType::rasterDispay )
                                            , penStack()
                                            , brushStack()
                                            //, wxFontWeightFlag(0)
                                            , fontStack()
                                            , textColor(0)
                                            , bkColor(uninitializedBkColor)
                                            {}

                        ~CDrawContext1Impl()
                           {
                            CLIASSERT(penStack.size()==0);
                            CLIASSERT(brushStack.size()==0);
                            CLIASSERT(fontStack.size()==0);
                           }

                        CLIMETHOD_(VOID, destroy) (THIS)
                           {
                           if (useRefCounting)
                           #include <cli/compspec/delthis.h>
                           }

                        void detachDC() {}

                    protected:

                    public:

                        void attachDC(TDC &_pdc,  /* TWND *_pwnd,  */ const CPoint &_offset, const CPoint &_size)
                           {
                            pdc  = &_pdc;
                            //pwnd = _pwnd;
                            setOffset(_offset);
                            setSize(_size);
                            setBkMode( ::cli::drawing::BkMode::transparent );
                            setDeviceRenderFlags( 0 );
                            //setupLikeDisplay();
                           }

                    public:

                        template <typename TWND>
                        void attachClientDC(TDC &_pdc, TWND *_pwnd, const CPoint &_offset, const CPoint &_size)
                           {
                            devType = ::cli::drawing::DeviceType::rasterDispay;
                            attachDC(_pdc,  /* _pwnd,  */ _offset, _size);
                           }

                        template <typename TWND>
                        void attachClientDC(TDC &_pdc, TWND *_pwnd, const CPoint &_offset)
                           {
                            int sizeX = 0, sizeY = 0;
                            //this->GetSize(&sizeX, &sizeY);
                            _pwnd->GetClientSize(&sizeX, &sizeY);
                            attachClientDC(_pdc, _pwnd, _offset, CPoint( sizeX, sizeY ));
                           }

                        template <typename TWND>
                        void attachClientDC(TDC &_pdc, TWND *_pwnd) { attachClientDC(_pdc, _pwnd, CPoint(0) ); }

                        #ifndef _WIN32
                            //#error "wxWidget does not support printing on this platform"
                        #else

                        // _pdc        must be wxPrinterDC
                        void attachPrinterDC(TDC &_pdc, const CPoint &_offset, const CPoint &_size)
                           {
                            devType = ::cli::drawing::DeviceType::rasterPrinter;
                            attachDC(_pdc,  /* _pwnd, */  _offset, _size);
                           }

                        void attachPrinterDC(TDC &_pdc, const CPoint &_offset)
                           { attachPrinterDC(_pdc,  /* _pPrinter, */  _offset, CPoint(_pdc->GetWidth(), _pdc->GetHeight()) ); }

                        void attachPrinterDC(TDC &_pdc)
                           { attachPrinterDC(_pdc,  /* _pPrinter, */  CPoint(0,0) ); }

                        #endif



                        /* interface ::cli::drawing::iDrawContext1 methods */
                        CLIMETHOD(getDpi) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    dpi /* [out,ref] ::cli::drawing::CPoint dpi  */)
                           {
                            if (!dpi) return 0;
                            wxSize ppi = pdc->GetPPI();
                            dpi->x = ppi.GetWidth();
                            dpi->y = ppi.GetHeight();
                            if (!dpi->x) dpi->x = 96;
                            if (!dpi->y) dpi->y = 96;
                            return 0;
                           }

                        CLIMETHOD_(DWORD, getDeviceType) (THIS)
                           {
                            return devType;
                           }

                        CLIMETHOD_(DWORD, setDeviceRenderFlags) (THIS_ DWORD    newFlags /* [in] ::cli::drawing::DeviceRenderFlag  newFlags  */)
                           {
                            return 0;
                           }


                        int getRealColorPlanes()
                           {
                            // TODO: return real num color planes here
                            return 3;
                           }

                        int getRealBitDepth()
                           { // TODO: return real bit depth here
                            return 8;
                           }


                        CLIMETHOD(setPixel) (THIS_ INT    x /* [in] int  x  */
                                                 , INT    y /* [in] int  y  */
                                                 , COLORREF    clr /* [in] colorref  clr  */
                                            )
                           {
                            coordToDcCoord(x, y);
                            wxPen prevPen = pdc->GetPen();
                            pdc->SetPen(wxPen(toWxColor(clr)));
                            //pdc->SetPen( wxPen( wxT("white"), 1, wxSOLID) );
                            pdc->DrawPoint( x, y);
                            // Draws a point using the color of the current pen. Note that the other properties of the pen are not used, such as width etc..
                            pdc->SetPen(prevPen);
                            return 0;
                           }

                        CLIMETHOD(setPixelPoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,ref] ::cli::drawing::CPoint  p  */
                                                      , COLORREF    clr /* [in] colorref  clr  */
                                                 )
                           {
                            CPoint pTmp;
                            coordToDcCoord( pTmp, *p );
                            wxPen prevPen = pdc->GetPen();
                            pdc->SetPen(wxPen(toWxColor(clr)));
                            pdc->DrawPoint( pTmp.x, pTmp.y );
                            pdc->SetPen(prevPen);
                            return 0;
                           }

                        CLIMETHOD(setPixels) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in] ::cli::drawing::CPoint  p[]  */
                                                  , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                                  , COLORREF    clr /* [in] colorref  clr  */
                                             )
                           {
                            wxPen prevPen = pdc->GetPen();
                            pdc->SetPen(wxPen(toWxColor(clr)));
                            for (SIZE_T i = 0; i!=numPoints; ++i, ++p)
                               {
                                CPoint pTmp;
                                coordToDcCoord( pTmp, *p );
                                pdc->DrawPoint( pTmp.x, pTmp.y );
                               }
                            pdc->SetPen(prevPen);
                            return 0;
                           }

                        CLIMETHOD(setPen) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                               , INT    width /* [in] int  width  */
                                               , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::PenStyle  style  */
                                          )
                           {
                            //wxPen wxpen(toWxColor(clr), scalePenWidth(width), penStyleToImpl(style));
                            pdc->SetPen( wxPen( toWxColor(clr)
                                              , width ? scalePenWidth(width) : 1
                                              , penStyleToImpl(style)
                                              )
                                       );
                            return 0;
                           }

                        CLIMETHOD(pushSetPen) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                   , INT    width /* [in] int  width  */
                                                   , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::PenStyle  style  */
                                              )
                           {
                            penStack.push(pdc->GetPen());
                            pdc->SetPen( wxPen( toWxColor(clr)
                                              , width ? scalePenWidth(width) : 1
                                              , penStyleToImpl(style)
                                              )
                                       );
                            return 0;
                           }

                        CLIMETHOD(setPenEx) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                 , INT    width /* [in] int  width  */
                                                 , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                                 , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                                 , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                            )
                           {
                            wxPen wxp( toWxColor(clr)
                                     , width ? scalePenWidth(width) : 1
                                     , penStyleToImpl(style)
                                     );
                            wxp.SetCap( penCapStyleToImpl(capStyle) );
                            wxp.SetJoin( penJoinStyleToImpl(joinStyle) );
                            pdc->SetPen( wxp );
                            return 0;
                           }

                        //int penStyleToImpl(ENUM_CLI_DRAWING_EPENSTYLE ps) const
                        //int penCapStyleToImpl(ENUM_CLI_DRAWING_EPENCAPSTYLE ps) const
                        //int penJoinStyleToImpl(ENUM_CLI_DRAWING_EPENJOINSTYLE ps) const

                        CLIMETHOD(pushSetPenEx) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                     , INT    width /* [in] int  width  */
                                                     , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                                     , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                                     , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                                )
                           {
                            penStack.push(pdc->GetPen());
                            wxPen wxp( toWxColor(clr)
                                     , width ? scalePenWidth(width) : 1
                                     , penStyleToImpl(style)
                                     );
                            wxp.SetCap( penCapStyleToImpl(capStyle) );
                            wxp.SetJoin( penJoinStyleToImpl(joinStyle) );
                            pdc->SetPen( wxp );
                            return 0;
                           }

                        CLIMETHOD(popPen) (THIS)
                           {
                            if (penStack.empty()) return 0; // no pens for restoring
                            wxPen wxpen = penStack.top(); penStack.pop();
                            pdc->SetPen( wxpen );
                            return 0;
                           }

                        CLIMETHOD(drawLine) (THIS_ INT    x1 /* [in] int  x1  */
                                                 , INT    y1 /* [in] int  y1  */
                                                 , INT    x2 /* [in] int  x2  */
                                                 , INT    y2 /* [in] int  y2  */
                                            )
                           {
                            coordToDcCoord(x1, y1);
                            coordToDcCoord(x2, y2);
                            pdc->DrawLine(x1, y1, x2, y2);
                            return 0;
                           }

                        CLIMETHOD(drawLinePoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    pointFrom /* [in,ref] ::cli::drawing::CPoint  pointFrom  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    pointTo /* [in,ref] ::cli::drawing::CPoint  pointTo  */
                                                 )
                           {
                            CPoint pTmp1, pTmp2;
                            coordToDcCoord( pTmp1, *pointFrom );
                            coordToDcCoord( pTmp2, *pointTo );
                            pdc->DrawLine(pTmp1.x, pTmp1.y, pTmp2.x, pTmp2.y);
                            return 0;
                           }

                        CLIMETHOD(drawLines) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    points /* [in] ::cli::drawing::CPoint  points[]  */
                                                  , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                             )
                           {
                            if (!points || numPoints<2) return 0;
                            CPoint startPoint, endPoint;
                            coordToDcCoord( endPoint, *points );
                            --numPoints; ++points;
                            for(; numPoints!=0; --numPoints, ++points)
                               {
                                startPoint = endPoint;
                                coordToDcCoord( endPoint, *points );
                                pdc->DrawLine(startPoint.x, startPoint.y, endPoint.x, endPoint.y);
                               }                           
                            return 0;
                           }

                        CLIMETHOD(drawLinesPairPoints) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    points /* [in] ::cli::drawing::CPoint  points[]  */
                                                      , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                                 )
                           {
                            if (!points || numPoints<2) return 0;
                            for(; numPoints>1; numPoints-=2, points+=2)
                               {
                                drawLinePoint(points, points+1);
                               }
                            return 0;
                           }

                        CLIMETHOD(setSolidBrush) (THIS_ COLORREF    clr /* [in] colorref  clr  */)
                           {
                            pdc->SetBrush( wxBrush(toWxColor(clr), wxSOLID) );
                            return 0;
                           }

                        CLIMETHOD(setNullBrush) (THIS)
                           {
                            pdc->SetBrush( wxBrush( wxColour(0,0,0), wxTRANSPARENT) );
                            return 0;
                           }

                        CLIMETHOD(pushSetSolidBrush) (THIS_ COLORREF    clr /* [in] colorref  clr  */)
                           {
                            brushStack.push(pdc->GetBrush());
                            pdc->SetBrush( wxBrush(toWxColor(clr), wxSOLID) );
                            return 0;
                           }

                        CLIMETHOD(pushSetNullBrush) (THIS)
                           {
                            brushStack.push(pdc->GetBrush());
                            pdc->SetBrush( wxBrush( wxColour(0,0,0), wxTRANSPARENT) );
                            return 0;
                           }

                        CLIMETHOD(popBrush) (THIS)
                           {
                            if (brushStack.empty()) return 0;
                            pdc->SetBrush( brushStack.top() );
                            brushStack.pop();
                            return 0;
                           }

                        //rectToDcCoord( STRUCT_CLI_DRAWING_CRECT &rectDst, STRUCT_CLI_DRAWING_CRECT &rectSrc)
                        //void coordToDcCoord(CPoint &coordDst, const CPoint &coordSrc)
                        CLIMETHOD(fillRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            return fillRectWH( &leftTop, &widthHeight);
                           }

                        CLIMETHOD(fillRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                              )
                           {
                            if (!leftTop || !widthHeight) return 0;

                            wxPen prevPen = pdc->GetPen();
                            setPen(0, 0, cli::drawing::EPenStyle::null ); // set null pen

                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            //coordToDcCoord(wh, *widthHeight);
                            sizeToDcSize(wh, *widthHeight);
                            pdc->DrawRectangle(lt.x, lt.y, wh.x, wh.y);
                            pdc->SetPen(prevPen); // restore old pen
                            // Draws a rectangle with the given top left corner, and with the given size. 
                            // The current pen is used for the outline and the current brush for filling the shape.
                            return 0;
                           }

                        #ifdef UNDEFINED
                        CLIMETHOD(drawChord) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                             )
                           {
                            return 0;
                           }

                        CLIMETHOD(drawChordWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                               )
                           {
                            return 0;
                           }

                        CLIMETHOD(drawPie) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                           )
                           {
                            return 0;
                           }

                        CLIMETHOD(drawPieWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                             )
                           {
                            return 0;
                           }
                        #endif // UNDEFINED

                        CLIMETHOD(drawEllipse) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            drawEllipseWH(&leftTop, &widthHeight);
                            return 0;
                           }

                        CLIMETHOD(drawEllipseWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            sizeToDcSize(wh, *widthHeight);
                            //coordToDcCoord(wh, *widthHeight);
                            pdc->DrawEllipse( lt.x, lt.y, wh.x, wh.y );
                            return 0;
                           }

                        CLIMETHOD(drawRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            drawRectWH(&leftTop, &widthHeight);
                            return 0;
                           }

                        CLIMETHOD(drawRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                              )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            sizeToDcSize(wh, *widthHeight);
                            //coordToDcCoord(wh, *widthHeight);
                            pdc->DrawRectangle( lt.x, lt.y, wh.x, wh.y );
                            return 0;
                           }

                        CLIMETHOD(drawRoundRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                      , INT    radius /* [in] int  radius  */
                                                 )
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            drawRoundRectWH(&leftTop, &widthHeight, radius);
                            return 0;
                           }

                        CLIMETHOD(drawRoundRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                        , INT    radius /* [in] int  radius  */
                                                   )

                           {
                            if (!leftTop || !widthHeight) return 0;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            sizeToDcSize(wh, *widthHeight);
                            //coordToDcCoord(wh, *widthHeight);
                            INT radiusX = radius, radiusY = radius; sizeToDcSize(radiusX, radiusY);
                            pdc->DrawRoundedRectangle( lt.x, lt.y, wh.x, wh.y, double(radiusX+radiusY)/2 ); // get average radius value
                            return 0;
                           }

                        //::cli::drawing::BkMode
                        //opaque
                        //transparent
                        CLIMETHOD_(DWORD, getBkMode) (THIS)
                           {
                            int mode = pdc->GetBackgroundMode();
                            using namespace ::cli::drawing::BkMode;
                            switch(mode)
                               {
                                case wxSOLID:       return opaque;
                                case wxTRANSPARENT: return transparent; 
                               }
                            return 0;
                           }

                        CLIMETHOD_(DWORD, setBkMode) (THIS_ DWORD    mode /* [in] ::cli::drawing::BkMode  mode  */)
                           {
                            using namespace ::cli::drawing::BkMode;
                            DWORD prevMode = getBkMode();                            
                            switch(mode)
                               {
                                case transparent:  pdc->SetBackgroundMode(wxTRANSPARENT); break;
                                case opaque:       pdc->SetBackgroundMode(wxSOLID); break;
                                default:           return 0;
                               }
                            return prevMode;
                           }

                        //wxColour toWxColor( COLORREF clr)
                        //COLORREF fromWxColor(const wxColour &wxclr)
                        CLIMETHOD_(COLORREF, getBkColor) (THIS)
                           {
                            if (bkColor==uninitializedBkColor)
                               {
                                bkColor = fromWxColor( pdc->GetTextBackground() );
                               }
                            return bkColor;
                           }

                        CLIMETHOD_(COLORREF, setBkColor) (THIS_ COLORREF    color /* [in] colorref  color  */)
                           {
                            COLORREF prevBkColor = getBkColor();
                            bkColor = color;
                            pdc->SetTextBackground( toWxColor(color) );
                            return prevBkColor;
                           }

                        CLIMETHOD(bkColorGet) (THIS_ COLORREF*    _bkColor /* [out] colorref bkColor  */)
                           {
                            if (!_bkColor) return EC_INVALID_PARAM;
                            *_bkColor = getBkColor();
                            return EC_OK;
                           }

                        CLIMETHOD(bkColorSet) (THIS_ COLORREF    _bkColor /* [in] colorref  bkColor  */)
                           { 
                            setBkColor(_bkColor); 
                            return EC_OK;
                           }

                        CLIMETHOD_(COLORREF, getTextColor) (THIS)
                           {
                            //return fromWxColor( pdc->GetTextForeground() );
                            return textColor;
                           }

                        CLIMETHOD_(COLORREF, setTextColor) (THIS_ COLORREF    color /* [in] colorref  color  */)
                           {
                            COLORREF prevColor = textColor;
                            textColor = color;
                            pdc->SetTextForeground( toWxColor(color) );
                            return prevColor;

                            //COLORREF prevColor = fromWxColor( pdc->GetTextForeground() );
                            //pdc->SetTextForeground( toWxColor(color) );
                            //return prevColor;
                           }

                        CLIMETHOD(textColorGet) (THIS_ COLORREF*    _textColor /* [out] colorref textColor  */)
                           {
                            if (!_textColor) return EC_INVALID_PARAM;
                            *_textColor = textColor;
                            return EC_OK;
                           }

                        CLIMETHOD(textColorSet) (THIS_ COLORREF    _textColor /* [in] colorref  textColor  */)
                           {
                            setTextColor(_textColor);
                            return EC_OK;
                           }

                        CLIMETHOD(textOut) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                , const CLISTR*     text
                                           )
                           {
                            if (!leftTopPos || !text) return 0;
                            CPoint ltpos;
                            coordToDcCoord( ltpos, *leftTopPos );

                            pdc->DrawText( toWxString( text->pData, text->stringSize )
                                         , ltpos.x, ltpos.y
                                         );
                            
                            /*
                            // ����� � ANSI/UNICODE
                            #ifndef wxUSE_UNICODE
                                #ifdef _WIN32
                                    wxMBConvUTF16 conv;
                                #else
                                    wxMBConv      conv;
                                #endif
                                pdc->DrawText( wxString( conv.cMB2WC( text->pData, text->stringSize ) )
                                             , ltpos.x, ltpos.y
                                             );
                            #else
                                pdc->DrawText( wxString( text->pData, text->stringSize )
                                             , ltpos.x, ltpos.y
                                             );
                            #endif
                            */
                            return 0;
                           }

                        CLIMETHOD(setFontIndirect) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    props /* [in,ref] ::cli::drawing::font::Properties  props  */)
                           {
                            if (!props) return EC_INVALID_PARAM;
                            pdc->SetFont(implCreateFont(props));
                            return 0;
                           }

                        CLIMETHOD(pushSetFontIndirect) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    props /* [in,ref] ::cli::drawing::font::Properties  props  */)
                           {
                            if (!props) return EC_INVALID_PARAM;
                            fontStack.push(pdc->GetFont());
                            pdc->SetFont(implCreateFont(props));
                            return 0;
                           }

                        CLIMETHOD(popFont) (THIS)
                           {
                            if (fontStack.empty()) return 0;
                            pdc->SetFont( fontStack.top() );
                            fontStack.pop();
                            return 0;
                           }

                        CLIMETHOD(calcTextExtent) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [out,ref] ::cli::drawing::CPoint widthHeight  */
                                                       , const CLISTR*     text
                                                  )
                           {
                            if (!widthHeight) return EC_OK; // do nothing
                            if (!text) return EC_INVALID_PARAM;

                            wxSize wxsize = pdc->GetTextExtent( toWxString(text->pData, text->stringSize) );

                            using ::cli::drawing::makePoint;
                            CPoint resSize;

                            sizeFromDcSize( resSize, makePoint( wxsize.GetWidth(), wxsize.GetHeight() ) );
                            widthHeight->x = resSize.x;
                            widthHeight->y = resSize.y;

                            return EC_OK;
                           }

                        CLIMETHOD(rotatedTextOut) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                       , INT    rotan /* [in] int  rotan  */
                                                       , const CLISTR*     text
                                                  )
                           {
                            if (!text || !leftTopPos) return EC_INVALID_PARAM;

                            #ifdef WX_NATIVE_WIN32_DRAWING_ENABLED
                                CPoint ltpos;
                                coordToDcCoord( ltpos, *leftTopPos );
                                return win32RotatedTextOut ( (HDC)pdc->GetHDC(), ltpos, rotan, text->pData, text->stringSize );
                            #else
                                pdc->DrawRotatedText( toWxString(text->pData, text->stringSize)
                                                    , leftTopPos->x, leftTopPos->y
                                                    , double(rotan)/10.0
                                                    );
                                return EC_OK;
                            #endif
                           }


                        double getDegreesAngleHelper( const CPoint &center, const CPoint &point )
                           {
                            CPoint distance;
                            distance.x = point.x - center.x;
                            distance.y = point.y - center.y;
                            //double radius = sqrt( (double)(distance.x*distance.x) + (double)(distance.y*distance.y) );
                            //double x = distance.x;
                            //double y = distance.y;
                            return atan2((double)distance.y, (double)distance.x) * 180 / M_PI; // - 90.0;
                           }

                        CLIMETHOD(drawEllipticArc) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    rightBottom /* [in,ref] ::cli::drawing::CPoint  rightBottom  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    arcStart /* [in,ref] ::cli::drawing::CPoint  arcStart  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    arcEnd /* [in,ref] ::cli::drawing::CPoint  arcEnd  */
                                                        , BOOL    direction /* [in] bool  direction  */
                                                   )
                           {
                            if (!leftTop || !rightBottom || !arcStart || !arcEnd) return EC_INVALID_PARAM;
                            CPoint ltPos, rbPos, asPos, aePos;

                            coordToDcCoord( ltPos, *leftTop     );
                            coordToDcCoord( rbPos, *rightBottom );
                            coordToDcCoord( asPos, *arcStart    );
                            coordToDcCoord( aePos, *arcEnd      );

                            CPoint ellipseSize;
                            ellipseSize.x = rbPos.x - ltPos.x + 1;
                            ellipseSize.y = rbPos.y - ltPos.y + 1;
                            CPoint ellipseCenter;
                            ellipseCenter.x = ltPos.x + ellipseSize.x/2;
                            ellipseCenter.y = ltPos.y + ellipseSize.y/2;

                            double startAngle = getDegreesAngleHelper( ellipseCenter, asPos );
                            double endAngle   = getDegreesAngleHelper( ellipseCenter, aePos );
                            // direction : 0 - clockwise, 1 counterclockwise
                            if (!direction)
                               {
                                startAngle = -startAngle;
                                endAngle   = -endAngle;
                               }
                            
                            pdc->DrawEllipticArc( wxCoord(ltPos.x), wxCoord(ltPos.y)
                                                , wxCoord(ellipseSize.x), wxCoord(ellipseSize.y)
                                                , startAngle, endAngle
                                                );
                            return EC_OK;
                           }

                        CLIMETHOD(drawGradientCircle) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                                           , INT    radius /* [in] int  radius  */
                                                           , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                                           , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                                           , DWORD    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                                      )
                           {
                            if (!centerPos) return EC_OK;

                            using namespace ::cli::drawing;

                            ::std::vector< COLORREF > gradient;
                            cli::drawing::colorUtils::makeGradientColorsVector( colorCenter
                                                                              , colorRadius
                                                                              , radius+1
                                                                              , gradient
                                                                              );
                            wxPen   orgPen   = pdc->GetPen();
                            wxBrush orgBrush = pdc->GetBrush();

                            pdc->SetBrush( wxBrush(toWxColor(gradient[0]), wxSOLID) );

                            if (radius<=1)
                               { // GradientFlags::drawDefault, GradientFlags::noCurrentPenBorder
                                if (flags&GradientFlags::noCurrentPenBorder)
                                   {
                                    pdc->SetPen(wxPen(toWxColor(gradient[1]), scalePenWidth(1), penStyleToImpl(EPenStyle::solid)));
                                   }

                                drawCircle(centerPos, radius);
                                if (flags&GradientFlags::noCurrentPenBorder)
                                   {
                                    pdc->SetPen(orgPen);
                                   }
                                pdc->SetBrush(orgBrush);
                                return EC_OK;
                               }

                            int scaledPenWidth = scalePenWidth(2);
                            if (scaledPenWidth<2) scaledPenWidth = 2;

                            COLORREF prevColor = gradient[1];
                            pdc->SetPen(wxPen(toWxColor(prevColor), scaledPenWidth, penStyleToImpl(EPenStyle::solid)));

                            drawCircle(centerPos, 2);
                            pdc->SetBrush( wxBrush( wxColour(0,0,0), wxTRANSPARENT) );

                            int curRadius = 2;
                            for(; curRadius<radius; ++curRadius)
                               {
                                // set pen to next gradient color, if it is different with current
                                if (prevColor!=gradient[curRadius])
                                   {
                                    prevColor = gradient[curRadius];
                                    pdc->SetPen(wxPen(toWxColor(prevColor), scaledPenWidth, penStyleToImpl(EPenStyle::solid)));
                                   }
                                drawCircle(centerPos, curRadius);
                               }

                            if (flags&GradientFlags::noCurrentPenBorder)
                               {
                                pdc->SetPen(wxPen(toWxColor(gradient[curRadius]), scalePenWidth(1), penStyleToImpl(EPenStyle::solid)));
                                drawCircle(centerPos, curRadius);
                                pdc->SetPen(orgPen);
                               }
                            else
                               {
                                pdc->SetPen(orgPen);
                                drawCircle(centerPos, curRadius);
                               }
                            pdc->SetBrush(orgBrush);

                            return EC_OK;
                           }

                        CLIMETHOD(drawGradientCircleEx) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                                             , INT    radius /* [in] int  radius  */
                                                             , INT    smallRadius /* [in] int  smallRadius  */
                                                             , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                                             , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                                             , DWORD    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                                        )
                           {
                            if (!centerPos) return EC_OK;

                            using namespace ::cli::drawing;
                            if (radius<smallRadius) ::std::swap(radius, smallRadius);

                            ::std::vector< COLORREF > gradient;
                            cli::drawing::colorUtils::makeGradientColorsVector( colorCenter
                                                                              , colorRadius
                                                                              , radius - smallRadius + 1
                                                                              , gradient
                                                                              );

                            wxPen   orgPen   = pdc->GetPen();
                            wxBrush orgBrush = pdc->GetBrush();

                            int scaledPenWidth = scalePenWidth(2);
                            if (scaledPenWidth<2) scaledPenWidth = 2;

                            pdc->SetBrush( wxBrush( wxColour(0,0,0), wxTRANSPARENT) );
                            COLORREF prevColor = gradient[0];
                            pdc->SetPen(wxPen(toWxColor(prevColor), scaledPenWidth, penStyleToImpl(EPenStyle::solid)));

                            int curRadius = smallRadius;
                            for(; curRadius<radius; ++curRadius)
                               {
                                // set pen to next gradient color, if it is different with current
                                if (prevColor!=gradient[curRadius-smallRadius])
                                   {
                                    prevColor = gradient[curRadius-smallRadius];
                                    pdc->SetPen(wxPen(toWxColor(prevColor), scaledPenWidth, penStyleToImpl(EPenStyle::solid)));
                                   }
                                drawCircle(centerPos, curRadius);
                               }

                            if (flags&GradientFlags::noCurrentPenBorder)
                               {
                                pdc->SetPen(wxPen(toWxColor(gradient[curRadius-smallRadius]), scalePenWidth(1), penStyleToImpl(EPenStyle::solid)));
                                drawCircle(centerPos, curRadius);
                                pdc->SetPen(orgPen);
                               }
                            else
                               {
                                pdc->SetPen(orgPen);
                                drawCircle(centerPos, curRadius);
                               }
                            pdc->SetBrush(orgBrush);

                            return EC_OK;
                           }

                        CLIMETHOD(setClipRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            //if (widthHeight.x<0) widthHeight.x = 0;
                            //if (widthHeight.y<0) widthHeight.y = 0;
                            return setClipRectWH(&leftTop, &widthHeight);
                            //return EC_OK;
                           }


                        CLIMETHOD(setClipRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            //coordToDcCoord(wh, *widthHeight);
                            sizeToDcSize(wh, *widthHeight);
                            if (wh.x<0) wh.x = 0;
                            if (wh.y<0) wh.y = 0;
                            //pdc->DrawRectangle( lt.x, lt.y, wh.x, wh.y );
                            pdc->DestroyClippingRegion();
                            pdc->SetClippingRegion( wxPoint(lt.x, lt.y), wxSize(wh.x, wh.y) );
                            return EC_OK;
                           }

                        CLIMETHOD(clearClipRect) (THIS)
                           {
                            pdc->DestroyClippingRegion();
                            return EC_OK;
                           }

                        CLIMETHOD(createBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                          , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                     )
                           {
                            if (!pbmp || !widthHeight) return EC_INVALID_PARAM;

                            CPoint wh;
                            sizeToDcSize(wh, *widthHeight);

                            ::cli::drawing::impl::wx::CDeviceBitmap *bmp = 
                                   new ::cli::drawing::impl::wx::CDeviceBitmap( pdc, wh.x, wh.y );
                            *pbmp = static_cast<INTERFACE_CLI_DRAWING_IDEVICEBITMAP*>(bmp);
                            return EC_OK;
                           }

                        CLIMETHOD(createCopyBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                              , const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                              , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                         )
                           {
                            if (!pbmp || !leftTop || !widthHeight) return EC_INVALID_PARAM;

                            CPoint wh;
                            sizeToDcSize(wh, *widthHeight);

                            CPoint lt;
                            coordToDcCoord( lt, *leftTop );

                            ::cli::drawing::impl::wx::CDeviceBitmap *bmp = 
                                   new ::cli::drawing::impl::wx::CDeviceBitmap( pdc, wh.x, wh.y, lt.x, lt.y );
                            *pbmp = static_cast<INTERFACE_CLI_DRAWING_IDEVICEBITMAP*>(bmp);
                            return EC_OK;
                           }

                        CLIMETHOD(drawBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP*    pbmp /* [in] ::cli::drawing::iDeviceBitmap*  pbmp  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   )
                           {
                            if (!pbmp || !leftTop) return EC_INVALID_PARAM;

                            INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP *pImplBmp = 0;
                            RCODE res = pbmp->queryInterface( ::cli::iidOf(pImplBmp), (VOID**)&pImplBmp );
                            if (res || !pImplBmp) return EC_INCOMPATIBLE_OBJECT;

                            CLI_DRAWING_GENERIC_HANDLE ghBmp;
                            res = pImplBmp->getHandle(&ghBmp);
                            if (res) return res;

                            STRUCT_CLI_DRAWING_CPOINT widthHeight;
                            res = pImplBmp->sizeGet(&widthHeight);
                            if (res) return res;

                            //CPoint wh;
                            //sizeToDcSize(wh, widthHeight);

                            CPoint lt;
                            coordToDcCoord( lt, *leftTop );

                            wxMemoryDC memDc;
                            memDc.SelectObject(*((wxBitmap*)ghBmp));
                            pdc->Blit( lt.x, lt.y, widthHeight.x, widthHeight.y, &memDc, 0, 0, wxCOPY );
                            memDc.SelectObject(wxNullBitmap);

                            return EC_OK;
                           }

/*

                        CLIMETHOD(setPen) (THIS_ COLORREF    clr 
                                               , INT    width 
                                               , DWORD    style 
                                          )
                           {
                            //wxPen wxpen(toWxColor(clr), scalePenWidth(width), penStyleToImpl(style));
                            pdc->SetPen(wxPen(toWxColor(clr), scalePenWidth(width), penStyleToImpl(style)));
                            return 0;
                           }

                        CLIMETHOD(pushSetPen) (THIS_ COLORREF    clr
                                                   , INT    width 
                                                   , DWORD    style
                                              )
                           {
                            penStack.push(pdc->GetPen());
                            pdc->SetPen(wxPen(toWxColor(clr), scalePenWidth(width), penStyleToImpl(style)));
                            return 0;
                           }

                        CLIMETHOD(popPen) (THIS)
                           {
                            if (penStack.empty()) return 0; // no pens for restoring
                            wxPen wxpen = penStack.top(); penStack.pop();
                            pdc->SetPen( wxpen );
                            return 0;
                           }


                        CLIMETHOD(setSolidBrush) (THIS_ COLORREF    clr )
                           {
                            pdc->SetBrush( wxBrush(toWxColor(clr), wxSOLID) );
                            return 0;
                           }
                        CLIMETHOD(setNullBrush) (THIS)
                           {
                            pdc->SetBrush( wxBrush( wxColour(0,0,0), wxTRANSPARENT) );
                            return 0;
                           }
                        CLIMETHOD(pushSetSolidBrush) (THIS_ COLORREF    clr )
                           {
                            brushStack.push(pdc->GetBrush());
                            pdc->SetBrush( wxBrush(toWxColor(clr), wxSOLID) );
                            return 0;
                           }
                        CLIMETHOD(pushSetNullBrush) (THIS)
                           {
                            brushStack.push(pdc->GetBrush());
                            pdc->SetBrush( wxBrush( wxColour(0,0,0), wxTRANSPARENT) );
                            return 0;
                           }
                        CLIMETHOD(drawEllipseWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop 
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight
                                                 )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            coordToDcCoord(wh, *widthHeight);
                            pdc->DrawEllipse( lt.x, lt.y, wh.x, wh.y );
                            return 0;
                           }

                        //--------- draw ellipse
                        if (!rect) return 0;
                        STRUCT_CLI_DRAWING_CRECT tmpRect;
                        rectToDcCoord(tmpRect, *rect);
                        ::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);
                        return 0;
                        //--------- draw circle
                        if (!leftTop) return 0;
                        using ::cli::drawing::makeRect;
                        STRUCT_CLI_DRAWING_CRECT rect = makeRect( leftTop->x - radius
                                                                , leftTop->y - radius
                                                                , leftTop->x + radius
                                                                , leftTop->y + radius
                                                                );
                        return drawEllipse( &rect );

*/

                        #ifdef CLI_DRAWING_IDC1_SUPPORT_GETPIXEL
                        CLIMETHOD_(COLORREF, getPixel) (THIS_ INT    x /* [in] int  x  */
                                                            , INT    y /* [in] int  y  */
                                                       )
                           {
                            coordToDcCoord(x, y);
                            wxColour wxclr;
                            pdc->GetPixel(x, y, &wxclr);
                            return fromWxColor(wxclr);
                           }

                        CLIMETHOD_(COLORREF, getPixelPoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,ref] ::cli::drawing::CPoint  p  */)
                           {
                            CPoint pTmp;
                            coordToDcCoord( pTmp, *p );
                            wxColour wxclr;
                            pdc->GetPixel(pTmp.x, pTmp.y, &wxclr);
                            return fromWxColor(wxclr);
                           }
                        #endif


        
                }; // ::cli::drawing::impl::wx::CDrawContext1Impl


            }; /* namespace wx */
        }; /* namespace impl */
    }; /* namespace drawing */
}; /* namespace cli */


#endif /* CLI_DRAWING_IMPL_DC1WX_H */

