// http://www.bymath.net/studyguide/tri/tri_topics.html

/*
http://www.bymath.net/studyguide/tri/sec/tri7.htm
             sin       cos       tan       cot
 -a        -sin(a)    +cos(a)   -tan(a)   -cot(a)
90-a       +cos(a)    +sin(a)   +cot(a)   +tan(a)
90+a       +cos(a)    -sin(a)   -cot(a)   -tan(a)
180-a      +sin(a)    -cos(a)   -tan(a)   -cot(a)
180+a      -sin(a)    -cos(a)   +tan(a)   +cot(a)
270-a      -cos(a)    -sin(a)   +cot(a)   +tan(a)
270+a      -cos(a)    +sin(a)   -cot(a)   -tan(a)
*/


#define _USE_MATH_DEFINES


//#if !defined(_INC_MATH) && !defined(_MATH_H_) && !defined(_MATH_H)
    #include <math.h>
//#endif


//#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
//#endif

//#if !defined(_INC_STDIO) && !defined(_STDIO_H_) && !defined(_STDIO_H)
    #include <stdio.h>
//#endif

//#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
//#endif


#ifndef M_PI
    #define M_PI       3.14159265358979323846
#endif



int main(int argc, char * argv[])
   {
    int maxLim = 3600;
    if (argc<=1)
       {
        std::cout<<"inline\nconst float*\ngetCosineTable()\n   {\n    static float cosineTable[] = {\n";
        maxLim = 900;
       }
    for(int i=0; i<=maxLim; ++i)
       {
        double phi = -(double(i)/10.0) * M_PI / 180.0;
        double cosPhi = cos(phi);
        char buf[256];
        sprintf(buf, "%.08f", cosPhi);
        if (argc<=1)
           {
            if (i) std::cout<<",\n";
            std::cout<<"                                  ";
           }
        else
           {
            if (i) std::cout<<"\n";
           }
        std::cout<<buf;
        sprintf(buf, "%2d.%1d", i/10, i%10);
        if (argc<=1)
           {
            std::cout<<" /* "<<buf<<" */";
           }
        else
           {
            std::cout<<"\t"<<buf;
           }
       }
    std::cout<<"\n";
    if (argc<=1)
       {
        std::cout<<"                                 }; // end of cosine table\n    return &cosineTable[0];\n   }\n";
       }

    // double phi = -(double(rotan)/10.0) * M_PI / 180.0;
    //  /* double */  float cosPhi = float(cos(phi));
    //  /* double  */ float sinPhi = float(sin(phi));
    return 0;
   }