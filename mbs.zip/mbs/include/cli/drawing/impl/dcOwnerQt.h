#ifndef CLI_DRAWING_IMPL_DCOWNERQT_H
#define CLI_DRAWING_IMPL_DCOWNERQT_H

/*
#ifndef CLI_DRAWING_IMPL_DCOWNERQT_H
    #include <cli/drawing/impl/dcOwnerQt.h>
#endif
*/

#ifndef CLI_DRAWING_IMPL_DCOWNERBASE_H
    #include <cli/drawing/impl/dcownerbase.h>
#endif

#ifndef CLI_DRAWING_IMPL_DC1QT_H
    #include <cli/drawing/impl/dc1qt.h>
#endif

namespace cli {
namespace drawing {
namespace impl{
namespace qt{



template <typename T> class QOffscreenDraw;
template <typename T> class QCliDcDraw;

template <typename T>
class CDrawContext1Partial : public ::cli::drawing::impl::qt::CDrawContext1Impl<QPainter, QOffscreenDraw<T> >
   {
    public:
    typedef  ::cli::drawing::impl::qt::CDrawContext1Impl<QPainter, QOffscreenDraw<T> > BaseImpl;

    private:

    //STRUCT_CLI_DRAWING_CRECT rectForUpdate;
    //bool                     useRectForUpdate;
    QPainter dc;
    QPixmap *pixmap;
    QOffscreenDraw<T> *pOffscreenDraw;
    //QWidget *qw;

    // void QPaintEngine::drawPixmap ( const QRectF & r, const QPixmap & pm, const QRectF & sr )   [pure virtual]
    // QPaintEngine * QWidget::paintEngine () const   [virtual]
    // The QPixmap class is an off-screen image representation that can be used as a paint device.

    public:

    CDrawContext1Partial(QPixmap *_pixmap, QOffscreenDraw<T> *q, const STRUCT_CLI_DRAWING_CRECT* pRectForUpdate = 0)
       : BaseImpl()
       //, rectForUpdate()
       //, useRectForUpdate(false)
       , dc(_pixmap)
       , pixmap(_pixmap)
       , pOffscreenDraw(q)
       //, qw(q)
       {
        /*
        if (pRectForUpdate) 
           {
            rectForUpdate    = *pRectForUpdate;
            useRectForUpdate = true;
           }
        */
        BaseImpl::useRefCounting = true;
        attachClientDC(dc, q);
       }
    ~CDrawContext1Partial()
       {
        //if (useRefCounting) ReleaseDC( hwndOwner, hdc );
        //qw->update();
        //pwnd->update();
        //pwnd->repaint();
        dc.end();
        pOffscreenDraw->updateFromBackBuffer();
        /*
        QPainter widgetPainter(pwnd);
        widgetPainter.drawPixmap( QRect( 0, 0, pwnd->width(), pwnd->height())
                                , *pixmap
                                , QRect( 0, 0, pwnd->width(), pwnd->height())
                                );
        */
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       if (BaseImpl::useRefCounting)
       #include <cli/compspec/delthis.h>
       }
   };




template <typename T>
class CDCOwnerImpl : public CDCOwnerImplBase
{
    QCliDcDraw<T> *wOwner;

public:

    CDCOwnerImpl( QCliDcDraw<T> *q = 0 )  : wOwner(q) { }
    void setOwnerWindow(QCliDcDraw<T> *q) { wOwner = q; }

    CLIMETHOD(dcCreateForPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
       {
        CLI_TRY{
                //CDrawContext1Partial *pdcImpl = new CDrawContext1Partial(qwidgetOwner);
                CDrawContext1Partial<T> *pdcImpl = new CDrawContext1Partial<T>(wOwner->getOffscreenBuffer(), wOwner);
                RCODE res = pdcImpl->queryInterface( ::cli::iidOf(*pdc), (VOID**)pdc );
                pdcImpl->release();
                return res;
               }
        catch(...)
               {
                return EC_UNKNOWN_INTERFACE;
               }
        //CLI_CATCH_RETURN_CLI_EXCEPTION()
        //CLI_CATCH_RETURN_STD_EXCEPTIONS()
       }
    
    CLIMETHOD(dcCreateForUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                   , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate /* [in,ref,optional] ::cli::drawing::CRect  rectForUpdate  */
                              )
       {
        CLI_TRY{
                CDrawContext1Partial<T> *pdcImpl = new CDrawContext1Partial<T>(wOwner->getOffscreenBuffer(), wOwner, rectForUpdate);
                RCODE res = pdcImpl->queryInterface( ::cli::iidOf(*pdc), (VOID**)pdc );
                pdcImpl->release();
                return res;
               }
        catch(...)
               {
                return EC_UNKNOWN_INTERFACE;
               }
        //CLI_CATCH_RETURN_CLI_EXCEPTION()
        //CLI_CATCH_RETURN_STD_EXCEPTIONS()
       }

    #if 0
    CLIMETHOD(posToScreen) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    pos /* [in,ref] ::cli::drawing::CPoint  pos  */
                                , STRUCT_CLI_DRAWING_CPOINT*    screenPos /* [out] ::cli::drawing::CPoint screenPos  */
                           )
       {
        if (!pos || !screenPos) return EC_INVALID_PARAM;

        wOwner

        POINT ps; ps.x = pos->x; ps.y = pos->y;
        ::ClientToScreen( hwndOwner, &ps );
        screenPos->x = ps.x; screenPos->y = ps.y;
        return EC_OK;
       }
    #endif

}; // class CDCOwnerQtImpl


//#include <QResizeEvent>

template <typename T>
class QOffscreenDraw : public T
{
    QPixmap backBuffer;
    bool    bOnlyCopyBackBuffer;

public:

    QOffscreenDraw(QWidget * parent = 0, Qt::WindowFlags f = 0)
       : T(parent, f)
       , backBuffer()
       , bOnlyCopyBackBuffer(false)
       {
        backBuffer = QPixmap ( T::width(), T::height() );
        T::setAttribute(Qt::WA_PaintOnScreen);
        T::setAttribute(Qt::WA_OpaquePaintEvent);
       }

    QPixmap* getOffscreenBuffer()
       {
        return &backBuffer; // QPainter(&backBuffer);
       }

    void updateFromBackBuffer()
       {
        bOnlyCopyBackBuffer = true;
        T::repaint();
        bOnlyCopyBackBuffer = false;
       }

protected:

    virtual void doPaint( QPainter *painter, QPaintEvent *event )
       {}

    void resizeEvent( QResizeEvent * event )
       {
        T::resizeEvent(event);
        if (!event->isAccepted()) return;
        backBuffer = QPixmap( event->size() );
       }

    void paintEvent(QPaintEvent *event)
       {
        if (!bOnlyCopyBackBuffer)
           {
            QPainter painter(&backBuffer);
            doPaint( &painter, event );
           }

        QPainter thisPainter(this);
        thisPainter.drawPixmap( QRect( 0, 0, T::width(), T::height()), backBuffer, QRect( 0, 0, T::width(), T::height()) );
       }
};


template <typename T>
class QCliDcDraw : public QOffscreenDraw<T>
{
    public:

    typedef     QOffscreenDraw<T> TBaseClass;
    typedef     QCliDcDraw<T>     TThisClass;

    ::cli::drawing::impl::qt::CDCOwnerImpl<T>   cliDcOwner;


    QCliDcDraw(QWidget * parent = 0, Qt::WindowFlags f = 0)
       : TBaseClass(parent, f)
       , cliDcOwner(this)
       {}

    virtual void doPaintOnCliDC( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc )
       {}

    virtual void doPaint( QPainter *painter, QPaintEvent *event )
       {
        ::cli::drawing::impl::qt::CDrawContext1Impl<QPainter, TThisClass> dcImpl;
        dcImpl.attachClientDC(*painter, this);
        ::cli::drawing::impl::CDCOwnerAuto dcOwnerAuto( cliDcOwner, static_cast<INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*>(&dcImpl));
        doPaintOnCliDC( &dcImpl );
        dcImpl.detachDC();
       }


};











}; /* namespace qt */
}; /* namespace impl */
}; /* namespace drawing */
}; /* namespace cli */




#endif /* CLI_DRAWING_IMPL_DCOWNERQT_H */

