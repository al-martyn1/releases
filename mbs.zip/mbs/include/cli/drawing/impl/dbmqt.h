#ifndef CLI_DRAWING_IMPL_DBMQT_H
#define CLI_DRAWING_IMPL_DBMQT_H

#ifndef CLI_DRAWING_IMPL_IMPLHLP_H
    #include <cli/drawing/impl/implhlp.h>
#endif


namespace cli {
namespace drawing {
namespace impl {
namespace qt {

class CDeviceBitmap : public ::cli::CComponentImplBase< ::cli::CRefCounter, ::cli::CDummyModule > // DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_DRAWING_IDEVICEBITMAP
                    , public INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP
{
        QPixmap                   qBitmap;

    public:

        typedef ::cli::CComponentImplBase< ::cli::CRefCounter, ::cli::CDummyModule > base_impl;

        // create compatible with dc
        CDeviceBitmap( QPainter *qdc, int width, int height )
           : qBitmap( (width<0?-width:width), (height<0?-height:height))
           {
           }

        // create compatible with dc and copies data from dc
        CDeviceBitmap( QPainter *qdc, int width, int height, int left, int top )
           : qBitmap( (width<0?-width:width), (height<0?-height:height))
           {
            QPaintEngine *pPaintEngine = qdc->paintEngine();
            if (!pPaintEngine) return;

            QPaintDevice *pPaintDevice = pPaintEngine->paintDevice();
            if (!pPaintDevice) return;

            QPixmap *srcPixmap = dynamic_cast<QPixmap*>(pPaintDevice);
            if (!srcPixmap) return;

            QPainter memPainter(&qBitmap);

            memPainter.drawPixmap( QRect(0, 0, (width<0?-width:width), (height<0?-height:height) )
                                 , *srcPixmap
                                 , QRect(left, top, (width<0?-width:width), (height<0?-height:height))
                                 );
           }

        ~CDeviceBitmap()
           {
           }
    
        CLI_BEGIN_INTERFACE_MAP2(CDeviceBitmap, INTERFACE_CLI_DRAWING_IDEVICEBITMAP)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_DRAWING_IDEVICEBITMAP )
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP )
        CLI_END_INTERFACE_MAP(CDeviceBitmap)
    
        CLIMETHOD_(ULONG, addRef) (THIS)  { return addRefImpl(); }
        CLIMETHOD_(ULONG, release) (THIS) { return releaseImpl();}
    
        CLIMETHOD_(VOID, destroy) (THIS)
           {
           #include <cli/compspec/delthis.h>
           }

        CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint size  */)
           {
            if (_size) *_size = ::cli::drawing::impl::makePoint( qBitmap.width(), qBitmap.height() );
            return EC_OK;
           }

        CLIMETHOD(getHandle) (THIS_ CLI_DRAWING_GENERIC_HANDLE*    dbmHandle /* [out] cli_drawing_generic_handle dbmHandle  */)
           {
            if (dbmHandle) *dbmHandle = (CLI_DRAWING_GENERIC_HANDLE)&qBitmap;
            return EC_OK;
           }

}; // class CDeviceBitmap

}; // namespace qt
}; // namespace impl
}; // namespace drawing
}; // namespace cli





#endif /* CLI_DRAWING_IMPL_DBMQT_H */

