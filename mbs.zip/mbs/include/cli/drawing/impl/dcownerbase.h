#ifndef CLI_DRAWING_IMPL_DCOWNERBASE_H
#define CLI_DRAWING_IMPL_DCOWNERBASE_H

/*
#ifndef CLI_DRAWING_IMPL_DCOWNERBASE_H
    #include <cli/drawing/impl/dcownerbase.h>
#endif
*/

#ifndef CLI_DRAWING_DCOWNER_H
    #include <cli/drawing/dcowner.h>
#endif

namespace cli {
namespace drawing {
namespace impl{


class CDCOwnerImplBase : public INTERFACE_CLI_DRAWING_IDCOWNER
{

public:

    //CLI_BEGIN_INTERFACE_MAP2(CDCOwnerImplBase, INTERFACE_CLI_DRAWING_IDCOWNER)
    CLI_BEGIN_INTERFACE_MAP(CDCOwnerImplBase)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_DRAWING_IDCOWNER )
    CLI_END_INTERFACE_MAP(CDCOwnerImplBase)

    // CDCOwnerImplBase and child classes, 
    // such as CQtDcOwner, CWxDcOwner, CWin32DcOwner, CWtlDcOwner,
    // must create object as automatic variable (window class member)
    CLIMETHOD_(ULONG, addRef) (THIS)    { return 1 ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return 1; }

protected:

    INTERFACE_CLI_DRAWING_IDRAWCONTEXT1    *ptrPaintDc; // used in onPaint and such event handlers

public:

    UINT  colorBits;
    BOOL  bMonochrome;
    BOOL  bMonochromeGreen;

    // need to be implemented in childs
    CLIMETHOD(dcCreateForPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */) PURE;
    CLIMETHOD(dcCreateForUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                   , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate /* [in,ref,optional] ::cli::drawing::CRect  rectForUpdate  */
                              ) PURE;

    CDCOwnerImplBase()
       : ptrPaintDc(0)
       , colorBits(8)
       , bMonochrome(FALSE)
       , bMonochromeGreen(FALSE)
       {}

    void setOnPaintDc(INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_ptrPaintDc)
       { 
        ptrPaintDc = _ptrPaintDc;
        if (ptrPaintDc) ptrPaintDc->setColorsConversionMode( colorBits, bMonochrome, bMonochromeGreen );
       }

    void clearOnPaintDc()
       {
        ptrPaintDc = 0;
       }


    CLIMETHOD(dcGetForPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
       {
        if (!pdc) return EC_INVALID_PARAM;
        if (ptrPaintDc)
           { // paint event performed, return saved paint context
            *pdc = ptrPaintDc;
            return EC_OK;
           }
        
        RCODE res = dcCreateForPaint( pdc );
        if (!res && *pdc)
           {
            (*pdc)->setColorsConversionMode( colorBits, bMonochrome, bMonochromeGreen );
           }
        return res;
       }

    CLIMETHOD(dcGetForUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                   , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate /* [in,ref,optional] ::cli::drawing::CRect  rectForUpdate  */
                              )
       {
        if (!pdc) return EC_INVALID_PARAM;
        if (ptrPaintDc)
           { // paint event performed, return saved paint context
            *pdc = ptrPaintDc;
            return EC_OK;
           }
        RCODE res = dcCreateForUpdate( pdc, rectForUpdate );
        if (!res && *pdc)
           {
            (*pdc)->setColorsConversionMode( colorBits, bMonochrome, bMonochromeGreen );
           }
        return res;
       }

}; // class CDCOwnerImplBase


// use it in OnPaint event handler
class CDCOwnerAuto
{
    CDCOwnerImplBase &ownerRef;
public:
    CDCOwnerAuto( CDCOwnerImplBase &ownr, INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc)
       : ownerRef(ownr)
       { ownerRef.setOnPaintDc(pdc); }
    ~CDCOwnerAuto()
       { ownerRef.clearOnPaintDc(); }

}; // class CDCOwnerAuto



}; /* namespace impl */
}; /* namespace drawing */
}; /* namespace cli */


#endif /* CLI_DRAWING_IMPL_DCOWNERBASE_H */

