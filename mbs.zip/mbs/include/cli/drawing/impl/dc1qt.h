#ifndef CLI_DRAWING_IMPL_DC1QT_H
#define CLI_DRAWING_IMPL_DC1QT_H

/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_IMPL_DC1QT_H
    #include <cli/drawing/impl/dc1qt.h>
#endif
*/

/*
#ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
#endif

#if !defined(_WINDOWS_)
    #include <windows.h>
#endif
*/

/*
����� ��뫪�
��ᮢ���� - http://www.crossplatform.ru/?q=node/53
Graphics View Framework - http://symmetrica.net/qt4/lesson4.htm

����� ��� 㣫��
http://www.linuxcenter.ru/lib/books/qt3/qt3_12.phtml

������ ��३��� � ����� �८�ࠧ������ (world matrix). ��� ������ ����� �࠭��ଠ権, ����� ������ ���� �믮����� � ���������� � �८�ࠧ������ �����᪨� ���न��� � 䨧��᪨�. �� �������� �믮����� ��������� ����⠡�, ��饭�� � ᤢ�� ��㥬�� ������⮢. ���ਬ��, �᫨ ����室��� ���ᮢ��� ⥪�� ��� 㣫�� 45 �ࠤ�ᮢ, � ����� ������� ᫥���騩 ���: 
  QWMatrix matrix; 
  matrix.rotate(45.0); 
  painter.setWorldMatrix(matrix); 
  painter.drawText(rect, AlignCenter, tr("Revenue"));
      
����� �����᪨� ���न����, ��।������ � drawText(), ᭠砫� �����࣠���� �࠭��ଠ樨, � ��⥬ �⮡ࠦ����� � 䨧��᪨� ���न����.


�᫨ 㪠�뢠���� ��᪮�쪮 �࠭��ଠ権, � ��� �ਬ������� � ���浪� ᫥������� � ��室��� ���� �ணࠬ��. ���ਬ��, �����⨬, �� ����室��� �������� ����ࠦ���� �⭮�⥫쭮 �窨 � ���न��⠬� (10, 20). ��� �⮣� ����� ������ ᫥���騩 ���冷� �࠭��ଠ権: ᤢ����� ���� ⠪, �⮡� 業�� ��饭�� ��६��⨫�� � ���न���� (0, 0), �������� ����ࠦ���� � ��⥬ �믮����� ����� ᤢ��:

  QWMatrix matrix; 
  matrix.translate(-10.0, -20.0); 
  matrix.rotate(45.0); 
  matrix.translate(+10.0, +20.0); 
  painter.setWorldMatrix(matrix); 
  painter.drawText(rect, AlignCenter, tr("Revenue"));
      
����� ���⮩ ᯮᮡ -- ��ᯮ�짮������ ��⮤��� ����� QPainter -- translate(), scale(), rotate() � shear(): 
  painter.translate(-10.0, -20.0); 
  painter.rotate(45.0); 
  painter.translate(+10.0, +20.0); 
  painter.drawText(rect, AlignCenter, tr("Revenue"));
      
�� �᫨ ����室��� ��ᯮ�짮������ ����� � ⥬ �� ����஬ �࠭��ଠ権 ��᪮�쪮 ࠧ �����, � ��ਠ�� � QWMatrix ���� ����⥫�� �먣��� �� �६���.


�� ����室�����, ������ �८�ࠧ������ ����� ��࠭��� �맮��� saveWorldMatrix() � ��⥬ ����⠭����� �맮��� restoreWorldMatrix().



*/


#ifndef CLI_DRAWING_DC1IMPLBASE_H
    #include <cli/drawing/impl/dc1implbase.h>
#endif

#ifndef CLI_DRAWING_IMPL_QTIMPLHLP_H
    #include <cli/drawing/impl/qtimplhlp.h>
#endif

#ifndef CLI_DRAWING_IMPL_DBMQT_H
    #include <cli/drawing/impl/dbmqt.h>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif


namespace cli {
    namespace drawing {
        namespace impl {
            namespace qt {

// ::cli::drawing::impl::qt

                template < typename TDC
                         , typename TWND
                         >
                class CDrawContext1Impl : public ::cli::drawing::impl::CDrawContext1ImplBase
                {
                    public:
        
                    protected:
        
                        TDC     *pdc;
                        TWND    *pwnd; // or printer, or other device
                        DWORD    devType;
                        COLORREF textColor;
                        COLORREF bkColor;
                        static const COLORREF uninitializedBkColor = 0xFF000000;

                        ::std::stack< QPen   > penStack;
                        ::std::stack< QBrush > brushStack;
                        ::std::stack< QFont  > fontStack;

                        COLORREF swapRedBlue(COLORREF c) const
                           {
                            // (0xFF&c) - blue
                            // (0xFF&(c>>16)) - red
                            return ((0xFF00FF00&c) | (0xFF&c)<<16 | (0xFF&(c>>16)));
                           }
                        
                        //QColor ( int r, int g, int b, int a = 255 )
                        //COLORREF fromQtColor(QColor qtclr)
                        //QColor toQtColor( COLORREF clr)
                        
                        COLORREF fromQtColor(QColor qtclr) const
                           {
                            //return (COLORREF)qtclr.rgba();
                            return swapRedBlue((COLORREF)qtclr.rgb());
                           }
                        
                        QColor toQtColor( COLORREF clr) const
                           {
                            return QColor( (QRgb)swapRedBlue(fastScaleColor(adjustColor(clr))) );
                           }


                        QFont::Weight toImplFontWeight(DWORD weight) const
                           {
                            using namespace ::cli::drawing::font::Weight;
                            switch(weight)
                               {
                                case extraLight: return (QFont::Weight)15; // 15
                                case light     : return QFont::Light;      // 25
                                case normal    : return QFont::Normal;     // 50
                                //case demibol   : 
                                case semibold  : return QFont::DemiBold;   // 63
                                case bold      : return QFont::Bold;       // 75
                                case extraBold : return QFont::Black;      // 87
                                case black     : return (QFont::Weight)92; // 92
                                default:         return QFont::Normal;
                               }                            
                           }

                        DWORD fromImplFontWeight(QFont::Weight weight) const
                           {
                            using namespace ::cli::drawing::font::Weight;
                            if ((int)weight <= (int)15)                   return extraLight;
                            else if ((int)weight <= (int)QFont::Light)    return light;
                            else if ((int)weight <= (int)QFont::Normal)   return normal;
                            else if ((int)weight <= (int)QFont::DemiBold) return semibold;
                            else if ((int)weight <= (int)QFont::Bold)     return bold;
                            else if ((int)weight <= (int)QFont::Black)    return extraBold;
                            else                          /* 92 */        return black;
                           }

                        QFont::StyleHint toImplFamilyAndPitch(DWORD family, DWORD pitch) const
                           {
                            // under Qt we ignoring pitch
                            using namespace ::cli::drawing::font::Family;
                            switch(family)
                               {
                                case dontCare:   return QFont::AnyStyle;     // wxFONTFAMILY_DEFAULT
                                case roman:      return QFont::Times;        // wxFONTFAMILY_ROMAN
                                case swiss:      return QFont::SansSerif;    // wxFONTFAMILY_SWISS
                                case modern:     return QFont::Courier;      // wxFONTFAMILY_MODERN
                                case script:     return QFont::AnyStyle;     // wxFONTFAMILY_SCRIPT
                                case decorative: return QFont::Decorative;   // wxFONTFAMILY_DECORATIVE
                                default:         return QFont::AnyStyle;
                               }
                           }

                        QFont implCreateFont(const STRUCT_CLI_DRAWING_FONT_PROPERTIES* props /* , int angle tenths of degree */) const
                           {
                            using namespace ::cli::drawing::font;

                            QFont qf( toQtString(props->faceName)
                                    , props->height
                                    , toImplFontWeight(props->weight)
                                    , props->flags&Flags::italic ? true : false
                                    );
                            if (props->flags&Flags::underlined)
                               qf.setUnderline( true );

                            if (props->pitch==Pitch::fixed)
                               qf.setFixedPitch(true);

                            //qf.setStretch( 100  /* normal */  );
                            QFont::StyleStrategy strategy = (QFont::StyleStrategy)0; // QFont::PreferDefault;

                            if (props->precision & Precision::preferDevice)
                                strategy = QFont::PreferDevice;
                            else if (props->precision & Precision::preferRaster)
                                strategy = QFont::PreferBitmap;
                            else if (props->precision & Precision::preferOutline)
                                strategy = QFont::PreferOutline;


                            if (props->precision & Precision::noAntialias)
                                strategy = (QFont::StyleStrategy)((unsigned)strategy | (unsigned)QFont::NoAntialias);
                            else if (props->precision & Precision::preferAntialias)
                                strategy = (QFont::StyleStrategy)((unsigned)strategy | (unsigned)QFont::PreferAntialias);

                            // �ॡ���� �筮� ᮮ⢥��⢨� ࠧ���� � �� ���ਪ�� 
                            if (props->precision & Precision::preferMatch)
                               {
                                strategy = (QFont::StyleStrategy)((unsigned)strategy | (unsigned)QFont::PreferMatch);
                               } // �ॡ���� ����⢮, �筮� ᮮ⢥��⢨� �� �ॡ����
                            else if (props->precision & Precision::preferQuality)
                               {
                                strategy = (QFont::StyleStrategy)((unsigned)strategy | (unsigned)QFont::PreferQuality);
                               }

                            // set up default strategy if no other sets
                            if (!(((unsigned)strategy)&0x0F))
                               strategy = (QFont::StyleStrategy)((unsigned)strategy | (unsigned)QFont::PreferDefault);

                            qf.setStyleHint ( toImplFamilyAndPitch(props->family, props->pitch)
                                            , strategy
                                            );
                            return qf;
                           }

                        // Qt::PenStyle penStyleToImpl(ENUM_CLI_DRAWING_EPENSTYLE ps) const
                        // Qt::PenCapStyle penCapStyleToImpl(ENUM_CLI_DRAWING_EPENCAPSTYLE ps) const
                        // Qt::PenJoinStyle penJoinStyleToImpl(ENUM_CLI_DRAWING_EPENJOINSTYLE ps) const
                        Qt::PenStyle penStyleToImpl(ENUM_CLI_DRAWING_EPENSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenStyle;
                            switch(ps)
                               {
                                case null      : return Qt::NoPen;
                                case solid     : return Qt::SolidLine;
                                case dash      : return Qt::DashLine;
                                case dot       : return Qt::DotLine;
                                case dashdot   : return Qt::DashDotLine;
                                case dashdotdot: return Qt::DashDotDotLine;
                                default        : return Qt::SolidLine;
                               }
                           }
                         
                        Qt::PenCapStyle penCapStyleToImpl(ENUM_CLI_DRAWING_EPENCAPSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenCapStyle;
                            switch(ps)
                               {
                                case square    : return Qt::SquareCap ;
                                case round     : return Qt::RoundCap  ;
                                case flat      : return Qt::FlatCap   ;
                                default        : return Qt::RoundCap  ;
                               }
                           }

                        Qt::PenJoinStyle penJoinStyleToImpl(ENUM_CLI_DRAWING_EPENJOINSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenJoinStyle;
                            switch(ps)
                               {
                                case bevel     : return Qt::BevelJoin ;
                                case miter     : return Qt::MiterJoin ;
                                case round     : return Qt::RoundJoin ;
                                default        : return Qt::RoundJoin ;
                               }
                           }
        
                    public:

                        // using namespace ::cli::drawing::DeviceType;
                        CDrawContext1Impl() : ::cli::drawing::impl::CDrawContext1ImplBase(), pdc(0), pwnd(0)
                                            , devType( ::cli::drawing::DeviceType::rasterDispay )
                                            , penStack()
                                            , brushStack()
                                            , textColor(0)
                                            , bkColor(uninitializedBkColor)
                                            , fontStack()
                                            {}

                        ~CDrawContext1Impl()
                           {
                            CLIASSERT(penStack.size()==0);
                            CLIASSERT(brushStack.size()==0);
                            CLIASSERT(fontStack.size()==0);
                           }

                        CLIMETHOD_(VOID, destroy) (THIS)
                           {
                           if (useRefCounting)
                           #include <cli/compspec/delthis.h>
                           }

                        void detachDC() {}

                        void setupDefaultFont()
                           {
                            // make default font larger
                            #ifdef _WIN32
                            int pixelSize  = pdc->font().pixelSize();
                            int pointSize = pdc->font().pointSize();
                            if (pointSize>0 && pointSize==8)
                               {
                                QFont font = pdc->font();
                                font.setPointSize( 10 );
                                font.setWeight(QFont::DemiBold); // Bold
                                pdc->setFont(font);
                               }
                            else if (pixelSize>0 && pixelSize==8)
                               {
                                QFont font = pdc->font();
                                font.setPixelSize( 10 );
                                font.setWeight(QFont::DemiBold); // Bold
                                pdc->setFont(font);
                               }
                            #endif
                           
                           }

                    protected:

                    public:
                        
                        void attachDC(TDC &_pdc,  TWND *_pwnd, const CPoint &_offset, const CPoint &_size)
                           {
                            pdc  = &_pdc;
                            pwnd = _pwnd;
                            setOffset(_offset);
                            setSize(_size);
                            
                            setBkMode( ::cli::drawing::BkMode::transparent );
                            setDeviceRenderFlags( 0 );
                            //setupLikeDisplay();

                            /*
                            int pixelSize  = pdc->font().pixelSize();
                            int pointSize = pdc->font().pointSize();
                            */
                            // Returns the pixel size of the font if it was set with setPixelSize(). Returns -1 if the size was set with setPointSize() or setPointSizeF().
                            /* const QFont & font () const
                             * QFontInfo fontInfo () const
                            int pixelSize () const
                            int pointSize () const
                             */
                           }
                        
                    public:

                        void attachClientDC(TDC &_pdc, TWND *_pwnd, const CPoint &_offset, const CPoint &_size)
                           {
                            using namespace ::cli::drawing::DeviceType;
                            devType = rasterDispay;
                            attachDC(_pdc,  _pwnd, _offset, _size);
                           }

                        void attachClientDC(TDC &_pdc, TWND *_pwnd, const CPoint &_offset)
                           { attachDC(_pdc, _pwnd, _offset, CPoint( _pwnd->width(), _pwnd->height() )); }

                        void attachClientDC(TDC &_pdc, TWND *_pwnd) { attachClientDC(_pdc, _pwnd, CPoint(0) ); }

                        void attachPrinterDC(TDC &_pdc, TWND *_pPrinter, const CPoint &_offset, const CPoint &_size)
                           {
                            using namespace ::cli::drawing::DeviceType;
                            devType = rasterPrinter;

                            //QRect pageRect = _pPrinter->pageRect()
                            //attachPrinterDC(_hdc, _offset, CPoint( pageRect.width(), pageRect.height() ) );
                            attachDC(_pdc, _pPrinter, _offset, _size);
                           }

                        void attachPrinterDC(TDC &_pdc, TWND *_pPrinter, const CPoint &_offset)
                           {
                            QPaintDevice *pDev = _pdc->device();
                            int sx = pDev ? pDev->width() : 0;
                            int sy = pDev ? pDev->height() : 0;
                            attachPrinterDC(_pdc, _pPrinter, _offset, CPoint(sx,sy));
                           }

                        void attachPrinterDC(TDC &_pdc, TWND *_pPrinter)
                           { attachPrinterDC(_pdc, _pPrinter, CPoint(0,0)); }

                        /* interface ::cli::drawing::iDrawContext1 methods */
                        CLIMETHOD(getDpi) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    dpi /* [out,ref] ::cli::drawing::CPoint dpi  */)
                           {
                            if (!dpi) return 0;
                            QPaintDevice *pDevice = pdc->device();
                            if (!pDevice)
                               {
                                // assume default screen dpi - 96 dpi
                                dpi->x = 96;
                                dpi->y = 96;
                               }
                            else
                               {
                                dpi->x = pDevice->logicalDpiX();
                                dpi->y = pDevice->logicalDpiY();
                                if (!dpi->x) dpi->x = 96;
                                if (!dpi->y) dpi->y = 96;
                               }
                            return 0;
                           }

                        CLIMETHOD_(DWORD, getDeviceType) (THIS)
                           {
                            return devType;
                           }

                        CLIMETHOD_(DWORD, setDeviceRenderFlags) (THIS_ DWORD    newFlags /* [in] ::cli::drawing::DeviceRenderFlag  newFlags  */)
                           {
                            // QFlags<QPainter::RenderHint>
                            QPainter::RenderHints prevHints = pdc->renderHints();
                            DWORD prevFlags = 0;

                            using namespace cli::drawing;

                            if ( prevHints & QPainter::RenderHints(QPainter::Antialiasing) )
                               prevFlags |= DeviceRenderFlag::antialiasing;

                            if ( prevHints & QPainter::RenderHints(QPainter::TextAntialiasing) )
                               prevFlags |= DeviceRenderFlag::antialiasingText;

                            if (newFlags&DeviceRenderFlag::antialiasing)
                               pdc->setRenderHint( QPainter::Antialiasing, true );
                            else
                               pdc->setRenderHint( QPainter::Antialiasing, false );

                            if (newFlags&DeviceRenderFlag::antialiasingText)
                               pdc->setRenderHint( QPainter::TextAntialiasing, true );
                            else
                               pdc->setRenderHint( QPainter::TextAntialiasing, false );

                            /*
                            void QPainter::setRenderHint ( RenderHint hint, bool on = true )
                            // Sets the given render hint on the painter if on is true; otherwise clears the render hint.
                            // See also setRenderHints(), renderHints(), and Rendering Quality.                           
                            
                            QPainter::Antialiasing
                            QPainter::TextAntialiasing
                            QPainter::SmoothPixmapTransform
                            QPainter::HighQualityAntialiasing
                            QPainter::NonCosmeticDefaultPen
                            */

                            return prevFlags;
                           }


                        int getRealColorPlanes()
                           {
                            // TODO: return real num color planes here
                            return 3;
                           }

                        int getRealBitDepth()
                           { // TODO: return real bit depth here
                            return 8;
                           }

                        CLIMETHOD(setPixel) (THIS_ INT    x /* [in] int  x  */
                                                 , INT    y /* [in] int  y  */
                                                 , COLORREF    clr /* [in] colorref  clr  */
                                            )
                           {
                            coordToDcCoord(x, y);
                            QPen prevPen = pdc->pen();
                            pdc->setPen( toQtColor(clr) );
                            pdc->drawPoint ( QPoint(x, y) );
                            pdc->setPen( prevPen );
                            return 0;
                           }

                        //void QPainter::drawPoints ( const QPoint * points, int pointCount )

                        CLIMETHOD(setPixelPoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,ref] ::cli::drawing::CPoint  p  */
                                                      , COLORREF    clr /* [in] colorref  clr  */
                                                 )
                           {
                            CPoint pTmp;
                            coordToDcCoord( pTmp, *p );
                            QPen prevPen = pdc->pen();
                            pdc->setPen( toQtColor(clr) );
                            pdc->drawPoint ( QPoint(pTmp.x, pTmp.y) );
                            pdc->setPen( prevPen );
                            return 0;
                           }

                        CLIMETHOD(setPixels) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in] ::cli::drawing::CPoint  p[]  */
                                                  , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                                  , COLORREF    clr /* [in] colorref  clr  */
                                             )
                           {
                            QPen prevPen = pdc->pen();
                            pdc->setPen( toQtColor(clr) );
                            for (SIZE_T i = 0; i!=numPoints; ++i, ++p)
                               {
                                CPoint pTmp;
                                coordToDcCoord( pTmp, *p );
                                pdc->drawPoint ( QPoint(pTmp.x, pTmp.y) );
                               }
                            pdc->setPen( prevPen );
                            return 0;
                           }

                        CLIMETHOD(setPen) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                               , INT    width /* [in] int  width  */
                                               , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::PenStyle  style  */
                                          )
                           {
                            QPen qpen( toQtColor(clr) );
                            qpen.setStyle ( penStyleToImpl(style) );
                            qpen.setWidth ( width ? scalePenWidth(width) : 0 );
                            pdc->setPen( qpen );
                            return 0;
                           }

                        CLIMETHOD(pushSetPen) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                   , INT    width /* [in] int  width  */
                                                   , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::PenStyle  style  */
                                              )
                           {
                            penStack.push(pdc->pen());
                            QPen qpen( toQtColor(clr) );
                            qpen.setStyle ( penStyleToImpl(style) );
                            qpen.setWidth ( width ? scalePenWidth(width) : 0 );
                            pdc->setPen( qpen );
                            return 0;
                           }

                        CLIMETHOD(setPenEx) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                 , INT    width /* [in] int  width  */
                                                 , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                                 , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                                 , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                            )
                           {
                            QPen qpen( toQtColor(clr) );
                            qpen.setStyle ( penStyleToImpl(style) );
                            qpen.setWidth ( width ? scalePenWidth(width) : 0 );
                            qpen.setCapStyle( penCapStyleToImpl(capStyle) );
                            qpen.setJoinStyle( penJoinStyleToImpl(joinStyle) );
                            pdc->setPen( qpen );
                            return 0;
                           }

                        CLIMETHOD(pushSetPenEx) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                     , INT    width /* [in] int  width  */
                                                     , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                                     , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                                     , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                                )
                           {
                            penStack.push(pdc->pen());
                            QPen qpen( toQtColor(clr) );
                            qpen.setStyle ( penStyleToImpl(style) );
                            qpen.setWidth ( width ? scalePenWidth(width) : 0 );
                            qpen.setCapStyle( penCapStyleToImpl(capStyle) );
                            qpen.setJoinStyle( penJoinStyleToImpl(joinStyle) );
                            pdc->setPen( qpen );
                            return 0;
                           }

                        // Qt::PenStyle penStyleToImpl(ENUM_CLI_DRAWING_EPENSTYLE ps) const
                        // Qt::PenCapStyle penCapStyleToImpl(ENUM_CLI_DRAWING_EPENCAPSTYLE ps) const
                        // Qt::PenJoinStyle penJoinStyleToImpl(ENUM_CLI_DRAWING_EPENJOINSTYLE ps) const


                        CLIMETHOD(popPen) (THIS)
                           {
                            if (penStack.empty()) return 0; // no pens for restoring
                            pdc->setPen( penStack.top() );
                            penStack.pop();
                            return 0;
                           }

                        CLIMETHOD(drawLine) (THIS_ INT    x1 /* [in] int  x1  */
                                                 , INT    y1 /* [in] int  y1  */
                                                 , INT    x2 /* [in] int  x2  */
                                                 , INT    y2 /* [in] int  y2  */
                                            )
                           {
                            coordToDcCoord(x1, y1);
                            coordToDcCoord(x2, y2);
                            pdc->drawLine ( x1, y1, x2, y2 );
                            return 0;
                           }

                        CLIMETHOD(drawLinePoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    pointFrom /* [in,ref] ::cli::drawing::CPoint  pointFrom  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    pointTo /* [in,ref] ::cli::drawing::CPoint  pointTo  */
                                                 )
                           {
                            CPoint pTmp1, pTmp2;
                            coordToDcCoord( pTmp1, *pointFrom );
                            coordToDcCoord( pTmp2, *pointTo );
                            pdc->drawLine(pTmp1.x, pTmp1.y, pTmp2.x, pTmp2.y);
                            return 0;
                           }

                        CLIMETHOD(drawLines) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    points /* [in] ::cli::drawing::CPoint  points[]  */
                                                  , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                             )
                           {
                            if (!points || numPoints<2) return 0;
                            CPoint startPoint, endPoint;
                            coordToDcCoord( endPoint, *points );
                            --numPoints; ++points;
                            for(; numPoints!=0; --numPoints, ++points)
                               {
                                startPoint = endPoint;
                                coordToDcCoord( endPoint, *points );
                                pdc->drawLine(startPoint.x, startPoint.y, endPoint.x, endPoint.y);
                               }                           
                            return 0;
                           }

                        CLIMETHOD(drawLinesPairPoints) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    points /* [in] ::cli::drawing::CPoint  points[]  */
                                                      , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                                 )
                           {
                            if (!points || numPoints<2) return 0;
                            for(; numPoints>1; numPoints-=2, points+=2)
                               {
                                drawLinePoint(points, points+1);
                               }
                            return 0;
                           }

                        CLIMETHOD(setSolidBrush) (THIS_ COLORREF    clr /* [in] colorref  clr  */)
                           {
                            pdc->setBrush ( QBrush(toQtColor(clr)));
                            return 0;
                           }

                        CLIMETHOD(setNullBrush) (THIS)
                           {
                            pdc->setBrush ( QBrush( Qt::NoBrush ) );
                            //QBrush ( Qt::BrushStyle style )
                            //The brush style() defines the fill pattern using the Qt::BrushStyle enum. The default brush style is Qt::NoBrush (depending on how you construct a brush). This style tells 
                            return 0;
                           }

                        CLIMETHOD(pushSetSolidBrush) (THIS_ COLORREF    clr /* [in] colorref  clr  */)
                           {
                            brushStack.push(pdc->brush());
                            pdc->setBrush ( QBrush(toQtColor(clr)));
                            return 0;
                           }

                        CLIMETHOD(pushSetNullBrush) (THIS)
                           {
                            brushStack.push(pdc->brush());
                            pdc->setBrush ( QBrush( Qt::NoBrush ) );
                            return 0;
                           }

                        CLIMETHOD(popBrush) (THIS)
                           {
                            if (brushStack.empty()) return 0;
                            pdc->setBrush( brushStack.top() );
                            brushStack.pop();
                            return 0;
                           }

                        CLIMETHOD(fillRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            return fillRectWH( &leftTop, &widthHeight);
                           }

                        CLIMETHOD(fillRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                              )
                           {
                            if (!leftTop || !widthHeight) return 0;

                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            //coordToDcCoord(wh, *widthHeight);
                            //sizeToDcSize(CPoint &coordSrcAndDst)
                            sizeToDcSize(wh, *widthHeight);

                            pdc->fillRect ( lt.x, lt.y, wh.x, wh.y, pdc->brush() );
                            return 0;
                           }

                        #ifdef UNDEFINED
                        CLIMETHOD(drawChord) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                             )
                           {
                            return 0;
                           }

                        CLIMETHOD(drawChordWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                               )
                           {
                            return 0;
                           }

                        CLIMETHOD(drawPie) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                           )
                           {
                            return 0;
                           }

                        CLIMETHOD(drawPieWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                             )
                           {
                            return 0;
                           }
                        #endif // UNDEFINED

                        CLIMETHOD(drawEllipse) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            drawEllipseWH(&leftTop, &widthHeight);
                            return 0;
                           }

                        CLIMETHOD(drawEllipseWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            //coordToDcCoord(wh, *widthHeight);
                            sizeToDcSize(wh, *widthHeight);
                            pdc->drawEllipse( lt.x, lt.y, wh.x, wh.y );
                            return 0;
                           }

                        CLIMETHOD(drawRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            drawRectWH(&leftTop, &widthHeight);
                            return 0;
                           }

                        CLIMETHOD(drawRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                              )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            //coordToDcCoord(wh, *widthHeight);
                            sizeToDcSize(wh, *widthHeight);
                            pdc->drawRect( lt.x, lt.y, wh.x, wh.y );
                            return 0;
                           }

                        CLIMETHOD(drawRoundRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                      , INT    radius /* [in] int  radius  */
                                                 )
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            drawRoundRectWH(&leftTop, &widthHeight, radius);
                            return 0;
                           }

                        CLIMETHOD(drawRoundRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                        , INT    radius /* [in] int  radius  */
                                                   )

                           {
                            if (!leftTop || !widthHeight) return 0;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            sizeToDcSize(wh, *widthHeight);
                            //coordToDcCoord(wh, *widthHeight);
                            INT radiusX = radius, radiusY = radius; sizeToDcSize(radiusX, radiusY);
                            #if !defined(QT_VERSION) /* too old version */ || QT_VERSION < 0x040400 /* Qt ver less than 4.4.0 */
                            pdc->drawRoundRect ( lt.x, lt.y, wh.x, wh.y, radiusX, radiusY );
                            #else
                            pdc->drawRoundedRect( lt.x, lt.y, wh.x, wh.y, qreal(radiusX), qreal(radiusY), Qt::AbsoluteSize );
                            #endif
                            return 0;
                           }

                        //::cli::drawing::BkMode
                        //opaque
                        //transparent
                        CLIMETHOD_(DWORD, getBkMode) (THIS)
                           {
                            using namespace ::cli::drawing::BkMode;
                            Qt::BGMode mode = pdc->backgroundMode();
                            if (mode==Qt::TransparentMode) return transparent;
                            if (mode==Qt::OpaqueMode)      return opaque;
                            return 0;
                           }

                        // setBkMode( ::cli::drawing::BkMode::transparent )
                        CLIMETHOD_(DWORD, setBkMode) (THIS_ DWORD    mode /* [in] ::cli::drawing::BkMode  mode  */)
                           {
                            using namespace ::cli::drawing::BkMode;
                            DWORD prevMode = getBkMode();                            
                            switch(mode)
                               {
                                case transparent:  pdc->setBackgroundMode(Qt::TransparentMode); break;
                                case opaque:       pdc->setBackgroundMode(Qt::OpaqueMode); break;
                                default:           return 0;
                               }
                            return prevMode;
                           }

                        //COLORREF fromQtColor(QColor qtclr)
                        //QColor toQtColor( COLORREF clr)
                        CLIMETHOD_(COLORREF, getBkColor) (THIS)
                           {
                            if (bkColor==uninitializedBkColor)
                               {
                                QBrush bgBrush = pdc->background();
                                bkColor = fromQtColor(bgBrush.color());
                               }
                            return bkColor;
                            //return fromQtColor(pdc->background().color());
                            /*
                            void QPainter::setBackground ( const QBrush & brush )
                            const QBrush & QPainter::background () const
                            const QColor & color () const
                            */
                            //return 0;
                           }

                        CLIMETHOD_(COLORREF, setBkColor) (THIS_ COLORREF    color /* [in] colorref  color  */)
                           {
                            COLORREF prevBkColor = getBkColor();
                            /*
                            QBrush bgBrush = pdc->background();
                            if (bkColor==uninitializedBkColor)
                               {
                                prevBkColor = fromQtColor(bgBrush.color());
                               }
                            else
                               {
                                prevBkColor = bkColor;
                               }
                            */
                            bkColor = color;
                            QBrush bgBrush = pdc->background();
                            bgBrush.setColor(toQtColor(color));
                            pdc->setBackground ( bgBrush );
                            return prevBkColor;
                           }

                        CLIMETHOD(bkColorGet) (THIS_ COLORREF*    _bkColor /* [out] colorref bkColor  */)
                           {
                            if (!_bkColor) return EC_INVALID_PARAM;
                            *_bkColor = getBkColor();
                            return EC_OK;
                           }

                        CLIMETHOD(bkColorSet) (THIS_ COLORREF    _bkColor /* [in] colorref  bkColor  */)
                           { 
                            setBkColor(_bkColor); 
                            return EC_OK;
                           }

                        CLIMETHOD_(COLORREF, getTextColor) (THIS)
                           {
                            return textColor;
                           }

                        CLIMETHOD_(COLORREF, setTextColor) (THIS_ COLORREF    color /* [in] colorref  color  */)
                           {
                            COLORREF prevColor = textColor;
                            textColor = color;
                            return prevColor;
                           }

                        CLIMETHOD(textColorGet) (THIS_ COLORREF*    _textColor /* [out] colorref textColor  */)
                           {
                            if (!_textColor) return EC_INVALID_PARAM;
                            *_textColor = textColor;
                            return EC_OK;
                           }

                        CLIMETHOD(textColorSet) (THIS_ COLORREF    _textColor /* [in] colorref  textColor  */)
                           {
                            setTextColor(_textColor);
                            return EC_OK;
                           }

                        CLIMETHOD(textOut) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                , const CLISTR*     text
                                           )
                           {
                            if (!leftTopPos || !text) return 0;
                            CPoint ltpos;
                            coordToDcCoord( ltpos, *leftTopPos );
                            /*
                            inline const ushort unicode() const { return ucs; }
                            QTextCodec
                            */
                            //textColor
                            QPen prevPen = pdc->pen();
                            pdc->setPen( toQtColor(textColor) );
                            //pdc->drawText ( QPoint(ltpos.x, ltpos.y),  toQtString(text->pData, text->stringSize) );
                            pdc->drawText ( ltpos.x, ltpos.y, 10, 10
                                          , Qt::AlignLeft | Qt::AlignTop | Qt::TextSingleLine | Qt::TextDontClip
                                          , toQtString(text->pData, text->stringSize)
                                          );

                            pdc->setPen( prevPen );
                            return 0;
                           }

                        CLIMETHOD(setFontIndirect) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    props /* [in,ref] ::cli::drawing::font::Properties  props  */)
                           {
                            if (!props) return EC_INVALID_PARAM;
                            pdc->setFont(implCreateFont(props));
                            return 0;
                           }

                        CLIMETHOD(pushSetFontIndirect) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    props /* [in,ref] ::cli::drawing::font::Properties  props  */)
                           {
                            if (!props) return EC_INVALID_PARAM;
                            fontStack.push(pdc->font());
                            pdc->setFont(implCreateFont(props));
                            return 0;
                           }

                        CLIMETHOD(popFont) (THIS)
                           {
                            if (fontStack.empty()) return 0;
                            pdc->setFont( fontStack.top() );
                            fontStack.pop();
                            return 0;
                           }

                        CLIMETHOD(calcTextExtent) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [out,ref] ::cli::drawing::CPoint widthHeight  */
                                                       , const CLISTR*     text
                                                  )
                           {
                            if (!widthHeight) return EC_OK; // do nothing
                            if (!text) return EC_INVALID_PARAM;

                            QRect orgRect(0,0,0,0);
                            QRect calcRect;

                            pdc->drawText ( orgRect
                                          , Qt::AlignLeft|Qt::AlignTop|Qt::TextDontClip|Qt::TextSingleLine|Qt::TextHideMnemonic|Qt::TextDontPrint /* int flags */ 
                                          , toQtString(text->pData, text->stringSize)
                                          , &calcRect
                                          );

                            using ::cli::drawing::makePoint;
                            CPoint resSize;

                            sizeFromDcSize( resSize, makePoint( calcRect.width(), calcRect.height() ) );
                            widthHeight->x = resSize.x;
                            widthHeight->y = resSize.y;

                            return EC_OK;
                           }

                        CLIMETHOD(rotatedTextOut) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                       , INT    rotan /* [in] int  rotan  */
                                                       , const CLISTR*     text
                                                  )
                           {
                            if (!text || !leftTopPos) return EC_INVALID_PARAM;

                            QMatrix prevMatrix = pdc->worldMatrix();

                            CPoint ltpos;
                            coordToDcCoord( ltpos, *leftTopPos );

                            pdc->translate(ltpos.x, ltpos.y); 
                            pdc->rotate(-double(rotan)/10.0);

                            QPen prevPen = pdc->pen();
                            pdc->setPen( toQtColor(textColor) );
                            //pdc->drawText ( QPoint(ltpos.x, ltpos.y),  toQtString(text->pData, text->stringSize) );
                            pdc->drawText ( 0, 0, 10, 10
                                          , Qt::AlignLeft | Qt::AlignTop | Qt::TextSingleLine | Qt::TextDontClip
                                          , toQtString(text->pData, text->stringSize)
                                          );

                            pdc->setPen( prevPen );

                            pdc->setWorldMatrix(prevMatrix);
                            return EC_OK;
                           }

                        CLIMETHOD(drawGradientCircle) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                                           , INT    radius /* [in] int  radius  */
                                                           , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                                           , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                                           , DWORD    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                                      )
                           {
                            if (!centerPos) return EC_OK;

                            using namespace ::cli::drawing;

                            CPoint cp;
                            coordToDcCoord( cp, *centerPos );
                            QPointF cpf( qreal(cp.x), qreal(cp.y) );

                            QRadialGradient gradient( cpf, qreal(scalePenWidth(radius)), cpf );
                            gradient.setColorAt ( 0.0, toQtColor(colorCenter) );
                            gradient.setColorAt ( 1.0, toQtColor(colorRadius) );
                            
                            QBrush oldBrush = pdc->brush();
                            QPen oldPen     = pdc->pen();
                            if (flags&GradientFlags::noCurrentPenBorder)
                               {
                                QPen qpen( toQtColor(colorRadius) );
                                qpen.setStyle ( penStyleToImpl(EPenStyle::solid) );
                                qpen.setWidth ( scalePenWidth(1) );
                                pdc->setPen( qpen );
                               }
                            pdc->setBrush(QBrush(gradient));
                            drawCircle(centerPos, radius);
                            pdc->setBrush(oldBrush);
                            pdc->setPen( oldPen );
                            return EC_OK;
                           }

                        CLIMETHOD(drawGradientCircleEx) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                                             , INT    radius /* [in] int  radius  */
                                                             , INT    smallRadius /* [in] int  smallRadius  */
                                                             , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                                             , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                                             , DWORD    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                                        )
                           {
                            if (!centerPos) return EC_OK;

                            using namespace ::cli::drawing;
                            if (radius<smallRadius) ::std::swap(radius, smallRadius);

                            ::std::vector< COLORREF > gradient;
                            cli::drawing::colorUtils::makeGradientColorsVector( colorCenter
                                                                              , colorRadius
                                                                              , radius - smallRadius + 1
                                                                              , gradient
                                                                              );

                            QPen   orgPen   = pdc->pen();
                            QBrush orgBrush = pdc->brush();

                            int scaledPenWidth = scalePenWidth(2);
                            if (scaledPenWidth<2) scaledPenWidth = 2;

                            pdc->setBrush( QBrush( Qt::NoBrush ) );
                            COLORREF prevColor = gradient[0];

                            QPen qpen( toQtColor(prevColor) );
                            qpen.setStyle ( Qt::SolidLine );
                            qpen.setWidth ( scaledPenWidth );
                            pdc->setPen( qpen );

                            int curRadius = smallRadius;
                            for(; curRadius<radius; ++curRadius)
                               {
                                // set pen to next gradient color, if it is different with current
                                if (prevColor!=gradient[curRadius-smallRadius])
                                   {
                                    prevColor = gradient[curRadius-smallRadius];
                                    QPen qpen( toQtColor(prevColor) );
                                    qpen.setStyle ( Qt::SolidLine );
                                    qpen.setWidth ( scaledPenWidth );
                                    pdc->setPen( qpen );                                    
                                   }
                                drawCircle(centerPos, curRadius);
                               }

                            if (flags&GradientFlags::noCurrentPenBorder)
                               {
                                QPen qpen( toQtColor(gradient[curRadius-smallRadius]) );
                                qpen.setStyle ( Qt::SolidLine );
                                qpen.setWidth ( scalePenWidth(1) );
                                pdc->setPen( qpen );
                                drawCircle(centerPos, curRadius);
                                pdc->setPen(orgPen);
                               }
                            else
                               {
                                pdc->setPen(orgPen);
                                drawCircle(centerPos, curRadius);
                               }
                            pdc->setBrush(orgBrush);
                           
                            return EC_OK;
                           }

                        CLIMETHOD(setClipRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                            leftTop.x = rect->left;
                            leftTop.y = rect->top;
                            widthHeight.x = rect->right - rect->left;
                            widthHeight.y = rect->bottom - rect->top;
                            setClipRectWH(&leftTop, &widthHeight);
                            //pdc->setClipping( true /* enable */  );
                            return EC_OK;
                           }

                        CLIMETHOD(setClipRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 )
                           {
                            if (!leftTop || !widthHeight) return EC_INVALID_PARAM;
                            CPoint lt, wh;
                            coordToDcCoord(lt, *leftTop);
                            //coordToDcCoord(wh, *widthHeight);
                            sizeToDcSize(wh, *widthHeight);
                            if (wh.x<0) wh.x = 0;
                            if (wh.y<0) wh.y = 0;
                            QRect clipRect( lt.x, lt.y, wh.x, wh.y );
                            pdc->setClipRect ( clipRect, Qt::ReplaceClip ); // Qt::ClipOperation operation = Qt::ReplaceClip
                            pdc->setClipping( true /* enable */  );
                            return EC_OK;
                           }

                        CLIMETHOD(clearClipRect) (THIS)
                           {
                            QRect clipRect( 0, 0, 0, 0 );
                            pdc->setClipRect ( clipRect, Qt::NoClip );
                            //pdc->setClipping( false /* disable */  );
                            return EC_OK;
                           }

                        CLIMETHOD(createBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                          , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                     )
                           {
                            if (!pbmp || !widthHeight) return EC_INVALID_PARAM;

                            CPoint wh;
                            sizeToDcSize(wh, *widthHeight);

                            ::cli::drawing::impl::qt::CDeviceBitmap *bmp = 
                                   new ::cli::drawing::impl::qt::CDeviceBitmap( pdc, wh.x, wh.y );
                            *pbmp = static_cast<INTERFACE_CLI_DRAWING_IDEVICEBITMAP*>(bmp);
                            return EC_OK;
                           }

                        CLIMETHOD(createCopyBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                              , const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                              , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                         )
                           {
                            if (!pbmp || !leftTop || !widthHeight) return EC_INVALID_PARAM;

                            CPoint wh;
                            sizeToDcSize(wh, *widthHeight);

                            CPoint lt;
                            coordToDcCoord( lt, *leftTop );

                            ::cli::drawing::impl::qt::CDeviceBitmap *bmp = 
                                   new ::cli::drawing::impl::qt::CDeviceBitmap( pdc, wh.x, wh.y, lt.x, lt.y );
                            *pbmp = static_cast<INTERFACE_CLI_DRAWING_IDEVICEBITMAP*>(bmp);
                            return EC_OK;
                           }

                        CLIMETHOD(drawBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP*    pbmp /* [in] ::cli::drawing::iDeviceBitmap*  pbmp  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   )
                           {
                            if (!pbmp || !leftTop) return EC_INVALID_PARAM;

                            INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP *pImplBmp = 0;
                            RCODE res = pbmp->queryInterface( ::cli::iidOf(pImplBmp), (VOID**)&pImplBmp );
                            if (res || !pImplBmp) return EC_INCOMPATIBLE_OBJECT;

                            CLI_DRAWING_GENERIC_HANDLE ghBmp;
                            res = pImplBmp->getHandle(&ghBmp);
                            if (res) return res;

                            STRUCT_CLI_DRAWING_CPOINT widthHeight;
                            res = pImplBmp->sizeGet(&widthHeight);
                            if (res) return res;

                            //CPoint wh;
                            //sizeToDcSize(wh, widthHeight);

                            CPoint lt;
                            coordToDcCoord( lt, *leftTop );

                            pdc->drawPixmap( QRect(lt.x, lt.y, widthHeight.x, widthHeight.y), *((QPixmap*)ghBmp), QRect(0, 0, widthHeight.x, widthHeight.y) );
                            return EC_OK;
                           }


                        #ifdef CLI_DRAWING_IDC1_SUPPORT_GETPIXEL
                        CLIMETHOD_(COLORREF, getPixel) (THIS_ INT    x /* [in] int  x  */
                                                            , INT    y /* [in] int  y  */
                                                       )
                           {
                            int *ptr = 0;
                            *ptr = 0; // getPixel not implemented - Qt QPainter has no apropriate methods
                            return 0;
                           }

                        CLIMETHOD_(COLORREF, getPixelPoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,ref] ::cli::drawing::CPoint  p  */)
                           {
                            int *ptr = 0;
                            *ptr = 0; // getPixel not implemented - Qt QPainter has no apropriate methods
                            return 0;
                           }
                        #endif


        
                }; // ::cli::drawing::impl::qt::CDrawContext1Impl


            }; /* namespace qt */
        }; /* namespace impl */
    }; /* namespace drawing */
}; /* namespace cli */


#endif /* CLI_DRAWING_IMPL_DC1QT_H */

