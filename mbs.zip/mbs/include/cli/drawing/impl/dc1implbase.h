#ifndef CLI_DRAWING_DC1IMPLBASE_H
#define CLI_DRAWING_DC1IMPLBASE_H



#ifdef _WIN32
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_DRAWING_IMPL_IMPLHLP_H
    #include <cli/drawing/impl/implhlp.h>
#endif


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STACK_) && !defined(_STLP_STACK) && !defined(__STD_STACK__) && !defined(_CPP_STACK) && !defined(_GLIBCXX_STACK)
    #include <stack>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

namespace cli {
    namespace drawing {
        namespace impl {

// ::cli::drawing::impl

            class CDrawContext1ImplBase : public ::cli::CComponentImplBase< ::cli::CRefCounter, ::cli::CDummyModule > // DEF_MODULE_TYPE >
                                        , public ::cli::drawing::iDrawContext1
            {
                public:

                    //typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
                    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, ::cli::CDummyModule > base_impl;
                    bool    useRefCounting;
                
                    //typedef ::cli::drawing::CPoint         CPoint;
    
                protected:
    
                    CPoint  offset;
                    CPoint  contextSize;

                    COLORREF m_colorScaleMultiplier; // 0x01010101
                    COLORREF m_colorScaleDivisor;    // 0x01010101

                    COLORREF m_colorScaleMultiplier1; // 0x01
                    COLORREF m_colorScaleDivisor1   ; // 0x01
                    COLORREF m_colorScaleMultiplier2; // 0x01
                    COLORREF m_colorScaleDivisor2   ; // 0x01
                    COLORREF m_colorScaleMultiplier3; // 0x01
                    COLORREF m_colorScaleDivisor3   ; // 0x01
                    COLORREF m_colorScaleMultiplier4; // 0x01
                    COLORREF m_colorScaleDivisor4   ; // 0x01

                    int     coordMultiplierX;
                    int     coordDividerX;
                    int     coordMultiplierY;
                    int     coordDividerY;
                    int     penWidthMultiplier;
                    int     penWidthDivider;

                    // struct for saving viewport params
                    struct CViewPortParams
                       {
                        CPoint  offset;
                        CPoint  contextSize;

                        int     coordMultiplierX;
                        int     coordDividerX;
                        int     coordMultiplierY;
                        int     coordDividerY;
                        int     penWidthMultiplier;
                        int     penWidthDivider;

                        CViewPortParams()
                           : offset            ( )
                           , contextSize       ( )
                           , coordMultiplierX  (1)
                           , coordDividerX     (1)
                           , coordMultiplierY  (1) 
                           , coordDividerY     (1)    
                           , penWidthMultiplier(1)
                           , penWidthDivider   (1)
                           /*
                           , coordMultiplierX  (0)
                           , coordDividerX     (0)
                           , coordMultiplierY  (0) 
                           , coordDividerY     (0)    
                           , penWidthMultiplier(0)
                           , penWidthDivider   (0)
                           */
                           {
                           }

                        CViewPortParams(const CDrawContext1ImplBase &dcImpl)
                           : offset            (dcImpl.offset            )
                           , contextSize       (dcImpl.contextSize       )
                           , coordMultiplierX  (dcImpl.coordMultiplierX  )
                           , coordDividerX     (dcImpl.coordDividerX     )
                           , coordMultiplierY  (dcImpl.coordMultiplierY  ) 
                           , coordDividerY     (dcImpl.coordDividerY     )    
                           , penWidthMultiplier(dcImpl.penWidthMultiplier)
                           , penWidthDivider   (dcImpl.penWidthDivider   )
                           {
                           }

                        void restoreDC(CDrawContext1ImplBase &dcImpl)
                           {
                            dcImpl.offset             = offset            ;
                            dcImpl.contextSize        = contextSize       ;
                            dcImpl.coordMultiplierX   = coordMultiplierX  ;
                            dcImpl.coordDividerX      = coordDividerX     ;
                            dcImpl.coordMultiplierY   = coordMultiplierY  ;
                            dcImpl.coordDividerY      = coordDividerY     ;
                            dcImpl.penWidthMultiplier = penWidthMultiplier;
                            dcImpl.penWidthDivider    = penWidthDivider   ;
                           }
                       };


                    bool    monochromeMode;
                    int     colorBits;
                    ::std::vector<COLORREF> monochromeColors;

                    /* color trust mode.     ��������� ��������� ������.      
                     * color trusting mode.  ���� ���������� ������.          
                     * trusted colors mode.  ������ ������, �������� ��������.
                     */
                    bool    colorTrustingMode;

                    STRUCT_CLI_DRAWING_CRECT                 curClipRect;
                    ::std::stack< STRUCT_CLI_DRAWING_CRECT > clipStack;
                    ::std::stack< CViewPortParams >          viewportStack;
                    //STRUCT_CLI_DRAWING_FONT_PROPERTIES curFontProps;
                    ::std::stack< STRUCT_CLI_DRAWING_FONT_PROPERTIES > fontPropsStack;

                    

    
                public:


                    ~CDrawContext1ImplBase() 
                       {
                        CLIASSERT(clipStack    .size()==0);
                        CLIASSERT(viewportStack.size()==0);
                       }

                    CDrawContext1ImplBase() 
                       //: base_impl(DEF_MODULE)
                       : base_impl()
                       , useRefCounting(false)
                       , offset()
                       , contextSize()

                       , m_colorScaleMultiplier(0x01010101)
                       , m_colorScaleDivisor(0x01010101)
                       , m_colorScaleMultiplier1(1)
                       , m_colorScaleDivisor1   (1)
                       , m_colorScaleMultiplier2(1)
                       , m_colorScaleDivisor2   (1)
                       , m_colorScaleMultiplier3(1)
                       , m_colorScaleDivisor3   (1)
                       , m_colorScaleMultiplier4(1)
                       , m_colorScaleDivisor4   (1)

                       , coordMultiplierX(1)
                       , coordDividerX(1)
                       , coordMultiplierY(1)
                       , coordDividerY(1)
                       , penWidthMultiplier(1)
                       , penWidthDivider(1)

                       , monochromeMode(false)
                       , colorBits(0)
                       , monochromeColors()
                       , colorTrustingMode(false)

                       , curClipRect(::cli::drawing::makeRect(-1, -1, -1, -1))
                       , clipStack()
                       , viewportStack()
                       //, greyScaleMode(0)
                       //, highContrastMode(0)
                       //, curFontProps()
                       , fontPropsStack()
                       {
                       }

                    RCODE beforeColorScaleGet() { return 0; }

                    RCODE afterColorScaleMultiplierSet()
                       {
                        m_colorScaleMultiplier1 = (m_colorScaleMultiplier    )&0xFF;
                        m_colorScaleMultiplier2 = (m_colorScaleMultiplier>> 8)&0xFF;
                        m_colorScaleMultiplier3 = (m_colorScaleMultiplier>>16)&0xFF;
                        m_colorScaleMultiplier4 = (m_colorScaleMultiplier>>24)&0xFF;
                        return 0;
                       }

                    RCODE afterColorScaleDivisorSet()
                       {
                        m_colorScaleDivisor1    = (m_colorScaleDivisor    )&0xFF;
                        m_colorScaleDivisor2    = (m_colorScaleDivisor>> 8)&0xFF;
                        m_colorScaleDivisor3    = (m_colorScaleDivisor>>16)&0xFF;
                        m_colorScaleDivisor4    = (m_colorScaleDivisor>>24)&0xFF;
                        return 0;
                       }

                    PROPERTY_RW_IMPL_EX( colorScaleMultiplier, m_colorScaleMultiplier, COLORREF, afterColorScaleMultiplierSet, beforeColorScaleGet )
                    PROPERTY_RW_IMPL_EX( colorScaleDivisor   , m_colorScaleDivisor   , COLORREF, afterColorScaleDivisorSet   , beforeColorScaleGet )

                    //PROPERTY_RW_IMPL( colorScaleMultiplier, m_colorScaleMultiplier, COLORREF )
                    //PROPERTY_RW_IMPL( colorScaleDivisor   , m_colorScaleDivisor   , COLORREF )

                    CLIMETHOD(setColorScaling) (THIS_ USHORT    mult /* [in] ushort  mult  */
                                                    , USHORT    div /* [in] ushort  div  */
                                               )
                       {
                        COLORREF m = (mult&0xFF);
                        COLORREF d = (div&0xFF);
                        //m_colorScaleMultiplier = m | (m<<8) | (m<<16) | (m<<24);
                        //m_colorScaleDivisor    = d | (d<<8) | (d<<16) | (d<<24);
                        colorScaleMultiplierSet( m | (m<<8) | (m<<16) | (m<<24) );
                        colorScaleDivisorSet( d | (d<<8) | (d<<16) | (d<<24) );
                        return EC_OK;
                       }

                    CLIMETHOD(resetColorScaling) (THIS)
                       {
                        return setColorScaling(1,1);
                       }

                    COLORREF fastScaleColor(COLORREF srcColor) const
                       {
                        if (m_colorScaleMultiplier==m_colorScaleDivisor) return srcColor;
                        /*
                        COLORREF tmpColor = srcColor>>8;
                        USHORT tmp1 = (USHORT)(((srcColor & 0x00FF00FF)*(m_colorScaleMultiplier & 0x00FF00FF)) & 0xFFFF);
                        USHORT tmp3 = (USHORT)((((srcColor & 0x00FF00FF)*(m_colorScaleMultiplier & 0x00FF00FF))>>16) & 0xFFFF);
                        USHORT tmp2 = (USHORT)(((tmpColor & 0x00FF00FF)*(m_colorScaleMultiplier & 0x00FF00FF)) & 0xFFFF);
                        USHORT tmp4 = (USHORT)((((tmpColor & 0x00FF00FF)*(m_colorScaleMultiplier & 0x00FF00FF))>>16) & 0xFFFF);

                        COLORREF tmp1 = (COLORREF)(((srcColor      ) & 0xFF) * ((m_colorScaleMultiplier      ) & 0xFF));
                        COLORREF tmp2 = (COLORREF)(((srcColor >>  8) & 0xFF) * ((m_colorScaleMultiplier >>  8) & 0xFF));
                        COLORREF tmp3 = (COLORREF)(((srcColor >> 16) & 0xFF) * ((m_colorScaleMultiplier >> 16) & 0xFF));
                        COLORREF tmp4 = (COLORREF)(((srcColor >> 24) & 0xFF) * ((m_colorScaleMultiplier >> 24) & 0xFF));
                        */

                        COLORREF tmp1 = (COLORREF)(((srcColor      ) & 0xFF) * m_colorScaleMultiplier1);
                        COLORREF tmp2 = (COLORREF)(((srcColor >>  8) & 0xFF) * m_colorScaleMultiplier2);
                        COLORREF tmp3 = (COLORREF)(((srcColor >> 16) & 0xFF) * m_colorScaleMultiplier3);
                        COLORREF tmp4 = (COLORREF)(((srcColor >> 24) & 0xFF) * m_colorScaleMultiplier4);

                        tmp1 /= m_colorScaleDivisor1;
                        tmp2 /= m_colorScaleDivisor2;
                        tmp3 /= m_colorScaleDivisor3;
                        tmp4 /= m_colorScaleDivisor4;

                        tmp1 = tmp1 > 255 ? 255 : tmp1;
                        tmp2 = tmp2 > 255 ? 255 : tmp2;
                        tmp3 = tmp3 > 255 ? 255 : tmp3;
                        tmp4 = tmp4 > 255 ? 255 : tmp4;

                        return ((COLORREF)(tmp1)) | ((COLORREF)(tmp2<<8)) | ((COLORREF)(tmp3<<16)) | ((COLORREF)(tmp4<<24));
                        /*
                        return
                        (((COLORREF)(tmp1 / (USHORT)((m_colorScaleDivisor    )&0xFF)))    ) |
                        (((COLORREF)(tmp2 / (USHORT)((m_colorScaleDivisor>>8 )&0xFF)))<<8 ) |
                        (((COLORREF)(tmp3 / (USHORT)((m_colorScaleDivisor>>16)&0xFF)))<<16) |
                        (((COLORREF)(tmp4 / (USHORT)((m_colorScaleDivisor>>24)&0xFF)))<<24) ;
                        */
                       }

                    // fills monochromeColors vector with interpolated values from black to white
                    void setMonochromeColors(COLORREF black, COLORREF white, int numBits)
                       {
                        monochromeColors.clear();
                        if (numBits<=1)
                           {
                            monochromeColors.push_back(black);
                            monochromeColors.push_back(white);
                            return;
                           }
                        int colorsNumber = 1<<numBits;

                        const unsigned scale = 10000;
                        unsigned bRed   = (unsigned(0xFF&black)       )*scale;
                        unsigned bGreen = (unsigned(0xFF&(black>>8))  )*scale;
                        unsigned bBlue  = (unsigned(0xFF&(black>>16)) )*scale;

                        unsigned wRed   = (unsigned(0xFF&white)       )*scale;
                        unsigned wGreen = (unsigned(0xFF&(white>>8))  )*scale;
                        unsigned wBlue  = (unsigned(0xFF&(white>>16)) )*scale;

                        unsigned dr = (wRed-bRed    )/(colorsNumber-1);
                        unsigned dg = (wGreen-bGreen)/(colorsNumber-1);
                        unsigned db = (wBlue -bBlue )/(colorsNumber-1);

                        for(int i=0; i!=colorsNumber; ++i)
                           {
                            monochromeColors.push_back( RGB( (bRed  +dr*i)/scale
                                                           , (bGreen+dg*i)/scale
                                                           , (bBlue +db*i)/scale
                                                           )
                                                      );
                           }
                       }

                    // number of color bits must be set before
                    void setMonochromeColors(COLORREF black, COLORREF white)
                       {
                        setMonochromeColors(black, white, colorBits);
                       }

                    void setMonochromeColors(bool bSet = true)
                       {
                        if (bSet)
                           setMonochromeColors(RGB(0, 40, 0), RGB(0, 160, 0));
                        else
                           monochromeColors.clear();
                       }

                    // set custom monochrome colors
                    void setMonochromeColors(const ::std::vector<COLORREF> &mc)
                       {
                        monochromeColors = mc;
                       }

                    void setColorTrustingMode(bool bTrusting = true)
                       {
                        colorTrustingMode = bTrusting;
                       }

                    COLORREF adjustColor(COLORREF color) const
                       {
                        if (colorTrustingMode && monochromeColors.empty()) return color;
                        return ::cli::drawing::colorUtils::adjustColor( color, monochromeMode, colorBits, &monochromeColors );
                       }

                    void setGreyScaleMode(int nBits = 8)
                       {
                        if (!nBits)
                           { // turn off color convesion
                            monochromeMode = false;
                            colorBits = 0;
                            return;
                           }
                        monochromeMode = true;
                        if (nBits>8) colorBits = 8;
                        else         colorBits = nBits;
                       }

                    void setHighContrastMode(int nBits = 8)
                       {
                        monochromeMode = false;
                        if (!nBits)
                           { // turn off color conversion
                            colorBits = 0;
                            return;
                           }
                        if (nBits>7) colorBits = 0;
                        else         colorBits = nBits;
                       }


                    void setOffset(const CPoint &_offset) { offset = _offset; }
                    void setSize  (const CPoint &size)    { contextSize = size; }

                    void coordToDcCoord(CPoint &coordDst, const CPoint &coordSrc)
                       { 
                        coordDst = coordSrc; 
                        coordDst.x += offset.x; 
                        coordDst.y += offset.y;

                        coordDst.x = mulDiv( coordDst.x, coordMultiplierX, coordDividerX);
                        coordDst.y = mulDiv( coordDst.y, coordMultiplierY, coordDividerY);
                       }

                    void coordToDcCoord(CPoint &coordSrcAndDst)
                       { 
                        coordSrcAndDst.x += offset.x; 
                        coordSrcAndDst.y += offset.y;
                        coordSrcAndDst.x = mulDiv( coordSrcAndDst.x, coordMultiplierX, coordDividerX);
                        coordSrcAndDst.y = mulDiv( coordSrcAndDst.y, coordMultiplierY, coordDividerY);
                       }

                    void sizeToDcSize(CPoint &coordDst, const CPoint &coordSrc)
                       { 
                        coordDst.x = mulDiv( coordSrc.x, coordMultiplierX, coordDividerX);
                        coordDst.y = mulDiv( coordSrc.y, coordMultiplierY, coordDividerY);
                       }

                    void sizeToDcSize(CPoint &coordSrcAndDst)
                       { 
                        coordSrcAndDst.x = mulDiv( coordSrcAndDst.x, coordMultiplierX, coordDividerX);
                        coordSrcAndDst.y = mulDiv( coordSrcAndDst.y, coordMultiplierY, coordDividerY);
                       }

                    void coordToDcCoord(INT &dstX, INT &dstY, INT srcX, INT srcY)
                       { 
                        dstX = srcX + offset.x; 
                        dstY = srcY + offset.y;
                        dstX = mulDiv( dstX, coordMultiplierX, coordDividerX);
                        dstY = mulDiv( dstY, coordMultiplierY, coordDividerY);
                       }
                    void sizeToDcSize(INT &dstX, INT &dstY, INT srcX, INT srcY)
                       { 
                        dstX = mulDiv( dstX, coordMultiplierX, coordDividerX);
                        dstY = mulDiv( dstY, coordMultiplierY, coordDividerY);
                       }

                    void coordToDcCoord(INT &X, INT &Y)
                       { 
                        X += offset.x; 
                        Y += offset.y;
                        X = mulDiv( X, coordMultiplierX, coordDividerX);
                        Y = mulDiv( Y, coordMultiplierY, coordDividerY);
                       }

                    void sizeToDcSize(INT &X, INT &Y)
                       { 
                        X = mulDiv( X, coordMultiplierX, coordDividerX);
                        Y = mulDiv( Y, coordMultiplierY, coordDividerY);
                       }

                    void rectToDcCoord( STRUCT_CLI_DRAWING_CRECT &rectDst, const STRUCT_CLI_DRAWING_CRECT &rectSrc)
                       {
                        rectDst.left   = rectSrc.left   + offset.x;
                        rectDst.top    = rectSrc.top    + offset.y;
                        rectDst.right  = rectSrc.right  + offset.x;
                        rectDst.bottom = rectSrc.bottom + offset.y;

                        rectDst.left   = mulDiv( rectDst.left  , coordMultiplierX, coordDividerX);
                        rectDst.top    = mulDiv( rectDst.top   , coordMultiplierY, coordDividerY);
                        rectDst.right  = mulDiv( rectDst.right , coordMultiplierX, coordDividerX);
                        rectDst.bottom = mulDiv( rectDst.bottom, coordMultiplierY, coordDividerY);
                       }

                    void sizeFromDcSize(CPoint &sizeDst, const CPoint &sizeSrc)
                       {
                        sizeDst = sizeSrc; // add translations here
                        sizeDst.x = mulDiv( sizeDst.x, coordDividerX, coordMultiplierX);
                        sizeDst.y = mulDiv( sizeDst.y, coordDividerY, coordMultiplierY);
                       }

                    int scalePenWidth(int penWidth) const
                       {
                        return mulDiv( penWidth, penWidthMultiplier, penWidthDivider);
                       /* , penWidthMultiplier(1)
                        * , penWidthDivider(1)
                        */
                        //return penWidth;
                       }

                    virtual
                    void getDisplayDpi(int &x, int &y)
                       {
                        x = 96;
                        y = 96;
                       }

                    void getDeviceDpi(int &x, int &y)
                       {
                        STRUCT_CLI_DRAWING_CPOINT dpi;
                        getDpi(&dpi);
                        x = dpi.x;
                        y = dpi.y;
                       }

                    void setupLikeDisplay()
                       {
                        //int dpiDisplayX, dpiDisplayY, dpiDeviceX, dpiDeviceY;
                        getDisplayDpi(coordDividerX, coordDividerY);
                        getDeviceDpi(coordMultiplierX, coordMultiplierY);

                        penWidthMultiplier = ( coordMultiplierX + coordMultiplierY ) / 2;
                        penWidthDivider    = ( coordDividerX    + coordDividerY    ) / 2;
                       }

                    virtual int getRealColorPlanes()
                       {
                        // TODO: return real num color planes here
                        return 3;
                       }

                    virtual int getRealBitDepth()
                       { // TODO: return real bit depth here
                        return 8;
                       }


                    /* interface ::cli::iUnknown methods */
                    CLI_BEGIN_INTERFACE_MAP( ::cli::drawing::impl::CDrawContext1ImplBase )
                        CLI_IMPLEMENT_INTERFACE(INTERFACE_CLI_DRAWING_IDRAWCONTEXT1)
                    CLI_END_INTERFACE_MAP(::cli::drawing::impl::CDrawContext1ImplBase)

                    // Window (or other) owns this object, ref counting not used for lifetime control
                    CLIMETHOD_(ULONG, addRef) (THIS)    
                       { 
                        if (useRefCounting) return addRefImpl();
                        else return 1;
                       }
                    CLIMETHOD_(ULONG, release) (THIS)   
                       {
                        if (useRefCounting) return releaseImpl();
                        else return 1;
                       }

                    // implement in childs as shown below
                    // void destroy() { if (useRefCounting) delete this; }

                    CLIMETHOD(setColorsConversionMode) (THIS_ UINT    _numBits /* [in] uint  numBits  */
                                                            , BOOL    _bMono /* [in] bool  bMono  */
                                                            , BOOL    _bGreen /* [in] bool  bGreen  */
                                                       )
                       {
                        if (_bMono)
                           {
                            setGreyScaleMode(_numBits);
                            if (_bGreen) setMonochromeColors();
                           }
                        else
                           {
                            setHighContrastMode(_numBits);
                           }
                        return EC_OK;
                       }

                    // Dialog Units
                    // ms-help://MS.MSDNQTR.v80.en/MS.MSDN.v80/MS.WINCE.v50.en/wceshellui5/html/wce50lrfgetdialogbaseunits.htm
                    // MS Shell Dlg, 8


                    /* interface ::cli::drawing::iDrawContext1 methods */
                    CLIMETHOD(getSize) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    pntSize /* [out,ref] ::cli::drawing::CPoint pntSize  */)
                       {
                        if (pntSize)
                           {
                            pntSize->x = mulDiv( contextSize.x, coordMultiplierX, coordDividerX);
                            pntSize->y = mulDiv( contextSize.y, coordMultiplierY, coordDividerY);
                            //coordSrcAndDst.y = mulDiv( coordSrcAndDst.y, coordMultiplierY, coordDividerY);
                            //*pntSize = contextSize;
                           }
                        return 0;
                       }

                    CLIMETHOD(getDeviceColorInfo) (THIS_ STRUCT_CLI_DRAWING_CDEVICECOLORINFO*    colorInfo /* [out,ref] ::cli::drawing::CDeviceColorInfo colorInfo  */)
                       {
                        if (!colorInfo) return 0;
                        if (colorBits || monochromeMode)
                           {
                            if (monochromeMode)
                               colorInfo->numOfColorPlanes = 1;
                            else
                                colorInfo->numOfColorPlanes = getRealColorPlanes();

                            if (colorBits)
                               colorInfo->bitDepth = colorBits;
                            else
                               {
                                colorInfo->bitDepth = getRealBitDepth();
                               }
                           }
                        else
                           {
                            // TODO: return real num color planes here
                            colorInfo->numOfColorPlanes = getRealColorPlanes();
                            colorInfo->bitDepth = getRealBitDepth();
                           }
                        return 0;
                       }

                    CLIMETHOD_(DWORD, getDeviceColorType) (THIS)
                       {
                        using namespace ::cli::drawing::DeviceColorType;
                        STRUCT_CLI_DRAWING_CDEVICECOLORINFO deviceColorInfo;
                        RCODE res = getDeviceColorInfo(&deviceColorInfo);
                        if (RC_FAIL(res)) return fullColored;

                        if (deviceColorInfo.numOfColorPlanes==1)
                           {
                            if (deviceColorInfo.bitDepth<=2)
                               return blackWhite;
                            return monochrome;
                           }
                        return fullColored;
                       }

                    struct CColorPoints
                        {
                         SIZE_T numPoints;
                         ::std::vector< STRUCT_CLI_DRAWING_CPOINT > points;
                         CColorPoints() : numPoints(0), points() {}
                        };

                    CLIMETHOD(setColorPixels) (THIS_ const STRUCT_CLI_DRAWING_CCOLORPOINT*    p /* [in] ::cli::drawing::CColorPoint  p[]  */
                                                   , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                              )
                       {

                        ::std::map< COLORREF, CColorPoints> colorPoints;

                        // first iteration - calc num of points of each color
                        const STRUCT_CLI_DRAWING_CCOLORPOINT* ptmp = p;
                        SIZE_T i = 0;
                        
                        for(; i!=numPoints; ++i, ++ptmp)
                           {
                            colorPoints[ptmp->color].numPoints += 1;
                           }

                        // reserve size in all vectors
                        for ( ::std::map< COLORREF, CColorPoints>::iterator it = colorPoints.begin()
                            ; it!=colorPoints.end()
                            ; ++it
                            )
                            {
                             it->second.points.reserve(it->second.numPoints);
                            }

                        // add point to apropriate colored vector
                        ptmp = p;
                        for(i = 0; i!=numPoints; ++i, ++ptmp)
                           {
                            colorPoints[ptmp->color].points.push_back(ptmp->point);
                           }

                        for ( ::std::map< COLORREF, CColorPoints>::iterator it = colorPoints.begin()
                            ; it!=colorPoints.end()
                            ; ++it
                            )
                            {
                             setPixels( &it->second.points[0], it->second.points.size(), it->first);
                            }

                        return 0;
                       }

                    CLIMETHOD(setPenParams) (THIS_ const STRUCT_CLI_DRAWING_CPENPARAMS*    params /* [in,ref] ::cli::drawing::CPenParams  params  */)
                       {
                        if (!params) return 0;
                        return setPen( params->clr, params->width, params->style);
                       }

                    CLIMETHOD(pushSetPenParams) (THIS_ const STRUCT_CLI_DRAWING_CPENPARAMS*    params /* [in,ref] ::cli::drawing::CPenParams  params  */)
                       {
                        if (!params) return 0;
                        return pushSetPen( params->clr, params->width, params->style);
                       }

                    CLIMETHOD(drawCircle) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                               , INT    radius /* [in] int  radius  */
                                          )
                       {
                        if (!leftTop) return 0;
                        using ::cli::drawing::makeRect;
                        STRUCT_CLI_DRAWING_CRECT rect = makeRect( leftTop->x - radius
                                                                , leftTop->y - radius
                                                                , leftTop->x + radius
                                                                , leftTop->y + radius
                                                                );
                        return drawEllipse( &rect );
                       }

                    CLIMETHOD(textOutChars) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                 , const WCHAR*    chars /* [in] wchar  chars[]  */
                                                 , SIZE_T    nChars /* [in] size_t  nChars  */
                                            )
                       {
                        if (!chars) return 0;
                        CCliStr str;
                        if (nChars==(SIZE_T)(-1)) str.assignLight( chars);
                        else                      str.assignLight( chars, nChars);
                        return this->textOut(leftTopPos, &str);
                       }

                    CLIMETHOD(setFont) (THIS_ FONT_SIZE_T height /* [in] int16  height  */
                                            , BYTE    weight /* [in] ::cli::drawing::font::Weight  weight  */
                                            , BYTE    flags /* [in] ::cli::drawing::font::Flags  flags  */
                                            , BYTE    precision /* [in] ::cli::drawing::font::Precision  precision  */
                                            , BYTE    pitch /* [in] ::cli::drawing::font::Pitch  pitch  */
                                            , BYTE    family /* [in] ::cli::drawing::font::Family  family  */
                                            , const WCHAR*    faceName /* [in] wchar  faceName[]  */
                                       )
                       {
                        // null face name allowed
                        // if (!faceName) return EC_INVALID_PARAM;
                        STRUCT_CLI_DRAWING_FONT_PROPERTIES 
                        props = { height, weight, flags, precision, pitch, family, 0 };
                        if (faceName)
                           { 
                            //(sizeof(props.faceName)/sizeof(props.faceName[0]))
                            //strncpy(props.faceName, faceName, (sizeof(props.faceName)/sizeof(props.faceName[0])));
                            wcsncpy(props.faceName, faceName, (sizeof(props.faceName)/sizeof(props.faceName[0])));
                            props.faceName[(sizeof(props.faceName)/sizeof(props.faceName[0]))-1] = 0;
                           }
                        return setFontIndirect( &props );
                       }


                    CLIMETHOD(pushSetFont) (THIS_ FONT_SIZE_T height /* [in] int16  height  */
                                                , BYTE    weight /* [in] ::cli::drawing::font::Weight  weight  */
                                                , BYTE    flags /* [in] ::cli::drawing::font::Flags  flags  */
                                                , BYTE    precision /* [in] ::cli::drawing::font::Precision  precision  */
                                                , BYTE    pitch /* [in] ::cli::drawing::font::Pitch  pitch  */
                                                , BYTE    family /* [in] ::cli::drawing::font::Family  family  */
                                                , const WCHAR*    faceName /* [in] wchar  faceName[]  */
                                           )
                       {
                        // null face name allowed
                        // if (!faceName) return EC_INVALID_PARAM;
                        STRUCT_CLI_DRAWING_FONT_PROPERTIES 
                        props = { height, weight, flags, precision, pitch, family, 0 };
                        if (faceName)
                           { 
                            //(sizeof(props.faceName)/sizeof(props.faceName[0]))
                            //strncpy(props.faceName, faceName, (sizeof(props.faceName)/sizeof(props.faceName[0])));
                            wcsncpy(props.faceName, faceName, (sizeof(props.faceName)/sizeof(props.faceName[0])));
                            props.faceName[(sizeof(props.faceName)/sizeof(props.faceName[0]))-1] = 0;
                           }
                        return pushSetFontIndirect( &props );
                       }

                    CLIMETHOD(calcTextExtentChars) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [out,ref] ::cli::drawing::CPoint widthHeight  */
                                                        , const WCHAR*    chars /* [in] wchar  chars[]  */
                                                        , SIZE_T    nChars /* [in] size_t  nChars  */
                                                   )
                       {
                        if (!chars) return 0;
                        CCliStr str;
                        //if (nChars==(SIZE_T)(-1)) str.assignLight( chars);
                        if (nChars==SIZE_T_NPOS) str.assignLight( chars);
                        else                      str.assignLight( chars, nChars);
                        return this->calcTextExtent(widthHeight, &str);
                       }

                    CLIMETHOD(rotatedTextOutChars) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                        , INT    rotan /* [in] int  rotan  */
                                                        , const WCHAR*    chars /* [in] wchar  chars[]  */
                                                        , SIZE_T    nChars /* [in] size_t  nChars  */
                                                   )
                       {
                        if (!chars) return 0;
                        CCliStr str;
                        //if (nChars==(SIZE_T)(-1)) str.assignLight( chars);
                        if (nChars==SIZE_T_NPOS) str.assignLight( chars);
                        else                      str.assignLight( chars, nChars);
                        return this->rotatedTextOut(leftTopPos, rotan, &str);
                       }

                    CLIMETHOD(pushSetClipRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                       {
                        if (!rect) return EC_INVALID_PARAM;
                        //, curClipRect(-1, -1, -1, -1)
                        clipStack.push(curClipRect);
                        curClipRect = *rect;
                        //clipStack.push(*rect);
                        //return EC_OK;
                        return setClipRect(rect);
                       }

                    CLIMETHOD(pushSetClipRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 )
                       {
                        if (!leftTop || !widthHeight) return EC_INVALID_PARAM;
                        using ::cli::drawing::makeRect;
                        STRUCT_CLI_DRAWING_CRECT rect = makeRect( *leftTop, *widthHeight);
                        //return EC_OK;
                        return pushSetClipRect(&rect);
                       }

                    CLIMETHOD(popClipRect) (THIS)
                       {
                        if (clipStack.empty())
                           {
                            clearClipRect();
                            curClipRect = ::cli::drawing::makeRect(-1, -1, -1, -1);
                            return EC_OK;
                           }

                        STRUCT_CLI_DRAWING_CRECT rect = clipStack.top();
                        clipStack.pop();
                        if (rect.right==rect.left && rect.bottom==rect.top && rect.left==rect.bottom && rect.left==-1)
                           { // no saved rect
                            clearClipRect();
                            curClipRect = ::cli::drawing::makeRect(-1, -1, -1, -1);
                            return EC_OK;
                           }

                        //return EC_OK;
                        curClipRect = rect;
                        return setClipRect(&rect);
                       }

                    CLIMETHOD(setViewport) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                       {
                        if (!rect) return EC_INVALID_PARAM;
                        STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                        leftTop.x = rect->left;
                        leftTop.y = rect->top;
                        widthHeight.x = rect->right - rect->left;
                        widthHeight.y = rect->bottom - rect->top;

                        return setViewportWH( &leftTop, &widthHeight );
                       }

                    CLIMETHOD(setViewportWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                             )
                       {
                        if (!leftTop || !widthHeight) return EC_INVALID_PARAM;

                        STRUCT_CLI_DRAWING_CPOINT wh = *widthHeight;
                        if (wh.x<0) wh.x = -wh.x;
                        if (wh.y<0) wh.y = -wh.y;

                        STRUCT_CLI_DRAWING_CPOINT curMaxs;
                        curMaxs.x = offset.x + contextSize.x;
                        curMaxs.y = offset.y + contextSize.y;

                        STRUCT_CLI_DRAWING_CPOINT newOffset;
                        newOffset.x = offset.x + leftTop->x;
                        newOffset.y = offset.y + leftTop->y;

                        STRUCT_CLI_DRAWING_CPOINT newMaxs;
                        newMaxs.x = newOffset.x + wh.x;
                        newMaxs.y = newOffset.y + wh.y;

                        // Don't check that new size is out of prev size
                        //if (newMaxs.x > curMaxs.x) newMaxs.x = curMaxs.x;
                        //if (newMaxs.y > curMaxs.y) newMaxs.y = curMaxs.y;

                        //wh.x = newMaxs.x - newOffset.x;
                        //wh.y = newMaxs.y - newOffset.y;
                        contextSize.x = newMaxs.x - newOffset.x;
                        contextSize.y = newMaxs.y - newOffset.y;

                        offset = newOffset;

                        STRUCT_CLI_DRAWING_CPOINT zeroPoint;
                        zeroPoint.x = zeroPoint.y = 0;

                        STRUCT_CLI_DRAWING_CPOINT clipSize;
                        if (newMaxs.x > curMaxs.x) newMaxs.x = curMaxs.x;
                        if (newMaxs.y > curMaxs.y) newMaxs.y = curMaxs.y;
                        clipSize.x = newMaxs.x - newOffset.x;
                        clipSize.y = newMaxs.y - newOffset.y;

                        return setClipRectWH( &zeroPoint, &clipSize );
                       }



                    CLIMETHOD(pushSetViewport) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                       {
                        if (!rect) return EC_INVALID_PARAM;

                        STRUCT_CLI_DRAWING_CPOINT leftTop, widthHeight;
                        leftTop.x = rect->left;
                        leftTop.y = rect->top;
                        widthHeight.x = rect->right - rect->left;
                        widthHeight.y = rect->bottom - rect->top;

                        return pushSetViewportWH( &leftTop, &widthHeight );
                       }

                    CLIMETHOD(pushSetViewportWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 )
                       {
                        if (!leftTop || !widthHeight) return EC_INVALID_PARAM;

                        viewportStack.push( CViewPortParams(*this) );

                        STRUCT_CLI_DRAWING_CPOINT wh = *widthHeight;
                        if (wh.x<0) wh.x = -wh.x;
                        if (wh.y<0) wh.y = -wh.y;

                        STRUCT_CLI_DRAWING_CPOINT curMaxs;
                        curMaxs.x = offset.x + contextSize.x;
                        curMaxs.y = offset.y + contextSize.y;

                        STRUCT_CLI_DRAWING_CPOINT newOffset;
                        newOffset.x = offset.x + leftTop->x;
                        newOffset.y = offset.y + leftTop->y;

                        STRUCT_CLI_DRAWING_CPOINT newMaxs;
                        newMaxs.x = newOffset.x + wh.x;
                        newMaxs.y = newOffset.y + wh.y;

                        // Don't check that new size is out of prev size
                        //if (newMaxs.x > curMaxs.x) newMaxs.x = curMaxs.x;
                        //if (newMaxs.y > curMaxs.y) newMaxs.y = curMaxs.y;

                        //wh.x = newMaxs.x - newOffset.x;
                        //wh.y = newMaxs.y - newOffset.y;
                        contextSize.x = newMaxs.x - newOffset.x;
                        contextSize.y = newMaxs.y - newOffset.y;

                        offset = newOffset;

                        STRUCT_CLI_DRAWING_CPOINT zeroPoint;
                        zeroPoint.x = zeroPoint.y = 0;

                        STRUCT_CLI_DRAWING_CPOINT clipSize;
                        if (newMaxs.x > curMaxs.x) newMaxs.x = curMaxs.x;
                        if (newMaxs.y > curMaxs.y) newMaxs.y = curMaxs.y;
                        clipSize.x = newMaxs.x - newOffset.x;
                        clipSize.y = newMaxs.y - newOffset.y;

                        return pushSetClipRectWH( &zeroPoint, &clipSize );
                       }

                    CLIMETHOD(popViewport) (THIS)
                       {
                        RCODE res = popClipRect();
                        if (res) return res;

                        if (viewportStack.empty())
                           return EC_STACK_UNDERFLOW;

                        CViewPortParams params = viewportStack.top();
                        params.restoreDC(*this);
                        viewportStack.pop();
                        return EC_OK;
                       }

                    CLIMETHOD(createBitmap) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                 , INT    width /* [in] int  width  */
                                                 , INT    height /* [in] int  height  */
                                            )
                       {
                        ::cli::drawing::CPoint point = ::cli::drawing::impl::makePoint(width, height);
                        return createBitmapPoint( pbmp, &point );
                       }

                    CLIMETHOD(createCopyBitmap) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                     , INT    left /* [in] int  left  */
                                                     , INT    top /* [in] int  top  */
                                                     , INT    width /* [in] int  width  */
                                                     , INT    height /* [in] int  height  */
                                                )
                       {
                        ::cli::drawing::CPoint ltPoint = ::cli::drawing::impl::makePoint(left, top);
                        ::cli::drawing::CPoint whPoint = ::cli::drawing::impl::makePoint(width, height);
                        return createCopyBitmapPoint( pbmp, &ltPoint, &whPoint );
                       }

                    CLIMETHOD(drawBitmap) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP*    pbmp /* [in] ::cli::drawing::iDeviceBitmap*  pbmp  */
                                               , INT    left /* [in] int  left  */
                                               , INT    top /* [in] int  top  */
                                          )
                       {
                        ::cli::drawing::CPoint point = ::cli::drawing::impl::makePoint(left, top);
                        return drawBitmapPoint( pbmp, &point );
                       }
    
            }; // ::cli::drawing::impl::CDrawContext1ImplBase


        }; /* namespace impl */
    }; /* namespace drawing */
}; /* namespace cli */


#endif /* CLI_DRAWING_DC1IMPLBASE_H */

