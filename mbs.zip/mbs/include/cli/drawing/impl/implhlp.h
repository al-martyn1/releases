#ifndef CLI_DRAWING_IMPL_IMPLHLP_H
#define CLI_DRAWING_IMPL_IMPLHLP_H

#ifdef _WIN32
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif


namespace cli {
    namespace drawing {
        namespace impl {

            inline
            INT32 mulDiv(INT32 val, INT32 multiplier, INT32 divider)
               {
                #ifdef _DEBUG
                if (!divider) throw ::std::runtime_error("Division by zero");
                #endif
                return (INT32)(((INT64)val) * ((INT64)multiplier) / ((INT64)divider));
               }

            /*
            template <typename T1, typename T2>
            void swap(T1 &t1, T2 &t2)
               {
                T1 tmp = t1;
                t1 = t2;
                t2 = T1(tmp);
               }
            */
// ::cli::drawing::impl

            struct CPoint : public ::cli::drawing::CPoint
                {
                 CPoint(INT p = 0)      { x = y = p; }
                 CPoint(INT px, INT py) { x = px; y = py; }
                 CPoint(const ::cli::drawing::CPoint &p)  { x = p.x; y = p.y; }
                 operator const ::cli::drawing::CPoint&() const  { return *this; } // { CPoint p; p.x = x; p.y = y; return p; }
                 operator       ::cli::drawing::CPoint () const  { return *this; } // { CPoint p; p.x = x; p.y = y; return p; }
                }; // ::cli::drawing::impl::win::CPoint

            inline
            ::cli::drawing::CPoint makePoint(INT x, INT y)
               {
                ::cli::drawing::CPoint p; p.x = x; p.y = y;
                return p;
               }

        }; /* namespace impl */
    }; /* namespace drawing */
}; /* namespace cli */

#endif /* CLI_DRAWING_IMPL_IMPLHLP_H */

