#ifndef CLI_DRAWING_IMPL_DC1WIN_H
#define CLI_DRAWING_IMPL_DC1WIN_H

/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_IMPL_DC1WIN_H
    #include <cli/drawing/impl/dc1win.h>
#endif
*/

#ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
#endif

#if !defined(_WINDOWS_)
    #include <windows.h>
#endif

#ifndef CLI_DRAWING_DC1IMPLBASE_H
    #include <cli/drawing/impl/dc1implbase.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_DRAWING_IMPL_WIN32IMPLHLP_H
    #include <cli/drawing/impl/win32implhlp.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_DRAWING_IMPL_DBMWIN_H
    #include <cli/drawing/impl/dbmwin.h>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif


//#include <cli/formatx.h>

// NOTE: GradientFill,ScrollDC,ExtEscape,ExtFloodFill
// also see WTL PlayMetaFile
// FillSolidRect imlemented using ExtTextOut (see WTL atlgdi.h)
// ExtFloodFill?
// GrayString?
// FillRgn
// FrameRgn
// PtVisible
// RectVisible
// AlphaBlend
// DitherBlt
// FillSolidRect - ::ExtTextOut(m_hDC, 0, 0, ETO_OPAQUE, lpRect, NULL, 0, NULL);


namespace cli {
    namespace drawing {
        namespace impl {
            namespace win {

// ::cli::drawing::impl::win

                class CDrawContext1Impl : public ::cli::drawing::impl::CDrawContext1ImplBase
                {
                    public:
        
                        //typedef ::cli::drawing::CPoint         CPoint;
        
                    protected:
        
                        HDC     hdc;
                        //HWND    hwnd;

                        HPEN    hDefaultPen;
                        HBRUSH  hDefaultBrush;
                        HFONT   hDefaultFont;

                        COLORREF textColor;
                        COLORREF bkColor;
                        static const COLORREF uninitializedBkColor = 0xFF000000;


                        ::std::stack< HPEN   > penStack;
                        ::std::stack< HBRUSH > brushStack;
                        ::std::stack< HFONT >  fontStack;

                        HPEN createPen(COLORREF clr, INT width, ENUM_CLI_DRAWING_EPENSTYLE style) const
                           {
                            DWORD dwWidth    = width ? scalePenWidth(width) : 1;
                            return ::CreatePen( penStyleToImpl(style)
                                              , dwWidth
                                              , adjustColor(clr)
                                              );
                           }

                        HPEN createPenEx( COLORREF clr, INT width
                                         , ENUM_CLI_DRAWING_EPENSTYLE style
                                         , ENUM_CLI_DRAWING_EPENCAPSTYLE  capStyle
                                         , ENUM_CLI_DRAWING_EPENJOINSTYLE joinStyle
                                         ) const
                           {
                            DWORD dwPenStyle = width ? PS_GEOMETRIC : PS_COSMETIC;
                            DWORD dwWidth    = width ? scalePenWidth(width) : 1;
                            dwPenStyle |= penStyleToImpl(style);
                            dwPenStyle |= penCapStyleToImpl(capStyle);
                            dwPenStyle |= penJoinStyleToImpl(joinStyle);

                            LOGBRUSH lb;
                            lb.lbColor = adjustColor(clr);
                            lb.lbStyle = BS_SOLID;
                            lb.lbHatch = 0;

                            return ExtCreatePen( dwPenStyle, dwWidth, &lb, 0, 0 );
                           }

                        void deletePen(HPEN hpen) const
                           {
                            if (hpen!=hDefaultPen)
                               ::DeleteObject((HGDIOBJ)hpen);
                           }

                        HPEN selectPen(HPEN hpen)
                           {
                            return (HPEN)::SelectObject(hdc, (HGDIOBJ)hpen);
                           }

                        HPEN getStockPen(int objType) const
                           { // objType: BLACK_PEN, WHITE_PEN
                            return (HPEN)::GetStockObject( objType );
                           }

                        HBRUSH createSolidBrush(COLORREF clr) const
                           {
                            return ::CreateSolidBrush( adjustColor(clr) );
                           }

                        void deleteBrush(HBRUSH hbrush) const
                           {
                            if (hbrush!=hDefaultBrush)
                               ::DeleteObject((HGDIOBJ)hbrush);
                           }

                        HBRUSH selectBrush(HBRUSH hbrush)
                           {
                            return (HBRUSH)::SelectObject(hdc, (HGDIOBJ)hbrush);
                           }

                        HBRUSH getStockBrush(int objType) const
                           { // objType: HOLLOW_BRUSH (NULL_BRUSH), BLACK_BRUSH, DKGRAY_BRUSH, DC_BRUSH (Windows 2000/XP), GRAY_BRUSH, LTGRAY_BRUSH, WHITE_BRUSH 
                            return (HBRUSH)::GetStockObject( objType );
                           }

                        void deleteFont(HFONT hfont) const
                           {
                            if (hfont!=hDefaultFont)
                               ::DeleteObject((HGDIOBJ)hfont);
                           }

                        HFONT selectFont(HFONT hfont)
                           {
                            return (HFONT)::SelectObject(hdc, (HGDIOBJ)hfont);
                           }


                        // LONG toImplFontWeight(DWORD weight) const
                        // DWORD fromImplFontWeight(LONG weight) const
                        // DWORD toImplFamilyAndPitch(DWORD family, DWORD pitch)

                        HFONT implCreateFont(const STRUCT_CLI_DRAWING_FONT_PROPERTIES* props /* , int angle tenths of degree */) const
                           {
                            return win32implCreateFont(hdc, props);
                           }

                        int penStyleToImpl(ENUM_CLI_DRAWING_EPENSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenStyle;
                            switch(ps)
                               {
                                case null      : return PS_NULL         ;
                                case solid     : return PS_SOLID        ;
                                case dash      : return PS_DASH         ;
                                case dot       : return PS_DOT          ;
                                case dashdot   : return PS_DASHDOT      ;
                                case dashdotdot: return PS_DASHDOTDOT   ;
                                default        : return PS_SOLID        ;
                               }
                           }

                        int penCapStyleToImpl(ENUM_CLI_DRAWING_EPENCAPSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenCapStyle;
                            switch(ps)
                               {
                                case square    : return PS_ENDCAP_SQUARE ;
                                case round     : return PS_ENDCAP_ROUND  ;
                                case flat      : return PS_ENDCAP_FLAT   ;
                                default        : return PS_ENDCAP_ROUND  ;
                               }
                           }

                        int penJoinStyleToImpl(ENUM_CLI_DRAWING_EPENJOINSTYLE ps) const
                           {
                            using namespace cli::drawing::EPenJoinStyle;
                            switch(ps)
                               {
                                case bevel     : return PS_JOIN_BEVEL    ;
                                case miter     : return PS_JOIN_MITER    ;
                                case round     : return PS_JOIN_ROUND    ;
                                default        : return PS_JOIN_ROUND    ;
                               }
                           }
        
                    public:

                        CDrawContext1Impl() : ::cli::drawing::impl::CDrawContext1ImplBase(), hdc(0)//, hwnd(0) 
                                            , hDefaultPen(0), hDefaultBrush(0), hDefaultFont(0)
                                            , textColor(0)
                                            , bkColor(uninitializedBkColor)
                                            , penStack()
                                            , brushStack()
                                            , fontStack()
                                         {}

                        ~CDrawContext1Impl()
                           {
                            CLIASSERT(penStack.size()==0);
                            CLIASSERT(brushStack.size()==0);
                            CLIASSERT(fontStack.size()==0);
                           }

                        CLIMETHOD_(VOID, destroy) (THIS)
                           {
                           if (useRefCounting)
                           #include <cli/compspec/delthis.h>
                           }

                        void detachDC()
                           {
                            if (hDefaultPen) 
                               { 
                                HPEN hpen = selectPen(hDefaultPen); 
                                if (hpen!=hDefaultPen)
                                   ::DeleteObject((HGDIOBJ)hpen);
                                hDefaultPen = 0;
                               }

                            if (hDefaultBrush)
                               {
                                HBRUSH hbrush = selectBrush(hDefaultBrush); 
                                if (hbrush!=hDefaultBrush)
                                   ::DeleteObject((HGDIOBJ)hbrush);
                                hDefaultBrush = 0;
                               }
                            hdc = 0;
                           }

                    COLORREF adjustColor(COLORREF color) const
                       {
                        return ::cli::drawing::impl::CDrawContext1ImplBase::adjustColor( fastScaleColor(color) );
                       }


                    protected:

                    public:

                        // attachDC earlier was protected
                        void attachDC(HDC _hdc, const CPoint &_offset, const CPoint &_size)
                           {
                            /*
                            ::cli::format::cli_log::message( L"Offset: %1 x %2, Size: %3 x %4"
                                                           , ::cli::format::arg( _offset.x ) % _offset.y % _size.x % _size.y
                                                           );
                            */
                            hdc  = _hdc;
                            //hwnd = _hwnd;
                            setOffset(_offset);
                            setSize(_size);
                            setBkMode( ::cli::drawing::BkMode::transparent );
                            setDeviceRenderFlags( 0 );
                            //setupLikeDisplay();
                           }

                    public:

                        void attachClientDC(HDC _hdc, HWND _hwnd, const CPoint &_offset, const CPoint &_size)
                           { attachDC(_hdc, _offset, _size); }

                        void attachClientDC(HDC _hdc, HWND _hwnd, const CPoint &_offset)
                           {
                            RECT clientRect;
                            GetClientRect( _hwnd, &clientRect);
                            attachDC(_hdc, _offset, CPoint( clientRect.right-clientRect.left+1, clientRect.bottom-clientRect.top+1 ));
                           }

                        void attachClientDC(HDC _hdc, HWND _hwnd) { attachClientDC(_hdc, _hwnd, CPoint(0) ); }

                        void attachPrinterDC(HDC _hdc, const CPoint &_offset, const CPoint &_size)
                           { attachDC(_hdc, _offset, _size); }

                        void attachPrinterDC(HDC _hdc, const CPoint &_offset)
                           {
                            attachPrinterDC(_hdc, _offset, CPoint( GetDeviceCaps(_hdc, HORZRES), GetDeviceCaps(_hdc, VERTRES) ) );
                           }

                        void attachPrinterDC(HDC _hdc) { attachPrinterDC(_hdc, CPoint( 0, 0 ) ); }

                        /* interface ::cli::drawing::iDrawContext1 methods */
                        CLIMETHOD(getDpi) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    dpi /* [out,ref] ::cli::drawing::CPoint dpi  */)
                           {
                            if (!dpi) return 0;
                            dpi->x = GetDeviceCaps(hdc, LOGPIXELSX);
                            dpi->y = GetDeviceCaps(hdc, LOGPIXELSY);
                            if (!dpi->x) dpi->x = 96;
                            if (!dpi->y) dpi->y = 96;
                            return 0;
                           }

                        CLIMETHOD_(DWORD, getDeviceType) (THIS)
                           {
                            DWORD deviceTechnology = GetDeviceCaps(hdc, TECHNOLOGY);
                            using namespace ::cli::drawing::DeviceType;
                            switch(deviceTechnology)
                               {
                                case DT_PLOTTER   :  return plotter;
                                //case DT_RASDISPLAY:  return ;
                                case DT_RASPRINTER:  return rasterPrinter;
                                case DT_METAFILE  :  
                                case DT_DISPFILE  :  return metafile;
                                default:             return rasterDispay;
                               }
                           }

                        CLIMETHOD_(DWORD, setDeviceRenderFlags) (THIS_ DWORD    newFlags /* [in] ::cli::drawing::DeviceRenderFlag  newFlags  */)
                           {
                            return 0;
                           }

                        int getRealColorPlanes()
                           {
                            // TODO: return real num color planes here
                            int devType   = GetDeviceCaps( hdc, TECHNOLOGY);
                            int bitsPixel = GetDeviceCaps( hdc, BITSPIXEL);
                            if (devType==DT_RASPRINTER && bitsPixel==1 /* monochrome printer */)
                               {
                                return 1; // monochrome
                               }
                            return 3;
                           }

                        int getRealBitDepth()
                           { // TODO: return real bit depth here
                            int devType   = GetDeviceCaps( hdc, TECHNOLOGY);
                            int bitsPixel = GetDeviceCaps( hdc, BITSPIXEL);
                            if (devType==DT_RASPRINTER && bitsPixel==1 /* monochrome printer */)
                               {
                                return 8; // assume printer is full greyscale
                               }
                            return 8;
                           }


                        CLIMETHOD(setPixel) (THIS_ INT    x /* [in] int  x  */
                                                 , INT    y /* [in] int  y  */
                                                 , COLORREF    clr /* [in] colorref  clr  */
                                            )
                           {
                            coordToDcCoord(x, y);
                            ::SetPixel( hdc, x, y, adjustColor(clr) );
                            return 0;
                           }

                        CLIMETHOD(setPixelPoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,ref] ::cli::drawing::CPoint  p  */
                                                      , COLORREF    clr /* [in] colorref  clr  */
                                                 )
                           {
                            //STRUCT_CLI_DRAWING_CPOINT 
                            CPoint pTmp;
                            coordToDcCoord( pTmp, *p );
                            ::SetPixel( hdc, pTmp.x, pTmp.y, adjustColor(clr) );
                            return 0;
                           }

                        CLIMETHOD(setPixels) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in] ::cli::drawing::CPoint  p[]  */
                                                  , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                                  , COLORREF    clr /* [in] colorref  clr  */
                                             )
                           {
                            clr = adjustColor(clr);
                            for (SIZE_T i = 0; i!=numPoints; ++i, ++p)
                               {
                                CPoint pTmp;
                                coordToDcCoord( pTmp, *p );
                                ::SetPixel( hdc, pTmp.x, pTmp.y, clr );
                               }
                            return 0;
                           }

                        CLIMETHOD(setPen) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                               , INT    width /* [in] int  width  */
                                               , DWORD    style /* [in] ::cli::drawing::PenStyle  style  */
                                          )
                           {
                            HPEN hpen = createPen(clr, width, style);
                            HPEN hPrevPen = selectPen(hpen);
                            if (!hDefaultPen) hDefaultPen = hPrevPen;
                            else deletePen(hPrevPen);
                            return 0;
                           }

                        CLIMETHOD(pushSetPen) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                   , INT    width /* [in] int  width  */
                                                   , DWORD    style /* [in] ::cli::drawing::PenStyle  style  */
                                              )
                           {
                            HPEN hpen = createPen(clr, width, style);
                            HPEN hPrevPen = selectPen(hpen);
                            if (!hDefaultPen) hDefaultPen = hPrevPen;
                            penStack.push(hPrevPen); // �� 㤠�塞
                            return 0;
                           }

                        CLIMETHOD(setPenEx) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                 , INT    width /* [in] int  width  */
                                                 , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                                 , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                                 , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                            )
                           {
                            HPEN hpen = createPenEx(clr, width, style, capStyle, joinStyle);
                            HPEN hPrevPen = selectPen(hpen);
                            if (!hDefaultPen) hDefaultPen = hPrevPen;
                            else deletePen(hPrevPen);
                            return 0;
                           }

                        CLIMETHOD(pushSetPenEx) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                                     , INT    width /* [in] int  width  */
                                                     , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                                     , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                                     , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                                )
                           {
                            HPEN hpen = createPenEx(clr, width, style, capStyle, joinStyle);
                            HPEN hPrevPen = selectPen(hpen);
                            if (!hDefaultPen) hDefaultPen = hPrevPen;
                            penStack.push(hPrevPen); // �� 㤠�塞
                            return 0;
                           }

                        CLIMETHOD(popPen) (THIS)
                           {
                            if (penStack.empty()) return 0; // no pens for restoring
                            deletePen(selectPen(penStack.top()));
                            penStack.pop();
                            return 0;
                           }

                        CLIMETHOD(drawLine) (THIS_ INT    x1 /* [in] int  x1  */
                                                 , INT    y1 /* [in] int  y1  */
                                                 , INT    x2 /* [in] int  x2  */
                                                 , INT    y2 /* [in] int  y2  */
                                            )
                           {
                            coordToDcCoord(x1, y1);
                            coordToDcCoord(x2, y2);
                            ::MoveToEx( hdc, x1, y1, 0 );
                            ::LineTo( hdc, x2, y2 );
                            return 0;
                           }

                        CLIMETHOD(drawLinePoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    pointFrom /* [in,ref] ::cli::drawing::CPoint  pointFrom  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    pointTo /* [in,ref] ::cli::drawing::CPoint  pointTo  */
                                                 )
                           {
                            CPoint pTmp1, pTmp2;
                            coordToDcCoord( pTmp1, *pointFrom );
                            coordToDcCoord( pTmp2, *pointTo );
                            ::MoveToEx( hdc, pTmp1.x, pTmp1.y, 0 );
                            ::LineTo( hdc, pTmp2.x, pTmp2.y );
                            return 0;
                           }

                        CLIMETHOD(drawLines) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    points /* [in] ::cli::drawing::CPoint  points[]  */
                                                  , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                             )
                           {
                            if (!points || numPoints<2) return 0;
                            CPoint pTmp;
                            coordToDcCoord( pTmp, *points );
                            ::MoveToEx( hdc, pTmp.x, pTmp.y, 0 );
                            --numPoints; ++points;

                            for(; numPoints!=0; --numPoints, ++points)
                               {
                                coordToDcCoord( pTmp, *points );
                                ::LineTo( hdc, pTmp.x, pTmp.y );
                               }
                            return 0;
                           }

                        CLIMETHOD(drawLinesPairPoints) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    points /* [in] ::cli::drawing::CPoint  points[]  */
                                                      , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                                 )
                           {
                            if (!points || numPoints<2) return 0;
                            for(; numPoints>1; numPoints-=2, points+=2)
                               {
                                drawLinePoint(points, points+1);
                               }
                            return 0;
                           }

                        CLIMETHOD(setSolidBrush) (THIS_ COLORREF    clr /* [in] colorref  clr  */)
                           {
                            HBRUSH hPrevBrush = selectBrush( createSolidBrush(clr) );
                            if (!hDefaultBrush) hDefaultBrush = hPrevBrush;
                            else                deleteBrush(hPrevBrush);
                            return 0;
                           }

                        CLIMETHOD(setNullBrush) (THIS)
                           {
                            HBRUSH hPrevBrush = selectBrush( getStockBrush(NULL_BRUSH) );
                            if (!hDefaultBrush) hDefaultBrush = hPrevBrush;
                            else                deleteBrush(hPrevBrush);
                            return 0;
                           }

                        CLIMETHOD(pushSetSolidBrush) (THIS_ COLORREF    clr /* [in] colorref  clr  */)
                           {
                            HBRUSH hPrevBrush = selectBrush( createSolidBrush(clr) );
                            if (!hDefaultBrush) hDefaultBrush = hPrevBrush;
                            brushStack.push(hPrevBrush);
                            return 0;
                           }

                        CLIMETHOD(pushSetNullBrush) (THIS)
                           {
                            HBRUSH hPrevBrush = selectBrush( getStockBrush(NULL_BRUSH) );
                            if (!hDefaultBrush) hDefaultBrush = hPrevBrush;
                            brushStack.push(hPrevBrush);
                            return 0;
                           }

                        CLIMETHOD(popBrush) (THIS)
                           {
                            if (brushStack.empty()) return 0;
                            deleteBrush(selectBrush(brushStack.top()));
                            brushStack.pop();
                            return 0;
                           }

                        CLIMETHOD(fillRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            
                            STRUCT_CLI_DRAWING_CRECT tmpRect;
                            rectToDcCoord(tmpRect, *rect);
                            RECT r;
                            r.left   = tmpRect.left;
                            r.top    = tmpRect.top ;
                            r.right  = tmpRect.right;
                            r.bottom = tmpRect.bottom;

                            HBRUSH hTmpBrush = ::CreateSolidBrush( 0 );
                            HBRUSH hCurBrush = selectBrush(hTmpBrush);

                            FillRect( hdc, &r, hCurBrush );

                            selectBrush(hCurBrush);
                            ::DeleteObject((HGDIOBJ)hTmpBrush);

                            return 0;
                           }

                        CLIMETHOD(fillRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                              )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            using ::cli::drawing::makeRect;
                            STRUCT_CLI_DRAWING_CRECT rect = makeRect( *leftTop, *widthHeight);
                            return fillRect(&rect);
                           }

                        #ifdef UNDEFINED
                        CLIMETHOD(drawChord) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                             )
                           {
                            if (!rect || !firstRadialsEndpoint || !secondRadialsEndpoint) return 0;

                            STRUCT_CLI_DRAWING_CRECT tmpRect;
                            rectToDcCoord(tmpRect, *rect);

                            CPoint freTmp, sreTmp;
                            coordToDcCoord( freTmp, *firstRadialsEndpoint );
                            coordToDcCoord( sreTmp, *secondRadialsEndpoint );

                            ::Chord( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom
                                   , freTmp->x, freTmp->y, sreTmp->x, sreTmp->y
                                   );
                            return 0;
                           }

                        CLIMETHOD(drawChordWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                    , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                               )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            using ::cli::drawing::makeRect;
                            STRUCT_CLI_DRAWING_CRECT rect = makeRect( *leftTop, *widthHeight);
                            return drawChord(&rect, firstRadialsEndpoint, secondRadialsEndpoint);
                           }

                        CLIMETHOD(drawPie) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                           )
                           {
                            return 0;
                           }

                        CLIMETHOD(drawPieWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    firstRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  firstRadialsEndpoint  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    secondRadialsEndpoint /* [in,ref] ::cli::drawing::CPoint  secondRadialsEndpoint  */
                                             )
                           {
                            return 0;
                           }
                        #endif // UNDEFINED

                        CLIMETHOD(drawEllipse) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CRECT tmpRect;
                            rectToDcCoord(tmpRect, *rect);
                            ::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);
                            return 0;
                           }

                        CLIMETHOD(drawEllipseWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            using ::cli::drawing::makeRect;
                            STRUCT_CLI_DRAWING_CRECT rect = makeRect( *leftTop, *widthHeight);
                            drawEllipse( &rect );
                            return 0;
                           }

                        CLIMETHOD(drawRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CRECT tmpRect;
                            rectToDcCoord(tmpRect, *rect);
                            ::Rectangle( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);
                            return 0;
                           }

                        CLIMETHOD(drawRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                              )
                           {
                            if (!leftTop || !widthHeight) return 0;
                            using ::cli::drawing::makeRect;
                            STRUCT_CLI_DRAWING_CRECT rect = makeRect( *leftTop, *widthHeight);
                            drawRect( &rect );
                            return 0;
                           }

                        CLIMETHOD(drawRoundRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                                      , INT    radius /* [in] int  radius  */
                                                 )
                           {
                            if (!rect) return 0;
                            STRUCT_CLI_DRAWING_CRECT tmpRect;
                            rectToDcCoord(tmpRect, *rect);
                            INT radiusX = radius, radiusY = radius; sizeToDcSize(radiusX, radiusY);
                            ::RoundRect( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom, radiusX, radiusY);
                            return 0;
                           }

                        CLIMETHOD(drawRoundRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                        , INT    radius /* [in] int  radius  */
                                                   )

                           {
                            if (!leftTop || !widthHeight) return 0;
                            using ::cli::drawing::makeRect;
                            STRUCT_CLI_DRAWING_CRECT rect = makeRect( *leftTop, *widthHeight);
                            drawRoundRect( &rect, radius );
                            return 0;
                           }

                        // ::cli::drawing::BkMode
                        // transparent = 1
                        // opaque      = 2
                        // #define TRANSPARENT         1
                        // #define OPAQUE              2

                        CLIMETHOD_(DWORD, getBkMode) (THIS)
                           {
                            return GetBkMode( hdc );
                           }

                        CLIMETHOD_(DWORD, setBkMode) (THIS_ DWORD    mode /* [in] ::cli::drawing::BkMode  mode  */)
                           {
                            return SetBkMode( hdc, mode );
                           }

                        CLIMETHOD_(COLORREF, getBkColor) (THIS)
                           {
                            //COLORREF prevBkColor = 0;
                            if (bkColor==uninitializedBkColor)
                               bkColor = ::GetBkColor( hdc );
                            return bkColor;
                            //return ::GetBkColor( hdc );
                           }

                        CLIMETHOD_(COLORREF, setBkColor) (THIS_ COLORREF    color /* [in] colorref  color  */)
                           {
                            COLORREF prevColor = getBkColor();
                            ::SetBkColor( hdc, adjustColor(color) );
                            return prevColor;
                           }

                        CLIMETHOD(bkColorGet) (THIS_ COLORREF*    _bkColor /* [out] colorref bkColor  */)
                           {
                            if (!_bkColor) return EC_INVALID_PARAM;
                            *_bkColor = getBkColor();
                            return EC_OK;
                           }

                        CLIMETHOD(bkColorSet) (THIS_ COLORREF    _bkColor /* [in] colorref  bkColor  */)
                           {
                            setBkColor(bkColor); 
                            return EC_OK;
                           }

                        CLIMETHOD_(COLORREF, getTextColor) (THIS)
                           {
                            //if (!textColor) textColor = ::GetTextColor( hdc );;
                            //return ::GetTextColor( hdc );
                            return textColor;
                           }

                        CLIMETHOD_(COLORREF, setTextColor) (THIS_ COLORREF    color /* [in] colorref  color  */)
                           {
                            COLORREF prevColor = textColor;
                            textColor = color;
                            //return 
                            ::SetTextColor( hdc, adjustColor(color) );
                            return prevColor;
                           }

                        CLIMETHOD(textColorGet) (THIS_ COLORREF*    _textColor /* [out] colorref textColor  */)
                           {
                            if (!_textColor) return EC_INVALID_PARAM;
                            *_textColor = textColor;
                            return EC_OK;
                           }

                        CLIMETHOD(textColorSet) (THIS_ COLORREF    _textColor /* [in] colorref  textColor  */)
                           {
                            setTextColor(_textColor);
                            return EC_OK;
                           }

                        CLIMETHOD(textOut) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                , const CLISTR*     text
                                           )
                           {
                            if (!leftTopPos || !text) return 0;
                            CPoint ltpos;
                            coordToDcCoord( ltpos, *leftTopPos );
                            RECT r;
                            r.left   = ltpos.x;
                            r.top    = ltpos.y;
                            r.right  = ltpos.x + 10;
                            r.bottom = ltpos.y + 10;

                            ::DrawTextW( hdc, text->pData, (int)text->stringSize, &r
                                       , DT_LEFT|DT_TOP|DT_NOPREFIX|DT_NOCLIP|DT_SINGLELINE
                                       );
                            return 0;
                           }

                        CLIMETHOD(setFontIndirect) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    props /* [in,ref] ::cli::drawing::font::Properties  props  */)
                           {
                            if (!props) return EC_INVALID_PARAM;

                            //if (fontPropsStack.empty())
                            //STRUCT_CLI_DRAWING_FONT_PROPERTIES 
                            //props = { height, weight, flags, precision, pitch, family, 0 };
                            //::std::stack< STRUCT_CLI_DRAWING_FONT_PROPERTIES > fontPropsStack;

                            HFONT hNewFont = implCreateFont(props);
                            if (!hNewFont) return EC_UNKNOWN;

                            HFONT hPrevFont = selectFont( hNewFont );
                            if (!hDefaultFont) hDefaultFont = hPrevFont;
                            else               deleteFont(hPrevFont);
                            return 0;
                           }

                        CLIMETHOD(pushSetFontIndirect) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    props /* [in,ref] ::cli::drawing::font::Properties  props  */)
                           {
                            if (!props) return EC_INVALID_PARAM;

                            HFONT hNewFont = implCreateFont(props);
                            if (!hNewFont) return EC_UNKNOWN;

                            HFONT hPrevFont = selectFont( hNewFont );
                            if (!hDefaultFont) hDefaultFont = hPrevFont;
                            fontStack.push(hPrevFont);

                            return 0;
                           }

                        CLIMETHOD(popFont) (THIS)
                           {
                            if (fontStack.empty()) return 0;
                            deleteFont(selectFont(fontStack.top()));
                            fontStack.pop();
                            return 0;
                           }

                        CLIMETHOD(calcTextExtent) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [out,ref] ::cli::drawing::CPoint widthHeight  */
                                                       , const CLISTR*     text
                                                  )
                           {
                            if (!widthHeight) return EC_OK; // do nothing
                            if (!text) return EC_INVALID_PARAM;

                            RECT rect; rect.left = 0; rect.top = 0; rect.right = 0; rect.bottom = 0;

                            int textHeightInLogUnits = 
                            DrawTextW( hdc, text->pData, (int)text->stringSize, &rect
                                     , DT_LEFT|DT_TOP|DT_NOPREFIX|DT_SINGLELINE|DT_NOCLIP|DT_CALCRECT
                                     );
                            DWORD dwErr = 0;
                            if (!textHeightInLogUnits) 
                               {
                                dwErr = GetLastError();
                               }

                            using ::cli::drawing::makePoint;
                            CPoint resSize;

                            sizeFromDcSize( resSize, makePoint( rect.right-rect.left, rect.bottom-rect.top ) );
                            widthHeight->x = resSize.x;
                            widthHeight->y = resSize.y;

                            return EC_OK;
                           }

                        CLIMETHOD(rotatedTextOut) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                       , INT    rotan /* [in] int  rotan  */
                                                       , const CLISTR*     text
                                                  )
                           {
                            if (!text || !leftTopPos) return EC_INVALID_PARAM;
                            CPoint ltpos;
                            coordToDcCoord( ltpos, *leftTopPos );
                            return win32RotatedTextOut ( hdc, ltpos, rotan, text->pData, text->stringSize );
                           }

                        CLIMETHOD(drawGradientCircle) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                                           , INT    radius /* [in] int  radius  */
                                                           , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                                           , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                                           , DWORD    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                                      )
                           {
                            if (!centerPos || !radius) return EC_OK;

                            using namespace ::cli::drawing;

                            ::std::vector< COLORREF > gradient;
                            cli::drawing::colorUtils::makeGradientColorsVector( colorCenter
                                                                              , colorRadius
                                                                              , radius+1
                                                                              , gradient
                                                                              );
                            // create brush that fills center
                            HBRUSH hOrgBrush = selectBrush( createSolidBrush( gradient[0] ) );
                            if (radius<=1)
                               { // GradientFlags::drawDefault, GradientFlags::noCurrentPenBorder
                                HPEN hPrevPen = 0;
                                if (flags&GradientFlags::noCurrentPenBorder)
                                   {
                                    hPrevPen = selectPen( createPen(gradient[1], scalePenWidth(1), EPenStyle::solid) );
                                   }
                                STRUCT_CLI_DRAWING_CRECT rect = makeRect( centerPos->x - radius
                                                                        , centerPos->y - radius
                                                                        , centerPos->x + radius
                                                                        , centerPos->y + radius
                                                                        );
                                STRUCT_CLI_DRAWING_CRECT tmpRect;
                                rectToDcCoord(tmpRect, rect);
                                ::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);
                                if (flags&GradientFlags::noCurrentPenBorder)
                                   {
                                    deletePen(selectPen(hPrevPen));
                                   }
                                deleteBrush(selectBrush(hOrgBrush));
                                return EC_OK;
                               }

                            int scaledPenWidth = scalePenWidth(2);
                            if (scaledPenWidth<2) scaledPenWidth = 2;

                            COLORREF prevColor = gradient[1];
                            HPEN hOrgPen = selectPen( ::CreatePen(PS_SOLID, scaledPenWidth, adjustColor(prevColor)) );
                            STRUCT_CLI_DRAWING_CRECT rect = makeRect( centerPos->x - 1
                                                                    , centerPos->y - 1
                                                                    , centerPos->x + 1
                                                                    , centerPos->y + 1
                                                                    );
                            STRUCT_CLI_DRAWING_CRECT tmpRect;
                            rectToDcCoord(tmpRect, rect);
                            ::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);

                            deleteBrush(selectBrush(getStockBrush(NULL_BRUSH)));

                            int curRadius = 2;
                            for(; curRadius<radius; ++curRadius)
                               {
                                // set pen to next gradient color, if it is different with current
                                if (prevColor!=gradient[curRadius])
                                   {
                                    prevColor = gradient[curRadius];
                                    deletePen( selectPen( ::CreatePen(PS_SOLID, scaledPenWidth, adjustColor(prevColor)) ) );
                                   }
                                rect = makeRect( centerPos->x - curRadius
                                               , centerPos->y - curRadius
                                               , centerPos->x + curRadius
                                               , centerPos->y + curRadius
                                               );
                                rectToDcCoord(tmpRect, rect);
                                ::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);
                               }

                            if (flags&GradientFlags::noCurrentPenBorder)
                               {
                                deletePen( selectPen( createPen(gradient[curRadius], scalePenWidth(1), EPenStyle::solid) ) );
                               }
                            else
                               {
                                deletePen( selectPen( hOrgPen ) );
                               }
                            rect = makeRect( centerPos->x - curRadius
                                           , centerPos->y - curRadius
                                           , centerPos->x + curRadius
                                           , centerPos->y + curRadius
                                           );
                            rectToDcCoord(tmpRect, rect);
                            ::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);

                            if (flags&GradientFlags::noCurrentPenBorder)
                               deletePen( selectPen( hOrgPen ) );

                            deleteBrush(selectBrush( hOrgBrush ));

                            return EC_OK;
                           }

                        CLIMETHOD(drawEllipticArc) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    rightBottom /* [in,ref] ::cli::drawing::CPoint  rightBottom  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    arcStart /* [in,ref] ::cli::drawing::CPoint  arcStart  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    arcEnd /* [in,ref] ::cli::drawing::CPoint  arcEnd  */
                                                        , BOOL    direction /* [in] bool  direction  */
                                                   )
                           {
                            if (!leftTop || !rightBottom || !arcStart || !arcEnd) return EC_INVALID_PARAM;
                            CPoint ltPos, rbPos, asPos, aePos;

                            coordToDcCoord( ltPos, *leftTop     );
                            coordToDcCoord( rbPos, *rightBottom );
                            coordToDcCoord( asPos, *arcStart    );
                            coordToDcCoord( aePos, *arcEnd      );

                            // direction : 0 - clockwise, 1 counterclockwise
                            SetArcDirection( hdc, direction>0 ? AD_COUNTERCLOCKWISE : AD_CLOCKWISE );
                            Arc( hdc, ltPos.x, ltPos.y, rbPos.x, rbPos.y
                               , asPos.x, asPos.y, aePos.x, aePos.y
                               );
                            return EC_OK;
                           }


                        CLIMETHOD(drawGradientCircleEx) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                                             , INT    radius /* [in] int  radius  */
                                                             , INT    smallRadius /* [in] int  smallRadius  */
                                                             , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                                             , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                                             , DWORD    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                                        )
                           {
                            if (!centerPos) return EC_OK;

                            using namespace ::cli::drawing;
                            if (radius<smallRadius) ::std::swap(radius, smallRadius);

                            ::std::vector< COLORREF > gradient;
                            cli::drawing::colorUtils::makeGradientColorsVector( colorCenter
                                                                              , colorRadius
                                                                              , radius - smallRadius + 1
                                                                              , gradient
                                                                              );
                            HBRUSH hOrgBrush = selectBrush(getStockBrush(NULL_BRUSH));

                            int scaledPenWidth = scalePenWidth(2);
                            if (scaledPenWidth<2) scaledPenWidth = 2;

                            COLORREF prevColor = gradient[0];
                            HPEN hOrgPen = selectPen( ::CreatePen(PS_SOLID, scaledPenWidth, adjustColor(prevColor)) );

                            STRUCT_CLI_DRAWING_CRECT rect;
                            STRUCT_CLI_DRAWING_CRECT tmpRect;
                            //rectToDcCoord(tmpRect, rect);
                            //::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);

                            int curRadius = smallRadius;
                            for(; curRadius<radius; ++curRadius)
                               {
                                // set pen to next gradient color, if it is different with current
                                if (prevColor!=gradient[curRadius-smallRadius])
                                   {
                                    prevColor = gradient[curRadius-smallRadius];
                                    deletePen( selectPen( ::CreatePen(PS_SOLID, scaledPenWidth, adjustColor(prevColor)) ) );
                                   }
                                rect = makeRect( centerPos->x - curRadius
                                               , centerPos->y - curRadius
                                               , centerPos->x + curRadius
                                               , centerPos->y + curRadius
                                               );
                                rectToDcCoord(tmpRect, rect);
                                ::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);
                               }

                            if (flags&GradientFlags::noCurrentPenBorder)
                               {
                                deletePen( selectPen( createPen(gradient[curRadius-smallRadius], scalePenWidth(1), EPenStyle::solid) ) );
                               }
                            else
                               {
                                deletePen( selectPen( hOrgPen ) );
                               }
                            rect = makeRect( centerPos->x - curRadius
                                           , centerPos->y - curRadius
                                           , centerPos->x + curRadius
                                           , centerPos->y + curRadius
                                           );
                            rectToDcCoord(tmpRect, rect);
                            ::Ellipse( hdc, tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom);

                            if (flags&GradientFlags::noCurrentPenBorder)
                               deletePen( selectPen( hOrgPen ) );

                            deleteBrush(selectBrush( hOrgBrush ));
                           
                            return EC_OK;
                           }


                        CLIMETHOD(setClipRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */)
                           {
                            if (!rect) return 0;

                            STRUCT_CLI_DRAWING_CRECT tmpRect;
                            rectToDcCoord(tmpRect, *rect);
                            /*
                            if (tmpRect.right  < tmpRect.left) ::std::swap(tmpRect.right , tmpRect.left);
                            if (tmpRect.bottom < tmpRect.top)  ::std::swap(tmpRect.bottom , tmpRect.top);
                            */
                            if (tmpRect.right  < tmpRect.left) tmpRect.right  = tmpRect.left;
                            if (tmpRect.bottom < tmpRect.top)  tmpRect.bottom = tmpRect.top;

                            /*
                            ::cli::format::cli_log::message( L"left: %1, top: %2, right: %3, bottom: %4, width: %5, height: %6"
                                                           , ::cli::format::arg(tmpRect.left) % tmpRect.top % tmpRect.right 
                                                             % tmpRect.bottom % (tmpRect.right - tmpRect.left) % (tmpRect.bottom - tmpRect.top) );
                            */

                            
                            HRGN hrgn = CreateRectRgn( tmpRect.left, tmpRect.top, tmpRect.right, tmpRect.bottom );

                            ::SelectClipRgn( hdc, (HRGN)0 );
                            ::SelectClipRgn( hdc, hrgn );
                            ::DeleteObject( (HGDIOBJ)hrgn );
                            
                            //::SelectObject( hdc, (HGDIOBJ)hrgn );
                            return EC_OK;
                           }

                        CLIMETHOD(setClipRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 )
                           {
                            if (!leftTop || !widthHeight) return EC_INVALID_PARAM;
                            using ::cli::drawing::makeRect;
                            STRUCT_CLI_DRAWING_CRECT rect = makeRect( *leftTop, *widthHeight);
                            return setClipRect(&rect);
                           }

                        CLIMETHOD(clearClipRect) (THIS)
                           {
                            ::SelectClipRgn( hdc, (HRGN)0 );
                            return EC_OK;
                           }

                        CLIMETHOD(createBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                          , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                     )
                           {
                            if (!pbmp || !widthHeight) return EC_INVALID_PARAM;

                            CPoint wh;
                            sizeToDcSize(wh, *widthHeight);

                            ::cli::drawing::impl::win::CDeviceBitmap *bmp = 
                                   new ::cli::drawing::impl::win::CDeviceBitmap( hdc, wh.x, wh.y );
                            *pbmp = static_cast<INTERFACE_CLI_DRAWING_IDEVICEBITMAP*>(bmp);
                            return EC_OK;
                           }

                        CLIMETHOD(createCopyBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                              , const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                              , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                         )
                           {
                            if (!pbmp || !leftTop || !widthHeight) return EC_INVALID_PARAM;

                            CPoint wh;
                            sizeToDcSize(wh, *widthHeight);

                            CPoint lt;
                            coordToDcCoord( lt, *leftTop );

                            ::cli::drawing::impl::win::CDeviceBitmap *bmp = 
                                   new ::cli::drawing::impl::win::CDeviceBitmap( hdc, wh.x, wh.y, lt.x, lt.y );
                            *pbmp = static_cast<INTERFACE_CLI_DRAWING_IDEVICEBITMAP*>(bmp);
                            return EC_OK;
                           }


                        CLIMETHOD(drawBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP*    pbmp /* [in] ::cli::drawing::iDeviceBitmap*  pbmp  */
                                                        , const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                   )
                           {
                            if (!pbmp || !leftTop) return EC_INVALID_PARAM;

                            INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP *pImplBmp = 0;
                            RCODE res = pbmp->queryInterface( ::cli::iidOf(pImplBmp), (VOID**)&pImplBmp );
                            if (res || !pImplBmp) return EC_INCOMPATIBLE_OBJECT;

                            CLI_DRAWING_GENERIC_HANDLE ghBmp;
                            res = pImplBmp->getHandle(&ghBmp);
                            if (res) return res;

                            STRUCT_CLI_DRAWING_CPOINT widthHeight;
                            res = pImplBmp->sizeGet(&widthHeight);
                            if (res) return res;

                            //CPoint wh;
                            //sizeToDcSize(wh, widthHeight);

                            CPoint lt;
                            coordToDcCoord( lt, *leftTop );

                            HDC hMemDc = ::CreateCompatibleDC(hdc);
                            //HBITMAP hOldBitmap = ::SelectBitmap(hMemDc, (HBITMAP)ghBmp);
                            HBITMAP hOldBitmap = (HBITMAP)::SelectObject(hMemDc, (HGDIOBJ)ghBmp);

                            ::BitBlt( hdc, lt.x, lt.y, widthHeight.x, widthHeight.y, hMemDc, 0, 0, SRCCOPY );
                            //::BitBlt( hdc, lt.x, lt.y, wh.x, wh.y, hMemDc, 0, 0, SRCCOPY );
                            //::SelectBitmap(hMemDc, hOldBitmap);                            
                            ::SelectObject(hMemDc, (HGDIOBJ)hOldBitmap);
                    
                            ::DeleteDC(hMemDc);

                            return EC_OK;
                           }



                        #ifdef CLI_DRAWING_IDC1_SUPPORT_GETPIXEL
                        CLIMETHOD_(COLORREF, getPixel) (THIS_ INT    x /* [in] int  x  */
                                                            , INT    y /* [in] int  y  */
                                                       )
                           {
                            coordToDcCoord(x, y);
                            return ::GetPixel( hdc, x, y );
                           }

                        CLIMETHOD_(COLORREF, getPixelPoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,ref] ::cli::drawing::CPoint  p  */)
                           {
                            //STRUCT_CLI_DRAWING_CPOINT 
                            CPoint pTmp;
                            coordToDcCoord( pTmp, *p );
                            return ::GetPixel( hdc, pTmp.x, pTmp.y );
                           }
                        #endif


        
                }; // ::cli::drawing::impl::win::CDrawContext1Impl


            }; /* namespace win */
        }; /* namespace impl */
    }; /* namespace drawing */
}; /* namespace cli */


#endif /* CLI_DRAWING_IMPL_DC1WIN_H */

