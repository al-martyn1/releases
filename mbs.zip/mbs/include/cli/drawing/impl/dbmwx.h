#ifndef CLI_DRAWING_IMPL_DBMWX_H
#define CLI_DRAWING_IMPL_DBMWX_H

#ifndef CLI_DRAWING_IMPL_IMPLHLP_H
    #include <cli/drawing/impl/implhlp.h>
#endif


#include <wx/dcmemory.h>

namespace cli {
namespace drawing {
namespace impl {
namespace wx {

class CDeviceBitmap : public ::cli::CComponentImplBase< ::cli::CRefCounter, ::cli::CDummyModule > // DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_DRAWING_IDEVICEBITMAP
                    , public INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP
{
        wxBitmap                  wBitmap;

    public:

        typedef ::cli::CComponentImplBase< ::cli::CRefCounter, ::cli::CDummyModule > base_impl;

        // create compatible with dc
        CDeviceBitmap( wxDC *wdc, int width, int height )
           : wBitmap( (width<0?-width:width), (height<0?-height:height))
           {
           }

        // create compatible with dc and copies data from dc
        CDeviceBitmap( wxDC *wdc, int width, int height, int left, int top )
           : wBitmap( (width<0?-width:width), (height<0?-height:height))
           {
            wxMemoryDC memDc;
            memDc.SelectObject(wBitmap);
            memDc.Blit( 0, 0, (width<0?-width:width), (height<0?-height:height), wdc, left, top, wxCOPY );
            memDc.SelectObject(wxNullBitmap);
           }
    
        ~CDeviceBitmap()
           {
           }
    
        CLI_BEGIN_INTERFACE_MAP2(CDeviceBitmap, INTERFACE_CLI_DRAWING_IDEVICEBITMAP)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_DRAWING_IDEVICEBITMAP )
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP )
        CLI_END_INTERFACE_MAP(CDeviceBitmap)
    
        CLIMETHOD_(ULONG, addRef) (THIS)  { return addRefImpl(); }
        CLIMETHOD_(ULONG, release) (THIS) { return releaseImpl();}
    
        CLIMETHOD_(VOID, destroy) (THIS)
           {
           #include <cli/compspec/delthis.h>
           }

        CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint size  */)
           {
            if (_size) *_size = ::cli::drawing::impl::makePoint( wBitmap.GetWidth(), wBitmap.GetHeight() );
            return EC_OK;
           }

        CLIMETHOD(getHandle) (THIS_ CLI_DRAWING_GENERIC_HANDLE*    dbmHandle /* [out] cli_drawing_generic_handle dbmHandle  */)
           {
            if (dbmHandle) *dbmHandle = (CLI_DRAWING_GENERIC_HANDLE)&wBitmap;
            return EC_OK;
           }

}; // class CDeviceBitmap


}; // namespace wx
}; // namespace impl
}; // namespace drawing
}; // namespace cli





#endif /* CLI_DRAWING_IMPL_DBMWX_H */

