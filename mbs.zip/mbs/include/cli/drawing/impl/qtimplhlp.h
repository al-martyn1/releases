#ifndef CLI_DRAWING_IMPL_QTIMPLHLP_H
#define CLI_DRAWING_IMPL_QTIMPLHLP_H

namespace cli {
    namespace drawing {
        namespace impl {
            namespace qt {

                inline
                QString toQtString(const WCHAR *str, SIZE_T size)
                   {
                    SIZE_T pos = 0;
                    QString qstr; qstr.reserve(size);
                    for(; pos!=size; ++pos, str++)
                       {
                        qstr.append(QChar(*str));
                       }
                    return qstr;
                   }

                inline
                QString toQtString(const ::std::wstring &str)
                   {
                    return toQtString(str.data(), str.size());
                   }

                inline
                QString toQtString(const CHAR *str, SIZE_T size)
                   {
                    SIZE_T pos = 0;
                    QString qstr; qstr.reserve(size);
                    for(; pos!=size; ++pos, str++)
                       {
                        qstr.append(QChar(*str));
                       }
                    return qstr;
                   }

                inline
                QString toQtString(const ::std::string &str)
                   {
                    return toQtString(str.data(), str.size());
                   }

            }; /* namespace qt */
        }; /* namespace impl */
    }; /* namespace drawing */
}; /* namespace cli */



#endif /* CLI_DRAWING_IMPL_QTIMPLHLP_H */

