#ifndef CLI_DRAWING_IMPL_WXIMPLHLP_H
#define CLI_DRAWING_IMPL_WXIMPLHLP_H

/*
#ifndef CLI_DRAWING_IMPL_WXIMPLHLP_H
    #include<cli/drawing/impl/wximplhlp.h>
#endif
*/

namespace cli {
    namespace drawing {
        namespace impl {
            namespace wx {


                inline
                COLORREF fromWxColor(const wxColour &wxclr)
                   {
                    return RGB( wxclr.Red(), wxclr.Green(), wxclr.Blue() ); // Alpha()
                   }

                inline
                wxColour toWxColor( COLORREF clr)
                   {
                    wxColour wxclr; wxclr.Set(clr); return wxclr;
                   }


                //const wxWCharBuffer cMB2WC(const char *in) const
               // const char* ascii_str = "Some text";
               // wxString str(ascii_str, wxConvUTF8);

                inline
                wxString toWxString(const WCHAR *str)
                   {
                    // ����� � ANSI/UNICODE
                    #ifndef wxUSE_UNICODE
                        #ifdef _WIN32
                            wxMBConvUTF16 conv;
                        #else
                            wxMBConv      conv;
                        #endif
                        return wxString( conv.cWC2MB( str ) );
                    #else
                        return wxString( str );
                    #endif
                   }

                inline
                wxString toWxString(const WCHAR *str, SIZE_T size)
                   {
                    // ����� � ANSI/UNICODE
                    #ifndef wxUSE_UNICODE
                        #ifdef _WIN32
                            wxMBConvUTF16 conv;
                        #else
                            wxMBConv      conv;
                        #endif
                        return wxString( conv.cWC2MB( str, size, 0 ) );
                    #else
                        // it's don't work
                        // return wxString( str, size );
                        // it works, we ignore taken len of string and assume that the string is zero-terminated
                        return wxString( str );
                    #endif
                   }

                inline
                wxString toWxString(const ::std::wstring &str)
                   {
                    return toWxString(str.data(), str.size());
                   }

                inline
                wxString toWxString(const CHAR *str)
                   {
                    // ����� � ANSI/UNICODE
                    #ifdef wxUSE_UNICODE
                        #ifdef _WIN32
                            wxMBConvUTF16 conv;
                        #else
                            //wxMBConv      conv; // not work
                            wxMBConvUTF8      conv;                            
                        #endif
                        return wxString( conv.cMB2WC( str ) );
                    #else
                        return wxString( str );
                    #endif
                   }

                inline
                wxString toWxString(const CHAR *str, SIZE_T size)
                   {
                    // ����� � ANSI/UNICODE
                    #ifdef wxUSE_UNICODE
                        #ifdef _WIN32
                            wxMBConvUTF16 conv;
                        #else
                            //wxMBConv      conv; // not work
                            wxMBConvUTF8      conv;
                        #endif
                        return wxString( conv.cMB2WC( str, size, 0 ) );
                    #else
                        // see above
                        //return wxString( str, size );
                        return wxString( str );
                    #endif
                   }

                inline
                wxString toWxString(const ::std::string &str)
                   {
                    return toWxString(str.data(), str.size());
                   }


            }; /* namespace wx */
        }; /* namespace impl */
    }; /* namespace drawing */
}; /* namespace cli */




#endif /* CLI_DRAWING_IMPL_WXIMPLHLP_H */

