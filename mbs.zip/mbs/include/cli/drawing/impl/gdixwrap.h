// http://www.rsdn.ru/article/gdi/gdiplus1.xml
// http://www.rsdn.ru/article/gdi/gdiplus2.xml
// http://www.rsdn.ru/article/gdi/gdiplus3.xml
