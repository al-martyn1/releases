#ifndef CLI_DRAWING_IMPL_WIN32IMPLHLP_H
#define CLI_DRAWING_IMPL_WIN32IMPLHLP_H

#if !defined(_WINDOWS_)
    #include <windows.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

#ifndef CLI_DRAWING_IMPL_IMPLHLP_H
    #include <cli/drawing/impl/implhlp.h>
#endif

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif


// MSVC math.h need _USE_MATH_DEFINES to be defined before
#define _USE_MATH_DEFINES

#if !defined(_INC_MATH) && !defined(_MATH_H_) && !defined(_MATH_H)
    #include <math.h>
#endif

#ifndef M_PI
    #define M_PI       3.14159265358979323846
#endif

#ifndef MARTY_WINAPI_H
    #include <marty/winapi.h>
#endif


namespace cli {
    namespace drawing {
        namespace impl {

            using MARTY_WINAPI_NS getVersionInfo;
            using MARTY_WINAPI_NS getWinVer;
            using MARTY_WINAPI_NS isWinNt;

            inline
            LONG win32ToImplFontWeight(DWORD weight)
               {
                using namespace ::cli::drawing::font::Weight;
                switch(weight)
                   {
                    case extraLight: return FW_EXTRALIGHT; // 200
                    case light     : return FW_LIGHT;      // 300
                    case normal    : return FW_NORMAL;     // 400
                    //case demibol   : 
                    case semibold  : return FW_SEMIBOLD;   // 600
                    case bold      : return FW_BOLD;       // 700
                    case extraBold : return FW_EXTRABOLD;  // 800
                    case black     : return FW_HEAVY;      // 900
                    default:         return FW_DONTCARE;   // 0
                   }                            
               }

            inline
            DWORD win32FromImplFontWeight(LONG weight)
               {
                using namespace ::cli::drawing::font::Weight;
                if (weight <= FW_EXTRALIGHT)        return extraLight;
                else if (weight <= FW_LIGHT)        return light;
                else if (weight <= FW_NORMAL)       return normal;
                else if (weight <= FW_SEMIBOLD)     return semibold;
                else if (weight <= FW_BOLD)         return bold;
                else if (weight <= FW_EXTRABOLD)    return extraBold;
                else                /* FW_HEAVY */  return black;
               }

            inline
            ::std::wstring win32StrToWide(const std::string &str, int codePage = CP_ACP)
               {
                DWORD flags = MB_PRECOMPOSED;
                switch(codePage)
                   {
                    case 50220: case 50221: case 50222: case 50225: case 50227: case 50229: case 52936: case 54936:
                    case 57002: case 57003: case 57004: case 57005: case 57006: case 57007: case 57008: case 57009:
                    case 57010: case 57011: case 65000: case 65001: case 42   :
                        flags = 0; break;
                   };
            
                int res = ::MultiByteToWideChar( codePage,
                                                 flags,
                                                 str.c_str(),
                                                 //str.size(),
                                                 -1,
                                                 0, 0);
                wchar_t *pRes = (wchar_t*)_alloca((size_t)(res+1)*sizeof(wchar_t));
                if (::MultiByteToWideChar( codePage,
                                     flags,
                                     str.c_str(),
                                     //str.size(),
                                     -1,
                                     pRes, res))
                   {
                    pRes[res] = 0;
                    return std::wstring(pRes); 
                   }
                return std::wstring();
                //pRes[res] = 0;
               }

            inline
            ::std::string win32StrToAnsi(const ::std::wstring &str, int codePage = CP_ACP)
               {
                int res = ::WideCharToMultiByte( codePage,
                                                 WC_COMPOSITECHECK,
                                                 str.c_str(),
                                                 //str.size(),
                                                 -1,
                                                 0, 0,
                                                 0, 0
                                                 );
                char *pRes = (char*)_alloca((size_t)(res+1)*sizeof(char));
                if (::WideCharToMultiByte( codePage,
                                       WC_COMPOSITECHECK,
                                       str.c_str(),
                                       //str.size(),
                                       -1,
                                       pRes, res,
                                       0, 0
                                       ))
                   {
                    pRes[res] = 0;
                    return ::std::string(pRes); 
                   }
                //pRes[res] = 0;
                return ::std::string();
               }


            inline
            DWORD win32ToImplFamilyAndPitch(DWORD family, DWORD pitch)
               {
                //using namespace ::cli::drawing::font::Family;
                return (family&0xF0) | (pitch&0x3);
               }

            template <typename TLOGFONTINFO>
            void win32implFillGenericLogFont(HDC hdc, const STRUCT_CLI_DRAWING_FONT_PROPERTIES* props, TLOGFONTINFO &logfont)
               {
                using namespace ::cli::drawing::font;
                // UNDONE: MulDiv below is good only for MM_TEXT mapping mode
                logfont.lfHeight       = - ::MulDiv(props->height, ::GetDeviceCaps(hdc, LOGPIXELSY), 72);
                logfont.lfWidth        = 0; //
                logfont.lfEscapement   = 0;
                logfont.lfOrientation  = 0;
                logfont.lfWeight       = win32ToImplFontWeight(props->weight);

                logfont.lfStrikeOut = FALSE;
                if (props->flags & Flags::italic)
                   logfont.lfItalic = TRUE;
                else
                   logfont.lfItalic = FALSE;

                if (props->flags & Flags::underlined)
                   logfont.lfUnderline = TRUE;
                else
                   logfont.lfUnderline = FALSE;

                logfont.lfCharSet = DEFAULT_CHARSET;

                logfont.lfOutPrecision  = OUT_DEFAULT_PRECIS;  // 0
                logfont.lfClipPrecision = CLIP_DEFAULT_PRECIS; // 0
                logfont.lfQuality       = DEFAULT_QUALITY;     // 0

                /*
                #if (_WIN32_WINNT >= 0x0500)
                #define CLEARTYPE_QUALITY       5
                #endif
                
                #if (_WIN32_WINNT >= 0x0501)
                #define CLEARTYPE_NATURAL_QUALITY       6
                #endif
                */

                #ifndef CLEARTYPE_QUALITY
                    #define CLEARTYPE_QUALITY           5
                #endif

                #ifndef CLEARTYPE_NATURAL_QUALITY
                    #define CLEARTYPE_NATURAL_QUALITY   6
                #endif

                if (props->precision & Precision::noAntialias)
                   {
                    logfont.lfQuality = NONANTIALIASED_QUALITY;
                   }
                else if (props->precision & Precision::preferAntialias)
                   {
                    logfont.lfQuality = ANTIALIASED_QUALITY;
                    DWORD winVer = getWinVer();
                    if (winVer>=0x0501) // XP
                       logfont.lfQuality = CLEARTYPE_NATURAL_QUALITY;
                    else if (winVer>=0x0500) // W2K
                       logfont.lfQuality = CLEARTYPE_QUALITY;
                   }

                // �ॡ���� �筮� ᮮ⢥��⢨� ࠧ���� � �� ���ਪ�� 
                if (props->precision & Precision::preferMatch)
                   {
                   if (!logfont.lfQuality) logfont.lfQuality = DRAFT_QUALITY;
                   } // �ॡ���� ����⢮, �筮� ᮮ⢥��⢨� �� �ॡ����
                else if (props->precision & Precision::preferQuality)
                   {
                    if (!logfont.lfQuality) logfont.lfQuality = PROOF_QUALITY;
                   }

                #ifndef OUT_OUTLINE_PRECIS
                    #define OUT_OUTLINE_PRECIS          8
                #endif

                if (props->precision & Precision::preferDevice)
                   {
                    logfont.lfOutPrecision = OUT_DEVICE_PRECIS;
                   }
                else if (props->precision & Precision::preferRaster)
                   {
                    logfont.lfOutPrecision = OUT_RASTER_PRECIS;
                   }
                else if (props->precision & Precision::preferOutline)
                   {
                    if (isWinNt()) // NT4, W2K, XP or higher
                       logfont.lfOutPrecision = OUT_OUTLINE_PRECIS;
                    else
                       logfont.lfOutPrecision = OUT_TT_PRECIS;
                   }

                logfont.lfPitchAndFamily = (BYTE)win32ToImplFamilyAndPitch(props->family, props->pitch);
                
                //strncpy(logfont.lfFaceName, props.faceName, LF_FACESIZE);
                //wcsncpy(logfont.lfFaceName, props->faceName, LF_FACESIZE);
                //logfont.lfFaceName[LF_FACESIZE-1] = 0;
               }

            inline
            void win32implFillLogFont(HDC hdc, const STRUCT_CLI_DRAWING_FONT_PROPERTIES* props, LOGFONTA &logfont)
               {
                win32implFillGenericLogFont(hdc, props, logfont);
                ::std::string fontFaceName = win32StrToAnsi(::std::wstring(props->faceName));
                SIZE_T copySize = fontFaceName.size() > (LF_FACESIZE-1) ? (SIZE_T)(LF_FACESIZE-1) : (SIZE_T)fontFaceName.size();
                //fontFaceName.copy(logfont.lfFaceName, copySize);
                strncpy(logfont.lfFaceName, fontFaceName.c_str(), copySize);
                logfont.lfFaceName[copySize] = 0;
               }

            inline
            void win32implFillLogFont(HDC hdc, const STRUCT_CLI_DRAWING_FONT_PROPERTIES* props, LOGFONTW &logfont)
               {
                win32implFillGenericLogFont(hdc, props, logfont);
                wcsncpy(logfont.lfFaceName, props->faceName, LF_FACESIZE);
                logfont.lfFaceName[LF_FACESIZE-1] = 0;
               }


            inline
            HFONT win32implCreateFont(HDC hdc, const STRUCT_CLI_DRAWING_FONT_PROPERTIES* props /* , int angle tenths of degree */)
               {
                using namespace ::cli::drawing::font;

                LOGFONT logfont; // = {};
                win32implFillLogFont(hdc, props, logfont);

                HFONT hfont = CreateFontIndirect( &logfont );
                if (!hfont && logfont.lfQuality!=DRAFT_QUALITY)
                   { // try to create font other way
                    logfont.lfQuality = DRAFT_QUALITY;
                    hfont = CreateFontIndirect( &logfont );
                   }
                if (!hfont && logfont.lfOutPrecision!=OUT_DEFAULT_PRECIS)
                   { // try to create font other way
                    logfont.lfOutPrecision = OUT_DEFAULT_PRECIS;
                    hfont = CreateFontIndirect( &logfont );
                   }
                return hfont;
               }

            inline 
            RCODE win32RotatedTextOut ( HDC hdc
                                      , const CPoint &leftTopPos // in HDC units
                                      , INT    rotan
                                      , const WCHAR*     str
                                      , SIZE_T           strLen
                                      )
               {
                if (!str) return EC_INVALID_PARAM;

                POINT prevPoint;
                if (!SetViewportOrgEx( hdc, leftTopPos.x, leftTopPos.y, &prevPoint))
                   return EC_UNKNOWN;

                int prevGraphicsMode = SetGraphicsMode( hdc, GM_ADVANCED );

                XFORM oldTransform;
                GetWorldTransform( hdc, &oldTransform );

                XFORM xform;
                /*
                | eM11 eM12 0 | 
                | eM21 eM22 0 | 
                | eDx  eDy  1 | 
                eM11: cos phi
                eM12: sin phi
                eM21: -sin phi
                eM22: cos phi
                eDx  eDy - move vector, zero
                */
                double phi = -(double(rotan)/10.0) * M_PI / 180.0;
                 /* double */  float cosPhi = float(cos(phi));
                 /* double  */ float sinPhi = float(sin(phi));

                xform.eM11 = cosPhi;  // cos phi               
                xform.eM12 = sinPhi;  // sin phi               
                xform.eM21 = -sinPhi; // -sin phi              
                xform.eM22 = cosPhi;  // cos phi               
                xform.eDx  = 0;       // - move vector x, zero
                xform.eDy  = 0;       // - move vector y, zero

                SetWorldTransform( hdc, &xform );
                //ModifyWorldTransform( hdc, &xform, MWT_RIGHTMULTIPLY);

                RECT r;
                r.left   = 0;
                r.top    = 0;
                r.right  = 1;
                r.bottom = 1;

                ::DrawTextW( hdc, str, (int)strLen, &r
                           , DT_LEFT|DT_TOP|DT_NOPREFIX|DT_NOCLIP|DT_SINGLELINE
                           );

                SetWorldTransform( hdc, &oldTransform); // , MWT_IDENTITY

                SetGraphicsMode( hdc, prevGraphicsMode );

                if (!SetViewportOrgEx( hdc, prevPoint.x, prevPoint.y, 0))
                   return EC_UNKNOWN;

                return EC_OK;
               }



        }; /* namespace impl */
    }; /* namespace drawing */
}; /* namespace cli */



#endif /* CLI_DRAWING_IMPL_WIN32IMPLHLP_H */

