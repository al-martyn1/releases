#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_DBM_H
#define CLI_DRAWING_DBM_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/drawing/dbm.h>", CLI_DRAWING_DBM_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::drawing::iDeviceBitmap */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace drawing {
        }; // namespace drawing
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_DRAWING_IDEVICEBITMAP_IID
    #define INTERFACE_CLI_DRAWING_IDEVICEBITMAP_IID    "/cli/drawing/iDeviceBitmap"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace drawing {
    #define INTERFACE iDeviceBitmap
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IDEVICEBITMAP
       #define INTERFACE_CLI_DRAWING_IDEVICEBITMAP    ::cli::drawing::iDeviceBitmap
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_drawing_iDeviceBitmap
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IDEVICEBITMAP
       #define INTERFACE_CLI_DRAWING_IDEVICEBITMAP    cli_drawing_iDeviceBitmap
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::drawing::iDeviceBitmap methods */
                CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace drawing
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::drawing::iDeviceBitmap >
           {
            static char const * getName() { return INTERFACE_CLI_DRAWING_IDEVICEBITMAP_IID; }
           };
        template<> struct CIidOfImpl< ::cli::drawing::iDeviceBitmap* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::drawing::iDeviceBitmap > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::drawing::impl::qt::iDeviceBitmap */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP_IID
    #define INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP_IID    "/cli/drawing/impl/qt/iDeviceBitmap"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace drawing {
            namespace impl {
                namespace qt {
    #define INTERFACE iDeviceBitmap
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP
       #define INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP    ::cli::drawing::impl::qt::iDeviceBitmap
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_drawing_impl_qt_iDeviceBitmap
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP
       #define INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP    cli_drawing_impl_qt_iDeviceBitmap
    #endif
#endif

                    CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                    {
                        
                        /* interface ::cli::iUnknown methods */
                        CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                       , VOID**    ifPtr /* [out] void* ifPtr  */
                                                  ) PURE;
                        CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                        CLIMETHOD_(ULONG, release) (THIS) PURE;
                        
                        /* interface ::cli::drawing::impl::qt::iDeviceBitmap methods */
                        CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */) PURE;
                        CLIMETHOD(getHandle) (THIS_ CLI_DRAWING_GENERIC_HANDLE*    dbmHandle /* [out] cli_drawing_generic_handle dbmHandle  */) PURE;
                    };

#if defined(__cplusplus) && !defined(CINTERFACE)

                }; // namespace qt
            }; // namespace impl
        }; // namespace drawing
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::drawing::impl::qt::iDeviceBitmap >
           {
            static char const * getName() { return INTERFACE_CLI_DRAWING_IMPL_QT_IDEVICEBITMAP_IID; }
           };
        template<> struct CIidOfImpl< ::cli::drawing::impl::qt::iDeviceBitmap* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::drawing::impl::qt::iDeviceBitmap > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::drawing::impl::wx::iDeviceBitmap */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP_IID
    #define INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP_IID    "/cli/drawing/impl/wx/iDeviceBitmap"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace drawing {
            namespace impl {
                namespace wx {
    #define INTERFACE iDeviceBitmap
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP
       #define INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP    ::cli::drawing::impl::wx::iDeviceBitmap
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_drawing_impl_wx_iDeviceBitmap
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP
       #define INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP    cli_drawing_impl_wx_iDeviceBitmap
    #endif
#endif

                    CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                    {
                        
                        /* interface ::cli::iUnknown methods */
                        CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                       , VOID**    ifPtr /* [out] void* ifPtr  */
                                                  ) PURE;
                        CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                        CLIMETHOD_(ULONG, release) (THIS) PURE;
                        
                        /* interface ::cli::drawing::impl::wx::iDeviceBitmap methods */
                        CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */) PURE;
                        CLIMETHOD(getHandle) (THIS_ CLI_DRAWING_GENERIC_HANDLE*    dbmHandle /* [out] cli_drawing_generic_handle dbmHandle  */) PURE;
                    };

#if defined(__cplusplus) && !defined(CINTERFACE)

                }; // namespace wx
            }; // namespace impl
        }; // namespace drawing
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::drawing::impl::wx::iDeviceBitmap >
           {
            static char const * getName() { return INTERFACE_CLI_DRAWING_IMPL_WX_IDEVICEBITMAP_IID; }
           };
        template<> struct CIidOfImpl< ::cli::drawing::impl::wx::iDeviceBitmap* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::drawing::impl::wx::iDeviceBitmap > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::drawing::impl::win::iDeviceBitmap */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP_IID
    #define INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP_IID    "/cli/drawing/impl/win/iDeviceBitmap"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace drawing {
            namespace impl {
                namespace win {
    #define INTERFACE iDeviceBitmap
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP
       #define INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP    ::cli::drawing::impl::win::iDeviceBitmap
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_drawing_impl_win_iDeviceBitmap
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP
       #define INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP    cli_drawing_impl_win_iDeviceBitmap
    #endif
#endif

                    CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
                    {
                        
                        /* interface ::cli::iUnknown methods */
                        CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                       , VOID**    ifPtr /* [out] void* ifPtr  */
                                                  ) PURE;
                        CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                        CLIMETHOD_(ULONG, release) (THIS) PURE;
                        
                        /* interface ::cli::drawing::impl::win::iDeviceBitmap methods */
                        CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint _size  */) PURE;
                        CLIMETHOD(getHandle) (THIS_ CLI_DRAWING_GENERIC_HANDLE*    dbmHandle /* [out] cli_drawing_generic_handle dbmHandle  */) PURE;
                    };

#if defined(__cplusplus) && !defined(CINTERFACE)

                }; // namespace win
            }; // namespace impl
        }; // namespace drawing
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::drawing::impl::win::iDeviceBitmap >
           {
            static char const * getName() { return INTERFACE_CLI_DRAWING_IMPL_WIN_IDEVICEBITMAP_IID; }
           };
        template<> struct CIidOfImpl< ::cli::drawing::impl::win::iDeviceBitmap* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::drawing::impl::win::iDeviceBitmap > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif





#endif /* CLI_DRAWING_DBM_H */
