#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_DCOWNER_H
#define CLI_DRAWING_DCOWNER_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/drawing/dcowner.h>", CLI_DRAWING_DCOWNER_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_DCOWNER_H
    #include <cli/drawing/dcowner.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::drawing::iDcOwner */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace drawing {
            interface                                iDrawContext1;
            #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
                #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               ::cli::drawing::iDrawContext1
            #endif

        }; // namespace drawing
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_PREDECLARED
    #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_PREDECLARED
    typedef interface tag_cli_drawing_iDrawContext1              cli_drawing_iDrawContext1;
    #endif //INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
        #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1               struct tag_cli_drawing_iDrawContext1
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_DRAWING_IDCOWNER_IID
    #define INTERFACE_CLI_DRAWING_IDCOWNER_IID    "/cli/drawing/iDcOwner"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace drawing {
    #define INTERFACE iDcOwner
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IDCOWNER
       #define INTERFACE_CLI_DRAWING_IDCOWNER    ::cli::drawing::iDcOwner
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_drawing_iDcOwner
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IDCOWNER
       #define INTERFACE_CLI_DRAWING_IDCOWNER    cli_drawing_iDcOwner
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::drawing::iDcOwner methods */
                CLIMETHOD(dcGetForPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */) PURE;
                CLIMETHOD(dcGetForUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                               , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate /* [in,ref,optional] ::cli::drawing::CRect  rectForUpdate  */
                                          ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace drawing
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::drawing::iDcOwner >
           {
            static char const * getName() { return INTERFACE_CLI_DRAWING_IDCOWNER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::drawing::iDcOwner* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::drawing::iDcOwner > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace drawing {
            // interface ::cli::drawing::iDcOwner wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_DRAWING_IDCOWNER >
                                          */
                     >
            class CiDcOwnerWrapper
            {
                public:
            
                    typedef  CiDcOwnerWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiDcOwnerWrapper() :
                       pif(0) {}
            
                    CiDcOwnerWrapper( iDcOwner *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiDcOwnerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiDcOwnerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiDcOwnerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiDcOwnerWrapper(const CiDcOwnerWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiDcOwnerWrapper()  { }
            
                    CiDcOwnerWrapper& operator=(const CiDcOwnerWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE dcGetForPaint( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
                       {
                    
                        return pif->dcGetForPaint(pdc);
                       }
                    
                    RCODE dcGetForUpdate( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                        , const STRUCT_CLI_DRAWING_CRECT*    rectForUpdate /* [in,ref,optional] ::cli::drawing::CRect  rectForUpdate  */
                                        )
                       {
                    
                    
                        return pif->dcGetForUpdate(pdc, rectForUpdate);
                       }
                    

            
            
            }; // class CiDcOwnerWrapper
            
            typedef CiDcOwnerWrapper< ::cli::CCliPtr< INTERFACE_CLI_DRAWING_IDCOWNER     > >  CiDcOwner;
            typedef CiDcOwnerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_DRAWING_IDCOWNER > >  CiDcOwner_nrc; /* No ref counting for interface used */
            typedef CiDcOwnerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_DRAWING_IDCOWNER > >  CiDcOwner_tmp; /* for temporary usage, same as CiDcOwner_nrc */
            
            
            
            
            
        }; // namespace drawing
    }; // namespace cli

#endif





#endif /* CLI_DRAWING_DCOWNER_H */
