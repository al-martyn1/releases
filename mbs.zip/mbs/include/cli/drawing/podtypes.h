#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_PODTYPES_H
#define CLI_DRAWING_PODTYPES_H

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

typedef UINT16 FONT_SIZE_T;

#ifndef CONSTANT_COLORREF
    #define CONSTANT_COLORREF(num)               ((COLORREF)num##ul)
#endif


#ifndef CLI_DRAWING_GENERIC_HANDLE_DEFINED
    #define CLI_DRAWING_GENERIC_HANDLE_DEFINED
    typedef VOID* CLI_DRAWING_GENERIC_HANDLE;
#endif


#endif /* CLI_DRAWING_PODTYPES_H */

