#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
#define CLI_DRAWING_DRAWHLP_H

/*
#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif
*/

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif


/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif
*/





namespace cli {
namespace drawing {

using ::cli::util::copyStr2buf;

namespace font {

   inline void setupFontFace(Properties &props, const WCHAR* faceName )
      {
       copyStr2buf(faceName, props.faceName, sizeof(props.faceName)/sizeof(props.faceName[0]) );
       /*
       if (faceName)
          {
           wcsncpy(props.faceName, faceName, (sizeof(props.faceName)/sizeof(props.faceName[0])));
           props.faceName[(sizeof(props.faceName)/sizeof(props.faceName[0]))-1] = 0;
          }
       else
          {
           props.faceName[0] = 0;
          }
       */
      }

   inline void setupFontFace(Properties &props, const ::std::wstring &faceName)
      {
       setupFontFace(props, faceName.c_str() );
      }

}; // namespace font


// using ::cli::drawing::makePoint;
inline CPoint makePoint(INT x, INT y)
   {
    CPoint p; p.x = x; p.y = y;
    return p;
   }

inline CPoint zeroPoint() { return makePoint(0, 0); }

inline CPoint absPoint(const CPoint &p)
   {
    CPoint resPoint = p;
    if (resPoint.x<0) resPoint.x = -resPoint.x;
    if (resPoint.y<0) resPoint.y = -resPoint.y;
    return resPoint;
   }

// using ::cli::drawing::makeColorPoint;
inline CColorPoint makeColorPoint(INT x, INT y, COLORREF clr)
   {
    CColorPoint p; p.point = makePoint(x, y);
    p.color = clr;
    return p;
   }

// using ::cli::drawing::makeRect;
inline CRect makeRect(int l, int t, int r, int b)
   {
    CRect rect; 
    rect.left   = l;
    rect.top    = t;
    rect.right  = r;
    rect.bottom = b;
    return rect;
   }

inline CRect makeRect(CPoint leftTop, CPoint widthHeight)
   {
    return makeRect(leftTop.x, leftTop.y, leftTop.x+widthHeight.x, leftTop.y+widthHeight.y);
   }

namespace colorUtils {

    // make bit mask - lowest N bits are 1, if nBits==0 mask is also 0
    inline
    unsigned makeMask(int nBits)
       {
        if (nBits<=0) return 0;
        unsigned mask = 1;
        for(int i=1; i<nBits; ++i) mask |= (mask<<1);
        return mask;
       }

    inline
    void makeGradientColorsVector( COLORREF fromColor, COLORREF toColor
                                 , SIZE_T numPoints
                                 , ::std::vector< COLORREF > &gradient
                                 )
       {

        switch(numPoints)
           {
            case 0: return; 
            case 1: gradient.push_back(fromColor); return;
            case 2: gradient.push_back(fromColor); gradient.push_back(toColor); return;
           }

        int fcR = COLORREF_GET_RED  (fromColor)<<16;
        //int fcR = ((int)(unsigned)(0xFF&(fromColor))) <<16;
        int fcG = COLORREF_GET_GREEN(fromColor)<<16;
        int fcB = COLORREF_GET_BLUE (fromColor)<<16;

        int deltaR = ((COLORREF_GET_RED(toColor)   - COLORREF_GET_RED(fromColor))   <<16) / int(numPoints-1);
        int deltaG = ((COLORREF_GET_GREEN(toColor) - COLORREF_GET_GREEN(fromColor)) <<16) / int(numPoints-1);
        int deltaB = ((COLORREF_GET_BLUE(toColor)  - COLORREF_GET_BLUE(fromColor))  <<16) / int(numPoints-1);
        for(SIZE_T i=0; i!=numPoints; ++i)
           {
            gradient.push_back( RGB( (fcR + i*deltaR)>>16
                                   , (fcG + i*deltaG)>>16
                                   , (fcB + i*deltaB)>>16
                                   ) 
                              );
           }
       }

    inline
    unsigned adjustChannelBits(unsigned color, int numBits, unsigned mask)
       {
        unsigned tmp  = (color>>(8-numBits))<<(8-numBits);
        if (!(color>>7)) return tmp;
        return tmp|mask;
       }

    inline
    unsigned adjustChannelBits(unsigned color, int numBits)
       {
        unsigned tmp  = (color>>(8-numBits))<<(8-numBits);
        if (!(color>>7)) return tmp;
        return tmp|makeMask(8-numBits);
       }

    inline
    COLORREF adjustColor( COLORREF color
                        , bool bMonochrome
                        , int colorBits
                        , const ::std::vector<COLORREF> *pMonochromeColors
                        )
       {
        if (!colorBits) return color;
        int _colorBits = colorBits>8 ? 8 : colorBits;

        if (bMonochrome)
           {
            unsigned greyColor = (
            (unsigned(0xFF&color)      )*30 +    /* red   30% */ 
            (unsigned(0xFF&(color>>8)) )*60 +    /* green 60% */ 
            (unsigned(0xFF&(color>>16)))*10      /* blue  10% */ 
            ) / 100;
            if (greyColor>255) greyColor = 255;
            greyColor = adjustChannelBits(greyColor, _colorBits);
            if (pMonochromeColors && pMonochromeColors->size()==(::std::vector<COLORREF>::size_type(1)<<_colorBits))
               {
                return (*pMonochromeColors)[greyColor>>(8-_colorBits)];
               }
            return  RGB( greyColor , greyColor , greyColor );
           }
        
        return  RGB( adjustChannelBits(unsigned(0xFF&color)      , _colorBits, makeMask(8-_colorBits))
                   , adjustChannelBits(unsigned(0xFF&(color>>8)) , _colorBits, makeMask(8-_colorBits))
                   , adjustChannelBits(unsigned(0xFF&(color>>16)), _colorBits, makeMask(8-_colorBits))
                   );
       }

}; // namespace colorUtils


}; /* namespace drawing */
}; /* namespace cli */



inline 
::cli::drawing::CPoint operator+(const ::cli::drawing::CPoint &p1, const ::cli::drawing::CPoint &p2)
   {
    return ::cli::drawing::makePoint( p1.x+p2.x, p1.y+p2.y );
   }

inline 
::cli::drawing::CPoint& operator+=(::cli::drawing::CPoint &p1, const ::cli::drawing::CPoint &p2)
   {
    p1.x+=p2.x;
    p1.y+=p2.y;
    return p1;
   }

inline 
::cli::drawing::CPoint operator-(const ::cli::drawing::CPoint &p1, const ::cli::drawing::CPoint &p2)
   {
    return ::cli::drawing::makePoint( p1.x-p2.x, p1.y-p2.y );
   }

inline 
::cli::drawing::CPoint& operator-=(::cli::drawing::CPoint &p1, const ::cli::drawing::CPoint &p2)
   {
    p1.x-=p2.x;
    p1.y-=p2.y;
    return p1;
   }




#define COLOR_BWBLACK       0
#define COLOR_BWDARKGREY    0x404040
#define COLOR_BWDARKGRAY    COLOR_BWDARKGREY
#define COLOR_BWLIGHTGREY   0xBFBFBF
#define COLOR_BWLIGHTGRAY   COLOR_BWLIGHTGREY
#define COLOR_BWWHITE       0xFFFFFF


#define COLOR_GSBLACK       0
#define COLOR_GSWHITE       0xFFFFFF

#define COLOR_GSDARKGREY0   COLOR_GSBLACK
#define COLOR_GSDARKGREY1   0x1F1F1F
#define COLOR_GSDARKGREY2   0x2F2F2F
#define COLOR_GSDARKGREY3   0x3F3F3F
#define COLOR_GSDARKGREY4   0x4F4F4F
#define COLOR_GSDARKGREY5   0x5F5F5F
#define COLOR_GSDARKGREY6   0x6F6F6F
#define COLOR_GSDARKGREY7   0x7F7F7F

#define COLOR_GSLIGHTGREY0  0x8F8F8F
#define COLOR_GSLIGHTGREY1  0x9F9F9F
#define COLOR_GSLIGHTGREY2  0xAFAFAF
#define COLOR_GSLIGHTGREY3  0xBFBFBF
#define COLOR_GSLIGHTGREY4  0xCFCFCF
#define COLOR_GSLIGHTGREY5  0xDFDFDF
#define COLOR_GSLIGHTGREY6  0xEFEFEF
#define COLOR_GSLIGHTGREY7  COLOR_GSWHITE

#define COLOR_GSDARKGRAY0   COLOR_GSDARKGREY0   
#define COLOR_GSDARKGRAY1   COLOR_GSDARKGREY1   
#define COLOR_GSDARKGRAY2   COLOR_GSDARKGREY2   
#define COLOR_GSDARKGRAY3   COLOR_GSDARKGREY3   
#define COLOR_GSDARKGRAY4   COLOR_GSDARKGREY4   
#define COLOR_GSDARKGRAY5   COLOR_GSDARKGREY5   
#define COLOR_GSDARKGRAY6   COLOR_GSDARKGREY6   
#define COLOR_GSDARKGRAY7   COLOR_GSDARKGREY7   
                                                
#define COLOR_GSLIGHTGRAY0  COLOR_GSLIGHTGREY0  
#define COLOR_GSLIGHTGRAY1  COLOR_GSLIGHTGREY1  
#define COLOR_GSLIGHTGRAY2  COLOR_GSLIGHTGREY2  
#define COLOR_GSLIGHTGRAY3  COLOR_GSLIGHTGREY3  
#define COLOR_GSLIGHTGRAY4  COLOR_GSLIGHTGREY4  
#define COLOR_GSLIGHTGRAY5  COLOR_GSLIGHTGREY5  
#define COLOR_GSLIGHTGRAY6  COLOR_GSLIGHTGREY6  
#define COLOR_GSLIGHTGRAY7  COLOR_GSLIGHTGREY7  







#endif /* CLI_DRAWING_DRAWHLP_H */




