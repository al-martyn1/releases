#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_DCAUTO_H
#define CLI_DRAWING_DCAUTO_H

/*
#ifndef CLI_DRAWING_DCAUTO_H
    #include <cli/drawing/dcauto.h>
#endif

using namespace ::cli::drawing::dc;

using ::cli::drawing::dc::CAutoPen      ;
using ::cli::drawing::dc::CAutoBrush    ;
using ::cli::drawing::dc::CAutoFont     ;
using ::cli::drawing::dc::CAutoClipRect ;
using ::cli::drawing::dc::CAutoViewport ;

*/

#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif

//#include <cli/format.h>

// ::cli::draing::dc
namespace cli
{
namespace drawing
{
namespace dc
{


// ::cli::draing::dc::CBaseAutoClass
class CBaseAutoClass
{

protected:

    INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc;

public:

    CBaseAutoClass(INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc) : pdc(_pdc)
       {
        #ifdef DC_AUTOCLASSES_NEED_ADDREF_RELEASE
        if (pdc) pdc->addRef();
        #endif
       }

    template <typename TDC>
    CBaseAutoClass(TDC &tdc) : pdc(tdc.getIfPtr())
       {
        #ifdef DC_AUTOCLASSES_NEED_ADDREF_RELEASE
        if (pdc) pdc->addRef();
        #endif
       }

    ~CBaseAutoClass()
       {
        #ifdef DC_AUTOCLASSES_NEED_ADDREF_RELEASE
        if (pdc) pdc->release();
        #endif
       }
}; // class CBaseAutoClass


// ::cli::draing::dc::CAutoPen
class CAutoPen : public CBaseAutoClass
{

public:

    CAutoPen( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc
            , COLORREF clr
            , INT width
            , ENUM_CLI_DRAWING_EPENSTYLE style = CLI_DRAWING_EPENSTYLE_SOLID
            ) : CBaseAutoClass(_pdc)
       {
        if (pdc) pdc->pushSetPen( clr, width, style );
       }

    CAutoPen( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc
            , const STRUCT_CLI_DRAWING_CPENPARAMS &penParams
            ) : CBaseAutoClass(_pdc)
       {
        if (pdc) pdc->pushSetPenParams( & penParams );
       }

    template <typename TDC>
    CAutoPen( TDC &tdc
            , COLORREF clr
            , INT width
            , ENUM_CLI_DRAWING_EPENSTYLE style = CLI_DRAWING_EPENSTYLE_SOLID
            ) : CBaseAutoClass(tdc)
       { 
        if (pdc) pdc->pushSetPen( clr, width, style );
       }

    template <typename TDC>
    CAutoPen( TDC &tdc
            , const STRUCT_CLI_DRAWING_CPENPARAMS &penParams
            ) : CBaseAutoClass(tdc)
       { 
        if (pdc) pdc->pushSetPenParams( & penParams );
       }

    void setPen( COLORREF clr
               , INT width
               , ENUM_CLI_DRAWING_EPENSTYLE style = CLI_DRAWING_EPENSTYLE_SOLID
               )
       { 
        if (pdc) pdc->setPen( clr, width, style );
       }

    void setPen( const STRUCT_CLI_DRAWING_CPENPARAMS &penParams )
       { 
        if (pdc) pdc->setPenParams( &penParams );
       }

    ~CAutoPen() { if (pdc) pdc->popPen(); }

}; // class CAutoPen


// ::cli::draing::dc::CAutoPenEx
class CAutoPenEx : public CBaseAutoClass
{

public:

    CAutoPenEx( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc
            , COLORREF clr
            , INT width
            , ENUM_CLI_DRAWING_EPENSTYLE     style     = CLI_DRAWING_EPENSTYLE_SOLID
            , ENUM_CLI_DRAWING_EPENCAPSTYLE  capStyle  = CLI_DRAWING_EPENCAPSTYLE_ROUND
            , ENUM_CLI_DRAWING_EPENJOINSTYLE joinStyle = CLI_DRAWING_EPENJOINSTYLE_ROUND
            ) : CBaseAutoClass(_pdc)
       {
        if (pdc) pdc->pushSetPenEx( clr, width, style, capStyle, joinStyle );
       }

    template <typename TDC>
    CAutoPenEx( TDC &tdc
            , COLORREF clr
            , INT width
            , ENUM_CLI_DRAWING_EPENSTYLE     style     = CLI_DRAWING_EPENSTYLE_SOLID
            , ENUM_CLI_DRAWING_EPENCAPSTYLE  capStyle  = CLI_DRAWING_EPENCAPSTYLE_ROUND
            , ENUM_CLI_DRAWING_EPENJOINSTYLE joinStyle = CLI_DRAWING_EPENJOINSTYLE_ROUND
            ) : CBaseAutoClass(tdc)
       { if (pdc) pdc->pushSetPenEx( clr, width, style, capStyle, joinStyle ); }

    void setPen( COLORREF clr
               , INT width
               , ENUM_CLI_DRAWING_EPENSTYLE     style     = CLI_DRAWING_EPENSTYLE_SOLID
               , ENUM_CLI_DRAWING_EPENCAPSTYLE  capStyle  = CLI_DRAWING_EPENCAPSTYLE_ROUND
               , ENUM_CLI_DRAWING_EPENJOINSTYLE joinStyle = CLI_DRAWING_EPENJOINSTYLE_ROUND
               )
       { if (pdc) pdc->setPenEx( clr, width, style, capStyle, joinStyle ); }

    ~CAutoPenEx() { if (pdc) pdc->popPen(); }

}; // class CAutoPen



// ::cli::drawing::dc::CAutoBrush
// Use it for null or solid brushes
class CAutoBrush : public CBaseAutoClass
{

public:

    // setting null brush
    CAutoBrush( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc )
       : CBaseAutoClass(_pdc)
       { if (pdc) pdc->pushSetNullBrush( ); }

    template <typename TDC>
    CAutoBrush( TDC &tdc ) 
       : CBaseAutoClass(tdc)
       { if (pdc) pdc->pushSetNullBrush( ); }

    // setting solid brush
    CAutoBrush( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc, COLORREF clr )
       : CBaseAutoClass(_pdc)
       { if (pdc) pdc->pushSetSolidBrush( clr ); }

    template <typename TDC>
    CAutoBrush( TDC &tdc, COLORREF clr ) 
       : CBaseAutoClass(tdc)
       { if (pdc) pdc->pushSetSolidBrush( clr ); }

    void setNullBrush()              { if (pdc) pdc->setNullBrush( ); }
    void setSolidBrush(COLORREF clr) { if (pdc) pdc->setSolidBrush( clr ); }

    ~CAutoBrush() { if (pdc) pdc->popBrush(); }

}; // CAutoBrush


// ::cli::draing::dc::CAutoFont
class CAutoFont : public CBaseAutoClass
{

public:

    // setting null brush
    CAutoFont( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc
             , const std::wstring             &faceName
             , FONT_SIZE_T                     height
             , ENUM_CLI_DRAWING_FONT_WEIGHT    weight = CLI_DRAWING_FONT_WEIGHT_NORMAL
             , ENUM_CLI_DRAWING_FONT_FLAGS     flags  = CLI_DRAWING_FONT_FLAGS_NORMAL
             , ENUM_CLI_DRAWING_FONT_PRECISION precision = CLI_DRAWING_FONT_PRECISION_USEDEFAULT
             , ENUM_CLI_DRAWING_FONT_PITCH     pitch = CLI_DRAWING_FONT_PITCH_USEDEFAULT
             , ENUM_CLI_DRAWING_FONT_FAMILY    family = CLI_DRAWING_FONT_FAMILY_DONTCARE
             )
       : CBaseAutoClass(_pdc)
       { 
        /*
        ::cli::format::cli_log::message( L"Font face: %1, size: %2", ::cli::format::arg(faceName) % height);
        */
        //Courier New

        if (pdc) pdc->pushSetFont( height, weight, flags
                                 , precision, pitch, family
                                 , faceName.empty() ? L"Roman" : faceName.c_str()
                                 );
       }

    CAutoFont( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1        *_pdc
             , const STRUCT_CLI_DRAWING_FONT_PROPERTIES  &props
             )
       : CBaseAutoClass(_pdc)
       { 
        if (pdc) pdc->pushSetFontIndirect( &props );
       }

    template <typename TDC>
    CAutoFont( TDC &tdc
             , const std::wstring             &faceName
             , FONT_SIZE_T                     height
             , ENUM_CLI_DRAWING_FONT_WEIGHT    weight = CLI_DRAWING_FONT_WEIGHT_NORMAL
             , ENUM_CLI_DRAWING_FONT_FLAGS     flags  = CLI_DRAWING_FONT_FLAGS_NORMAL
             , ENUM_CLI_DRAWING_FONT_PRECISION precision = CLI_DRAWING_FONT_PRECISION_USEDEFAULT
             , ENUM_CLI_DRAWING_FONT_PITCH     pitch = CLI_DRAWING_FONT_PITCH_USEDEFAULT
             , ENUM_CLI_DRAWING_FONT_FAMILY    family = CLI_DRAWING_FONT_FAMILY_DONTCARE
             )
       : CBaseAutoClass(tdc)
       { 
        if (pdc) pdc->pushSetFont( height, weight, flags
                                 , precision, pitch, family
                                 , faceName.empty() ? L"Roman" : faceName.c_str()
                                 );
       }

    template <typename TDC>
    CAutoFont( TDC &tdc, const STRUCT_CLI_DRAWING_FONT_PROPERTIES&  props )
       : CBaseAutoClass(tdc)
       { 
        if (pdc) pdc->pushSetFontIndirect( &props );
       }

    void setFont( const std::wstring             &faceName
                , FONT_SIZE_T                     height
                , ENUM_CLI_DRAWING_FONT_WEIGHT    weight = CLI_DRAWING_FONT_WEIGHT_NORMAL
                , ENUM_CLI_DRAWING_FONT_FLAGS     flags  = CLI_DRAWING_FONT_FLAGS_NORMAL
                , ENUM_CLI_DRAWING_FONT_PRECISION precision = CLI_DRAWING_FONT_PRECISION_USEDEFAULT
                , ENUM_CLI_DRAWING_FONT_PITCH     pitch = CLI_DRAWING_FONT_PITCH_USEDEFAULT
                , ENUM_CLI_DRAWING_FONT_FAMILY    family = CLI_DRAWING_FONT_FAMILY_DONTCARE
                )
       { 
        if (pdc) pdc->setFont( height, weight, flags
                             , precision, pitch, family
                             , faceName.empty() ? L"Roman" : faceName.c_str()
                             );
       }

    void setFont( const STRUCT_CLI_DRAWING_FONT_PROPERTIES&  props )
       {
        if (pdc) pdc->setFontIndirect( &props );
       }

    ~CAutoFont() { if (pdc) pdc->popFont(); }

}; // CAutoFont



// using ::cli::drawing::dc::CAutoTextColor;
class CAutoTextColor : public CBaseAutoClass
{

    COLORREF prevColor;

public:

    CAutoTextColor( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc, COLORREF clr )
       : CBaseAutoClass(_pdc), prevColor(0)
       { 
        if (pdc) prevColor = pdc->setTextColor( clr );
       }

    template <typename TDC>
    CAutoTextColor( TDC &tdc, COLORREF clr ) 
       : CBaseAutoClass(tdc), prevColor(0)
       { 
        if (pdc) prevColor = pdc->setTextColor( clr );
       }

    ~CAutoTextColor() { if (pdc) pdc->setTextColor(prevColor); }

}; // CAutoBrush








class CAutoClipRect : public CBaseAutoClass
{

public:

    CAutoClipRect( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc
                 , const STRUCT_CLI_DRAWING_CRECT      &rect
                 )
       : CBaseAutoClass(_pdc)
       { if (pdc) pdc->pushSetClipRect( &rect ); }

    template <typename TDC>
    CAutoClipRect( TDC &tdc, const STRUCT_CLI_DRAWING_CRECT &rect ) 
       : CBaseAutoClass(tdc)
       { if (pdc) pdc->pushSetClipRect( &rect ); }

    CAutoClipRect( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc
                 , const STRUCT_CLI_DRAWING_CPOINT     &leftTop
                 , const STRUCT_CLI_DRAWING_CPOINT     &widthHeight
                 )
       : CBaseAutoClass(_pdc)
       { if (pdc) pdc->pushSetClipRectWH( &leftTop, &widthHeight ); }

    template <typename TDC>
    CAutoClipRect( TDC &tdc
                 , const STRUCT_CLI_DRAWING_CPOINT     &leftTop
                 , const STRUCT_CLI_DRAWING_CPOINT     &widthHeight
                 ) 
       : CBaseAutoClass(tdc)
       { if (pdc) pdc->pushSetClipRectWH( &leftTop, &widthHeight ); }

    void setClipRect( const STRUCT_CLI_DRAWING_CRECT &rect )
       {
        if (pdc) pdc->setClipRect( &rect );
       }

    void setClipRect( const STRUCT_CLI_DRAWING_CPOINT     &leftTop
                    , const STRUCT_CLI_DRAWING_CPOINT     &widthHeight
                    )
       { if (pdc) pdc->setClipRectWH( &leftTop, &widthHeight ); }

    ~CAutoClipRect() { if (pdc) pdc->popClipRect(); }

}; // CAutoClipRect



// ::cli::draing::dc::CAutoViewport
class CAutoViewport : public CBaseAutoClass
{

public:

    CAutoViewport( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc
                 , const STRUCT_CLI_DRAWING_CRECT      &rect
                 )
       : CBaseAutoClass(_pdc)
       { if (pdc) pdc->pushSetViewport( &rect ); }

    template <typename TDC>
    CAutoViewport( TDC &tdc, const STRUCT_CLI_DRAWING_CRECT &rect ) 
       : CBaseAutoClass(tdc)
       { if (pdc) pdc->pushSetViewport( &rect ); }

    CAutoViewport( INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *_pdc
                 , const STRUCT_CLI_DRAWING_CPOINT     &leftTop
                 , const STRUCT_CLI_DRAWING_CPOINT     &widthHeight
                 )
       : CBaseAutoClass(_pdc)
       { if (pdc) pdc->pushSetViewportWH( &leftTop, &widthHeight ); }

    template <typename TDC>
    CAutoViewport( TDC &tdc
                 , const STRUCT_CLI_DRAWING_CPOINT     &leftTop
                 , const STRUCT_CLI_DRAWING_CPOINT     &widthHeight
                 ) 
       : CBaseAutoClass(tdc)
       { if (pdc) pdc->pushSetViewportWH( &leftTop, &widthHeight ); }

    ~CAutoViewport() { if (pdc) pdc->popViewport(); }

}; // CAutoViewport






}; // namespace dc
}; // namespace drawing
}; // namespace cli





#endif /* CLI_DRAWING_DCAUTO_H */

