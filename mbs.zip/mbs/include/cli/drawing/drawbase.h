#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
#define CLI_DRAWING_DRAWBASE_H

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif


#if defined(_WIN32) || defined(WIN32)

    // typedef DWORD   COLORREF;

#else
    #ifndef CLI_COLORREF_POD_DEFINED
        #define CLI_COLORREF_POD_DEFINED
        typedef DWORD   COLORREF;
        #define RGB(r,g,b)          ((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)))
    #endif

    #define GetBValue(rgb)   ((BYTE) ((rgb) >> 16))

#endif
/*
#ifndef GetRValue
    #define GetRValue(rgb)   ((BYTE) (rgb))
#endif

#ifndef GetGValue
    #define GetGValue(rgb)   ((BYTE) (((WORD) (rgb)) >> 8))
#endif

#ifndef GetBValue
    #define GetBValue(rgb)   ((BYTE) ((rgb) >> 16))
#endif
*/

#ifndef COLORREF_GET_RED
    #define COLORREF_GET_RED(color)      ((int)(unsigned)(0xFF&(color)))
#endif

#ifndef COLORREF_GET_GREEN
    #define COLORREF_GET_GREEN(color)    ((int)(unsigned)(0xFF&((color)>>8)))
#endif

#ifndef COLORREF_GET_BLUE
    #define COLORREF_GET_BLUE(color)     ((int)(unsigned)(0xFF&((color)>>16)))
#endif

#endif /* CLI_DRAWING_DRAWBASE_H */

