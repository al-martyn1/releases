#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DRAWING_DC1_H
#define CLI_DRAWING_DC1_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/drawing/dc1.h>", CLI_DRAWING_DC1_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_DRAWING_DC1_H
    #include <cli/drawing/dc1.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_DRAWING_DBM_H
    #include <cli/drawing/dbm.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::drawing::iDrawContext1 */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace drawing {
            interface                                iDeviceBitmap;
            #ifndef INTERFACE_CLI_DRAWING_IDEVICEBITMAP
                #define INTERFACE_CLI_DRAWING_IDEVICEBITMAP               ::cli::drawing::iDeviceBitmap
            #endif

        }; // namespace drawing
    }; // namespace cli
    namespace cli {
        namespace drawing {
            namespace font {
            }; // namespace font
        }; // namespace drawing
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_DRAWING_IDEVICEBITMAP_PREDECLARED
    #define INTERFACE_CLI_DRAWING_IDEVICEBITMAP_PREDECLARED
    typedef interface tag_cli_drawing_iDeviceBitmap              cli_drawing_iDeviceBitmap;
    #endif //INTERFACE_CLI_DRAWING_IDEVICEBITMAP
    #ifndef INTERFACE_CLI_DRAWING_IDEVICEBITMAP
        #define INTERFACE_CLI_DRAWING_IDEVICEBITMAP               struct tag_cli_drawing_iDeviceBitmap
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_IID
    #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_IID    "/cli/drawing/iDrawContext1"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace drawing {
    #define INTERFACE iDrawContext1
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
       #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1    ::cli::drawing::iDrawContext1
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_drawing_iDrawContext1
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_DRAWING_IDRAWCONTEXT1
       #define INTERFACE_CLI_DRAWING_IDRAWCONTEXT1    cli_drawing_iDrawContext1
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::drawing::iDrawContext1 methods */
                CLIMETHOD(colorScaleMultiplierGet) (THIS_ COLORREF*    _colorScaleMultiplier /* [out] colorref _colorScaleMultiplier  */) PURE;
                CLIMETHOD(colorScaleMultiplierSet) (THIS_ COLORREF    _colorScaleMultiplier /* [in] colorref  _colorScaleMultiplier  */) PURE;
                CLIMETHOD(colorScaleDivisorGet) (THIS_ COLORREF*    _colorScaleDivisor /* [out] colorref _colorScaleDivisor  */) PURE;
                CLIMETHOD(colorScaleDivisorSet) (THIS_ COLORREF    _colorScaleDivisor /* [in] colorref  _colorScaleDivisor  */) PURE;
                CLIMETHOD(setColorScaling) (THIS_ USHORT    mult /* [in] ushort  mult  */
                                                , USHORT    div /* [in] ushort  div  */
                                           ) PURE;
                CLIMETHOD(resetColorScaling) (THIS) PURE;
                CLIMETHOD(bkColorGet) (THIS_ COLORREF*    _bkColor /* [out] colorref _bkColor  */) PURE;
                CLIMETHOD(bkColorSet) (THIS_ COLORREF    _bkColor /* [in] colorref  _bkColor  */) PURE;
                CLIMETHOD(textColorGet) (THIS_ COLORREF*    _textColor /* [out] colorref _textColor  */) PURE;
                CLIMETHOD(textColorSet) (THIS_ COLORREF    _textColor /* [in] colorref  _textColor  */) PURE;
                CLIMETHOD(setColorsConversionMode) (THIS_ UINT    numBits /* [in] uint  numBits  */
                                                        , BOOL    bMono /* [in] bool  bMono  */
                                                        , BOOL    bGreen /* [in] bool  bGreen  */
                                                   ) PURE;
                CLIMETHOD(getSize) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    pntSize /* [out,ref] ::cli::drawing::CPoint pntSize  */) PURE;
                CLIMETHOD(getDpi) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    dpi /* [out,ref] ::cli::drawing::CPoint dpi  */) PURE;
                CLIMETHOD_(ENUM_CLI_DRAWING_DEVICETYPE, getDeviceType) (THIS) PURE;
                CLIMETHOD(getDeviceColorInfo) (THIS_ STRUCT_CLI_DRAWING_CDEVICECOLORINFO*    colorInfo /* [out,ref] ::cli::drawing::CDeviceColorInfo colorInfo  */) PURE;
                CLIMETHOD_(ENUM_CLI_DRAWING_DEVICECOLORTYPE, getDeviceColorType) (THIS) PURE;
                CLIMETHOD_(ENUM_CLI_DRAWING_DEVICERENDERFLAG, setDeviceRenderFlags) (THIS_ ENUM_CLI_DRAWING_DEVICERENDERFLAG    newFlags /* [in] ::cli::drawing::DeviceRenderFlag  newFlags  */) PURE;
                CLIMETHOD(setPixel) (THIS_ INT    x /* [in] int  x  */
                                         , INT    y /* [in] int  y  */
                                         , COLORREF    clr /* [in] colorref  clr  */
                                    ) PURE;
                CLIMETHOD(setPixelPoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,ref] ::cli::drawing::CPoint  p  */
                                              , COLORREF    clr /* [in] colorref  clr  */
                                         ) PURE;
                CLIMETHOD(setPixels) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,flat] ::cli::drawing::CPoint  p[]  */
                                          , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                          , COLORREF    clr /* [in] colorref  clr  */
                                     ) PURE;
                CLIMETHOD(setColorPixels) (THIS_ const STRUCT_CLI_DRAWING_CCOLORPOINT*    p /* [in,flat] ::cli::drawing::CColorPoint  p[]  */
                                               , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                          ) PURE;
                CLIMETHOD(setPen) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                       , INT    width /* [in] int  width  */
                                       , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                  ) PURE;
                CLIMETHOD(setPenParams) (THIS_ const STRUCT_CLI_DRAWING_CPENPARAMS*    params /* [in,ref] ::cli::drawing::CPenParams  params  */) PURE;
                CLIMETHOD(pushSetPen) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                           , INT    width /* [in] int  width  */
                                           , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                      ) PURE;
                CLIMETHOD(pushSetPenParams) (THIS_ const STRUCT_CLI_DRAWING_CPENPARAMS*    params /* [in,ref] ::cli::drawing::CPenParams  params  */) PURE;
                CLIMETHOD(setPenEx) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                         , INT    width /* [in] int  width  */
                                         , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                         , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                         , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                    ) PURE;
                CLIMETHOD(pushSetPenEx) (THIS_ COLORREF    clr /* [in] colorref  clr  */
                                             , INT    width /* [in] int  width  */
                                             , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                             , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                             , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                        ) PURE;
                CLIMETHOD(popPen) (THIS) PURE;
                CLIMETHOD(drawLine) (THIS_ INT    x1 /* [in] int  x1  */
                                         , INT    y1 /* [in] int  y1  */
                                         , INT    x2 /* [in] int  x2  */
                                         , INT    y2 /* [in] int  y2  */
                                    ) PURE;
                CLIMETHOD(drawLinePoint) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    pointFrom /* [in,ref] ::cli::drawing::CPoint  pointFrom  */
                                              , const STRUCT_CLI_DRAWING_CPOINT*    pointTo /* [in,ref] ::cli::drawing::CPoint  pointTo  */
                                         ) PURE;
                CLIMETHOD(drawLines) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    points /* [in,flat] ::cli::drawing::CPoint  points[]  */
                                          , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                     ) PURE;
                CLIMETHOD(drawLinesPairPoints) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    points /* [in,flat] ::cli::drawing::CPoint  points[]  */
                                                    , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                               ) PURE;
                CLIMETHOD(setSolidBrush) (THIS_ COLORREF    clr /* [in] colorref  clr  */) PURE;
                CLIMETHOD(setNullBrush) (THIS) PURE;
                CLIMETHOD(pushSetSolidBrush) (THIS_ COLORREF    clr /* [in] colorref  clr  */) PURE;
                CLIMETHOD(pushSetNullBrush) (THIS) PURE;
                CLIMETHOD(popBrush) (THIS) PURE;
                CLIMETHOD(fillRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */) PURE;
                CLIMETHOD(fillRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                           , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                      ) PURE;
                CLIMETHOD(drawEllipse) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */) PURE;
                CLIMETHOD(drawEllipseWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                              , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                         ) PURE;
                CLIMETHOD(drawCircle) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                           , INT    radius /* [in] int  radius  */
                                      ) PURE;
                CLIMETHOD(drawRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */) PURE;
                CLIMETHOD(drawRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                           , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                      ) PURE;
                CLIMETHOD(drawRoundRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */
                                              , INT    radius /* [in] int  radius  */
                                         ) PURE;
                CLIMETHOD(drawRoundRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                , INT    radius /* [in] int  radius  */
                                           ) PURE;
                CLIMETHOD_(ENUM_CLI_DRAWING_BKMODE, getBkMode) (THIS) PURE;
                CLIMETHOD_(ENUM_CLI_DRAWING_BKMODE, setBkMode) (THIS_ ENUM_CLI_DRAWING_BKMODE    mode /* [in] ::cli::drawing::BkMode  mode  */) PURE;
                CLIMETHOD_(COLORREF, getBkColor) (THIS) PURE;
                CLIMETHOD_(COLORREF, setBkColor) (THIS_ COLORREF    color /* [in] colorref  color  */) PURE;
                CLIMETHOD_(COLORREF, getTextColor) (THIS) PURE;
                CLIMETHOD_(COLORREF, setTextColor) (THIS_ COLORREF    color /* [in] colorref  color  */) PURE;
                CLIMETHOD(textOut) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                        , const CLISTR*     text
                                   ) PURE;
                CLIMETHOD(textOutChars) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                             , const WCHAR*    chars /* [in,flat] wchar  chars[]  */
                                             , SIZE_T    nChars /* [in] size_t  nChars  */
                                        ) PURE;
                CLIMETHOD(setFontIndirect) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    props /* [in,ref] ::cli::drawing::font::Properties  props  */) PURE;
                CLIMETHOD(setFont) (THIS_ FONT_SIZE_T    height /* [in] font_size_t  height  */
                                        , ENUM_CLI_DRAWING_FONT_WEIGHT    weight /* [in] ::cli::drawing::font::Weight  weight  */
                                        , ENUM_CLI_DRAWING_FONT_FLAGS    flags /* [in] ::cli::drawing::font::Flags  flags  */
                                        , ENUM_CLI_DRAWING_FONT_PRECISION    precision /* [in] ::cli::drawing::font::Precision  precision  */
                                        , ENUM_CLI_DRAWING_FONT_PITCH    pitch /* [in] ::cli::drawing::font::Pitch  pitch  */
                                        , ENUM_CLI_DRAWING_FONT_FAMILY    family /* [in] ::cli::drawing::font::Family  family  */
                                        , const WCHAR*    faceName /* [in,flat] wchar  faceName[]  */
                                   ) PURE;
                CLIMETHOD(pushSetFontIndirect) (THIS_ const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    props /* [in,ref] ::cli::drawing::font::Properties  props  */) PURE;
                CLIMETHOD(pushSetFont) (THIS_ FONT_SIZE_T    height /* [in] font_size_t  height  */
                                            , ENUM_CLI_DRAWING_FONT_WEIGHT    weight /* [in] ::cli::drawing::font::Weight  weight  */
                                            , ENUM_CLI_DRAWING_FONT_FLAGS    flags /* [in] ::cli::drawing::font::Flags  flags  */
                                            , ENUM_CLI_DRAWING_FONT_PRECISION    precision /* [in] ::cli::drawing::font::Precision  precision  */
                                            , ENUM_CLI_DRAWING_FONT_PITCH    pitch /* [in] ::cli::drawing::font::Pitch  pitch  */
                                            , ENUM_CLI_DRAWING_FONT_FAMILY    family /* [in] ::cli::drawing::font::Family  family  */
                                            , const WCHAR*    faceName /* [in,flat] wchar  faceName[]  */
                                       ) PURE;
                CLIMETHOD(popFont) (THIS) PURE;
                CLIMETHOD(calcTextExtent) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [out,ref] ::cli::drawing::CPoint widthHeight  */
                                               , const CLISTR*     text
                                          ) PURE;
                CLIMETHOD(calcTextExtentChars) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [out,ref] ::cli::drawing::CPoint widthHeight  */
                                                    , const WCHAR*    chars /* [in,flat] wchar  chars[]  */
                                                    , SIZE_T    nChars /* [in] size_t  nChars  */
                                               ) PURE;
                CLIMETHOD(rotatedTextOut) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                               , INT    rotan /* [in] int  rotan  */
                                               , const CLISTR*     text
                                          ) PURE;
                CLIMETHOD(rotatedTextOutChars) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  */
                                                    , INT    rotan /* [in] int  rotan  */
                                                    , const WCHAR*    chars /* [in,flat] wchar  chars[]  */
                                                    , SIZE_T    nChars /* [in] size_t  nChars  */
                                               ) PURE;
                CLIMETHOD(drawGradientCircle) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                                   , INT    radius /* [in] int  radius  */
                                                   , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                                   , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                                   , ENUM_CLI_DRAWING_GRADIENTFLAGS    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                              ) PURE;
                CLIMETHOD(drawGradientCircleEx) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  */
                                                     , INT    radius /* [in] int  radius  */
                                                     , INT    smallRadius /* [in] int  smallRadius  */
                                                     , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                                     , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                                     , ENUM_CLI_DRAWING_GRADIENTFLAGS    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                                ) PURE;
                CLIMETHOD(setClipRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */) PURE;
                CLIMETHOD(setClipRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                              , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                         ) PURE;
                CLIMETHOD(clearClipRect) (THIS) PURE;
                CLIMETHOD(pushSetClipRect) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */) PURE;
                CLIMETHOD(pushSetClipRectWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                             ) PURE;
                CLIMETHOD(popClipRect) (THIS) PURE;
                CLIMETHOD(setViewport) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */) PURE;
                CLIMETHOD(setViewportWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                              , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                         ) PURE;
                CLIMETHOD(pushSetViewport) (THIS_ const STRUCT_CLI_DRAWING_CRECT*    rect /* [in,ref] ::cli::drawing::CRect  rect  */) PURE;
                CLIMETHOD(pushSetViewportWH) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                             ) PURE;
                CLIMETHOD(popViewport) (THIS) PURE;
                CLIMETHOD(createBitmap) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                             , INT    width /* [in] int  width  */
                                             , INT    height /* [in] int  height  */
                                        ) PURE;
                CLIMETHOD(createBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                  , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                             ) PURE;
                CLIMETHOD(createCopyBitmap) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                 , INT    left /* [in] int  left  */
                                                 , INT    top /* [in] int  top  */
                                                 , INT    width /* [in] int  width  */
                                                 , INT    height /* [in] int  height  */
                                            ) PURE;
                CLIMETHOD(createCopyBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                      , const STRUCT_CLI_DRAWING_CPOINT*    widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  */
                                                 ) PURE;
                CLIMETHOD(drawBitmap) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP*    pbmp /* [in] ::cli::drawing::iDeviceBitmap*  pbmp  */
                                           , INT    left /* [in] int  left  */
                                           , INT    top /* [in] int  top  */
                                      ) PURE;
                CLIMETHOD(drawBitmapPoint) (THIS_ INTERFACE_CLI_DRAWING_IDEVICEBITMAP*    pbmp /* [in] ::cli::drawing::iDeviceBitmap*  pbmp  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                           ) PURE;
                CLIMETHOD(drawEllipticArc) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    rightBottom /* [in,ref] ::cli::drawing::CPoint  rightBottom  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    arcStart /* [in,ref] ::cli::drawing::CPoint  arcStart  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    arcEnd /* [in,ref] ::cli::drawing::CPoint  arcEnd  */
                                                , BOOL    direction /* [in] bool  direction  */
                                           ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace drawing
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::drawing::iDrawContext1 >
           {
            static char const * getName() { return INTERFACE_CLI_DRAWING_IDRAWCONTEXT1_IID; }
           };
        template<> struct CIidOfImpl< ::cli::drawing::iDrawContext1* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::drawing::iDrawContext1 > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace drawing {
            // interface ::cli::drawing::iDrawContext1 wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 >
                                          */
                     >
            class CiDrawContext1Wrapper
            {
                public:
            
                    typedef  CiDrawContext1Wrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiDrawContext1Wrapper() :
                       pif(0) {}
            
                    CiDrawContext1Wrapper( iDrawContext1 *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiDrawContext1Wrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiDrawContext1Wrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiDrawContext1Wrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiDrawContext1Wrapper(const CiDrawContext1Wrapper &i) :
                        pif(i.pif) { }
            
                    ~CiDrawContext1Wrapper()  { }
            
                    CiDrawContext1Wrapper& operator=(const CiDrawContext1Wrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    COLORREF get_colorScaleMultiplier( )
                       {
                        COLORREF tmpVal;
                        RCODE res = colorScaleMultiplierGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_colorScaleMultiplier( COLORREF _colorScaleMultiplier
                                                 )
                       {
                        RCODE res = colorScaleMultiplierSet( _colorScaleMultiplier );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, colorScaleMultiplier );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE colorScaleMultiplierGet( COLORREF*    _colorScaleMultiplier /* [out] colorref _colorScaleMultiplier  */)
                       {
                    
                        return pif->colorScaleMultiplierGet(_colorScaleMultiplier);
                       }
                    
                    RCODE colorScaleMultiplierSet( COLORREF    _colorScaleMultiplier /* [in] colorref  _colorScaleMultiplier  */)
                       {
                    
                        return pif->colorScaleMultiplierSet(_colorScaleMultiplier);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    COLORREF get_colorScaleDivisor( )
                       {
                        COLORREF tmpVal;
                        RCODE res = colorScaleDivisorGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_colorScaleDivisor( COLORREF _colorScaleDivisor
                                              )
                       {
                        RCODE res = colorScaleDivisorSet( _colorScaleDivisor );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, colorScaleDivisor );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE colorScaleDivisorGet( COLORREF*    _colorScaleDivisor /* [out] colorref _colorScaleDivisor  */)
                       {
                    
                        return pif->colorScaleDivisorGet(_colorScaleDivisor);
                       }
                    
                    RCODE colorScaleDivisorSet( COLORREF    _colorScaleDivisor /* [in] colorref  _colorScaleDivisor  */)
                       {
                    
                        return pif->colorScaleDivisorSet(_colorScaleDivisor);
                       }
                    
                    RCODE setColorScaling( USHORT    mult /* [in] ushort  mult  */
                                         , USHORT    div /* [in] ushort  div  */
                                         )
                       {
                    
                    
                        return pif->setColorScaling(mult, div);
                       }
                    
                    RCODE resetColorScaling( )
                       {
                        return pif->resetColorScaling();
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    COLORREF get_bkColor( )
                       {
                        COLORREF tmpVal;
                        RCODE res = bkColorGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_bkColor( COLORREF _bkColor
                                    )
                       {
                        RCODE res = bkColorSet( _bkColor );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, bkColor );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE bkColorGet( COLORREF*    _bkColor /* [out] colorref _bkColor  */)
                       {
                    
                        return pif->bkColorGet(_bkColor);
                       }
                    
                    RCODE bkColorSet( COLORREF    _bkColor /* [in] colorref  _bkColor  */)
                       {
                    
                        return pif->bkColorSet(_bkColor);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    COLORREF get_textColor( )
                       {
                        COLORREF tmpVal;
                        RCODE res = textColorGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_textColor( COLORREF _textColor
                                      )
                       {
                        RCODE res = textColorSet( _textColor );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, COLORREF, textColor );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE textColorGet( COLORREF*    _textColor /* [out] colorref _textColor  */)
                       {
                    
                        return pif->textColorGet(_textColor);
                       }
                    
                    RCODE textColorSet( COLORREF    _textColor /* [in] colorref  _textColor  */)
                       {
                    
                        return pif->textColorSet(_textColor);
                       }
                    
                    RCODE setColorsConversionMode( UINT    numBits /* [in] uint  numBits  */
                                                 , BOOL    bMono /* [in] bool  bMono  */
                                                 , BOOL    bGreen /* [in] bool  bGreen  */
                                                 )
                       {
                    
                    
                    
                        return pif->setColorsConversionMode(numBits, bMono, bGreen);
                       }
                    
                    RCODE getSize( STRUCT_CLI_DRAWING_CPOINT    &pntSize /* [out,ref] ::cli::drawing::CPoint pntSize  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->getSize(&pntSize);
                       }
                    
                    RCODE getDpi( STRUCT_CLI_DRAWING_CPOINT    &dpi /* [out,ref] ::cli::drawing::CPoint dpi  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->getDpi(&dpi);
                       }
                    
                    ENUM_CLI_DRAWING_DEVICETYPE getDeviceType( )
                       {
                        return pif->getDeviceType();
                       }
                    
                    RCODE getDeviceColorInfo( STRUCT_CLI_DRAWING_CDEVICECOLORINFO    &colorInfo /* [out,ref] ::cli::drawing::CDeviceColorInfo colorInfo  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->getDeviceColorInfo(&colorInfo);
                       }
                    
                    ENUM_CLI_DRAWING_DEVICECOLORTYPE getDeviceColorType( )
                       {
                        return pif->getDeviceColorType();
                       }
                    
                    ENUM_CLI_DRAWING_DEVICERENDERFLAG setDeviceRenderFlags( ENUM_CLI_DRAWING_DEVICERENDERFLAG    newFlags /* [in] ::cli::drawing::DeviceRenderFlag  newFlags  */)
                       {
                    
                        return pif->setDeviceRenderFlags(newFlags);
                       }
                    
                    RCODE setPixel( INT    x /* [in] int  x  */
                                  , INT    y /* [in] int  y  */
                                  , COLORREF    clr /* [in] colorref  clr  */
                                  )
                       {
                    
                    
                    
                        return pif->setPixel(x, y, clr);
                       }
                    
                    RCODE setPixelPoint( const STRUCT_CLI_DRAWING_CPOINT    &p /* [in,ref] ::cli::drawing::CPoint  p  (struct passed by ref in wrapper) */
                                       , COLORREF    clr /* [in] colorref  clr  */
                                       )
                       {
                    
                    
                        return pif->setPixelPoint(&p, clr);
                       }
                    
                    RCODE setPixels( const STRUCT_CLI_DRAWING_CPOINT*    p /* [in,flat] ::cli::drawing::CPoint  p[]  */
                                   , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                   , COLORREF    clr /* [in] colorref  clr  */
                                   )
                       {
                    
                    
                    
                        return pif->setPixels(p, numPoints, clr);
                       }
                    
                    RCODE setColorPixels( const STRUCT_CLI_DRAWING_CCOLORPOINT*    p /* [in,flat] ::cli::drawing::CColorPoint  p[]  */
                                        , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                        )
                       {
                    
                    
                        return pif->setColorPixels(p, numPoints);
                       }
                    
                    RCODE setPen( COLORREF    clr /* [in] colorref  clr  */
                                , INT    width /* [in] int  width  */
                                , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                )
                       {
                    
                    
                    
                        return pif->setPen(clr, width, style);
                       }
                    
                    RCODE setPenParams( const STRUCT_CLI_DRAWING_CPENPARAMS    &params /* [in,ref] ::cli::drawing::CPenParams  params  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->setPenParams(&params);
                       }
                    
                    RCODE pushSetPen( COLORREF    clr /* [in] colorref  clr  */
                                    , INT    width /* [in] int  width  */
                                    , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                    )
                       {
                    
                    
                    
                        return pif->pushSetPen(clr, width, style);
                       }
                    
                    RCODE pushSetPenParams( const STRUCT_CLI_DRAWING_CPENPARAMS    &params /* [in,ref] ::cli::drawing::CPenParams  params  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->pushSetPenParams(&params);
                       }
                    
                    RCODE setPenEx( COLORREF    clr /* [in] colorref  clr  */
                                  , INT    width /* [in] int  width  */
                                  , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                  , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                  , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                  )
                       {
                    
                    
                    
                    
                    
                        return pif->setPenEx(clr, width, style, capStyle, joinStyle);
                       }
                    
                    RCODE pushSetPenEx( COLORREF    clr /* [in] colorref  clr  */
                                      , INT    width /* [in] int  width  */
                                      , ENUM_CLI_DRAWING_EPENSTYLE    style /* [in] ::cli::drawing::EPenStyle  style  */
                                      , ENUM_CLI_DRAWING_EPENCAPSTYLE    capStyle /* [in] ::cli::drawing::EPenCapStyle  capStyle  */
                                      , ENUM_CLI_DRAWING_EPENJOINSTYLE    joinStyle /* [in] ::cli::drawing::EPenJoinStyle  joinStyle  */
                                      )
                       {
                    
                    
                    
                    
                    
                        return pif->pushSetPenEx(clr, width, style, capStyle, joinStyle);
                       }
                    
                    RCODE popPen( )
                       {
                        return pif->popPen();
                       }
                    
                    RCODE drawLine( INT    x1 /* [in] int  x1  */
                                  , INT    y1 /* [in] int  y1  */
                                  , INT    x2 /* [in] int  x2  */
                                  , INT    y2 /* [in] int  y2  */
                                  )
                       {
                    
                    
                    
                    
                        return pif->drawLine(x1, y1, x2, y2);
                       }
                    
                    RCODE drawLinePoint( const STRUCT_CLI_DRAWING_CPOINT    &pointFrom /* [in,ref] ::cli::drawing::CPoint  pointFrom  (struct passed by ref in wrapper) */
                                       , const STRUCT_CLI_DRAWING_CPOINT    &pointTo /* [in,ref] ::cli::drawing::CPoint  pointTo  (struct passed by ref in wrapper) */
                                       )
                       {
                    
                    
                        return pif->drawLinePoint(&pointFrom, &pointTo);
                       }
                    
                    RCODE drawLines( const STRUCT_CLI_DRAWING_CPOINT*    points /* [in,flat] ::cli::drawing::CPoint  points[]  */
                                   , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                   )
                       {
                    
                    
                        return pif->drawLines(points, numPoints);
                       }
                    
                    RCODE drawLinesPairPoints( const STRUCT_CLI_DRAWING_CPOINT*    points /* [in,flat] ::cli::drawing::CPoint  points[]  */
                                             , SIZE_T    numPoints /* [in] size_t  numPoints  */
                                             )
                       {
                    
                    
                        return pif->drawLinesPairPoints(points, numPoints);
                       }
                    
                    RCODE setSolidBrush( COLORREF    clr /* [in] colorref  clr  */)
                       {
                    
                        return pif->setSolidBrush(clr);
                       }
                    
                    RCODE setNullBrush( )
                       {
                        return pif->setNullBrush();
                       }
                    
                    RCODE pushSetSolidBrush( COLORREF    clr /* [in] colorref  clr  */)
                       {
                    
                        return pif->pushSetSolidBrush(clr);
                       }
                    
                    RCODE pushSetNullBrush( )
                       {
                        return pif->pushSetNullBrush();
                       }
                    
                    RCODE popBrush( )
                       {
                        return pif->popBrush();
                       }
                    
                    RCODE fillRect( const STRUCT_CLI_DRAWING_CRECT    &rect /* [in,ref] ::cli::drawing::CRect  rect  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->fillRect(&rect);
                       }
                    
                    RCODE fillRectWH( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                    , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                    )
                       {
                    
                    
                        return pif->fillRectWH(&leftTop, &widthHeight);
                       }
                    
                    RCODE drawEllipse( const STRUCT_CLI_DRAWING_CRECT    &rect /* [in,ref] ::cli::drawing::CRect  rect  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->drawEllipse(&rect);
                       }
                    
                    RCODE drawEllipseWH( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                       , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                       )
                       {
                    
                    
                        return pif->drawEllipseWH(&leftTop, &widthHeight);
                       }
                    
                    RCODE drawCircle( const STRUCT_CLI_DRAWING_CPOINT    &centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  (struct passed by ref in wrapper) */
                                    , INT    radius /* [in] int  radius  */
                                    )
                       {
                    
                    
                        return pif->drawCircle(&centerPos, radius);
                       }
                    
                    RCODE drawRect( const STRUCT_CLI_DRAWING_CRECT    &rect /* [in,ref] ::cli::drawing::CRect  rect  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->drawRect(&rect);
                       }
                    
                    RCODE drawRectWH( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                    , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                    )
                       {
                    
                    
                        return pif->drawRectWH(&leftTop, &widthHeight);
                       }
                    
                    RCODE drawRoundRect( const STRUCT_CLI_DRAWING_CRECT    &rect /* [in,ref] ::cli::drawing::CRect  rect  (struct passed by ref in wrapper) */
                                       , INT    radius /* [in] int  radius  */
                                       )
                       {
                    
                    
                        return pif->drawRoundRect(&rect, radius);
                       }
                    
                    RCODE drawRoundRectWH( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                         , INT    radius /* [in] int  radius  */
                                         )
                       {
                    
                    
                    
                        return pif->drawRoundRectWH(&leftTop, &widthHeight, radius);
                       }
                    
                    ENUM_CLI_DRAWING_BKMODE getBkMode( )
                       {
                        return pif->getBkMode();
                       }
                    
                    ENUM_CLI_DRAWING_BKMODE setBkMode( ENUM_CLI_DRAWING_BKMODE    mode /* [in] ::cli::drawing::BkMode  mode  */)
                       {
                    
                        return pif->setBkMode(mode);
                       }
                    
                    COLORREF getBkColor( )
                       {
                        return pif->getBkColor();
                       }
                    
                    COLORREF setBkColor( COLORREF    color /* [in] colorref  color  */)
                       {
                    
                        return pif->setBkColor(color);
                       }
                    
                    COLORREF getTextColor( )
                       {
                        return pif->getTextColor();
                       }
                    
                    COLORREF setTextColor( COLORREF    color /* [in] colorref  color  */)
                       {
                    
                        return pif->setTextColor(color);
                       }
                    
                    RCODE textOut( const STRUCT_CLI_DRAWING_CPOINT    &leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  (struct passed by ref in wrapper) */
                                 , const ::std::wstring    &text
                                 )
                       {
                    
                        CCliStr tmp_text; CCliStr_lightCopyTo( tmp_text, text);
                        return pif->textOut(&leftTopPos, &tmp_text);
                       }
                    
                    RCODE textOutChars( const STRUCT_CLI_DRAWING_CPOINT    &leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  (struct passed by ref in wrapper) */
                                      , const WCHAR*    chars /* [in,flat] wchar  chars[]  */
                                      , SIZE_T    nChars /* [in] size_t  nChars  */
                                      )
                       {
                    
                    
                    
                        return pif->textOutChars(&leftTopPos, chars, nChars);
                       }
                    
                    RCODE setFontIndirect( const STRUCT_CLI_DRAWING_FONT_PROPERTIES    &props /* [in,ref] ::cli::drawing::font::Properties  props  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->setFontIndirect(&props);
                       }
                    
                    RCODE setFont( FONT_SIZE_T    height /* [in] font_size_t  height  */
                                 , ENUM_CLI_DRAWING_FONT_WEIGHT    weight /* [in] ::cli::drawing::font::Weight  weight  */
                                 , ENUM_CLI_DRAWING_FONT_FLAGS    flags /* [in] ::cli::drawing::font::Flags  flags  */
                                 , ENUM_CLI_DRAWING_FONT_PRECISION    precision /* [in] ::cli::drawing::font::Precision  precision  */
                                 , ENUM_CLI_DRAWING_FONT_PITCH    pitch /* [in] ::cli::drawing::font::Pitch  pitch  */
                                 , ENUM_CLI_DRAWING_FONT_FAMILY    family /* [in] ::cli::drawing::font::Family  family  */
                                 , const WCHAR*    faceName /* [in,flat] wchar  faceName[]  */
                                 )
                       {
                    
                    
                    
                    
                    
                    
                    
                        return pif->setFont(height, weight, flags, precision, pitch, family, faceName);
                       }
                    
                    RCODE pushSetFontIndirect( const STRUCT_CLI_DRAWING_FONT_PROPERTIES    &props /* [in,ref] ::cli::drawing::font::Properties  props  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->pushSetFontIndirect(&props);
                       }
                    
                    RCODE pushSetFont( FONT_SIZE_T    height /* [in] font_size_t  height  */
                                     , ENUM_CLI_DRAWING_FONT_WEIGHT    weight /* [in] ::cli::drawing::font::Weight  weight  */
                                     , ENUM_CLI_DRAWING_FONT_FLAGS    flags /* [in] ::cli::drawing::font::Flags  flags  */
                                     , ENUM_CLI_DRAWING_FONT_PRECISION    precision /* [in] ::cli::drawing::font::Precision  precision  */
                                     , ENUM_CLI_DRAWING_FONT_PITCH    pitch /* [in] ::cli::drawing::font::Pitch  pitch  */
                                     , ENUM_CLI_DRAWING_FONT_FAMILY    family /* [in] ::cli::drawing::font::Family  family  */
                                     , const WCHAR*    faceName /* [in,flat] wchar  faceName[]  */
                                     )
                       {
                    
                    
                    
                    
                    
                    
                    
                        return pif->pushSetFont(height, weight, flags, precision, pitch, family, faceName);
                       }
                    
                    RCODE popFont( )
                       {
                        return pif->popFont();
                       }
                    
                    RCODE calcTextExtent( STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [out,ref] ::cli::drawing::CPoint widthHeight  (struct passed by ref in wrapper) */
                                        , const ::std::wstring    &text
                                        )
                       {
                    
                        CCliStr tmp_text; CCliStr_lightCopyTo( tmp_text, text);
                        return pif->calcTextExtent(&widthHeight, &tmp_text);
                       }
                    
                    RCODE calcTextExtentChars( STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [out,ref] ::cli::drawing::CPoint widthHeight  (struct passed by ref in wrapper) */
                                             , const WCHAR*    chars /* [in,flat] wchar  chars[]  */
                                             , SIZE_T    nChars /* [in] size_t  nChars  */
                                             )
                       {
                    
                    
                    
                        return pif->calcTextExtentChars(&widthHeight, chars, nChars);
                       }
                    
                    RCODE rotatedTextOut( const STRUCT_CLI_DRAWING_CPOINT    &leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  (struct passed by ref in wrapper) */
                                        , INT    rotan /* [in] int  rotan  */
                                        , const ::std::wstring    &text
                                        )
                       {
                    
                    
                        CCliStr tmp_text; CCliStr_lightCopyTo( tmp_text, text);
                        return pif->rotatedTextOut(&leftTopPos, rotan, &tmp_text);
                       }
                    
                    RCODE rotatedTextOutChars( const STRUCT_CLI_DRAWING_CPOINT    &leftTopPos /* [in,ref] ::cli::drawing::CPoint  leftTopPos  (struct passed by ref in wrapper) */
                                             , INT    rotan /* [in] int  rotan  */
                                             , const WCHAR*    chars /* [in,flat] wchar  chars[]  */
                                             , SIZE_T    nChars /* [in] size_t  nChars  */
                                             )
                       {
                    
                    
                    
                    
                        return pif->rotatedTextOutChars(&leftTopPos, rotan, chars, nChars);
                       }
                    
                    RCODE drawGradientCircle( const STRUCT_CLI_DRAWING_CPOINT    &centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  (struct passed by ref in wrapper) */
                                            , INT    radius /* [in] int  radius  */
                                            , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                            , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                            , ENUM_CLI_DRAWING_GRADIENTFLAGS    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                            )
                       {
                    
                    
                    
                    
                    
                        return pif->drawGradientCircle(&centerPos, radius, colorCenter, colorRadius, flags);
                       }
                    
                    RCODE drawGradientCircleEx( const STRUCT_CLI_DRAWING_CPOINT    &centerPos /* [in,ref] ::cli::drawing::CPoint  centerPos  (struct passed by ref in wrapper) */
                                              , INT    radius /* [in] int  radius  */
                                              , INT    smallRadius /* [in] int  smallRadius  */
                                              , COLORREF    colorCenter /* [in] colorref  colorCenter  */
                                              , COLORREF    colorRadius /* [in] colorref  colorRadius  */
                                              , ENUM_CLI_DRAWING_GRADIENTFLAGS    flags /* [in] ::cli::drawing::GradientFlags  flags  */
                                              )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->drawGradientCircleEx(&centerPos, radius, smallRadius, colorCenter, colorRadius, flags);
                       }
                    
                    RCODE setClipRect( const STRUCT_CLI_DRAWING_CRECT    &rect /* [in,ref] ::cli::drawing::CRect  rect  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->setClipRect(&rect);
                       }
                    
                    RCODE setClipRectWH( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                       , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                       )
                       {
                    
                    
                        return pif->setClipRectWH(&leftTop, &widthHeight);
                       }
                    
                    RCODE clearClipRect( )
                       {
                        return pif->clearClipRect();
                       }
                    
                    RCODE pushSetClipRect( const STRUCT_CLI_DRAWING_CRECT    &rect /* [in,ref] ::cli::drawing::CRect  rect  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->pushSetClipRect(&rect);
                       }
                    
                    RCODE pushSetClipRectWH( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                           , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                           )
                       {
                    
                    
                        return pif->pushSetClipRectWH(&leftTop, &widthHeight);
                       }
                    
                    RCODE popClipRect( )
                       {
                        return pif->popClipRect();
                       }
                    
                    RCODE setViewport( const STRUCT_CLI_DRAWING_CRECT    &rect /* [in,ref] ::cli::drawing::CRect  rect  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->setViewport(&rect);
                       }
                    
                    RCODE setViewportWH( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                       , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                       )
                       {
                    
                    
                        return pif->setViewportWH(&leftTop, &widthHeight);
                       }
                    
                    RCODE pushSetViewport( const STRUCT_CLI_DRAWING_CRECT    &rect /* [in,ref] ::cli::drawing::CRect  rect  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->pushSetViewport(&rect);
                       }
                    
                    RCODE pushSetViewportWH( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                           , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                           )
                       {
                    
                    
                        return pif->pushSetViewportWH(&leftTop, &widthHeight);
                       }
                    
                    RCODE popViewport( )
                       {
                        return pif->popViewport();
                       }
                    
                    RCODE createBitmap( INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                      , INT    width /* [in] int  width  */
                                      , INT    height /* [in] int  height  */
                                      )
                       {
                    
                    
                    
                        return pif->createBitmap(pbmp, width, height);
                       }
                    
                    RCODE createBitmapPoint( INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                           , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                           )
                       {
                    
                    
                        return pif->createBitmapPoint(pbmp, &widthHeight);
                       }
                    
                    RCODE createCopyBitmap( INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                          , INT    left /* [in] int  left  */
                                          , INT    top /* [in] int  top  */
                                          , INT    width /* [in] int  width  */
                                          , INT    height /* [in] int  height  */
                                          )
                       {
                    
                    
                    
                    
                    
                        return pif->createCopyBitmap(pbmp, left, top, width, height);
                       }
                    
                    RCODE createCopyBitmapPoint( INTERFACE_CLI_DRAWING_IDEVICEBITMAP**    pbmp /* [out] ::cli::drawing::iDeviceBitmap* pbmp  */
                                               , const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                               , const STRUCT_CLI_DRAWING_CPOINT    &widthHeight /* [in,ref] ::cli::drawing::CPoint  widthHeight  (struct passed by ref in wrapper) */
                                               )
                       {
                    
                    
                    
                        return pif->createCopyBitmapPoint(pbmp, &leftTop, &widthHeight);
                       }
                    
                    RCODE drawBitmap( INTERFACE_CLI_DRAWING_IDEVICEBITMAP*    pbmp /* [in] ::cli::drawing::iDeviceBitmap*  pbmp  */
                                    , INT    left /* [in] int  left  */
                                    , INT    top /* [in] int  top  */
                                    )
                       {
                    
                    
                    
                        return pif->drawBitmap(pbmp, left, top);
                       }
                    
                    RCODE drawBitmapPoint( INTERFACE_CLI_DRAWING_IDEVICEBITMAP*    pbmp /* [in] ::cli::drawing::iDeviceBitmap*  pbmp  */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                         )
                       {
                    
                    
                        return pif->drawBitmapPoint(pbmp, &leftTop);
                       }
                    
                    RCODE drawEllipticArc( const STRUCT_CLI_DRAWING_CPOINT    &leftTop /* [in,ref] ::cli::drawing::CPoint  leftTop  (struct passed by ref in wrapper) */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &rightBottom /* [in,ref] ::cli::drawing::CPoint  rightBottom  (struct passed by ref in wrapper) */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &arcStart /* [in,ref] ::cli::drawing::CPoint  arcStart  (struct passed by ref in wrapper) */
                                         , const STRUCT_CLI_DRAWING_CPOINT    &arcEnd /* [in,ref] ::cli::drawing::CPoint  arcEnd  (struct passed by ref in wrapper) */
                                         , BOOL    direction /* [in] bool  direction  */
                                         )
                       {
                    
                    
                    
                    
                    
                        return pif->drawEllipticArc(&leftTop, &rightBottom, &arcStart, &arcEnd, direction);
                       }
                    

            
            
            }; // class CiDrawContext1Wrapper
            
            typedef CiDrawContext1Wrapper< ::cli::CCliPtr< INTERFACE_CLI_DRAWING_IDRAWCONTEXT1     > >  CiDrawContext1;
            typedef CiDrawContext1Wrapper< ::cli::CFoolishPtr< INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 > >  CiDrawContext1_nrc; /* No ref counting for interface used */
            typedef CiDrawContext1Wrapper< ::cli::CFoolishPtr< INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 > >  CiDrawContext1_tmp; /* for temporary usage, same as CiDrawContext1_nrc */
            
            
            
            
            
        }; // namespace drawing
    }; // namespace cli

#endif





#endif /* CLI_DRAWING_DC1_H */
