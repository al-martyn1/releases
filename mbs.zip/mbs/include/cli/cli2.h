#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLI2_H
#define CLI_CLI2_H

/* Add next lines to your C/C++ code
#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif
*/

#ifndef CLI_EMBED_H
    #include <cli/embed.h>
#endif

#ifdef CLI_MONOLITHIC
    #ifndef CLI_MONOLITH
        #define CLI_MONOLITH
    #endif
#endif

#ifdef CLI_MONOLITH
    #ifndef CLI_MONOLITHIC
        #define CLI_MONOLITHIC
    #endif
#endif


#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_CLI2CI_H
    #include <cli/cli2ci.h>
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    #if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
        #include <exception>
    #endif

    #if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
        #include <stdexcept>
    #endif

#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#if !defined(CLI_INTERNAL) && !defined(CLI_INTERNAL_DONT_LINK_CLI_LIB)
    #ifdef _MSC_VER
        #if !defined(CLI_MONOLITHIC) && !defined(CLI_MONOLITH)
            //#pragma message("not CLI_MONOLITHIC nor CLI_MONOLITH defined")
            #pragma comment( lib, "cli2" )
        #else
            //#pragma message("CLI_MONOLITHIC or CLI_MONOLITH defined")
            #pragma comment( lib, "cli2m" )
            // cli2tls required for windows monolithic configurations
            #pragma comment( lib, "cli2tls" )
        #endif
    #endif
#endif

#if defined(_UNICODE) || defined(UNICODE)
    #define CLI_MODULE_INFO_CACHE_SUFFIX   L".cli"
#else
    #define CLI_MODULE_INFO_CACHE_SUFFIX    ".cli"
#endif

#define CLI_MODULE_INFO_CACHE_SUFFIX_LEN 4





#if defined(CLI_MONOLITHIC) || defined(CLI_MONOLITH)
    #define CLIAPIENTRY
#else
    #if defined(CLI_INTERNAL) // used to compile cli itself
        #define CLIAPIENTRY MODULE_EXPORT_FUNC
    #else
        #define CLIAPIENTRY MODULE_IMPORT_FUNC
    #endif
#endif

#ifdef CLI_MONOLITHIC

EXTERN_CLI
CLIAPIENTRY
UINT
CLICALL
cliInitMonolithic( BYTE * componentDbBuf, SIZE_T bufSize);

#endif

EXTERN_CLI
CLIAPIENTRY
UINT
CLICALL
cliInit( );


/*! return number of processors */
EXTERN_CLI
CLIAPIENTRY
ULONG
CLICALL
cliGetNumOfSystemProcessors( );

EXTERN_CLI
CLIAPIENTRY
ULONG
CLICALL
cliGetNumOfCliProcessors( );

/*! return 0 for use single processor mode, !0 for multiprocessor mode
    defualt strategy is based on cliGetNumOfCliProcessors result, but an be overriden by cli settings
*/
EXTERN_CLI
CLIAPIENTRY
BOOL
CLICALL
cliGetMpStrategy( );


EXTERN_CLI
CLIAPIENTRY
VOID
CLICALL
cliWriteLogStringC( const CHAR *str);

EXTERN_CLI
CLIAPIENTRY
VOID
CLICALL
cliWriteLogStringW( const WCHAR *str);

EXTERN_CLI
CLIAPIENTRY
VOID
CLICALL
cliSetLogFileName( const TCHAR *logFileName);

#if defined(_UNICODE) || defined(UNICODE)
    #define cliWriteLogString cliWriteLogStringW
#else
    #define cliWriteLogString cliWriteLogStringC
#endif

// legacy method
EXTERN_CLI
CLIAPIENTRY
GENERIC_OBJ_PTR
CLICALL
cli_create( CHAR const * componentId
          , CHAR const * interfaceId
          , CLI_IUNKNOWN_PTR outer
          );

// legacy method
EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliCreateObject( CHAR const * componentId
               , CHAR const * interfaceId
               , CLI_IUNKNOWN_PTR outer
               , GENERIC_OBJ_PTR *pRes
               );

/* return 0 if categoryIdx out of range
   if categoryNameBuf is 0
      return buf size required for category name, including termanating zero
      bufSize ignored
   if categoryNameBuf != 0
      copy category name to categoryNameBuf up to bufSize chars, return number of copied chars
 */

/* Deprecated, use /cli/component-manager instead */
CLI_DEPRECATED(
                EXTERN_CLI
                CLIAPIENTRY
                SIZE_T
                CLICALL
                cliEnumComponentCategories( CHAR const * componentId
                                          , SIZE_T categoryIdx
                                          , SIZE_T bufSize
                                          , CHAR *categoryNameBuf
                                          )
              );

CLI_DEPRECATED(
                EXTERN_CLI
                CLIAPIENTRY
                SIZE_T
                CLICALL
                cliGetComponentDecsription( CHAR const * componentId
                                          , const WCHAR* requestedLang
                                          , BOOL         findExactLang
                                          , SIZE_T bufSize
                                          , WCHAR *componentDescriptionBuf
                                          )
              );

/* Deprecated, use /cli/component-manager instead */
/* same as prev, but enums all categories */
CLI_DEPRECATED(
                EXTERN_CLI
                CLIAPIENTRY
                SIZE_T
                CLICALL
                cliEnumCategories( SIZE_T categoryIdx
                                 , SIZE_T bufSize
                                 , CHAR *categoryNameBuf
                                 )
              );

/* return 0 if componentIdx out of range
   if componentNameBuf is 0
      return buf size required for component name, including termanating zero
      bufSize ignored
   if componentNameBuf != 0
      copy component name to componentNameBuf up to bufSize chars, return number of copied chars
 */
/* Deprecated, use /cli/component-manager instead */
CLI_DEPRECATED(
                EXTERN_CLI
                CLIAPIENTRY
                SIZE_T
                CLICALL
                cliEnumCategoryComponents( CHAR const * categoryId
                                         , SIZE_T componentIdx
                                         , SIZE_T bufSize
                                         , CHAR *componentNameBuf
                                         )
              );

#ifndef CLI_EMBEDDED

EXTERN_CLI
CLIAPIENTRY
BOOL
CLICALL
cliMatchMaskC( const CHAR * name, const CHAR * mask );

EXTERN_CLI
CLIAPIENTRY
BOOL
CLICALL
cliMatchMaskCI( const CHAR * name, const CHAR * mask );

EXTERN_CLI
CLIAPIENTRY
BOOL
CLICALL
cliMatchMaskW( const WCHAR * name, const WCHAR * mask );

EXTERN_CLI
CLIAPIENTRY
BOOL
CLICALL
cliMatchMaskWI( const WCHAR * name, const WCHAR * mask );

#endif /* CLI_EMBEDDED */


#ifdef CLI_MONOLITHIC
EXTERN_CLI
CLIAPIENTRY
UINT
CLICALL
cliRegisterModule( CHAR const *moduleId
                 , cliEnumModuleComponentsProcT enumProc
                 , cli_create_proc_t legacyCreateProc
                 , CliCreateProcT createProc
                 );
#endif



#define MACHINE_SPEED_VERY_SLOW         0
#define MACHINE_SPEED_SLOW              1
#define MACHINE_SPEED_ABOVE_SLOW        2
#define MACHINE_SPEED_MEDIUM            3
#define MACHINE_SPEED_ABOVE_MEDIUM      4
#define MACHINE_SPEED_HIGH              5
#define MACHINE_SPEED_ABOVE_HIGH        6
#define MACHINE_SPEED_VERY_HIGH         7
//#define MACHINE_SPEED_

EXTERN_CLI
CLIAPIENTRY
DWORD
CLICALL
cliGetMachineSpeed( );


// CLI_INTERNAL

#endif /* CLI_CLI2_H */

