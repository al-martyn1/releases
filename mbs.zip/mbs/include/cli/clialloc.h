#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

/* Add next lines to your C/C++ code
#ifndef CLI_CLIALLOC_H
    #include <cli/clialloc.h>
#endif
*/


#ifndef CLI_CLIALLOC_H
#define CLI_CLIALLOC_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_IALLOCATOR_H
    #include <cli/iallocator.h>
#endif


EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliCreateAllocator( INTERFACE_CLI_IALLOCATOR ** piAllocator );

EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliCreateFastAllocator( INTERFACE_CLI_IALLOCATOR ** piAllocator );

EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliGetAllocator( INTERFACE_CLI_IALLOCATOR ** piAllocator );

#if defined(__cplusplus) && !defined(CINTERFACE)
namespace cli{

inline INTERFACE_CLI_IALLOCATOR* getAllocator()
   {
     INTERFACE_CLI_IALLOCATOR *pa = 0;
     cliGetAllocator( &pa );
     return pa;
   }


};
#endif

#endif /* CLI_CLIALLOC_H */

