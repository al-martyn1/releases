#ifndef CLI_INTERLOCKED_H
#define CLI_INTERLOCKED_H

/*
#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif
*/

#ifndef CLI_DETECTTARGET_H
    #include <cli/detectTarget.h>
#endif

//MACHINE_UNKNOWN

#if defined(WIN32) || defined(_WIN32)
    
    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif

    #define CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDCOMPAREEXCHANGE
    #define CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDEXCHANGEADD
    #define CLI__PLATFORM_REQUIRE_ATOMIC_CMPSET_INT
    #define CLI__PLATFORM_REQUIRE_ATOMIC_FETCHADD_INT

#else

    #ifndef _SYS_CDEFS_H_
        #include <sys/cdefs.h>
    #endif

    #ifndef _SYS_TYPES_H_
        #include <sys/types.h>
    #endif

#endif



#if defined(CLI__PLATFORM_REQUIRE_ATOMIC_CMPSET_INT) || defined(CLI__PLATFORM_REQUIRE_ATOMIC_FETCHADD_INT)
    #if defined(FREEBSD)
        #ifndef _MACHINE_ATOMIC_H_
            #include <machine/atomic.h>
        #endif
        #define CLI__PLATFORM_HAS_NATIVE_ATOMIC_CMPSET_INT
        #define CLI__PLATFORM_HAS_NATIVE_ATOMIC_FETCHADD_INT
    #endif
#endif


#if !defined(CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDCOMPAREEXCHANGE) && !defined(CLI__PLATFORM_HAS_NATIVE_ATOMIC_CMPSET_INT)
    #if defined(MACHINE_X86)
        // we can implement theese functions
        //#define CLI_HAS_SAFE_INTERLOCKED_FUNCTIONS
        //#define CLI__PLATFORM_REQUIRE_ATOMIC_CMPSET_INT_OWN_IMPLEMENTATION
        //#define CLI__PLATFORM_REQUIRE_ATOMIC_FETCHADD_INT_OWN_IMPLEMENTATION
    #else
        //#define CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
        //#define CLI_UNSAFE_INTERLOCKED_FUNCTIONS
    #endif
#endif



//defined(LINUX) && defined(MACHINE_ARM)
// http://ru.wikipedia.org/wiki/%D0%A1%D1%80%D0%B0%D0%B2%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5_%D1%81_%D0%BE%D0%B1%D0%BC%D0%B5%D0%BD%D0%BE%D0%BC


#if defined(WIN32) 

    typedef LONG            ilint_t;
    #if defined(_MSC_VER) // MSVC
        #define ILVOLATILE      volatile
    #else // MinGW, other compilers with old headers
        #define ILVOLATILE
    #endif

#elif defined(FREEBSD)

    typedef u_int           ilint_t;
    #define ILVOLATILE      volatile

#elif defined(MACHINE_X86)

    // platform has u_int
    typedef u_int           ilint_t;
    #define ILVOLATILE      volatile

#else // generic unsafe implementation

    typedef unsigned int    ilint_t;
    #define ILVOLATILE      volatile

#endif



#if defined(_MSC_VER) && _MSC_VER<=1200
    #pragma warning( push )
    #pragma warning( disable : 4786 ) // identifier was truncated to '255' characters
    #pragma warning( disable : 4503 ) // decorated name length exceeded, name was truncated
#endif


#if !defined(CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDCOMPAREEXCHANGE) && !defined(CLI__PLATFORM_HAS_NATIVE_ATOMIC_CMPSET_INT)
    #if defined(MACHINE_X86)
        #if defined(__GNUC__)
            // http://gcc.gnu.org/onlinedocs/gcc-4.3.3/gcc/Atomic-Builtins.html#Atomic-Builtins
        
            #ifndef __STRING
                #define __STRING(x) #x      /* stringify without expanding x */
            #endif
        
            #ifndef __XSTRING
                #define __XSTRING(x)    __STRING(x) /* expand x, then stringify */
            #endif
        
            #ifndef MPLOCKED
                #define MPLOCKED    lock ;
            #endif

            static __inline int
            atomic_cmpset_int(volatile u_int *dst, u_int exp, u_int src)
            {
                int res = exp;
            
                __asm __volatile (
                "   " __XSTRING(MPLOCKED) " "
                "   cmpxchgl %2,%1 ;    "
                "       setz    %%al ;      "
                "   movzbl  %%al,%0 ;   "
                "1:             "
                "# atomic_cmpset_int"
                : "+a" (res),           /* 0 (result) */
                  "=m" (*dst)           /* 1 */
                : "r" (src),            /* 2 */
                  "m" (*dst)            /* 3 */
                : "memory");
            
                return (res);
            }

            static __inline u_int
            atomic_fetchadd_int(volatile u_int *p, u_int v)
            {
            
                __asm __volatile (
                "   " __XSTRING(MPLOCKED) " "
                "   xaddl   %0, %1 ;    "
                "# atomic_fetchadd_int"
                : "+r" (v),         /* 0 (result) */
                  "=m" (*p)         /* 1 */
                : "m" (*p));            /* 2 */
            
                return (v);
            }

            #define CLI__PLATFORM_HAS_NATIVE_ATOMIC_CMPSET_INT
            #define CLI__PLATFORM_HAS_NATIVE_ATOMIC_FETCHADD_INT

        #else


        #endif // __GNUC__

        // we can implement theese functions
        
        //#define CLI__PLATFORM_REQUIRE_ATOMIC_CMPSET_INT_OWN_IMPLEMENTATION
        //#define CLI__PLATFORM_REQUIRE_ATOMIC_FETCHADD_INT_OWN_IMPLEMENTATION

    #else // !MACHINE_X86

    #endif
#endif



#if defined(CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDCOMPAREEXCHANGE) || defined(CLI__PLATFORM_HAS_NATIVE_ATOMIC_CMPSET_INT)
    #define CLI_HAS_SAFE_INTERLOCKED_FUNCTIONS
#else
    #define CLI_NO_SAFE_INTERLOCKED_FUNCTIONS
    #define CLI_UNSAFE_INTERLOCKED_FUNCTIONS
#endif

//--------------------------------------------------------------
// The interlockedCompareExchange function performs an atomic comparison of the 
// *dst value with the comperand value. If the *dst value is equal to the Comperand 
// value, the exchg value is stored in the address specified by Destination. 
// Otherwise, no operation is performed.
// if *dst==comperand *dst = exchg; return 1
// else               return 0;


//static 
inline
ilint_t interlockedCompareExchange(ilint_t ILVOLATILE *dst, ilint_t exchg, ilint_t comperand)
   {
    #if defined(CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDCOMPAREEXCHANGE)
        if (::InterlockedCompareExchange( dst, exchg, comperand)==comperand)  return 1;
        else                                                                  return 0;
    #elif defined(CLI__PLATFORM_HAS_NATIVE_ATOMIC_CMPSET_INT)
        return ::atomic_cmpset_int(dst, comperand, exchg);
    #else
        if (*dst==comperand) { *dst = exchg; return 1; }
        return 0;
    #endif    
   }
//--------------------------------------------------------------
// The InterlockedExchangeAdd function performs an atomic addition of addval to 
// the value pointed to by dst. The result is stored in the address specified 
// by dst. The function returns the initial value of the variable pointed 
// to by dst is returned as the function value.
//static 
inline
ilint_t interlockedExchangeAdd(ilint_t ILVOLATILE *dst, ilint_t addval)
{
    #if defined(CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDEXCHANGEADD)
        return ::InterlockedExchangeAdd(dst, addval);
    #elif defined(CLI__PLATFORM_HAS_NATIVE_ATOMIC_FETCHADD_INT)
        return ::atomic_fetchadd_int(dst, addval);
    #else
        ilint_t retVal = *dst; *dst += addval; return retVal;
    #endif
}

//--------------------------------------------------------------
// return incremented value
//static 
inline 
ilint_t interlockedIncrement(ilint_t ILVOLATILE *dst)
{
    // Win32 - ::InterlockedIncrement( dst );
    #if defined(CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDEXCHANGEADD) || defined(CLI__PLATFORM_HAS_NATIVE_ATOMIC_FETCHADD_INT)
    return interlockedExchangeAdd(dst, 1) + 1;
    #else
    *dst += 1; return *dst;
    #endif
}

//--------------------------------------------------------------
// return decremented value
//static 
inline 
ilint_t interlockedDecrement(ilint_t ILVOLATILE *dst)
{
    // Win32 - ::InterlockedDecrement( dst );
    #if defined(CLI__PLATFORM_HAS_NATIVE_INTERLOCKEDEXCHANGEADD) || defined(CLI__PLATFORM_HAS_NATIVE_ATOMIC_FETCHADD_INT)
    return interlockedExchangeAdd(dst, (ilint_t)(-1l)) - 1l;
    #else
    *dst -= 1; return *dst;
    #endif
}




#if defined(_MSC_VER) && _MSC_VER<=1200
    #pragma warning( pop )
#endif


#endif /* CLI_INTERLOCKED_H */

