#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_SPINCSEC_H
#define CLI_SPINCSEC_H

/* add this lines to your src
#ifndef CLI_SPINCSEC_H
    #include <cli/spincsec.h>
#endif
*/
// $


#ifndef CLI_YIELD_H
    #include <cli/yield.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif


#if defined(_MSC_VER) && _MSC_VER<=1200
    #pragma warning( push )
    #pragma warning( disable : 4786 ) // identifier was truncated to '255' characters
    #pragma warning( disable : 4503 ) // decorated name length exceeded, name was truncated
#endif


namespace cli
{

#if defined(WIN32) || defined(_WIN32)
    typedef BOOL (WINAPI *SwitchToThreadFnPtrType)( VOID );
    // Kernel32.dll
#endif


class CSpinCountingBase
{
    protected:

        unsigned                           spinCount;
        bool                               forceUniprocessorHost;

    private:
        static const unsigned              defaultSpinCount    = 4000;
        #if defined(WIN32) || defined(_WIN32)
        HMODULE                            hKernelModule;
        SwitchToThreadFnPtrType            SwitchToThreadFnPtr;
        #endif

    protected:

        unsigned getSpinCount() const { return spinCount; }

        void  setSpinCount(unsigned cnt)
           {
            if (forceUniprocessorHost) cnt = 0;
            else if (!cnt)             cnt = defaultSpinCount;
            spinCount = cnt;
           }

        void sleep() const
           {
            #if defined(WIN32) || defined(_WIN32)
            if (SwitchToThreadFnPtr) SwitchToThreadFnPtr();
            else                     ::cli::sched::yield();
            #else
            ::cli::sched::yield();
            #endif
           }

    public:

        CSpinCountingBase( unsigned _spinCount = 0
                         , bool _forceUniprocessorHost = false
                         )
           : spinCount(0)
           , forceUniprocessorHost(_forceUniprocessorHost)
           #if defined(WIN32) || defined(_WIN32)
           , hKernelModule(0)
           , SwitchToThreadFnPtr(0)
           #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            hKernelModule = ::GetModuleHandleA( "Kernel32.dll" );
            if (hKernelModule)
               {
                SwitchToThreadFnPtr = (SwitchToThreadFnPtrType) ::GetProcAddress( hKernelModule, "SwitchToThread" );
               }
            #endif

            #ifndef CLI_CSEC_DONT_USE_CLI_RUNTIME
            if (!forceUniprocessorHost)
               {
                forceUniprocessorHost = cliGetMpStrategy()==0;
               }
            #endif
            setSpinCount(_spinCount);
           }
};



class CCriticalSectionBase : public CSpinCountingBase
{

        #if defined(WIN32) || defined(_WIN32)
        typedef unsigned    tid_t;
        #else
        typedef pthread_t   tid_t;
        #endif

    protected:

        //unsigned              spinCount;
        ILVOLATILE ilint_t    lockCount;
        int                   recurseCount;
        tid_t                 ownerTid;
        //bool                  forceUniprocessorHost;

        //static const unsigned              defaultSpinCount    = 4000;
        #if defined(WIN32) || defined(_WIN32)
        static const unsigned              defaultSleepPeriod  = 0;
        #else
        static const unsigned              defaultSleepPeriod  = 25;
        #endif

        /*
        #if defined(WIN32) || defined(_WIN32)
        HMODULE                            hKernelModule;
        SwitchToThreadFnPtrType            SwitchToThreadFnPtr;
        #endif
        */

    public:

        //unsigned getSpinCount() const { return spinCount; }

        // in cli internal code (when cli is not initialized properly) use
        // constructor with forceSingleCpu = true, this disallows to call
        // cliGetMpStrategy cli syscall and prevents possible recursion
        // In user code default arg shall be used for using cli information
        // about multiprocessor strategy

        CCriticalSectionBase( unsigned argSpinCount = 0
                            , bool forceSingleCpu = false
                            )
           : CSpinCountingBase(argSpinCount, forceSingleCpu)
           //  spinCount(0)
           , lockCount(0)
           , recurseCount(0)
           , ownerTid(0)
           /*
           , forceUniprocessorHost(forceSingleCpu)
           #if defined(WIN32) || defined(_WIN32)
           , hKernelModule(0)
           , SwitchToThreadFnPtr(0)
           #endif
           */
           {
            /*
            #if defined(WIN32) || defined(_WIN32)
            //hKernelModule = ::LoadLibraryA("Kernel32.dll");
            // don't need to free handle, and I'm sure that Kernel32.dll will alwais be in memory
            hKernelModule = ::GetModuleHandleA( "Kernel32.dll" );
            if (hKernelModule)
               {
                SwitchToThreadFnPtr = (SwitchToThreadFnPtrType) ::GetProcAddress( hKernelModule, "SwitchToThread" );
               }

            #endif

            #ifndef CLI_CSEC_DONT_USE_CLI_RUNTIME
            if (!forceUniprocessorHost)
               {
                forceUniprocessorHost = cliGetMpStrategy()==0;
               }
            #endif
            setSpinCount(argSpinCount);
            */
           }

        ~CCriticalSectionBase()
           {
            if (ownerTid)
               {
                #if (defined(WIN32) || defined(_WIN32)) && defined(_DEBUG)
                ::DebugBreak();
                #else
                throw ::std::runtime_error("~CCriticalSectionBase - can't destory non-released object");
                #endif
               }
           }


    private:
        // copy not allowed
        CCriticalSectionBase(const CCriticalSectionBase &c) {}
        CCriticalSectionBase& operator=(const CCriticalSectionBase &c) { return *this; }

    protected:

        tid_t getThreadId() const
           {
            #if defined(WIN32) || defined(_WIN32)
            return ::GetCurrentThreadId();
            #else
            return ::pthread_self();
            #endif
           }

        bool  tryLock(unsigned tryCount) const
           {
            CCriticalSectionBase* ncThis = const_cast<CCriticalSectionBase*>(this);
            tid_t tid = getThreadId();

            bool thisThreadOwner = false;
            unsigned cnt = tryCount;
            do{
               // if lockCount is zero, we get ownership for this object
               thisThreadOwner = (interlockedCompareExchange( &(ncThis->lockCount), 1, 0) != 0);

               if (thisThreadOwner)
                  { // successfully owned
                   ncThis->ownerTid     = tid;
                   ncThis->recurseCount = 1;
                  }
               else if (ownerTid==tid)
                  { // if we allready owns this csec
                   interlockedIncrement(&(ncThis->lockCount));
                   ncThis->recurseCount++;
                   thisThreadOwner = true;
                  }
              } while (!thisThreadOwner && (cnt-- > 0) );

            return thisThreadOwner;
           }

};



class CCriticalSectionSleepDriven : public CCriticalSectionBase
{

    protected:

        //CCriticalSectionSleepDriven(const CCriticalSectionSleepDriven &c) {}
        CCriticalSectionSleepDriven& operator=(const CCriticalSectionSleepDriven &c) { return *this; }

    public:

        CCriticalSectionSleepDriven( unsigned argSpinCount = 0
                                   , bool forceSingleCpu = false
                                   )
           : CCriticalSectionBase(argSpinCount, forceSingleCpu)
           { }

        // CS state not copied
        // use this constructor only for initializing CS with specific
        // spin count and uniprocessor host flags
        CCriticalSectionSleepDriven(const CCriticalSectionSleepDriven &cs)
           : CCriticalSectionBase(cs.spinCount, cs.forceUniprocessorHost)
           {}


        bool tryLock() const
           {
            return CCriticalSectionBase::tryLock(getSpinCount());
           }

        void lock()    const
           {
            if (CCriticalSectionBase::tryLock(getSpinCount())) return;
            do{
               sleep();
              } while(!CCriticalSectionBase::tryLock(0));
           }

        void unlock()  const
           {
            CCriticalSectionSleepDriven* ncThis = const_cast<CCriticalSectionSleepDriven*>(this);

            if (ownerTid!=getThreadId())
               {
                #if (defined(WIN32) || defined(_WIN32)) && defined(_DEBUG)
                ::DebugBreak();
                #else
                throw ::std::runtime_error("CCriticalSectionSleepDriven::unlock - failed to unlock, current thread is not an owner of critical section");
                #endif
               }

            if (--(ncThis->recurseCount) <=0 )
               {
                ncThis->ownerTid = 0;
               }
            interlockedDecrement(&(ncThis->lockCount));
           }

}; // CCriticalSectionSleepDriven


};// namespace cli



#endif /* CLI_SPINCSEC_H */

