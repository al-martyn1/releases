#ifndef CLI_CLIERR_H
#define CLI_CLIERR_H

//  This file used in two ways.
//  Normaly it is used by compiler and macro DECLARE_CLI_ERROR produces next code:
//      const RCODE id = code ;
//  
//  if this file used to build message file, cpp preprocessor used with 
//  defined macro BUILD_MSG and preprocessor produces next:
//  code message
//  
//  line 
//     DECLARE_CLI_ERROR(EC_UNKNOWN     , 0xC0000000, "Unknown error")
//  produces 
//     const RCODE EC_UNKNOWN = 0xC0000000 ;
//  or 
//     0xC0000000 "Unknown error"
//  depending on macro BUILD_MSG defined or not
//  
//  This is used to build code and message resource file from one source
//  
//  Next windows cmd-shell produces message resource file
// ----------------------------------------------------------
//     rem Borland/CodeGear preprocessor used - cpp32
//     rem It is possible to use another preprocessor
//     rem test cpp32 -I.. -D_WIN32 clierr.h
//     rem -P- - turns off source lines info
//     rem Codegear preprocessor puts output into clierr.i file
//     cpp32 -P- -DBUILD_MSG clierr.h
//     if not exist clierr.i (
//         echo FAIL: making msg file from C-header failed - preprocessor error
//         exit /b 1
//     )
//     rem creating or clearing file cli.msg
//     echo #cli.msg - error codes messages > cli2.msg
//         rem � ���������� i - ����
//         rem � ���������� j - ��������
//         rem �� ����������� ��� � ���� cli.msg
//     for /f "usebackq eol=# tokens=1,2*" %%i in (clierr.i) do (
//         echo %%i %%j %%k>> cli2.msg
//     )
//     
//     del clierr.i
//     
//     exit /b 0
// ----------------------------------------------------------


#ifndef BUILD_MSG

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

/* RCODE represents error (result) codes, also it can be used for formatting application messages */
/* we use windows error coding scheme with some exception */

//  Original scheme
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|       Facility        |               Code            |
//  +---+-+-+-----------------------+-------------------------------+

//  Our scheme
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-------+---------------+-------------------------------+
//  |Sev|C|R| Src   |   Facility    |               Code            |
//  +---+-+-+-------+---------------+-------------------------------+

// Windows reserves 12 bits for facility - 4096 values,
// but this range not used at all. 
// We cut 4 most bits for source indicator, in most cases this not conflicts with
// windows HRESULT/NTSTATUS codes


#define EC_SEVERITY_MASK            0xC0000000    /* 11 */
#define EC_SEVERITY_SUCCESS         0x00000000    /* 00 */
#define EC_SEVERITY_DEBUG           EC_SEVERITY_SUCCESS
#define EC_SEVERITY_INFORMATIONAL   0x40000000    /* 01 */
#define EC_SEVERITY_WARNING         0x80000000    /* 10 */
#define EC_SEVERITY_ERROR           0xC0000000    /* 11 */

#define EC_CUSTOM_FLAG              0x20000000
#define EC_RESERVED_FLAG            0x10000000

#define EC_SOURCE_MASK              0x0F000000    
#define EC_SOURCE_GENERIC           0x0F000000    
#define EC_SOURCE_CLI               0x00000000    /* Native cli codes */
#define EC_SOURCE_COM               0x01000000    /* COM HRESULT */
#define EC_SOURCE_WIN32             0x02000000    /* Win32 API error code */
#define EC_SOURCE_POSIX             0x03000000    /* UNIX/POSIX/crt error code */
#define EC_SOURCE_NATIVE            0x04000000    /* Native subsystem on embedded platforms */

#define EC_SOURCE_UNKNOWN           0x0F000000


#define EC_CODE_MASK                0x0000FFFF    
#define EC_GENERIC_USER_ERROR_CODE  0x0000FFFF    
#define EC_USER_CODE_MASK           0x00008000    
#define EC_USER_CODE                0x00008000    

#define EC_FACILITY_MASK            0x00FF0000    
#define EC_FACILITY_GENERIC         0x00FF0000
#define EC_FACILITY_UNKNOWN         0x00FF0000
#define EC_FACILITY_NULL            0x00000000
#define EC_FACILITY_CXX             0x00010000    /* C++ exceptions */
#define EC_FACILITY_NETWORK         0x00020000
#define EC_FACILITY_SOCKET          0x00020000
#define EC_FACILITY_RESOLVER        0x00020000
#define EC_FACILITY_SERIALIZATION   0x00030000    /* Serialization subsystem, e.g XML serialization */
#define EC_FACILITY_EXTERNAL        0x00040000    /* external program result */
#define EC_FACILITY_DOCUMENTS       0x00050000    /* document processing */

// #define EC_FACILITY_*            /* other facilities not defined now */


/* HRESULT to cli RCODE */
#define HR2RC(hr)       (((hr)&(~EC_SOURCE_MASK))|EC_SOURCE_COM)
#define RC2HR(rc)       ((rc)&(~EC_SOURCE_MASK))

/* Win32 error code to cli RCODE */
#define WIN2RC(err)     ((!(err)) ? 0 : EC_SEVERITY_ERROR | EC_SOURCE_WIN32 | ((err)&0xFFFF))
#define RC2WIN(err)     ((err)&0xFFFF)

/* Posix error code to cli RCODE */
#define POSIX2RC(err)   ((!(err)) ? 0 : EC_SEVERITY_ERROR | EC_SOURCE_POSIX | ((err)&0xFFFF))
#define RC2POSIX(err)   ((err)&0xFFFF)


#define DECLARE_CLI_ERROR(id, code, message)   const RCODE id = code ;

#ifndef RC_OK
    #define RC_OK(code)    (((SRCODE)(code)) >=0)
#endif

#ifndef RCOK
    #define RCOK(code)     RC_OK(code)
#endif

#ifndef RC_SUCCESS
    #define RC_SUCCESS(code)     RC_OK(code)
#endif

#ifndef RCSUCCESS
    #define RCSUCCESS(code)      RC_OK(code)
#endif

#ifndef RC_FAIL
    #define RC_FAIL(code)  (((SRCODE)(code)) <0)
#endif

#ifndef RCFAIL
    #define RCFAIL(code)   RC_FAIL(code)
#endif



#else // do BUILD_MSG

#define DECLARE_CLI_ERROR(id, code, message)   code message

#endif /* BUILD_MSG */


/* Error codes definition starts here */


#ifndef BUILD_MSG
    // obsolete constants
    #define CLI_OK                                0
    #define CLI_SUCCESS                           0
    /*
    #define CLI_ERR_UNKNOWN                       0x80000000
    #define CLI_ERR_INVALID_OUT_PTR               0x80000001
    #define CLI_ERR_UNKNOWN_INTERFACE             0x80000002
    #define CLI_ERR_INVALID_PARAM                 0x80000003
    */
    /*
    #define EC_OK                                0
    #define EC_SUCCESS                           0
    #define EC_UNKNOWN                           0x80000000
    #define EC_INVALID_OUT_PTR                   0x80000001
    #define EC_UNKNOWN_INTERFACE                 0x80000002
    #define EC_INVALID_PARAM                     0x80000003
    #define EC_RESOURCE_NOT_FOUND                0x80000004
    */
#endif /* BUILD_MSG */



DECLARE_CLI_ERROR(EC_OK                            , 0x00000000, "No error")

#define EC_SUCCESS  EC_OK  /* alias */            
#define EC_CONTINUE EC_OK  /* another alias */            

DECLARE_CLI_ERROR(EC_ALLREADY                      , 0x00000001, "Process allready done, or object allready exist")
// test failed
#define EC_FALSE                                   EC_ALLREADY 
#define EC_CANCEL                                  EC_ALLREADY 


DECLARE_CLI_ERROR(EC_COMMAND_LINE_PARSING_STOPPED  , 0x00000002, "Command line parsing stopped")

// Connection in progress
#define EC_OK_CONNECTION_IN_PROGRESS               EC_ALLREADY 

//EC_ERR_ALLREADY

DECLARE_CLI_ERROR(EC_GENERIC_ERROR                 , 0xFFFFFFFF, "Generic error")
DECLARE_CLI_ERROR(EC_GENERIC_ERROR_NO_FLAGS        , 0xCFFFFFFF, "Generic error")

DECLARE_CLI_ERROR(EC_UNKNOWN_GENERAL               , 0xFFFFFFFF, "Unknown general error")
/*
EC_UNKNOWN_GENERAL = EC_SEVERITY_ERROR 
                   | EC_CUSTOM_FLAG 
                   | EC_RESERVED_FLAG 
                   | EC_SOURCE_UNKNOWN 
                   | EC_FACILITY_UNKNOWN 
                   | 0x0000FFFF;
EC_UNKNOWN_GENERAL == (RCODE)-1
*/

#ifndef PFS_ERR_UNKNOWN
    #define PFS_ERR_UNKNOWN  EC_UNKNOWN_GENERAL
#endif


DECLARE_CLI_ERROR(EC_UNKNOWN                       , 0xC0000000, "Unknown error")
DECLARE_CLI_ERROR(EC_INVALID_OUT_PTR               , 0xC0000001, "Invalid argument - invalid out pointer")
DECLARE_CLI_ERROR(EC_UNKNOWN_INTERFACE             , 0xC0000002, "Unknown (unsupported) interface")
DECLARE_CLI_ERROR(EC_INVALID_PARAM                 , 0xC0000003, "Invalid parameter %1 (%2)")

/* define aliases for old code support */
#define CLI_ERR_UNKNOWN                            EC_UNKNOWN
#define CLI_ERR_INVALID_OUT_PTR                    EC_INVALID_OUT_PTR
#define CLI_ERR_UNKNOWN_INTERFACE                  EC_UNKNOWN_INTERFACE
#define CLI_ERR_INVALID_PARAM                      EC_INVALID_PARAM

DECLARE_CLI_ERROR(EC_RESOURCE_NOT_FOUND            , 0xC0000004, "Resource (message or string) not found")
DECLARE_CLI_ERROR(EC_FORMAT_ERR_UNKN_CODE_SRC      , 0xC0000005, "Unknown code source field value in RCODE")
DECLARE_CLI_ERROR(EC_FORMAT_ERR_UNAVAIL_TEXT       , 0xC0000006, "Message text is unavailable on this platform")
DECLARE_CLI_ERROR(EC_NO_DATA                       , 0xC0000007, "Requested data unavailable")
DECLARE_CLI_ERROR(EC_NO_ERROR_INFO                 , 0xC0000008, "There is no extended error information available")
DECLARE_CLI_ERROR(EC_NO_MEM                        , 0xC0000009, "There is no memory to perform requested operation")
DECLARE_CLI_ERROR(EC_DIALOG_FAIL                   , 0xC000000A, "Failed to create dialog or gui object")
DECLARE_CLI_ERROR(EC_NOT_IMPLEMENTED               , 0xC000000B, "Method not implemented")
DECLARE_CLI_ERROR(EC_INVALID_IOSTREAM_NAME         , 0xC000000C, "Invalid stream name: '%1'")
DECLARE_CLI_ERROR(EC_UNKNOWN_IOSTREAM_TYPE         , 0xC000000D, "Unknown IO stream type: '%1' (stream name: '%2')")
DECLARE_CLI_ERROR(EC_IOSTREAM_OPEN_FAILED          , 0xC000000E, "Open '%1' stream failed, system failure")
DECLARE_CLI_ERROR(EC_OPERATION_GENERIC_ERROR       , 0xC000000F, "Error occured while performing requested operation")
DECLARE_CLI_ERROR(EC_IOSTREAM_UNKNOWN_OPTION       , 0xC0000010, "Unknown option '%1' taken (stream name: '%2')")
DECLARE_CLI_ERROR(EC_IOSTREAM_INVALID_OPTVAL       , 0xC0000011, "Invalid option '%1' value '%3' taken (stream name: '%2')")
DECLARE_CLI_ERROR(EC_IOSTREAM_OPT_MULTIPLE         , 0xC0000012, "Option '%1' taken multiple times (stream name: '%2')")
DECLARE_CLI_ERROR(EC_IOSTREAM_INVALID_OPENMODE     , 0xC0000013, "Invalid open mode '%1' taken (stream name: '%2')")
DECLARE_CLI_ERROR(EC_IOSTREAM_INVALID_PATH         , 0xC0000014, "Invalid stream path '%1' taken (stream name: '%2')")
DECLARE_CLI_ERROR(EC_IOSTREAM_ALLREADY_OPENED      , 0xC0000015, "Stream allready opened (stream name: '%2')")

DECLARE_CLI_ERROR(EC_SERIAL_INVALID_BAUD           , 0xC0000016, "Invalid baud value: '%1'")
DECLARE_CLI_ERROR(EC_SERIAL_BAUD_NOT_SUPPORTED     , 0xC0000017, "Taken baud rate '%1' not supported on this system")
DECLARE_CLI_ERROR(EC_SERIAL_INVALID_PARITY         , 0xC0000018, "Invalid parity value: '%1'")
DECLARE_CLI_ERROR(EC_SERIAL_INVALID_DATABITS       , 0xC0000019, "Invalid data bits value: '%1'")
DECLARE_CLI_ERROR(EC_SERIAL_INVALID_STOPBITS       , 0xC000001A, "Invalid stop bits value: '%1'")
DECLARE_CLI_ERROR(EC_SERIAL_INVALID_DEVICE_NAME    , 0xC000001B, "Invalid device name: '%1'")
DECLARE_CLI_ERROR(EC_SERIAL_INVALID_INTERNAL_DEVICE_NAME, 0xC000001C, "Invalid internal device name, check CLI_IO_SERIAL_DEVICE_NAME, CLI_IO_SERIAL_DEVICE_DISPLAY_NAME and CLI_IO_SERIAL_DEVICENO_ADD environment variables (stream name: '%2')")
DECLARE_CLI_ERROR(EC_SERIAL_INVALID_HANDLE         , 0xC000001D, "Invalid device handle")
DECLARE_CLI_ERROR(EC_ABORTED                       , 0xC000001E, "Aborted by user")
#define EC_ABORT  EC_ABORTED
DECLARE_CLI_ERROR(EC_COMPONENT_NOT_FOUND           , 0xC000001F, "Component '%1' not found")
DECLARE_CLI_ERROR(EC_NOT_SUPPORTED                 , 0xC0000020, "Feature not supported")
DECLARE_CLI_ERROR(EC_BROKEN_STREAM                 , 0xC0000021, "Invalid (broken) IO stream")
DECLARE_CLI_ERROR(EC_PARTIALLY_SENT                , 0xC0000022, "Data was partially sent")
DECLARE_CLI_ERROR(EC_NOT_ENOUGH_MEM                , 0xC0000023, "Not enough memory")
DECLARE_CLI_ERROR(EC_EOF                           , 0xC0000024, "End of file encountered")
DECLARE_CLI_ERROR(EC_INVALID_DATA                  , 0xC0000025, "Invalid data taken")
DECLARE_CLI_ERROR(EC_IOSTREAM_NOT_READABLE         , 0xC0000026, "Stream not readable")
DECLARE_CLI_ERROR(EC_IOSTREAM_NOT_WRITEABLE        , 0xC0000027, "Stream not writeable")
DECLARE_CLI_ERROR(EC_OUT_OF_RANGE                  , 0xC0000028, "Index out of range")
DECLARE_CLI_ERROR(EC_TIMED_OUT                     , 0xC0000029, "Operation timed out")
DECLARE_CLI_ERROR(EC_CANCELED                      , 0xC000002A, "The (blocking) call was canceled through signal/event")
// #define EC_CANCEL EC_CANCELED
DECLARE_CLI_ERROR(EC_TLS_FAIL                      , 0xC000002B, "System error - thread local storage initialization failed")
DECLARE_CLI_ERROR(EC_NO_DATA_FOR_READING           , 0xC000002C, "No data for reading")
DECLARE_CLI_ERROR(EC_NO_REPLY                      , 0xC000002D, "No reply from server or device")
DECLARE_CLI_ERROR(EC_NOT_FOUND                     , 0xC000002E, "Not found")
DECLARE_CLI_ERROR(EC_NO_SUCH_FILE                  , 0xC000002F, "No such file, stream or device")
DECLARE_CLI_ERROR(EC_FILE_IN_USE                   , 0xC0000030, "File, device or stream allready in use (pid: %1)")
DECLARE_CLI_ERROR(EC_NO_SERIAL_SERVER              , 0xC0000031, "No such serial server (type: %1, address: %2)")
DECLARE_CLI_ERROR(EC_NO_PORT_ON_SERVER             , 0xC0000032, "No such port on the serial server (port: %1, total ports on server: %2, server model: %3)")
DECLARE_CLI_ERROR(EC_BAD_SERVER_REPLY              , 0xC0000033, "Invalid reply from the serial server (server model: %1, %2 bytes len reply: %3)")
DECLARE_CLI_ERROR(EC_SKIP                          , 0xC0000034, "Current action must be skipped")
DECLARE_CLI_ERROR(EC_STACK_OVERFLOW                , 0xC0000035, "Stack overflow")
DECLARE_CLI_ERROR(EC_STACK_UNDERFLOW               , 0xC0000036, "Stack underflow")
DECLARE_CLI_ERROR(EC_NO_OBJECT                     , 0xC0000037, "Object is missing")
DECLARE_CLI_ERROR(EC_TEST_FAILED                   , 0xC0000038, "Test failed")
DECLARE_CLI_ERROR(EC_INVALID_OBJECT_STATE          , 0xC0000039, "Object is in invalid state")
DECLARE_CLI_ERROR(EC_INCOMPATIBLE_OBJECT           , 0xC000003A, "Object has incompatible type (possible different underlaying subsystem)")
DECLARE_CLI_ERROR(EC_NO_OWNER                      , 0xC000003B, "There is no owner for this object")
DECLARE_CLI_ERROR(EC_INVALID_OBJECT_PTR            , 0xC000003C, "Object pointer is invalid or null")
DECLARE_CLI_ERROR(EC_NO_SLAVE                      , 0xC000003D, "There is no slave object")
DECLARE_CLI_ERROR(EC_NO_SUCH_OBJECT                , 0xC000003E, "No such function, object or component")
DECLARE_CLI_ERROR(EC_OUT_OF_LIMIT                  , 0xC000003F, "Value is out of it's limit")
DECLARE_CLI_ERROR(EC_INVALID_FORMAT                , 0xC0000040, "Invalid format")

DECLARE_CLI_ERROR(EC_COMMAND_UNKNOWN               , 0xC0000041, "Unknown (unregistered) command")
DECLARE_CLI_ERROR(EC_COMMAND_DISABLED              , 0xC0000042, "Failed to call command cause it is disabled")
DECLARE_CLI_ERROR(EC_COMMAND_NO_HANDLER            , 0xC0000043, "Failed to call command cause it has no handler (zero handler)")
DECLARE_CLI_ERROR(EC_COMMAND_INVALID_NAME          , 0xC0000044, "Invalid command name")
DECLARE_CLI_ERROR(EC_MENU_UNKNOWN                  , 0xC0000045, "Unknown menu")
DECLARE_CLI_ERROR(EC_RADIOGROUP_UNKNOWN            , 0xC0000046, "Unknown radiogroup")
#define           EC_COMMAND_INVOKED                 EC_OK  /* alias */
#define           EC_COMMAND_OK                      EC_OK  /* another alias */

DECLARE_CLI_ERROR(EC_ERR_ALLREADY                  , 0xC0000047, "Allready exist")
DECLARE_CLI_ERROR(EC_DELEGATION_FAILED             , 0xC0000048, "Delegation failed cause interface pointer is null")

DECLARE_CLI_ERROR(EC_NO_MORE_DATA                  , 0xC0000049, "No more data")
DECLARE_CLI_ERROR(EC_NO_MORE_RECORDS               , 0xC000004A, "No more records")
DECLARE_CLI_ERROR(EC_INVALID_COMMAND_LINE          , 0xC000004B, "Invalid command line")

DECLARE_CLI_ERROR(EC_IOSTREAM_IO_ERROR             , 0xC000004C, "Error reading/writing from/to file/stream")
#define           EC_IO_ERROR                      EC_IOSTREAM_IO_ERROR

DECLARE_CLI_ERROR(EC_COMMAND_LINE_GENERIC_ERR      , 0xC000004D, "Command line generic error")

DECLARE_CLI_ERROR(EC_COMMAND_LINE_BAD_OPTION       , 0xC000004E, "%1: Urecognized option '%2' or option requres value to be taken")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_BAD_OPTION2      , 0xC000004F, "%1: Urecognized option '%2' or option requres value to be taken.%nTry %1 --help for more information")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_BAD_OPTION_CHAR  , 0xC0000050, "%1: Urecognized option '%3' in '%2' or option requres value to be taken")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_BAD_OPTION_CHAR2 , 0xC0000051, "%1: Urecognized option '%3' in '%2' or option requres value to be taken.%nTry %1 --help for more information")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_BAD_OPTION_VALUE , 0xC0000052, "%1: Invalid value '%2' in option '%3'")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_BAD_OPTION_VALUE2, 0xC0000053, "%1: Invalid value '%2' in option '%3'.%nTry %1 --help for more information")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_REQUIRE_ARGS     , 0xC0000054, "%1: No input taken")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_REQUIRE_ARGS2    , 0xC0000055, "%1: No input taken.%nTry %1 --help for more information")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_MISSING_MANDATORY_OPTIONS, 0xC0000056, "%1: Missing mandatory options")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_MISSING_MANDATORY_OPTIONS2,0xC0000057, "%1: Missing mandatory options.%nTry %1 --help for more information")

#define EC_COMMAND_LINE_NO_INPUT_TAKEN               EC_COMMAND_LINE_REQUIRE_ARGS
#define EC_COMMAND_LINE_NO_INPUT_TAKEN2              EC_COMMAND_LINE_REQUIRE_ARGS2
#define EC_COMMAND_LINE_NO_INPUT_TAKEN_TRY_HELP      EC_COMMAND_LINE_REQUIRE_ARGS2

DECLARE_CLI_ERROR(EC_RANGE_ERROR                   , 0xC0000058, "Value %1 is out of range")
DECLARE_CLI_ERROR(EC_EOD                           , 0xC0000059, "End of data")
DECLARE_CLI_ERROR(EC_UNEXPECTED_EOD                , 0xC000005A, "Unexpected end of data")
DECLARE_CLI_ERROR(EC_INCONSISTENT_DATA             , 0xC000005B, "Inconsistent data")
DECLARE_CLI_ERROR(EC_INVALID_INPUT_DATA            , 0xC000005C, "Invalid input data")

// dynamic loading errors
DECLARE_CLI_ERROR(EC_INVALID_MODULE                , 0xC000005D, "Invalid dynamic library/shared object")

DECLARE_CLI_ERROR(EC_COMMAND_LINE_REQUIRE_INPUT_FILES,0xC000005E, "No input files taken")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_REQUIRE_INPUT_FILES2,0xC000005F, "No input files taken.%nTry --help for more information")

DECLARE_CLI_ERROR(EC_COMMAND_LINE_ERROR            ,0xC0000060, "Command line error")
DECLARE_CLI_ERROR(EC_COMMAND_LINE_ERROR_TRY_HELP   ,0xC0000061, "Command line error.%nTry --help for more information")

#define EC_COMMAND_LINE_BAD_OPTION_TRY_HELP                EC_COMMAND_LINE_BAD_OPTION2
#define EC_COMMAND_LINE_BAD_OPTION_CHAR_TRY_HELP           EC_COMMAND_LINE_BAD_OPTION_CHAR2
#define EC_COMMAND_LINE_BAD_OPTION_VALUE_TRY_HELP          EC_COMMAND_LINE_BAD_OPTION_VALUE2
#define EC_COMMAND_LINE_REQUIRE_ARGS_TRY_HELP              EC_COMMAND_LINE_REQUIRE_ARGS2
#define EC_COMMAND_LINE_MISSING_MANDATORY_OPTIONS_TRY_HELP EC_COMMAND_LINE_MISSING_MANDATORY_OPTIONS2
#define EC_COMMAND_LINE_REQUIRE_INPUT_FILES_TRY_HELP       EC_COMMAND_LINE_REQUIRE_INPUT_FILES2


DECLARE_CLI_ERROR(EC_CONFIGURATION_NOT_FOUND       ,0xC0000062, "Configuration not found.%nSee documentation for more details")
DECLARE_CLI_ERROR(EC_MISCONFIGURED                 ,0xC0000063, "Missconfigured")
DECLARE_CLI_ERROR(EC_MISCONFIGURED_SEE_DOCS        ,0xC0000064, "Missconfigured. See description for '%1' value in documentation")


DECLARE_CLI_ERROR(EC_NOT_OBJECT                   , 0xC0000065, "Not an object")
DECLARE_CLI_ERROR(EC_NOT_INITIALIZED              , 0xC0000066, "Object not initialized properly")
DECLARE_CLI_ERROR(EC_COMPONENT_MODULE_NOT_FOUND   , 0xC0000067, "Component '%1' module for not found")
DECLARE_CLI_ERROR(EC_COMPONENT_MODULE_NO_ENTRY    , 0xC0000068, "Component '%1' module - no entry point")
DECLARE_CLI_ERROR(EC_COMPONENT_CREATION_FAILED    , 0xC0000069, "Component '%1' creation failed - module does't contain requested component or component doesn't support requested interface")

DECLARE_CLI_ERROR(EC_INVALID_PTR                  , 0xC000006A, "Pointer is not a valid part of the user address space")
DECLARE_CLI_ERROR(EC_NO_MORE_DESCRIPTORS          , 0xC000006B, "No more system descriptors available")
DECLARE_CLI_ERROR(EC_NO_MORE_BUFS                 , 0xC000006C, "No more buffer space is available")
DECLARE_CLI_ERROR(EC_WOULD_BLOCK                  , 0xC000006D, "Operation on nonblocking descriptor cannot be completed immediately")
DECLARE_CLI_ERROR(EC_UNSUPPORTED_OPTION           , 0xC000006E, "Unsupported flag/option taken")
DECLARE_CLI_ERROR(EC_INVALID_ARG                  , 0xC000006F, "An invalid argument was supplied")

DECLARE_CLI_ERROR(EC_NOT_CLI_MODULE               , 0xC0000070, "Not a CLI module")
DECLARE_CLI_ERROR(EC_TRIAL_EXPIRED                , 0xC0000071, "Trial period expired")

DECLARE_CLI_ERROR(EC_NO_VALID_INPUT               , 0xC0000072, "No valid input taken")



// XML serialization errors

#define           EC_XML_OK                        EC_OK  /* another alias for EC_OK */

/* PUGIXML errors mapping */

#define           EC_FILE_NOT_FOUND                EC_NO_SUCH_FILE
#define           EC_IO_ERROR                      EC_IOSTREAM_IO_ERROR
// #define           EC_NOT_ENOUGH_MEM             /* Use as is, no alias */

// PUGIXML-specific errors mapping
DECLARE_CLI_ERROR(EC_XML_INTERNAL_ERROR            , 0xC0030001, "Serialization engine internal error")
DECLARE_CLI_ERROR(EC_XML_UNKNOWN_ERROR             , 0xC0030002, "Serialization engine unknown error")
DECLARE_CLI_ERROR(EC_XML_BAD_TAG                   , 0xC0030003, "Parser could not determine tag type or tag name is empty")
DECLARE_CLI_ERROR(EC_XML_BAD_PI                    , 0xC0030004, "Parsing error occured while parsing document declaration/processing instruction (<?...?>)")
DECLARE_CLI_ERROR(EC_XML_BAD_COMMENT               , 0xC0030005, "Parsing error occured while parsing comment (<!--...-->)")
DECLARE_CLI_ERROR(EC_XML_BAD_CDATA                 , 0xC0030006, "Parsing error occured while parsing CDATA section (<![CDATA[...]]>)")
DECLARE_CLI_ERROR(EC_XML_BAD_DOCTYPE               , 0xC0030007, "Parsing error occured while parsing document type declaration")
DECLARE_CLI_ERROR(EC_XML_BAD_PCDATA                , 0xC0030008, "Parsing error occured while parsing PCDATA section (>...<)")
DECLARE_CLI_ERROR(EC_XML_BAD_START_ELEMENT         , 0xC0030009, "Parsing error occured while parsing start element tag (<name ...>)")
DECLARE_CLI_ERROR(EC_XML_BAD_ATTRIBUTE             , 0xC003000A, "Parsing error occured while parsing element attribute")
DECLARE_CLI_ERROR(EC_XML_BAD_END_ELEMENT           , 0xC003000B, "Parsing error occured while parsing end element tag (</name>)")
DECLARE_CLI_ERROR(EC_XML_TAG_MISMATCH              , 0xC003000C, "There was a mismatch of start-end tags (closing tag had incorrect name, some tag was not closed or there was an excessive closing tag)")

// TINYXML-specific errors mapping
DECLARE_CLI_ERROR(EC_XML_BAD_ELEMENT               , 0xC003000D, "Parsing error occured while parsing element")
DECLARE_CLI_ERROR(EC_XML_BAD_ELEMENT_NAME          , 0xC003000E, "Parsing error occured while parsing element name")
DECLARE_CLI_ERROR(EC_XML_BAD_ELEMENT_VALUE         , 0xC003000F, "Parsing error occured while parsing element value")
DECLARE_CLI_ERROR(EC_XML_BAD_DECLARATION           , 0xC0030010, "Parsing error occured while parsing document declaration")
DECLARE_CLI_ERROR(EC_XML_DOCUMENT_EMPTY            , 0xC0030011, "XML document is empty")
DECLARE_CLI_ERROR(EC_XML_UNEXPECTED_END            , 0xC0030012, "Unexpected end of data found")
DECLARE_CLI_ERROR(EC_XML_WRONG_ROOT_TAG            , 0xC0030014, "Wrong root tag")

DECLARE_CLI_ERROR(EC_XML_INVALID_CHAR_REF          , 0xC0030015, "Invalid character reference")
DECLARE_CLI_ERROR(EC_XML_UNKNOW_ENTITY_REF         , 0xC0030016, "Unknown entity reference")
DECLARE_CLI_ERROR(EC_XML_INVALID_DOCUMENT          , 0xC0030017, "Invalid document")
DECLARE_CLI_ERROR(EC_XML_NUM_ATTRS_LIM             , 0xC0030018, "Internal error: number of attributes limit exceed")
DECLARE_CLI_ERROR(EC_XML_BAD_ENTITY_REF            , 0xC0030019, "Invalid symbol in entity reference")
DECLARE_CLI_ERROR(EC_XML_BAD_CHAR_REF              , 0xC0030020, "Invalid symbol in character reference or character code is out of range")

DECLARE_CLI_ERROR(EC_XPATH_INVALID_EXPRESSION      , 0xC0030100, "Invalid XPath expression, error at pos: %1 (line: %2, pos: %3)")
DECLARE_CLI_ERROR(EC_XPATH_UNEXPECTED_END_OF_EXPRESSION, 0xC0030101, "Unexpected end of XPath expression")
DECLARE_CLI_ERROR(EC_XPATH_UNEXPECTED_TOKEN        , 0xC0030102, "Unexpected token (%4) at pos: %1 (line: %2, pos: %3)")
DECLARE_CLI_ERROR(EC_XPATH_UNSUPPORTED_AXIS        , 0xC0030103, "Unsupported axis (%4) at pos: %1 (line: %2, pos: %3)")
DECLARE_CLI_ERROR(EC_XPATH_UNSUPPORTED_FUNCTION    , 0xC0030104, "Unsupported function (%4) at pos: %1 (line: %2, pos: %3)")
DECLARE_CLI_ERROR(EC_XPATH_UNSUPPORTED_OPERATOR    , 0xC0030105, "Unsupported operator (%4) at pos: %1 (line: %2, pos: %3)")
DECLARE_CLI_ERROR(EC_XPATH_FN_WRONG_NUM_OPERANDS   , 0xC0030106, "Wrong number of operands (%5) for function %4 at pos: %1 (line: %2, pos: %3)")
DECLARE_CLI_ERROR(EC_XPATH_OP_WRONG_NUM_OPERANDS   , 0xC0030107, "Wrong number of operands (%5) for operator %4 at pos: %1 (line: %2, pos: %3)")
DECLARE_CLI_ERROR(EC_XPATH_UNEXPECTED_RESULT_SET   , 0xC0030108, "Unexpected result set size, try to use other methods")

DECLARE_CLI_ERROR(EC_XML_HTML_UNKNOWN_ENCODING     , 0xC0030109, "Unknown (unsupported) document encoding: %1")
DECLARE_CLI_ERROR(EC_XML_HTML_UNKNOWN_TAG          , 0xC003010A, "Unknown tag: %1")
DECLARE_CLI_ERROR(EC_XML_HTML_EXPECTED_ATTR_MISSING, 0xC003010B, "Expected attribute is missing: %1")
DECLARE_CLI_ERROR(EC_XML_HTML_EXPECTED_ATTR_EMPTY  , 0xC003010C, "Expected attribute is empty: %1")
DECLARE_CLI_ERROR(EC_XML_HTML_ENCODING_ERROR       , 0xC003010D, "Error encoding the XML/HTML document, encoding: %1")
DECLARE_CLI_ERROR(EC_XML_HTML_EXPECTED_TAG         , 0xC003010E, "Unexpected tag: %1")
DECLARE_CLI_ERROR(EC_XML_HTML_UNEXPECTED_SINGLE_TAG, 0xC0030110, "Unexpected single tag found where form of open/close (<tag>...</tag>) tag pair expected: %1")
DECLARE_CLI_ERROR(EC_XML_HTML_UNEXPECTED_PAIR_TAG  , 0xC0030111, "Unexpected pair tag found where form of single (<tag/>) tag expected: %1")

// DECLARE_CLI_ERROR(EC_          , 0xC003000D, "Invalid command line")






#define EC_RESOLV_SUCCESS   EC_OK
DECLARE_CLI_ERROR(EC_RESOLV_TRY_AGAIN              , 0xC0020001, "Temporary failure in name resolution - non-authoritative host not found, or name server failure")
DECLARE_CLI_ERROR(EC_RESOLV_HOST_NOT_FOUND         , 0xC0020002, "Host not found")
DECLARE_CLI_ERROR(EC_RESOLV_NO_DATA                , 0xC0020003, "Valid name, but no data record of requested type")
DECLARE_CLI_ERROR(EC_RESOLV_NO_RECOVERY            , 0xC0020004, "Non-recoverable error in name resolution")
DECLARE_CLI_ERROR(EC_RESOLV_INVALID_ADDR           , 0xC0020005, "Invalid address")

DECLARE_CLI_ERROR(EC_CONNECTION_CLOSED             , 0xC0020006, "Connection closed by peer")
DECLARE_CLI_ERROR(EC_INVALID_SOCKET                , 0xC0020007, "Invalid socket handle")
DECLARE_CLI_ERROR(EC_INVALID_PORT                  , 0xC0020008, "Invalid port or service name")
#define EC_INVALID_SERV  EC_INVALID_PORT
DECLARE_CLI_ERROR(EC_INVALID_SERV_PROTO            , 0xC0020009, "Invalid port/service name and/or protocol (%1/%2)")
DECLARE_CLI_ERROR(EC_IN_PROGRESS                   , 0xC002000A, "Connection in progress")
DECLARE_CLI_ERROR(EC_INVALID_AF                    , 0xC002000B, "Invalid address family")

DECLARE_CLI_ERROR(EC_INVALID_METHOD                , 0xC002000C, "Invalid method: %1")

DECLARE_CLI_ERROR(EC_RPC_FAULT                     , 0xC002000D, "Remote procedure call (XML-RPC, SOAP, etc) generic error")

DECLARE_CLI_ERROR(EC_NOT_CONNECTED                 , 0xC002000E, "The socket is not connected")
DECLARE_CLI_ERROR(EC_INVALID_SOCK_ADDR             , 0xC002000F, "Invalid socket address. The name or the namelen parameter is not a valid part of the user address space, or the namelen parameter is too small")
DECLARE_CLI_ERROR(EC_SOCK_NOT_BOUND                , 0xC0020010, "The socket has not been bound to an address with bind, or ADDR_ANY is specified in bind but connection has not yet occurred")
DECLARE_CLI_ERROR(EC_CONNECTION_RESET              , 0xC0020011, "An incoming connection was indicated, but was subsequently terminated by the remote peer prior to accepting the call")
DECLARE_CLI_ERROR(EC_NET_DOWN                      , 0xC0020012, "The network subsystem has failed")
DECLARE_CLI_ERROR(EC_SOCKETS_NOT_INITIALIZED       , 0xC0020013, "The sockets subsystem not initialized")
DECLARE_CLI_ERROR(EC_SOCK_ADDR_IN_USE              , 0xC0020014, "The socket address allready in use (see the SO_REUSEADDR socket option under setsockopt)")
DECLARE_CLI_ERROR(EC_SOCK_NOT_BROADCAST            , 0xC0020015, "Attempt to connect datagram socket to broadcast address failed because setsockopt option SO_BROADCAST is not enabled")
DECLARE_CLI_ERROR(EC_SOCK_OP_NOT_SUPP              , 0xC0020016, "Operation not supported on this socket")
DECLARE_CLI_ERROR(EC_SOCK_ADDR_NOT_AVAIL           , 0xC0020017, "The specified address is not a valid address for computer")
DECLARE_CLI_ERROR(EC_SOCK_MSG_SIZE                 , 0xC0020018, "The message was too large to fit into the buffer pointed to by the buf parameter and was truncated")
DECLARE_CLI_ERROR(EC_SOCK_INVALID_TYPE             , 0xC0020019, "The specified socket type is not supported in this address")
DECLARE_CLI_ERROR(EC_SOCK_INVALID_PROTO            , 0xC002001A, "The specified protocol is not supported")
DECLARE_CLI_ERROR(EC_SOCK_INVALID_TYPE_PROTO       , 0xC002001B, "The specified protocol is the wrong type for this socket")
DECLARE_CLI_ERROR(EC_SOCK_NET_RESET                , 0xC002001C, "The connection has timed out when SO_KEEPALIVE is set")
DECLARE_CLI_ERROR(EC_SOCK_INVALID_PROTO_OPT        , 0xC002001D, "The option is unknown or unsupported for the specified provider or socket")
DECLARE_CLI_ERROR(EC_SOCK_ALLREADY_CONNECTED       , 0xC002001E, "The socket is already connected")
DECLARE_CLI_ERROR(EC_SOCK_ALLREADY_BOUND           , 0xC002001F, "The socket is already bound to an address")
DECLARE_CLI_ERROR(EC_SOCK_LISTEN_FIRST             , 0xC0020020, "The listen must be called first for this socket")
DECLARE_CLI_ERROR(EC_CONNECTION_REFUSED            , 0xC0020021, "The attempt to connect was forcefully rejected")
DECLARE_CLI_ERROR(EC_SOCK_IS_LISTENING             , 0xC0020022, "The taken socket is a listening socket")
DECLARE_CLI_ERROR(EC_SOCK_UNREACH_NET              , 0xC0020023, "The network cannot be reached from this host at this time")
DECLARE_CLI_ERROR(EC_SOCK_UNREACH_HOST             , 0xC0020024, "A socket operation was attempted to an unreachable host")
DECLARE_CLI_ERROR(EC_SOCK_SHUTTED_DOWN             , 0xC0020025, "The socket has been shut down")
DECLARE_CLI_ERROR(EC_CONNECTION_ABORTED            , 0xC0020026, "The virtual circuit was terminated due to a time-out or other failure. The application should close the socket as it is no longer usable")
DECLARE_CLI_ERROR(EC_SOCK_ADDR_REQUIRED            , 0xC0020027, "A destination address is required")
DECLARE_CLI_ERROR(EC_SOCK_NO_PORT                  , 0xC0020028, "Address is valid, but there is no port taken")



DECLARE_CLI_ERROR(EC_HTTP_ERROR_BASE                            , 0xC0021000, "HTTP 000 - Result base")
// 100
DECLARE_CLI_ERROR(EC_HTTP_ERROR_CONT                            , 0xC0021064, "HTTP 100 - Continue")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_SWITCHING                       , 0xC0021065, "HTTP 101 - Switching Protocols")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_PROCESSING                      , 0xC0021066, "HTTP 102 - Processing")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NAME_NOT_RESOLVED               , 0xC0021067, "HTTP 103 - Name Not Resolved")
// 200
DECLARE_CLI_ERROR(EC_HTTP_ERROR_OK                              , 0xC00210C8, "HTTP 200 - Ok")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_CREATED                         , 0xC00210C9, "HTTP 201 - Created")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_ACCEPTED                        , 0xC00210CA, "HTTP 202 - Accepted")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NON_AUTH_INFO                   , 0xC00210CB, "HTTP 203 - Non-authoritative Information")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NO_CONTENT                      , 0xC00210CC, "HTTP 204 - No Content")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_RESET_CONTENT                   , 0xC00210CD, "HTTP 205 - Reset Content")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_PARTIAL_CONTENT                 , 0xC00210CE, "HTTP 206 - Partial Content")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_MULTI_STATUS                    , 0xC00210CF, "HTTP 207 - Multi-Status")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_IM_USED                         , 0xC00210E2, "HTTP 226 - IM Used")
// 300
DECLARE_CLI_ERROR(EC_HTTP_ERROR_MULTIPLE_CHOISES                , 0xC002112C, "HTTP 300 - Multiple Choices")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_MOVED_PERMANENTLY               , 0xC002112D, "HTTP 301 - Moved Permanently")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_MOVED_TEMPORARILY               , 0xC002112E, "HTTP 302 - Moved Temporarily")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_SEE_OTHER                       , 0xC002112F, "HTTP 303 - See Other")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NOT_MODIFIED                    , 0xC0021130, "HTTP 304 - Not Modified")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_USE_PROXY                       , 0xC0021131, "HTTP 305 - Use Proxy")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_UNUSED306                       , 0xC0021132, "HTTP 306 - Unused")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_TEMPORARY_REDIRECT              , 0xC0021133, "HTTP 307 - Temporary Redirect")
// 400
DECLARE_CLI_ERROR(EC_HTTP_ERROR_BAD_REQUEST                     , 0xC0021190 , "HTTP 400 - Bad Request")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_UNAUTHORIZED                    , 0xC0021191 , "HTTP 401 - Unauthorized")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_PAYMENT_REQUIRED                , 0xC0021192 , "HTTP 402 - Payment Required")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_FORBIDDEN                       , 0xC0021193 , "HTTP 403 - Forbidden")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NOT_FOUND                       , 0xC0021194 , "HTTP 404 - Not Found")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_METHOD_NOT_ALLOWED              , 0xC0021195 , "HTTP 405 - Method Not Allowed")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NOT_ACCEPTABLE                  , 0xC0021196 , "HTTP 406 - Not Acceptable")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_PROXY_AUTHENTIFICATION_REQUIRED , 0xC0021197 , "HTTP 407 - Proxy Authentication Required")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_REQUEST_TIMEOUT                 , 0xC0021198 , "HTTP 408 - Request Timeout")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_CONFLICT                        , 0xC0021199 , "HTTP 409 - Conflict")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_GONE                            , 0xC002119A , "HTTP 410 - Gone")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_LENGTH_REQUIRED                 , 0xC002119B , "HTTP 411 - Length Required")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_PRECONDITION_FAILED             , 0xC002119C , "HTTP 412 - Precondition Failed")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_REQUEST_ENTITY_TOO_LARGE        , 0xC002119D , "HTTP 413 - Request Entity Too Large")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_REQUEST_URL_TOO_LONG            , 0xC002119E , "HTTP 414 - Request-url Too Long")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_UNSUPPORTED_MEDIA_TYPE          , 0xC002119F , "HTTP 415 - Unsupported Media Type")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_REQUESTED_RANGE_NOT_SATISFIABLE , 0xC00211A0 , "HTTP 416 - Requested Range Not Satisfiable ")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_EXPECTATION_FAILED              , 0xC00211A1 , "HTTP 417 - Expectation Failed")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_IM_A_TEAPOT                     , 0xC00211A2 , "HTTP 418 - I'm a teapot")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_UNPROCESSABLE_ENTITY            , 0xC00211A6 , "HTTP 422 - Unprocessable Entity")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_LOCKED                          , 0xC00211A7 , "HTTP 423 - Locked")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_FAILED_DEPENDENCY               , 0xC00211A8 , "HTTP 424 - Failed Dependency")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_UNORDERED_COLLECTION            , 0xC00211A9 , "HTTP 425 - Unordered Collection")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_UPGRADE_REQUIRED                , 0xC00211AA , "HTTP 426 - Upgrade Required")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_PRECONDITION_REQUIRED           , 0xC00211AC , "HTTP 428 - Precondition Required")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_TOO_MANY_REQUESTS               , 0xC00211AD , "HTTP 429 - Too Many Requests")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_REQUEST_HEADER_FIELDS_TOO_LARGE , 0xC00211AF , "HTTP 431 - Request Header Fields Too Large")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_REQUESTED_HOST_UNAVAILABLE      , 0xC00211B2 , "HTTP 434 - Requested host unavailable")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_RETRY_WITH                      , 0xC00211C1 , "HTTP 449 - Retry With")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_UNAVAILABLE_FOR_LEGAL_REASONS   , 0xC00211C3 , "HTTP 451 - Unavailable For Legal Reasons")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_UNRECOVERABLE_ERROR             , 0xC00211C8 , "HTTP 456 - Unrecoverable Error")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NGINX_SPECIFIC                  , 0xC00211F3 , "HTTP 499 - NGNIX")
// 500
DECLARE_CLI_ERROR(EC_HTTP_ERROR_INTERNAL_SERVER_ERROR           , 0xC00211F4 , "HTTP 500 - Internal Server Error")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NOT_IMPLEMENTED                 , 0xC00211F5 , "HTTP 501 - Not Implemented")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_BAD_GATEWAY                     , 0xC00211F6 , "HTTP 502 - Bad Gateway")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_SERVICE_UNAVAILABLE             , 0xC00211F7 , "HTTP 503 - Service Unavailable")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_GATEWAY_TIMEOUT                 , 0xC00211F8 , "HTTP 504 - Gateway Timeout")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_HTTP_VERSION_NOT_SUPPORTED      , 0xC00211F9 , "HTTP 505 - HTTP Version Not Supported")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_VARIANT_ALSO_NEGOTIATES         , 0xC00211FA , "HTTP 506 - Variant Also Negotiates")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_INSUFFICIENT_STORAGE            , 0xC00211FB , "HTTP 507 - Insufficient Storage")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_LOOP_DETECTED                   , 0xC00211FC , "HTTP 508 - Loop Detected")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_BANDWIDTH_LIMIT_EXCEEDED        , 0xC00211FD , "HTTP 509 - Bandwidth Limit Exceeded")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NOT_EXTENDED                    , 0xC00211FE , "HTTP 510 - Not Extended")
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NETWORK_AUTHENTICATION_REQUIRED , 0xC00211FF , "HTTP 511 - Network Authentication Required")

// 600
DECLARE_CLI_ERROR(EC_HTTP_ERROR_NEXT_GROUP                      , 0xC0021258 , "HTTP 600 - Next code group (undefined)")

//DECLARE_CLI_ERROR(EC_HTTP_ERROR_                   , 0xC0021   , "HTTP - ")

DECLARE_CLI_ERROR(EC_CXX_UNKNOWN                   , 0xC0010000, "There was an unknown exception")
DECLARE_CLI_ERROR(EC_CXX_EXCEPTION                 , 0xC0010001, "There was an exception std::exception with message: %1")

/* exception descendants */
DECLARE_CLI_ERROR(EC_CXX_BAD_ALLOC                 , 0xC0010002, "There was an exception std::bad_alloc with message: %1")
DECLARE_CLI_ERROR(EC_CXX_BAD_EXCEPTION             , 0xC0010003, "There was an exception std::bad_exception with message: %1")
DECLARE_CLI_ERROR(EC_CXX_IOS_BASE_FAILURE          , 0xC0010004, "There was an exception std::ios_base::failure with message: %1")
DECLARE_CLI_ERROR(EC_CXX_BAD_TYPEID                , 0xC0010005, "There was an exception std::bad_typeid with message: %1")
DECLARE_CLI_ERROR(EC_CXX_BAD_CAST                  , 0xC0010006, "There was an exception std::bad_cast with message: %1")

/* logic_error and its descendants */
DECLARE_CLI_ERROR(EC_CXX_LOGIC_ERROR               , 0xC0010007, "There was an exception std::logic_error with message: %1")
DECLARE_CLI_ERROR(EC_CXX_LENGTH_ERROR              , 0xC0010008, "There was an exception std::length_error with message: %1")
DECLARE_CLI_ERROR(EC_CXX_DOMAIN_ERROR              , 0xC0010009, "There was an exception std::domain_error with message: %1")
DECLARE_CLI_ERROR(EC_CXX_OUT_OF_RANGE              , 0xC001000A, "There was an exception std::out_of_range with message: %1")
DECLARE_CLI_ERROR(EC_CXX_INVALID_ARGUMENT          , 0xC001000B, "There was an exception std::invalid_argument with message: %1")

/* runtime_error and its descendants */
DECLARE_CLI_ERROR(EC_CXX_RUNTIME_ERROR             , 0xC001000C, "There was an exception std::runtime_error with message: %1")
DECLARE_CLI_ERROR(EC_CXX_RANGE_ERROR               , 0xC001000D, "There was an exception std::range_error with message: %1")
DECLARE_CLI_ERROR(EC_CXX_OVERFLOW_ERROR            , 0xC001000E, "There was an exception std::overflow_error with message: %1")
DECLARE_CLI_ERROR(EC_CXX_UNDERFLOW_ERROR           , 0xC001000F, "There was an exception std::underflow_error with message: %1")
// DECLARE_CLI_ERROR(EC_CXX_                          , 0x00010000, "There was an exception std:: with message: %1")


DECLARE_CLI_ERROR(EC_EXTERNAL_PROGRAM_FAILURE      , 0xC0040000, "External program '%1' failure")



DECLARE_CLI_ERROR(EC_DOCUMENT_EMPTY                , 0xC0050000, "Document is empty")
DECLARE_CLI_ERROR(EC_DOCTYPE_UNDEFINED             , 0xC0050001, "Document type undefined")
DECLARE_CLI_ERROR(EC_DOCTYPE_UNDEFINED_WARN        , 0x80050001, "Document type undefined") // for non-fatal error messages
DECLARE_CLI_ERROR(EC_DOCTYPE_UNKNOWN               , 0xC0050002, "Document type unknown")
DECLARE_CLI_ERROR(EC_DOCTYPE_UNKNOWN_WARN          , 0x80050002, "Document type unknown")   // for non-fatal error messages
DECLARE_CLI_ERROR(EC_DOCTYPE_DETECT_FAILED         , 0xC0050003, "Failed to detect document type")
DECLARE_CLI_ERROR(EC_DOCTYPE_INVALID               , 0xC0050004, "Invalid document type")
DECLARE_CLI_ERROR(EC_DOCTYPE_INVALID_WARN          , 0x80050004, "Invalid document type")
DECLARE_CLI_ERROR(EC_DOCUMENT_UNSUPPORTED_UTF_ENCODING , 0xC0050005, "Unsupported document encoding (UTF-16 or UTF-32)")
DECLARE_CLI_ERROR(EC_DOCUMENT_UNKNOWN_ENCODING     , 0xC0050006, "Unknown encoding: %1")
DECLARE_CLI_ERROR(EC_DOCUMENT_UNKNOWN_ENCODING_WARN, 0x80050006, "Unknown encoding: %1")
DECLARE_CLI_ERROR(EC_DOCUMENT_PARSE_ERR            , 0xC0050007, "Parsing error")
DECLARE_CLI_ERROR(EC_DOCUMENT_UNEXPECTED_END       , 0xC0050008, "Unexpected end of document")
DECLARE_CLI_ERROR(EC_DOCUMENT_ENCODING_ERROR       , 0xC0050009, "Error encoding the document, encoding: %1")

DECLARE_CLI_ERROR(EC_DOCUMENT_ALREADY_INCLUDED     , 0xC005000A, "Document already included: %1")
DECLARE_CLI_ERROR(EC_DOCUMENT_CLASS_NOT_FOUND      , 0xC005000B, "Document class definition not found")

//#define EC_FACILITY_DOCUMENTS                        0x00050000    /* document processing */

//#define EC_SEVERITY_INFORMATIONAL   0x40000000    /* 01 */
//#define EC_SEVERITY_WARNING         0x80000000    /* 10 */




#endif /* CLI_CLIERR_H */


