#if defined(_MSC_VER)
    /* warning C4244: '=' : conversion from 'X' to 'Y', possible loss of data */
    #pragma warning (push)
    #pragma warning( disable:4244 )
#endif

