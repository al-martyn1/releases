#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_APP_APPCONFIG_H
#define CLI_APP_APPCONFIG_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/app/appconfig.h>", CLI_APP_APPCONFIG_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::app::iConfig */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace drawing {
            namespace font {
            }; // namespace font
        }; // namespace drawing
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_APP_ICONFIG_IID
    #define INTERFACE_CLI_APP_ICONFIG_IID    "/cli/app/iConfig"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace app {
    #define INTERFACE iConfig
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_APP_ICONFIG
       #define INTERFACE_CLI_APP_ICONFIG    ::cli::app::iConfig
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_app_iConfig
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_APP_ICONFIG
       #define INTERFACE_CLI_APP_ICONFIG    cli_app_iConfig
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::app::iConfig methods */
                CLIMETHOD(getColor) (THIS_ const CLISTR*     colorId
                                         , ENUM_CLI_DRAWING_DEVICECOLORTYPE    colorType /* [in] ::cli::drawing::DeviceColorType  colorType  */
                                         , COLORREF*    color /* [out] colorref color  */
                                    ) PURE;
                CLIMETHOD(setDefaultColorValue) (THIS_ const CLISTR*     colorId
                                                     , COLORREF    fullColor /* [in] colorref  fullColor  */
                                                     , COLORREF    bwColor /* [in] colorref  bwColor  */
                                                     , COLORREF    monochromeColor /* [in] colorref  monochromeColor  */
                                                ) PURE;
                CLIMETHOD(getString) (THIS_ const CLISTR*     strId
                                          , CLISTR*           str
                                     ) PURE;
                CLIMETHOD(getStringPStr) (THIS_ const CLISTR*     strId
                                              , CLIPSTR*          str
                                         ) PURE;
                CLIMETHOD(setDefaultStringValue) (THIS_ const CLISTR*     strId
                                                      , const CLISTR*     str
                                                 ) PURE;
                CLIMETHOD(setDefaultStringValuePStr) (THIS_ const CLISTR*     strId
                                                          , CLIPSTR           str
                                                     ) PURE;
                CLIMETHOD(getFont) (THIS_ const CLISTR*     fontId
                                        , STRUCT_CLI_DRAWING_FONT_PROPERTIES*    fontProps /* [out] ::cli::drawing::font::Properties fontProps  */
                                   ) PURE;
                CLIMETHOD(setDefaultFontValue) (THIS_ const CLISTR*     fontId
                                                    , const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    fontProps /* [in,ref] ::cli::drawing::font::Properties  fontProps  */
                                               ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace app
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::app::iConfig >
           {
            static char const * getName() { return INTERFACE_CLI_APP_ICONFIG_IID; }
           };
        template<> struct CIidOfImpl< ::cli::app::iConfig* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::app::iConfig > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace app {
            // interface ::cli::app::iConfig wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_APP_ICONFIG >
                                          */
                     >
            class CiConfigWrapper
            {
                public:
            
                    typedef  CiConfigWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiConfigWrapper() :
                       pif(0) {}
            
                    CiConfigWrapper( iConfig *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiConfigWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiConfigWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiConfigWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiConfigWrapper(const CiConfigWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiConfigWrapper()  { }
            
                    CiConfigWrapper& operator=(const CiConfigWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE getColor( const ::std::wstring    &colorId
                                  , ENUM_CLI_DRAWING_DEVICECOLORTYPE    colorType /* [in] ::cli::drawing::DeviceColorType  colorType  */
                                  , COLORREF*    color /* [out] colorref color  */
                                  )
                       {
                        CCliStr tmp_colorId; CCliStr_lightCopyTo( tmp_colorId, colorId);
                    
                    
                        return pif->getColor(&tmp_colorId, colorType, color);
                       }
                    
                    RCODE setDefaultColorValue( const ::std::wstring    &colorId
                                              , COLORREF    fullColor /* [in] colorref  fullColor  */
                                              , COLORREF    bwColor /* [in] colorref  bwColor  */
                                              , COLORREF    monochromeColor /* [in] colorref  monochromeColor  */
                                              )
                       {
                        CCliStr tmp_colorId; CCliStr_lightCopyTo( tmp_colorId, colorId);
                    
                    
                    
                        return pif->setDefaultColorValue(&tmp_colorId, fullColor, bwColor, monochromeColor);
                       }
                    
                    RCODE getString( const ::std::wstring    &strId
                                   , ::std::wstring    &str
                                   )
                       {
                        CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
                        CCliStr tmp_str; CCliStr_init( tmp_str );
                        RCODE res = pif->getString(&tmp_strId, &tmp_str);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( str, tmp_str);
                           }
                        return res;
                       }
                    
                    RCODE getStringPStr( const ::std::wstring    &strId
                                       , ::std::wstring    &str
                                       )
                       {
                        CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
                        CCliPStr tmp_str; CCliPStr_init( tmp_str );
                        RCODE res = pif->getStringPStr(&tmp_strId, &tmp_str);
                        if (RCOK(res))
                           {
                            CCliPStr_copyFromIfModified( str, tmp_str);
                           }
                        return res;
                       }
                    
                    RCODE setDefaultStringValue( const ::std::wstring    &strId
                                               , const ::std::wstring    &str
                                               )
                       {
                        CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
                        CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                        return pif->setDefaultStringValue(&tmp_strId, &tmp_str);
                       }
                    
                    RCODE setDefaultStringValuePStr( const ::std::wstring    &strId
                                                   , ::std::wstring    str
                                                   )
                       {
                        CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
                        CCliPStr tmp_str; CCliPStr_lightCopyTo( tmp_str, str);
                        return pif->setDefaultStringValuePStr(&tmp_strId, tmp_str);
                       }
                    
                    RCODE getFont( const ::std::wstring    &fontId
                                 , STRUCT_CLI_DRAWING_FONT_PROPERTIES    &fontProps /* [out] ::cli::drawing::font::Properties fontProps  (struct passed by ref in wrapper) */
                                 )
                       {
                        CCliStr tmp_fontId; CCliStr_lightCopyTo( tmp_fontId, fontId);
                    
                        return pif->getFont(&tmp_fontId, &fontProps);
                       }
                    
                    RCODE setDefaultFontValue( const ::std::wstring    &fontId
                                             , const STRUCT_CLI_DRAWING_FONT_PROPERTIES    &fontProps /* [in,ref] ::cli::drawing::font::Properties  fontProps  (struct passed by ref in wrapper) */
                                             )
                       {
                        CCliStr tmp_fontId; CCliStr_lightCopyTo( tmp_fontId, fontId);
                    
                        return pif->setDefaultFontValue(&tmp_fontId, &fontProps);
                       }
                    

            
            
            }; // class CiConfigWrapper
            
            typedef CiConfigWrapper< ::cli::CCliPtr< INTERFACE_CLI_APP_ICONFIG     > >  CiConfig;
            typedef CiConfigWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_APP_ICONFIG > >  CiConfig_nrc; /* No ref counting for interface used */
            typedef CiConfigWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_APP_ICONFIG > >  CiConfig_tmp; /* for temporary usage, same as CiConfig_nrc */
            
            
            
            
            
        }; // namespace app
    }; // namespace cli

#endif





#endif /* CLI_APP_APPCONFIG_H */
