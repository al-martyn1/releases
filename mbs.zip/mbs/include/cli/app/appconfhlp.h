#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_APP_APPCONFHLP_H
#define CLI_APP_APPCONFHLP_H

/* Add next lines to your C/C++ code
#ifndef CLI_APP_APPCONFHLP_H
    #include <cli/app/appconfhlp.h>
#endif
*/

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_STRAPI_H
    #include <cli/strapi.h>
#endif

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

namespace cli
   {
    namespace app
       {

        struct CColorTriplet
           {
            COLORREF  blackWhiteColor;  // ::cli::drawing::DeviceColorType::blackWhite
            COLORREF  monochromeColor;  // ::cli::drawing::DeviceColorType::monochrome
            COLORREF  fullColoredColor; // ::cli::drawing::DeviceColorType::fullColored

            COLORREF adjustColor( COLORREF color, bool bMonochrome, int colorBits) const
               {
                return ::cli::drawing::colorUtils::adjustColor( color, bMonochrome, colorBits, 0 );
               }                

            CColorTriplet() : blackWhiteColor(0), monochromeColor(0), fullColoredColor(0) {}
            CColorTriplet(COLORREF fullColor) 
               : blackWhiteColor ( adjustColor(fullColor, true , 2) )
               , monochromeColor ( adjustColor(fullColor, true , 8) )
               , fullColoredColor( fullColor )
               {}
            CColorTriplet(COLORREF fullColor, COLORREF bwColor) 
               : blackWhiteColor ( bwColor )
               , monochromeColor ( adjustColor(fullColor, true , 8) )
               , fullColoredColor( fullColor )
               {}

            CColorTriplet(COLORREF fullColor, COLORREF bwColor, COLORREF monoColor) 
               : blackWhiteColor ( bwColor   )
               , monochromeColor ( monoColor )
               , fullColoredColor( fullColor )
               {}

            COLORREF getColor(DWORD colorType) const
               {                   
                switch(colorType)
                   {
                    case ::cli::drawing::DeviceColorType::fullColored :  return fullColoredColor;
                    case ::cli::drawing::DeviceColorType::monochrome  :  return monochromeColor; 
                    default:                                             return blackWhiteColor; 
                   }
               }
           };


        template <typename Interface_iAppConfig>
        bool getAppColorAux( Interface_iAppConfig *pAppConfig
                        , const ::std::wstring &colorName
                        , DWORD colorType
                        , COLORREF &resColor
                        , const CColorTriplet &defColors
                        )
           {
            if (pAppConfig)
               {
                CCliStr tmp_colorName; CCliStr_lightCopyTo( tmp_colorName, colorName);
                RCODE res = pAppConfig->getColor(&tmp_colorName, colorType, &resColor);
                if (RC_OK(res)) return true;
                pAppConfig->setDefaultColorValue( &tmp_colorName
                                                , defColors.fullColoredColor
                                                , defColors.blackWhiteColor
                                                , defColors.monochromeColor
                                                );
               }
            return false;
           }
           
        template <typename Interface_iAppConfig>
        COLORREF getAppColor( Interface_iAppConfig *pAppConfig
                            , INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc
                            , const ::std::wstring &colorName
                            , const CColorTriplet &defColor /* ::cli::app::CColorTriplet(defaultFullColor, defaultBwColor, defaultMonochromeColor) */
                            )
           {
            DWORD colorType = ::cli::drawing::DeviceColorType::fullColored;
            if (pdc) colorType = pdc->getDeviceColorType();
            COLORREF resColor = 0;
            if (getAppColorAux(pAppConfig, colorName, colorType, resColor, defColor)) return resColor;

            return defColor.getColor(colorType);
           }

        template <typename Interface_iAppConfig>
        ::std::wstring getAppString( Interface_iAppConfig *pAppConfig
                            , const ::std::wstring &strId
                            , const ::std::wstring &defStr
                            )
           {
            if (!pAppConfig) return defStr;

            CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
            CCliStr tmp_str; CCliStr_init( tmp_str );

            RCODE res = pAppConfig->getString(&tmp_strId, &tmp_str);
            if (RC_OK(res)) 
               {
                ::std::wstring resultStr;
                CCliStr_copyFromIfModified( resultStr, tmp_str);
                return resultStr;
               }
            CCliStr_lightCopyTo( tmp_str, defStr);
            pAppConfig->setDefaultStringValue(&tmp_strId, &tmp_str);
            return defStr;
           }

        template <typename Interface_iAppConfig>
        void getAppString( CLIPSTR &pstrDst
                         , Interface_iAppConfig *pAppConfig
                         , const ::std::wstring &strId
                         , const ::std::wstring &defStr
                         )
           {
            INTERFACE_CLI_PSTRINGHELPER* pStrApi = cliGetPStringHelper( );
            CLIASSERT(pStrApi!=0);

            if (!pAppConfig)
               {                
                pStrApi->assign /* Len */ ( &pstrDst, defStr.c_str() /* , defStr.size() */  );
                return;
               }

            CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
            RCODE res = pAppConfig->getStringPStr(&tmp_strId, &pstrDst);
            if (RC_OK(res)) 
               {
                return;
               }

            CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, defStr);
            pAppConfig->setDefaultStringValue(&tmp_strId, &tmp_str);
            pStrApi->assign /* Len */ ( &pstrDst, defStr.c_str() /* , defStr.size() */  );
           }

        template <typename Interface_iAppConfig>
        CLIPSTR getAppPString( Interface_iAppConfig *pAppConfig
                            , const ::std::wstring &strId
                            , const ::std::wstring &defStr
                            )
           {
            INTERFACE_CLI_PSTRINGHELPER* pStrApi = cliGetPStringHelper( );
            CLIASSERT(pStrApi!=0);

            CLIPSTR strRes = 0;
            if (!pAppConfig)
               {                
                pStrApi->alloc /* Len */ ( &strRes, defStr.c_str() /* , defStr.size() */  );
                return strRes;
               }

            CCliStr tmp_strId; CCliStr_lightCopyTo( tmp_strId, strId);
            RCODE res = pAppConfig->getStringPStr(&tmp_strId, &strRes);
            if (RC_OK(res)) 
               {
                return strRes;
               }

            CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, defStr);
            pAppConfig->setDefaultStringValue(&tmp_strId, &tmp_str);
            pStrApi->assign /* Len */ ( &strRes, defStr.c_str() /* , defStr.size() */  );
            return strRes;
           }


        template <typename Interface_iAppConfig>
        void getAppFont( Interface_iAppConfig *pAppConfig
                       , const ::std::wstring &fontId
                       , STRUCT_CLI_DRAWING_FONT_PROPERTIES &fontProps
                       , const STRUCT_CLI_DRAWING_FONT_PROPERTIES &defFontProps
                       )
           {
            fontProps = defFontProps; 
            // appConfig->getFont() can fill not all members, only most significant
            // other properties must be taken by font user
            if (!pAppConfig) 
               {                
                return;
               }

            CCliStr tmp_fontId; CCliStr_lightCopyTo( tmp_fontId, fontId);
            RCODE res = pAppConfig->getFont(&tmp_fontId, &fontProps);
            if (RC_OK(res)) return;

            pAppConfig->setDefaultFontValue(&tmp_fontId, &defFontProps);
            fontProps = defFontProps;
           }

        template <typename Interface_iAppConfig>
        void getAppFont( Interface_iAppConfig *pAppConfig
                       , const ::std::wstring &fontId
                       , STRUCT_CLI_DRAWING_FONT_PROPERTIES &fontProps
                       , FONT_SIZE_T fontSize
                       , const ::std::wstring fontFaceName
                       // ::cli::drawing::font::Family:: dontCare, roman, swiss (sans-serifed), modern, script, decorative
                       , DWORD fontFamily 
                       , DWORD pitch = ::cli::drawing::font::Pitch::useDefault // fixed, variable

                       // ::cli::drawing::font::Weight:: dontCare, extraLight, light, normal, semibold (demibold), bold, extraBold, black
                       , DWORD weight = ::cli::drawing::font::Weight::normal // preffered values - light, normal, bold
                       , DWORD flags  = ::cli::drawing::font::Flags::normal  // italic, underlined
                       // useDefault, noAntialias, preferAntialias, preferDevice, preferRaster, preferOutline, preferMatch, preferQuality
                       , DWORD precision = ::cli::drawing::font::Precision::useDefault
                       )
           {
            STRUCT_CLI_DRAWING_FONT_PROPERTIES defFontProps;
            defFontProps.height = (BYTE)fontSize;
            defFontProps.weight = (BYTE)weight;
            defFontProps.flags  = (BYTE)flags;
            defFontProps.precision = (BYTE)precision;
            defFontProps.pitch  = (BYTE)pitch;
            defFontProps.family = (BYTE)fontFamily;
            defFontProps.reserved = 0;

            ::cli::drawing::font::setupFontFace(defFontProps, fontFaceName);
            getAppFont( pAppConfig, fontId, fontProps, defFontProps );
           }

       }; // namespace app
   }; // namespace cli

#define APP_DEFCOLORS1(defaultFullColor)                                         ::cli::app::CColorTriplet(defaultFullColor)
#define APP_DEFCOLORS2(defaultFullColor, defaultBwColor)                         ::cli::app::CColorTriplet(defaultFullColor, defaultBwColor)
#define APP_DEFCOLORS3(defaultFullColor, defaultBwColor, defaultMonochromeColor) ::cli::app::CColorTriplet(defaultFullColor, defaultBwColor, defaultMonochromeColor)

#endif /* CLI_APP_APPCONFHLP_H */

