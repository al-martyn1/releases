#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_APP_IMPL_APPCONFIGBASE_H
#define CLI_APP_IMPL_APPCONFIGBASE_H

/* Add next lines to your C/C++ code
#ifndef CLI_APP_IMPL_APPCONFIGBASE_H
    #include <cli/app/impl/appconfigbase.h>
#endif
*/

#ifndef CLI_APP_APPCONFIG_H
    #include <cli/app/appconfig.h>
#endif

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif

#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

namespace cli
   {
    namespace app
       {
        namespace impl
           {        
        
            template <typename InterfaceAppConfig = INTERFACE_CLI_APP_ICONFIG >
            struct CAppConfigImplBase : public InterfaceAppConfig
               {
                std::map< ::std::wstring, CColorTriplet>   colors;

                CAppConfigImplBase() : colors() {}
            
                // add colors to map
                void addColor(const ::std::wstring colorName, COLORREF fullColor)
                   { colors[colorName] = CColorTriplet(fullColor); }

                void addColor(const ::std::wstring colorName, COLORREF fullColor, COLORREF bwColor)
                   { colors[colorName] = CColorTriplet(fullColor, bwColor); }

                void addColor(const ::std::wstring colorName, COLORREF fullColor, COLORREF bwColor, COLORREF monoColor)
                   { colors[colorName] = CColorTriplet(fullColor, bwColor, monoColor); }

                // implement interface method
                CLIMETHOD(getColor) (THIS_ const CLISTR*     colorName
                                         , DWORD    colorType /* [in] dword  colorType  */
                                         , COLORREF*    color /* [out] colorref color  */
                                    )
                   {
                    if (!colorName) return CLI_ERR_UNKNOWN;

                    const CCliStr *pCliStr = reinterpret_cast<const CCliStr*>(colorName);
                    ::std::wstring wColorName(*pCliStr);

                    std::map< ::std::wstring, CColorTriplet>::const_iterator cit = colors.find(wColorName);
                    if (cit==colors.end()) return CLI_ERR_UNKNOWN;

                    if (color) *color = cit->second.getColor(colorType);
                    return CLI_OK;
                   }

                CLIMETHOD(setDefaultColorValue) (THIS_ const CLISTR*     colorId
                                                     , COLORREF    fullColor /* [in] colorref  fullColor  */
                                                     , COLORREF    bwColor /* [in] colorref  bwColor  */
                                                     , COLORREF    monochromeColor /* [in] colorref  monochromeColor  */
                                                )
                   {
                    return CLI_OK;
                   }

                CLIMETHOD(getString) (THIS_ const CLISTR*     strId
                                          , CLISTR*           str
                                     )
                   {
                    return CLI_ERR_UNKNOWN;
                   }

                CLIMETHOD(getStringPStr) (THIS_ const CLISTR*     strId
                                              , CLIPSTR*          str
                                         )
                   {
                    return CLI_ERR_UNKNOWN;
                   }

                CLIMETHOD(setDefaultStringValue) (THIS_ const CLISTR*     strId
                                                      , const CLISTR*     str
                                                 )
                   {
                    return CLI_OK;
                   }

                CLIMETHOD(setDefaultStringValuePStr) (THIS_ const CLISTR*     strId
                                                          , CLIPSTR           str
                                                     )
                   {
                    return CLI_OK;
                   }

                CLIMETHOD(getFont) (THIS_ const CLISTR*     fontId
                                        , STRUCT_CLI_DRAWING_FONT_PROPERTIES*    fontProps /* [out] ::cli::drawing::font::Properties fontProps  */
                                   )
                   {
                    return CLI_ERR_UNKNOWN;
                   }

                CLIMETHOD(setDefaultFontValue) (THIS_ const CLISTR*     fontId
                                                    , const STRUCT_CLI_DRAWING_FONT_PROPERTIES*    fontProps /* [in,ref] ::cli::drawing::font::Properties  fontProps  */
                                               )
                   {
                    return CLI_OK;
                   }


               }; // struct CAppConfigImplBase
            
            
            
            
            
            
            
        
        
           }; // namespace impl
       }; // namespace app
   }; // namespace cli



#endif /* CLI_APP_IMPL_APPCONFIGBASE_H */

