#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_ITIMER_H
#define CLI_ITIMER_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/itimer.h>", CLI_ITIMER_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_ITIMER_H
    #include <cli/itimer.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iTimerHandler */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iTimer;
        #ifndef INTERFACE_CLI_ITIMER
            #define INTERFACE_CLI_ITIMER              ::cli::iTimer
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ITIMER_PREDECLARED
    #define INTERFACE_CLI_ITIMER_PREDECLARED
    typedef interface tag_cli_iTimer         cli_iTimer;
    #endif //INTERFACE_CLI_ITIMER
    #ifndef INTERFACE_CLI_ITIMER
        #define INTERFACE_CLI_ITIMER              struct tag_cli_iTimer
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITIMERHANDLER_IID
    #define INTERFACE_CLI_ITIMERHANDLER_IID    "/cli/iTimerHandler"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTimerHandler
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ITIMERHANDLER
       #define INTERFACE_CLI_ITIMERHANDLER    ::cli::iTimerHandler
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTimerHandler
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ITIMERHANDLER
       #define INTERFACE_CLI_ITIMERHANDLER    cli_iTimerHandler
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iTimerHandler methods */
            CLIMETHOD(onTimerEvent) (THIS_ INTERFACE_CLI_ITIMER*    pTimerEventSource /* [in] ::cli::iTimer*  pTimerEventSource  */
                                         , SIZE_T    id /* [in] size_t  id  */
                                    ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTimerHandler >
           {
            static char const * getName() { return INTERFACE_CLI_ITIMERHANDLER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTimerHandler* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTimerHandler > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iTimerHandler wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ITIMERHANDLER >
                                      */
                 >
        class CiTimerHandlerWrapper
        {
            public:
        
                typedef  CiTimerHandlerWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTimerHandlerWrapper() :
                   pif(0) {}
        
                CiTimerHandlerWrapper( iTimerHandler *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTimerHandlerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTimerHandlerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTimerHandlerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTimerHandlerWrapper(const CiTimerHandlerWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTimerHandlerWrapper()  { }
        
                CiTimerHandlerWrapper& operator=(const CiTimerHandlerWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE onTimerEvent( INTERFACE_CLI_ITIMER*    pTimerEventSource /* [in] ::cli::iTimer*  pTimerEventSource  */
                                  , SIZE_T    id /* [in] size_t  id  */
                                  )
                   {
                
                
                    return pif->onTimerEvent(pTimerEventSource, id);
                   }
                

        
        
        }; // class CiTimerHandlerWrapper
        
        typedef CiTimerHandlerWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITIMERHANDLER     > >  CiTimerHandler;
        typedef CiTimerHandlerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITIMERHANDLER > >  CiTimerHandler_nrc; /* No ref counting for interface used */
        typedef CiTimerHandlerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITIMERHANDLER > >  CiTimerHandler_tmp; /* for temporary usage, same as CiTimerHandler_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iTimer */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iTimerHandler;
        #ifndef INTERFACE_CLI_ITIMERHANDLER
            #define INTERFACE_CLI_ITIMERHANDLER       ::cli::iTimerHandler
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ITIMERHANDLER_PREDECLARED
    #define INTERFACE_CLI_ITIMERHANDLER_PREDECLARED
    typedef interface tag_cli_iTimerHandler  cli_iTimerHandler;
    #endif //INTERFACE_CLI_ITIMERHANDLER
    #ifndef INTERFACE_CLI_ITIMERHANDLER
        #define INTERFACE_CLI_ITIMERHANDLER       struct tag_cli_iTimerHandler
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITIMER_IID
    #define INTERFACE_CLI_ITIMER_IID    "/cli/iTimer"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTimer
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ITIMER
       #define INTERFACE_CLI_ITIMER    ::cli::iTimer
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTimer
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ITIMER
       #define INTERFACE_CLI_ITIMER    cli_iTimer
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iTimer methods */
            CLIMETHOD(addTimerHandler) (THIS_ INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                            , SIZE_T    id /* [in] size_t  id  */
                                            , TICK_T    timeout /* [in] tick_t  timeout  */
                                            , BOOL    oneShot /* [in] bool  oneShot  */
                                       ) PURE;
            CLIMETHOD(removeTimerHandler) (THIS_ INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                               , SIZE_T    id /* [in] size_t  id  */
                                          ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTimer >
           {
            static char const * getName() { return INTERFACE_CLI_ITIMER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTimer* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTimer > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iTimer wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ITIMER >
                                      */
                 >
        class CiTimerWrapper
        {
            public:
        
                typedef  CiTimerWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTimerWrapper() :
                   pif(0) {}
        
                CiTimerWrapper( iTimer *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTimerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTimerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTimerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTimerWrapper(const CiTimerWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTimerWrapper()  { }
        
                CiTimerWrapper& operator=(const CiTimerWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE addTimerHandler( INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                     , SIZE_T    id /* [in] size_t  id  */
                                     , TICK_T    timeout /* [in] tick_t  timeout  */
                                     , BOOL    oneShot /* [in] bool  oneShot  */
                                     )
                   {
                
                
                
                
                    return pif->addTimerHandler(pHandler, id, timeout, oneShot);
                   }
                
                RCODE removeTimerHandler( INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                        , SIZE_T    id /* [in] size_t  id  */
                                        )
                   {
                
                
                    return pif->removeTimerHandler(pHandler, id);
                   }
                

        
        
        }; // class CiTimerWrapper
        
        typedef CiTimerWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITIMER     > >  CiTimer;
        typedef CiTimerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITIMER > >  CiTimer_nrc; /* No ref counting for interface used */
        typedef CiTimerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITIMER > >  CiTimer_tmp; /* for temporary usage, same as CiTimer_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_ITIMER_H */
