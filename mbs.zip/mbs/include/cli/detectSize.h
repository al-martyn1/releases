#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

/*
#ifndef CLI_DETECTSIZE_H
    #include <cli/detectSize.h>
#endif
*/

#ifndef CLI_DETECTSIZE_H
#define CLI_DETECTSIZE_H

#if defined(WIN32) || defined(_WIN32)
    #ifndef WIN32
        #define WIN32 _WIN32
    #endif
#endif

// CROSS: http://www.emb-linux.narod.ru/tion-pro-270/building-toolchain.html

/*
CLI_PLATFORM_ADDRESS_SIZE  // in bits
CLI_PLATFORM_BIG_ENDIAN
CLI_PLATFORM_LITTLE_ENDIAN
*/


#ifdef _WIN32

    #if !defined(CLI_PLATFORM_BIG_ENDIAN) && !defined(CLI_PLATFORM_LITTLE_ENDIAN)
        #define CLI_PLATFORM_LITTLE_ENDIAN
    #endif

    #ifdef _WIN64

        #define CLI_PLATFORM_ADDRESS_SIZE     64
        #define CLI_PLATFORM_ADDRESS_SIZE_64

        #define SIZE_T_SIZE     8
        #define SSIZE_T_SIZE    8
        #define SIZEOF_SSIZE_T  8
        #define SIZEOF_SIZE_T   8

    #else

        #define CLI_PLATFORM_ADDRESS_SIZE     32
        #define CLI_PLATFORM_ADDRESS_SIZE_32

        #define SIZE_T_SIZE     4
        #define SSIZE_T_SIZE    4
        #define SIZEOF_SSIZE_T  4
        #define SIZEOF_SIZE_T   4

    #endif

#else

    //UNDONE: detect platform endianess
    #if !defined(CLI_PLATFORM_BIG_ENDIAN) && !defined(CLI_PLATFORM_LITTLE_ENDIAN)
        #define CLI_PLATFORM_LITTLE_ENDIAN
    #endif

    #if (defined(__WORDSIZE) && (__WORDSIZE == 64)) || (defined(_INTEGRAL_MAX_BITS) && (_INTEGRAL_MAX_BITS == 64))

        #define CLI_PLATFORM_ADDRESS_SIZE     64
        #define CLI_PLATFORM_ADDRESS_SIZE_64

        #define SIZE_T_SIZE     8
        #define SSIZE_T_SIZE    8
        #define SIZEOF_SSIZE_T  8
        #define SIZEOF_SIZE_T   8

    #else

        #define CLI_PLATFORM_ADDRESS_SIZE     32
        #define CLI_PLATFORM_ADDRESS_SIZE_32

        #define SIZE_T_SIZE     4
        #define SSIZE_T_SIZE    4
        #define SIZEOF_SSIZE_T  4
        #define SIZEOF_SIZE_T   4

    #endif


#endif


// sizeof(size_t)==SIZEOF_SIZE_T


#endif /* CLI_DETECTSIZE_H */

