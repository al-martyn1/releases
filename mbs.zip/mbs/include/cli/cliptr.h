#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLIPTR_H
#define CLI_CLIPTR_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif


// original code taken from atlcomcli.h
// see discussion on http://rsdn.ru/forum/message/3176138.flat.aspx#3176138 (russian)

#if defined(__cplusplus) && !defined(CINTERFACE)

namespace cli
{

template <typename IF1, typename IF2>
bool isEqualObjects( IF1 *pif1, IF2 *pif2)
   {
    if (pif1==0 || pif2==0) return false; // one or both is zero ptr - zero pointers are not equal at all

    ::cli::iUnknown *punk1 = 0;
    if (pif1->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), (VOID**)&punk1))
       { // failed to query iUnknown
        return false;
       }

    ::cli::iUnknown *punk2 = 0;
    if (pif2->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), (VOID**)&punk2))
       { // failed to query iUnknown
        punk1->release();
        return false;
       }

    bool res = (punk1==punk2);
    punk1->release();
    punk2->release();
    return res;
   }

template <typename IF>
bool isObjectEqualTo( IF *pif1, ::cli::iUnknown *punk)
   {
    if (pif1==0 || punk==0) return false; // one or both is zero ptr - zero pointers are not equal at all

    ::cli::iUnknown *punk1 = 0;
    if (pif1->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), (VOID**)&punk1))
       { // failed to query iUnknown
        return false;
       }

    bool res = (punk1==punk);
    punk1->release();
    return res;
   }

/*
bool isEqualObject(::cli::iUnknown* pOther)
   {
    // They are both NULL objects
    if (p == NULL && pOther == NULL) return true;

    // One is NULL the other is not
    if (p == NULL || pOther == NULL) return false;

    CCliPtrBase< ::cli::iUnknown, ::cli::internal::CDoAddRefRelease<T> > punk1;
    CCliPtrBase< ::cli::iUnknown, ::cli::internal::CDoAddRefRelease<T> > punk2;
    p     ->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), punk1.getVpp() );
    pOther->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), punk2.getVpp() );
    return punk1.get() == punk2.get();
   }
*/



template <typename T>
class _No_addRef_release_onCCliPtr : public T
{
    private:
        CLIMETHOD_(ULONG, addRef)()=0;
        CLIMETHOD_(ULONG, release)()=0;
};



/*
template <typename T>
class CCliPtr;
*/

namespace internal
{

template <typename TRawPtr>
struct CDoAddRefRelease
{
    static const bool queryInterfaceAllowed = true;
    static ULONG doAddRef (TRawPtr *ptr) { return ptr->addRef();  }
    static ULONG doRelease(TRawPtr *ptr) { return ptr->release(); }
    static RCODE doQueryInterface(TRawPtr *ptr, const CHAR* interfaceId, VOID** ifPtr)
       {
        return ptr->queryInterface(interfaceId, ifPtr);
       }

    static RCODE doCreateObject( CHAR const * componentId
                               , CHAR const * interfaceId
                               , CLI_IUNKNOWN_PTR outer
                               , void** ptrPtr  )
       {
        return cliCreateObject(componentId, interfaceId, outer, ptrPtr );
       }


}; // struct CUseAddRefRelease

template <typename TRawPtr>
struct CDontAddRefRelease
{
    static const bool queryInterfaceAllowed = true;
    static ULONG doAddRef (TRawPtr *ptr) { return 1;  }
    static ULONG doRelease(TRawPtr *ptr) { return 0; }
    static RCODE doQueryInterface(TRawPtr *ptr, const CHAR* interfaceId, VOID** ifPtr)
       {
        CLI_STATIC_CHECK(0, CDontAddRefRelease_doQueryInterface_not_allowed___Possible_used_CFoolPtr_in_wrong_way);
        return 0;
       }

    static RCODE doCreateObject( CHAR const * componentId
                               , CHAR const * interfaceId
                               , CLI_IUNKNOWN_PTR outer
                               , void** ptrPtr  )
       {
        CLI_STATIC_CHECK(0, CDontAddRefRelease_doCreateObject_not_allowed___Possible_used_CFoolPtr_in_wrong_way);
        return 0;
       }

}; // struct CUseAddRefRelease


}; // namespace internal


template <typename T, typename TAddRefStrategy >
class CCliPtrBase
{
    public:

        typedef T   interface_type;
        typedef T*  interface_pointer_type;
        typedef T*  pointer_type;

    protected:

        //struct PP_proxy;
        friend struct PP_proxy;

        pointer_type    p;

        CCliPtrBase() : p(0) {}
        CCliPtrBase(int mustBeNull) : p(0)
           {
            CLIASSERT(mustBeNull==0);
           }

        // from generic pointer
        CCliPtrBase(T *_p, bool bNoAddRef=false) : p(_p)
           {
            if (p && !bNoAddRef) TAddRefStrategy::doAddRef(p); // p->addRef();
           }

        CCliPtrBase(const CCliPtrBase &pb) : p(pb.p) { if (p) TAddRefStrategy::doAddRef(p); /* p->addRef(); */  }
        CCliPtrBase& operator=(const CCliPtrBase &pb)
           {
            if (&pb==this) return *this;
            if (p) TAddRefStrategy::doRelease(p); //p->release();
            p = pb.p;
            if (p) TAddRefStrategy::doAddRef(p); // p->addRef();
            return *this;
           }

        CCliPtrBase& operator=(T *pt)
           {
            if (pt==this->p) return *this;
            if (p) TAddRefStrategy::doRelease(p); // p->release();
            p = pt;
            if (p) TAddRefStrategy::doAddRef(p); //p->addRef();
            return *this;
           }

    public:

        void swap(CCliPtrBase &pb)
           {
            pointer_type pTmp = p;
            p = pb.p;
            pb.p = pTmp;
           }

        ~CCliPtrBase()
           {
            if (p) TAddRefStrategy::doRelease(p); // p->release();
           }

        operator T*() const { return p; }

        // returns address of CCliPtrBase object,
        // or adress of p member of CCliPtrBase object as void**
        // for use with cliCreateObject and queryInterface
        // Works in conjunction with operator&()
        struct PP_proxy
        {
             CCliPtrBase<T, TAddRefStrategy> *cliPtr;
             PP_proxy(CCliPtrBase<T, TAddRefStrategy> *p) : cliPtr(p) {}
             operator CCliPtrBase<T, TAddRefStrategy>*()
                {
                 return cliPtr;
                }
             operator void**()
                {
                 CLIASSERT(p->p==0);
                 //return reinterpret_cast<void**>(&(p->p))
                 return p->getVpp();
                }
             operator T**()
                {
                 CLIASSERT(p->p==0);
                 return &(p->p);
                }
        };

        // substitutes T** operator&()
        PP_proxy operator&()
           {
            return PP_proxy(this);
           }



        //void** getVpp()       { return (void**)&p; }
        //void** getVpp()       { return reinterpret_cast<void**>(&p); }
        //void** getVpp()       { return reinterpret_cast<void**>(reinterpret_cast<char*>(&p)); }
        //void** getVpp()       { return (void**)(char**)(char*)(&p); }
        #if defined(__GNUC__)
            void** getVpp()       { UINT_PTR uip = (UINT_PTR)&p; return (void**)uip; }
            //void** getVpp()       { return &(void*)p; }
        #else
            void** getVpp()       { return (void**)&p; }
        #endif

        interface_pointer_type* getPP()    { return &p; }

        // use it at your own risk
        interface_pointer_type  getIfPtr() { return p; }

        ///////

        //operator T*() const { return p; }


        _No_addRef_release_onCCliPtr<T>* operator->() const
           {
            CLIASSERT(p!=0);
            return (_No_addRef_release_onCCliPtr<T>*)p;
           }

        _No_addRef_release_onCCliPtr<T>& operator*() const
           {
            CLIASSERT(p!=0); /* ATLENSURE(p!=NULL); */
            return *((_No_addRef_release_onCCliPtr<T>*)p);
           }

        operator bool() const               { return (p != 0); }
        bool operator!() const              { return (p == 0); }
        bool operator< (const T* pT) const  { return p < pT; }
        bool operator<=(const T* pT) const  { return p <= pT; }
        bool operator> (const T* pT) const  { return p > pT; }
        bool operator>=(const T* pT) const  { return p >= pT; }
        bool operator!=(const T* pT) const  { return !operator==(pT); }
        bool operator==(const T* pT) const  { return p == pT; }

        void release()
           {
            T* pTemp = p;
            if (pTemp)
               {
                p = 0;
                TAddRefStrategy::doRelease(pTemp); // pTemp->release();
               }
           }

        bool isEqualObject(::cli::iUnknown* pOther)
           {
            // They are both NULL objects
            // if (p == NULL && pOther == NULL) return true;

            // One is NULL the other is not
            if (p == 0 || pOther == 0) return false;

            CCliPtrBase< ::cli::iUnknown, ::cli::internal::CDoAddRefRelease<T> > punk1;
            CCliPtrBase< ::cli::iUnknown, ::cli::internal::CDoAddRefRelease<T> > punk2;
            p     ->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), punk1.getVpp() );
            pOther->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), punk2.getVpp() );
            return punk1.get() == punk2.get();
           }

        void attach(T* newP)  { if (p) TAddRefStrategy::doRelease(p);  /* p->release(); */  p = newP; }
        T*   detach()         { T* pRet = p; p = 0; return pRet; }
        T*   get()            { return p; }

        RCODE createObject( CHAR const * componentId, CLI_IUNKNOWN_PTR outer=0 )
           {
            release();
            //return cliCreateObject(componentId, ::cli::iidOf( (T*)0 ), outer, getVpp() );
            return TAddRefStrategy::doCreateObject(componentId, ::cli::iidOf( (T*)0 ), outer, getVpp() );
           }

        template <typename Q>
        RCODE queryInterface(Q **pq)
           {
            CLIASSERT(p!=0);
            if (!p) return CLI_ERR_UNKNOWN;
            if (TAddRefStrategy::queryInterfaceAllowed)
               {
                //return p->queryInterface(::cli::iidOf( *pq ), (void**)pq);
                return TAddRefStrategy::doQueryInterface(p, ::cli::iidOf( *pq ), (void**)pq);
               }
            else
               {
                *((void**)pq) = 0;
                return EC_NOT_IMPLEMENTED;
               }
           }

        template <typename Q>
        RCODE queryInterface(CCliPtrBase<Q, ::cli::internal::CDoAddRefRelease<Q> > &q)
           {
            CLIASSERT(p!=0);
            if (!p) return CLI_ERR_UNKNOWN;
            if (TAddRefStrategy::queryInterfaceAllowed)
               {
                return TAddRefStrategy::doQueryInterface(p, ::cli::iidOf( (Q*)0 ), q.getVpp());
                //TAddRefStrategy::doQueryInterface(p, ::cli::iidOf( (Q*)0 ), (void**)pq);
                //return p->queryInterface(::cli::iidOf( (Q*)0 ), q.getVpp());
               }
            else
               {
                *(q.getVpp()) = 0;
                return EC_NOT_IMPLEMENTED;
               }
           }

};




template <typename T>
class CCliPtr : public CCliPtrBase<T, ::cli::internal::CDoAddRefRelease<T> >
{
    public:

        typedef CCliPtrBase<T, ::cli::internal::CDoAddRefRelease<T> >           smart_ptr_type;
        typedef typename smart_ptr_type::interface_type                         interface_type;
        typedef typename smart_ptr_type::interface_pointer_type                 interface_pointer_type;
        typedef typename smart_ptr_type::pointer_type                           pointer_type;

        CCliPtr() : smart_ptr_type() { }
        CCliPtr(int mustBeNull) : smart_ptr_type(mustBeNull) { }

        void swap( smart_ptr_type &p )
           {
            smart_ptr_type::swap(p);
           }

        // from generic pointer
        CCliPtr(T *_p, bool bNoAddRef=false) : smart_ptr_type(_p, bNoAddRef) { }

        CCliPtr(const CCliPtr &pb) : smart_ptr_type(pb) { }
        CCliPtr& operator=(const CCliPtr &pb)
           {
            smart_ptr_type::operator=(pb);
            return *this;
           }

        CCliPtr& operator=(T *pt)
           {
            smart_ptr_type::operator=(pt);
            return *this;
           }
};



// 1) Weak ptr is not good name for foolish ptr
// 2) For CFoolishPtr now we use CCliPtrBase with internal::CDontAddRefRelease strategy

template <typename T>
class CFoolishPtr : public CCliPtrBase<T, ::cli::internal::CDontAddRefRelease<T> >
{
    public:

        typedef CCliPtrBase<T, ::cli::internal::CDontAddRefRelease<T> >         smart_ptr_type;
        typedef typename smart_ptr_type::interface_type                         interface_type;
        typedef typename smart_ptr_type::interface_pointer_type                 interface_pointer_type;
        typedef typename smart_ptr_type::pointer_type                           pointer_type;

        CFoolishPtr() : smart_ptr_type() { }
        CFoolishPtr(int mustBeNull) : smart_ptr_type(mustBeNull) { }

        void swap( smart_ptr_type &p )
           {
            smart_ptr_type::swap(p);
           }

        // from generic pointer
        CFoolishPtr(T *_p, bool bNoAddRef=false) : smart_ptr_type(_p, bNoAddRef) { }

        CFoolishPtr(const CFoolishPtr &pb) : smart_ptr_type(pb) { }
        CFoolishPtr& operator=(const CFoolishPtr &pb)
           {
            smart_ptr_type::operator=(pb);
            return *this;
           }

        CFoolishPtr& operator=(T *pt)
           {
            smart_ptr_type::operator=(pt);
            return *this;
           }
};




/*
template <typename T>
class CCliWeakPtrBase
{
    public:

        typedef T   interface_type;
        typedef T*  interface_pointer_type;
        typedef T*  pointer_type;

    protected:

        //struct PP_proxy;
        friend struct PP_proxy;

        pointer_type    p;

        CCliWeakPtrBase() : p(0) {}
        CCliWeakPtrBase(int mustBeNull) : p(0)
           {
            CLIASSERT(mustBeNull==0)
           }

        // from generic pointer
        CCliWeakPtrBase(T *_p, bool bNoAddRef=false) : p(_p)
           {
            // add ref not used in weak smart pointer
           }

        CCliWeakPtrBase(const CCliWeakPtrBase &pb) : p(pb.p) {  }
        CCliWeakPtrBase& operator=(const CCliWeakPtrBase &pb)
           {
            if (&pb!=this)
               p = pb.p;
            return *this;
           }

        CCliWeakPtrBase& operator=(T *pt)
           {
            if (pt!=this->p)
               p = pt;
            return *this;
           }

    public:

        //void swap(CCliPtrBase &pb) { pointer_type pTmp = p; p = pb.p; pb.p = pTmp; }

        ~CCliWeakPtrBase()
           {
           }

        operator T*() const { return p; }

        // returns address of CCliPtrBase object,
        // or adress of p member of CCliPtrBase object as void**
        // for use with cliCreateObject and queryInterface
        // Works in conjunction with operator&()
        struct PP_proxy
        {
             CCliWeakPtrBase<T> *cliPtr;
             PP_proxy(CCliWeakPtrBase<T> *p) : cliPtr(p) {}
             operator CCliWeakPtrBase<T>*()
                {
                 return cliPtr;
                }
             operator void**()
                {
                 CLIASSERT(p->p==0)
                 //return reinterpret_cast<void**>(&(p->p))
                 return p->getVpp();
                }
             operator T**()
                {
                 CLIASSERT(p->p==0)
                 return &(p->p);
                }
        };

        // substitutes T** operator&()
        PP_proxy operator&()
           {
            return PP_proxy(this);
           }

        void** getVpp()       { return (void**)&p; }
        ///////

        //operator T*() const { return p; }


        _No_addRef_release_onCCliPtr<T>* operator->() const
           {
            CLIASSERT(p!=0);
            return (_No_addRef_release_onCCliPtr<T>*)p;
           }

        _No_addRef_release_onCCliPtr<T>& operator*() const
           {
            CLIASSERT(p!=0); // ATLENSURE(p!=NULL);
            return *((_No_addRef_release_onCCliPtr<T>*)p);
           }

        bool operator!() const              { return (p == NULL); }
        operator bool() const               { return (p != NULL); }
        bool operator< (const T* pT) const  { return p < pT; }
        bool operator<=(const T* pT) const  { return p <= pT; }
        bool operator> (const T* pT) const  { return p > pT; }
        bool operator>=(const T* pT) const  { return p >= pT; }
        bool operator!=(const T* pT) const  { return !operator==(pT); }
        bool operator==(const T* pT) const  { return p == pT; }

        bool isEqualObject(::cli::iUnknown* pOther)
           {
            // They are both NULL objects
            if (p == NULL && pOther == NULL) return true;

            // One is NULL the other is not
            if (p == NULL || pOther == NULL) return false;

            CCliPtrBase< ::cli::iUnknown > punk1;
            CCliPtrBase< ::cli::iUnknown > punk2;
            p     ->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), punk1.getVpp());
            pOther->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), punk2.getVpp());
            return punk1.get() == punk2.get();
           }

        void attach(T* newP)  { p = newP; }
        T*   detach()         { T* pRet = p; p = 0; return pRet; }
        T*   get()            { return p; }

        RCODE createObject( CHAR const * componentId, CLI_IUNKNOWN_PTR outer=0 )
           {
            return cliCreateObject(componentId, ::cli::iidOf( (T*)0 ), outer, getVpp() );
           }

        template <typename Q>
        RCODE queryInterface(Q **pq)
           {
            CLIASSERT(p!=0);
            if (!p) return CLI_ERR_UNKNOWN;
            return p->queryInterface(::cli::iidOf( *pq ), (void**)pq);
           }

        template <typename Q>
        RCODE queryInterface(CCliPtrBase<Q> &q)
           {
            CLIASSERT(p!=0);
            if (!p) return CLI_ERR_UNKNOWN;
            return p->queryInterface(::cli::iidOf( (Q*)0 ), q.getVpp());
           }

};
*/








/*
template <typename T>
class CComPtrBase
{
protected:

public:
        return p;
    }
?   T& operator*() const
    {
        ATLENSURE(p!=NULL);
        return *p;
    }
    //The assert on operator& usually indicates a bug.  If this is really
    //what is needed, however, take the address of the p member explicitly.
?   T** operator&() throw()
    {
        ATLASSERT(p==NULL);
        return &p;
    }
?   _NoAddRefReleaseOnCComPtr<T>* operator->() const throw()
    {
        ATLASSERT(p!=NULL);
        return (_NoAddRefReleaseOnCComPtr<T>*)p;
    }

?   __checkReturn HRESULT CopyTo(__deref_out_opt T** ppT) throw()
    {
        ATLASSERT(ppT != NULL);
        if (ppT == NULL)
            return E_POINTER;
        *ppT = p;
        if (p)
            p->AddRef();
        return S_OK;
    }
?   __checkReturn HRESULT SetSite(__in_opt IUnknown* punkParent) throw()
    {
        return AtlSetChildSite(p, punkParent);
    }
?   __checkReturn HRESULT Advise(__in IUnknown* pUnk, __in const IID& iid, __out LPDWORD pdw) throw()
    {
        return AtlAdvise(p, pUnk, iid, pdw);
    }
    __checkReturn HRESULT CoCreateInstance(__in REFCLSID rclsid, __in_opt LPUNKNOWN pUnkOuter = NULL, __in DWORD dwClsContext = CLSCTX_ALL) throw()
    {
        ATLASSERT(p == NULL);
        return ::CoCreateInstance(rclsid, pUnkOuter, dwClsContext, __uuidof(T), (void**)&p);
    }
    __checkReturn HRESULT CoCreateInstance(__in LPCOLESTR szProgID, __in_opt LPUNKNOWN pUnkOuter = NULL, __in DWORD dwClsContext = CLSCTX_ALL) throw()
    {
        CLSID clsid;
        HRESULT hr = CLSIDFromProgID(szProgID, &clsid);
        ATLASSERT(p == NULL);
        if (SUCCEEDED(hr))
            hr = ::CoCreateInstance(clsid, pUnkOuter, dwClsContext, __uuidof(T), (void**)&p);
        return hr;
    }
    template <typename Q>
    __checkReturn HRESULT QueryInterface(__deref_out_opt Q** pp) const throw()
    {
        ATLASSERT(pp != NULL);
        return p->QueryInterface(__uuidof(Q), (void**)pp);
    }
    T* p;
};

*/

/*
template <typename T>
class CCliWeakPtr : public CCliWeakPtrBase<T>
{
    public:

        typedef typename CCliWeakPtrBase<T>::interface_type            interface_type;
        typedef typename CCliWeakPtrBase<T>::interface_pointer_type    interface_pointer_type;
        typedef typename CCliWeakPtrBase<T>::pointer_type              pointer_type;

        CCliWeakPtr() : CCliWeakPtrBase<T>() { }
        CCliWeakPtr(int mustBeNull) : CCliWeakPtrBase<T>(mustBeNull) { }

        // from generic pointer
        CCliWeakPtr(T *_p, bool bNoAddRef=false) : CCliWeakPtrBase<T>(_p, bNoAddRef) { }

        CCliWeakPtr(const CCliWeakPtr &pb) : CCliWeakPtrBase<T>(pb) { }
        CCliWeakPtr& operator=(const CCliWeakPtr &pb)
           {
            CCliPtrBase<T>::operator=(pb);
            return *this;
           }

        CCliWeakPtr& operator=(T *pt)
           {
            CCliWeakPtrBase<T>::operator=(pt);
            return *this;
           }
};
*/




}; // namespace cli

#endif // (__cplusplus) && !defined(CINTERFACE)

#endif /* CLI_CLIPTR_H */

