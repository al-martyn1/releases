#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INET_IFINFOHLP_H
#define CLI_INET_IFINFOHLP_H

/* add this lines to your sr�
#ifndef CLI_INET_IFINFOHLP_H
    #include <cli/inet/ifInfoHlp.h>
#endif
*/

#ifndef CLI_INET_IIFINFO_H
    #include <cli/inet/iIfInfo.h>
#endif

#ifndef CLI_INET_IROUTEINFO_H
    #include <cli/inet/iRouteInfo.h>
#endif


#ifdef WIN32
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else /* __GNUC__ */
     #include <alloca.h>
     #ifndef _alloca
         #define _alloca  alloca
     #endif
#endif

#if defined(WIN32) || defined(_WIN32)
    #include <Iphlpapi.h>
    #ifdef _MSC_VER
        #pragma comment( lib, "Iphlpapi" )
    #endif
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif


#ifndef CLI_INET_INETHLP_H
    #include <cli/inet/inetHlp.h>
#endif

#ifdef _WIN32
#else
    #include <net/if.h>
    #include <net/route.h>
    #include <sys/types.h>
    #include <sys/param.h>
    #include <sys/sysctl.h>
    #include <sys/ioctl.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif



namespace cli
{
namespace inet
{
namespace implHlp
{


struct CNetworkInterfaceInfo
{
    STRUCT_CLI_INET_CNETINTERFACEIPINFO info;
    std::wstring                        internalName;
    std::wstring                        deviceName;
    std::wstring                        name;
    std::wstring                        description;
    CNetworkInterfaceInfo() : info(), internalName(), deviceName(), name(), description() {}

};

//STRUCT_CLI_INET_CNETINTERFACEIPINFO

#if defined(WIN32) || defined(_WIN32)

// GetInterfaceInfo

template <typename TAdapterInfoHandler>
DWORD getAdaptersInfoHelperHandler( const TAdapterInfoHandler &handler )
   {
    PIP_ADAPTER_INFO pAdapterInfoTable = 0;
    ULONG uSize = 0;
    DWORD res = ::GetAdaptersInfo(pAdapterInfoTable, &uSize); // == ERROR_INSUFFICIENT_BUFFER) {
    if (res!=ERROR_BUFFER_OVERFLOW && res!=NO_ERROR) return res;
    pAdapterInfoTable = (PIP_ADAPTER_INFO)_alloca(uSize);
    res = ::GetAdaptersInfo(pAdapterInfoTable, &uSize);
    if (res!=NO_ERROR) return res;

    PIP_ADAPTER_INFO pAdapter = pAdapterInfoTable;
    while(pAdapter)
       {
        PIP_ADAPTER_INFO pAdapterTmp = pAdapter;
        pAdapter = pAdapter->Next;
        pAdapterTmp->Next = 0;
        if (!handler( *pAdapterTmp )) return 0; // stops
       }
    return 0;
   }

struct CAdaptersInfoHandler{
                ::std::vector< IP_ADAPTER_INFO > &adaptersInfo;
                //CAdaptersInfoHandler(const CAdaptersInfoHandler &h) : adaptersInfo(h.adaptersInfo) {}
                CAdaptersInfoHandler( ::std::vector< IP_ADAPTER_INFO > &_adaptersInfo ) : adaptersInfo(_adaptersInfo) {}
                bool operator()( const IP_ADAPTER_INFO &adapterInfo) const { adaptersInfo.push_back(adapterInfo); return true; }
               };

struct CAdaptersInfoNameDescriptionHandler{
                ::std::map< ULONG, CNetworkInterfaceInfo > &adapters;
                //CAdaptersInfoHandler(const CAdaptersInfoHandler &h) : adaptersInfo(h.adaptersInfo) {}
                CAdaptersInfoNameDescriptionHandler( ::std::map< ULONG, CNetworkInterfaceInfo > &a ) : adapters(a) {}
                bool operator()( const IP_ADAPTER_INFO &adapterInfo) const 
                {
                 adapters[adapterInfo.Index].info.interfaceId  = adapterInfo.Index;
                 ::std::map< ULONG, CNetworkInterfaceInfo >::iterator pa = adapters.find(adapterInfo.Index);

                 pa->second.info.af = CLI_INET_IPADDRESSFAMILY_IPV4;

                 pa->second.info.interfaceFlags = CLI_INET_NETINTERFACEFLAGS_OFF;
                 switch(adapterInfo.Type)
                    {
                     case MIB_IF_TYPE_ETHERNET :  pa->second.info.interfaceType = CLI_INET_NETINTERFACETYPE_ETHERNET; break;
                     case MIB_IF_TYPE_TOKENRING:  pa->second.info.interfaceType = CLI_INET_NETINTERFACETYPE_TOKENRING; break;
                     case MIB_IF_TYPE_FDDI     :  pa->second.info.interfaceType = CLI_INET_NETINTERFACETYPE_FDDI; break;
                     case MIB_IF_TYPE_PPP      :  pa->second.info.interfaceType = CLI_INET_NETINTERFACETYPE_PPP; break;
                     case MIB_IF_TYPE_LOOPBACK :  pa->second.info.interfaceType = CLI_INET_NETINTERFACETYPE_LOOPBACK; break;
                     case MIB_IF_TYPE_SLIP     :  pa->second.info.interfaceType = CLI_INET_NETINTERFACETYPE_SLIP; break;
                     default :  pa->second.info.interfaceType = CLI_INET_NETINTERFACETYPE_OTHER;
                    }

                 pa->second.name         = MARTY_CON::strToWide( adapterInfo.Description );
                 pa->second.internalName = MARTY_CON::strToWide( adapterInfo.AdapterName );

                 pa->second.info.macAddressSize = adapterInfo.AddressLength;
                 if (pa->second.info.macAddressSize > sizeof(pa->second.info.macAddress) / sizeof(pa->second.info.macAddress[0]))
                    pa->second.info.macAddressSize = sizeof(pa->second.info.macAddress) / sizeof(pa->second.info.macAddress[0]);
                 for(SIZE_T i=0; i!=pa->second.info.macAddressSize; ++i)
                    {
                     pa->second.info.macAddress[i] = adapterInfo.Address[i];
                    }

                 //adapterNames[adapterInfo.Index]        = MARTY_CON::strToWide( adapterInfo.AdapterName );
                 //adapterDescriptions[adapterInfo.Index] = MARTY_CON::strToWide( adapterInfo.Description );
                 return true;
                }

               };


inline
DWORD getAdaptersInfoHelper( ::std::vector< IP_ADAPTER_INFO > &adaptersInfo)
   {
    return getAdaptersInfoHelperHandler<CAdaptersInfoHandler>( CAdaptersInfoHandler(adaptersInfo) );
   }


        struct CMacFillerHandler
        {
         ::std::vector< STRUCT_CLI_INET_CNETINTERFACEIPINFO > &ifList;
         CMacFillerHandler(::std::vector< STRUCT_CLI_INET_CNETINTERFACEIPINFO > &_ifList) : ifList(_ifList) {}
         bool operator()( const IP_ADAPTER_INFO &adapterInfo) const
            {
             ::std::vector< STRUCT_CLI_INET_CNETINTERFACEIPINFO >::iterator it = ifList.begin();
             for(; it != ifList.end(); ++it)
                {
                 if (it->interfaceId == adapterInfo.Index)
                    {
                     it->macAddressSize = adapterInfo.AddressLength;
                     if (it->macAddressSize > sizeof(it->macAddress) / sizeof(it->macAddress[0]))
                        it->macAddressSize = sizeof(it->macAddress) / sizeof(it->macAddress[0]);
                     for(SIZE_T i=0; i!=it->macAddressSize; ++i)
                        {
                         it->macAddress[i] = adapterInfo.Address[i];
                        }
                     //return true; do not stop on first occurence
                    }
                }
             return true;
            }

        };

inline
bool isLoopbackIp4Addr( const STRUCT_CLI_INET_IPADDRESS &addr)
{
   if (addr.af==AF_INET && addr.addr[0]==127 && addr.addr[1]==0 && addr.addr[2]==0 ) // && addr.addr[3]==1
      return true;
   return false;
}

inline
bool isLoopbackIp4Addr( DWORD addr)
{
   #if defined(CLI_PLATFORM_LITTLE_ENDIAN)
   if ((addr&0x00FFFFFF) == 0x0000007F)
      return true;
   #else
   if ((addr&0xFFFFFF00) == 0x7F000000)
      return true;
   #endif
   return false;
}

// http://www.codeproject.com/Articles/4004/The-quot-New-ipconfig-quot-and-the-IP-Helper-API
// See also GetAdaptersInfo and GetAdaptersAddresses, GetPerAdapterInfo. 
inline
DWORD
//getInterfaceIpInfo( ::std::vector< STRUCT_CLI_INET_CNETINTERFACEIPINFO > &ifList, std::vector< std::wstring > &ifInternalNames, std::vector< std::wstring > &ifNames, std::vector< std::wstring > &ifDescriptions )
getInterfaceIpInfo( ::std::vector< CNetworkInterfaceInfo > &ifList )
   {
    ::std::map< ULONG, CNetworkInterfaceInfo > adapters;
    DWORD res = getAdaptersInfoHelperHandler( CAdaptersInfoNameDescriptionHandler( adapters ) );
    if (res) return res;

    DWORD dwSize = 0;
    PMIB_IPADDRTABLE pIpAddrTable = 0;

    //DWORD 
    res = ::GetIpAddrTable( pIpAddrTable, &dwSize, TRUE );
    if (res!=ERROR_INSUFFICIENT_BUFFER && res!=NO_ERROR) return res;
    pIpAddrTable = (PMIB_IPADDRTABLE)_alloca(dwSize);
    res = ::GetIpAddrTable( pIpAddrTable, &dwSize, TRUE );
    if (res!=NO_ERROR) return res;

    for(DWORD i=0; i!=(DWORD)pIpAddrTable->dwNumEntries; ++i)
       {
        ::std::map< ULONG, CNetworkInterfaceInfo >::iterator pa = adapters.find(pIpAddrTable->table[i].dwIndex);
        if (pa == adapters.end()) 
           {
            adapters[pIpAddrTable->table[i].dwIndex].info.interfaceId  = pIpAddrTable->table[i].dwIndex;
            pa = adapters.find(pIpAddrTable->table[i].dwIndex);
            if (isLoopbackIp4Addr(pIpAddrTable->table[i].dwAddr))
               {
                pa->second.info.interfaceType = CLI_INET_NETINTERFACETYPE_LOOPBACK;
                pa->second.internalName = L"loopback";
                pa->second.name         = L"Loopback adapter";
                // std::wstring                        internalName;
                // std::wstring                        deviceName;
                // std::wstring                        name;
                // std::wstring                        description;
               }
           }
        //continue;

        pa->second.info.interfaceFlags = CLI_INET_NETINTERFACEFLAGS_ON;
        ::cli::inet::hlp::initAddressFromDw( pa->second.info.addr          , pIpAddrTable->table[i].dwAddr );
        ::cli::inet::hlp::initAddressFromDw( pa->second.info.mask          , pIpAddrTable->table[i].dwMask );
        ::cli::inet::hlp::initAddressFromDw( pa->second.info.broadcastAddr , pIpAddrTable->table[i].dwBCastAddr );
       }

    IP_INTERFACE_INFO  ipInfInfo;
    IP_INTERFACE_INFO *pIpInfInfos = &ipInfInfo;
    ULONG ulIpInfInfosBufSize = (ULONG)sizeof(ipInfInfo);

    DWORD dwRetVal = GetInterfaceInfo(pIpInfInfos, &ulIpInfInfosBufSize);

    if (dwRetVal==ERROR_INSUFFICIENT_BUFFER)
       {
        pIpInfInfos = (IP_INTERFACE_INFO*)_alloca(ulIpInfInfosBufSize);
        dwRetVal = GetInterfaceInfo(pIpInfInfos, &ulIpInfInfosBufSize);
       }
    if (dwRetVal)
       return 0;

    LONG adapterInfoIdx = 0;
    for(; adapterInfoIdx!=pIpInfInfos->NumAdapters; ++adapterInfoIdx)
       {
        ::std::map< ULONG, CNetworkInterfaceInfo >::iterator pa = adapters.find(pIpInfInfos->Adapter[adapterInfoIdx].Index);
        if (pa == adapters.end()) 
            continue;
        pa->second.deviceName = pIpInfInfos->Adapter[adapterInfoIdx].Name;
       }

    ::std::map< ULONG, CNetworkInterfaceInfo >::const_iterator ait = adapters.begin();
    for(; ait != adapters.end(); ++ait)
       {
        SIZE_T idx = ifList.size();
        ifList.push_back(ait->second);
        //ifList[idx].
       }

    /*
    ifList.clear(); // resize()

    for(DWORD i=0; i!=(DWORD)pIpAddrTable->dwNumEntries; ++i)
       {
        STRUCT_CLI_INET_CNETINTERFACEIPINFO ifInfo;
        ifInfo.macAddressSize = 0;
        ::cli::inet::hlp::initAddressFromDw( ifInfo.addr          , pIpAddrTable->table[i].dwAddr );
        ::cli::inet::hlp::initAddressFromDw( ifInfo.mask          , pIpAddrTable->table[i].dwMask );
        ::cli::inet::hlp::initAddressFromDw( ifInfo.broadcastAddr , pIpAddrTable->table[i].dwBCastAddr );
        ifInfo.interfaceId = (UINT)pIpAddrTable->table[i].dwIndex;
        ifList.push_back(ifInfo);
       }
    getAdaptersInfoHelperHandler<CMacFillerHandler>( CMacFillerHandler(ifList) );

    IP_INTERFACE_INFO  ipInfInfo;
    IP_INTERFACE_INFO *pIpInfInfos = &ipInfInfo;
    ULONG ulIpInfInfosBufSize = (ULONG)sizeof(ipInfInfo);

    DWORD dwRetVal = GetInterfaceInfo(pIpInfInfos, &ulIpInfInfosBufSize);

    if (dwRetVal==ERROR_INSUFFICIENT_BUFFER)
       {
        pIpInfInfos = (IP_INTERFACE_INFO*)_alloca(ulIpInfInfosBufSize);
        dwRetVal = GetInterfaceInfo(pIpInfInfos, &ulIpInfInfosBufSize);
       }
    if (dwRetVal)
       return dwRetVal;

    std::map< ULONG, std::wstring > adapterInternalNameMap;
    std::map< ULONG, std::wstring > adapterNames;
    std::map< ULONG, std::wstring > adapterDescriptions;

    LONG adapterInfoIdx = 0;
    for(; adapterInfoIdx!=pIpInfInfos->NumAdapters; ++adapterInfoIdx)
       {
        adapterInternalNameMap[pIpInfInfos->Adapter[adapterInfoIdx].Index] = pIpInfInfos->Adapter[adapterInfoIdx].Name;
       }

    //DWORD 
    getAdaptersInfoHelperHandler( CAdaptersInfoNameDescriptionHandler( adapters ) );

    

    ::std::vector< STRUCT_CLI_INET_CNETINTERFACEIPINFO >::const_iterator cilIt = ifList.begin();
    for(; cilIt != ifList.end(); ++cilIt)
       {
        std::map< ULONG, std::wstring >::const_iterator anIt = adapterInternalNameMap.find( (ULONG)cilIt->interfaceId );
        if (anIt == adapterInternalNameMap.end() || anIt->second.empty())
           {
            if (isLoopbackIp4Addr(cilIt->addr))
               ifInternalNames.push_back( std::wstring(L"loopback") );
            else
               ifInternalNames.push_back( std::wstring(L"Unknown") );
           }
        else
           {
            ifInternalNames.push_back(anIt->second);
           }

        anIt = adapterNames.find( (ULONG)cilIt->interfaceId );
        if (anIt == adapterNames.end() || anIt->second.empty())
           {
            if (isLoopbackIp4Addr(cilIt->addr))
               ifNames.push_back( std::wstring(L"Loopback") );
            else
               ifNames.push_back( std::wstring(L"Unknown") );
           }
        else
           {
            ifNames.push_back( anIt->second );
           }

        anIt = adapterDescriptions.find( (ULONG)cilIt->interfaceId );
        if (anIt == adapterDescriptions.end() || anIt->second.empty())
           {
            ifDescriptions.push_back( std::wstring(L"No description") );
           }
        else
           {
            ifDescriptions.push_back( anIt->second );
           }

       }
    */
    return 0;
   }


inline
DWORD getRouteInfo( ::std::vector< STRUCT_CLI_INET_CROUTEINFO > &routeTable )
   {
    PMIB_IPFORWARDTABLE pIpForwardTable = 0;
    DWORD dwSize = 0;
    DWORD res = ::GetIpForwardTable(pIpForwardTable, &dwSize, 0); // == ERROR_INSUFFICIENT_BUFFER) {
    if (res!=ERROR_INSUFFICIENT_BUFFER && res!=NO_ERROR) return res;
    pIpForwardTable = (PMIB_IPFORWARDTABLE)_alloca(dwSize);
    res = ::GetIpForwardTable(pIpForwardTable, &dwSize, 0);
    if (res!=NO_ERROR) return res;

    for (DWORD i = 0; i < pIpForwardTable->dwNumEntries; i++)
        {
         STRUCT_CLI_INET_CROUTEINFO info;
         ::cli::inet::hlp::initAddressFromDw( info.destination , pIpForwardTable->table[i].dwForwardDest );
         ::cli::inet::hlp::initAddressFromDw( info.mask        , pIpForwardTable->table[i].dwForwardMask );
         ::cli::inet::hlp::initAddressFromDw( info.gateway     , pIpForwardTable->table[i].dwForwardNextHop );
         info.interfaceId = pIpForwardTable->table[i].dwForwardIfIndex;
         info.metric1 = pIpForwardTable->table[i].dwForwardMetric1;
         routeTable.push_back(info);
        }
    return 0;
   }

#else // Linux

// READ: Linux Standard Base - http://citkit.ru/articles/282/


// NOTE: to obtain interface list wed can use sysctl with name
// int sysctlName[2] = { CTL_NET, AF_ROUTE, 0, AF_INET, NET_RT_IFLIST, 0 };
// instead of ioctl


inline
//DWORD getInterfaceIpInfo( ::std::vector< STRUCT_CLI_INET_CNETINTERFACEIPINFO > &ifList )
DWORD getInterfaceIpInfo( ::std::vector< CNetworkInterfaceInfo > &ifList )
   {
    //ifList.clear();

    // http://man7.org/linux/man-pages/man7/netdevice.7.html
    // getifaddrs 
    int fd = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return 0; // some error

    //struct
    ifconf       ifc;
    //struct
    ifreq        ifcBuf[1024];

    ifc.ifc_len = sizeof(ifcBuf);
    ifc.ifc_buf = (char *)&ifcBuf[0];

    if ( ioctl(fd, SIOCGIFCONF, &ifc) < 0)
       {
        ::close(fd);
        return 0;
       }


    SIZE_T numIfreqs = ifc.ifc_len / sizeof( /* struct */ ifreq);
    //struct
    ifreq  *pIfReq = ifc.ifc_req;
    for( SIZE_T i = 0 ; i != numIfreqs; pIfReq++, i++ )
       {
        //::std::cout<<"--------------------\n";
        if (pIfReq->ifr_addr.sa_family != AF_INET)
           {
            //::std::cout<<"Not an IPv4 interface\n";
            continue; // skip IPv6 interfaces
           }
        //::std::cout<<"Name: "<<pIfReq->ifr_name<<"\n";


        //STRUCT_CLI_INET_CNETINTERFACEIPINFO interfaceInfo;
        CNetworkInterfaceInfo nwi;
        
        //interfaceInfo.interfaceFlags
        //pa->second.info.interfaceFlags = CLI_INET_NETINTERFACEFLAGS_ON;

        //nwi.info.interfaceId = pIfReq->ifr_ifindex;
        nwi.info.interfaceId = if_nametoindex ( pIfReq->ifr_name );

        nwi.info.af = CLI_INET_IPADDRESSFAMILY_IPV4;

        nwi.internalName = MARTY_CON::strToWide(pIfReq->ifr_name);
        //nwi.description  = MARTY_CON::strToWide();
        //nwi.deviceName   = MARTY_CON::strToWide();
        nwi.name         = MARTY_CON::strToWide(pIfReq->ifr_name);
        //nwi.info.interfaceId = if_nametoindex ( pIfReq->ifr_name );

        nwi.info.macAddressSize = 0;
        if ( ioctl(fd,SIOCGIFHWADDR, pIfReq) >= 0)
           {
           const BYTE *pMac = (const BYTE*)&(pIfReq->ifr_hwaddr.sa_data);
           nwi.info.macAddressSize = 6;
           for(SIZE_T i=0; i!=nwi.info.macAddressSize; ++i)
              nwi.info.macAddress[i] = pMac[i];
          }

        //::cli::inet::hlp::initIpAddress( nwi.info.addr, &pIfReq->ifr_addr );
        //::cli::inet::hlp::initIpAddress( nwi.info.mask, &pIfReq->ifr_netmask );
        if ( ioctl(fd, SIOCGIFADDR, pIfReq) >= 0)
            ::cli::inet::hlp::initIpAddress( nwi.info.addr, &pIfReq->ifr_addr );
        else
            ::cli::inet::hlp::initAddressFromDw( nwi.info.addr, 0 );

        if ( ioctl(fd, SIOCGIFNETMASK, pIfReq) >= 0)
            ::cli::inet::hlp::initIpAddress( nwi.info.mask, &pIfReq->ifr_netmask );
        else
            ::cli::inet::hlp::initAddressFromDw( nwi.info.mask, 0 );

        /*
        if (pIfReq->ifr_flags & IFF_BROADCAST)
           ::cli::inet::hlp::initIpAddress( nwi.info.broadcastAddr, &pIfReq->ifr_broadaddr );
        else
           ::cli::inet::hlp::initAddressFromDw( nwi.info.broadcastAddr, 0 );
        */
        if ( ioctl(fd, SIOCGIFBRDADDR, pIfReq) >= 0)
            ::cli::inet::hlp::initIpAddress( nwi.info.broadcastAddr, &pIfReq->ifr_broadaddr );
        else
            ::cli::inet::hlp::initAddressFromDw( nwi.info.broadcastAddr, 0 );

        
        //bool fUp = true;
        //bool fLoopback = false;
        if ( ioctl(fd, SIOCGIFFLAGS, pIfReq) >= 0)
           {
            /*
            if (!(pIfReq->ifr_flags&IFF_UP)) // 0x1
               fUp = false;
            if (!(pIfReq->ifr_flags&IFF_LOOPBACK)) // 0x8
               fLoopback = true;
            */
           }
        
        //if (fUp)
        if (pIfReq->ifr_flags & IFF_UP)
           nwi.info.interfaceFlags = CLI_INET_NETINTERFACEFLAGS_ON;
        /*
           http://stackoverflow.com/questions/11679514/what-is-the-difference-between-iff-up-and-iff-running
           IFF_RUNNING is supposed to reflect the operational status on a network interface, 
           rather than its administrative one. To provide an example, an Ethernet interface 
           may be brought UP by the administrator (e.g. ifconfig eth0 up), but it will not be 
           considered operational (i.e. RUNNING as per RFC2863) if the cable is not plugged in.        
        */

        //if (fLoopback)
        nwi.info.interfaceType  = CLI_INET_NETINTERFACETYPE_ETHERNET;
        if (pIfReq->ifr_flags & IFF_LOOPBACK)
           nwi.info.interfaceType  = CLI_INET_NETINTERFACETYPE_LOOPBACK;
        else if (pIfReq->ifr_flags & IFF_POINTOPOINT)
           nwi.info.interfaceType  = CLI_INET_NETINTERFACETYPE_PPP;

        //CLI_INET_NETINTERFACETYPE_TOKENRING
        //CLI_INET_NETINTERFACETYPE_FDDI


        ifList.push_back( nwi );
       }

    ::close(fd);

    return 0;

    /*
    STRUCT_CLI_INET_CNETINTERFACEIPINFO
    {
        UINT                        interfaceId;
        STRUCT_CLI_INET_IPADDRESS               addr;
        STRUCT_CLI_INET_IPADDRESS               mask;
        STRUCT_CLI_INET_IPADDRESS               broadcastAddr;
        SIZE_T                      macAddressSize;
        BYTE                        macAddress[32];
    };
    */
   }

namespace cvt_util
{
unsigned hexStringToUint( const char *phex, SIZE_T *pReadedChars);
SIZE_T skipSpaces( const char *pstr );
SIZE_T skipNonSpaces( const char *pstr );
}; // namespace cvt_util

inline
DWORD getRouteInfo( ::std::vector< STRUCT_CLI_INET_CROUTEINFO > &routeTable )
   {
    routeTable.clear();
    #ifdef NET_RT_DUMP
        #error "getRouteInfo version not implemented now with sysctl and NET_RT_DUMP"
    #else

    int fd = open( "/proc/net/route", O_RDONLY );
    if (fd<0)
        return 0;

    ::std::string curStr;
    ::std::vector< ::std::string > rtStrings;

    // reading file and parsing it into rtStrings lines
    char buf[4096];
    ssize_t readRes = read(fd, (void*)buf, sizeof(buf));
    while(readRes>0)
       {
        for(ssize_t i = 0; i!=readRes; ++i)
           {
            if (buf[i]=='\r') continue;
            if (buf[i]!='\n')
               {
                curStr.append(1,buf[i]);
                continue;
               }

            if (!curStr.empty())
               {
                rtStrings.push_back(curStr);
                curStr.clear();
               }
           }
        readRes = read(fd, (void*)buf, sizeof(buf));
       }
    if (!curStr.empty())
       {
        rtStrings.push_back(curStr);
        curStr.clear();
       }

    close(fd);


    if (rtStrings.size()<2) return 0;

    ::std::vector< ::std::string >::const_iterator lit = rtStrings.begin();
    ++lit; // skip first line
    for(; lit != rtStrings.end(); ++lit)
       {
        const char *pStr = lit->c_str();

        pStr += ::cli::inet::implHlp::cvt_util::skipSpaces( pStr );
        SIZE_T len = ::cli::inet::implHlp::cvt_util::skipNonSpaces( pStr );
        ::std::string ifName( pStr, len );

        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        len = 0;
        DWORD dwDst = ::cli::inet::implHlp::cvt_util::hexStringToUint( pStr, &len );
        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        len = 0;
        DWORD dwGate = ::cli::inet::implHlp::cvt_util::hexStringToUint( pStr, &len );
        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        len = 0;
        //DWORD dwFlags =
        ::cli::inet::implHlp::cvt_util::hexStringToUint( pStr, &len );
        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        len = 0;
        //DWORD dwRefCnt =
        ::cli::inet::implHlp::cvt_util::hexStringToUint( pStr, &len );
        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        len = 0;
        //DWORD dwUse =
        ::cli::inet::implHlp::cvt_util::hexStringToUint( pStr, &len );
        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        STRUCT_CLI_INET_CROUTEINFO ri;
        len = 0;
        //DWORD dwMetric =
        ri.metric1 = ::cli::inet::implHlp::cvt_util::hexStringToUint( pStr, &len );
        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        len = 0;
        DWORD dwMask = ::cli::inet::implHlp::cvt_util::hexStringToUint( pStr, &len );
        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        len = 0;
        //DWORD dwMtu =
        ::cli::inet::implHlp::cvt_util::hexStringToUint( pStr, &len );
        pStr += len + ::cli::inet::implHlp::cvt_util::skipSpaces( pStr + len );

        ::cli::inet::hlp::initAddressFromDw(ri.destination, dwDst);
        ::cli::inet::hlp::initAddressFromDw(ri.gateway, dwGate);
        ::cli::inet::hlp::initAddressFromDw(ri.mask, dwMask);
        ri.interfaceId = if_nametoindex ( ifName.c_str() );
        routeTable.push_back(ri);
       }
    #endif

    return 0;
   }



// /proc/net/route - ⠡��� ������⨧�樨

#endif // non-Win32


inline
bool checkAddLoopbackRoute( ::std::vector< STRUCT_CLI_INET_CROUTEINFO > &routeTable )
   {
    ::std::vector< STRUCT_CLI_INET_CROUTEINFO >::iterator it = routeTable.begin();
    for(; it != routeTable.end(); ++it)
       {
        if (it->destination.af==AF_INET && it->destination.addr[0]==127) // found loopback
           return false; // routeTable don't touched
       }

    STRUCT_CLI_INET_CROUTEINFO riLo;

    riLo.destination.af = AF_INET;
    riLo.destination.addr[0] = 127;
    riLo.destination.addr[1] = 0;
    riLo.destination.addr[2] = 0;
    riLo.destination.addr[3] = 1;

    riLo.mask.af = AF_INET;
    riLo.mask.addr[0] = 255;
    riLo.mask.addr[1] = 0;
    riLo.mask.addr[2] = 0;
    riLo.mask.addr[3] = 0;

    riLo.gateway.af = AF_INET;
    riLo.gateway.addr[0] = 127;
    riLo.gateway.addr[1] = 0;
    riLo.gateway.addr[2] = 0;
    riLo.gateway.addr[3] = 1;

    riLo.metric1 = 0;
    #ifdef _WIN32
    riLo.interfaceId = 1;
    #else
    riLo.interfaceId = if_nametoindex ( "lo" );
    #endif

    //if (riLo.interfaceId)
    routeTable.push_back(riLo);

    return true; // table modified
   }



namespace cvt_util
{

inline
char uint2hexChar(unsigned i)
   {
    i &= 0x0F;
    if (i>9) return 'A' + i - 10;
    return '0' + i;
   }

inline
wchar_t uint2hexWChar(unsigned i)
   {
    i &= 0x0F;
    if (i>9) return L'A' + i - 10;
    return L'0' + i;
   }

inline
char uint2decChar(unsigned i)
   {
    i = i % 10;
    return '0' + i;
   }

inline
wchar_t uint2decWChar(unsigned i)
   {
    i = i % 10;
    return L'0' + i;
   }


inline
void byte2hex( BYTE b, ::std::string &str )
   {
    str.append( 1, uint2hexChar( b>>4 ));
    str.append( 1, uint2hexChar( b    ));
   }

inline
void byte2hex( BYTE b, ::std::wstring &str )
   {
    str.append( 1, uint2hexWChar( b>>4 ));
    str.append( 1, uint2hexWChar( b    ));
   }

inline
void uint2dec( unsigned i, ::std::string &str )
   {
    while(i)
       {
        str.append(1, uint2decChar(i));
        i /= 10;
       }
    if (str.empty()) str.append(1, '0');
    else ::std::reverse( str.begin(), str.end() );
   }

inline
void uint2dec( unsigned i, ::std::wstring &str )
   {
    while(i)
       {
        str.append(1, uint2decChar(i));
        i /= 10;
       }
    if (str.empty()) str.append(1, L'0');
    else ::std::reverse( str.begin(), str.end() );
   }

inline
int hexToInt( char ch)
   {
    if (ch>='a' && ch<='f') return (unsigned)(ch - 'a') + 10;
    if (ch>='A' && ch<='F') return (unsigned)(ch - 'A') + 10;
    if (ch>='0' && ch<='9') return (unsigned)(ch - '0');
    return -1;
   }

inline
unsigned hexStringToUint( const char *phex, SIZE_T *pReadedChars)
   {
    unsigned res = 0;
    //SIZE_T readedChars = 0;
    const char *phexOrg = phex;

    while(phex && *phex)
       {
        int digit = hexToInt( *phex );
        if (digit<0)
           {
            if (pReadedChars) *pReadedChars = phex - phexOrg;
            return res;
           }
        res<<=4;
        res += (unsigned)digit;
        ++phex;
       }
    if (pReadedChars) *pReadedChars = phex - phexOrg;
    return res;
   }

inline
SIZE_T skipSpaces( const char *pstr )
   {
    //SIZE_T skipped = 0;
    const char *pstrOrg = pstr;
    while(pstr && *pstr && (*pstr==' ' || *pstr=='\t')) ++pstr;
    return pstr - pstrOrg;
   }

inline
SIZE_T skipNonSpaces( const char *pstr )
   {
    //SIZE_T skipped = 0;
    const char *pstrOrg = pstr;
    while(pstr && *pstr && *pstr!=' ' && *pstr!='\t') ++pstr;
    return pstr - pstrOrg;
   }


}; // namespace cvt_util


inline
::std::string macToString( SIZE_T macSize, const BYTE *pMac )
   {
    ::std::string res;
    for(SIZE_T i=0; i!=macSize; ++i)
       {
        res.append(1,(char)pMac[i]);
       }
    return res;
   }

inline
void formatMacAddr( SIZE_T macSize, const BYTE *pMac, ::std::string &strTo )
   {
    for(SIZE_T i=0; i!=macSize; ++i)
       {
        if (!strTo.empty()) strTo.append(1, ':');
        cvt_util::byte2hex( pMac[i], strTo );
       }
   }

inline
void formatMacAddr( SIZE_T macSize, const BYTE *pMac, ::std::wstring &strTo )
   {
    for(SIZE_T i=0; i!=macSize; ++i)
       {
        if (!strTo.empty()) strTo.append(1, L':');
        cvt_util::byte2hex( pMac[i], strTo );
       }
   }

inline
void formatMacAddr( const ::std::string &macAddr, ::std::string &strTo )
   {
    for(SIZE_T i=0; i!=macAddr.size(); ++i)
       {
        if (!strTo.empty()) strTo.append(1, ':');
        cvt_util::byte2hex( (BYTE)macAddr[i], strTo );
       }
   }

inline
void formatMacAddr( const ::std::string &macAddr, ::std::wstring &strTo )
   {
    for(SIZE_T i=0; i!=macAddr.size(); ++i)
       {
        if (!strTo.empty()) strTo.append(1, L':');
        cvt_util::byte2hex( (BYTE)macAddr[i], strTo );
       }
   }

inline
void formatIp( const STRUCT_CLI_INET_IPADDRESS &ipAddr, ::std::string &strTo )
   {
    if (ipAddr.af!=CLI_INET_IPADDRESSFAMILY_IPV4)
       {
        strTo = "<IPv6Addr>";
        return;
       }

    SIZE_T i = 0, size = 4;
    for(; i!=size; ++i)
       {
        if (!strTo.empty()) strTo.append(1,'.');
        ::std::string strTmp;
        cvt_util::uint2dec( ipAddr.addr[i], strTmp );
        strTo += strTmp;
       }
   }

inline
void formatIp( const STRUCT_CLI_INET_IPADDRESS &ipAddr, ::std::wstring &strTo )
   {
    if (ipAddr.af!=CLI_INET_IPADDRESSFAMILY_IPV4)
       {
        strTo = L"<IPv6Addr>";
        return;
       }

    SIZE_T i = 0, size = 4;
    for(; i!=size; ++i)
       {
        if (!strTo.empty()) strTo.append(1,L'.');
        ::std::wstring strTmp;
        cvt_util::uint2dec( ipAddr.addr[i], strTmp );
        strTo += strTmp;
       }
   }





}; // namespace implHlp
}; // namespace inet
}; // namespace cli









#endif /* CLI_INET_IFINFOHLP_H */

