#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INET_IROUTEINFO_H
#define CLI_INET_IROUTEINFO_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/inet/iRouteInfo.h>", CLI_INET_IROUTEINFO_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_INET_IROUTEINFO_H
    #include <cli/inet/iRouteInfo.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif

#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::inet::CRouteInfo */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            struct                                   IpAddress;
            #ifndef STRUCT_CLI_INET_IPADDRESS
                #define STRUCT_CLI_INET_IPADDRESS         ::cli::inet::IpAddress
            #endif

        }; // namespace inet
    }; // namespace cli

#else /* C-like declarations */

    #ifndef STRUCT_CLI_INET_IPADDRESS_PREDECLARED
    #define STRUCT_CLI_INET_IPADDRESS_PREDECLARED
    typedef struct tag_cli_inet_IpAddress    cli_inet_IpAddress;
    #endif //STRUCT_CLI_INET_IPADDRESS
    #ifndef STRUCT_CLI_INET_IPADDRESS
        #define STRUCT_CLI_INET_IPADDRESS         struct tag_cli_inet_IpAddress
    #endif


#endif /* end of C-like declarations */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
    #define CLI_STRUCT_NAME                   CRouteInfo
    #ifndef STRUCT_CLI_INET_CROUTEINFO_PREDECLARED
    #define STRUCT_CLI_INET_CROUTEINFO_PREDECLARED
        struct CRouteInfo;
        #ifndef STRUCT_CLI_INET_CROUTEINFO
            #define STRUCT_CLI_INET_CROUTEINFO        ::cli::inet::CRouteInfo
        #endif
    #endif // STRUCT_CLI_INET_CROUTEINFO_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_inet_CRouteInfo
    #ifndef STRUCT_CLI_INET_CROUTEINFO_PREDECLARED
    #define STRUCT_CLI_INET_CROUTEINFO_PREDECLARED
        struct  tag_cli_inet_CRouteInfo;
        typedef struct tag_cli_inet_CRouteInfo cli_inet_CRouteInfo;
        #ifndef STRUCT_CLI_INET_CROUTEINFO
            #define STRUCT_CLI_INET_CROUTEINFO        struct tag_cli_inet_CRouteInfo
        #endif
    #endif // STRUCT_CLI_INET_CROUTEINFO_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_INET_CROUTEINFO_DEFINED
            #define STRUCT_CLI_INET_CROUTEINFO_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                STRUCT_CLI_INET_IPADDRESS               destination;
                STRUCT_CLI_INET_IPADDRESS               mask;
                STRUCT_CLI_INET_IPADDRESS               gateway;
                UINT                        interfaceId;
                UINT                        metric1;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_INET_CROUTEINFO_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::inet::iRouteInfo */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_INET_IROUTEINFO_IID
    #define INTERFACE_CLI_INET_IROUTEINFO_IID    "/cli/inet/iRouteInfo"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace inet {
    #define INTERFACE iRouteInfo
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_INET_IROUTEINFO
       #define INTERFACE_CLI_INET_IROUTEINFO    ::cli::inet::iRouteInfo
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_inet_iRouteInfo
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_INET_IROUTEINFO
       #define INTERFACE_CLI_INET_IROUTEINFO    cli_inet_iRouteInfo
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::inet::iRouteInfo methods */
                CLIMETHOD(routeInfoGet) (THIS_ STRUCT_CLI_INET_CROUTEINFO*    _routeInfo /* [out] ::cli::inet::CRouteInfo _routeInfo  */
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                CLIMETHOD(routeInfoSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(queryRouteInfo) (THIS) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::inet::iRouteInfo >
           {
            static char const * getName() { return INTERFACE_CLI_INET_IROUTEINFO_IID; }
           };
        template<> struct CIidOfImpl< ::cli::inet::iRouteInfo* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::inet::iRouteInfo > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace inet {
            // interface ::cli::inet::iRouteInfo wrapper
            // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_INET_IROUTEINFO >
                                          */
                     >
            class CiRouteInfoWrapper
            {
                public:
            
                    typedef  CiRouteInfoWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiRouteInfoWrapper() :
                       pif(0) {}
            
                    CiRouteInfoWrapper( iRouteInfo *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiRouteInfoWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiRouteInfoWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiRouteInfoWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiRouteInfoWrapper(const CiRouteInfoWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiRouteInfoWrapper()  { }
            
                    CiRouteInfoWrapper& operator=(const CiRouteInfoWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    STRUCT_CLI_INET_CROUTEINFO get_routeInfo( SIZE_T idx1 )
                       {
                        STRUCT_CLI_INET_CROUTEINFO tmpVal;
                        RCODE res = routeInfoGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_routeInfo(  )
                       {
                        SIZE_T size;
                        RCODE res = routeInfoSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, STRUCT_CLI_INET_CROUTEINFO, routeInfo, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE routeInfoGet( STRUCT_CLI_INET_CROUTEINFO    &_routeInfo /* [out] ::cli::inet::CRouteInfo _routeInfo  (struct passed by ref in wrapper) */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                       {
                    
                    
                        return pif->routeInfoGet(&_routeInfo, idx1);
                       }
                    
                    RCODE routeInfoSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->routeInfoSize(_size);
                       }
                    
                    RCODE queryRouteInfo( )
                       {
                        return pif->queryRouteInfo();
                       }
                    

            
            
            }; // class CiRouteInfoWrapper
            
            typedef CiRouteInfoWrapper< ::cli::CCliPtr< INTERFACE_CLI_INET_IROUTEINFO     > >  CiRouteInfo;
            typedef CiRouteInfoWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_IROUTEINFO > >  CiRouteInfo_nrc; /* No ref counting for interface used */
            typedef CiRouteInfoWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_IROUTEINFO > >  CiRouteInfo_tmp; /* for temporary usage, same as CiRouteInfo_nrc */
            
            
            
            
            
        }; // namespace inet
    }; // namespace cli

#endif





#endif /* CLI_INET_IROUTEINFO_H */
