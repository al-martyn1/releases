#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INET_IRESOLV_H
#define CLI_INET_IRESOLV_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/inet/iResolv.h>", CLI_INET_IRESOLV_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif

#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::inet::EMulticastAddressType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_INET_EMULTICASTADDRESSTYPE                 UINT
#else
    #define ENUM_CLI_INET_EMULTICASTADDRESSTYPE                 UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_INET_EMULTICASTADDRESSTYPE_ADDRANY
    #define CLI_INET_EMULTICASTADDRESSTYPE_ADDRANY            CONSTANT_UINT(0)
#endif /* CLI_INET_EMULTICASTADDRESSTYPE_ADDRANY */

#ifndef CLI_INET_EMULTICASTADDRESSTYPE_LOCALHOST
    #define CLI_INET_EMULTICASTADDRESSTYPE_LOCALHOST          1
#endif /* CLI_INET_EMULTICASTADDRESSTYPE_LOCALHOST */

#ifndef CLI_INET_EMULTICASTADDRESSTYPE_BROADCAST
    #define CLI_INET_EMULTICASTADDRESSTYPE_BROADCAST          2
#endif /* CLI_INET_EMULTICASTADDRESSTYPE_BROADCAST */

#ifndef CLI_INET_EMULTICASTADDRESSTYPE_LINKLOCAL
    #define CLI_INET_EMULTICASTADDRESSTYPE_LINKLOCAL          3
#endif /* CLI_INET_EMULTICASTADDRESSTYPE_LINKLOCAL */

#ifndef CLI_INET_EMULTICASTADDRESSTYPE_SITELOCAL
    #define CLI_INET_EMULTICASTADDRESSTYPE_SITELOCAL          4
#endif /* CLI_INET_EMULTICASTADDRESSTYPE_SITELOCAL */

#ifndef CLI_INET_EMULTICASTADDRESSTYPE_ORGANIZATIONLOCAL
    #define CLI_INET_EMULTICASTADDRESSTYPE_ORGANIZATIONLOCAL  5
#endif /* CLI_INET_EMULTICASTADDRESSTYPE_ORGANIZATIONLOCAL */

#ifndef CLI_INET_EMULTICASTADDRESSTYPE_INVALID
    #define CLI_INET_EMULTICASTADDRESSTYPE_INVALID            CONSTANT_UINT(0xffffffff)
#endif /* CLI_INET_EMULTICASTADDRESSTYPE_INVALID */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            namespace EMulticastAddressType {
                    const UINT addrAny          = CONSTANT_UINT(0);
                    const UINT localhost        = CONSTANT_UINT(1);
                    const UINT broadcast        = CONSTANT_UINT(2);
                    const UINT linkLocal        = CONSTANT_UINT(3);
                    const UINT siteLocal        = CONSTANT_UINT(4);
                    const UINT organizationLocal        = CONSTANT_UINT(5);
                    const UINT invalid          = CONSTANT_UINT(0xffffffff);
            }; // namespace EMulticastAddressType
        }; // namespace inet
    }; // namespace cli
    /* using namespace ::cli::inet::EMulticastAddressType; */
    
#endif





/* ------------------------------------------------------ */
/* Interface: ::cli::inet::iResolver */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace inet {
        }; // namespace inet
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_INET_IRESOLVER_IID
    #define INTERFACE_CLI_INET_IRESOLVER_IID    "/cli/inet/iResolver"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace inet {
    #define INTERFACE iResolver
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_INET_IRESOLVER
       #define INTERFACE_CLI_INET_IRESOLVER    ::cli::inet::iResolver
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_inet_iResolver
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_INET_IRESOLVER
       #define INTERFACE_CLI_INET_IRESOLVER    cli_inet_iResolver
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::inet::iResolver methods */
                CLIMETHOD(stringToIp) (THIS_ const CLISTR*     ipStr
                                           , STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [out] ::cli::inet::IpAddress ipAddr  */
                                      ) PURE;
                CLIMETHOD(stringToIpChars) (THIS_ const WCHAR*    ipBuf /* [in,flat] wchar  ipBuf[]  */
                                                , SIZE_T    ipBufSize /* [in] size_t  ipBufSize  */
                                                , STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [out] ::cli::inet::IpAddress ipAddr  */
                                           ) PURE;
                CLIMETHOD(ipToString) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [in,ref] ::cli::inet::IpAddress  ipAddr  */
                                           , CLISTR*           ipStr
                                      ) PURE;
                CLIMETHOD(sockAddrToString) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sockAddr /* [in,ref] ::cli::inet::SocketAddress  sockAddr  */
                                                 , CLISTR*           ipStr
                                            ) PURE;
                CLIMETHOD(sockAddrToAddrPortString) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sockAddr /* [in,ref] ::cli::inet::SocketAddress  sockAddr  */
                                                         , CLISTR*           ipStr
                                                         , CLISTR*           portStr
                                                    ) PURE;
                CLIMETHOD(getHostName) (THIS_ CLISTR*           name) PURE;
                CLIMETHOD(makeByTypeIpAddr) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                                 , ENUM_CLI_INET_EMULTICASTADDRESSTYPE    addrType /* [in] ::cli::inet::EMulticastAddressType  addrType  */
                                                 , STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [out,ref] ::cli::inet::IpAddress ipAddr  */
                                            ) PURE;
                CLIMETHOD(makeByTypeSockAddr) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                                   , ENUM_CLI_INET_EMULTICASTADDRESSTYPE    addrType /* [in] ::cli::inet::EMulticastAddressType  addrType  */
                                                   , UINT    port /* [in] uint  port  */
                                                   , STRUCT_CLI_INET_SOCKETADDRESS*    sockAddr /* [out,ref] ::cli::inet::SocketAddress sockAddr  */
                                              ) PURE;
                CLIMETHOD(macAddrToString) (THIS_ const BYTE*    mac /* [in,flat] byte  mac[]  */
                                                , SIZE_T    macSize /* [in] size_t  macSize  */
                                                , CLISTR*           macStr
                                           ) PURE;
                CLIMETHOD(canonicalNameGet) (THIS_ CLISTR*           _canonicalName) PURE;
                CLIMETHOD(addrListGet) (THIS_ STRUCT_CLI_INET_IPADDRESS*    _addrList /* [out] ::cli::inet::IpAddress _addrList  */
                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                       ) PURE;
                CLIMETHOD(addrListSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(aliasListGet) (THIS_ CLISTR*           _aliasList
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                        ) PURE;
                CLIMETHOD(aliasListSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(serviceNameGet) (THIS_ CLISTR*           _serviceName) PURE;
                CLIMETHOD(serviceAliasesGet) (THIS_ CLISTR*           _serviceAliases
                                                  , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             ) PURE;
                CLIMETHOD(serviceAliasesSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(portGet) (THIS_ UINT*    _port /* [out] uint _port  */) PURE;
                CLIMETHOD(serviceProtocolStrGet) (THIS_ CLISTR*           _serviceProtocolStr) PURE;
                CLIMETHOD(serviceProtocolGet) (THIS_ ENUM_CLI_INET_PROTOCOLTYPE*    _serviceProtocol /* [out] ::cli::inet::ProtocolType _serviceProtocol  */) PURE;
                CLIMETHOD(addrListGetSocketAddress) (THIS_ STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [out] ::cli::inet::SocketAddress sa  */
                                                         , SIZE_T    addrIdx /* [in] size_t  addrIdx  */
                                                    ) PURE;
                CLIMETHOD(getHostInfoByName) (THIS_ const CLISTR*     host
                                                  , ENUM_CLI_INET_IPADDRESSFAMILY    afRequested /* [in] ::cli::inet::IpAddressFamily  afRequested  */
                                             ) PURE;
                CLIMETHOD(getHostInfoByNameChars) (THIS_ const WCHAR*    hostStr /* [in,flat] wchar  hostStr[]  */
                                                       , SIZE_T    hostStrSize /* [in] size_t  hostStrSize  */
                                                       , ENUM_CLI_INET_IPADDRESSFAMILY    afRequested /* [in] ::cli::inet::IpAddressFamily  afRequested  */
                                                  ) PURE;
                CLIMETHOD(getHostByAddress) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [in,ref] ::cli::inet::IpAddress  ipAddr  */) PURE;
                CLIMETHOD(getHostByAddressString) (THIS_ const CLISTR*     ipStr) PURE;
                CLIMETHOD(getHostByAddressStringChars) (THIS_ const WCHAR*    ipStr /* [in,flat] wchar  ipStr[]  */
                                                            , SIZE_T    ipStrSize /* [in] size_t  ipStrSize  */
                                                       ) PURE;
                CLIMETHOD(getServiceInfo) (THIS_ UINT    port /* [in] uint  port  */
                                               , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                          ) PURE;
                CLIMETHOD(getServiceInfoStr) (THIS_ const CLISTR*     portOrName
                                                  , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                             ) PURE;
                CLIMETHOD(getServiceInfoStrChars) (THIS_ const WCHAR*    portOrNameStr /* [in,flat] wchar  portOrNameStr[]  */
                                                       , SIZE_T    portOrNameStrSize /* [in] size_t  portOrNameStrSize  */
                                                       , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                                  ) PURE;
                CLIMETHOD(getServiceInfoStr2) (THIS_ const CLISTR*     portOrName
                                                   , const CLISTR*     protocol
                                              ) PURE;
                CLIMETHOD(getServiceInfoStr2Chars) (THIS_ const WCHAR*    portOrNameStr /* [in,flat] wchar  portOrNameStr[]  */
                                                        , SIZE_T    portOrNameStrSize /* [in] size_t  portOrNameStrSize  */
                                                        , const WCHAR*    protocolStr /* [in,flat] wchar  protocolStr[]  */
                                                        , SIZE_T    protocolStrSize /* [in] size_t  protocolStrSize  */
                                                   ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::inet::iResolver >
           {
            static char const * getName() { return INTERFACE_CLI_INET_IRESOLVER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::inet::iResolver* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::inet::iResolver > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace inet {
            // interface ::cli::inet::iResolver wrapper
            // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_INET_IRESOLVER >
                                          */
                     >
            class CiResolverWrapper
            {
                public:
            
                    typedef  CiResolverWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiResolverWrapper() :
                       pif(0) {}
            
                    CiResolverWrapper( iResolver *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiResolverWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiResolverWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiResolverWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiResolverWrapper(const CiResolverWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiResolverWrapper()  { }
            
                    CiResolverWrapper& operator=(const CiResolverWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE stringToIp( const ::std::wstring    &ipStr
                                    , STRUCT_CLI_INET_IPADDRESS    &ipAddr /* [out] ::cli::inet::IpAddress ipAddr  (struct passed by ref in wrapper) */
                                    )
                       {
                        CCliStr tmp_ipStr; CCliStr_lightCopyTo( tmp_ipStr, ipStr);
                    
                        return pif->stringToIp(&tmp_ipStr, &ipAddr);
                       }
                    
                    RCODE stringToIpChars( const WCHAR*    ipBuf /* [in,flat] wchar  ipBuf[]  */
                                         , SIZE_T    ipBufSize /* [in] size_t  ipBufSize  */
                                         , STRUCT_CLI_INET_IPADDRESS    &ipAddr /* [out] ::cli::inet::IpAddress ipAddr  (struct passed by ref in wrapper) */
                                         )
                       {
                    
                    
                    
                        return pif->stringToIpChars(ipBuf, ipBufSize, &ipAddr);
                       }
                    
                    RCODE ipToString( const STRUCT_CLI_INET_IPADDRESS    &ipAddr /* [in,ref] ::cli::inet::IpAddress  ipAddr  (struct passed by ref in wrapper) */
                                    , ::std::wstring    &ipStr
                                    )
                       {
                    
                        CCliStr tmp_ipStr; CCliStr_init( tmp_ipStr );
                        RCODE res = pif->ipToString(&ipAddr, &tmp_ipStr);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( ipStr, tmp_ipStr);
                           }
                        return res;
                       }
                    
                    RCODE sockAddrToString( const STRUCT_CLI_INET_SOCKETADDRESS    &sockAddr /* [in,ref] ::cli::inet::SocketAddress  sockAddr  (struct passed by ref in wrapper) */
                                          , ::std::wstring    &ipStr
                                          )
                       {
                    
                        CCliStr tmp_ipStr; CCliStr_init( tmp_ipStr );
                        RCODE res = pif->sockAddrToString(&sockAddr, &tmp_ipStr);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( ipStr, tmp_ipStr);
                           }
                        return res;
                       }
                    
                    RCODE sockAddrToAddrPortString( const STRUCT_CLI_INET_SOCKETADDRESS    &sockAddr /* [in,ref] ::cli::inet::SocketAddress  sockAddr  (struct passed by ref in wrapper) */
                                                  , ::std::wstring    &ipStr
                                                  , ::std::wstring    &portStr
                                                  )
                       {
                    
                        CCliStr tmp_ipStr; CCliStr_init( tmp_ipStr );
                        CCliStr tmp_portStr; CCliStr_init( tmp_portStr );
                        RCODE res = pif->sockAddrToAddrPortString(&sockAddr, &tmp_ipStr, &tmp_portStr);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( ipStr, tmp_ipStr);
                            CCliStr_copyFromIfModified( portStr, tmp_portStr);
                           }
                        return res;
                       }
                    
                    RCODE getHostName( ::std::wstring    &name)
                       {
                        CCliStr tmp_name; CCliStr_init( tmp_name );
                        RCODE res = pif->getHostName(&tmp_name);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( name, tmp_name);
                           }
                        return res;
                       }
                    
                    RCODE makeByTypeIpAddr( ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                          , ENUM_CLI_INET_EMULTICASTADDRESSTYPE    addrType /* [in] ::cli::inet::EMulticastAddressType  addrType  */
                                          , STRUCT_CLI_INET_IPADDRESS    &ipAddr /* [out,ref] ::cli::inet::IpAddress ipAddr  (struct passed by ref in wrapper) */
                                          )
                       {
                    
                    
                    
                        return pif->makeByTypeIpAddr(af, addrType, &ipAddr);
                       }
                    
                    RCODE makeByTypeSockAddr( ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                            , ENUM_CLI_INET_EMULTICASTADDRESSTYPE    addrType /* [in] ::cli::inet::EMulticastAddressType  addrType  */
                                            , UINT    port /* [in] uint  port  */
                                            , STRUCT_CLI_INET_SOCKETADDRESS    &sockAddr /* [out,ref] ::cli::inet::SocketAddress sockAddr  (struct passed by ref in wrapper) */
                                            )
                       {
                    
                    
                    
                    
                        return pif->makeByTypeSockAddr(af, addrType, port, &sockAddr);
                       }
                    
                    RCODE macAddrToString( const BYTE*    mac /* [in,flat] byte  mac[]  */
                                         , SIZE_T    macSize /* [in] size_t  macSize  */
                                         , ::std::wstring    &macStr
                                         )
                       {
                    
                    
                        CCliStr tmp_macStr; CCliStr_init( tmp_macStr );
                        RCODE res = pif->macAddrToString(mac, macSize, &tmp_macStr);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( macStr, tmp_macStr);
                           }
                        return res;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_canonicalName( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = canonicalNameGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, ::std::wstring, canonicalName );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE canonicalNameGet( ::std::wstring    &_canonicalName)
                       {
                        CCliStr tmp__canonicalName; CCliStr_init( tmp__canonicalName );
                        RCODE res = pif->canonicalNameGet(&tmp__canonicalName);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _canonicalName, tmp__canonicalName);
                           }
                        return res;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    STRUCT_CLI_INET_IPADDRESS get_addrList( SIZE_T idx1 )
                       {
                        STRUCT_CLI_INET_IPADDRESS tmpVal;
                        RCODE res = addrListGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_addrList(  )
                       {
                        SIZE_T size;
                        RCODE res = addrListSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, STRUCT_CLI_INET_IPADDRESS, addrList, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE addrListGet( STRUCT_CLI_INET_IPADDRESS    &_addrList /* [out] ::cli::inet::IpAddress _addrList  (struct passed by ref in wrapper) */
                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                     )
                       {
                    
                    
                        return pif->addrListGet(&_addrList, idx1);
                       }
                    
                    RCODE addrListSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->addrListSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_aliasList( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = aliasListGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_aliasList(  )
                       {
                        SIZE_T size;
                        RCODE res = aliasListSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, aliasList, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE aliasListGet( ::std::wstring    &_aliasList
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
                       {
                        CCliStr tmp__aliasList; CCliStr_init( tmp__aliasList );
                    
                        RCODE res = pif->aliasListGet(&tmp__aliasList, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _aliasList, tmp__aliasList);
                           }
                        return res;
                       }
                    
                    RCODE aliasListSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->aliasListSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_serviceName( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = serviceNameGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, ::std::wstring, serviceName );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE serviceNameGet( ::std::wstring    &_serviceName)
                       {
                        CCliStr tmp__serviceName; CCliStr_init( tmp__serviceName );
                        RCODE res = pif->serviceNameGet(&tmp__serviceName);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _serviceName, tmp__serviceName);
                           }
                        return res;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_serviceAliases( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = serviceAliasesGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_serviceAliases(  )
                       {
                        SIZE_T size;
                        RCODE res = serviceAliasesSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, serviceAliases, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE serviceAliasesGet( ::std::wstring    &_serviceAliases
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                           )
                       {
                        CCliStr tmp__serviceAliases; CCliStr_init( tmp__serviceAliases );
                    
                        RCODE res = pif->serviceAliasesGet(&tmp__serviceAliases, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _serviceAliases, tmp__serviceAliases);
                           }
                        return res;
                       }
                    
                    RCODE serviceAliasesSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->serviceAliasesSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    UINT get_port( )
                       {
                        UINT tmpVal;
                        RCODE res = portGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, UINT, port );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE portGet( UINT*    _port /* [out] uint _port  */)
                       {
                    
                        return pif->portGet(_port);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_serviceProtocolStr( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = serviceProtocolStrGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, ::std::wstring, serviceProtocolStr );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE serviceProtocolStrGet( ::std::wstring    &_serviceProtocolStr)
                       {
                        CCliStr tmp__serviceProtocolStr; CCliStr_init( tmp__serviceProtocolStr );
                        RCODE res = pif->serviceProtocolStrGet(&tmp__serviceProtocolStr);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _serviceProtocolStr, tmp__serviceProtocolStr);
                           }
                        return res;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ENUM_CLI_INET_PROTOCOLTYPE get_serviceProtocol( )
                       {
                        ENUM_CLI_INET_PROTOCOLTYPE tmpVal;
                        RCODE res = serviceProtocolGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, ENUM_CLI_INET_PROTOCOLTYPE, serviceProtocol );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE serviceProtocolGet( ENUM_CLI_INET_PROTOCOLTYPE*    _serviceProtocol /* [out] ::cli::inet::ProtocolType _serviceProtocol  */)
                       {
                    
                        return pif->serviceProtocolGet(_serviceProtocol);
                       }
                    
                    RCODE addrListGetSocketAddress( STRUCT_CLI_INET_SOCKETADDRESS    &sa /* [out] ::cli::inet::SocketAddress sa  (struct passed by ref in wrapper) */
                                                  , SIZE_T    addrIdx /* [in] size_t  addrIdx  */
                                                  )
                       {
                    
                    
                        return pif->addrListGetSocketAddress(&sa, addrIdx);
                       }
                    
                    RCODE getHostInfoByName( const ::std::wstring    &host
                                           , ENUM_CLI_INET_IPADDRESSFAMILY    afRequested /* [in] ::cli::inet::IpAddressFamily  afRequested  */
                                           )
                       {
                        CCliStr tmp_host; CCliStr_lightCopyTo( tmp_host, host);
                    
                        return pif->getHostInfoByName(&tmp_host, afRequested);
                       }
                    
                    RCODE getHostInfoByNameChars( const WCHAR*    hostStr /* [in,flat] wchar  hostStr[]  */
                                                , SIZE_T    hostStrSize /* [in] size_t  hostStrSize  */
                                                , ENUM_CLI_INET_IPADDRESSFAMILY    afRequested /* [in] ::cli::inet::IpAddressFamily  afRequested  */
                                                )
                       {
                    
                    
                    
                        return pif->getHostInfoByNameChars(hostStr, hostStrSize, afRequested);
                       }
                    
                    RCODE getHostByAddress( const STRUCT_CLI_INET_IPADDRESS    &ipAddr /* [in,ref] ::cli::inet::IpAddress  ipAddr  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->getHostByAddress(&ipAddr);
                       }
                    
                    RCODE getHostByAddressString( const ::std::wstring    &ipStr)
                       {
                        CCliStr tmp_ipStr; CCliStr_lightCopyTo( tmp_ipStr, ipStr);
                        return pif->getHostByAddressString(&tmp_ipStr);
                       }
                    
                    RCODE getHostByAddressStringChars( const WCHAR*    ipStr /* [in,flat] wchar  ipStr[]  */
                                                     , SIZE_T    ipStrSize /* [in] size_t  ipStrSize  */
                                                     )
                       {
                    
                    
                        return pif->getHostByAddressStringChars(ipStr, ipStrSize);
                       }
                    
                    RCODE getServiceInfo( UINT    port /* [in] uint  port  */
                                        , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                        )
                       {
                    
                    
                        return pif->getServiceInfo(port, protocol);
                       }
                    
                    RCODE getServiceInfoStr( const ::std::wstring    &portOrName
                                           , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                           )
                       {
                        CCliStr tmp_portOrName; CCliStr_lightCopyTo( tmp_portOrName, portOrName);
                    
                        return pif->getServiceInfoStr(&tmp_portOrName, protocol);
                       }
                    
                    RCODE getServiceInfoStrChars( const WCHAR*    portOrNameStr /* [in,flat] wchar  portOrNameStr[]  */
                                                , SIZE_T    portOrNameStrSize /* [in] size_t  portOrNameStrSize  */
                                                , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                                )
                       {
                    
                    
                    
                        return pif->getServiceInfoStrChars(portOrNameStr, portOrNameStrSize, protocol);
                       }
                    
                    RCODE getServiceInfoStr2( const ::std::wstring    &portOrName
                                            , const ::std::wstring    &protocol
                                            )
                       {
                        CCliStr tmp_portOrName; CCliStr_lightCopyTo( tmp_portOrName, portOrName);
                        CCliStr tmp_protocol; CCliStr_lightCopyTo( tmp_protocol, protocol);
                        return pif->getServiceInfoStr2(&tmp_portOrName, &tmp_protocol);
                       }
                    
                    RCODE getServiceInfoStr2Chars( const WCHAR*    portOrNameStr /* [in,flat] wchar  portOrNameStr[]  */
                                                 , SIZE_T    portOrNameStrSize /* [in] size_t  portOrNameStrSize  */
                                                 , const WCHAR*    protocolStr /* [in,flat] wchar  protocolStr[]  */
                                                 , SIZE_T    protocolStrSize /* [in] size_t  protocolStrSize  */
                                                 )
                       {
                    
                    
                    
                    
                        return pif->getServiceInfoStr2Chars(portOrNameStr, portOrNameStrSize, protocolStr, protocolStrSize);
                       }
                    

            
            
            }; // class CiResolverWrapper
            
            typedef CiResolverWrapper< ::cli::CCliPtr< INTERFACE_CLI_INET_IRESOLVER     > >  CiResolver;
            typedef CiResolverWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_IRESOLVER > >  CiResolver_nrc; /* No ref counting for interface used */
            typedef CiResolverWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_IRESOLVER > >  CiResolver_tmp; /* for temporary usage, same as CiResolver_nrc */
            
            
            
            
            
        }; // namespace inet
    }; // namespace cli

#endif





#endif /* CLI_INET_IRESOLV_H */
