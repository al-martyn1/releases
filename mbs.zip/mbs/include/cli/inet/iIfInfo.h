#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INET_IIFINFO_H
#define CLI_INET_IIFINFO_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/inet/iIfInfo.h>", CLI_INET_IIFINFO_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_INET_IIFINFO_H
    #include <cli/inet/iIfInfo.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif

#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::inet::NetInterfaceType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_INET_NETINTERFACETYPE      UINT
#else
    #define ENUM_CLI_INET_NETINTERFACETYPE      UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_INET_NETINTERFACETYPE_OTHER
    #define CLI_INET_NETINTERFACETYPE_OTHER   CONSTANT_UINT(0)
#endif /* CLI_INET_NETINTERFACETYPE_OTHER */

#ifndef CLI_INET_NETINTERFACETYPE_ETHERNET
    #define CLI_INET_NETINTERFACETYPE_ETHERNET                1
#endif /* CLI_INET_NETINTERFACETYPE_ETHERNET */

#ifndef CLI_INET_NETINTERFACETYPE_TOKENRING
    #define CLI_INET_NETINTERFACETYPE_TOKENRING               2
#endif /* CLI_INET_NETINTERFACETYPE_TOKENRING */

#ifndef CLI_INET_NETINTERFACETYPE_FDDI
    #define CLI_INET_NETINTERFACETYPE_FDDI    3
#endif /* CLI_INET_NETINTERFACETYPE_FDDI */

#ifndef CLI_INET_NETINTERFACETYPE_PPP
    #define CLI_INET_NETINTERFACETYPE_PPP     4
#endif /* CLI_INET_NETINTERFACETYPE_PPP */

#ifndef CLI_INET_NETINTERFACETYPE_LOOPBACK
    #define CLI_INET_NETINTERFACETYPE_LOOPBACK                5
#endif /* CLI_INET_NETINTERFACETYPE_LOOPBACK */

#ifndef CLI_INET_NETINTERFACETYPE_SLIP
    #define CLI_INET_NETINTERFACETYPE_SLIP    6
#endif /* CLI_INET_NETINTERFACETYPE_SLIP */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            namespace NetInterfaceType {
                    const UINT other            = CONSTANT_UINT(0);
                    const UINT ethernet         = CONSTANT_UINT(1);
                    const UINT tokenring        = CONSTANT_UINT(2);
                    const UINT fddi             = CONSTANT_UINT(3);
                    const UINT ppp              = CONSTANT_UINT(4);
                    const UINT loopback         = CONSTANT_UINT(5);
                    const UINT slip             = CONSTANT_UINT(6);
            }; // namespace NetInterfaceType
        }; // namespace inet
    }; // namespace cli
    /* using namespace ::cli::inet::NetInterfaceType; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::inet::NetInterfaceFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_INET_NETINTERFACEFLAGS     UINT
#else
    #define ENUM_CLI_INET_NETINTERFACEFLAGS     UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_INET_NETINTERFACEFLAGS_OFF
    #define CLI_INET_NETINTERFACEFLAGS_OFF    CONSTANT_UINT(0)
#endif /* CLI_INET_NETINTERFACEFLAGS_OFF */

#ifndef CLI_INET_NETINTERFACEFLAGS_ON
    #define CLI_INET_NETINTERFACEFLAGS_ON     1
#endif /* CLI_INET_NETINTERFACEFLAGS_ON */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            namespace NetInterfaceFlags {
                    const UINT off              = CONSTANT_UINT(0);
                    const UINT on               = CONSTANT_UINT(1);
            }; // namespace NetInterfaceFlags
        }; // namespace inet
    }; // namespace cli
    /* using namespace ::cli::inet::NetInterfaceFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::inet::CNetInterfaceIpInfo */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            struct                                   IpAddress;
            #ifndef STRUCT_CLI_INET_IPADDRESS
                #define STRUCT_CLI_INET_IPADDRESS         ::cli::inet::IpAddress
            #endif

        }; // namespace inet
    }; // namespace cli

#else /* C-like declarations */

    #ifndef STRUCT_CLI_INET_IPADDRESS_PREDECLARED
    #define STRUCT_CLI_INET_IPADDRESS_PREDECLARED
    typedef struct tag_cli_inet_IpAddress    cli_inet_IpAddress;
    #endif //STRUCT_CLI_INET_IPADDRESS
    #ifndef STRUCT_CLI_INET_IPADDRESS
        #define STRUCT_CLI_INET_IPADDRESS         struct tag_cli_inet_IpAddress
    #endif


#endif /* end of C-like declarations */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
    #define CLI_STRUCT_NAME                   CNetInterfaceIpInfo
    #ifndef STRUCT_CLI_INET_CNETINTERFACEIPINFO_PREDECLARED
    #define STRUCT_CLI_INET_CNETINTERFACEIPINFO_PREDECLARED
        struct CNetInterfaceIpInfo;
        #ifndef STRUCT_CLI_INET_CNETINTERFACEIPINFO
            #define STRUCT_CLI_INET_CNETINTERFACEIPINFO               ::cli::inet::CNetInterfaceIpInfo
        #endif
    #endif // STRUCT_CLI_INET_CNETINTERFACEIPINFO_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_inet_CNetInterfaceIpInfo
    #ifndef STRUCT_CLI_INET_CNETINTERFACEIPINFO_PREDECLARED
    #define STRUCT_CLI_INET_CNETINTERFACEIPINFO_PREDECLARED
        struct  tag_cli_inet_CNetInterfaceIpInfo;
        typedef struct tag_cli_inet_CNetInterfaceIpInfo cli_inet_CNetInterfaceIpInfo;
        #ifndef STRUCT_CLI_INET_CNETINTERFACEIPINFO
            #define STRUCT_CLI_INET_CNETINTERFACEIPINFO               struct tag_cli_inet_CNetInterfaceIpInfo
        #endif
    #endif // STRUCT_CLI_INET_CNETINTERFACEIPINFO_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_INET_CNETINTERFACEIPINFO_DEFINED
            #define STRUCT_CLI_INET_CNETINTERFACEIPINFO_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                UINT                        interfaceId;
                ENUM_CLI_INET_IPADDRESSFAMILY           af;
                STRUCT_CLI_INET_IPADDRESS               addr;
                STRUCT_CLI_INET_IPADDRESS               mask;
                STRUCT_CLI_INET_IPADDRESS               broadcastAddr;
                ENUM_CLI_INET_NETINTERFACETYPE          interfaceType;
                ENUM_CLI_INET_NETINTERFACEFLAGS         interfaceFlags;
                SIZE_T                      macAddressSize;
                BYTE                        macAddress[32];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_INET_CNETINTERFACEIPINFO_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::inet::iNetInterfaceInfo */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace inet {
        }; // namespace inet
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_INET_INETINTERFACEINFO_IID
    #define INTERFACE_CLI_INET_INETINTERFACEINFO_IID    "/cli/inet/iNetInterfaceInfo"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace inet {
    #define INTERFACE iNetInterfaceInfo
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_INET_INETINTERFACEINFO
       #define INTERFACE_CLI_INET_INETINTERFACEINFO    ::cli::inet::iNetInterfaceInfo
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_inet_iNetInterfaceInfo
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_INET_INETINTERFACEINFO
       #define INTERFACE_CLI_INET_INETINTERFACEINFO    cli_inet_iNetInterfaceInfo
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::inet::iNetInterfaceInfo methods */
                CLIMETHOD(netInterfaceIpInfoGet) (THIS_ STRUCT_CLI_INET_CNETINTERFACEIPINFO*    _netInterfaceIpInfo /* [out] ::cli::inet::CNetInterfaceIpInfo _netInterfaceIpInfo  */
                                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                 ) PURE;
                CLIMETHOD(netInterfaceIpInfoSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(netInterfaceInternalNameGet) (THIS_ CLISTR*           _netInterfaceInternalName
                                                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                       ) PURE;
                CLIMETHOD(netInterfaceInternalNameSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(netInterfaceNameGet) (THIS_ CLISTR*           _netInterfaceName
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               ) PURE;
                CLIMETHOD(netInterfaceNameSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(netInterfaceDescriptionGet) (THIS_ CLISTR*           _netInterfaceDescription
                                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                      ) PURE;
                CLIMETHOD(netInterfaceDescriptionSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD(netInterfaceDeviceNameGet) (THIS_ CLISTR*           _netInterfaceDeviceName
                                                          , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                     ) PURE;
                CLIMETHOD(netInterfaceDeviceNameSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
                CLIMETHOD_(SIZE_T, getInfoSize) (THIS) PURE;
                CLIMETHOD(formatMacToString) (THIS_ const BYTE*    macAddr /* [in,flat] byte  macAddr[]  */
                                                  , SIZE_T    macAddrSize /* [in] size_t  macAddrSize  */
                                                  , CLISTR*           strMac
                                             ) PURE;
                CLIMETHOD(formatIpAddrToString) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */
                                                     , CLISTR*           strIpAddr
                                                ) PURE;
                CLIMETHOD(formatSockAddrToString) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    addr /* [in,ref] ::cli::inet::SocketAddress  addr  */
                                                       , BOOL    addrOnly /* [in] bool  addrOnly  */
                                                       , CLISTR*           strAddr
                                                  ) PURE;
                CLIMETHOD(queryNetInterfaceIpInfo) (THIS) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::inet::iNetInterfaceInfo >
           {
            static char const * getName() { return INTERFACE_CLI_INET_INETINTERFACEINFO_IID; }
           };
        template<> struct CIidOfImpl< ::cli::inet::iNetInterfaceInfo* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::inet::iNetInterfaceInfo > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace inet {
            // interface ::cli::inet::iNetInterfaceInfo wrapper
            // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_INET_INETINTERFACEINFO >
                                          */
                     >
            class CiNetInterfaceInfoWrapper
            {
                public:
            
                    typedef  CiNetInterfaceInfoWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiNetInterfaceInfoWrapper() :
                       pif(0) {}
            
                    CiNetInterfaceInfoWrapper( iNetInterfaceInfo *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiNetInterfaceInfoWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiNetInterfaceInfoWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiNetInterfaceInfoWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiNetInterfaceInfoWrapper(const CiNetInterfaceInfoWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiNetInterfaceInfoWrapper()  { }
            
                    CiNetInterfaceInfoWrapper& operator=(const CiNetInterfaceInfoWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    STRUCT_CLI_INET_CNETINTERFACEIPINFO get_netInterfaceIpInfo( SIZE_T idx1 )
                       {
                        STRUCT_CLI_INET_CNETINTERFACEIPINFO tmpVal;
                        RCODE res = netInterfaceIpInfoGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_netInterfaceIpInfo(  )
                       {
                        SIZE_T size;
                        RCODE res = netInterfaceIpInfoSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, STRUCT_CLI_INET_CNETINTERFACEIPINFO, netInterfaceIpInfo, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE netInterfaceIpInfoGet( STRUCT_CLI_INET_CNETINTERFACEIPINFO    &_netInterfaceIpInfo /* [out] ::cli::inet::CNetInterfaceIpInfo _netInterfaceIpInfo  (struct passed by ref in wrapper) */
                                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                                               )
                       {
                    
                    
                        return pif->netInterfaceIpInfoGet(&_netInterfaceIpInfo, idx1);
                       }
                    
                    RCODE netInterfaceIpInfoSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->netInterfaceIpInfoSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_netInterfaceInternalName( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = netInterfaceInternalNameGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_netInterfaceInternalName(  )
                       {
                        SIZE_T size;
                        RCODE res = netInterfaceInternalNameSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, netInterfaceInternalName, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE netInterfaceInternalNameGet( ::std::wstring    &_netInterfaceInternalName
                                                     , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                     )
                       {
                        CCliStr tmp__netInterfaceInternalName; CCliStr_init( tmp__netInterfaceInternalName );
                    
                        RCODE res = pif->netInterfaceInternalNameGet(&tmp__netInterfaceInternalName, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _netInterfaceInternalName, tmp__netInterfaceInternalName);
                           }
                        return res;
                       }
                    
                    RCODE netInterfaceInternalNameSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->netInterfaceInternalNameSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_netInterfaceName( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = netInterfaceNameGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_netInterfaceName(  )
                       {
                        SIZE_T size;
                        RCODE res = netInterfaceNameSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, netInterfaceName, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE netInterfaceNameGet( ::std::wstring    &_netInterfaceName
                                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                                             )
                       {
                        CCliStr tmp__netInterfaceName; CCliStr_init( tmp__netInterfaceName );
                    
                        RCODE res = pif->netInterfaceNameGet(&tmp__netInterfaceName, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _netInterfaceName, tmp__netInterfaceName);
                           }
                        return res;
                       }
                    
                    RCODE netInterfaceNameSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->netInterfaceNameSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_netInterfaceDescription( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = netInterfaceDescriptionGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_netInterfaceDescription(  )
                       {
                        SIZE_T size;
                        RCODE res = netInterfaceDescriptionSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, netInterfaceDescription, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE netInterfaceDescriptionGet( ::std::wstring    &_netInterfaceDescription
                                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                    )
                       {
                        CCliStr tmp__netInterfaceDescription; CCliStr_init( tmp__netInterfaceDescription );
                    
                        RCODE res = pif->netInterfaceDescriptionGet(&tmp__netInterfaceDescription, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _netInterfaceDescription, tmp__netInterfaceDescription);
                           }
                        return res;
                       }
                    
                    RCODE netInterfaceDescriptionSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->netInterfaceDescriptionSize(_size);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_netInterfaceDeviceName( SIZE_T idx1 )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = netInterfaceDeviceNameGet( tmpVal, idx1);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    SIZE_T size_netInterfaceDeviceName(  )
                       {
                        SIZE_T size;
                        RCODE res = netInterfaceDeviceNameSize( &size );
                        CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                        return size;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, netInterfaceDeviceName, SIZE_T );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE netInterfaceDeviceNameGet( ::std::wstring    &_netInterfaceDeviceName
                                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                                                   )
                       {
                        CCliStr tmp__netInterfaceDeviceName; CCliStr_init( tmp__netInterfaceDeviceName );
                    
                        RCODE res = pif->netInterfaceDeviceNameGet(&tmp__netInterfaceDeviceName, idx1);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _netInterfaceDeviceName, tmp__netInterfaceDeviceName);
                           }
                        return res;
                       }
                    
                    RCODE netInterfaceDeviceNameSize( SIZE_T*    _size /* [out] size_t _size  */)
                       {
                    
                        return pif->netInterfaceDeviceNameSize(_size);
                       }
                    
                    SIZE_T getInfoSize( )
                       {
                        return pif->getInfoSize();
                       }
                    
                    RCODE formatMacToString( const BYTE*    macAddr /* [in,flat] byte  macAddr[]  */
                                           , SIZE_T    macAddrSize /* [in] size_t  macAddrSize  */
                                           , ::std::wstring    &strMac
                                           )
                       {
                    
                    
                        CCliStr tmp_strMac; CCliStr_init( tmp_strMac );
                        RCODE res = pif->formatMacToString(macAddr, macAddrSize, &tmp_strMac);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( strMac, tmp_strMac);
                           }
                        return res;
                       }
                    
                    RCODE formatIpAddrToString( const STRUCT_CLI_INET_IPADDRESS    &addr /* [in,ref] ::cli::inet::IpAddress  addr  (struct passed by ref in wrapper) */
                                              , ::std::wstring    &strIpAddr
                                              )
                       {
                    
                        CCliStr tmp_strIpAddr; CCliStr_init( tmp_strIpAddr );
                        RCODE res = pif->formatIpAddrToString(&addr, &tmp_strIpAddr);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( strIpAddr, tmp_strIpAddr);
                           }
                        return res;
                       }
                    
                    RCODE formatSockAddrToString( const STRUCT_CLI_INET_SOCKETADDRESS    &addr /* [in,ref] ::cli::inet::SocketAddress  addr  (struct passed by ref in wrapper) */
                                                , BOOL    addrOnly /* [in] bool  addrOnly  */
                                                , ::std::wstring    &strAddr
                                                )
                       {
                    
                    
                        CCliStr tmp_strAddr; CCliStr_init( tmp_strAddr );
                        RCODE res = pif->formatSockAddrToString(&addr, addrOnly, &tmp_strAddr);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( strAddr, tmp_strAddr);
                           }
                        return res;
                       }
                    
                    RCODE queryNetInterfaceIpInfo( )
                       {
                        return pif->queryNetInterfaceIpInfo();
                       }
                    

            
            
            }; // class CiNetInterfaceInfoWrapper
            
            typedef CiNetInterfaceInfoWrapper< ::cli::CCliPtr< INTERFACE_CLI_INET_INETINTERFACEINFO     > >  CiNetInterfaceInfo;
            typedef CiNetInterfaceInfoWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_INETINTERFACEINFO > >  CiNetInterfaceInfo_nrc; /* No ref counting for interface used */
            typedef CiNetInterfaceInfoWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_INETINTERFACEINFO > >  CiNetInterfaceInfo_tmp; /* for temporary usage, same as CiNetInterfaceInfo_nrc */
            
            
            
            
            
        }; // namespace inet
    }; // namespace cli

#endif





#endif /* CLI_INET_IIFINFO_H */
