#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INET_ISOCK_H
#define CLI_INET_ISOCK_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/inet/isock.h>", CLI_INET_ISOCK_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_INET_ISOCK_H
    #include <cli/inet/isock.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif

#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::inet::SelectWhat */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_INET_SELECTWHAT            DWORD
#else
    #define ENUM_CLI_INET_SELECTWHAT            DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_INET_SELECTWHAT_SELECTREAD
    #define CLI_INET_SELECTWHAT_SELECTREAD    1
#endif /* CLI_INET_SELECTWHAT_SELECTREAD */

#ifndef CLI_INET_SELECTWHAT_SELECTWRITE
    #define CLI_INET_SELECTWHAT_SELECTWRITE   2
#endif /* CLI_INET_SELECTWHAT_SELECTWRITE */

#ifndef CLI_INET_SELECTWHAT_SELECTEXCEPT
    #define CLI_INET_SELECTWHAT_SELECTEXCEPT  4
#endif /* CLI_INET_SELECTWHAT_SELECTEXCEPT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            namespace SelectWhat {
                    const DWORD selectRead       = CONSTANT_DWORD(1);
                    const DWORD selectWrite      = CONSTANT_DWORD(2);
                    const DWORD selectExcept     = CONSTANT_DWORD(4);
            }; // namespace SelectWhat
        }; // namespace inet
    }; // namespace cli
    /* using namespace ::cli::inet::SelectWhat; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::inet::EUdpServerCreateServerSocketFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS     DWORD
#else
    #define ENUM_CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS     DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS_REUSEADDR
    #define CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS_REUSEADDR              1
#endif /* CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS_REUSEADDR */

#ifndef CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS_EXCLUSIVEADDRUSE
    #define CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS_EXCLUSIVEADDRUSE       2
#endif /* CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS_EXCLUSIVEADDRUSE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            namespace EUdpServerCreateServerSocketFlags {
                    const DWORD reuseAddr        = CONSTANT_DWORD(1);
                    const DWORD exclusiveAddrUse = CONSTANT_DWORD(2);
            }; // namespace EUdpServerCreateServerSocketFlags
        }; // namespace inet
    }; // namespace cli
    /* using namespace ::cli::inet::EUdpServerCreateServerSocketFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::inet::CUdpRecvData */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            struct                                   SocketAddress;
            #ifndef STRUCT_CLI_INET_SOCKETADDRESS
                #define STRUCT_CLI_INET_SOCKETADDRESS     ::cli::inet::SocketAddress
            #endif

            interface                                iSocket;
            #ifndef INTERFACE_CLI_INET_ISOCKET
                #define INTERFACE_CLI_INET_ISOCKET        ::cli::inet::iSocket
            #endif

        }; // namespace inet
    }; // namespace cli

#else /* C-like declarations */

    #ifndef STRUCT_CLI_INET_SOCKETADDRESS_PREDECLARED
    #define STRUCT_CLI_INET_SOCKETADDRESS_PREDECLARED
    typedef struct tag_cli_inet_SocketAddress                    cli_inet_SocketAddress;
    #endif //STRUCT_CLI_INET_SOCKETADDRESS
    #ifndef STRUCT_CLI_INET_SOCKETADDRESS
        #define STRUCT_CLI_INET_SOCKETADDRESS     struct tag_cli_inet_SocketAddress
    #endif

    #ifndef INTERFACE_CLI_INET_ISOCKET_PREDECLARED
    #define INTERFACE_CLI_INET_ISOCKET_PREDECLARED
    typedef interface tag_cli_inet_iSocket   cli_inet_iSocket;
    #endif //INTERFACE_CLI_INET_ISOCKET
    #ifndef INTERFACE_CLI_INET_ISOCKET
        #define INTERFACE_CLI_INET_ISOCKET        struct tag_cli_inet_iSocket
    #endif


#endif /* end of C-like declarations */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
    #define CLI_STRUCT_NAME                   CUdpRecvData
    #ifndef STRUCT_CLI_INET_CUDPRECVDATA_PREDECLARED
    #define STRUCT_CLI_INET_CUDPRECVDATA_PREDECLARED
        struct CUdpRecvData;
        #ifndef STRUCT_CLI_INET_CUDPRECVDATA
            #define STRUCT_CLI_INET_CUDPRECVDATA      ::cli::inet::CUdpRecvData
        #endif
    #endif // STRUCT_CLI_INET_CUDPRECVDATA_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_inet_CUdpRecvData
    #ifndef STRUCT_CLI_INET_CUDPRECVDATA_PREDECLARED
    #define STRUCT_CLI_INET_CUDPRECVDATA_PREDECLARED
        struct  tag_cli_inet_CUdpRecvData;
        typedef struct tag_cli_inet_CUdpRecvData cli_inet_CUdpRecvData;
        #ifndef STRUCT_CLI_INET_CUDPRECVDATA
            #define STRUCT_CLI_INET_CUDPRECVDATA      struct tag_cli_inet_CUdpRecvData
        #endif
    #endif // STRUCT_CLI_INET_CUDPRECVDATA_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_INET_CUDPRECVDATA_DEFINED
            #define STRUCT_CLI_INET_CUDPRECVDATA_DEFINED
            #include <cli/pshpack4.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                INTERFACE_CLI_INET_ISOCKET            * socket;
                SIZE_T                      receivedBytes;
                STRUCT_CLI_INET_SOCKETADDRESS           localAddr;
                STRUCT_CLI_INET_SOCKETADDRESS           recevedFrom;
                BYTE                        dataBuf[4000];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_INET_CUDPRECVDATA_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::inet::iSocket */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli
    namespace cli {
        namespace inet {
        }; // namespace inet
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_INET_ISOCKET_IID
    #define INTERFACE_CLI_INET_ISOCKET_IID    "/cli/inet/iSocket"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace inet {
    #define INTERFACE iSocket
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_INET_ISOCKET
       #define INTERFACE_CLI_INET_ISOCKET    ::cli::inet::iSocket
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_inet_iSocket
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_INET_ISOCKET
       #define INTERFACE_CLI_INET_ISOCKET    cli_inet_iSocket
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::inet::iSocket methods */
                CLIMETHOD(handleGet) (THIS_ SYS_SOCKET_HANDLE*    _handle /* [out] sys_socket_handle _handle  */) PURE;
                CLIMETHOD(handleSet) (THIS_ SYS_SOCKET_HANDLE    _handle /* [in] sys_socket_handle  _handle  */) PURE;
                CLIMETHOD(socketTypeGet) (THIS_ ENUM_CLI_INET_SOCKETTYPE*    _socketType /* [out] ::cli::inet::SocketType _socketType  */) PURE;
                CLIMETHOD(localAddrGet) (THIS_ STRUCT_CLI_INET_SOCKETADDRESS*    _localAddr /* [out] ::cli::inet::SocketAddress _localAddr  */) PURE;
                CLIMETHOD(peerAddrGet) (THIS_ STRUCT_CLI_INET_SOCKETADDRESS*    _peerAddr /* [out] ::cli::inet::SocketAddress _peerAddr  */) PURE;
                CLIMETHOD(broadcastModeGet) (THIS_ BOOL*    _broadcastMode /* [out] bool _broadcastMode  */) PURE;
                CLIMETHOD(broadcastModeSet) (THIS_ BOOL    _broadcastMode /* [in] bool  _broadcastMode  */) PURE;
                CLIMETHOD(reuseAddrGet) (THIS_ BOOL*    _reuseAddr /* [out] bool _reuseAddr  */) PURE;
                CLIMETHOD(reuseAddrSet) (THIS_ BOOL    _reuseAddr /* [in] bool  _reuseAddr  */) PURE;
                CLIMETHOD(reusePortGet) (THIS_ BOOL*    _reusePort /* [out] bool _reusePort  */) PURE;
                CLIMETHOD(reusePortSet) (THIS_ BOOL    _reusePort /* [in] bool  _reusePort  */) PURE;
                CLIMETHOD(exclusiveAddrUseGet) (THIS_ BOOL*    _exclusiveAddrUse /* [out] bool _exclusiveAddrUse  */) PURE;
                CLIMETHOD(exclusiveAddrUseSet) (THIS_ BOOL    _exclusiveAddrUse /* [in] bool  _exclusiveAddrUse  */) PURE;
                CLIMETHOD(tcpNoDelayGet) (THIS_ BOOL*    _tcpNoDelay /* [out] bool _tcpNoDelay  */) PURE;
                CLIMETHOD(tcpNoDelaySet) (THIS_ BOOL    _tcpNoDelay /* [in] bool  _tcpNoDelay  */) PURE;
                CLIMETHOD(defMulticastGroupInterfaceGet) (THIS_ STRUCT_CLI_INET_IPADDRESS*    _defMulticastGroupInterface /* [out] ::cli::inet::IpAddress _defMulticastGroupInterface  */) PURE;
                CLIMETHOD(defMulticastGroupInterfaceSet) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    _defMulticastGroupInterface /* [in,ref] ::cli::inet::IpAddress  _defMulticastGroupInterface  */) PURE;
                CLIMETHOD(createSocketEx) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                               , ENUM_CLI_INET_SOCKETTYPE    type /* [in] ::cli::inet::SocketType  type  */
                                               , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                               , BOOL    bNonBlock /* [in] bool  bNonBlock  */
                                          ) PURE;
                CLIMETHOD(createSocket) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                             , ENUM_CLI_INET_SOCKETTYPE    type /* [in] ::cli::inet::SocketType  type  */
                                             , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                        ) PURE;
                CLIMETHOD(closeSocket) (THIS) PURE;
                CLIMETHOD(connectSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */) PURE;
                CLIMETHOD(selectSocket) (THIS_ ENUM_CLI_INET_SELECTWHAT    selectFor /* [in] ::cli::inet::SelectWhat  selectFor  */
                                             , ENUM_CLI_INET_SELECTWHAT*    readyFor /* [out] ::cli::inet::SelectWhat readyFor  */
                                             , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                        ) PURE;
                CLIMETHOD(bindSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */) PURE;
                CLIMETHOD(bindSocketStr) (THIS_ const CLISTR*     addr
                                              , const CLISTR*     port
                                              , const CLISTR*     protocol
                                         ) PURE;
                CLIMETHOD(listenSocket) (THIS) PURE;
                CLIMETHOD(setMulticastInterface) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */) PURE;
                CLIMETHOD(getMulticastInterface) (THIS_ STRUCT_CLI_INET_IPADDRESS*    addr /* [out] ::cli::inet::IpAddress addr  */) PURE;
                CLIMETHOD(setMulticastInterfaceId) (THIS_ UINT    ifId /* [in] uint  ifId  */) PURE;
                CLIMETHOD(getMulticastInterfaceId) (THIS_ UINT*    ifId /* [out] uint ifId  */) PURE;
                CLIMETHOD(setMulticastInterfaceStr) (THIS_ const CLISTR*     addr) PURE;
                CLIMETHOD(getMulticastInterfaceStr) (THIS_ CLISTR*           addr) PURE;
                CLIMETHOD(setMulticastLoop) (THIS_ BOOL    loopOn /* [in] bool  loopOn  */) PURE;
                CLIMETHOD(getMulticastLoop) (THIS_ BOOL*    loopState /* [out] bool loopState  */) PURE;
                CLIMETHOD(acceptSocketConnection) (THIS_ SYS_SOCKET_HANDLE*    hAccepted /* [out] sys_socket_handle hAccepted  */
                                                       , STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [out] ::cli::inet::SocketAddress sa  */
                                                       , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                                  ) PURE;
                CLIMETHOD(waitAsyncConnect) (THIS_ TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */) PURE;
                CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                     , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                     , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                ) PURE;
                CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                            , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                            , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                            , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                       ) PURE;
                CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                      , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                      , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 ) PURE;
                CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                             , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                             , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                             , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                        ) PURE;
                CLIMETHOD(recvFrom) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                         , STRUCT_CLI_INET_SOCKETADDRESS*    localAddr /* [out,ref] ::cli::inet::SocketAddress localAddr  */
                                         , STRUCT_CLI_INET_SOCKETADDRESS*    peerAddr /* [out,ref] ::cli::inet::SocketAddress peerAddr  */
                                    ) PURE;
                CLIMETHOD(recvFromTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                                , STRUCT_CLI_INET_SOCKETADDRESS*    localAddr /* [out,ref] ::cli::inet::SocketAddress localAddr  */
                                                , STRUCT_CLI_INET_SOCKETADDRESS*    peerAddr /* [out,ref] ::cli::inet::SocketAddress peerAddr  */
                                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                           ) PURE;
                CLIMETHOD(sendTo) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                       , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                       , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                       , const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */
                                  ) PURE;
                CLIMETHOD(sendToTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                              , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                              , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                              , const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */
                                              , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                         ) PURE;
                CLIMETHOD(joinToMulticastGroup) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */) PURE;
                CLIMETHOD(joinToMulticastGroupStr) (THIS_ const CLISTR*     addr) PURE;
                CLIMETHOD(leaveMulticastGroup) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */) PURE;
                CLIMETHOD(leaveMulticastGroupStr) (THIS_ const CLISTR*     addr) PURE;
                CLIMETHOD(joinToMulticastGroupEx) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */
                                                       , const STRUCT_CLI_INET_IPADDRESS*    ifAddr /* [in,ref] ::cli::inet::IpAddress  ifAddr  */
                                                  ) PURE;
                CLIMETHOD(joinToMulticastGroupExStr) (THIS_ const CLISTR*     addr
                                                          , const CLISTR*     ifAddr
                                                     ) PURE;
                CLIMETHOD(leaveMulticastGroupEx) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */
                                                      , const STRUCT_CLI_INET_IPADDRESS*    ifAddr /* [in,ref] ::cli::inet::IpAddress  ifAddr  */
                                                 ) PURE;
                CLIMETHOD(leaveMulticastGroupExStr) (THIS_ const CLISTR*     addr
                                                         , const CLISTR*     ifAddr
                                                    ) PURE;
                CLIMETHOD(multicastTTLGet) (THIS_ UINT*    _multicastTTL /* [out] uint _multicastTTL  */) PURE;
                CLIMETHOD(multicastTTLSet) (THIS_ UINT    _multicastTTL /* [in] uint  _multicastTTL  */) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::inet::iSocket >
           {
            static char const * getName() { return INTERFACE_CLI_INET_ISOCKET_IID; }
           };
        template<> struct CIidOfImpl< ::cli::inet::iSocket* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::inet::iSocket > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace inet {
            // interface ::cli::inet::iSocket wrapper
            // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_INET_ISOCKET >
                                          */
                     >
            class CiSocketWrapper
            {
                public:
            
                    typedef  CiSocketWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiSocketWrapper() :
                       pif(0) {}
            
                    CiSocketWrapper( iSocket *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiSocketWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiSocketWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiSocketWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiSocketWrapper(const CiSocketWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiSocketWrapper()  { }
            
                    CiSocketWrapper& operator=(const CiSocketWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    SYS_SOCKET_HANDLE get_handle( )
                       {
                        SYS_SOCKET_HANDLE tmpVal;
                        RCODE res = handleGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_handle( SYS_SOCKET_HANDLE _handle
                                   )
                       {
                        RCODE res = handleSet( _handle );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, SYS_SOCKET_HANDLE, handle );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE handleGet( SYS_SOCKET_HANDLE*    _handle /* [out] sys_socket_handle _handle  */)
                       {
                    
                        return pif->handleGet(_handle);
                       }
                    
                    RCODE handleSet( SYS_SOCKET_HANDLE    _handle /* [in] sys_socket_handle  _handle  */)
                       {
                    
                        return pif->handleSet(_handle);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ENUM_CLI_INET_SOCKETTYPE get_socketType( )
                       {
                        ENUM_CLI_INET_SOCKETTYPE tmpVal;
                        RCODE res = socketTypeGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, ENUM_CLI_INET_SOCKETTYPE, socketType );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE socketTypeGet( ENUM_CLI_INET_SOCKETTYPE*    _socketType /* [out] ::cli::inet::SocketType _socketType  */)
                       {
                    
                        return pif->socketTypeGet(_socketType);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    STRUCT_CLI_INET_SOCKETADDRESS get_localAddr( )
                       {
                        STRUCT_CLI_INET_SOCKETADDRESS tmpVal;
                        RCODE res = localAddrGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, STRUCT_CLI_INET_SOCKETADDRESS, localAddr );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE localAddrGet( STRUCT_CLI_INET_SOCKETADDRESS    &_localAddr /* [out] ::cli::inet::SocketAddress _localAddr  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->localAddrGet(&_localAddr);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    STRUCT_CLI_INET_SOCKETADDRESS get_peerAddr( )
                       {
                        STRUCT_CLI_INET_SOCKETADDRESS tmpVal;
                        RCODE res = peerAddrGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, STRUCT_CLI_INET_SOCKETADDRESS, peerAddr );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE peerAddrGet( STRUCT_CLI_INET_SOCKETADDRESS    &_peerAddr /* [out] ::cli::inet::SocketAddress _peerAddr  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->peerAddrGet(&_peerAddr);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    BOOL get_broadcastMode( )
                       {
                        BOOL tmpVal;
                        RCODE res = broadcastModeGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_broadcastMode( BOOL _broadcastMode
                                          )
                       {
                        RCODE res = broadcastModeSet( _broadcastMode );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, broadcastMode );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE broadcastModeGet( BOOL*    _broadcastMode /* [out] bool _broadcastMode  */)
                       {
                    
                        return pif->broadcastModeGet(_broadcastMode);
                       }
                    
                    RCODE broadcastModeSet( BOOL    _broadcastMode /* [in] bool  _broadcastMode  */)
                       {
                    
                        return pif->broadcastModeSet(_broadcastMode);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    BOOL get_reuseAddr( )
                       {
                        BOOL tmpVal;
                        RCODE res = reuseAddrGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_reuseAddr( BOOL _reuseAddr
                                      )
                       {
                        RCODE res = reuseAddrSet( _reuseAddr );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, reuseAddr );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE reuseAddrGet( BOOL*    _reuseAddr /* [out] bool _reuseAddr  */)
                       {
                    
                        return pif->reuseAddrGet(_reuseAddr);
                       }
                    
                    RCODE reuseAddrSet( BOOL    _reuseAddr /* [in] bool  _reuseAddr  */)
                       {
                    
                        return pif->reuseAddrSet(_reuseAddr);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    BOOL get_reusePort( )
                       {
                        BOOL tmpVal;
                        RCODE res = reusePortGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_reusePort( BOOL _reusePort
                                      )
                       {
                        RCODE res = reusePortSet( _reusePort );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, reusePort );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE reusePortGet( BOOL*    _reusePort /* [out] bool _reusePort  */)
                       {
                    
                        return pif->reusePortGet(_reusePort);
                       }
                    
                    RCODE reusePortSet( BOOL    _reusePort /* [in] bool  _reusePort  */)
                       {
                    
                        return pif->reusePortSet(_reusePort);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    BOOL get_exclusiveAddrUse( )
                       {
                        BOOL tmpVal;
                        RCODE res = exclusiveAddrUseGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_exclusiveAddrUse( BOOL _exclusiveAddrUse
                                             )
                       {
                        RCODE res = exclusiveAddrUseSet( _exclusiveAddrUse );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, exclusiveAddrUse );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE exclusiveAddrUseGet( BOOL*    _exclusiveAddrUse /* [out] bool _exclusiveAddrUse  */)
                       {
                    
                        return pif->exclusiveAddrUseGet(_exclusiveAddrUse);
                       }
                    
                    RCODE exclusiveAddrUseSet( BOOL    _exclusiveAddrUse /* [in] bool  _exclusiveAddrUse  */)
                       {
                    
                        return pif->exclusiveAddrUseSet(_exclusiveAddrUse);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    BOOL get_tcpNoDelay( )
                       {
                        BOOL tmpVal;
                        RCODE res = tcpNoDelayGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_tcpNoDelay( BOOL _tcpNoDelay
                                       )
                       {
                        RCODE res = tcpNoDelaySet( _tcpNoDelay );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, tcpNoDelay );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE tcpNoDelayGet( BOOL*    _tcpNoDelay /* [out] bool _tcpNoDelay  */)
                       {
                    
                        return pif->tcpNoDelayGet(_tcpNoDelay);
                       }
                    
                    RCODE tcpNoDelaySet( BOOL    _tcpNoDelay /* [in] bool  _tcpNoDelay  */)
                       {
                    
                        return pif->tcpNoDelaySet(_tcpNoDelay);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    STRUCT_CLI_INET_IPADDRESS get_defMulticastGroupInterface( )
                       {
                        STRUCT_CLI_INET_IPADDRESS tmpVal;
                        RCODE res = defMulticastGroupInterfaceGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_defMulticastGroupInterface( const STRUCT_CLI_INET_IPADDRESS &_defMulticastGroupInterface
                                                       )
                       {
                        RCODE res = defMulticastGroupInterfaceSet( _defMulticastGroupInterface );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, STRUCT_CLI_INET_IPADDRESS, defMulticastGroupInterface );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE defMulticastGroupInterfaceGet( STRUCT_CLI_INET_IPADDRESS    &_defMulticastGroupInterface /* [out] ::cli::inet::IpAddress _defMulticastGroupInterface  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->defMulticastGroupInterfaceGet(&_defMulticastGroupInterface);
                       }
                    
                    RCODE defMulticastGroupInterfaceSet( const STRUCT_CLI_INET_IPADDRESS    &_defMulticastGroupInterface /* [in,ref] ::cli::inet::IpAddress  _defMulticastGroupInterface  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->defMulticastGroupInterfaceSet(&_defMulticastGroupInterface);
                       }
                    
                    RCODE createSocketEx( ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                        , ENUM_CLI_INET_SOCKETTYPE    type /* [in] ::cli::inet::SocketType  type  */
                                        , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                        , BOOL    bNonBlock /* [in] bool  bNonBlock  */
                                        )
                       {
                    
                    
                    
                    
                        return pif->createSocketEx(af, type, protocol, bNonBlock);
                       }
                    
                    RCODE createSocket( ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                      , ENUM_CLI_INET_SOCKETTYPE    type /* [in] ::cli::inet::SocketType  type  */
                                      , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                      )
                       {
                    
                    
                    
                        return pif->createSocket(af, type, protocol);
                       }
                    
                    RCODE closeSocket( )
                       {
                        return pif->closeSocket();
                       }
                    
                    RCODE connectSocket( const STRUCT_CLI_INET_SOCKETADDRESS    &sa /* [in,ref] ::cli::inet::SocketAddress  sa  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->connectSocket(&sa);
                       }
                    
                    RCODE selectSocket( ENUM_CLI_INET_SELECTWHAT    selectFor /* [in] ::cli::inet::SelectWhat  selectFor  */
                                      , ENUM_CLI_INET_SELECTWHAT*    readyFor /* [out] ::cli::inet::SelectWhat readyFor  */
                                      , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                      )
                       {
                    
                    
                    
                        return pif->selectSocket(selectFor, readyFor, millisecTimeout);
                       }
                    
                    RCODE bindSocket( const STRUCT_CLI_INET_SOCKETADDRESS    &sa /* [in,ref] ::cli::inet::SocketAddress  sa  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->bindSocket(&sa);
                       }
                    
                    RCODE bindSocketStr( const ::std::wstring    &addr
                                       , const ::std::wstring    &port
                                       , const ::std::wstring    &protocol
                                       )
                       {
                        CCliStr tmp_addr; CCliStr_lightCopyTo( tmp_addr, addr);
                        CCliStr tmp_port; CCliStr_lightCopyTo( tmp_port, port);
                        CCliStr tmp_protocol; CCliStr_lightCopyTo( tmp_protocol, protocol);
                        return pif->bindSocketStr(&tmp_addr, &tmp_port, &tmp_protocol);
                       }
                    
                    RCODE listenSocket( )
                       {
                        return pif->listenSocket();
                       }
                    
                    RCODE setMulticastInterface( const STRUCT_CLI_INET_IPADDRESS    &addr /* [in,ref] ::cli::inet::IpAddress  addr  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->setMulticastInterface(&addr);
                       }
                    
                    RCODE getMulticastInterface( STRUCT_CLI_INET_IPADDRESS    &addr /* [out] ::cli::inet::IpAddress addr  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->getMulticastInterface(&addr);
                       }
                    
                    RCODE setMulticastInterfaceId( UINT    ifId /* [in] uint  ifId  */)
                       {
                    
                        return pif->setMulticastInterfaceId(ifId);
                       }
                    
                    RCODE getMulticastInterfaceId( UINT*    ifId /* [out] uint ifId  */)
                       {
                    
                        return pif->getMulticastInterfaceId(ifId);
                       }
                    
                    RCODE setMulticastInterfaceStr( const ::std::wstring    &addr)
                       {
                        CCliStr tmp_addr; CCliStr_lightCopyTo( tmp_addr, addr);
                        return pif->setMulticastInterfaceStr(&tmp_addr);
                       }
                    
                    RCODE getMulticastInterfaceStr( ::std::wstring    &addr)
                       {
                        CCliStr tmp_addr; CCliStr_init( tmp_addr );
                        RCODE res = pif->getMulticastInterfaceStr(&tmp_addr);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( addr, tmp_addr);
                           }
                        return res;
                       }
                    
                    RCODE setMulticastLoop( BOOL    loopOn /* [in] bool  loopOn  */)
                       {
                    
                        return pif->setMulticastLoop(loopOn);
                       }
                    
                    RCODE getMulticastLoop( BOOL*    loopState /* [out] bool loopState  */)
                       {
                    
                        return pif->getMulticastLoop(loopState);
                       }
                    
                    RCODE acceptSocketConnection( SYS_SOCKET_HANDLE*    hAccepted /* [out] sys_socket_handle hAccepted  */
                                                , STRUCT_CLI_INET_SOCKETADDRESS    &sa /* [out] ::cli::inet::SocketAddress sa  (struct passed by ref in wrapper) */
                                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                                )
                       {
                    
                    
                    
                        return pif->acceptSocketConnection(hAccepted, &sa, millisecTimeout);
                       }
                    
                    RCODE waitAsyncConnect( TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */)
                       {
                    
                        return pif->waitAsyncConnect(millisecTimeout);
                       }
                    
                    RCODE read( VOID*    buf /* [out,flat] void buf[]  */
                              , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                              , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                              )
                       {
                    
                    
                    
                        return pif->read(buf, numBytesToRead, numBytesReaded);
                       }
                    
                    RCODE readTimeout( VOID*    buf /* [out,flat] void buf[]  */
                                     , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                     , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                     , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                     )
                       {
                    
                    
                    
                    
                        return pif->readTimeout(buf, numBytesToRead, numBytesReaded, millisecTimeout);
                       }
                    
                    RCODE write( const VOID*    buf /* [in,flat] void  buf[]  */
                               , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                               , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                               )
                       {
                    
                    
                    
                        return pif->write(buf, numBytesToWrite, numBytesWritten);
                       }
                    
                    RCODE writeTimeout( const VOID*    buf /* [in,flat] void  buf[]  */
                                      , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                      , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                      , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                      )
                       {
                    
                    
                    
                    
                        return pif->writeTimeout(buf, numBytesToWrite, numBytesWritten, millisecTimeout);
                       }
                    
                    RCODE recvFrom( const VOID*    buf /* [in,flat] void  buf[]  */
                                  , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                  , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                  , STRUCT_CLI_INET_SOCKETADDRESS    &localAddr /* [out,ref] ::cli::inet::SocketAddress localAddr  (struct passed by ref in wrapper) */
                                  , STRUCT_CLI_INET_SOCKETADDRESS    &peerAddr /* [out,ref] ::cli::inet::SocketAddress peerAddr  (struct passed by ref in wrapper) */
                                  )
                       {
                    
                    
                    
                    
                    
                        return pif->recvFrom(buf, numBytesToRead, numBytesReaded, &localAddr, &peerAddr);
                       }
                    
                    RCODE recvFromTimeout( const VOID*    buf /* [in,flat] void  buf[]  */
                                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                         , STRUCT_CLI_INET_SOCKETADDRESS    &localAddr /* [out,ref] ::cli::inet::SocketAddress localAddr  (struct passed by ref in wrapper) */
                                         , STRUCT_CLI_INET_SOCKETADDRESS    &peerAddr /* [out,ref] ::cli::inet::SocketAddress peerAddr  (struct passed by ref in wrapper) */
                                         , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                         )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->recvFromTimeout(buf, numBytesToRead, numBytesReaded, &localAddr, &peerAddr, millisecTimeout);
                       }
                    
                    RCODE sendTo( const VOID*    buf /* [in,flat] void  buf[]  */
                                , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                , const STRUCT_CLI_INET_SOCKETADDRESS    &sa /* [in,ref] ::cli::inet::SocketAddress  sa  (struct passed by ref in wrapper) */
                                )
                       {
                    
                    
                    
                    
                        return pif->sendTo(buf, numBytesToWrite, numBytesWritten, &sa);
                       }
                    
                    RCODE sendToTimeout( const VOID*    buf /* [in,flat] void  buf[]  */
                                       , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                       , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                       , const STRUCT_CLI_INET_SOCKETADDRESS    &sa /* [in,ref] ::cli::inet::SocketAddress  sa  (struct passed by ref in wrapper) */
                                       , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                       )
                       {
                    
                    
                    
                    
                    
                        return pif->sendToTimeout(buf, numBytesToWrite, numBytesWritten, &sa, millisecTimeout);
                       }
                    
                    RCODE joinToMulticastGroup( const STRUCT_CLI_INET_IPADDRESS    &addr /* [in,ref] ::cli::inet::IpAddress  addr  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->joinToMulticastGroup(&addr);
                       }
                    
                    RCODE joinToMulticastGroupStr( const ::std::wstring    &addr)
                       {
                        CCliStr tmp_addr; CCliStr_lightCopyTo( tmp_addr, addr);
                        return pif->joinToMulticastGroupStr(&tmp_addr);
                       }
                    
                    RCODE leaveMulticastGroup( const STRUCT_CLI_INET_IPADDRESS    &addr /* [in,ref] ::cli::inet::IpAddress  addr  (struct passed by ref in wrapper) */)
                       {
                    
                        return pif->leaveMulticastGroup(&addr);
                       }
                    
                    RCODE leaveMulticastGroupStr( const ::std::wstring    &addr)
                       {
                        CCliStr tmp_addr; CCliStr_lightCopyTo( tmp_addr, addr);
                        return pif->leaveMulticastGroupStr(&tmp_addr);
                       }
                    
                    RCODE joinToMulticastGroupEx( const STRUCT_CLI_INET_IPADDRESS    &addr /* [in,ref] ::cli::inet::IpAddress  addr  (struct passed by ref in wrapper) */
                                                , const STRUCT_CLI_INET_IPADDRESS    &ifAddr /* [in,ref] ::cli::inet::IpAddress  ifAddr  (struct passed by ref in wrapper) */
                                                )
                       {
                    
                    
                        return pif->joinToMulticastGroupEx(&addr, &ifAddr);
                       }
                    
                    RCODE joinToMulticastGroupExStr( const ::std::wstring    &addr
                                                   , const ::std::wstring    &ifAddr
                                                   )
                       {
                        CCliStr tmp_addr; CCliStr_lightCopyTo( tmp_addr, addr);
                        CCliStr tmp_ifAddr; CCliStr_lightCopyTo( tmp_ifAddr, ifAddr);
                        return pif->joinToMulticastGroupExStr(&tmp_addr, &tmp_ifAddr);
                       }
                    
                    RCODE leaveMulticastGroupEx( const STRUCT_CLI_INET_IPADDRESS    &addr /* [in,ref] ::cli::inet::IpAddress  addr  (struct passed by ref in wrapper) */
                                               , const STRUCT_CLI_INET_IPADDRESS    &ifAddr /* [in,ref] ::cli::inet::IpAddress  ifAddr  (struct passed by ref in wrapper) */
                                               )
                       {
                    
                    
                        return pif->leaveMulticastGroupEx(&addr, &ifAddr);
                       }
                    
                    RCODE leaveMulticastGroupExStr( const ::std::wstring    &addr
                                                  , const ::std::wstring    &ifAddr
                                                  )
                       {
                        CCliStr tmp_addr; CCliStr_lightCopyTo( tmp_addr, addr);
                        CCliStr tmp_ifAddr; CCliStr_lightCopyTo( tmp_ifAddr, ifAddr);
                        return pif->leaveMulticastGroupExStr(&tmp_addr, &tmp_ifAddr);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    UINT get_multicastTTL( )
                       {
                        UINT tmpVal;
                        RCODE res = multicastTTLGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_multicastTTL( UINT _multicastTTL
                                         )
                       {
                        RCODE res = multicastTTLSet( _multicastTTL );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, UINT, multicastTTL );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE multicastTTLGet( UINT*    _multicastTTL /* [out] uint _multicastTTL  */)
                       {
                    
                        return pif->multicastTTLGet(_multicastTTL);
                       }
                    
                    RCODE multicastTTLSet( UINT    _multicastTTL /* [in] uint  _multicastTTL  */)
                       {
                    
                        return pif->multicastTTLSet(_multicastTTL);
                       }
                    

            
            
            }; // class CiSocketWrapper
            
            typedef CiSocketWrapper< ::cli::CCliPtr< INTERFACE_CLI_INET_ISOCKET     > >  CiSocket;
            typedef CiSocketWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_ISOCKET > >  CiSocket_nrc; /* No ref counting for interface used */
            typedef CiSocketWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_ISOCKET > >  CiSocket_tmp; /* for temporary usage, same as CiSocket_nrc */
            
            
            
            
            
        }; // namespace inet
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::inet::iTcpServer */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace io {
            interface                                iIOStream;
            #ifndef INTERFACE_CLI_IO_IIOSTREAM
                #define INTERFACE_CLI_IO_IIOSTREAM        ::cli::io::iIOStream
            #endif

        }; // namespace io
    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IO_IIOSTREAM_PREDECLARED
    #define INTERFACE_CLI_IO_IIOSTREAM_PREDECLARED
    typedef interface tag_cli_io_iIOStream   cli_io_iIOStream;
    #endif //INTERFACE_CLI_IO_IIOSTREAM
    #ifndef INTERFACE_CLI_IO_IIOSTREAM
        #define INTERFACE_CLI_IO_IIOSTREAM        struct tag_cli_io_iIOStream
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_INET_ITCPSERVER_IID
    #define INTERFACE_CLI_INET_ITCPSERVER_IID    "/cli/inet/iTcpServer"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace inet {
    #define INTERFACE iTcpServer
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_INET_ITCPSERVER
       #define INTERFACE_CLI_INET_ITCPSERVER    ::cli::inet::iTcpServer
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_inet_iTcpServer
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_INET_ITCPSERVER
       #define INTERFACE_CLI_INET_ITCPSERVER    cli_inet_iTcpServer
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::inet::iTcpServer methods */
                CLIMETHOD(createServerSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */
                                                   , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                              ) PURE;
                CLIMETHOD(createServerSocketStr) (THIS_ const CLISTR*     addr
                                                      , const CLISTR*     port
                                                      , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                                 ) PURE;
                CLIMETHOD(acceptConnections) (THIS_ INTERFACE_CLI_INET_ISOCKET**    serverSockets /* [in,flat] ::cli::inet::iSocket*  serverSockets[]  */
                                                  , SIZE_T    numSockets /* [in] size_t  numSockets  */
                                                  , INTERFACE_CLI_IO_IIOSTREAM**    acceptedStreams /* [out,flat] ::cli::io::iIOStream* acceptedStreams[]  */
                                                  , SIZE_T*    acceptedStreamsCount /* [in,out] size_t acceptedStreamsCount  */
                                                  , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                             ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::inet::iTcpServer >
           {
            static char const * getName() { return INTERFACE_CLI_INET_ITCPSERVER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::inet::iTcpServer* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::inet::iTcpServer > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace inet {
            // interface ::cli::inet::iTcpServer wrapper
            // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_INET_ITCPSERVER >
                                          */
                     >
            class CiTcpServerWrapper
            {
                public:
            
                    typedef  CiTcpServerWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiTcpServerWrapper() :
                       pif(0) {}
            
                    CiTcpServerWrapper( iTcpServer *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiTcpServerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiTcpServerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiTcpServerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiTcpServerWrapper(const CiTcpServerWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiTcpServerWrapper()  { }
            
                    CiTcpServerWrapper& operator=(const CiTcpServerWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE createServerSocket( const STRUCT_CLI_INET_SOCKETADDRESS    &sa /* [in,ref] ::cli::inet::SocketAddress  sa  (struct passed by ref in wrapper) */
                                            , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                            )
                       {
                    
                    
                        return pif->createServerSocket(&sa, newSock);
                       }
                    
                    RCODE createServerSocketStr( const ::std::wstring    &addr
                                               , const ::std::wstring    &port
                                               , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                               )
                       {
                        CCliStr tmp_addr; CCliStr_lightCopyTo( tmp_addr, addr);
                        CCliStr tmp_port; CCliStr_lightCopyTo( tmp_port, port);
                    
                        return pif->createServerSocketStr(&tmp_addr, &tmp_port, newSock);
                       }
                    
                    RCODE acceptConnections( INTERFACE_CLI_INET_ISOCKET**    serverSockets /* [in,flat] ::cli::inet::iSocket*  serverSockets[]  */
                                           , SIZE_T    numSockets /* [in] size_t  numSockets  */
                                           , INTERFACE_CLI_IO_IIOSTREAM**    acceptedStreams /* [out,flat] ::cli::io::iIOStream* acceptedStreams[]  */
                                           , SIZE_T*    acceptedStreamsCount /* [in,out] size_t acceptedStreamsCount  */
                                           , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                           )
                       {
                    
                    
                    
                    
                    
                        return pif->acceptConnections(serverSockets, numSockets, acceptedStreams, acceptedStreamsCount, millisecTimeout);
                       }
                    

            
            
            }; // class CiTcpServerWrapper
            
            typedef CiTcpServerWrapper< ::cli::CCliPtr< INTERFACE_CLI_INET_ITCPSERVER     > >  CiTcpServer;
            typedef CiTcpServerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_ITCPSERVER > >  CiTcpServer_nrc; /* No ref counting for interface used */
            typedef CiTcpServerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_ITCPSERVER > >  CiTcpServer_tmp; /* for temporary usage, same as CiTcpServer_nrc */
            
            
            
            
            
        }; // namespace inet
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::inet::iUdpServer */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_INET_IUDPSERVER_IID
    #define INTERFACE_CLI_INET_IUDPSERVER_IID    "/cli/inet/iUdpServer"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace inet {
    #define INTERFACE iUdpServer
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_INET_IUDPSERVER
       #define INTERFACE_CLI_INET_IUDPSERVER    ::cli::inet::iUdpServer
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_inet_iUdpServer
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_INET_IUDPSERVER
       #define INTERFACE_CLI_INET_IUDPSERVER    cli_inet_iUdpServer
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::inet::iUdpServer methods */
                CLIMETHOD(createServerSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    bindToSockAddr /* [in,ref] ::cli::inet::SocketAddress  bindToSockAddr  */
                                                   , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                              ) PURE;
                CLIMETHOD(createServerSocketStr) (THIS_ const CLISTR*     bindToAddr
                                                      , const CLISTR*     bindToPort
                                                      , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                                 ) PURE;
                CLIMETHOD(createServerSocketEx) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    bindToSockAddr /* [in,ref] ::cli::inet::SocketAddress  bindToSockAddr  */
                                                     , ENUM_CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS    flags /* [in] ::cli::inet::EUdpServerCreateServerSocketFlags  flags  */
                                                     , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                                ) PURE;
                CLIMETHOD(createServerSocketExStr) (THIS_ const CLISTR*     bindToAddr
                                                        , const CLISTR*     bindToPort
                                                        , ENUM_CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS    flags /* [in] ::cli::inet::EUdpServerCreateServerSocketFlags  flags  */
                                                        , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                                   ) PURE;
                CLIMETHOD(createUdpClientSocket) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                                      , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                                 ) PURE;
                CLIMETHOD(receiveFrom) (THIS_ INTERFACE_CLI_INET_ISOCKET**    sockets /* [in,flat] ::cli::inet::iSocket*  sockets[]  */
                                            , SIZE_T    numSockets /* [in] size_t  numSockets  */
                                            , SIZE_T    itemSize /* [in] size_t  itemSize  */
                                            , STRUCT_CLI_INET_CUDPRECVDATA*    received /* [out,flat] ::cli::inet::CUdpRecvData received[]  */
                                            , SIZE_T*    receivedCount /* [in,out] size_t receivedCount  */
                                            , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                       ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::inet::iUdpServer >
           {
            static char const * getName() { return INTERFACE_CLI_INET_IUDPSERVER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::inet::iUdpServer* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::inet::iUdpServer > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace inet {
            // interface ::cli::inet::iUdpServer wrapper
            // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_INET_IUDPSERVER >
                                          */
                     >
            class CiUdpServerWrapper
            {
                public:
            
                    typedef  CiUdpServerWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiUdpServerWrapper() :
                       pif(0) {}
            
                    CiUdpServerWrapper( iUdpServer *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiUdpServerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiUdpServerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiUdpServerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiUdpServerWrapper(const CiUdpServerWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiUdpServerWrapper()  { }
            
                    CiUdpServerWrapper& operator=(const CiUdpServerWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    RCODE createServerSocket( const STRUCT_CLI_INET_SOCKETADDRESS    &bindToSockAddr /* [in,ref] ::cli::inet::SocketAddress  bindToSockAddr  (struct passed by ref in wrapper) */
                                            , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                            )
                       {
                    
                    
                        return pif->createServerSocket(&bindToSockAddr, newSock);
                       }
                    
                    RCODE createServerSocketStr( const ::std::wstring    &bindToAddr
                                               , const ::std::wstring    &bindToPort
                                               , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                               )
                       {
                        CCliStr tmp_bindToAddr; CCliStr_lightCopyTo( tmp_bindToAddr, bindToAddr);
                        CCliStr tmp_bindToPort; CCliStr_lightCopyTo( tmp_bindToPort, bindToPort);
                    
                        return pif->createServerSocketStr(&tmp_bindToAddr, &tmp_bindToPort, newSock);
                       }
                    
                    RCODE createServerSocketEx( const STRUCT_CLI_INET_SOCKETADDRESS    &bindToSockAddr /* [in,ref] ::cli::inet::SocketAddress  bindToSockAddr  (struct passed by ref in wrapper) */
                                              , ENUM_CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS    flags /* [in] ::cli::inet::EUdpServerCreateServerSocketFlags  flags  */
                                              , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                              )
                       {
                    
                    
                    
                        return pif->createServerSocketEx(&bindToSockAddr, flags, newSock);
                       }
                    
                    RCODE createServerSocketExStr( const ::std::wstring    &bindToAddr
                                                 , const ::std::wstring    &bindToPort
                                                 , ENUM_CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS    flags /* [in] ::cli::inet::EUdpServerCreateServerSocketFlags  flags  */
                                                 , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                                 )
                       {
                        CCliStr tmp_bindToAddr; CCliStr_lightCopyTo( tmp_bindToAddr, bindToAddr);
                        CCliStr tmp_bindToPort; CCliStr_lightCopyTo( tmp_bindToPort, bindToPort);
                    
                    
                        return pif->createServerSocketExStr(&tmp_bindToAddr, &tmp_bindToPort, flags, newSock);
                       }
                    
                    RCODE createUdpClientSocket( ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                               , INTERFACE_CLI_INET_ISOCKET**    newSock /* [out] ::cli::inet::iSocket* newSock  */
                                               )
                       {
                    
                    
                        return pif->createUdpClientSocket(af, newSock);
                       }
                    
                    RCODE receiveFrom( INTERFACE_CLI_INET_ISOCKET**    sockets /* [in,flat] ::cli::inet::iSocket*  sockets[]  */
                                     , SIZE_T    numSockets /* [in] size_t  numSockets  */
                                     , SIZE_T    itemSize /* [in] size_t  itemSize  */
                                     , STRUCT_CLI_INET_CUDPRECVDATA*    received /* [out,flat] ::cli::inet::CUdpRecvData received[]  */
                                     , SIZE_T*    receivedCount /* [in,out] size_t receivedCount  */
                                     , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                     )
                       {
                    
                    
                    
                    
                    
                    
                        return pif->receiveFrom(sockets, numSockets, itemSize, received, receivedCount, millisecTimeout);
                       }
                    

            
            
            }; // class CiUdpServerWrapper
            
            typedef CiUdpServerWrapper< ::cli::CCliPtr< INTERFACE_CLI_INET_IUDPSERVER     > >  CiUdpServer;
            typedef CiUdpServerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_IUDPSERVER > >  CiUdpServer_nrc; /* No ref counting for interface used */
            typedef CiUdpServerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INET_IUDPSERVER > >  CiUdpServer_tmp; /* for temporary usage, same as CiUdpServer_nrc */
            
            
            
            
            
        }; // namespace inet
    }; // namespace cli

#endif





#endif /* CLI_INET_ISOCK_H */
