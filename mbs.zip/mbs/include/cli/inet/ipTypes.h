#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INET_IPTYPES_H
#define CLI_INET_IPTYPES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/inet/ipTypes.h>", CLI_INET_IPTYPES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IO_IOTYPES_H
    #include <cli/io/ioTypes.h>
#endif

#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::inet::IpAddressFamily */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_INET_IPADDRESSFAMILY       UINT
#else
    #define ENUM_CLI_INET_IPADDRESSFAMILY       UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_INET_IPADDRESSFAMILY_UNSPEC
    #define CLI_INET_IPADDRESSFAMILY_UNSPEC   AF_UNSPEC
#endif /* CLI_INET_IPADDRESSFAMILY_UNSPEC */

#ifndef CLI_INET_IPADDRESSFAMILY_IPV4
    #define CLI_INET_IPADDRESSFAMILY_IPV4     AF_INET
#endif /* CLI_INET_IPADDRESSFAMILY_IPV4 */

#ifndef CLI_INET_IPADDRESSFAMILY_IPV6
    #define CLI_INET_IPADDRESSFAMILY_IPV6     AF_INET6
#endif /* CLI_INET_IPADDRESSFAMILY_IPV6 */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            namespace IpAddressFamily {
                    const UINT unspec           = AF_UNSPEC;
                    const UINT ipV4             = AF_INET;
                    const UINT ipV6             = AF_INET6;
            }; // namespace IpAddressFamily
        }; // namespace inet
    }; // namespace cli
    /* using namespace ::cli::inet::IpAddressFamily; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::inet::SocketType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_INET_SOCKETTYPE            INT
#else
    #define ENUM_CLI_INET_SOCKETTYPE            INT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_INET_SOCKETTYPE_STREAM
    #define CLI_INET_SOCKETTYPE_STREAM        SOCK_STREAM
#endif /* CLI_INET_SOCKETTYPE_STREAM */

#ifndef CLI_INET_SOCKETTYPE_DGRAM
    #define CLI_INET_SOCKETTYPE_DGRAM         SOCK_DGRAM
#endif /* CLI_INET_SOCKETTYPE_DGRAM */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            namespace SocketType {
                    const INT stream           = SOCK_STREAM;
                    const INT dgram            = SOCK_DGRAM;
            }; // namespace SocketType
        }; // namespace inet
    }; // namespace cli
    /* using namespace ::cli::inet::SocketType; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::inet::ProtocolType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_INET_PROTOCOLTYPE          INT
#else
    #define ENUM_CLI_INET_PROTOCOLTYPE          INT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_INET_PROTOCOLTYPE_UNSPEC
    #define CLI_INET_PROTOCOLTYPE_UNSPEC      IPPROTO_IP
#endif /* CLI_INET_PROTOCOLTYPE_UNSPEC */

#ifndef CLI_INET_PROTOCOLTYPE_IP
    #define CLI_INET_PROTOCOLTYPE_IP          IPPROTO_IP
#endif /* CLI_INET_PROTOCOLTYPE_IP */

#ifndef CLI_INET_PROTOCOLTYPE_TCP
    #define CLI_INET_PROTOCOLTYPE_TCP         IPPROTO_TCP
#endif /* CLI_INET_PROTOCOLTYPE_TCP */

#ifndef CLI_INET_PROTOCOLTYPE_UDP
    #define CLI_INET_PROTOCOLTYPE_UDP         IPPROTO_UDP
#endif /* CLI_INET_PROTOCOLTYPE_UDP */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
            namespace ProtocolType {
                    const INT unspec           = IPPROTO_IP;
                    const INT ip               = IPPROTO_IP;
                    const INT tcp              = IPPROTO_TCP;
                    const INT udp              = IPPROTO_UDP;
            }; // namespace ProtocolType
        }; // namespace inet
    }; // namespace cli
    /* using namespace ::cli::inet::ProtocolType; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::inet::IpAddress */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
    #define CLI_STRUCT_NAME                   IpAddress
    #ifndef STRUCT_CLI_INET_IPADDRESS_PREDECLARED
    #define STRUCT_CLI_INET_IPADDRESS_PREDECLARED
        struct IpAddress;
        #ifndef STRUCT_CLI_INET_IPADDRESS
            #define STRUCT_CLI_INET_IPADDRESS         ::cli::inet::IpAddress
        #endif
    #endif // STRUCT_CLI_INET_IPADDRESS_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_inet_IpAddress
    #ifndef STRUCT_CLI_INET_IPADDRESS_PREDECLARED
    #define STRUCT_CLI_INET_IPADDRESS_PREDECLARED
        struct  tag_cli_inet_IpAddress;
        typedef struct tag_cli_inet_IpAddress cli_inet_IpAddress;
        #ifndef STRUCT_CLI_INET_IPADDRESS
            #define STRUCT_CLI_INET_IPADDRESS         struct tag_cli_inet_IpAddress
        #endif
    #endif // STRUCT_CLI_INET_IPADDRESS_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_INET_IPADDRESS_DEFINED
            #define STRUCT_CLI_INET_IPADDRESS_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                ENUM_CLI_INET_IPADDRESSFAMILY           af;
                USHORT                      addr[8];
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_INET_IPADDRESS_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Struct: ::cli::inet::SocketAddress */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace inet {
    #define CLI_STRUCT_NAME                   SocketAddress
    #ifndef STRUCT_CLI_INET_SOCKETADDRESS_PREDECLARED
    #define STRUCT_CLI_INET_SOCKETADDRESS_PREDECLARED
        struct SocketAddress;
        #ifndef STRUCT_CLI_INET_SOCKETADDRESS
            #define STRUCT_CLI_INET_SOCKETADDRESS     ::cli::inet::SocketAddress
        #endif
    #endif // STRUCT_CLI_INET_SOCKETADDRESS_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_inet_SocketAddress
    #ifndef STRUCT_CLI_INET_SOCKETADDRESS_PREDECLARED
    #define STRUCT_CLI_INET_SOCKETADDRESS_PREDECLARED
        struct  tag_cli_inet_SocketAddress;
        typedef struct tag_cli_inet_SocketAddress cli_inet_SocketAddress;
        #ifndef STRUCT_CLI_INET_SOCKETADDRESS
            #define STRUCT_CLI_INET_SOCKETADDRESS     struct tag_cli_inet_SocketAddress
        #endif
    #endif // STRUCT_CLI_INET_SOCKETADDRESS_PREDECLARED

#endif /* end of C-like declarations */

            #ifndef STRUCT_CLI_INET_SOCKETADDRESS_DEFINED
            #define STRUCT_CLI_INET_SOCKETADDRESS_DEFINED
            #include <cli/pshpack1.h>
            CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
                ENUM_CLI_INET_IPADDRESSFAMILY           af;
                USHORT                      addr[8];
                USHORT                      port;
            CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
            #include <cli/poppack.h>
            #endif // STRUCT_CLI_INET_SOCKETADDRESS_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; // namespace inet
    }; // namespace cli
#endif

#endif /* CLI_INET_IPTYPES_H */
