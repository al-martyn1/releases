#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INET_IPHLP_H
#define CLI_INET_IPHLP_H

#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif

namespace cli {
namespace inet {

inline
bool isBroadcastAddr(const STRUCT_CLI_INET_SOCKETADDRESS &ip)
   {
    if (ip.af==AF_INET && ip.addr[0]==255 && ip.addr[1]==255 && ip.addr[2]==255 && ip.addr[3]==255)
       return true;
    return false;
   }

inline
bool isBroadcastAddr(const STRUCT_CLI_INET_IPADDRESS &ip)
   {
    if (ip.af==AF_INET && ip.addr[0]==255 && ip.addr[1]==255 && ip.addr[2]==255 && ip.addr[3]==255)
       return true;
    return false;
   }


inline
UINT64 macToUint(const BYTE *macAddr)
   {
    return
    ((UINT64)macAddr[0]<<40) |
    ((UINT64)macAddr[1]<<32) |
    ((UINT64)macAddr[2]<<24) |
    ((UINT64)macAddr[3]<<16) |
    ((UINT64)macAddr[4]<<8 ) |
    ((UINT64)macAddr[5]    ) ;
   }

inline
bool isEqualAddr(const STRUCT_CLI_INET_IPADDRESS &ip1, const STRUCT_CLI_INET_IPADDRESS &ip2)
   {
    if (ip1.af!=ip2.af) return false;
    if (ip1.af!=AF_INET && ip1.af!=AF_INET6) return false; // not IPv4 nor IPv6 - unspecs addrs are not equal

    SIZE_T ipLen = ip1.af==AF_INET ? 4 : 8;
    for(SIZE_T i=0; i!=ipLen; ++i)
       {
        if (ip1.addr[i]!=ip2.addr[i]) return false;
       }
    return true;
   }

inline
bool isEqualAddr(const STRUCT_CLI_INET_SOCKETADDRESS &ip1, const STRUCT_CLI_INET_SOCKETADDRESS &ip2)
   {
    if (ip1.af!=ip2.af) return false;
    if (ip1.af!=AF_INET && ip1.af!=AF_INET6) return false; // not IPv4 nor IPv6 - unspecs addrs are not equal
    if (ip1.port!=ip2.port) return false;
    
    SIZE_T ipLen = ip1.af==AF_INET ? 4 : 8;
    for(SIZE_T i=0; i!=ipLen; ++i)
       {
        if (ip1.addr[i]!=ip2.addr[i]) return false;
       }
    return true;
   }

inline
STRUCT_CLI_INET_SOCKETADDRESS sockAddrFromIpAddr( const STRUCT_CLI_INET_IPADDRESS &ip, unsigned port)
   {
    STRUCT_CLI_INET_SOCKETADDRESS sa;
    sa.port = port;
    sa.af = ip.af;
    if (sa.af!=AF_INET && sa.af!=AF_INET6) return sa;

    SIZE_T ipLen = sa.af==AF_INET ? 4 : 8;
    for(SIZE_T i=0; i!=ipLen; ++i)
       {
        sa.addr[i] = ip.addr[i];
       }
    return sa;
   }

inline
STRUCT_CLI_INET_IPADDRESS ipAddrFromSockAddr( const STRUCT_CLI_INET_SOCKETADDRESS &sa)
   {
    STRUCT_CLI_INET_IPADDRESS ip;
    ip.af = sa.af;
    if (sa.af!=AF_INET && sa.af!=AF_INET6) return ip;

    SIZE_T ipLen = sa.af==AF_INET ? 4 : 8;
    for(SIZE_T i=0; i!=ipLen; ++i)
       {
        ip.addr[i] = sa.addr[i];
       }
    return ip;
   }

}; // namespace inet
}; // namespace cli


#endif /* CLI_INET_IPHLP_H */

