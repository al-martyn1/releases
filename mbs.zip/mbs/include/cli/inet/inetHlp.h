#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INET_INETHLP_H
#define CLI_INET_INETHLP_H

/* add this lines to your scr
#ifndef CLI_INET_INETHLP_H
    #include <cli/inet/inetHlp.h>
#endif
*/


#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#ifndef CLI_INET_IIFINFO_H
    #include <cli/inet/iIfInfo.h>
#endif

#ifndef CLI_INET_IIFINFO_H
    #include <cli/inet/iIfInfo.h>
#endif

#ifndef CLI_INET_IROUTEINFO_H
    #include <cli/inet/iRouteInfo.h>
#endif


namespace cli
{
namespace inet
{
namespace hlp
{


inline
void copyIpAddress( const STRUCT_CLI_INET_IPADDRESS &ipFrom, STRUCT_CLI_INET_SOCKETADDRESS &saTo )
{
    saTo.af = ipFrom.af;
    for(SIZE_T i = 0; i!=(sizeof(ipFrom.addr) / sizeof(ipFrom.addr[0])); ++i)
       {
        saTo.addr[i] = ipFrom.addr[i];
       }
}

inline
void copyIpAddress( const STRUCT_CLI_INET_SOCKETADDRESS &saFrom, STRUCT_CLI_INET_IPADDRESS &ipTo )
{
    ipTo.af = saFrom.af;
    for(SIZE_T i = 0; i!=(sizeof(saFrom.addr) / sizeof(saFrom.addr[0])); ++i)
       {
        ipTo.addr[i] = saFrom.addr[i];
       }
}


inline 
SIZE_T getAddressPartsNumber( ENUM_CLI_INET_IPADDRESSFAMILY af )
   {
    if (af==CLI_INET_IPADDRESSFAMILY_IPV4) return 4;
    if (af==CLI_INET_IPADDRESSFAMILY_IPV6) return 8;
    return 0;
   }

template <typename TAddr>
void initAddress( TAddr &addr, ENUM_CLI_INET_IPADDRESSFAMILY af, USHORT initVal = 0 )
   {
    addr.af = af;
    SIZE_T i = 0, size = getAddressPartsNumber( af );
    for(; i!=size; ++i)
       addr.addr[i] = initVal;
   }

template <typename TAddr1, typename TAddr2>
void copyAddress( const TAddr1 &addrSrc, TAddr2 &addrDst )
   {
    addrDst.af = addrSrc.af;
    SIZE_T i = 0, size = getAddressPartsNumber( addrDst.af );
    for(; i!=size; ++i)
       addrDst.addr[i] = addrSrc.addr[i];
   }

template <typename TAddr1, typename TAddr2>
bool applyMaskToAddress( const TAddr1 &mask, TAddr2 &addrApplyFor )
   {
    if (mask.af!=addrApplyFor.af) return false; // different address families
    SIZE_T i = 0, size = getAddressPartsNumber( mask.af );
    for(; i!=size; ++i)
       addrApplyFor.addr[i] &= mask.addr[i];
    return true;
   }

template <typename TAddr1, typename TAddr2>
bool equalAddress( const TAddr1 &addr1, const TAddr2 &addr2 )
   {
    if (addr1.af!=addr2.af) return false; // different address families
    SIZE_T addrSize = ( addr1.af==AF_INET ? 4 : 8 );
    for( SIZE_T i = 0; i!=addrSize; ++i)
       {
        if (addr1.addr[i]!=addr2.addr[i]) return false;
       }
    return true;
   }

template <typename TAddr>
bool isAnyAddress( const TAddr &addr )
   {
    if (addr.af!=AF_INET && addr.af!=AF_INET6) return false; // invalid addr
    SIZE_T addrSize = ( addr.af==AF_INET ? 4 : 8 );
    for( SIZE_T i = 0; i!=addrSize; ++i)
       {
        if (addr.addr[i]) return false;
       }
    return true;
   }


template <typename TAddr>
void initAddressFromDw( TAddr &addr, DWORD dwAddr )
   {
    addr.af = CLI_INET_IPADDRESSFAMILY_IPV4;
    // NOTE: possible need to be reverse order used on different endianes platform
    addr.addr[0] = ((((UINT)dwAddr)>> 0)&0xFF);
    addr.addr[1] = ((((UINT)dwAddr)>> 8)&0xFF);
    addr.addr[2] = ((((UINT)dwAddr)>>16)&0xFF);
    addr.addr[3] = ((((UINT)dwAddr)>>24)&0xFF);
   }

template <typename TAddr>
void initIpAddress( TAddr &addr, const sockaddr *psa )
   {
    if (psa->sa_family==AF_INET)
       {
        //addr.af = CLI_INET_IPADDRESSFAMILY_IPV4;
        sockaddr_in *psaIn = (sockaddr_in*)psa;
        initAddressFromDw( addr, psaIn->sin_addr.s_addr );
        return;
       }
    addr.af = CLI_INET_IPADDRESSFAMILY_UNSPEC;
    /*
    addr.af = CLI_INET_IPADDRESSFAMILY_IPV4;
    addr.addr[0] = ((((UINT)dwAddr)>> 0)&0xFF);
    addr.addr[1] = ((((UINT)dwAddr)>> 8)&0xFF);
    addr.addr[2] = ((((UINT)dwAddr)>>16)&0xFF);
    addr.addr[3] = ((((UINT)dwAddr)>>24)&0xFF);
    */
   }




//-----------------------------------------------------------------------------
// routing helpers
//-----------------------------------------------------------------------------
inline
void copyRoutingTable( ::cli::inet::CiRouteInfo &routeInfoFrom
                     , ::std::vector<STRUCT_CLI_INET_CROUTEINFO> &routingTableTo
                     , bool getNewTable = false
                     )
   {
    if (getNewTable) routeInfoFrom.queryRouteInfo();
    SIZE_T rIdx = 0, rSize = routeInfoFrom.size_routeInfo();
    for(; rIdx!=rSize; ++rIdx)
       {
        STRUCT_CLI_INET_CROUTEINFO routeInfoItem = routeInfoFrom.routeInfo[rIdx];
        routingTableTo.push_back( routeInfoItem );
       }
   }

//-----------------------------------------------------------------------------
inline
SIZE_T findDefaultGatewayRecord( const ::std::vector<STRUCT_CLI_INET_CROUTEINFO> &routingTable )
   {
    SIZE_T i = 0, size = routingTable.size();
    for(; i!=size; ++i)
       {
        if (  ::cli::inet::hlp::isAnyAddress( routingTable[i].destination )
           && ::cli::inet::hlp::isAnyAddress( routingTable[i].mask )
           )
           return i;
       }
    return SIZE_T_NPOS;
   }

//-----------------------------------------------------------------------------
inline
SIZE_T findDefaultGatewayRecord( ::cli::inet::CiRouteInfo &routeInfo )
   {
    SIZE_T rIdx = 0, rSize = routeInfo.size_routeInfo();
    for(; rIdx!=rSize; ++rIdx)
       {
        STRUCT_CLI_INET_CROUTEINFO routeInfoItem = routeInfo.routeInfo[rIdx];
        if (  ::cli::inet::hlp::isAnyAddress( routeInfoItem.destination )
           && ::cli::inet::hlp::isAnyAddress( routeInfoItem.mask )
           )
           return rIdx;
       }
    return SIZE_T_NPOS;
   }

//-----------------------------------------------------------------------------
inline
SIZE_T findGatewayAddressForDestination( const ::cli::inet::IpAddress &ipDst
                                       , const ::std::vector<STRUCT_CLI_INET_CROUTEINFO> &routingTable
                                       )
   {
    SIZE_T i = 0, size = routingTable.size();
    for(; i!=size; ++i)
       {
        ::cli::inet::IpAddress ipDstMasked;
        ::cli::inet::hlp::copyAddress( ipDst, ipDstMasked );

        ::cli::inet::IpAddress ipGatewayDestinationMasked;
        ::cli::inet::hlp::copyAddress( routingTable[i].destination, ipGatewayDestinationMasked );

        if (  ::cli::inet::hlp::applyMaskToAddress( routingTable[i].mask, ipDstMasked)
           && ::cli::inet::hlp::applyMaskToAddress( routingTable[i].mask, ipGatewayDestinationMasked )
           && ::cli::inet::hlp::equalAddress( ipGatewayDestinationMasked, ipDstMasked )
           )
           return i; // found RI item
       }
    return findDefaultGatewayRecord(routingTable);
   }

//-----------------------------------------------------------------------------
inline
SIZE_T findGatewayAddressForDestination( const ::cli::inet::IpAddress &ipDst
                                       , ::cli::inet::CiRouteInfo &routeInfoFrom
                                       , bool getNewTable = false
                                       )
   {
    if (getNewTable) routeInfoFrom.queryRouteInfo();
    SIZE_T rIdx = 0, rSize = routeInfoFrom.size_routeInfo();
    for(; rIdx!=rSize; ++rIdx)
       {
        STRUCT_CLI_INET_CROUTEINFO routeInfoItem = routeInfoFrom.routeInfo[rIdx];

        ::cli::inet::IpAddress ipDstMasked;
        ::cli::inet::hlp::copyAddress( ipDst, ipDstMasked );

        ::cli::inet::IpAddress ipGatewayDestinationMasked;
        ::cli::inet::hlp::copyAddress( routeInfoItem.destination, ipGatewayDestinationMasked );

        if (  ::cli::inet::hlp::applyMaskToAddress( routeInfoItem.mask, ipDstMasked)
           && ::cli::inet::hlp::applyMaskToAddress( routeInfoItem.mask, ipGatewayDestinationMasked )
           && ::cli::inet::hlp::equalAddress( ipGatewayDestinationMasked, ipDstMasked )
           )
           return rIdx; // found RI item
       }
    return findDefaultGatewayRecord(routeInfoFrom);
   }

//-----------------------------------------------------------------------------
inline
void copyNetInterfaceIpInfoList( ::cli::inet::CiNetInterfaceInfo &ifListerFrom
                     , ::std::vector<STRUCT_CLI_INET_CNETINTERFACEIPINFO> &ifListTo
                     , bool getNewList = false
                     )
   {
    if (getNewList) ifListerFrom.queryNetInterfaceIpInfo();
    SIZE_T ifIdx = 0, ifListSize = ifListerFrom.size_netInterfaceIpInfo();
    for(; ifIdx!=ifListSize; ++ifIdx)
       {
        STRUCT_CLI_INET_CNETINTERFACEIPINFO item = ifListerFrom.netInterfaceIpInfo[ifIdx];
        ifListTo.push_back( item );
       }
   }

//-----------------------------------------------------------------------------
inline
SIZE_T findNetInerfaceIpRecordByIp( const ::cli::inet::IpAddress &ipToFind
                          , const ::std::vector<STRUCT_CLI_INET_CNETINTERFACEIPINFO> &ifList
                          )
   {
    SIZE_T i = 0, size = ifList.size();
    for(; i!=size; ++i)
       {
        if (::cli::inet::hlp::equalAddress( ipToFind, ifList[i].addr )) return i;
       }
    return SIZE_T_NPOS;
   }

//-----------------------------------------------------------------------------
inline
SIZE_T findNetInerfaceIpRecordByIp( const ::cli::inet::IpAddress &ipToFind
                          , ::cli::inet::CiNetInterfaceInfo &ifLister
                          , bool getNewList = false
                          )
   {
    if (getNewList) ifLister.queryNetInterfaceIpInfo();
    SIZE_T ifIdx = 0, ifListSize = ifLister.size_netInterfaceIpInfo();
    for(; ifIdx!=ifListSize; ++ifIdx)
       {
        STRUCT_CLI_INET_CNETINTERFACEIPINFO item = ifLister.netInterfaceIpInfo[ifIdx];
        if (::cli::inet::hlp::equalAddress( ipToFind, item.addr )) return ifIdx;
       }
    return SIZE_T_NPOS;
   }

//-----------------------------------------------------------------------------
inline
SIZE_T findNetInerfaceIpRecordForLocalNetDestination( const ::cli::inet::IpAddress &ipDst
                                                    , const ::std::vector<STRUCT_CLI_INET_CNETINTERFACEIPINFO> &ifList
                                                    )
   {
    
    SIZE_T i = 0, size = ifList.size();
    for(; i!=size; ++i)
       {
        ::cli::inet::IpAddress ipDstMasked;
        ::cli::inet::hlp::copyAddress( ipDst, ipDstMasked );

        ::cli::inet::IpAddress ipInterfaceMasked;
        ::cli::inet::hlp::copyAddress( ifList[i].addr, ipInterfaceMasked );

        if (  ::cli::inet::hlp::applyMaskToAddress( ifList[i].mask, ipDstMasked)
           && ::cli::inet::hlp::applyMaskToAddress( ifList[i].mask, ipInterfaceMasked )
           && ::cli::inet::hlp::equalAddress( ipInterfaceMasked, ipDstMasked )
           )
           return i; // found outgoing interface for host in same net
       }
    return SIZE_T_NPOS;
   }

//-----------------------------------------------------------------------------
inline
SIZE_T findNetInerfaceIpRecordForLocalNetDestination( const ::cli::inet::IpAddress &ipDst
                                                    , ::cli::inet::CiNetInterfaceInfo &ifLister
                                                    , bool getNewList = false
                                                    )
   {
    if (getNewList) ifLister.queryNetInterfaceIpInfo();
    SIZE_T ifIdx = 0, ifListSize = ifLister.size_netInterfaceIpInfo();
    for(; ifIdx!=ifListSize; ++ifIdx)
       {
        STRUCT_CLI_INET_CNETINTERFACEIPINFO item = ifLister.netInterfaceIpInfo[ifIdx];
    
        ::cli::inet::IpAddress ipDstMasked;
        ::cli::inet::hlp::copyAddress( ipDst, ipDstMasked );

        //::cli::inet::IpAddress ipInterfaceMasked;
        //::cli::inet::hlp::copyAddress( ifList[i].addr, ipInterfaceMasked );

        if (  ::cli::inet::hlp::applyMaskToAddress( item.mask, ipDstMasked)
           && ::cli::inet::hlp::applyMaskToAddress( item.mask, item.addr )
           && ::cli::inet::hlp::equalAddress( item.addr, ipDstMasked )
           )
           return ifIdx; // found outgoing interface for host in same net
       }
    return SIZE_T_NPOS;
   }





/*
struct CNetInterfaceIpInfo
{
    uint                       interfaceId;
    ::cli::inet::IpAddress     addr;           
    ::cli::inet::IpAddress     mask;           
    ::cli::inet::IpAddress     broadcastAddr;  
    size_t                     macAddressSize;
    byte                       macAddress[32]; // max len of MAC addr is 32
//    size_t                     reassemblySize;     // Specifies the maximum re-assembly size for received datagrams
//    uint                       typeState;          // Specifies the address type or state (Currently platform specific).
//    wchar                      interfaceName[128];
};
*/


/*
::cli::inet::IpAddress ipDst;


    ::cli::inet::CiRouteInfo            routeInfo( routeInfoComponentName.c_str() );
    STRUCT_CLI_INET_CROUTEINFO
    routeInfo.queryRouteInfo();

        if (  ::cli::inet::hlp::isAnyAddress( routeInfoItem.destination )
           && ::cli::inet::hlp::isAnyAddress( routeInfoItem.mask )

            ::cli::inet::hlp::copyAddress( routeInfoItem.gateway, foundGateway );


        if (  ::cli::inet::hlp::applyMaskToAddress( routeInfoItem.mask, routeDestinationMasked)
           && ::cli::inet::hlp::applyMaskToAddress( routeInfoItem.mask, ipDstMasked )
           && ::cli::inet::hlp::equalAddress( routeDestinationMasked, ipDstMasked )
           )




        ::cli::inet::CiNetInterfaceInfo     interfaceInfo(interfaceInfoComponentName.c_str());
        STRUCT_CLI_INET_CNETINTERFACEIPINFO

*/


}; // namespace hlp
}; // namespace inet
}; // namespace cli




#endif /* CLI_INET_INETHLP_H */

