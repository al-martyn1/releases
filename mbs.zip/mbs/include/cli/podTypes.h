#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_PODTYPES_H
#define CLI_PODTYPES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/podTypes.h>", CLI_PODTYPES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif
*/

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::EBool */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EBOOL                      BOOL
#else
    #define ENUM_CLI_EBOOL                      BOOL
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EBOOL_CONST_UNDEFINED
    #define CLI_EBOOL_CONST_UNDEFINED         CONSTANT_BOOL(0xFFFFFFFF)
#endif /* CLI_EBOOL_CONST_UNDEFINED */

#ifndef CLI_EBOOL_CONST_FALSE
    #define CLI_EBOOL_CONST_FALSE             CONSTANT_BOOL(0)
#endif /* CLI_EBOOL_CONST_FALSE */

#ifndef CLI_EBOOL_CONST_TRUE
    #define CLI_EBOOL_CONST_TRUE              1
#endif /* CLI_EBOOL_CONST_TRUE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EBool {
                const BOOL const_undefined  = CONSTANT_BOOL(0xFFFFFFFF);
                const BOOL const_false      = CONSTANT_BOOL(0);
                const BOOL const_true       = CONSTANT_BOOL(1);
        }; // namespace EBool
    }; // namespace cli
    /* using namespace ::cli::EBool; */
    
#endif




#endif /* CLI_PODTYPES_H */
