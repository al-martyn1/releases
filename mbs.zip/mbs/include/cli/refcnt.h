#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_REFCNT_H
#define CLI_REFCNT_H

/* add this lines to your src
#ifndef CLI_REFCNT_H
    #include <cli/refcnt.h>
#endif
*/

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif



#ifdef __cplusplus
//CInterlockedRefCounter

#if defined(_MSC_VER)
    #pragma warning( push )
    #pragma warning( disable : 4312 ) // conversion from 'volatile const ilint_t' to 'void *' of greater size
#endif

namespace cli
{


class CFakeRefCounter
{
   ilint_t ILVOLATILE  counter;
   public:
   CFakeRefCounter() : counter(1) {}
   CFakeRefCounter(int i) : counter(i) {}
   //CRefCounter(ilint_t c) : counter(c) {}
   CFakeRefCounter(const CFakeRefCounter &rc){}
   operator ilint_t() const { return counter; }
   operator bool()    const { return true;  }
   bool operator!()   const { return false; }

   ilint_t operator--() // prefix
      { return counter; }

   ilint_t operator--(int) // postfix
      { return counter; }

   ilint_t operator++() // prefix
      { return counter; }

   ilint_t operator++(int) // postfix
      { return counter; }

};


#if defined(CLI_NO_SAFE_INTERLOCKED_FUNCTIONS)
class CSafeRefCounter
{
   ilint_t ILVOLATILE  counter;
   CCriticalSection    cs;
   public:
   CSafeRefCounter() : counter(0), cs() {}
   CSafeRefCounter(int i) : counter(i), cs() {}
   //CRefCounter(ilint_t c) : counter(c) {}
   CSafeRefCounter(const CSafeRefCounter &rc) : counter(rc.counter), cs() {}
   operator ilint_t() const { CAutoLocker<CCriticalSection> locker(cs); return counter; }
   operator bool()    const { CAutoLocker<CCriticalSection> locker(cs); return counter!=0; }
   bool operator!()   const { CAutoLocker<CCriticalSection> locker(cs); return counter==0; }

   ilint_t operator--() // prefix
      {
       CAutoLocker<CCriticalSection> locker(cs);
       return interlockedDecrement(&counter);
      }

   ilint_t operator--(int) // postfix
      {
       CAutoLocker<CCriticalSection> locker(cs);
       ilint_t res = counter;
       interlockedDecrement(&counter);
       return res;
      }
   ilint_t operator++() // prefix
      {
       CAutoLocker<CCriticalSection> locker(cs);
       return interlockedIncrement(&counter);
      }

   ilint_t operator++(int) // postfix
      {
       CAutoLocker<CCriticalSection> locker(cs);
       ilint_t res = counter;
       interlockedIncrement(&counter);
       return res;
      }
}; // class CSafeRefCounter
#endif


class CGenericRefCounter
{
   ilint_t ILVOLATILE  counter;
   public:
   CGenericRefCounter() : counter(0) {}
   CGenericRefCounter(int i) : counter(i) {}
   //CRefCounter(ilint_t c) : counter(c) {}
   CGenericRefCounter(const CGenericRefCounter &rc) : counter(rc.counter) {}
   operator ilint_t() const { return counter; }
   operator bool()    const { return counter!=0; }
   bool operator!()   const { return counter==0; }

   ilint_t operator--() // prefix
      {
       return interlockedDecrement(&counter);
      }

   ilint_t operator--(int) // postfix
      {
       ilint_t res = counter;
       interlockedDecrement(&counter);
       return res;
      }
   ilint_t operator++() // prefix
      {
       return interlockedIncrement(&counter);
      }

   ilint_t operator++(int) // postfix
      {
       ilint_t res = counter;
       interlockedIncrement(&counter);
       return res;
      }
}; // class CGenericRefCounter




#if defined(CLI_NO_SAFE_INTERLOCKED_FUNCTIONS)
    // by default we assume that refcounting performed in one thread,
    // there is no refcounted objects beetween threads
    typedef CGenericRefCounter  CUnsafeRefCounter;
    #if defined(CLI_USE_SAFE_REFCOUNTING)
        typedef CSafeRefCounter     CRefCounter;
    #else
        typedef CGenericRefCounter  CRefCounter;
    #endif
#else
    typedef CGenericRefCounter  CSafeRefCounter;
    typedef CGenericRefCounter  CUnsafeRefCounter;
    typedef CGenericRefCounter  CRefCounter;
#endif

//&& defined(CLI_USE_SAFE_REFCOUNTING)


#if defined(_MSC_VER)
    #pragma warning( pop )
#endif


}; // namespace cli


#endif /* __cplusplus */


#endif /* CLI_REFCNT_H */

