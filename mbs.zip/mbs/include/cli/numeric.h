#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_NUMERIC_H
#define CLI_NUMERIC_H

/* add this lines to your scr
#ifndef CLI_NUMERIC_H
    #include <cli/numeric.h>
#endif
*/

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_LIMITS_) && !defined(_STLP_LIMITS) && !defined(__STD_LIMITS__) && !defined(_CPP_LIMITS) && !defined(_GLIBCXX_LIMITS)
    #include <limits>
#endif

#if !defined(_INC_LIMITS) && !defined(_LIMITS_H_) && !defined(_LIMITS_H)
    #include <limits.h>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif


#ifndef CLI_DETECTSIZE_H
    #include <cli/detectSize.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifdef _WIN32
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else
    #include <alloca.h>
    #ifndef _alloca
        #define _alloca  alloca
    #endif
#endif


#ifndef CLI_NUMERIC_FORMAT_BUF_SIZE
    #define CLI_NUMERIC_FORMAT_BUF_SIZE 2048
#endif



#ifdef min
    #undef min
    #define CLI_NUMERIC_RESTORE_WIN_MIN
#endif

#ifdef max
    #undef max
    #define CLI_NUMERIC_RESTORE_WIN_MAX
#endif



/*
using namespace ::cli::numeric;
::cli::numeric::
*/

namespace cli
{
namespace numeric
{





enum rounding_type
{
    rounding_trunctate = 0,
    rounding_math      = 1,
    rounding_bankers   = 2
};

class division_by_zero : std::overflow_error
{
public:
    division_by_zero() : std::overflow_error("Division by zero") {}
    division_by_zero(const division_by_zero &d) : std::overflow_error(d) {}
    division_by_zero(const char* msg) : std::overflow_error(msg) {}
    division_by_zero& operator=(const division_by_zero &d)
    {
        if (&d==this) return *this;
        std::overflow_error::operator=(d);
        return *this;
    }
};

//if (res<0) throw std::overflow_error("minimal value convert error");



/* to do 

 1) Addition with carry for unsigned       [+]
 2) Addition with carry for signed         [+]
 3) Integer pow                            [ ]
 4) 128bit ints                            [ ]
 */

/*
/forum/cpp/4697746.1
int checked_add(int a, int b) {
  int sum = a + b;
  int ssd = a ^ b; // �� ᠬ�� ���� ��� �㦥� ⮫쪮 ���訩 ���
  if ((ssd >= 0) && ((ssd ^ sum) < 0))
    throw integer_overflow();
  return sum;
}

/forum/cpp/4695611.1
template<typename T>
T add (T x, T y)
{
  T result = x + y;
  assert(y > 0 == result > x);
  return result;  
}

/forum/cpp/4698962.1
template<typename T>
T add (T a, T b)
{
  T c = a + b;
  assert(b >= 0 == c >= a);
  return c;  
}

*/


//template<typename IntT>
//bool unsigned_addition(IntT)

/*
    _STCONS(int, digits, CHAR_BIT * sizeof (unsigned short));
    _STCONS(int, digits10, (CHAR_BIT * sizeof (unsigned short))
        * 301L / 1000);
*/


/*
// return number of bits in char
unsigned char_bits()

// return unsigned value with all char bits set to 1
unsigned char_size_mask()

// return number of bit in value of type T
template<typename T>
unsigned number_of_bits()

// make value of type T with all bits set to 1
template<typename T>
T make_mask()

template<typename IntT, typename WideIntT>
WideIntT make_base()

*/


// return number of bits in char
inline
unsigned char_bits()
{
    return CHAR_BIT;
}

// return unsigned value with all char bits set to 1
inline
unsigned char_size_mask()
{
    return (unsigned)UCHAR_MAX;
}

// return number of bit in value of type T
template<typename T>
unsigned number_of_bits()
{
    return sizeof(T)*char_bits();
}

// make value of type T with all bits set to 1
template<typename T>
T make_mask()
{
    T m = 1;
    unsigned numBits = number_of_bits<T>();
    while(numBits--) m |= m<<1;
    return m;
}


template<typename IntT, typename WideIntT>
WideIntT make_base()
{
    WideIntT r = 1;
    return r << number_of_bits<IntT>();
}



// returns true if overflow detected
inline bool unsigned_addition( UINT16 a, UINT16 b, UINT16 *c = 0 )
{
    UINT16 r = a + b; if (c) *c = r; return !(r>=a && r>=b);
}

inline bool unsigned_addition( UINT32 a, UINT32 b, UINT32 *c = 0 )
{
    UINT32 r = a + b; if (c) *c = r; return !(r>=a && r>=b);
}

inline bool unsigned_addition( UINT64 a, UINT64 b, UINT64 *c = 0 )
{
    UINT64 r = a + b; if (c) *c = r; return !(r>=a && r>=b);
}

inline bool unsigned_subtraction( UINT16 a, UINT16 b, UINT16 *c = 0 )
{
    UINT16 r = a - b; if (c) *c = r; return a<b;
}

inline bool unsigned_subtraction( UINT32 a, UINT32 b, UINT32 *c = 0 )
{
    UINT32 r = a - b; if (c) *c = r; return a<b;
}

inline bool unsigned_subtraction( UINT64 a, UINT64 b, UINT64 *c = 0 )
{
    UINT64 r = a - b; if (c) *c = r; return a<b;
}

inline bool unsigned_addition( UINT16 a, UINT16 b, UINT16 &c )
    { return unsigned_addition( a, b, &c ); }
inline bool unsigned_addition( UINT32 a, UINT32 b, UINT32 &c ) 
    { return unsigned_addition( a, b, &c ); }
inline bool unsigned_addition( UINT64 a, UINT64 b, UINT64 &c )
    { return unsigned_addition( a, b, &c ); }

inline bool unsigned_subtraction( UINT16 a, UINT16 b, UINT16 &c )
    { return unsigned_subtraction( a, b, &c ); }
inline bool unsigned_subtraction( UINT32 a, UINT32 b, UINT32 &c )
    { return unsigned_subtraction( a, b, &c ); }
inline bool unsigned_subtraction( UINT64 a, UINT64 b, UINT64 &c )
    { return unsigned_subtraction( a, b, &c ); }




// returns true if carry detected
inline bool signed_addition( INT16 a, INT16 b, INT16 *c = 0 )
{
    INT16 r = a + b; if (c) *c = r; return !((b >= 0) == (r >= a));
}

inline bool signed_addition( INT32 a, INT32 b, INT32 *c = 0 )
{
    INT32 r = a + b; if (c) *c = r; return !((b >= 0) == (r >= a));
}

inline bool signed_addition( INT64 a, INT64 b, INT64 *c = 0 )
{
    INT64 r = a + b; if (c) *c = r; return !((b >= 0) == (r >= a));
}

inline bool signed_subtraction( INT16 a, INT16 b, INT16 *c = 0 )
    { return signed_addition( a, -b, c ); }
inline bool signed_subtraction( INT32 a, INT32 b, INT32 *c = 0 )
    { return signed_addition( a, -b, c ); }
inline bool signed_subtraction( INT64 a, INT64 b, INT64 *c = 0 )
    { return signed_addition( a, -b, c ); }


inline bool signed_addition( INT16 a, INT16 b, INT16 &c ) 
    { return signed_addition( a, b, &c ); }
inline bool signed_addition( INT32 a, INT32 b, INT32 &c )
    { return signed_addition( a, b, &c ); }
inline bool signed_addition( INT64 a, INT64 b, INT64 &c )
    { return signed_addition( a, b, &c ); }

inline bool signed_subtraction( INT16 a, INT16 b, INT16 &c )
    { return signed_subtraction( a, b, &c ); }
inline bool signed_subtraction( INT32 a, INT32 b, INT32 &c )
    { return signed_subtraction( a, b, &c ); }
inline bool signed_subtraction( INT64 a, INT64 b, INT64 &c )
    { return signed_subtraction( a, b, &c ); }


template<typename IntT>
bool integer_addition( IntT a, IntT b, IntT *c = 0)
{
    return signed_addition( (INT64)a, (INT64)b, (INT64*)c );
}

template<typename IntT>
bool integer_addition( IntT a, IntT b, IntT &c )
{
    INT64 tmp;
    bool bRes = signed_addition( (INT64)a, (INT64)b, &tmp );
    c = (IntT)tmp;
    return bRes;
}

template<> inline bool integer_addition<INT16> (INT16  a, INT16  b, INT16  *c) { return signed_addition( a, b, c ); }
template<> inline bool integer_addition<INT16> (INT16  a, INT16  b, INT16  &c) { return signed_addition( a, b, c ); }
template<> inline bool integer_addition<INT32> (INT32  a, INT32  b, INT32  *c) { return signed_addition( a, b, c ); }
template<> inline bool integer_addition<INT32> (INT32  a, INT32  b, INT32  &c) { return signed_addition( a, b, c ); }
template<> inline bool integer_addition<INT64> (INT64  a, INT64  b, INT64  *c) { return signed_addition( a, b, c ); }
template<> inline bool integer_addition<INT64> (INT64  a, INT64  b, INT64  &c) { return signed_addition( a, b, c ); }

template<> inline bool integer_addition<UINT16>(UINT16 a, UINT16 b, UINT16 *c) { return unsigned_addition( a, b, c ); }
template<> inline bool integer_addition<UINT16>(UINT16 a, UINT16 b, UINT16 &c) { return unsigned_addition( a, b, c ); }
template<> inline bool integer_addition<UINT32>(UINT32 a, UINT32 b, UINT32 *c) { return unsigned_addition( a, b, c ); }
template<> inline bool integer_addition<UINT32>(UINT32 a, UINT32 b, UINT32 &c) { return unsigned_addition( a, b, c ); }
template<> inline bool integer_addition<UINT64>(UINT64 a, UINT64 b, UINT64 *c) { return unsigned_addition( a, b, c ); }
template<> inline bool integer_addition<UINT64>(UINT64 a, UINT64 b, UINT64 &c) { return unsigned_addition( a, b, c ); }


template<typename IntT>
bool integer_subtraction( IntT a, IntT b, IntT *c = 0)
{
    return signed_subtraction( (INT64)a, (INT64)b, (INT64*)c );
}

template<typename IntT>
bool integer_subtraction( IntT a, IntT b, IntT &c )
{
    INT64 tmp;
    bool bRes = signed_subtraction( (INT64)a, (INT64)b, &tmp );
    c = (IntT)tmp;
    return bRes;
}

template<> inline bool integer_subtraction<INT16> (INT16  a, INT16  b, INT16  *c) { return signed_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<INT16> (INT16  a, INT16  b, INT16  &c) { return signed_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<INT32> (INT32  a, INT32  b, INT32  *c) { return signed_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<INT32> (INT32  a, INT32  b, INT32  &c) { return signed_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<INT64> (INT64  a, INT64  b, INT64  *c) { return signed_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<INT64> (INT64  a, INT64  b, INT64  &c) { return signed_subtraction( a, b, c ); }

template<> inline bool integer_subtraction<UINT16>(UINT16 a, UINT16 b, UINT16 *c) { return unsigned_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<UINT16>(UINT16 a, UINT16 b, UINT16 &c) { return unsigned_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<UINT32>(UINT32 a, UINT32 b, UINT32 *c) { return unsigned_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<UINT32>(UINT32 a, UINT32 b, UINT32 &c) { return unsigned_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<UINT64>(UINT64 a, UINT64 b, UINT64 *c) { return unsigned_subtraction( a, b, c ); }
template<> inline bool integer_subtraction<UINT64>(UINT64 a, UINT64 b, UINT64 &c) { return unsigned_subtraction( a, b, c ); }



template<typename IntT>
IntT integer_abs( IntT i )  { return (i<0) ? -i : i; }

template<typename IntT>
IntT throwing_integer_abs( IntT i )
{
    IntT res = integer_abs(i);
    if (res<0) throw std::overflow_error("minimal value convert error");
    return res;
}


template<typename IntT>
IntT integer_sign( IntT i ) { return (i<0) ? -1 : 1; }

template<typename IntT>
int sign_multiple( IntT a, IntT b )
    { return integer_sign(a)==integer_sign(b) ? 1 : -1; }


template<typename IntT>
IntT make_lo_half_mask()
{
    IntT mask = char_size_mask();
    IntT resMask = mask;
    for(unsigned i =0; i!=(unsigned)(sizeof(IntT)/2); ++i)
       {
        resMask |= mask;
        mask <<= char_bits();
       }
    return resMask;
}

template<typename IntT> 
unsigned calc_half_shift() { return (unsigned)(sizeof(IntT)*4); }

template<typename IntT>
IntT lo_part( IntT i ) { return i & make_lo_half_mask<IntT>(); }

template<typename IntT>
IntT hi_part( IntT i ) 
    { return (i >> calc_half_shift<IntT>()) & make_lo_half_mask<IntT>(); }

/* keep sign */
template<typename IntT>
IntT lo_part_s( IntT i ) { return i & make_lo_half_mask<IntT>(); }

template<typename IntT>
IntT hi_part_s( IntT i ) 
    { return i >> calc_half_shift<IntT>(); }



template<typename UIntT, typename UIntT2>
void multiply_num_mn_unsigned_impl( UIntT *w
           , const UIntT *u, const UIntT *v
           , unsigned m, unsigned n
           )
{
    UIntT2 k, t; //, b;
    unsigned i, j; // counters

    for (i=0; i<m; i++)
        w[i] = 0;

    for(j=0; j!=n; j++)
       {
        k = 0;
        for(i=0; i!=m; i++)
           {
            //t = u[i]   * v[j] 
            //  + w[i+j] + k;
            t = static_cast<UIntT2>(u[i])   * static_cast<UIntT2>(v[j]) 
              + static_cast<UIntT2>(w[i+j]) + static_cast<UIntT2>(k);
            w[i+j] = static_cast<UIntT>(lo_part_s(t)); // t; // (�.�., t & OxFFFF).
            k = hi_part_s(t); // t >> 16;
           }
        w[j+m] = static_cast<UIntT>(k);
       }
}

inline void 
multiply_num_mn_unsigned( UINT8 *w, const UINT8 *u, const UINT8 *v
                        , unsigned m, unsigned n )
    { multiply_num_mn_unsigned_impl<UINT8, UINT16>(w, u, v, m, n ); }

inline void 
multiply_num_mn_unsigned( UINT16 *w, const UINT16 *u, const UINT16 *v
                        , unsigned m, unsigned n )
    { multiply_num_mn_unsigned_impl<UINT16, UINT32>(w, u, v, m, n ); }

inline void 
multiply_num_mn_unsigned( UINT32 *w, const UINT32 *u, const UINT32 *v
                        , unsigned m, unsigned n )
    { multiply_num_mn_unsigned_impl<UINT32, UINT64>(w, u, v, m, n ); }




template<typename UIntT, typename SIntT, typename UIntT2>
void multiply_num_mn_signed_impl( UIntT *w
           , const UIntT *u, const UIntT *v
           , unsigned m, unsigned n
           )
{
    UIntT2 t, b; // k, 
    unsigned i, j; // counters
    multiply_num_mn_unsigned( w, u, v, m, n );

    // ������ w[] �������� ����������� ������������.
    // ������������ ���������� v*2**16m ��� � < 0 �
    // ���������� u*2**16n ��� v < �
    if ((SIntT)u[m-1] < 0)
       {
        b = 0; // �������������� ����
        for (j=0; j!=n; j++)
            {
             t = w[j+m] - v[j] - b;
             w[j+m] = static_cast<UIntT>(t);
             b = t >> (sizeof(UIntT2)*char_bits() - 1); // 31;
            }
       }

    if ((SIntT)v[n-1] < 0)
       {
        b = 0;
        for(i=0; i!=m; i++)
           {
            t = w[i+n] - u[i] - b;
            w[i+n] = static_cast<UIntT>(t);
            b = t >> (sizeof(UIntT2)*char_bits() - 1); // 31;
           }
       }
    return;
}

inline void 
multiply_num_mn_signed( UINT8 *w, const UINT8 *u, const UINT8 *v
                        , unsigned m, unsigned n )
    { multiply_num_mn_signed_impl<UINT8, INT8, UINT16>(w, u, v, m, n ); }

inline void 
multiply_num_mn_signed( UINT16 *w, const UINT16 *u, const UINT16 *v
                        , unsigned m, unsigned n )
    { multiply_num_mn_signed_impl<UINT16, INT16, UINT32>(w, u, v, m, n ); }

inline void 
multiply_num_mn_signed( UINT32 *w, const UINT32 *u, const UINT32 *v
                        , unsigned m, unsigned n )
    { multiply_num_mn_signed_impl<UINT32, INT32, UINT64>(w, u, v, m, n ); }


template<typename IntT, typename UIntT>
IntT multiply_impl(IntT u, IntT v, UIntT *pLowPart)
{
    UIntT u0 = lo_part_s(u); // u & 0xFF; 
    IntT  u1 = hi_part_s(u); // u >>  8;

    UIntT v0 = lo_part_s(v); // v & 0xFF; 
    IntT  v1 = hi_part_s(v); // v >>  8;

    UIntT w0 = u0*v0;
    IntT  t  = u1*v0 + hi_part_s(w0); // (w0 >> 8) ;
    IntT  w1 = lo_part_s(t); // t & 0xFF;
    IntT  w2 = hi_part_s(t); // t >>  8;
    w1       = u0*v1 + w1;
    if (pLowPart) *pLowPart = (UIntT)(w1 << calc_half_shift<UIntT>()) | (w0 & make_lo_half_mask<UIntT>() );
    return u1*v1 + w2 + hi_part_s(w1); // (w1 >> 8) ;
}



template<typename IntT, typename UIntT>
IntT multiply_high_impl(IntT u, IntT v)
{
    return multiply_impl(u, v, (UIntT*)0);
}

template<typename IntT>
IntT multiply_high( IntT a, IntT b)
{
    return multiply_high_impl<UINT64, UINT64>( a, b );
}

template<> inline INT16  multiply_high<INT16> (INT16  a, INT16  b) { return multiply_high_impl<INT16,  UINT16>( a, b ); }
template<> inline INT32  multiply_high<INT32> (INT32  a, INT32  b) { return multiply_high_impl<INT32,  UINT32>( a, b ); }
template<> inline INT64  multiply_high<INT64> (INT64  a, INT64  b) { return multiply_high_impl<INT64,  UINT64>( a, b ); }

template<> inline UINT16 multiply_high<UINT16>(UINT16 a, UINT16 b) { return multiply_high_impl<UINT16, UINT16>( a, b ); }
template<> inline UINT32 multiply_high<UINT32>(UINT32 a, UINT32 b) { return multiply_high_impl<UINT32, UINT32>( a, b ); }
template<> inline UINT64 multiply_high<UINT64>(UINT64 a, UINT64 b) { return multiply_high_impl<UINT64, UINT64>( a, b ); }



template <typename IntT>
IntT integer_pow( IntT i, unsigned p, bool *pOverflow = 0)
{
    if (pOverflow) *pOverflow = false;
    if (i==0 && p==0)
       {
        if (pOverflow) *pOverflow = true;
        return 0;
       }
    if (!i) return 0;
    if (!p) return 1;

    IntT res = 1;
    do{
       IntT tmp = res*i;
       IntT mh  = multiply_high(res,i);
       //sign_multiple( IntT a, IntT b )

       if (std::numeric_limits<IntT> :: is_signed )
          {
           if (i<0)
              {
               if (sign_multiple(tmp, res)>=0)
                  {
                   if (pOverflow) *pOverflow = true;
                  }
              }
           else
              {
               if (sign_multiple(tmp, res)<0)
                  {
                   if (pOverflow) *pOverflow = true;
                  }
              }

           int mhs  = sign_multiple(res,i);
           if (  (mhs<0 && mh!=(IntT)-1)
              || (mhs>0 && mh!=0)
              )
              {
               if (pOverflow) *pOverflow = true;
              }
          }
       else
          {
           if (mh>0)
              {
               if (pOverflow) *pOverflow = true;
              }
          }
       res = tmp;
       if (!res) { if (pOverflow) *pOverflow = true; return 0; }
       --p;
      } while(p);
    return res;
}

template <typename IntT>
IntT integer_pow( IntT i, unsigned p, bool &bOverflow )
{
    return integer_pow( i, p, &bOverflow );
}

template <typename IntT>
static IntT make_hi_bits_mask( unsigned numBits )
{
    IntT mask = 1;
    mask <<= (sizeof(IntT)*8)-1;
    numBits %= sizeof(IntT)*8;
    while(numBits--) mask |= mask>>1;
    return mask;
}

template <typename IntT>
IntT make_lo_bits_mask( unsigned numBits )
{
    IntT mask = 1;
    numBits %= sizeof(IntT)*8;
    while(numBits--) mask |= mask<<1;
    return mask;
}


#include <cli/warncvtlossdata.h>
inline unsigned calc_num_of_high_bits(UINT8 u)
{
    static unsigned tbl[16] = { 0, 1, 1, 2 // 0000, 0001, 0010, 0011
                              , 1, 2, 2, 3 // 0100, 0101, 0110, 0111
                              , 1, 2, 2, 3 // 1000, 1001, 1010, 1011
                              , 2, 3, 3, 4 // 1100, 1101, 1110, 1111
                              };
    return tbl[u&0x0F] + tbl[u>>4];
}

inline unsigned calc_num_of_high_bits(INT8 u)
    { return calc_num_of_high_bits((UINT8)u); }

inline unsigned calc_num_of_high_bits(UINT16 u)
    { return calc_num_of_high_bits( (UINT8)(u&0xFF) ) 
    + calc_num_of_high_bits( (UINT8)(u>>8) ); }

inline unsigned calc_num_of_high_bits(INT16 u)
    { return calc_num_of_high_bits((UINT16)u); }

inline unsigned calc_num_of_high_bits(UINT32 u)
    { return calc_num_of_high_bits( (UINT16)(u&0xFFFF) ) 
    + calc_num_of_high_bits( (UINT16)(u>>16) ); }

inline unsigned calc_num_of_high_bits(INT32 u)
    { return calc_num_of_high_bits((UINT32)u); }

inline unsigned calc_num_of_high_bits(UINT64 u)
    { return calc_num_of_high_bits( (UINT32)(u&0xFFFFFFFF) ) 
    + calc_num_of_high_bits( (UINT32)(u>>32) ); }

inline unsigned calc_num_of_high_bits(INT64 u)
    { return calc_num_of_high_bits((UINT64)u); }

// 0 - no 1 bits found, 1 - lowest bit etc
inline unsigned get_high_bit_number( UINT8 u )
{
    static unsigned tbl[16] = { 0, 1, 2, 2 // 0000, 0001, 0010, 0011
                              , 3, 3, 3, 3 // 0100, 0101, 0110, 0111
                              , 4, 4, 4, 4 // 1000, 1001, 1010, 1011
                              , 4, 4, 4, 4 // 1100, 1101, 1110, 1111
                              };
    unsigned res = tbl[ u>>4 ];
    if (res) return res + 4;
    return tbl[u&0x0F];
}

inline unsigned get_high_bit_number(INT8 u)
    { return get_high_bit_number((UINT8)u); }


inline unsigned get_high_bit_number( UINT16 u )
{
    unsigned res = get_high_bit_number((UINT8)(u>>8));
    if (res) return res + 8;
    return get_high_bit_number((UINT8)(u&0xFF));
}

inline unsigned get_high_bit_number(INT16 u)
    { return get_high_bit_number((UINT16)u); }


inline unsigned get_high_bit_number( UINT32 u )
{
    unsigned res = get_high_bit_number((UINT16)(u>>16));
    if (res) return res + 16;
    return get_high_bit_number((UINT16)(u&0xFFFF));
}

inline unsigned get_high_bit_number(INT32 u)
    { return get_high_bit_number((UINT32)u); }


inline unsigned get_high_bit_number( UINT64 u )
{
    unsigned res = get_high_bit_number((UINT32)(u>>32));
    if (res) return res + 32;
    return get_high_bit_number((UINT32)(u&0xFFFFFFFF));
}

inline unsigned get_high_bit_number(INT64 u)
    { return get_high_bit_number((UINT64)u); }


// 0 - no 1 bits found, 1 - lowest bit etc
inline unsigned get_low_bit_number( UINT8 u )
{
    static unsigned tbl[16] = { 0, 1, 2, 1 // 0000, 0001, 0010, 0011
                              , 3, 1, 2, 1 // 0100, 0101, 0110, 0111
                              , 4, 1, 2, 1 // 1000, 1001, 1010, 1011
                              , 3, 1, 2, 1 // 1100, 1101, 1110, 1111
                              };
    unsigned res = tbl[u&0x0F];
    if (res) return res;
    res = tbl[u>>4];
    return res ? res + 4 : res;
}

inline unsigned get_low_bit_number(INT8 u)
    { return get_low_bit_number((UINT8)u); }


inline unsigned get_low_bit_number( UINT16 u )
{
    unsigned res = get_low_bit_number((UINT8)(u&0xFF));
    if (res) return res;
    res = get_low_bit_number((UINT8)(u>>8));
    return res ? res + 8 : res;
}

inline unsigned get_low_bit_number(INT16 u)
    { return get_low_bit_number((UINT16)u); }


inline unsigned get_low_bit_number( UINT32 u )
{
    unsigned res = get_low_bit_number((UINT16)(u&0xFFFF));
    if (res) return res;
    res = get_low_bit_number((UINT16)(u>>16));
    return res ? res + 16 : res;
}

inline unsigned get_low_bit_number(INT32 u)
    { return get_low_bit_number((UINT32)u); }


inline unsigned get_low_bit_number( UINT64 u )
{
    unsigned res = get_low_bit_number((UINT32)(u&0xFFFFFFFF));
    if (res) return res;
    res = get_low_bit_number((UINT32)(u>>32));
    return res ? res + 32 : res;
}

inline unsigned get_low_bit_number(INT64 u)
    { return get_low_bit_number((UINT64)u); }



template<typename IntT>
unsigned get_number_of_zero_leading_bits( IntT i)
{
    return number_of_bits<IntT>() - get_high_bit_number(i); 
    // get_high_bit_number return value from 1 to sizeof()*8 (including)
}


#include <cli/warnpop.h>

//WHAT: alternating sum




template<typename UIntT, typename UIntT2, typename SIntT2>
int division_num_mn_unsigned_impl(UIntT *q, UIntT *r
           , const UIntT *u, const UIntT *v
           , int m, int n
           )
{
    const UIntT2 b = make_base<UIntT,UIntT2>(); // 65536; // ��������� ����� (16 �����)
    UIntT *un, *vn; // ��������������� ��� u � v
    UIntT2 qhat; // �������������� ����� ��������
    UIntT2 rhat; // �������
    UIntT2 p; // ������������ ���� ����
    SIntT2 s, i, j, t, k;
    if (m < n || n <= 0 || v[n-1] == 0)
       return 1; // ������������ ��� ������������ ���������
    if (n==1) // ������� ������ �������� �� ����� �����
       {
        k = 0;
        for(j=m-1; j>=0; j--)
           {
            q[j] = static_cast<UIntT>( (k*b + u[j])/v[0] );
            k = (k*b + u[j]) - q[j]*v[0] ;
           }
        if (r!=0) r[0] = static_cast<UIntT>(k);
        return 0;
       }

    // ������������ ����� ������ v �����, ������, ���
    // ������� ��� ���������� ���������, � ������ u �����
    // �� �� �� ��������. ��� ����� ������������� ��������
    // ������� ����� � ��������; �� ������ ��� ����������
    s = get_number_of_zero_leading_bits(static_cast<SIntT2>(v[n-1])) 
        - number_of_bits<UIntT>(); // 16; // 0 <= s <= 16.
    vn = (UIntT*)_alloca(sizeof(UIntT)*2*n);
    for(i=n-1; i>0; i--)
       vn[i] = (make_mask<UIntT>() & (v[i] << s)) 
             | (make_mask<UIntT>() & (v[i-1] >> (number_of_bits<UIntT>()-s) ) ); // 16-s
    vn[0] = v[0] << s;

    un = (UIntT*)_alloca(sizeof(UIntT)*2*(m+1)) ;
    un[m] = u[m-1] >> (number_of_bits<UIntT>()-s); // 16-s;
    for (i=m-1; i>0; i--)
        un[i] = (make_mask<UIntT>() & (u[i] << s)) 
              | (make_mask<UIntT>() & (u[i-1] >> (number_of_bits<UIntT>()-s) ) ); // 16
    un[0] = u[0] << s;

    for(j=m-n; j>=0; j--) // ������� ����
       {                  // ��������� ������ q[j]
        qhat = (static_cast<UIntT2>(un[j+n])*b + static_cast<UIntT2>(un[j+n-1])) 
             / static_cast<UIntT2>(vn[n-1]);        
        rhat = (static_cast<UIntT2>(un[j+n])*b + static_cast<UIntT2>(un[j+n-1])) 
             - qhat*static_cast<UIntT2>(vn[n-1]);

        #if 0
        again:

        if (qhat>=b || qhat*static_cast<UIntT2>(vn[n-2]) > (b*rhat+static_cast<UIntT2>(un[j+n-2])))
           {
            qhat = qhat - 1;
            rhat = rhat + static_cast<UIntT2>(vn[n-1]);
            if (rhat < b) goto again;
           }
        #else
        while (qhat>=b || qhat*static_cast<UIntT2>(vn[n-2]) > (b*rhat+static_cast<UIntT2>(un[j+n-2])))
           {
            qhat = qhat - 1;
            rhat = rhat + static_cast<UIntT2>(vn[n-1]);
            if (rhat < b) continue;
            break;
           }
        #endif

        // ��������� � ���������
        k = 0;
        for(i=0; i<n; i++)
           {
            p = qhat*static_cast<UIntT2>(vn[i]); // (p & OxFFFF);
            t = static_cast<UIntT2>(un[i+j]) - k -  (p & static_cast<UIntT2>(make_mask<UIntT>()) ); 
            un[i+j] = static_cast<UIntT>(t);
            //k = (p >> 16) - (t >> 16) ;
            k = (p >> number_of_bits<UIntT>()) - (t >> number_of_bits<UIntT>()) ;
           }
        t = static_cast<UIntT2>(un[j+n]) - k;
        un[j+n] = static_cast<UIntT>(t);
        q[j] = static_cast<UIntT>(qhat); // ���������� ����� ��������
        if (t<0)     // ���� �� ����� ������� �����,
           {         // ������ �����
            q[j] = q[j] - 1;
            k = 0;
            for(i=0; i<n; i++)
               {
                t = static_cast<UIntT2>(un[i+j]) + static_cast<UIntT2>(vn[i]) + k;
                un[i+j] = static_cast<UIntT>(t);
                k = t >> number_of_bits<UIntT>(); // 16;
               }
            un[j+n] = static_cast<UIntT>(static_cast<UIntT2>(un[j+n]) + k);
           }
       } // for j


    // ���� ���������� ������� ����� �������� �������,
    // ������������� � ���������� ���
    if (r!=0)
       {
        for(i=0; i<n; i++)
           r[i] = static_cast<UIntT>((make_mask<UIntT>()&(un[i]>>s)) | (make_mask<UIntT>()&(un[i+1]<<(number_of_bits<UIntT>()-s))));
           //r[i] = (un[i] >> s) | (un[i+l] << 16-s);
       }
    
    return 0;
}





/*
// return number of bits in char
unsigned char_bits()

// return unsigned value with all char bits set to 1
unsigned char_size_mask()

// return number of bit in value of type T
template<typename T>
unsigned number_of_bits()

// make value of type T with all bits set to 1
template<typename T>
T make_mask()

template<typename IntT, typename WideIntT>
WideIntT make_base()

*/



// Greatest Common Divisor
template<typename IntT>
IntT gcd(IntT g, IntT l)
{
    if (g<l) std::swap(g,l); // guarantees that g>=l
    if (l==0) return g;
    if (l==1) return l;

    #if 1
    while (g != l)
       {
        (g>l) ? (g-=l) : (l-=g);
       }
    #else
    while(g!=l)
       {
        g = g - l;
        if (g<l) std::swap(g,l);
       }
    #endif
    return g;
}


// Least common multiple
template<typename IntT>
IntT lcm(IntT a, IntT b)
{
    a = integer_abs(a);
    b = integer_abs(b);
    return a*b / gcd(a,b);
}

template<typename IntT>
IntT throwing_lcm(IntT a, IntT b)
{
    a = throwing_integer_abs(a);
    b = throwing_integer_abs(b);
    IntT g = gcd(a,b);
    if (!g) throw division_by_zero("Division by zero detected when calculating least common multiple");
    //UNDONE: need to check multiplication overflow
    return a*b / g;
}

//throwing_integer_abs( IntT i )


/*
while (i != j)
    {
       if (g > l)
           g -= l;
       else
           l -= g;

       if (i > j)
           i -= j;
       else
           j -= i;
    }
*/


#if !defined(CLI_PLATFORM_BIG_ENDIAN) && !defined(CLI_PLATFORM_LITTLE_ENDIAN)
    #error "Platform endianess not defined. Please define CLI_PLATFORM_LITTLE_ENDIAN or CLI_PLATFORM_BIG_ENDIAN"
#endif


/* gcc has __int128

*/

#include <cli/pshpack8.h>
template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
struct extended_size_int_t
{
    #if defined(CLI_PLATFORM_LITTLE_ENDIAN)
    UIntT    loPart;
    SIntT    hiPart;
    #else
    SIntT    hiPart;
    UIntT    loPart;
    #endif

    typedef SIntT         base_int_type;
    typedef UIntT         base_unsigned_type;
    typedef SIntHalfSize  base_half_int_type;
    typedef UIntHalfSize  base_half_unsigned_type;

    void swap( extended_size_int_t &i )
    {
        std::swap(loPart,i.loPart);
        std::swap(hiPart,i.hiPart);
    }

    extended_size_int_t() : loPart(0), hiPart(0) {}
    extended_size_int_t(SIntT hp, UIntT lp) : loPart(lp), hiPart(hp) {}
    extended_size_int_t(const extended_size_int_t &i) : loPart(i.loPart), hiPart(i.hiPart) {}

    extended_size_int_t( base_int_type i ) : loPart(i), hiPart(i<0 ? -1 : 0) { }
    extended_size_int_t( base_half_int_type i ) : loPart((base_int_type)i), hiPart(i<0 ? -1 : 0) { }
    extended_size_int_t( base_unsigned_type i ) : loPart(i), hiPart(0) { }
    extended_size_int_t( base_half_unsigned_type i ) : loPart(i), hiPart(0) { }

/*
    template <typename OtherIntT>
    extended_size_int_t( OtherIntT i ) : loPart(i), hiPart(i<0 ? -1 : 0) { }
*/

    void clear() { hiPart = 0; loPart = 0; }
    void reset() { hiPart = 0; loPart = 0; }
    void assign( SIntT hp, UIntT lp ) { hiPart = hp; loPart = lp; }
    void assign( base_int_type i ) { hiPart = i<0 ? -1 : 0; loPart = (UIntT)i; }
    void assign( base_half_int_type i ) { hiPart = i<0 ? -1 : 0; loPart = (UIntT)(base_int_type)i; }
    void assign( base_unsigned_type i ) { hiPart = 0; loPart = i; }
    void assign( base_half_unsigned_type i ) { hiPart = 0; loPart = i; }

    extended_size_int_t& operator=( const extended_size_int_t &i )
    { 
        assign(i.hiPart, i.loPart); return *this;
    }

    extended_size_int_t& operator=( base_int_type i )
    { 
        assign(i); return *this;
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t& operator=( base_half_int_type i )
    { 
        assign(i); return *this;
    }
    #endif

    extended_size_int_t& invert()
    {
        loPart ^= (UIntT)-1;
        hiPart ^= (SIntT)-1;
        return *this;
    }

    extended_size_int_t& increment()
    {
        UIntT savedLoPart = loPart++;
        hiPart += (savedLoPart>loPart)
                ? 1 // overflow detected
                : 0 ;
        return *this; 
    }

    extended_size_int_t& decrement()
    {
        UIntT savedLoPart = loPart--;
        hiPart -= (savedLoPart<loPart)
                ? 1 // carry detected
                : 0 ;
        return *this; 
    }

    extended_size_int_t& negate( bool doNegate = true ) 
    {
        if (!doNegate) return *this; 
        invert(); return increment();
    }

    extended_size_int_t negate_copy() const
    { 
        extended_size_int_t res(*this); res.invert(); return res.increment();
    }

    bool is_negative() const { return hiPart<0; }
    int  get_sign()    const { return is_negative() ? -1 : 1; }
    bool is_positive() const { return hiPart>=0; } // or zero
    bool is_zero()  const { return hiPart==0 && loPart==0; }
    bool is_false() const { return hiPart==0 && loPart==0; }
    bool is_true()  const { return !is_false(); }
    bool half_overflow() const
    {
        return (hiPart<0)
             ? hiPart!=(SIntT)-1
             : hiPart!=0 ;
    }

    static extended_size_int_t make_lo_half_mask()
    {
        return extended_size_int_t( 0, (UIntT)-1 );
    }

    static unsigned calc_half_shift()
    {
        return sizeof(UIntT)*2;
    }

    unsigned get_lo_tetrad() const
    {
        return (unsigned)(loPart&0xF);
    }

    extended_size_int_t operator+() const
    {
        return *this;
    }

    extended_size_int_t& add( const extended_size_int_t& i )
    {
        if (unsigned_addition(loPart, i.loPart, loPart))
           ++hiPart; // detected overflow
        signed_addition(hiPart, i.hiPart, hiPart); // ignore overflow on hi part
        return *this;
    }

    extended_size_int_t& operator+=(const extended_size_int_t& i)
    {
        return add(i);
    }

    extended_size_int_t& operator+=( base_int_type i )
    {
        return add(extended_size_int_t(i));
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t& operator+=( base_half_int_type i )
    {
        return add(extended_size_int_t(i));
    }
    #endif

    extended_size_int_t operator-() const
    {
        return negate_copy();
    }

    extended_size_int_t& operator-=(const extended_size_int_t& i)
    {
        return add( i.negate_copy() );
    }

    extended_size_int_t& operator-=( base_int_type i )
    {
        return add( extended_size_int_t(i).negate() );
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t& operator-=( base_half_int_type i )
    {
        return add( extended_size_int_t(i).negate() );
    }
    #endif

    //NOTE: need to be checked on non-little-endian platforms
    #if defined(CLI_PLATFORM_LITTLE_ENDIAN)
    const UIntHalfSize* getHalfWordPtr() const { return (UIntHalfSize*)&loPart; }
          UIntHalfSize* getHalfWordPtr()       { return (UIntHalfSize*)&loPart; }
    #else
    const UIntHalfSize* getHalfWordPtr() const { return (UIntHalfSize*)&hiPart; }
          UIntHalfSize* getHalfWordPtr()       { return (UIntHalfSize*)&hiPart; }
    #endif

    // return true if overflow detected
    bool safe_self_multiply(const extended_size_int_t& i)
    {
        int resSign = sign_multiple( get_sign(), i.get_sign() );

        #if defined(CLI_PLATFORM_LITTLE_ENDIAN)
        UIntT w[4] = { 0 };

        multiply_num_mn_signed_impl<UIntHalfSize, SIntHalfSize, UIntT>( (UIntHalfSize*)&w[0]
                                                                      , getHalfWordPtr() // &u[0]
                                                                      , i.getHalfWordPtr() // &v[0]
                                                                      , 4, 4 );
        loPart = w[0];
        hiPart = static_cast<SIntT>(w[1]); // h0

        //const SIntT &h1 = *(static_cast<SIntT*>(&w[2]));
        //const SIntT &h2 = *(static_cast<SIntT*>(&w[2]));
        SIntT h1 = static_cast<SIntT>(w[2]);
        SIntT h2 = static_cast<SIntT>(w[3]);

        #else

        UIntHalfSize u[4] = { 0 };
        u[0] = static_cast<UIntHalfSize>( loPart                              &::make_lo_half_mask<UIntT>());
        u[1] = static_cast<UIntHalfSize>((loPart>> ::calc_half_shift<UIntT>())&::make_lo_half_mask<UIntT>());
        u[2] = static_cast<UIntHalfSize>( hiPart                              &::make_lo_half_mask<SIntT>());
        u[3] = static_cast<UIntHalfSize>((hiPart>> ::calc_half_shift<UIntT>())&::make_lo_half_mask<SIntT>());

        UIntHalfSize v[4] = { 0 };
        v[0] = static_cast<UIntHalfSize>( i.loPart                              &::make_lo_half_mask<UIntT>());
        v[1] = static_cast<UIntHalfSize>((i.loPart>> ::calc_half_shift<UIntT>())&::make_lo_half_mask<UIntT>());
        v[2] = static_cast<UIntHalfSize>( i.hiPart                              &::make_lo_half_mask<SIntT>());
        v[3] = static_cast<UIntHalfSize>((i.hiPart>> ::calc_half_shift<SIntT>())&::make_lo_half_mask<SIntT>());

        UIntHalfSize w[8] = { 0 };
        //                          UIntHalfSize, UIntT, SIntT
        multiply_num_mn_signed_impl<UIntHalfSize, SIntHalfSize, UIntT>( &w[0], &u[0], &v[0], 4, 4 );
        loPart =         ((UIntT)w[0]) | (((UIntT)w[1]))<< ::calc_half_shift<UIntT>();
        hiPart = (SIntT)(((UIntT)w[2]) | (((UIntT)w[3]))<< ::calc_half_shift<SIntT>());

        SIntT h1 = (SIntT)(((UIntT)w[4]) | (((UIntT)w[5]))<< ::calc_half_shift<SIntT>());
        SIntT h2 = (SIntT)(((UIntT)w[6]) | (((UIntT)w[7]))<< ::calc_half_shift<SIntT>());

        #endif

        // check overflow
        if (resSign<0)
           {
            if (h1!=(SIntT)-1 || h2!=(SIntT)-1) return true; // overflow detected
           }
        else
           {
            if (h1!=0 || h2!=0) return true; // overflow detected
           }

        return false; // no overflow
    }

    // return true if error detected, 
    bool safe_self_divide(const extended_size_int_t& param_i, extended_size_int_t *pR)
    {
        if (param_i.is_zero())
           {
            loPart = 0;
            SIntT m = make_mask<SIntT>();
            hiPart = m ^ static_cast<SIntT>(static_cast<UIntT>(m)>>1);
            return true;
           }

        extended_size_int_t i = param_i;
        int s1 = get_sign();
        if (s1<0) negate();

        int s2 = i.get_sign();
        if (s2<0) i.negate();

        int resSign = sign_multiple( s1, s2 );

        #if defined(CLI_PLATFORM_LITTLE_ENDIAN)

        UIntT q[4] = { 0 };
        UIntT r[4] = { 0 };
        // m-n+1

        const UIntHalfSize *pu = getHalfWordPtr();
        int m = 4;
        const UIntHalfSize *pv = i.getHalfWordPtr();
        int n = 4;

        #else

        UIntHalfSize q[8] = { 0 };
        UIntHalfSize r[8] = { 0 };

        UIntHalfSize u[4] = { 0 };
        u[0] = static_cast<UIntHalfSize>( loPart                              &::make_lo_half_mask<UIntT>());
        u[1] = static_cast<UIntHalfSize>((loPart>> ::calc_half_shift<UIntT>())&::make_lo_half_mask<UIntT>());
        u[2] = static_cast<UIntHalfSize>( hiPart                              &::make_lo_half_mask<SIntT>());
        u[3] = static_cast<UIntHalfSize>((hiPart>> ::calc_half_shift<UIntT>())&::make_lo_half_mask<SIntT>());

        UIntHalfSize v[4] = { 0 };
        v[0] = static_cast<UIntHalfSize>( i.loPart                              &::make_lo_half_mask<UIntT>());
        v[1] = static_cast<UIntHalfSize>((i.loPart>> ::calc_half_shift<UIntT>())&::make_lo_half_mask<UIntT>());
        v[2] = static_cast<UIntHalfSize>( i.hiPart                              &::make_lo_half_mask<SIntT>());
        v[3] = static_cast<UIntHalfSize>((i.hiPart>> ::calc_half_shift<SIntT>())&::make_lo_half_mask<SIntT>());

        const UIntHalfSize *pu = &u[0];
        int m = 4;
        const UIntHalfSize *pv = &v[0];
        int n = 4;

        #endif

        int tmpI = n;
        for(; tmpI!=0; --tmpI)
           {
            if (pv[tmpI-1]!=0) break;
           }

        if (!tmpI)
           {
            loPart = 0;
            SIntT m = make_mask<SIntT>();
            hiPart = m ^ static_cast<SIntT>(static_cast<UIntT>(m)>>1);
            return true;
           }

        n = tmpI;

        int dr = division_num_mn_unsigned_impl<UIntHalfSize, UIntT, SIntT >( 
                           (UIntHalfSize*)&q[0], (UIntHalfSize*)&r[0]
                         , pu, pv, m, n
                         );
        if (dr)
           {
            loPart = 0;
            SIntT m = make_mask<SIntT>();
            hiPart = m ^ static_cast<SIntT>(static_cast<UIntT>(m)>>1);
            return true;
           }

        #if defined(CLI_PLATFORM_LITTLE_ENDIAN)

        loPart = q[0];
        hiPart = static_cast<SIntT>(q[1]); // h0

        if (pR)
           {
            pR->assign( (SIntT)r[1], (UIntT)r[0] );
            if (s2<0) pR->negate();
           }

        #else

        loPart =         ((UIntT)q[0]) | (((UIntT)q[1]))<< ::calc_half_shift<UIntT>();
        hiPart = (SIntT)(((UIntT)q[2]) | (((UIntT)q[3]))<< ::calc_half_shift<SIntT>());

        if (pR)
           {
            pR->assign( (SIntT)(((UIntT)r[2]) | (((UIntT)r[3]))<< ::calc_half_shift<SIntT>()), ((UIntT)r[0]) | (((UIntT)r[1]))<< ::calc_half_shift<UIntT>() );
            if (s2<0) pR->negate();
           }

        #endif

        if (resSign<0) negate();

        return false;
    }


    extended_size_int_t& operator*=(const extended_size_int_t& i)
    {
        safe_self_multiply(i); // ignore overflow
        return *this;
    }

    extended_size_int_t& operator*=( base_int_type i )
    {
        safe_self_multiply(extended_size_int_t(i)); // ignore overflow
        return *this;
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t& operator*=( base_half_int_type i )
    {
        safe_self_multiply(extended_size_int_t(i)); // ignore overflow
        return *this;
    }
    #endif

    extended_size_int_t& operator/=(const extended_size_int_t& i)
    { 
        safe_self_divide(i,0); // ignore overflow
        return *this;
    }

    extended_size_int_t& operator/=( base_int_type i )
    {
        safe_self_divide(extended_size_int_t(i),0); // ignore overflow
        return *this;
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t& operator/=( base_half_int_type i )
    {
        safe_self_divide(extended_size_int_t(i),0); // ignore overflow
        return *this;
    }
    #endif

    extended_size_int_t& operator%=(const extended_size_int_t& i)
    {
        //  dividend or numerator, b the divisor or denominator and the result c is called the quotient.
        //  remainder
        extended_size_int_t quotient(*this);
        //extended_size_int_t remainder;
        quotient.safe_self_divide(i,this);
        return *this;
    }

    extended_size_int_t& operator%=( base_int_type i )
    {
        extended_size_int_t quotient(*this);
        quotient.safe_self_divide(extended_size_int_t(i),this);
        return *this;
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t& operator%=( base_half_int_type i )
    {
        extended_size_int_t quotient(*this);
        quotient.safe_self_divide(extended_size_int_t(i),this);
        return *this;
    }
    #endif

    extended_size_int_t operator++() // prefix
    {
        return increment();
    }
             
    extended_size_int_t operator++(int)      // suffix
    {
        extended_size_int_t res(*this);
        increment();
        return res;
    }

    extended_size_int_t operator--() // prefix
    {
        return decrement();
    }
             
    extended_size_int_t operator--(int)      // suffix
    {
        extended_size_int_t res(*this);
        decrement();
        return res;
    }


    bool operator==( const extended_size_int_t& i ) const
    {
        return loPart==i.loPart && hiPart==i.hiPart;
    }

    bool operator==( base_int_type i ) const
    {
        return operator==(extended_size_int_t(i));
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    bool operator==( base_half_int_type i ) const
    {
        return operator==(extended_size_int_t(i));
    }
    #endif

    bool operator!=( const extended_size_int_t& i ) const
    {
        return loPart!=i.loPart || hiPart!=i.hiPart;
    }

    bool operator!=( base_int_type i ) const
    {
        return operator!=(extended_size_int_t(i));
    }
    
    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    bool operator!=( base_half_int_type i ) const
    {
        return operator!=(extended_size_int_t(i));
    }
    #endif
    
    bool operator>( const extended_size_int_t& i ) const
    {
        return (hiPart==i.hiPart)
             ? loPart>i.loPart
             : hiPart>i.hiPart ;
    }

    bool operator>( base_int_type i ) const
    {
        return operator>(extended_size_int_t(i));
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    bool operator>( base_half_int_type i ) const
    {
        return operator>(extended_size_int_t(i));
    }
    #endif

    bool operator<( const extended_size_int_t& i ) const
    {
        return (hiPart==i.hiPart)
             ? loPart<i.loPart
             : hiPart<i.hiPart ;
    }

    bool operator<( base_int_type i ) const
    {
        return operator<(extended_size_int_t(i));
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    bool operator<( base_half_int_type i ) const
    {
        return operator<(extended_size_int_t(i));
    }
    #endif

    bool operator>=( const extended_size_int_t& i ) const
    {
        return (hiPart==i.hiPart)
             ? loPart>=i.loPart
             : hiPart>=i.hiPart ;
    }

    bool operator>=( base_int_type i ) const
    {
        return operator>=(extended_size_int_t(i));
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    bool operator>=( base_half_int_type i ) const
    {
        return operator>=(extended_size_int_t(i));
    }
    #endif

    bool operator<=( const extended_size_int_t& i ) const
    {
        return (hiPart==i.hiPart)
             ? loPart<=i.loPart
             : hiPart<=i.hiPart ;
    }

    bool operator<=( base_int_type i ) const
    {
        return operator<=(extended_size_int_t(i));
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    bool operator<=( base_half_int_type i ) const
    {
        return operator<=(extended_size_int_t(i));
    }
    #endif


    SIntT        to_int_type() const { return (SIntT)loPart; }
    UIntT        to_unsigned_type() const { return loPart; }
    SIntHalfSize to_half_int_type() const { return (SIntHalfSize)(SIntT)loPart; }
    UIntHalfSize to_half_unsigned_type() const { return (UIntHalfSize)loPart; }

    double to_double() const
    {
        int sign = get_sign();
        extended_size_int_t absVal = (sign<0) ? negate_copy() : *this;
        double res = (double)absVal.hiPart;
        res *= integer_pow( (UIntT)2, number_of_bits<UIntT>());
        res += absVal.loPart;
        return (sign<0) ? -res : res;
    }
/*
    operator SIntT() const  { return (SIntT)loPart; }
    operator UIntT() const  { return loPart; }
    operator SIntHalfSize() const  { return (SIntHalfSize)loPart; }
    operator UIntHalfSize() const  { return (UIntHalfSize)loPart; }
*/

    bool operator!( ) const
    {
        return is_false();
    }

    operator void*( ) const
    {
        return is_true() ? (void*)1 : (void*)0;
    }
    
    bool operator&&( const extended_size_int_t& i ) const
    {
        return is_true() && i.is_true();
    }

    bool operator&&( base_int_type i )
    {
        return is_true() && (i!=0);
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    bool operator&&( base_half_int_type i )
    {
        return is_true() && (i!=0);
    }
    #endif

    bool operator&&( bool i )
    {
        return is_true() && (i!=0);
    }

    bool operator||( const extended_size_int_t& i ) const
    {
        return is_true() || i.is_true();
    }

    bool operator||( base_int_type i )
    {
        return is_true() || (i!=0);
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    bool operator||( base_half_int_type i )
    {
        return is_true() || (i!=0);
    }
    #endif

    bool operator||( bool i )
    {
        return is_true() || (i!=0);
    }


    extended_size_int_t operator~() const
    {
        extended_size_int_t res(*this);
        return res.invert();
    }

    extended_size_int_t& operator&=( const extended_size_int_t& i )
    {
        hiPart &= i.hiPart;
        loPart &= i.loPart;
        return *this;
    }

    extended_size_int_t operator&=( base_int_type i )
    {
        return operator&=( extended_size_int_t(i) );
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t operator&=( base_half_int_type i )
    {
        return operator&=( extended_size_int_t(i) );
    }
    #endif

    extended_size_int_t& operator|=( const extended_size_int_t& i )
    {
        hiPart |= i.hiPart;
        loPart |= i.loPart;
        return *this;
    }

    extended_size_int_t operator|=( base_int_type i )
    {
        return operator|=( extended_size_int_t(i) );
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t operator|=( base_half_int_type i )
    {
        return operator|=( extended_size_int_t(i) );
    }
    #endif


    extended_size_int_t& operator^=( const extended_size_int_t& i )
    {
        hiPart ^= i.hiPart;
        loPart ^= i.loPart;
        return *this;
    }

    extended_size_int_t operator^=( base_int_type i ) const
    {
        return operator^=( extended_size_int_t(i) );
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t operator^=( base_half_int_type i ) const
    {
        return operator^=( extended_size_int_t(i) );
    }
    #endif

    extended_size_int_t& operator<<=( base_unsigned_type i)
    {
        unsigned shiftNumBits = static_cast<unsigned>(i);
        if (shiftNumBits >= (sizeof(SIntT)+sizeof(UIntT))*8 )
           {
            hiPart = 0;
            loPart = 0;
           }
        else
           {
            UIntT tmp = loPart&make_hi_bits_mask<UIntT>(shiftNumBits);
            tmp >>= sizeof(UIntT)*8 - shiftNumBits;
            loPart <<= shiftNumBits;
            hiPart <<= shiftNumBits;
            hiPart |= (SIntT)tmp;
           }
        return *this;
    }

    extended_size_int_t& operator>>=( base_unsigned_type i)
    {
        unsigned shiftNumBits = static_cast<unsigned>(i);
        if (shiftNumBits >= (sizeof(SIntT)+sizeof(UIntT))*8 )
           {
            hiPart>>= shiftNumBits;
            loPart  = (UIntT)hiPart;
           }
        else
           {
            SIntT tmp = hiPart&make_lo_bits_mask<SIntT>(shiftNumBits);
            tmp <<= sizeof(SIntT)*8 - shiftNumBits;
            hiPart >>= shiftNumBits;
            loPart >>= shiftNumBits;
            loPart |= (UIntT)tmp;
           }
        return *this;
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t& operator<<=( base_half_unsigned_type i)
    {
        unsigned shiftNumBits = static_cast<unsigned>(i);
        if (shiftNumBits >= (sizeof(SIntT)+sizeof(UIntT))*8 )
           {
            hiPart = 0;
            loPart = 0;
           }
        else
           {
            UIntT tmp = loPart&make_hi_bits_mask<UIntT>(shiftNumBits);
            tmp >>= sizeof(UIntT)*8 - shiftNumBits;
            loPart <<= shiftNumBits;
            hiPart <<= shiftNumBits;
            hiPart |= (SIntT)tmp;
           }
        return *this;
    }
    #endif

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t& operator>>=( base_half_unsigned_type i)
    {
        unsigned shiftNumBits = static_cast<unsigned>(i);
        if (shiftNumBits >= (sizeof(SIntT)+sizeof(UIntT))*8 )
           {
            hiPart>>= shiftNumBits;
            loPart  = (UIntT)hiPart;
           }
        else
           {
            SIntT tmp = hiPart&make_lo_bits_mask<SIntT>(shiftNumBits);
            tmp <<= sizeof(SIntT)*8 - shiftNumBits;
            hiPart >>= shiftNumBits;
            loPart >>= shiftNumBits;
            loPart |= (UIntT)tmp;
           }
        return *this;
    }
    #endif

    extended_size_int_t operator<<( base_unsigned_type i) const
    {
        extended_size_int_t res(*this);
        return res.operator<<=( i);
    }

    extended_size_int_t operator>>( base_unsigned_type i) const
    {
        extended_size_int_t res(*this);
        return res.operator>>=( i);
    }

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t operator<<( base_half_unsigned_type i) const
    {
        extended_size_int_t res(*this);
        return res.operator<<=( i);
    }
    #endif

    #if defined(ALOW_CLI_NUMERIC_EXTENDED_SIZE_INT_HALF_OPERATORS)
    extended_size_int_t operator>>( base_half_unsigned_type i) const
    {
        extended_size_int_t res(*this);
        return res.operator>>=( i);
    }
    #endif


}; // template <typename SIntT, UIntT> struct extended_size_int_t
#include <cli/poppack.h>

//-------
template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator+( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator+=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator+( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntT i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator+=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator+( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntHalfSize i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator+=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator+( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator+=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator+( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator+=(i2);
}

//-------
template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator-( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator-=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator-( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntT i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator-=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator-( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntHalfSize i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator-=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator-( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator-=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator-( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator-=(i2);
}

//-------
template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator*( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator*=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator*( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntT i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator*=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator*( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntHalfSize i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator*=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator*( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator*=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator*( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator*=(i2);
}

//-------
template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator/( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator/=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator/( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntT i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator/=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator/( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntHalfSize i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator/=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator/( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator/=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator/( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator/=(i2);
}

//-------
template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator%( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator%=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator%( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntT i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator%=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator%( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntHalfSize i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator%=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator%( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator%=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator%( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator%=(i2);
}

//-------
template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator==( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator==(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator==( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator==(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator!=( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator!=(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator!=( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator!=(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator>( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator<=(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator>( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator<=(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator>=( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator<(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator>=( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator<(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator<( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator>=(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator<( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator>=(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator<=( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator>(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator<=( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator>(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator&&( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator&&(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator&&( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator&&(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator&&( bool i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator&&(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator||( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator||(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator||( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator||(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
bool operator||( bool i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    return i2.operator||(i1);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator&( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator&=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator&( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntT i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator&=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator&( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntHalfSize i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator&=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator&( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator&=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator&( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator&=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator|( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator|=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator|( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntT i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator|=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator|( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntHalfSize i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator|=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator|( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator|=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator|( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator|=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator^( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator^=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator^( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntT i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator^=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator^( const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i1
         , SIntHalfSize i2)
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator^=(extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >(i2));
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator^( SIntT i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator^=(i2);
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize >
operator^( SIntHalfSize i1
         , const extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > &i2 )
{
    extended_size_int_t< SIntT, UIntT, SIntHalfSize, UIntHalfSize > res(i1);
    return res.operator^=(i2);
}








/*
const CharType* extended_size_int_from_string_dec(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* extended_size_int_from_string_hex(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* extended_size_int_from_string_oct(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* extended_size_int_from_string_auto(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i, unsigned *pBaseFound)

CharType* format_extended_size_int_to_dec_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, CharType fillChar = (CharType)' ')
CharType* format_extended_size_int_to_hex_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false)
CharType* format_extended_size_int_to_oct_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0)

std::string& format_extended_size_int_oct( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0 )
std::wstring& format_extended_size_int_oct( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0 )
std::string& format_extended_size_int_hex( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false )
std::wstring& format_extended_size_int_hex( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false )
std::string& format_extended_size_int_dec( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, char fillChar = ' ' )
std::wstring& format_extended_size_int_dec( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, wchar_t fillChar = L' ' )
*/

template<typename CharType>
int char_to_digit( CharType c )
{
    if (c>=(CharType)'0' && c<=(CharType)'9') return (int)(c - (CharType)'0');
    if (c>=(CharType)'a' && c<=(CharType)'f') return (int)(c - (CharType)'a') + 10;
    if (c>=(CharType)'A' && c<=(CharType)'F') return (int)(c - (CharType)'A') + 10;
    return -1;
}

template <typename CharType, typename SIntT, typename UIntT, typename UIntHalfSize, typename SIntHalfSize>
const CharType* extended_size_int_from_string_dec(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
{
    i = 0;
    bool hasSign = false;
    bool neg  = false;
    for(; str && *str; ++str)
       {
        if (!hasSign && (*str==(CharType)'-' || *str==(CharType)'+'))
           {
            //if (hasSign) return i.negate(neg), str;
            hasSign = true;
            neg = (*str==(CharType)'-') ? true : false;
           }
        else
           {
            int d = char_to_digit(*str);
            if (d<0 || d>=10) return i.negate(neg), str;
            hasSign = true;
            i *= 10;
            i += d;
           }
       }
    i.negate(neg);
    return str;
}

template <typename CharType, typename SIntT, typename UIntT, typename UIntHalfSize, typename SIntHalfSize>
const CharType* extended_size_int_from_string_hex(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
{
    i = 0;
    for(; str && *str; ++str)
       {
        int d = char_to_digit(*str);
        if (d<0 || d>=16) return str;
        i <<= 4;
        i += d;
       }
    return str;
}

template <typename CharType, typename SIntT, typename UIntT, typename UIntHalfSize, typename SIntHalfSize>
const CharType* extended_size_int_from_string_oct(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
{
    i = 0;
    for(; str && *str; ++str)
       {
        int d = char_to_digit(*str);
        if (d<0 || d>=8) return str;
        i <<= 3;
        i += d;
       }
    return str;
}

template <typename CharType, typename SIntT, typename UIntT, typename UIntHalfSize, typename SIntHalfSize>
const CharType* extended_size_int_from_string_auto(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i, unsigned *pBaseFound = 0)
{
    const CharType* strOrg = str;
    if (!str) return str;
    if (*str==(CharType)'0') // oct or hex
       {
        ++str;
        if (!(*str))
           { // simple zero
            i = 0;
            if (pBaseFound) *pBaseFound = 10;
            return str;
           }
        if (*str==(CharType)'x' || *str==(CharType)'X') // possible hex
           {
            ++str;
            if (!(*str)) return strOrg; // error
            const CharType* strRes = extended_size_int_from_string_hex(str, i);
            if (strRes==str) return strOrg; // error
            if (pBaseFound) *pBaseFound = 16;
            return str;
           }
        //const CharType* strRes = 
        if (pBaseFound) *pBaseFound = 8;
        return extended_size_int_from_string_oct(str, i);
       }
    else
       {
        if (pBaseFound) *pBaseFound = 10;
        if (*str==(CharType)'-' || *str==(CharType)'+')
           {
            ++str;
            if (!(*str)) return strOrg; // error
            int d = char_to_digit<CharType>( *str );
            if (d<0 || d>=10) return strOrg; // error
            return extended_size_int_from_string_dec(str, i);
           }
        int d = char_to_digit<CharType>( *str );
        if (d<0 || d>=10) return strOrg; // error
        return extended_size_int_from_string_dec(str, i);
       }
}

template<typename CharType>
CharType digit_to_char_impl( unsigned i, const CharType *alphabet)
{
    return alphabet[i];
}

template<typename CharType>
CharType digit_to_char( unsigned i, bool lowerCase )
{
    return (CharType)' ';
}

template<> inline 
char digit_to_char<char>( unsigned i, bool lowerCase )
{
    static const char *loAlphas = "0123456789abcdefghijklmnopqrstuvwxyz";
    static const char *hiAlphas = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    return digit_to_char_impl( i, lowerCase ? loAlphas : hiAlphas );
}

template<> inline 
wchar_t digit_to_char<wchar_t>( unsigned i, bool lowerCase )
{
    static const wchar_t *loAlphas = L"0123456789abcdefghijklmnopqrstuvwxyz";
    static const wchar_t *hiAlphas = L"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    return digit_to_char_impl( i, lowerCase ? loAlphas : hiAlphas );
}



// buf must be enough to hold all digits - for extended_size_int_t<INT64,UINT64,UINT32> it is 33 bytes at least
template <typename CharType, typename SIntT, typename UIntT, typename UIntHalfSize, typename SIntHalfSize>
CharType* format_extended_size_int_to_hex_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false)
{
    CharType *p = buf;
    if (i<0) 
       {
        if (minWidth < (sizeof(SIntT)+sizeof(UIntT))*2)
           minWidth = (sizeof(SIntT)+sizeof(UIntT))*2;
       }
    if (!minWidth)
       {
        minWidth = 1;
       }
    unsigned j=0;
    for(; i; ++j)
       {
        *p++ = digit_to_char<CharType>(i.get_lo_tetrad(), lowerCase);
        i>>=4;
       }
    for(; j<minWidth; ++j)
       {
        *p++ = digit_to_char<CharType>( 0 /* i.get_lo_tetrad() */ , lowerCase);
       }
    ::std::reverse(buf, p);
    *p = 0;
    return p;
}

template <typename CharType, typename SIntT, typename UIntT, typename UIntHalfSize, typename SIntHalfSize>
CharType* format_extended_size_int_to_oct_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0)
{
    CharType *p = buf;
    if (i<0) 
       {
        if (minWidth < (sizeof(SIntT)+sizeof(UIntT))*2)
           minWidth = (sizeof(SIntT)+sizeof(UIntT))*2;
       }
    if (!minWidth)
       {
        minWidth = 1;
       }
    unsigned j=0;
    for(; i; ++j)
       {
        *p++ = digit_to_char<CharType>( 0x07&i.get_lo_tetrad(), false);
        i>>=3;
       }

    for(; j<minWidth; ++j)
       {
        *p++ = digit_to_char<CharType>( 0 /* i.get_lo_tetrad() */ , false);
       }
    ::std::reverse(buf, p);
    *p = 0;
    return p;
}

template <typename CharType, typename SIntT, typename UIntT, typename UIntHalfSize, typename SIntHalfSize>
CharType* format_extended_size_int_to_dec_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, CharType fillChar = (CharType)' ')
{
    CharType *p = buf;
    bool bNeg = false;
    if (i<0) 
       {
        i = -i;
        bNeg = true;
        //if (minWidth)
        fillChar = (CharType)' ';
       }
    if (!minWidth)
       {
        minWidth = 1;
        fillChar = (CharType)'0';
       }
/*
    SIntT        to_int_type() const { return (SIntT)loPart; }
    UIntT        to_unsigned_type() const { return loPart; }
    SIntHalfSize to_half_int_type() const { return (SIntHalfSize)(SIntT)loPart; }
    UIntHalfSize to_half_unsigned_type() const { return (UIntHalfSize)loPart; }
*/
    unsigned j=0;
    for(; i; ++j)
       {
        *p++ = digit_to_char<CharType>( (i%10).to_half_unsigned_type(), false /* lowerCase */ );
        i/=10;
       }
    if (bNeg)
       {
        *p++ = (CharType)'-';
       }

    for(; j<minWidth; ++j)
       {
        *p++ = fillChar; // digit_to_char<CharType>( 0 /* i.get_lo_tetrad() */ , lowerCase);
       }
    ::std::reverse(buf, p);
    *p = 0;
    return p;
}


template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
std::string& format_extended_size_int_oct( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0 )
{
    char buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_extended_size_int_to_oct_buf( buf, i, minWidth );
    formatTo.assign(buf);
    return formatTo;
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
std::wstring& format_extended_size_int_oct( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0 )
{
    wchar_t buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_extended_size_int_to_oct_buf( buf, i, minWidth );
    formatTo.assign(buf);
    return formatTo;
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
std::string& format_extended_size_int_hex( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false )
{
    char buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_extended_size_int_to_hex_buf( buf, i, minWidth , lowerCase );
    formatTo.assign(buf);
    return formatTo;
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
std::wstring& format_extended_size_int_hex( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false )
{
    wchar_t buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_extended_size_int_to_hex_buf( buf, i, minWidth , lowerCase );
    formatTo.assign(buf);
    return formatTo;
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
std::string& format_extended_size_int_dec( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, char fillChar = ' ' )
{
    char buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_extended_size_int_to_dec_buf( buf, i, minWidth , fillChar );
    formatTo.assign(buf);
    return formatTo;
}

template <typename SIntT, typename UIntT, typename SIntHalfSize, typename UIntHalfSize>
std::wstring& format_extended_size_int_dec( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, wchar_t fillChar = L' ' )
{
    wchar_t buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_extended_size_int_to_dec_buf( buf, i, minWidth , fillChar );
    formatTo.assign(buf);
    return formatTo;
}





typedef extended_size_int_t<INT64,UINT64,INT32,UINT32>    extended_int128_t;




inline
void fromCliBigInteger( const ::cli::BigInteger &b, extended_int128_t &i128 )
{
    i128.assign(b.hiPart, b.loPart);
}

inline
void toCliBigInteger( const extended_int128_t &i128, ::cli::BigInteger &b )
{
    b.hiPart = i128.hiPart;
    b.loPart = i128.loPart;
}


struct rational_number_t;

template<typename CharType>
const CharType* rational_number_from_string(const CharType *str, rational_number_t &r);



#include <cli/pshpack8.h>
struct rational_number_t
{
    typedef extended_int128_t   nom_type;
    typedef extended_int128_t   denom_type;

    typedef rational_number_t   this_type;

    extended_int128_t           nom;
    extended_int128_t           denom;


    void swap( rational_number_t &f )
    {
        std::swap(nom  ,f.nom);
        std::swap(denom,f.denom);
    }

    void swap_nom()
    {
        std::swap(nom,denom);
    }


    rational_number_t() : nom(0), denom(1) {}
    rational_number_t(const rational_number_t &f) : nom(f.nom), denom(f.denom) {}
    rational_number_t(const nom_type &n) : nom(n), denom(1) {}
    rational_number_t(const nom_type &n, const denom_type &d) : nom(d<denom_type(0)?-n:n), denom(d<denom_type(0)?-d:d) {}
    rational_number_t(const nom_type::base_int_type &n) : nom(n), denom(1) {}
    rational_number_t(const nom_type::base_int_type &n, const nom_type::base_int_type &d) : nom(d<0?-n:n), denom(d<0?-d:d) {}

    explicit
    rational_number_t( const char *str ) : nom(0), denom(1)
        { rational_number_from_string(str, *this); }

    explicit
    rational_number_t( const wchar_t *str ) : nom(0), denom(1)
        { rational_number_from_string(str, *this); }

    explicit
    rational_number_t( const std::string &str ) : nom(0), denom(1)
        { rational_number_from_string(str.c_str(), *this); }

    explicit
    rational_number_t( const std::wstring &str ) : nom(0), denom(1)
        { rational_number_from_string(str.c_str(), *this); }

    template <typename IntT>
    rational_number_t(IntT n) : nom(n), denom(1) {}

    template <typename IntT>
    rational_number_t(IntT n, IntT d) : nom(d<0?-n:n), denom(d<0?-d:d) {}


    void assign( const rational_number_t &r ) { nom = r.nom; denom = r.denom; }

    void assign( const nom_type &n ) { nom = n; denom = 1; }

    void assign( const nom_type &n, const denom_type &d ) { nom = d<denom_type(0)?-n:n; denom = d<denom_type(0)?-d:d; }

    void assign( const nom_type::base_int_type &n ) { nom = n; denom = 1; }

    void assign( const nom_type::base_int_type &n, const nom_type::base_int_type &d ) { nom = d<0?-n:n; denom = d<0?-d:d; }

    template <typename IntT>
    void assign( IntT n ) { nom = n; denom = 1; }

    template <typename IntT>
    void assign( IntT n, IntT d ) { nom = d<0?-n:n; denom = d<0?-d:d; }

    void clear() { nom.reset(); denom = 1; }
    void reset() { nom.reset(); denom = 1; }

    rational_number_t& operator=( const rational_number_t &r )
    { 
        //assign(r); 
        nom = r.nom; denom = r.denom;
        return *this;
    }

    rational_number_t& operator=( const nom_type &i )
    { 
        assign(i); return *this;
    }

    template <typename OtherIntT>
    rational_number_t& operator=( OtherIntT i )
    {
        assign(i); return *this;
    }

    rational_number_t& increment()
    {
        nom += denom;
        return *this; 
    }

    rational_number_t& decrement()
    {
        nom -= denom;
        return *this; 
    }

    rational_number_t& negate( bool doNegate = true ) 
    {
        if (!doNegate) return *this; 
        nom.negate(doNegate);
        return *this; 
    }

    rational_number_t negate_copy(bool doNegate = true) const
    { 
        rational_number_t res(*this); return res.negate(doNegate);
    }

    bool is_negative() const { return nom<nom_type(0); }
    int  get_sign()    const { return is_negative() ? -1 : 1; }
    bool is_positive() const { return nom>=nom_type(0); } // or zero
    bool is_zero()  const { return nom.is_zero(); }
    bool is_false() const { return nom.is_false(); }
    bool is_true()  const { return !is_false(); }

    nom_type  to_int_type() const { return nom / denom; }
    double    to_double()   const { return nom.to_double() / denom.to_double(); }
    float     to_float()    const { return (float)(nom.to_double() / denom.to_double()); }

    rational_number_t integer_abs() const
    {
        rational_number_t res(*this);
        if (res.nom<0) res.nom = ::cli::numeric::integer_abs(res.nom);
        return res;
    }

    rational_number_t throwing_integer_abs() const
    {
        rational_number_t res(*this);
        if (res.nom<0) res.nom = ::cli::numeric::throwing_integer_abs(res.nom);
        return res;
    }

    static void reduce( nom_type &n, denom_type &d)
    {
        nom_type g = gcd(::cli::numeric::throwing_integer_abs(n), d);
        if (g<1) return;
        n /= g;
        d /= g;
    }

    void reduce()
    {
        reduce( nom, denom );
    }

    static void reduce( rational_number_t &i )
    {
        i.reduce();
    }

    void make_proper(nom_type *pIntPart)
    {
        if (pIntPart) *pIntPart = nom / denom;
        nom %= denom;
    }


    rational_number_t operator+() const
    {
        return *this;
    }

    static void throwing_calc_common_denom( rational_number_t& r1, rational_number_t& r2)
    {
        if (!r1.denom) throw division_by_zero("Division by zero detected when calculating common denominator");
        if (!r2.denom) throw division_by_zero("Division by zero detected when calculating common denominator");
        denom_type lcmVal = throwing_lcm(r1.denom,r2.denom);
        denom_type k1 = lcmVal / r1.denom;
        denom_type k2 = lcmVal / r2.denom;
        //UNDONE: need to check multiply overflow
        r1.nom *= k1; r1.denom = lcmVal;
        r2.nom *= k2; r2.denom = lcmVal;
    }

    inline rational_number_t& assign_addition_impl( rational_number_t i, bool bReduceAfter = true )
    {
        throwing_calc_common_denom(*this, i);
        nom += i.nom;
        if (bReduceAfter) reduce();
        return *this;
    }

    inline rational_number_t& assign_subtraction_impl( rational_number_t i, bool bReduceAfter = true )
    {
        throwing_calc_common_denom(*this, i);
        nom -= i.nom;
        if (bReduceAfter) reduce();
        return *this;
    }

    rational_number_t& operator+=(const rational_number_t &i)
    {
        return assign_addition_impl(i);
    }

    rational_number_t operator+(rational_number_t i) const
    {
        rational_number_t res(*this);
        return res.assign_addition_impl(i);
    }

    template <typename OtherIntT>
    rational_number_t& operator+=( const OtherIntT &i )
    {
        return assign_addition_impl(rational_number_t(i));
    }

    template <typename OtherIntT>
    rational_number_t operator+( const OtherIntT &i ) const
    {
        rational_number_t res(*this);
        return res.assign_addition_impl(rational_number_t(i));
    }

    rational_number_t operator-() const
    {
        return negate_copy();
    }

    rational_number_t operator-(const rational_number_t& i) const
    {
        rational_number_t res(*this);
        return res.assign_subtraction_impl(i);
    }

    rational_number_t& operator-=(const rational_number_t& i)
    {
        return assign_subtraction_impl(i);
    }

    template <typename OtherIntT>
    rational_number_t operator-( const OtherIntT &i ) const
    {
        rational_number_t res(*this);
        return res.assign_subtraction_impl(rational_number_t(i));
    }

    template <typename OtherIntT>
    rational_number_t& operator-=( const OtherIntT &i )
    {
        return assign_subtraction_impl(rational_number_t(i));
    }


    rational_number_t& assign_multiply_impl( rational_number_t i, bool bReduceAfter = true )
    {
        reduce();
        reduce(i);

        reduce( nom  , i.denom );
        reduce( i.nom,   denom );

        /*
        nom_type g1 = gcd(throwing_integer_abs(  nom), i.denom);
        nom_type g2 = gcd(throwing_integer_abs(i.nom),   denom);

        nom /= g1;
        denom_type idenom = i.denom / g1;

        denom /= g2;
        nom_type inom = i.nom / g2;
        */

        nom   *= i.nom;
        denom *= i.denom;

        if (bReduceAfter) reduce();

        /*
        nom_type g = gcd(throwing_integer_abs(nom), denom);
        if (g>1)
           {
            nom /= g;
            denom /= g;
           }
        */
        return *this;
    }

    rational_number_t& assign_division_impl( rational_number_t i, bool bReduceAfter = true )
    {
        if (!i.nom) throw division_by_zero("Division by zero detected while try to divide rational numbers");
        std::swap(i.nom,i.denom);
        if (i.denom<0)
           {
            i.denom = -i.denom;
            i.nom   = -i.nom;
           }

        return assign_multiply_impl( i, bReduceAfter );
    }

    rational_number_t& operator*=(const rational_number_t& i)
    {
        return assign_multiply_impl( i );
    }

    rational_number_t operator*(const rational_number_t& i) const
    {
        rational_number_t res(*this);
        res.assign_multiply_impl(i);
        return res;
    }

    template <typename OtherIntT>
    rational_number_t& operator*=( const OtherIntT &i )
    {
        return assign_multiply_impl( rational_number_t(i) );
    }

    template <typename OtherIntT>
    rational_number_t operator*( const OtherIntT &i ) const
    {
        rational_number_t res(*this);
        res.assign_multiply_impl(rational_number_t(i));
        return res;
    }

    rational_number_t& operator/=(const rational_number_t& i)
    { 
        return assign_division_impl( i );
    }

    rational_number_t operator/(const rational_number_t& i) const
    {
        rational_number_t res(*this);
        res.assign_division_impl( i );
        return res;
    }

    template <typename OtherIntT>
    rational_number_t& operator/=( const OtherIntT &i )
    {
        return assign_division_impl( rational_number_t(i) );
    }

    template <typename OtherIntT>
    rational_number_t operator/( const OtherIntT &i ) const
    {
        rational_number_t res(*this);
        res.assign_division_impl( rational_number_t(i) );
        return res;
    }
/*
    extended_int128_t& operator%=(const extended_int128_t& i)
    {
        //  dividend or numerator, b the divisor or denom and the result c is called the quotient.
        //  remainder
        extended_int128_t quotient(*this);
        //extended_int128_t remainder;
        quotient.safe_self_divide(i,this);
        return *this;
    }

    extended_int128_t operator%(const extended_int128_t& i) const
    {
        extended_int128_t quotient(*this);
        extended_int128_t remainder;
        quotient.safe_self_divide(i,&remainder);
        return remainder;
    }

    template <typename OtherIntT>
    extended_int128_t& operator%=( const OtherIntT &i )
    {
        extended_int128_t quotient(*this);
        quotient.safe_self_divide(extended_int128_t(i),this);
        return *this;
    }

    template <typename OtherIntT>
    extended_int128_t operator%( const OtherIntT &i ) const
    {
        extended_int128_t quotient(*this);
        extended_int128_t remainder;
        quotient.safe_self_divide(extended_int128_t(i),&remainder);
        return remainder;
    }
*/

    rational_number_t operator++() // prefix
    {
        return increment();
    }
             
    rational_number_t operator++(int)      // suffix
    {
        this_type res(*this);
        increment();
        return res;
    }

    rational_number_t operator--() // prefix
    {
        return decrement();
    }
             
    rational_number_t operator--(int)      // suffix
    {
        this_type res(*this);
        decrement();
        return res;
    }

/*
    bool operator==( const extended_int128_t& i ) const
    {
        return loPart==i.loPart && hiPart==i.hiPart;
    }
    
    template <typename OtherIntT>
    bool operator==( const OtherIntT &i ) const
    {
        return operator==(extended_int128_t(i));
    }

    bool operator!=( const extended_int128_t& i ) const
    {
        return loPart!=i.loPart || hiPart!=i.hiPart;
    }
    
    template <typename OtherIntT>
    bool operator!=( const OtherIntT &i ) const
    {
        return operator!=(extended_int128_t(i));
    }
*/
    bool operator>( rational_number_t i ) const
    {
        rational_number_t thc(*this);
        throwing_calc_common_denom( thc, i);
        return thc.nom > i.nom;
    }

    template <typename OtherIntT>
    bool operator>( const OtherIntT &i ) const
    {
        rational_number_t thc(*this);
        rational_number_t ri(i);
        throwing_calc_common_denom( thc, ri);
        return thc.nom > ri.nom;
    }

    bool operator<( rational_number_t i ) const
    {
        rational_number_t thc(*this);
        throwing_calc_common_denom( thc, i);
        return thc.nom < i.nom;
    }
    
    template <typename OtherIntT>
    bool operator<( const OtherIntT &i ) const
    {
        rational_number_t thc(*this);
        rational_number_t ri(i);
        throwing_calc_common_denom( thc, ri);
        return thc.nom < ri.nom;
    }

    bool operator>=( rational_number_t i ) const
    {
        rational_number_t thc(*this);
        throwing_calc_common_denom( thc, i);
        return thc.nom >= i.nom;
    }
    
    template <typename OtherIntT>
    bool operator>=( const OtherIntT &i ) const
    {
        rational_number_t thc(*this);
        rational_number_t ri(i);
        throwing_calc_common_denom( thc, ri);
        return thc.nom >= ri.nom;
    }

    bool operator<=( rational_number_t i ) const
    {
        rational_number_t thc(*this);
        throwing_calc_common_denom( thc, i);
        return thc.nom <= i.nom;
    }
    
    template <typename OtherIntT>
    bool operator<=( const OtherIntT &i ) const
    {
        rational_number_t thc(*this);
        rational_number_t ri(i);
        throwing_calc_common_denom( thc, ri);
        return thc.nom <= ri.nom;
    }

    bool operator==( rational_number_t i ) const
    {
        rational_number_t thc(*this);
        throwing_calc_common_denom( thc, i);
        return thc.nom == i.nom;
    }
    
    template <typename OtherIntT>
    bool operator==( const OtherIntT &i ) const
    {
        rational_number_t thc(*this);
        rational_number_t ri(i);
        throwing_calc_common_denom( thc, ri);
        return thc.nom == ri.nom;
    }

    bool operator!=( rational_number_t i ) const
    {
        rational_number_t thc(*this);
        throwing_calc_common_denom( thc, i);
        return thc.nom != i.nom;
    }
    
    template <typename OtherIntT>
    bool operator!=( const OtherIntT &i ) const
    {
        rational_number_t thc(*this);
        rational_number_t ri(i);
        throwing_calc_common_denom( thc, ri);
        return thc.nom != ri.nom;
    }


    /*
    operator bool() const
    {
        return is_true();
    }
    */

    bool operator!( ) const
    {
        return is_false();
    }

    bool operator&&( const extended_int128_t& i ) const
    {
        return is_true() && i.is_true();
    }
    
    template <typename OtherT>
    bool operator&&( const OtherT &i )
    {
        return is_true() && i;
    }

    bool operator||( const extended_int128_t& i ) const
    {
        return is_true() || i.is_true();
    }
    
    template <typename OtherT>
    bool operator||( const OtherT &i )
    {
        return is_true() || i;
    }

/*

    extended_int128_t operator~() const
    {
        extended_int128_t res(*this);
        return res.invert();
    }

    extended_int128_t operator&( const extended_int128_t& i ) const
    {
        return extended_int128_t( hiPart&i.hiPart, loPart&i.loPart );
    }

    extended_int128_t& operator&=( const extended_int128_t& i )
    {
        hiPart &= i.hiPart;
        loPart &= i.loPart;
        return *this;
    }

    template <typename OtherIntT>
    extended_int128_t operator&( const OtherIntT &i ) const
    {
        return operator&( extended_int128_t(i) );
    }

    template <typename OtherIntT>
    extended_int128_t operator&=( const OtherIntT &i )
    {
        return operator&=( extended_int128_t(i) );
    }

    extended_int128_t operator|( const extended_int128_t& i ) const
    {
        return extended_int128_t( hiPart|i.hiPart, loPart|i.loPart );
    }

    extended_int128_t& operator|=( const extended_int128_t& i )
    {
        hiPart |= i.hiPart;
        loPart |= i.loPart;
        return *this;
    }

    template <typename OtherIntT>
    extended_int128_t operator|( const OtherIntT &i ) const
    {
        return operator|( extended_int128_t(i) );
    }

    template <typename OtherIntT>
    extended_int128_t operator|=( const OtherIntT &i )
    {
        return operator|=( extended_int128_t(i) );
    }

    extended_int128_t operator^( const extended_int128_t& i ) const
    {
        return extended_int128_t( hiPart^i.hiPart, loPart^i.loPart );
    }

    extended_int128_t& operator^=( const extended_int128_t& i )
    {
        hiPart ^= i.hiPart;
        loPart ^= i.loPart;
        return *this;
    }

    template <typename OtherIntT>
    extended_int128_t operator^( const OtherIntT &i ) const
    {
        return operator^( extended_int128_t(i) );
    }

    template <typename OtherIntT>
    extended_int128_t operator^=( const OtherIntT &i )
    {
        return operator^=( extended_int128_t(i) );
    }

    template <typename OtherIntT>
    extended_int128_t& operator<<=( const OtherIntT &i)
    {
        unsigned shiftNumBits = static_cast<unsigned>(i);
        if (shiftNumBits >= (sizeof(SIntT)+sizeof(UIntT))*8 )
           {
            hiPart = 0;
            loPart = 0;
           }
        else
           {
            UIntT tmp = loPart&make_hi_bits_mask<UIntT>(shiftNumBits);
            tmp >>= sizeof(UIntT)*8 - shiftNumBits;
            loPart <<= shiftNumBits;
            hiPart <<= shiftNumBits;
            hiPart |= (SIntT)tmp;
           }
        return *this;
    }

    template <typename OtherIntT>
    extended_int128_t& operator>>=( const OtherIntT &i)
    {
        unsigned shiftNumBits = static_cast<unsigned>(i);
        if (shiftNumBits >= (sizeof(SIntT)+sizeof(UIntT))*8 )
           {
            hiPart>>= shiftNumBits;
            loPart  = (UIntT)hiPart;
           }
        else
           {
            SIntT tmp = hiPart&make_lo_bits_mask<SIntT>(shiftNumBits);
            tmp <<= sizeof(SIntT)*8 - shiftNumBits;
            hiPart >>= shiftNumBits;
            loPart >>= shiftNumBits;
            loPart |= (UIntT)tmp;
           }
        return *this;
    }

    template <typename OtherIntT>
    extended_int128_t operator<<( const OtherIntT &i) const
    {
        extended_int128_t res(*this);
        res <<= i;
        return res;
    }

    template <typename OtherIntT>
    extended_int128_t operator>>( const OtherIntT &i) const
    {
        extended_int128_t res(*this);
        res >>= i;
        return res;
    }

*/

}; // struct rational_number_t
#include <cli/poppack.h>



template<> inline 
rational_number_t integer_abs<rational_number_t>( rational_number_t i )
    { return i.integer_abs(); }

template<> inline 
rational_number_t throwing_integer_abs<rational_number_t>( rational_number_t i )
    { return i.throwing_integer_abs(); }

inline int integer_sign( const rational_number_t &i )
    { return i.get_sign(); }



inline
void fromCliRational( const ::cli::RationalNumber &crn, rational_number_t &r )
{
    fromCliBigInteger(crn.nominator  , r.nom  );
    fromCliBigInteger(crn.denominator, r.denom);
}

inline
void toCliRational( const rational_number_t &r, ::cli::RationalNumber &crn )
{
    toCliBigInteger(r.nom  , crn.nominator  );
    toCliBigInteger(r.denom, crn.denominator);
}

template<typename CharType>
const CharType* rational_number_from_string(const CharType *str, rational_number_t &r)
{
    if (!str || !(*str)) return str;

    rational_number_t::nom_type nom;
    const CharType* strTmp = extended_size_int_from_string_dec(str, nom);
    if (strTmp==str) return str; // error

    r.assign(nom); // make X/1 number

    if (!(*strTmp))
       {
        return strTmp;
       }

    if (*strTmp==(CharType)' ')
       {
        const CharType* strOrg2 = strTmp;
        while(*strTmp==(CharType)' ') strTmp++;
        int d = char_to_digit( *strTmp );
        if (d<0 || d>=10) // not a number, something else
           {
            return strOrg2;
           }

        bool backSlashFound = false;

        strTmp = extended_size_int_from_string_dec(strTmp, nom);
        if (*strTmp!=(CharType)'/' && *strTmp!=(CharType)'\\')
           { // not a fraction part
            return strOrg2; 
           }
        if (*strTmp==(CharType)'\\') backSlashFound = true;

        strTmp++;
        d = char_to_digit( *strTmp );
        if (d<1 || d>=10) // 0 not allowed for denominator
           { // not a fraction part
            return strOrg2; 
           }
        
        rational_number_t::nom_type denom; 
        const CharType* strTmp2 = extended_size_int_from_string_dec(strTmp, denom);
        if (strTmp2==strTmp)
           return strOrg2; 

        if (backSlashFound) denom.swap(nom);

        rational_number_t r2(nom,denom);
        if (r<0) r2 = -r2;
        //r += r2;
        r.assign_addition_impl( r2, false /* bReduceAfter */);

        return strTmp2;
       }

    if (*strTmp==(CharType)'/' || *strTmp==(CharType)'\\')
       {
        const CharType* strOrg2 = strTmp;
        strTmp++;
        int d = char_to_digit( *strTmp );
        if (d<0 || d>=10) // not a number, something else
           {
            return strOrg2;
           }
        bool backSlashFound = false;
        if (*strTmp==(CharType)'\\') backSlashFound = true;

        rational_number_t::nom_type denom; 
        const CharType* strTmp2 = extended_size_int_from_string_dec(strTmp, denom);
        if (strTmp2==strTmp)
           return strOrg2; 

        if (denom==0)
           return strOrg2; 

        r.denom = denom;
        if (backSlashFound)
           r.swap_nom();
        return strTmp2;
       }

    if (*strTmp==(CharType)',' || *strTmp==(CharType)'.')
       { // decimal fraction found
        //rational_number_t::nom_type denom; 
        strTmp++;
        int d = char_to_digit( *strTmp );
        if (d<0 || d>=10) // not a number, something else
           {
            return strTmp;
           }

        rational_number_t::nom_type decimalNom;

        const CharType* strTmp2 = extended_size_int_from_string_dec(strTmp, decimalNom);
        if (strTmp2==strTmp) return strTmp;
        unsigned decimalPower = (unsigned)(strTmp2-strTmp); // number of digits is a decimal power

        rational_number_t r2(decimalNom, (rational_number_t::denom_type)integer_pow( (unsigned)10, decimalPower) );
        if (r<0) r2 = -r2;
        //r += r2;
        r.assign_addition_impl( r2, false /* bReduceAfter */);

        return strTmp2;
       }

    return strTmp;
}

template<typename CharType>
CharType* format_rational_number_to_buf( CharType *buf, rational_number_t r, bool makeMixed = true)
{
    CharType *p = buf;
    int sign = integer_sign(r);
    r = integer_abs(r);

    if (sign<0)
       *p++ = (CharType)'-';

    if (r.denom==1) makeMixed = true;

    if (makeMixed)
       {
        rational_number_t::nom_type intPart = 0;
        r.make_proper(&intPart);

        if (intPart!=0)
           p = format_extended_size_int_to_dec_buf( p, intPart );
        if (!r.nom.is_zero())
           {
            if (intPart!=0)
               *p++ = (CharType)' ';
            p = format_extended_size_int_to_dec_buf( p, r.nom );
            *p++ = (CharType)'/';
            p = format_extended_size_int_to_dec_buf( p, r.denom );
           }
       }
    else
       {
        p = format_extended_size_int_to_dec_buf( p, r.nom );
        *p++ = (CharType)'/';
        p = format_extended_size_int_to_dec_buf( p, r.denom );
       }
    *p = 0;
    return p;
}

inline
std::string& format_rational_number( std::string &formatTo, const rational_number_t &r, bool makeMixed = true)
{
    char buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_rational_number_to_buf( buf, r, makeMixed );
    formatTo.assign(buf);
    return formatTo;
}

inline
std::wstring& format_rational_number( std::wstring &formatTo, const rational_number_t &r, bool makeMixed = true)
{
    wchar_t buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_rational_number_to_buf( buf, r, makeMixed );
    formatTo.assign(buf);
    return formatTo;
}

template<typename CharType>
CharType* format_rational_number_dec_to_buf( CharType *buf, rational_number_t r, int numSigns = 2, rounding_type rounding = rounding_math, const CharType *decimalSepStr = 0)
{
    CharType defSep[2] = { (CharType)'.', 0 };
    if (!decimalSepStr) decimalSepStr = &defSep[0];
    CharType *p = buf;
    int sign = integer_sign(r);
    r = integer_abs(r);

    if (sign<0)
       *p++ = (CharType)'-';

    //if (r.denom==1) makeMixed = true;

    rational_number_t::nom_type intPart = 0;
    r.make_proper(&intPart);

    p = format_extended_size_int_to_dec_buf( p, intPart );
    bool bAuto = false;
    if (numSigns<0)
       {
        numSigns = -numSigns;
        bAuto    = true;
       }

    while(*decimalSepStr) *p++ = *decimalSepStr++;

    if (!numSigns)
       {
        *p = 0;
        return p;
       }

/*
    if (r.nom==0 && bAuto) // fractional part not required
       {
        *p = 0;
        return p;
       }
    SIntT        to_int_type() const { return (SIntT)loPart; }
    UIntT        to_unsigned_type() const { return loPart; }
    SIntHalfSize to_half_int_type() const { return (SIntHalfSize)(SIntT)loPart; }
    UIntHalfSize to_half_unsigned_type() const { return (UIntHalfSize)loPart; }

*/

    unsigned pow10 = integer_pow( (unsigned)10, numSigns+1 );
    intPart = r.nom;
    intPart *= pow10;

    intPart /= r.denom;

    unsigned truncedDigit = (unsigned)(intPart%10).to_half_unsigned_type();
    //intPart quotient = intPart 10
    intPart /= 10;
    unsigned lastDigit = (unsigned)(intPart%10).to_half_unsigned_type();

    switch(rounding)
       {
        case rounding_trunctate:
             break;
        case rounding_math:
             if (truncedDigit>=5) intPart++; // round up
             break;
        case rounding_bankers:  
             if (truncedDigit>5) intPart++; // round up
             else if (truncedDigit==5)
                {
                 if (lastDigit&1) intPart++; // round to closest even
                }
             break;
        //default:            
       }

    CharType *p2 = format_extended_size_int_to_dec_buf( p, intPart, (unsigned)numSigns, (CharType)'0' );
    *p2 = 0;
    if (bAuto)
       {
        while(p2!=p)
           {
            --p2;
            int d = char_to_digit( *p2 );
            if (d==0) continue;
            break;
           }
        ++p2;
        *p2 = 0;
       }

    return p2;
}

inline
std::string& format_rational_number_dec( std::string &formatTo, const rational_number_t &r, int numSigns = 2, rounding_type rounding = rounding_math, const char *decimalSepStr = 0)
{
    char buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_rational_number_dec_to_buf( buf, r, numSigns, rounding, decimalSepStr );
    formatTo.assign(buf);
    return formatTo;
}

inline
std::wstring& format_rational_number_dec( std::wstring &formatTo, const rational_number_t &r, int numSigns = 2, rounding_type rounding = rounding_math, const wchar_t *decimalSepStr = 0)
{
    wchar_t buf[CLI_NUMERIC_FORMAT_BUF_SIZE];
    format_rational_number_dec_to_buf( buf, r, numSigns, rounding, decimalSepStr );
    formatTo.assign(buf);
    return formatTo;
}


/*
const CharType* extended_size_int_from_string_dec(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* extended_size_int_from_string_hex(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* extended_size_int_from_string_oct(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* extended_size_int_from_string_auto(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i, unsigned *pBaseFound)

CharType* format_extended_size_int_to_dec_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, CharType fillChar = (CharType)' ')
CharType* format_extended_size_int_to_hex_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false)
CharType* format_extended_size_int_to_oct_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0)

std::string& format_extended_size_int_oct( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0 )
std::wstring& format_extended_size_int_oct( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0 )
std::string& format_extended_size_int_hex( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false )
std::wstring& format_extended_size_int_hex( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false )
std::string& format_extended_size_int_dec( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, char fillChar = ' ' )
std::wstring& format_extended_size_int_dec( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, wchar_t fillChar = L' ' )
*/


/*

template<typename CharType>
int char_to_digit( CharType c )
{
    if (c>=(CharType)'0' && c<=(CharType)'9') return (int)(c - (CharType)'0');
    if (c>=(CharType)'a' && c<=(CharType)'f') return (int)(c - (CharType)'a') + 10;
    if (c>=(CharType)'A' && c<=(CharType)'F') return (int)(c - (CharType)'A') + 10;
    return -1;
}

const CharType* from_string_dec(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* from_string_hex(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* from_string_oct(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i)
const CharType* from_string_auto(const CharType *str, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> &i, unsigned *pBaseFound)

void format_string_hex_to_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false)
void format_string_oct_to_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0)
void format_string_dec_to_buf( CharType *buf, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, CharType fillChar = (CharType)' ')

std::string& format_string_oct( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0 )
std::wstring& format_string_oct( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0 )
std::string& format_string_hex( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false )
std::wstring& format_string_hex( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, bool lowerCase = false )
std::string& format_string_dec( std::string &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, char fillChar = ' ' )
std::wstring& format_string_dec( std::wstring &formatTo, extended_size_int_t<SIntT, UIntT, SIntHalfSize, UIntHalfSize> i, unsigned minWidth = 0, wchar_t fillChar = L' ' )
*/


/*
::cli::BigInteger
CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
    UINT64                      loPart;
    INT64                       hiPart;
CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);


::cli::Fraction
CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
    STRUCT_CLI_BIGINTEGER       nominator;
    STRUCT_CLI_BIGINTEGER       denominator;
CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);


#ifndef STRUCT_CLI_FRACTION_DEFINED
#include <cli/pshpack8.h>
    struct Fraction
    {
                INT64                       nominator;
                UINT64                      denominator;
    };
#include <cli/poppack.h>
#else
    typedef ::cli::Fraction Fraction;
#endif

struct CFraction : public Fraction
{};
*/



}; // namespace numeric
}; // namespace cli


namespace std
{
/*
template<>
void swap(g,l);
*/
}; // namespace std


/*
#ifndef NOMINMAX
#endif
*/

#ifdef CLI_NUMERIC_RESTORE_WIN_MAX /*max*/
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifdef CLI_NUMERIC_RESTORE_WIN_MIN /*min*/
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif




#endif /* CLI_NUMERIC_H */

