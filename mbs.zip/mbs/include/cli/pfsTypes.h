#ifndef CLI_PFSTYPES_H
#define CLI_PFSTYPES_H

/* add this lines to your scr
#ifndef CLI_PFSTYPES_H
    #include <cli/pfstypes.h>
#endif
*/

#ifndef CLI_IALLOCATOR_H
    #include <cli/iallocator.h>
#endif


#if !defined(PFS_STRING_T_DEFINED) || PFS_STRING_T_DEFINED==0

    #include <cli/pshpack1.h>
    typedef struct tag_pfs_string_t
    {
        char                            *data         ;  /* pointer to memory that holds data */
        SIZE_T                           strSize      ;  /* size (len) of data*/
        SIZE_T                           bufSize      ;  /* current buffer size */
        INTERFACE_CLI_ISIMPLEALLOCATOR  *pAllocator   ;  /* allocator for dynamic strings */
        char                            *staticOrgBuf ;  /* mixed strings (static/dynamic) ptr to org static buf */
        SIZE_T                           staticOrgSize;  /* mixed strings org static buf size */
    } pfs_string_t;
    #include <cli/poppack.h>

    typedef pfs_string_t      *  ptr_pfs_string_t;
    typedef const pfs_string_t*  cptr_pfs_string_t;

    #if defined(__cplusplus)
    inline SIZE_T pfs_str_size( cptr_pfs_string_t str ) { return str->strSize; }
    inline bool   pfs_str_empty( cptr_pfs_string_t str ) { return str->strSize!=0; }
    inline const char* pfs_str_data( cptr_pfs_string_t str ) { return str->data; }
    inline const char* pfs_str_c_str( cptr_pfs_string_t str ) { return str->data; }
    #endif

    #ifndef PFS_PARSER_STATE_TYPE_DEFINED
        #define PFS_PARSER_STATE_TYPE_DEFINED
        /* Keep it in sync with RCODE - utils/pfserr.h */
        /* typedef unsigned long pfs_parser_state_t; */
        typedef RCODE pfs_parser_state_t;
    #endif


#else

    typedef pfs_string_t      *  ptr_pfs_string_t;
    typedef const pfs_string_t*  cptr_pfs_string_t;

#endif




#endif /* CLI_PFSTYPES_H */


