#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_YIELD_H
#define CLI_YIELD_H

/*
#ifndef CLI_YIELD_H
    #include <cli/yield.h>
#endif
*/

#ifndef CLI_DETECTTARGET_H
    #include <cli/detectTarget.h>
#endif


#ifdef WIN32

    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif

#else

    // _POSIX_PRIORITY_SCHEDULING must be defined

    #if defined(LINUX) || defined(FREEBSD)

        #if !defined(_SCHED_H)
            #include <sched.h>
        #endif

        #if !defined(_SYS_SELECT_H) && !defined(_SYS_SELECT_H_) && !defined(_SELECT_H_)
            #include <sys/select.h>
        #endif

    #else
        #include <unistd.h>
        #ifndef _POSIX_PRIORITY_SCHEDULING
            #error "Platform not supported"
        #endif

    #endif

#endif

namespace cli
{
namespace sched
{

// ::cli::sched::yield()
inline void yield()
   {
    #ifdef WIN32
    ::Sleep(0);
    #else
        #if defined(LINUX) || defined(FREEBSD)
            ::sched_yield();
        #else
            #error "Platform not supported"
        #endif
    #endif
   }

// millisecond sleep
// ::cli::sched::sleepMs()
inline void sleepMs(unsigned ms)
   {
    #ifdef WIN32
    ::Sleep(ms);
    #else
    if (!ms)
       yield();
    else
       {
        #if defined(LINUX) || defined(FREEBSD)
            struct timeval to;
            to.tv_sec  = ms / 1000;
            to.tv_usec = (ms % 1000) * 1000;
            ::select( 0, 0, 0, 0, &to);
        #else
            #error "Platform not supported"
        #endif
       }
    #endif
   }

}; // namespace sched
}; // namespace cli



#endif /* CLI_YIELD_H */

