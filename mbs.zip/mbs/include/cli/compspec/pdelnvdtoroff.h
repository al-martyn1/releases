#if defined(_MSC_VER)

    #pragma warning( push ) 
    #pragma warning( disable : 4265 ) // C4265 Visual C++ warning - virtual member function and no virtual destructor

#elif defined(__GNUC__) && !(defined(WIN32) || defined(_WIN32))

    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wdelete-non-virtual-dtor"
    //#pragma GCC diagnostic warning "-Wformat"

#endif

