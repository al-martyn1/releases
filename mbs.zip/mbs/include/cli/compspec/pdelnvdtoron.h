#if defined(_MSC_VER)

    #pragma warning( pop )

#elif defined(__GNUC__) && !(defined(WIN32) || defined(_WIN32))

    #pragma GCC diagnostic pop

#endif

