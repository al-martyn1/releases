#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_TICKCOUNT_H
#define CLI_TICKCOUNT_H

/* Add next lines to your C/C++ code
#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif
*/


#if !defined(CLI_TICKCOUNT_STANDALONE)

    #ifndef CLI_CLI2_H
        #include <cli/cli2.h>
    #endif
    
    #ifndef CLI_CLI2BASE_H
        #include <cli/cli2base.h>
    #endif
    
    #ifndef CLI_CLI2TYPES_H
        #include <cli/cli2types.h>
    #endif

#else /* standalone */

    #ifndef EXTERN_C
        #ifdef __cplusplus
            #define EXTERN_C   extern "C"
        #else
            #define EXTERN_C
        #endif
    #endif    

    #ifndef EXTERN_CLI
        #ifdef CLI_MONOLITHIC
            #define EXTERN_CLI  EXTERN_C
        #else
            #define EXTERN_CLI  EXTERN_C
        #endif
    #endif

    #ifndef MODULE_EXPORT
        #if defined(_MSC_VER) || defined(__BORLANDC__) || (defined(__GNUC__) && defined(_WIN32))
            #define MODULE_EXPORT __declspec(dllexport)
            #define MODULE_IMPORT __declspec(dllimport)
            #define MODULE_LOCAL
        #elif defined(__GNUC__)
            #ifdef HAVE_GCCVISIBILITYPATCH
              #define MODULE_EXPORT __attribute__ ((visibility("default")))
              #define MODULE_IMPORT __attribute__ ((visibility("default")))
              //#define MODULE_LOCAL __attribute__ ((visibility("hidden")))
              #define MODULE_LOCAL __attribute__ ((visibility("internal")))
            #else
              #define MODULE_EXPORT
              #define MODULE_IMPORT
              #define MODULE_LOCAL
            #endif
        #endif
    #endif

    #ifndef MODULE_EXPORT_FUNC
        #define MODULE_EXPORT_FUNC MODULE_EXPORT
    #endif
    
    #ifndef MODULE_IMPORT_FUNC
        #define MODULE_IMPORT_FUNC MODULE_IMPORT
    #endif
    
    #if defined(CLI_MONOLITHIC) || defined(CLI_MONOLITH)
        #define CLIAPIENTRY
    #else
        #if defined(CLI_INTERNAL) // used to compile cli itself
            #define CLIAPIENTRY MODULE_EXPORT_FUNC
        #else
            #define CLIAPIENTRY MODULE_IMPORT_FUNC
        #endif
    #endif

    #if defined(WIN32)
        #include <windows.h>
    #else
        #include <stdint.h>
    #endif

    typedef int64_t          INT64, *PINT64;
    typedef uint64_t         UINT64, *PUINT64;
    typedef UINT64   TICK_T;
    typedef INT64    TICK_DIFF_T;

#endif /* standalone or not */


EXTERN_CLI
CLIAPIENTRY
TICK_T
CLICALL
cliGetTickCount();

EXTERN_CLI
CLIAPIENTRY
TICK_DIFF_T
CLICALL
cliTickDiff(TICK_T start_tick, TICK_T end_tick);

EXTERN_CLI
CLIAPIENTRY
INT
CLICALL
cliTickDiffShort(TICK_T start_tick, TICK_T end_tick);

EXTERN_CLI
CLIAPIENTRY
TICK_DIFF_T
CLICALL
cliGetCurrentTickDiff(TICK_T start_tick);

EXTERN_CLI
CLIAPIENTRY
INT
CLICALL
cliGerCurrentTickDiffShort(TICK_T start_tick);


#endif /* CLI_TICKCOUNT_H */

