#ifndef CLI_IFDEFS_H
#define CLI_IFDEFS_H


// GCC attribute ms_abi/sysv_abi
// void fatal () __attribute__ ((nothrow));


/*
InterFace DEFinitionS Header
*/

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif

#ifdef _WIN32
    #ifndef _BASETYPS_H_
        #include <basetyps.h>
    #endif

    #ifndef _OBJBASE_H_
        #include <ObjBase.h>
    #endif
#endif

/* to avoid conflict with win32 objbase.h we test 'interface' macro existence */
#if !defined(interface)
    #if defined(__cplusplus) && !defined(CINTERFACE)
        #define __STRUCT__ struct
        #define interface __STRUCT__
    #else
        #define interface struct
    #endif
#endif


#ifndef DECLSPEC_NOVTABLE
    #if (_MSC_VER >= 1100) && defined(__cplusplus) && !defined(CINTERFACE)
        #define DECLSPEC_NOVTABLE   __declspec(novtable)
    #else
        #define DECLSPEC_NOVTABLE
    #endif
#endif

#ifndef CLI_BEGIN_STRUCT_DECLARATION
    #if defined(__cplusplus) && !defined(CINTERFACE)
        #define CLI_BEGIN_STRUCT_DECLARATION(name)  struct name {
    #else
        #define CLI_BEGIN_STRUCT_DECLARATION_X(name)  struct tag_##name {
        #define CLI_BEGIN_STRUCT_DECLARATION(name)  CLI_BEGIN_STRUCT_DECLARATION_X(name)
    #endif
#endif /* CLI_BEGIN_STRUCT_DECLARATION */


#ifndef CLI_END_STRUCT_DECLARATION
    #if defined(__cplusplus) && !defined(CINTERFACE)
        #define CLI_END_STRUCT_DECLARATION(name)  }
    #else
        #define CLI_END_STRUCT_DECLARATION(name)  }  /* name */ 
    #endif
#endif /* CLI_END_STRUCT_DECLARATION */


#ifndef CLI_BEGIN_UNION_DECLARATION
    #if defined(__cplusplus) && !defined(CINTERFACE)
        #define CLI_BEGIN_UNION_DECLARATION(name)  struct name { union {
    #else
        #define CLI_BEGIN_UNION_DECLARATION_X(name)  struct tag_##name { union {
        #define CLI_BEGIN_UNION_DECLARATION(name)  CLI_BEGIN_UNION_DECLARATION_X(name)
    #endif
#endif /* CLI_BEGIN_UNION_DECLARATION */


#ifndef CLI_END_UNION_DECLARATION
    #if defined(__cplusplus) && !defined(CINTERFACE)
        #define CLI_END_UNION_DECLARATION(name)  }; }
    #else
        #define CLI_END_UNION_DECLARATION(name)  }; }  /* name */ 
    #endif
#endif /* CLI_END_UNION_DECLARATION */

   
#ifndef CLI_STRUCT_TYPEDEF
    #if defined(__cplusplus) && !defined(CINTERFACE)
        #define CLI_STRUCT_TYPEDEF(orgName, newName)     typedef  orgName newName
    #else
        #define CLI_STRUCT_TYPEDEF_X(orgName, newName)   typedef  struct tag_##orgName newName
        #define CLI_STRUCT_TYPEDEF(orgName, newName)     CLI_STRUCT_ALIAS_X(orgName, newName)
    #endif
#endif /* CLI_END_STRUCT_DECLARATION */

   


#if defined(__cplusplus) && !defined(CINTERFACE)

    #define CLIMETHOD_(type,name)    virtual type CLICALL name
    #define CLIMETHOD(name)          CLIMETHOD_(RCODE,name)
    #define CLIMETHODVA_(type,name)  virtual type CLICALLVA name
    #define CLIMETHODVA(name)        CLIMETHODVA_(RCODE,name)

    #define CLIMETHODIMP_(type,name)    type CLICALL name
    #define CLIMETHODIMP(name)          CLIMETHODIMP_(RCODE,name)
    #define CLIMETHODVAIMP_(type,name)  type CLICALLVA name
    #define CLIMETHODVAIMP(name)        CLIMETHODVAIMP_(RCODE,name)

    #ifndef PURE
        #define PURE = 0
    #endif

    #ifndef THIS_
        #define THIS_
    #endif

    #ifndef THIS
        #define THIS
    #endif

    #ifndef CLI_DECLARE_INTERFACE
        #define CLI_DECLARE_INTERFACE(iface)    interface DECLSPEC_NOVTABLE iface
    #endif
    
    #ifndef CLI_DECLARE_INTERFACE_
        #define CLI_DECLARE_INTERFACE_(iface, baseiface)    interface DECLSPEC_NOVTABLE iface : public baseiface
    #endif

    #ifndef CLI_DECLARE_INTERFACE2_
        #define CLI_DECLARE_INTERFACE2_(iface                             \
                                       , baseiface1                       \
                                       , baseiface2                       \
                                       )                                  \
                    interface DECLSPEC_NOVTABLE iface : public baseiface1 \
                                                      , public baseiface2
    #endif

    #ifndef CLI_DECLARE_INTERFACE3_
        #define CLI_DECLARE_INTERFACE3_(iface                             \
                                       , baseiface1                       \
                                       , baseiface2                       \
                                       , baseiface3                       \
                                       )                                  \
                    interface DECLSPEC_NOVTABLE iface : public baseiface1 \
                                                      , public baseiface2 \
                                                      , public baseiface3
    #endif

    #ifndef CLI_DECLARE_INTERFACE4_
        #define CLI_DECLARE_INTERFACE4_(iface                             \
                                       , baseiface1                       \
                                       , baseiface2                       \
                                       , baseiface3                       \
                                       , baseiface4                       \
                                       )                                  \
                    interface DECLSPEC_NOVTABLE iface : public baseiface1 \
                                                      , public baseiface2 \
                                                      , public baseiface3 \
                                                      , public baseiface4
    #endif

    #ifndef CLI_DECLARE_INTERFACE5_
        #define CLI_DECLARE_INTERFACE5_(iface                             \
                                       , baseiface1                       \
                                       , baseiface2                       \
                                       , baseiface3                       \
                                       , baseiface4                       \
                                       , baseiface5                       \
                                       )                                  \
                    interface DECLSPEC_NOVTABLE iface : public baseiface1 \
                                                      , public baseiface2 \
                                                      , public baseiface3 \
                                                      , public baseiface4 \
                                                      , public baseiface5
    #endif

    #ifndef CLI_PREDECLARE_STRUCT
        #define CLI_PREDECLARE_STRUCT(structName) struct structName
    #endif

    #ifndef CLI_PREDECLARE_INTERFACE
        #define CLI_PREDECLARE_INTERFACE(iface)   interface iface
    #endif

    // for usage without agregation support
    #define CLI_BEGIN_INTERFACE_MAP(className)                                                           \
                    CLIMETHOD_(RCODE, queryInterface) (THIS_ const CHAR*    interfaceId                  \
                                                           , VOID**    ifPtr                             \
                                                      )                                                  \
                       {                                                                                 \
                        if (!ifPtr) return CLI_ERR_INVALID_OUT_PTR;                                      \
                                                                                                         \
                        if (!interfaceId)                                                                \
                           {                                                                             \
                            INTERFACE_CLI_IUNKNOWN* pi = static_cast<INTERFACE_CLI_IUNKNOWN*>(this);     \
                            pi->addRef();                                                                \
                            *ifPtr = (void*)pi;                                                          \
                            return CLI_OK;                                                               \
                           }                                                                             \
                                                                                                         \
                         if (!strcmp(interfaceId, INTERFACE_CLI_IUNKNOWN_IID))                           \
                            {                                                                            \
                             INTERFACE_CLI_IUNKNOWN* pi = static_cast<INTERFACE_CLI_IUNKNOWN*>(this);    \
                             pi->addRef();                                                               \
                             *ifPtr = (void*)pi;                                                         \
                             return CLI_OK;                                                              \
                            }
    // reinterpret_cast
    #define CLI_BEGIN_INTERFACE_MAP2(className, ifUnknown)                                               \
                    CLIMETHOD_(RCODE, queryInterface) (THIS_ const CHAR*    interfaceId                  \
                                                           , VOID**    ifPtr                             \
                                                      )                                                  \
                       {                                                                                 \
                        if (!ifPtr) return CLI_ERR_INVALID_OUT_PTR;                                      \
                                                                                                         \
                        if (!interfaceId)                                                                \
                           {                                                                             \
                            INTERFACE_CLI_IUNKNOWN* pi                                                   \
                                    = static_cast<INTERFACE_CLI_IUNKNOWN*>(                              \
                                                            static_cast<ifUnknown*>(this)                \
                                                                          );                             \
                            pi->addRef();                                                                \
                            *ifPtr = (void*)pi;                                                          \
                            return CLI_OK;                                                               \
                           }                                                                             \
                                                                                                         \
                         if (!strcmp(interfaceId, INTERFACE_CLI_IUNKNOWN_IID))                           \
                            {                                                                            \
                            INTERFACE_CLI_IUNKNOWN* pi                                                   \
                                    = static_cast<INTERFACE_CLI_IUNKNOWN*>(                              \
                                                            static_cast<ifUnknown*>(this)                \
                                                                          );                             \
                             pi->addRef();                                                               \
                             *ifPtr = (void*)pi;                                                         \
                             return CLI_OK;                                                              \
                            }

    #define CLI_IMPLEMENT_INTERFACE(interfaceName)                                   \
                        if (!strcmp(interfaceId, interfaceName##_IID))               \
                           {                                                         \
                            interfaceName* pi = static_cast<interfaceName*>(this);   \
                            pi->addRef();                                            \
                            *ifPtr = (void*)pi;                                      \
                            return CLI_OK;                                           \
                           }

    #define CLI_IMPLEMENT_INTERFACE2(interfaceName, throughType)                     \
                        if (!strcmp(interfaceId, interfaceName##_IID))               \
                           {                                                         \
                            interfaceName* pi = static_cast<interfaceName*>( static_cast<throughType*>(this) );   \
                            pi->addRef();                                            \
                            *ifPtr = (void*)pi;                                      \
                            return CLI_OK;                                           \
                           }

    #define CLI_END_INTERFACE_MAP(className)                 \
                        return CLI_ERR_UNKNOWN_INTERFACE;    \
                       }


#else

    #define CLIMETHOD_(type,name)    type (CLICALL * name)
    #define CLIMETHOD(name)          CLIMETHOD_(RCODE,name)
    #define CLIMETHODVA_(type,name)  type (CLICALLVA * name)
    #define CLIMETHODVA(name)        CLIMETHODVA_(RCODE,name)

    #ifndef PURE
        #define PURE
    #endif

    #ifndef THIS_
        #define THIS_   INTERFACE * This,
    #endif

    #ifndef THIS
        #define THIS    INTERFACE * This
    #endif

    #ifdef CONST_VTABLE
        #undef CONST_VTBL
        #define CONST_VTBL const
    #else /* CONST_VTABLE not defined*/
        #undef CONST_VTBL
        #define CONST_VTBL
    #endif

    #ifndef CLI_DECLARE_INTERFACE
        #define CLI_DECLARE_INTERFACE_AUX_(iface)    typedef interface tag_##iface {           \
                                                CONST_VTBL struct iface##Vtbl * lpVtbl;        \
                                            } iface;                                           \
                                            typedef CONST_VTBL struct iface##Vtbl iface##Vtbl; \
                                            const struct iface##Vtbl
        #define CLI_DECLARE_INTERFACE(iface)    CLI_DECLARE_INTERFACE_AUX_(iface)
    #endif

    #ifndef CLI_DECLARE_INTERFACE_
        #define CLI_DECLARE_INTERFACE_(iface, baseiface)    CLI_DECLARE_INTERFACE(iface)
    #endif

    #ifndef CLI_PREDECLARE_STRUCT
        #define CLI_PREDECLARE_STRUCT(structName) typedef struct tag_##structName structName
    #endif

    #ifndef CLI_PREDECLARE_INTERFACE
        #define CLI_PREDECLARE_INTERFACE(iface)   typedef interface tag_##iface iface
    #endif

#endif


#ifndef MCALL
    #if defined(__cplusplus) && !defined(CINTERFACE)    
        #define MCALL(objPtr)    (objPtr)
    #else
        #define MCALL(objPtr)    (objPtr)->lpVtbl
    #endif
#endif


#ifdef __cplusplus
namespace cli
{
namespace ifdefs
{

template <typename IFWrapper>
//template <class IFWrapper> inline
void swap( IFWrapper &w1, IFWrapper &w2 )
   {
    typename IFWrapper::interface_pointer_type* p1 = w1.getPP();
    typename IFWrapper::interface_pointer_type* p2 = w2.getPP();
    #ifdef CLIASSERT
    CLIASSERT(p1 && p2);
    #endif
    typename IFWrapper::interface_pointer_type tmp = w1.getIfPtr();
    *p1 = w2.getIfPtr();
    *p2 = tmp;
   }

}; // namespace ifdefs
}; // namespace cli
#endif /* __cplusplus */




#endif /* CLI_IFDEFS_H */

