#ifndef CLI_STRENC_H
#define CLI_STRENC_H

/* add this lines to your scr
#ifndef CLI_STRENC_H
    #include <cli/strenc.h>
#endif
*/

#ifndef CLI_ISTRENC_H
    #include <cli/istrenc.h>
#endif

namespace cli
{

// en.wikipedia.org/wiki/Byte_order_mark

inline
ENUM_CLI_EBOMTYPE detectEncodingBomImplementation(const char * docData, SIZE_T docDataSize, SIZE_T &resBomSize)
   {
    resBomSize = 0;
    if (docDataSize<2) return CLI_EBOMTYPE_BOMUNKNOWN;

    if (docData[0]==(char)0xEF) // EF BB BF: utf-8 branch
       {
        if (docDataSize<3)                              return CLI_EBOMTYPE_BOMUNKNOWN;
        if (docData[1]!=(char)0xBB)                     return CLI_EBOMTYPE_BOMUNKNOWN;
        if (docData[2]!=(char)0xBF)                     return CLI_EBOMTYPE_BOMUNKNOWN;
        resBomSize = 3;
        return CLI_EBOMTYPE_BOMUTF8;
       }
    else if (docData[0]==(char)0xFE) // FE FF: UTF-16 (BE) branch
       {
        if (docData[1]!=(char)0xFF) return CLI_EBOMTYPE_BOMUNKNOWN;
        resBomSize = 2;
        return CLI_EBOMTYPE_BOMUTF16BE;
       }
    else if (docData[0]==(char)0xFF) // FF FE / FF FE 00 00: UTF-16/32 (LE) branch
       {
        if (docData[1]!=(char)0xFE)                     return CLI_EBOMTYPE_BOMUNKNOWN;
        if (docDataSize<4)            { resBomSize = 2; return CLI_EBOMTYPE_BOMUTF16LE; }
        if (docData[2]!=(char)0 || docData[3]!=(char)0) return CLI_EBOMTYPE_BOMUNKNOWN;
        resBomSize = 4;
        return CLI_EBOMTYPE_BOMUTF32LE;
       }
    else if (docData[0]==0x00) // 00 00 FE FF: UTF-32 (BE) branch
       {
        if (docData[1]!=(char)0   )    return CLI_EBOMTYPE_BOMUNKNOWN;
        if (docDataSize<4   )          return CLI_EBOMTYPE_BOMUNKNOWN;
        if (docData[2]!=(char)0xFE)    return CLI_EBOMTYPE_BOMUNKNOWN;
        if (docData[3]!=(char)0xFF)    return CLI_EBOMTYPE_BOMUNKNOWN;
        resBomSize = 4;
        return CLI_EBOMTYPE_BOMUTF32BE;
       }

    return CLI_EBOMTYPE_BOMUNKNOWN;
   }






}; // namespace cli


#endif /* CLI_STRENC_H */

