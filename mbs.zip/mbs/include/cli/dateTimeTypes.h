#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DATETIMETYPES_H
#define CLI_DATETIMETYPES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/dateTimeTypes.h>", CLI_DATETIMETYPES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::EDateTimeFormatFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EDATETIMEFORMATFLAGS       UINT
#else
    #define ENUM_CLI_EDATETIMEFORMATFLAGS       UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EDATETIMEFORMATFLAGS_PARTMASK
    #define CLI_EDATETIMEFORMATFLAGS_PARTMASK                 CONSTANT_UINT(0xFFF000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PARTMASK */

#ifndef CLI_EDATETIMEFORMATFLAGS_PYEAR
    #define CLI_EDATETIMEFORMATFLAGS_PYEAR    CONSTANT_UINT(0x00001000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PYEAR */

#ifndef CLI_EDATETIMEFORMATFLAGS_PMONTH
    #define CLI_EDATETIMEFORMATFLAGS_PMONTH   CONSTANT_UINT(0x00002000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PMONTH */

#ifndef CLI_EDATETIMEFORMATFLAGS_PDAYOFWEEK
    #define CLI_EDATETIMEFORMATFLAGS_PDAYOFWEEK               CONSTANT_UINT(0x00003000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PDAYOFWEEK */

#ifndef CLI_EDATETIMEFORMATFLAGS_PDAY
    #define CLI_EDATETIMEFORMATFLAGS_PDAY     CONSTANT_UINT(0x00004000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PDAY */

#ifndef CLI_EDATETIMEFORMATFLAGS_PHOUR
    #define CLI_EDATETIMEFORMATFLAGS_PHOUR    CONSTANT_UINT(0x00005000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PHOUR */

#ifndef CLI_EDATETIMEFORMATFLAGS_PMINUTE
    #define CLI_EDATETIMEFORMATFLAGS_PMINUTE  CONSTANT_UINT(0x00006000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PMINUTE */

#ifndef CLI_EDATETIMEFORMATFLAGS_PSECOND
    #define CLI_EDATETIMEFORMATFLAGS_PSECOND  CONSTANT_UINT(0x00007000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PSECOND */

#ifndef CLI_EDATETIMEFORMATFLAGS_PMICROSEC
    #define CLI_EDATETIMEFORMATFLAGS_PMICROSEC                CONSTANT_UINT(0x00008000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PMICROSEC */

#ifndef CLI_EDATETIMEFORMATFLAGS_PAPINDICATOR
    #define CLI_EDATETIMEFORMATFLAGS_PAPINDICATOR             CONSTANT_UINT(0x00009000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PAPINDICATOR */

#ifndef CLI_EDATETIMEFORMATFLAGS_PGMOFFSET
    #define CLI_EDATETIMEFORMATFLAGS_PGMOFFSET                CONSTANT_UINT(0x0000A000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PGMOFFSET */

#ifndef CLI_EDATETIMEFORMATFLAGS_PWEEK
    #define CLI_EDATETIMEFORMATFLAGS_PWEEK    CONSTANT_UINT(0x0000B000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PWEEK */

#ifndef CLI_EDATETIMEFORMATFLAGS_PSIGNPLUS
    #define CLI_EDATETIMEFORMATFLAGS_PSIGNPLUS                CONSTANT_UINT(0x0000C000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PSIGNPLUS */

#ifndef CLI_EDATETIMEFORMATFLAGS_PSIGNMINUS
    #define CLI_EDATETIMEFORMATFLAGS_PSIGNMINUS               CONSTANT_UINT(0x0000D000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PSIGNMINUS */

#ifndef CLI_EDATETIMEFORMATFLAGS_PSIGNIGNORE
    #define CLI_EDATETIMEFORMATFLAGS_PSIGNIGNORE              CONSTANT_UINT(0x0000E000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PSIGNIGNORE */

#ifndef CLI_EDATETIMEFORMATFLAGS_PSIGNIGNORESTRONG
    #define CLI_EDATETIMEFORMATFLAGS_PSIGNIGNORESTRONG        CONSTANT_UINT(0x0000F000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PSIGNIGNORESTRONG */

#ifndef CLI_EDATETIMEFORMATFLAGS_PSIGNDATESEP
    #define CLI_EDATETIMEFORMATFLAGS_PSIGNDATESEP             CONSTANT_UINT(0x00010000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PSIGNDATESEP */

#ifndef CLI_EDATETIMEFORMATFLAGS_PSIGNTIMESEP
    #define CLI_EDATETIMEFORMATFLAGS_PSIGNTIMESEP             CONSTANT_UINT(0x00011000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PSIGNTIMESEP */

#ifndef CLI_EDATETIMEFORMATFLAGS_PSTARTQUOTE
    #define CLI_EDATETIMEFORMATFLAGS_PSTARTQUOTE              CONSTANT_UINT(0x00012000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PSTARTQUOTE */

#ifndef CLI_EDATETIMEFORMATFLAGS_PENDQUOTE
    #define CLI_EDATETIMEFORMATFLAGS_PENDQUOTE                CONSTANT_UINT(0x00013000)
#endif /* CLI_EDATETIMEFORMATFLAGS_PENDQUOTE */

#ifndef CLI_EDATETIMEFORMATFLAGS_MASKNUMDIGITS
    #define CLI_EDATETIMEFORMATFLAGS_MASKNUMDIGITS            CONSTANT_UINT(0x000F)
#endif /* CLI_EDATETIMEFORMATFLAGS_MASKNUMDIGITS */

#ifndef CLI_EDATETIMEFORMATFLAGS_NUMDIGITSONE
    #define CLI_EDATETIMEFORMATFLAGS_NUMDIGITSONE             CONSTANT_UINT(0x0000)
#endif /* CLI_EDATETIMEFORMATFLAGS_NUMDIGITSONE */

#ifndef CLI_EDATETIMEFORMATFLAGS_NUMDIGITS1
    #define CLI_EDATETIMEFORMATFLAGS_NUMDIGITS1               CONSTANT_UINT(0x0000)
#endif /* CLI_EDATETIMEFORMATFLAGS_NUMDIGITS1 */

#ifndef CLI_EDATETIMEFORMATFLAGS_NUMDIGITSTWO
    #define CLI_EDATETIMEFORMATFLAGS_NUMDIGITSTWO             CONSTANT_UINT(0x0001)
#endif /* CLI_EDATETIMEFORMATFLAGS_NUMDIGITSTWO */

#ifndef CLI_EDATETIMEFORMATFLAGS_NUMDIGITS2
    #define CLI_EDATETIMEFORMATFLAGS_NUMDIGITS2               CONSTANT_UINT(0x0001)
#endif /* CLI_EDATETIMEFORMATFLAGS_NUMDIGITS2 */

#ifndef CLI_EDATETIMEFORMATFLAGS_NUMDIGITSTHREE
    #define CLI_EDATETIMEFORMATFLAGS_NUMDIGITSTHREE           CONSTANT_UINT(0x0002)
#endif /* CLI_EDATETIMEFORMATFLAGS_NUMDIGITSTHREE */

#ifndef CLI_EDATETIMEFORMATFLAGS_NUMDIGITS3
    #define CLI_EDATETIMEFORMATFLAGS_NUMDIGITS3               CONSTANT_UINT(0x0002)
#endif /* CLI_EDATETIMEFORMATFLAGS_NUMDIGITS3 */

#ifndef CLI_EDATETIMEFORMATFLAGS_NUMDIGITSFOUR
    #define CLI_EDATETIMEFORMATFLAGS_NUMDIGITSFOUR            CONSTANT_UINT(0x0003)
#endif /* CLI_EDATETIMEFORMATFLAGS_NUMDIGITSFOUR */

#ifndef CLI_EDATETIMEFORMATFLAGS_NUMDIGITS4
    #define CLI_EDATETIMEFORMATFLAGS_NUMDIGITS4               CONSTANT_UINT(0x0003)
#endif /* CLI_EDATETIMEFORMATFLAGS_NUMDIGITS4 */

#ifndef CLI_EDATETIMEFORMATFLAGS_FENGLISH
    #define CLI_EDATETIMEFORMATFLAGS_FENGLISH                 CONSTANT_UINT(0x0010)
#endif /* CLI_EDATETIMEFORMATFLAGS_FENGLISH */

#ifndef CLI_EDATETIMEFORMATFLAGS_FLEADINGZERO
    #define CLI_EDATETIMEFORMATFLAGS_FLEADINGZERO             CONSTANT_UINT(0x0020)
#endif /* CLI_EDATETIMEFORMATFLAGS_FLEADINGZERO */

#ifndef CLI_EDATETIMEFORMATFLAGS_F12HOUR
    #define CLI_EDATETIMEFORMATFLAGS_F12HOUR  CONSTANT_UINT(0x0040)
#endif /* CLI_EDATETIMEFORMATFLAGS_F12HOUR */

#ifndef CLI_EDATETIMEFORMATFLAGS_FUPPER
    #define CLI_EDATETIMEFORMATFLAGS_FUPPER   CONSTANT_UINT(0x0040)
#endif /* CLI_EDATETIMEFORMATFLAGS_FUPPER */

#ifndef CLI_EDATETIMEFORMATFLAGS_FLOCALTIMEZONE
    #define CLI_EDATETIMEFORMATFLAGS_FLOCALTIMEZONE           CONSTANT_UINT(0x0040)
#endif /* CLI_EDATETIMEFORMATFLAGS_FLOCALTIMEZONE */

#ifndef CLI_EDATETIMEFORMATFLAGS_FSIGNFORCEENABLE
    #define CLI_EDATETIMEFORMATFLAGS_FSIGNFORCEENABLE         CONSTANT_UINT(0x0080)
#endif /* CLI_EDATETIMEFORMATFLAGS_FSIGNFORCEENABLE */

#ifndef CLI_EDATETIMEFORMATFLAGS_FSIGNFORCEDISABLE
    #define CLI_EDATETIMEFORMATFLAGS_FSIGNFORCEDISABLE        CONSTANT_UINT(0x0100)
#endif /* CLI_EDATETIMEFORMATFLAGS_FSIGNFORCEDISABLE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EDateTimeFormatFlags {
                const UINT partMask         = CONSTANT_UINT(0xFFF000);
                const UINT pYear            = CONSTANT_UINT(0x00001000);
                const UINT pMonth           = CONSTANT_UINT(0x00002000);
                const UINT pDayOfWeek       = CONSTANT_UINT(0x00003000);
                const UINT pDay             = CONSTANT_UINT(0x00004000);
                const UINT pHour            = CONSTANT_UINT(0x00005000);
                const UINT pMinute          = CONSTANT_UINT(0x00006000);
                const UINT pSecond          = CONSTANT_UINT(0x00007000);
                const UINT pMicrosec        = CONSTANT_UINT(0x00008000);
                const UINT pApIndicator     = CONSTANT_UINT(0x00009000);
                const UINT pGmOffset        = CONSTANT_UINT(0x0000A000);
                const UINT pWeek            = CONSTANT_UINT(0x0000B000);
                const UINT pSignPlus        = CONSTANT_UINT(0x0000C000);
                const UINT pSignMinus       = CONSTANT_UINT(0x0000D000);
                const UINT pSignIgnore      = CONSTANT_UINT(0x0000E000);
                const UINT pSignIgnoreStrong        = CONSTANT_UINT(0x0000F000);
                const UINT pSignDateSep     = CONSTANT_UINT(0x00010000);
                const UINT pSignTimeSep     = CONSTANT_UINT(0x00011000);
                const UINT pStartQuote      = CONSTANT_UINT(0x00012000);
                const UINT pEndQuote        = CONSTANT_UINT(0x00013000);
                const UINT maskNumDigits    = CONSTANT_UINT(0x000F);
                const UINT numDigitsOne     = CONSTANT_UINT(0x0000);
                const UINT numDigits1       = CONSTANT_UINT(0x0000);
                const UINT numDigitsTwo     = CONSTANT_UINT(0x0001);
                const UINT numDigits2       = CONSTANT_UINT(0x0001);
                const UINT numDigitsThree   = CONSTANT_UINT(0x0002);
                const UINT numDigits3       = CONSTANT_UINT(0x0002);
                const UINT numDigitsFour    = CONSTANT_UINT(0x0003);
                const UINT numDigits4       = CONSTANT_UINT(0x0003);
                const UINT fEnglish         = CONSTANT_UINT(0x0010);
                const UINT fLeadingZero     = CONSTANT_UINT(0x0020);
                const UINT f12hour          = CONSTANT_UINT(0x0040);
                const UINT fUpper           = CONSTANT_UINT(0x0040);
                const UINT fLocalTimezone   = CONSTANT_UINT(0x0040);
                const UINT fSignForceEnable = CONSTANT_UINT(0x0080);
                const UINT fSignForceDisable        = CONSTANT_UINT(0x0100);
        }; // namespace EDateTimeFormatFlags
    }; // namespace cli
    /* using namespace ::cli::EDateTimeFormatFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::CLISYSTEMTIME */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
    #define CLI_STRUCT_NAME                   CLISYSTEMTIME
    #ifndef STRUCT_CLI_CLISYSTEMTIME_PREDECLARED
    #define STRUCT_CLI_CLISYSTEMTIME_PREDECLARED
        struct CLISYSTEMTIME;
        #ifndef STRUCT_CLI_CLISYSTEMTIME
            #define STRUCT_CLI_CLISYSTEMTIME          ::cli::CLISYSTEMTIME
        #endif
    #endif // STRUCT_CLI_CLISYSTEMTIME_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_CLISYSTEMTIME
    #ifndef STRUCT_CLI_CLISYSTEMTIME_PREDECLARED
    #define STRUCT_CLI_CLISYSTEMTIME_PREDECLARED
        struct  tag_cli_CLISYSTEMTIME;
        typedef struct tag_cli_CLISYSTEMTIME cli_CLISYSTEMTIME;
        #ifndef STRUCT_CLI_CLISYSTEMTIME
            #define STRUCT_CLI_CLISYSTEMTIME          struct tag_cli_CLISYSTEMTIME
        #endif
    #endif // STRUCT_CLI_CLISYSTEMTIME_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef STRUCT_CLI_CLISYSTEMTIME_DEFINED
        #define STRUCT_CLI_CLISYSTEMTIME_DEFINED
        #include <cli/pshpack1.h>
        CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
            WORD                        year;
            WORD                        month;
            WORD                        dayOfWeek;
            WORD                        day;
            WORD                        hour;
            WORD                        minute;
            WORD                        second;
            DWORD                       microsec;
            SHORT                       gmOffset;
        CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
        #include <cli/poppack.h>
        #endif // STRUCT_CLI_CLISYSTEMTIME_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli
#endif

#endif /* CLI_DATETIMETYPES_H */
