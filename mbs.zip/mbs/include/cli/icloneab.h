#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_ICLONEAB_H
#define CLI_ICLONEAB_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/icloneab.h>", CLI_ICLONEAB_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_ICLONEAB_H
    #include <cli/icloneab.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iCloneable */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iCloneable;
        #ifndef INTERFACE_CLI_ICLONEABLE
            #define INTERFACE_CLI_ICLONEABLE          ::cli::iCloneable
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ICLONEABLE_PREDECLARED
    #define INTERFACE_CLI_ICLONEABLE_PREDECLARED
    typedef interface tag_cli_iCloneable     cli_iCloneable;
    #endif //INTERFACE_CLI_ICLONEABLE
    #ifndef INTERFACE_CLI_ICLONEABLE
        #define INTERFACE_CLI_ICLONEABLE          struct tag_cli_iCloneable
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ICLONEABLE_IID
    #define INTERFACE_CLI_ICLONEABLE_IID    "/cli/iCloneable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iCloneable
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ICLONEABLE
       #define INTERFACE_CLI_ICLONEABLE    ::cli::iCloneable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iCloneable
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ICLONEABLE
       #define INTERFACE_CLI_ICLONEABLE    cli_iCloneable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iCloneable methods */
            CLIMETHOD(cloneObject) (THIS_ INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iCloneable >
           {
            static char const * getName() { return INTERFACE_CLI_ICLONEABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iCloneable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iCloneable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iCloneable wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ICLONEABLE >
                                      */
                 >
        class CiCloneableWrapper
        {
            public:
        
                typedef  CiCloneableWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiCloneableWrapper() :
                   pif(0) {}
        
                CiCloneableWrapper( iCloneable *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiCloneableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiCloneableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiCloneableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiCloneableWrapper(const CiCloneableWrapper &i) :
                    pif(i.pif) { }
        
                ~CiCloneableWrapper()  { }
        
                CiCloneableWrapper& operator=(const CiCloneableWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE cloneObject( INTERFACE_CLI_ICLONEABLE**    pObjClone /* [out] ::cli::iCloneable* pObjClone  */)
                   {
                
                    return pif->cloneObject(pObjClone);
                   }
                

        
        
        }; // class CiCloneableWrapper
        
        typedef CiCloneableWrapper< ::cli::CCliPtr< INTERFACE_CLI_ICLONEABLE     > >  CiCloneable;
        typedef CiCloneableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICLONEABLE > >  CiCloneable_nrc; /* No ref counting for interface used */
        typedef CiCloneableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICLONEABLE > >  CiCloneable_tmp; /* for temporary usage, same as CiCloneable_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iConstructable */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iConstructable;
        #ifndef INTERFACE_CLI_ICONSTRUCTABLE
            #define INTERFACE_CLI_ICONSTRUCTABLE      ::cli::iConstructable
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ICONSTRUCTABLE_PREDECLARED
    #define INTERFACE_CLI_ICONSTRUCTABLE_PREDECLARED
    typedef interface tag_cli_iConstructable cli_iConstructable;
    #endif //INTERFACE_CLI_ICONSTRUCTABLE
    #ifndef INTERFACE_CLI_ICONSTRUCTABLE
        #define INTERFACE_CLI_ICONSTRUCTABLE      struct tag_cli_iConstructable
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ICONSTRUCTABLE_IID
    #define INTERFACE_CLI_ICONSTRUCTABLE_IID    "/cli/iConstructable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iConstructable
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ICONSTRUCTABLE
       #define INTERFACE_CLI_ICONSTRUCTABLE    ::cli::iConstructable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iConstructable
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ICONSTRUCTABLE
       #define INTERFACE_CLI_ICONSTRUCTABLE    cli_iConstructable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iConstructable methods */
            CLIMETHOD(constructObject) (THIS_ INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iConstructable >
           {
            static char const * getName() { return INTERFACE_CLI_ICONSTRUCTABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iConstructable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iConstructable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iConstructable wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ICONSTRUCTABLE >
                                      */
                 >
        class CiConstructableWrapper
        {
            public:
        
                typedef  CiConstructableWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiConstructableWrapper() :
                   pif(0) {}
        
                CiConstructableWrapper( iConstructable *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiConstructableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiConstructableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiConstructableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiConstructableWrapper(const CiConstructableWrapper &i) :
                    pif(i.pif) { }
        
                ~CiConstructableWrapper()  { }
        
                CiConstructableWrapper& operator=(const CiConstructableWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE constructObject( INTERFACE_CLI_ICONSTRUCTABLE**    pNewObj /* [out] ::cli::iConstructable* pNewObj  */)
                   {
                
                    return pif->constructObject(pNewObj);
                   }
                

        
        
        }; // class CiConstructableWrapper
        
        typedef CiConstructableWrapper< ::cli::CCliPtr< INTERFACE_CLI_ICONSTRUCTABLE     > >  CiConstructable;
        typedef CiConstructableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICONSTRUCTABLE > >  CiConstructable_nrc; /* No ref counting for interface used */
        typedef CiConstructableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICONSTRUCTABLE > >  CiConstructable_tmp; /* for temporary usage, same as CiConstructable_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iShareCloneable */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iShareCloneable;
        #ifndef INTERFACE_CLI_ISHARECLONEABLE
            #define INTERFACE_CLI_ISHARECLONEABLE     ::cli::iShareCloneable
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ISHARECLONEABLE_PREDECLARED
    #define INTERFACE_CLI_ISHARECLONEABLE_PREDECLARED
    typedef interface tag_cli_iShareCloneable                    cli_iShareCloneable;
    #endif //INTERFACE_CLI_ISHARECLONEABLE
    #ifndef INTERFACE_CLI_ISHARECLONEABLE
        #define INTERFACE_CLI_ISHARECLONEABLE     struct tag_cli_iShareCloneable
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISHARECLONEABLE_IID
    #define INTERFACE_CLI_ISHARECLONEABLE_IID    "/cli/iShareCloneable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iShareCloneable
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ISHARECLONEABLE
       #define INTERFACE_CLI_ISHARECLONEABLE    ::cli::iShareCloneable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iShareCloneable
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ISHARECLONEABLE
       #define INTERFACE_CLI_ISHARECLONEABLE    cli_iShareCloneable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iShareCloneable methods */
            CLIMETHOD(shareCloneObject) (THIS_ INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iShareCloneable* pObjClone  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iShareCloneable >
           {
            static char const * getName() { return INTERFACE_CLI_ISHARECLONEABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iShareCloneable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iShareCloneable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iShareCloneable wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ISHARECLONEABLE >
                                      */
                 >
        class CiShareCloneableWrapper
        {
            public:
        
                typedef  CiShareCloneableWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiShareCloneableWrapper() :
                   pif(0) {}
        
                CiShareCloneableWrapper( iShareCloneable *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiShareCloneableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiShareCloneableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiShareCloneableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiShareCloneableWrapper(const CiShareCloneableWrapper &i) :
                    pif(i.pif) { }
        
                ~CiShareCloneableWrapper()  { }
        
                CiShareCloneableWrapper& operator=(const CiShareCloneableWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE shareCloneObject( INTERFACE_CLI_ISHARECLONEABLE**    pObjClone /* [out] ::cli::iShareCloneable* pObjClone  */)
                   {
                
                    return pif->shareCloneObject(pObjClone);
                   }
                

        
        
        }; // class CiShareCloneableWrapper
        
        typedef CiShareCloneableWrapper< ::cli::CCliPtr< INTERFACE_CLI_ISHARECLONEABLE     > >  CiShareCloneable;
        typedef CiShareCloneableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISHARECLONEABLE > >  CiShareCloneable_nrc; /* No ref counting for interface used */
        typedef CiShareCloneableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISHARECLONEABLE > >  CiShareCloneable_tmp; /* for temporary usage, same as CiShareCloneable_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_ICLONEAB_H */
