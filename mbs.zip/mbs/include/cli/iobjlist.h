#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IOBJLIST_H
#define CLI_IOBJLIST_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/iobjlist.h>", CLI_IOBJLIST_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IOBJLIST_H
    #include <cli/iobjlist.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iObjectList */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iObjectList;
        #ifndef INTERFACE_CLI_IOBJECTLIST
            #define INTERFACE_CLI_IOBJECTLIST         ::cli::iObjectList
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IOBJECTLIST_PREDECLARED
    #define INTERFACE_CLI_IOBJECTLIST_PREDECLARED
    typedef interface tag_cli_iObjectList    cli_iObjectList;
    #endif //INTERFACE_CLI_IOBJECTLIST
    #ifndef INTERFACE_CLI_IOBJECTLIST
        #define INTERFACE_CLI_IOBJECTLIST         struct tag_cli_iObjectList
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IOBJECTLIST_IID
    #define INTERFACE_CLI_IOBJECTLIST_IID    "/cli/iObjectList"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iObjectList
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IOBJECTLIST
       #define INTERFACE_CLI_IOBJECTLIST    ::cli::iObjectList
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iObjectList
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IOBJECTLIST
       #define INTERFACE_CLI_IOBJECTLIST    cli_iObjectList
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iObjectList methods */
            CLIMETHOD(pushObject) (THIS_ INTERFACE_CLI_IUNKNOWN*    pObj /* [in] ::cli::iUnknown*  pObj  */) PURE;
            CLIMETHOD(insertObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */
                                         , INTERFACE_CLI_IUNKNOWN*    pObj /* [in] ::cli::iUnknown*  pObj  */
                                    ) PURE;
            CLIMETHOD(objectCountGet) (THIS_ SIZE_T*    _objectCount /* [out] size_t _objectCount  */) PURE;
            CLIMETHOD(getObjectCount) (THIS_ SIZE_T*    size /* [out] size_t size  */) PURE;
            CLIMETHOD(getObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */
                                      , INTERFACE_CLI_IUNKNOWN**    pObj /* [out] ::cli::iUnknown* pObj  */
                                 ) PURE;
            CLIMETHOD(removeObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */) PURE;
            CLIMETHOD(clearList) (THIS) PURE;
            CLIMETHOD(assignList) (THIS_ INTERFACE_CLI_IOBJECTLIST*    pObjList /* [in] ::cli::iObjectList*  pObjList  */) PURE;
            CLIMETHOD(appendList) (THIS_ INTERFACE_CLI_IOBJECTLIST*    pObjList /* [in] ::cli::iObjectList*  pObjList  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iObjectList >
           {
            static char const * getName() { return INTERFACE_CLI_IOBJECTLIST_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iObjectList* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iObjectList > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iObjectList wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IOBJECTLIST >
                                      */
                 >
        class CiObjectListWrapper
        {
            public:
        
                typedef  CiObjectListWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiObjectListWrapper() :
                   pif(0) {}
        
                CiObjectListWrapper( iObjectList *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiObjectListWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiObjectListWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiObjectListWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiObjectListWrapper(const CiObjectListWrapper &i) :
                    pif(i.pif) { }
        
                ~CiObjectListWrapper()  { }
        
                CiObjectListWrapper& operator=(const CiObjectListWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE pushObject( INTERFACE_CLI_IUNKNOWN*    pObj /* [in] ::cli::iUnknown*  pObj  */)
                   {
                
                    return pif->pushObject(pObj);
                   }
                
                RCODE insertObject( SIZE_T    pos /* [in] size_t  pos  */
                                  , INTERFACE_CLI_IUNKNOWN*    pObj /* [in] ::cli::iUnknown*  pObj  */
                                  )
                   {
                
                
                    return pif->insertObject(pos, pObj);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_objectCount( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = objectCountGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, objectCount );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE objectCountGet( SIZE_T*    _objectCount /* [out] size_t _objectCount  */)
                   {
                
                    return pif->objectCountGet(_objectCount);
                   }
                
                RCODE getObjectCount( SIZE_T*    size /* [out] size_t size  */)
                   {
                
                    return pif->getObjectCount(size);
                   }
                
                RCODE getObject( SIZE_T    pos /* [in] size_t  pos  */
                               , INTERFACE_CLI_IUNKNOWN**    pObj /* [out] ::cli::iUnknown* pObj  */
                               )
                   {
                
                
                    return pif->getObject(pos, pObj);
                   }
                
                RCODE removeObject( SIZE_T    pos /* [in] size_t  pos  */)
                   {
                
                    return pif->removeObject(pos);
                   }
                
                RCODE clearList( )
                   {
                    return pif->clearList();
                   }
                
                RCODE assignList( INTERFACE_CLI_IOBJECTLIST*    pObjList /* [in] ::cli::iObjectList*  pObjList  */)
                   {
                
                    return pif->assignList(pObjList);
                   }
                
                RCODE appendList( INTERFACE_CLI_IOBJECTLIST*    pObjList /* [in] ::cli::iObjectList*  pObjList  */)
                   {
                
                    return pif->appendList(pObjList);
                   }
                

        
        
        }; // class CiObjectListWrapper
        
        typedef CiObjectListWrapper< ::cli::CCliPtr< INTERFACE_CLI_IOBJECTLIST     > >  CiObjectList;
        typedef CiObjectListWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IOBJECTLIST > >  CiObjectList_nrc; /* No ref counting for interface used */
        typedef CiObjectListWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IOBJECTLIST > >  CiObjectList_tmp; /* for temporary usage, same as CiObjectList_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IOBJLIST_H */
