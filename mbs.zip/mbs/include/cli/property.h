#ifndef CLI_PROPERTY_H
#define CLI_PROPERTY_H

/* Add next lines to your C/C++ code
#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif
*/

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif


#if defined(CLI_PROPERTIES_NO_EXCEPTIONS)

    #define CLI_CHECK_GET_PROPERTY_RESULT(res)    CLIASSERT(RC_OK(res))
    #define CLI_CHECK_SET_PROPERTY_RESULT(res)    CLIASSERT(RC_OK(res))
    #define CLI_CHECK_PROPERTY_SIZE_RESULT(res)   CLIASSERT(RC_OK(res))
   
#else

    #define CLI_CHECK_GET_PROPERTY_RESULT(res)    CLI_THROW_IF_NOK(res)
    #define CLI_CHECK_SET_PROPERTY_RESULT(res)    CLI_THROW_IF_NOK(res)
    #define CLI_CHECK_PROPERTY_SIZE_RESULT(res)   CLI_THROW_IF_NOK(res)

#endif

/*
+ CLI_DECLARE_PROPERTY_RW
CLI_DECLARE_PROPERTY_RW_IDX1
CLI_DECLARE_PROPERTY_RW_IDX2
CLI_DECLARE_PROPERTY_RW_IDX3

+ CLI_DECLARE_PROPERTY_R
CLI_DECLARE_PROPERTY_R_IDX1
CLI_DECLARE_PROPERTY_R_IDX2
CLI_DECLARE_PROPERTY_R_IDX3

+ CLI_DECLARE_PROPERTY_W
CLI_DECLARE_PROPERTY_W_IDX1
CLI_DECLARE_PROPERTY_W_IDX2
CLI_DECLARE_PROPERTY_W_IDX3
*/

/*
Struct/class offsets
        int ofs = (int)&((Class*)0)->element;
[Vilhelm S. comments: Note that <stddef.h> provides an offsetof(type, field_name) macro, so you can leave the dirty work of abusing NULL pointers in perverted ways to your standard library implementor! (The typical implementation of it is as above, though...)]
*/


/* Original macro CONTAINING_RECORD from WinNT.h */
#if defined(_MSC_VER) || defined(DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND)
    #define CLI_CONTAINING_RECORD(address, type, field) ((type *)( \
                                                      (PCHAR)(address) - \
                                                      (ULONG_PTR)(&((type *)0)->field)))
#else
    #define CLI_CONTAINING_RECORD(address, type, field) ((type *)( \
                                                      1+(PCHAR)(address) - \
                                                      (ULONG_PTR)(&((type *)1)->field)))
#endif

#if defined(_MSC_VER) && !defined(CLI_DISABLE_MS_PROPERTY)

    // simple properties
    #define CLI_DECLARE_PROPERTY_RW(OWNERNAME, TYPE, NAME) \
                                    __declspec( property( get=get_##NAME, put=set_##NAME ) ) TYPE NAME
    #define CLI_DECLARE_PROPERTY_R(OWNERNAME, TYPE, NAME) \
                                    __declspec( property( get=get_##NAME ) ) TYPE NAME
    #define CLI_DECLARE_PROPERTY_W(OWNERNAME, TYPE, NAME) \
                                   __declspec( property( put=set_##NAME ) ) TYPE NAME

    // indexed properties

    #define CLI_DECLARE_PROPERTY_RW_IDX1(OWNERNAME, TYPE, NAME, IDX_T1) \
                                    __declspec( property( get=get_##NAME, put=set_##NAME ) ) TYPE NAME []
    #define CLI_DECLARE_PROPERTY_R_IDX1(OWNERNAME, TYPE, NAME, IDX_T1) \
                                    __declspec( property( get=get_##NAME ) ) TYPE NAME []
    #define CLI_DECLARE_PROPERTY_W_IDX1(OWNERNAME, TYPE, NAME, IDX_T1) \
                                   __declspec( property( put=set_##NAME ) ) TYPE NAME []

    #define CLI_DECLARE_PROPERTY_RW_IDX2(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2) \
                                    __declspec( property( get=get_##NAME, put=set_##NAME ) ) TYPE NAME [][]
    #define CLI_DECLARE_PROPERTY_R_IDX2(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2) \
                                    __declspec( property( get=get_##NAME ) ) TYPE NAME [][]
    #define CLI_DECLARE_PROPERTY_W_IDX2(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2) \
                                   __declspec( property( put=set_##NAME ) ) TYPE NAME [][]

    #define CLI_DECLARE_PROPERTY_RW_IDX3(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2, IDX_T3) \
                                    __declspec( property( get=get_##NAME, put=set_##NAME ) ) TYPE NAME [][][]
    #define CLI_DECLARE_PROPERTY_R_IDX3(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2, IDX_T3) \
                                    __declspec( property( get=get_##NAME ) ) TYPE NAME [][][]
    #define CLI_DECLARE_PROPERTY_W_IDX3(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2, IDX_T3) \
                                   __declspec( property( put=set_##NAME ) ) TYPE NAME [][][]

 
#else 

    #define CLI_DECLARE_PROPERTY_RW(OWNERNAME, TYPE, NAME)                   \
    struct propclass_##NAME {                                                \
        typedef TYPE property_type;                                          \
        DWORD dummy;                                                         \
        /*propclass_##NAME() : dummy() {}*/                                  \
        inline operator property_type() {                                    \
            return CLI_CONTAINING_RECORD(this, OWNERNAME, NAME)-> get_##NAME ();    \
        }                                                                    \
        inline void operator=(const property_type &src) {                    \
            CLI_CONTAINING_RECORD(this, OWNERNAME, NAME)-> set_##NAME (src); \
        }                                                                    \
        /*private:*/                                                             \
        /*explicit propclass_##NAME(const propclass_##NAME &src) {} */            \
        /*inline void operator=(const propclass_##NAME &src) {}     */           \
                                                                             \
    } NAME
    
    #define CLI_DECLARE_PROPERTY_R(OWNERNAME, TYPE, NAME)                    \
    struct propclass_##NAME {                                                \
        typedef TYPE property_type;                                          \
        DWORD dummy;                                                         \
        inline operator property_type() {                                    \
            return CLI_CONTAINING_RECORD(this, OWNERNAME, NAME)-> get_##NAME ();    \
        }                                                                    \
    } NAME
    
    #define CLI_DECLARE_PROPERTY_W(OWNERNAME, TYPE, NAME)                    \
    struct propclass_##NAME {                                                \
        typedef TYPE property_type;                                          \
        DWORD dummy;                                                         \
        inline void operator=(const property_type &src) {                    \
            CLI_CONTAINING_RECORD(this, OWNERNAME, NAME)-> set_##NAME (src); \
        }                                                                    \
        private:                                                             \
        inline void operator=(const propclass_##NAME &src) {}                \
    } NAME



    #define CLI_DECLARE_PROPERTY_RW_IDX1(OWNERNAME, TYPE, NAME, IDX_T1)                       \
    struct propclass_##NAME {                                                                 \
        typedef TYPE property_type;                                          \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        propclass_##NAME(OWNERNAME *p, const IDX_T1 &i1) : ptr(p), idx1(i1) {}                \
        inline operator property_type() {                                                     \
            return ptr -> get_##NAME (idx1);                                                  \
        }                                                                                     \
        inline void operator=(const property_type &src) {                                     \
            ptr -> set_##NAME (idx1, src);                                                    \
        }                                                                                     \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T1_##NAME {                                                        \
        DWORD dummy;                                                                          \
        inline propclass_##NAME operator[](const IDX_T1 &i1) { return propclass_##NAME(CLI_CONTAINING_RECORD(this, OWNERNAME, NAME), i1); } \
    } NAME




    #define CLI_DECLARE_PROPERTY_RW_IDX2(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2 )              \
    struct propclass_##NAME {                                                                 \
        typedef TYPE property_type;                                                           \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        IDX_T2  idx2;                                                                         \
        propclass_##NAME(OWNERNAME *p, const IDX_T1 &i1, const IDX_T2 &i2)                    \
           : ptr(p), idx1(i1), idx2(i2) {}                                                    \
                                                                                              \
        inline operator property_type() {                                                     \
            return ptr -> get_##NAME (idx1,idx2);                                             \
        }                                                                                     \
                                                                                              \
        inline void operator=(const property_type &src) {                                     \
            ptr -> set_##NAME (idx1, idx2, src);                                              \
        }                                                                                     \
                                                                                              \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T2_##NAME {                                                        \
        typedef TYPE property_type;                                                           \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        propclass_##IDX_T2_##NAME(OWNERNAME *p, const IDX_T1 &i1) : ptr(p), idx1(i1) {}       \
                                                                                              \
        inline propclass_##NAME operator[](const IDX_T2 &i2)                                  \
           {                                                                                  \
            return propclass_##NAME(ptr, idx1, i2);                                           \
           }                                                                                  \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T1_##NAME {                                                        \
        typedef TYPE property_type;                                                           \
        DWORD dummy;                                                                          \
        inline propclass_##IDX_T2_##NAME operator[](const IDX_T1 &i1)                         \
           {                                                                                  \
            return propclass_##IDX_T2_##NAME(CLI_CONTAINING_RECORD(this, OWNERNAME, NAME), i1);\
           }                                                                                  \
    } NAME

        
    #define CLI_DECLARE_PROPERTY_RW_IDX3(OWNERNAME, TYPE, NAME, idx1, idx2, idx3 )




    #define CLI_DECLARE_PROPERTY_R_IDX1(OWNERNAME, TYPE, NAME, IDX_T1)                        \
    struct propclass_##NAME {                                                                 \
        typedef TYPE property_type;                                                           \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        propclass_##NAME(OWNERNAME *p, const IDX_T1 &i1) : ptr(p), idx1(i1) {}                \
        inline operator property_type() {                                                              \
            return ptr -> get_##NAME (idx1);                                                  \
        }                                                                                     \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T1_##NAME {                                                        \
        DWORD dummy;                                                                          \
        inline propclass_##NAME operator[](const IDX_T1 &i1) { return propclass_##NAME(CLI_CONTAINING_RECORD(this, OWNERNAME, NAME), i1); } \
    } NAME;


    #define CLI_DECLARE_PROPERTY_W_IDX1(OWNERNAME, TYPE, NAME, IDX_T1)                        \
    struct propclass_##NAME {                                                                 \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        propclass_##NAME(OWNERNAME *p, const IDX_T1 &i1) : ptr(p), idx1(i1) {}                \
        inline void operator=(const TYPE &src) {                                              \
            ptr -> set_##NAME (idx1, src);                                                    \
        }                                                                                     \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T1_##NAME {                                                        \
        DWORD dummy;                                                                          \
        inline propclass_##NAME operator[](const IDX_T1 &i1) { return propclass_##NAME(CLI_CONTAINING_RECORD(this, OWNERNAME, NAME), i1); } \
    } NAME



    #define CLI_DECLARE_PROPERTY_R_IDX2(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2 )               \
    struct propclass_##NAME {                                                                 \
        typedef TYPE property_type;                                                           \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        IDX_T2  idx2;                                                                         \
        propclass_##NAME(OWNERNAME *p, const IDX_T1 &i1, const IDX_T2 &i2)                    \
           : ptr(p), idx1(i1), idx2(i2) {}                                                    \
                                                                                              \
        inline operator property_type() {                                                              \
            return ptr -> get_##NAME (idx1,idx2);                                             \
        }                                                                                     \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T2_##NAME {                                                        \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        propclass_##IDX_T2_##NAME(OWNERNAME *p, const IDX_T1 &i1) : ptr(p), idx1(i1) {}       \
                                                                                              \
        inline propclass_##NAME operator[](const IDX_T2 &i2)                                  \
           {                                                                                  \
            return propclass_##NAME(ptr, idx1, i2);                                           \
           }                                                                                  \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T1_##NAME {                                                        \
        DWORD dummy;                                                                          \
        inline propclass_##IDX_T2_##NAME operator[](const IDX_T1 &i1)                         \
           {                                                                                  \
            return propclass_##IDX_T2_##NAME(CLI_CONTAINING_RECORD(this, OWNERNAME, NAME), i1);\
           }                                                                                  \
    } NAME


    
    #define CLI_DECLARE_PROPERTY_R_IDX3(OWNERNAME, TYPE, NAME, idx1, idx2, idx3 )


    #define CLI_DECLARE_PROPERTY_W_IDX2(OWNERNAME, TYPE, NAME, IDX_T1, IDX_T2 )               \
    struct propclass_##NAME {                                                                 \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        IDX_T2  idx2;                                                                         \
        propclass_##NAME(OWNERNAME *p, const IDX_T1 &i1, const IDX_T2 &i2)                    \
           : ptr(p), idx1(i1), idx2(i2) {}                                                    \
                                                                                              \
        inline void operator=(const TYPE &src) {                                              \
            ptr -> set_##NAME (idx1, idx2, src);                                              \
        }                                                                                     \
                                                                                              \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T2_##NAME {                                                        \
        OWNERNAME *ptr;                                                                       \
        IDX_T1  idx1;                                                                         \
        propclass_##IDX_T2_##NAME(OWNERNAME *p, const IDX_T1 &i1) : ptr(p), idx1(i1) {}       \
                                                                                              \
        inline propclass_##NAME operator[](const IDX_T2 &i2)                                  \
           {                                                                                  \
            return propclass_##NAME(ptr, idx1, i2);                                           \
           }                                                                                  \
    };                                                                                        \
                                                                                              \
    struct propclass_##IDX_T1_##NAME {                                                        \
        DWORD dummy;                                                                          \
        inline propclass_##IDX_T2_##NAME operator[](const IDX_T1 &i1)                         \
           {                                                                                  \
            return propclass_##IDX_T2_##NAME(CLI_CONTAINING_RECORD(this, OWNERNAME, NAME), i1);\
           }                                                                                  \
    } NAME;                                                                                   \

    
    #define CLI_DECLARE_PROPERTY_W_IDX3(OWNERNAME, TYPE, NAME, idx1, idx2, idx3 )
    
    /*
    #define PROPERTY_DEF(OWNERNAME, TYPE, NAME) \
        PROPERTY(OWNERNAME, TYPE, NAME, Get_##NAME, Put_##NAME)
    */


#endif // MS Property

// not implemented yet


/*

#define PROPERTY(OWNERNAME, TYPE, NAME, FNGET, FNPUT) \
struct propclass_##NAME { \
    inline operator TYPE() { \
        CONTAINING_RECORD(this, OWNERNAME, NAME)->FNGET(); \
    } \
    inline void operator=(TYPE src) { \
        CONTAINING_RECORD(this, OWNERNAME, NAME)->FNPUT(src); \
    } \
} NAME;

#define PROPERTY_DEF(OWNERNAME, TYPE, NAME) \
    PROPERTY(OWNERNAME, TYPE, NAME, Get_##NAME, Put_##NAME)
 
*/


#endif /* PROPERTY_H */

