#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IUNKNOWN_H
#define CLI_IUNKNOWN_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/iunknown.h>", CLI_IUNKNOWN_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif
*/

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iUnknown */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifndef INTERFACE_CLI_IUNKNOWN_IID
    #define INTERFACE_CLI_IUNKNOWN_IID    "/cli/iUnknown"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iUnknown
    #ifndef INTERFACE_CLI_IUNKNOWN
       #define INTERFACE_CLI_IUNKNOWN    ::cli::iUnknown
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IUNKNOWN
       #define INTERFACE_CLI_IUNKNOWN    cli_iUnknown
    #endif
#endif

        CLI_DECLARE_INTERFACE(INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iUnknown >
           {
            static char const * getName() { return INTERFACE_CLI_IUNKNOWN_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iUnknown* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iUnknown > :: getName(); }
           };
    }; // namespace cli

    /* C++ wrapper generation disabled by 'cpp_option(interface, "no_wrapper")' in interface definition */
    /* To enable wrapper generation, remove "no_wrapper" option or add "need_wrapper" option after "no_wrapper" option */


#endif





#endif /* CLI_IUNKNOWN_H */
