#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLICMDLINE_H
#define CLI_CLICMDLINE_H


/* Add next lines to your C/C++ code
#ifndef CLI_CLICMDLINE_H
    #include <cli/clicmdline.h>
#endif
*/

#ifndef CLI_ARGLIST_H
    #include <cli/arglist.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_ICACHEMAN_H
    #include <cli/icacheman.h>
#endif

#ifndef CLI_GUITYPES_H
    #include <cli/guitypes.h>
#endif

#ifdef __cplusplus

    #if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
        #include <stdexcept>
    #endif
    
    #if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
        #include <map>
    #endif
    
    #if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
        #include <set>
    #endif
    
    #if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
        #include <vector>
    #endif
    
    #if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
        #include <iostream>
    #endif

    #if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
        #include <sstream>
    #endif

    #ifndef CLI_CLIUTILX_H
        #include <cli/cliutilx.h>
    #endif

    #ifndef MARTY_LIBAPI_H
        #include <marty/libapi.h>
    #endif

    #ifndef CLICMDLINE_NO_EXPANDRESPONSEFILEARGS_FUNCTION
    
        #ifndef MARTY_FILESYS_H
            #include <marty/filesys.h>
        #endif
    
        #ifndef MARTY_UTIL_H
            #include <marty/util.h>
        #endif
    
    #endif
#endif // __cpusplus

#ifndef CLI_GUITYPES_H
    #include <cli/guitypes.h>
#endif



// split single line into separate arguments
EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliSplitCommandLine( const WCHAR *cmdLine
                   , INTERFACE_CLI_IARGLIST** ppArgs
                   );

// note that cliComposeCommandLine releases pArgs
EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliComposeCommandLine( CLIPSTR *resStr
                     , INTERFACE_CLI_IARGLIST* pArgs
                     );



#ifdef __cplusplus

namespace cli{
namespace cmd_line{
// parse
// compose



inline
::std::string composeSingleArg( const ::std::string &argStr )
   {
    if (argStr.empty()) return ::std::string("\"\"");

    bool           needQuote = false;
    ::std::string  resStr;
    int            slashCnt = 0;

    ::std::string::size_type pos = 0, size = argStr.size();
    for(; pos!=size; ++pos)
       {
        char ch = argStr[pos];
        if (ch=='\\')
           {
            ++slashCnt;
            continue;
           }
        if (ch==' ' || ch=='\t')
           {
            if (slashCnt) { resStr.append(slashCnt,'\\'); slashCnt = 0; }
            resStr.append(1,ch);
            needQuote = true;
            continue;
           }
        if (ch=='\"')
           {
            if (slashCnt) { resStr.append(slashCnt*2,'\\'); slashCnt = 0; }
            resStr.append(1,'\\'); // make escaped
            resStr.append(1,ch);
            continue;
           }
        // something else
        if (slashCnt) { resStr.append(slashCnt,'\\'); slashCnt = 0; }
        resStr.append(1,ch);
       }

    if (slashCnt) 
       { 
        resStr.append( needQuote ? (slashCnt*2+1) : slashCnt , '\\' ); slashCnt = 0;
       }
    if (needQuote)
       {
        ::std::string tmpStr(1,'\"');
        tmpStr.append(resStr);
        tmpStr.append(1,'\"');
        return tmpStr;
       }
    return resStr;
   }

inline
::std::wstring composeSingleArg( const ::std::wstring &argStr )
   {
    if (argStr.empty()) return ::std::wstring(L"\"\"");

    bool           needQuote = false;
    ::std::wstring resStr;
    int            slashCnt = 0;

    ::std::wstring::size_type pos = 0, size = argStr.size();
    for(; pos!=size; ++pos)
       {
        wchar_t ch = argStr[pos];
        if (ch==L'\\')
           {
            ++slashCnt;
            continue;
           }
        if (ch==L' ' || ch==L'\t')
           {
            if (slashCnt) { resStr.append(slashCnt,L'\\'); slashCnt = 0; }
            resStr.append(1,ch);
            needQuote = true;
            continue;
           }
        if (ch==L'\"')
           {
            if (slashCnt) { resStr.append(slashCnt*2,L'\\'); slashCnt = 0; }
            resStr.append(1,L'\\'); // make escaped
            resStr.append(1,ch);
            continue;
           }
        // something else
        if (slashCnt) { resStr.append(slashCnt,L'\\'); slashCnt = 0; }
        resStr.append(1,ch);
       }

    if (slashCnt) 
       { 
        resStr.append( needQuote ? (slashCnt*2+1) : slashCnt , L'\\' ); slashCnt = 0;
       }
    if (needQuote)
       {
        ::std::wstring tmpStr(1,L'\"');
        tmpStr.append(resStr);
        tmpStr.append(1,L'\"');
        return tmpStr;
       }
    return resStr;
   }


inline
INTERFACE_CLI_IARGLIST* split( const ::std::wstring &cmdLine )
   {
    INTERFACE_CLI_IARGLIST* pArgsRes = 0;
    RCODE res = cliSplitCommandLine( cmdLine.c_str(), &pArgsRes );
    if (res)
       {
        if (pArgsRes) pArgsRes->release();
        return 0;
       }
    return pArgsRes;
   }

inline
::std::wstring compose( INTERFACE_CLI_IARGLIST* pArgs )
   {
    CLIPSTR resStr = 0;
    RCODE res = cliComposeCommandLine( &resStr, pArgs );

    ::std::wstring resStdStr;

    if (!resStr || res) return resStdStr;
    resStdStr.assign(clipstr_data(resStr), clipstr_size(resStr));
    clipstr_free(&resStr);
    return resStdStr;
   }

/*
struct CDoNothingConverter
{
    CWinAnsiConverter() {}
    ::std::wstring operator()( const ::std::wstring &str ) const
       { return str; }
    ::std::wstring operator()( const ::std::wstring &str ) const { return str; }
};
*/

#ifdef WIN32

struct CWinAnsiConverter
{
    CWinAnsiConverter() {}
    ::std::wstring operator()( const ::std::string &str ) const
       {
        return MARTY_CON::strToWide(str, CP_ACP );
       }
    ::std::wstring operator()( const ::std::wstring &str ) const { return str; }
};

struct CWinToAnsiConverter
{
    CWinToAnsiConverter() {}
    ::std::string operator()( const ::std::wstring &str ) const
       {
        return MARTY_CON::strToAnsi(str, CP_ACP );
       }
    ::std::string operator()( const ::std::string &str ) const { return str; }
};

struct CWinOemConverter
{
    CWinOemConverter() {}
    ::std::wstring operator()( const ::std::string &str ) const
       {
        return MARTY_CON::strToWide(str, CP_OEMCP );
       }
    ::std::wstring operator()( const ::std::wstring &str ) const { return str; }
};

struct CWinToOemConverter
{
    CWinToOemConverter() {}
    ::std::string operator()( const ::std::wstring &str ) const
       {
        return MARTY_CON::strToAnsi(str, CP_OEMCP );
       }
    ::std::string operator()( const ::std::string &str ) const { return str; }
};
#endif // WIN32

struct CUtf8Converter
{
    CUtf8Converter() {}
    ::std::wstring operator()( const ::std::string &str ) const
       {
        return MARTY_UTF::fromUtf8(str);
       }
    ::std::wstring operator()( const ::std::wstring &str ) const { return str; }
};

struct CToUtf8Converter
{
    CToUtf8Converter() {}
    ::std::string operator()( const ::std::wstring &str ) const
       {
        return MARTY_UTF::toUtf8(str);
       }
    ::std::string operator()( const ::std::string &str ) const { return str; }
};

#ifndef CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER
    #ifdef WIN32
        #define CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER    ::cli::cmd_line::CWinToAnsiConverter
    #else
        #define CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER    ::cli::cmd_line::CToUtf8Converter
    #endif
#endif // CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER

#ifndef CLICMDLINE_ANSI2WIDE_DEFAULT_CONVERTER
    #ifdef WIN32
        #define CLICMDLINE_ANSI2WIDE_DEFAULT_CONVERTER    ::cli::cmd_line::CWinAnsiConverter
    #else
        #define CLICMDLINE_ANSI2WIDE_DEFAULT_CONVERTER    ::cli::cmd_line::CUtf8Converter
    #endif
#endif // CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER

/*
struct CDoNothingConverter
{
    ::std::wstring operator()( const ::std::wstring &str )
       {
        return str;
       }
};
*/


//template <typename Something>
//const Something& deduce_helper( const Something &s) { return s; }

template < typename CharType
         , typename ConvertPred
         >
INTERFACE_CLI_IARGLIST* buildArgListFromMainArguments( int argc
                                                     , CharType * argv[]
                                                     , const ConvertPred &converter
                                                     )
   {
    INTERFACE_CLI_IARGLIST* pArgList = cliGetArgList();
    ::cli::CiArgList argList(pArgList);

    ::std::basic_string<CharType> executableFullName;
    MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, executableFullName);
    ::std::basic_string<CharType> executableFileName = MARTY_FILENAME::getFile(executableFullName);
    if (argc>0)
       {
        ::std::basic_string<CharType> argsExecutableName = argv[0];
        argsExecutableName = MARTY_FILENAME::prepareForCompare( argsExecutableName );
        executableFileName = MARTY_FILENAME::prepareForCompare( executableFileName );
        if (argsExecutableName.find(executableFileName)==argsExecutableName.npos)
           { // executable name not taken as argument
            // put it before all other args
            argList.putString( converter(executableFullName) );
           }
       }

    for(int i=0; i!=argc; ++i)
       {
        argList.putString( converter(argv[i]) );
       }
    return pArgList;
   }


template < typename CharType
         , typename ConvertPred
         >
INTERFACE_CLI_IARGLIST* buildArgListFromWinMainArguments( const CharType * cmdLine
                                                        , const ConvertPred &converter
                                                        )
   {
    INTERFACE_CLI_IARGLIST* pArgList = 0;
    ::std::wstring wideCmdLine = converter( cmdLine );
    if ( cliSplitCommandLine( wideCmdLine.c_str(), &pArgList ) )
       pArgList = cliGetArgList(); // make empty arglist

    ::std::wstring executableFullName;
    MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, executableFullName);
    ::std::wstring executableFileName = MARTY_FILENAME::getFile(executableFullName);
    //::std::wstring wideCmdLineTmp = wideCmdLine;
    executableFileName = MARTY_FILENAME::prepareForCompare( executableFileName );

    ::cli::CiArgList argList(pArgList);
    SIZE_T numArgs = argList.getCount();
    if (numArgs!=SIZE_T_NPOS)
       {
        if (!numArgs)
           argList.putString( executableFullName );
        else
           {
            ::std::wstring argsExecutableName;
            if (!argList.getString(0, argsExecutableName))
               { // getString OK
                argsExecutableName = MARTY_FILENAME::prepareForCompare( argsExecutableName );
                if (argsExecutableName.find(executableFileName)==argsExecutableName.npos)
                   { // no exe name in command line at all
                    ::std::wstring newCmdLine = composeSingleArg( executableFullName );
                    if (!newCmdLine.empty() && !wideCmdLine.empty())
                       newCmdLine.append(L" ");
                    if (!wideCmdLine.empty())
                       newCmdLine.append(wideCmdLine);
                    pArgList->release();
                    return buildArgListFromWinMainArguments( newCmdLine.c_str(), converter );
                   }
               }
           }
       }
/*
    if (wideCmdLineTmp.find(executableFileName)==wideCmdLineTmp.npos)
       { // executable name not taken in command line
        // put it before all other args
        ::cli::CiArgList argList(pArgList);
        argList.putString( executableFullName );
       }
*/
    return pArgList;
   }



// http://www.gnu.org/prep/standards/html_node/Command_002dLine-Interfaces.html#Command_002dLine-Interfaces
// http://www.gnu.org/prep/standards/html_node/Option-Table.html#Option-Table
// http://www.gnu.org/prep/standards/html_node/index.html

// http://www.opengroup.org/onlinepubs/009695399/basedefs/xbd_chap12.html
// http://www.opengroup.org/onlinepubs/009695399/basedefs/xbd_chap12.html#tag_12_02


#define CLI_GETOPT_CMDID(id)                                     ((wchar_t)(id))
#define CLI_GETOPT_FIRST_PRIVATE_CMDID                           CLI_GETOPT_CMDID(128)

#define CLI_GETOPT_IS_CMDID(ch)                                  ((ch)>=CLI_GETOPT_FIRST_PRIVATE_CMDID)
#define CLI_GETOPT_IS_IN_REGULAR_SHORTOPT_RANGE(ch, low, high)   ((ch)>=(low)) && ((ch)<=(high))
#define CLI_GETOPT_IS_REGULAR_SHORTOPT(ch)                       (( (CLI_GETOPT_IS_IN_REGULAR_SHORTOPT_RANGE(ch,L'0',L'9'))  \
                                                                  ||(CLI_GETOPT_IS_IN_REGULAR_SHORTOPT_RANGE(ch,L'A',L'Z'))  \
                                                                  ||(CLI_GETOPT_IS_IN_REGULAR_SHORTOPT_RANGE(ch,L'a',L'z')) \
                                                                  ))


#define CLI_GETOPT_FIRST_CMDID                                   (CLI_GETOPT_FIRST_PRIVATE_CMDID + 32)

// --where - prints path and executable name of programm
#define CLI_GETOPT_WHERE_CMDID                                   (CLI_GETOPT_FIRST_PRIVATE_CMDID + 1)
#define CLI_GETOPT_WHERE_IS_CMDID                                (CLI_GETOPT_FIRST_PRIVATE_CMDID + 1)
#define CLI_GETOPT_WHERE_IS_IT_CMDID                             (CLI_GETOPT_FIRST_PRIVATE_CMDID + 1)
#define CLI_GETOPT_BUILD_CACHE_CMDID                             (CLI_GETOPT_FIRST_PRIVATE_CMDID + 2)
#define CLI_GETOPT_BUILD_PLUGINS_CACHE_CMDID                     (CLI_GETOPT_FIRST_PRIVATE_CMDID + 2)
#define CLI_GETOPT_BUILD_COMPONENTS_CACHE_CMDID                  (CLI_GETOPT_FIRST_PRIVATE_CMDID + 2)
#define CLI_GETOPT_BUILD_COMPONENTS_CACHE_EX_CMDID               (CLI_GETOPT_FIRST_PRIVATE_CMDID + 3)

#define CLI_GETOPT_HELP_CMDID                                    L'h'
#define CLI_GETOPT_HELP_CMD                                      L"help"
#define CLI_GETOPT_HELP_CMD_INFO                                 L"print this help screen."

#define CLI_GETOPT_VERSION_CMDID                                 L'V'
#define CLI_GETOPT_VERSION_CMD                                   L"version"
#define CLI_GETOPT_VERSION_CMD_INFO                              L"print program version number."

#define CLI_GETOPT_WHERE_CMD                                     L"where"
#define CLI_GETOPT_WHERE_CMD_INFO                                L"print program path and executable file name."
#define CLI_GETOPT_WHERE_IS_CMD                                  L"where-is"
#define CLI_GETOPT_WHERE_IS_CMD_INFO                             L"same as '--where'."
#define CLI_GETOPT_WHERE_IS_IT_CMD                               L"where-is-it"
#define CLI_GETOPT_WHERE_IS_IT_CMD_INFO                          L"same as '--where'."

#define CLI_GETOPT_BUILD_CACHE_CMD                               L"build-cache"
#define CLI_GETOPT_BUILD_CACHE_CMD_INFO                          L"build plugins/components cache."

#define CLI_GETOPT_BUILD_PLUGINS_CACHE_CMD                       L"build-plugins-cache"
#define CLI_GETOPT_BUILD_PLUGINS_CACHE_CMD_INFO                  L"build plugins/components cache."

#define CLI_GETOPT_BUILD_COMPONENTS_CACHE_CMD                    L"build-components-cache"
#define CLI_GETOPT_BUILD_COMPONENTS_CACHE_CMD_INFO               L"build plugins/components cache."

#define CLI_GETOPT_BUILD_COMPONENTS_CACHE_EX_CMD                 L"build-components-cache-ex"
#define CLI_GETOPT_BUILD_COMPONENTS_CACHE_EX_CMD_INFO            L"build plugins/components cache."


const unsigned int optFlag           = 0;      // no argument, simple flag
const unsigned int optValueOptional  = 1;      // optional argument
const unsigned int optOptional       = 1;      // alias for optValueOptional
const unsigned int optValueRequired  = 2;      // required mandatory argument
const unsigned int optRequiredOption = 0x1000; // this option is required for program normal execution


struct COptDescription
{
    wchar_t          shortOpt;     // can't be 0
    const wchar_t   *longOpt;      // can be 0
    unsigned int     optFlags;     // opt*
    const wchar_t   *paramName;    // optional string with option parameter name
    const wchar_t   *description;

    ::std::wstring   getOptName() const
       {
        if (longOpt) return longOpt;
        return ::std::wstring(1,shortOpt);
       }
};


const unsigned int gfDontParseResponseFiles = 1; // don't perform arg substitution from @resnonse.ext files
const unsigned int gfDontSkipFirstArg       = 2; // don't skip first arg (program exe path/name), this means it is allready removed
const unsigned int gfDontPrintTryHelp       = 4;
const unsigned int gfAllowLongOptAliases    = 8;


struct CGetoptContext
{
    ::std::vector<COptDescription>        opts     ;
    ::std::map< wchar_t, size_t >         shortMap ;
    ::std::map< ::std::wstring, size_t >  longMap  ;
    ::std::ostream                        *pOs     ; // = 0 // don't print any messages
    ::std::ostream                        *pOsErr  ; // = 0 // don't print any messages
    //::std::string
    SIZE_T                                 valueIndex;

    ::std::wstring                        programName;
    ::std::wstring                        programInputsInfoString;
    ::std::wstring                        programDescription;
    ::std::wstring                        programVersionString;

    ::std::wstring                        curOptName; // currently processed option name

    ::std::string                         messageBoxCid;
    
    ENUM_CLI_GUI_DIALOGRESULT 
    tryShowMessageBox( WND_HANDLE parentWnd
                     , const ::std::wstring &caption
                     , const ::std::wstring &message
                     , ENUM_CLI_GUI_ERRORDIALOGFLAGS flags = CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION|CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON 
                     ) const
    {
     try{
         if (messageBoxCid.empty()) return CLI_GUI_DIALOGRESULT_FAILED;
         ::cli::gui::CiSimpleMessageBox msgBox( messageBoxCid.c_str() );
         ENUM_CLI_GUI_DIALOGRESULT res;
         if (msgBox.showModal( &res, parentWnd
                             , caption.empty() ? (const WCHAR*)0 : caption.data(), caption.size()
                             , message.empty() ? (const WCHAR*)0 : message.data(), message.size()
                             , flags
                             ) ) return CLI_GUI_DIALOGRESULT_FAILED;
         return res;
        }
     catch(...)
        {
         return CLI_GUI_DIALOGRESULT_FAILED;
        }
    }


    CGetoptContext() 
       : opts(), shortMap(), longMap(), pOs(0), pOsErr(0), valueIndex(0), programName(), programInputsInfoString(), programDescription(), programVersionString(), curOptName(), messageBoxCid(CLI_GUI_GENERIC_SIMPLE_MESSAGE_BOX_CID)
       {}
    CGetoptContext( const ::std::wstring &pn) 
       : opts(), shortMap(), longMap(), pOs(0), pOsErr(0), valueIndex(0), programName(pn), programInputsInfoString(), programDescription(), programVersionString(), curOptName(), messageBoxCid(CLI_GUI_GENERIC_SIMPLE_MESSAGE_BOX_CID)
       {}
    CGetoptContext( const ::std::wstring &pn, const ::std::wstring &piis) 
       : opts(), shortMap(), longMap(), pOs(0), pOsErr(0), valueIndex(0), programName(pn), programInputsInfoString(piis), programDescription(), programVersionString(), curOptName(), messageBoxCid(CLI_GUI_GENERIC_SIMPLE_MESSAGE_BOX_CID)
       {}
    CGetoptContext( const ::std::wstring &pn, const ::std::wstring &piis, const ::std::wstring &descr) 
       : opts(), shortMap(), longMap(), pOs(0), pOsErr(0), valueIndex(0), programName(pn), programInputsInfoString(piis), programDescription(descr), programVersionString(), curOptName(), messageBoxCid(CLI_GUI_GENERIC_SIMPLE_MESSAGE_BOX_CID)
       {}
    CGetoptContext( const ::std::wstring &pn, const ::std::wstring &piis, const ::std::wstring &descr, const ::std::wstring &verStr) 
       : opts(), shortMap(), longMap(), pOs(0), pOsErr(0), valueIndex(0), programName(pn), programInputsInfoString(piis), programDescription(descr), programVersionString(verStr), curOptName(), messageBoxCid(CLI_GUI_GENERIC_SIMPLE_MESSAGE_BOX_CID)
       {}
};







#ifndef CLICMDLINE_NO_EXPANDRESPONSEFILEARGS_FUNCTION

//expandResponseFiles

struct CIsLineFeedPred
{
    bool operator()(char ch) const { if (ch=='\n') return true; return false; }
    bool operator()(wchar_t ch) const { if (ch==L'\n') return true; return false; }
};


struct CFileReader
{
    bool operator()( const ::std::wstring& fileName, ::std::string &readedData ) const
       {
        MARTY_FILESYSTEM::CHFile hFile = MARTY_FILESYSTEM::openFile( fileName, MARTY_FILESYSTEM::o_rdonly, false);
        if (hFile==MARTY_FILESYSTEM::hInvalidHandle) return false;

        char buf[4096];
        for(int res = readFile(hFile, (void*)buf, (unsigned)sizeof(buf))
           ; res>0
           ; res = readFile(hFile, (void*)buf, (unsigned)sizeof(buf))
           )
           {
            readedData.append( buf, res );
           }
        return true;
       }
};
//MARTY_FILESYSTEM


template< typename FileReader, typename ConvertPred >
void expandResponseFileArgs( const CGetoptContext &ctx, ::cli::CiArgList &argList, const FileReader &reader, const ConvertPred &converter )
   {
    SIZE_T argNum = argList.getCount( );
    if (!argNum) return; // nothing to do

    //INTERFACE_CLI_IARGLIST* pArgList = cliGetArgList();
    //::cli::CiArgList argListTmp( cliGetArgList(), false );
    ::cli::CiArgList argListTmp( cliGetArgList(), true /* do not do addRef */ );
    

    bool stopProcessRespFiles = false;

    for(SIZE_T idx = 0; idx!=argNum; ++idx)
       {
        ::std::wstring str;
        argList.getString( idx, str );
        if (stopProcessRespFiles)
           {
            argListTmp.putString( str );
            continue;
           }
        if (str.empty())
           {
            argListTmp.putString( str );
            continue;
           }
        if (str==L"--")
           {
            argListTmp.putString( str );
            stopProcessRespFiles = true;
            continue;
           }
        if (str[0]!=L'@')
           {
            argListTmp.putString( str );
            continue;
           }

        // found response file
        ::std::string respFileData;
        ::std::wstring respFileName(str, 1, ::std::wstring::npos );
        if (!reader( respFileName, respFileData ))
           {
            ::std::wstring curWorkingDir;
            MARTY_FILESYSTEM::getCurrentDirectory(curWorkingDir);
            // EC_FILE_NOT_FOUND
            CLI_THROW_ARGS(EC_FILE_NOT_FOUND,  (::cli::format::arg( curWorkingDir /* ctx.programName */  ) % respFileName ) );
           }

        using namespace ::marty::util;

        ::std::vector< ::std::string > lines;
        ::marty::util::split( lines, respFileData, CIsLineFeedPred(), ::marty::util::token_compress_on );
        ::std::vector< ::std::string >::const_iterator lit = lines.begin();
        for(; lit!=lines.end(); ++lit)
           {
            ::std::string line = ::cli::util::trim_copy(*lit, ::cli::util::CIsSpace<char>() );
            if (line.empty() || line[0]=='#') continue;
            if (line.size()>=2 && line[0]=='\"' && line[line.size()-1]=='\"')
               {
                line.erase(line.size()-1, 1);
                line.erase(0, 1);
                argListTmp.putString( converter(line) );
               }
            else
               {
                INTERFACE_CLI_IARGLIST *pParsedLineArgList = ::cli::cmd_line::split( converter(line) );
                if (pParsedLineArgList)
                   {
                    argListTmp.putArgListAll(pParsedLineArgList);
                    pParsedLineArgList->release();
                   }
               }
            //argListTmp.putString( converter(line) );
           }
       }
    ::cli::ifdefs::swap(argList, argListTmp);
   }
//::cli::CiArgList &argList
//INTERFACE_CLI_IARGLIST*

#endif // CLICMDLINE_NO_EXPANDRESPONSEFILEARGS_FUNCTION
//cliGetArgList()








// last
inline
void getoptPrepareDescriptions( const COptDescription                 *optsPtr
                              , ::std::vector<COptDescription>        &opts
                              , ::std::map< wchar_t, size_t >         &shortMap
                              , ::std::map< ::std::wstring, size_t >  &longMap
                              , bool allowAliases = false
                              )
   {
    ::std::set<wchar_t> cmdidSet;
    while( optsPtr && (optsPtr->shortOpt || optsPtr->longOpt))
       {
        if ( (optsPtr->optFlags&optRequiredOption) && !(optsPtr->optFlags&optValueRequired) )
           {
            throw ::std::invalid_argument( "Flag optRequiredOption can be used only with optValueRequired flag, options with optional parameters can be only optional" );
           }

        bool shortOptIsId = CLI_GETOPT_IS_CMDID(optsPtr->shortOpt);
        if (!shortOptIsId)
           {
            if (!optsPtr->shortOpt)
               throw ::std::invalid_argument( "Short option symbol can't be equal to 0. Short option symbol must be a character in ranges '0'-'9', 'A'-'Z', 'a'-'z', or a numeric value greater than 127, threated as option ID" );
            if (!CLI_GETOPT_IS_REGULAR_SHORTOPT(optsPtr->shortOpt))
               throw ::std::invalid_argument( "Short option symbol must be a character in ranges '0'-'9', 'A'-'Z', 'a'-'z', or a numeric value greater than 127, threated as option ID" );
           }

        if (!allowAliases)
           {
            if ( shortOptIsId && cmdidSet.find(optsPtr->shortOpt)!=cmdidSet.end() )
               throw ::std::invalid_argument( "Duplicated CMDID short option, use gfAllowLongOptAliases flag" );
           }
        cmdidSet.insert(optsPtr->shortOpt);

        if (shortOptIsId && !optsPtr->longOpt)
           throw ::std::invalid_argument( "Long option name can't be null if CMDID given instead of short option symbol" );

           
        size_t curIdx = opts.size();
        opts.push_back( *optsPtr );
        if (optsPtr->shortOpt && !shortOptIsId)
            {
             if (shortMap.find(optsPtr->shortOpt)!=shortMap.end())
                {
                 throw ::std::invalid_argument( ( ::std::string("Duplicated short option char '" ) 
                                             + CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(1, optsPtr->shortOpt))
                                             + ::std::string("'" )
                                             ).c_str()
                                           );
                }
             shortMap[optsPtr->shortOpt] = curIdx;
            }
        if (optsPtr->longOpt)
           {
             if (longMap.find(optsPtr->longOpt)!=longMap.end())
                {
                 throw ::std::invalid_argument( ( ::std::string("Duplicated long option '" ) 
                                             + CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(optsPtr->longOpt))
                                             + ::std::string("'" )
                                             ).c_str()
                                           );
                }
            longMap[::std::wstring(optsPtr->longOpt)] = curIdx;
           }
        ++optsPtr;
       }
   }

inline
bool getoptPrepareArgList( ::cli::CiArgList                            &argList
                         , const ::std::vector<COptDescription>        &opts
                         , const ::std::map< wchar_t, size_t >         &shortMap
                         , const ::std::map< ::std::wstring, size_t >  &longMap
                         , ::std::wstring                              &invalidOptionStr
                         , wchar_t                                     &unknowOptChar // can be set to 0 if error in long option
                         )
   {
    bool             stopProcessOptions = false;
    //::cli::CiArgList argListTmp( cliGetArgList(), false );
    ::cli::CiArgList argListTmp( cliGetArgList(), true /* do not do addRef */ ); 
    SIZE_T           argNum = argList.getCount( );
    for(SIZE_T idx = 0; idx!=argNum; ++idx)
       {
        ::std::wstring argStr;
        argList.getString( idx, argStr );
        if (stopProcessOptions || argStr.empty())
           {
            argListTmp.putString( argStr );
            continue;
           }
        if (argStr==L"--")
           {
            stopProcessOptions = true;
            argListTmp.putString( argStr );
            continue;
           }
        //size_t strPos = 0;
        if (argStr[0]!=L'-')
           { // not an option
            argListTmp.putString( argStr );
            continue;
           }

        if (argStr.size()<2) // simple '-' found
           {
            invalidOptionStr = argStr;
            return false;
           }
        
        size_t pos = 1;
        size_t argSize = argStr.size();
        if (argStr[pos]!=L'-')
           { // short option found
            wchar_t optChar = argStr[pos];
            
            //const 
            ::std::map< wchar_t, size_t >::const_iterator shIt = shortMap.find( optChar );
            if (shIt==shortMap.end())
               {
                invalidOptionStr = argStr;
                unknowOptChar    = optChar;
                return false;
               }
            CLIASSERT( shIt->second < opts.size() );
            // found first option
            unsigned int optFlags = opts[shIt->second].optFlags & ~optRequiredOption;
            if ( optFlags==optFlag)
               { // first option works as flag without params
                 // make theese options separated in arglist
                 {
                  ::std::wstring tmp(1, L'-'); tmp.append(1,optChar);
                  argListTmp.putString( tmp ); argListTmp.putEmpty();
                 }
                ++pos;
                // iterate trough flags
                for(; pos!=argSize; ++pos)
                   {
                    optChar = argStr[pos];
                    ::std::map< wchar_t, size_t >::const_iterator shIt = shortMap.find( optChar );
                    //unsigned int 
                    if (shIt!=shortMap.end())
                       optFlags = opts[shIt->second].optFlags & ~optRequiredOption;
                    if (shIt==shortMap.end() || optFlags==optValueRequired)
                       { // unknown switch or option required mandatory parameter and can't be used in flags list
                        invalidOptionStr = argStr;
                        unknowOptChar    = optChar;
                        return false;
                       }
                    ::std::wstring tmp(1, L'-'); tmp.append(1,optChar);
                    argListTmp.putString( tmp ); argListTmp.putEmpty();
                   }
               }
            else
               { // option need optional or required parameter
                ++pos;
                // when reading response file the short option and its value
                // can be in a single line but separated by some spaces
                // unsigned int optFlags = opts[shIt->second].optFlags & ~optRequiredOption;
                while(pos!=argSize && argStr[pos]==L' ') ++pos; 
                if (pos==argSize)
                   { // end of option name
                    if ((idx+1)==argNum)
                       { // end of cmd line args encountered
                        if (optFlags==optValueRequired)
                           { // option required mandatory parameter and can't be used in flags list
                            invalidOptionStr = argStr;
                            unknowOptChar    = optChar;
                            return false;
                           }
                        // there is no optional parameter
                        ::std::wstring tmp(1, L'-'); tmp.append(1,optChar);
                        argListTmp.putString( tmp ); argListTmp.putEmpty();
                       }
                    else // argList has more data
                       { // get next arg text
                        ::std::wstring nextArgStr;
                        argList.getString( idx+1, nextArgStr );
                        if (nextArgStr==L"--" || nextArgStr.empty() || nextArgStr[0]==L'-')
                           { // next arg is next option
                            if (optFlags==optValueRequired)
                               { // option required mandatory parameter and can't be used in flags list
                                invalidOptionStr = argStr;
                                unknowOptChar    = optChar;
                                return false;
                               }
                            // there is no optional parameter
                            ::std::wstring tmp(1, L'-'); tmp.append(1,optChar);
                            argListTmp.putString( tmp ); argListTmp.putEmpty();
                           }
                        else
                           {
                            // put nextArg as param of current option
                            ::std::wstring tmp(1, L'-'); tmp.append(1,optChar);
                            argListTmp.putString( tmp ); argListTmp.putString(nextArgStr);
                            ++idx;
                           }
                       }                   
                   }
                else // opt param taken immediately
                   {
                    ::std::wstring tmp(1, L'-'); tmp.append(1,optChar);
                    argListTmp.putString( tmp ); argListTmp.putString( ::std::wstring(argStr, pos, argStr.npos) );
                   }
               }
           }
        else // long option
           {
            // can be two forms --opt=val | --opt val
            ++pos;
            size_t eqPos = argStr.find_first_of( L"= ", pos );
            if (eqPos==pos) // this can occur only for '--=' string, cause '--' string checked before
               { // error - param separator immediately folows --
                invalidOptionStr = argStr;
                unknowOptChar    = L'=';
                return false;
               }

            bool spaceFound = false;
            if (eqPos!=argStr.npos && argStr[eqPos]==L' ')
               { // space found
                // skip spaces (can occur in pesponse files)
                while(eqPos!=argSize && argStr[eqPos]==L' ') ++eqPos;
                // eqPos now points to first-non-space char
                // move it back to space char
                --eqPos;
                spaceFound = true;
               }

            if (eqPos!=argStr.npos && (eqPos+1)==argSize && !spaceFound)
               { // found '--option=' option, this is an error
                invalidOptionStr = argStr;
                unknowOptChar    = 0;
                return false;
               }

            ::std::wstring optName, optVal;
            if (eqPos==argStr.npos)
               { // there is no param in current argument
                optName = ::std::wstring( argStr, pos, eqPos );
               }
            else
               {
                optName = ::std::wstring( argStr, pos, eqPos-pos );
                optVal  = ::std::wstring( argStr, eqPos+1, argStr.npos );
               }

            ::std::map< ::std::wstring, size_t >::const_iterator lmIt = longMap.find(optName);
            if (lmIt==longMap.end())
               { // unknown long option
                invalidOptionStr = argStr;
                unknowOptChar    = 0;
                return false;
               }
            CLIASSERT( lmIt->second < opts.size() );

            unsigned int optFlags = opts[lmIt->second].optFlags & ~optRequiredOption;

            argListTmp.putString( ::std::wstring(2, L'-')+optName );

            if (optVal.empty() && optFlags==optValueRequired && (idx+1)==argNum)
               { // option required mandatory parameter
                invalidOptionStr = argStr;
                unknowOptChar    = 0;
                return false;
               }

            if (optVal.empty() && (optFlags==optValueRequired || optFlags==optValueOptional))
               {
                if ((idx+1)!=argNum)
                   {
                    ::std::wstring nextArgStr;
                    argList.getString( idx+1, nextArgStr );
                    if (nextArgStr==L"--" || nextArgStr.empty() || nextArgStr[0]==L'-')
                       { // next arg is next option
                        if (optFlags==optValueRequired)
                           { // option required mandatory parameter and can't be used in flags list
                            invalidOptionStr = argStr;
                            unknowOptChar    = 0;
                            return false;
                           }
                        // there is no optional parameter
                       }
                    else
                       {
                        optVal = nextArgStr;
                        ++idx;
                       }
                   }
               }

            if (optFlags==optFlag)
               {
                if (optVal.empty())
                   argListTmp.putEmpty();
                else
                   { // long option can't have args
                    invalidOptionStr = argStr;
                    unknowOptChar    = 0;
                    return false;
                   }
               }
            else if (optFlags==optValueRequired)
               {
                if (!optVal.empty())
                   argListTmp.putString(optVal);
                else
                   { // long option mast have args
                    invalidOptionStr = argStr;
                    unknowOptChar    = 0;
                    return false;
                   }
               }
            else // optional
               {
                if (optVal.empty())
                   argListTmp.putEmpty();
                else
                   argListTmp.putString(optVal);
               }
           }
       }
    ::cli::ifdefs::swap(argList, argListTmp);
    return true;
   }

// getopt: unrecognized option `--ewfd'
// Try `getopt --help' for more information.

inline
::std::wstring infoFormatHelper( const ::std::wstring &str, const ::std::wstring &indent, size_t firstIndentLen, size_t maxLen = 78)
   {
    //if (firstIndentLen+10)
    ::std::wstring res; res.reserve( 4*(str.size() + indent.size()) );
    size_t curLen = firstIndentLen;
    size_t pos = 0, size = str.size();
    for(; pos!=size; ++pos)
       {
        if (str[pos]==L'\n')
           {
            if ((pos+1)!=size)
               {
                res.append(1,L'\n'); 
                res.append(indent);
               }
            curLen = indent.size();
            continue;
           }

        // calc next word len
        size_t nextWordLen = 0;
        bool curIsSpace = !!(str[pos]==L' ' || str[pos]==L'\t');
        if (curIsSpace)
           {
            ::std::wstring::size_type nextSpacePos = str.find_first_of(L" \n\t", pos+1);
            if (nextSpacePos==str.npos)
               nextWordLen = size-(pos+1);
            else
               nextWordLen = nextSpacePos-(pos+1);
           }

        if (curIsSpace && (curLen+nextWordLen)>=maxLen)
           {
            res.append(1,L'\n'); 
            res.append(indent);
            curLen = indent.size();
            continue;
           }
        res.append(1,str[pos]);
        ++curLen;
       }
    return res;
   }


inline
void getoptPrintTryHelp( const ::std::wstring  &programName
                       //, ::std::ostream        &os
                       , ::std::wostream        &os
                       )
    {
     /*
     os<<"Try '";
     if (!programName.empty())
        os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(programName) <<" ";
     os<<"--help' for more information.\n";
     */
     os<<L"Try '";
     if (!programName.empty())
        os<< programName <<L" ";
     os<<L"--help' for more information.\n";
    }

inline
void getoptPrintUnrecognizedOptionMessage( const ::std::wstring  &invalidOptionStr
                                         , wchar_t                unknowOptChar // can be set to 0 if error in long option
                                         , const ::std::wstring  &programName
                                         //, ::std::ostream        &os
                                         , ::std::wostream        &os
                                         , bool                  bTryHelp = true
                                         )
    {
     #if !defined(CLICMDLINE_NO_ERRORMESSAGE_NOTHROW)
     RCODE code = unknowOptChar ? EC_COMMAND_LINE_BAD_OPTION_CHAR : EC_COMMAND_LINE_BAD_OPTION;
     if (bTryHelp) ++code;
     CLI_THROW_ARGS(code,  (::cli::format::arg( programName ) % invalidOptionStr % unknowOptChar) );
     #elif !defined(CLICMDLINE_NO_FORMATERRORMESSAGE)
     RCODE code = unknowOptChar ? EC_COMMAND_LINE_BAD_OPTION_CHAR : EC_COMMAND_LINE_BAD_OPTION;
     if (bTryHelp) ++code;
     ::std::wstring strMsg = ::cli::formatErrorMessage( 0, code
                                                      , 0 // locale
                                                      , 0 // FMF_ALLOW_ASCII_CTRL_CHARS // /* FMF_AUTO_APPEND_LF| */ FMF_IGNORE_FORMAT_LF
                                                      , ::cli::format::arg( programName )
                                                        % invalidOptionStr % unknowOptChar
                                                      );
     //os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(strMsg) <<"\n";
     os<< strMsg <<L"\n";
     #else
     if (!programName.empty())
        {
         //os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(programName)<<": ";
         os<< programName<<L": ";
        }

     if (unknowOptChar)
        {
         //os<<"Unrecognized option '"<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(1,unknowOptChar)) << "' in '" << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(invalidOptionStr) <<"' or option requres value to be taken.\n";
         os<<L"Unrecognized option '"<< ::std::wstring(1,unknowOptChar) << L"' in '" << invalidOptionStr <<L"' or option requres value to be taken.\n";
        }
     else
        {
         //os<<"Unrecognized option '" << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(invalidOptionStr) <<"' or option requres value to be taken.\n";
         os<<L"Unrecognized option '" << invalidOptionStr <<L"' or option requres value to be taken.\n";
        }
     if (bTryHelp) getoptPrintTryHelp( programName, os);
     #endif
    }

inline
RCODE getoptPrintInvalidOptionValueMessage( const ::std::wstring  &optionName
                                         , const ::std::wstring  &invalidValue
                                         , const ::std::wstring  &programName
                                         //, ::std::ostream        &os
                                         , ::std::wostream        &os
                                         , bool                  bTryHelp = true
                                         )
    {
     #if !defined(CLICMDLINE_NO_ERRORMESSAGE_NOTHROW)
     RCODE code = EC_COMMAND_LINE_BAD_OPTION_VALUE;
     if (bTryHelp) ++code;
     CLI_THROW_ARGS(code,  (::cli::format::arg( programName ) % invalidValue % (::std::wstring( (optionName.size()>1 ? 2 : 1), L'-') + optionName) ) );
     return code;
     #elif !defined(CLICMDLINE_NO_FORMATERRORMESSAGE)
     RCODE code = EC_COMMAND_LINE_BAD_OPTION_VALUE;
     if (bTryHelp) ++code;
     ::std::wstring strMsg = ::cli::formatErrorMessage( 0, code
                                                      , 0 // locale
                                                      , 0 // FMF_ALLOW_ASCII_CTRL_CHARS // /* FMF_AUTO_APPEND_LF| */ FMF_IGNORE_FORMAT_LF
                                                      , ::cli::format::arg( programName )
                                                        % invalidValue % (::std::wstring( (optionName.size()>1 ? 2 : 1), L'-' ) + optionName)
                                                      );
     //os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(strMsg) <<"\n";
     os<< strMsg <<L"\n";
     return code;
     #else
     if (!programName.empty())
        {
         //os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(programName)<<": ";
         os<< programName<<L": ";
        }

     //os<<"Invalid value '"<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(invalidValue)) 
     //  << "' in option '" << ::std::string( (optionName.size()>1 ? 2 : 1), '-' ) << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(optionName) <<"'.\n";

     // CLICMDLINE_ANSI2WIDE_DEFAULT_CONVERTER
     os<<L"Invalid value '"<< ::std::wstring(invalidValue) 
       << "' in option '" << ::std::wtring( (optionName.size()>1 ? 2 : 1), L'-' ) << optionName <<L"'.\n";
     if (bTryHelp) getoptPrintTryHelp( programName, os);
     return EC_COMMAND_LINE_BAD_OPTION_VALUE;
     #endif
    }

inline
RCODE getoptPrintInvalidOptionValueMessage( const wchar_t         *optionName
                                         , const ::std::wstring  &invalidValue
                                         , const ::std::wstring  &programName
                                         , ::std::wostream       &os
                                         , bool                  bTryHelp = true
                                         )
   {
    return getoptPrintInvalidOptionValueMessage( ::std::wstring(optionName), invalidValue, programName, os, bTryHelp );
   }


inline
void getoptPrintHelp( const ::std::vector<COptDescription>        &opts
                    , const ::std::map< wchar_t, size_t >         &shortMap
                    , const ::std::map< ::std::wstring, size_t >  &longMap
                    , const ::std::wstring                        &programName
                    , const ::std::wstring                        &optionalProgramInputString
                    , const ::std::wstring                        &programDescr
                    , const ::std::wstring                        &programVerStr
                    , ::std::wostream                             &os
                    , size_t                                      infoIndentLen = 28
                    , size_t                                      infoMaxWidth  = 78
                    )
   {
    if (!programVerStr.empty())
       {
        //os << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(programVerStr) << "\n";
        os << programVerStr << "\n";
       }

    if (!programDescr.empty())
       {
        //os << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()( infoFormatHelper( programDescr, ::std::wstring(), 0, infoMaxWidth ) ) << "\n";
        os << infoFormatHelper( programDescr, ::std::wstring(), 0, infoMaxWidth ) << L"\n";
       }

    if (programName.empty())
       {
        //os<<"Command arguments which can be used:";
        os<<L"Command arguments which can be used:";
       }
    else
       {
        //os<<"Usage: "<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(programName); // <<"";
        os<<L"Usage: "<< programName; // <<"";
       }

    ::std::vector< size_t > optOrder;
    optOrder.reserve( opts.size() );

    ::std::wstring flagsStr;
    ::std::map< wchar_t, size_t >::const_iterator shIt = shortMap.begin();
    // 1. we print all short flags in single command line argument
    for(; shIt!=shortMap.end(); ++shIt)
       {
        CLIASSERT( shIt->second < opts.size() );
        if (opts[shIt->second].optFlags==optFlag) 
           {
            flagsStr.append(1,shIt->first);
            optOrder.push_back(shIt->second); // put index into order array
           }
       }

    if (!flagsStr.empty())
       {
        //os<<" [-"<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(flagsStr)<<"]";
        os<<L" [-"<< flagsStr<<L"]";
       }

    // 2. we print all short options
    //::std::map< wchar_t, size_t >::const_iterator 
    shIt = shortMap.begin();
    for(; shIt!=shortMap.end(); ++shIt)
       {
        CLIASSERT( shIt->second < opts.size() );
        if (opts[shIt->second].optFlags==optFlag) continue;
        optOrder.push_back(shIt->second); // put index into order array
        unsigned int optAllFlags = opts[shIt->second].optFlags;
        unsigned int optFlags    = optAllFlags & ~optRequiredOption;

        if (!(optAllFlags&optRequiredOption)) os<<" [";
        else                                  os<<" ";

        //os<<"-"<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(1,shIt->first));
        os<<L"-"<< ::std::wstring(1,shIt->first);

        if (optFlags==optValueOptional)       os<<L" ["; // os<<" [";
        else                                  os<<L" ";  // os<<" ";

        if (opts[shIt->second].paramName)
           {
            //os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(opts[shIt->second].paramName));
            os<< ::std::wstring(opts[shIt->second].paramName);
           }
        else
           {
            //os<<"value";
            os<<L"value";
           }

        if (optFlags==optValueOptional)        os<<L"]"; // os<<"]";
        if (!(optAllFlags&optRequiredOption))  os<<L"]"; // os<<"]";
       }

    size_t longOptNameLenMax = 0;

    ::std::map< ::std::wstring, size_t >::const_iterator lmIt = longMap.begin();
    for(; lmIt!=longMap.end(); ++lmIt)
       {
        CLIASSERT( lmIt->second < opts.size() );
        if (CLI_GETOPT_IS_REGULAR_SHORTOPT(opts[lmIt->second].shortOpt)) continue;
        if (opts[lmIt->second].optFlags!=optFlag) continue;

        optOrder.push_back(lmIt->second); // put index into order array
        //os<<" [--"
        //  << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(lmIt->first)
        //  <<"]";
        os<<L" [--"
          << lmIt->first
          <<L"]";
       }

    lmIt = longMap.begin();
    for(; lmIt!=longMap.end(); ++lmIt)
       {
        CLIASSERT( lmIt->second < opts.size() );
        if (longOptNameLenMax<lmIt->first.size()) longOptNameLenMax = lmIt->first.size();
        if (CLI_GETOPT_IS_REGULAR_SHORTOPT(opts[lmIt->second].shortOpt)) continue;
        if (opts[lmIt->second].optFlags==optFlag) continue;
        optOrder.push_back(lmIt->second); // put index into order array

        unsigned int optAllFlags = opts[lmIt->second].optFlags;
        unsigned int optFlags    = optAllFlags & ~optRequiredOption;

        if (!(optAllFlags&optRequiredOption)) os<<L" ["; // os<<" [";
        else                                  os<<L" ";  // os<<" ";

        //os<<"--"<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(lmIt->first);
        os<<L"--"<< lmIt->first;

        if (optFlags==optValueOptional)       os<<L"[="; // os<<"[=";
        else                                  os<<L"=";  // os<<"=";

        if (opts[lmIt->second].paramName)
           {
            //os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(opts[lmIt->second].paramName));
            os<< ::std::wstring(opts[lmIt->second].paramName);
           }
        else
           {
            //os<<"value";
            os<<L"value";
           }

        if (optFlags==optValueOptional)        os<<L"]"; // os<<"]";
        if (!(optAllFlags&optRequiredOption))  os<<L"]"; // os<<"]";
       }

    if (!optionalProgramInputString.empty())
       {
        //os<<" "<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(optionalProgramInputString);
        os<<L" "<< optionalProgramInputString;
       }
    //os<<"\n";
    os<<L"\n";

    // -C,_  - optional short name
    // --    - long option prefix
    //  *    - required param marker
    longOptNameLenMax += 10; 
    //if (longOptNameLenMax>32) longOptNameLenMax = 32;

    if (infoIndentLen>=infoMaxWidth)
       infoIndentLen = 4;
    if (infoMaxWidth<38) infoMaxWidth = 38;

    if ( longOptNameLenMax > infoIndentLen )       longOptNameLenMax = infoIndentLen;
    if ( infoIndentLen+2     > longOptNameLenMax ) infoIndentLen = longOptNameLenMax+2;

    bool hasRequreds = false;

    ::std::vector< size_t >::const_iterator ordIt = optOrder.begin();
    for(; ordIt!=optOrder.end(); ++ordIt)
       {
        size_t optIdx = *ordIt;
        CLIASSERT( optIdx < opts.size() );
        //::std::string optStr;
        ::std::wstring optStr;

        //::std::string paramName;
        ::std::wstring paramName;
        if (opts[optIdx].paramName)
           {
            //paramName = CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(opts[optIdx].paramName);
            paramName = opts[optIdx].paramName;
           }
        else
           {
            paramName = L"value";
           }

        bool valuePrinted = false;

        if (CLI_GETOPT_IS_REGULAR_SHORTOPT(opts[optIdx].shortOpt))
           {
            //optStr.append(1,'-');
            //optStr.append( CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(1, opts[optIdx].shortOpt)) );
            optStr.append(1,L'-');
            optStr.append( ::std::wstring(1, opts[optIdx].shortOpt) );

            if (!opts[optIdx].longOpt)
               { // no long option
                if (opts[optIdx].optFlags&(optValueOptional|optValueRequired))
                   { // need to print param name
                    if (opts[optIdx].optFlags&(optValueOptional))  optStr.append(L" ["); // optStr.append(" [");
                    else                                           optStr.append(L" ");  // optStr.append(" "); 
                    optStr.append(paramName);
                    if (opts[optIdx].optFlags&(optValueOptional))  optStr.append(L"]");  // optStr.append("]");
                    valuePrinted = true;
                   }
               }
           }

        //optStr.append(1,'');
        if (opts[optIdx].longOpt)
           {
            if (!optStr.empty()) optStr.append(L", "); // optStr.append(", ");
            //optStr.append("--");
            //optStr.append(CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(::std::wstring(opts[optIdx].longOpt)) );
            optStr.append(L"--");
            optStr.append(::std::wstring(opts[optIdx].longOpt) );

            if (!valuePrinted)
               { // no long option
                if (opts[optIdx].optFlags&(optValueOptional|optValueRequired))
                   { // need to print param name
                    if (opts[optIdx].optFlags&(optValueOptional))  optStr.append(L" ["); // optStr.append(" [");
                    else                                           optStr.append(L" ");  // optStr.append(" "); 
                    optStr.append(paramName);                                                                  
                    if (opts[optIdx].optFlags&(optValueOptional))  optStr.append(L"]");  // optStr.append("]"); 
                   }
               }
           }

        if (optStr.size()<(longOptNameLenMax-0)) optStr.append( (longOptNameLenMax-0)-optStr.size(), L' '); // optStr.append( (longOptNameLenMax-0)-optStr.size(), ' ');
        else optStr.append(1, L' '); // optStr.append(1, ' ');

        if (opts[optIdx].optFlags&optRequiredOption)
           {
            hasRequreds = true;
            //optStr.append("* ");
            optStr.append(L"* ");
           }
        else
           optStr.append(L"  "); // optStr.append("  ");



        os<<optStr;
        if ( opts[optIdx].description )
           {
            //os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()( infoFormatHelper( opts[optIdx].description, ::std::wstring(infoIndentLen, L' '), optStr.size(), infoMaxWidth) );
            os<< infoFormatHelper( opts[optIdx].description, ::std::wstring(infoIndentLen, L' '), optStr.size(), infoMaxWidth);
           }
        else
           {
            //os<<"No description.";
            os<<L"No description.";
           }
        //os<<"\n";
        os<<L"\n";
       }

    if (hasRequreds)
       {
        //os<<" Note: * - required arguments.\n";
        os<<L" Note: * - required arguments.\n";
       }
   }

/*
inline
void getoptPrintHelp( const ::std::vector<COptDescription>        &opts
                    , const ::std::map< wchar_t, size_t >         &shortMap
                    , const ::std::map< ::std::wstring, size_t >  &longMap
                    , const ::std::wstring                        &programName
                    , const ::std::wstring                        &optionalProgramInputString
                    , const ::std::wstring                        &programDescr
                    , const ::std::wstring                        &programVerStr
                    , ::std::ostream                              &os
                    , size_t                                      infoIndentLen = 28
                    , size_t                                      infoMaxWidth  = 78
                    )
{
    std::wstringstream ws;
    getoptPrintHelp( opts, shortMap, longMap, programName, optionalProgramInputString, programDescr, programVerStr, ws, infoIndentLen, infoMaxWidth );
    os<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(ws.str());
}
*/

inline
void getoptPrepareDescriptions( const COptDescription                 *optsPtr
                              , CGetoptContext                        &context
                              , bool                                   allowAliases = false
                              )
   {
    getoptPrepareDescriptions(optsPtr, context.opts, context.shortMap, context.longMap, allowAliases );
   }

inline
bool getoptPrepareArgList( ::cli::CiArgList                            &argList
                         , const CGetoptContext                        &context
                         , ::std::wstring                              &invalidOptionStr
                         , wchar_t                                     &unknowOptChar // can be set to 0 if error in long option
                         )
   {
    return getoptPrepareArgList( argList, context.opts, context.shortMap, context.longMap, invalidOptionStr, unknowOptChar);
   }

inline
void getoptPrintUnrecognizedOptionMessage( const CGetoptContext  &context
                                         , const ::std::wstring  &invalidOptionStr
                                         , wchar_t                unknowOptChar // can be set to 0 if error in long option
                                         , bool                  bTryHelp = true
                                         )
   {
    std::wstringstream ws;
    getoptPrintUnrecognizedOptionMessage( invalidOptionStr, unknowOptChar, context.programName, ws, bTryHelp );
    if (context.pOsErr)
       {
        *context.pOsErr << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(ws.str());
       }
    else
       {
        context.tryShowMessageBox( (WND_HANDLE)0, context.programName, ws.str(), CLI_GUI_ERRORDIALOGFLAGS_ICONERROR|CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON );
       }
    //getoptPrintUnrecognizedOptionMessage( invalidOptionStr, unknowOptChar, context.programName, os, bTryHelp );
   }

inline
RCODE getoptPrintInvalidOptionValueMessage( const ::std::wstring  &optionName
                                         , const ::std::wstring  &invalidValue
                                         , const CGetoptContext  &context
                                         , bool                  bTryHelp = true
                                         )
   {
    std::wstringstream ws;
    RCODE res = getoptPrintInvalidOptionValueMessage( optionName, invalidValue, context.programName, ws, bTryHelp );
    if (context.pOsErr)
       {
        *context.pOsErr << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(ws.str());
       }
    else
       {
        context.tryShowMessageBox( (WND_HANDLE)0, context.programName, ws.str(), CLI_GUI_ERRORDIALOGFLAGS_ICONERROR|CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON );
       }
    return res;
   }

inline
RCODE getoptPrintInvalidOptionValueMessage( const wchar_t         *optionName
                                         , const ::std::wstring  &invalidValue
                                         , const CGetoptContext  &context
                                         , bool                  bTryHelp = true
                                         )
   {
    return getoptPrintInvalidOptionValueMessage( ::std::wstring(optionName), invalidValue, context, bTryHelp );
   }


inline
void getoptPrintHelp( const CGetoptContext                        &context
                    //, ::std::ostream                              &os
                    , bool                                        useErrStream = false
                    , size_t                                      infoIndentLen = 28
                    , size_t                                      infoMaxWidth  = 78
                    )
   {
    std::wstringstream ws;
    getoptPrintHelp( context.opts, context.shortMap, context.longMap
                   , context.programName, context.programInputsInfoString
                   , context.programDescription, context.programVersionString
                   , ws, infoIndentLen, infoMaxWidth
                   );

    ::std::ostream *pStream = useErrStream ? context.pOsErr : context.pOs;
    if (pStream)
       {
        *pStream << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(ws.str());
       }
    else
       {
        ENUM_CLI_GUI_ERRORDIALOGFLAGS flags = CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON;
        if (useErrStream) flags |= CLI_GUI_ERRORDIALOGFLAGS_ICONERROR;
        else              flags |= CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION;
        context.tryShowMessageBox( (WND_HANDLE)0, context.programName, ws.str(), flags );
       }
   }

inline
void getoptPrintTryHelp( const CGetoptContext  &context
                       , bool                                        useErrStream = false
                       //, ::std::ostream        &os
                       )
   {
    std::wstringstream ws;
    getoptPrintTryHelp(context.programName, ws);
    ::std::ostream *pStream = useErrStream ? context.pOsErr : context.pOs;
    if (pStream)
       {
        *pStream << CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(ws.str());
       }
    else
       {
        ENUM_CLI_GUI_ERRORDIALOGFLAGS flags = CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON;
        if (useErrStream) flags |= CLI_GUI_ERRORDIALOGFLAGS_ICONERROR;
        else              flags |= CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION;
        context.tryShowMessageBox( (WND_HANDLE)0, context.programName, ws.str(), flags );
       }
   }

/*
inline
void getoptPrintHelp( const CGetoptContext                        &context
                    , ::std::wostream                             &os
                    , size_t                                      infoIndentLen = 28
                    , size_t                                      infoMaxWidth  = 78
                    )
   {
    getoptPrintHelp( context.opts, context.shortMap, context.longMap
                   , context.programName, context.programInputsInfoString
                   , context.programDescription, context.programVersionString
                   , os, infoIndentLen, infoMaxWidth
                   );
   }

inline
void getoptPrintTryHelp( const CGetoptContext  &context
                       , ::std::wostream       &os
                       )
   {
    getoptPrintTryHelp(context.programName, os);
   }
*/

/*
inline
void getoptPrintUnrecognizedOptionMessage( const CGetoptContext  &context
                                         , const ::std::wstring  &invalidOptionStr
                                         , wchar_t                unknowOptChar // can be set to 0 if error in long option
                                         , bool                  bTryHelp = true
                                         )
   {
    if (context.pOsErr)
       getoptPrintUnrecognizedOptionMessage( invalidOptionStr, unknowOptChar, context.programName, *context.pOsErr, bTryHelp );
    else
       {
        std::ostringstream os;
        getoptPrintUnrecognizedOptionMessage( invalidOptionStr, unknowOptChar, context.programName, os, bTryHelp );
       }

    getoptPrintUnrecognizedOptionMessage( invalidOptionStr, unknowOptChar, context.programName, os, bTryHelp );
   }
*/


template < typename GetoptHandler >
RCODE getoptParse( ::cli::CiArgList        &a_argList
                , const COptDescription   *optsPtr
                , const CGetoptContext    &_ctx
                , const GetoptHandler     &handler
                , unsigned int            flags
                )
   {
    CGetoptContext ctx = _ctx;
    RCODE optRes = EC_OK;
    //::cli::CiArgList argList( cliGetArgList(), false );
    ::cli::CiArgList argList( cliGetArgList(), true /* do not do addRef */ );
    // make copy af original arglist
      {
       SIZE_T argNum = a_argList.getCount( );
       if (!argNum) 
          {
           //return true; // absolutely nothing to do
           return EC_OK;
          }

       SIZE_T i = 0;
       if (!(flags&gfDontSkipFirstArg)) ++i; // skip program path/name
       
       for(; i!=argNum; ++i)
          {
           ::std::wstring str;
           a_argList.getString( i, str );
           argList.putString( str );
          }
      }

    #ifndef CLICMDLINE_NO_EXPANDRESPONSEFILEARGS_FUNCTION
    if (!(flags&gfDontParseResponseFiles))
       { // expand response files
        expandResponseFileArgs( ctx, argList, ::cli::cmd_line::CFileReader(), CLICMDLINE_ANSI2WIDE_DEFAULT_CONVERTER() );
       }
    #endif

    getoptPrepareDescriptions( optsPtr, ctx, !!(flags&gfAllowLongOptAliases) );

    ::std::wstring   invalidOptionStr;
    wchar_t          unknowOptChar;
    if (!getoptPrepareArgList( argList, ctx, invalidOptionStr, unknowOptChar ))
       {
        if (ctx.pOsErr)
           {
            getoptPrintUnrecognizedOptionMessage( ctx, invalidOptionStr, unknowOptChar, !(flags&gfDontPrintTryHelp) );
            //return false;
            return EC_COMMAND_LINE_PARSING_STOPPED;
           }
        //return getoptPrepareArgList( argList, context.opts, context.shortMap, context.longMap, invalidOptionStr, unknowOptChar);
       }

    bool endOfOptions = false;
    SIZE_T argNum = argList.getCount( );
    for(SIZE_T argIdx=0; argIdx!=argNum; ++argIdx)
       {
        if (endOfOptions)
           {
            ctx.curOptName.clear(); // getOptName()
            ctx.valueIndex = argIdx;
            optRes = handler( ctx, 0, 0, argList );
            //if (RC_FAIL(optRes)) return optRes;
            if (optRes!=EC_OK)   return optRes;
           }
        else
           {
            std::wstring optStr;
            argList.getString( argIdx, optStr );
            if (optStr.empty() || optStr[0]!=L'-')
               {
                ctx.valueIndex = argIdx;
                ctx.curOptName.clear(); // getOptName()
                optRes = handler( ctx, 0, 0, argList );
                //if (RC_FAIL(optRes)) return optRes;
                if (optRes!=EC_OK)   return optRes;
                continue; // input filename or other value
               }

            if (optStr==L"--")
               {
                endOfOptions = true;
               }
            else
               {
                SIZE_T optDescrIdx = 0;

                if (optStr.size()>=2 && optStr[1]==L'-')
                   { // long option
                    ::std::map< ::std::wstring, size_t >::const_iterator lmIt = ctx.longMap.find( ::std::wstring( optStr, 2, optStr.npos ) );
                    if (lmIt==ctx.longMap.end()) return EC_COMMAND_LINE_PARSING_STOPPED; // false; // normally never occurs
                    optDescrIdx = lmIt->second;
                   }
                else // short option
                   {
                    ::std::map< wchar_t, size_t >::const_iterator shIt = ctx.shortMap.find(optStr[1]);
                    if (shIt==ctx.shortMap.end()) return EC_COMMAND_LINE_PARSING_STOPPED; // false; // normally never occurs
                    optDescrIdx = shIt->second;
                   }

                CLIASSERT( optDescrIdx < ctx.opts.size() );

                ctx.valueIndex = argIdx+1;
                if (ctx.valueIndex==argNum)
                   ctx.valueIndex = SIZE_T_NPOS;
                else
                   ++argIdx;

                ctx.curOptName = ctx.opts[optDescrIdx].getOptName(); // getOptName()
                //ctx.valueIndex = argIdx;
                optRes = handler( ctx, ctx.opts[optDescrIdx].shortOpt, &ctx.opts[optDescrIdx], argList );
                //if (RC_FAIL(optRes)) return optRes;
                if (optRes!=EC_OK)   return optRes;
               }
           }
       }
    return EC_OK;
   }


struct COptionHandlerBase
{
    size_t infoIndentLen;
    size_t infoMaxWidth;

/*
    static const int no_error      = 1;
    static const int no_error_stop = -1;
    static const int error_stop    = 0;
    mutable int errorStatus;

    int  getErrorStatus()  const { return errorStatus; }
    bool isErrorStatusOk() const { return errorStatus!=error_stop; }
*/

    RCODE returnErrorStop( RCODE res = EC_COMMAND_LINE_GENERIC_ERR ) const {  /* errorStatus = error_stop   ; */  return res; }
    RCODE returnStop()      const {  /* errorStatus = no_error_stop; */  return EC_COMMAND_LINE_PARSING_STOPPED; }
    RCODE returnOk()        const {  /* errorStatus = no_error     ; */  return EC_OK; }
    RCODE returnContinue()  const { return returnOk(); }

    //::std::ostream        *pOs
    //::std::ostream        *pOsErr

    COptionHandlerBase() : infoIndentLen(28), infoMaxWidth(78) /* , errorStatus(error_stop) */  {}


    bool safeReadBool( const ::cli::cmd_line::CGetoptContext &ctx
                     , ::cli::CiArgList        &argList
                     , bool                    &bVal
                     , bool                     defVal            = false
                     , bool                     allowDefVal       = false
                     , bool                     ignoreWrongValues = false
                     ) const
       {
        if ( allowDefVal && argList.getType(ctx.valueIndex)==CLI_VARIANTTYPE_VT_EMPTY )
           { bVal = defVal; return true; }

        BOOL b = 0;
        argList.getBool( ctx.valueIndex, &b);
        if (b>0)
           { bVal = true; return true; }
        if (b==0)
           { bVal = false; return true; }

        if (ignoreWrongValues)
           { bVal = defVal; return true; }

        //if (ctx.pOsErr) // report error
           {
            ::std::wstring invalidValue;
            argList.getString( ctx.valueIndex, invalidValue );
            getoptPrintInvalidOptionValueMessage( ctx.curOptName, invalidValue, ctx, true );
           }
        return false;
       }

    template <typename CharType, typename Traits, typename Allocator>
    bool splitToPair( const ::std::basic_string<CharType, Traits, Allocator> &str
                    , ::std::basic_string<CharType, Traits, Allocator> &first
                    , ::std::basic_string<CharType, Traits, Allocator> &second
                    , CharType chSep
                    ) const
       {
        typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
        typename string_type::size_type sepPos = str.find( chSep );

        if (sepPos==str.npos)
           {
            first = str;
            return false; // indicate that there is no separator found
           }
        first.assign( str, 0, sepPos );
        second.assign( str, sepPos+1, str.npos );
        return !second.empty();
       }

    void safeReadStringPair( const ::cli::cmd_line::CGetoptContext &ctx
                           , ::cli::CiArgList        &argList
                           , ::std::string &first
                           , ::std::string &second
                           , char sepChar = '='
                           , ::std::string defVal = ::std::string() // bool allowEmptySecond = false
                           ) const
       {
        ::std::wstring tmp;
        argList.getString( ctx.valueIndex, tmp );
        if (!splitToPair( MARTY_CON::strToAnsi(tmp), first, second, sepChar ) && defVal.empty())
        //if (ctx.pOsErr) // report error
           {
            getoptPrintInvalidOptionValueMessage( ctx.curOptName, tmp, ctx, true );
           }
       }

    void safeReadStringPair( const ::cli::cmd_line::CGetoptContext &ctx
                           , ::cli::CiArgList        &argList
                           , ::std::wstring &first
                           , ::std::wstring &second
                           , wchar_t sepChar = L'='
                           , ::std::wstring defVal = ::std::wstring() // bool allowEmptySecond = false
                           ) const
       {
        ::std::wstring tmp;
        argList.getString( ctx.valueIndex, tmp );
        if (!splitToPair( tmp, first, second, sepChar ) && defVal.empty())
        //if (ctx.pOsErr) // report error
           {
            getoptPrintInvalidOptionValueMessage( ctx.curOptName, tmp, ctx, true );
           }
       }

    // return false to stop processing options
    RCODE operator()( const CGetoptContext        &ctx
                   , wchar_t                optSelector
                   , const COptDescription *pOptInfo
                   , ::cli::CiArgList      &argList
                   ) const
      {      
       switch(optSelector)
          {
           case CLI_GETOPT_VERSION_CMDID: //L'V':  // --version
                       if (ctx.pOs) (*ctx.pOs)<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()(ctx.programVersionString) << "\n";
                       else
                          {
                           ENUM_CLI_GUI_ERRORDIALOGFLAGS flags = CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON | CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION;
                           // if (useErrStream) flags |= CLI_GUI_ERRORDIALOGFLAGS_ICONERROR;
                           // else              flags |= CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION;
                           ctx.tryShowMessageBox( (WND_HANDLE)0, ctx.programName, ctx.programVersionString, flags );
                          }
                       return returnStop(); 

           case CLI_GETOPT_HELP_CMDID: // L'h':  // --help
                       //if (ctx.pOs)
                       {
                        ::std::ostream *pStream = ctx.pOs; // useErrStream = false
                        if (!pStream) getoptPrintHelp( ctx, false, infoIndentLen, infoMaxWidth*2 );
                        else          getoptPrintHelp( ctx, false, infoIndentLen, infoMaxWidth );
                       }
                       return returnStop();

           case CLI_GETOPT_BUILD_COMPONENTS_CACHE_CMDID:
                       //if (ctx.pOs)
                       //   getoptPrintHelp( ctx, false, infoIndentLen, infoMaxWidth );
                       {
                           ::cli::CiComponentCacheManager cacheMan("/cli/component-cache-mgr");
                           cacheMan.createCacheForModules(FALSE, TRUE );
                       }
                       return returnStop();

           case CLI_GETOPT_BUILD_COMPONENTS_CACHE_EX_CMDID:
                       //if (ctx.pOs)
                       //   getoptPrintHelp( ctx, false, infoIndentLen, infoMaxWidth );
                       {
                           ::cli::CiComponentCacheManager cacheMan("/cli/component-cache-mgr");
                           cacheMan.createCacheForModules(TRUE, TRUE );
                       }
                       return returnStop();

           case CLI_GETOPT_WHERE_CMDID:
                       {
                          ::std::wstring name;
                          MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, name);
                          if (ctx.pOs)
                             {
                              //setFileName(name);
                              (*ctx.pOs)<< CLICMDLINE_WIDE2ANSI_DEFAULT_CONVERTER()( name ) << "\n";
                             }
                          else
                             {
                              ENUM_CLI_GUI_ERRORDIALOGFLAGS flags = CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON | CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION;
                              // if (useErrStream) flags |= CLI_GUI_ERRORDIALOGFLAGS_ICONERROR;
                              // else              flags |= CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION;
                              ctx.tryShowMessageBox( (WND_HANDLE)0, ctx.programName, name, flags );
                             }
                          return returnStop();
                       }

           case 0:     // do nothing - we don't know how to process input
                       break;
           default:    // do nothing too
                       break;
          }

       return EC_OK;
      }

}; // struct COptionHandlerBase

/*
getoptPrepareDescriptions( opts, optsTmp, shortMap, longMap );
if (!::cli::cmd_line::getoptPrepareArgList( argList, optsTmp, shortMap, longMap, invalidOptionStr, unknowOptChar))
::cli::cmd_line::getoptPrintUnrecognizedOptionMessage( invalidOptionStr, unknowOptChar, programPathName, ::std::cout );
::cli::cmd_line::getoptPrintHelp( optsTmp, shortMap, longMap, programPathName, L"[files]", L"Some programm description", L"xmlanalize 0.1", ::std::cout, 20, 78 );
*/


/*
const unsigned int optFlag           = 0;      // no argument, simple flag
const unsigned int optValueOptional  = 1;      // optional argument
const unsigned int optOptional       = 1;      // alias for optValueOptional
const unsigned int optValueRequired  = 2;      // required mandatory argument
const unsigned int optRequiredOption = 0x1000; // this option is required for program normal execution


struct COptDescription
{
    wchar_t          shortOpt;     // can be 0
    const wchar_t   *longOpt;
    unsigned int     optFlags;     // opt*
    const wchar_t   *description;
    const wchar_t   *paramName;    // optional string with option parameter name
};
CLI_GETOPT_IS_CMDID(optsPtr->shortOpt);
*/

/*
struct CGetoptBaseHandler
{
    bool operator
};
*/

}; // namespace cmd_line
}; // namespace cli{




#if defined(_WIN32) || defined(WIN32)
    //#if !defined(__GNUC__)
        #if defined(UNICODE) || defined(_UNICODE)
            #define C_MAIN()                  int wmain ( int argc, wchar_t *argv[] )
            #define C_WINMAIN() int WINAPI    wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpstrCmdLine, int nCmdShow)
        #else
            #define C_MAIN()                  int main  ( int argc, char *argv[ ] )
            #define C_WINMAIN() int WINAPI    WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpstrCmdLine, int nCmdShow)
        #endif        
    //#else
    //    // mingw doesn't support wide versions
    //    #define C_MAIN()                  int main  ( int argc, char *argv[ ] )
    //    #define C_WINMAIN() int WINAPI    WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpstrCmdLine, int nCmdShow)
    //#endif

#else // Linux or others
    #define C_MAIN()                      int main ( int argc, char *argv[] )
    #define C_WINMAIN()                   C_MAIN() /* no difference with console main */
#endif


#define CLI_MAIN_DECLARE_ARGS_EX( converter )     ::cli::CiArgList argList( ::cli::cmd_line::buildArgListFromMainArguments(argc, argv, converter), true );


#if defined(_WIN32) || defined(WIN32)
    #define CLI_MAIN_DECLARE_ARGS()                   CLI_MAIN_DECLARE_ARGS_EX( ::cli::cmd_line::CWinAnsiConverter() )
    #define CLI_WINMAIN_DECLARE_ARGS_EX( converter )  ::cli::CiArgList argList( ::cli::cmd_line::buildArgListFromWinMainArguments(lpstrCmdLine, converter), true );
    #define CLI_WINMAIN_DECLARE_ARGS()                CLI_WINMAIN_DECLARE_ARGS_EX( ::cli::cmd_line::CWinAnsiConverter() )
#else
    #define CLI_MAIN_DECLARE_ARGS()                   CLI_MAIN_DECLARE_ARGS_EX( ::cli::cmd_line::CUtf8Converter() )
    #define CLI_WINMAIN_DECLARE_ARGS_EX(converter)    CLI_MAIN_DECLARE_ARGS_EX( converter )
    #define CLI_WINMAIN_DECLARE_ARGS(converter)       CLI_MAIN_DECLARE_ARGS_EX( ::cli::cmd_line::CUtf8Converter() )
#endif

// int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPTSTR lpstrCmdLine, int nCmdShow)


// CLI_MAIN_EX, CLI_MAIN requires iostream to be included
// CLI_APP_REPORT_TO_CONSOLE CLI_APP_REPORT_DIALOG
#define CLI_MAIN_EX2( howToShowErrors, converter )\
RCODE cliMain( ::cli::CiArgList &argList );       \
                                                  \
C_MAIN()                                          \
   {                                              \
    CLI_MAIN_DECLARE_ARGS_EX( converter );        \
    CLI_BEGIN_APP_CODE()                          \
    appExecutionResult = cliMain( argList );      \
    CLI_END_APP_CODE_EX(howToShowErrors, 0 )      \
   }                                              \
                                                  \
RCODE cliMain( ::cli::CiArgList &argList )


#if defined(_WIN32) || defined(WIN32)
    #define CLI_MAIN_EX( howToShowErrors )       CLI_MAIN_EX2( howToShowErrors, ::cli::cmd_line::CWinAnsiConverter() )
#else
    #define CLI_MAIN_EX( howToShowErrors )       CLI_MAIN_EX2( howToShowErrors, ::cli::cmd_line::CUtf8Converter() )
#endif

#define CLI_MAIN()     CLI_MAIN_EX(CLI_APP_REPORT_TO_CONSOLE)


#define CLI_MAIN_PARSE_ARGS_EX2( projectName, paramName, helpString, versionString  \
                               , outStream, errStream                               \
                               , optHandlerClass, optHandlerFlags                   \
                               , howToShowErrors, converter                         \
                               )                                                    \
                                                                                    \
RCODE userMain( const ::cli::cmd_line::CGetoptContext &getoptContext, optHandlerClass &optHandler );                   \
CLI_MAIN_EX2( howToShowErrors, converter )                                                                             \
   {                                                                                                                   \
    ::cli::cmd_line::CGetoptContext getoptContext( MARTY_CON::strToWide(projectName)                                   \
                                                 , paramName                                                           \
                                                 , helpString                                                          \
                                                 , MARTY_CON::strToWide(projectName) + ::std::wstring( (::std::wstring( versionString ).empty() ? L"" : L" " ) ) + ::std::wstring( versionString ) \
                                                 );                                                                    \
    getoptContext.pOs    = & outStream;                                                                                \
    getoptContext.pOsErr = & errStream;                                                                                \
    optHandlerClass optHandler;                                                                                        \
    RCODE optRes = ::cli::cmd_line::getoptParse< optHandlerClass >( argList, programmCmdOpts, getoptContext, optHandler, optHandlerFlags ); \
    if (optRes)                                                                                                        \
       return optRes /* EC_COMMAND_LINE_PARSING_STOPPED */ ;                                                           \
                                                                                                                       \
    return userMain( getoptContext, optHandler );                                                                      \
   }                                             \
                                                 \
RCODE userMain( const ::cli::cmd_line::CGetoptContext &getoptContext, optHandlerClass &optHandler )



#if defined(_WIN32) || defined(WIN32)
    #define CLI_MAIN_PARSE_ARGS_EX( projectName, paramName, helpString, versionString \
                                  , outStream, errStream                              \
                                  , optHandlerClass, optHandlerFlags                  \
                                  , howToShowErrors                                   \
                                  )                                                   \
                     CLI_MAIN_PARSE_ARGS_EX2( projectName, paramName, helpString, versionString     \
                                            , outStream, errStream                                  \
                                            , optHandlerClass, optHandlerFlags                      \
                                            , howToShowErrors, ::cli::cmd_line::CWinAnsiConverter() \
                                            )
#else
    #define CLI_MAIN_PARSE_ARGS_EX( projectName, paramName, helpString, versionString  \
                                  , outStream, errStream                               \
                                  , optHandlerClass, optHandlerFlags                   \
                                  , howToShowErrors                                    \
                                  )                                                    \
                     CLI_MAIN_PARSE_ARGS_EX2( projectName, paramName, helpString, versionString     \
                                            , outStream, errStream                                  \
                                            , optHandlerClass, optHandlerFlags                      \
                                            , howToShowErrors, ::cli::cmd_line::CUtf8Converter()    \
                                            )

#endif




#define CLI_MAIN_PARSE_ARGS( paramName, helpString, versionString  \
                           , outStream, errStream, optHandlerClass \
                           , optHandlerFlags                       \
                           )                                       \
            CLI_MAIN_PARSE_ARGS_EX( MBS_PROJECT_NAME, paramName, helpString, versionString     \
                               , outStream, errStream, optHandlerClass, optHandlerFlags        \
                               , CLI_APP_REPORT_TO_CONSOLE                                     \
                               )





#if defined(_WIN32) || defined(WIN32)
    #define DECLARE_CLIAPP_WINMAIN_GLOBALS()    HINSTANCE cliAppInstance     = 0; \
                                                HINSTANCE cliAppPrevInstance = 0; \
                                                int cliAppCmdShow            = 0;

    #define ASSIGN_CLIAPP_WINMAIN_GLOBALS()     cliAppInstance               = hInstance; \
                                                cliAppPrevInstance           = hPrevInstance; \
                                                cliAppCmdShow                = nCmdShow;

#else
    #define DECLARE_CLIAPP_WINMAIN_GLOBALS()    int cliAppInstance           = 0; \
                                                int cliAppPrevInstance       = 0; \
                                                int cliAppCmdShow            = 0;
    #define ASSIGN_CLIAPP_WINMAIN_GLOBALS()
#endif



#define CLI_WINMAIN_EX2( howToShowErrors  /* ignored */ , converter ) \
RCODE cliMain( ::cli::CiArgList &argList );           \
DECLARE_CLIAPP_WINMAIN_GLOBALS()                      \
                                                      \
C_WINMAIN()                                           \
   {                                                  \
    ASSIGN_CLIAPP_WINMAIN_GLOBALS()                   \
    CLI_WINMAIN_DECLARE_ARGS_EX( converter );         \
    CLI_BEGIN_APP_CODE()                              \
    appExecutionResult = cliMain( argList );          \
    CLI_END_APP_CODE_EX( CLI_APP_REPORT_DIALOG, 0 )   \
   }                                                  \
                                                      \
RCODE cliMain( ::cli::CiArgList &argList )

#if defined(_WIN32) || defined(WIN32)
    #define CLI_WINMAIN_EX( howToShowErrors )       CLI_WINMAIN_EX2( howToShowErrors, ::cli::cmd_line::CWinAnsiConverter() )
#else
    #define CLI_WINMAIN_EX( howToShowErrors )       CLI_WINMAIN_EX2( howToShowErrors, ::cli::cmd_line::CUtf8Converter() )
#endif

#define CLI_WINMAIN( )  CLI_WINMAIN_EX( CLI_APP_REPORT_DIALOG )

#endif // __cplusplus

// http://www.intuit.ru/department/se/pposix/examples.html


#endif /* CLI_CLICMDLINE_H */

