#ifndef CLI_COMMON_ITEXTBUF_H
#define CLI_COMMON_ITEXTBUF_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/common/itextbuf.h>", CLI_COMMON_ITEXTBUF_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_COMMON_ITEXTBUF_H
    #include <cli/common/itextbuf.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iTextBuf */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITEXTBUF_IID
    #define INTERFACE_CLI_ITEXTBUF_IID    "/cli/iTextBuf"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTextBuf
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ITEXTBUF
       #define INTERFACE_CLI_ITEXTBUF    ::cli::iTextBuf
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTextBuf
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ITEXTBUF
       #define INTERFACE_CLI_ITEXTBUF    cli_iTextBuf
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iTextBuf methods */
            CLIMETHOD(textGet) (THIS_ CLISTR*           _text
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               ) PURE;
            CLIMETHOD(textSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(textSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 ) PURE;
            CLIMETHOD(clearText) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTextBuf >
           {
            static char const * getName() { return INTERFACE_CLI_ITEXTBUF_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTextBuf* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTextBuf > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iTextBuf wrapper
        // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ITEXTBUF >
                                      */
                 >
        class CiTextBufWrapper
        {
            public:
        
                typedef  CiTextBufWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTextBufWrapper() :
                   pif(0) {}
        
                CiTextBufWrapper( iTextBuf *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTextBufWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTextBufWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTextBufWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTextBufWrapper(const CiTextBufWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTextBufWrapper()  { }
        
                CiTextBufWrapper& operator=(const CiTextBufWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_text( SIZE_T idx1
                                       , SIZE_T idx2
                                       )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = textGet( tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size1_text(  )
                   {
                    SIZE_T size;
                    RCODE res = textSize1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_text( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = textSize2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, ::std::wstring, text, SIZE_T, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE textGet( ::std::wstring    &_text
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                             )
                   {
                    CCliStr tmp__text; CCliStr_init( tmp__text );
                
                
                    RCODE res = pif->textGet(&tmp__text, idx1, idx2);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _text, tmp__text);
                       }
                    return res;
                   }
                
                RCODE textSize1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->textSize1(_size);
                   }
                
                RCODE textSize2( SIZE_T*    _size /* [out] size_t _size  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
                   {
                
                
                    return pif->textSize2(_size, idx1);
                   }
                
                RCODE clearText( )
                   {
                    return pif->clearText();
                   }
                

        
        
        }; // class CiTextBufWrapper
        
        typedef CiTextBufWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITEXTBUF     > >  CiTextBuf;
        typedef CiTextBufWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITEXTBUF > >  CiTextBuf_nrc; /* No ref counting for interface used */
        typedef CiTextBufWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITEXTBUF > >  CiTextBuf_tmp; /* for temporary usage, same as CiTextBuf_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_COMMON_ITEXTBUF_H */
