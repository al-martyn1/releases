#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_COMMON_IMPL_FILTERIMPLBASE_H
#define CLI_COMMON_IMPL_FILTERIMPLBASE_H

/* add this lines to your src
#ifndef CLI_COMMON_IMPL_FILTERIMPLBASE_H
    #include <cli/common/impl/filterImplBase.h>
#endif
*/
// $

namespace cli
{
namespace impl
{


class CStreamFilterImplBase : public INTERFACE_CLI_ISTREAMFILTER
{
    protected:

        INTERFACE_CLI_ISTREAMFILTER *nextStreamFilter;

    public:

        typedef INTERFACE_CLI_ISTREAMFILTER         base_class;
        typedef CStreamFilterImplBase               this_class;

        CStreamFilterImplBase() : base_class(), nextStreamFilter() {}
        ~CStreamFilterImplBase()
           {
            if (nextStreamFilter) nextStreamFilter->release();
           }

        CLIMETHOD(nextStreamFilterGet) (THIS_ INTERFACE_CLI_ISTREAMFILTER**    _nextStreamFilter /* [out] ::cli::iStreamFilter* _nextFilter  */)
           {
            if (!_nextStreamFilter) return EC_OK;
            *_nextStreamFilter = nextStreamFilter;
            if (nextStreamFilter) nextStreamFilter->addRef();
            return EC_OK;
           }

        CLIMETHOD(nextStreamFilterSet) (THIS_ INTERFACE_CLI_ISTREAMFILTER*    _nextStreamFilter /* [in] ::cli::iStreamFilter*  _nextFilter  */)
           {
            if (nextStreamFilter) nextStreamFilter->release();
            nextStreamFilter = _nextStreamFilter;
            if (nextStreamFilter) nextStreamFilter->addRef();
            return EC_OK;
           }

        CLIMETHOD(putData) (THIS_ const BYTE*    data /* [in,flat] byte  data[]  */
                                , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                , SIZE_T    pos /* [in] size_t  pos  */
                           )
           {
            RCODE res = 0;
            for(SIZE_T i=0; i!=dataLen; ++i)
               {
                res = putByte(data[i], pos+i );
                if (res) return res;
               }
            return res;           
           }

        // putByte need to be implemented
        // endOfStream need to be implemented


}; // CStreamFilterImplBase






class CTextFilterImplBase : public INTERFACE_CLI_ITEXTFILTER
{

    protected:

        bool                                      useOwnNumbering;
        INTERFACE_CLI_ITEXTFILTER                *nextTextFilter;

    public:

        typedef INTERFACE_CLI_ITEXTFILTER         base_class;
        typedef CTextFilterImplBase               this_class;

        CTextFilterImplBase() : base_class(), useOwnNumbering(true), nextTextFilter(0) {}
        ~CTextFilterImplBase()
           {
            if (nextTextFilter) nextTextFilter->release();
           }

        CLIMETHOD(useOwnNumberingGet) (THIS_ BOOL*    _useOwnNumbering /* [out] bool _useOwnNumbering  */)
           {
            if (!_useOwnNumbering) return EC_OK;
            *_useOwnNumbering = useOwnNumbering ? TRUE : FALSE;
            return EC_OK;
           }

        CLIMETHOD(useOwnNumberingSet) (THIS_ BOOL    _useOwnNumbering /* [in] bool  _useOwnNumbering  */)
           {
            useOwnNumbering = _useOwnNumbering ? true : false;
            return EC_OK;
           }

        CLIMETHOD(nextTextFilterGet) (THIS_ INTERFACE_CLI_ITEXTFILTER**    _nextTextFilter /* [out] ::cli::iTextFilter* _nextTextFilter  */)
           {
            if (!_nextTextFilter) return EC_OK;
            *_nextTextFilter = nextTextFilter;
            if (nextTextFilter) nextTextFilter->addRef();
            return EC_OK;
           }

        CLIMETHOD(nextTextFilterSet) (THIS_ INTERFACE_CLI_ITEXTFILTER*    _nextTextFilter /* [in] ::cli::iTextFilter*  _nextTextFilter  */)
           {
            if (nextTextFilter) nextTextFilter->release();
            nextTextFilter = _nextTextFilter;
            if (nextTextFilter) nextTextFilter->addRef();
            return EC_OK;
           }

        CLIMETHOD(putString) (THIS_ const CLISTR*     _str
                                  , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                  , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                  , SIZE_T    linePos /* [in] size_t  linePos  */
                             )
           {
            RCODE res = 0;
            ::std::wstring str = stdstr(_str);
            for(SIZE_T i=0; i!=str.size(); ++i)
               {
                res = putChar(str[i], streamPos+i, lineNo, linePos++ );
                if (res) return res;
                if (str[i]==L'\n') { lineNo++; linePos = 0; }
               }
            return res;
           }

        CLIMETHOD(putStringChars) (THIS_ const WCHAR*    dataBuf /* [in,flat] wchar  dataBuf[]  */
                                       , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                       , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                       , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                       , SIZE_T    linePos /* [in] size_t  linePos  */
                                  )
           {
            RCODE res = 0;
            for(SIZE_T i=0; i!=dataLen; ++i)
               {
                res = putChar(dataBuf[i], streamPos+i, lineNo, linePos++ );
                if (res) return res;
                if (dataBuf[i]==L'\n') { lineNo++; linePos = 0; }
               }
            return res;           
           }

        // putChar need to be implemented
        // endOfText need to be implemented

}; // class CTextFilterImplBase








}; // namespace impl
}; // namespace cli


#endif /* CLI_COMMON_IMPL_FILTERIMPLBASE_H */

