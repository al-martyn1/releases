#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_COMMON_IMPL_TEXTFILTERCHAINBASE_H
#define CLI_COMMON_IMPL_TEXTFILTERCHAINBASE_H

#ifndef CLI_COMMON_IMPL_MULTITEXTFILTERCHAINBASE_H
    #include <cli/common/impl/multiTextFilterChainBase.h>
#endif

#ifndef CLI_COMMON_IMPL_SINGLETEXTFILTERCHAINBASE_H
    #include <cli/common/impl/singleTextFilterChainBase.h>
#endif

namespace cli
{
namespace impl
{

template <typename BaseImpl>
class CTextFilterChainImplBase : public BaseImpl
{

    public:

        typedef BaseImpl                               base_class;
        typedef CTextFilterChainImplBase< base_class > this_class;

//        CTextFilterChainImplBase()

}; // class CTextFilterChainImplBase

// CMultiTextFilterChainImplBase
// CSingleTextFilterChainImplBase
template <> 
class CTextFilterChainImplBase< ::cli::impl::CMultiTextFilterChainImplBase> : public ::cli::impl::CMultiTextFilterChainImplBase
{
    public:

        typedef ::cli::impl::CMultiTextFilterChainImplBase                            base_class;
        typedef CTextFilterChainImplBase< ::cli::impl::CMultiTextFilterChainImplBase> this_class;

        CTextFilterChainImplBase() : base_class() {}

        CLIMETHOD(chainPutChar) (THIS_ WCHAR    ch /* [in] wchar  ch  */
                                , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                , SIZE_T    linePos /* [in] size_t  linePos  */
                           )
           {
            RCODE res = 0;
            ::std::vector<INTERFACE_CLI_ITEXTFILTER*>::iterator it = this->filtersList.begin();
            for(; it != this->filtersList.end(); ++it)
               {
                res = (*it)->putChar( ch, streamPos, lineNo, linePos );
               }
            return res;
           }

        CLIMETHOD(chainEndOfText) (THIS_ SIZE_T    streamPos /* [in] size_t  streamPos  */
                                , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                , SIZE_T    linePos /* [in] size_t  linePos  */
                           )
           {
            RCODE res = 0;
            ::std::vector<INTERFACE_CLI_ITEXTFILTER*>::iterator it = this->filtersList.begin();
            for(; it != this->filtersList.end(); ++it)
               {
                res = (*it)->endOfText( streamPos, lineNo, linePos );
               }
            return res;
           }

        CLIMETHOD(chainOnTextError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                    , RCODE    errCode /* [in] rcode  errCode  */
                                    , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                    , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                    , SIZE_T    linePos /* [in] size_t  linePos  */
                               )
           {
            RCODE res = 0;
            ::std::vector<INTERFACE_CLI_ITEXTFILTER*>::iterator it = this->filtersList.begin();
            for(; it != this->filtersList.end(); ++it)
               {
                res = (*it)->onTextError( fltName, errCode, streamPos, lineNo, linePos );
               }
            return res;
           }
}; // multi




template <> 
class CTextFilterChainImplBase< ::cli::impl::CSingleTextFilterChainImplBase > : public ::cli::impl::CSingleTextFilterChainImplBase
{
    public:

        typedef ::cli::impl::CSingleTextFilterChainImplBase                            base_class;
        typedef CTextFilterChainImplBase< ::cli::impl::CSingleTextFilterChainImplBase> this_class;

        CTextFilterChainImplBase() : base_class() {}

        CLIMETHOD(chainPutChar) (THIS_ WCHAR    ch /* [in] wchar  ch  */
                                , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                , SIZE_T    linePos /* [in] size_t  linePos  */
                           )
           {
            if (!this->singleFilter) return 0;
            return this->singleFilter->putChar( ch, streamPos, lineNo, linePos );
           }

        CLIMETHOD(chainEndOfText) (THIS_ SIZE_T    streamPos /* [in] size_t  streamPos  */
                                , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                , SIZE_T    linePos /* [in] size_t  linePos  */
                           )
           {
            if (!this->singleFilter) return 0;
            return this->singleFilter->endOfText( streamPos, lineNo, linePos );
           }

        CLIMETHOD(chainOnTextError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                    , RCODE    errCode /* [in] rcode  errCode  */
                                    , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                    , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                    , SIZE_T    linePos /* [in] size_t  linePos  */
                               )
           {
            if (!this->singleFilter) return 0;
            return this->singleFilter->onTextError( fltName, errCode, streamPos, lineNo, linePos );
           }

}; // single



}; // namespace impl
}; // namespace cli


#endif // CLI_COMMON_IMPL_TEXTFILTERCHAINBASE_H

