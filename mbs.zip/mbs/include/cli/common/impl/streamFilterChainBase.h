#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_COMMON_IMPL_STREAMFILTERCHAINBASE_H
#define CLI_COMMON_IMPL_STREAMFILTERCHAINBASE_H

#ifndef CLI_COMMON_IMPL_MULTISTREAMFILTERCHAINBASE_H
    #include <cli/common/multiTextFilterChainBase.h>
#endif

#ifndef CLI_COMMON_IMPL_SINGLESTREAMFILTERCHAINBASE_H
    #include <cli/common/singleTextFilterChainBase.h>
#endif

namespace cli
{
namespace impl
{

template <typename BaseImpl>
class CStreamFilterChainImplBase : public BaseImpl
{

    public:

        typedef BaseImpl                                 base_class;
        typedef CStreamFilterChainImplBase< base_class > this_class;

//        CTextFilterChainImplBase()

}; // class CTextFilterChainImplBase

// CMultiTextFilterChainImplBase
// CSingleTextFilterChainImplBase
template <> class CStreamFilterChainImplBase<CMultiStreamFilterChainImplBase> : public CMultiStreamFilterChainImplBase
{
    public:
        CStreamFilterChainImplBase() : CMultiStreamFilterChainImplBase() {}

        CLIMETHOD(chainPutByte) (THIS_ BYTE    b /* [in] byte  b  */
                                , SIZE_T    pos /* [in] size_t  pos  */
                           )
           {
            RCODE res = 0;
            ::std::vector<INTERFACE_CLI_ISTREAMFILTERCHAIN*>::iterator it = this->filtersList.begin();
            for(; it != this->filtersList.end(); ++it)
               {
                res = (*it)->putByte( b, pos );
               }
            return res;
           }

        CLIMETHOD(chainEndOfStream) (THIS_ SIZE_T    pos /* [in] size_t  pos  */)
           {
            RCODE res = 0;
            ::std::vector<INTERFACE_CLI_ISTREAMFILTERCHAIN*>::iterator it = this->filtersList.begin();
            for(; it != this->filtersList.end(); ++it)
               {
                res = (*it)->endOfStream( pos );
               }
            return res;
           }

        CLIMETHOD(chainOnDataError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                    , RCODE    errCode /* [in] rcode  errCode  */
                                    , SIZE_T    errPos /* [in] size_t  errPos  */
                               )
           {
            RCODE res = 0;
            ::std::vector<INTERFACE_CLI_ISTREAMFILTERCHAIN*>::iterator it = this->filtersList.begin();
            for(; it != this->filtersList.end(); ++it)
               {
                res = (*it)->onDataError( fltName, errCode, errPos );
               }
            return res;
           }
}; // multi




template <> class CStreamFilterChainImplBase<CSingleStreamFilterChainImplBase> : public CSingleStreamFilterChainImplBase
{
    public:
        CStreamFilterChainImplBase() : CSingleStreamFilterChainImplBase() {}

        CLIMETHOD(chainPutByte) (THIS_ BYTE    b /* [in] byte  b  */
                                , SIZE_T    pos /* [in] size_t  pos  */
                           )
           {
            if (!this->singleFilter) return 0;
            return this->singleFilter->putByte( b, pos );
           }

        CLIMETHOD(chainEndOfStream) (THIS_ SIZE_T    pos /* [in] size_t  pos  */)
           {
            if (!this->singleFilter) return 0;
            return this->singleFilter->endOfStream( pos );
           }

        CLIMETHOD(chainOnDataError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                    , RCODE    errCode /* [in] rcode  errCode  */
                                    , SIZE_T    errPos /* [in] size_t  errPos  */
                               )
           {
            if (!this->singleFilter) return 0;
            return this->singleFilter->onDataError( fltName, errCode, errPos );
           }

}; // single





}; // namespace impl
}; // namespace cli


#endif // CLI_COMMON_IMPL_STREAMFILTERCHAINBASE_H

