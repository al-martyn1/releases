#ifndef CLI_COMMON_IITERATOR_H
#define CLI_COMMON_IITERATOR_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/common/iiterator.h>", CLI_COMMON_IITERATOR_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_COMMON_IITERATOR_H
    #include <cli/common/iiterator.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_COMMON_IITERABLE_H
    #include <cli/common/iiterable.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iIterator */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iGenericIterable;
        #ifndef INTERFACE_CLI_IGENERICITERABLE
            #define INTERFACE_CLI_IGENERICITERABLE    ::cli::iGenericIterable
        #endif

    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iGenericIterable                   cli_iGenericIterable;
    #ifndef INTERFACE_CLI_IGENERICITERABLE
        #define INTERFACE_CLI_IGENERICITERABLE    struct tag_cli_iGenericIterable
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IITERATOR_IID
    #define INTERFACE_CLI_IITERATOR_IID    "/cli/iIterator"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iIterator
    #define BASE_INTERFACE ::cli::iGenericIterable
    #ifndef INTERFACE_CLI_IITERATOR
       #define INTERFACE_CLI_IITERATOR    ::cli::iIterator
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iIterator
    #define BASE_INTERFACE cli_iGenericIterable
    #ifndef INTERFACE_CLI_IITERATOR
       #define INTERFACE_CLI_IITERATOR    cli_iIterator
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iIterable methods */
            CLIMETHOD_(BOOL, isBegin) (THIS) PURE;
            CLIMETHOD_(BOOL, isEnd) (THIS) PURE;
            CLIMETHOD(getDataPtr) (THIS_ VOID**    pData /* [out] void* pData  */) PURE;
            
            /* interface ::cli::iGenericIterable methods */
            CLIMETHOD(move) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iIterator >
           {
            static char const * getName() { return INTERFACE_CLI_IITERATOR_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iIterator* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iIterator > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iIterator wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IITERATOR >
                                      */
                 >
        class CiIteratorWrapper
        {
            public:
        
                typedef  CiIteratorWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiIteratorWrapper() :
                   pif(0) {}
        
                CiIteratorWrapper( iIterator *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiIteratorWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiIteratorWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiIteratorWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiIteratorWrapper(const CiIteratorWrapper &i) :
                    pif(i.pif) { }
        
                ~CiIteratorWrapper()  { }
        
                CiIteratorWrapper& operator=(const CiIteratorWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                BOOL isBegin( )
                   {
                    return pif->isBegin();
                   }
                
                BOOL isEnd( )
                   {
                    return pif->isEnd();
                   }
                
                RCODE getDataPtr( VOID**    pData /* [out] void* pData  */)
                   {
                
                    return pif->getDataPtr(pData);
                   }
                
                RCODE move( )
                   {
                    return pif->move();
                   }
                

        
        
        }; // class CiIteratorWrapper
        
        typedef CiIteratorWrapper< ::cli::CCliPtr< INTERFACE_CLI_IITERATOR     > >  CiIterator;
        typedef CiIteratorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IITERATOR > >  CiIterator_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iRandomIterator */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iRandomIterable;
        #ifndef INTERFACE_CLI_IRANDOMITERABLE
            #define INTERFACE_CLI_IRANDOMITERABLE     ::cli::iRandomIterable
        #endif

    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iRandomIterable                    cli_iRandomIterable;
    #ifndef INTERFACE_CLI_IRANDOMITERABLE
        #define INTERFACE_CLI_IRANDOMITERABLE     struct tag_cli_iRandomIterable
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IRANDOMITERATOR_IID
    #define INTERFACE_CLI_IRANDOMITERATOR_IID    "/cli/iRandomIterator"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iRandomIterator
    #define BASE_INTERFACE ::cli::iRandomIterable
    #ifndef INTERFACE_CLI_IRANDOMITERATOR
       #define INTERFACE_CLI_IRANDOMITERATOR    ::cli::iRandomIterator
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iRandomIterator
    #define BASE_INTERFACE cli_iRandomIterable
    #ifndef INTERFACE_CLI_IRANDOMITERATOR
       #define INTERFACE_CLI_IRANDOMITERATOR    cli_iRandomIterator
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iIterable methods */
            CLIMETHOD_(BOOL, isBegin) (THIS) PURE;
            CLIMETHOD_(BOOL, isEnd) (THIS) PURE;
            CLIMETHOD(getDataPtr) (THIS_ VOID**    pData /* [out] void* pData  */) PURE;
            
            /* interface ::cli::iRandomIterable methods */
            CLIMETHOD(move) (THIS) PURE;
            CLIMETHOD(moveForward) (THIS) PURE;
            CLIMETHOD(moveBackward) (THIS) PURE;
            CLIMETHOD(moveRandom) (THIS_ SSIZE_T    moveDist /* [in] ssize_t  moveDist  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iRandomIterator >
           {
            static char const * getName() { return INTERFACE_CLI_IRANDOMITERATOR_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iRandomIterator* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iRandomIterator > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iRandomIterator wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IRANDOMITERATOR >
                                      */
                 >
        class CiRandomIteratorWrapper
        {
            public:
        
                typedef  CiRandomIteratorWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiRandomIteratorWrapper() :
                   pif(0) {}
        
                CiRandomIteratorWrapper( iRandomIterator *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiRandomIteratorWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiRandomIteratorWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiRandomIteratorWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiRandomIteratorWrapper(const CiRandomIteratorWrapper &i) :
                    pif(i.pif) { }
        
                ~CiRandomIteratorWrapper()  { }
        
                CiRandomIteratorWrapper& operator=(const CiRandomIteratorWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                BOOL isBegin( )
                   {
                    return pif->isBegin();
                   }
                
                BOOL isEnd( )
                   {
                    return pif->isEnd();
                   }
                
                RCODE getDataPtr( VOID**    pData /* [out] void* pData  */)
                   {
                
                    return pif->getDataPtr(pData);
                   }
                
                RCODE move( )
                   {
                    return pif->move();
                   }
                
                RCODE moveForward( )
                   {
                    return pif->moveForward();
                   }
                
                RCODE moveBackward( )
                   {
                    return pif->moveBackward();
                   }
                
                RCODE moveRandom( SSIZE_T    moveDist /* [in] ssize_t  moveDist  */)
                   {
                
                    return pif->moveRandom(moveDist);
                   }
                

        
        
        }; // class CiRandomIteratorWrapper
        
        typedef CiRandomIteratorWrapper< ::cli::CCliPtr< INTERFACE_CLI_IRANDOMITERATOR     > >  CiRandomIterator;
        typedef CiRandomIteratorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IRANDOMITERATOR > >  CiRandomIterator_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; /* namespace cli */

#endif





#endif /* CLI_COMMON_IITERATOR_H */
