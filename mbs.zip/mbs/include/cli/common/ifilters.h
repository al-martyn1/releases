#ifndef CLI_COMMON_IFILTERS_H
#define CLI_COMMON_IFILTERS_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/common/ifilters.h>", CLI_COMMON_IFILTERS_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_COMMON_IFILTERS_H
    #include <cli/common/ifilters.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iStreamFilter */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iStreamFilter;
        #ifndef INTERFACE_CLI_ISTREAMFILTER
            #define INTERFACE_CLI_ISTREAMFILTER       ::cli::iStreamFilter
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ISTREAMFILTER_PREDECLARED
    #define INTERFACE_CLI_ISTREAMFILTER_PREDECLARED
    typedef interface tag_cli_iStreamFilter  cli_iStreamFilter;
    #endif //INTERFACE_CLI_ISTREAMFILTER
    #ifndef INTERFACE_CLI_ISTREAMFILTER
        #define INTERFACE_CLI_ISTREAMFILTER       struct tag_cli_iStreamFilter
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISTREAMFILTER_IID
    #define INTERFACE_CLI_ISTREAMFILTER_IID    "/cli/iStreamFilter"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iStreamFilter
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ISTREAMFILTER
       #define INTERFACE_CLI_ISTREAMFILTER    ::cli::iStreamFilter
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iStreamFilter
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ISTREAMFILTER
       #define INTERFACE_CLI_ISTREAMFILTER    cli_iStreamFilter
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iStreamFilter methods */
            CLIMETHOD(nextStreamFilterGet) (THIS_ INTERFACE_CLI_ISTREAMFILTER**    _nextStreamFilter /* [out] ::cli::iStreamFilter* _nextStreamFilter  */) PURE;
            CLIMETHOD(nextStreamFilterSet) (THIS_ INTERFACE_CLI_ISTREAMFILTER*    _nextStreamFilter /* [in] ::cli::iStreamFilter*  _nextStreamFilter  */) PURE;
            CLIMETHOD(putByte) (THIS_ BYTE    b /* [in] byte  b  */
                                    , SIZE_T    pos /* [in] size_t  pos  */
                               ) PURE;
            CLIMETHOD(putData) (THIS_ const BYTE*    data /* [in,flat] byte  data[]  */
                                    , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                    , SIZE_T    pos /* [in] size_t  pos  */
                               ) PURE;
            CLIMETHOD(endOfStream) (THIS_ SIZE_T    pos /* [in] size_t  pos  */) PURE;
            CLIMETHOD(onDataError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                        , RCODE    errCode /* [in] rcode  errCode  */
                                        , SIZE_T    errPos /* [in] size_t  errPos  */
                                   ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iStreamFilter >
           {
            static char const * getName() { return INTERFACE_CLI_ISTREAMFILTER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iStreamFilter* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iStreamFilter > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iStreamFilter wrapper
        // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ISTREAMFILTER >
                                      */
                 >
        class CiStreamFilterWrapper
        {
            public:
        
                typedef  CiStreamFilterWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiStreamFilterWrapper() :
                   pif(0) {}
        
                CiStreamFilterWrapper( iStreamFilter *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiStreamFilterWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiStreamFilterWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiStreamFilterWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiStreamFilterWrapper(const CiStreamFilterWrapper &i) :
                    pif(i.pif) { }
        
                ~CiStreamFilterWrapper()  { }
        
                CiStreamFilterWrapper& operator=(const CiStreamFilterWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_ISTREAMFILTER* get_nextStreamFilter( )
                   {
                    INTERFACE_CLI_ISTREAMFILTER* tmpVal;
                    RCODE res = nextStreamFilterGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_nextStreamFilter( INTERFACE_CLI_ISTREAMFILTER* _nextStreamFilter
                                         )
                   {
                    RCODE res = nextStreamFilterSet( _nextStreamFilter );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_ISTREAMFILTER*, nextStreamFilter );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE nextStreamFilterGet( INTERFACE_CLI_ISTREAMFILTER**    _nextStreamFilter /* [out] ::cli::iStreamFilter* _nextStreamFilter  */)
                   {
                
                    return pif->nextStreamFilterGet(_nextStreamFilter);
                   }
                
                RCODE nextStreamFilterSet( INTERFACE_CLI_ISTREAMFILTER*    _nextStreamFilter /* [in] ::cli::iStreamFilter*  _nextStreamFilter  */)
                   {
                
                    return pif->nextStreamFilterSet(_nextStreamFilter);
                   }
                
                RCODE putByte( BYTE    b /* [in] byte  b  */
                             , SIZE_T    pos /* [in] size_t  pos  */
                             )
                   {
                
                
                    return pif->putByte(b, pos);
                   }
                
                RCODE putData( const BYTE*    data /* [in,flat] byte  data[]  */
                             , SIZE_T    dataLen /* [in] size_t  dataLen  */
                             , SIZE_T    pos /* [in] size_t  pos  */
                             )
                   {
                
                
                
                    return pif->putData(data, dataLen, pos);
                   }
                
                RCODE endOfStream( SIZE_T    pos /* [in] size_t  pos  */)
                   {
                
                    return pif->endOfStream(pos);
                   }
                
                RCODE onDataError( const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                 , RCODE    errCode /* [in] rcode  errCode  */
                                 , SIZE_T    errPos /* [in] size_t  errPos  */
                                 )
                   {
                
                
                
                    return pif->onDataError(fltName, errCode, errPos);
                   }
                

        
        
        }; // class CiStreamFilterWrapper
        
        typedef CiStreamFilterWrapper< ::cli::CCliPtr< INTERFACE_CLI_ISTREAMFILTER     > >  CiStreamFilter;
        typedef CiStreamFilterWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTREAMFILTER > >  CiStreamFilter_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iStreamFilterChain */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISTREAMFILTERCHAIN_IID
    #define INTERFACE_CLI_ISTREAMFILTERCHAIN_IID    "/cli/iStreamFilterChain"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iStreamFilterChain
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ISTREAMFILTERCHAIN
       #define INTERFACE_CLI_ISTREAMFILTERCHAIN    ::cli::iStreamFilterChain
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iStreamFilterChain
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ISTREAMFILTERCHAIN
       #define INTERFACE_CLI_ISTREAMFILTERCHAIN    cli_iStreamFilterChain
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iStreamFilterChain methods */
            CLIMETHOD(filtersGet) (THIS_ INTERFACE_CLI_ISTREAMFILTER**    _filters /* [out] ::cli::iStreamFilter* _filters  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  ) PURE;
            CLIMETHOD(filtersSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(addFilter) (THIS_ INTERFACE_CLI_ISTREAMFILTER*    pf /* [in] ::cli::iStreamFilter*  pf  */) PURE;
            CLIMETHOD(removeFilter) (THIS_ INTERFACE_CLI_ISTREAMFILTER*    pf /* [in] ::cli::iStreamFilter*  pf  */) PURE;
            CLIMETHOD(removeFilterByIndex) (THIS_ SIZE_T    filterIndex /* [in] size_t  filterIndex  */) PURE;
            CLIMETHOD(clearFilters) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iStreamFilterChain >
           {
            static char const * getName() { return INTERFACE_CLI_ISTREAMFILTERCHAIN_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iStreamFilterChain* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iStreamFilterChain > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iStreamFilterChain wrapper
        // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ISTREAMFILTERCHAIN >
                                      */
                 >
        class CiStreamFilterChainWrapper
        {
            public:
        
                typedef  CiStreamFilterChainWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiStreamFilterChainWrapper() :
                   pif(0) {}
        
                CiStreamFilterChainWrapper( iStreamFilterChain *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiStreamFilterChainWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiStreamFilterChainWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiStreamFilterChainWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiStreamFilterChainWrapper(const CiStreamFilterChainWrapper &i) :
                    pif(i.pif) { }
        
                ~CiStreamFilterChainWrapper()  { }
        
                CiStreamFilterChainWrapper& operator=(const CiStreamFilterChainWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_ISTREAMFILTER* get_filters( SIZE_T idx1 )
                   {
                    INTERFACE_CLI_ISTREAMFILTER* tmpVal;
                    RCODE res = filtersGet( &tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_filters(  )
                   {
                    SIZE_T size;
                    RCODE res = filtersSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, INTERFACE_CLI_ISTREAMFILTER*, filters, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE filtersGet( INTERFACE_CLI_ISTREAMFILTER**    _filters /* [out] ::cli::iStreamFilter* _filters  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                )
                   {
                
                
                    return pif->filtersGet(_filters, idx1);
                   }
                
                RCODE filtersSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->filtersSize(_size);
                   }
                
                RCODE addFilter( INTERFACE_CLI_ISTREAMFILTER*    pf /* [in] ::cli::iStreamFilter*  pf  */)
                   {
                
                    return pif->addFilter(pf);
                   }
                
                RCODE removeFilter( INTERFACE_CLI_ISTREAMFILTER*    pf /* [in] ::cli::iStreamFilter*  pf  */)
                   {
                
                    return pif->removeFilter(pf);
                   }
                
                RCODE removeFilterByIndex( SIZE_T    filterIndex /* [in] size_t  filterIndex  */)
                   {
                
                    return pif->removeFilterByIndex(filterIndex);
                   }
                
                RCODE clearFilters( )
                   {
                    return pif->clearFilters();
                   }
                

        
        
        }; // class CiStreamFilterChainWrapper
        
        typedef CiStreamFilterChainWrapper< ::cli::CCliPtr< INTERFACE_CLI_ISTREAMFILTERCHAIN     > >  CiStreamFilterChain;
        typedef CiStreamFilterChainWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTREAMFILTERCHAIN > >  CiStreamFilterChain_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iTextFilter */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iTextFilter;
        #ifndef INTERFACE_CLI_ITEXTFILTER
            #define INTERFACE_CLI_ITEXTFILTER         ::cli::iTextFilter
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ITEXTFILTER_PREDECLARED
    #define INTERFACE_CLI_ITEXTFILTER_PREDECLARED
    typedef interface tag_cli_iTextFilter    cli_iTextFilter;
    #endif //INTERFACE_CLI_ITEXTFILTER
    #ifndef INTERFACE_CLI_ITEXTFILTER
        #define INTERFACE_CLI_ITEXTFILTER         struct tag_cli_iTextFilter
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITEXTFILTER_IID
    #define INTERFACE_CLI_ITEXTFILTER_IID    "/cli/iTextFilter"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTextFilter
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ITEXTFILTER
       #define INTERFACE_CLI_ITEXTFILTER    ::cli::iTextFilter
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTextFilter
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ITEXTFILTER
       #define INTERFACE_CLI_ITEXTFILTER    cli_iTextFilter
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iTextFilter methods */
            CLIMETHOD(nextTextFilterGet) (THIS_ INTERFACE_CLI_ITEXTFILTER**    _nextTextFilter /* [out] ::cli::iTextFilter* _nextTextFilter  */) PURE;
            CLIMETHOD(nextTextFilterSet) (THIS_ INTERFACE_CLI_ITEXTFILTER*    _nextTextFilter /* [in] ::cli::iTextFilter*  _nextTextFilter  */) PURE;
            CLIMETHOD(useOwnNumberingGet) (THIS_ BOOL*    _useOwnNumbering /* [out] bool _useOwnNumbering  */) PURE;
            CLIMETHOD(useOwnNumberingSet) (THIS_ BOOL    _useOwnNumbering /* [in] bool  _useOwnNumbering  */) PURE;
            CLIMETHOD(putChar) (THIS_ WCHAR    ch /* [in] wchar  ch  */
                                    , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                    , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                    , SIZE_T    linePos /* [in] size_t  linePos  */
                               ) PURE;
            CLIMETHOD(putString) (THIS_ const CLISTR*     str
                                      , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                      , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                      , SIZE_T    linePos /* [in] size_t  linePos  */
                                 ) PURE;
            CLIMETHOD(putStringChars) (THIS_ const WCHAR*    dataBuf /* [in,flat] wchar  dataBuf[]  */
                                           , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                           , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                           , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                           , SIZE_T    linePos /* [in] size_t  linePos  */
                                      ) PURE;
            CLIMETHOD(endOfText) (THIS_ SIZE_T    streamPos /* [in] size_t  streamPos  */
                                      , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                      , SIZE_T    linePos /* [in] size_t  linePos  */
                                 ) PURE;
            CLIMETHOD(onTextError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                        , RCODE    errCode /* [in] rcode  errCode  */
                                        , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                        , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                        , SIZE_T    linePos /* [in] size_t  linePos  */
                                   ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTextFilter >
           {
            static char const * getName() { return INTERFACE_CLI_ITEXTFILTER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTextFilter* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTextFilter > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iTextFilter wrapper
        // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ITEXTFILTER >
                                      */
                 >
        class CiTextFilterWrapper
        {
            public:
        
                typedef  CiTextFilterWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTextFilterWrapper() :
                   pif(0) {}
        
                CiTextFilterWrapper( iTextFilter *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTextFilterWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTextFilterWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTextFilterWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTextFilterWrapper(const CiTextFilterWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTextFilterWrapper()  { }
        
                CiTextFilterWrapper& operator=(const CiTextFilterWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_ITEXTFILTER* get_nextTextFilter( )
                   {
                    INTERFACE_CLI_ITEXTFILTER* tmpVal;
                    RCODE res = nextTextFilterGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_nextTextFilter( INTERFACE_CLI_ITEXTFILTER* _nextTextFilter
                                       )
                   {
                    RCODE res = nextTextFilterSet( _nextTextFilter );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_ITEXTFILTER*, nextTextFilter );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE nextTextFilterGet( INTERFACE_CLI_ITEXTFILTER**    _nextTextFilter /* [out] ::cli::iTextFilter* _nextTextFilter  */)
                   {
                
                    return pif->nextTextFilterGet(_nextTextFilter);
                   }
                
                RCODE nextTextFilterSet( INTERFACE_CLI_ITEXTFILTER*    _nextTextFilter /* [in] ::cli::iTextFilter*  _nextTextFilter  */)
                   {
                
                    return pif->nextTextFilterSet(_nextTextFilter);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                BOOL get_useOwnNumbering( )
                   {
                    BOOL tmpVal;
                    RCODE res = useOwnNumberingGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_useOwnNumbering( BOOL _useOwnNumbering
                                        )
                   {
                    RCODE res = useOwnNumberingSet( _useOwnNumbering );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, useOwnNumbering );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE useOwnNumberingGet( BOOL*    _useOwnNumbering /* [out] bool _useOwnNumbering  */)
                   {
                
                    return pif->useOwnNumberingGet(_useOwnNumbering);
                   }
                
                RCODE useOwnNumberingSet( BOOL    _useOwnNumbering /* [in] bool  _useOwnNumbering  */)
                   {
                
                    return pif->useOwnNumberingSet(_useOwnNumbering);
                   }
                
                RCODE putChar( WCHAR    ch /* [in] wchar  ch  */
                             , SIZE_T    streamPos /* [in] size_t  streamPos  */
                             , SIZE_T    lineNo /* [in] size_t  lineNo  */
                             , SIZE_T    linePos /* [in] size_t  linePos  */
                             )
                   {
                
                
                
                
                    return pif->putChar(ch, streamPos, lineNo, linePos);
                   }
                
                RCODE putString( const ::std::wstring    &str
                               , SIZE_T    streamPos /* [in] size_t  streamPos  */
                               , SIZE_T    lineNo /* [in] size_t  lineNo  */
                               , SIZE_T    linePos /* [in] size_t  linePos  */
                               )
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                
                
                
                    return pif->putString(&tmp_str, streamPos, lineNo, linePos);
                   }
                
                RCODE putStringChars( const WCHAR*    dataBuf /* [in,flat] wchar  dataBuf[]  */
                                    , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                    , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                    , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                    , SIZE_T    linePos /* [in] size_t  linePos  */
                                    )
                   {
                
                
                
                
                
                    return pif->putStringChars(dataBuf, dataLen, streamPos, lineNo, linePos);
                   }
                
                RCODE endOfText( SIZE_T    streamPos /* [in] size_t  streamPos  */
                               , SIZE_T    lineNo /* [in] size_t  lineNo  */
                               , SIZE_T    linePos /* [in] size_t  linePos  */
                               )
                   {
                
                
                
                    return pif->endOfText(streamPos, lineNo, linePos);
                   }
                
                RCODE onTextError( const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                 , RCODE    errCode /* [in] rcode  errCode  */
                                 , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                 , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                 , SIZE_T    linePos /* [in] size_t  linePos  */
                                 )
                   {
                
                
                
                
                
                    return pif->onTextError(fltName, errCode, streamPos, lineNo, linePos);
                   }
                

        
        
        }; // class CiTextFilterWrapper
        
        typedef CiTextFilterWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITEXTFILTER     > >  CiTextFilter;
        typedef CiTextFilterWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITEXTFILTER > >  CiTextFilter_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iTextFilterChain */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITEXTFILTERCHAIN_IID
    #define INTERFACE_CLI_ITEXTFILTERCHAIN_IID    "/cli/iTextFilterChain"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTextFilterChain
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ITEXTFILTERCHAIN
       #define INTERFACE_CLI_ITEXTFILTERCHAIN    ::cli::iTextFilterChain
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTextFilterChain
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ITEXTFILTERCHAIN
       #define INTERFACE_CLI_ITEXTFILTERCHAIN    cli_iTextFilterChain
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iTextFilterChain methods */
            CLIMETHOD(filtersGet) (THIS_ INTERFACE_CLI_ITEXTFILTER**    _filters /* [out] ::cli::iTextFilter* _filters  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  ) PURE;
            CLIMETHOD(filtersSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(addFilter) (THIS_ INTERFACE_CLI_ITEXTFILTER*    pf /* [in] ::cli::iTextFilter*  pf  */) PURE;
            CLIMETHOD(removeFilter) (THIS_ INTERFACE_CLI_ITEXTFILTER*    pf /* [in] ::cli::iTextFilter*  pf  */) PURE;
            CLIMETHOD(removeFilterByIndex) (THIS_ SIZE_T    filterIndex /* [in] size_t  filterIndex  */) PURE;
            CLIMETHOD(clearFilters) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTextFilterChain >
           {
            static char const * getName() { return INTERFACE_CLI_ITEXTFILTERCHAIN_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTextFilterChain* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTextFilterChain > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iTextFilterChain wrapper
        // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ITEXTFILTERCHAIN >
                                      */
                 >
        class CiTextFilterChainWrapper
        {
            public:
        
                typedef  CiTextFilterChainWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTextFilterChainWrapper() :
                   pif(0) {}
        
                CiTextFilterChainWrapper( iTextFilterChain *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTextFilterChainWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTextFilterChainWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTextFilterChainWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTextFilterChainWrapper(const CiTextFilterChainWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTextFilterChainWrapper()  { }
        
                CiTextFilterChainWrapper& operator=(const CiTextFilterChainWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_ITEXTFILTER* get_filters( SIZE_T idx1 )
                   {
                    INTERFACE_CLI_ITEXTFILTER* tmpVal;
                    RCODE res = filtersGet( &tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_filters(  )
                   {
                    SIZE_T size;
                    RCODE res = filtersSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, INTERFACE_CLI_ITEXTFILTER*, filters, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE filtersGet( INTERFACE_CLI_ITEXTFILTER**    _filters /* [out] ::cli::iTextFilter* _filters  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                                )
                   {
                
                
                    return pif->filtersGet(_filters, idx1);
                   }
                
                RCODE filtersSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->filtersSize(_size);
                   }
                
                RCODE addFilter( INTERFACE_CLI_ITEXTFILTER*    pf /* [in] ::cli::iTextFilter*  pf  */)
                   {
                
                    return pif->addFilter(pf);
                   }
                
                RCODE removeFilter( INTERFACE_CLI_ITEXTFILTER*    pf /* [in] ::cli::iTextFilter*  pf  */)
                   {
                
                    return pif->removeFilter(pf);
                   }
                
                RCODE removeFilterByIndex( SIZE_T    filterIndex /* [in] size_t  filterIndex  */)
                   {
                
                    return pif->removeFilterByIndex(filterIndex);
                   }
                
                RCODE clearFilters( )
                   {
                    return pif->clearFilters();
                   }
                

        
        
        }; // class CiTextFilterChainWrapper
        
        typedef CiTextFilterChainWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITEXTFILTERCHAIN     > >  CiTextFilterChain;
        typedef CiTextFilterChainWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITEXTFILTERCHAIN > >  CiTextFilterChain_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iTextDecoder */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITEXTDECODER_IID
    #define INTERFACE_CLI_ITEXTDECODER_IID    "/cli/iTextDecoder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTextDecoder
    #define BASE_INTERFACE ::cli::iStreamFilter
    #ifndef INTERFACE_CLI_ITEXTDECODER
       #define INTERFACE_CLI_ITEXTDECODER    ::cli::iTextDecoder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTextDecoder
    // Only first interface declared as base
    #define BASE_INTERFACE cli_iStreamFilter
    #ifndef INTERFACE_CLI_ITEXTDECODER
       #define INTERFACE_CLI_ITEXTDECODER    cli_iTextDecoder
    #endif
#endif

        CLI_DECLARE_INTERFACE2_(INTERFACE, BASE_INTERFACE, INTERFACE_CLI_ITEXTFILTER)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iStreamFilter methods */
            CLIMETHOD(nextStreamFilterGet) (THIS_ INTERFACE_CLI_ISTREAMFILTER**    _nextStreamFilter /* [out] ::cli::iStreamFilter* _nextStreamFilter  */) PURE;
            CLIMETHOD(nextStreamFilterSet) (THIS_ INTERFACE_CLI_ISTREAMFILTER*    _nextStreamFilter /* [in] ::cli::iStreamFilter*  _nextStreamFilter  */) PURE;
            CLIMETHOD(putByte) (THIS_ BYTE    b /* [in] byte  b  */
                                    , SIZE_T    pos /* [in] size_t  pos  */
                               ) PURE;
            CLIMETHOD(putData) (THIS_ const BYTE*    data /* [in,flat] byte  data[]  */
                                    , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                    , SIZE_T    pos /* [in] size_t  pos  */
                               ) PURE;
            CLIMETHOD(endOfStream) (THIS_ SIZE_T    pos /* [in] size_t  pos  */) PURE;
            CLIMETHOD(onDataError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                        , RCODE    errCode /* [in] rcode  errCode  */
                                        , SIZE_T    errPos /* [in] size_t  errPos  */
                                   ) PURE;
            
            /* interface ::cli::iTextFilter methods */
            CLIMETHOD(nextTextFilterGet) (THIS_ INTERFACE_CLI_ITEXTFILTER**    _nextTextFilter /* [out] ::cli::iTextFilter* _nextTextFilter  */) PURE;
            CLIMETHOD(nextTextFilterSet) (THIS_ INTERFACE_CLI_ITEXTFILTER*    _nextTextFilter /* [in] ::cli::iTextFilter*  _nextTextFilter  */) PURE;
            CLIMETHOD(useOwnNumberingGet) (THIS_ BOOL*    _useOwnNumbering /* [out] bool _useOwnNumbering  */) PURE;
            CLIMETHOD(useOwnNumberingSet) (THIS_ BOOL    _useOwnNumbering /* [in] bool  _useOwnNumbering  */) PURE;
            CLIMETHOD(putChar) (THIS_ WCHAR    ch /* [in] wchar  ch  */
                                    , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                    , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                    , SIZE_T    linePos /* [in] size_t  linePos  */
                               ) PURE;
            CLIMETHOD(putString) (THIS_ const CLISTR*     str
                                      , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                      , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                      , SIZE_T    linePos /* [in] size_t  linePos  */
                                 ) PURE;
            CLIMETHOD(putStringChars) (THIS_ const WCHAR*    dataBuf /* [in,flat] wchar  dataBuf[]  */
                                           , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                           , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                           , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                           , SIZE_T    linePos /* [in] size_t  linePos  */
                                      ) PURE;
            CLIMETHOD(endOfText) (THIS_ SIZE_T    streamPos /* [in] size_t  streamPos  */
                                      , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                      , SIZE_T    linePos /* [in] size_t  linePos  */
                                 ) PURE;
            CLIMETHOD(onTextError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                        , RCODE    errCode /* [in] rcode  errCode  */
                                        , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                        , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                        , SIZE_T    linePos /* [in] size_t  linePos  */
                                   ) PURE;
            
            /* interface ::cli::iTextDecoder methods */
            CLIMETHOD(streamPosGet) (THIS_ SIZE_T*    _streamPos /* [out] size_t _streamPos  */) PURE;
            CLIMETHOD(streamPosSet) (THIS_ SIZE_T    _streamPos /* [in] size_t  _streamPos  */) PURE;
            CLIMETHOD(lineNoGet) (THIS_ SIZE_T*    _lineNo /* [out] size_t _lineNo  */) PURE;
            CLIMETHOD(lineNoSet) (THIS_ SIZE_T    _lineNo /* [in] size_t  _lineNo  */) PURE;
            CLIMETHOD(posNoGet) (THIS_ SIZE_T*    _posNo /* [out] size_t _posNo  */) PURE;
            CLIMETHOD(posNoSet) (THIS_ SIZE_T    _posNo /* [in] size_t  _posNo  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTextDecoder >
           {
            static char const * getName() { return INTERFACE_CLI_ITEXTDECODER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTextDecoder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTextDecoder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iTextDecoder wrapper
        // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ITEXTDECODER >
                                      */
                 >
        class CiTextDecoderWrapper
        {
            public:
        
                typedef  CiTextDecoderWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTextDecoderWrapper() :
                   pif(0) {}
        
                CiTextDecoderWrapper( iTextDecoder *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTextDecoderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTextDecoderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTextDecoderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTextDecoderWrapper(const CiTextDecoderWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTextDecoderWrapper()  { }
        
                CiTextDecoderWrapper& operator=(const CiTextDecoderWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_ISTREAMFILTER* get_nextStreamFilter( )
                   {
                    INTERFACE_CLI_ISTREAMFILTER* tmpVal;
                    RCODE res = nextStreamFilterGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_nextStreamFilter( INTERFACE_CLI_ISTREAMFILTER* _nextStreamFilter
                                         )
                   {
                    RCODE res = nextStreamFilterSet( _nextStreamFilter );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_ISTREAMFILTER*, nextStreamFilter );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE nextStreamFilterGet( INTERFACE_CLI_ISTREAMFILTER**    _nextStreamFilter /* [out] ::cli::iStreamFilter* _nextStreamFilter  */)
                   {
                
                    return pif->nextStreamFilterGet(_nextStreamFilter);
                   }
                
                RCODE nextStreamFilterSet( INTERFACE_CLI_ISTREAMFILTER*    _nextStreamFilter /* [in] ::cli::iStreamFilter*  _nextStreamFilter  */)
                   {
                
                    return pif->nextStreamFilterSet(_nextStreamFilter);
                   }
                
                RCODE putByte( BYTE    b /* [in] byte  b  */
                             , SIZE_T    pos /* [in] size_t  pos  */
                             )
                   {
                
                
                    return pif->putByte(b, pos);
                   }
                
                RCODE putData( const BYTE*    data /* [in,flat] byte  data[]  */
                             , SIZE_T    dataLen /* [in] size_t  dataLen  */
                             , SIZE_T    pos /* [in] size_t  pos  */
                             )
                   {
                
                
                
                    return pif->putData(data, dataLen, pos);
                   }
                
                RCODE endOfStream( SIZE_T    pos /* [in] size_t  pos  */)
                   {
                
                    return pif->endOfStream(pos);
                   }
                
                RCODE onDataError( const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                 , RCODE    errCode /* [in] rcode  errCode  */
                                 , SIZE_T    errPos /* [in] size_t  errPos  */
                                 )
                   {
                
                
                
                    return pif->onDataError(fltName, errCode, errPos);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_ITEXTFILTER* get_nextTextFilter( )
                   {
                    INTERFACE_CLI_ITEXTFILTER* tmpVal;
                    RCODE res = nextTextFilterGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_nextTextFilter( INTERFACE_CLI_ITEXTFILTER* _nextTextFilter
                                       )
                   {
                    RCODE res = nextTextFilterSet( _nextTextFilter );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_ITEXTFILTER*, nextTextFilter );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE nextTextFilterGet( INTERFACE_CLI_ITEXTFILTER**    _nextTextFilter /* [out] ::cli::iTextFilter* _nextTextFilter  */)
                   {
                
                    return pif->nextTextFilterGet(_nextTextFilter);
                   }
                
                RCODE nextTextFilterSet( INTERFACE_CLI_ITEXTFILTER*    _nextTextFilter /* [in] ::cli::iTextFilter*  _nextTextFilter  */)
                   {
                
                    return pif->nextTextFilterSet(_nextTextFilter);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                BOOL get_useOwnNumbering( )
                   {
                    BOOL tmpVal;
                    RCODE res = useOwnNumberingGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_useOwnNumbering( BOOL _useOwnNumbering
                                        )
                   {
                    RCODE res = useOwnNumberingSet( _useOwnNumbering );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, useOwnNumbering );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE useOwnNumberingGet( BOOL*    _useOwnNumbering /* [out] bool _useOwnNumbering  */)
                   {
                
                    return pif->useOwnNumberingGet(_useOwnNumbering);
                   }
                
                RCODE useOwnNumberingSet( BOOL    _useOwnNumbering /* [in] bool  _useOwnNumbering  */)
                   {
                
                    return pif->useOwnNumberingSet(_useOwnNumbering);
                   }
                
                RCODE putChar( WCHAR    ch /* [in] wchar  ch  */
                             , SIZE_T    streamPos /* [in] size_t  streamPos  */
                             , SIZE_T    lineNo /* [in] size_t  lineNo  */
                             , SIZE_T    linePos /* [in] size_t  linePos  */
                             )
                   {
                
                
                
                
                    return pif->putChar(ch, streamPos, lineNo, linePos);
                   }
                
                RCODE putString( const ::std::wstring    &str
                               , SIZE_T    streamPos /* [in] size_t  streamPos  */
                               , SIZE_T    lineNo /* [in] size_t  lineNo  */
                               , SIZE_T    linePos /* [in] size_t  linePos  */
                               )
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                
                
                
                    return pif->putString(&tmp_str, streamPos, lineNo, linePos);
                   }
                
                RCODE putStringChars( const WCHAR*    dataBuf /* [in,flat] wchar  dataBuf[]  */
                                    , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                    , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                    , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                    , SIZE_T    linePos /* [in] size_t  linePos  */
                                    )
                   {
                
                
                
                
                
                    return pif->putStringChars(dataBuf, dataLen, streamPos, lineNo, linePos);
                   }
                
                RCODE endOfText( SIZE_T    streamPos /* [in] size_t  streamPos  */
                               , SIZE_T    lineNo /* [in] size_t  lineNo  */
                               , SIZE_T    linePos /* [in] size_t  linePos  */
                               )
                   {
                
                
                
                    return pif->endOfText(streamPos, lineNo, linePos);
                   }
                
                RCODE onTextError( const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                 , RCODE    errCode /* [in] rcode  errCode  */
                                 , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                 , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                 , SIZE_T    linePos /* [in] size_t  linePos  */
                                 )
                   {
                
                
                
                
                
                    return pif->onTextError(fltName, errCode, streamPos, lineNo, linePos);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_streamPos( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = streamPosGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_streamPos( SIZE_T _streamPos
                                  )
                   {
                    RCODE res = streamPosSet( _streamPos );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, streamPos );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE streamPosGet( SIZE_T*    _streamPos /* [out] size_t _streamPos  */)
                   {
                
                    return pif->streamPosGet(_streamPos);
                   }
                
                RCODE streamPosSet( SIZE_T    _streamPos /* [in] size_t  _streamPos  */)
                   {
                
                    return pif->streamPosSet(_streamPos);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_lineNo( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = lineNoGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_lineNo( SIZE_T _lineNo
                               )
                   {
                    RCODE res = lineNoSet( _lineNo );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, lineNo );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE lineNoGet( SIZE_T*    _lineNo /* [out] size_t _lineNo  */)
                   {
                
                    return pif->lineNoGet(_lineNo);
                   }
                
                RCODE lineNoSet( SIZE_T    _lineNo /* [in] size_t  _lineNo  */)
                   {
                
                    return pif->lineNoSet(_lineNo);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_posNo( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = posNoGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_posNo( SIZE_T _posNo
                              )
                   {
                    RCODE res = posNoSet( _posNo );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, posNo );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE posNoGet( SIZE_T*    _posNo /* [out] size_t _posNo  */)
                   {
                
                    return pif->posNoGet(_posNo);
                   }
                
                RCODE posNoSet( SIZE_T    _posNo /* [in] size_t  _posNo  */)
                   {
                
                    return pif->posNoSet(_posNo);
                   }
                

        
        
        }; // class CiTextDecoderWrapper
        
        typedef CiTextDecoderWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITEXTDECODER     > >  CiTextDecoder;
        typedef CiTextDecoderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITEXTDECODER > >  CiTextDecoder_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iTextEncoder */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ITEXTENCODER_IID
    #define INTERFACE_CLI_ITEXTENCODER_IID    "/cli/iTextEncoder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iTextEncoder
    #define BASE_INTERFACE ::cli::iTextFilter
    #ifndef INTERFACE_CLI_ITEXTENCODER
       #define INTERFACE_CLI_ITEXTENCODER    ::cli::iTextEncoder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iTextEncoder
    #define BASE_INTERFACE cli_iTextFilter
    #ifndef INTERFACE_CLI_ITEXTENCODER
       #define INTERFACE_CLI_ITEXTENCODER    cli_iTextEncoder
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iTextFilter methods */
            CLIMETHOD(nextTextFilterGet) (THIS_ INTERFACE_CLI_ITEXTFILTER**    _nextTextFilter /* [out] ::cli::iTextFilter* _nextTextFilter  */) PURE;
            CLIMETHOD(nextTextFilterSet) (THIS_ INTERFACE_CLI_ITEXTFILTER*    _nextTextFilter /* [in] ::cli::iTextFilter*  _nextTextFilter  */) PURE;
            CLIMETHOD(useOwnNumberingGet) (THIS_ BOOL*    _useOwnNumbering /* [out] bool _useOwnNumbering  */) PURE;
            CLIMETHOD(useOwnNumberingSet) (THIS_ BOOL    _useOwnNumbering /* [in] bool  _useOwnNumbering  */) PURE;
            CLIMETHOD(putChar) (THIS_ WCHAR    ch /* [in] wchar  ch  */
                                    , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                    , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                    , SIZE_T    linePos /* [in] size_t  linePos  */
                               ) PURE;
            CLIMETHOD(putString) (THIS_ const CLISTR*     str
                                      , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                      , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                      , SIZE_T    linePos /* [in] size_t  linePos  */
                                 ) PURE;
            CLIMETHOD(putStringChars) (THIS_ const WCHAR*    dataBuf /* [in,flat] wchar  dataBuf[]  */
                                           , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                           , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                           , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                           , SIZE_T    linePos /* [in] size_t  linePos  */
                                      ) PURE;
            CLIMETHOD(endOfText) (THIS_ SIZE_T    streamPos /* [in] size_t  streamPos  */
                                      , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                      , SIZE_T    linePos /* [in] size_t  linePos  */
                                 ) PURE;
            CLIMETHOD(onTextError) (THIS_ const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                        , RCODE    errCode /* [in] rcode  errCode  */
                                        , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                        , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                        , SIZE_T    linePos /* [in] size_t  linePos  */
                                   ) PURE;
            
            /* interface ::cli::iTextEncoder methods */
            CLIMETHOD(encodingOptionsGet) (THIS_ CLISTR*           _encodingOptions
                                               , const CLISTR*     idx1
                                          ) PURE;
            CLIMETHOD(encodingOptionsSet) (THIS_ const CLISTR*     _encodingOptions
                                               , const CLISTR*     idx1
                                          ) PURE;
            CLIMETHOD(encodingOptionsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(validateEncodingOption) (THIS_ const CLISTR*     optName
                                                   , const CLISTR*     optValue
                                              ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iTextEncoder >
           {
            static char const * getName() { return INTERFACE_CLI_ITEXTENCODER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iTextEncoder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iTextEncoder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iTextEncoder wrapper
        // generated from F:\work\cliponents\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ITEXTENCODER >
                                      */
                 >
        class CiTextEncoderWrapper
        {
            public:
        
                typedef  CiTextEncoderWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiTextEncoderWrapper() :
                   pif(0) {}
        
                CiTextEncoderWrapper( iTextEncoder *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiTextEncoderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiTextEncoderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiTextEncoderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiTextEncoderWrapper(const CiTextEncoderWrapper &i) :
                    pif(i.pif) { }
        
                ~CiTextEncoderWrapper()  { }
        
                CiTextEncoderWrapper& operator=(const CiTextEncoderWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_ITEXTFILTER* get_nextTextFilter( )
                   {
                    INTERFACE_CLI_ITEXTFILTER* tmpVal;
                    RCODE res = nextTextFilterGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_nextTextFilter( INTERFACE_CLI_ITEXTFILTER* _nextTextFilter
                                       )
                   {
                    RCODE res = nextTextFilterSet( _nextTextFilter );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_ITEXTFILTER*, nextTextFilter );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE nextTextFilterGet( INTERFACE_CLI_ITEXTFILTER**    _nextTextFilter /* [out] ::cli::iTextFilter* _nextTextFilter  */)
                   {
                
                    return pif->nextTextFilterGet(_nextTextFilter);
                   }
                
                RCODE nextTextFilterSet( INTERFACE_CLI_ITEXTFILTER*    _nextTextFilter /* [in] ::cli::iTextFilter*  _nextTextFilter  */)
                   {
                
                    return pif->nextTextFilterSet(_nextTextFilter);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                BOOL get_useOwnNumbering( )
                   {
                    BOOL tmpVal;
                    RCODE res = useOwnNumberingGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_useOwnNumbering( BOOL _useOwnNumbering
                                        )
                   {
                    RCODE res = useOwnNumberingSet( _useOwnNumbering );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, useOwnNumbering );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE useOwnNumberingGet( BOOL*    _useOwnNumbering /* [out] bool _useOwnNumbering  */)
                   {
                
                    return pif->useOwnNumberingGet(_useOwnNumbering);
                   }
                
                RCODE useOwnNumberingSet( BOOL    _useOwnNumbering /* [in] bool  _useOwnNumbering  */)
                   {
                
                    return pif->useOwnNumberingSet(_useOwnNumbering);
                   }
                
                RCODE putChar( WCHAR    ch /* [in] wchar  ch  */
                             , SIZE_T    streamPos /* [in] size_t  streamPos  */
                             , SIZE_T    lineNo /* [in] size_t  lineNo  */
                             , SIZE_T    linePos /* [in] size_t  linePos  */
                             )
                   {
                
                
                
                
                    return pif->putChar(ch, streamPos, lineNo, linePos);
                   }
                
                RCODE putString( const ::std::wstring    &str
                               , SIZE_T    streamPos /* [in] size_t  streamPos  */
                               , SIZE_T    lineNo /* [in] size_t  lineNo  */
                               , SIZE_T    linePos /* [in] size_t  linePos  */
                               )
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                
                
                
                    return pif->putString(&tmp_str, streamPos, lineNo, linePos);
                   }
                
                RCODE putStringChars( const WCHAR*    dataBuf /* [in,flat] wchar  dataBuf[]  */
                                    , SIZE_T    dataLen /* [in] size_t  dataLen  */
                                    , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                    , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                    , SIZE_T    linePos /* [in] size_t  linePos  */
                                    )
                   {
                
                
                
                
                
                    return pif->putStringChars(dataBuf, dataLen, streamPos, lineNo, linePos);
                   }
                
                RCODE endOfText( SIZE_T    streamPos /* [in] size_t  streamPos  */
                               , SIZE_T    lineNo /* [in] size_t  lineNo  */
                               , SIZE_T    linePos /* [in] size_t  linePos  */
                               )
                   {
                
                
                
                    return pif->endOfText(streamPos, lineNo, linePos);
                   }
                
                RCODE onTextError( const WCHAR*    fltName /* [in,flat] wchar  fltName[]  */
                                 , RCODE    errCode /* [in] rcode  errCode  */
                                 , SIZE_T    streamPos /* [in] size_t  streamPos  */
                                 , SIZE_T    lineNo /* [in] size_t  lineNo  */
                                 , SIZE_T    linePos /* [in] size_t  linePos  */
                                 )
                   {
                
                
                
                
                
                    return pif->onTextError(fltName, errCode, streamPos, lineNo, linePos);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_encodingOptions( const ::std::wstring &idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = encodingOptionsGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_encodingOptions( const ::std::wstring &idx1 , const ::std::wstring &_encodingOptions
                                        )
                   { // MS style - index goes before value, need reorder
                    RCODE res = encodingOptionsSet( _encodingOptions, idx1 );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                SIZE_T size_encodingOptions(  )
                   {
                    SIZE_T size;
                    RCODE res = encodingOptionsSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW_IDX1(wrapper_type, ::std::wstring, encodingOptions, ::std::wstring );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE encodingOptionsGet( ::std::wstring    &_encodingOptions
                                        , const ::std::wstring    &idx1
                                        )
                   {
                    CCliStr tmp__encodingOptions; CCliStr_init( tmp__encodingOptions );
                    CCliStr tmp_idx1; CCliStr_lightCopyTo( tmp_idx1, idx1);
                    RCODE res = pif->encodingOptionsGet(&tmp__encodingOptions, &tmp_idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _encodingOptions, tmp__encodingOptions);
                       }
                    return res;
                   }
                
                RCODE encodingOptionsSet( const ::std::wstring    &_encodingOptions
                                        , const ::std::wstring    &idx1
                                        )
                   {
                    CCliStr tmp__encodingOptions; CCliStr_lightCopyTo( tmp__encodingOptions, _encodingOptions);
                    CCliStr tmp_idx1; CCliStr_lightCopyTo( tmp_idx1, idx1);
                    return pif->encodingOptionsSet(&tmp__encodingOptions, &tmp_idx1);
                   }
                
                RCODE encodingOptionsSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->encodingOptionsSize(_size);
                   }
                
                RCODE validateEncodingOption( const ::std::wstring    &optName
                                            , const ::std::wstring    &optValue
                                            )
                   {
                    CCliStr tmp_optName; CCliStr_lightCopyTo( tmp_optName, optName);
                    CCliStr tmp_optValue; CCliStr_lightCopyTo( tmp_optValue, optValue);
                    return pif->validateEncodingOption(&tmp_optName, &tmp_optValue);
                   }
                

        
        
        }; // class CiTextEncoderWrapper
        
        typedef CiTextEncoderWrapper< ::cli::CCliPtr< INTERFACE_CLI_ITEXTENCODER     > >  CiTextEncoder;
        typedef CiTextEncoderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ITEXTENCODER > >  CiTextEncoder_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_COMMON_IFILTERS_H */
