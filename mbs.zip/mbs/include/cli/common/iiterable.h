#ifndef CLI_COMMON_IITERABLE_H
#define CLI_COMMON_IITERABLE_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/common/iiterable.h>", CLI_COMMON_IITERABLE_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_COMMON_IITERABLE_H
    #include <cli/common/iiterable.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iIterable */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IITERABLE_IID
    #define INTERFACE_CLI_IITERABLE_IID    "/cli/iIterable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iIterable
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IITERABLE
       #define INTERFACE_CLI_IITERABLE    ::cli::iIterable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iIterable
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IITERABLE
       #define INTERFACE_CLI_IITERABLE    cli_iIterable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iIterable methods */
            CLIMETHOD_(BOOL, isBegin) (THIS) PURE;
            CLIMETHOD_(BOOL, isEnd) (THIS) PURE;
            CLIMETHOD(getDataPtr) (THIS_ VOID**    pData /* [out] void* pData  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iIterable >
           {
            static char const * getName() { return INTERFACE_CLI_IITERABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iIterable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iIterable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iIterable wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IITERABLE >
                                      */
                 >
        class CiIterableWrapper
        {
            public:
        
                typedef  CiIterableWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiIterableWrapper() :
                   pif(0) {}
        
                CiIterableWrapper( iIterable *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiIterableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiIterableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiIterableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiIterableWrapper(const CiIterableWrapper &i) :
                    pif(i.pif) { }
        
                ~CiIterableWrapper()  { }
        
                CiIterableWrapper& operator=(const CiIterableWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                BOOL isBegin( )
                   {
                    return pif->isBegin();
                   }
                
                BOOL isEnd( )
                   {
                    return pif->isEnd();
                   }
                
                RCODE getDataPtr( VOID**    pData /* [out] void* pData  */)
                   {
                
                    return pif->getDataPtr(pData);
                   }
                

        
        
        }; // class CiIterableWrapper
        
        typedef CiIterableWrapper< ::cli::CCliPtr< INTERFACE_CLI_IITERABLE     > >  CiIterable;
        typedef CiIterableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IITERABLE > >  CiIterable_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iGenericIterable */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iIterable;
        #ifndef INTERFACE_CLI_IITERABLE
            #define INTERFACE_CLI_IITERABLE           ::cli::iIterable
        #endif

    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iIterable      cli_iIterable;
    #ifndef INTERFACE_CLI_IITERABLE
        #define INTERFACE_CLI_IITERABLE           struct tag_cli_iIterable
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IGENERICITERABLE_IID
    #define INTERFACE_CLI_IGENERICITERABLE_IID    "/cli/iGenericIterable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iGenericIterable
    #define BASE_INTERFACE ::cli::iIterable
    #ifndef INTERFACE_CLI_IGENERICITERABLE
       #define INTERFACE_CLI_IGENERICITERABLE    ::cli::iGenericIterable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iGenericIterable
    #define BASE_INTERFACE cli_iIterable
    #ifndef INTERFACE_CLI_IGENERICITERABLE
       #define INTERFACE_CLI_IGENERICITERABLE    cli_iGenericIterable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iIterable methods */
            CLIMETHOD_(BOOL, isBegin) (THIS) PURE;
            CLIMETHOD_(BOOL, isEnd) (THIS) PURE;
            CLIMETHOD(getDataPtr) (THIS_ VOID**    pData /* [out] void* pData  */) PURE;
            
            /* interface ::cli::iGenericIterable methods */
            CLIMETHOD(move) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iGenericIterable >
           {
            static char const * getName() { return INTERFACE_CLI_IGENERICITERABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iGenericIterable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iGenericIterable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iGenericIterable wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IGENERICITERABLE >
                                      */
                 >
        class CiGenericIterableWrapper
        {
            public:
        
                typedef  CiGenericIterableWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiGenericIterableWrapper() :
                   pif(0) {}
        
                CiGenericIterableWrapper( iGenericIterable *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiGenericIterableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiGenericIterableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiGenericIterableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiGenericIterableWrapper(const CiGenericIterableWrapper &i) :
                    pif(i.pif) { }
        
                ~CiGenericIterableWrapper()  { }
        
                CiGenericIterableWrapper& operator=(const CiGenericIterableWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                BOOL isBegin( )
                   {
                    return pif->isBegin();
                   }
                
                BOOL isEnd( )
                   {
                    return pif->isEnd();
                   }
                
                RCODE getDataPtr( VOID**    pData /* [out] void* pData  */)
                   {
                
                    return pif->getDataPtr(pData);
                   }
                
                RCODE move( )
                   {
                    return pif->move();
                   }
                

        
        
        }; // class CiGenericIterableWrapper
        
        typedef CiGenericIterableWrapper< ::cli::CCliPtr< INTERFACE_CLI_IGENERICITERABLE     > >  CiGenericIterable;
        typedef CiGenericIterableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IGENERICITERABLE > >  CiGenericIterable_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iForwardIterable */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IFORWARDITERABLE_IID
    #define INTERFACE_CLI_IFORWARDITERABLE_IID    "/cli/iForwardIterable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iForwardIterable
    #define BASE_INTERFACE ::cli::iIterable
    #ifndef INTERFACE_CLI_IFORWARDITERABLE
       #define INTERFACE_CLI_IFORWARDITERABLE    ::cli::iForwardIterable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iForwardIterable
    #define BASE_INTERFACE cli_iIterable
    #ifndef INTERFACE_CLI_IFORWARDITERABLE
       #define INTERFACE_CLI_IFORWARDITERABLE    cli_iForwardIterable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iIterable methods */
            CLIMETHOD_(BOOL, isBegin) (THIS) PURE;
            CLIMETHOD_(BOOL, isEnd) (THIS) PURE;
            CLIMETHOD(getDataPtr) (THIS_ VOID**    pData /* [out] void* pData  */) PURE;
            
            /* interface ::cli::iForwardIterable methods */
            CLIMETHOD(moveForward) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iForwardIterable >
           {
            static char const * getName() { return INTERFACE_CLI_IFORWARDITERABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iForwardIterable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iForwardIterable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iForwardIterable wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IFORWARDITERABLE >
                                      */
                 >
        class CiForwardIterableWrapper
        {
            public:
        
                typedef  CiForwardIterableWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiForwardIterableWrapper() :
                   pif(0) {}
        
                CiForwardIterableWrapper( iForwardIterable *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiForwardIterableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiForwardIterableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiForwardIterableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiForwardIterableWrapper(const CiForwardIterableWrapper &i) :
                    pif(i.pif) { }
        
                ~CiForwardIterableWrapper()  { }
        
                CiForwardIterableWrapper& operator=(const CiForwardIterableWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                BOOL isBegin( )
                   {
                    return pif->isBegin();
                   }
                
                BOOL isEnd( )
                   {
                    return pif->isEnd();
                   }
                
                RCODE getDataPtr( VOID**    pData /* [out] void* pData  */)
                   {
                
                    return pif->getDataPtr(pData);
                   }
                
                RCODE moveForward( )
                   {
                    return pif->moveForward();
                   }
                

        
        
        }; // class CiForwardIterableWrapper
        
        typedef CiForwardIterableWrapper< ::cli::CCliPtr< INTERFACE_CLI_IFORWARDITERABLE     > >  CiForwardIterable;
        typedef CiForwardIterableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IFORWARDITERABLE > >  CiForwardIterable_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iBackwardIterable */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IBACKWARDITERABLE_IID
    #define INTERFACE_CLI_IBACKWARDITERABLE_IID    "/cli/iBackwardIterable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iBackwardIterable
    #define BASE_INTERFACE ::cli::iIterable
    #ifndef INTERFACE_CLI_IBACKWARDITERABLE
       #define INTERFACE_CLI_IBACKWARDITERABLE    ::cli::iBackwardIterable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iBackwardIterable
    #define BASE_INTERFACE cli_iIterable
    #ifndef INTERFACE_CLI_IBACKWARDITERABLE
       #define INTERFACE_CLI_IBACKWARDITERABLE    cli_iBackwardIterable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iIterable methods */
            CLIMETHOD_(BOOL, isBegin) (THIS) PURE;
            CLIMETHOD_(BOOL, isEnd) (THIS) PURE;
            CLIMETHOD(getDataPtr) (THIS_ VOID**    pData /* [out] void* pData  */) PURE;
            
            /* interface ::cli::iBackwardIterable methods */
            CLIMETHOD(moveBackward) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iBackwardIterable >
           {
            static char const * getName() { return INTERFACE_CLI_IBACKWARDITERABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iBackwardIterable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iBackwardIterable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iBackwardIterable wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IBACKWARDITERABLE >
                                      */
                 >
        class CiBackwardIterableWrapper
        {
            public:
        
                typedef  CiBackwardIterableWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiBackwardIterableWrapper() :
                   pif(0) {}
        
                CiBackwardIterableWrapper( iBackwardIterable *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiBackwardIterableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiBackwardIterableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiBackwardIterableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiBackwardIterableWrapper(const CiBackwardIterableWrapper &i) :
                    pif(i.pif) { }
        
                ~CiBackwardIterableWrapper()  { }
        
                CiBackwardIterableWrapper& operator=(const CiBackwardIterableWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                BOOL isBegin( )
                   {
                    return pif->isBegin();
                   }
                
                BOOL isEnd( )
                   {
                    return pif->isEnd();
                   }
                
                RCODE getDataPtr( VOID**    pData /* [out] void* pData  */)
                   {
                
                    return pif->getDataPtr(pData);
                   }
                
                RCODE moveBackward( )
                   {
                    return pif->moveBackward();
                   }
                

        
        
        }; // class CiBackwardIterableWrapper
        
        typedef CiBackwardIterableWrapper< ::cli::CCliPtr< INTERFACE_CLI_IBACKWARDITERABLE     > >  CiBackwardIterable;
        typedef CiBackwardIterableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IBACKWARDITERABLE > >  CiBackwardIterable_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; /* namespace cli */

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iRandomIterable */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IRANDOMITERABLE_IID
    #define INTERFACE_CLI_IRANDOMITERABLE_IID    "/cli/iRandomIterable"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iRandomIterable
    #define BASE_INTERFACE ::cli::iIterable
    #ifndef INTERFACE_CLI_IRANDOMITERABLE
       #define INTERFACE_CLI_IRANDOMITERABLE    ::cli::iRandomIterable
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iRandomIterable
    #define BASE_INTERFACE cli_iIterable
    #ifndef INTERFACE_CLI_IRANDOMITERABLE
       #define INTERFACE_CLI_IRANDOMITERABLE    cli_iRandomIterable
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iIterable methods */
            CLIMETHOD_(BOOL, isBegin) (THIS) PURE;
            CLIMETHOD_(BOOL, isEnd) (THIS) PURE;
            CLIMETHOD(getDataPtr) (THIS_ VOID**    pData /* [out] void* pData  */) PURE;
            
            /* interface ::cli::iRandomIterable methods */
            CLIMETHOD(move) (THIS) PURE;
            CLIMETHOD(moveForward) (THIS) PURE;
            CLIMETHOD(moveBackward) (THIS) PURE;
            CLIMETHOD(moveRandom) (THIS_ SSIZE_T    moveDist /* [in] ssize_t  moveDist  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iRandomIterable >
           {
            static char const * getName() { return INTERFACE_CLI_IRANDOMITERABLE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iRandomIterable* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iRandomIterable > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iRandomIterable wrapper
        // generated from F:\work\navis\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IRANDOMITERABLE >
                                      */
                 >
        class CiRandomIterableWrapper
        {
            public:
        
                typedef  CiRandomIterableWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiRandomIterableWrapper() :
                   pif(0) {}
        
                CiRandomIterableWrapper( iRandomIterable *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiRandomIterableWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiRandomIterableWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiRandomIterableWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiRandomIterableWrapper(const CiRandomIterableWrapper &i) :
                    pif(i.pif) { }
        
                ~CiRandomIterableWrapper()  { }
        
                CiRandomIterableWrapper& operator=(const CiRandomIterableWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                BOOL isBegin( )
                   {
                    return pif->isBegin();
                   }
                
                BOOL isEnd( )
                   {
                    return pif->isEnd();
                   }
                
                RCODE getDataPtr( VOID**    pData /* [out] void* pData  */)
                   {
                
                    return pif->getDataPtr(pData);
                   }
                
                RCODE move( )
                   {
                    return pif->move();
                   }
                
                RCODE moveForward( )
                   {
                    return pif->moveForward();
                   }
                
                RCODE moveBackward( )
                   {
                    return pif->moveBackward();
                   }
                
                RCODE moveRandom( SSIZE_T    moveDist /* [in] ssize_t  moveDist  */)
                   {
                
                    return pif->moveRandom(moveDist);
                   }
                

        
        
        }; // class CiRandomIterableWrapper
        
        typedef CiRandomIterableWrapper< ::cli::CCliPtr< INTERFACE_CLI_IRANDOMITERABLE     > >  CiRandomIterable;
        typedef CiRandomIterableWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IRANDOMITERABLE > >  CiRandomIterable_nrc; /* No ref counting for interface used */
        
        
        
        
        
    }; /* namespace cli */

#endif





#endif /* CLI_COMMON_IITERABLE_H */
