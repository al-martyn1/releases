#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IARGLIST_H
#define CLI_IARGLIST_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/iarglist.h>", CLI_IARGLIST_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iArgList */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iArgList;
        #ifndef INTERFACE_CLI_IARGLIST
            #define INTERFACE_CLI_IARGLIST            ::cli::iArgList
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

        interface                                iVariant;
        #ifndef INTERFACE_CLI_IVARIANT
            #define INTERFACE_CLI_IVARIANT            ::cli::iVariant
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IARGLIST_PREDECLARED
    #define INTERFACE_CLI_IARGLIST_PREDECLARED
    typedef interface tag_cli_iArgList       cli_iArgList;
    #endif //INTERFACE_CLI_IARGLIST
    #ifndef INTERFACE_CLI_IARGLIST
        #define INTERFACE_CLI_IARGLIST            struct tag_cli_iArgList
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_IVARIANT_PREDECLARED
    #define INTERFACE_CLI_IVARIANT_PREDECLARED
    typedef interface tag_cli_iVariant       cli_iVariant;
    #endif //INTERFACE_CLI_IVARIANT
    #ifndef INTERFACE_CLI_IVARIANT
        #define INTERFACE_CLI_IVARIANT            struct tag_cli_iVariant
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IARGLIST_IID
    #define INTERFACE_CLI_IARGLIST_IID    "/cli/iArgList"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iArgList
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IARGLIST
       #define INTERFACE_CLI_IARGLIST    ::cli::iArgList
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iArgList
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IARGLIST
       #define INTERFACE_CLI_IARGLIST    cli_iArgList
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iArgList methods */
            CLIMETHOD_(ENUM_CLI_VARIANTTYPE, getType) (THIS_ SIZE_T    idx /* [in] size_t  idx  */) PURE;
            CLIMETHOD(convertType) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                        , ENUM_CLI_VARIANTTYPE    newType /* [in] ::cli::VariantType  newType  */
                                   ) PURE;
            CLIMETHOD(getTypeStringChars) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                               , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                               , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                          ) PURE;
            CLIMETHOD_(SIZE_T, getCount) (THIS) PURE;
            CLIMETHOD(valueQueryInterface) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                , const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                                , VOID**    ifPtr /* [out] void* ifPtr  */
                                           ) PURE;
            CLIMETHOD(shiftArgs1) (THIS) PURE;
            CLIMETHOD(shiftArgs) (THIS_ SIZE_T    shiftCount /* [in] size_t  shiftCount  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, clearArgs) (THIS) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setCopyFrom) (THIS_ SIZE_T    thisListIdx /* [in] size_t  thisListIdx  */
                                                                  , INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                                  , SIZE_T    copyFromIdx /* [in] size_t  copyFromIdx  */
                                                             ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putCopyFrom) (THIS_ INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                                  , SIZE_T    copyFromIdx /* [in] size_t  copyFromIdx  */
                                                             ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putArgList) (THIS_ INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                                 , SIZE_T    copyFromIdxBegin /* [in] size_t  copyFromIdxBegin  */
                                                                 , SIZE_T    copyFromIdxEnd /* [in] size_t  copyFromIdxEnd  */
                                                            ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putArgListAll) (THIS_ INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putEmpty) (THIS) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putChar) (THIS_ CHAR    ch /* [in] char  ch  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putWChar) (THIS_ WCHAR    wch /* [in] wchar  wch  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putShort) (THIS_ SHORT    s /* [in] short  s  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUShort) (THIS_ USHORT    us /* [in] ushort  us  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putInt) (THIS_ INT    i /* [in] int  i  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUInt) (THIS_ UINT    i /* [in] uint  i  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putInt64) (THIS_ INT64    i /* [in] int64  i  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUInt64) (THIS_ UINT64    i /* [in] uint64  i  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putIntPtr) (THIS_ INT_PTR    i /* [in] int_ptr  i  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUIntPtr) (THIS_ UINT_PTR    i /* [in] uint_ptr  i  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putFloat) (THIS_ FLOAT    f /* [in] float  f  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putDouble) (THIS_ DOUBLE    d /* [in] double  d  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putPtr) (THIS_ const VOID*    vptr /* [in] void*  vptr  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putString) (THIS_ const CLISTR*     str) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putStringPStr) (THIS_ CLIPSTR           str) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putStringChars) (THIS_ const WCHAR*    str /* [in,flat] wchar  str[]  */
                                                                     , SIZE_T    strSize /* [in] size_t  strSize  */
                                                                ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putDump) (THIS_ const BYTE*    d /* [in,flat] byte  d[]  */
                                                              , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                                                         ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putDate) (THIS_ const STRUCT_CLI_CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putBool) (THIS_ BOOL    b /* [in] bool  b  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUnknown) (THIS_ INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putBigInteger) (THIS_ const STRUCT_CLI_BIGINTEGER*    bigint /* [in,ref] ::cli::BigInteger  bigint  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putRationalNumber) (THIS_ const STRUCT_CLI_RATIONALNUMBER*    rational /* [in,ref] ::cli::RationalNumber  rational  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setEmpty) (THIS_ SIZE_T    idx /* [in] size_t  idx  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setChar) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                              , CHAR    ch /* [in] char  ch  */
                                                         ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setWChar) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                               , WCHAR    wch /* [in] wchar  wch  */
                                                          ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setShort) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                               , SHORT    s /* [in] short  s  */
                                                          ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUShort) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                , USHORT    us /* [in] ushort  us  */
                                                           ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setInt) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                             , INT    i /* [in] int  i  */
                                                        ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUInt) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                              , UINT    i /* [in] uint  i  */
                                                         ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setInt64) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                               , INT64    i /* [in] int64  i  */
                                                          ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUInt64) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                , UINT64    i /* [in] uint64  i  */
                                                           ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setIntPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                , INT_PTR    i /* [in] int_ptr  i  */
                                                           ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUIntPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                 , UINT_PTR    i /* [in] uint_ptr  i  */
                                                            ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setFloat) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                               , FLOAT    f /* [in] float  f  */
                                                          ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setDouble) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                , DOUBLE    d /* [in] double  d  */
                                                           ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                             , const VOID*    vptr /* [in] void*  vptr  */
                                                        ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                , const CLISTR*     str
                                                           ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setStringPStr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                    , CLIPSTR           str
                                                               ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setStringChars) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                     , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                                                     , SIZE_T    strSize /* [in] size_t  strSize  */
                                                                ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setDump) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                              , const BYTE*    d /* [in,flat] byte  d[]  */
                                                              , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                                                         ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setDate) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                              , const STRUCT_CLI_CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */
                                                         ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setBool) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                              , BOOL    b /* [in] bool  b  */
                                                         ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUnknown) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                 , INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */
                                                            ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setBigInteger) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                    , const STRUCT_CLI_BIGINTEGER*    bigint /* [in,ref] ::cli::BigInteger  bigint  */
                                                               ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setRationalNumber) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                        , const STRUCT_CLI_RATIONALNUMBER*    rational /* [in,ref] ::cli::RationalNumber  rational  */
                                                                   ) PURE;
            CLIMETHOD(getChar) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                    , CHAR*    ch /* [out] char ch  */
                               ) PURE;
            CLIMETHOD(getWChar) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                     , WCHAR*    wch /* [out] wchar wch  */
                                ) PURE;
            CLIMETHOD(getShort) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                     , SHORT*    s /* [out] short s  */
                                ) PURE;
            CLIMETHOD(getUShort) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , USHORT*    us /* [out] ushort us  */
                                 ) PURE;
            CLIMETHOD(getInt) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                   , INT*    i /* [out] int i  */
                              ) PURE;
            CLIMETHOD(getUInt) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                    , UINT*    i /* [out] uint i  */
                               ) PURE;
            CLIMETHOD(getInt64) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                     , INT64*    i /* [out] int64 i  */
                                ) PURE;
            CLIMETHOD(getUInt64) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , UINT64*    i /* [out] uint64 i  */
                                 ) PURE;
            CLIMETHOD(getIntPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , INT_PTR*    i /* [out] int_ptr i  */
                                 ) PURE;
            CLIMETHOD(getUIntPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                       , UINT_PTR*    i /* [out] uint_ptr i  */
                                  ) PURE;
            CLIMETHOD(getFloat) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                     , FLOAT*    f /* [out] float f  */
                                ) PURE;
            CLIMETHOD(getDouble) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , DOUBLE*    d /* [out] double d  */
                                 ) PURE;
            CLIMETHOD(getPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                   , VOID**    vptr /* [out] void* vptr  */
                              ) PURE;
            CLIMETHOD(getString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , CLISTR*           str
                                 ) PURE;
            CLIMETHOD(getStringPStr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                          , CLIPSTR*          str
                                     ) PURE;
            CLIMETHOD(getStringChars) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                           , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                           , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                      ) PURE;
            CLIMETHOD(getDump) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                    , CLIPCSTR*         str
                               ) PURE;
            CLIMETHOD(getDate) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                    , STRUCT_CLI_CLISYSTEMTIME*    datetime /* [out] ::cli::CLISYSTEMTIME datetime  */
                               ) PURE;
            CLIMETHOD(getBool) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                    , BOOL*    b /* [out] bool b  */
                               ) PURE;
            CLIMETHOD(getUnknown) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                       , INTERFACE_CLI_IUNKNOWN**    pUnknown /* [out] ::cli::iUnknown* pUnknown  */
                                  ) PURE;
            CLIMETHOD(getBigInteger) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                          , STRUCT_CLI_BIGINTEGER*    bigint /* [out] ::cli::BigInteger bigint  */
                                     ) PURE;
            CLIMETHOD(getRationalNumber) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                              , STRUCT_CLI_RATIONALNUMBER*    rational /* [out] ::cli::RationalNumber rational  */
                                         ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putVariant) (THIS_ INTERFACE_CLI_IVARIANT*    v /* [in] ::cli::iVariant*  v  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putVariantRaw) (THIS_ const STRUCT_CLI_VARIANT*    v /* [in,ref] ::cli::Variant  v  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setVariant) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                 , INTERFACE_CLI_IVARIANT*    v /* [in] ::cli::iVariant*  v  */
                                                            ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setVariantRaw) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                    , const STRUCT_CLI_VARIANT*    v /* [in,ref] ::cli::Variant  v  */
                                                               ) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putColorref) (THIS_ COLORREF    i /* [in] colorref  i  */) PURE;
            CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setColorref) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                  , COLORREF    i /* [in] colorref  i  */
                                                             ) PURE;
            CLIMETHOD(getColorref) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                        , COLORREF*    i /* [out] colorref i  */
                                   ) PURE;
            CLIMETHOD(splitIntoVariantsEx) (THIS_ INTERFACE_CLI_IVARIANT**    v /* [out,flat] ::cli::iVariant* v[]  */
                                                , SIZE_T    count /* [in] size_t  count  */
                                                , INTERFACE_CLI_IVARIANT*    referenceVar /* [in] ::cli::iVariant*  referenceVar  */
                                                , SIZE_T    startIdx /* [in] size_t  startIdx  */
                                           ) PURE;
            CLIMETHOD(splitIntoVariants) (THIS_ INTERFACE_CLI_IVARIANT**    v /* [out,flat] ::cli::iVariant* v[]  */
                                              , SIZE_T    count /* [in] size_t  count  */
                                         ) PURE;
            CLIMETHOD(putFromVariants) (THIS_ INTERFACE_CLI_IVARIANT**    v /* [in,flat] ::cli::iVariant*  v[]  */
                                            , SIZE_T    count /* [in] size_t  count  */
                                       ) PURE;
            CLIMETHOD(assignFromVariants) (THIS_ INTERFACE_CLI_IVARIANT**    v /* [in,flat] ::cli::iVariant*  v[]  */
                                               , SIZE_T    count /* [in] size_t  count  */
                                          ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iArgList >
           {
            static char const * getName() { return INTERFACE_CLI_IARGLIST_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iArgList* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iArgList > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iArgList wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IARGLIST >
                                      */
                 >
        class CiArgListWrapper
        {
            public:
        
                typedef  CiArgListWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiArgListWrapper() :
                   pif(0) {}
        
                CiArgListWrapper( iArgList *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiArgListWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiArgListWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiArgListWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiArgListWrapper(const CiArgListWrapper &i) :
                    pif(i.pif) { }
        
                ~CiArgListWrapper()  { }
        
                CiArgListWrapper& operator=(const CiArgListWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                ENUM_CLI_VARIANTTYPE getType( SIZE_T    idx /* [in] size_t  idx  */)
                   {
                
                    return pif->getType(idx);
                   }
                
                RCODE convertType( SIZE_T    idx /* [in] size_t  idx  */
                                 , ENUM_CLI_VARIANTTYPE    newType /* [in] ::cli::VariantType  newType  */
                                 )
                   {
                
                
                    return pif->convertType(idx, newType);
                   }
                
                RCODE getTypeStringChars( SIZE_T    idx /* [in] size_t  idx  */
                                        , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                        , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                        )
                   {
                
                
                
                    return pif->getTypeStringChars(idx, buf, bufSize);
                   }
                
                SIZE_T getCount( )
                   {
                    return pif->getCount();
                   }
                
                RCODE valueQueryInterface( SIZE_T    idx /* [in] size_t  idx  */
                                         , const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                         , VOID**    ifPtr /* [out] void* ifPtr  */
                                         )
                   {
                
                
                
                    return pif->valueQueryInterface(idx, interfaceId, ifPtr);
                   }
                
                RCODE shiftArgs1( )
                   {
                    return pif->shiftArgs1();
                   }
                
                RCODE shiftArgs( SIZE_T    shiftCount /* [in] size_t  shiftCount  */)
                   {
                
                    return pif->shiftArgs(shiftCount);
                   }
                
                INTERFACE_CLI_IARGLIST* clearArgs( )
                   {
                    return pif->clearArgs();
                   }
                
                INTERFACE_CLI_IARGLIST* setCopyFrom( SIZE_T    thisListIdx /* [in] size_t  thisListIdx  */
                                                   , INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                   , SIZE_T    copyFromIdx /* [in] size_t  copyFromIdx  */
                                                   )
                   {
                
                
                
                    return pif->setCopyFrom(thisListIdx, copyFrom, copyFromIdx);
                   }
                
                INTERFACE_CLI_IARGLIST* putCopyFrom( INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                   , SIZE_T    copyFromIdx /* [in] size_t  copyFromIdx  */
                                                   )
                   {
                
                
                    return pif->putCopyFrom(copyFrom, copyFromIdx);
                   }
                
                INTERFACE_CLI_IARGLIST* putArgList( INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                  , SIZE_T    copyFromIdxBegin /* [in] size_t  copyFromIdxBegin  */
                                                  , SIZE_T    copyFromIdxEnd /* [in] size_t  copyFromIdxEnd  */
                                                  )
                   {
                
                
                
                    return pif->putArgList(copyFrom, copyFromIdxBegin, copyFromIdxEnd);
                   }
                
                INTERFACE_CLI_IARGLIST* putArgListAll( INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */)
                   {
                
                    return pif->putArgListAll(copyFrom);
                   }
                
                INTERFACE_CLI_IARGLIST* putEmpty( )
                   {
                    return pif->putEmpty();
                   }
                
                INTERFACE_CLI_IARGLIST* putChar( CHAR    ch /* [in] char  ch  */)
                   {
                
                    return pif->putChar(ch);
                   }
                
                INTERFACE_CLI_IARGLIST* putWChar( WCHAR    wch /* [in] wchar  wch  */)
                   {
                
                    return pif->putWChar(wch);
                   }
                
                INTERFACE_CLI_IARGLIST* putShort( SHORT    s /* [in] short  s  */)
                   {
                
                    return pif->putShort(s);
                   }
                
                INTERFACE_CLI_IARGLIST* putUShort( USHORT    us /* [in] ushort  us  */)
                   {
                
                    return pif->putUShort(us);
                   }
                
                INTERFACE_CLI_IARGLIST* putInt( INT    i /* [in] int  i  */)
                   {
                
                    return pif->putInt(i);
                   }
                
                INTERFACE_CLI_IARGLIST* putUInt( UINT    i /* [in] uint  i  */)
                   {
                
                    return pif->putUInt(i);
                   }
                
                INTERFACE_CLI_IARGLIST* putInt64( INT64    i /* [in] int64  i  */)
                   {
                
                    return pif->putInt64(i);
                   }
                
                INTERFACE_CLI_IARGLIST* putUInt64( UINT64    i /* [in] uint64  i  */)
                   {
                
                    return pif->putUInt64(i);
                   }
                
                INTERFACE_CLI_IARGLIST* putIntPtr( INT_PTR    i /* [in] int_ptr  i  */)
                   {
                
                    return pif->putIntPtr(i);
                   }
                
                INTERFACE_CLI_IARGLIST* putUIntPtr( UINT_PTR    i /* [in] uint_ptr  i  */)
                   {
                
                    return pif->putUIntPtr(i);
                   }
                
                INTERFACE_CLI_IARGLIST* putFloat( FLOAT    f /* [in] float  f  */)
                   {
                
                    return pif->putFloat(f);
                   }
                
                INTERFACE_CLI_IARGLIST* putDouble( DOUBLE    d /* [in] double  d  */)
                   {
                
                    return pif->putDouble(d);
                   }
                
                INTERFACE_CLI_IARGLIST* putPtr( const VOID*    vptr /* [in] void*  vptr  */)
                   {
                
                    return pif->putPtr(vptr);
                   }
                
                INTERFACE_CLI_IARGLIST* putString( const ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->putString(&tmp_str);
                   }
                
                INTERFACE_CLI_IARGLIST* putStringPStr( ::std::wstring    str)
                   {
                    CCliPStr tmp_str; CCliPStr_lightCopyTo( tmp_str, str);
                    return pif->putStringPStr(tmp_str);
                   }
                
                INTERFACE_CLI_IARGLIST* putStringChars( const WCHAR*    str /* [in,flat] wchar  str[]  */
                                                      , SIZE_T    strSize /* [in] size_t  strSize  */
                                                      )
                   {
                
                
                    return pif->putStringChars(str, strSize);
                   }
                
                INTERFACE_CLI_IARGLIST* putDump( const BYTE*    d /* [in,flat] byte  d[]  */
                                               , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                                               )
                   {
                
                
                    return pif->putDump(d, dumpSize);
                   }
                
                INTERFACE_CLI_IARGLIST* putDate( const STRUCT_CLI_CLISYSTEMTIME    &datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->putDate(&datetime);
                   }
                
                INTERFACE_CLI_IARGLIST* putBool( BOOL    b /* [in] bool  b  */)
                   {
                
                    return pif->putBool(b);
                   }
                
                INTERFACE_CLI_IARGLIST* putUnknown( INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */)
                   {
                
                    return pif->putUnknown(pUnknown);
                   }
                
                INTERFACE_CLI_IARGLIST* putBigInteger( const STRUCT_CLI_BIGINTEGER    &bigint /* [in,ref] ::cli::BigInteger  bigint  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->putBigInteger(&bigint);
                   }
                
                INTERFACE_CLI_IARGLIST* putRationalNumber( const STRUCT_CLI_RATIONALNUMBER    &rational /* [in,ref] ::cli::RationalNumber  rational  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->putRationalNumber(&rational);
                   }
                
                INTERFACE_CLI_IARGLIST* setEmpty( SIZE_T    idx /* [in] size_t  idx  */)
                   {
                
                    return pif->setEmpty(idx);
                   }
                
                INTERFACE_CLI_IARGLIST* setChar( SIZE_T    idx /* [in] size_t  idx  */
                                               , CHAR    ch /* [in] char  ch  */
                                               )
                   {
                
                
                    return pif->setChar(idx, ch);
                   }
                
                INTERFACE_CLI_IARGLIST* setWChar( SIZE_T    idx /* [in] size_t  idx  */
                                                , WCHAR    wch /* [in] wchar  wch  */
                                                )
                   {
                
                
                    return pif->setWChar(idx, wch);
                   }
                
                INTERFACE_CLI_IARGLIST* setShort( SIZE_T    idx /* [in] size_t  idx  */
                                                , SHORT    s /* [in] short  s  */
                                                )
                   {
                
                
                    return pif->setShort(idx, s);
                   }
                
                INTERFACE_CLI_IARGLIST* setUShort( SIZE_T    idx /* [in] size_t  idx  */
                                                 , USHORT    us /* [in] ushort  us  */
                                                 )
                   {
                
                
                    return pif->setUShort(idx, us);
                   }
                
                INTERFACE_CLI_IARGLIST* setInt( SIZE_T    idx /* [in] size_t  idx  */
                                              , INT    i /* [in] int  i  */
                                              )
                   {
                
                
                    return pif->setInt(idx, i);
                   }
                
                INTERFACE_CLI_IARGLIST* setUInt( SIZE_T    idx /* [in] size_t  idx  */
                                               , UINT    i /* [in] uint  i  */
                                               )
                   {
                
                
                    return pif->setUInt(idx, i);
                   }
                
                INTERFACE_CLI_IARGLIST* setInt64( SIZE_T    idx /* [in] size_t  idx  */
                                                , INT64    i /* [in] int64  i  */
                                                )
                   {
                
                
                    return pif->setInt64(idx, i);
                   }
                
                INTERFACE_CLI_IARGLIST* setUInt64( SIZE_T    idx /* [in] size_t  idx  */
                                                 , UINT64    i /* [in] uint64  i  */
                                                 )
                   {
                
                
                    return pif->setUInt64(idx, i);
                   }
                
                INTERFACE_CLI_IARGLIST* setIntPtr( SIZE_T    idx /* [in] size_t  idx  */
                                                 , INT_PTR    i /* [in] int_ptr  i  */
                                                 )
                   {
                
                
                    return pif->setIntPtr(idx, i);
                   }
                
                INTERFACE_CLI_IARGLIST* setUIntPtr( SIZE_T    idx /* [in] size_t  idx  */
                                                  , UINT_PTR    i /* [in] uint_ptr  i  */
                                                  )
                   {
                
                
                    return pif->setUIntPtr(idx, i);
                   }
                
                INTERFACE_CLI_IARGLIST* setFloat( SIZE_T    idx /* [in] size_t  idx  */
                                                , FLOAT    f /* [in] float  f  */
                                                )
                   {
                
                
                    return pif->setFloat(idx, f);
                   }
                
                INTERFACE_CLI_IARGLIST* setDouble( SIZE_T    idx /* [in] size_t  idx  */
                                                 , DOUBLE    d /* [in] double  d  */
                                                 )
                   {
                
                
                    return pif->setDouble(idx, d);
                   }
                
                INTERFACE_CLI_IARGLIST* setPtr( SIZE_T    idx /* [in] size_t  idx  */
                                              , const VOID*    vptr /* [in] void*  vptr  */
                                              )
                   {
                
                
                    return pif->setPtr(idx, vptr);
                   }
                
                INTERFACE_CLI_IARGLIST* setString( SIZE_T    idx /* [in] size_t  idx  */
                                                 , const ::std::wstring    &str
                                                 )
                   {
                
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->setString(idx, &tmp_str);
                   }
                
                INTERFACE_CLI_IARGLIST* setStringPStr( SIZE_T    idx /* [in] size_t  idx  */
                                                     , ::std::wstring    str
                                                     )
                   {
                
                    CCliPStr tmp_str; CCliPStr_lightCopyTo( tmp_str, str);
                    return pif->setStringPStr(idx, tmp_str);
                   }
                
                INTERFACE_CLI_IARGLIST* setStringChars( SIZE_T    idx /* [in] size_t  idx  */
                                                      , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                                      , SIZE_T    strSize /* [in] size_t  strSize  */
                                                      )
                   {
                
                
                
                    return pif->setStringChars(idx, str, strSize);
                   }
                
                INTERFACE_CLI_IARGLIST* setDump( SIZE_T    idx /* [in] size_t  idx  */
                                               , const BYTE*    d /* [in,flat] byte  d[]  */
                                               , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                                               )
                   {
                
                
                
                    return pif->setDump(idx, d, dumpSize);
                   }
                
                INTERFACE_CLI_IARGLIST* setDate( SIZE_T    idx /* [in] size_t  idx  */
                                               , const STRUCT_CLI_CLISYSTEMTIME    &datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  (struct passed by ref in wrapper) */
                                               )
                   {
                
                
                    return pif->setDate(idx, &datetime);
                   }
                
                INTERFACE_CLI_IARGLIST* setBool( SIZE_T    idx /* [in] size_t  idx  */
                                               , BOOL    b /* [in] bool  b  */
                                               )
                   {
                
                
                    return pif->setBool(idx, b);
                   }
                
                INTERFACE_CLI_IARGLIST* setUnknown( SIZE_T    idx /* [in] size_t  idx  */
                                                  , INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */
                                                  )
                   {
                
                
                    return pif->setUnknown(idx, pUnknown);
                   }
                
                INTERFACE_CLI_IARGLIST* setBigInteger( SIZE_T    idx /* [in] size_t  idx  */
                                                     , const STRUCT_CLI_BIGINTEGER    &bigint /* [in,ref] ::cli::BigInteger  bigint  (struct passed by ref in wrapper) */
                                                     )
                   {
                
                
                    return pif->setBigInteger(idx, &bigint);
                   }
                
                INTERFACE_CLI_IARGLIST* setRationalNumber( SIZE_T    idx /* [in] size_t  idx  */
                                                         , const STRUCT_CLI_RATIONALNUMBER    &rational /* [in,ref] ::cli::RationalNumber  rational  (struct passed by ref in wrapper) */
                                                         )
                   {
                
                
                    return pif->setRationalNumber(idx, &rational);
                   }
                
                RCODE getChar( SIZE_T    idx /* [in] size_t  idx  */
                             , CHAR*    ch /* [out] char ch  */
                             )
                   {
                
                
                    return pif->getChar(idx, ch);
                   }
                
                RCODE getWChar( SIZE_T    idx /* [in] size_t  idx  */
                              , WCHAR*    wch /* [out] wchar wch  */
                              )
                   {
                
                
                    return pif->getWChar(idx, wch);
                   }
                
                RCODE getShort( SIZE_T    idx /* [in] size_t  idx  */
                              , SHORT*    s /* [out] short s  */
                              )
                   {
                
                
                    return pif->getShort(idx, s);
                   }
                
                RCODE getUShort( SIZE_T    idx /* [in] size_t  idx  */
                               , USHORT*    us /* [out] ushort us  */
                               )
                   {
                
                
                    return pif->getUShort(idx, us);
                   }
                
                RCODE getInt( SIZE_T    idx /* [in] size_t  idx  */
                            , INT*    i /* [out] int i  */
                            )
                   {
                
                
                    return pif->getInt(idx, i);
                   }
                
                RCODE getUInt( SIZE_T    idx /* [in] size_t  idx  */
                             , UINT*    i /* [out] uint i  */
                             )
                   {
                
                
                    return pif->getUInt(idx, i);
                   }
                
                RCODE getInt64( SIZE_T    idx /* [in] size_t  idx  */
                              , INT64*    i /* [out] int64 i  */
                              )
                   {
                
                
                    return pif->getInt64(idx, i);
                   }
                
                RCODE getUInt64( SIZE_T    idx /* [in] size_t  idx  */
                               , UINT64*    i /* [out] uint64 i  */
                               )
                   {
                
                
                    return pif->getUInt64(idx, i);
                   }
                
                RCODE getIntPtr( SIZE_T    idx /* [in] size_t  idx  */
                               , INT_PTR*    i /* [out] int_ptr i  */
                               )
                   {
                
                
                    return pif->getIntPtr(idx, i);
                   }
                
                RCODE getUIntPtr( SIZE_T    idx /* [in] size_t  idx  */
                                , UINT_PTR*    i /* [out] uint_ptr i  */
                                )
                   {
                
                
                    return pif->getUIntPtr(idx, i);
                   }
                
                RCODE getFloat( SIZE_T    idx /* [in] size_t  idx  */
                              , FLOAT*    f /* [out] float f  */
                              )
                   {
                
                
                    return pif->getFloat(idx, f);
                   }
                
                RCODE getDouble( SIZE_T    idx /* [in] size_t  idx  */
                               , DOUBLE*    d /* [out] double d  */
                               )
                   {
                
                
                    return pif->getDouble(idx, d);
                   }
                
                RCODE getPtr( SIZE_T    idx /* [in] size_t  idx  */
                            , VOID**    vptr /* [out] void* vptr  */
                            )
                   {
                
                
                    return pif->getPtr(idx, vptr);
                   }
                
                RCODE getString( SIZE_T    idx /* [in] size_t  idx  */
                               , ::std::wstring    &str
                               )
                   {
                
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getString(idx, &tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getStringPStr( SIZE_T    idx /* [in] size_t  idx  */
                                   , ::std::wstring    &str
                                   )
                   {
                
                    CCliPStr tmp_str; CCliPStr_init( tmp_str );
                    RCODE res = pif->getStringPStr(idx, &tmp_str);
                    if (RCOK(res))
                       {
                        CCliPStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getStringChars( SIZE_T    idx /* [in] size_t  idx  */
                                    , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                    , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                    )
                   {
                
                
                
                    return pif->getStringChars(idx, buf, bufSize);
                   }
                
                RCODE getDump( SIZE_T    idx /* [in] size_t  idx  */
                             , ::std::string    &str
                             )
                   {
                
                    CCliPCStr tmp_str; CCliPCStr_init( tmp_str );
                    RCODE res = pif->getDump(idx, &tmp_str);
                    if (RCOK(res))
                       {
                        CCliPCStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getDate( SIZE_T    idx /* [in] size_t  idx  */
                             , STRUCT_CLI_CLISYSTEMTIME    &datetime /* [out] ::cli::CLISYSTEMTIME datetime  (struct passed by ref in wrapper) */
                             )
                   {
                
                
                    return pif->getDate(idx, &datetime);
                   }
                
                RCODE getBool( SIZE_T    idx /* [in] size_t  idx  */
                             , BOOL*    b /* [out] bool b  */
                             )
                   {
                
                
                    return pif->getBool(idx, b);
                   }
                
                RCODE getUnknown( SIZE_T    idx /* [in] size_t  idx  */
                                , INTERFACE_CLI_IUNKNOWN**    pUnknown /* [out] ::cli::iUnknown* pUnknown  */
                                )
                   {
                
                
                    return pif->getUnknown(idx, pUnknown);
                   }
                
                RCODE getBigInteger( SIZE_T    idx /* [in] size_t  idx  */
                                   , STRUCT_CLI_BIGINTEGER    &bigint /* [out] ::cli::BigInteger bigint  (struct passed by ref in wrapper) */
                                   )
                   {
                
                
                    return pif->getBigInteger(idx, &bigint);
                   }
                
                RCODE getRationalNumber( SIZE_T    idx /* [in] size_t  idx  */
                                       , STRUCT_CLI_RATIONALNUMBER    &rational /* [out] ::cli::RationalNumber rational  (struct passed by ref in wrapper) */
                                       )
                   {
                
                
                    return pif->getRationalNumber(idx, &rational);
                   }
                
                INTERFACE_CLI_IARGLIST* putVariant( INTERFACE_CLI_IVARIANT*    v /* [in] ::cli::iVariant*  v  */)
                   {
                
                    return pif->putVariant(v);
                   }
                
                INTERFACE_CLI_IARGLIST* putVariantRaw( const STRUCT_CLI_VARIANT    &v /* [in,ref] ::cli::Variant  v  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->putVariantRaw(&v);
                   }
                
                INTERFACE_CLI_IARGLIST* setVariant( SIZE_T    idx /* [in] size_t  idx  */
                                                  , INTERFACE_CLI_IVARIANT*    v /* [in] ::cli::iVariant*  v  */
                                                  )
                   {
                
                
                    return pif->setVariant(idx, v);
                   }
                
                INTERFACE_CLI_IARGLIST* setVariantRaw( SIZE_T    idx /* [in] size_t  idx  */
                                                     , const STRUCT_CLI_VARIANT    &v /* [in,ref] ::cli::Variant  v  (struct passed by ref in wrapper) */
                                                     )
                   {
                
                
                    return pif->setVariantRaw(idx, &v);
                   }
                
                INTERFACE_CLI_IARGLIST* putColorref( COLORREF    i /* [in] colorref  i  */)
                   {
                
                    return pif->putColorref(i);
                   }
                
                INTERFACE_CLI_IARGLIST* setColorref( SIZE_T    idx /* [in] size_t  idx  */
                                                   , COLORREF    i /* [in] colorref  i  */
                                                   )
                   {
                
                
                    return pif->setColorref(idx, i);
                   }
                
                RCODE getColorref( SIZE_T    idx /* [in] size_t  idx  */
                                 , COLORREF*    i /* [out] colorref i  */
                                 )
                   {
                
                
                    return pif->getColorref(idx, i);
                   }
                
                RCODE splitIntoVariantsEx( INTERFACE_CLI_IVARIANT**    v /* [out,flat] ::cli::iVariant* v[]  */
                                         , SIZE_T    count /* [in] size_t  count  */
                                         , INTERFACE_CLI_IVARIANT*    referenceVar /* [in] ::cli::iVariant*  referenceVar  */
                                         , SIZE_T    startIdx /* [in] size_t  startIdx  */
                                         )
                   {
                
                
                
                
                    return pif->splitIntoVariantsEx(v, count, referenceVar, startIdx);
                   }
                
                RCODE splitIntoVariants( INTERFACE_CLI_IVARIANT**    v /* [out,flat] ::cli::iVariant* v[]  */
                                       , SIZE_T    count /* [in] size_t  count  */
                                       )
                   {
                
                
                    return pif->splitIntoVariants(v, count);
                   }
                
                RCODE putFromVariants( INTERFACE_CLI_IVARIANT**    v /* [in,flat] ::cli::iVariant*  v[]  */
                                     , SIZE_T    count /* [in] size_t  count  */
                                     )
                   {
                
                
                    return pif->putFromVariants(v, count);
                   }
                
                RCODE assignFromVariants( INTERFACE_CLI_IVARIANT**    v /* [in,flat] ::cli::iVariant*  v[]  */
                                        , SIZE_T    count /* [in] size_t  count  */
                                        )
                   {
                
                
                    return pif->assignFromVariants(v, count);
                   }
                

        
        
        }; // class CiArgListWrapper
        
        typedef CiArgListWrapper< ::cli::CCliPtr< INTERFACE_CLI_IARGLIST     > >  CiArgList;
        typedef CiArgListWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IARGLIST > >  CiArgList_nrc; /* No ref counting for interface used */
        typedef CiArgListWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IARGLIST > >  CiArgList_tmp; /* for temporary usage, same as CiArgList_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IARGLIST_H */
