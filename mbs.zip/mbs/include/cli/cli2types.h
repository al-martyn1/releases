#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLI2TYPES_H
#define CLI_CLI2TYPES_H

/* Add next lines to your C/C++ code
#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif
*/

#ifndef CLI_DETECTSIZE_H
    #include <cli/detectSize.h>
#endif

#ifndef CLI_DETECTTARGET_H
    #include <cli/detectTarget.h>
#endif

#if !defined(CLI_IO_IOTYPES_H) && !defined(CLI2TYPES_NO_CLI_IO_IOTYPES_H)
    #include <cli/io/ioTypes.h>
#endif

#if defined(_MSC_VER) || defined(__GNUC__)

    #if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
        #include <string.h>
    #endif

#endif

#if defined(WIN32) || defined(_WIN32)

    #if !defined(_WTYPES_H)    /* mingw inc guard */\
     && !defined(__wtypes_h__)     /* ms sdk inc guard */
        #include <wtypes.h>
    #endif

    #ifdef _MSC_VER
         #ifndef _BASETSD_H_
             #include <BaseTsd.h>
         #endif
    #else
        // mingw BaseTsd.h does not contain some definitions
        typedef signed char         INT8, *PINT8;
        typedef signed short        INT16, *PINT16;
        typedef signed int          INT32, *PINT32;
        typedef signed __int64      INT64, *PINT64;
        typedef unsigned char       UINT8, *PUINT8;
        typedef unsigned short      UINT16, *PUINT16;
        typedef unsigned int        UINT32, *PUINT32;
        typedef unsigned __int64    UINT64, *PUINT64;
    #endif

    #if !defined(_WINDEF_H)    /* mingw inc guard */\
     && !defined(_WINDEF_)     /* ms sdk inc guard */
        #include <windef.h>
     #endif

    #if !defined(_WINNT_H)    /* mingw inc guard */\
     && !defined(_WINNT_)     /* ms sdk inc guard */
        #include <winnt.h>
     #endif

    #if !defined(_INC_TCHAR) && !defined(__TCHAR_H)
        #include <tchar.h>
    #endif

    #ifdef _WIN64
    #define INT_PTR_EQUAL_TO_INT64          1
    #define UINT_PTR_EQUAL_TO_UINT64        1
    #else
    #define INT_PTR_EQUAL_TO_INT            1
    #define UINT_PTR_EQUAL_TO_UINT          1
    #endif

#else

    #include <stdint.h>
    #include <stdlib.h>
    #include <stddef.h>
    #include <unistd.h>

    #ifndef BASETYPES
    #define BASETYPES

    typedef char             CHAR,   *PCHAR;
    typedef wchar_t          WCHAR,  *PWCHAR;
    typedef short            SHORT,  *PSHORT;
    typedef int              INT,    *PINT;
    typedef long             LONG;

    typedef unsigned char    UCHAR,  *PUCHAR;
    typedef unsigned short   USHORT, *PUSHORT;
    typedef unsigned int     UINT,   *PUINT;
    typedef unsigned long    ULONG,  *PULONG;
    typedef void             VOID;
    typedef void            *PVOID, *LPVOID;

    typedef double           DOUBLE;
    typedef float            FLOAT;

    #if defined(_UNICODE) || defined(UNICODE)
        typedef WCHAR        TCHAR;
    #else
        typedef CHAR         TCHAR;
    #endif /* _UNICODE*/

    //# if __WORDSIZE == 64
    //_WIN64

    typedef int8_t           INT8, *PINT8;
    typedef int16_t          INT16, *PINT16;
    typedef int32_t          INT32, *PINT32;
    typedef int64_t          INT64, *PINT64;
    typedef uint8_t          UINT8, *PUINT8;
    typedef uint16_t         UINT16, *PUINT16;
    typedef uint32_t         UINT32, *PUINT32;
    typedef uint64_t         UINT64, *PUINT64;

    //typedef UINT32           DWORD;
    typedef unsigned long    DWORD;
    typedef long             BOOL;
    typedef uint8_t          BYTE;
    typedef uint16_t         WORD;
    //typedef float            FLOAT;

    #if (defined(__WORDSIZE) && (__WORDSIZE == 64)) || (defined(_INTEGRAL_MAX_BITS) && (_INTEGRAL_MAX_BITS == 64))

    typedef INT64            INT_PTR;
    typedef UINT64           UINT_PTR;
    typedef INT64            LONG_PTR;
    typedef UINT64           ULONG_PTR;
    typedef UINT64           DWORD_PTR;

    #define INT_PTR_EQUAL_TO_INT64          1
    #define UINT_PTR_EQUAL_TO_UINT64        1

    #else

    typedef INT32            INT_PTR;
    typedef UINT32           UINT_PTR;
    typedef INT32            LONG_PTR;
    typedef UINT32           ULONG_PTR;
    typedef UINT32           DWORD_PTR;

    #define INT_PTR_EQUAL_TO_INT            1
    #define UINT_PTR_EQUAL_TO_UINT          1

    #endif

    typedef size_t           SIZE_T;
    typedef ssize_t          SSIZE_T;


    #endif  /* BASETYPES */


    #ifndef FALSE
        #define FALSE               0
    #endif

    #ifndef TRUE
        #define TRUE                1
    #endif

    #ifndef IN
        #define IN
    #endif

    #ifndef OUT
        #define OUT
    #endif

    #ifndef OPTIONAL
        #define OPTIONAL
    #endif

    #define MAKEWORD(a, b)      ((WORD)(((BYTE)((DWORD_PTR)(a) & 0xff)) | ((WORD)((BYTE)((DWORD_PTR)(b) & 0xff))) << 8))
    #define MAKELONG(a, b)      ((LONG)(((WORD)((DWORD_PTR)(a) & 0xffff)) | ((DWORD)((WORD)((DWORD_PTR)(b) & 0xffff))) << 16))
    #define LOWORD(l)           ((WORD)((DWORD_PTR)(l) & 0xffff))
    #define HIWORD(l)           ((WORD)((DWORD_PTR)(l) >> 16))
    #define LOBYTE(w)           ((BYTE)((DWORD_PTR)(w) & 0xff))
    #define HIBYTE(w)           ((BYTE)((DWORD_PTR)(w) >> 8))

#endif /* WIN32 */

// limit constants for compatibility with linux
#ifndef WIN32

    #ifndef _UI64_MAX
        #define _UI64_MAX ULONG_LONG_MAX
    #endif

    #ifndef _I64_MAX
        #define _I64_MAX LONG_LONG_MAX
    #endif

    #ifndef _I64_MIN
        #define _I64_MIN LONG_LONG_MIN
    #endif

#endif



typedef const CHAR*    CONST_PCHAR;
typedef const WCHAR*   CONST_PWCHAR;

#ifndef RCODE_TYPES_DEFINED
#define RCODE_TYPES_DEFINED
typedef DWORD RCODE; /* result code */
typedef INT32 SRCODE; /* signed RCODE */
#endif

typedef UINT64   TICK_T;
typedef INT64    TICK_DIFF_T;

typedef UINT64   FILE_SIZE_T;
typedef INT64    FILE_DIFF_T;
#define FILE_SIZE_T_NPOS  ((UINT64)-1ll)




#if defined(__cplusplus)
    #define LDOUBLE10_STATIC_INLINE    inline
#else
    #define LDOUBLE10_STATIC_INLINE    static
#endif



#ifndef LDOUBLE10_CONVERSIONS1_DEFINED
    #define LDOUBLE10_CONVERSIONS1_DEFINED

    #ifdef __BORLANDC__

    #elif defined(_MSC_VER) || defined(__GNUC__)

        #include <cli/pshpack1.h>
        #if defined(__cplusplus)
        struct LDOUBLE10_as_chars{
        #else
        typedef struct tag_LDOUBLE10_as_chars{
        #endif
            char data[10];
        #if defined(__cplusplus)
        };
        #else
        } LDOUBLE10_as_chars;
        #endif
        #include <cli/poppack.h>

        LDOUBLE10_STATIC_INLINE
        void longDouble2doubleAsChars(const LDOUBLE10_as_chars *l, double *d)
        {
            int i;
            char *ch=(char*)d;
            memset(ch, 0, sizeof(*d));
            /*for(i=0;i<8;i++) ch[i]=0;*/
            for(i=0;i<6;i++)
               {
                ch[i]|=(l->data[i+1]>>3)&0x1f;
                ch[i]|=(l->data[i+2]&0x07)<<5;
               }
            ch[i]|=(l->data[i+1]>>3)&0x0f;
            ch[i]|=(l->data[i+2]&0x0f)<<4;
            ch[i+1]|=(l->data[i+2]>>4)&0x0f;
            ch[i+1]|=(l->data[i+3]<<4)&0x30;
            ch[i+1]|=l->data[i+3]&0xc0;
        }

        LDOUBLE10_STATIC_INLINE
        void double2longDoubleAsChars(const double *d, LDOUBLE10_as_chars *l)
        {
            int i;
            const char *ch=(const char*)d;
            memset(l, 0, sizeof(*l));
            /*for(i=0;i<10;i++) l->data[i]=0;*/
            for(i=0;i<6;i++)
              {
               l->data[i+1]|=(ch[i]&0x1f)<<3;
               l->data[i+2]=0;
               l->data[i+2]|=(ch[i]>>5)&0x07;
              }
            l->data[i+1]|=(ch[i]&0x0f)<<3;
            l->data[i+1]|=1<<7;
            l->data[i+2]|=(ch[i]>>4)&0x0f;
            l->data[i+2]|=(ch[i+1]<<4)&0xf0;
            l->data[i+3]|=(ch[i+1]>>4)&0x03;
            l->data[i+3]|=ch[i+1]&0xc0;
            l->data[i+3]|=(1-((ch[i+1]>>6)&1))*0x3c;
        }
    #else
        #error "Unsupported compiler"
    #endif

#endif // LDOUBLE10_CONVERSIONS1_DEFINED



#ifdef LDOUBLE10_TYPE_DEFINED


#else // LDOUBLE10_TYPE_DEFINED

    #define LDOUBLE10_TYPE_DEFINED

    #ifdef __BORLANDC__
        typedef long double LDOUBLE10;
    #elif defined(_MSC_VER) || defined(__GNUC__)

        // non-compliant to IEEE-754-1985
        // compliant to IEEE-854-1987
        #include <cli/pshpack1.h>
        #if defined(__cplusplus)
        struct LDOUBLE10
        #else
        typedef struct tag_LDOUBLE10
        #endif
        {
             UINT64  m:63;
             UINT64  i:1;
             UINT16  e:15;
             UINT16  s:1;

             #if defined(__cplusplus) && !defined(LDOUBLE10_NO_CONVERSIONS)

             LDOUBLE10(double d=0.0) : m(0), i(0), e(0), s(0)
                {
                 double2longDoubleAsChars(&d, (LDOUBLE10_as_chars*)this);
                }

             LDOUBLE10(const LDOUBLE10 &ld) : m(ld.m), i(ld.i), e(ld.e), s(ld.s)
                {
                }


             LDOUBLE10& operator=(double d)
                {
                 double2longDoubleAsChars(&d, (LDOUBLE10_as_chars*)this);
                 return *this;
                }

             LDOUBLE10& operator=(const LDOUBLE10 &ld)
                {
                 m = ld.m; i = ld.i; e = ld.e; s = ld.s;
                 return *this;
                }

             operator double() const
                {
                 double d;
                 longDouble2doubleAsChars((const LDOUBLE10_as_chars*)this, &d);
                 return d;
                }

        //void longDouble2double(const LDOUBLE10_as_chars *l, double *d)
        //void double2longDouble(const double *d, LDOUBLE10_as_chars *l)

             #endif // __cplusplus

        #if defined(__cplusplus)
        }; // LDOUBLE10;
        #else
        } LDOUBLE10;
        #endif

        #include <cli/poppack.h>

    #else
        #error "Unsupported compiler"
    #endif


#ifndef LDOUBLE10_CONVERSIONS2_DEFINED
    #define LDOUBLE10_CONVERSIONS2_DEFINED

    #ifdef __BORLANDC__

    #elif defined(_MSC_VER) || defined(__GNUC__)

    LDOUBLE10_STATIC_INLINE
    void longDouble2double(const LDOUBLE10 *l, double *d)
       {
        longDouble2doubleAsChars((const LDOUBLE10_as_chars*)l, d);
       }

    LDOUBLE10_STATIC_INLINE
    void double2longDouble( const double *d, LDOUBLE10 *l)
       {
        double2longDoubleAsChars(d, (LDOUBLE10_as_chars*)l);
       }

    #else
        #error "Unsupported compiler"
    #endif


#endif // LDOUBLE10_CONVERSIONS2_DEFINED

#endif /* LDOUBLE10_TYPE_DEFINED */



#if defined(_WIN32) || defined(WIN32)

    // typedef DWORD   COLORREF;

#else
    #ifndef CLI_COLORREF_POD_DEFINED
        #define CLI_COLORREF_POD_DEFINED
        typedef DWORD   COLORREF;
        #define RGB(r,g,b)          ((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)))
    #endif
#endif

#ifndef COLORREF_GET_RED
    #define COLORREF_GET_RED(color)      ((int)(unsigned)(0xFF&(color)))
#endif

#ifndef COLORREF_GET_GREEN
    #define COLORREF_GET_GREEN(color)    ((int)(unsigned)(0xFF&((color)>>8)))
#endif

#ifndef COLORREF_GET_BLUE
    #define COLORREF_GET_BLUE(color)     ((int)(unsigned)(0xFF&((color)>>16)))
#endif





#ifndef RC_OK
    #define RC_OK(code)    (((SRCODE)(code)) >=0)
#endif

#ifndef RCOK
    #define RCOK(code)     RC_OK(code)
#endif

#ifndef RC_FAIL
    #define RC_FAIL(code)  (((SRCODE)(code)) <0)
#endif

#ifndef RCFAIL
    #define RCFAIL(code)   RC_FAIL(code)
#endif


#define CONSTANT_BOOL(num)               num##ul
#define CONSTANT_DWORD(num)              num##ul
#define CONSTANT_WORD(num)               num##u
#define CONSTANT_SHORT(num)              num
#define CONSTANT_USHORT(num)             num
#define CONSTANT_LONG(num)               num##l
#define CONSTANT_INT(num)                num
#define CONSTANT_UINT(num)               num##u
#define CONSTANT_BYTE(num)               num##u

#define CONSTANT_INT64(num)              num##ll
#define CONSTANT_UINT64(num)             num##ull
#define CONSTANT_INT32(num)              num
#define CONSTANT_UINT32(num)             num##u

#define CONSTANT_INT16(num)              num
#define CONSTANT_UINT16(num)             num##u

#define CONSTANT_INT8(num)               num
#define CONSTANT_UINT8(num)              num##u



#if (defined(__WORDSIZE) && (__WORDSIZE == 64)) || (defined(_INTEGRAL_MAX_BITS) && (_INTEGRAL_MAX_BITS == 64))
    #define CONSTANT_INT_PTR(num)        CONSTANT_INT64(num)
    #define CONSTANT_UINT_PTR(num)       CONSTANT_UINT64(num)
    #define CONSTANT_LONG_PTR(num)       CONSTANT_INT64(num)
    #define CONSTANT_ULONG_PTR(num)      CONSTANT_UINT64(num)
    #define CONSTANT_DWORD_PTR(num)      CONSTANT_UINT64(num)
    #define CONSTANT_SIZE_T(num)         num##ull
#else
    #define CONSTANT_INT_PTR(num)        CONSTANT_INT32(num)
    #define CONSTANT_UINT_PTR(num)       CONSTANT_UINT32(num)
    #define CONSTANT_LONG_PTR(num)       CONSTANT_INT32(num)
    #define CONSTANT_ULONG_PTR(num)      CONSTANT_UINT32(num)
    #define CONSTANT_DWORD_PTR(num)      CONSTANT_UINT32(num)
    #define CONSTANT_SIZE_T(num)         num##ul
#endif

#define CONSTANT_RCODE(num)              CONSTANT_DWORD(num)
#define CONSTANT_SRCODE(num)             CONSTANT_INT32(num)

#ifndef SIZE_T_NPOS
    #if (defined(__WORDSIZE) && (__WORDSIZE == 64)) || (defined(_INTEGRAL_MAX_BITS) && (_INTEGRAL_MAX_BITS == 64))
        // 64 bit platform
        #define SIZE_T_NPOS    ((SIZE_T)-1LL)
    #else
        // 32 bit platform
        #define SIZE_T_NPOS    ((SIZE_T)-1L)
    #endif
#endif



//#include <cli/ifdefs.h>



#endif /* CLI_CLI2TYPES_H */

