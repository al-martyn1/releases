#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IALLOCATOR_H
#define CLI_IALLOCATOR_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/iallocator.h>", CLI_IALLOCATOR_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IALLOCATOR_H
    #include <cli/iallocator.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IDESTROYABLE_H
    #include <cli/idestroyable.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::allocator_flag */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_ALLOCATOR_FLAG             DWORD
#else
    #define ENUM_CLI_ALLOCATOR_FLAG             DWORD
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_ALLOCATOR_FLAG_FILL_MEMORY
    #define CLI_ALLOCATOR_FLAG_FILL_MEMORY    CONSTANT_DWORD(0x0100)
#endif /* CLI_ALLOCATOR_FLAG_FILL_MEMORY */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace allocator_flag {
                const DWORD fill_memory      = CONSTANT_DWORD(0x0100);
        }; // namespace allocator_flag
    }; // namespace cli
    /* using namespace ::cli::allocator_flag; */
    
#endif





/* ------------------------------------------------------ */
/* Interface: ::cli::iAllocator */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IALLOCATOR_IID
    #define INTERFACE_CLI_IALLOCATOR_IID    "/cli/iAllocator"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iAllocator
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IALLOCATOR
       #define INTERFACE_CLI_IALLOCATOR    ::cli::iAllocator
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iAllocator
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IALLOCATOR
       #define INTERFACE_CLI_IALLOCATOR    cli_iAllocator
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iAllocator methods */
            CLIMETHOD_(VOID*, allocate) (THIS_ SIZE_T    blockSize /* [in] size_t  blockSize  */
                                             , UINT    flags /* [in] uint  flags  */
                                             , BYTE    bFill /* [in] byte  bFill  */
                                        ) PURE;
            CLIMETHOD_(VOID*, reallocate) (THIS_ const VOID*    pMem /* [in] void*  pMem  */
                                               , SIZE_T    newBlockSize /* [in] size_t  newBlockSize  */
                                               , UINT    flags /* [in] uint  flags  */
                                               , BYTE    bFill /* [in] byte  bFill  */
                                          ) PURE;
            CLIMETHOD(deallocate) (THIS_ const VOID*    pMem /* [in] void*  pMem  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iAllocator >
           {
            static char const * getName() { return INTERFACE_CLI_IALLOCATOR_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iAllocator* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iAllocator > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iAllocator wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IALLOCATOR >
                                      */
                 >
        class CiAllocatorWrapper
        {
            public:
        
                typedef  CiAllocatorWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiAllocatorWrapper() :
                   pif(0) {}
        
                CiAllocatorWrapper( iAllocator *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiAllocatorWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiAllocatorWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiAllocatorWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiAllocatorWrapper(const CiAllocatorWrapper &i) :
                    pif(i.pif) { }
        
                ~CiAllocatorWrapper()  { }
        
                CiAllocatorWrapper& operator=(const CiAllocatorWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                VOID* allocate( SIZE_T    blockSize /* [in] size_t  blockSize  */
                              , UINT    flags /* [in] uint  flags  */
                              , BYTE    bFill /* [in] byte  bFill  */
                              )
                   {
                
                
                
                    return pif->allocate(blockSize, flags, bFill);
                   }
                
                VOID* reallocate( const VOID*    pMem /* [in] void*  pMem  */
                                , SIZE_T    newBlockSize /* [in] size_t  newBlockSize  */
                                , UINT    flags /* [in] uint  flags  */
                                , BYTE    bFill /* [in] byte  bFill  */
                                )
                   {
                
                
                
                
                    return pif->reallocate(pMem, newBlockSize, flags, bFill);
                   }
                
                RCODE deallocate( const VOID*    pMem /* [in] void*  pMem  */)
                   {
                
                    return pif->deallocate(pMem);
                   }
                

        
        
        }; // class CiAllocatorWrapper
        
        typedef CiAllocatorWrapper< ::cli::CCliPtr< INTERFACE_CLI_IALLOCATOR     > >  CiAllocator;
        typedef CiAllocatorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IALLOCATOR > >  CiAllocator_nrc; /* No ref counting for interface used */
        typedef CiAllocatorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IALLOCATOR > >  CiAllocator_tmp; /* for temporary usage, same as CiAllocator_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iSimpleAllocator */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iDestroyable;
        #ifndef INTERFACE_CLI_IDESTROYABLE
            #define INTERFACE_CLI_IDESTROYABLE        ::cli::iDestroyable
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IDESTROYABLE_PREDECLARED
    #define INTERFACE_CLI_IDESTROYABLE_PREDECLARED
    typedef interface tag_cli_iDestroyable   cli_iDestroyable;
    #endif //INTERFACE_CLI_IDESTROYABLE
    #ifndef INTERFACE_CLI_IDESTROYABLE
        #define INTERFACE_CLI_IDESTROYABLE        struct tag_cli_iDestroyable
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISIMPLEALLOCATOR_IID
    #define INTERFACE_CLI_ISIMPLEALLOCATOR_IID    "/cli/iSimpleAllocator"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iSimpleAllocator
    #define BASE_INTERFACE ::cli::iDestroyable
    #ifndef INTERFACE_CLI_ISIMPLEALLOCATOR
       #define INTERFACE_CLI_ISIMPLEALLOCATOR    ::cli::iSimpleAllocator
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iSimpleAllocator
    #define BASE_INTERFACE cli_iDestroyable
    #ifndef INTERFACE_CLI_ISIMPLEALLOCATOR
       #define INTERFACE_CLI_ISIMPLEALLOCATOR    cli_iSimpleAllocator
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDestroyable methods */
            CLIMETHOD_(VOID, destroy) (THIS) PURE;
            
            /* interface ::cli::iSimpleAllocator methods */
            CLIMETHOD_(VOID*, allocate) (THIS_ SIZE_T    blockSize /* [in] size_t  blockSize  */) PURE;
            CLIMETHOD_(VOID*, reallocate) (THIS_ const VOID*    pMem /* [in] void*  pMem  */
                                               , SIZE_T    newBlockSize /* [in] size_t  newBlockSize  */
                                          ) PURE;
            CLIMETHOD(free) (THIS_ const VOID*    pMem /* [in] void*  pMem  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iSimpleAllocator >
           {
            static char const * getName() { return INTERFACE_CLI_ISIMPLEALLOCATOR_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iSimpleAllocator* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iSimpleAllocator > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iSimpleAllocator wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ISIMPLEALLOCATOR >
                                      */
                 >
        class CiSimpleAllocatorWrapper
        {
            public:
        
                typedef  CiSimpleAllocatorWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiSimpleAllocatorWrapper() :
                   pif(0) {}
        
                CiSimpleAllocatorWrapper( iSimpleAllocator *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiSimpleAllocatorWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiSimpleAllocatorWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiSimpleAllocatorWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiSimpleAllocatorWrapper(const CiSimpleAllocatorWrapper &i) :
                    pif(i.pif) { }
        
                ~CiSimpleAllocatorWrapper()  { }
        
                CiSimpleAllocatorWrapper& operator=(const CiSimpleAllocatorWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                VOID destroy( )
                   {
                pif->destroy();
                   }
                
                VOID* allocate( SIZE_T    blockSize /* [in] size_t  blockSize  */)
                   {
                
                    return pif->allocate(blockSize);
                   }
                
                VOID* reallocate( const VOID*    pMem /* [in] void*  pMem  */
                                , SIZE_T    newBlockSize /* [in] size_t  newBlockSize  */
                                )
                   {
                
                
                    return pif->reallocate(pMem, newBlockSize);
                   }
                
                RCODE free( const VOID*    pMem /* [in] void*  pMem  */)
                   {
                
                    return pif->free(pMem);
                   }
                

        
        
        }; // class CiSimpleAllocatorWrapper
        
        typedef CiSimpleAllocatorWrapper< ::cli::CCliPtr< INTERFACE_CLI_ISIMPLEALLOCATOR     > >  CiSimpleAllocator;
        typedef CiSimpleAllocatorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISIMPLEALLOCATOR > >  CiSimpleAllocator_nrc; /* No ref counting for interface used */
        typedef CiSimpleAllocatorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISIMPLEALLOCATOR > >  CiSimpleAllocator_tmp; /* for temporary usage, same as CiSimpleAllocator_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IALLOCATOR_H */
