#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IDATADOM_H
#define CLI_IDATADOM_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/idatadom.h>", CLI_IDATADOM_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IDATADOM_H
    #include <cli/idatadom.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_DRAWING_PODTYPES_H
    #include <cli/drawing/podtypes.h>
#endif

#ifndef CLI_DRAWING_DRAWBASE_H
    #include <cli/drawing/drawbase.h>
#endif

#ifndef CLI_DRAWING_DRAWTYPES_H
    #include <cli/drawing/drawtypes.h>
#endif

#ifndef CLI_GUI_GUIPODS_H
    #include <cli/gui/guiPods.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_GUI_TYPES_H
    #include <cli/gui/types.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IVARMAP_H
    #include <cli/ivarmap.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::EDataNodeType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EDATANODETYPE              UINT
#else
    #define ENUM_CLI_EDATANODETYPE              UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EDATANODETYPE_ANY
    #define CLI_EDATANODETYPE_ANY             CONSTANT_UINT(0)
#endif /* CLI_EDATANODETYPE_ANY */

#ifndef CLI_EDATANODETYPE_NODE
    #define CLI_EDATANODETYPE_NODE            1
#endif /* CLI_EDATANODETYPE_NODE */

#ifndef CLI_EDATANODETYPE_ATTRIBUTE
    #define CLI_EDATANODETYPE_ATTRIBUTE       2
#endif /* CLI_EDATANODETYPE_ATTRIBUTE */

#ifndef CLI_EDATANODETYPE_TEXT
    #define CLI_EDATANODETYPE_TEXT            4
#endif /* CLI_EDATANODETYPE_TEXT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EDataNodeType {
                const UINT any              = CONSTANT_UINT(0);
                const UINT node             = CONSTANT_UINT(1);
                const UINT attribute        = CONSTANT_UINT(2);
                const UINT text             = CONSTANT_UINT(4);
        }; // namespace EDataNodeType
    }; // namespace cli
    /* using namespace ::cli::EDataNodeType; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::EDataNodeSerializeFlag */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EDATANODESERIALIZEFLAG     UINT
#else
    #define ENUM_CLI_EDATANODESERIALIZEFLAG     UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EDATANODESERIALIZEFLAG_NOXMLDECLARATION
    #define CLI_EDATANODESERIALIZEFLAG_NOXMLDECLARATION       CONSTANT_UINT(0x0001)
#endif /* CLI_EDATANODESERIALIZEFLAG_NOXMLDECLARATION */

#ifndef CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO
    #define CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO             CONSTANT_UINT(0x0002)
#endif /* CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO */

#ifndef CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME
    #define CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME         CONSTANT_UINT(0x0004)
#endif /* CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME */

#ifndef CLI_EDATANODESERIALIZEFLAG_WRITEBOM
    #define CLI_EDATANODESERIALIZEFLAG_WRITEBOM               CONSTANT_UINT(0x0008)
#endif /* CLI_EDATANODESERIALIZEFLAG_WRITEBOM */

#ifndef CLI_EDATANODESERIALIZEFLAG_WRITECONDENCED
    #define CLI_EDATANODESERIALIZEFLAG_WRITECONDENCED         CONSTANT_UINT(0x0010)
#endif /* CLI_EDATANODESERIALIZEFLAG_WRITECONDENCED */

#ifndef CLI_EDATANODESERIALIZEFLAG_WRITEPRETTY
    #define CLI_EDATANODESERIALIZEFLAG_WRITEPRETTY            CONSTANT_UINT(0x0020)
#endif /* CLI_EDATANODESERIALIZEFLAG_WRITEPRETTY */

#ifndef CLI_EDATANODESERIALIZEFLAG_XMLSTANDALONE
    #define CLI_EDATANODESERIALIZEFLAG_XMLSTANDALONE          CONSTANT_UINT(0x0040)
#endif /* CLI_EDATANODESERIALIZEFLAG_XMLSTANDALONE */

#ifndef CLI_EDATANODESERIALIZEFLAG_FORCENONSERIALIZABLE
    #define CLI_EDATANODESERIALIZEFLAG_FORCENONSERIALIZABLE   CONSTANT_UINT(0x0080)
#endif /* CLI_EDATANODESERIALIZEFLAG_FORCENONSERIALIZABLE */

#ifndef CLI_EDATANODESERIALIZEFLAG_WRITESTAMP
    #define CLI_EDATANODESERIALIZEFLAG_WRITESTAMP             CONSTANT_UINT(0x0100)
#endif /* CLI_EDATANODESERIALIZEFLAG_WRITESTAMP */

#ifndef CLI_EDATANODESERIALIZEFLAG_WRITESTAMPASDATETIME
    #define CLI_EDATANODESERIALIZEFLAG_WRITESTAMPASDATETIME   CONSTANT_UINT(0x0200)
#endif /* CLI_EDATANODESERIALIZEFLAG_WRITESTAMPASDATETIME */

#ifndef CLI_EDATANODESERIALIZEFLAG_WRITEONLYCOMMONENTITIES
    #define CLI_EDATANODESERIALIZEFLAG_WRITEONLYCOMMONENTITIES                CONSTANT_UINT(0x0400)
#endif /* CLI_EDATANODESERIALIZEFLAG_WRITEONLYCOMMONENTITIES */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EDataNodeSerializeFlag {
                const UINT noXmlDeclaration = CONSTANT_UINT(0x0001);
                const UINT noTypeInfo       = CONSTANT_UINT(0x0002);
                const UINT updateNodeName   = CONSTANT_UINT(0x0004);
                const UINT writeBom         = CONSTANT_UINT(0x0008);
                const UINT writeCondenced   = CONSTANT_UINT(0x0010);
                const UINT writePretty      = CONSTANT_UINT(0x0020);
                const UINT xmlStandalone    = CONSTANT_UINT(0x0040);
                const UINT forceNonSerializable     = CONSTANT_UINT(0x0080);
                const UINT writeStamp       = CONSTANT_UINT(0x0100);
                const UINT writeStampAsDateTime     = CONSTANT_UINT(0x0200);
                const UINT writeOnlyCommonEntities  = CONSTANT_UINT(0x0400);
        }; // namespace EDataNodeSerializeFlag
    }; // namespace cli
    /* using namespace ::cli::EDataNodeSerializeFlag; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::EDataNodeFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EDATANODEFLAGS             UINT
#else
    #define ENUM_CLI_EDATANODEFLAGS             UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EDATANODEFLAGS_NONSERIALIZABLE
    #define CLI_EDATANODEFLAGS_NONSERIALIZABLE                CONSTANT_UINT(0x00000001)
#endif /* CLI_EDATANODEFLAGS_NONSERIALIZABLE */

#ifndef CLI_EDATANODEFLAGS_USERFLAG1
    #define CLI_EDATANODEFLAGS_USERFLAG1      CONSTANT_UINT(0x00010000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG1 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG2
    #define CLI_EDATANODEFLAGS_USERFLAG2      CONSTANT_UINT(0x00020000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG2 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG3
    #define CLI_EDATANODEFLAGS_USERFLAG3      CONSTANT_UINT(0x00040000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG3 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG4
    #define CLI_EDATANODEFLAGS_USERFLAG4      CONSTANT_UINT(0x00080000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG4 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG5
    #define CLI_EDATANODEFLAGS_USERFLAG5      CONSTANT_UINT(0x00100000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG5 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG6
    #define CLI_EDATANODEFLAGS_USERFLAG6      CONSTANT_UINT(0x00200000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG6 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG7
    #define CLI_EDATANODEFLAGS_USERFLAG7      CONSTANT_UINT(0x00400000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG7 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG8
    #define CLI_EDATANODEFLAGS_USERFLAG8      CONSTANT_UINT(0x00800000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG8 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG9
    #define CLI_EDATANODEFLAGS_USERFLAG9      CONSTANT_UINT(0x01000000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG9 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG10
    #define CLI_EDATANODEFLAGS_USERFLAG10     CONSTANT_UINT(0x02000000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG10 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG11
    #define CLI_EDATANODEFLAGS_USERFLAG11     CONSTANT_UINT(0x04000000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG11 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG12
    #define CLI_EDATANODEFLAGS_USERFLAG12     CONSTANT_UINT(0x08000000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG12 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG13
    #define CLI_EDATANODEFLAGS_USERFLAG13     CONSTANT_UINT(0x10000000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG13 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG14
    #define CLI_EDATANODEFLAGS_USERFLAG14     CONSTANT_UINT(0x20000000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG14 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG15
    #define CLI_EDATANODEFLAGS_USERFLAG15     CONSTANT_UINT(0x40000000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG15 */

#ifndef CLI_EDATANODEFLAGS_USERFLAG16
    #define CLI_EDATANODEFLAGS_USERFLAG16     CONSTANT_UINT(0x80000000)
#endif /* CLI_EDATANODEFLAGS_USERFLAG16 */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EDataNodeFlags {
                const UINT nonSerializable  = CONSTANT_UINT(0x00000001);
                const UINT userFlag1        = CONSTANT_UINT(0x00010000);
                const UINT userFlag2        = CONSTANT_UINT(0x00020000);
                const UINT userFlag3        = CONSTANT_UINT(0x00040000);
                const UINT userFlag4        = CONSTANT_UINT(0x00080000);
                const UINT userFlag5        = CONSTANT_UINT(0x00100000);
                const UINT userFlag6        = CONSTANT_UINT(0x00200000);
                const UINT userFlag7        = CONSTANT_UINT(0x00400000);
                const UINT userFlag8        = CONSTANT_UINT(0x00800000);
                const UINT userFlag9        = CONSTANT_UINT(0x01000000);
                const UINT userFlag10       = CONSTANT_UINT(0x02000000);
                const UINT userFlag11       = CONSTANT_UINT(0x04000000);
                const UINT userFlag12       = CONSTANT_UINT(0x08000000);
                const UINT userFlag13       = CONSTANT_UINT(0x10000000);
                const UINT userFlag14       = CONSTANT_UINT(0x20000000);
                const UINT userFlag15       = CONSTANT_UINT(0x40000000);
                const UINT userFlag16       = CONSTANT_UINT(0x80000000);
        }; // namespace EDataNodeFlags
    }; // namespace cli
    /* using namespace ::cli::EDataNodeFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::EDataNodeEventMask */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EDATANODEEVENTMASK         UINT
#else
    #define ENUM_CLI_EDATANODEEVENTMASK         UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EDATANODEEVENTMASK_VALUECHANGED
    #define CLI_EDATANODEEVENTMASK_VALUECHANGED               CONSTANT_UINT(0x01)
#endif /* CLI_EDATANODEEVENTMASK_VALUECHANGED */

#ifndef CLI_EDATANODEEVENTMASK_CHILDVALUECHANGED
    #define CLI_EDATANODEEVENTMASK_CHILDVALUECHANGED          CONSTANT_UINT(0x02)
#endif /* CLI_EDATANODEEVENTMASK_CHILDVALUECHANGED */

#ifndef CLI_EDATANODEEVENTMASK_CHILDADDED
    #define CLI_EDATANODEEVENTMASK_CHILDADDED                 CONSTANT_UINT(0x04)
#endif /* CLI_EDATANODEEVENTMASK_CHILDADDED */

#ifndef CLI_EDATANODEEVENTMASK_CHILDREMOVED
    #define CLI_EDATANODEEVENTMASK_CHILDREMOVED               CONSTANT_UINT(0x08)
#endif /* CLI_EDATANODEEVENTMASK_CHILDREMOVED */

#ifndef CLI_EDATANODEEVENTMASK_CHILDSMODIFIED
    #define CLI_EDATANODEEVENTMASK_CHILDSMODIFIED             CONSTANT_UINT(0x0C)
#endif /* CLI_EDATANODEEVENTMASK_CHILDSMODIFIED */

#ifndef CLI_EDATANODEEVENTMASK_FLAGDONTCHECKTAG
    #define CLI_EDATANODEEVENTMASK_FLAGDONTCHECKTAG           CONSTANT_UINT(0x20)
#endif /* CLI_EDATANODEEVENTMASK_FLAGDONTCHECKTAG */

#ifndef CLI_EDATANODEEVENTMASK_FLAGEXCEPTTAG
    #define CLI_EDATANODEEVENTMASK_FLAGEXCEPTTAG              CONSTANT_UINT(0x10)
#endif /* CLI_EDATANODEEVENTMASK_FLAGEXCEPTTAG */

#ifndef CLI_EDATANODEEVENTMASK_FLAGEQUALTOTAG
    #define CLI_EDATANODEEVENTMASK_FLAGEQUALTOTAG             CONSTANT_UINT(0x00)
#endif /* CLI_EDATANODEEVENTMASK_FLAGEQUALTOTAG */

#ifndef CLI_EDATANODEEVENTMASK_ALLEVENTS
    #define CLI_EDATANODEEVENTMASK_ALLEVENTS  CONSTANT_UINT(0xFFFFFFFF)
#endif /* CLI_EDATANODEEVENTMASK_ALLEVENTS */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EDataNodeEventMask {
                const UINT valueChanged     = CONSTANT_UINT(0x01);
                const UINT childValueChanged        = CONSTANT_UINT(0x02);
                const UINT childAdded       = CONSTANT_UINT(0x04);
                const UINT childRemoved     = CONSTANT_UINT(0x08);
                const UINT childsModified   = CONSTANT_UINT(0x0C);
                const UINT flagDontCheckTag = CONSTANT_UINT(0x20);
                const UINT flagExceptTag    = CONSTANT_UINT(0x10);
                const UINT flagEqualToTag   = CONSTANT_UINT(0x00);
                const UINT allEvents        = CONSTANT_UINT(0xFFFFFFFF);
        }; // namespace EDataNodeEventMask
    }; // namespace cli
    /* using namespace ::cli::EDataNodeEventMask; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::EXPathExpressionFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EXPATHEXPRESSIONFLAGS      UINT
#else
    #define ENUM_CLI_EXPATHEXPRESSIONFLAGS      UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EXPATHEXPRESSIONFLAGS_EXPRNORMAL
    #define CLI_EXPATHEXPRESSIONFLAGS_EXPRNORMAL              CONSTANT_UINT(0x00)
#endif /* CLI_EXPATHEXPRESSIONFLAGS_EXPRNORMAL */

#ifndef CLI_EXPATHEXPRESSIONFLAGS_EXPRSHORT
    #define CLI_EXPATHEXPRESSIONFLAGS_EXPRSHORT               CONSTANT_UINT(0x01)
#endif /* CLI_EXPATHEXPRESSIONFLAGS_EXPRSHORT */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EXPathExpressionFlags {
                const UINT exprNormal       = CONSTANT_UINT(0x00);
                const UINT exprShort        = CONSTANT_UINT(0x01);
        }; // namespace EXPathExpressionFlags
    }; // namespace cli
    /* using namespace ::cli::EXPathExpressionFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Enum: ::cli::EDataNodeSwapFlags */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EDATANODESWAPFLAGS         UINT
#else
    #define ENUM_CLI_EDATANODESWAPFLAGS         UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EDATANODESWAPFLAGS_NOUPDATE
    #define CLI_EDATANODESWAPFLAGS_NOUPDATE   CONSTANT_UINT(0x00)
#endif /* CLI_EDATANODESWAPFLAGS_NOUPDATE */

#ifndef CLI_EDATANODESWAPFLAGS_UPDATEINPUTSTREAMID
    #define CLI_EDATANODESWAPFLAGS_UPDATEINPUTSTREAMID        CONSTANT_UINT(0x01)
#endif /* CLI_EDATANODESWAPFLAGS_UPDATEINPUTSTREAMID */

#ifndef CLI_EDATANODESWAPFLAGS_UPDATESTREAMID
    #define CLI_EDATANODESWAPFLAGS_UPDATESTREAMID             CONSTANT_UINT(0x02)
#endif /* CLI_EDATANODESWAPFLAGS_UPDATESTREAMID */

#ifndef CLI_EDATANODESWAPFLAGS_UPDATELINENO
    #define CLI_EDATANODESWAPFLAGS_UPDATELINENO               CONSTANT_UINT(0x04)
#endif /* CLI_EDATANODESWAPFLAGS_UPDATELINENO */

#ifndef CLI_EDATANODESWAPFLAGS_UPDATELINEPOS
    #define CLI_EDATANODESWAPFLAGS_UPDATELINEPOS              CONSTANT_UINT(0x08)
#endif /* CLI_EDATANODESWAPFLAGS_UPDATELINEPOS */

#ifndef CLI_EDATANODESWAPFLAGS_UPDATESTREAMINFO
    #define CLI_EDATANODESWAPFLAGS_UPDATESTREAMINFO           CONSTANT_UINT(0x0F)
#endif /* CLI_EDATANODESWAPFLAGS_UPDATESTREAMINFO */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EDataNodeSwapFlags {
                const UINT noUpdate         = CONSTANT_UINT(0x00);
                const UINT updateInputStreamId      = CONSTANT_UINT(0x01);
                const UINT updateStreamId   = CONSTANT_UINT(0x02);
                const UINT updateLineNo     = CONSTANT_UINT(0x04);
                const UINT updateLinePos    = CONSTANT_UINT(0x08);
                const UINT updateStreamInfo = CONSTANT_UINT(0x0F);
        }; // namespace EDataNodeSwapFlags
    }; // namespace cli
    /* using namespace ::cli::EDataNodeSwapFlags; */
    
#endif





/* ------------------------------------------------------ */
/* Interface: ::cli::iDataNode */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iDataEventHandler;
        #ifndef INTERFACE_CLI_IDATAEVENTHANDLER
            #define INTERFACE_CLI_IDATAEVENTHANDLER   ::cli::iDataEventHandler
        #endif

        interface                                iDataNode;
        #ifndef INTERFACE_CLI_IDATANODE
            #define INTERFACE_CLI_IDATANODE           ::cli::iDataNode
        #endif

        interface                                iDataNodeList;
        #ifndef INTERFACE_CLI_IDATANODELIST
            #define INTERFACE_CLI_IDATANODELIST       ::cli::iDataNodeList
        #endif

        interface                                iReadOnlyVariant;
        #ifndef INTERFACE_CLI_IREADONLYVARIANT
            #define INTERFACE_CLI_IREADONLYVARIANT    ::cli::iReadOnlyVariant
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

        interface                                iVariant;
        #ifndef INTERFACE_CLI_IVARIANT
            #define INTERFACE_CLI_IVARIANT            ::cli::iVariant
        #endif

        interface                                iVariantMap;
        #ifndef INTERFACE_CLI_IVARIANTMAP
            #define INTERFACE_CLI_IVARIANTMAP         ::cli::iVariantMap
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IDATAEVENTHANDLER_PREDECLARED
    #define INTERFACE_CLI_IDATAEVENTHANDLER_PREDECLARED
    typedef interface tag_cli_iDataEventHandler                  cli_iDataEventHandler;
    #endif //INTERFACE_CLI_IDATAEVENTHANDLER
    #ifndef INTERFACE_CLI_IDATAEVENTHANDLER
        #define INTERFACE_CLI_IDATAEVENTHANDLER   struct tag_cli_iDataEventHandler
    #endif

    #ifndef INTERFACE_CLI_IDATANODE_PREDECLARED
    #define INTERFACE_CLI_IDATANODE_PREDECLARED
    typedef interface tag_cli_iDataNode      cli_iDataNode;
    #endif //INTERFACE_CLI_IDATANODE
    #ifndef INTERFACE_CLI_IDATANODE
        #define INTERFACE_CLI_IDATANODE           struct tag_cli_iDataNode
    #endif

    #ifndef INTERFACE_CLI_IDATANODELIST_PREDECLARED
    #define INTERFACE_CLI_IDATANODELIST_PREDECLARED
    typedef interface tag_cli_iDataNodeList  cli_iDataNodeList;
    #endif //INTERFACE_CLI_IDATANODELIST
    #ifndef INTERFACE_CLI_IDATANODELIST
        #define INTERFACE_CLI_IDATANODELIST       struct tag_cli_iDataNodeList
    #endif

    #ifndef INTERFACE_CLI_IREADONLYVARIANT_PREDECLARED
    #define INTERFACE_CLI_IREADONLYVARIANT_PREDECLARED
    typedef interface tag_cli_iReadOnlyVariant                   cli_iReadOnlyVariant;
    #endif //INTERFACE_CLI_IREADONLYVARIANT
    #ifndef INTERFACE_CLI_IREADONLYVARIANT
        #define INTERFACE_CLI_IREADONLYVARIANT    struct tag_cli_iReadOnlyVariant
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif

    #ifndef INTERFACE_CLI_IVARIANT_PREDECLARED
    #define INTERFACE_CLI_IVARIANT_PREDECLARED
    typedef interface tag_cli_iVariant       cli_iVariant;
    #endif //INTERFACE_CLI_IVARIANT
    #ifndef INTERFACE_CLI_IVARIANT
        #define INTERFACE_CLI_IVARIANT            struct tag_cli_iVariant
    #endif

    #ifndef INTERFACE_CLI_IVARIANTMAP_PREDECLARED
    #define INTERFACE_CLI_IVARIANTMAP_PREDECLARED
    typedef interface tag_cli_iVariantMap    cli_iVariantMap;
    #endif //INTERFACE_CLI_IVARIANTMAP
    #ifndef INTERFACE_CLI_IVARIANTMAP
        #define INTERFACE_CLI_IVARIANTMAP         struct tag_cli_iVariantMap
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IDATANODE_IID
    #define INTERFACE_CLI_IDATANODE_IID    "/cli/iDataNode"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iDataNode
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IDATANODE
       #define INTERFACE_CLI_IDATANODE    ::cli::iDataNode
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iDataNode
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IDATANODE
       #define INTERFACE_CLI_IDATANODE    cli_iDataNode
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDataNode methods */
            CLIMETHOD(nodeTypeGet) (THIS_ ENUM_CLI_EDATANODETYPE*    _nodeType /* [out] ::cli::EDataNodeType _nodeType  */) PURE;
            CLIMETHOD(nodeTypeSet) (THIS_ ENUM_CLI_EDATANODETYPE    _nodeType /* [in] ::cli::EDataNodeType  _nodeType  */) PURE;
            CLIMETHOD(nodeNameGet) (THIS_ CLISTR*           _nodeName) PURE;
            CLIMETHOD(nodeNameSet) (THIS_ const CLISTR*     _nodeName) PURE;
            CLIMETHOD(nodeFlagsGet) (THIS_ ENUM_CLI_EDATANODEFLAGS*    _nodeFlags /* [out] ::cli::EDataNodeFlags _nodeFlags  */) PURE;
            CLIMETHOD(nodeFlagsSet) (THIS_ ENUM_CLI_EDATANODEFLAGS    _nodeFlags /* [in] ::cli::EDataNodeFlags  _nodeFlags  */) PURE;
            CLIMETHOD(childIndexGet) (THIS_ SIZE_T*    _childIndex /* [out] size_t _childIndex  */
                                          , const CLISTR*     idx1
                                     ) PURE;
            CLIMETHOD(childIndexSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(attrIndexGet) (THIS_ SIZE_T*    _attrIndex /* [out] size_t _attrIndex  */
                                         , const CLISTR*     idx1
                                    ) PURE;
            CLIMETHOD(attrIndexSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(childsGet) (THIS_ INTERFACE_CLI_IDATANODE**    _childs /* [out] ::cli::iDataNode* _childs  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 ) PURE;
            CLIMETHOD(childsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(inputStreamIdGet) (THIS_ SIZE_T*    _inputStreamId /* [out] size_t _inputStreamId  */) PURE;
            CLIMETHOD(inputStreamIdSet) (THIS_ SIZE_T    _inputStreamId /* [in] size_t  _inputStreamId  */) PURE;
            CLIMETHOD(streamIdGet) (THIS_ SIZE_T*    _streamId /* [out] size_t _streamId  */) PURE;
            CLIMETHOD(streamIdSet) (THIS_ SIZE_T    _streamId /* [in] size_t  _streamId  */) PURE;
            CLIMETHOD(lineNoGet) (THIS_ SIZE_T*    _lineNo /* [out] size_t _lineNo  */) PURE;
            CLIMETHOD(lineNoSet) (THIS_ SIZE_T    _lineNo /* [in] size_t  _lineNo  */) PURE;
            CLIMETHOD(linePosGet) (THIS_ SIZE_T*    _linePos /* [out] size_t _linePos  */) PURE;
            CLIMETHOD(linePosSet) (THIS_ SIZE_T    _linePos /* [in] size_t  _linePos  */) PURE;
            CLIMETHOD(levelNoGet) (THIS_ SIZE_T*    _levelNo /* [out] size_t _levelNo  */) PURE;
            CLIMETHOD(createDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                           , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                           , const CLISTR*     nodeName
                                           , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                      ) PURE;
            CLIMETHOD(createDataNodeChars) (THIS_ INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                                , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                                , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                           ) PURE;
            CLIMETHOD(createChildDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                                , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                , const CLISTR*     nodeName
                                                , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                           ) PURE;
            CLIMETHOD(createChildDataNodeChars) (THIS_ INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                                     , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                     , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                                     , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                                ) PURE;
            CLIMETHOD(cloneDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeCopy /* [out] ::cli::iDataNode* pNodeCopy  */) PURE;
            CLIMETHOD(setParentNode) (THIS_ INTERFACE_CLI_IDATANODE*    pParentNode /* [in] ::cli::iDataNode*  pParentNode  */) PURE;
            CLIMETHOD(getParentNode) (THIS_ INTERFACE_CLI_IDATANODE**    pParentNode /* [out] ::cli::iDataNode* pParentNode  */) PURE;
            CLIMETHOD(getRootNode) (THIS_ INTERFACE_CLI_IDATANODE**    pRootNode /* [out] ::cli::iDataNode* pRootNode  */) PURE;
            CLIMETHOD(getChildNodeType) (THIS_ ENUM_CLI_EDATANODETYPE*    childType /* [out] ::cli::EDataNodeType childType  */
                                             , SIZE_T    where /* [in] size_t  where  */
                                        ) PURE;
            CLIMETHOD(lockChildNodes) (THIS) PURE;
            CLIMETHOD(unlockChildNodes) (THIS) PURE;
            CLIMETHOD(getChildsCount) (THIS_ SIZE_T*    childsCount /* [out] size_t childsCount  */) PURE;
            CLIMETHOD_(SIZE_T, getChildsCountSimple) (THIS) PURE;
            CLIMETHOD(getChildNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                         , SIZE_T    nodeIndex /* [in] size_t  nodeIndex  */
                                    ) PURE;
            CLIMETHOD(insertChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                            , SIZE_T    where /* [in] size_t  where  */
                                       ) PURE;
            CLIMETHOD(pushBackChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(moveChildNodeFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeFrom /* [in] ::cli::iDataNode*  pNodeFrom  */
                                              , SIZE_T    moveFromIdx /* [in] size_t  moveFromIdx  */
                                              , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                         ) PURE;
            CLIMETHOD(moveChildNodesByTypeFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                     , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                                ) PURE;
            CLIMETHOD(moveChildNodesByTypeFromEx) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                       , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                                       , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                                  ) PURE;
            CLIMETHOD(eraseChildNode) (THIS_ SIZE_T    where /* [in] size_t  where  */) PURE;
            CLIMETHOD(swapChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeNew /* [in] ::cli::iDataNode*  pNodeNew  */
                                          , SIZE_T    where /* [in] size_t  where  */
                                          , ENUM_CLI_EDATANODESWAPFLAGS    flags /* [in] ::cli::EDataNodeSwapFlags  flags  */
                                          , INTERFACE_CLI_IDATANODE**    pNodePrev /* [out,optional] ::cli::iDataNode* pNodePrev  */
                                     ) PURE;
            CLIMETHOD(clearChildsEx) (THIS_ ENUM_CLI_EDATANODETYPE    keepTypes /* [in] ::cli::EDataNodeType  keepTypes  */) PURE;
            CLIMETHOD(clearChilds) (THIS) PURE;
            CLIMETHOD(getChildNodes) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */) PURE;
            CLIMETHOD(getChildList) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */) PURE;
            CLIMETHOD(setChildList) (THIS_ INTERFACE_CLI_IDATANODELIST*    pNodeList /* [in] ::cli::iDataNodeList*  pNodeList  */) PURE;
            CLIMETHOD(swapChilds) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(getChildsToListByTypeAndName) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                         , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                         , const CLISTR*     names
                                                    ) PURE;
            CLIMETHOD(getChildsToListByTypeAndNameChars) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                              , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                              , const WCHAR*    names /* [in,flat] wchar  names[]  */
                                                         ) PURE;
            CLIMETHOD(getChildsToListByType) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                  , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                             ) PURE;
            CLIMETHOD(getChildNodeByIndex) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                                , SIZE_T    idx /* [in] size_t  idx  */
                                           ) PURE;
            CLIMETHOD_(BOOL, findChild) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD_(SIZE_T, getChildIndex) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(getNextSibling) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeSibling /* [out] ::cli::iDataNode* pNodeSibling  */) PURE;
            CLIMETHOD(getPrevSibling) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeSibling /* [out] ::cli::iDataNode* pNodeSibling  */) PURE;
            CLIMETHOD_(SIZE_T, getChildIndexByName) (THIS_ const CLISTR*     name) PURE;
            CLIMETHOD_(SIZE_T, getChildIndexByNameType) (THIS_ const CLISTR*     name
                                                             , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                        ) PURE;
            CLIMETHOD_(SIZE_T, getChildIndexByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */) PURE;
            CLIMETHOD_(SIZE_T, getChildIndexByNameTypeChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                                  , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                             ) PURE;
            CLIMETHOD_(BOOL, compareName) (THIS_ const CLISTR*     name) PURE;
            CLIMETHOD_(BOOL, compareNameType) (THIS_ const CLISTR*     name
                                                   , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                              ) PURE;
            CLIMETHOD_(BOOL, compareNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */) PURE;
            CLIMETHOD_(BOOL, compareNameTypeChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                        , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                   ) PURE;
            CLIMETHOD(getDataNodeValue) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    pValue /* [out] ::cli::iReadOnlyVariant* pValue  */) PURE;
            CLIMETHOD(copyValueToNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(removeValue) (THIS) PURE;
            CLIMETHOD_(BOOL, hasValue) (THIS_ BOOL    emptyAsNoValue /* [in] bool  emptyAsNoValue  */) PURE;
            CLIMETHOD_(ENUM_CLI_VARIANTTYPE, getValueType) (THIS) PURE;
            CLIMETHOD(setValue) (THIS_ INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */) PURE;
            CLIMETHOD(setValueCopy) (THIS_ INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */) PURE;
            CLIMETHOD(setValueToNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(setValueToNodeCopy) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(setEmpty) (THIS) PURE;
            CLIMETHOD(setChar) (THIS_ CHAR    ch /* [in] char  ch  */) PURE;
            CLIMETHOD(setWChar) (THIS_ WCHAR    wch /* [in] wchar  wch  */) PURE;
            CLIMETHOD(setShort) (THIS_ SHORT    s /* [in] short  s  */) PURE;
            CLIMETHOD(setUShort) (THIS_ USHORT    us /* [in] ushort  us  */) PURE;
            CLIMETHOD(setInt) (THIS_ INT    i /* [in] int  i  */) PURE;
            CLIMETHOD(setUInt) (THIS_ UINT    i /* [in] uint  i  */) PURE;
            CLIMETHOD(setColorref) (THIS_ COLORREF    i /* [in] colorref  i  */) PURE;
            CLIMETHOD(setInt64) (THIS_ INT64    i /* [in] int64  i  */) PURE;
            CLIMETHOD(setUInt64) (THIS_ UINT64    i /* [in] uint64  i  */) PURE;
            CLIMETHOD(setIntPtr) (THIS_ INT_PTR    i /* [in] int_ptr  i  */) PURE;
            CLIMETHOD(setUIntPtr) (THIS_ UINT_PTR    i /* [in] uint_ptr  i  */) PURE;
            CLIMETHOD(setFloat) (THIS_ FLOAT    f /* [in] float  f  */) PURE;
            CLIMETHOD(setDouble) (THIS_ DOUBLE    d /* [in] double  d  */) PURE;
            CLIMETHOD(setPtr) (THIS_ const VOID*    vptr /* [in] void*  vptr  */) PURE;
            CLIMETHOD(setString) (THIS_ const CLISTR*     str) PURE;
            CLIMETHOD(setStringPStr) (THIS_ CLIPSTR           str) PURE;
            CLIMETHOD(setStringChars) (THIS_ const WCHAR*    str /* [in,flat] wchar  str[]  */
                                           , SIZE_T    strSize /* [in] size_t  strSize  */
                                      ) PURE;
            CLIMETHOD(setDump) (THIS_ const BYTE*    d /* [in,flat] byte  d[]  */
                                    , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                               ) PURE;
            CLIMETHOD(setDate) (THIS_ const STRUCT_CLI_CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */) PURE;
            CLIMETHOD(setBool) (THIS_ BOOL    b /* [in] bool  b  */) PURE;
            CLIMETHOD(getChar) (THIS_ CHAR*    ch /* [out] char ch  */) PURE;
            CLIMETHOD(getWChar) (THIS_ WCHAR*    wch /* [out] wchar wch  */) PURE;
            CLIMETHOD(getShort) (THIS_ SHORT*    s /* [out] short s  */) PURE;
            CLIMETHOD(getUShort) (THIS_ USHORT*    us /* [out] ushort us  */) PURE;
            CLIMETHOD(getInt) (THIS_ INT*    i /* [out] int i  */) PURE;
            CLIMETHOD(getUInt) (THIS_ UINT*    i /* [out] uint i  */) PURE;
            CLIMETHOD(getColorref) (THIS_ COLORREF*    i /* [out] colorref i  */) PURE;
            CLIMETHOD(getInt64) (THIS_ INT64*    i /* [out] int64 i  */) PURE;
            CLIMETHOD(getUInt64) (THIS_ UINT64*    i /* [out] uint64 i  */) PURE;
            CLIMETHOD(getIntPtr) (THIS_ INT_PTR*    i /* [out] int_ptr i  */) PURE;
            CLIMETHOD(getUIntPtr) (THIS_ UINT_PTR*    i /* [out] uint_ptr i  */) PURE;
            CLIMETHOD(getFloat) (THIS_ FLOAT*    f /* [out] float f  */) PURE;
            CLIMETHOD(getDouble) (THIS_ DOUBLE*    d /* [out] double d  */) PURE;
            CLIMETHOD(getPtr) (THIS_ VOID**    vptr /* [out] void* vptr  */) PURE;
            CLIMETHOD(getString) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(getStringPStr) (THIS_ CLIPSTR*          str) PURE;
            CLIMETHOD(getStringChars) (THIS_ WCHAR*    buf /* [out,flat] wchar buf[]  */
                                           , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                      ) PURE;
            CLIMETHOD(getDump) (THIS_ CLIPCSTR*         str) PURE;
            CLIMETHOD(getDate) (THIS_ STRUCT_CLI_CLISYSTEMTIME*    datetime /* [out] ::cli::CLISYSTEMTIME datetime  */) PURE;
            CLIMETHOD(getBool) (THIS_ BOOL*    b /* [out] bool b  */) PURE;
            CLIMETHOD(getText) (THIS_ BOOL    allText /* [in] bool  allText  */
                                    , CLISTR*           str
                               ) PURE;
            CLIMETHOD(serializeValueSimple) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(serializeValueAdvanced) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(serializeValueAdvancedSeparate) (THIS_ CLISTR*           strValue
                                                           , CLISTR*           strType
                                                      ) PURE;
            CLIMETHOD(deserializeValueSimple) (THIS_ const CLISTR*     str) PURE;
            CLIMETHOD(deserializeValueAdvanced) (THIS_ const CLISTR*     str) PURE;
            CLIMETHOD(deserializeValueAdvancedSeparate) (THIS_ const CLISTR*     strValue
                                                             , const CLISTR*     strType
                                                        ) PURE;
            CLIMETHOD(serializeXml) (THIS_ CLICSTR*          strTo
                                         , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                    ) PURE;
            CLIMETHOD(deserializeXmlBuf) (THIS_ const CHAR*    buf /* [in,flat] char  buf[]  */
                                              , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                              , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                         ) PURE;
            CLIMETHOD(deserializeXml) (THIS_ const CLICSTR*    strXml
                                           , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                      ) PURE;
            CLIMETHOD(buildXPathQueryVarMapSpec) (THIS_ INTERFACE_CLI_IVARIANTMAP*    pVarMapSpec /* [in] ::cli::iVariantMap*  pVarMapSpec  */
                                                      , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                                      , CLISTR*           query
                                                 ) PURE;
            CLIMETHOD(buildXPathQueryStringSpec) (THIS_ const CLISTR*     strSpec
                                                      , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                                      , CLISTR*           query
                                                 ) PURE;
            CLIMETHOD(buildXPathQueryStringSpecChars) (THIS_ const WCHAR*    strSpec /* [in,flat] wchar  strSpec[]  */
                                                           , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                                           , CLISTR*           query
                                                      ) PURE;
            CLIMETHOD(lockNodeEvents) (THIS) PURE;
            CLIMETHOD(unlockNodeEvents) (THIS) PURE;
            CLIMETHOD_(BOOL, isNodeEventsLocked) (THIS) PURE;
            CLIMETHOD(addEventHandler) (THIS_ INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */
                                            , ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */
                                       ) PURE;
            CLIMETHOD_(SIZE_T, findEventHandler) (THIS_ INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */) PURE;
            CLIMETHOD(removeEventHandler) (THIS_ INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */) PURE;
            CLIMETHOD(removeEventHandlerByIndex) (THIS_ SIZE_T    handlerIndex /* [in] size_t  handlerIndex  */) PURE;
            CLIMETHOD(clearEventHandlers) (THIS) PURE;
            CLIMETHOD_(CLI_TIME_T, createStamp) (THIS) PURE;
            CLIMETHOD(putStamp) (THIS) PURE;
            CLIMETHOD(putStampEx) (THIS_ CLI_TIME_T    st /* [in] cli_time_t  st  */) PURE;
            CLIMETHOD_(CLI_TIME_T, getStamp) (THIS) PURE;
            CLIMETHOD(generateEvent) (THIS_ ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */) PURE;
            CLIMETHOD(childGenerateEvent) (THIS_ ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iDataNode >
           {
            static char const * getName() { return INTERFACE_CLI_IDATANODE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iDataNode* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iDataNode > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iDataNode wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IDATANODE >
                                      */
                 >
        class CiDataNodeWrapper
        {
            public:
        
                typedef  CiDataNodeWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiDataNodeWrapper() :
                   pif(0) {}
        
                CiDataNodeWrapper( iDataNode *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiDataNodeWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiDataNodeWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiDataNodeWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiDataNodeWrapper(const CiDataNodeWrapper &i) :
                    pif(i.pif) { }
        
                ~CiDataNodeWrapper()  { }
        
                CiDataNodeWrapper& operator=(const CiDataNodeWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ENUM_CLI_EDATANODETYPE get_nodeType( )
                   {
                    ENUM_CLI_EDATANODETYPE tmpVal;
                    RCODE res = nodeTypeGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_nodeType( ENUM_CLI_EDATANODETYPE _nodeType
                                 )
                   {
                    RCODE res = nodeTypeSet( _nodeType );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_EDATANODETYPE, nodeType );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE nodeTypeGet( ENUM_CLI_EDATANODETYPE*    _nodeType /* [out] ::cli::EDataNodeType _nodeType  */)
                   {
                
                    return pif->nodeTypeGet(_nodeType);
                   }
                
                RCODE nodeTypeSet( ENUM_CLI_EDATANODETYPE    _nodeType /* [in] ::cli::EDataNodeType  _nodeType  */)
                   {
                
                    return pif->nodeTypeSet(_nodeType);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_nodeName( )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = nodeNameGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_nodeName( const ::std::wstring &_nodeName
                                 )
                   {
                    RCODE res = nodeNameSet( _nodeName );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, nodeName );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE nodeNameGet( ::std::wstring    &_nodeName)
                   {
                    CCliStr tmp__nodeName; CCliStr_init( tmp__nodeName );
                    RCODE res = pif->nodeNameGet(&tmp__nodeName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _nodeName, tmp__nodeName);
                       }
                    return res;
                   }
                
                RCODE nodeNameSet( const ::std::wstring    &_nodeName)
                   {
                    CCliStr tmp__nodeName; CCliStr_lightCopyTo( tmp__nodeName, _nodeName);
                    return pif->nodeNameSet(&tmp__nodeName);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ENUM_CLI_EDATANODEFLAGS get_nodeFlags( )
                   {
                    ENUM_CLI_EDATANODEFLAGS tmpVal;
                    RCODE res = nodeFlagsGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_nodeFlags( ENUM_CLI_EDATANODEFLAGS _nodeFlags
                                  )
                   {
                    RCODE res = nodeFlagsSet( _nodeFlags );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, ENUM_CLI_EDATANODEFLAGS, nodeFlags );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE nodeFlagsGet( ENUM_CLI_EDATANODEFLAGS*    _nodeFlags /* [out] ::cli::EDataNodeFlags _nodeFlags  */)
                   {
                
                    return pif->nodeFlagsGet(_nodeFlags);
                   }
                
                RCODE nodeFlagsSet( ENUM_CLI_EDATANODEFLAGS    _nodeFlags /* [in] ::cli::EDataNodeFlags  _nodeFlags  */)
                   {
                
                    return pif->nodeFlagsSet(_nodeFlags);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_childIndex( const ::std::wstring &idx1 )
                   {
                    SIZE_T tmpVal;
                    RCODE res = childIndexGet( &tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_childIndex(  )
                   {
                    SIZE_T size;
                    RCODE res = childIndexSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, SIZE_T, childIndex, ::std::wstring );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE childIndexGet( SIZE_T*    _childIndex /* [out] size_t _childIndex  */
                                   , const ::std::wstring    &idx1
                                   )
                   {
                
                    CCliStr tmp_idx1; CCliStr_lightCopyTo( tmp_idx1, idx1);
                    return pif->childIndexGet(_childIndex, &tmp_idx1);
                   }
                
                RCODE childIndexSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->childIndexSize(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_attrIndex( const ::std::wstring &idx1 )
                   {
                    SIZE_T tmpVal;
                    RCODE res = attrIndexGet( &tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_attrIndex(  )
                   {
                    SIZE_T size;
                    RCODE res = attrIndexSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, SIZE_T, attrIndex, ::std::wstring );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE attrIndexGet( SIZE_T*    _attrIndex /* [out] size_t _attrIndex  */
                                  , const ::std::wstring    &idx1
                                  )
                   {
                
                    CCliStr tmp_idx1; CCliStr_lightCopyTo( tmp_idx1, idx1);
                    return pif->attrIndexGet(_attrIndex, &tmp_idx1);
                   }
                
                RCODE attrIndexSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->attrIndexSize(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_IDATANODE* get_childs( SIZE_T idx1 )
                   {
                    INTERFACE_CLI_IDATANODE* tmpVal;
                    RCODE res = childsGet( &tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_childs(  )
                   {
                    SIZE_T size;
                    RCODE res = childsSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, INTERFACE_CLI_IDATANODE*, childs, SIZE_T );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE childsGet( INTERFACE_CLI_IDATANODE**    _childs /* [out] ::cli::iDataNode* _childs  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
                   {
                
                
                    return pif->childsGet(_childs, idx1);
                   }
                
                RCODE childsSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->childsSize(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_inputStreamId( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = inputStreamIdGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_inputStreamId( SIZE_T _inputStreamId
                                      )
                   {
                    RCODE res = inputStreamIdSet( _inputStreamId );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, inputStreamId );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE inputStreamIdGet( SIZE_T*    _inputStreamId /* [out] size_t _inputStreamId  */)
                   {
                
                    return pif->inputStreamIdGet(_inputStreamId);
                   }
                
                RCODE inputStreamIdSet( SIZE_T    _inputStreamId /* [in] size_t  _inputStreamId  */)
                   {
                
                    return pif->inputStreamIdSet(_inputStreamId);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_streamId( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = streamIdGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_streamId( SIZE_T _streamId
                                 )
                   {
                    RCODE res = streamIdSet( _streamId );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, streamId );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE streamIdGet( SIZE_T*    _streamId /* [out] size_t _streamId  */)
                   {
                
                    return pif->streamIdGet(_streamId);
                   }
                
                RCODE streamIdSet( SIZE_T    _streamId /* [in] size_t  _streamId  */)
                   {
                
                    return pif->streamIdSet(_streamId);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_lineNo( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = lineNoGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_lineNo( SIZE_T _lineNo
                               )
                   {
                    RCODE res = lineNoSet( _lineNo );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, lineNo );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE lineNoGet( SIZE_T*    _lineNo /* [out] size_t _lineNo  */)
                   {
                
                    return pif->lineNoGet(_lineNo);
                   }
                
                RCODE lineNoSet( SIZE_T    _lineNo /* [in] size_t  _lineNo  */)
                   {
                
                    return pif->lineNoSet(_lineNo);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_linePos( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = linePosGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_linePos( SIZE_T _linePos
                                )
                   {
                    RCODE res = linePosSet( _linePos );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, linePos );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE linePosGet( SIZE_T*    _linePos /* [out] size_t _linePos  */)
                   {
                
                    return pif->linePosGet(_linePos);
                   }
                
                RCODE linePosSet( SIZE_T    _linePos /* [in] size_t  _linePos  */)
                   {
                
                    return pif->linePosSet(_linePos);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_levelNo( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = levelNoGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, levelNo );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE levelNoGet( SIZE_T*    _levelNo /* [out] size_t _levelNo  */)
                   {
                
                    return pif->levelNoGet(_levelNo);
                   }
                
                RCODE createDataNode( INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                    , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                    , const ::std::wstring    &nodeName
                                    , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                    )
                   {
                
                
                    CCliStr tmp_nodeName; CCliStr_lightCopyTo( tmp_nodeName, nodeName);
                
                    return pif->createDataNode(pNewNode, nodeType, &tmp_nodeName, pValue);
                   }
                
                RCODE createDataNodeChars( INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                         , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                         , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                         , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                         )
                   {
                
                
                
                
                    return pif->createDataNodeChars(pNewNode, nodeType, nodeName, pValue);
                   }
                
                RCODE createChildDataNode( INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                         , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                         , const ::std::wstring    &nodeName
                                         , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                         )
                   {
                
                
                    CCliStr tmp_nodeName; CCliStr_lightCopyTo( tmp_nodeName, nodeName);
                
                    return pif->createChildDataNode(pNewChildNode, nodeType, &tmp_nodeName, pValue);
                   }
                
                RCODE createChildDataNodeChars( INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                              , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                              , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                              , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                              )
                   {
                
                
                
                
                    return pif->createChildDataNodeChars(pNewChildNode, nodeType, nodeName, pValue);
                   }
                
                RCODE cloneDataNode( INTERFACE_CLI_IDATANODE**    pNodeCopy /* [out] ::cli::iDataNode* pNodeCopy  */)
                   {
                
                    return pif->cloneDataNode(pNodeCopy);
                   }
                
                RCODE setParentNode( INTERFACE_CLI_IDATANODE*    pParentNode /* [in] ::cli::iDataNode*  pParentNode  */)
                   {
                
                    return pif->setParentNode(pParentNode);
                   }
                
                RCODE getParentNode( INTERFACE_CLI_IDATANODE**    pParentNode /* [out] ::cli::iDataNode* pParentNode  */)
                   {
                
                    return pif->getParentNode(pParentNode);
                   }
                
                RCODE getRootNode( INTERFACE_CLI_IDATANODE**    pRootNode /* [out] ::cli::iDataNode* pRootNode  */)
                   {
                
                    return pif->getRootNode(pRootNode);
                   }
                
                RCODE getChildNodeType( ENUM_CLI_EDATANODETYPE*    childType /* [out] ::cli::EDataNodeType childType  */
                                      , SIZE_T    where /* [in] size_t  where  */
                                      )
                   {
                
                
                    return pif->getChildNodeType(childType, where);
                   }
                
                RCODE lockChildNodes( )
                   {
                    return pif->lockChildNodes();
                   }
                
                RCODE unlockChildNodes( )
                   {
                    return pif->unlockChildNodes();
                   }
                
                RCODE getChildsCount( SIZE_T*    childsCount /* [out] size_t childsCount  */)
                   {
                
                    return pif->getChildsCount(childsCount);
                   }
                
                SIZE_T getChildsCountSimple( )
                   {
                    return pif->getChildsCountSimple();
                   }
                
                RCODE getChildNode( INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                  , SIZE_T    nodeIndex /* [in] size_t  nodeIndex  */
                                  )
                   {
                
                
                    return pif->getChildNode(pNode, nodeIndex);
                   }
                
                RCODE insertChildNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                     , SIZE_T    where /* [in] size_t  where  */
                                     )
                   {
                
                
                    return pif->insertChildNode(pNode, where);
                   }
                
                RCODE pushBackChildNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->pushBackChildNode(pNode);
                   }
                
                RCODE moveChildNodeFrom( INTERFACE_CLI_IDATANODE*    pNodeFrom /* [in] ::cli::iDataNode*  pNodeFrom  */
                                       , SIZE_T    moveFromIdx /* [in] size_t  moveFromIdx  */
                                       , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                       )
                   {
                
                
                
                    return pif->moveChildNodeFrom(pNodeFrom, moveFromIdx, insertWhere);
                   }
                
                RCODE moveChildNodesByTypeFrom( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                              , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                              )
                   {
                
                
                    return pif->moveChildNodesByTypeFrom(pNode, moveTypes);
                   }
                
                RCODE moveChildNodesByTypeFromEx( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                                , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                                )
                   {
                
                
                
                    return pif->moveChildNodesByTypeFromEx(pNode, moveTypes, insertWhere);
                   }
                
                RCODE eraseChildNode( SIZE_T    where /* [in] size_t  where  */)
                   {
                
                    return pif->eraseChildNode(where);
                   }
                
                RCODE swapChildNode( INTERFACE_CLI_IDATANODE*    pNodeNew /* [in] ::cli::iDataNode*  pNodeNew  */
                                   , SIZE_T    where /* [in] size_t  where  */
                                   , ENUM_CLI_EDATANODESWAPFLAGS    flags /* [in] ::cli::EDataNodeSwapFlags  flags  */
                                   , INTERFACE_CLI_IDATANODE**    pNodePrev /* [out,optional] ::cli::iDataNode* pNodePrev  */
                                   )
                   {
                
                
                
                
                    return pif->swapChildNode(pNodeNew, where, flags, pNodePrev);
                   }
                
                RCODE clearChildsEx( ENUM_CLI_EDATANODETYPE    keepTypes /* [in] ::cli::EDataNodeType  keepTypes  */)
                   {
                
                    return pif->clearChildsEx(keepTypes);
                   }
                
                RCODE clearChilds( )
                   {
                    return pif->clearChilds();
                   }
                
                RCODE getChildNodes( INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */)
                   {
                
                    return pif->getChildNodes(pNodeList);
                   }
                
                RCODE getChildList( INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */)
                   {
                
                    return pif->getChildList(pNodeList);
                   }
                
                RCODE setChildList( INTERFACE_CLI_IDATANODELIST*    pNodeList /* [in] ::cli::iDataNodeList*  pNodeList  */)
                   {
                
                    return pif->setChildList(pNodeList);
                   }
                
                RCODE swapChilds( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->swapChilds(pNode);
                   }
                
                RCODE getChildsToListByTypeAndName( INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                  , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                  , const ::std::wstring    &names
                                                  )
                   {
                
                
                    CCliStr tmp_names; CCliStr_lightCopyTo( tmp_names, names);
                    return pif->getChildsToListByTypeAndName(pNodeList, nodeType, &tmp_names);
                   }
                
                RCODE getChildsToListByTypeAndNameChars( INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                       , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                       , const WCHAR*    names /* [in,flat] wchar  names[]  */
                                                       )
                   {
                
                
                
                    return pif->getChildsToListByTypeAndNameChars(pNodeList, nodeType, names);
                   }
                
                RCODE getChildsToListByType( INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                           , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                           )
                   {
                
                
                    return pif->getChildsToListByType(pNodeList, nodeType);
                   }
                
                RCODE getChildNodeByIndex( INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                         , SIZE_T    idx /* [in] size_t  idx  */
                                         )
                   {
                
                
                    return pif->getChildNodeByIndex(pNode, idx);
                   }
                
                BOOL findChild( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->findChild(pNode);
                   }
                
                SIZE_T getChildIndex( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->getChildIndex(pNode);
                   }
                
                RCODE getNextSibling( INTERFACE_CLI_IDATANODE**    pNodeSibling /* [out] ::cli::iDataNode* pNodeSibling  */)
                   {
                
                    return pif->getNextSibling(pNodeSibling);
                   }
                
                RCODE getPrevSibling( INTERFACE_CLI_IDATANODE**    pNodeSibling /* [out] ::cli::iDataNode* pNodeSibling  */)
                   {
                
                    return pif->getPrevSibling(pNodeSibling);
                   }
                
                SIZE_T getChildIndexByName( const ::std::wstring    &name)
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                    return pif->getChildIndexByName(&tmp_name);
                   }
                
                SIZE_T getChildIndexByNameType( const ::std::wstring    &name
                                              , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                              )
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                
                    return pif->getChildIndexByNameType(&tmp_name, type);
                   }
                
                SIZE_T getChildIndexByNameChars( const WCHAR*    name /* [in,flat] wchar  name[]  */)
                   {
                
                    return pif->getChildIndexByNameChars(name);
                   }
                
                SIZE_T getChildIndexByNameTypeChars( const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                   , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                   )
                   {
                
                
                    return pif->getChildIndexByNameTypeChars(name, type);
                   }
                
                BOOL compareName( const ::std::wstring    &name)
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                    return pif->compareName(&tmp_name);
                   }
                
                BOOL compareNameType( const ::std::wstring    &name
                                    , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                    )
                   {
                    CCliStr tmp_name; CCliStr_lightCopyTo( tmp_name, name);
                
                    return pif->compareNameType(&tmp_name, nodeType);
                   }
                
                BOOL compareNameChars( const WCHAR*    name /* [in,flat] wchar  name[]  */)
                   {
                
                    return pif->compareNameChars(name);
                   }
                
                BOOL compareNameTypeChars( const WCHAR*    name /* [in,flat] wchar  name[]  */
                                         , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                         )
                   {
                
                
                    return pif->compareNameTypeChars(name, nodeType);
                   }
                
                RCODE getDataNodeValue( INTERFACE_CLI_IREADONLYVARIANT**    pValue /* [out] ::cli::iReadOnlyVariant* pValue  */)
                   {
                
                    return pif->getDataNodeValue(pValue);
                   }
                
                RCODE copyValueToNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->copyValueToNode(pNode);
                   }
                
                RCODE removeValue( )
                   {
                    return pif->removeValue();
                   }
                
                BOOL hasValue( BOOL    emptyAsNoValue /* [in] bool  emptyAsNoValue  */)
                   {
                
                    return pif->hasValue(emptyAsNoValue);
                   }
                
                ENUM_CLI_VARIANTTYPE getValueType( )
                   {
                    return pif->getValueType();
                   }
                
                RCODE setValue( INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */)
                   {
                
                    return pif->setValue(pValue);
                   }
                
                RCODE setValueCopy( INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */)
                   {
                
                    return pif->setValueCopy(pValue);
                   }
                
                RCODE setValueToNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->setValueToNode(pNode);
                   }
                
                RCODE setValueToNodeCopy( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->setValueToNodeCopy(pNode);
                   }
                
                RCODE setEmpty( )
                   {
                    return pif->setEmpty();
                   }
                
                RCODE setChar( CHAR    ch /* [in] char  ch  */)
                   {
                
                    return pif->setChar(ch);
                   }
                
                RCODE setWChar( WCHAR    wch /* [in] wchar  wch  */)
                   {
                
                    return pif->setWChar(wch);
                   }
                
                RCODE setShort( SHORT    s /* [in] short  s  */)
                   {
                
                    return pif->setShort(s);
                   }
                
                RCODE setUShort( USHORT    us /* [in] ushort  us  */)
                   {
                
                    return pif->setUShort(us);
                   }
                
                RCODE setInt( INT    i /* [in] int  i  */)
                   {
                
                    return pif->setInt(i);
                   }
                
                RCODE setUInt( UINT    i /* [in] uint  i  */)
                   {
                
                    return pif->setUInt(i);
                   }
                
                RCODE setColorref( COLORREF    i /* [in] colorref  i  */)
                   {
                
                    return pif->setColorref(i);
                   }
                
                RCODE setInt64( INT64    i /* [in] int64  i  */)
                   {
                
                    return pif->setInt64(i);
                   }
                
                RCODE setUInt64( UINT64    i /* [in] uint64  i  */)
                   {
                
                    return pif->setUInt64(i);
                   }
                
                RCODE setIntPtr( INT_PTR    i /* [in] int_ptr  i  */)
                   {
                
                    return pif->setIntPtr(i);
                   }
                
                RCODE setUIntPtr( UINT_PTR    i /* [in] uint_ptr  i  */)
                   {
                
                    return pif->setUIntPtr(i);
                   }
                
                RCODE setFloat( FLOAT    f /* [in] float  f  */)
                   {
                
                    return pif->setFloat(f);
                   }
                
                RCODE setDouble( DOUBLE    d /* [in] double  d  */)
                   {
                
                    return pif->setDouble(d);
                   }
                
                RCODE setPtr( const VOID*    vptr /* [in] void*  vptr  */)
                   {
                
                    return pif->setPtr(vptr);
                   }
                
                RCODE setString( const ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->setString(&tmp_str);
                   }
                
                RCODE setStringPStr( ::std::wstring    str)
                   {
                    CCliPStr tmp_str; CCliPStr_lightCopyTo( tmp_str, str);
                    return pif->setStringPStr(tmp_str);
                   }
                
                RCODE setStringChars( const WCHAR*    str /* [in,flat] wchar  str[]  */
                                    , SIZE_T    strSize /* [in] size_t  strSize  */
                                    )
                   {
                
                
                    return pif->setStringChars(str, strSize);
                   }
                
                RCODE setDump( const BYTE*    d /* [in,flat] byte  d[]  */
                             , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                             )
                   {
                
                
                    return pif->setDump(d, dumpSize);
                   }
                
                RCODE setDate( const STRUCT_CLI_CLISYSTEMTIME    &datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->setDate(&datetime);
                   }
                
                RCODE setBool( BOOL    b /* [in] bool  b  */)
                   {
                
                    return pif->setBool(b);
                   }
                
                RCODE getChar( CHAR*    ch /* [out] char ch  */)
                   {
                
                    return pif->getChar(ch);
                   }
                
                RCODE getWChar( WCHAR*    wch /* [out] wchar wch  */)
                   {
                
                    return pif->getWChar(wch);
                   }
                
                RCODE getShort( SHORT*    s /* [out] short s  */)
                   {
                
                    return pif->getShort(s);
                   }
                
                RCODE getUShort( USHORT*    us /* [out] ushort us  */)
                   {
                
                    return pif->getUShort(us);
                   }
                
                RCODE getInt( INT*    i /* [out] int i  */)
                   {
                
                    return pif->getInt(i);
                   }
                
                RCODE getUInt( UINT*    i /* [out] uint i  */)
                   {
                
                    return pif->getUInt(i);
                   }
                
                RCODE getColorref( COLORREF*    i /* [out] colorref i  */)
                   {
                
                    return pif->getColorref(i);
                   }
                
                RCODE getInt64( INT64*    i /* [out] int64 i  */)
                   {
                
                    return pif->getInt64(i);
                   }
                
                RCODE getUInt64( UINT64*    i /* [out] uint64 i  */)
                   {
                
                    return pif->getUInt64(i);
                   }
                
                RCODE getIntPtr( INT_PTR*    i /* [out] int_ptr i  */)
                   {
                
                    return pif->getIntPtr(i);
                   }
                
                RCODE getUIntPtr( UINT_PTR*    i /* [out] uint_ptr i  */)
                   {
                
                    return pif->getUIntPtr(i);
                   }
                
                RCODE getFloat( FLOAT*    f /* [out] float f  */)
                   {
                
                    return pif->getFloat(f);
                   }
                
                RCODE getDouble( DOUBLE*    d /* [out] double d  */)
                   {
                
                    return pif->getDouble(d);
                   }
                
                RCODE getPtr( VOID**    vptr /* [out] void* vptr  */)
                   {
                
                    return pif->getPtr(vptr);
                   }
                
                RCODE getString( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getString(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getStringPStr( ::std::wstring    &str)
                   {
                    CCliPStr tmp_str; CCliPStr_init( tmp_str );
                    RCODE res = pif->getStringPStr(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliPStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getStringChars( WCHAR*    buf /* [out,flat] wchar buf[]  */
                                    , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                    )
                   {
                
                
                    return pif->getStringChars(buf, bufSize);
                   }
                
                RCODE getDump( ::std::string    &str)
                   {
                    CCliPCStr tmp_str; CCliPCStr_init( tmp_str );
                    RCODE res = pif->getDump(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliPCStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getDate( STRUCT_CLI_CLISYSTEMTIME    &datetime /* [out] ::cli::CLISYSTEMTIME datetime  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->getDate(&datetime);
                   }
                
                RCODE getBool( BOOL*    b /* [out] bool b  */)
                   {
                
                    return pif->getBool(b);
                   }
                
                RCODE getText( BOOL    allText /* [in] bool  allText  */
                             , ::std::wstring    &str
                             )
                   {
                
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getText(allText, &tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE serializeValueSimple( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->serializeValueSimple(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE serializeValueAdvanced( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->serializeValueAdvanced(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE serializeValueAdvancedSeparate( ::std::wstring    &strValue
                                                    , ::std::wstring    &strType
                                                    )
                   {
                    CCliStr tmp_strValue; CCliStr_init( tmp_strValue );
                    CCliStr tmp_strType; CCliStr_init( tmp_strType );
                    RCODE res = pif->serializeValueAdvancedSeparate(&tmp_strValue, &tmp_strType);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( strValue, tmp_strValue);
                        CCliStr_copyFromIfModified( strType, tmp_strType);
                       }
                    return res;
                   }
                
                RCODE deserializeValueSimple( const ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->deserializeValueSimple(&tmp_str);
                   }
                
                RCODE deserializeValueAdvanced( const ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->deserializeValueAdvanced(&tmp_str);
                   }
                
                RCODE deserializeValueAdvancedSeparate( const ::std::wstring    &strValue
                                                      , const ::std::wstring    &strType
                                                      )
                   {
                    CCliStr tmp_strValue; CCliStr_lightCopyTo( tmp_strValue, strValue);
                    CCliStr tmp_strType; CCliStr_lightCopyTo( tmp_strType, strType);
                    return pif->deserializeValueAdvancedSeparate(&tmp_strValue, &tmp_strType);
                   }
                
                RCODE serializeXml( ::std::string    &strTo
                                  , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                  )
                   {
                    CCliCStr tmp_strTo; CCliCStr_init( tmp_strTo );
                
                    RCODE res = pif->serializeXml(&tmp_strTo, flags);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( strTo, tmp_strTo);
                       }
                    return res;
                   }
                
                RCODE deserializeXmlBuf( const CHAR*    buf /* [in,flat] char  buf[]  */
                                       , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                       , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                       )
                   {
                
                
                
                    return pif->deserializeXmlBuf(buf, bufSize, flags);
                   }
                
                RCODE deserializeXml( const ::std::string    &strXml
                                    , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                    )
                   {
                    CCliCStr tmp_strXml; CCliCStr_lightCopyTo( tmp_strXml, strXml);
                
                    return pif->deserializeXml(&tmp_strXml, flags);
                   }
                
                RCODE buildXPathQueryVarMapSpec( INTERFACE_CLI_IVARIANTMAP*    pVarMapSpec /* [in] ::cli::iVariantMap*  pVarMapSpec  */
                                               , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                               , ::std::wstring    &query
                                               )
                   {
                
                
                    CCliStr tmp_query; CCliStr_init( tmp_query );
                    RCODE res = pif->buildXPathQueryVarMapSpec(pVarMapSpec, flags, &tmp_query);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( query, tmp_query);
                       }
                    return res;
                   }
                
                RCODE buildXPathQueryStringSpec( const ::std::wstring    &strSpec
                                               , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                               , ::std::wstring    &query
                                               )
                   {
                    CCliStr tmp_strSpec; CCliStr_lightCopyTo( tmp_strSpec, strSpec);
                
                    CCliStr tmp_query; CCliStr_init( tmp_query );
                    RCODE res = pif->buildXPathQueryStringSpec(&tmp_strSpec, flags, &tmp_query);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( query, tmp_query);
                       }
                    return res;
                   }
                
                RCODE buildXPathQueryStringSpecChars( const WCHAR*    strSpec /* [in,flat] wchar  strSpec[]  */
                                                    , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                                    , ::std::wstring    &query
                                                    )
                   {
                
                
                    CCliStr tmp_query; CCliStr_init( tmp_query );
                    RCODE res = pif->buildXPathQueryStringSpecChars(strSpec, flags, &tmp_query);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( query, tmp_query);
                       }
                    return res;
                   }
                
                RCODE lockNodeEvents( )
                   {
                    return pif->lockNodeEvents();
                   }
                
                RCODE unlockNodeEvents( )
                   {
                    return pif->unlockNodeEvents();
                   }
                
                BOOL isNodeEventsLocked( )
                   {
                    return pif->isNodeEventsLocked();
                   }
                
                RCODE addEventHandler( INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */
                                     , ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */
                                     )
                   {
                
                
                    return pif->addEventHandler(pHandler, eventMask);
                   }
                
                SIZE_T findEventHandler( INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */)
                   {
                
                    return pif->findEventHandler(pHandler);
                   }
                
                RCODE removeEventHandler( INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */)
                   {
                
                    return pif->removeEventHandler(pHandler);
                   }
                
                RCODE removeEventHandlerByIndex( SIZE_T    handlerIndex /* [in] size_t  handlerIndex  */)
                   {
                
                    return pif->removeEventHandlerByIndex(handlerIndex);
                   }
                
                RCODE clearEventHandlers( )
                   {
                    return pif->clearEventHandlers();
                   }
                
                CLI_TIME_T createStamp( )
                   {
                    return pif->createStamp();
                   }
                
                RCODE putStamp( )
                   {
                    return pif->putStamp();
                   }
                
                RCODE putStampEx( CLI_TIME_T    st /* [in] cli_time_t  st  */)
                   {
                
                    return pif->putStampEx(st);
                   }
                
                CLI_TIME_T getStamp( )
                   {
                    return pif->getStamp();
                   }
                
                RCODE generateEvent( ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */)
                   {
                
                    return pif->generateEvent(eventMask);
                   }
                
                RCODE childGenerateEvent( ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */)
                   {
                
                    return pif->childGenerateEvent(eventMask);
                   }
                

        
        
        }; // class CiDataNodeWrapper
        
        typedef CiDataNodeWrapper< ::cli::CCliPtr< INTERFACE_CLI_IDATANODE     > >  CiDataNode;
        typedef CiDataNodeWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATANODE > >  CiDataNode_nrc; /* No ref counting for interface used */
        typedef CiDataNodeWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATANODE > >  CiDataNode_tmp; /* for temporary usage, same as CiDataNode_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iDataEventHandler */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IDATAEVENTHANDLER_IID
    #define INTERFACE_CLI_IDATAEVENTHANDLER_IID    "/cli/iDataEventHandler"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iDataEventHandler
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IDATAEVENTHANDLER
       #define INTERFACE_CLI_IDATAEVENTHANDLER    ::cli::iDataEventHandler
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iDataEventHandler
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IDATAEVENTHANDLER
       #define INTERFACE_CLI_IDATAEVENTHANDLER    cli_iDataEventHandler
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDataEventHandler methods */
            CLIMETHOD(onDataEvent) (THIS_ INTERFACE_CLI_IDATANODE*    pDataEventSource /* [in] ::cli::iDataNode*  pDataEventSource  */
                                        , ENUM_CLI_EDATANODEEVENTMASK    eventType /* [in] ::cli::EDataNodeEventMask  eventType  */
                                   ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iDataEventHandler >
           {
            static char const * getName() { return INTERFACE_CLI_IDATAEVENTHANDLER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iDataEventHandler* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iDataEventHandler > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iDataEventHandler wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IDATAEVENTHANDLER >
                                      */
                 >
        class CiDataEventHandlerWrapper
        {
            public:
        
                typedef  CiDataEventHandlerWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiDataEventHandlerWrapper() :
                   pif(0) {}
        
                CiDataEventHandlerWrapper( iDataEventHandler *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiDataEventHandlerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiDataEventHandlerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiDataEventHandlerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiDataEventHandlerWrapper(const CiDataEventHandlerWrapper &i) :
                    pif(i.pif) { }
        
                ~CiDataEventHandlerWrapper()  { }
        
                CiDataEventHandlerWrapper& operator=(const CiDataEventHandlerWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE onDataEvent( INTERFACE_CLI_IDATANODE*    pDataEventSource /* [in] ::cli::iDataNode*  pDataEventSource  */
                                 , ENUM_CLI_EDATANODEEVENTMASK    eventType /* [in] ::cli::EDataNodeEventMask  eventType  */
                                 )
                   {
                
                
                    return pif->onDataEvent(pDataEventSource, eventType);
                   }
                

        
        
        }; // class CiDataEventHandlerWrapper
        
        typedef CiDataEventHandlerWrapper< ::cli::CCliPtr< INTERFACE_CLI_IDATAEVENTHANDLER     > >  CiDataEventHandler;
        typedef CiDataEventHandlerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATAEVENTHANDLER > >  CiDataEventHandler_nrc; /* No ref counting for interface used */
        typedef CiDataEventHandlerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATAEVENTHANDLER > >  CiDataEventHandler_tmp; /* for temporary usage, same as CiDataEventHandler_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iDataEventsQueue */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IDATAEVENTSQUEUE_IID
    #define INTERFACE_CLI_IDATAEVENTSQUEUE_IID    "/cli/iDataEventsQueue"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iDataEventsQueue
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IDATAEVENTSQUEUE
       #define INTERFACE_CLI_IDATAEVENTSQUEUE    ::cli::iDataEventsQueue
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iDataEventsQueue
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IDATAEVENTSQUEUE
       #define INTERFACE_CLI_IDATAEVENTSQUEUE    cli_iDataEventsQueue
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDataEventsQueue methods */
            CLIMETHOD(enabledGet) (THIS_ BOOL*    _enabled /* [out] bool _enabled  */) PURE;
            CLIMETHOD(enabledSet) (THIS_ BOOL    _enabled /* [in] bool  _enabled  */) PURE;
            CLIMETHOD(queueSizeGet) (THIS_ SIZE_T*    _queueSize /* [out] size_t _queueSize  */) PURE;
            CLIMETHOD(mergeEventsGet) (THIS_ BOOL*    _mergeEvents /* [out] bool _mergeEvents  */) PURE;
            CLIMETHOD(mergeEventsSet) (THIS_ BOOL    _mergeEvents /* [in] bool  _mergeEvents  */) PURE;
            CLIMETHOD(clearEventsQueue) (THIS) PURE;
            CLIMETHOD(postEvent) (THIS_ INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */
                                      , INTERFACE_CLI_IDATANODE*    pDataNodeFrom /* [in] ::cli::iDataNode*  pDataNodeFrom  */
                                      , ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */
                                 ) PURE;
            CLIMETHOD(callQueuedEvent) (THIS) PURE;
            CLIMETHOD(callAllQueuedEvents) (THIS) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iDataEventsQueue >
           {
            static char const * getName() { return INTERFACE_CLI_IDATAEVENTSQUEUE_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iDataEventsQueue* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iDataEventsQueue > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iDataEventsQueue wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IDATAEVENTSQUEUE >
                                      */
                 >
        class CiDataEventsQueueWrapper
        {
            public:
        
                typedef  CiDataEventsQueueWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiDataEventsQueueWrapper() :
                   pif(0) {}
        
                CiDataEventsQueueWrapper( iDataEventsQueue *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiDataEventsQueueWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiDataEventsQueueWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiDataEventsQueueWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiDataEventsQueueWrapper(const CiDataEventsQueueWrapper &i) :
                    pif(i.pif) { }
        
                ~CiDataEventsQueueWrapper()  { }
        
                CiDataEventsQueueWrapper& operator=(const CiDataEventsQueueWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                BOOL get_enabled( )
                   {
                    BOOL tmpVal;
                    RCODE res = enabledGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_enabled( BOOL _enabled
                                )
                   {
                    RCODE res = enabledSet( _enabled );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, enabled );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE enabledGet( BOOL*    _enabled /* [out] bool _enabled  */)
                   {
                
                    return pif->enabledGet(_enabled);
                   }
                
                RCODE enabledSet( BOOL    _enabled /* [in] bool  _enabled  */)
                   {
                
                    return pif->enabledSet(_enabled);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_queueSize( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = queueSizeGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, queueSize );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE queueSizeGet( SIZE_T*    _queueSize /* [out] size_t _queueSize  */)
                   {
                
                    return pif->queueSizeGet(_queueSize);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                BOOL get_mergeEvents( )
                   {
                    BOOL tmpVal;
                    RCODE res = mergeEventsGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_mergeEvents( BOOL _mergeEvents
                                    )
                   {
                    RCODE res = mergeEventsSet( _mergeEvents );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, BOOL, mergeEvents );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE mergeEventsGet( BOOL*    _mergeEvents /* [out] bool _mergeEvents  */)
                   {
                
                    return pif->mergeEventsGet(_mergeEvents);
                   }
                
                RCODE mergeEventsSet( BOOL    _mergeEvents /* [in] bool  _mergeEvents  */)
                   {
                
                    return pif->mergeEventsSet(_mergeEvents);
                   }
                
                RCODE clearEventsQueue( )
                   {
                    return pif->clearEventsQueue();
                   }
                
                RCODE postEvent( INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */
                               , INTERFACE_CLI_IDATANODE*    pDataNodeFrom /* [in] ::cli::iDataNode*  pDataNodeFrom  */
                               , ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */
                               )
                   {
                
                
                
                    return pif->postEvent(pHandler, pDataNodeFrom, eventMask);
                   }
                
                RCODE callQueuedEvent( )
                   {
                    return pif->callQueuedEvent();
                   }
                
                RCODE callAllQueuedEvents( )
                   {
                    return pif->callAllQueuedEvents();
                   }
                

        
        
        }; // class CiDataEventsQueueWrapper
        
        typedef CiDataEventsQueueWrapper< ::cli::CCliPtr< INTERFACE_CLI_IDATAEVENTSQUEUE     > >  CiDataEventsQueue;
        typedef CiDataEventsQueueWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATAEVENTSQUEUE > >  CiDataEventsQueue_nrc; /* No ref counting for interface used */
        typedef CiDataEventsQueueWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATAEVENTSQUEUE > >  CiDataEventsQueue_tmp; /* for temporary usage, same as CiDataEventsQueue_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iDataNodeList */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IDATANODELIST_IID
    #define INTERFACE_CLI_IDATANODELIST_IID    "/cli/iDataNodeList"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iDataNodeList
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IDATANODELIST
       #define INTERFACE_CLI_IDATANODELIST    ::cli::iDataNodeList
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iDataNodeList
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IDATANODELIST
       #define INTERFACE_CLI_IDATANODELIST    cli_iDataNodeList
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDataNodeList methods */
            CLIMETHOD(listSizeGet) (THIS_ SIZE_T*    _listSize /* [out] size_t _listSize  */) PURE;
            CLIMETHOD(cloneNodeList) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */) PURE;
            CLIMETHOD(cloneDataNodesToNewList) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */) PURE;
            CLIMETHOD(makeCleanNodeListClone) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */) PURE;
            CLIMETHOD(insertDataNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                           , SIZE_T    where /* [in] size_t  where  */
                                      ) PURE;
            CLIMETHOD(pushBackDataNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(eraseDataNode) (THIS_ SIZE_T    where /* [in] size_t  where  */) PURE;
            CLIMETHOD(eraseDataNodeEx) (THIS_ SIZE_T    where /* [in] size_t  where  */
                                            , BOOL    fClearParent /* [in] bool  fClearParent  */
                                       ) PURE;
            CLIMETHOD(swapDataNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeNew /* [in] ::cli::iDataNode*  pNodeNew  */
                                         , SIZE_T    where /* [in] size_t  where  */
                                         , ENUM_CLI_EDATANODESWAPFLAGS    flags /* [in] ::cli::EDataNodeSwapFlags  flags  */
                                         , INTERFACE_CLI_IDATANODE**    pNodePrev /* [out,optional] ::cli::iDataNode* pNodePrev  */
                                    ) PURE;
            CLIMETHOD(clearList) (THIS) PURE;
            CLIMETHOD(clearListEx) (THIS_ BOOL    fClearParents /* [in] bool  fClearParents  */
                                        , ENUM_CLI_EDATANODETYPE    keepTypes /* [in] ::cli::EDataNodeType  keepTypes  */
                                   ) PURE;
            CLIMETHOD(getDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                        , SIZE_T    idx /* [in] size_t  idx  */
                                   ) PURE;
            CLIMETHOD(appendNodeList) (THIS_ INTERFACE_CLI_IDATANODELIST*    pNodes /* [in] ::cli::iDataNodeList*  pNodes  */) PURE;
            CLIMETHOD_(BOOL, findNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD_(SIZE_T, getNodeIndex) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD_(SIZE_T, findNodeByName) (THIS_ const CLISTR*     nodeName) PURE;
            CLIMETHOD_(SIZE_T, findNodeByNameType) (THIS_ const CLISTR*     nodeName
                                                        , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                   ) PURE;
            CLIMETHOD_(SIZE_T, findNodeByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */) PURE;
            CLIMETHOD_(SIZE_T, findNodeByNameTypeChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                             , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                        ) PURE;
            CLIMETHOD(getDataNodeValue) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    pValue /* [out] ::cli::iReadOnlyVariant* pValue  */
                                             , SIZE_T    idx /* [in] size_t  idx  */
                                        ) PURE;
            CLIMETHOD(setParentNode) (THIS_ INTERFACE_CLI_IDATANODE*    pParentNode /* [in] ::cli::iDataNode*  pParentNode  */) PURE;
            CLIMETHOD(mergeNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(mergeNodeList) (THIS_ INTERFACE_CLI_IDATANODELIST*    pNodes /* [in] ::cli::iDataNodeList*  pNodes  */) PURE;
            CLIMETHOD(cloneDataNodesToNode) (THIS_ INTERFACE_CLI_IDATANODE*    pListRootNode /* [in] ::cli::iDataNode*  pListRootNode  */) PURE;
            CLIMETHOD(getText) (THIS_ CLISTR*           str) PURE;
            CLIMETHOD(getNodeName) (THIS_ CLISTR*           str
                                        , SIZE_T    idx /* [in] size_t  idx  */
                                   ) PURE;
            CLIMETHOD(getNodeType) (THIS_ ENUM_CLI_EDATANODETYPE*    type /* [out] ::cli::EDataNodeType type  */
                                        , SIZE_T    idx /* [in] size_t  idx  */
                                   ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iDataNodeList >
           {
            static char const * getName() { return INTERFACE_CLI_IDATANODELIST_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iDataNodeList* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iDataNodeList > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iDataNodeList wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IDATANODELIST >
                                      */
                 >
        class CiDataNodeListWrapper
        {
            public:
        
                typedef  CiDataNodeListWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiDataNodeListWrapper() :
                   pif(0) {}
        
                CiDataNodeListWrapper( iDataNodeList *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiDataNodeListWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiDataNodeListWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiDataNodeListWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiDataNodeListWrapper(const CiDataNodeListWrapper &i) :
                    pif(i.pif) { }
        
                ~CiDataNodeListWrapper()  { }
        
                CiDataNodeListWrapper& operator=(const CiDataNodeListWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_listSize( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = listSizeGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, listSize );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE listSizeGet( SIZE_T*    _listSize /* [out] size_t _listSize  */)
                   {
                
                    return pif->listSizeGet(_listSize);
                   }
                
                RCODE cloneNodeList( INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */)
                   {
                
                    return pif->cloneNodeList(pNodes);
                   }
                
                RCODE cloneDataNodesToNewList( INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */)
                   {
                
                    return pif->cloneDataNodesToNewList(pNodes);
                   }
                
                RCODE makeCleanNodeListClone( INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */)
                   {
                
                    return pif->makeCleanNodeListClone(pNodes);
                   }
                
                RCODE insertDataNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                    , SIZE_T    where /* [in] size_t  where  */
                                    )
                   {
                
                
                    return pif->insertDataNode(pNode, where);
                   }
                
                RCODE pushBackDataNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->pushBackDataNode(pNode);
                   }
                
                RCODE eraseDataNode( SIZE_T    where /* [in] size_t  where  */)
                   {
                
                    return pif->eraseDataNode(where);
                   }
                
                RCODE eraseDataNodeEx( SIZE_T    where /* [in] size_t  where  */
                                     , BOOL    fClearParent /* [in] bool  fClearParent  */
                                     )
                   {
                
                
                    return pif->eraseDataNodeEx(where, fClearParent);
                   }
                
                RCODE swapDataNode( INTERFACE_CLI_IDATANODE*    pNodeNew /* [in] ::cli::iDataNode*  pNodeNew  */
                                  , SIZE_T    where /* [in] size_t  where  */
                                  , ENUM_CLI_EDATANODESWAPFLAGS    flags /* [in] ::cli::EDataNodeSwapFlags  flags  */
                                  , INTERFACE_CLI_IDATANODE**    pNodePrev /* [out,optional] ::cli::iDataNode* pNodePrev  */
                                  )
                   {
                
                
                
                
                    return pif->swapDataNode(pNodeNew, where, flags, pNodePrev);
                   }
                
                RCODE clearList( )
                   {
                    return pif->clearList();
                   }
                
                RCODE clearListEx( BOOL    fClearParents /* [in] bool  fClearParents  */
                                 , ENUM_CLI_EDATANODETYPE    keepTypes /* [in] ::cli::EDataNodeType  keepTypes  */
                                 )
                   {
                
                
                    return pif->clearListEx(fClearParents, keepTypes);
                   }
                
                RCODE getDataNode( INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                 , SIZE_T    idx /* [in] size_t  idx  */
                                 )
                   {
                
                
                    return pif->getDataNode(pNode, idx);
                   }
                
                RCODE appendNodeList( INTERFACE_CLI_IDATANODELIST*    pNodes /* [in] ::cli::iDataNodeList*  pNodes  */)
                   {
                
                    return pif->appendNodeList(pNodes);
                   }
                
                BOOL findNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->findNode(pNode);
                   }
                
                SIZE_T getNodeIndex( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->getNodeIndex(pNode);
                   }
                
                SIZE_T findNodeByName( const ::std::wstring    &nodeName)
                   {
                    CCliStr tmp_nodeName; CCliStr_lightCopyTo( tmp_nodeName, nodeName);
                    return pif->findNodeByName(&tmp_nodeName);
                   }
                
                SIZE_T findNodeByNameType( const ::std::wstring    &nodeName
                                         , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                         )
                   {
                    CCliStr tmp_nodeName; CCliStr_lightCopyTo( tmp_nodeName, nodeName);
                
                    return pif->findNodeByNameType(&tmp_nodeName, type);
                   }
                
                SIZE_T findNodeByNameChars( const WCHAR*    name /* [in,flat] wchar  name[]  */)
                   {
                
                    return pif->findNodeByNameChars(name);
                   }
                
                SIZE_T findNodeByNameTypeChars( const WCHAR*    name /* [in,flat] wchar  name[]  */
                                              , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                              )
                   {
                
                
                    return pif->findNodeByNameTypeChars(name, type);
                   }
                
                RCODE getDataNodeValue( INTERFACE_CLI_IREADONLYVARIANT**    pValue /* [out] ::cli::iReadOnlyVariant* pValue  */
                                      , SIZE_T    idx /* [in] size_t  idx  */
                                      )
                   {
                
                
                    return pif->getDataNodeValue(pValue, idx);
                   }
                
                RCODE setParentNode( INTERFACE_CLI_IDATANODE*    pParentNode /* [in] ::cli::iDataNode*  pParentNode  */)
                   {
                
                    return pif->setParentNode(pParentNode);
                   }
                
                RCODE mergeNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->mergeNode(pNode);
                   }
                
                RCODE mergeNodeList( INTERFACE_CLI_IDATANODELIST*    pNodes /* [in] ::cli::iDataNodeList*  pNodes  */)
                   {
                
                    return pif->mergeNodeList(pNodes);
                   }
                
                RCODE cloneDataNodesToNode( INTERFACE_CLI_IDATANODE*    pListRootNode /* [in] ::cli::iDataNode*  pListRootNode  */)
                   {
                
                    return pif->cloneDataNodesToNode(pListRootNode);
                   }
                
                RCODE getText( ::std::wstring    &str)
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    RCODE res = pif->getText(&tmp_str);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getNodeName( ::std::wstring    &str
                                 , SIZE_T    idx /* [in] size_t  idx  */
                                 )
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                
                    RCODE res = pif->getNodeName(&tmp_str, idx);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( str, tmp_str);
                       }
                    return res;
                   }
                
                RCODE getNodeType( ENUM_CLI_EDATANODETYPE*    type /* [out] ::cli::EDataNodeType type  */
                                 , SIZE_T    idx /* [in] size_t  idx  */
                                 )
                   {
                
                
                    return pif->getNodeType(type, idx);
                   }
                

        
        
        }; // class CiDataNodeListWrapper
        
        typedef CiDataNodeListWrapper< ::cli::CCliPtr< INTERFACE_CLI_IDATANODELIST     > >  CiDataNodeList;
        typedef CiDataNodeListWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATANODELIST > >  CiDataNodeList_nrc; /* No ref counting for interface used */
        typedef CiDataNodeListWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATANODELIST > >  CiDataNodeList_tmp; /* for temporary usage, same as CiDataNodeList_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iDataRoot */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IDATAROOT_IID
    #define INTERFACE_CLI_IDATAROOT_IID    "/cli/iDataRoot"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iDataRoot
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IDATAROOT
       #define INTERFACE_CLI_IDATAROOT    ::cli::iDataRoot
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iDataRoot
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IDATAROOT
       #define INTERFACE_CLI_IDATAROOT    cli_iDataRoot
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDataRoot methods */
            CLIMETHOD(inputStreamIdGet) (THIS_ SIZE_T*    _inputStreamId /* [out] size_t _inputStreamId  */) PURE;
            CLIMETHOD(inputStreamIdSet) (THIS_ SIZE_T    _inputStreamId /* [in] size_t  _inputStreamId  */) PURE;
            CLIMETHOD(streamIdGet) (THIS_ SIZE_T*    _streamId /* [out] size_t _streamId  */) PURE;
            CLIMETHOD(streamIdSet) (THIS_ SIZE_T    _streamId /* [in] size_t  _streamId  */) PURE;
            CLIMETHOD(encodingNameGet) (THIS_ CLISTR*           _encodingName) PURE;
            CLIMETHOD(encodingNameSet) (THIS_ const CLISTR*     _encodingName) PURE;
            CLIMETHOD(xmlVersionGet) (THIS_ CLISTR*           _xmlVersion) PURE;
            CLIMETHOD(xmlVersionSet) (THIS_ const CLISTR*     _xmlVersion) PURE;
            CLIMETHOD(serializeXml) (THIS_ CLICSTR*          strTo
                                         , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                    ) PURE;
            CLIMETHOD(deserializeXml) (THIS_ const CLICSTR*    strXml
                                           , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                      ) PURE;
            CLIMETHOD(getChildDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */) PURE;
            CLIMETHOD(createDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                           , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                           , const CLISTR*     nodeName
                                           , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                      ) PURE;
            CLIMETHOD(createDataNodeChars) (THIS_ INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                                , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                                , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                           ) PURE;
            CLIMETHOD(createChildDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                                , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                , const CLISTR*     nodeName
                                                , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                           ) PURE;
            CLIMETHOD(createChildDataNodeChars) (THIS_ INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                                     , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                     , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                                     , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                                ) PURE;
            CLIMETHOD(getChildsCount) (THIS_ SIZE_T*    childsCount /* [out] size_t childsCount  */) PURE;
            CLIMETHOD_(SIZE_T, getChildsCountSimple) (THIS) PURE;
            CLIMETHOD(getChildNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                         , SIZE_T    nodeIndex /* [in] size_t  nodeIndex  */
                                    ) PURE;
            CLIMETHOD(insertChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                            , SIZE_T    where /* [in] size_t  where  */
                                       ) PURE;
            CLIMETHOD(pushBackChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */) PURE;
            CLIMETHOD(moveChildNodeFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeFrom /* [in] ::cli::iDataNode*  pNodeFrom  */
                                              , SIZE_T    moveFromIdx /* [in] size_t  moveFromIdx  */
                                              , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                         ) PURE;
            CLIMETHOD(moveChildNodesByTypeFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                     , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                                ) PURE;
            CLIMETHOD(moveChildNodesByTypeFromEx) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                       , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                                       , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                                  ) PURE;
            CLIMETHOD(eraseChildNode) (THIS_ SIZE_T    where /* [in] size_t  where  */) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iDataRoot >
           {
            static char const * getName() { return INTERFACE_CLI_IDATAROOT_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iDataRoot* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iDataRoot > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iDataRoot wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IDATAROOT >
                                      */
                 >
        class CiDataRootWrapper
        {
            public:
        
                typedef  CiDataRootWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiDataRootWrapper() :
                   pif(0) {}
        
                CiDataRootWrapper( iDataRoot *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiDataRootWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiDataRootWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiDataRootWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiDataRootWrapper(const CiDataRootWrapper &i) :
                    pif(i.pif) { }
        
                ~CiDataRootWrapper()  { }
        
                CiDataRootWrapper& operator=(const CiDataRootWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_inputStreamId( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = inputStreamIdGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_inputStreamId( SIZE_T _inputStreamId
                                      )
                   {
                    RCODE res = inputStreamIdSet( _inputStreamId );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, inputStreamId );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE inputStreamIdGet( SIZE_T*    _inputStreamId /* [out] size_t _inputStreamId  */)
                   {
                
                    return pif->inputStreamIdGet(_inputStreamId);
                   }
                
                RCODE inputStreamIdSet( SIZE_T    _inputStreamId /* [in] size_t  _inputStreamId  */)
                   {
                
                    return pif->inputStreamIdSet(_inputStreamId);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                SIZE_T get_streamId( )
                   {
                    SIZE_T tmpVal;
                    RCODE res = streamIdGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_streamId( SIZE_T _streamId
                                 )
                   {
                    RCODE res = streamIdSet( _streamId );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, SIZE_T, streamId );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE streamIdGet( SIZE_T*    _streamId /* [out] size_t _streamId  */)
                   {
                
                    return pif->streamIdGet(_streamId);
                   }
                
                RCODE streamIdSet( SIZE_T    _streamId /* [in] size_t  _streamId  */)
                   {
                
                    return pif->streamIdSet(_streamId);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_encodingName( )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = encodingNameGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_encodingName( const ::std::wstring &_encodingName
                                     )
                   {
                    RCODE res = encodingNameSet( _encodingName );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, encodingName );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE encodingNameGet( ::std::wstring    &_encodingName)
                   {
                    CCliStr tmp__encodingName; CCliStr_init( tmp__encodingName );
                    RCODE res = pif->encodingNameGet(&tmp__encodingName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _encodingName, tmp__encodingName);
                       }
                    return res;
                   }
                
                RCODE encodingNameSet( const ::std::wstring    &_encodingName)
                   {
                    CCliStr tmp__encodingName; CCliStr_lightCopyTo( tmp__encodingName, _encodingName);
                    return pif->encodingNameSet(&tmp__encodingName);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_xmlVersion( )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = xmlVersionGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_xmlVersion( const ::std::wstring &_xmlVersion
                                   )
                   {
                    RCODE res = xmlVersionSet( _xmlVersion );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, xmlVersion );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE xmlVersionGet( ::std::wstring    &_xmlVersion)
                   {
                    CCliStr tmp__xmlVersion; CCliStr_init( tmp__xmlVersion );
                    RCODE res = pif->xmlVersionGet(&tmp__xmlVersion);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _xmlVersion, tmp__xmlVersion);
                       }
                    return res;
                   }
                
                RCODE xmlVersionSet( const ::std::wstring    &_xmlVersion)
                   {
                    CCliStr tmp__xmlVersion; CCliStr_lightCopyTo( tmp__xmlVersion, _xmlVersion);
                    return pif->xmlVersionSet(&tmp__xmlVersion);
                   }
                
                RCODE serializeXml( ::std::string    &strTo
                                  , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                  )
                   {
                    CCliCStr tmp_strTo; CCliCStr_init( tmp_strTo );
                
                    RCODE res = pif->serializeXml(&tmp_strTo, flags);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( strTo, tmp_strTo);
                       }
                    return res;
                   }
                
                RCODE deserializeXml( const ::std::string    &strXml
                                    , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                    )
                   {
                    CCliCStr tmp_strXml; CCliCStr_lightCopyTo( tmp_strXml, strXml);
                
                    return pif->deserializeXml(&tmp_strXml, flags);
                   }
                
                RCODE getChildDataNode( INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */)
                   {
                
                    return pif->getChildDataNode(pNode);
                   }
                
                RCODE createDataNode( INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                    , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                    , const ::std::wstring    &nodeName
                                    , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                    )
                   {
                
                
                    CCliStr tmp_nodeName; CCliStr_lightCopyTo( tmp_nodeName, nodeName);
                
                    return pif->createDataNode(pNewNode, nodeType, &tmp_nodeName, pValue);
                   }
                
                RCODE createDataNodeChars( INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                         , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                         , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                         , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                         )
                   {
                
                
                
                
                    return pif->createDataNodeChars(pNewNode, nodeType, nodeName, pValue);
                   }
                
                RCODE createChildDataNode( INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                         , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                         , const ::std::wstring    &nodeName
                                         , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                         )
                   {
                
                
                    CCliStr tmp_nodeName; CCliStr_lightCopyTo( tmp_nodeName, nodeName);
                
                    return pif->createChildDataNode(pNewChildNode, nodeType, &tmp_nodeName, pValue);
                   }
                
                RCODE createChildDataNodeChars( INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                              , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                              , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                              , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                              )
                   {
                
                
                
                
                    return pif->createChildDataNodeChars(pNewChildNode, nodeType, nodeName, pValue);
                   }
                
                RCODE getChildsCount( SIZE_T*    childsCount /* [out] size_t childsCount  */)
                   {
                
                    return pif->getChildsCount(childsCount);
                   }
                
                SIZE_T getChildsCountSimple( )
                   {
                    return pif->getChildsCountSimple();
                   }
                
                RCODE getChildNode( INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                  , SIZE_T    nodeIndex /* [in] size_t  nodeIndex  */
                                  )
                   {
                
                
                    return pif->getChildNode(pNode, nodeIndex);
                   }
                
                RCODE insertChildNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                     , SIZE_T    where /* [in] size_t  where  */
                                     )
                   {
                
                
                    return pif->insertChildNode(pNode, where);
                   }
                
                RCODE pushBackChildNode( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
                   {
                
                    return pif->pushBackChildNode(pNode);
                   }
                
                RCODE moveChildNodeFrom( INTERFACE_CLI_IDATANODE*    pNodeFrom /* [in] ::cli::iDataNode*  pNodeFrom  */
                                       , SIZE_T    moveFromIdx /* [in] size_t  moveFromIdx  */
                                       , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                       )
                   {
                
                
                
                    return pif->moveChildNodeFrom(pNodeFrom, moveFromIdx, insertWhere);
                   }
                
                RCODE moveChildNodesByTypeFrom( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                              , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                              )
                   {
                
                
                    return pif->moveChildNodesByTypeFrom(pNode, moveTypes);
                   }
                
                RCODE moveChildNodesByTypeFromEx( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                                , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                                )
                   {
                
                
                
                    return pif->moveChildNodesByTypeFromEx(pNode, moveTypes, insertWhere);
                   }
                
                RCODE eraseChildNode( SIZE_T    where /* [in] size_t  where  */)
                   {
                
                    return pif->eraseChildNode(where);
                   }
                

        
        
        }; // class CiDataRootWrapper
        
        typedef CiDataRootWrapper< ::cli::CCliPtr< INTERFACE_CLI_IDATAROOT     > >  CiDataRoot;
        typedef CiDataRootWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATAROOT > >  CiDataRoot_nrc; /* No ref counting for interface used */
        typedef CiDataRootWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATAROOT > >  CiDataRoot_tmp; /* for temporary usage, same as CiDataRoot_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iDataXPathQuery */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IDATAXPATHQUERY_IID
    #define INTERFACE_CLI_IDATAXPATHQUERY_IID    "/cli/iDataXPathQuery"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iDataXPathQuery
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IDATAXPATHQUERY
       #define INTERFACE_CLI_IDATAXPATHQUERY    ::cli::iDataXPathQuery
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iDataXPathQuery
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IDATAXPATHQUERY
       #define INTERFACE_CLI_IDATAXPATHQUERY    cli_iDataXPathQuery
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iDataXPathQuery methods */
            CLIMETHOD(setQueryString) (THIS_ const CLISTR*     queryStr) PURE;
            CLIMETHOD(setQueryStringChars) (THIS_ const WCHAR*    queryStr /* [in,flat] wchar  queryStr[]  */) PURE;
            CLIMETHOD(getQueryString) (THIS_ CLISTR*           queryStr) PURE;
            CLIMETHOD(getNormalizedQueryString) (THIS_ CLISTR*           queryStr) PURE;
            CLIMETHOD(executeQuery) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                         , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                         , INTERFACE_CLI_IDATANODELIST**    pResultNodes /* [out,optional] ::cli::iDataNodeList* pResultNodes  */
                                    ) PURE;
            CLIMETHOD(executeCreationQuery) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                 , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                            ) PURE;
            CLIMETHOD(executeQuerySingleNodeResult) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                         , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                         , BOOL    bClone /* [in] bool  bClone  */
                                                         , INTERFACE_CLI_IDATANODE**    pResultNode /* [out,optional] ::cli::iDataNode* pResultNode  */
                                                    ) PURE;
            CLIMETHOD(executeQueryCloneToParent) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                      , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                      , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                                 ) PURE;
            CLIMETHOD(executeQueryCloneToParentEx) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                        , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                        , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                                        , const CLISTR*     newParentName
                                                   ) PURE;
            CLIMETHOD(executeQueryCloneToParentExChars) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                             , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                             , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                                             , const WCHAR*    newParentName /* [in,flat] wchar  newParentName[]  */
                                                        ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iDataXPathQuery >
           {
            static char const * getName() { return INTERFACE_CLI_IDATAXPATHQUERY_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iDataXPathQuery* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iDataXPathQuery > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iDataXPathQuery wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IDATAXPATHQUERY >
                                      */
                 >
        class CiDataXPathQueryWrapper
        {
            public:
        
                typedef  CiDataXPathQueryWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiDataXPathQueryWrapper() :
                   pif(0) {}
        
                CiDataXPathQueryWrapper( iDataXPathQuery *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiDataXPathQueryWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiDataXPathQueryWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiDataXPathQueryWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiDataXPathQueryWrapper(const CiDataXPathQueryWrapper &i) :
                    pif(i.pif) { }
        
                ~CiDataXPathQueryWrapper()  { }
        
                CiDataXPathQueryWrapper& operator=(const CiDataXPathQueryWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE setQueryString( const ::std::wstring    &queryStr)
                   {
                    CCliStr tmp_queryStr; CCliStr_lightCopyTo( tmp_queryStr, queryStr);
                    return pif->setQueryString(&tmp_queryStr);
                   }
                
                RCODE setQueryStringChars( const WCHAR*    queryStr /* [in,flat] wchar  queryStr[]  */)
                   {
                
                    return pif->setQueryStringChars(queryStr);
                   }
                
                RCODE getQueryString( ::std::wstring    &queryStr)
                   {
                    CCliStr tmp_queryStr; CCliStr_init( tmp_queryStr );
                    RCODE res = pif->getQueryString(&tmp_queryStr);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( queryStr, tmp_queryStr);
                       }
                    return res;
                   }
                
                RCODE getNormalizedQueryString( ::std::wstring    &queryStr)
                   {
                    CCliStr tmp_queryStr; CCliStr_init( tmp_queryStr );
                    RCODE res = pif->getNormalizedQueryString(&tmp_queryStr);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( queryStr, tmp_queryStr);
                       }
                    return res;
                   }
                
                RCODE executeQuery( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                  , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                  , INTERFACE_CLI_IDATANODELIST**    pResultNodes /* [out,optional] ::cli::iDataNodeList* pResultNodes  */
                                  )
                   {
                
                
                
                    return pif->executeQuery(pNode, pVarMap, pResultNodes);
                   }
                
                RCODE executeCreationQuery( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                          , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                          )
                   {
                
                
                    return pif->executeCreationQuery(pNode, pVarMap);
                   }
                
                RCODE executeQuerySingleNodeResult( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                  , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                  , BOOL    bClone /* [in] bool  bClone  */
                                                  , INTERFACE_CLI_IDATANODE**    pResultNode /* [out,optional] ::cli::iDataNode* pResultNode  */
                                                  )
                   {
                
                
                
                
                    return pif->executeQuerySingleNodeResult(pNode, pVarMap, bClone, pResultNode);
                   }
                
                RCODE executeQueryCloneToParent( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                               , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                               , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                               )
                   {
                
                
                
                    return pif->executeQueryCloneToParent(pNode, pVarMap, pResultNode);
                   }
                
                RCODE executeQueryCloneToParentEx( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                 , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                 , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                                 , const ::std::wstring    &newParentName
                                                 )
                   {
                
                
                
                    CCliStr tmp_newParentName; CCliStr_lightCopyTo( tmp_newParentName, newParentName);
                    return pif->executeQueryCloneToParentEx(pNode, pVarMap, pResultNode, &tmp_newParentName);
                   }
                
                RCODE executeQueryCloneToParentExChars( INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                      , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                      , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                                      , const WCHAR*    newParentName /* [in,flat] wchar  newParentName[]  */
                                                      )
                   {
                
                
                
                
                    return pif->executeQueryCloneToParentExChars(pNode, pVarMap, pResultNode, newParentName);
                   }
                

        
        
        }; // class CiDataXPathQueryWrapper
        
        typedef CiDataXPathQueryWrapper< ::cli::CCliPtr< INTERFACE_CLI_IDATAXPATHQUERY     > >  CiDataXPathQuery;
        typedef CiDataXPathQueryWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATAXPATHQUERY > >  CiDataXPathQuery_nrc; /* No ref counting for interface used */
        typedef CiDataXPathQueryWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IDATAXPATHQUERY > >  CiDataXPathQuery_tmp; /* for temporary usage, same as CiDataXPathQuery_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IDATADOM_H */
