#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_IGUID_H
#define CLI_IGUID_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/iguid.h>", CLI_IGUID_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_IGUID_H
    #include <cli/iguid.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::GuidInfo */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_GUIDINFO                   SIZE_T
#else
    #define ENUM_CLI_GUIDINFO                   SIZE_T
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_GUIDINFO_GUIDSIZE
    #define CLI_GUIDINFO_GUIDSIZE             16
#endif /* CLI_GUIDINFO_GUIDSIZE */

#ifndef CLI_GUIDINFO_GUIDSTRINFSIZE
    #define CLI_GUIDINFO_GUIDSTRINFSIZE       36
#endif /* CLI_GUIDINFO_GUIDSTRINFSIZE */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace GuidInfo {
                const SIZE_T guidSize         = CONSTANT_SIZE_T(16);
                const SIZE_T guidStrinfSize   = CONSTANT_SIZE_T(36);
        }; // namespace GuidInfo
    }; // namespace cli
    /* using namespace ::cli::GuidInfo; */
    
#endif





/* ------------------------------------------------------ */
/* Struct: ::cli::Guid */
/* ------------------------------------------------------ */

#ifdef CLI_STRUCT_NAME
   #undef CLI_STRUCT_NAME
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
    #define CLI_STRUCT_NAME                   Guid
    #ifndef STRUCT_CLI_GUID_PREDECLARED
    #define STRUCT_CLI_GUID_PREDECLARED
        struct Guid;
        #ifndef STRUCT_CLI_GUID
            #define STRUCT_CLI_GUID                   ::cli::Guid
        #endif
        #ifndef STRUCT_CLI_UUID
            #define STRUCT_CLI_UUID                   ::cli::Uuid
        #endif
        typedef STRUCT_CLI_GUID                   Uuid;

    #endif // STRUCT_CLI_GUID_PREDECLARED

#else /* C-like declarations */

    #define CLI_STRUCT_NAME                   cli_Guid
    #ifndef STRUCT_CLI_GUID_PREDECLARED
    #define STRUCT_CLI_GUID_PREDECLARED
        struct  tag_cli_Guid;
        typedef struct tag_cli_Guid cli_Guid;
        #ifndef STRUCT_CLI_GUID
            #define STRUCT_CLI_GUID                   struct tag_cli_Guid
        #endif
        #ifndef STRUCT_CLI_UUID
            #define STRUCT_CLI_UUID                   cli_Uuid
        #endif
        typedef STRUCT_CLI_GUID                   cli_Uuid;

    #endif // STRUCT_CLI_GUID_PREDECLARED

#endif /* end of C-like declarations */

        #ifndef STRUCT_CLI_GUID_DEFINED
        #define STRUCT_CLI_GUID_DEFINED
        #include <cli/pshpack1.h>
        CLI_BEGIN_STRUCT_DECLARATION(CLI_STRUCT_NAME)
            DWORD                       Data1;
            WORD                        Data2;
            WORD                        Data3;
            BYTE                        Data4[8];
        CLI_END_STRUCT_DECLARATION(CLI_STRUCT_NAME);
        #include <cli/poppack.h>
        #endif // STRUCT_CLI_GUID_DEFINED

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iGuid */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_IGUID_IID
    #define INTERFACE_CLI_IGUID_IID    "/cli/iGuid"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iGuid
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_IGUID
       #define INTERFACE_CLI_IGUID    ::cli::iGuid
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iGuid
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_IGUID
       #define INTERFACE_CLI_IGUID    cli_iGuid
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iGuid methods */
            CLIMETHOD(generateGuidEx) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                           , const BYTE*    customPart /* [in,flat] byte  customPart[]  */
                                      ) PURE;
            CLIMETHOD(generateGuid) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */) PURE;
            CLIMETHOD_(BOOL, isEqualGuid) (THIS_ const STRUCT_CLI_GUID*    g1 /* [in,ref] ::cli::Guid  g1  */
                                               , const STRUCT_CLI_GUID*    g2 /* [in,ref] ::cli::Guid  g2  */
                                          ) PURE;
            CLIMETHOD(parseStringToGuid) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                              , const CLISTR*     str
                                         ) PURE;
            CLIMETHOD(parseCharStringToGuid) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                                  , const CLICSTR*    str
                                             ) PURE;
            CLIMETHOD(parseStringToGuidChars) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                                   , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                                   , SIZE_T    strSize /* [in] size_t  strSize  */
                                              ) PURE;
            CLIMETHOD(parseCharStringToGuidChars) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                                       , const CHAR*    str /* [in,flat] char  str[]  */
                                                       , SIZE_T    strSize /* [in] size_t  strSize  */
                                                  ) PURE;
            CLIMETHOD(formatGuidToString) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                               , CLISTR*           s
                                          ) PURE;
            CLIMETHOD(formatGuidToCharString) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                                   , CLICSTR*          s
                                              ) PURE;
            CLIMETHOD(formatGuidToStringEx) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                                 , CLISTR*           s
                                                 , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                                 , WCHAR    chSep /* [in] wchar  chSep  */
                                            ) PURE;
            CLIMETHOD(formatGuidToCharStringEx) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                                     , CLICSTR*          s
                                                     , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                                     , CHAR    chSep /* [in] char  chSep  */
                                                ) PURE;
            CLIMETHOD(formatGuidToStringBuf) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                                  , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                             ) PURE;
            CLIMETHOD(formatGuidToCharStringBuf) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                                      , CHAR*    buf /* [out,flat] char buf[]  */
                                                 ) PURE;
            CLIMETHOD(formatGuidToStringExBuf) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                                    , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                                    , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                                    , WCHAR    chSep /* [in] wchar  chSep  */
                                               ) PURE;
            CLIMETHOD(formatGuidToCharStringExBuf) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                                        , CHAR*    buf /* [out,flat] char buf[]  */
                                                        , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                                        , CHAR    chSep /* [in] char  chSep  */
                                                   ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iGuid >
           {
            static char const * getName() { return INTERFACE_CLI_IGUID_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iGuid* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iGuid > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iGuid wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_IGUID >
                                      */
                 >
        class CiGuidWrapper
        {
            public:
        
                typedef  CiGuidWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiGuidWrapper() :
                   pif(0) {}
        
                CiGuidWrapper( iGuid *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiGuidWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiGuidWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiGuidWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiGuidWrapper(const CiGuidWrapper &i) :
                    pif(i.pif) { }
        
                ~CiGuidWrapper()  { }
        
                CiGuidWrapper& operator=(const CiGuidWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE generateGuidEx( STRUCT_CLI_GUID    &g /* [out] ::cli::Guid g  (struct passed by ref in wrapper) */
                                    , const BYTE*    customPart /* [in,flat] byte  customPart[]  */
                                    )
                   {
                
                
                    return pif->generateGuidEx(&g, customPart);
                   }
                
                RCODE generateGuid( STRUCT_CLI_GUID    &g /* [out] ::cli::Guid g  (struct passed by ref in wrapper) */)
                   {
                
                    return pif->generateGuid(&g);
                   }
                
                BOOL isEqualGuid( const STRUCT_CLI_GUID    &g1 /* [in,ref] ::cli::Guid  g1  (struct passed by ref in wrapper) */
                                , const STRUCT_CLI_GUID    &g2 /* [in,ref] ::cli::Guid  g2  (struct passed by ref in wrapper) */
                                )
                   {
                
                
                    return pif->isEqualGuid(&g1, &g2);
                   }
                
                RCODE parseStringToGuid( STRUCT_CLI_GUID    &g /* [out] ::cli::Guid g  (struct passed by ref in wrapper) */
                                       , const ::std::wstring    &str
                                       )
                   {
                
                    CCliStr tmp_str; CCliStr_lightCopyTo( tmp_str, str);
                    return pif->parseStringToGuid(&g, &tmp_str);
                   }
                
                RCODE parseCharStringToGuid( STRUCT_CLI_GUID    &g /* [out] ::cli::Guid g  (struct passed by ref in wrapper) */
                                           , const ::std::string    &str
                                           )
                   {
                
                    CCliCStr tmp_str; CCliCStr_lightCopyTo( tmp_str, str);
                    return pif->parseCharStringToGuid(&g, &tmp_str);
                   }
                
                RCODE parseStringToGuidChars( STRUCT_CLI_GUID    &g /* [out] ::cli::Guid g  (struct passed by ref in wrapper) */
                                            , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                            , SIZE_T    strSize /* [in] size_t  strSize  */
                                            )
                   {
                
                
                
                    return pif->parseStringToGuidChars(&g, str, strSize);
                   }
                
                RCODE parseCharStringToGuidChars( STRUCT_CLI_GUID    &g /* [out] ::cli::Guid g  (struct passed by ref in wrapper) */
                                                , const CHAR*    str /* [in,flat] char  str[]  */
                                                , SIZE_T    strSize /* [in] size_t  strSize  */
                                                )
                   {
                
                
                
                    return pif->parseCharStringToGuidChars(&g, str, strSize);
                   }
                
                RCODE formatGuidToString( const STRUCT_CLI_GUID    &g /* [in,ref] ::cli::Guid  g  (struct passed by ref in wrapper) */
                                        , ::std::wstring    &s
                                        )
                   {
                
                    CCliStr tmp_s; CCliStr_init( tmp_s );
                    RCODE res = pif->formatGuidToString(&g, &tmp_s);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( s, tmp_s);
                       }
                    return res;
                   }
                
                RCODE formatGuidToCharString( const STRUCT_CLI_GUID    &g /* [in,ref] ::cli::Guid  g  (struct passed by ref in wrapper) */
                                            , ::std::string    &s
                                            )
                   {
                
                    CCliCStr tmp_s; CCliCStr_init( tmp_s );
                    RCODE res = pif->formatGuidToCharString(&g, &tmp_s);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( s, tmp_s);
                       }
                    return res;
                   }
                
                RCODE formatGuidToStringEx( const STRUCT_CLI_GUID    &g /* [in,ref] ::cli::Guid  g  (struct passed by ref in wrapper) */
                                          , ::std::wstring    &s
                                          , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                          , WCHAR    chSep /* [in] wchar  chSep  */
                                          )
                   {
                
                    CCliStr tmp_s; CCliStr_init( tmp_s );
                
                
                    RCODE res = pif->formatGuidToStringEx(&g, &tmp_s, bLowerCase, chSep);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( s, tmp_s);
                       }
                    return res;
                   }
                
                RCODE formatGuidToCharStringEx( const STRUCT_CLI_GUID    &g /* [in,ref] ::cli::Guid  g  (struct passed by ref in wrapper) */
                                              , ::std::string    &s
                                              , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                              , CHAR    chSep /* [in] char  chSep  */
                                              )
                   {
                
                    CCliCStr tmp_s; CCliCStr_init( tmp_s );
                
                
                    RCODE res = pif->formatGuidToCharStringEx(&g, &tmp_s, bLowerCase, chSep);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( s, tmp_s);
                       }
                    return res;
                   }
                
                RCODE formatGuidToStringBuf( const STRUCT_CLI_GUID    &g /* [in,ref] ::cli::Guid  g  (struct passed by ref in wrapper) */
                                           , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                           )
                   {
                
                
                    return pif->formatGuidToStringBuf(&g, buf);
                   }
                
                RCODE formatGuidToCharStringBuf( const STRUCT_CLI_GUID    &g /* [in,ref] ::cli::Guid  g  (struct passed by ref in wrapper) */
                                               , CHAR*    buf /* [out,flat] char buf[]  */
                                               )
                   {
                
                
                    return pif->formatGuidToCharStringBuf(&g, buf);
                   }
                
                RCODE formatGuidToStringExBuf( const STRUCT_CLI_GUID    &g /* [in,ref] ::cli::Guid  g  (struct passed by ref in wrapper) */
                                             , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                             , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                             , WCHAR    chSep /* [in] wchar  chSep  */
                                             )
                   {
                
                
                
                
                    return pif->formatGuidToStringExBuf(&g, buf, bLowerCase, chSep);
                   }
                
                RCODE formatGuidToCharStringExBuf( const STRUCT_CLI_GUID    &g /* [in,ref] ::cli::Guid  g  (struct passed by ref in wrapper) */
                                                 , CHAR*    buf /* [out,flat] char buf[]  */
                                                 , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                                 , CHAR    chSep /* [in] char  chSep  */
                                                 )
                   {
                
                
                
                
                    return pif->formatGuidToCharStringExBuf(&g, buf, bLowerCase, chSep);
                   }
                

        
        
        }; // class CiGuidWrapper
        
        typedef CiGuidWrapper< ::cli::CCliPtr< INTERFACE_CLI_IGUID     > >  CiGuid;
        typedef CiGuidWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IGUID > >  CiGuid_nrc; /* No ref counting for interface used */
        typedef CiGuidWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_IGUID > >  CiGuid_tmp; /* for temporary usage, same as CiGuid_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_IGUID_H */
