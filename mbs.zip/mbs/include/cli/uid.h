#ifndef CLI_UID_H
#define CLI_UID_H

/* add this lines to your scr
#ifndef CLI_UID_H
    #include <cli/uid.h>
#endif
*/

#ifndef CLI_IGUID_H
    #include <cli/iguid.h>
#endif


#ifndef CLI_INET_IFINFOHLP_H
    #include <cli/inet/ifInfoHlp.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


namespace cli
{

inline
bool operator<( const ::cli::Guid &g1, const ::cli::Guid &g2)
{
     return memcmp(&g1,&g2,sizeof(STRUCT_CLI_GUID))<0 ? true : false;
}

inline
bool operator>( const ::cli::Guid &g1, const ::cli::Guid &g2)
{
     return memcmp(&g1,&g2,sizeof(STRUCT_CLI_GUID))>0 ? true : false;
}

inline
bool operator==( const ::cli::Guid &g1, const ::cli::Guid &g2)
{
     return memcmp(&g1,&g2,sizeof(STRUCT_CLI_GUID))==0 ? true : false;
}

inline
bool operator!=( const ::cli::Guid &g1, const ::cli::Guid &g2)
{
     return memcmp(&g1,&g2,sizeof(STRUCT_CLI_GUID))!=0 ? true : false;
}


inline
SIZE_T copyMacToBufHelper( BYTE * macBuf, const BYTE * srcMacBuf, SIZE_T maxBytesToCopy )
{
    SIZE_T i=0;
    for(; i!=maxBytesToCopy; ++i)
       macBuf[i] = srcMacBuf[i];
    return i;
}

// return number of bytes copied
inline
SIZE_T getNetworkInterfaceMacForUuidGen( BYTE * macBuf, SIZE_T maxBytesToCopy, ::cli::inet::CiNetInterfaceInfo &ifInfoHolder )
{
    RCODE res = ifInfoHolder.queryNetInterfaceIpInfo();
    if (res) return 0;

    SIZE_T ifIdx = 0, ifIdxMax = ifInfoHolder.getInfoSize();

    for(; ifIdx!=ifIdxMax; ++ifIdx )
       {
        STRUCT_CLI_INET_CNETINTERFACEIPINFO ifInfo = ifInfoHolder.netInterfaceIpInfo[ifIdx];
        if (ifInfo.interfaceType==CLI_INET_NETINTERFACETYPE_LOOPBACK) continue;
        if (!(ifInfo.interfaceFlags&CLI_INET_NETINTERFACEFLAGS_ON))   continue;
        return copyMacToBufHelper( macBuf, &ifInfo.macAddress[0], (maxBytesToCopy < ifInfo.macAddressSize) ? maxBytesToCopy : ifInfo.macAddressSize );
       }

    // allow interfaces in OFF state
    for(ifIdx = 0; ifIdx!=ifIdxMax; ++ifIdx )
       {
        STRUCT_CLI_INET_CNETINTERFACEIPINFO ifInfo = ifInfoHolder.netInterfaceIpInfo[ifIdx];
        if (ifInfo.interfaceType==CLI_INET_NETINTERFACETYPE_LOOPBACK) continue;
        return copyMacToBufHelper( macBuf, &ifInfo.macAddress[0], (maxBytesToCopy < ifInfo.macAddressSize) ? maxBytesToCopy : ifInfo.macAddressSize );
       }

    // allow loopback interfaces
    for(ifIdx = 0; ifIdx!=ifIdxMax; ++ifIdx )
       {
        STRUCT_CLI_INET_CNETINTERFACEIPINFO ifInfo = ifInfoHolder.netInterfaceIpInfo[ifIdx];
        return copyMacToBufHelper( macBuf, &ifInfo.macAddress[0], (maxBytesToCopy < ifInfo.macAddressSize) ? maxBytesToCopy : ifInfo.macAddressSize );
       }

    return 0;
}


inline
SIZE_T getNetworkInterfaceMacForUuidGen( BYTE * macBuf, SIZE_T maxBytesToCopy, const std::string &ifInfoComponentName = "/cli/inet/netinterfaceinfo" )
{
    try{
        ::cli::inet::CiNetInterfaceInfo ifInfoHolder(ifInfoComponentName.c_str());
        return getNetworkInterfaceMacForUuidGen( macBuf, maxBytesToCopy, ifInfoHolder );
       }
    catch(...)
       {}
    return 0;
}

// ::cli::Guid guidGen("/cli/guidgen");
inline
RCODE guidParse( ::cli::Guid &parseTo, const std::wstring &strGuid, ::cli::CiGuid &gg )
{
    return gg.parseStringToGuid( parseTo, strGuid );
}

inline
RCODE guidParse( ::cli::Guid &parseTo, const std::string &strGuid, ::cli::CiGuid &gg )
{
    return gg.parseCharStringToGuid( parseTo, strGuid );
}

inline
RCODE guidFormat( const ::cli::Guid &guid, std::wstring &strFormatTo, ::cli::CiGuid &gg, bool bLowerCase = false, wchar_t sepChar = L'-')
{
    return gg.formatGuidToStringEx( guid, strFormatTo, bLowerCase?TRUE:FALSE, sepChar );
}

inline
RCODE guidFormat( const ::cli::Guid &guid, std::string &strFormatTo, ::cli::CiGuid &gg, bool bLowerCase = false, char sepChar = L'-')
{
    return gg.formatGuidToCharStringEx( guid, strFormatTo, bLowerCase?TRUE:FALSE, sepChar );
}

inline
RCODE generateGuid( ::cli::Guid &guid, ::cli::CiGuid &guidGen, BYTE *mac = 0, SIZE_T macSize = 0)
{
    if (mac && macSize==6) 
       return guidGen.generateGuidEx(guid, mac);
    else
       return guidGen.generateGuid(guid);
}




struct CGuid : public ::cli::Guid
{

}; // struct CGuid

}; // namespace cli



#endif /* CLI_UID_H */

