#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLIMOD_H
#define CLI_CLIMOD_H

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_REFCNT_H
    #include <cli/refcnt.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#ifndef __MBS_STRINGIZE
    #define __MBS_STRINGIZE(name) #name
#endif

#ifndef MBS_STRINGIZE
    #define MBS_STRINGIZE(name) __MBS_STRINGIZE(name)
#endif

#ifndef MBS_STRINGIZE_W
    #define MBS_STRINGIZE_W(name) L##__MBS_STRINGIZE(name)
#endif

#ifndef MBS_PROJECT_NAME
    #ifndef PROJECT_NAME
        #ifdef _MSC_VER
            #pragma message("PROJECT_NAME macro not defined, set up PROJECT_NAME=$(ProjectName) in your project's C++ preporcessor definitions")
            #pragma message("PROJECT_NAME macro required for some automatizations")
        #endif
        #define PROJECT_NAME Project_name_not_taken__Please_set_macro_PROJECT_NAME
    #endif

    #define MBS_PROJECT_NAME  MBS_STRINGIZE(PROJECT_NAME)
#endif
/*
#ifndef __MBS_PROJECT_NAME_W
    #define __MBS_PROJECT_NAME_W(name)  L##name
#endif

#ifndef _MBS_PROJECT_NAME_W
    #define _MBS_PROJECT_NAME_W(name)  name
#endif

#ifndef MBS_PROJECT_NAME_W
    #define MBS_PROJECT_NAME_W  __MBS_PROJECT_NAME_W(MBS_PROJECT_NAME)
#endif
*/

#ifndef MARTY_LIBAPI_H
    #include <marty/libapi.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#if !defined(_WIN32) && !defined(CLI_MONOLITHIC)
    #include <dlfcn.h>
#endif

#ifdef DL_DEBUG
    #ifndef MARTY_UTF_H
        #include <marty/utf.h>
    #endif
#endif


#if !defined(CLI_MONOLITHIC) && !defined(TARGET_TYPE_EXE) && !defined(NOT_CLI_MODULE)
    #ifndef USE_CLI_MODULE
        #define USE_CLI_MODULE
    #endif
#else
#endif


#if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
extern char cliModuleInternalNameBuf[];
#endif


namespace cli
{

class CModuleBase
{
protected:
        mutable CCriticalSection        locker;
        mutable ::std::wstring          moduleFileName;     // full file name
        //::std::wstring          moduleName;         // name only, without path and ext
        mutable ::std::wstring          moduleInternalName; // internal name, based on MBS_PROJECT_NAME macro value

protected:

        void toWide(const ::std::string  &c, ::std::wstring &w) const
           {
            #ifdef DL_DEBUG
            printf("CModuleBase::toWide enter\n" );
            #endif
            w = MARTY_CON::strToWide(c);
            #ifdef DL_DEBUG
            printf("CModuleBase::toWide leave\n" );
            #endif
           }

        ::std::wstring toWideCopy(const ::std::string  &c ) const
           {
            ::std::wstring res;
            toWide( c, res );
            return res;
           }


public:

        void setFileName(const CHAR* fname)
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            // do nothing
            #else

            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const CHAR*) enter, fname: %s\n", fname );
            #endif
            if (!fname) setFileName( ::std::string() );
            else        setFileName( ::std::string(fname) );
            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const CHAR*) leave\n" );
            #endif

            #endif
           }

        void setFileName(const WCHAR* fname)
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            // do nothing
            #else

            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName( const WCHAR*) enter, fname: %s\n", MARTY_UTF::toUtf8(fname).c_str() );
            #endif
            if (!fname) setFileName( ::std::wstring() );
            else        setFileName( ::std::wstring(fname) );
            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const WCHAR*) leave\n" );
            #endif

            #endif
           }

        void setFileName(const ::std::string &fname)
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            // do nothing
            #else

            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const string&) enter, fname: %s\n", fname.c_str() );
            #endif
            ::std::wstring wfname; toWide( fname, wfname); setFileName(wfname);
            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const string&) leave\n" );
            #endif

            #endif
           }

        void setFileName(const ::std::wstring &fname)
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            // do nothing
            #else

            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const wstring&) enter, fname: %s\n", MARTY_UTF::toUtf8(fname).c_str() );
            #endif
            if (fname.empty())
               {
                #ifdef DL_DEBUG
                printf("CModuleBase::setFileName(const wstring&) - name empty, clearing\n" );
                #endif
                moduleFileName.clear();
                #ifdef DL_DEBUG
                printf("CModuleBase::setFileName(const wstring&) - name empty, cleared\n" );
                #endif

                //::std::wstring().swap( moduleFileName     );
                //::std::wstring().swap( moduleName         );
                return;
               }
            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const wstring&) - assign new name to moduleFileName\n" );
            printf("CModuleBase::setFileName(const wstring&) - change %s to %s\n", MARTY_UTF::toUtf8(moduleFileName).c_str(), MARTY_UTF::toUtf8(fname).c_str() );
            #endif
            moduleFileName = fname;
            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const wstring&) - new name assigned\n" );
            #endif
            //moduleName = MARTY_FILENAME::getName( moduleFileName );
            #ifdef DL_DEBUG
            printf("CModuleBase::setFileName(const wstring&) leave\n" );
            #endif

            #endif
           }

        void setInternalName(const CHAR* name)
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            // do nothing
            #else

            if (!name) setInternalName( ::std::string() );
            else       setInternalName( ::std::string(name) );

            #endif
           }

        void setInternalName(const WCHAR* name)
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            // do nothing
            #else

            if (!name) setInternalName( ::std::wstring() );
            else       setInternalName( ::std::wstring(name) );

            #endif
           }

        void setInternalName(const ::std::string &name)
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            // do nothing
            #else

            ::std::wstring wname; toWide( name, wname); setInternalName(wname);

            #endif
           }

        void setInternalName(const ::std::wstring &name)
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            // do nothing
            #else

            if (name.empty()) moduleInternalName.clear(); //::std::wstring().swap( moduleInternalName );
            else              moduleInternalName = name;

            #endif
           }

        CModuleBase()
           : locker()
           , moduleFileName()
           //, moduleName()
           , moduleInternalName()
           {
            #ifdef DL_DEBUG
            printf("CModuleBase::CModuleBase()\n" );
            #endif
            setInternalName(MBS_PROJECT_NAME);
           }

        ~CModuleBase()
           {
            #ifdef DL_DEBUG
            printf("CModuleBase::~CModuleBase()\n" );
            #endif
            //HACK: swap needed cause c++ runtime reports that memory is corrupted under Linux
            #ifdef __GNUC__
            //moduleFileName.clear();
            //moduleInternalName.clear();
            ::std::wstring().swap( moduleFileName     );
            //::std::wstring().swap( moduleName         );
            ::std::wstring().swap( moduleInternalName );
            #endif
           }

        const WCHAR* getInternalName() const
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            if (moduleInternalName.empty())
               {
                CLI_AUTOLOCK(locker);
                moduleInternalName = toWideCopy(::std::string(cliModuleInternalNameBuf));
                #ifdef MBS_PROJECT_NAME
                if (moduleInternalName.empty())
                   moduleInternalName = toWideCopy(::std::string(MBS_PROJECT_NAME));
                #endif
                if (moduleInternalName.empty())
                   moduleInternalName = L"anonimous_module";
               }
            return moduleInternalName.c_str();
            #else // WIN32 || !USE_CLI_MODULE
            return moduleInternalName.c_str();
            #endif
           }

        const WCHAR* getFileName() const
           {
            #if defined(USE_CLI_MODULE) && !defined(WIN32) && !defined(_WIN32)
            if (moduleFileName.empty())
               {
                CLI_AUTOLOCK(locker);
                MARTY_LIBAPI::libdl::getCurrentModuleFileName( moduleFileName );
                #ifdef MBS_PROJECT_NAME
                if (moduleFileName.empty())
                   moduleFileName = toWideCopy(::std::string(MBS_PROJECT_NAME) + ::std::string(".so"));
                #endif
                if (moduleFileName.empty())
                   moduleFileName = L"anonimous_module.so";
               }
            return moduleFileName.c_str();
            #else // WIN32 || !USE_CLI_MODULE
                #if defined(WIN32) || defined(_WIN32)
                if (moduleFileName.empty())
                   {
                    CLI_AUTOLOCK(locker);
                    // assume that is a main module
                    MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, moduleFileName);
                   }
                #endif // WIN32
            return moduleFileName.c_str();
            #endif
           }
        /*
        const WCHAR* getFileName()// const
           {
            if (moduleFileName.empty())
               {
                CLI_AUTOLOCK(locker);
                // assume that is a main module
                ::std::wstring name;
                MARTY_LIBAPI_NS getModuleFileName((ABSTRACT_MODULE_HANDLE)0, name);
                setFileName(name);
               }
            return moduleFileName.c_str();
           }
        */

        const WCHAR* getName() const
           {
            #ifdef CLI_MONOLITHIC
            return getInternalName();
            #else
            return getFileName();
            //return moduleName.c_str(); // get file name
            #endif
           }


};

class CModule : public CModuleBase
{
        ::cli::CRefCounter      refCount;
        //::std::wstring          moduleFileName;
        //::std::wstring          moduleInternalName;

        //CCriticalSection        locker;

        #ifndef CLI_MONOLITHIC
            #if defined(_WIN32)
            HINSTANCE               hModule;
            #elif defined(__GNUC__)
            void*                   hModule;
            #else
                #error "Unsupported compiler"
            #endif
        #endif
        CModule(const CModule &)
           : CModuleBase()
           , refCount()
           //, moduleFileName()
           //, moduleInternalName()
           //, locker()
           #if !defined(CLI_MONOLITHIC)
           , hModule(0)
           #endif
           {
           }
        CModule& operator=(const CModule &) { return *this; }


    public:

        CModule()
           : CModuleBase()
           , refCount()
           //, moduleFileName()
           //, moduleInternalName()
           //, locker()
           #if !defined(CLI_MONOLITHIC)
           , hModule(0)
           #endif
           {
            #ifdef DL_DEBUG
            printf("CModule::CModule()\n" );
            #endif
           }

        ~CModule()
           {
            #ifdef DL_DEBUG
            printf("CModule::~CModule()\n" );
            #endif
           }

        ULONG addRef()
           {
            return (ilint_t)++refCount;
           }
        ULONG release()
           {
            return (ilint_t)--refCount;
           }

        BOOL canUnload() const
           {
            return ((ilint_t)refCount)>0 ? FALSE : TRUE ;
           }

       #if defined(_WIN32)
       void setModuleHandle(HINSTANCE hm)
       #else
       void setModuleHandle(void* hm)
       #endif
          {
           #if defined(CLI_MONOLITHIC)
           // do nothing
           #else
           hModule = hm;
           #endif
          }

       #if defined(_WIN32)
       HINSTANCE getModuleHandle() const
       #else
       void* getModuleHandle() const
       #endif
          {
           #if defined(CLI_MONOLITHIC)
           return 0;
           #else
               #if !defined(WIN32) && !defined(_WIN32)
               if (!hModule) // not initialized yet
                  {
                   ::std::string modFileName;
                   if (MARTY_LIBAPI::libdl::getCurrentModuleFileName( modFileName ))
                      {
                       const_cast<CModule*>(this)->hModule = ::dlopen(modFileName.c_str(),  RTLD_LAZY|RTLD_LOCAL|RTLD_NOLOAD);
                      }
                  }
               return hModule;
               #else
               return hModule;
               #endif
           #endif
          }
};



class CAppModule : public CModuleBase
{
public:

        CAppModule() : CModuleBase()
           {
            #ifdef DL_DEBUG
            printf("CAppModule::CAppModule()\n" );
            #endif
            //::std::wstring name;
            //MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, name);
            //setFileName(name);
            MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, moduleFileName);
            #ifdef MBS_PROJECT_NAME
            //setInternalName(MBS_PROJECT_NAME);
            moduleInternalName = toWideCopy(MBS_PROJECT_NAME);
            #else
            //setInternalName(L"cliApp");
            moduleInternalName = L"cliApp";
            #endif
           }

        ULONG addRef()  { return 1; }
        ULONG release() { return 1; }
};




#ifdef CLI_MONOLITHIC
    #define INIT_CLI_MODULE_NAME(cliModule, internalName)
#else

    #if defined(WIN32) || defined(_WIN32)

    #define WIN32_ON_DYN_MODULE_PROCESS_ATTACH()
    #define WIN32_ON_DYN_MODULE_PROCESS_DETACH()
    #define WIN32_ON_DYN_MODULE_THREAD_ATTACH()
    #define WIN32_ON_DYN_MODULE_THREAD_DETACH()

    extern "C" BOOL WINAPI DllMain( HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved );

    #define INIT_CLI_MODULE_NAME(cliModule, internalName)                                                \
    BOOL WINAPI DllMain( HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved )                           \
       {                                                                                                 \
        switch(dwReason)                                                                                 \
           {                                                                                             \
            case DLL_PROCESS_ATTACH:                                                                     \
                 {                                                                                       \
                  cliModule . setModuleHandle((HINSTANCE)hinstDLL);                                      \
                  WCHAR moduleFileName[4096];                                                            \
                  DWORD res = ::GetModuleFileNameW( (HMODULE)hinstDLL                                    \
                                                  , moduleFileName                                       \
                                                  , sizeof(moduleFileName)/sizeof(moduleFileName[0])-1   \
                                                  );                                                     \
                  moduleFileName[res] = 0;                                                               \
                  cliModule . setFileName(moduleFileName);                                               \
                  cliModule . setInternalName(internalName);                                             \
                  WIN32_ON_DYN_MODULE_PROCESS_ATTACH();                                                  \
                  break;                                                                                 \
                 }                                                                                       \
            case DLL_PROCESS_DETACH:                                                                     \
                 WIN32_ON_DYN_MODULE_PROCESS_DETACH();                                                   \
                 break;                                                                                  \
            case DLL_THREAD_ATTACH:                                                                      \
                 WIN32_ON_DYN_MODULE_THREAD_ATTACH();                                                    \
                 break;                                                                                  \
            case DLL_THREAD_DETACH:                                                                      \
                 WIN32_ON_DYN_MODULE_THREAD_DETACH();                                                    \
                 break;                                                                                  \
                                                                                                         \
           };                                                                                            \
        return TRUE;                                                                                     \
       }

    #else // LINUX/GNU
    #define INIT_CLI_MODULE_NAME(cliModule, internalName)                                                \
    char cliModuleInternalNameBuf[256] = { 0 };                                                          \
    static void __attribute__ ((constructor)) getModuleName(void)                                        \
       {                                                                                                 \
        /*
        Dl_info info;                                                                                    \
        int res = dladdr((void*)(&getModuleName), &info);                                                \
        if (!res || !info.dli_fname) { cliModule . setFileName(L""); return; }                           \
        */                                                                                               \
        strcpy(&cliModuleInternalNameBuf[0], internalName );                                             \
                                                                                                         \
        /*                                                                                               \
        ::std::wstring tmp; MARTY_FILESYSTEM_NS filenameDecode(tmp, ::std::string(info.dli_fname));      \
                                                                                                         \
        cliModule . setFileName(tmp);                                                                    \
        cliModule . setInternalName(internalName);                                                       \
        void* hCliDll = ::dlopen(info.dli_fname,  RTLD_LAZY|RTLD_LOCAL|RTLD_NOLOAD);                     \
        cliModule . setModuleHandle(hCliDll);                                                            \
        */                                                                                               \
       }

    #endif
#endif



}; // namespace cli



//                <Add option="-D&quot;MBS_PROJECT_NAME=MBS_STRINGIZE(c2idl)&quot;"/>

// http://voffka.com/archives/2004/01/06/002876.html
#endif /* CLI_CLIMOD_H */

