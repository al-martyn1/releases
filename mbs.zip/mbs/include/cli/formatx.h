#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_FORMATX_H
#define CLI_FORMATX_H

/*
#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif
*/

#ifndef __cplusplus
    #error "C++ compilation required for this header"
#endif

#ifndef CLI_FORMAT_H
    #include <cli/format.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifdef WIN32
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else /* __GNUC__ */
     #include <alloca.h>
     #ifndef _alloca
         #define _alloca  alloca
     #endif
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIME_H
    #include <cli/dateTime.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_ARGLIST_H
    #include <cli/arglist.h>
#endif


/*
#ifndef CLI_DATETIME_H
    #include <cli/dateTime.h>
#endif

#ifndef CLI_DATETIMEFORMAT_H
    #include <cli/dateTimeFormat.h>
#endif
*/


#ifdef _MSC_VER
    #if _NATIVE_WCHAR_T_DEFINED
    #else
        #define WCHAR_IS_TYPEDEF_TO_USHORT
    #endif
#else
    //#define WCHAR_IS_TYPEDEF_TO_USHORT
#endif



namespace cli
{

// class CDateTime;

namespace format
{

typedef ::cli::args::dump           dump;
typedef ::cli::args::ascii          ascii;
typedef ::cli::args::empty          empty;
typedef ::cli::args::extended_int   extended_int;
typedef ::cli::args::rational       rational;

typedef ::cli::arglist              arg;

//-----------------------------------------------------------------------------

// be sure that customFormat don't release arglist, so if ::cli::format::arg used there is memory leaks to be occurs
inline
::std::wstring customFormat( const ::std::wstring      &fmtName
                           , const ::std::wstring     &customFormatString
                           , INTERFACE_CLI_IARGLIST   *arglist
                           , SIZE_T                    argNo
                           )
   {
    if (fmtName.empty()) return ::std::wstring(L"<MISSING FORMATER NAME>");

    SIZE_T curSize = 1024; // enough for most cases
    WCHAR *pResultBuf = (WCHAR*)_alloca(curSize*sizeof(WCHAR));
    SIZE_T resultSize = 0;

    RCODE res = EC_OK;
    do {
        resultSize = curSize;
        res = cliCustomFormatStringEx( fmtName.c_str()
                                     , pResultBuf
                                     , &resultSize
                                     , customFormatString.c_str()
                                     , customFormatString.size()
                                     , arglist
                                     , argNo
                                     );
        if (res==EC_NOT_ENOUGH_MEM)
           {
            curSize <<=2;
            pResultBuf = (WCHAR*)_alloca(curSize*sizeof(WCHAR));
           }
        else if (res==EC_NO_SUCH_OBJECT)
           {
            return ::std::wstring(L"<FORMATER ")
                 + fmtName
                 + ::std::wstring(L" NOT FOUND>");
           }
       } while( res!=EC_OK );

    return ::std::wstring(pResultBuf, resultSize);
   }

inline
::std::wstring customFormat( const ::std::wstring     &fmtName
                           , const ::std::wstring     &customFormatString
                           , const arg                &a
                           , SIZE_T                    argNo
                           )
   {
    INTERFACE_CLI_IARGLIST* pArgList = a;
    ::std::wstring res = customFormat( fmtName, customFormatString, pArgList, argNo );
    pArgList->release();
    return res;
   }


// void operator() ( ::std::wstring &resStr, const ::std::wstring &formatString, INTERFACE_CLI_IARGLIST* arglist, SIZE_T argNo )
template <typename FormaterImpl>
SIZE_T
cliFormaterImplementationHelper( const FormaterImpl &fmtImpl
                               , WCHAR*    charBuf
                               , SIZE_T    charBufSize
                               , const WCHAR*    fmtStrChars
                               , SIZE_T    fmtStrCharsSize
                               , INTERFACE_CLI_IARGLIST*    arglist
                               , SIZE_T    argNo
                               )
   {
    ::std::wstring resStr;
    fmtImpl( resStr, (fmtStrChars ? ::std::wstring( fmtStrChars, fmtStrCharsSize ) : ::std::wstring() ), arglist, argNo );
    if (!charBuf)
       {
        return resStr.size();
       }

    SIZE_T numCharsToCopy = charBufSize-1;
    if (numCharsToCopy > (SIZE_T)resStr.size()) numCharsToCopy = (SIZE_T)resStr.size();

    resStr.copy(charBuf, numCharsToCopy, 0 );
    charBuf[numCharsToCopy] = 0;

    return numCharsToCopy;
   }

//-----------------------------------------------------------------------------
inline
::std::wstring messageEx( const ::std::wstring &fmt
                                 , const arg &args
                                 , DWORD flags /* FMF_* */
                                 , ::std::vector< INT > tabs
                                 )
   {
    CLIPSTR resStr = 0;
    cliFormatMessageEx( &resStr, fmt.c_str()
                      , (INTERFACE_CLI_IARGLIST*)args
                      , flags
                      , (tabs.empty() ? 0 : &tabs[0])
                      , tabs.size()
                      );
    ::std::wstring res;
    if (!resStr) return res;

    res.assign(clipstr_data(resStr), clipstr_size(resStr));
    clipstr_free(&resStr);
    return res;
   }

//-----------------------------------------------------------------------------
inline
::std::string messageEx( const ::std::string &fmt
                                 , const arg &args
                                 , DWORD flags /* FMF_* */
                                 , ::std::vector< INT > tabs
                                 )
   {
    return MARTY_CON::strToAnsi( messageEx( MARTY_CON::strToWide(fmt), args, flags, tabs ) );
   }

//-----------------------------------------------------------------------------
inline
::std::wstring messageEx( const ::std::wstring &fmt
                                 , const arg &args
                                 , DWORD flags /* FMF_* */
                                 )
   {
    CLIPSTR resStr = 0;
    cliFormatMessageEx( &resStr, fmt.c_str()
                      , (INTERFACE_CLI_IARGLIST*)args
                      , flags
                      , 0
                      , 0
                      );
    ::std::wstring res;
    if (!resStr) return res;

    res.assign(clipstr_data(resStr), clipstr_size(resStr));
    clipstr_free(&resStr);
    return res;
   }

//-----------------------------------------------------------------------------
inline
::std::string messageEx( const ::std::string &fmt
                                 , const arg &args
                                 , DWORD flags /* FMF_* */
                                 )
   {
    return MARTY_CON::strToAnsi( messageEx( MARTY_CON::strToWide(fmt), args, flags ) );
   }

//-----------------------------------------------------------------------------
inline
::std::wstring message( const ::std::wstring &fmt
                                 , const arg &args
                                 )
   {
    CLIPSTR resStr = 0;
    cliFormatMessage( &resStr, fmt.c_str()
                    , (INTERFACE_CLI_IARGLIST*)args
                    );
    ::std::wstring res;
    if (!resStr) return res;

    res.assign(clipstr_data(resStr), clipstr_size(resStr));
    clipstr_free(&resStr);
    return res;
   }

//-----------------------------------------------------------------------------
inline
::std::string message( const ::std::string &fmt
                                 , const arg &args
                                 )
   {
    return MARTY_CON::strToAnsi( message( MARTY_CON::strToWide(fmt), args ) );
   }

//-----------------------------------------------------------------------------
inline
::std::wstring message( const ::std::wstring &fmt )
   {
    CLIPSTR resStr = 0;
    cliFormatMessage( &resStr, fmt.c_str()
                    , (INTERFACE_CLI_IARGLIST*)0
                    );
    ::std::wstring res;
    if (!resStr) return res;

    res.assign(clipstr_data(resStr), clipstr_size(resStr));
    clipstr_free(&resStr);
    return res;
   }

//-----------------------------------------------------------------------------
inline
::std::string message( const ::std::string &fmt
                                 )
   {
    return MARTY_CON::strToAnsi( message( MARTY_CON::strToWide(fmt) ) );
   }

//-----------------------------------------------------------------------------
inline
::std::wstring resultCode( RCODE code )
   {
    switch(code&EC_SOURCE_MASK)
       {
        case EC_SOURCE_CLI:
                return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)code) );
        case EC_SOURCE_COM:
                return ::cli::format::message(L"0x%1!08X!, HRESULT: 0x%2!08X!", ::cli::format::arg((UINT)code) % (UINT)RC2HR(code) );
        case EC_SOURCE_WIN32:
                return ::cli::format::message(L"0x%1!08X!, Win32: %2", ::cli::format::arg((UINT)code) % (UINT)RC2WIN(code) );
        case EC_SOURCE_POSIX:
                //codeStr.append(::cli::format::message(L"0x%1!08X!, Posix/Crt: %2!d!", ::cli::format::arg((UINT)code) % RC2POSIX(code) ));
                return ::cli::format::message(L"0x%1!08X!, Posix/Crt: %2", ::cli::format::arg((UINT)code) % (INT)RC2POSIX(code) );
        case EC_SOURCE_GENERIC:
                return ::cli::format::message(L"0x%1!08X! (Generic)!", ::cli::format::arg((UINT)code) );

                
        default:
                return ::cli::format::message(L"0x%1!08X! (unknown source)", ::cli::format::arg((UINT)code) );
       }
   }

inline
::std::wstring resultOnlyCode( RCODE code )
   {
    switch(code&EC_SOURCE_MASK)
       {
        case EC_SOURCE_CLI:
                return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)code) );
        case EC_SOURCE_COM:
                return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)code) );
        case EC_SOURCE_WIN32:
                return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)code) );
        case EC_SOURCE_POSIX:
                //codeStr.append(::cli::format::message(L"0x%1!08X!, Posix/Crt: %2!d!", ::cli::format::arg((UINT)code) % RC2POSIX(code) ));
                return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)code) );
        default:
                return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)code) );
       }
   }

inline
::std::wstring resultCodeSource( RCODE code )
   {
    switch(code&EC_SOURCE_MASK)
       {
        case EC_SOURCE_CLI:   return ::std::wstring(L"CLI" );
        case EC_SOURCE_COM:   return ::std::wstring(L"HRESULT" );
        case EC_SOURCE_WIN32: return ::std::wstring(L"Win32" );
        case EC_SOURCE_POSIX: return ::std::wstring(L"Posix/Crt" );
        default:              return ::std::wstring(L"(unknown source)" );
       }
   }

inline
::std::wstring resultCodeNative( RCODE code )
   {
    switch(code&EC_SOURCE_MASK)
       {
        case EC_SOURCE_CLI:   return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)code) );
        case EC_SOURCE_COM:   return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)RC2HR(code)) );
        case EC_SOURCE_WIN32: return ::cli::format::message(L"%1", ::cli::format::arg((UINT)RC2WIN(code)) );
        case EC_SOURCE_POSIX: return ::cli::format::message(L"%1", ::cli::format::arg((UINT)RC2POSIX(code)) );
        default:              return ::cli::format::message(L"0x%1!08X!", ::cli::format::arg((UINT)code) );
       }
   }


//-----------------------------------------------------------------------------
namespace cli_log
{

inline
void messageEx( const ::std::wstring &fmt
                                 , const arg &args
                                 , DWORD flags /* FMF_* */
                                 )
   {
    cliWriteLogMessageEx( fmt.c_str(), (INTERFACE_CLI_IARGLIST*)args, flags, 0, 0 );
   }

inline
void messageEx( const ::std::string &fmt
                                 , const arg &args
                                 , DWORD flags /* FMF_* */
                                 )
   {
    cliWriteLogMessageEx( MARTY_CON::strToWide(fmt).c_str(), (INTERFACE_CLI_IARGLIST*)args, flags, 0, 0 );
   }



inline
void messageEx( const ::std::wstring &fmt
                                 , const arg &args
                                 , DWORD flags /* FMF_* */
                                 , ::std::vector< INT > tabs
                                 )
   {
    cliWriteLogMessageEx( fmt.c_str(), (INTERFACE_CLI_IARGLIST*)args, flags, (tabs.empty() ? 0 : &tabs[0]), tabs.size() );
   }

inline
void messageEx( const ::std::string &fmt
                                 , const arg &args
                                 , DWORD flags /* FMF_* */
                                 , ::std::vector< INT > tabs
                                 )
   {
    cliWriteLogMessageEx( MARTY_CON::strToWide(fmt).c_str(), (INTERFACE_CLI_IARGLIST*)args, flags, (tabs.empty() ? 0 : &tabs[0]), tabs.size() );
   }

inline
void message( const ::std::wstring &fmt
                                 , const arg &args
                                 )
   {
    cliWriteLogMessage( fmt.c_str(), (INTERFACE_CLI_IARGLIST*)args );
   }

inline
void message( const ::std::string &fmt
                                 , const arg &args
                                 )
   {
    cliWriteLogMessage( MARTY_CON::strToWide(fmt).c_str(), (INTERFACE_CLI_IARGLIST*)args );
   }

inline
void message( const ::std::wstring &fmt )
   {
    cliWriteLogMessage( fmt.c_str(), (INTERFACE_CLI_IARGLIST*)0 );
   }

inline
void message( const ::std::string &fmt )
   {
    cliWriteLogMessage( MARTY_CON::strToWide(fmt).c_str(), (INTERFACE_CLI_IARGLIST*)0 );
   }

}; // namespace cli_log
}; // namespace format
}; // namespace cli


// ::cli::format::cli_log::message

#endif /* CLI_FORMATX_H */
