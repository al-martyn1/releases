#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLIUTILX_H
#define CLI_CLIUTILX_H

/*
#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif
*/

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_INC_STDDEF) && !defined(_STDDEF_H_) && !defined(_STDDEF_H)
    #include <stddef.h>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef MARTY_CASECONV_H
    #include <marty/caseconv.h>
#endif


/*
template<class ForwardIterator, class Type>
   bool binary_search(
      ForwardIterator _First,
      ForwardIterator _Last,
      const Type& _Val
   );
template<class ForwardIterator, class Type, class BinaryPredicate>
   bool binary_search(
      ForwardIterator _First,
      ForwardIterator _Last,
      const Type& _Val,
      BinaryPredicate _Comp
   );

template<class ForwardIterator, class Type>
   ForwardIterator lower_bound(
      ForwardIterator _First,
      ForwardIterator _Last,
      const Type& _Val
   );
template<class ForwardIterator, class Type, class BinaryPredicate>
   ForwardIterator lower_bound(
      ForwardIterator _First,
      ForwardIterator _Last,
      const Type& _Val,
      BinaryPredicate _Comp
   );

template<class Type>
   struct less : public binary_function <Type, Type, bool>
   {
      bool operator()(
         const Type& _Left,
         const Type& _Right
      ) const;
   };

*/

// ::cli::util::

namespace cli
{
namespace util
{


inline void copyStr2buf(const WCHAR* src, WCHAR* dst, SIZE_T dstSize, SIZE_T *nCharsCopied=0 /* including zero */ )
  {

   if (src && dstSize)
      {
       SIZE_T nCharsToCopy = wcslen(src);
       if ((dstSize-1)<nCharsToCopy) nCharsToCopy = dstSize-1;
       wcsncpy(dst, src, nCharsToCopy );
       dst[nCharsToCopy] = 0;
       if (nCharsCopied) *nCharsCopied = nCharsToCopy+1;
      }
   else
      {
       dst[0] = 0;
       if (nCharsCopied) *nCharsCopied = 1;
      }
  }

inline void copyStr2buf(const std::wstring &src, WCHAR* dst, SIZE_T dstSize, SIZE_T *nCharsCopied=0 /* including zero */  )
  {
   SIZE_T nCharsToCopy = src.size();
   if ((dstSize-1)<nCharsToCopy) nCharsToCopy = dstSize-1;
   src.copy( dst, nCharsToCopy, 0 );
   dst[nCharsToCopy] = 0;
   if (nCharsCopied) *nCharsCopied = nCharsToCopy+1;
  }


//-----------------------------------------------------------------------------
template<class ForwardIterator, class Type>
ForwardIterator binary_find( ForwardIterator _First
                           , ForwardIterator _Last
                           , const Type& _Val
                           )
   {
    _First = std::lower_bound(_First, _Last, _Val);
    return _First == _Last ? _Last : (       _Val < *_First   ? _Last : _First);
   }

//-----------------------------------------------------------------------------
template<class ForwardIterator, class Type, class BinaryPredicate>
ForwardIterator binary_find( ForwardIterator _First
                           , ForwardIterator _Last
                           , const Type& _Val
                           , BinaryPredicate _Comp
                           )
   {
    _First = std::lower_bound(_First, _Last, _Val, _Comp);
    return _First == _Last ? _Last : ( _Comp(_Val , *_First)  ? _Last : _First);
   }

//-----------------------------------------------------------------------------
template < typename CharType
         , CharType C
         >
struct CIsExactChar
{
    bool operator()(CharType c) const
       { return c==C; }
};

//-----------------------------------------------------------------------------
template < typename CharType >
struct CIsExactCharVar
{
    CharType C;
    CIsExactCharVar(CharType _C) : C(_C) {}
    bool operator()(CharType c) const
       { return c==C; }
};

template < typename CharType, typename Traits=::std::char_traits<CharType>, typename Allocator=::std::allocator<CharType> >
struct CIsCharOneOf
{
    ::std::basic_string<CharType, Traits, Allocator> charsSet;
    CIsCharOneOf( const ::std::basic_string<CharType, Traits, Allocator> &cs) : charsSet(cs) {}
    bool operator()(CharType c) const
       {
        return charsSet.find( c, 0 )!=charsSet.npos;
       }
};


/*
template < char C
         >
struct CIsExactChar<char, C>
{
    bool operator()(char c) const
       { return c==C; }
};
*/
/*
template<char C>
struct CIsExactChar
{
    bool operator()(char c) const
       { return c==C; }
};

template<wchar_t C>
struct CIsExactChar
{
    bool operator()(wchar_t c) const
       { return c==C; }
};
*/

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename PredSepType
        , typename StringHandlerType
        >
void splitString( const ::std::basic_string<CharType, Traits, Allocator> &str
                , PredSepType predSep
                , StringHandlerType stringHandler
                )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator>   string;
    typedef typename string::const_iterator const_iterator;
    const_iterator it = str.begin();
    const_iterator prev = it;

    while(it!=str.end())
       {
        if (predSep(*it)) // found sep
           {
            stringHandler(string(prev, it));
            prev = ++it;
            continue;
           }
        ++it;
       }

    if (it!=prev) stringHandler(string(prev, it));

   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
struct CVectorCollector
{
    ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &v;
    CVectorCollector( const CVectorCollector &c) : v(c.v) {}
    CVectorCollector( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &_v
                    ) : v(_v) {}
    void operator()( const ::std::basic_string<CharType, Traits, Allocator> &str )
       {
        v.push_back(str);
       }
};

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename PredSepType
        >
void splitString( const ::std::basic_string<CharType, Traits, Allocator> &str
                , ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &strings
                , PredSepType predSep
                )
   {
    CVectorCollector<CharType, Traits, Allocator> collector(strings);
    splitString(str, predSep, collector);
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename predSepType
        , typename predPairSepType
        , typename PairHandlerType
        >
void splitStringToMap( const ::std::basic_string<CharType, Traits, Allocator> &str
                     , predSepType predSep
                     , predPairSepType predPairSep
                     , PairHandlerType PairHandler
                     )
   {
    typedef typename ::std::basic_string<CharType, Traits, Allocator>::const_iterator const_iterator;
    const_iterator it = str.begin();
    const_iterator keyBegin = it;
    const_iterator keyEnd   = it;
    const_iterator valBegin = it;
    const_iterator valEnd   = it;
    for(; it!=str.end();  /* ++it */ )
       {
        while(it!=str.end() && !predSep(*it) && !predPairSep(*it)) ++it;
        if (it==str.end()) { valEnd = it; continue; }

        if (predPairSep(*it))
           { // found key:value separator
            keyEnd   = it;
            ++it;
            valBegin = valEnd = it;
            if (it==str.end()) continue;
           }
        else if(predSep(*it))
           { // found end of pair separator
            valEnd = it;
            //m[ ::std::basic_string<CharType, Traits, Allocator>(keyBegin, keyEnd) ] = ::std::basic_string<CharType, Traits, Allocator>(valBegin, valEnd);
            PairHandler( ::std::basic_string<CharType, Traits, Allocator>(keyBegin, keyEnd)
                       , ::std::basic_string<CharType, Traits, Allocator>(valBegin, valEnd)
                       );
            ++it;
            keyBegin = it;
            keyEnd   = it;
            valBegin = it;
            valEnd   = it;
           }
       }
    if (keyBegin!=keyEnd || valBegin!=valEnd)
       {
        //m[ ::std::basic_string<CharType, Traits, Allocator>(keyBegin, keyEnd) ] = ::std::basic_string<CharType, Traits, Allocator>(valBegin, valEnd);
        PairHandler( ::std::basic_string<CharType, Traits, Allocator>(keyBegin, keyEnd)
                   , ::std::basic_string<CharType, Traits, Allocator>(valBegin, valEnd)
                   );
       }
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
struct CMapCollector
{
    ::std::map< ::std::basic_string<CharType, Traits, Allocator>
              , ::std::basic_string<CharType, Traits, Allocator>
              > &m;
    CMapCollector( const CMapCollector &c) : m(c.m) {}
    CMapCollector(
                  ::std::map< ::std::basic_string<CharType, Traits, Allocator>
                            , ::std::basic_string<CharType, Traits, Allocator>
                            > &_m
                 ) : m(_m) {}
    void operator()( const ::std::basic_string<CharType, Traits, Allocator> &key
                   , const ::std::basic_string<CharType, Traits, Allocator> &val
                   )
       {
        if (key.empty() && val.empty()) return;
        m[key] = val;
       }
};

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename predSepType
        , typename predPairSepType
        >
void splitStringToMap( ::std::map< ::std::basic_string<CharType, Traits, Allocator>
                                 , ::std::basic_string<CharType, Traits, Allocator>
                                 > &m
                     , const ::std::basic_string<CharType, Traits, Allocator> &str
                     , predSepType predSep
                     , predPairSepType predPairSep
                     )
   {
    CMapCollector<CharType, Traits, Allocator> collector(m);
    splitStringToMap(str, predSep, predPairSep, collector);
   }

//-----------------------------------------------------------------------------
template< typename CharType >
struct CIsSpace
{
    bool operator()(const CharType ch) const
       {
        if ( ch==(CharType)' '
           ||ch==(CharType)'\r'
           ||ch==(CharType)'\n'
           ||ch==(CharType)'\t'
           ) return true;
        return false;
       }
};

template< typename CharType >
struct CIsLinefeed
{
    bool operator()(const CharType ch) const
       {
        if ( ch==(CharType)'\n'
           ) return true;
        return false;
       }
};

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
void ltrim(::std::basic_string<CharType, Traits, Allocator> &str, const IsSpacePred &pred)
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string;
    typedef typename string::size_type                       size_type;
    size_type pos = 0, size = str.size();
    for(; pos!=size && pred(str[pos]); ++pos) {}
    str.erase(0, pos);
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
void rtrim(::std::basic_string<CharType, Traits, Allocator> &str, const IsSpacePred &pred)
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string;
    typedef typename string::size_type                       size_type;
    size_type pos = str.size();
    for(; pos && pred(str[pos-1]); --pos) {}
    str.erase(pos, str.size()-pos);
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
void trim(::std::basic_string<CharType, Traits, Allocator> &str, const IsSpacePred &pred)
   {
    ltrim(str, pred);
    rtrim(str, pred);
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
void ltrim( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &lines, const IsSpacePred &pred)
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string;
    typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::iterator lit = lines.begin();
    for(; lit!=lines.end(); ++lit)
       ::cli::util::ltrim( *lit, pred );
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
void rtrim( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &lines, const IsSpacePred &pred)
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string;
    typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::iterator lit = lines.begin();
    for(; lit!=lines.end(); ++lit)
       ::cli::util::rtrim( *lit, pred );
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
void trim( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &lines, const IsSpacePred &pred)
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string;
    typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::iterator lit = lines.begin();
    for(; lit!=lines.end(); ++lit)
       ::cli::util::trim( *lit, pred );
   }



//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
::std::basic_string<CharType, Traits, Allocator>
ltrim_copy(const ::std::basic_string<CharType, Traits, Allocator> &str, const IsSpacePred &pred)
   {
    ::std::basic_string<CharType, Traits, Allocator> res = str;
    ltrim(res, pred);
    return res;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
::std::basic_string<CharType, Traits, Allocator>
rtrim_copy(const ::std::basic_string<CharType, Traits, Allocator> &str, const IsSpacePred &pred)
   {
    ::std::basic_string<CharType, Traits, Allocator> res = str;
    rtrim(res, pred);
    return res;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpacePred
        >
::std::basic_string<CharType, Traits, Allocator>
trim_copy(const ::std::basic_string<CharType, Traits, Allocator> &str, const IsSpacePred &pred)
   {
    ::std::basic_string<CharType, Traits, Allocator> res = str;
    ltrim(res, pred);
    rtrim(res, pred);
    return res;
   }



//-----------------------------------------------------------------------------
template <typename CharType>
CharType plainToUpperCase( CharType ch )
   {
    if (ch>=(CharType)'a' && ch<=(CharType)'z') return ch - (CharType)'a' + (CharType)'A';
    return ch;
   }

template <typename CharType>
CharType plainToLowerCase( CharType ch )
   {
    if (ch>=(CharType)'A' && ch<=(CharType)'Z') return ch - (CharType)'A' + (CharType)'a';
    return ch;
   }

template <typename CharType, typename Traits, typename Allocator>
void plainToUpperCase( ::std::basic_string<CharType, Traits, Allocator> &str )
   {
    typename ::std::basic_string< CharType, Traits, Allocator>::iterator it = str.begin(), end = str.end();
    for( ; it != end; ++it )
       {
        *it = plainToUpperCase(*it);
       }
   }

template <typename CharType, typename Traits, typename Allocator>
void plainToLowerCase( ::std::basic_string<CharType, Traits, Allocator> &str )
   {
    typename ::std::basic_string< CharType, Traits, Allocator>::iterator it = str.begin(), end = str.end();
    for( ; it != end; ++it )
       {
        *it = plainToLowerCase(*it);
       }
   }

template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator> plainToUpperCaseCopy( const ::std::basic_string<CharType, Traits, Allocator> &_str )
   {
    ::std::basic_string<CharType, Traits, Allocator> str = _str;
    plainToUpperCase(str); return str;
   }

template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator> plainToLowerCaseCopy( const ::std::basic_string<CharType, Traits, Allocator> &_str )
   {
    ::std::basic_string<CharType, Traits, Allocator> str = _str;
    plainToLowerCase(str); return str;
   }
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
template < typename ValType >
void plainToUpperCase( std::vector< ValType > &vec )
{
    std::vector< ValType >::iterator vit = vec.begin();
    for(; vit != vec.end(); ++vit)
       {
        plainToUpperCase(*vit);
       }
}
//-----------------------------------------------------------------------------
template < typename ValType >
void plainToLowerCase( std::vector< ValType > &vec )
{
    std::vector< ValType >::iterator vit = vec.begin();
    for(; vit != vec.end(); ++vit)
       {
        plainToLowerCase(*vit);
       }
}
//-----------------------------------------------------------------------------






//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
bool
startsWith( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
          , const ::std::basic_string<CharType, Traits, Allocator> &strStartsWith )
   {
    if (!strCompareTo.compare(0, strStartsWith.size(), strStartsWith, 0, strStartsWith.size()))
       return true;
    return false;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
bool
startsWith( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
          , const CharType *strStartsWith )
   {
    return startsWith( strCompareTo, ::std::basic_string<CharType, Traits, Allocator>(strStartsWith) );
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
bool
startsWithI( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
           , const ::std::basic_string<CharType, Traits, Allocator> &strStartsWith )
   {
    return startsWith( MARTY_FILENAME_NS utils::lowerCase(strCompareTo , MARTY_FILENAME_NS utils::makeUserLocale())
                     , MARTY_FILENAME_NS utils::lowerCase(strStartsWith, MARTY_FILENAME_NS utils::makeUserLocale())
                     );
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
bool
startsWithI( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
          , const CharType *strStartsWith )
   {
    return startsWithI( strCompareTo, ::std::basic_string<CharType, Traits, Allocator>(strStartsWith) );
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
bool
endsWith( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
        , const ::std::basic_string<CharType, Traits, Allocator> &strEndsWith )
   {
    if (strCompareTo.size()<strEndsWith.size()) return false;
    if (!strCompareTo.compare( strCompareTo.size()-strEndsWith.size() // offset in strCompareTo
                             , strEndsWith.size()                     // len of campared part
                             , strEndsWith                            // string compare with
                             , 0                                      // offset in strEndsWith
                             , strEndsWith.size()                     // The maximum number of characters from the strEndsWith to be compared
                             ))
       return true;
    return false;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
bool
endsWithI( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
           , const ::std::basic_string<CharType, Traits, Allocator> &strEndsWith )
   {
    return endsWith( MARTY_FILENAME_NS utils::lowerCase(strCompareTo , MARTY_FILENAME_NS utils::makeUserLocale())
                   , MARTY_FILENAME_NS utils::lowerCase(strEndsWith, MARTY_FILENAME_NS utils::makeUserLocale())
                   );
   }

template< typename CharType, typename Traits, typename Allocator >
bool splitToPairHelper( const ::std::basic_string<CharType, Traits, Allocator> &str
                , const ::std::basic_string<CharType, Traits, Allocator> &splitter
                , ::std::basic_string<CharType, Traits, Allocator> &first
                , ::std::basic_string<CharType, Traits, Allocator> &second
                )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    typename string_type::size_type pos = str.find( splitter, 0 );
    if (pos==str.npos)
       {
        return false;
       }
    second.assign(str, pos+splitter.size(), str.npos );
    first .assign(str, 0, pos);
    return true;
   }

template< typename CharType, typename Traits, typename Allocator >
bool splitToPair( const ::std::basic_string<CharType, Traits, Allocator> &str
                , const ::std::basic_string<CharType, Traits, Allocator> &splitter
                , ::std::basic_string<CharType, Traits, Allocator> &first
                , ::std::basic_string<CharType, Traits, Allocator> &second
                )
   {
    if (!splitToPairHelper(str,splitter,first,second))
       {
        first.assign(str);
        return false;
       }
    return true;
   }

template< typename CharType, typename Traits, typename Allocator >
bool splitToPair( const ::std::basic_string<CharType, Traits, Allocator> &str
              , const ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &splitters
              , ::std::basic_string<CharType, Traits, Allocator> &first
              , ::std::basic_string<CharType, Traits, Allocator> &second
              )
   {
    typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::const_iterator it = splitters.begin();
    for(; it!=splitters.end(); ++it)
       {
        if (splitToPairHelper( str, *it, first, second)) return true;
       }
    first.assign(str);
    return false;
   }


inline
bool str2Int( const WCHAR *pstr, INT64 &i )
   {
    if (!pstr) return false;
    WCHAR *endPtr = const_cast<WCHAR*>(pstr);
    #if defined(_WIN32)
        #if defined(__GNUC__)
        i = wcstoll(pstr, &endPtr, 0);
        #else
        // msvc, borland, intel or other msvc compatible
        i = _wcstoi64( pstr, &endPtr, 0 );
        #endif
    #else
       #if defined __USE_GNU
       i = wcstoll(pstr, &endPtr, 0);
       #else
       i = wcstol(pstr, &endPtr, 0); // long ints strints truncated
       #endif
    #endif
    if (*endPtr!=0) return false;
    return true;
   }

inline
bool str2Int( const WCHAR *pstr, UINT64 &i)
   {
    if (!pstr) return false;
    WCHAR *endPtr = const_cast<WCHAR*>(pstr);
    #if defined(_WIN32)
        #if defined(__GNUC__)
        i = wcstoull(pstr, &endPtr, 0);
        #else
        // msvc, borland, intel or other msvc compatible
        i = _wcstoui64( pstr, &endPtr, 0 );
        #endif
    #else
       #if defined __USE_GNU
       i = wcstoull(pstr, &endPtr, 0);
       #else
       i = wcstoul(pstr, &endPtr, 0); // long ints strints truncated
       #endif
    #endif
    if (*endPtr!=0) return false;
    return true;
   }

inline
bool str2Int( const CHAR *pstr, INT64 &i )
   {
    if (!pstr) return false;
    CHAR *endPtr = const_cast<CHAR*>(pstr);
    #if defined(_WIN32)
        #if defined(__GNUC__)
        i = strtoll(pstr, &endPtr, 0);
        #else
        // msvc, borland, intel or other msvc compatible
        i = _strtoi64( pstr, &endPtr, 0 );
        #endif
    #else
       #if defined __USE_GNU
       i = strtoll(pstr, &endPtr, 0);
       #else
       i = strtol(pstr, &endPtr, 0); // long ints strints truncated
       #endif
    #endif
    if (*endPtr!=0) return false;
    return true;
   }

inline
bool str2Int( const CHAR *pstr, UINT64 &i )
   {
    if (!pstr) return false;
    CHAR *endPtr = const_cast<CHAR*>(pstr);
    #if defined(_WIN32)
        #if defined(__GNUC__)
        i = strtoull(pstr, &endPtr, 0);
        #else
        // msvc, borland, intel or other msvc compatible
        i = _strtoui64( pstr, &endPtr, 0 );
        #endif
    #else
       #if defined __USE_GNU
       i = strtoull(pstr, &endPtr, 0);
       #else
       i = strtoul(pstr, &endPtr, 0); // long ints strints truncated
       #endif
    #endif
    if (*endPtr!=0) return false;
    return true;
   }


inline bool str2Int( const ::std::wstring &str, INT64 &i )
    { if (str.empty()) return false; return str2Int(str.c_str(), i);  }

inline bool str2Int( const ::std::wstring &str, UINT64 &i )
    { if (str.empty()) return false; return str2Int(str.c_str(), i); }

inline bool str2Int( const ::std::string &str, INT64 &i )
    { if (str.empty()) return false; return str2Int(str.c_str(), i);  }

inline bool str2Int( const ::std::string &str, UINT64 &i )
    { if (str.empty()) return false; return str2Int(str.c_str(), i); }



// 0xFFFFFFFFFFFFFFFFull -   18446744073709551615ull
//                           -9223372036854775808ull
// 20 ��������

const size_t int64StringBufSize = 32;

template <typename CharType>
bool int2StrAux2( UINT64 i, CharType *buf, size_t bufSize, unsigned int radix, const CharType *digits )
   {
    if (radix<2 || radix>36) return false;
    size_t pos = 0;
    for(; i>0 && pos!=(bufSize-1); ++pos )
       {
        buf[pos] = digits[i%radix];
        i /= radix;
       }
    if (!pos) buf[pos++] = digits[0];
    buf[pos] = 0;
    ::std::reverse( buf, buf+pos);
    if (i>0) return false; // buffer overflow
    return true;
   }

inline
bool int2StrAux( UINT64 i, char *buf, size_t bufSize, unsigned int radix )
   {
    return int2StrAux2( i, buf, bufSize, radix, "01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ" );
   }

inline
bool int2StrAux( UINT64 i, wchar_t *buf, size_t bufSize, unsigned int radix )
   {
    return int2StrAux2( i, buf, bufSize, radix, L"01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ" );
   }

inline
bool int2Str( INT64 i, ::std::string &str, unsigned int radix )
   {
    char buf[int64StringBufSize];
    size_t bufSize = int64StringBufSize, pos = 0;
    if (i<0 && radix==10) { buf[pos++] = '-'; --bufSize; i = -i; }
    if (!int2StrAux( (UINT64)i, &buf[pos], bufSize, radix )) return false;
    str.assign(buf);
    return true;
   }

inline
bool int2Str( UINT64 i, ::std::string &str, unsigned int radix )
   {
    char buf[int64StringBufSize];
    if (!int2StrAux( i, &buf[0], int64StringBufSize, radix )) return false;
    str.assign(buf);
    return true;
   }

inline
bool int2Str( INT64 i, ::std::wstring &str, unsigned int radix )
   {
    wchar_t buf[int64StringBufSize];
    size_t bufSize = int64StringBufSize, pos = 0;
    if (i<0 && radix==10) { buf[pos++] = L'-'; --bufSize; i = -i; } // use sign
    if (!int2StrAux( (UINT64)i, &buf[pos], bufSize, radix )) return false;
    str.assign(buf);
    return true;
   }

inline
bool int2Str( UINT64 i, ::std::wstring &str, unsigned int radix )
   {
    wchar_t buf[int64StringBufSize];
    if (!int2StrAux( i, &buf[0], int64StringBufSize, radix )) return false;
    str.assign(buf);
    return true;
   }


#if defined(UNICODE) || defined(_UNICODE)
inline ::std::wstring smpInt2Str( INT64 i, unsigned int radix = 10)
   {
    ::std::wstring res;
    if (int2Str(i, res, radix)) return res;
    else return L"0";
   }
inline ::std::wstring smpInt2Str( UINT64 i, unsigned int radix = 10 )
   {
    ::std::wstring res;
    if (int2Str(i, res, radix)) return res;
    else return L"0";
   }
#else
inline ::std::string smpInt2Str( INT64 i, unsigned int radix = 10)
   {
    ::std::string res;
    if (int2Str(i, res, radix)) return res;
    else return "0";
   }
inline ::std::string smpInt2Str( UINT64 i, unsigned int radix = 10 )
   {
    ::std::string res;
    if (int2Str(i, res, radix)) return res;
    else return "0";
   }
#endif



template <typename TLineHandler>
struct CLineReader
{
    ::std::string      buf;
    TLineHandler       handler;

    CLineReader(const TLineHandler &h) : buf(), handler(h) {}
    CLineReader(const CLineReader &lr) : buf(), handler(lr.handler) {}

    void operator()(char ch)
       {
        if (ch=='\r') return;
        if (ch=='\n')
           {
            handler(buf);
            buf.clear();
            return;
           }
        buf.append(1, ch);
       }

    void operator()(const char *pData, unsigned nBytes)
       {
        for(unsigned i=0; i<nBytes; ++i, ++pData)
           operator()(*pData);
       }

}; // struct CLineReader


template< typename CharType
        , typename Traits
        , typename Allocator
        >
bool splitConfigLine(const ::std::basic_string<CharType, Traits, Allocator> &str, ::std::basic_string<CharType, Traits, Allocator> &name, ::std::basic_string<CharType, Traits, Allocator> &val)
   {
    ::std::basic_string<CharType, Traits, Allocator> tmp = trim_copy<CharType, Traits, Allocator, CIsSpace<CharType> >(str, CIsSpace<CharType>());
    if (tmp.empty()) return false;
    if (tmp[0]==(CharType)'#') return false;
    //::std::string::const_iterator it =
    typename ::std::basic_string<CharType, Traits, Allocator>::size_type pos = tmp.find((CharType)'=');
    if (pos==::std::basic_string<CharType, Traits, Allocator>::npos)
       {
        name = tmp;
       }
    else
       {
        name = ::std::basic_string<CharType, Traits, Allocator>(tmp, 0, pos);
        val  = ::std::basic_string<CharType, Traits, Allocator>(tmp, pos+1, ::std::basic_string<CharType, Traits, Allocator>::npos);
       }
    return true;
   }


//::std::basic_string<CharType, Traits, Allocator>


template< typename Key
        //, typename Val
        , typename KeyCmp
        >
class CIdMap
{
    public:
        typedef size_t                                   size_type;
        typedef ::std::map<Key, size_type, KeyCmp>       container_type;
        //typedef typename container_type::size_type       size_type;
        typedef ::std::map<size_type, Key>               secondary_container_type;

        //static const size_type npos = reinterpret_cast<size_type>(-1);
        static const size_type npos = (size_type)(-1);

    protected:
        container_type                key2val;
        secondary_container_type      val2key;

    public:

        CIdMap()
           : key2val()
           , val2key()
           {}

        CIdMap(const CIdMap &m)
           : key2val(m.key2val)
           , val2key(m.val2key)
           {}

        CIdMap& operator=(const CIdMap &m)
           {
            if (&m==this) return *this;
            container_type             tmp1(m.key2val);
            secondary_container_type   tmp2(m.val2key);
            tmp1.swap(key2val);
            tmp2.swap(val2key);
            return *this;
           }

        bool put(const Key& k)
           {
            if (key2val.find(k)!=key2val.end()) return false; // allready exist
            size_type id = (size_type)key2val.size();
            key2val[k]  = id;
            val2key[id] = k;
            return true;
           }

        size_type getId(const Key& k)
           {
            typename container_type::const_iterator it = key2val.find(k);
            if (it!=key2val.end()) return it->second;
            size_type id = (size_type)key2val.size();
            key2val[k]  = id;
            val2key[id] = k;
            return id;
           }

        bool getKey(const size_type& id, Key& k)
           {
            typename secondary_container_type::const_iterator it = val2key.find(id);
            if (it==val2key.end()) return false;
            k = it->second;
            return true;
           }

        Key getKey(const size_type& id)
           {
            Key k;
            if (!getKey(id, k)) throw ::std::out_of_range("id out of range - requested key of non-existen id");
            return k;
           }

};


//template <typename IFWrapper>


template< typename Type, typename Compare = ::std::less<Type>, typename Allocator = ::std::allocator<Type> >
class CAutoSortVector
{

public:

    //typedef ::std::vector< typename Type, typename Allocator >   storage_type;
    typedef ::std::vector< Type, Allocator >   storage_type;

protected:

    storage_type     storage;

public:

    typedef typename storage_type::allocator_type            allocator_type;
    typedef typename storage_type::const_iterator            const_iterator;
    typedef typename storage_type::const_pointer             const_pointer;
    typedef typename storage_type::const_reference           const_reference;
    typedef typename storage_type::const_reverse_iterator    const_reverse_iterator;
    typedef typename storage_type::difference_type           difference_type;
    typedef typename storage_type::iterator                  iterator;
    typedef typename storage_type::pointer                   pointer;
    typedef typename storage_type::reference                 reference;
    typedef typename storage_type::reverse_iterator          reverse_iterator;
    typedef typename storage_type::size_type                 size_type;
    typedef typename storage_type::value_type                value_type;

    void sort()
       {
        if (storage.empty()) return;
        ::std::sort( storage.begin(), storage.end(), Compare() );
       }

    CAutoSortVector() : storage() {}
    explicit CAutoSortVector( const Allocator& Al ) : storage( Al ) {}
    explicit CAutoSortVector( size_type Count ) : storage( Count ) {}
    CAutoSortVector( size_type Count, const Type& Val ) : storage( Count, Val ) {}
    CAutoSortVector( size_type Count, const Type& Val, const Allocator& Al ) : storage( Count, Val, Al ) {}

    // assume that Right is sorted
    CAutoSortVector( const CAutoSortVector& Right ) : storage( Right.storage ) {}
    CAutoSortVector( const storage_type& Right ) : storage( Right.storage ) { sort(); }

    template<class InputIterator>
    CAutoSortVector( InputIterator First, InputIterator Last ) : storage()
       {
        for(; First!=Last; ++First) storage.push_back(*First);
        sort();
       }

    template<class InputIterator>
    CAutoSortVector( InputIterator First, InputIterator Last, const Allocator& Al ) : storage( Al )
       {
        for(; First!=Last; ++First) storage.push_back(*First);
        sort();
       }

    void assign( size_type Count, const Type& Val ) { storage.assign( Count, Val ); }

    template<class InputIterator>
    void assign( InputIterator First, InputIterator Last )
       {
        storage.clear();
        for(; First!=Last; ++First) storage.push_back(*First);
        sort();
       }

    reference at( size_type Pos ) { return storage.at(Pos); }
    const_reference at( size_type Pos ) const { return storage.at(Pos); }

    // back Returns a reference to the last element of the vector.

    const_iterator begin( ) const { return storage.begin(); }
    iterator begin( ) { return storage.begin(); }

    size_type capacity( ) const { return storage.capacity(); }
    void clear( ) { storage.clear(); }
    bool empty( ) const { return storage.empty(); }

    iterator end( ) { return storage.end(); }
    const_iterator end( ) const { return storage.end(); }

    iterator erase( iterator Where )
       {
        return storage.erase(Where); // order not changed
       }

    iterator erase( iterator First, iterator Last )
       {
        return storage.erase(First, Last); // order not changed
       }

    // front Returns a reference to the first element in a vector.

    // get_allocator Returns an object to the allocator class used by a vector.

    iterator insert( iterator Where, const Type& Val )
       {
        storage.insert( Where, Val );
        sort();
       }

    void insert( iterator Where, size_type Count, const Type& Val )
       {
        storage.insert( Where, Count, Val );
        sort();
       }

    template<class InputIterator>
    void insert( iterator Where, InputIterator First, InputIterator Last )
       {
        storage.insert( Where, First, Last );
        sort();
       }

    size_type max_size( ) const { return storage.max_size(); }
    void pop_back( ) { return storage.pop_back(); }
    void push_back( const Type& Val ) { storage.push_back(Val); sort(); }
    void unsorted_push_back( const Type& Val ) { storage.push_back(Val); }

    reverse_iterator rbegin( ) { return storage.rbegin(); }
    const_reverse_iterator rbegin( ) const { return storage.rbegin(); }

    reverse_iterator rend( ) { return storage.rbegin(); }
    const_reverse_iterator rend( ) const { return storage.rend(); }

    void resize( size_type Newsize ) { storage.resize(Newsize); sort(); }
    void resize( size_type Newsize, Type Val ) { storage.resize(Newsize,Val); sort(); }

    void reserve( size_type Count ) { storage.reserve(Count); }
    size_type size( ) const { return storage.size(); }

    void swap( CAutoSortVector & Right ) { storage.swap(Right.storage); }
    void swap( storage_type & Right ) { storage.swap(Right); sort(); }

//    friend void swap( CAutoSortVector& Left, CAutoSortVector& Right );

    // additional member

    const_iterator find( const Type& Val ) const
       {
        return binary_find( storage.begin(), storage.end(), Val, Compare() );
       }

    iterator find( const Type& Val )
       {
        return binary_find( storage.begin(), storage.end(), Val, Compare() );
       }

    reference operator[]( size_type _Pos )
       {
        return storage.operator[]( _Pos );
       }

    const_reference operator[]( size_type _Pos ) const
       {
        return storage.operator[]( _Pos );
       }

}; // class CAutoSortVector

//inline
template< typename Type, typename Compare, typename Allocator >
void swap( CAutoSortVector< Type, Compare, Allocator >& Left, CAutoSortVector< Type, Compare, Allocator >& Right )
   {
    Left.swap(Right);
   }


template<class Type>
struct pair_first_less : public ::std::binary_function <Type, Type, bool>
{
  bool operator()(
     const Type& _Left,
     const Type& _Right
  ) const
  {
   return _Left.first < _Right.first;
  }

}; // pair_first_less


/*
template< typename Type, typename Compare = ::std::less<Type>, typename Allocator = ::std::allocator<Type> >
class CAutoSortVector
{
*/


template < typename T1
         , typename T2
         >
struct CKeyTuple
{
    T1 t1;
    T2 t2;
    CKeyTuple() :t1(), t2() {}
    CKeyTuple(const T1 &_t1, const T2 &_t2) :t1(_t1), t2(_t2) {}

    bool operator<( const CKeyTuple &k )
      {
       if (t1<k.t1) return true;
       if (t1>k.t1) return false;
       // t1 are equal
       if (t2<k.t2) return true;
       return false;
      }

    bool operator>( const CKeyTuple &k )
      {
       if (t1>k.t1) return true;
       if (t1<k.t1) return false;
       // t1 are equal
       if (t2>k.t2) return true;
       return false;
      }

    bool operator==( const CKeyTuple &k )
      {
       return t1==k.t1 && t2==k.t2;
      }

    bool operator!=( const CKeyTuple &k )
      {
       return t1!=k.t1 || t2!=k.t2;
      }

}; // CKeyTuple


template < typename T1
         , typename T2
         , typename T3
         >
struct CKeyTriple
{
    T1 t1;
    T2 t2;
    T3 t3;
    CKeyTriple() :t1(), t2(), t3() {}
    CKeyTriple(const T1 &_t1, const T2 &_t2, const T3 &_t3) :t1(_t1), t2(_t2), t3(_t3) {}

    bool operator<( const CKeyTriple &k )
      {
       if (t1<k.t1) return true;
       if (t1>k.t1) return false;
       // t1 are equal
       if (t2<k.t2) return true;
       if (t2>k.t2) return false;
       // t2 are equal
       if (t3<k.t3) return true;
       return false;
      }

    bool operator>( const CKeyTriple &k )
      {
       if (t1>k.t1) return true;
       if (t1<k.t1) return false;
       // t1 are equal
       if (t2>k.t2) return true;
       if (t2<k.t2) return false;
       // t2 are equal
       if (t3>k.t3) return true;
       return false;
      }

    bool operator==( const CKeyTriple &k )
      {
       return t1==k.t1 && t2==k.t2 && t3==k.t3;
      }

    bool operator!=( const CKeyTriple &k )
      {
       return t1!=k.t1 || t2!=k.t2 || t3!=k.t3;
      }

}; // CKeyTriple

template < typename T1
         , typename T2
         , typename T3
         , typename T4
         >
struct CKeyQuad
{
    T1 t1;
    T2 t2;
    T3 t3;
    T4 t4;
    CKeyQuad() :t1(), t2(), t3(), t4() {}
    CKeyQuad(const T1 &_t1, const T2 &_t2, const T3 &_t3, const T4 &_t4) :t1(_t1), t2(_t2), t3(_t3), t4(_t4) {}

    bool operator<( const CKeyQuad &k )
      {
       if (t1<k.t1) return true;
       if (t1>k.t1) return false;
       // t1 are equal
       if (t2<k.t2) return true;
       if (t2>k.t2) return false;
       // t2 are equal
       if (t3<k.t3) return true;
       if (t3>k.t3) return false;
       // t3 are equal
       if (t4<k.t4) return true;
       return false;
      }

    bool operator>( const CKeyQuad &k )
      {
       if (t1>k.t1) return true;
       if (t1<k.t1) return false;
       // t1 are equal
       if (t2>k.t2) return true;
       if (t2<k.t2) return false;
       // t2 are equal
       if (t3>k.t3) return true;
       if (t3<k.t3) return false;
       // t3 are equal
       if (t4>k.t4) return true;
       return false;
      }

    bool operator==( const CKeyQuad &k )
      {
       return t1==k.t1 && t2==k.t2 && t3==k.t3 && t4==k.t4;
      }

    bool operator!=( const CKeyQuad &k )
      {
       return t1!=k.t1 || t2!=k.t2 || t3!=k.t3 || t4!=k.t4;
      }

}; // struct CKeyQuad



}; // namespace util

//using util::swap;

}; // namespace cli





#endif /* CLI_CLIUTILX_H */

