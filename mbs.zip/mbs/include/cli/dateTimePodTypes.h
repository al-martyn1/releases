#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DATETIMEPODTYPES_H
#define CLI_DATETIMEPODTYPES_H

/*
// Add this
#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif
*/

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

// microseconds since January 1, 1601 (current implementation uses, in future this can be changed)
typedef INT64     CLI_TIME_T;
typedef UINT64    CLI_UTIME_T;
typedef INT64     CLI_STIME_T;

#endif /* CLI_DATETIMEPODTYPES_H */

