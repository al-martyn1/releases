#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_MESSAGES_H
#define CLI_MESSAGES_H

/*
#ifndef CLI_MESSAGES_H
    #include <cli/messages.h>
#endif
*/

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

#ifndef CLI_ARGLIST_H
    #include <cli/arglist.h>
#endif

#ifdef __cplusplus
    #ifndef CLI_FORMATX_H
        #include <cli/formatx.h>
    #endif
#endif

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif


/*
// flags for cliFormatMessage, also allowed for cliFormatErrorMessage

#define FMF_IGNORE_ASCII_CTRL_CHARS      0x0000 // default
#define FMF_ALLOW_ASCII_CTRL_CHARS       0x0001 // force allow \r, \n, \t etc
#define FMF_AUTO_APPEND_LF               0x0002 // if last char of result string is not \n, \n added
#define FMF_IGNORE_FORMAT_LF             0x0004 // ignore all %n sequences in source line
#define FMF_LONG_TABS                    0x0010 // default tab step is 8 not 4
#define FMF_EMPTY_OUT_OF_RANGE_ARGS      0x0020 // if arg index out of range, place empty string instead if '0'
*/

// flags for cliFindMessage and cliFindString
#define FIND_MESSAGE_DEFAULT             0x00000000
#define FIND_MESSAGE_FROM_MODULE         0x01000000
#define FIND_MESSAGE_FROM_APP            0x02000000
#define FIND_MESSAGE_USE_USER_LOCALE     0x04000000 /* instead of system locale, if langAndLocale not taken (Win32 only) */
#define FIND_MESSAGE_USE_APP_CONFIG      0x08000000 /* no mean for cliFind* directly, tells that usage of iAppConfig is prefered if possible */
                                                    /* for example, iMenuBuilder uses this flag */

#define FIND_STRING_DEFAULT              0x00000000
#define FIND_STRING_FROM_MODULE          0x01000000
#define FIND_STRING_FROM_APP             0x02000000
#define FIND_STRING_USE_USER_LOCALE      0x04000000 /* instead of system locale, if langAndLocale not taken (Win32 only) */
#define FIND_STRING_USE_APP_CONFIG       0x08000000 /* no mean for cliFind* directly, tells that usage of iAppConfig is prefered if possible */
                                                    /* for example, iMenuBuilder uses this flag */

#define FIND_MESSAGE_FLAGS_MASK          0xFF000000
#define FIND_STRING_FLAGS_MASK           0xFF000000


EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliFindMessage( CLIPSTR *msgFound
              , const WCHAR *moduleName
              , RCODE code
              , const WCHAR *langAndLocale
              , DWORD flags
              );

EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliFindString( CLIPSTR *msgFound
             , const WCHAR *moduleName
             , const WCHAR *strId
             , const WCHAR *langAndLocale
              , DWORD flags
             );

EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliFormatErrorMessage( CLIPSTR *msgFormatted
              , const WCHAR *moduleName
              , RCODE code
              , const WCHAR *langAndLocale
              , DWORD flags
              , INTERFACE_CLI_IARGLIST* pArgs
              );




#ifdef __cplusplus

namespace cli
{

inline
::std::wstring findMessageDef( const ::std::wstring &defMsg
                          , const WCHAR *moduleName
                          , RCODE code
                          , const WCHAR *langAndLocale
                          , DWORD flags
                          )
   {
    CLIPSTR msgFound;
    if (cliFindMessage( &msgFound, moduleName, code, langAndLocale, flags ) || !msgFound)
       return defMsg;

    ::std::wstring res(clipstr_data(msgFound), clipstr_size(msgFound));
    clipstr_free(&msgFound);
    return res;
   }

inline
bool findMessage( ::std::wstring &res
                          , const WCHAR *moduleName
                          , RCODE code
                          , const WCHAR *langAndLocale
                          , DWORD flags
                          )
   {
    CLIPSTR msgFound;
    if (cliFindMessage( &msgFound, moduleName, code, langAndLocale, flags ) || !msgFound)
       return false;

    res = ::std::wstring(clipstr_data(msgFound), clipstr_size(msgFound));
    clipstr_free(&msgFound);
    return true;
   }

inline
::std::wstring findStringDef( const ::std::wstring &defMsg
                          , const WCHAR *moduleName
                          , const WCHAR *strId
                          , const WCHAR *langAndLocale
                          , DWORD flags
                          )
   {
    CLIPSTR msgFound;
    if (cliFindString( &msgFound, moduleName, strId, langAndLocale, flags ) || !msgFound)
       return defMsg;

    ::std::wstring res(clipstr_data(msgFound), clipstr_size(msgFound));
    clipstr_free(&msgFound);
    return res;
   }

inline
bool findString( ::std::wstring &res
                          , const WCHAR *moduleName
                          , const WCHAR *strId
                          , const WCHAR *langAndLocale
                          , DWORD flags
                          )
   {
    CLIPSTR msgFound;
    if (cliFindString( &msgFound, moduleName, strId, langAndLocale, flags ) || !msgFound)
       return true;

    res = ::std::wstring(clipstr_data(msgFound), clipstr_size(msgFound));
    clipstr_free(&msgFound);
    return true;
   }


inline
RCODE formatErrorMessage( ::std::wstring &msgFormatted
                        , const WCHAR *moduleName
                        , RCODE code
                        , const WCHAR *langAndLocale
                        , DWORD flags
                        , const ::cli::format::arg &a
                        )
   {
    CLIPSTR msg = 0;
    RCODE res = cliFormatErrorMessage( &msg
                                     , moduleName
                                     , code
                                     , langAndLocale
                                     , flags
                                     , (INTERFACE_CLI_IARGLIST*)a
                                     );
    if (msg)
       {
        msgFormatted = ::std::wstring(clipstr_data(msg), clipstr_size(msg));
        clipstr_free(&msg);
       }
    return res;
   }

inline
::std::wstring formatErrorMessage( const WCHAR *moduleName
                        , RCODE code
                        , const WCHAR *langAndLocale
                        , DWORD flags
                        , const ::cli::format::arg &a
                        )
   {
    ::std::wstring res;
    formatErrorMessage( res, moduleName, code, langAndLocale, flags, a );
    return res;
   }


inline
RCODE formatErrorMessage( ::std::wstring &msgFormatted
                        , const WCHAR *moduleName
                        , RCODE code
                        , const WCHAR *langAndLocale
                        , DWORD flags
                        )
   {
    CLIPSTR msg = 0;
    RCODE res = cliFormatErrorMessage( &msg
                                     , moduleName
                                     , code
                                     , langAndLocale
                                     , flags
                                     , (INTERFACE_CLI_IARGLIST*)0
                                     );
    if (msg)
       {
        msgFormatted = ::std::wstring(clipstr_data(msg), clipstr_size(msg));
        clipstr_free(&msg);
       }
    return res;
   }

inline
::std::wstring formatErrorMessage( const WCHAR *moduleName
                        , RCODE code
                        , const WCHAR *langAndLocale
                        , DWORD flags
                        )
   {
    ::std::wstring res;
    formatErrorMessage( res, moduleName, code, langAndLocale, flags );
    return res;
   }



}; // namespace cli


#endif


#endif /* CLI_MESSAGES_H */

