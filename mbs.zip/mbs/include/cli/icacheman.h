#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_ICACHEMAN_H
#define CLI_ICACHEMAN_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/icacheman.h>", CLI_ICACHEMAN_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_ICACHEMAN_H
    #include <cli/icacheman.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iComponentCacheManager */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ICOMPONENTCACHEMANAGER_IID
    #define INTERFACE_CLI_ICOMPONENTCACHEMANAGER_IID    "/cli/iComponentCacheManager"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iComponentCacheManager
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ICOMPONENTCACHEMANAGER
       #define INTERFACE_CLI_ICOMPONENTCACHEMANAGER    ::cli::iComponentCacheManager
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iComponentCacheManager
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ICOMPONENTCACHEMANAGER
       #define INTERFACE_CLI_ICOMPONENTCACHEMANAGER    cli_iComponentCacheManager
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iComponentCacheManager methods */
            CLIMETHOD(getExecutableName) (THIS_ CLISTR*           exeName) PURE;
            CLIMETHOD(getExecutablePath) (THIS_ CLISTR*           exePath) PURE;
            CLIMETHOD(isCliComponentsModule) (THIS_ const CLISTR*     modNamePath
                                                  , BOOL*    fIsModule /* [out] bool fIsModule  */
                                             ) PURE;
            CLIMETHOD(createCacheStrForModule) (THIS_ const CLISTR*     modNamePath
                                                    , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                                    , CLICSTR*          strCache
                                               ) PURE;
            CLIMETHOD(getCacheFilename) (THIS_ const CLISTR*     modNamePath
                                             , CLISTR*           modCacheName
                                        ) PURE;
            CLIMETHOD(createCacheForModule) (THIS_ const CLISTR*     modNamePath
                                                 , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                            ) PURE;
            CLIMETHOD(createCacheForModuleMask) (THIS_ const CLISTR*     modNamePathMask
                                                     , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                                     , BOOL    recurseSubdirs /* [in] bool  recurseSubdirs  */
                                                ) PURE;
            CLIMETHOD(createCacheForModules) (THIS_ BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                                  , BOOL    recurseSubdirs /* [in] bool  recurseSubdirs  */
                                             ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iComponentCacheManager >
           {
            static char const * getName() { return INTERFACE_CLI_ICOMPONENTCACHEMANAGER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iComponentCacheManager* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iComponentCacheManager > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iComponentCacheManager wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ICOMPONENTCACHEMANAGER >
                                      */
                 >
        class CiComponentCacheManagerWrapper
        {
            public:
        
                typedef  CiComponentCacheManagerWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiComponentCacheManagerWrapper() :
                   pif(0) {}
        
                CiComponentCacheManagerWrapper( iComponentCacheManager *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiComponentCacheManagerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiComponentCacheManagerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiComponentCacheManagerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiComponentCacheManagerWrapper(const CiComponentCacheManagerWrapper &i) :
                    pif(i.pif) { }
        
                ~CiComponentCacheManagerWrapper()  { }
        
                CiComponentCacheManagerWrapper& operator=(const CiComponentCacheManagerWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE getExecutableName( ::std::wstring    &exeName)
                   {
                    CCliStr tmp_exeName; CCliStr_init( tmp_exeName );
                    RCODE res = pif->getExecutableName(&tmp_exeName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( exeName, tmp_exeName);
                       }
                    return res;
                   }
                
                RCODE getExecutablePath( ::std::wstring    &exePath)
                   {
                    CCliStr tmp_exePath; CCliStr_init( tmp_exePath );
                    RCODE res = pif->getExecutablePath(&tmp_exePath);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( exePath, tmp_exePath);
                       }
                    return res;
                   }
                
                RCODE isCliComponentsModule( const ::std::wstring    &modNamePath
                                           , BOOL*    fIsModule /* [out] bool fIsModule  */
                                           )
                   {
                    CCliStr tmp_modNamePath; CCliStr_lightCopyTo( tmp_modNamePath, modNamePath);
                
                    return pif->isCliComponentsModule(&tmp_modNamePath, fIsModule);
                   }
                
                RCODE createCacheStrForModule( const ::std::wstring    &modNamePath
                                             , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                             , ::std::string    &strCache
                                             )
                   {
                    CCliStr tmp_modNamePath; CCliStr_lightCopyTo( tmp_modNamePath, modNamePath);
                
                    CCliCStr tmp_strCache; CCliCStr_init( tmp_strCache );
                    RCODE res = pif->createCacheStrForModule(&tmp_modNamePath, addModuleInfo, &tmp_strCache);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( strCache, tmp_strCache);
                       }
                    return res;
                   }
                
                RCODE getCacheFilename( const ::std::wstring    &modNamePath
                                      , ::std::wstring    &modCacheName
                                      )
                   {
                    CCliStr tmp_modNamePath; CCliStr_lightCopyTo( tmp_modNamePath, modNamePath);
                    CCliStr tmp_modCacheName; CCliStr_init( tmp_modCacheName );
                    RCODE res = pif->getCacheFilename(&tmp_modNamePath, &tmp_modCacheName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( modCacheName, tmp_modCacheName);
                       }
                    return res;
                   }
                
                RCODE createCacheForModule( const ::std::wstring    &modNamePath
                                          , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                          )
                   {
                    CCliStr tmp_modNamePath; CCliStr_lightCopyTo( tmp_modNamePath, modNamePath);
                
                    return pif->createCacheForModule(&tmp_modNamePath, addModuleInfo);
                   }
                
                RCODE createCacheForModuleMask( const ::std::wstring    &modNamePathMask
                                              , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                              , BOOL    recurseSubdirs /* [in] bool  recurseSubdirs  */
                                              )
                   {
                    CCliStr tmp_modNamePathMask; CCliStr_lightCopyTo( tmp_modNamePathMask, modNamePathMask);
                
                
                    return pif->createCacheForModuleMask(&tmp_modNamePathMask, addModuleInfo, recurseSubdirs);
                   }
                
                RCODE createCacheForModules( BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                           , BOOL    recurseSubdirs /* [in] bool  recurseSubdirs  */
                                           )
                   {
                
                
                    return pif->createCacheForModules(addModuleInfo, recurseSubdirs);
                   }
                

        
        
        }; // class CiComponentCacheManagerWrapper
        
        typedef CiComponentCacheManagerWrapper< ::cli::CCliPtr< INTERFACE_CLI_ICOMPONENTCACHEMANAGER     > >  CiComponentCacheManager;
        typedef CiComponentCacheManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICOMPONENTCACHEMANAGER > >  CiComponentCacheManager_nrc; /* No ref counting for interface used */
        typedef CiComponentCacheManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICOMPONENTCACHEMANAGER > >  CiComponentCacheManager_tmp; /* for temporary usage, same as CiComponentCacheManager_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_ICACHEMAN_H */
