#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLIRC_H
#define CLI_CLIRC_H

/* add this lines to your src
#ifndef CLI_CLIRC_H
    #include <cli/clirc.h>
#endif
*/

#ifndef CLI_IRES_H
    #include <cli/ires.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

CLI_DEPRECATED(
                EXTERN_CLI
                CLIAPIENTRY
                INTERFACE_CLI_IRESOURCEMANAGER*
                CLICALL
                cliGetRcMan( )
              );

/* return prev RC Manager */
CLI_DEPRECATED(
                EXTERN_CLI
                CLIAPIENTRY
                INTERFACE_CLI_IRESOURCEMANAGER*
                CLICALL
                cliChangeRcMan( INTERFACE_CLI_IRESOURCEMANAGER* pRcManNew )
              );

CLI_DEPRECATED(
                EXTERN_CLI
                CLIAPIENTRY
                VOID
                CLICALL
                cliSetRcMan( INTERFACE_CLI_IRESOURCEMANAGER* pRcManNew )
              );

EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
clircUnpackRle( const CLICSTR* strPacked, CLICSTR* strUnpackTo );


#ifdef __cplusplus

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif


namespace cli{

namespace rc
{

namespace helpers
{

struct CLocaleEnumeratorImplBase : public INTERFACE_CLI_ILOCALEENUMERATOR
                           , public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
{

        typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
        typedef CLocaleEnumeratorImplBase this_class;

        CLocaleEnumeratorImplBase()
           : base_impl(DEF_MODULE)
           {}

        CLI_BEGIN_INTERFACE_MAP2(CLocaleEnumeratorImplBase, INTERFACE_CLI_ILOCALEENUMERATOR)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ILOCALEENUMERATOR )
        CLI_END_INTERFACE_MAP(CLocaleEnumeratorImplBase)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return 1; }
        CLIMETHOD_(ULONG, release) (THIS)   { return 1; }
        CLIMETHOD_(VOID, destroy) (THIS)
           {
           #include <cli/compspec/delthis.h>
           }

        // need to be redefined
        CLIMETHOD(onLocaleEnumerate) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                          , const WCHAR*    langAndLocaleName /* [in,flat] wchar  langAndLocaleName[]  */
                                     ) { return EC_OK; }

}; // struct CLocaleEnumeratorImplBase

template<typename StringType>
struct CLocaleEnumeratorImpl : public CLocaleEnumeratorImplBase
{
    ::std::vector< ::std::pair< StringType, StringType > > &locales;
    CLocaleEnumeratorImpl(::std::vector< ::std::pair< StringType, StringType > > &l) : CLocaleEnumeratorImplBase(), locales(l) {}

    CLIMETHOD(onLocaleEnumerate) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                      , const WCHAR*    langAndLocaleName /* [in,flat] wchar  langAndLocaleName[]  */
                                 )
       {
        locales.push_back( std::make_pair(stdstr(langAndLocale),stdstr(langAndLocaleName)) );
        return EC_OK;
       }
};

template<>
struct CLocaleEnumeratorImpl< ::std::string > : public CLocaleEnumeratorImplBase
{
    ::std::vector< ::std::pair< ::std::string, ::std::string > > &locales;
    CLocaleEnumeratorImpl(::std::vector< ::std::pair< ::std::string, ::std::string > > &l) : CLocaleEnumeratorImplBase(), locales(l) {}

    CLIMETHOD(onLocaleEnumerate) (THIS_ const WCHAR*    langAndLocale /* [in,flat] wchar  langAndLocale[]  */
                                      , const WCHAR*    langAndLocaleName /* [in,flat] wchar  langAndLocaleName[]  */
                                 )
       {
        locales.push_back( std::make_pair(MARTY_CON::strToAnsi(stdstr(langAndLocale)),MARTY_CON::strToAnsi(stdstr(langAndLocaleName))) );
        return EC_OK;
       }
};


inline
std::wstring getStrTail( const std::wstring &strId )
   {
    ::std::wstring::size_type slashPos = strId.rfind( L'/' );
    if (slashPos==::std::wstring::npos) return strId;
    return ::std::wstring( strId, slashPos+1, ::std::wstring::npos );
   }

inline
std::string getStrTail( const std::string &strId )
   {
    ::std::string::size_type slashPos = strId.rfind( '/' );
    if (slashPos==::std::string::npos) return strId;
    return ::std::string( strId, slashPos+1, ::std::string::npos );
   }
   
}; // namespace helpers

inline
::std::wstring findString( const std::wstring &strId
                       , const std::wstring &lc_NM = std::wstring() /* locale name */
                       , ENUM_CLI_ERCMANFINDFLAGS flags = CLI_ERCMANFINDFLAGS_RCFINDSTRINGDEFAULT
                       , const std::wstring &findFromModule = std::wstring()
                       )
   {
    INTERFACE_CLI_IRESOURCEMANAGER *pRcMan = cliGetRcMan( );
    if (!pRcMan) return helpers::getStrTail(strId);

    ::cli::CiResourceManager_tmp rcMan(pRcMan);

    ::std::wstring resStr;
    RCODE rc = EC_OK;
    if (findFromModule.empty())
       rc = rcMan.findString( resStr, strId, lc_NM, flags );
    else
       rc = rcMan.findStringEx( resStr, strId, lc_NM, flags, findFromModule );

    if (rc && resStr.empty()) return helpers::getStrTail(strId);
    return resStr;
   }

inline
::std::string findString( const std::string &strId
                       , const std::string &lc_NM = std::string() /* locale name */
                       , ENUM_CLI_ERCMANFINDFLAGS flags = CLI_ERCMANFINDFLAGS_RCFINDSTRINGDEFAULT
                       , const std::string &findFromModule = std::string()
                       )
   {
    return MARTY_CON::strToAnsi( findString( MARTY_CON::strToWide(strId), MARTY_CON::strToWide(lc_NM)
                                           , flags, MARTY_CON::strToWide(findFromModule)
                                           )
                               );
   }

inline
::std::wstring findMessage( RCODE msgCode
                       , const std::wstring &lc_NM = std::wstring() /* locale name */
                       , ENUM_CLI_ERCMANFINDFLAGS flags = CLI_ERCMANFINDFLAGS_RCFINDSTRINGDEFAULT
                       , const std::wstring &findFromModule = std::wstring()
                       )
   {
    INTERFACE_CLI_IRESOURCEMANAGER *pRcMan = cliGetRcMan( );
    if (!pRcMan) return ::std::wstring(L"unknown_message_code");

    ::cli::CiResourceManager_tmp rcMan(pRcMan);

    ::std::wstring resStr;
    RCODE rc = EC_OK;
    if (findFromModule.empty())
       rc = rcMan.findMessage( resStr, msgCode, lc_NM, flags );
    else
       rc = rcMan.findMessageEx( resStr, msgCode, lc_NM, flags, findFromModule );

    if (rc && resStr.empty()) return ::std::wstring(L"unknown_message_code");
    return resStr;
   }

inline
::std::string findMessage( RCODE msgCode
                       , const std::string &lc_NM = std::string() /* locale name */
                       , ENUM_CLI_ERCMANFINDFLAGS flags = CLI_ERCMANFINDFLAGS_RCFINDSTRINGDEFAULT
                       , const std::string &findFromModule = std::string()
                       )
   {
    return MARTY_CON::strToAnsi( findMessage( msgCode, MARTY_CON::strToWide(lc_NM)
                                           , flags, MARTY_CON::strToWide(findFromModule)
                                           )
                               );
   }

}; // namespace rc



inline
RCODE rcUnpackRle( const ::std::string &strPacked, ::std::string &strUnpackTo )
   {
    CCliCStr tmp__strUnpackTo; CCliCStr_init( tmp__strUnpackTo );
    CCliCStr tmp_strPacked   ; CCliCStr_lightCopyTo( tmp_strPacked, strPacked );

    RCODE res = clircUnpackRle( &tmp_strPacked, &tmp__strUnpackTo );
    if (RCOK(res))
       {
        CCliCStr_copyFromIfModified( strUnpackTo, tmp__strUnpackTo);
       }
    return res;
   }

inline
RCODE rcUnpackRle( const char* packedData, SIZE_T packedDataSize, ::std::string &strUnpackTo )
   {
    CCliCStr tmp__strUnpackTo; CCliCStr_init( tmp__strUnpackTo );
    CCliCStr tmp_strPacked   ; //CCliCStr_lightCopyTo( tmp_strPacked, strPacked );
    tmp_strPacked.assignLight(packedData, packedDataSize);

    RCODE res = clircUnpackRle( &tmp_strPacked, &tmp__strUnpackTo );
    if (RCOK(res))
       {
        CCliCStr_copyFromIfModified( strUnpackTo, tmp__strUnpackTo);
       }
    return res;
   }

inline
RCODE rcUnpackRle( const unsigned char* packedData, SIZE_T packedDataSize, ::std::string &strUnpackTo )
   {
    return rcUnpackRle( (const char*)packedData, packedDataSize, strUnpackTo );
   }


struct CConfDummy{ int dummy; };

class CRcAutoReg
{
    RCODE regResult;
    const wchar_t *f;
    const wchar_t *lL;

public:

    CRcAutoReg( const char *pData, SIZE_T dataLen, const wchar_t *fileName, const wchar_t *lang_LOCALE = 0 ) : regResult(0), f(fileName), lL(lang_LOCALE)
       {
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        regResult = pRcMan->registerResourceChars( lang_LOCALE, fileName, (const BYTE*)pData, dataLen, CLI_ERCMANREGISTERFLAGS_RCREGDEFAULT );
       }

    CRcAutoReg( const unsigned char *pData, SIZE_T dataLen, const wchar_t *fileName, const wchar_t *lang_LOCALE = 0 ) : regResult(0), f(fileName), lL(lang_LOCALE)
       {
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        regResult = pRcMan->registerResourceChars( lang_LOCALE, fileName, (const BYTE*)pData, dataLen, CLI_ERCMANREGISTERFLAGS_RCREGDEFAULT );
       }

    CRcAutoReg( const char *pData, SIZE_T dataLen, const wchar_t *fileName, const CConfDummy &c, const wchar_t *lang_LOCALE = 0 ) : regResult(0), f(fileName), lL(lang_LOCALE)
       {
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        regResult = pRcMan->registerResourceChars( lang_LOCALE, fileName, (const BYTE*)pData, dataLen, CLI_ERCMANREGISTERFLAGS_RCTYPECONF );
       }

    CRcAutoReg( const unsigned char *pData, SIZE_T dataLen, const wchar_t *fileName, const CConfDummy &c, const wchar_t *lang_LOCALE = 0 ) : regResult(0), f(fileName), lL(lang_LOCALE)
       {
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        regResult = pRcMan->registerResourceChars( lang_LOCALE, fileName, (const BYTE*)pData, dataLen, CLI_ERCMANREGISTERFLAGS_RCTYPECONF );
       }

    ~CRcAutoReg()
       {
        if (regResult) return;
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        pRcMan->unregisterResourceChars( lL, f );
       }


}; /* class CRcAutoReg */


class CRcUnpackRleAutoReg
{
    RCODE regResult;
    const wchar_t *f;
    const wchar_t *lL;

public:

    CRcUnpackRleAutoReg( const char *pData, SIZE_T dataLen, const wchar_t *fileName, const wchar_t *lang_LOCALE = 0 ) : regResult(0), f(fileName), lL(lang_LOCALE)
       {
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        ::std::string strUnpacked;
        rcUnpackRle( pData, dataLen, strUnpacked );

        regResult = pRcMan->registerResourceChars( lang_LOCALE, fileName, (const BYTE*)strUnpacked.data(), (SIZE_T)strUnpacked.size(), CLI_ERCMANREGISTERFLAGS_RCREGCOPY );
       }

    CRcUnpackRleAutoReg( const unsigned char *pData, SIZE_T dataLen, const wchar_t *fileName, const wchar_t *lang_LOCALE = 0 ) : regResult(0), f(fileName), lL(lang_LOCALE)
       {
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        ::std::string strUnpacked;
        rcUnpackRle( pData, dataLen, strUnpacked );

        regResult = pRcMan->registerResourceChars( lang_LOCALE, fileName, (const BYTE*)strUnpacked.data(), (SIZE_T)strUnpacked.size(), CLI_ERCMANREGISTERFLAGS_RCREGCOPY );
       }

    CRcUnpackRleAutoReg( const char *pData, SIZE_T dataLen, const wchar_t *fileName, const CConfDummy &c, const wchar_t *lang_LOCALE = 0 ) : regResult(0), f(fileName), lL(lang_LOCALE)
       {
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        ::std::string strUnpacked;
        rcUnpackRle( pData, dataLen, strUnpacked );

        regResult = pRcMan->registerResourceChars( lang_LOCALE, fileName, (const BYTE*)strUnpacked.data(), (SIZE_T)strUnpacked.size(), CLI_ERCMANREGISTERFLAGS_RCREGCOPY|CLI_ERCMANREGISTERFLAGS_RCTYPECONF );
       }

    CRcUnpackRleAutoReg( const unsigned char *pData, SIZE_T dataLen, const wchar_t *fileName, const CConfDummy &c, const wchar_t *lang_LOCALE = 0 ) : regResult(0), f(fileName), lL(lang_LOCALE)
       {
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        ::std::string strUnpacked;
        rcUnpackRle( pData, dataLen, strUnpacked );

        regResult = pRcMan->registerResourceChars( lang_LOCALE, fileName, (const BYTE*)strUnpacked.data(), (SIZE_T)strUnpacked.size(), CLI_ERCMANREGISTERFLAGS_RCREGCOPY|CLI_ERCMANREGISTERFLAGS_RCTYPECONF );
       }

    ~CRcUnpackRleAutoReg()
       {
        if (regResult) return;
        INTERFACE_CLI_IRESOURCEMANAGER* pRcMan = cliGetRcMan( );
        if (!pRcMan) return;

        pRcMan->unregisterResourceChars( lL, f );
       }


}; /* class CRcAutoReg */


}; /* namespace cli */



#define CTRSA(id)  ::cli::rc::findString( id )
#define CTRSW_(id) ::cli::rc::findString( L##id )
#define CTRSW(id)  CTRSW_(id)
#define CTRS(id)   ::cli::rc::findString( _T(id) )

#define CTRCA(id)  ::cli::rc::findString( id ).c_str()
#define CTRCW_(id) ::cli::rc::findString( L##id ).c_str()
#define CTRCW(id)  CTRCW_(id)
#define CTRC(id)   ::cli::rc::findString( _T(id) ).c_str()




#endif /* __cplusplus */

#endif /* CLI_CLIRC_H */

