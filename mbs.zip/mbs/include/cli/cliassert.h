#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CLIASSERT_H
#define CLI_CLIASSERT_H

/* Add next lines to your C/C++ code
#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif
*/

#include <assert.h>


/* from loki/static_check.h
   The Loki Library
   Copyright (c) 2001 by Andrei Alexandrescu
*/

#if defined(__cplusplus) && !defined(CINTERFACE) && !defined(CLIASSERT_C)
    namespace cli
    {
        template<int> struct CompileTimeError;
        template<> struct CompileTimeError<true> {};
    };

    #define CLI_STATIC_CHECK(expr, msg) \
        { ::cli::CompileTimeError<((expr) != 0)> ERROR_##msg; (void)ERROR_##msg; }

    #ifndef CLIASSERT
        #if defined(ATLASSERT)
            #define CLIASSERT(expr)  ATLASSERT(expr)
        #else
            #ifdef _DEBUG
                #define CLIASSERT(expr)  assert(expr)
            #else
                #define CLIASSERT(expr)  do {} while(0)
            #endif /* _DEBUG */
        #endif /* ATLASSERT */
    #endif /* CLIASSERT */

#else // plain C

    #define CLI_STATIC_CHECK(expr, msg) { char msg[ (expr) ? 1 : 0 ]; }

    #ifndef CLIASSERT
        #ifdef _DEBUG
            #define CLIASSERT(expr)  assert(expr)
        #else
            #define CLIASSERT(expr)  do {} while(0)
        #endif /* _DEBUG */
    #endif /* CLIASSERT */

#endif
/*
#ifndef CLIASSERT
    #ifdef _DEBUG
        #define CLIASSERT(expr)  assert(expr)
        // if (!(expr)) { int *p = 0; *p = 0; }
    #else
        #define CLIASSERT(expr)  do {} while(0)
    #endif
#endif
*/


#endif /* CLI_CLIASSERT_H */

