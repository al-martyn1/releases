#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DETECTTARGET_H
#define CLI_DETECTTARGET_H

/* add this lines to your scr
#ifndef CLI_DETECTTARGET_H
    #include <cli/detectTarget.h>
#endif
*/

#if defined(WIN32) && !defined(_WIN32)
    #define _WIN32
#endif

#if defined(_WIN32) && !defined(WIN32)
    #define WIN32
#endif

// default machine for win32, linux, freebsd is x86
#if (defined(_WIN32) || defined(LINUX) || defined(FREEBSD)) && defined(MACHINE_UNKNOWN)
    #undef MACHINE_UNKNOWN
    #ifdef PLATFORMMACHINE
         #undef PLATFORMMACHINE
    #endif

    #define MACHINE_X86
    #define PLATFORMMACHINE MACHINE_X86

    #if !defined(CLI_PLATFORM_BIG_ENDIAN) && !defined(CLI_PLATFORM_LITTLE_ENDIAN)
        #define CLI_PLATFORM_LITTLE_ENDIAN
    #endif
#endif


#if defined(linux) || defined(__linux) || defined(__linux__)
    #ifndef LINUX
        #define LINUX
    #endif
#endif

#if defined(__FreeBSD__)
    #ifndef FREEBSD
        #define FREEBSD
    #endif
#endif

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__DragonFly__)
    #ifndef BSD
        #define BSD
    #endif
#endif

#ifdef _WIN32
    #ifdef LINUX
        #error "WIN32 macro conflicts with LINUX macro"
    #endif
    #ifdef FREEBSD
        #error "WIN32 macro conflicts with FREEBSD macro"
    #endif
    #ifdef BSD
        #error "WIN32 macro conflicts with BSD macro"
    #endif
#endif

#ifdef LINUX
    #ifdef FREEBSD
        #error "LINUX macro conflicts with FREEBSD macro"
    #endif
    #ifdef BSD
        #error "LINUX macro conflicts with BSD macro"
    #endif
#endif

#endif /* CLI_DETECTTARGET_H */

