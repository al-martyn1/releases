#ifndef CLI_IIDOF_H
#define CLI_IIDOF_H

#if defined(__cplusplus) && !defined(CINTERFACE)

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

    namespace cli{

        template< typename T> struct CIidOfImpl
        {
         static char const * getName() { CLI_STATIC_CHECK(0, struct_cli_CIidOfImpl_must_be_specialized_for_this_type_0_Possible_interface_does_not_extend_cli_iUnknown); return 0; }
        };

        template< typename T> struct CIidOfImpl<T*>
        {
         static char const * getName() { CLI_STATIC_CHECK(0, struct_cli_CIidOfImpl_must_be_specialized_for_this_type_0_Possible_interface_does_not_extend_cli_iUnknown); return 0; }
        };

        template< typename T> struct CIidOfImpl<T**>
        {
         static char const * getName() { CLI_STATIC_CHECK(0, struct_cli_CIidOfImpl_must_be_specialized_for_this_type_0_Possible_interface_does_not_extend_cli_iUnknown); return 0; }
        };

        template<typename T>
        char const* iidOf(T const &t)
           {
            return ::cli::CIidOfImpl< T > :: getName();
           }

        /*
        // Usage sample
        template<> struct CIidOfImpl< INTERFACE_TYPE >
        {
         static char const * getName(INTERFACE_TYPE const & t) { return "InterfaceName"; }
        };

        template<> struct CIidOfImpl<INTERFACE_TYPE*>
        {
         static char const * getName(INTERFACE_TYPE* const & t) { return "InterfaceName"; }
        };
        */
    }; // namespace cli
#endif


#endif /* CLI_IIDOF_H */

