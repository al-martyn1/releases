#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_MISC_WRITEUTILS_H
#define CLI_MISC_WRITEUTILS_H

/* add this lines to your src
#ifndef CLI_MISC_WRITEUTILS_H
    #include <cli/misc/writeutils.h>
#endif
*/

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_IO_IO_H
    #include <cli/io/io.h>
#endif

#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef MARTY_LIBAPI_H
    #include <marty/libapi.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


namespace cli
{
namespace misc
{
namespace utils
{

#ifndef CLI_MISC_UTILS_TSTRING_DEFINED
    #define CLI_MISC_UTILS_TSTRING_DEFINED
    #if defined(UNICODE) || defined(_UNICODE)
        typedef ::std::wstring    tstring;
    #else
        typedef ::std::string     tstring;
    #endif
#endif


// MARTY_CON::strToWide(fileName)
inline
RCODE writeFile( const ::std::wstring &fileName, const ::std::string &fileData )
   {
    ::cli::io::CiIOFactory iof( "/cli/io-factory" );
    #if defined(WIN32) || defined(_WIN32)
    ::std::wstring streamName = ::std::wstring(L"file:///") + fileName + ::std::wstring(L"?mode=w");
    #else
    ::std::wstring streamName = ::std::wstring(L"file://")  + fileName + ::std::wstring(L"?mode=w");
    #endif

    ::cli::io::CiIOStream ios;
    RCODE res = iof.createStream( streamName, ios.getPP(), 0 );
    if (res) return res;

    SIZE_T written = 0;
    return ios.writeTimeout( fileData.data(), fileData.size(), &written, 100);
   }

inline
RCODE writeFile( const ::std::string &fileName, const ::std::string &fileData )
   {
    return writeFile( MARTY_CON::strToWide(fileName), fileData );
   }









}; // namespace utils
}; // namespace misc
}; // namespace cli


#endif /* CLI_MISC_READUTILS_H */

