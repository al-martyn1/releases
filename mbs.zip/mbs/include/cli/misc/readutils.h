#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_MISC_READUTILS_H
#define CLI_MISC_READUTILS_H

/* add this lines to your src
#ifndef CLI_MISC_READUTILS_H
    #include <cli/misc/readutils.h>
#endif
*/

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_IO_IO_H
    #include <cli/io/io.h>
#endif

#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef MARTY_LIBAPI_H
    #include <marty/libapi.h>
#endif


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


// ::cli::misc::utils::

namespace cli
{
namespace misc
{
namespace utils
{

#ifndef CLI_MISC_UTILS_TSTRING_DEFINED
    #define CLI_MISC_UTILS_TSTRING_DEFINED
    #if defined(UNICODE) || defined(_UNICODE)
        typedef ::std::wstring    tstring;
    #else
        typedef ::std::string     tstring;
    #endif
#endif


// MARTY_CON::strToWide(fileName)

inline
RCODE readFile( ::cli::io::CiIOStream ios, ::std::string &inputData )
   {
    char buf[16384];
    SIZE_T readed = 0;
    RCODE res = 0;
    while((res = ios.readTimeout( buf, sizeof(buf), &readed, 100)) == EC_OK)
       {
        if (!readed) break; // continue;
        inputData.append(buf, readed);
       }
    return EC_OK;
   }

inline
RCODE readFile( const ::std::wstring &fileName, ::std::string &inputData )
   {
    ::cli::io::CiIOFactory iof( "/cli/io-factory" );
    #if defined(WIN32) || defined(_WIN32)
    ::std::wstring streamName = ::std::wstring(L"file:///") + fileName + ::std::wstring(L"?mode=r");
    #else
    ::std::wstring streamName = ::std::wstring(L"file://")  + fileName + ::std::wstring(L"?mode=r");
    #endif

    ::cli::io::CiIOStream ios;
    RCODE res = iof.createStream( streamName, ios.getPP(), 0 );
    if (res) return res;
    return readFile( ios, inputData );
   }

inline
RCODE readFile( const ::std::string &fileName, ::std::string &inputData )
   {
    return readFile( MARTY_CON::strToWide(fileName), inputData );
   }

inline
RCODE canReadFile( const ::std::wstring &fileName )
   {
    ::cli::io::CiIOFactory iof( "/cli/io-factory" );
    #if defined(WIN32) || defined(_WIN32)
    ::std::wstring streamName = ::std::wstring(L"file:///") + fileName + ::std::wstring(L"?mode=r");
    #else
    ::std::wstring streamName = ::std::wstring(L"file://")  + fileName + ::std::wstring(L"?mode=r");
    #endif

    ::cli::io::CiIOStream ios;
    RCODE res = iof.createStream( streamName, ios.getPP(), 0 );
    if (res) return res;
/*
    char buf[256];
    SIZE_T readed = 0;
    res = ios.readTimeout( buf, sizeof(buf), &readed, 100));
    return res;
    while((res = ios.readTimeout( buf, sizeof(buf), &readed, 100)) == EC_OK)
       {
        if (!readed) break; // continue;
        inputData.append(buf, readed);
       }
*/
    return EC_OK;
   }

inline
RCODE canReadFile( const ::std::string &fileName )
   {
    return canReadFile( MARTY_CON::strToWide(fileName));
   }


inline
RCODE findApplicationConfig( tstring &foundFileName, ::std::string &configData, const tstring &_cfgName = tstring(), const tstring &cfgExt = _T("xml") )
   {
    using MARTY_FILENAME::appendPath;
    using MARTY_FILENAME::appendExtention;
    using MARTY_FILENAME::getFile;
    using MARTY_FILENAME::getName;
    using MARTY_FILENAME::getPath;
    using MARTY_FILENAME::makeCanonical;

    tstring appPathName;
    MARTY_LIBAPI::getModuleFileName((ABSTRACT_MODULE_HANDLE)0, appPathName);

    tstring cfgRoot = getPath( appPathName );
    tstring cfgName = _cfgName;
    if (cfgName.empty())
       cfgName = getName( appPathName );

    foundFileName = makeCanonical( appendExtention( appendPath( appendPath( cfgRoot, _T("../conf") ), cfgName ), cfgExt ) );

    //::std::string inputData;
    RCODE res = readFile( foundFileName, configData );
    if (res)
       {
        foundFileName = makeCanonical( appendExtention( appendPath( cfgRoot, cfgName ), cfgExt ) );
        res = readFile( foundFileName, configData );
        if (res) // use first variant to create config file
           foundFileName = makeCanonical( appendExtention( appendPath( appendPath( cfgRoot, _T("../conf") ), cfgName ), cfgExt ) );
       }
    return res;
   }



}; // namespace utils
}; // namespace misc
}; // namespace cli


#endif /* CLI_MISC_READUTILS_H */

