#ifndef CLI_TCHAR_H
#define CLI_TCHAR_H

/* add this lines to your scr
#ifndef CLI_TCHAR_H
    #include <cli/tchar.h>
#endif
*/


#include <tchar.h>

#if defined(UNICODE) || defined(_UNICODE)

    #ifndef __T
        #define __T(x) L##x
    #endif

#else

    #ifndef __T
        #define __T(x) x
    #endif

#endif

#ifndef _T
    #define _T(x) __T(x)
#endif

#ifndef _TEXT
    #define _TEXT(x) __T(x)
#endif


#ifndef __CLI_L
    #define __CLI_L(x) L##x
#endif

#ifndef _CLI_L
    #define _CLI_L(x) __CLI_L(x)
#endif

#ifndef _LTEXT
    #define _LTEXT(x) __CLI_L(x)
#endif

#ifndef _L
    #define _L(x) __CLI_L(x)
#endif



#endif /* CLI_TCHAR_H */

