#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_THREADS_H
#define CLI_THREADS_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif


// required includes

#if defined(WIN32) || defined(_WIN32)

    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif

    #if !defined(_INC_PROCESS)
        #include <process.h>
    #endif

#else

    #if !defined(_UNISTD_H) && !defined(_UNISTD_H_)
        #include <unistd.h>
    #endif

    #if !defined(_PTHREAD_H) && !defined(_PTHREAD_H_)
        #include <pthread.h>
    #endif

    #if !defined(_SYS_TIME_H) && !defined(_SYS_TIME_H_)
        #include <sys/time.h>
    #endif

    #if !defined(_SYS_TYPES_H) && !defined(_SYS_TYPES_H_) && !defined(_TYPES_H_)
        #include <sys/types.h>
    #endif

    #if !defined(_INC_TIME) && !defined(_TIME_H_) && !defined(_TIME_H)
        #include <time.h>
    #endif

#endif


#ifndef CLI_YIELD_H
    #include <cli/yield.h>
#endif


// requred types


#if defined(WIN32) || defined(_WIN32)

#define CLI_THREAD_PROC_CALL_TYPE STDCALL

typedef unsigned (CLI_THREAD_PROC_CALL_TYPE *cli_thread_proc_t )( void * );
typedef unsigned tid_t;

#ifndef _PID_T_
#define _PID_T_
#ifndef _NO_OLDNAMES
typedef unsigned pid_t;
#endif // _NO_OLDNAMES
#endif // Not _PID_T_

#else

#define CLI_THREAD_PROC_CALL_TYPE

typedef void * (CLI_THREAD_PROC_CALL_TYPE *cli_thread_proc_aux_t)(void *);
typedef unsigned (CLI_THREAD_PROC_CALL_TYPE *cli_thread_proc_t)(void *);
typedef pthread_t tid_t;

#endif

typedef tid_t TID_T;
typedef pid_t PID_T;

// misc defines

EXTERN_CLI
CLIAPIENTRY
TID_T
CLICALL
cliGetCurrentThread();

EXTERN_CLI
CLIAPIENTRY
TID_T
CLICALL
cliBeginThreadEx( unsigned stack_size
              , cli_thread_proc_t thproc
              , void * pArg
              , BOOL fSuspended
              );

EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliResumeThread( TID_T threadId );

EXTERN_CLI
CLIAPIENTRY
TID_T
CLICALL
cliBeginThread( unsigned stack_size
              , cli_thread_proc_t thproc
              , void * pArg
              );

#ifdef __cplusplus


typedef INT THSTATE_T;

const THSTATE_T  thsStateUndefined  = -1;
const THSTATE_T  thsStateNew        = 0;
const THSTATE_T  thsStateRunning    = 1;
const THSTATE_T  thsStateSuspended  = 2;
const THSTATE_T  thsStateTerminated = 3;



namespace cli
{

// http://w0.sao.ru/hq/sts/linux/book/c_marshall/node29.html
// http://www.cs.cf.ac.uk/Dave/C/node29.html

#ifndef _MSC_VER
    #ifdef USE_CLI_THREAD_STACK_CONTROL
        #undef USE_CLI_THREAD_STACK_CONTROL
    #endif // USE_CLI_THREAD_STACK_CONTROL
#endif // _MSC_VER


#ifdef USE_CLI_THREAD_STACK_CONTROL
__declspec(thread) const char* gStackBase;  // ������쭠�
#endif


class CThread
{
public:

static const THSTATE_T  stateUndefined  = -1;
static const THSTATE_T  stateNew        = 0;
static const THSTATE_T  stateRunning    = 1;
static const THSTATE_T  stateSuspended  = 2;
static const THSTATE_T  stateTerminated = 3;


    #ifdef USE_CLI_THREAD_STACK_CONTROL
    static void markStackBase()
       {
        char marker;
        gStackBase = &marker;
       }
    #endif

public:

    #ifdef USE_CLI_THREAD_STACK_CONTROL
    static SIZE_T getStackBase()
       {
        if (!gStackBase) markStackBase();
        return (SIZE_T)gStackBase;
       }
    static SIZE_T getCurrentStackMarker()
       {
        char marker;
        return (SIZE_T)&marker;
       }
    /*
    static SIZE_T getCurrentStackDepth()
       {
        char marker;
        return gStackBase - &marker;
       }
    */
    #else
    static SIZE_T getStackBase()
       {
        return 0;
       }
    static SIZE_T getCurrentStackMarker()
       {
        return 0;
       }
    /*
    static SIZE_T getCurrentStackDepth()
       {
        return 0;
       }
    */
    #endif

    static SIZE_T getCurrentStackDepth()
       {
        return getStackBase() - getCurrentStackMarker();
       }


private:

    volatile bool      fStop;
    volatile bool      fRun;
    //volatile bool      fStopped;
    volatile THSTATE_T  thState;
    volatile THSTATE_T *pThreadState;

    bool               selfDelete;
    RCODE              resultCode;
    TID_T              tid;
    DWORD              loopSleepPeriod;


    static
    unsigned CLI_THREAD_PROC_CALL_TYPE thread_proc( void *pv )
       {
        CThread *pth = (CThread*)pv;
        if (!pth) return 0;

        #ifdef USE_CLI_THREAD_STACK_CONTROL
        markStackBase();
        #endif

        //while(!pth->fRun) pth->sleep(10);
        pth->suspendWait( 10 );

        //pth->thState = stateRunning;
        //if (pth->pThreadState) *(pth->pThreadState) = pth->thState;

        pth->resultCode = pth->beforeStart();
        if (pth->resultCode)
           {
            pth->thState = stateTerminated;
            if (pth->pThreadState) *(pth->pThreadState) = pth->thState;

            if (pth->selfDelete) delete pth;
            return 0;
           }
        pth->resultCode = pth->execute();
        pth->afterExecute();

        pth->thState = stateTerminated;
        if (pth->pThreadState) *(pth->pThreadState) = pth->thState;

        if (pth->selfDelete) delete pth;
        return 0;
       }

public:

    static const bool deleteOnStop    = true;
    static const bool keepAliveOnStop = false;

    virtual void stop()      { fStop = true; }
    bool  stopped()    const { return thState==stateTerminated; }
    bool  teminated()  const { return thState==stateTerminated; }
    bool  running()    const { return thState==stateRunning; }
    bool  suspended()  const { return thState==stateSuspended; }
    void  run()              { fRun = true; }
    void  resume()           { fRun = true; }
    void  suspend()          { fRun = false; }

    static
    SIZE_T waitForThreads( volatile THSTATE_T *pStates
                         , SIZE_T numItems
                         , THSTATE_T waitForState
                         , bool bAll = true
                         , DWORD millisecTicks = 20
                         )
       {
        bool allGood = false;
        while(!allGood)
           {
            allGood = true;
            for(SIZE_T i=0; i!=numItems; ++i)
               {
                if (pStates[i]==waitForState && !bAll) return i; // first found item is the result
                if (pStates[i]!=waitForState)
                   {
                    allGood = false;
                    break;
                   }
               }
            if (!allGood)
               ::cli::sched::sleepMs((unsigned)millisecTicks);
           }
        return 0;
       }

    bool  mustStop()   const { return fStop; }
    RCODE getResult()  const { return resultCode; }
    TID_T getId()      const { return tid; }

    CThread( bool _selfDelete = true, volatile THSTATE_T *_pThreadState = 0, SIZE_T stackSize = 0 )
       : fStop(false)
       , fRun(false)
       //, fStopped(false)
       , thState(stateNew)
       , pThreadState(_pThreadState)
       , selfDelete(_selfDelete)
       , resultCode(0)
       , tid(0)
       , loopSleepPeriod(20)
       {
        //thState = stateNew;
        if (pThreadState) *pThreadState = thState;

        tid = cliBeginThreadEx( (unsigned)stackSize, &thread_proc, (void*)this, FALSE  /* fSuspended */ );
       }

    virtual ~CThread() {}

protected:

    void setLoopSleepPeriod(DWORD t) { loopSleepPeriod = t; }

    void suspendWait( DWORD millisecTicks = 20 )
       {
        if (!fRun)
           {
            if (thState==stateRunning) thState = stateSuspended;
            if (pThreadState) *pThreadState = thState;
           }
        else
           {
            ::cli::sched::sleepMs((unsigned)millisecTicks);
           }
        while(!fRun) ::cli::sched::sleepMs((unsigned)millisecTicks);
        thState = stateRunning;
        if (pThreadState) *pThreadState = thState;
       }

    void sleep(DWORD millisecTicks)
       {
        ::cli::sched::sleepMs((unsigned)millisecTicks);
       }

    void yield() const              { ::cli::sched::yield(); }

    virtual RCODE beforeStart()     { return 0; }
    virtual RCODE execute()
       {
        while(!mustStop())
           {
            RCODE tmp = executeLoop();
            if (tmp) return tmp;
            suspendWait( loopSleepPeriod );
            //sleep(loopSleepPeriod);
           }
        return 0;
       }
    virtual RCODE executeLoop()     { return 0; }
    virtual RCODE afterExecute()    { return 0; }


}; // class CThread







}; // namespace cli


#endif


#endif /* CLI_THREADS_H */



