#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_ISTRENC_H
#define CLI_ISTRENC_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/istrenc.h>", CLI_ISTRENC_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_ISTRENC_H
    #include <cli/istrenc.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif


/* ------------------------------------------------------ */
/* Enum: ::cli::EBomType */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)
    #define ENUM_CLI_EBOMTYPE                   UINT
#else
    #define ENUM_CLI_EBOMTYPE                   UINT
#endif

/* defines allowed both for C and C++ */

#ifndef CLI_EBOMTYPE_BOMNONE
    #define CLI_EBOMTYPE_BOMNONE              CONSTANT_UINT(0)
#endif /* CLI_EBOMTYPE_BOMNONE */

#ifndef CLI_EBOMTYPE_BOMUNKNOWN
    #define CLI_EBOMTYPE_BOMUNKNOWN           CONSTANT_UINT(0)
#endif /* CLI_EBOMTYPE_BOMUNKNOWN */

#ifndef CLI_EBOMTYPE_BOMUTF7
    #define CLI_EBOMTYPE_BOMUTF7              1
#endif /* CLI_EBOMTYPE_BOMUTF7 */

#ifndef CLI_EBOMTYPE_BOMUTF8
    #define CLI_EBOMTYPE_BOMUTF8              2
#endif /* CLI_EBOMTYPE_BOMUTF8 */

#ifndef CLI_EBOMTYPE_BOMUTF16BE
    #define CLI_EBOMTYPE_BOMUTF16BE           3
#endif /* CLI_EBOMTYPE_BOMUTF16BE */

#ifndef CLI_EBOMTYPE_BOMUTF16LE
    #define CLI_EBOMTYPE_BOMUTF16LE           4
#endif /* CLI_EBOMTYPE_BOMUTF16LE */

#ifndef CLI_EBOMTYPE_BOMUTF16
    #define CLI_EBOMTYPE_BOMUTF16             4
#endif /* CLI_EBOMTYPE_BOMUTF16 */

#ifndef CLI_EBOMTYPE_BOMUTF32BE
    #define CLI_EBOMTYPE_BOMUTF32BE           5
#endif /* CLI_EBOMTYPE_BOMUTF32BE */

#ifndef CLI_EBOMTYPE_BOMUTF32LE
    #define CLI_EBOMTYPE_BOMUTF32LE           6
#endif /* CLI_EBOMTYPE_BOMUTF32LE */

#ifndef CLI_EBOMTYPE_BOMUTF32
    #define CLI_EBOMTYPE_BOMUTF32             6
#endif /* CLI_EBOMTYPE_BOMUTF32 */


#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        namespace EBomType {
                const UINT bomNone          = CONSTANT_UINT(0);
                const UINT bomUnknown       = CONSTANT_UINT(0);
                const UINT bomUtf7          = CONSTANT_UINT(1);
                const UINT bomUtf8          = CONSTANT_UINT(2);
                const UINT bomUtf16BE       = CONSTANT_UINT(3);
                const UINT bomUtf16LE       = CONSTANT_UINT(4);
                const UINT bomUtf16         = CONSTANT_UINT(4);
                const UINT bomUtf32BE       = CONSTANT_UINT(5);
                const UINT bomUtf32LE       = CONSTANT_UINT(6);
                const UINT bomUtf32         = CONSTANT_UINT(6);
        }; // namespace EBomType
    }; // namespace cli
    /* using namespace ::cli::EBomType; */
    
#endif





/* ------------------------------------------------------ */
/* Interface: ::cli::iStringEncoder */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iStringEncoderCallback;
        #ifndef INTERFACE_CLI_ISTRINGENCODERCALLBACK
            #define INTERFACE_CLI_ISTRINGENCODERCALLBACK              ::cli::iStringEncoderCallback
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ISTRINGENCODERCALLBACK_PREDECLARED
    #define INTERFACE_CLI_ISTRINGENCODERCALLBACK_PREDECLARED
    typedef interface tag_cli_iStringEncoderCallback             cli_iStringEncoderCallback;
    #endif //INTERFACE_CLI_ISTRINGENCODERCALLBACK
    #ifndef INTERFACE_CLI_ISTRINGENCODERCALLBACK
        #define INTERFACE_CLI_ISTRINGENCODERCALLBACK              struct tag_cli_iStringEncoderCallback
    #endif

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISTRINGENCODER_IID
    #define INTERFACE_CLI_ISTRINGENCODER_IID    "/cli/iStringEncoder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iStringEncoder
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ISTRINGENCODER
       #define INTERFACE_CLI_ISTRINGENCODER    ::cli::iStringEncoder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iStringEncoder
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ISTRINGENCODER
       #define INTERFACE_CLI_ISTRINGENCODER    cli_iStringEncoder
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iStringEncoder methods */
            CLIMETHOD(encodingCanonicalNameGet) (THIS_ CLISTR*           _encodingCanonicalName) PURE;
            CLIMETHOD(encodingDescriptionGet) (THIS_ CLISTR*           _encodingDescription) PURE;
            CLIMETHOD(fromMultibyteExGet) (THIS_ CLISTR*           _fromMultibyteEx
                                               , const CLICSTR*    idx1
                                               , BOOL    idx2 /* [in] bool  idx2  */
                                          ) PURE;
            CLIMETHOD(fromMultibyteExSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(fromMultibyteExSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                                 , const CLICSTR*    idx1
                                            ) PURE;
            CLIMETHOD(fromMultibyteGet) (THIS_ CLISTR*           _fromMultibyte
                                             , const CLICSTR*    idx1
                                        ) PURE;
            CLIMETHOD(fromMultibyteSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(toMultibyteExGet) (THIS_ CLICSTR*          _toMultibyteEx
                                             , const CLISTR*     idx1
                                             , BOOL    idx2 /* [in] bool  idx2  */
                                        ) PURE;
            CLIMETHOD(toMultibyteExSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(toMultibyteExSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                               , const CLISTR*     idx1
                                          ) PURE;
            CLIMETHOD(toMultibyteGet) (THIS_ CLICSTR*          _toMultibyte
                                           , const CLISTR*     idx1
                                      ) PURE;
            CLIMETHOD(toMultibyteSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(encodeWideStringBuf) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                                , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                                , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                                , CHAR    defChar /* [in] char  defChar  */
                                                , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                                , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                                , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                           ) PURE;
            CLIMETHOD(encodeWideString) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                             , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                             , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                             , CHAR    defChar /* [in] char  defChar  */
                                             , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                             , CLICSTR*          strEncoded
                                        ) PURE;
            CLIMETHOD(encodeWideStringBufEx) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                                  , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                                  , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                                  , INTERFACE_CLI_ISTRINGENCODERCALLBACK*    callback /* [in] ::cli::iStringEncoderCallback*  callback  */
                                                  , const WCHAR*    forceCallbackForChars /* [in,flat] wchar  forceCallbackForChars[]  */
                                                  , SIZE_T    numForceCallbackForChars /* [in] size_t  numForceCallbackForChars  */
                                                  , CHAR    defChar /* [in] char  defChar  */
                                                  , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                                  , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                                  , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                             ) PURE;
            CLIMETHOD(encodeWideStringEx) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                               , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                               , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                               , INTERFACE_CLI_ISTRINGENCODERCALLBACK*    callback /* [in] ::cli::iStringEncoderCallback*  callback  */
                                               , const WCHAR*    forceCallbackForChars /* [in,flat] wchar  forceCallbackForChars[]  */
                                               , SIZE_T    numForceCallbackForChars /* [in] size_t  numForceCallbackForChars  */
                                               , CHAR    defChar /* [in] char  defChar  */
                                               , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                               , CLICSTR*          strEncoded
                                          ) PURE;
            CLIMETHOD(decodeMultibyteStringBuf) (THIS_ BOOL    precompose /* [in] bool  precompose  */
                                                     , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                                     , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                                     , WCHAR*    bufDecodeTo /* [out,flat] wchar bufDecodeTo[]  */
                                                     , SIZE_T*    bufDecodeToSize /* [in,out] size_t bufDecodeToSize  */
                                                ) PURE;
            CLIMETHOD(decodeMultibyteString) (THIS_ BOOL    precompose /* [in] bool  precompose  */
                                                  , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                                  , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                                  , CLISTR*           strDecoded
                                             ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iStringEncoder >
           {
            static char const * getName() { return INTERFACE_CLI_ISTRINGENCODER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iStringEncoder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iStringEncoder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iStringEncoder wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ISTRINGENCODER >
                                      */
                 >
        class CiStringEncoderWrapper
        {
            public:
        
                typedef  CiStringEncoderWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiStringEncoderWrapper() :
                   pif(0) {}
        
                CiStringEncoderWrapper( iStringEncoder *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiStringEncoderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiStringEncoderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiStringEncoderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiStringEncoderWrapper(const CiStringEncoderWrapper &i) :
                    pif(i.pif) { }
        
                ~CiStringEncoderWrapper()  { }
        
                CiStringEncoderWrapper& operator=(const CiStringEncoderWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_encodingCanonicalName( )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = encodingCanonicalNameGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R(wrapper_type, ::std::wstring, encodingCanonicalName );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE encodingCanonicalNameGet( ::std::wstring    &_encodingCanonicalName)
                   {
                    CCliStr tmp__encodingCanonicalName; CCliStr_init( tmp__encodingCanonicalName );
                    RCODE res = pif->encodingCanonicalNameGet(&tmp__encodingCanonicalName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _encodingCanonicalName, tmp__encodingCanonicalName);
                       }
                    return res;
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_encodingDescription( )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = encodingDescriptionGet( tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R(wrapper_type, ::std::wstring, encodingDescription );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE encodingDescriptionGet( ::std::wstring    &_encodingDescription)
                   {
                    CCliStr tmp__encodingDescription; CCliStr_init( tmp__encodingDescription );
                    RCODE res = pif->encodingDescriptionGet(&tmp__encodingDescription);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _encodingDescription, tmp__encodingDescription);
                       }
                    return res;
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_fromMultibyteEx( const ::std::string &idx1
                                                  , BOOL idx2
                                                  )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = fromMultibyteExGet( tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size1_fromMultibyteEx(  )
                   {
                    SIZE_T size;
                    RCODE res = fromMultibyteExSize1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_fromMultibyteEx( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = fromMultibyteExSize2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, ::std::wstring, fromMultibyteEx, ::std::string, BOOL );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE fromMultibyteExGet( ::std::wstring    &_fromMultibyteEx
                                        , const ::std::string    &idx1
                                        , BOOL    idx2 /* [in] bool  idx2  */
                                        )
                   {
                    CCliStr tmp__fromMultibyteEx; CCliStr_init( tmp__fromMultibyteEx );
                    CCliCStr tmp_idx1; CCliCStr_lightCopyTo( tmp_idx1, idx1);
                
                    RCODE res = pif->fromMultibyteExGet(&tmp__fromMultibyteEx, &tmp_idx1, idx2);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _fromMultibyteEx, tmp__fromMultibyteEx);
                       }
                    return res;
                   }
                
                RCODE fromMultibyteExSize1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->fromMultibyteExSize1(_size);
                   }
                
                RCODE fromMultibyteExSize2( SIZE_T*    _size /* [out] size_t _size  */
                                          , const ::std::string    &idx1
                                          )
                   {
                
                    CCliCStr tmp_idx1; CCliCStr_lightCopyTo( tmp_idx1, idx1);
                    return pif->fromMultibyteExSize2(_size, &tmp_idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_fromMultibyte( const ::std::string &idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = fromMultibyteGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_fromMultibyte(  )
                   {
                    SIZE_T size;
                    RCODE res = fromMultibyteSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, fromMultibyte, ::std::string );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE fromMultibyteGet( ::std::wstring    &_fromMultibyte
                                      , const ::std::string    &idx1
                                      )
                   {
                    CCliStr tmp__fromMultibyte; CCliStr_init( tmp__fromMultibyte );
                    CCliCStr tmp_idx1; CCliCStr_lightCopyTo( tmp_idx1, idx1);
                    RCODE res = pif->fromMultibyteGet(&tmp__fromMultibyte, &tmp_idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _fromMultibyte, tmp__fromMultibyte);
                       }
                    return res;
                   }
                
                RCODE fromMultibyteSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->fromMultibyteSize(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::string get_toMultibyteEx( const ::std::wstring &idx1
                                               , BOOL idx2
                                               )
                   {
                    ::std::string tmpVal;
                    RCODE res = toMultibyteExGet( tmpVal, idx1, idx2);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size1_toMultibyteEx(  )
                   {
                    SIZE_T size;
                    RCODE res = toMultibyteExSize1( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                SIZE_T size2_toMultibyteEx( SIZE_T idx1 )
                   {
                    SIZE_T size;
                    RCODE res = toMultibyteExSize2( &size, idx1 );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX2(wrapper_type, ::std::string, toMultibyteEx, ::std::wstring, BOOL );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE toMultibyteExGet( ::std::string    &_toMultibyteEx
                                      , const ::std::wstring    &idx1
                                      , BOOL    idx2 /* [in] bool  idx2  */
                                      )
                   {
                    CCliCStr tmp__toMultibyteEx; CCliCStr_init( tmp__toMultibyteEx );
                    CCliStr tmp_idx1; CCliStr_lightCopyTo( tmp_idx1, idx1);
                
                    RCODE res = pif->toMultibyteExGet(&tmp__toMultibyteEx, &tmp_idx1, idx2);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( _toMultibyteEx, tmp__toMultibyteEx);
                       }
                    return res;
                   }
                
                RCODE toMultibyteExSize1( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->toMultibyteExSize1(_size);
                   }
                
                RCODE toMultibyteExSize2( SIZE_T*    _size /* [out] size_t _size  */
                                        , const ::std::wstring    &idx1
                                        )
                   {
                
                    CCliStr tmp_idx1; CCliStr_lightCopyTo( tmp_idx1, idx1);
                    return pif->toMultibyteExSize2(_size, &tmp_idx1);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::string get_toMultibyte( const ::std::wstring &idx1 )
                   {
                    ::std::string tmpVal;
                    RCODE res = toMultibyteGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_toMultibyte(  )
                   {
                    SIZE_T size;
                    RCODE res = toMultibyteSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::string, toMultibyte, ::std::wstring );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE toMultibyteGet( ::std::string    &_toMultibyte
                                    , const ::std::wstring    &idx1
                                    )
                   {
                    CCliCStr tmp__toMultibyte; CCliCStr_init( tmp__toMultibyte );
                    CCliStr tmp_idx1; CCliStr_lightCopyTo( tmp_idx1, idx1);
                    RCODE res = pif->toMultibyteGet(&tmp__toMultibyte, &tmp_idx1);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( _toMultibyte, tmp__toMultibyte);
                       }
                    return res;
                   }
                
                RCODE toMultibyteSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->toMultibyteSize(_size);
                   }
                
                RCODE encodeWideStringBuf( BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                         , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                         , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                         , CHAR    defChar /* [in] char  defChar  */
                                         , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                         , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                         , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                         )
                   {
                
                
                
                
                
                
                
                    return pif->encodeWideStringBuf(compositeCheck, strToEncode, numCharsToEncode, defChar, defCharUsed, bufEncodeTo, bufEncodeToSize);
                   }
                
                RCODE encodeWideString( BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                      , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                      , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                      , CHAR    defChar /* [in] char  defChar  */
                                      , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                      , ::std::string    &strEncoded
                                      )
                   {
                
                
                
                
                
                    CCliCStr tmp_strEncoded; CCliCStr_init( tmp_strEncoded );
                    RCODE res = pif->encodeWideString(compositeCheck, strToEncode, numCharsToEncode, defChar, defCharUsed, &tmp_strEncoded);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( strEncoded, tmp_strEncoded);
                       }
                    return res;
                   }
                
                RCODE encodeWideStringBufEx( BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                           , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                           , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                           , INTERFACE_CLI_ISTRINGENCODERCALLBACK*    callback /* [in] ::cli::iStringEncoderCallback*  callback  */
                                           , const WCHAR*    forceCallbackForChars /* [in,flat] wchar  forceCallbackForChars[]  */
                                           , SIZE_T    numForceCallbackForChars /* [in] size_t  numForceCallbackForChars  */
                                           , CHAR    defChar /* [in] char  defChar  */
                                           , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                           , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                           , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                           )
                   {
                
                
                
                
                
                
                
                
                
                
                    return pif->encodeWideStringBufEx(compositeCheck, strToEncode, numCharsToEncode, callback, forceCallbackForChars, numForceCallbackForChars, defChar, defCharUsed, bufEncodeTo, bufEncodeToSize);
                   }
                
                RCODE encodeWideStringEx( BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                        , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                        , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                        , INTERFACE_CLI_ISTRINGENCODERCALLBACK*    callback /* [in] ::cli::iStringEncoderCallback*  callback  */
                                        , const WCHAR*    forceCallbackForChars /* [in,flat] wchar  forceCallbackForChars[]  */
                                        , SIZE_T    numForceCallbackForChars /* [in] size_t  numForceCallbackForChars  */
                                        , CHAR    defChar /* [in] char  defChar  */
                                        , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                        , ::std::string    &strEncoded
                                        )
                   {
                
                
                
                
                
                
                
                
                    CCliCStr tmp_strEncoded; CCliCStr_init( tmp_strEncoded );
                    RCODE res = pif->encodeWideStringEx(compositeCheck, strToEncode, numCharsToEncode, callback, forceCallbackForChars, numForceCallbackForChars, defChar, defCharUsed, &tmp_strEncoded);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( strEncoded, tmp_strEncoded);
                       }
                    return res;
                   }
                
                RCODE decodeMultibyteStringBuf( BOOL    precompose /* [in] bool  precompose  */
                                              , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                              , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                              , WCHAR*    bufDecodeTo /* [out,flat] wchar bufDecodeTo[]  */
                                              , SIZE_T*    bufDecodeToSize /* [in,out] size_t bufDecodeToSize  */
                                              )
                   {
                
                
                
                
                
                    return pif->decodeMultibyteStringBuf(precompose, strToDecode, numCharsToDecode, bufDecodeTo, bufDecodeToSize);
                   }
                
                RCODE decodeMultibyteString( BOOL    precompose /* [in] bool  precompose  */
                                           , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                           , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                           , ::std::wstring    &strDecoded
                                           )
                   {
                
                
                
                    CCliStr tmp_strDecoded; CCliStr_init( tmp_strDecoded );
                    RCODE res = pif->decodeMultibyteString(precompose, strToDecode, numCharsToDecode, &tmp_strDecoded);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( strDecoded, tmp_strDecoded);
                       }
                    return res;
                   }
                

        
        
        }; // class CiStringEncoderWrapper
        
        typedef CiStringEncoderWrapper< ::cli::CCliPtr< INTERFACE_CLI_ISTRINGENCODER     > >  CiStringEncoder;
        typedef CiStringEncoderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTRINGENCODER > >  CiStringEncoder_nrc; /* No ref counting for interface used */
        typedef CiStringEncoderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTRINGENCODER > >  CiStringEncoder_tmp; /* for temporary usage, same as CiStringEncoder_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iStringEncoderManager */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iStringEncoder;
        #ifndef INTERFACE_CLI_ISTRINGENCODER
            #define INTERFACE_CLI_ISTRINGENCODER      ::cli::iStringEncoder
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_ISTRINGENCODER_PREDECLARED
    #define INTERFACE_CLI_ISTRINGENCODER_PREDECLARED
    typedef interface tag_cli_iStringEncoder cli_iStringEncoder;
    #endif //INTERFACE_CLI_ISTRINGENCODER
    #ifndef INTERFACE_CLI_ISTRINGENCODER
        #define INTERFACE_CLI_ISTRINGENCODER      struct tag_cli_iStringEncoder
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISTRINGENCODERMANAGER_IID
    #define INTERFACE_CLI_ISTRINGENCODERMANAGER_IID    "/cli/iStringEncoderManager"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iStringEncoderManager
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ISTRINGENCODERMANAGER
       #define INTERFACE_CLI_ISTRINGENCODERMANAGER    ::cli::iStringEncoderManager
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iStringEncoderManager
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ISTRINGENCODERMANAGER
       #define INTERFACE_CLI_ISTRINGENCODERMANAGER    cli_iStringEncoderManager
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iStringEncoderManager methods */
            CLIMETHOD(encodingCanonicalNameGet) (THIS_ CLISTR*           _encodingCanonicalName
                                                     , UINT    idx1 /* [in] uint  idx1  */
                                                ) PURE;
            CLIMETHOD(encodingCanonicalNameSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(encodingDescriptionGet) (THIS_ CLISTR*           _encodingDescription
                                                   , UINT    idx1 /* [in] uint  idx1  */
                                              ) PURE;
            CLIMETHOD(encodingDescriptionSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */) PURE;
            CLIMETHOD(getEncodingIdByName) (THIS_ const CLISTR*     encodingName
                                                , UINT*    id /* [out] uint id  */
                                           ) PURE;
            CLIMETHOD(getEncodingIdByNameChars) (THIS_ const WCHAR*    encodingName /* [in,flat] wchar  encodingName[]  */
                                                     , UINT*    id /* [out] uint id  */
                                                ) PURE;
            CLIMETHOD(getEncodingIdByMultibyteName) (THIS_ const CLICSTR*    encodingName
                                                         , UINT*    id /* [out] uint id  */
                                                    ) PURE;
            CLIMETHOD(getEncodingIdByMultibyteNameChars) (THIS_ const CHAR*    encodingName /* [in,flat] char  encodingName[]  */
                                                              , UINT*    id /* [out] uint id  */
                                                         ) PURE;
            CLIMETHOD(getStringEncoder) (THIS_ UINT    encId /* [in] uint  encId  */
                                             , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                        ) PURE;
            CLIMETHOD(getStringEncoderByName) (THIS_ const CLISTR*     encodingName
                                                   , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                              ) PURE;
            CLIMETHOD(getStringEncoderByMultibyteName) (THIS_ const CLICSTR*    encodingName
                                                            , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                                       ) PURE;
            CLIMETHOD(detectBomBuf) (THIS_ ENUM_CLI_EBOMTYPE*    bomType /* [out] ::cli::EBomType bomType  */
                                         , SIZE_T*    bomSize /* [out,optional] size_t bomSize  */
                                         , const CHAR*    docData /* [in,flat] char  docData[]  */
                                         , SIZE_T    docDataSize /* [in] size_t  docDataSize  */
                                    ) PURE;
            CLIMETHOD(detectBom) (THIS_ ENUM_CLI_EBOMTYPE*    bomType /* [out] ::cli::EBomType bomType  */
                                      , SIZE_T*    bomSize /* [out,optional] size_t bomSize  */
                                      , const CLICSTR*    docData
                                 ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iStringEncoderManager >
           {
            static char const * getName() { return INTERFACE_CLI_ISTRINGENCODERMANAGER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iStringEncoderManager* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iStringEncoderManager > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iStringEncoderManager wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ISTRINGENCODERMANAGER >
                                      */
                 >
        class CiStringEncoderManagerWrapper
        {
            public:
        
                typedef  CiStringEncoderManagerWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiStringEncoderManagerWrapper() :
                   pif(0) {}
        
                CiStringEncoderManagerWrapper( iStringEncoderManager *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiStringEncoderManagerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiStringEncoderManagerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiStringEncoderManagerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiStringEncoderManagerWrapper(const CiStringEncoderManagerWrapper &i) :
                    pif(i.pif) { }
        
                ~CiStringEncoderManagerWrapper()  { }
        
                CiStringEncoderManagerWrapper& operator=(const CiStringEncoderManagerWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_encodingCanonicalName( UINT idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = encodingCanonicalNameGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_encodingCanonicalName(  )
                   {
                    SIZE_T size;
                    RCODE res = encodingCanonicalNameSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, encodingCanonicalName, UINT );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE encodingCanonicalNameGet( ::std::wstring    &_encodingCanonicalName
                                              , UINT    idx1 /* [in] uint  idx1  */
                                              )
                   {
                    CCliStr tmp__encodingCanonicalName; CCliStr_init( tmp__encodingCanonicalName );
                
                    RCODE res = pif->encodingCanonicalNameGet(&tmp__encodingCanonicalName, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _encodingCanonicalName, tmp__encodingCanonicalName);
                       }
                    return res;
                   }
                
                RCODE encodingCanonicalNameSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->encodingCanonicalNameSize(_size);
                   }
                
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                ::std::wstring get_encodingDescription( UINT idx1 )
                   {
                    ::std::wstring tmpVal;
                    RCODE res = encodingDescriptionGet( tmpVal, idx1);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                SIZE_T size_encodingDescription(  )
                   {
                    SIZE_T size;
                    RCODE res = encodingDescriptionSize( &size );
                    CLI_CHECK_PROPERTY_SIZE_RESULT(res);
                    return size;
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_R_IDX1(wrapper_type, ::std::wstring, encodingDescription, UINT );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE encodingDescriptionGet( ::std::wstring    &_encodingDescription
                                            , UINT    idx1 /* [in] uint  idx1  */
                                            )
                   {
                    CCliStr tmp__encodingDescription; CCliStr_init( tmp__encodingDescription );
                
                    RCODE res = pif->encodingDescriptionGet(&tmp__encodingDescription, idx1);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( _encodingDescription, tmp__encodingDescription);
                       }
                    return res;
                   }
                
                RCODE encodingDescriptionSize( SIZE_T*    _size /* [out] size_t _size  */)
                   {
                
                    return pif->encodingDescriptionSize(_size);
                   }
                
                RCODE getEncodingIdByName( const ::std::wstring    &encodingName
                                         , UINT*    id /* [out] uint id  */
                                         )
                   {
                    CCliStr tmp_encodingName; CCliStr_lightCopyTo( tmp_encodingName, encodingName);
                
                    return pif->getEncodingIdByName(&tmp_encodingName, id);
                   }
                
                RCODE getEncodingIdByNameChars( const WCHAR*    encodingName /* [in,flat] wchar  encodingName[]  */
                                              , UINT*    id /* [out] uint id  */
                                              )
                   {
                
                
                    return pif->getEncodingIdByNameChars(encodingName, id);
                   }
                
                RCODE getEncodingIdByMultibyteName( const ::std::string    &encodingName
                                                  , UINT*    id /* [out] uint id  */
                                                  )
                   {
                    CCliCStr tmp_encodingName; CCliCStr_lightCopyTo( tmp_encodingName, encodingName);
                
                    return pif->getEncodingIdByMultibyteName(&tmp_encodingName, id);
                   }
                
                RCODE getEncodingIdByMultibyteNameChars( const CHAR*    encodingName /* [in,flat] char  encodingName[]  */
                                                       , UINT*    id /* [out] uint id  */
                                                       )
                   {
                
                
                    return pif->getEncodingIdByMultibyteNameChars(encodingName, id);
                   }
                
                RCODE getStringEncoder( UINT    encId /* [in] uint  encId  */
                                      , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                      )
                   {
                
                
                    return pif->getStringEncoder(encId, pStringEncoder);
                   }
                
                RCODE getStringEncoderByName( const ::std::wstring    &encodingName
                                            , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                            )
                   {
                    CCliStr tmp_encodingName; CCliStr_lightCopyTo( tmp_encodingName, encodingName);
                
                    return pif->getStringEncoderByName(&tmp_encodingName, pStringEncoder);
                   }
                
                RCODE getStringEncoderByMultibyteName( const ::std::string    &encodingName
                                                     , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                                     )
                   {
                    CCliCStr tmp_encodingName; CCliCStr_lightCopyTo( tmp_encodingName, encodingName);
                
                    return pif->getStringEncoderByMultibyteName(&tmp_encodingName, pStringEncoder);
                   }
                
                RCODE detectBomBuf( ENUM_CLI_EBOMTYPE*    bomType /* [out] ::cli::EBomType bomType  */
                                  , SIZE_T*    bomSize /* [out,optional] size_t bomSize  */
                                  , const CHAR*    docData /* [in,flat] char  docData[]  */
                                  , SIZE_T    docDataSize /* [in] size_t  docDataSize  */
                                  )
                   {
                
                
                
                
                    return pif->detectBomBuf(bomType, bomSize, docData, docDataSize);
                   }
                
                RCODE detectBom( ENUM_CLI_EBOMTYPE*    bomType /* [out] ::cli::EBomType bomType  */
                               , SIZE_T*    bomSize /* [out,optional] size_t bomSize  */
                               , const ::std::string    &docData
                               )
                   {
                
                
                    CCliCStr tmp_docData; CCliCStr_lightCopyTo( tmp_docData, docData);
                    return pif->detectBom(bomType, bomSize, &tmp_docData);
                   }
                

        
        
        }; // class CiStringEncoderManagerWrapper
        
        typedef CiStringEncoderManagerWrapper< ::cli::CCliPtr< INTERFACE_CLI_ISTRINGENCODERMANAGER     > >  CiStringEncoderManager;
        typedef CiStringEncoderManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTRINGENCODERMANAGER > >  CiStringEncoderManager_nrc; /* No ref counting for interface used */
        typedef CiStringEncoderManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTRINGENCODERMANAGER > >  CiStringEncoderManager_tmp; /* for temporary usage, same as CiStringEncoderManager_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iStringEncoderCallback */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISTRINGENCODERCALLBACK_IID
    #define INTERFACE_CLI_ISTRINGENCODERCALLBACK_IID    "/cli/iStringEncoderCallback"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iStringEncoderCallback
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ISTRINGENCODERCALLBACK
       #define INTERFACE_CLI_ISTRINGENCODERCALLBACK    ::cli::iStringEncoderCallback
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iStringEncoderCallback
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ISTRINGENCODERCALLBACK
       #define INTERFACE_CLI_ISTRINGENCODERCALLBACK    cli_iStringEncoderCallback
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iStringEncoderCallback methods */
            CLIMETHOD(getSpecialReplaceChars) (THIS_ INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                                   , const WCHAR*    strWideChars /* [in,flat] wchar  strWideChars[]  */
                                                   , SIZE_T    numWideChars /* [in] size_t  numWideChars  */
                                                   , WCHAR*    bufEncodeTo /* [out,flat] wchar bufEncodeTo[]  */
                                                   , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                              ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iStringEncoderCallback >
           {
            static char const * getName() { return INTERFACE_CLI_ISTRINGENCODERCALLBACK_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iStringEncoderCallback* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iStringEncoderCallback > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iStringEncoderCallback wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ISTRINGENCODERCALLBACK >
                                      */
                 >
        class CiStringEncoderCallbackWrapper
        {
            public:
        
                typedef  CiStringEncoderCallbackWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiStringEncoderCallbackWrapper() :
                   pif(0) {}
        
                CiStringEncoderCallbackWrapper( iStringEncoderCallback *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiStringEncoderCallbackWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiStringEncoderCallbackWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiStringEncoderCallbackWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiStringEncoderCallbackWrapper(const CiStringEncoderCallbackWrapper &i) :
                    pif(i.pif) { }
        
                ~CiStringEncoderCallbackWrapper()  { }
        
                CiStringEncoderCallbackWrapper& operator=(const CiStringEncoderCallbackWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                RCODE getSpecialReplaceChars( INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                            , const WCHAR*    strWideChars /* [in,flat] wchar  strWideChars[]  */
                                            , SIZE_T    numWideChars /* [in] size_t  numWideChars  */
                                            , WCHAR*    bufEncodeTo /* [out,flat] wchar bufEncodeTo[]  */
                                            , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                            )
                   {
                
                
                
                
                
                    return pif->getSpecialReplaceChars(pEncoder, strWideChars, numWideChars, bufEncodeTo, bufEncodeToSize);
                   }
                

        
        
        }; // class CiStringEncoderCallbackWrapper
        
        typedef CiStringEncoderCallbackWrapper< ::cli::CCliPtr< INTERFACE_CLI_ISTRINGENCODERCALLBACK     > >  CiStringEncoderCallback;
        typedef CiStringEncoderCallbackWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTRINGENCODERCALLBACK > >  CiStringEncoderCallback_nrc; /* No ref counting for interface used */
        typedef CiStringEncoderCallbackWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTRINGENCODERCALLBACK > >  CiStringEncoderCallback_tmp; /* for temporary usage, same as CiStringEncoderCallback_nrc */
        
        
        
        
        
    }; // namespace cli

#endif






/* ------------------------------------------------------ */
/* Interface: ::cli::iStringSpecialEncoder */
/* ------------------------------------------------------ */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ISTRINGSPECIALENCODER_IID
    #define INTERFACE_CLI_ISTRINGSPECIALENCODER_IID    "/cli/iStringSpecialEncoder"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iStringSpecialEncoder
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ISTRINGSPECIALENCODER
       #define INTERFACE_CLI_ISTRINGSPECIALENCODER    ::cli::iStringSpecialEncoder
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iStringSpecialEncoder
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ISTRINGSPECIALENCODER
       #define INTERFACE_CLI_ISTRINGSPECIALENCODER    cli_iStringSpecialEncoder
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iStringSpecialEncoder methods */
            CLIMETHOD(defEncoderGet) (THIS_ INTERFACE_CLI_ISTRINGENCODER**    _defEncoder /* [out] ::cli::iStringEncoder* _defEncoder  */) PURE;
            CLIMETHOD(defEncoderSet) (THIS_ INTERFACE_CLI_ISTRINGENCODER*    _defEncoder /* [in] ::cli::iStringEncoder*  _defEncoder  */) PURE;
            CLIMETHOD(addEntity) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                      , const WCHAR*    val /* [in,flat] wchar  val[]  */
                                 ) PURE;
            CLIMETHOD(encodeWideStringBuf) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                                , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                                , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                                , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                                , CHAR    defChar /* [in] char  defChar  */
                                                , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                                , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                                , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                           ) PURE;
            CLIMETHOD(encodeWideString) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                             , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                             , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                             , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                             , CHAR    defChar /* [in] char  defChar  */
                                             , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                             , CLICSTR*          strEncoded
                                        ) PURE;
            CLIMETHOD(decodeMultibyteStringBuf) (THIS_ BOOL    precompose /* [in] bool  precompose  */
                                                     , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                                     , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                                     , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                                     , WCHAR*    bufDecodeTo /* [out,flat] wchar bufDecodeTo[]  */
                                                     , SIZE_T*    bufDecodeToSize /* [in,out] size_t bufDecodeToSize  */
                                                ) PURE;
            CLIMETHOD(decodeMultibyteString) (THIS_ BOOL    precompose /* [in] bool  precompose  */
                                                  , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                                  , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                                  , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                                  , CLISTR*           strDecoded
                                             ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iStringSpecialEncoder >
           {
            static char const * getName() { return INTERFACE_CLI_ISTRINGSPECIALENCODER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iStringSpecialEncoder* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iStringSpecialEncoder > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iStringSpecialEncoder wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ISTRINGSPECIALENCODER >
                                      */
                 >
        class CiStringSpecialEncoderWrapper
        {
            public:
        
                typedef  CiStringSpecialEncoderWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiStringSpecialEncoderWrapper() :
                   pif(0) {}
        
                CiStringSpecialEncoderWrapper( iStringSpecialEncoder *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiStringSpecialEncoderWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiStringSpecialEncoderWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiStringSpecialEncoderWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiStringSpecialEncoderWrapper(const CiStringSpecialEncoderWrapper &i) :
                    pif(i.pif) { }
        
                ~CiStringSpecialEncoderWrapper()  { }
        
                CiStringSpecialEncoderWrapper& operator=(const CiStringSpecialEncoderWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                
                INTERFACE_CLI_ISTRINGENCODER* get_defEncoder( )
                   {
                    INTERFACE_CLI_ISTRINGENCODER* tmpVal;
                    RCODE res = defEncoderGet( &tmpVal);
                    CLI_CHECK_GET_PROPERTY_RESULT(res);
                    return tmpVal;
                   }
                
                void set_defEncoder( INTERFACE_CLI_ISTRINGENCODER* _defEncoder
                                   )
                   {
                    RCODE res = defEncoderSet( _defEncoder );
                    CLI_CHECK_SET_PROPERTY_RESULT(res);
                   }
                
                #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                   By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                CLI_DECLARE_PROPERTY_RW(wrapper_type, INTERFACE_CLI_ISTRINGENCODER*, defEncoder );
                #endif /* CLI_WRAPPER_NO_PROPERTIES */
                
                #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                
                
                RCODE defEncoderGet( INTERFACE_CLI_ISTRINGENCODER**    _defEncoder /* [out] ::cli::iStringEncoder* _defEncoder  */)
                   {
                
                    return pif->defEncoderGet(_defEncoder);
                   }
                
                RCODE defEncoderSet( INTERFACE_CLI_ISTRINGENCODER*    _defEncoder /* [in] ::cli::iStringEncoder*  _defEncoder  */)
                   {
                
                    return pif->defEncoderSet(_defEncoder);
                   }
                
                RCODE addEntity( const WCHAR*    name /* [in,flat] wchar  name[]  */
                               , const WCHAR*    val /* [in,flat] wchar  val[]  */
                               )
                   {
                
                
                    return pif->addEntity(name, val);
                   }
                
                RCODE encodeWideStringBuf( BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                         , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                         , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                         , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                         , CHAR    defChar /* [in] char  defChar  */
                                         , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                         , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                         , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                         )
                   {
                
                
                
                
                
                
                
                
                    return pif->encodeWideStringBuf(compositeCheck, strToEncode, numCharsToEncode, pEncoder, defChar, defCharUsed, bufEncodeTo, bufEncodeToSize);
                   }
                
                RCODE encodeWideString( BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                      , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                      , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                      , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                      , CHAR    defChar /* [in] char  defChar  */
                                      , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                      , ::std::string    &strEncoded
                                      )
                   {
                
                
                
                
                
                
                    CCliCStr tmp_strEncoded; CCliCStr_init( tmp_strEncoded );
                    RCODE res = pif->encodeWideString(compositeCheck, strToEncode, numCharsToEncode, pEncoder, defChar, defCharUsed, &tmp_strEncoded);
                    if (RCOK(res))
                       {
                        CCliCStr_copyFromIfModified( strEncoded, tmp_strEncoded);
                       }
                    return res;
                   }
                
                RCODE decodeMultibyteStringBuf( BOOL    precompose /* [in] bool  precompose  */
                                              , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                              , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                              , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                              , WCHAR*    bufDecodeTo /* [out,flat] wchar bufDecodeTo[]  */
                                              , SIZE_T*    bufDecodeToSize /* [in,out] size_t bufDecodeToSize  */
                                              )
                   {
                
                
                
                
                
                
                    return pif->decodeMultibyteStringBuf(precompose, strToDecode, numCharsToDecode, pEncoder, bufDecodeTo, bufDecodeToSize);
                   }
                
                RCODE decodeMultibyteString( BOOL    precompose /* [in] bool  precompose  */
                                           , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                           , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                           , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                           , ::std::wstring    &strDecoded
                                           )
                   {
                
                
                
                
                    CCliStr tmp_strDecoded; CCliStr_init( tmp_strDecoded );
                    RCODE res = pif->decodeMultibyteString(precompose, strToDecode, numCharsToDecode, pEncoder, &tmp_strDecoded);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( strDecoded, tmp_strDecoded);
                       }
                    return res;
                   }
                

        
        
        }; // class CiStringSpecialEncoderWrapper
        
        typedef CiStringSpecialEncoderWrapper< ::cli::CCliPtr< INTERFACE_CLI_ISTRINGSPECIALENCODER     > >  CiStringSpecialEncoder;
        typedef CiStringSpecialEncoderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTRINGSPECIALENCODER > >  CiStringSpecialEncoder_nrc; /* No ref counting for interface used */
        typedef CiStringSpecialEncoderWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ISTRINGSPECIALENCODER > >  CiStringSpecialEncoder_tmp; /* for temporary usage, same as CiStringSpecialEncoder_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_ISTRENC_H */
