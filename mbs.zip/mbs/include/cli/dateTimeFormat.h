#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_DATETIMEFORMAT_H
#define CLI_DATETIMEFORMAT_H

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

/*

see also http://kozhanov.boom.ru/articles/Cyrillic-HOWTO/Cyrillic-HOWTO-russian-11.html

short-date             see DATE_SHORTDATE
short-time             see DATE_LONGDATE
short-datetime
long-date
long-time
long-datetime

LOCALE_SABBREVMONTHNAME
LOCALE_SMONTHNAME
LOCALE_SABBREVDAYNAME
LOCALE_SDAYNAME
*/


/*
------------------------------------------------------------
Date and time format picture string to use to form date/time.
Format string syntax based on WinAPI functions GetDateFormat/GetTimeFormat format string.

Note: single quotation mark (') turn off format string parsing and place all chars as is to destination, 
next single quot turns parsing on. 
  To place quot in quoted string, duplicate it: 'don''t'. 
  To place single quot use '''' sequence.


Date format
?        This symbol simple ignored
_        System date separator
D        Day of month as digits with no leading zero for single-digit days. 
Dd       Day of month as digits with leading zero for single-digit days. 
Ddd      Day of week as a three-letter abbreviation. The function uses value 
         associated with the current locale. 
Dddd     Day of week as its full name. The function uses the value 
         associated with the current locale. 
----- CLI Extention -----
d        same as D    (adds Qt format compatibility)
dd       same as Dd   (adds Qt format compatibility)
ddd      same as Ddd  (adds Qt format compatibility)
dddd     same as Dddd (adds Qt format compatibility)
dde,Dde  Day of week as a three-letter abbreviation (English).
ddde,Ddde Day of week as its full name (English).
e        same as d, D
ee       same as dd, Dd
eee      same as dde, Dde
eeee     same as ddde, Ddde
--- CLI Extention ends --

M        Month as digits with no leading zero for single-digit months. 
MM       Month as digits with leading zero for single-digit months. 
MMM      Month as a three-letter abbreviation. The function uses value associated with the current locale. 
MMMM     Month as its full name. The function uses value associated with the current locale. 
----- CLI Extention -----
E        Month as digits with no leading zero for single-digit months (same as M). 
EE       Month as digits with leading zero for single-digit months (same as MM). 
EEE      Month as a three-letter abbreviation (English). 
EEEE     Month as its full name (English).
ME       same as EE
MME      same as EEE
MMME     same as EEEE
         value associated with the specified locale. 
--- CLI Extention ends --
y        Year as last two digits, with a leading zero for years less 
         than 10. The same format as "yy".
yy       Year as last two digits, with a leading zero for years less than 10. 
yyyy     Year represented by full four digits, with a leading space for years less than 1000. 
----- CLI Extention -----
yyy      Year represented by 1, 2, 3 or 4 digits
--- CLI Extention ends --


Time format

?        This symbol simple ignored
=        System time separator
h        Hours with no leading zero for single-digit hours; 12-hour clock. 
hh       Hours with leading zero for single-digit hours; 12-hour clock. 
H        Hours with no leading zero for single-digit hours; 24-hour clock. 
HH       Hours with leading zero for single-digit hours; 24-hour clock. 
m        Minutes with no leading zero for single-digit minutes. 
mm       Minutes with leading zero for single-digit minutes. 
s        Seconds with no leading zero for single-digit seconds. 
ss       Seconds with leading zero for single-digit seconds. 
t        One character time-marker string, such as 'A' or 'P'
tt       Multicharacter time-marker string, such as 'AM' or 'PM' (originally AM/PM). 
----- CLI Extention -----
T        One character time-marker string, such as 'a' or 'p'. 
TT       Multicharacter time-marker string, such as 'am' or 'pm'. 
tT       same as tt
Tt       same as TT
AP       same as tt
ap       same as TT
c,z            tenth of second        (0)
cc,zz          1/100 of second        (1)
ccc,zzz        milliseconds           (2)
cccc,zzzz      microseconds           (6)
ccccc,zzzzz    microseconds           (6)
cccccc,zzzzzz  microseconds           (6)
C,Z,CC,ZZ and same - same as above, but no leading zeros added

gmOffset field
u        +3
uu       +03
uuu      +3:30
uuuu     +03:30

U,UU,UUU,UUUU  - format local GMT offset same as u,uu,uuu,uuuu

--- CLI Extention ends --



------------------------------------------------------------
Time intervals format picture string.

+        Force add + or - sign at start
-        Force remove + or - sign from start
         Default: auto - show only - if needed

h        Hours with no leading zero for single-digit hours, 24 hours module
hh       Hours with leading zero for single-digit hours; 24 hours module
hhh      Hours with no leading zero, total.

w        Number of weeks, with no leading zero for single-digit week number, 7 day week module
ww       Number of weeks, with leading zero for single-digit week number, 7 day week module
www      Number of weeks, total

m,mm,mmm minutes in same format as hours/weeks
s,ss,sss seconds in same format as hours/weeks

c,z            tenth of second        (0)
cc,zz          1/100 of second        (1)
ccc,zzz        milliseconds           (2)
cccc,zzzz      microseconds           (6)
ccccc,zzzzz    microseconds           (6)
cccccc,zzzzzz  microseconds           (6)
C,Z,CC,ZZ and same - same as above, but no leading zeros added

*/

EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliFormatDateTime( WCHAR*    charBuf
                 , SIZE_T   *charBufSize
                 , const WCHAR*    fmtStrChars
                 , SIZE_T    fmtStrCharsSize
                 , const STRUCT_CLI_CLISYSTEMTIME *pDateTime
                 );


#ifdef __cplusplus

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifdef WIN32
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else /* __GNUC__ */
     #include <alloca.h>
     #ifndef _alloca
         #define _alloca  alloca
     #endif
#endif


namespace cli
{
namespace format
{

inline
::std::wstring formatDateTime( const ::std::wstring     &dtFormat
                             , const STRUCT_CLI_CLISYSTEMTIME &dt
                             )
   {
    if (dtFormat.empty()) return ::std::wstring(L"");

    SIZE_T curSize = 128; // enough for most cases
    WCHAR *pResultBuf = 0; // (WCHAR*)_alloca(curSize*sizeof(WCHAR));
    SIZE_T resultSize = 0;

    RCODE res = EC_OK;
    do {
        curSize <<=2;
        pResultBuf = (WCHAR*)_alloca(curSize*sizeof(WCHAR));

        resultSize = curSize;
        res = cliFormatDateTime( pResultBuf
                               , &resultSize
                               , dtFormat.c_str()
                               , dtFormat.size()
                               , &dt
                               );
       } while( res==EC_NOT_ENOUGH_MEM );
    if (res==EC_OK)
       return ::std::wstring(pResultBuf, resultSize);
    else
       return ::std::wstring(L"");
   }






}; // namespace format
}; // namespace cli

#endif




#endif /* CLI_DATETIMEFORMAT_H */

