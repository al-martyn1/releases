#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_CORESERVICES_H
#define CLI_CORESERVICES_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/coreservices.h>", CLI_CORESERVICES_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_CORESERVICES_H
    #include <cli/coreservices.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_ITAG_H
    #include <cli/itag.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_IOBJLIST_H
    #include <cli/iobjlist.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif

#ifndef CLI_IRES_H
    #include <cli/ires.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::iComponentManager */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; // namespace cli

#else /* C-like declarations */

    #ifndef INTERFACE_CLI_IUNKNOWN_PREDECLARED
    #define INTERFACE_CLI_IUNKNOWN_PREDECLARED
    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #endif //INTERFACE_CLI_IUNKNOWN
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_ICOMPONENTMANAGER_IID
    #define INTERFACE_CLI_ICOMPONENTMANAGER_IID    "/cli/iComponentManager"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
    #define INTERFACE iComponentManager
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_ICOMPONENTMANAGER
       #define INTERFACE_CLI_ICOMPONENTMANAGER    ::cli::iComponentManager
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_iComponentManager
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_ICOMPONENTMANAGER
       #define INTERFACE_CLI_ICOMPONENTMANAGER    cli_iComponentManager
    #endif
#endif

        CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
        {
            
            /* interface ::cli::iUnknown methods */
            CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                           , VOID**    ifPtr /* [out] void* ifPtr  */
                                      ) PURE;
            CLIMETHOD_(ULONG, addRef) (THIS) PURE;
            CLIMETHOD_(ULONG, release) (THIS) PURE;
            
            /* interface ::cli::iComponentManager methods */
            CLIMETHOD_(SIZE_T, enumComponentCategoriesMbs) (THIS_ const CHAR*    componentId /* [in,flat] char  componentId[]  */
                                                                , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                                , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                                                , CHAR*    categoryNameBuf /* [out,flat,optional] char categoryNameBuf[]  */
                                                           ) PURE;
            CLIMETHOD_(SIZE_T, enumComponentCategoriesBuf) (THIS_ const WCHAR*    componentId /* [in,flat] wchar  componentId[]  */
                                                                , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                                , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                                                , WCHAR*    categoryNameBuf /* [out,flat,optional] wchar categoryNameBuf[]  */
                                                           ) PURE;
            CLIMETHOD(enumComponentCategories) (THIS_ const CLISTR*     componentId
                                                    , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                    , CLISTR*           categoryName
                                               ) PURE;
            CLIMETHOD_(SIZE_T, enumCategoriesMbs) (THIS_ SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                       , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                                       , CHAR*    categoryNameBuf /* [out,flat,optional] char categoryNameBuf[]  */
                                                  ) PURE;
            CLIMETHOD_(SIZE_T, enumCategoriesBuf) (THIS_ SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                       , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                                       , WCHAR*    categoryNameBuf /* [out,flat,optional] wchar categoryNameBuf[]  */
                                                  ) PURE;
            CLIMETHOD(enumCategories) (THIS_ SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                           , CLISTR*           categoryName
                                      ) PURE;
            CLIMETHOD_(SIZE_T, enumCategoryComponentsMbs) (THIS_ const CHAR*    categoryId /* [in,flat] char  categoryId[]  */
                                                               , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                                               , SIZE_T    componentNameBufSize /* [in] size_t  componentNameBufSize  */
                                                               , CHAR*    componentNameBuf /* [out,flat,optional] char componentNameBuf[]  */
                                                          ) PURE;
            CLIMETHOD_(SIZE_T, enumCategoryComponentsBuf) (THIS_ const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                               , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                                               , SIZE_T    componentNameBufSize /* [in] size_t  componentNameBufSize  */
                                                               , WCHAR*    componentNameBuf /* [out,flat,optional] wchar componentNameBuf[]  */
                                                          ) PURE;
            CLIMETHOD(enumCategoryComponents) (THIS_ const CLISTR*     categoryId
                                                   , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                                   , CLISTR*           componentName
                                              ) PURE;
            CLIMETHOD_(SIZE_T, getComponentDescriptionMbs) (THIS_ const CHAR*    componentId /* [in,flat] char  componentId[]  */
                                                                , const WCHAR*    requestedLang /* [in,flat] wchar  requestedLang[]  */
                                                                , BOOL    findExactLang /* [in] bool  findExactLang  */
                                                                , SIZE_T    descriptionBufSize /* [in] size_t  descriptionBufSize  */
                                                                , WCHAR*    descriptionBuf /* [out,flat,optional] wchar descriptionBuf[]  */
                                                           ) PURE;
            CLIMETHOD_(SIZE_T, getComponentDescriptionBuf) (THIS_ const WCHAR*    componentId /* [in,flat] wchar  componentId[]  */
                                                                , const WCHAR*    requestedLang /* [in,flat] wchar  requestedLang[]  */
                                                                , BOOL    findExactLang /* [in] bool  findExactLang  */
                                                                , SIZE_T    descriptionBufSize /* [in] size_t  descriptionBufSize  */
                                                                , WCHAR*    descriptionBuf /* [out,flat,optional] wchar descriptionBuf[]  */
                                                           ) PURE;
            CLIMETHOD(getComponentDescription) (THIS_ const CLISTR*     componentId
                                                    , const CLISTR*     requestedLang
                                                    , BOOL    findExactLang /* [in] bool  findExactLang  */
                                                    , CLISTR*           descriptionStr
                                               ) PURE;
        };

#if defined(__cplusplus) && !defined(CINTERFACE)

    }; // namespace cli

    namespace cli{
        template<> struct CIidOfImpl< ::cli::iComponentManager >
           {
            static char const * getName() { return INTERFACE_CLI_ICOMPONENTMANAGER_IID; }
           };
        template<> struct CIidOfImpl< ::cli::iComponentManager* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::iComponentManager > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        // interface ::cli::iComponentManager wrapper
        // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
        template <
                  typename smartPtrType
                                      /*
                                      =
                                          ::cli::CCliPtr< INTERFACE_CLI_ICOMPONENTMANAGER >
                                      */
                 >
        class CiComponentManagerWrapper
        {
            public:
        
                typedef  CiComponentManagerWrapper< smartPtrType >           wrapper_type;
                typedef  typename smartPtrType::interface_type              interface_type;
                typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                typedef  typename smartPtrType::pointer_type                pointer_type;
        
            protected:
        
                // pointer to interface variable name
                // allways must be pif - autogeneration depends on this name
                smartPtrType                pif;
        
            public:
        
                CiComponentManagerWrapper() :
                   pif(0) {}
        
                CiComponentManagerWrapper( iComponentManager *_pi, bool noAddRef=false) :
                   pif(_pi, noAddRef)
                  { }
        
                operator bool() const { return bool(pif); }
                bool operator!() const { return pif.operator!(); }
                interface_pointer_type* getPP() { return pif.getPP(); }
        
                interface_pointer_type getIfPtr()
                   {
                    interface_pointer_type* ptrPtr = pif.getPP();
                    if (!ptrPtr) return 0;
                    return *ptrPtr;
                   }
        
                void release()
                   {
                    pif.release();
                   }
        
                CiComponentManagerWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   RCODE res = pif.createObject( componentId, pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
                CiComponentManagerWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                   pif(0)
                  {
                   if (componentId.empty())
                      throw ::std::runtime_error("Empty component name taken");
                   RCODE res = pif.createObject( componentId.c_str(), pOuter );
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Failed to create requiested component");
                  }
        
               CiComponentManagerWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                   pif(0)
                  {
                   ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                   RCODE res = tmpPtr.queryInterface(pif);
                   if (RC_FAIL(res))
                      throw ::std::runtime_error("Requested interface not supported by object");
                  }
        
                CiComponentManagerWrapper(const CiComponentManagerWrapper &i) :
                    pif(i.pif) { }
        
                ~CiComponentManagerWrapper()  { }
        
                CiComponentManagerWrapper& operator=(const CiComponentManagerWrapper &i)
                   {
                    if (&i!=this) pif = i.pif;
                    return *this;
                   }
        
                template <typename T>
                RCODE queryInterface( T **t)
                  {
                   return pif.queryInterface(t);
                  }
        
                template <typename T>
                RCODE queryInterface( T &t)
                  {
                   t.release();
                   return pif.queryInterface(t.getPP());
                  }
        
                RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                   {
                    return pif.createObject(componentId, pOuter);
                   }
        
        
                // Automaticaly generated methods code goes here
        
                SIZE_T enumComponentCategoriesMbs( const CHAR*    componentId /* [in,flat] char  componentId[]  */
                                                 , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                 , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                                 , CHAR*    categoryNameBuf /* [out,flat,optional] char categoryNameBuf[]  */
                                                 )
                   {
                
                
                
                
                    return pif->enumComponentCategoriesMbs(componentId, categoryIdx, categoryNameBufSize, categoryNameBuf);
                   }
                
                SIZE_T enumComponentCategoriesBuf( const WCHAR*    componentId /* [in,flat] wchar  componentId[]  */
                                                 , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                                 , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                                 , WCHAR*    categoryNameBuf /* [out,flat,optional] wchar categoryNameBuf[]  */
                                                 )
                   {
                
                
                
                
                    return pif->enumComponentCategoriesBuf(componentId, categoryIdx, categoryNameBufSize, categoryNameBuf);
                   }
                
                RCODE enumComponentCategories( const ::std::wstring    &componentId
                                             , SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                             , ::std::wstring    &categoryName
                                             )
                   {
                    CCliStr tmp_componentId; CCliStr_lightCopyTo( tmp_componentId, componentId);
                
                    CCliStr tmp_categoryName; CCliStr_init( tmp_categoryName );
                    RCODE res = pif->enumComponentCategories(&tmp_componentId, categoryIdx, &tmp_categoryName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( categoryName, tmp_categoryName);
                       }
                    return res;
                   }
                
                SIZE_T enumCategoriesMbs( SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                        , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                        , CHAR*    categoryNameBuf /* [out,flat,optional] char categoryNameBuf[]  */
                                        )
                   {
                
                
                
                    return pif->enumCategoriesMbs(categoryIdx, categoryNameBufSize, categoryNameBuf);
                   }
                
                SIZE_T enumCategoriesBuf( SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                        , SIZE_T    categoryNameBufSize /* [in] size_t  categoryNameBufSize  */
                                        , WCHAR*    categoryNameBuf /* [out,flat,optional] wchar categoryNameBuf[]  */
                                        )
                   {
                
                
                
                    return pif->enumCategoriesBuf(categoryIdx, categoryNameBufSize, categoryNameBuf);
                   }
                
                RCODE enumCategories( SIZE_T    categoryIdx /* [in] size_t  categoryIdx  */
                                    , ::std::wstring    &categoryName
                                    )
                   {
                
                    CCliStr tmp_categoryName; CCliStr_init( tmp_categoryName );
                    RCODE res = pif->enumCategories(categoryIdx, &tmp_categoryName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( categoryName, tmp_categoryName);
                       }
                    return res;
                   }
                
                SIZE_T enumCategoryComponentsMbs( const CHAR*    categoryId /* [in,flat] char  categoryId[]  */
                                                , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                                , SIZE_T    componentNameBufSize /* [in] size_t  componentNameBufSize  */
                                                , CHAR*    componentNameBuf /* [out,flat,optional] char componentNameBuf[]  */
                                                )
                   {
                
                
                
                
                    return pif->enumCategoryComponentsMbs(categoryId, componentIdx, componentNameBufSize, componentNameBuf);
                   }
                
                SIZE_T enumCategoryComponentsBuf( const WCHAR*    categoryId /* [in,flat] wchar  categoryId[]  */
                                                , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                                , SIZE_T    componentNameBufSize /* [in] size_t  componentNameBufSize  */
                                                , WCHAR*    componentNameBuf /* [out,flat,optional] wchar componentNameBuf[]  */
                                                )
                   {
                
                
                
                
                    return pif->enumCategoryComponentsBuf(categoryId, componentIdx, componentNameBufSize, componentNameBuf);
                   }
                
                RCODE enumCategoryComponents( const ::std::wstring    &categoryId
                                            , SIZE_T    componentIdx /* [in] size_t  componentIdx  */
                                            , ::std::wstring    &componentName
                                            )
                   {
                    CCliStr tmp_categoryId; CCliStr_lightCopyTo( tmp_categoryId, categoryId);
                
                    CCliStr tmp_componentName; CCliStr_init( tmp_componentName );
                    RCODE res = pif->enumCategoryComponents(&tmp_categoryId, componentIdx, &tmp_componentName);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( componentName, tmp_componentName);
                       }
                    return res;
                   }
                
                SIZE_T getComponentDescriptionMbs( const CHAR*    componentId /* [in,flat] char  componentId[]  */
                                                 , const WCHAR*    requestedLang /* [in,flat] wchar  requestedLang[]  */
                                                 , BOOL    findExactLang /* [in] bool  findExactLang  */
                                                 , SIZE_T    descriptionBufSize /* [in] size_t  descriptionBufSize  */
                                                 , WCHAR*    descriptionBuf /* [out,flat,optional] wchar descriptionBuf[]  */
                                                 )
                   {
                
                
                
                
                
                    return pif->getComponentDescriptionMbs(componentId, requestedLang, findExactLang, descriptionBufSize, descriptionBuf);
                   }
                
                SIZE_T getComponentDescriptionBuf( const WCHAR*    componentId /* [in,flat] wchar  componentId[]  */
                                                 , const WCHAR*    requestedLang /* [in,flat] wchar  requestedLang[]  */
                                                 , BOOL    findExactLang /* [in] bool  findExactLang  */
                                                 , SIZE_T    descriptionBufSize /* [in] size_t  descriptionBufSize  */
                                                 , WCHAR*    descriptionBuf /* [out,flat,optional] wchar descriptionBuf[]  */
                                                 )
                   {
                
                
                
                
                
                    return pif->getComponentDescriptionBuf(componentId, requestedLang, findExactLang, descriptionBufSize, descriptionBuf);
                   }
                
                RCODE getComponentDescription( const ::std::wstring    &componentId
                                             , const ::std::wstring    &requestedLang
                                             , BOOL    findExactLang /* [in] bool  findExactLang  */
                                             , ::std::wstring    &descriptionStr
                                             )
                   {
                    CCliStr tmp_componentId; CCliStr_lightCopyTo( tmp_componentId, componentId);
                    CCliStr tmp_requestedLang; CCliStr_lightCopyTo( tmp_requestedLang, requestedLang);
                
                    CCliStr tmp_descriptionStr; CCliStr_init( tmp_descriptionStr );
                    RCODE res = pif->getComponentDescription(&tmp_componentId, &tmp_requestedLang, findExactLang, &tmp_descriptionStr);
                    if (RCOK(res))
                       {
                        CCliStr_copyFromIfModified( descriptionStr, tmp_descriptionStr);
                       }
                    return res;
                   }
                

        
        
        }; // class CiComponentManagerWrapper
        
        typedef CiComponentManagerWrapper< ::cli::CCliPtr< INTERFACE_CLI_ICOMPONENTMANAGER     > >  CiComponentManager;
        typedef CiComponentManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICOMPONENTMANAGER > >  CiComponentManager_nrc; /* No ref counting for interface used */
        typedef CiComponentManagerWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_ICOMPONENTMANAGER > >  CiComponentManager_tmp; /* for temporary usage, same as CiComponentManager_nrc */
        
        
        
        
        
    }; // namespace cli

#endif





#endif /* CLI_CORESERVICES_H */
