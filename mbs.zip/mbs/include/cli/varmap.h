#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_VARMAP_H
#define CLI_VARMAP_H

/* Add next lines to your C/C++ code
#ifndef CLI_VARMAP_H
    #include <cli/varmap.h>
#endif
*/

#ifndef CLI_IVARMAP_H
    #include <cli/ivarmap.h>
#endif

namespace cli
{

// set variable helpers
inline
void setVariantMapValue( INTERFACE_CLI_IVARIANTMAP *pVarMap, const ::std::wstring &varName, const ::std::wstring &varValue )
   {
    ::cli::CiVariant variantTmp;
    if (!pVarMap->queryValueByNameChars(varName.c_str(),variantTmp.getPP()) && !!variantTmp)
        {
         variantTmp.setString( varValue );
        }
     else
        {
         variantTmp.create("/cli/variant");
         variantTmp.setString( varValue );
         pVarMap->insertValueChars( varName.c_str(), TRUE  /* overwriteExisting */, FALSE  /* do not copyValue */, variantTmp.getIfPtr() );
        }
   }

inline
void setVariantMapValue( ::cli::CiVariantMap &varMap, const ::std::wstring &varName, const ::std::wstring &varValue )
   {
    setVariantMapValue( varMap.getIfPtr(), varName, varValue );
   }

inline
void setVariantMapValue( ::cli::CiVariantMap_tmp &varMap, const ::std::wstring &varName, const ::std::wstring &varValue )
   {
    setVariantMapValue( varMap.getIfPtr(), varName, varValue );
   }



inline
void setVariantMapValue( INTERFACE_CLI_IVARIANTMAP *pVarMap, const ::std::wstring &varName, UINT varValue )
   {
    ::cli::CiVariant variantTmp;
    if (!pVarMap->queryValueByNameChars(varName.c_str(),variantTmp.getPP()) && !!variantTmp)
        {
         variantTmp.setUInt( varValue );
        }
     else
        {
         variantTmp.create("/cli/variant");
         variantTmp.setUInt( varValue );
         pVarMap->insertValueChars( varName.c_str(), TRUE  /* overwriteExisting */, FALSE  /* do not copyValue */, variantTmp.getIfPtr() );
        }
   }

inline
void setVariantMapValue( ::cli::CiVariantMap &varMap, const ::std::wstring &varName, UINT  varValue )
   {
    setVariantMapValue( varMap.getIfPtr(), varName, varValue );
   }

inline
void setVariantMapValue( ::cli::CiVariantMap_tmp &varMap, const ::std::wstring &varName, UINT  varValue )
   {
    setVariantMapValue( varMap.getIfPtr(), varName, varValue );
   }



inline
void setVariantMapValue( INTERFACE_CLI_IVARIANTMAP *pVarMap, const ::std::wstring &varName, INT varValue )
   {
    ::cli::CiVariant variantTmp;
    if (!pVarMap->queryValueByNameChars(varName.c_str(),variantTmp.getPP()) && !!variantTmp)
        {
         variantTmp.setInt( varValue );
        }
     else
        {
         variantTmp.create("/cli/variant");
         variantTmp.setInt( varValue );
         pVarMap->insertValueChars( varName.c_str(), TRUE  /* overwriteExisting */, FALSE  /* do not copyValue */, variantTmp.getIfPtr() );
        }
   }

inline
void setVariantMapValue( ::cli::CiVariantMap &varMap, const ::std::wstring &varName, INT  varValue )
   {
    setVariantMapValue( varMap.getIfPtr(), varName, varValue );
   }

inline
void setVariantMapValue( ::cli::CiVariantMap_tmp &varMap, const ::std::wstring &varName, INT  varValue )
   {
    setVariantMapValue( varMap.getIfPtr(), varName, varValue );
   }



inline
void setVariantMapValue( INTERFACE_CLI_IVARIANTMAP *pVarMap, const ::std::wstring &varName, DOUBLE varValue )
   {
    ::cli::CiVariant variantTmp;
    if (!pVarMap->queryValueByNameChars(varName.c_str(),variantTmp.getPP()) && !!variantTmp)
        {
         variantTmp.setDouble( varValue );
        }
     else
        {
         variantTmp.create("/cli/variant");
         variantTmp.setDouble( varValue );
         pVarMap->insertValueChars( varName.c_str(), TRUE  /* overwriteExisting */, FALSE  /* do not copyValue */, variantTmp.getIfPtr() );
        }
   }

inline
void setVariantMapValue( ::cli::CiVariantMap &varMap, const ::std::wstring &varName, DOUBLE varValue )
   {
    setVariantMapValue( varMap.getIfPtr(), varName, varValue );
   }

inline
void setVariantMapValue( ::cli::CiVariantMap_tmp &varMap, const ::std::wstring &varName, DOUBLE varValue )
   {
    setVariantMapValue( varMap.getIfPtr(), varName, varValue );
   }





}; // namespace cli



#endif /* CLI_VARMAP_H */
