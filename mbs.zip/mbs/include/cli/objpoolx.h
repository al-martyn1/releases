#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_OBJPOOLX_H
#define CLI_OBJPOOLX_H

#ifndef __cplusplus
    #error "C++ compilation required for this header"
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#if !defined(_STACK_) && !defined(_STLP_STACK) && !defined(__STD_STACK__) && !defined(_CPP_STACK) && !defined(_GLIBCXX_STACK)
    #include <stack>
#endif

#if !defined(_INC_STDLIB) && !defined(_STDLIB_H_) && !defined(_STDLIB_H)
    #include <stdlib.h>
#endif

#if !defined(_INC_WCHAR) && !defined(_WCHAR_H_) && !defined(_WCHAR_H)
    #include <wchar.h>
#endif

/*
#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif
*/

/*
inline
::std::wstring toStr(RCODE rc)
   {
    WCHAR buf[128];
    #ifdef _WIN32
    _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"0x%08X", rc );
    #else
    swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"0x%08X", rc );
    #endif
    return ::std::wstring(buf);
   }
*/

namespace cli
{

template < typename TDefaultObjectType
         , typename TDynamicObjectType
         , typename TPooledObjectInterface
         , typename TLockerType
         , typename TCleanup
         >
class CObjectPool
{
    protected:
        TDefaultObjectType                    defObject;
        ::std::stack< TDynamicObjectType* >   pool;
        TLockerType                           poolLocker;
        UINT                                  newCount;
        TCleanup                              cleanupObj;

        const WCHAR                          *poolName; // for debugging

        #ifdef _DEBUG
            #ifndef DISABLE_CLI_DEBUG_OBJ_POOL
                #ifdef _WIN32
                    #define USE_CLI_DEBUG_OBJ_POOL
                #endif
            #endif
        #endif

        #ifdef USE_CLI_DEBUG_OBJ_POOL
        typedef TDynamicObjectType*          ObjPtrT;
        ::std::set< ObjPtrT >                allDynObjects;
        #endif


    public:

      CObjectPool()
         : defObject()
         , pool()
         , poolLocker()
         , newCount(0)
         , poolName(L"Noname")
         #ifdef USE_CLI_DEBUG_OBJ_POOL
         , allDynObjects()
         #endif
         {
         }

      CObjectPool(const WCHAR *pn)
         : defObject()
         , pool()
         , poolLocker()
         , newCount(0)
         , poolName(pn)
         #ifdef USE_CLI_DEBUG_OBJ_POOL
         , allDynObjects()
         #endif
         {
         }

      ~CObjectPool()
         {
          /*
          //using namespace ::cli::format;

          //UINT poolSize = (UINT)pool.size();
          messageEx( L"Object pool \"%1\", total objects created: %2, object in pool when destroing: %3"
                   , arg(poolName) % newCount % poolSize
                   , FMF_AUTO_APPEND_LF
                   );
          */
          WCHAR buf[512];
          UINT poolSize = (UINT)pool.size();
          #ifdef _WIN32
          _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"Object pool \"%s\", total objects created: %d, objects in pool when destroing: %d, %s\n", poolName, newCount, poolSize, (newCount==poolSize ? L"Ok" : L"Failed, counts mismatch") );
          #else
          swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"Object pool \"%s\", total objects created: %d, objects in pool when destroing: %d, %s\n", poolName, newCount, poolSize, (newCount==poolSize ? L"Ok" : L"Failed, counts mismatch") );
          #endif

          // not works on unloading cli library
          //cliWriteLogStringW(buf);
          #ifdef _WIN32
          OutputDebugStringW( buf );
          #endif

          while(!pool.empty())
             {
              TDynamicObjectType* ptr = pool.top();
              pool.pop();
              #include <cli/compspec/pdelnvdtoroff.h>
              delete ptr;
              #include <cli/compspec/pdelnvdtoron.h>
              #ifdef USE_CLI_DEBUG_OBJ_POOL
              allDynObjects.erase(ptr);
              #endif
             }

          #ifdef USE_CLI_DEBUG_OBJ_POOL
          //if (newCount==poolSize)
          if (!allDynObjects.empty())
             {
              typename ::std::set< ObjPtrT >::const_iterator it = allDynObjects.begin();
              for(; it != allDynObjects.end(); ++it)
                 {
                  ::std::wstring dumpStr;
                  ObjPtrT ptr = *it;
                  ptr->dumpPooledObject( dumpStr );
                  #ifdef _WIN32
                  _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), L"%p: ", ptr );
                  #else
                  swprintf  (buf, sizeof(buf)/sizeof(buf[0]), L"%p: ", ptr );
                  #endif

                  #ifdef _WIN32
                  OutputDebugStringW( buf );
                  if (!dumpStr.empty())
                     OutputDebugStringW( dumpStr.c_str() );
                  else
                     OutputDebugStringW( L"<EMPTY>" );
                  OutputDebugStringW( L"\n" );
                  #endif
                 }
             }
          #endif
          cleanupObj();
         }

      TPooledObjectInterface* getInstance()
         {
          CLI_AUTOLOCK(poolLocker);

          TDynamicObjectType* ptr = 0;
          if (!pool.empty())
             {
              ptr = pool.top(); pool.pop();
             }
          else
             {
              try{
                  ptr = new TDynamicObjectType(*this);
                  #ifdef USE_CLI_DEBUG_OBJ_POOL
                  allDynObjects.insert(ptr);
                  #endif
                  ++newCount;
                 }
              catch(...)
                 {
                  return static_cast<TPooledObjectInterface*>(&defObject);
                 }
             }
          ptr->addRef();
          return static_cast<TPooledObjectInterface*>(ptr);
         }

      void putBack(TDynamicObjectType *pObj)
         {
          CLI_AUTOLOCK(poolLocker);
          pool.push(pObj);
         }
};

}; // namespace cli

#endif /* CLI_OBJPOOLX_H */

