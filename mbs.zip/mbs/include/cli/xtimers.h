#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_XTIMERS_H
#define CLI_XTIMERS_H


#include <cli/tickcount.h>

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif


#define XTIMERSCALL  CLICALL


namespace cli
{


class CTimersList;

struct CTimerInfo
{
    TICK_T startedAt;
    TICK_T period;
    TICK_T periodEllapsed;
};


typedef VOID (XTIMERSCALL *xtimer_proc)( const CTimerInfo *pInfo
                                       , UINT_PTR timerParam1
                                       , UINT_PTR timerParam2
                                       , CTimersList *pTimersList
                                       );


struct CTimerParams
{
    TICK_T         startTick;
    TICK_T         period;

    xtimer_proc    timerProc;
    UINT_PTR       timerProcArg1;
    UINT_PTR       timerProcArg2;

    CTimerParams() : startTick(0), period(0), timerProc(0), timerProcArg1(0), timerProcArg2(0) {}
    CTimerParams(TICK_T st, TICK_T p, xtimer_proc proc, UINT_PTR arg1, UINT_PTR arg2)
       : startTick(st)
       , period(p)
       , timerProc(proc)
       , timerProcArg1(arg1)
       , timerProcArg2(arg2)
       {}
};



class CTimersList
{
    private:
        ::std::vector< CTimerParams > timersList;

        CTimersList( const CTimersList &) {}
        CTimersList& operator=( const CTimersList &) { return *this; }

    public:

        CTimersList() : timersList() {}

        bool addTimer( TICK_T interval, xtimer_proc proc, UINT_PTR arg1, UINT_PTR arg2 )
           {
            if (!proc) return false;
            try{
                timersList.push_back( CTimerParams( cliGetTickCount(), interval, proc, arg1, arg2) );
               }
            catch(...)
               {
                return false;
               }
            return true;
           }

        SIZE_T checkTimers()
           {
            SIZE_T ellapsedTimersCount = 0;

            ::std::vector< CTimerParams >::size_type i = 0;
            while( i!=timersList.size() )
               {
                CTimerInfo info;
                info.periodEllapsed = (TICK_T)cliGetCurrentTickDiff( timersList[i].startTick );
                if (timersList[i].period > info.periodEllapsed)
                   {
                    ++i;
                    continue;
                   }

                info.startedAt = timersList[i].startTick;
                info.period    = timersList[i].period;

                timersList[i].timerProc( &info, timersList[i].timerProcArg1, timersList[i].timerProcArg2, this );
                timersList.erase( timersList.begin() + i );
                ++ellapsedTimersCount;
                // don't need to increment i
               }
            return ellapsedTimersCount;
           }

        void clearTimers()
           {
            timersList.clear();
           }

};



/* void handler( const ::cli::CTimerInfo *pInfo, UINT_PTR arg, ::cli::CTimersList *pTimersList ) */
//#define CLASS_XTIMER_HANDLER  xtimer_handler

#define CLASS_DECLARE_SET_XTIMER(functionName, handlerName)                               \
                        bool functionName( ::cli::CTimersList *pTimersList, TICK_T interval, UINT_PTR arg )\
                           {                                                              \
                            if (!pTimersList) return false;                               \
                            return pTimersList->addTimer( interval                        \
                                                        , &static_xtimer_handler##handlerName \
                                                        , (UINT_PTR)this                  \
                                                        , arg                             \
                                                        );                                \
                           }


#define CLASS_USE_XTIMER( className, handlerName )                                        \
                        static                                                            \
                        VOID XTIMERSCALL static_xtimer_handler##handlerName( const ::cli::CTimerInfo *pInfo \
                                                              , UINT_PTR timerParam1       \
                                                              , UINT_PTR timerParam2       \
                                                              , ::cli::CTimersList *pTimersList  \
                                                              )                           \
                           {                                                              \
                            className* pClassObj = (className*)timerParam1;               \
                            if (!pClassObj) return;                                       \
                            pClassObj-> handlerName (pInfo, timerParam2, pTimersList);    \
                           }

#define CLASS_CONST_USE_XTIMER( className, handlerName )                                  \
                        static                                                            \
                        VOID XTIMERSCALL static_xtimer_handler##handlerName( const ::cli::CTimerInfo *pInfo \
                                                              , UINT_PTR timerParam1       \
                                                              , UINT_PTR timerParam2       \
                                                              , ::cli::CTimersList *pTimersList  \
                                                              )                           \
                           {                                                              \
                            const className* pClassObj = (const className*)timerParam1;   \
                            if (!pClassObj) return;                                       \
                            pClassObj-> handlerName (pInfo, timerParam2, pTimersList);    \
                           }


#define CLASS_USE_XTIMER_EX( className, handlerName, setupFunctionName )              \
                           CLASS_USE_XTIMER( className, handlerName )                 \
                           CLASS_DECLARE_SET_XTIMER(setupFunctionName, handlerName)   \

#define CLASS_CONST_USE_XTIMER_EX( className, handlerName, setupFunctionName )        \
                           CLASS_CONST_USE_XTIMER( className, handlerName )           \
                           CLASS_DECLARE_SET_XTIMER(setupFunctionName, handlerName)   \


}; // namespace cli

#endif /* CLI_XTIMERS_H */

