#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

/*
#ifndef CLI_GUITYPES_H
    #include <cli/guitypes.h>
#endif
*/

#ifndef CLI_GUITYPES_H
#define CLI_GUITYPES_H

#ifndef WND_HANDLE_DEFINED

    // #define WND_HANDLE

    // try to detect Wx usage
    #ifndef __cli_WX_USED__
        //#error __cli_WX_USED__ not defined
        #if defined(__WX__) || defined(__WXX11__)
            #define __cli_WX_USED__
        #endif
    #endif

    // try to detect Qt usage
    #ifndef __cli_QT_USED__
        #if defined(QT_THREAD_SUPPORT) || \
            defined(QT_NO_DEBUG) ||       \
            defined(QT_DEBUG) ||          \
            defined(QT_CORE_LIB) ||       \
            defined(QT_GUI_LIB)
            #define __cli_QT_USED__
        #endif
    #endif


    #if defined(__cli_WX_USED__)
        #if !defined(_WIN32) || defined(CLI_GUI_FORCE_WX)
            #define WND_HANDLE_DEFINED
            //typedef wxWidget*   WND_HANDLE;
            class wxWindow; // if <wx/window.h> not included before
            typedef wxWindow*   WND_HANDLE;

        //#else
        #endif
    #elif defined(__cli_QT_USED__)
        #if !defined(_WIN32) || defined(CLI_GUI_FORCE_WX)
            #define WND_HANDLE_DEFINED
            // class QWidget
            //typedef qtWidget*   WND_HANDLE;
            typedef QWidget*   WND_HANDLE;
        #endif
    #endif

    #ifdef _WIN32
        #ifndef WND_HANDLE_DEFINED
            #define WND_HANDLE_DEFINED
            // windows.h must be included first
            typedef HWND        WND_HANDLE;
        #endif
    #else // generic platorm
        // UNDONE: ��祬�-� �� ࠡ�⠥� ��⮤�⥪� �� __cli_WX_USED__
        #ifndef WND_HANDLE_DEFINED
            #define WND_HANDLE_DEFINED
            typedef void*        WND_HANDLE;
        #endif

    #endif

    #ifndef WND_HANDLE_DEFINED
        #error WND_HANDLE_DEFINED not defined
    #endif

#endif // ifndef WND_HANDLE_DEFINED


#ifndef CLI_GUI_GENERIC_GUI_TYPE_STR

#if defined(__cli_WX_USED__)
    #define CLI_GUI_GENERIC_GUI_TYPE_STR "wx"
#elif defined(__cli_QT_USED__)
    #define CLI_GUI_GENERIC_GUI_TYPE_STR "qt"
#elif defined(WIN32)
    #define CLI_GUI_GENERIC_GUI_TYPE_STR "win"
#else
    #define CLI_GUI_GENERIC_GUI_TYPE_STR "undefined-ui"
#endif

#endif /* CLI_GUI_GENERIC_GUI_TYPE_STR */


#define CLI_GUI_GENERIC_ERROR_DIALOG_CID         "/cli/core/gui/error_dialog/" CLI_GUI_GENERIC_GUI_TYPE_STR
#define CLI_GUI_GENERIC_SIMPLE_MESSAGE_BOX_CID   "/cli/core/gui/simple_message_box/" CLI_GUI_GENERIC_GUI_TYPE_STR





#endif /* CLI_GUITYPES_H */

