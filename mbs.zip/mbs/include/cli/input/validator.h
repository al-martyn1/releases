#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INPUT_VALIDATOR_H
#define CLI_INPUT_VALIDATOR_H

/*
#ifndef CLI_INPUT_VALIDATOR_H
    #include <cli/input/validator.h>
#endif
*/

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifndef CLI_INPUT_IVALIDATOR_H
    #include <cli/input/ivalidator.h>
#endif

#ifndef CLI_ARGLIST_H
    #include <cli/arglist.h>
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif


namespace cli
{
namespace input
{



inline
::std::string composeValidatorComponentName( const ::std::wstring &validatorName)
   {
    if (!validatorName.empty() && validatorName[0]==L'/') // full qualified name
       return MARTY_UTF_NS toUtf8(validatorName);
    return ::std::string("/cli/input/validator/") + MARTY_UTF_NS toUtf8(validatorName);
   }


//-----------------------------------------------------------------------------


template <typename T>
::std::wstring buildSampleString( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                   , const ::std::wstring &formatString
                   , T t
                   )
   {
    if (!pValidator) return ::std::wstring();

    ::cli::input::CiValidator validator( pValidator );
    validator.formatString = formatString;
    validator.buildSampleString( 0, ::cli::format::arg(t) );
    return validator.testString;
   }


inline
bool validateString( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                   , const ::std::wstring &strToValidate
                   , const ::std::wstring &validateFormatString
                   , SIZE_T               *pValidLen = 0
                   , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                   )
   {
    if (!pValidator) return bValidIfunknowValidator;

    ::cli::input::CiValidator validator( pValidator );
    validator.formatString = validateFormatString;
    validator.testString   = strToValidate;
    bool bRes = validator.validateString() ? false : true;
    if (pValidLen) *pValidLen = validator.validLen;
    return bRes;    
   }

inline
bool validateString( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                   , const ::std::wstring &strToValidate
                   , SIZE_T               *pValidLen = 0
                   , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                   )
   {
    if (!pValidator) return bValidIfunknowValidator;
    ::cli::input::CiValidator validator( pValidator );
    //validator.formatString = validateFormatString; // no format string
    validator.testString   = strToValidate;
    bool bRes = validator.validateString() ? false : true;
    if (pValidLen) *pValidLen = validator.validLen;
    return bRes;    
   }

inline
bool validateString( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                   , const ::std::wstring &strToValidate
                   , const ::std::vector< ::std::wstring > &validateFormats
                   , SIZE_T               *pValidLen = 0
                   , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                   )
   {
    if (!pValidator) return bValidIfunknowValidator;

    ::cli::input::CiValidator validator( pValidator );
    validator.testString   = strToValidate;
    ::std::vector< ::std::wstring >::const_iterator vit = validateFormats.begin();
    for(; vit!=validateFormats.end(); ++vit)
       {
        validator.formatString = *vit;
        if (!validator.validateString())
           {
            if (pValidLen) *pValidLen = validator.validLen;
            return true;
           }
       }
    if (pValidLen) *pValidLen = 0;
    return false;
   }

inline
SIZE_T validateStringEx( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                   , const ::std::wstring &strToValidate
                   , const ::std::vector< ::std::wstring > &validateFormats
                   , SIZE_T               *pValidLen = 0
                   )
   {
    if (!pValidator) return SIZE_T_NPOS;

    ::cli::input::CiValidator validator( pValidator );
    validator.testString   = strToValidate;
    ::std::vector< ::std::wstring >::const_iterator vit = validateFormats.begin();
    for(; vit!=validateFormats.end(); ++vit)
       {
        validator.formatString = *vit;
        if (!validator.validateString())
           {
            if (pValidLen) *pValidLen = validator.validLen;
            return (SIZE_T)(vit-validateFormats.begin());
           }
       }
    return SIZE_T_NPOS;
   }

//-----------------------------------------------------------------------------


template <typename T>
::std::wstring buildSampleString( const ::std::wstring &validatorName
                   , const ::std::wstring &formatString
                   , T t
                   )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return buildSampleString(validator.getIfPtr(), formatString, t);
       }
    catch(...)
       {
        return ::std::wstring();
       }
   }

inline
bool validateString( const ::std::wstring &validatorName
                   , const ::std::wstring &strToValidate
                   , const ::std::wstring &validateFormatString
                   , SIZE_T               *pValidLen = 0
                   , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                   )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return validateString(validator.getIfPtr(), strToValidate, validateFormatString, pValidLen, bValidIfunknowValidator);
       }
    catch(...)
       {
        return bValidIfunknowValidator;
       }
   }

inline
bool validateString( const ::std::wstring &validatorName
                   , const ::std::wstring &strToValidate
                   , SIZE_T               *pValidLen = 0
                   , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                   )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return validateString(validator.getIfPtr(), strToValidate, pValidLen, bValidIfunknowValidator);
       }
    catch(...)
       {
        return bValidIfunknowValidator;
       }
   }

inline
bool validateString( const ::std::wstring &validatorName
                   , const ::std::wstring &strToValidate
                   , const ::std::vector< ::std::wstring > &validateFormats
                   , SIZE_T               *pValidLen = 0
                   , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                   )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return validateString(validator.getIfPtr(), strToValidate, validateFormats, pValidLen, bValidIfunknowValidator);
       }
    catch(...)
       {
        return bValidIfunknowValidator;
       }
   }

inline
SIZE_T validateStringEx( const ::std::wstring &validatorName
                   , const ::std::wstring &strToValidate
                   , const ::std::vector< ::std::wstring > &validateFormats
                   , SIZE_T               *pValidLen = 0
                   )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return validateStringEx(validator.getIfPtr(), strToValidate, validateFormats, pValidLen);
       }
    catch(...)
       {
        return SIZE_T_NPOS;
       }
   }

//-----------------------------------------------------------------------------

template <typename T>
bool convertString( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                  , T &t
                  , const ::std::wstring &strToConvert
                  , const ::std::wstring &validateFormatString
                  , SIZE_T               *pValidLen = 0
                  , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                  )
   {
    if (!pValidator) return bValidIfunknowValidator;

    ::cli::input::CiValidator validator( pValidator );
    validator.formatString = validateFormatString;
    validator.testString   = strToConvert;
    ::cli::CArgList al;
    bool bRes = validator.convertString( 0, al.getIfPtr() ) ? false : true;
    if (pValidLen) *pValidLen = validator.validLen;
    if (bRes) al.getValue( 0, t );
    return bRes;    
   }

template <typename T>
bool convertString( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                  , T &t
                  , const ::std::wstring &strToConvert
                  , SIZE_T               *pValidLen = 0
                  , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                  )
   {
    if (!pValidator) return bValidIfunknowValidator;

    ::cli::input::CiValidator validator( pValidator );
    //validator.formatString = validateFormatString;
    validator.testString   = strToConvert;
    ::cli::CArgList al;
    bool bRes = validator.convertString( 0, al.getIfPtr() ) ? false : true;
    if (pValidLen) *pValidLen = validator.validLen;
    if (bRes) al.getValue( 0, t );
    return bRes;    
   }

template <typename T>
bool convertString( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                  , T &t
                  , const ::std::wstring &strToConvert
                  , const ::std::vector< ::std::wstring > &validateFormats
                  , SIZE_T               *pValidLen = 0
                  , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                  )
   {
    if (!pValidator) return bValidIfunknowValidator;

    ::cli::input::CiValidator validator( pValidator );
    validator.testString   = strToConvert;
    ::std::vector< ::std::wstring >::const_iterator vit = validateFormats.begin();
    ::cli::CArgList al;
    for(; vit!=validateFormats.end(); ++vit)
       {
        validator.formatString = *vit;
        if (!validator.convertString( 0, al.getIfPtr() ))
           {
            if (pValidLen) *pValidLen = validator.validLen;
            al.getValue( 0, t );
            return true;
           }
       }
    if (pValidLen) *pValidLen = 0;
    return false;
   }

template <typename T>
SIZE_T convertStringEx( INTERFACE_CLI_INPUT_IVALIDATOR *pValidator
                  , T &t
                  , const ::std::wstring &strToConvert
                  , const ::std::vector< ::std::wstring > &validateFormats
                  , SIZE_T               *pValidLen = 0
                  )
   {
    if (!pValidator) return SIZE_T_NPOS;

    ::cli::input::CiValidator validator( pValidator );
    validator.testString   = strToConvert;
    ::std::vector< ::std::wstring >::const_iterator vit = validateFormats.begin();
    ::cli::CArgList al;
    for(; vit!=validateFormats.end(); ++vit)
       {
        validator.formatString = *vit;
        if (!validator.convertString( 0, al.getIfPtr() ))
           {
            if (pValidLen) *pValidLen = validator.validLen;
            al.getValue( 0, t );
            return (SIZE_T)(vit-validateFormats.begin());
           }
       }
    if (pValidLen) *pValidLen = 0;
    return SIZE_T_NPOS;
   }

//-----------------------------------------------------------------------------

template <typename T>
bool convertString( const ::std::wstring &validatorName
                  , T &t
                  , const ::std::wstring &strToConvert
                  , const ::std::wstring &validateFormatString
                  , SIZE_T               *pValidLen = 0
                  , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                  )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return convertString(validator.getIfPtr(), t, strToConvert, validateFormatString, pValidLen, bValidIfunknowValidator);
       }
    catch(...)
       {
        return bValidIfunknowValidator;
       }
   }

template <typename T>
bool convertString( const ::std::wstring &validatorName
                  , T &t
                  , const ::std::wstring &strToConvert
                  , SIZE_T               *pValidLen = 0
                  , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                  )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return convertString(validator.getIfPtr(), t, strToConvert, pValidLen, bValidIfunknowValidator);
       }
    catch(...)
       {
        return bValidIfunknowValidator;
       }
   }

template <typename T>
bool convertString( const ::std::wstring &validatorName
                  , T &t
                  , const ::std::wstring &strToConvert
                  , const ::std::vector< ::std::wstring > &validateFormats
                  , SIZE_T               *pValidLen = 0
                  , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                  )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return convertString(validator.getIfPtr(), t, strToConvert, validateFormats, pValidLen, bValidIfunknowValidator);
       }
    catch(...)
       {
        return bValidIfunknowValidator;
       }
   }

template <typename T>
SIZE_T convertString( const ::std::wstring &validatorName
                  , T &t
                  , const ::std::wstring &strToConvert
                  , const ::std::vector< ::std::wstring > &validateFormats
                  , SIZE_T               *pValidLen = 0
                  )
   {
    try{
        ::cli::input::CiValidator validator(composeValidatorComponentName(validatorName).c_str());
        return convertStringEx(validator.getIfPtr(), t, strToConvert, validateFormats, pValidLen);
       }
    catch(...)
       {
        return SIZE_T_NPOS;
       }
   }

//-----------------------------------------------------------------------------


class CValidator
{
    ::std::map< ::std::wstring, INTERFACE_CLI_INPUT_IVALIDATOR *> knownValidators;

    public:

        CValidator() : knownValidators() {}
    
        CValidator( const CValidator &v) : knownValidators(v.knownValidators)
           {
            ::std::map< ::std::wstring, INTERFACE_CLI_INPUT_IVALIDATOR *>::const_iterator it = knownValidators.begin();
            for(; it!=knownValidators.end(); ++it)
               {
                it->second->addRef();
               }
           }
    
        CValidator& operator=( const CValidator &v )
           {
            if (&v==this) return *this;
    
            ::std::map< ::std::wstring, INTERFACE_CLI_INPUT_IVALIDATOR *>::const_iterator it = knownValidators.begin();
            for(; it!=knownValidators.end(); ++it)
               {
                it->second->release();
               }
             knownValidators = v.knownValidators;
    
            //::std::map< ::std::wstring, INTERFACE_CLI_INPUT_IVALIDATOR *>::const_iterator 
            it = knownValidators.begin();
            for(; it!=knownValidators.end(); ++it)
               {
                it->second->addRef();
               }
    
            return *this;
           }
    
        ~CValidator()
           {
            ::std::map< ::std::wstring, INTERFACE_CLI_INPUT_IVALIDATOR *>::const_iterator it = knownValidators.begin();
            for(; it!=knownValidators.end(); ++it)
               {
                it->second->release();
               }
           }

    protected:

        INTERFACE_CLI_INPUT_IVALIDATOR* getValidator( const ::std::wstring &vn)
           {
            ::std::map< ::std::wstring, INTERFACE_CLI_INPUT_IVALIDATOR *>::iterator it = knownValidators.find(vn);
            if (it!=knownValidators.end()) return it->second;
    
            try{
                ::cli::input::CiValidator validator(composeValidatorComponentName(vn).c_str());
                INTERFACE_CLI_INPUT_IVALIDATOR *pv = validator.getIfPtr();
                if (!pv) return pv;
                pv->addRef();
                knownValidators[vn] = pv;
                return pv;
               }
            catch(...)
               {
                return 0;
               }
           }

    public:
        
        //-----------------------------------------------------------------------------

        template <typename T>
        ::std::wstring buildSampleString( const ::std::wstring &validatorName
                           , const ::std::wstring &formatString
                           , T t
                           )
           {
            return ::cli::input::buildSampleString( getValidator(validatorName), formatString, t );
           }
        
        bool validateString( const ::std::wstring &validatorName
                           , const ::std::wstring &strToValidate
                           , const ::std::wstring &validateFormatString
                           , SIZE_T               *pValidLen = 0
                           , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                           )
            {
             return ::cli::input::validateString( getValidator(validatorName), strToValidate, validateFormatString, pValidLen, bValidIfunknowValidator );
            }
        
        inline
        bool validateString( const ::std::wstring &validatorName
                           , const ::std::wstring &strToValidate
                           , SIZE_T               *pValidLen = 0
                           , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                           )
            {
             return ::cli::input::validateString( getValidator(validatorName), strToValidate, pValidLen, bValidIfunknowValidator );
            }
        
        inline
        bool validateString( const ::std::wstring &validatorName
                           , const ::std::wstring &strToValidate
                           , const ::std::vector< ::std::wstring > &validateFormats
                           , SIZE_T               *pValidLen = 0
                           , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                           )
            {
             return ::cli::input::validateString( getValidator(validatorName), strToValidate, validateFormats, pValidLen, bValidIfunknowValidator );
            }
        
        inline
        SIZE_T validateStringEx( const ::std::wstring &validatorName
                           , const ::std::wstring &strToValidate
                           , const ::std::vector< ::std::wstring > &validateFormats
                           , SIZE_T               *pValidLen = 0
                           )
            {
             return ::cli::input::validateStringEx( getValidator(validatorName), strToValidate, validateFormats, pValidLen );
            }
        
        //-----------------------------------------------------------------------------
        
        template <typename T>
        bool convertString( const ::std::wstring &validatorName
                          , T &t
                          , const ::std::wstring &strToConvert
                          , const ::std::wstring &validateFormatString
                          , SIZE_T               *pValidLen = 0
                          , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                          )
            {
             return ::cli::input::convertString( getValidator(validatorName), t, strToConvert, validateFormatString, pValidLen, bValidIfunknowValidator );
            }
        
        template <typename T>
        bool convertString( const ::std::wstring &validatorName
                          , T &t
                          , const ::std::wstring &strToConvert
                          , SIZE_T               *pValidLen = 0
                          , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                          )
            {
             return ::cli::input::convertString( getValidator(validatorName), t, strToConvert, pValidLen, bValidIfunknowValidator);
            }
        
        
        template <typename T>
        bool convertString( const ::std::wstring &validatorName
                          , T &t
                          , const ::std::wstring &strToConvert
                          , const ::std::vector< ::std::wstring > &validateFormats
                          , SIZE_T               *pValidLen = 0
                          , bool  bValidIfunknowValidator = true // by default, value is valid if validator not found
                          )
            {
             return ::cli::input::convertString( getValidator(validatorName), t, strToConvert, validateFormats, pValidLen, bValidIfunknowValidator);
            }
        
        
        template <typename T>
        SIZE_T convertString( const ::std::wstring &validatorName
                          , T &t
                          , const ::std::wstring &strToConvert
                          , const ::std::vector< ::std::wstring > &validateFormats
                          , SIZE_T               *pValidLen = 0
                          )
            {
             return ::cli::input::convertString( getValidator(validatorName), t, strToConvert, validateFormats, pValidLen);
            }
        

}; // class CValidator






}; // namespace input
}; // namespace cli



#endif /* CLI_INPUT_VALIDATOR_H */

