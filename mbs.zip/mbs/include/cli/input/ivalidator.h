#ifndef CLI_INPUT_IVALIDATOR_H
#define CLI_INPUT_IVALIDATOR_H

/* Warning! Automaticaly generated file, do not edit */

/* Add next line to your IDL code
cpp_include("<cli/input/ivalidator.h>", CLI_INPUT_IVALIDATOR_H);
*/

/* Add next lines to your C/C++ code
#ifndef CLI_INPUT_IVALIDATOR_H
    #include <cli/input/ivalidator.h>
#endif
*/

/* Standard includes */

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_IIDOF_H
    #include <cli/iidof.h>
#endif

#ifndef CLI_IFDEFS_H
    #include <cli/ifdefs.h>
#endif

#ifndef CLI_CLIASSERT_H
    #include <cli/cliassert.h>
#endif

#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_PROPERTY_H
    #include <cli/property.h>
#endif

#ifndef CLI_CLIPTR_H
    #include <cli/cliptr.h>
#endif

#ifndef CLI_CLISTR_H
    #include <cli/clistr.h>
#endif

/* User defined includes */

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_DATETIMEPODTYPES_H
    #include <cli/dateTimePodTypes.h>
#endif

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#ifndef CLI_IARGLIST_H
    #include <cli/iarglist.h>
#endif


/* ------------------------------------------------------ */
/* Interface: ::cli::input::iValidator */
/* ------------------------------------------------------ */

#if defined(__cplusplus) && !defined(CINTERFACE)

    namespace cli {
        interface                                iArgList;
        #ifndef INTERFACE_CLI_IARGLIST
            #define INTERFACE_CLI_IARGLIST            ::cli::iArgList
        #endif

        interface                                iUnknown;
        #ifndef INTERFACE_CLI_IUNKNOWN
            #define INTERFACE_CLI_IUNKNOWN            ::cli::iUnknown
        #endif

    }; /* namespace cli */

#else /* C-like declarations */

    typedef interface tag_cli_iArgList       cli_iArgList;
    #ifndef INTERFACE_CLI_IARGLIST
        #define INTERFACE_CLI_IARGLIST            struct tag_cli_iArgList
    #endif

    typedef interface tag_cli_iUnknown       cli_iUnknown;
    #ifndef INTERFACE_CLI_IUNKNOWN
        #define INTERFACE_CLI_IUNKNOWN            struct tag_cli_iUnknown
    #endif


#endif /* end of C-like declarations */

#ifdef INTERFACE
    #undef INTERFACE
#endif

#ifdef BASE_INTERFACE
    #undef BASE_INTERFACE
#endif

#ifndef INTERFACE_CLI_INPUT_IVALIDATOR_IID
    #define INTERFACE_CLI_INPUT_IVALIDATOR_IID    "/cli/input/iValidator"
#endif

#if defined(__cplusplus) && !defined(CINTERFACE)
    namespace cli {
        namespace input {
    #define INTERFACE iValidator
    #define BASE_INTERFACE ::cli::iUnknown
    #ifndef INTERFACE_CLI_INPUT_IVALIDATOR
       #define INTERFACE_CLI_INPUT_IVALIDATOR    ::cli::input::iValidator
    #endif
#else /* C-like declaration */
    #define INTERFACE cli_input_iValidator
    #define BASE_INTERFACE cli_iUnknown
    #ifndef INTERFACE_CLI_INPUT_IVALIDATOR
       #define INTERFACE_CLI_INPUT_IVALIDATOR    cli_input_iValidator
    #endif
#endif

            CLI_DECLARE_INTERFACE_(INTERFACE, BASE_INTERFACE)
            {
                
                /* interface ::cli::iUnknown methods */
                CLIMETHOD(queryInterface) (THIS_ const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                               , VOID**    ifPtr /* [out] void* ifPtr  */
                                          ) PURE;
                CLIMETHOD_(ULONG, addRef) (THIS) PURE;
                CLIMETHOD_(ULONG, release) (THIS) PURE;
                
                /* interface ::cli::input::iValidator methods */
                CLIMETHOD(formatStringGet) (THIS_ CLISTR*           _formatString) PURE;
                CLIMETHOD(formatStringSet) (THIS_ const CLISTR*     _formatString) PURE;
                CLIMETHOD(testStringGet) (THIS_ CLISTR*           _testString) PURE;
                CLIMETHOD(testStringSet) (THIS_ const CLISTR*     _testString) PURE;
                CLIMETHOD(validStringGet) (THIS_ CLISTR*           _validString) PURE;
                CLIMETHOD(validLenGet) (THIS_ SIZE_T*    _validLen /* [out] size_t _validLen  */) PURE;
                CLIMETHOD(validateString) (THIS) PURE;
                CLIMETHOD(convertString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                              , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                         ) PURE;
                CLIMETHOD(buildSampleString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                  , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                             ) PURE;
            };

#if defined(__cplusplus) && !defined(CINTERFACE)

        }; /* namespace input */
    }; /* namespace cli */

    namespace cli{
        template<> struct CIidOfImpl< ::cli::input::iValidator >
           {
            static char const * getName() { return INTERFACE_CLI_INPUT_IVALIDATOR_IID; }
           };
        template<> struct CIidOfImpl< ::cli::input::iValidator* >
           {
            static char const * getName() { return CIidOfImpl< ::cli::input::iValidator > :: getName(); }
           };
    }; // namespace cli

    namespace cli {
        namespace input {
            // interface ::cli::input::iValidator wrapper
            // generated from F:\work\cli2\trunk\out\Win32\cidl\conf\templates\wrapper_template.cpp template file
            template <
                      typename smartPtrType
                                          /*
                                          =
                                              ::cli::CCliPtr< INTERFACE_CLI_INPUT_IVALIDATOR >
                                          */
                     >
            class CiValidatorWrapper
            {
                public:
            
                    typedef  CiValidatorWrapper< smartPtrType >           wrapper_type;
                    typedef  typename smartPtrType::interface_type              interface_type;
                    typedef  typename smartPtrType::interface_pointer_type      interface_pointer_type;
                    typedef  typename smartPtrType::pointer_type                pointer_type;
            
                protected:
            
                    // pointer to interface variable name
                    // allways must be pif - autogeneration depends on this name
                    smartPtrType                pif;
            
                public:
            
                    CiValidatorWrapper() :
                       pif(0) {}
            
                    CiValidatorWrapper( iValidator *_pi, bool noAddRef=false) :
                       pif(_pi, noAddRef)
                      { }
            
                    operator bool() const { return bool(pif); }
                    bool operator!() const { return pif.operator!(); }
                    interface_pointer_type* getPP() { return pif.getPP(); }
            
                    interface_pointer_type getIfPtr()
                       {
                        interface_pointer_type* ptrPtr = pif.getPP();
                        if (!ptrPtr) return 0;
                        return *ptrPtr;
                       }
            
                    void release()
                       {
                        pif.release();
                       }
            
                    CiValidatorWrapper( const CHAR *componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       RCODE res = pif.createObject( componentId, pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                    CiValidatorWrapper( const ::std::string &componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0) :
                       pif(0)
                      {
                       if (componentId.empty())
                          throw ::std::runtime_error("Empty component name taken");
                       RCODE res = pif.createObject( componentId.c_str(), pOuter );
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Failed to create requiested component");
                      }
            
                   CiValidatorWrapper( INTERFACE_CLI_IUNKNOWN *pUnk) :
                       pif(0)
                      {
                       ::cli::CFoolishPtr<INTERFACE_CLI_IUNKNOWN> tmpPtr(pUnk);
                       RCODE res = tmpPtr.queryInterface(pif);
                       if (RC_FAIL(res))
                          throw ::std::runtime_error("Requested interface not supported by object");
                      }
            
                    CiValidatorWrapper(const CiValidatorWrapper &i) :
                        pif(i.pif) { }
            
                    ~CiValidatorWrapper()  { }
            
                    CiValidatorWrapper& operator=(const CiValidatorWrapper &i)
                       {
                        if (&i!=this) pif = i.pif;
                        return *this;
                       }
            
                    template <typename T>
                    RCODE queryInterface( T **t)
                      {
                       return pif.queryInterface(t);
                      }
            
                    template <typename T>
                    RCODE queryInterface( T &t)
                      {
                       t.release();
                       return pif.queryInterface(t.getPP());
                      }
            
                    RCODE create(CHAR const * componentId, INTERFACE_CLI_IUNKNOWN *pOuter=0)
                       {
                        return pif.createObject(componentId, pOuter);
                       }
            
            
                    // Automaticaly generated methods code goes here
            
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_formatString( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = formatStringGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_formatString( const ::std::wstring &_formatString
                                         )
                       {
                        RCODE res = formatStringSet( _formatString );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, formatString );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE formatStringGet( ::std::wstring    &_formatString)
                       {
                        CCliStr tmp__formatString; CCliStr_init( tmp__formatString );
                        RCODE res = pif->formatStringGet(&tmp__formatString);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _formatString, tmp__formatString);
                           }
                        return res;
                       }
                    
                    RCODE formatStringSet( const ::std::wstring    &_formatString)
                       {
                        CCliStr tmp__formatString; CCliStr_lightCopyTo( tmp__formatString, _formatString);
                        return pif->formatStringSet(&tmp__formatString);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_testString( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = testStringGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    void set_testString( const ::std::wstring &_testString
                                       )
                       {
                        RCODE res = testStringSet( _testString );
                        CLI_CHECK_SET_PROPERTY_RESULT(res);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_RW(wrapper_type, ::std::wstring, testString );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE testStringGet( ::std::wstring    &_testString)
                       {
                        CCliStr tmp__testString; CCliStr_init( tmp__testString );
                        RCODE res = pif->testStringGet(&tmp__testString);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _testString, tmp__testString);
                           }
                        return res;
                       }
                    
                    RCODE testStringSet( const ::std::wstring    &_testString)
                       {
                        CCliStr tmp__testString; CCliStr_lightCopyTo( tmp__testString, _testString);
                        return pif->testStringSet(&tmp__testString);
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    ::std::wstring get_validString( )
                       {
                        ::std::wstring tmpVal;
                        RCODE res = validStringGet( tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, ::std::wstring, validString );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE validStringGet( ::std::wstring    &_validString)
                       {
                        CCliStr tmp__validString; CCliStr_init( tmp__validString );
                        RCODE res = pif->validStringGet(&tmp__validString);
                        if (RCOK(res))
                           {
                            CCliStr_copyFromIfModified( _validString, tmp__validString);
                           }
                        return res;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS)
                    
                    SIZE_T get_validLen( )
                       {
                        SIZE_T tmpVal;
                        RCODE res = validLenGet( &tmpVal);
                        CLI_CHECK_GET_PROPERTY_RESULT(res);
                        return tmpVal;
                       }
                    
                    #if !defined(CLI_WRAPPER_NO_PROPERTIES)
                    /* GCC note: invalid access to non-static data member of NULL object warning must be ignored. This is known GCC "offsetof problem"
                       By default, special version of code used for GCC, use DISABLE_GCC_OFFSETOF_WARNING_WORKAROUND to switch off workaround and see this warning */
                    CLI_DECLARE_PROPERTY_R(wrapper_type, SIZE_T, validLen );
                    #endif /* CLI_WRAPPER_NO_PROPERTIES */
                    
                    #endif /* CLI_WRAPPER_NO_SAFE_PROPERTY_METHODS */
                    
                    
                    RCODE validLenGet( SIZE_T*    _validLen /* [out] size_t _validLen  */)
                       {
                    
                        return pif->validLenGet(_validLen);
                       }
                    
                    RCODE validateString( )
                       {
                        return pif->validateString();
                       }
                    
                    RCODE convertString( SIZE_T    idx /* [in] size_t  idx  */
                                       , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                       )
                       {
                    
                    
                        return pif->convertString(idx, data);
                       }
                    
                    RCODE buildSampleString( SIZE_T    idx /* [in] size_t  idx  */
                                           , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                           )
                       {
                    
                    
                        return pif->buildSampleString(idx, data);
                       }
                    

            
            
            }; // class CiValidatorWrapper
            
            typedef CiValidatorWrapper< ::cli::CCliPtr< INTERFACE_CLI_INPUT_IVALIDATOR     > >  CiValidator;
            typedef CiValidatorWrapper< ::cli::CFoolishPtr< INTERFACE_CLI_INPUT_IVALIDATOR > >  CiValidator_nrc; /* No ref counting for interface used */
            
            
            
            
            
        }; /* namespace input */
    }; /* namespace cli */

#endif





#endif /* CLI_INPUT_IVALIDATOR_H */
