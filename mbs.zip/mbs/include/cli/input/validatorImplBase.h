#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_INPUT_VALIDATORIMPLBASE_H
#define CLI_INPUT_VALIDATORIMPLBASE_H

#ifndef CLI_INPUT_IVALIDATOR_H
    #include <cli/input/ivalidator.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif


namespace cli
{
namespace input
{
namespace validator
{
namespace impl
{

struct CValidatorImplBase : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                          , public INTERFACE_CLI_INPUT_IVALIDATOR
{
    protected:

        std::wstring             formatString;
        std::wstring             testString;
        std::wstring::size_type  validLen;

    public:

        typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
        CValidatorImplBase()
           : base_impl(DEF_MODULE)
           , formatString()
           , testString()
           , validLen(0)
           {}

        /* interface ::cli::input::iValidator methods */
        CLIMETHOD(formatStringGet) (THIS_ CLISTR*           _formatString)
           {
            CLI_TRY{
                    return ::cli::propertyGetImpl( _formatString, formatString );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
           }

        CLIMETHOD(formatStringSet) (THIS_ const CLISTR*     _formatString)
           {
            CLI_TRY{
                    return ::cli::propertySetImpl( _formatString, formatString );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
           }

        CLIMETHOD(testStringGet) (THIS_ CLISTR*           _testString)
           {
            CLI_TRY{
                    return ::cli::propertyGetImpl( _testString, testString );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
           }

        CLIMETHOD(testStringSet) (THIS_ const CLISTR*     _testString)
           {
            CLI_TRY{
                    return ::cli::propertySetImpl( _testString, testString );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
           }

        CLIMETHOD(validStringGet) (THIS_ CLISTR*           _validString)
           {
            CLI_TRY{
                    return ::cli::propertyGetImpl( _validString, std::wstring(testString, 0, validLen ) );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
           }

        CLIMETHOD(validLenGet) (THIS_ SIZE_T*    _validLen /* [out] size_t _validLen  */)
           {
            if (!_validLen) return EC_INVALID_PARAM;
            *_validLen = validLen;
            return EC_OK;
           }

        //CLIMETHOD(validateString) (THIS)
        //CLIMETHOD(convertString) (THIS_ INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */)


};



}; // namespace impl
}; // namespace validator
}; // namespace format
}; // namespace cli



#endif /* CLI_INPUT_VALIDATORIMPLBASE_H */

