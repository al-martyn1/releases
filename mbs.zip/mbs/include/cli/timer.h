#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_TIMER_H
#define CLI_TIMER_H

/* add this lines to your src
#ifndef CLI_TIMER_H
    #include <cli/timer.h>
#endif
*/

#ifndef CLI_ITIMER_H
    #include <cli/itimer.h>
#endif

#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif


namespace cli
{
namespace impl
{


// Note: Not thread safe !!!
class CTimerImplBase : public INTERFACE_CLI_ITIMER
{

protected:

    struct CHandlerInfo
    {
         ::cli::CiTimerHandler handler;
         SIZE_T                id;
         TICK_T                timeout;
         BOOL                  oneShot;
         TICK_T                lastShot;

         CHandlerInfo( INTERFACE_CLI_ITIMERHANDLER *pHandler, SIZE_T _id, TICK_T _timeout = 0, BOOL _oneShot = FALSE)
            : handler(pHandler), id(_id), timeout(_timeout), oneShot(_oneShot), lastShot( cliGetTickCount() ) {}

         CHandlerInfo( const CHandlerInfo &i )
            : handler(i.handler), id(i.id), timeout(i.timeout), oneShot(i.oneShot), lastShot( i.lastShot ) {}

         CHandlerInfo& operator=( const CHandlerInfo &i )
            {
             if (&i==this) return *this;
             handler  = i.handler;
             id       = i.id;
             timeout  = i.timeout;
             oneShot  = i.oneShot;
             lastShot = i.lastShot;
             return *this;
            }

         bool operator==(const CHandlerInfo &i) const
            {
             CHandlerInfo *phi1 = const_cast<CHandlerInfo*>(this);
             CHandlerInfo *phi2 = const_cast<CHandlerInfo*>(&i);
             if (phi1->handler.getIfPtr() != phi2->handler.getIfPtr()) return false;
             if ( id==SIZE_T_NPOS || i.id==SIZE_T_NPOS ) return true;
             return id == i.id;
            }

         bool operator!=(const CHandlerInfo &i) const
            {
             CHandlerInfo *phi1 = const_cast<CHandlerInfo*>(this);
             CHandlerInfo *phi2 = const_cast<CHandlerInfo*>(&i);
             if (phi1->handler.getIfPtr() == phi2->handler.getIfPtr()) return false;
             if ( id==SIZE_T_NPOS || i.id==SIZE_T_NPOS ) return false;
             return id != i.id;
            }
    }; // struct CHandlerInfo

    ::std::vector< CHandlerInfo > handlers;
    ::std::vector< CHandlerInfo > removeList;
    ::std::vector< CHandlerInfo > addList;
    int                           inShot;

    void removeSingle( const CHandlerInfo &compareTo )
       {
        ::std::vector< CHandlerInfo >::size_type i = 0, size = handlers.size();
        for(; i!=size; )
           {
            if (handlers[i]==compareTo)
               {
                handlers.erase( handlers.begin() + i);
                size = handlers.size();
               }
            else
               ++i;
           }
       }

    void applyRemove()
       {
        //CHandlerInfo compareTo( pHandler, id );
        ::std::vector< CHandlerInfo >::const_iterator rmIt = removeList.begin();
        for(; rmIt !=removeList.end(); ++rmIt)
           {
            removeSingle(*rmIt);
           }
        removeList.clear();
       }

    void applyAdd()
       {
        handlers.insert( handlers.end(), addList.begin(), addList.end() );
        addList.clear();
       }

public:

    CTimerImplBase() : handlers(), removeList(), addList(), inShot(0) {}

    CLIMETHOD(addTimerHandler) (THIS_ INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                    , SIZE_T    id /* [in] size_t  id  */
                                    , TICK_T    timeout /* [in] tick_t  timeout  */
                                    , BOOL    oneShot /* [in] bool  oneShot  */
                               )
       {
        if (!pHandler || id==SIZE_T_NPOS) return EC_INVALID_PARAM;
        if (inShot>0)
           addList.push_back(CHandlerInfo( pHandler, id, timeout, oneShot ));
        else
           handlers.push_back(CHandlerInfo( pHandler, id, timeout, oneShot ));
        return EC_OK;
       }

    CLIMETHOD(removeTimerHandler) (THIS_ INTERFACE_CLI_ITIMERHANDLER*    pHandler /* [in] ::cli::iTimerHandler*  pHandler  */
                                       , SIZE_T    id /* [in] size_t  id  */
                                  )
       {
        if (inShot>0)
           removeList.push_back(CHandlerInfo( pHandler, id ));
        else
           removeSingle( CHandlerInfo( pHandler, id ) );
        return EC_OK;
        /*
        //::std::vector< CHandlerInfo > handlersCopy;
        //handlersCopy.reserve(handlers.size());
        CHandlerInfo compareTo( pHandler, id );
        ::std::vector< CHandlerInfo >::size_type i = 0, size = handlers.size();
        for(; i!=size; )
           {
            if (handlers[i]==compareTo)
               {
                handlers.erase( handlers.begin() + i);
                size = handlers.size();
               }
            else
               ++i;
           }
        */
       }

    virtual 
    INTERFACE_CLI_ITIMER* getSelfInterface() = 0;
    /* put in final implementation
    INTERFACE_CLI_ITIMER* getSelfInterface()
       {
        return static_cast<INTERFACE_CLI_ITIMER*>(this);
       }
    */

    bool isShotsNeeded()
       {
        return !handlers.empty();
       }

    void makeShot() // const
       {
        applyRemove();
        applyAdd();
        ++inShot;
        ::std::vector< CHandlerInfo >::iterator it = handlers.begin();
        INTERFACE_CLI_ITIMER* pTimer = getSelfInterface();
        for(; it != handlers.end(); ++it)
           {
            TICK_T ellapsed = (TICK_T)cliGetCurrentTickDiff( it->lastShot );
            if (ellapsed < it->timeout ) continue;
            it->handler.onTimerEvent( pTimer, it->id );
            if (it->oneShot) removeTimerHandler( it->handler.getIfPtr(), it->id );
            else it->lastShot = cliGetTickCount();
           }
        --inShot;
        applyRemove();
        applyAdd();
       }

}; // class CTimerImplBase


struct CTimerImplAuto : public CTimerImplBase // no ref counting support
{
public:

    CLI_BEGIN_INTERFACE_MAP(CTimerImplAuto)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ITIMER )
    CLI_END_INTERFACE_MAP(CTimerImplAuto)

    // use this class as automatic object
    CLIMETHOD_(ULONG, addRef) (THIS)    { return 1; }
    CLIMETHOD_(ULONG, release) (THIS)   { return 1; }

    INTERFACE_CLI_ITIMER* getSelfInterface()
       {
        return static_cast<INTERFACE_CLI_ITIMER*>(this);
       }

}; // class CTimerImplAuto





}; // namespace impl
}; // namespace cli

#endif /* CLI_TIMER_H */


