#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_TLS_H
#define CLI_TLS_H

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif


/* This header declares CLI_TLS macro for thread local variables */

//#ifdef _MSC_VER
#if defined(WIN32) || defined(_WIN32)/* assume that all win32 target's compilers support MSVC __declspec( thread ) keyword */
    #define CLI_TLS __declspec( thread )
    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif
#elif defined(__GNUC__)
    #if !defined(_PTHREAD_H) && !defined(_PTHREAD_H_)
        #include <pthread.h>
    #endif
    #define CLI_TLS __thread
#else
    #error "Unsupported compiler"
#endif

// man pthread_key_create � ����� 

#ifndef TLS_INDEX_T_DEFINED
    #define TLS_INDEX_T_DEFINED
    #if defined(WIN32) || defined(_WIN32)
        typedef DWORD         TLS_INDEX_T;
        #define INVALID_TLS_INDEX  TLS_OUT_OF_INDEXES
    #else
        typedef pthread_key_t TLS_INDEX_T;
        #define INVALID_TLS_INDEX  ((pthread_key_t)-1)
    #endif
#endif

#if defined(WIN32) || defined(_WIN32)
typedef void (CLICALL *CLI_TLS_DESTUCTION_FN) ();
typedef void (CLICALL *CLI_TLS_KEY_DESTUCTION_FN) ( void * );
#else
typedef void (*CLI_TLS_DESTUCTION_FN) ();
typedef void (*CLI_TLS_KEY_DESTUCTION_FN) (void *);
#endif


#if defined(WIN32) || defined(_WIN32)
EXTERN_CLI
CLIAPIENTRY
CLI_TLS_DESTUCTION_FN
CLICALL
cliSetTlsDestructorFunction( CLI_TLS_DESTUCTION_FN pfn );

EXTERN_CLI
CLIAPIENTRY
CLI_TLS_DESTUCTION_FN
CLICALL
cliGetTlsDestructorFunction( );
#endif

EXTERN_CLI
CLIAPIENTRY
VOID
CLICALL
cliTouchTls( );



#endif /* CLI_TLS_H */

