#include <cli/ponce.h>
#ifdef CLI_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef CLI_EMBED_H
#define CLI_EMBED_H

#ifdef EMBEDDED
    #ifndef CLI_EMBEDDED
        #define CLI_EMBEDDED
    #endif
#endif

// if we build embedded app, it must be also monolith
#ifdef CLI_EMBEDDED
    #ifndef CLI_MONOLITH
        #define CLI_MONOLITH
    #endif
    #ifndef CLI_MONOLITHIC
        #define CLI_MONOLITHIC
    #endif
#endif

#endif /* CLI_EMBED_H */

