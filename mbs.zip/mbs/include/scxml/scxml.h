#ifndef SCXML_SCXML_H
#define SCXML_SCXML_H

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_INC_ERRNO) && !defined(_ERRNO_H_) && !defined(_ERRNO_H)
    #include <errno.h>
#endif


#include <sixml/sixmlx.h>

#include <sixml/serializ.h>


//-----------------------------------------------------------------------------
namespace scxml
{

//-----------------------------------------------------------------------------
enum tag_EScxmlExmode
{
    scx_em_lax = 0,
    scx_em_strict = 1
};

typedef tag_EScxmlExmode EScxmlExmode;
//-----------------------------------------------------------------------------

}; // namespace scxml
//-----------------------------------------------------------------------------





//-----------------------------------------------------------------------------
// enums must be in global ns, otherwise something not works
using scxml::tag_EScxmlExmode;

//-----------------------------------------------------------------------------
BEGIN_ENUM_META_DATA(tag_EScxmlExmode)
    enumerate( scxml::scx_em_lax,    _T("lax"));
    enumerate( scxml::scx_em_strict, _T("strict"));
END_ENUM_META_DATA(tag_EScxmlExmode)
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
namespace scxml
{


//-----------------------------------------------------------------------------
struct CScxmlDoc
{
    std::string                   xmlns_scxml;
    std::string                   version;
    std::string                   name;
    EScxmlExmode                  exmode;
    std::string                   initial;
    std::string                   profile;

    CScxmlDoc()
       : xmlns_scxml("http://www.w3.org/2005/07/scxml")
       , version(_T("1.0"))
       , name()
       , exmode(scx_em_lax)
       , initial()
       , profile()
       {}

    STRUCT_LAYOUT_DEFAULT(CScxmlDoc)
            attribute(_T("xmlns")              , &CScxmlDoc::xmlns_scxml   , tstring(_T("")));
            attribute(_T("version")            , &CScxmlDoc::version       );
            attribute(_T("name")               , &CScxmlDoc::name          , tstring(_T("")));
            attribute(_T("exmode")             , &CScxmlDoc::exmode        , scx_em_lax);
            attribute(_T("initial")            , &CScxmlDoc::initial       , tstring(_T("")));
            attribute(_T("profile")            , &CScxmlDoc::profile       , tstring(_T("")));
    END_STRUCT_LAYOUT()


};
//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
void save_scxml(const std::string &filename, const CScxmlDoc &scx)
   {   
    sixml::serializer::write_xml( filename.c_str(),  
                                  "scxml", 
                                  scx, 
                                  sixml::serializer::write_attr::more_indent, // default_method, less_indent, more_indent
                                  true
                                );
   }

//-----------------------------------------------------------------------------
void load_scxml(const std::string &filename, CScxmlDoc &scx)
   {
    sixml::serializer::load_xml<scxml::CScxmlDoc>(filename.c_str(), scx);
   }


//-----------------------------------------------------------------------------

}; // namespace scxml


#endif /* SCXML_SCXML_H */

