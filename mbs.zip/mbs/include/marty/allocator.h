#include <marty/ponce.h>
#pragma once

#ifndef MARTY_ALLOCATOR_H
#define MARTY_ALLOCATOR_H

/* add this lines to your scr
#ifndef MARTY_ALLOCATOR_H
    #include <marty/allocator.h>
#endif
*/

#if !defined(_CSTDDEF_) && !defined(_STLP_CSTDDEF) && !defined(_CPP_CSTDDEF) && !defined(_GLIBCXX_CSTDDEF)
    #include <cstddef>
#endif

#if !defined(_NEW_) && !defined(_NEW) && !defined(__NEW__) && !defined(_STLP_NEW) && !defined(__STD_NEW)
    #include <new>
#endif



namespace marty
{


//-----------------------------------------------------------------------------
struct IRefCountedPool
{
    virtual int   addRef () = 0;
    virtual int   release() = 0;
    virtual void* allocateMem  ( size_t size ) = 0;
    virtual void  deallocateMem( void* ) = 0;
protected:
    virtual void destroy() = 0;
};

// provides non thread safe ref counting
struct IRefCountedPoolUnsafeImplBase : public IRefCountedPool
{
private: 

    int refCounter;

public:

    IRefCountedPoolUnsafeImplBase() : refCounter(1) {}

    int addRef () 
       { 
        return ++refCounter;
       }
    int release() 
       { 
        if (--refCounter == 0) 
           { 
            destroy(); 
            return 0;
           } 
        return refCounter;
       }
};


// provides no-free pool
template < typename BasePoolImpl >
struct IFixedChunkPoolT : public BasePoolImpl
{
protected:
    char    *pMemChunk;
    SIZE_T   chunkSize;
    SIZE_T   usedCount;
    bool     bDeleteChunk;

    ~IFixedChunkPoolT()
       {
        if (bDeleteChunk) delete[] pMemChunk;
       }

private:

     // no default constructor
     IFixedChunkPoolT(); 
     // no copy
     IFixedChunkPoolT(const IFixedChunkPoolT &p);
     IFixedChunkPoolT& operator=(const IFixedChunkPoolT &p);

public:

    IFixedChunkPoolT( size_t poolSize, char *pMem = 0 )
       : pMemChunk(pMem ? pMem : new char[poolSize])
       , chunkSize(poolSize)
       , usedCount(0)
       , bDeleteChunk( pMem==0 )
       {}

    void* allocateMem  ( size_t size )
       {
        if ((usedCount+size)>chunkSize) throw ::std::bad_alloc("No memory in chunk");
        void* pRes = (void*)(&pMemChunk[usedCount]);
        usedCount += size;
        return pRes;
       }

    void deallocateMem( void* ) { }

protected:

    void destroy()
       {
        delete this;
       }
};

typedef IFixedChunkPoolT<IRefCountedPoolUnsafeImplBase> IFixedChunkPool;

//-----------------------------------------------------------------------------

#ifndef MARTY_THROW0
    #ifdef _THROW0  
        #define MARTY_THROW0()   _THROW0()
    #else
        #define MARTY_THROW0()   throw ()
    #endif
#endif

template <typename _Ty>
class IPoolAllocator
    {
public:
    //typedef _Allocator_base<_Ty> _Mybase;
    typedef _Ty          value_type;
    typedef value_type  *pointer;
    typedef value_type  &reference;
    typedef const value_type *const_pointer;
    typedef const value_type &const_reference;

    typedef ::std::size_t    size_type;
    typedef ::std::ptrdiff_t difference_type;

    template<class _Other>
    struct rebind
        {   // convert an allocator<_Ty> to an allocator <_Other>
        typedef IPoolAllocator<_Other> other;
        };

    pointer address(reference _Val) const
        {   // return address of mutable _Val
        return (&_Val);
        }

    const_pointer address(const_reference _Val) const
        {   // return address of nonmutable _Val
        return (&_Val);
        }

private: // not allowed

    IRefCountedPool *pPool;

public:

    IPoolAllocator() MARTY_THROW0()
       : pPool(0)
        {   // construct default allocator (do nothing)
        }

    IPoolAllocator(IRefCountedPool *pp) MARTY_THROW0()
       : pPool(pp)
        {   // construct default allocator (do nothing)
         if (pPool) pPool->addRef();
        }

    ~IPoolAllocator()
        {
         if (pPool) pPool->release();
        }

    //IPoolAllocator(const IPoolAllocator<_Ty>& c) MARTY_THROW0()
    IPoolAllocator(const IPoolAllocator& c) MARTY_THROW0()
       : pPool( c.pPool )
        {   // construct by copying (do nothing)
         if (pPool) pPool->addRef();
        }

    IPoolAllocator& operator=(const IPoolAllocator& c) MARTY_THROW0()
        {   // construct by copying (do nothing)
        if (pPool) pPool->release();
        pPool = c.pPool;
        if (pPool) pPool->addRef();
        return (*this);
        }

    bool operator==(const IPoolAllocator& c) const
        {
         return this == &c;
        }

    template<class _Other>
    IPoolAllocator(const IPoolAllocator<_Other> &c) MARTY_THROW0()
       : pPool( c.pPool )
        {   // construct from a related allocator (do nothing)
         if (pPool) pPool->addRef();
        }

    template<class _Other>
    IPoolAllocator<_Ty>& operator=(const IPoolAllocator<_Other>& c)
        {   // assign from a related allocator (do nothing)
        if (pPool) pPool->release();
        pPool = c.pPool;
        if (pPool) pPool->addRef();
        return (*this);
        }

    void deallocate(pointer _Ptr, size_type)
        {   // deallocate object at _Ptr, ignore size
        // ::operator delete(_Ptr);
        if (!pPool) throw ::std::bad_alloc("Allocator not initialized");
        pPool->deallocateMem( (void*)_Ptr );
        }

    pointer allocate(size_type _Count)
        {   // allocate array of _Count elements
        // return (_Allocate(_Count, (pointer)0));
        if (!pPool) throw ::std::bad_alloc("Allocator not initialized");
        return (pointer)pPool->allocateMem(_Count);
        }

    pointer allocate(size_type _Count, const void _FARQ *)
        {   // allocate array of _Count elements, ignore hint
        if (!pPool) throw ::std::bad_alloc("Allocator not initialized");
        return (pointer)pPool->allocateMem(_Count);
        //return (allocate(_Count));
        }

    void construct(pointer _Ptr, const _Ty& _Val)
        {   // construct object at _Ptr with value _Val
         //_Construct(_Ptr, _Val);
         void *_Vptr = _Ptr;
         ::new (_Vptr) _Ty(_Val);
        }

    void destroy(pointer _Ptr)
        {   // destroy object at _Ptr
        //_Destroy(_Ptr);
        _Ptr->~_Ty();
        }

    size_type max_size() const MARTY_THROW0()
        {   // estimate maximum array size
        size_type _Count = (size_type)(-1) / sizeof (_Ty);
        return (0 < _Count ? _Count : 1);
        }
    };









}; // namespace marty

#endif /* MARTY_ALLOCATOR_H */



