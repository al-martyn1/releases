#include <marty/ponce.h>
#ifdef MARTY_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef MARTY_TEXTFORMAT_H
#define MARTY_TEXTFORMAT_H

/* add this lines to your scr
#ifndef MARTY_TEXTFORMAT_H
    #include <marty/textFormat.h>
#endif
*/


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif


namespace marty
{
namespace txt
{


//-----------------------------------------------------------------------------
template<typename CharType>
struct isSpace
{
    bool operator()(CharType ch) const
       {
        if (ch==(CharType)' ' || ch==(CharType)'\n' || ch==(CharType)'\r' || ch==(CharType)'\t') return true;
        return false;
       }
};

template<typename CharType>
struct isLinefeed
{
    bool operator()(CharType ch) const
       {
        if (ch==(CharType)'\n') return true;
        return false;
       }
};

template<typename CharType>
struct isCr
{
    bool operator()(CharType ch) const
       {
        if (ch==(CharType)'\r') return true;
        return false;
       }
};

template<typename CharType>
struct alwaysNotSpace
{
    bool operator()(CharType ch) const
       {
        return false;
       }
};

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpasePred
        , typename IsIgnoredPred
        >
void splitText( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &words
              , const ::std::basic_string<CharType, Traits, Allocator> &line
              , const IsSpasePred   &isSpasePred
              , const IsIgnoredPred &isIgnoredPred
              )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    words.reserve(line.size()/4); //

    string_type curWord;
    typename string_type::size_type pos = 0, size = line.size();
    for(; pos!=size; ++pos)
       {
        if (isSpasePred(line[pos]))
           {
            if (!curWord.empty())
               {
                words.push_back(curWord);
                curWord.clear();
               }
           }
        else
           {
            if (!isIgnoredPred(line[pos]))
               curWord.append(1, line[pos]);
           }
       }

    if (!curWord.empty())
       words.push_back(curWord);
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
void splitToWords( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &words
                 , const ::std::basic_string<CharType, Traits, Allocator> &line
                 )
   {
    splitText( words, line, isSpace<CharType>(), alwaysNotSpace<CharType>() );
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
void splitToLines( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &words
                 , const ::std::basic_string<CharType, Traits, Allocator> &line
                 )
   {
    splitText( words, line, isLinefeed<CharType>(), isCr<CharType>() );
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
void correctPunctuation( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >  &words
                       , const ::std::set< ::std::basic_string<CharType, Traits, Allocator> > &marks
                       , const ::std::set< ::std::basic_string<CharType, Traits, Allocator> > &frontMarks // such as (, {, [
                       )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;

    ::std::vector< string_type > tmp;
    tmp.reserve( words.size() );

    for( typename ::std::vector< string_type >::const_iterator pWord = words.begin(); pWord!=words.end(); ++pWord )
       {
        if (!tmp.empty() && frontMarks.find(tmp[tmp.size()-1])!=frontMarks.end())
           { // prev word is front mark
            tmp[tmp.size()-1].append(*pWord);
            continue;
           }
        if (marks.find(*pWord)==marks.end())
           { // not a mark
            tmp.push_back(*pWord);
            continue;
           }
        if (tmp.empty())
           { // not a mark
            tmp.push_back(*pWord);
            continue;
           }
        // punctuation must be appended to prev word
        tmp[tmp.size()-1].append(*pWord);
       }
    tmp.swap(words);
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
::std::basic_string<CharType, Traits, Allocator>
correctPunctuation( const ::std::basic_string<CharType, Traits, Allocator>               &text
                  , const ::std::set< ::std::basic_string<CharType, Traits, Allocator> > &marks
                  , const ::std::set< ::std::basic_string<CharType, Traits, Allocator> > &frontMarks // such as (, {, [
                  )
   {
    ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > words;
    splitToWords( words, text );
    correctPunctuation( words, marks, frontMarks );
    ::std::basic_string<CharType, Traits, Allocator> resStr;
    typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::const_iterator wit = words.begin();
    for(; wit!=words.end(); ++wit)
       {
        if (!resStr.empty()) resStr.append(1, (CharType)' ');
        resStr.append(*wit);
       }
    return resStr;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
::std::set< ::std::basic_string<CharType, Traits, Allocator> >
makeStdPunctuationMarkSet()
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    ::std::set< string_type > res;
    res.insert( string_type(1,(CharType)'.') );
    res.insert( string_type(3,(CharType)'.') );
    res.insert( string_type(1,(CharType)',') );
    res.insert( string_type(1,(CharType)';') );
    res.insert( string_type(1,(CharType)':') );
    res.insert( string_type(1,(CharType)'?') );
    res.insert( string_type(1,(CharType)'!') );
    res.insert( string_type(1,(CharType)'>') );
    res.insert( string_type(1,(CharType)')') );
    res.insert( string_type(1,(CharType)'}') );
    res.insert( string_type(1,(CharType)']') );
    return res;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
::std::set< ::std::basic_string<CharType, Traits, Allocator> >
makeStdPunctuationFrontMarkSet()
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    ::std::set< string_type > res;
    res.insert( string_type(1,(CharType)'<') );
    res.insert( string_type(1,(CharType)'(') );
    res.insert( string_type(1,(CharType)'{') );
    res.insert( string_type(1,(CharType)'[') );
    return res;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::const_iterator
buildLineNotLonger( ::std::basic_string<CharType, Traits, Allocator> &resLine // NOTE: must be empty
                  , typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::const_iterator pWord
                  , typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::const_iterator pEnd
                  , typename ::std::basic_string<CharType, Traits, Allocator>::size_type maxSize
                  )
   {
    for(; pWord!=pEnd && resLine.size()+1+pWord->size()<=maxSize ; ++pWord)
       {
        if (!resLine.empty()) resLine.append( 1, (CharType)' ' );
        resLine.append(*pWord);
       }
    if (pWord!=pEnd && resLine.empty())
       resLine.append(*pWord++);

    return pWord;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpasePred
        >
::std::basic_string<CharType, Traits, Allocator>
adjustLineWidthStep( const ::std::basic_string<CharType, Traits, Allocator> &str
                   , typename ::std::basic_string<CharType, Traits, Allocator>::size_type width
                   , const IsSpasePred &isSpacePred
                   )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    typename string_type::size_type pos = 0, size = str.size();
    string_type resStr;
    for(; pos!=size && (resStr.size() + (size - pos))<width; ++pos)
       { // rest = size - pos
        if (isSpacePred(str[pos])) resStr.append( 1, str[pos] ); // make dup of cur space
        resStr.append( 1, str[pos] );
       }
    resStr.append(str, pos, str.npos);
    return resStr;
   }

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        , typename IsSpasePred
        >
::std::basic_string<CharType, Traits, Allocator>
adjustLineWidth( const ::std::basic_string<CharType, Traits, Allocator> &str
               , typename ::std::basic_string<CharType, Traits, Allocator>::size_type width
               , const IsSpasePred &isSpacePred
               )
   {
    if (str.size()>=width) return str;

    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    string_type res = str;
    while(res.size()<width)
       res = adjustLineWidthStep(res, width, isSpacePred);
    return res;
   }

//-----------------------------------------------------------------------------
enum EFormatFlag
{
    ff_Left,
    ff_Right,
    ff_Center,
    ff_Width,
};

//-----------------------------------------------------------------------------
template< typename CharType
        , typename Traits
        , typename Allocator
        >
::std::basic_string<CharType, Traits, Allocator>
formatPara( const ::std::basic_string<CharType, Traits, Allocator> &paraText
          , typename ::std::basic_string<CharType, Traits, Allocator>::size_type firstIndent // first line indent
          , typename ::std::basic_string<CharType, Traits, Allocator>::size_type width
          , EFormatFlag howFormat
          , bool adjustLastLineWidth = false // dont enlarge last line width
          , const ::std::basic_string<CharType, Traits, Allocator> &firstLinePrefixStr = ::std::basic_string<CharType, Traits, Allocator>()
          , const ::std::basic_string<CharType, Traits, Allocator> &linePrefixStr      = ::std::basic_string<CharType, Traits, Allocator>()
          , bool noIndentOnSingleLine = true
          , bool fCorrectPunctuation  = false
          )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;

    if (firstIndent>=width/2) firstIndent = width/2;
    ::std::vector< string_type > words;
    splitToWords( words, paraText );

    if (fCorrectPunctuation)
       correctPunctuation( words, makeStdPunctuationMarkSet<CharType,Traits,Allocator>(), makeStdPunctuationFrontMarkSet<CharType,Traits,Allocator>() );

    ::std::vector< string_type > lines;

    typename ::std::vector< ::std::basic_string<CharType, Traits, Allocator> >::const_iterator pWord = words.begin();
    for(; pWord != words.end();  /* ++pWord */ )
       {
        typename string_type::size_type w = (pWord == words.begin() ? width - firstIndent : width );
        string_type lineText;
        pWord = buildLineNotLonger( lineText, pWord, words.end(), w );
        //if (w!=width) // first line
        //   lineText = string_type( firstIndent, (CharType)' ') + lineText; //
        lines.push_back(lineText);
       }

    typename ::std::vector< string_type >::size_type lineIdx = 0, linesSize = lines.size();
    for( ; lineIdx != linesSize; ++lineIdx )
       {
        //linesSize<2 - single line
        //linesSize<2 && !noIndentOnSingleLine
        //(noIndentOnSingleLine && linesSize<2)
        // !lineIdx - first line
        // lineIdx==(linesSize-1) - last line
        if (!lineIdx)
           {
            if (linesSize<2 && !noIndentOnSingleLine)
               {
                switch(howFormat)
                   {
                    case ff_Left:
                         lines[lineIdx] = string_type( firstIndent, (CharType)' ') + lines[lineIdx]; //
                         break;
                    case ff_Right:
                         lines[lineIdx].append(firstIndent, (CharType)' ');
                         if (lines[lineIdx].size()<width)
                            lines[lineIdx] = string_type( (width - lines[lineIdx].size()), (CharType)' ') + lines[lineIdx]; //
                         break;
                    case ff_Center:
                         if (lines[lineIdx].size()<width)
                             lines[lineIdx] = string_type( (width - lines[lineIdx].size())/2, (CharType)' ') + lines[lineIdx]; //
                         break;
                    case ff_Width:
                         lines[lineIdx] = adjustLineWidth( lines[lineIdx], width-firstIndent, isSpace<CharType>());
                         lines[lineIdx] = string_type( firstIndent, (CharType)' ') + lines[lineIdx]; //
                         break;
                   }
               }
            if (!firstLinePrefixStr.empty()) lines[lineIdx] = firstLinePrefixStr + lines[lineIdx];
            continue;
           }
        if (lineIdx==(linesSize-1))
           { // last line
            switch(howFormat)
               {
                case ff_Left:  break;
                case ff_Right:
                     if (lines[lineIdx].size()<width)
                        lines[lineIdx] = string_type( (width - lines[lineIdx].size()), (CharType)' ') + lines[lineIdx]; //
                     break;
                case ff_Center:
                     if (lines[lineIdx].size()<width)
                         lines[lineIdx] = string_type( (width - lines[lineIdx].size())/2, (CharType)' ') + lines[lineIdx]; //
                     break;
                case ff_Width:
                     if (adjustLastLineWidth)
                        lines[lineIdx] = adjustLineWidth( lines[lineIdx], width, isSpace<CharType>());
                     break;
               }
            if (!linePrefixStr.empty()) lines[lineIdx] = linePrefixStr + lines[lineIdx];
            continue;
           }
        // not first and not last
        switch(howFormat)
           {
            case ff_Left:
                 break;
            case ff_Right:
                 if (lines[lineIdx].size()<width)
                    lines[lineIdx] = string_type( (width - lines[lineIdx].size()), (CharType)' ') + lines[lineIdx]; //
                 break;
            case ff_Center:
                 if (lines[lineIdx].size()<width)
                     lines[lineIdx] = string_type( (width - lines[lineIdx].size())/2, (CharType)' ') + lines[lineIdx]; //
                 break;
            case ff_Width:
                 lines[lineIdx] = adjustLineWidth( lines[lineIdx], width, isSpace<CharType>());
                 break;
           }
        if (!linePrefixStr.empty()) lines[lineIdx] = linePrefixStr + lines[lineIdx];
       }

    string_type resStr;
    lineIdx = 0;
    for( ; lineIdx != linesSize; ++lineIdx )
       {
        if (lineIdx) resStr.append(1,(CharType)'\n');
        resStr.append(lines[lineIdx]);
       }
    return resStr;
   }


/*
void splitToWords( ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &words
                 , const ::std::basic_string<CharType, Traits, Allocator> &line
                 )
*/



}; // namespace txt
}; // namespace marty

#endif /* MARTY_TEXTFORMAT_H */

