#ifndef MARTY_AUTORUN_H
#define MARTY_AUTORUN_H

/* add this lines to your scr
#ifndef MARTY_AUTORUN_H
    #include <marty/autorun.h>
#endif
*/

#ifndef MARTY_WINAPI_H
    #include <marty/winapi.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif


namespace marty
{

namespace autorun_utils
{

    struct CIsSpace{
        CIsSpace() {}
        bool operator()(char ch) const
        {
            if (ch==' ' || ch=='\r' || ch=='\n' || ch=='\t') return true;
            return false;
        }
        bool operator()(wchar_t ch) const
        {
            if (ch==L' ' || ch==L'\r' || ch==L'\n' || ch==L'\t') return true;
            return false;
        }
    };
    
    struct CIsQuot{
        CIsQuot() {}
        bool operator()(char ch) const
        {
            if (ch=='\"') return true;
            return false;
        }
        bool operator()(wchar_t ch) const
        {
            if (ch==L'\"') return true;
            return false;
        }
    };
    
    struct CIsApos{
        CIsApos() {}
        bool operator()(char ch) const
        {
            if (ch=='\'') return true;
            return false;
        }
        bool operator()(wchar_t ch) const
        {
            if (ch==L'\'') return true;
            return false;
        }
    };
    
    struct CIsQuotApos{
        CIsQuotApos() {}
        bool operator()(char ch) const
        {
            if (ch=='\"' || ch=='\'') return true;
            return false;
        }
        bool operator()(wchar_t ch) const
        {
            if (ch==L'\"' || ch==L'\'') return true;
            return false;
        }
    };
    
    
    struct CIsPairSep{
        CIsPairSep() {}
        bool operator()(char ch) const
        {
            if (ch=='=' || ch==':') return true;
            return false;
        }
    };
    
    struct CIsCharExact{
        char chcmp;
        CIsCharExact(char c) : chcmp(c) {}
        bool operator()(char ch) const
        {
            if (chcmp==ch) return true;
            return false;
        }
    };
    
    
    struct CIsCharOneOf{
        const char *charsStr;
        CIsCharOneOf(const char *s) : charsStr(s) {}
        bool operator()(char ch) const
        {
            if (!charsStr) return false;
            const char *s = charsStr;
            while(*s) 
               { 
                if (*s++==ch) 
                   return true;
               }
            return false;
        }
    };
    
    
    
    struct CIsLinefeed : public CIsCharExact{
        CIsLinefeed() : CIsCharExact('\n') {}
    };
    
    struct CIsNotAnyChar{
        bool operator()(char ch) const
        {
            return false;
        }
    };
    
    struct CIsAnyChar{
        bool operator()(char ch) const
        {
            return true;
        }
    };



    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    void rtrim( ::std::basic_string<CharType, Traits, Allocator> &str, const Pred &p )
    {
        if (str.empty()) return;
        typename ::std::basic_string<CharType, Traits, Allocator>::size_type i = str.size();
        for(; i; --i)
           {
            if (!p(str[i-1])) 
               {
                str = ::std::basic_string<CharType, Traits, Allocator>( str, 0, i );
                return;
               }
           }
        str.clear();
    }
    
    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    void ltrim( ::std::basic_string<CharType, Traits, Allocator> &str, const Pred &p )
    {
        if (str.empty()) return;
        typename ::std::basic_string<CharType, Traits, Allocator>::size_type i = 0;
        for(; i!=str.size(); ++i)
           {
            if (!p(str[i])) 
               {
                str = ::std::basic_string<CharType, Traits, Allocator>( str, i, str.size() - i );
                return;
               }
           }
        str.clear();
    }
    
    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    void trim( ::std::basic_string<CharType, Traits, Allocator> &str, const Pred &p )
    {
        rtrim(str, p);
        ltrim(str, p);
    }
    
    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    void rtrim( std::vector< ::std::basic_string<CharType, Traits, Allocator> > &v, const Pred &p )
    {
        std::vector< ::std::string >::const_iterator vit = v.begin();
        for(; vit != v.end(); ++vit) rtrim(*vit, p);
    }
    
    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    void ltrim( std::vector< ::std::basic_string<CharType, Traits, Allocator> > &v, const Pred &p )
    {
        std::vector< ::std::string >::const_iterator vit = v.begin();
        for(; vit != v.end(); ++vit) ltrim(*vit, p);
    }
    
    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    void trim( std::vector< ::std::basic_string<CharType, Traits, Allocator> > &v, const Pred &p )
    {
        std::vector< ::std::string >::const_iterator vit = v.begin();
        for(; vit != v.end(); ++vit) trim(*vit, p);
    }
    
    
    
    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    ::std::basic_string<CharType, Traits, Allocator> rtrim_copy( const ::std::basic_string<CharType, Traits, Allocator> &str, const Pred &p )
    {
        if (str.empty()) return str;
        typename ::std::basic_string<CharType, Traits, Allocator>::size_type i = str.size();
        for(; i; --i)
           {
            if (!p(str[i-1])) return ::std::basic_string<CharType, Traits, Allocator>( str, 0, i );
           }
        return ::std::string();
    }
    
    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    ::std::basic_string<CharType, Traits, Allocator> ltrim_copy( const ::std::basic_string<CharType, Traits, Allocator> &str, const Pred &p )
    {
        if (str.empty()) return str;
        ::std::basic_string<CharType, Traits, Allocator>::size_type i = 0;
        for(; i!=str.size(); ++i)
           {
            if (!p(str[i])) return ::std::basic_string<CharType, Traits, Allocator>( str, i, str.size() - i );
           }
        return ::std::string();
    }
    
    template< typename CharType, typename Traits, typename Allocator, typename Pred >
    ::std::basic_string<CharType, Traits, Allocator> trim_copy( const ::std::basic_string<CharType, Traits, Allocator> &str, const Pred &p )
    {
        return ltrim_copy( rtrim_copy(str, p), p );
    }

    template< typename CharType
            , typename Traits
            , typename Allocator
            >
    bool
    startsWith( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
              , const ::std::basic_string<CharType, Traits, Allocator> &strStartsWith )
       {
        if (!strCompareTo.compare(0, strStartsWith.size(), strStartsWith, 0, strStartsWith.size()))
           return true;
        return false;
       }
    
    //-----------------------------------------------------------------------------
    template< typename CharType
            , typename Traits
            , typename Allocator
            >
    bool
    startsWith( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
              , const CharType *strStartsWith )
       {
        return startsWith( strCompareTo, ::std::basic_string<CharType, Traits, Allocator>(strStartsWith) );
       }
    
    //-----------------------------------------------------------------------------
    template< typename CharType
            , typename Traits
            , typename Allocator
            >
    bool
    startsWithI( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
               , const ::std::basic_string<CharType, Traits, Allocator> &strStartsWith )
       {
        return startsWith( toLowerCopy(strCompareTo )
                         , toLowerCopy(strStartsWith)
                         );
       }
    
    //-----------------------------------------------------------------------------
    template< typename CharType
            , typename Traits
            , typename Allocator
            >
    bool
    startsWithI( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
              , const CharType *strStartsWith )
       {
        return startsWithI( strCompareTo, ::std::basic_string<CharType, Traits, Allocator>(strStartsWith) );
       }
    
    //-----------------------------------------------------------------------------
    template< typename CharType
            , typename Traits
            , typename Allocator
            >
    bool
    endsWith( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
            , const ::std::basic_string<CharType, Traits, Allocator> &strEndsWith )
       {
        if (strCompareTo.size()<strEndsWith.size()) return false;
        if (!strCompareTo.compare( strCompareTo.size()-strEndsWith.size() // offset in strCompareTo
                                 , strEndsWith.size()                     // len of campared part
                                 , strEndsWith                            // string compare with
                                 , 0                                      // offset in strEndsWith
                                 , strEndsWith.size()                     // The maximum number of characters from the strEndsWith to be compared
                                 ))
           return true;
        return false;
       }
    
    //-----------------------------------------------------------------------------
    template< typename CharType
            , typename Traits
            , typename Allocator
            >
    bool
    endsWithI( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
               , const ::std::basic_string<CharType, Traits, Allocator> &strEndsWith )
       {
        return endsWith( toLowerCopy(strCompareTo)
                       , toLowerCopy(strEndsWith)
                       );
       }



    template <typename CharType, typename Traits, typename Allocator>
    ::std::basic_string<CharType, Traits, Allocator> getAppExecutableName()
    {
        return std::basic_string<CharType, Traits, Allocator>();
    }
    
    template<>
    inline
    std::basic_string<char, std::char_traits<char>, std::allocator<char> >
    getAppExecutableName<char, std::char_traits<char>, std::allocator<char> >()
    {
        MARTY_WINAPI::registry::CAutoHeapAlloc<char> bufAlloc(8192);
        DWORD dwres = GetModuleFileNameA( 0, bufAlloc.getBuf(), (DWORD)(bufAlloc.getSize()) - 1 );
        if (dwres>((DWORD)(bufAlloc.getSize()) - 1)) bufAlloc.getBuf()[(DWORD)(bufAlloc.getSize()) - 1] = 0;
        else bufAlloc.getBuf()[dwres] = 0;
        return std::basic_string<char>(bufAlloc.getBuf());
    }
    
    template<>
    inline
    std::basic_string<wchar_t, std::char_traits<wchar_t>, std::allocator<wchar_t> > getAppExecutableName< wchar_t, std::char_traits<wchar_t>, std::allocator<wchar_t> >()
    {
        MARTY_WINAPI::registry::CAutoHeapAlloc<wchar_t> bufAlloc(8192);
        DWORD dwres = GetModuleFileNameW( 0, bufAlloc.getBuf(), (DWORD)(bufAlloc.getSize()) - 1);
        if (dwres>((DWORD)(bufAlloc.getSize()) - 1)) bufAlloc.getBuf()[(DWORD)(bufAlloc.getSize()) - 1] = 0;
        else bufAlloc.getBuf()[dwres] = 0;
        return std::basic_string<wchar_t>(bufAlloc.getBuf());
    }
    
    template <typename CharType, typename Traits, typename Allocator>
    std::basic_string<CharType, Traits, Allocator> getFilePath( const std::basic_string<CharType, Traits, Allocator> &fullname, const CharType *pathSeps)
    {
        std::basic_string<CharType, Traits, Allocator>::size_type slashPos = fullname.find_last_of(pathSeps); // "/\\"
        if (slashPos == fullname.npos) return std::basic_string<CharType, Traits, Allocator>();
        return std::basic_string<CharType, Traits, Allocator>(fullname, 0, slashPos);
    }
    
    template <typename CharType, typename Traits, typename Allocator>
    std::basic_string<CharType, Traits, Allocator> getFileName( const std::basic_string<CharType, Traits, Allocator> &fullname, const CharType *pathSeps)
    {
        std::basic_string<CharType, Traits, Allocator>::size_type slashPos = fullname.find_last_of(pathSeps); // "/\\"
        if (slashPos == fullname.npos) return fullname;
        return std::basic_string<CharType, Traits, Allocator>(fullname, slashPos+1, fullname.npos);
    }
    
    template <typename CharType, typename Traits, typename Allocator>
    std::basic_string<CharType, Traits, Allocator> getFileExt( const std::basic_string<CharType, Traits, Allocator> &fullname, const CharType *extSeps)
    {
        std::basic_string<CharType, Traits, Allocator>::size_type dotPos = fullname.find_last_of(extSeps); // "/\\"
        if (dotPos == fullname.npos) return std::basic_string<CharType, Traits, Allocator>();
        return std::basic_string<CharType, Traits, Allocator>(fullname, dotPos+1, fullname.npos);
    }
    
    template <typename CharType, typename Traits, typename Allocator>
    std::basic_string<CharType, Traits, Allocator> getFileNameOnly( const std::basic_string<CharType, Traits, Allocator> &fullname, const CharType *pathSeps, const CharType *extSeps)
    {
        std::basic_string<CharType, Traits, Allocator> filename = getFileName( fullname, pathSeps);
        std::basic_string<CharType, Traits, Allocator>::size_type dotPos = filename.find_last_of(extSeps); // "/\\"
        if (dotPos == filename.npos) return std::basic_string<CharType, Traits, Allocator>();
        return std::basic_string<CharType, Traits, Allocator>(filename, 0, dotPos);
    }

}; // namespace autorun_utils



struct CAutorunConfig
{
    typedef TCHAR CharType;
    std::basic_string< CharType, std::char_traits<CharType>, std::allocator<CharType> > autorunRegPath;
    std::basic_string< CharType, std::char_traits<CharType>, std::allocator<CharType> > programAutorunName;

    // additional option which tells the app to start it's main function immediatelly
    std::basic_string< CharType, std::char_traits<CharType>, std::allocator<CharType> > programRegKey;
    std::basic_string< CharType, std::char_traits<CharType>, std::allocator<CharType> > programAutostartValueName1;
    std::basic_string< CharType, std::char_traits<CharType>, std::allocator<CharType> > programAutostartValueName2;
    std::basic_string< CharType, std::char_traits<CharType>, std::allocator<CharType> > programAutostartValueName3;

    bool      autorun;
    bool      autostart1;
    bool      autostart2;
    bool      autostart3;

    CAutorunConfig( TCHAR *an, TCHAR *regPath=_T(""), TCHAR *regValName1=_T(""), TCHAR *regValName2=_T(""), TCHAR *regValName3=_T("") ) 
       : autorunRegPath(_T("Software\\Microsoft\\Windows\\CurrentVersion\\Run"))
       , programAutorunName(an)
       , programRegKey(regPath)
       , programAutostartValueName1(regValName1)
       , programAutostartValueName2(regValName2)
       , programAutostartValueName3(regValName3)
       , autorun(false)
       , autostart1(false)
       , autostart2(false)
       , autostart3(false)
       {}
    CAutorunConfig( TCHAR *an, const std::basic_string< CharType, std::char_traits<CharType>, std::allocator<CharType> > &regPath = _T("")
                  , TCHAR *regValName1 = _T("")
                  , TCHAR *regValName2 = _T("")
                  , TCHAR *regValName3 = _T("")
                  ) 
       : autorunRegPath(_T("Software\\Microsoft\\Windows\\CurrentVersion\\Run"))
       , programAutorunName(an)
       , programRegKey(regPath)
       , programAutostartValueName1(regValName1)
       , programAutostartValueName2(regValName2)
       , programAutostartValueName3(regValName3)
       , autorun(false)
       , autostart1(false)
       , autostart2(false)
       , autostart3(false)
       {}

    bool saveAutorunToReg( bool share64ForBoth, HKEY hRootKey = HKEY_CURRENT_USER ) const
       {
        using namespace MARTY_WINAPI::registry;

        HKEY hAutorunKey;
        LONG res = createKey( hRootKey, autorunRegPath, &hAutorunKey, share64ForBoth );
        if (res==ERROR_SUCCESS)
           {
            if (autorun)
               {
                std::basic_string<TCHAR> appExe  = autorun_utils::getAppExecutableName<TCHAR, std::char_traits<TCHAR>, std::allocator<TCHAR> >();
                autorun_utils::trim( appExe, autorun_utils::CIsSpace() );
                std::basic_string<TCHAR> cmdLine =  ::GetCommandLine();
                autorun_utils::trim( cmdLine, autorun_utils::CIsSpace() ); autorun_utils::trim( cmdLine, autorun_utils::CIsQuotApos() );
                std::basic_string<TCHAR> autorunCommandLine;
                if (autorun_utils::startsWith(cmdLine, appExe))
                   {
                    autorunCommandLine = cmdLine;
                   }
                else
                   {
                    autorunCommandLine = appExe + std::basic_string<TCHAR>( 1, _T(' ') ) + cmdLine;
                   }
                setValue( hAutorunKey, programAutorunName, autorunCommandLine ); // (TCHAR)'A'
               }
            else
               {
                deleteValue( hAutorunKey, programAutorunName.c_str() );
               }
            closeKey( hAutorunKey );
            return true;
           }
        return false;
       }

    bool saveAutostartToReg( bool share64ForBoth, HKEY hRootKey = HKEY_CURRENT_USER ) const
       {
        if (programRegKey.empty()  /* || programAutostartValueName.empty() */ ) return true;
        using namespace MARTY_WINAPI::registry;
        //return 
        if (!programAutostartValueName1.empty()) setValue( hRootKey, programRegKey, programAutostartValueName1 ); // == ERROR_SUCCESS;
        if (!programAutostartValueName2.empty()) setValue( hRootKey, programRegKey, programAutostartValueName2 );
        if (!programAutostartValueName3.empty()) setValue( hRootKey, programRegKey, programAutostartValueName3 );
        return true;
       }

    bool saveToReg( bool share64ForBoth, HKEY hRootKey = HKEY_CURRENT_USER ) const
       {
        return saveAutorunToReg(share64ForBoth, hRootKey) && saveAutostartToReg(share64ForBoth, hRootKey);
       }

    bool loadAutorunFromReg( bool share64ForBoth, HKEY hRootKey = HKEY_CURRENT_USER )
       {
         using namespace MARTY_WINAPI::registry;
         HKEY hAutorunKey;
         LONG res = createKey( hRootKey, autorunRegPath, &hAutorunKey, share64ForBoth );
         if (res==ERROR_SUCCESS)
            {
             std::basic_string<TCHAR> autorunExe = getValue( hAutorunKey, programAutorunName, std::basic_string<TCHAR>() );
             std::basic_string<TCHAR> appExe     = autorun_utils::getAppExecutableName<TCHAR, std::char_traits<TCHAR>, std::allocator<TCHAR> >();
             autorunExe =  autorun_utils::getFileName( autorunExe, _T("/\\"));
             appExe     =  autorun_utils::getFileName( appExe    , _T("/\\"));
             autorunExe = MARTY_FILENAME::prepareForCompare(autorunExe );
             appExe     = MARTY_FILENAME::prepareForCompare(appExe     );
             //if (autorunExe!=appExe)
             if (autorunExe.empty() || !autorun_utils::startsWith(autorunExe, appExe))
                {
                 //::RegDeleteValue( hAutorunKey, programAutorunName );
                 autorun = false;
                }
             else
                {
                 autorun = true;
                }
             closeKey( hAutorunKey );
             return true;
            }
         return false;
       }

    bool loadAutostartFromReg( bool share64ForBoth, HKEY hRootKey = HKEY_CURRENT_USER )
       {
        if (programRegKey.empty() /*  || programAutostartValueName.empty() */ ) return true;
        using namespace MARTY_WINAPI::registry;
        if (!programAutostartValueName1.empty()) autostart1 = getValue( hRootKey, programRegKey, programAutostartValueName1, autostart1, share64ForBoth );
        if (!programAutostartValueName2.empty()) autostart2 = getValue( hRootKey, programRegKey, programAutostartValueName2, autostart2, share64ForBoth );
        if (!programAutostartValueName3.empty()) autostart3 = getValue( hRootKey, programRegKey, programAutostartValueName3, autostart3, share64ForBoth );
        return true;
       }

    bool loadFromReg( bool share64ForBoth, HKEY hRootKey = HKEY_CURRENT_USER )
       {
        return loadAutorunFromReg(share64ForBoth, hRootKey) && loadAutostartFromReg(share64ForBoth, hRootKey);
       }

}; // struct CAutorunConfig



}; // namespace marty


#endif /* MARTY_AUTORUN_H */

