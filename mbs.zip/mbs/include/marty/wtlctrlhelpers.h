template <typename IterType>
void enableControls( IterType b, IterType e, bool fEnable)
   {
    for(; b!=e; ++b)
       {
        CWindow wnd(GetDlgItem(*b));
        wnd.EnableWindow(fEnable ? TRUE : FALSE);
       }
   }

void setControlChecked(int ctrlId, bool fChecked)
   {
    CButton btn(GetDlgItem(ctrlId));
    btn.SetCheck(fChecked ? BST_CHECKED : BST_UNCHECKED);
   }

bool getControlChecked(int ctrlId)
   {
    CButton btn(GetDlgItem(ctrlId));
    return (btn.GetCheck()==BST_CHECKED);
   }

void enableControl(int ctrlId, bool fEnable)
   {
    CWindow wnd(GetDlgItem(ctrlId));
    wnd.EnableWindow( fEnable ? TRUE : FALSE );
   }


bool isControlEnabled( int ctrlId )
{
   if (::IsWindowEnabled( GetDlgItem(ctrlId))) return true;
   return false;
}

void setEditLimitText( int editId, UINT nMax )
{
    CEdit e(GetDlgItem(editId));
    e.SetLimitText(nMax);
}

void setControlText( int ctrlId, LPCTSTR txt )
{
    CWindow wnd(GetDlgItem(ctrlId));
    wnd.SetWindowText(txt);
}

