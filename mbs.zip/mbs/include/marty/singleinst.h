#ifndef MARTY_SINGLEINST_H
#define MARTY_SINGLEINST_H

/* add this lines to your scr
#ifndef MARTY_SINGLEINST_H
    #include <marty/singleinst.h>
#endif
*/

#ifndef MARTY_WINAPI_H
    #include <marty/winapi.h>
#endif


namespace marty
{
namespace win32
{

struct CSingleInstanceChecker
{
    private:
        HANDLE       hMut;
        bool         fAllreadyRunning;
        const TCHAR *pMutexName;

        bool tryCreate()
           {
            SetLastError(0);
            hMut = ::CreateMutex(NULL, FALSE, pMutexName );
            if (GetLastError() == ERROR_ALREADY_EXISTS) 
               fAllreadyRunning = true;
            else
               fAllreadyRunning = false;
            return fAllreadyRunning;
           }

    public:

        CSingleInstanceChecker( const TCHAR *pMutName)
           : pMutexName(pMutName), hMut(0), fAllreadyRunning(false)
           {
            tryCreate();
           }

        bool testAllreadyRuning()
           {
            if (hMut) 
               {
                ::CloseHandle(hMut);
                hMut = 0;
               }

            tryCreate();
            return fAllreadyRunning;
           }

        ~CSingleInstanceChecker()
           {
            if (hMut) 
               ::CloseHandle(hMut);
           }

        bool getAllreadyRuningState() const { return fAllreadyRunning; }

        bool waitForSingleInstanceRunAllowed( UINT waitNumSec )
           {
            if (getAllreadyRuningState())
               {
                // allready exist
                UINT i=0;
                //bool allreadyRuning = true;
                for(; i!=(waitNumSec*10); ++i)
                   {
                    ::Sleep(100);
                    if (!testAllreadyRuning()) 
                       {
                        //allreadyRuning = false; 
                        break;
                       }
                   }
                //if (allreadyRuning) return EC_OK;
               }
            return !getAllreadyRuningState();
           }

}; // struct CSingleInstanceChecker



}; // namespace win32
}; // namespace marty



#endif /* MARTY_SINGLEINST_H */

