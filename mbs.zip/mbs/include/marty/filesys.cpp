/*
   Copyright (c) 2007-2009 Alex Martynov, amart at mail.ru
   This code can be used without any limitations.
   This code provided as is, use it on your own risk.
*/

#ifndef MARTY_FILESYS_CPP
#define MARTY_FILESYS_CPP


#ifndef MARTY_FILESYS_H
    #include <marty/filesys.h>
#endif


#ifndef _WIN32

BEGIN_MARTY_FILESYSTEM_NS

//-----------------------------------------------------------------------------
CFilenameEncoder< ::std::string::traits_type::char_type
                , ::std::string::traits_type
                , ::std::string::allocator_type>& 
getFilenameEncoder(const ::std::string &dummy)
   {
    static CFilenameEncoder< ::std::string::traits_type::char_type
                           , ::std::string::traits_type
                           , ::std::string::allocator_type> enc; 
    return enc;
   }

//-----------------------------------------------------------------------------
CFilenameEncoder< ::std::wstring::traits_type::char_type
                , ::std::wstring::traits_type
                , ::std::wstring::allocator_type>& 
getFilenameEncoder(const ::std::wstring &dummy)
   {
    static CFilenameEncoder< ::std::wstring::traits_type::char_type
                           , ::std::wstring::traits_type
                           , ::std::wstring::allocator_type> enc;
    return enc;
   }



END_MARTY_FILESYSTEM_NS

#endif /* WIN32 */

#endif /* MARTY_FILESYS_CPP */

#if 0

SOCKET ifs_socket(int af, int type, int protocol)
{
    unsigned long proto_buffers_len = 4096;
    SOCKET out = INVALID_SOCKET;
    int nProtocols[] = {protocol, 0};
    WSAPROTOCOL_INFO *pInfo = NULL;
    int nResult;
    char str[128];

    //while ((pInfo = (WSAPROTOCOL_INFO *)realloc(pInfo, proto_buffers_len)))
    while ((pInfo = (WSAPROTOCOL_INFO *)malloc(proto_buffers_len))!=0)
    {
        nResult = WSAEnumProtocols(nProtocols, pInfo, &proto_buffers_len);
 //       sprintf(str, "pInfo 0x%X nResult = %d,\n",(int)pInfo,nResult);
//          write_message_file(str, 0);
        if (nResult != SOCKET_ERROR)
        {
            for (int i = 0; i < nResult; ++i)
                if (((af == AF_UNSPEC) || (af == pInfo[i].iAddressFamily))&&(type == pInfo[i].iSocketType) &&(pInfo[i].dwServiceFlags1 & XP1_IFS_HANDLES))
                {
                    out = WSASocket(af, type, protocol, &pInfo[i], 0, 0);
                    break;
                }
            break;
        }
        if (WSAGetLastError() != WSAENOBUFS)
            break;
        free(pInfo);
    }
    if(pInfo)
        free(pInfo);
    //
    return out;
}

#endif

