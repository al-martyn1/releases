/*
   Copyright (c) 2007-2014 Alex Martynov, amart at mail.ru
   This code can be used without any limitations.
   This code provided as is, use it on your own risk.
*/

#include <marty/ponce.h>
#ifdef MARTY_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef MARTY_WINAPI_H
#define MARTY_WINAPI_H

/*
#ifndef MARTY_WINAPI_H
    #include <marty/winapi.h>
#endif
*/

/* Copyright (c) 2004-2007 Alex Martynov, amart at mail dot ru
 */

// define WINAPI_IN_MARTY_NAMESPACE for use ::marty::winapi::* insted of ::winapi::*
// also you can define MARTY_NAMESPACE macro, which automaticaly define WINAPI_IN_MARTY_NAMESPACE

/*
#ifdef USE_MARTY_NAMESPACE
    #ifndef MARTY_NAMESPACE
        #define MARTY_NAMESPACE
    #endif
#endif
*/

#ifndef MARTY_BASICTCHARDEFS_H
    #include <marty/basictchardefs.h>
#endif



#ifdef USE_MARTY_NAMESPACE
    #ifndef WINAPI_IN_MARTY_NAMESPACE
        #define WINAPI_IN_MARTY_NAMESPACE
    #endif
#endif

#ifdef WINAPI_IN_MARTY_NAMESPACE
    #ifndef MARTY_NS
        #define BEGIN_MARTY_NS          namespace marty {
        #define END_MARTY_NS            };
        #define MARTY_NS                ::marty::
    #endif
    #define MARTY_WINAPI_NS         MARTY_NS winapi::
    #define MARTY_WINAPI            MARTY_NS winapi
#else
    #ifndef MARTY_NS
        #define BEGIN_MARTY_NS
        #define END_MARTY_NS
        #define MARTY_NS                ::
    #endif
    #define MARTY_WINAPI_NS        MARTY_NS winapi::
    #define MARTY_WINAPI           MARTY_NS winapi
#endif

#define BEGIN_MARTY_WINAPI_NS      BEGIN_MARTY_NS namespace winapi {
#define END_MARTY_WINAPI_NS        END_MARTY_NS   };

#ifdef WINAPI_IN_MARTY_NAMESPACE
    #define USING_MARTY_WINAPI using namespace ::marty::winapi
#else
    #define USING_MARTY_WINAPI using namespace ::winapi
#endif

#if !defined(_WINDOWS_)
    #include <windows.h>
#endif

#if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
    #include <malloc.h>
#endif



#if !defined(WINAPI_NO_SHFOLDER) && defined(WIN32) && defined(__GNUC__)
    #define WINAPI_NO_SHFOLDER
#endif /* MinGW does not support ShFolder.h */


#if !defined(WINAPI_NO_SHFOLDER)
#if defined(WINAPI_FORCE_SHFOLDER)
/* ShlObj.h need to be included before ShFolder.h */
#ifndef _SHLOBJ_H_
    #include <ShlObj.h>
#endif

#ifndef _SHFOLDER_H_
    #include <ShFolder.h>
#endif
#endif /* WINAPI_FORCE_SHFOLDER */
#endif /* WINAPI_NO_SHFOLDER */



#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif


#ifndef FILENAME_OLD_NAMES
    #define FILENAME_OLD_NAMES
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif


#ifdef WINAPI_IN_MARTY_NAMESPACE
namespace marty {
#endif


namespace winapi
{

#ifndef FILENAME_USING_TSTRING
    #ifdef FILENAME_IN_MARTY_NAMESPACE
        //using ::marty::filename::tstring;
        typedef ::marty::filename::tstring tstring;
    #else
        //using ::filename::tstring;
        typedef ::filename::tstring        tstring;
    #endif
#endif


inline
bool getVersionInfo(OSVERSIONINFO &info)
   {
    info.dwOSVersionInfoSize = sizeof(info);
    return GetVersionEx(&info) ? true : false;
   }

inline
bool getVersionInfo(OSVERSIONINFOEX &info)
   {
    info.dwOSVersionInfoSize = sizeof(info);
    return GetVersionEx((LPOSVERSIONINFO)&info) ? true : false;
   }

inline
DWORD getWinVer()
   {
    OSVERSIONINFO info;
    if (!getVersionInfo(info)) return 0x0400;
    return info.dwMajorVersion<<8 | info.dwMinorVersion;
   }

inline
bool isWinNt()
   {
    OSVERSIONINFO info;
    if (!getVersionInfo(info)) return false;
    return info.dwPlatformId==VER_PLATFORM_WIN32_NT;
   }


/*
#define VER_PLATFORM_WIN32s             0
#define VER_PLATFORM_WIN32_WINDOWS      1
#define VER_PLATFORM_WIN32_NT           2
*/

/* Marty/WinApi constants - keeped in sync with WinApi VER_PLATFORM_* values */

#if 0

GetProductInfo function
http://msdn.microsoft.com/en-us/library/windows/desktop/ms724358(v=vs.85).aspx

#define MWA_VER_VER_PLATFORM_WIN32s        0 /* Win32 on 16bit Windows */
#define MWA_VER_VER_PLATFORM_WIN32S        0
#define MWA_VER_PLATFORM_WIN32_WINDOWS     1 /* Win32 on Windows 9X */
#define MWA_VER_PLATFORM_WIN32_NT          2 /* Win32 on WinNT platforms */
/* 3-9 reserved for future Windows zakidons */
#define MWA_VER_PLATFORM_WIN16             10 /* Added by historical reasons and may be changed in the furure */


#define 



typedef struct _OSVERSIONINFOEX {
  DWORD dwOSVersionInfoSize;
  DWORD dwMajorVersion;
  DWORD dwMinorVersion;
  DWORD dwBuildNumber;
  DWORD dwPlatformId;
  TCHAR szCSDVersion[128];
  WORD  wServicePackMajor;
  WORD  wServicePackMinor;
  WORD  wSuiteMask;
  BYTE  wProductType;
  BYTE  wReserved;
} OSVERSIONINFOEX, *POSVERSIONINFOEX, *LPOSVERSIONINFOEX;


typedef struct _OSVERSIONINFO {
  DWORD dwOSVersionInfoSize;
  DWORD dwMajorVersion;
  DWORD dwMinorVersion;
  DWORD dwBuildNumber;
  DWORD dwPlatformId;
  TCHAR szCSDVersion[128];
} OSVERSIONINFO;

WINBASEAPI
BOOL
WINAPI
GetVersionExA(
    __inout LPOSVERSIONINFOA lpVersionInformation
    );
WINBASEAPI
BOOL
WINAPI
GetVersionExW(
    __inout LPOSVERSIONINFOW lpVersionInformation
    );
#ifdef UNICODE
#define GetVersionEx  GetVersionExW
#else
#define GetVersionEx  GetVersionExA
#endif // !UNICODE


BOOL WINAPI GetVersionEx(
  _Inout_  LPOSVERSIONINFO lpVersionInfo
);


Kernel32.dll
#endif



inline
BOOL IsRunningUnderWindows64() /* return TRUE if current app is 32/64 bits app is running on 64 bit Windows */
{
    #if defined(_WIN64)
    return TRUE; // 64 bit apps can't run on 32 bit widows
    #else
    typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);
    BOOL bIsWow64 = FALSE;
    LPFN_ISWOW64PROCESS fnIsWow64Process = (LPFN_ISWOW64PROCESS)GetProcAddress(GetModuleHandle(_T("kernel32")),"IsWow64Process");
    if (!fnIsWow64Process) return FALSE; // WOW64 is not present
    if (!fnIsWow64Process(GetCurrentProcess(),&bIsWow64)) return FALSE; // error, assuming 32 bit Windows
    return bIsWow64;
    #endif
}



/*
   getter(TCHAR *buf, size_t size)
*/

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
/*
struct TGetter
{
   TGetter() {}
   DWORD operator() (TCHAR *buf, size_t size) const
      { return ::WiapiCall( ... , buf, (DWORD)size); }
};
*/

// ������ ������������ ��� ��������� ������� WinAPI �������.
// T getter �������� ��������� �� ����� � ������ ������,
// �������� ������ WinAPI �����, ��������� ��� �������������
// �������������� ���������. ��������� ������� ������ ��������� � ������ ����
// �������, ������� ��� ������������� ����� ������ ���������� ��� �� �����.
// ������ getApiStringValue ��������� ��� �������� �������� getter, �� ��� ��� ����
// ������������ ����� �� ����� ������ ����������.
// getApiStringValue ������������� ��������� ��������� ������. � ������ ����������
// ������������ __alloca � ����������� ������� ���������� ������ � ��� ���� ��� �������.
// ������ ������ ������ ����� ������� ����� ��������� ������� (���� �������� ����� getter,
// ������� ������ ��� ��������� � ���������� ���� �������-�������), �� ����� �������
// ����� �������� ��������� ��������� ������ ��� �������������.

template <typename T, typename TCH /*  = TCHAR */ >
::std::basic_string< TCH, ::std::char_traits<TCH>, ::std::allocator<TCH> >
getApiStringValue(const T &getter)
   {
    size_t size = 1024;
    TCH *buf = (TCH*)_alloca(size*sizeof(buf[0]));
    DWORD res = getter( buf, size);
    while(res && (res==size || res==(size-1)))
       {
        size *= 2;
        buf = (TCH*)_alloca(size*sizeof(buf[0]));
        res = getter( buf, size);
       }
    buf[res] = 0;

    typedef ::std::basic_string< TCH, ::std::char_traits<TCH>, ::std::allocator<TCH> > string;
    return string(buf);
   }

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

/* MAKELANGID(
 *   USHORT usPrimaryLanguage,  // primary language identifier
 *   USHORT usSubLanguage       // sublanguage identifier
 * );
 * LANG_USER_DEFAULT
 */
inline
char* formatMessageA(unsigned err, char *buf, unsigned bufSize)
{
    DWORD dwChars = ::FormatMessageA( FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS
                                    , 0, err
                                    , MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT)
                                    , buf, bufSize, NULL
                                    );
    if (dwChars == 0)
       {
        static const char* err = "Unknown error code";
        return (char*)err;
       }

    return buf;
}

inline
wchar_t* formatMessageW(unsigned err, wchar_t *buf, unsigned bufSize)
{
    DWORD dwChars = ::FormatMessageW( FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS
                                    , 0, err
                                    , MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT)
                                    , buf, bufSize, NULL
                                    );
    if (dwChars == 0)
       {
        static const wchar_t *err = L"Unknown error code";
        return (wchar_t*)err;
       }

    return buf;
}



template <typename ProcType>
ProcType getProcAddress(HMODULE hModule, const char *procName)
   {
    return (ProcType)::GetProcAddress(hModule, procName);
   }



//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

// ���� �� ���������� � �������������� Interlocked ������� ��� ��������� ������������������
class CModule;

class CModuleRefCounted
{
    friend class CModule;

        HMODULE  hModule;
        int      refCount;

    public:

        CModuleRefCounted(HMODULE hModule) : hModule(hModule), refCount(1) {}
        int addRef()  { return ++refCount; }
        int release()
           {
            int res = --refCount;
            if (res<=0)
               {
                if (hModule) ::FreeLibrary(hModule);
                delete this;
               }
            return res;
           }
};


// CModule - ������������ ��� �������� � stl-����������� map, vector
class CModule
{
        CModuleRefCounted *pRefCountedHModule;

    public:

        CModule(const TCHAR *modName)
           : pRefCountedHModule(0)
           {
            pRefCountedHModule = new CModuleRefCounted(
                                                       modName
                                                       ? ::LoadLibrary(modName)
                                                       : (HMODULE)0
                                                      );
           }

        CModule(const tstring &modName)
           : pRefCountedHModule(0)
           {
            pRefCountedHModule = new CModuleRefCounted(
                                                       !modName.empty()
                                                       ? ::LoadLibrary(modName.c_str())
                                                       : (HMODULE)0
                                                      );
           }

        CModule(HMODULE hModule)
           : pRefCountedHModule(0)
           {
            pRefCountedHModule = new CModuleRefCounted(hModule);
           }

        CModule(const CModule &cmod)
           : pRefCountedHModule(cmod.pRefCountedHModule)
           {
            if (pRefCountedHModule) pRefCountedHModule->addRef();
           }

        CModule& operator=(const CModule &cmod)
           {
            if (&cmod==this) return *this;
            CModuleRefCounted  *pOldRefCountedHModule = pRefCountedHModule;
            pRefCountedHModule = cmod.pRefCountedHModule;
            if (pRefCountedHModule)    pRefCountedHModule->addRef();
            if (pOldRefCountedHModule) pOldRefCountedHModule->release();
            return *this;
           }

        ~CModule()
           {
            if (pRefCountedHModule) pRefCountedHModule->release();
           }

        operator HMODULE () const
           {
            if (!pRefCountedHModule) return 0;
            return pRefCountedHModule->hModule;
           }

        bool operator!() const
           {
            if (!pRefCountedHModule) return true;
            return pRefCountedHModule->hModule==0;
           }

        template <typename ProcType>
        ProcType getProcAddress(const char *procName)
           {
            if (!pRefCountedHModule) return 0;
            return winapi::getProcAddress<ProcType>(pRefCountedHModule->hModule, procName);
           }
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
// getter
struct CGetModuleFileName
{
    HMODULE hModule;
    CGetModuleFileName(HMODULE hModule) : hModule(hModule) {}
    /* DWORD operator() (TCHAR *buf, size_t size) const
     *    { return ::GetModuleFileName( hModule, buf, (DWORD)size); }
     */
    DWORD operator() (char *buf, size_t size) const
       { return ::GetModuleFileNameA( hModule, buf, (DWORD)size); }
    DWORD operator() (wchar_t *buf, size_t size) const
       { return ::GetModuleFileNameW( hModule, buf, (DWORD)size); }
};

/*
template<typename CharType>
::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> >
getModuleFileName(HMODULE hModule)
   {
    return getApiStringValue<CGetModuleFileName, CharType>(CGetModuleFileName(hModule));
   }
*/
//-----------------------------------------------------------------------------
inline
void getModuleFileName(HMODULE hModule, ::std::string &filename)
   {
    filename = getApiStringValue<CGetModuleFileName, char>(CGetModuleFileName(hModule));
   }

//-----------------------------------------------------------------------------
inline
void getModuleFileName(HMODULE hModule, ::std::wstring &filename)
   {
    filename = getApiStringValue<CGetModuleFileName, wchar_t>(CGetModuleFileName(hModule));
   }

//-----------------------------------------------------------------------------
inline
HMODULE getModuleHandle( const ::std::string &filename )
{
    return GetModuleHandleA( filename.c_str() );
}

//-----------------------------------------------------------------------------
inline
HMODULE getModuleHandle( const ::std::wstring &filename )
{
    return GetModuleHandleW( filename.c_str() );
}


//-----------------------------------------------------------------------------
struct CGetWindowText
{
    HWND hwnd;
    CGetWindowText(HWND _hwnd) : hwnd(_hwnd) {}
    /* DWORD operator() (TCHAR *buf, size_t size) const
     *    { return ::GetModuleFileName( hModule, buf, (DWORD)size); }
     */
    DWORD operator() (char *buf, size_t size) const
       { return ::GetWindowTextA( hwnd, buf, (int)size); }
    DWORD operator() (wchar_t *buf, size_t size) const
       { return ::GetWindowTextW( hwnd, buf, (int)size); }
};
//-----------------------------------------------------------------------------
inline
void getWindowText(HWND hwnd, ::std::string &text)
   {
    text = getApiStringValue<CGetWindowText, char>(CGetWindowText(hwnd));
   }

//-----------------------------------------------------------------------------
inline
void getWindowText(HWND hwnd, ::std::wstring &text)
   {
    text = getApiStringValue<CGetWindowText, wchar_t>(CGetWindowText(hwnd));
   }


inline
bool getComputerName(::std::string &name)
   {
    DWORD size = MAX_COMPUTERNAME_LENGTH+1;
    char *buf = (char*)_alloca(size*sizeof(buf[0]));
    if (!::GetComputerNameA( buf, &size))
       {
        if (::GetLastError()!=ERROR_BUFFER_OVERFLOW) return false;
        ++size; // add space to term zero
        buf = (char*)_alloca(size*sizeof(buf[0]));
        if (!::GetComputerNameA( buf, &size)) return false;
       }
    buf[size] = 0;
    name.assign(buf);
    return true;
   }

inline
bool getComputerName(::std::wstring &name)
   {
    DWORD size = MAX_COMPUTERNAME_LENGTH+1;
    wchar_t *buf = (wchar_t*)_alloca(size*sizeof(buf[0]));
    if (!::GetComputerNameW( buf, &size))
       {
        if (::GetLastError()!=ERROR_BUFFER_OVERFLOW) return false;
        ++size; // add space to term zero
        buf = (wchar_t*)_alloca(size*sizeof(buf[0]));
        if (!::GetComputerNameW( buf, &size)) return false;
       }
    buf[size] = 0;
    name.assign(buf);
    return true;
   }

inline
bool getUserName(::std::string &name)
   {
    DWORD size = 256;
    char *buf = (char*)_alloca(size*sizeof(buf[0]));
    if (!::GetUserNameA( buf, &size))
       {
        if (::GetLastError()!=ERROR_INSUFFICIENT_BUFFER) return false;
        buf = (char*)_alloca(size*sizeof(buf[0]));
        if (!::GetUserNameA( buf, &size)) return false;
       }
    name.assign(buf);
    return true;
   }

inline
bool getUserName(::std::wstring &name)
   {
    DWORD size = 256;
    wchar_t *buf = (wchar_t*)_alloca(size*sizeof(buf[0]));
    if (!::GetUserNameW( buf, &size))
       {
        if (::GetLastError()!=ERROR_INSUFFICIENT_BUFFER) return false;
        buf = (wchar_t*)_alloca(size*sizeof(buf[0]));
        if (!::GetUserNameW( buf, &size)) return false;
       }
    name.assign(buf);
    return true;
   }




/*
See also GetComputerObjectName, GetUserNameEx

inline
bool getComputerName( COMPUTER_NAME_FORMAT NameType, ::std::string &name)
   {


BOOL WINAPI GetComputerNameEx(
  __in     COMPUTER_NAME_FORMAT NameType,
  __out    LPTSTR lpBuffer,
  __inout  LPDWORD lpnSize
);
*/






//-----------------------------------------------------------------------------
inline
bool getTempPath(::std::string &text)
   {
    size_t size = 1024;
    char *buf = (char*)_alloca(size*sizeof(buf[0]));
    DWORD res = ::GetTempPathA( (DWORD)size, buf );
    while(res && (res>size))
       {
        size *= 2;
        buf = (char*)_alloca(size*sizeof(buf[0]));
        res = ::GetTempPathA( (DWORD)size, buf );
       }
    if (!res) return false;
    text.assign(buf,(size_t)res);
    return true;
   }

//-----------------------------------------------------------------------------
inline
bool getTempPath(::std::wstring &text)
   {
    size_t size = 1024;
    wchar_t *buf = (wchar_t*)_alloca(size*sizeof(buf[0]));
    DWORD res = ::GetTempPathW( (DWORD)size, buf );
    while(res && (res>size))
       {
        size *= 2;
        buf = (wchar_t*)_alloca(size*sizeof(buf[0]));
        res = ::GetTempPathW( (DWORD)size, buf );
       }
    if (!res) return false;
    text.assign(buf,(size_t)res);
    return true;
   }

//-----------------------------------------------------------------------------
inline
void getDlgItemText(HWND hwndDlg, int ctrlId, ::std::string &text)
   {
    getWindowText( ::GetDlgItem(hwndDlg,ctrlId), text );
   }

//-----------------------------------------------------------------------------
inline
void getDlgItemText(HWND hwndDlg, int ctrlId, ::std::wstring &text)
   {
    getWindowText( ::GetDlgItem(hwndDlg,ctrlId), text );
   }

//-----------------------------------------------------------------------------
inline
BOOL setWindowText( HWND hwnd, const ::std::string &text )
   {
    return ::SetWindowTextA( hwnd, text.c_str() );
   }

//-----------------------------------------------------------------------------
inline
BOOL setWindowText( HWND hwnd, const ::std::wstring &text )
   {
    return ::SetWindowTextW( hwnd, text.c_str() );
   }

inline
BOOL clrWindowText( HWND hwnd )
   {
    return ::SetWindowTextA( hwnd, "" );
   }

//-----------------------------------------------------------------------------
inline
BOOL setDlgItemText( HWND hwndDlg, int ctrlId, const ::std::string &text )
   {
    return ::SetWindowTextA( ::GetDlgItem(hwndDlg,ctrlId), text.c_str() );
   }

//-----------------------------------------------------------------------------
inline
BOOL setDlgItemText( HWND hwndDlg, int ctrlId, const ::std::wstring &text )
   {
    return ::SetWindowTextW( ::GetDlgItem(hwndDlg,ctrlId), text.c_str() );
   }

//-----------------------------------------------------------------------------
inline
BOOL clrDlgItemText( HWND hwndDlg, int ctrlId )
   {
    return clrWindowText( ::GetDlgItem(hwndDlg,ctrlId) );
   }


/*
#define BST_UNCHECKED      0x0000
#define BST_CHECKED        0x0001
#define BST_INDETERMINATE  0x0002
#define BST_PUSHED         0x0004
#define BST_FOCUS          0x0008
*/

inline
int getCheck( HWND hwndButton )
   {
    return (int)::SendMessage(hwndButton, BM_GETCHECK, 0, 0L);
   }

inline
int getCheck( HWND hwndDlg, int ctrlId )
   {
    return getCheck( ::GetDlgItem(hwndDlg,ctrlId) );
   }

// alias for getCheck
inline
int getDlgItemCheck( HWND hwndDlg, int ctrlId )
   {
    return getCheck(hwndDlg, ctrlId);
   }

inline
int getDlgRadioGroupCheck(HWND hwndDlg, int ctrlIdFirst, int numOfRadios)
   {
    for(int i=0; i!=numOfRadios; ++i)
       if (getDlgItemCheck(hwndDlg, ctrlIdFirst+i)==BST_CHECKED) return i;
    return -1;
   }

inline
void setCheck( HWND hwndButton, int checkState )
   {
    ::SendMessage(hwndButton, BM_SETCHECK, checkState, 0L);
   }

inline
void setCheck( HWND hwndDlg, int ctrlId, int checkState )
   {
    setCheck( ::GetDlgItem(hwndDlg,ctrlId), checkState );
   }

// alias for setCheck
inline
void setDlgItemCheck( HWND hwndDlg, int ctrlId, int checkState )
   {
    setCheck(hwndDlg, ctrlId, checkState);
   }

inline
void setDlgRadioGroupCheck(HWND hwndDlg, int ctrlIdFirst, int checkIdx)
   {
    if (checkIdx<0) return;
    //for(i=0; i!=numOfRadios; ++i)
    //   if (getDlgItemCheck(hwndDlg, ctrlIdFirst+i)==BST_CHECKED) return i;
    //return -1;
    setDlgItemCheck( hwndDlg, ctrlIdFirst+checkIdx, BST_CHECKED );
   }


inline
void enableWindow( HWND hwnd, BOOL bEnable )
   {
    ::EnableWindow(hwnd, bEnable);
   }

inline
void enableDlgItem( HWND hwndDlg, int ctrlId, BOOL bEnable )
   {
    enableWindow( ::GetDlgItem(hwndDlg,ctrlId), bEnable );
   }

inline
void enableDlgItems( HWND hwndDlg, const int *pItems, SIZE_T itemsNum, BOOL bEnable )
   {
    const int *pItemsEnd = pItems + itemsNum;
    for(; pItems!=pItemsEnd; ++pItems)
       {
        enableDlgItem( hwndDlg, *pItems, bEnable );
       }
   }


inline
HWND setFocusDlgItem( HWND hwndDlg, int ctrlId )
   {
    return ::SetFocus( ::GetDlgItem(hwndDlg,ctrlId) );
   }

inline
int getFocusDlgItem( HWND hwndDlg )
   {
    HWND hwndFocus = ::GetFocus();
    if (!hwndFocus) return -1;
    HWND hwndParent = ::GetParent( hwndFocus );
    if (hwndParent!=hwndDlg) return -1;
    //return reinterpret_cast<int>(reinterpret_cast<INT_PTR>(::GetMenu( hwndFocus )));
    return PtrToLong( ::GetMenu( hwndFocus ) );
   }



/*
inline
bool getUserName( ::std::string &name )
   {
    char buf[1024];
    DWORD size = sizeof(buf)/sizeof(buf[0]);
    if (!::GetUserNameA( buf, &size)) return false;
    name = ::std::string(buf);
    return true;
   }

//-----------------------------------------------------------------------------
inline
bool getUserName( ::std::wstring &name )
   {
    wchar_t buf[1024];
    DWORD size = sizeof(buf)/sizeof(buf[0]);
    if (!::GetUserNameW( buf, &size)) return false;
    name = ::std::wstring(buf);
    return true;
   }
*/
//--------------------------------------------------------------------
inline
bool getShortFileName( const ::std::string &name, ::std::string &res )
   {
    char buf[1024];
    DWORD dwRes = GetShortPathNameA( name.c_str(), &buf[0], sizeof(buf)/sizeof(buf[0])-1 );
    buf[dwRes] = 0;
    if (!dwRes) return false;
    res.assign(buf);
    return true;
   }

//--------------------------------------------------------------------
inline
bool getShortFileName( const ::std::wstring &name, ::std::wstring &res )
   {
    wchar_t buf[1024];
    DWORD dwRes = GetShortPathNameW( name.c_str(), &buf[0], sizeof(buf)/sizeof(buf[0])-1 );
    buf[dwRes] = 0;
    if (!dwRes) return false;
    res.assign(buf);
    return true;
   }

//--------------------------------------------------------------------
inline
::std::string getShortFileName( const ::std::string &name )
   {
    ::std::string tmp;
    if (!getShortFileName( name, tmp )) return name;
    return tmp;
   }

//--------------------------------------------------------------------
inline
::std::wstring getShortFileName( const ::std::wstring &name )
   {
    ::std::wstring tmp;
    if (!getShortFileName( name, tmp )) return name;
    return tmp;
   }

//-----------------------------------------------------------------------------
inline
tstring getSystemDirectory()
   {
    TCHAR ch = 0;
    TCHAR *buf = &ch;
    DWORD size = ::GetSystemDirectory(buf, 1);
    if (!size) return tstring();
    buf = (TCHAR*)_alloca(size*sizeof(TCHAR));
    ::GetSystemDirectory(buf, size);
    return tstring(buf);
   }

//-----------------------------------------------------------------------------
inline
void getSystemDirectory(::std::string &dir)
   {
    char ch = 0;
    char *buf = &ch;
    DWORD size = ::GetSystemDirectoryA(buf, 1);
    if (!size) { dir = ::std::string(); return; }
    buf = (char*)_alloca(size*sizeof(char));
    ::GetSystemDirectoryA(buf, size);
    dir = ::std::string(buf);
   }
//-----------------------------------------------------------------------------
inline
void getSystemDirectory(::std::wstring &dir)
   {
    wchar_t ch = 0;
    wchar_t *buf = &ch;
    DWORD size = ::GetSystemDirectoryW(buf, 1);
    if (!size) { dir = ::std::wstring(); return; }
    buf = (wchar_t*)_alloca(size*sizeof(wchar_t));
    ::GetSystemDirectoryW(buf, size);
    dir = ::std::wstring(buf);
   }
//--------------------------------------------------------------------
inline
tstring getWindowsDirectory()
   {
    TCHAR  ch = 0;
    TCHAR *buf = &ch;
    DWORD size = ::GetWindowsDirectory(buf, 1);
    if (!size) return tstring();
    buf = (TCHAR*)_alloca(size*sizeof(TCHAR));
    ::GetWindowsDirectory(buf, size);
    return tstring(buf);
   }
//--------------------------------------------------------------------
inline
void getWindowsDirectory(::std::string &dir)
   {
    char  ch = 0;
    char *buf = &ch;
    DWORD size = ::GetWindowsDirectoryA(buf, 1);
    if (!size) { dir = ::std::string(); return; }
    buf = (char*)_alloca(size*sizeof(char));
    ::GetWindowsDirectoryA(buf, size);
    dir = ::std::string(buf);
   }
//--------------------------------------------------------------------
inline
void getWindowsDirectory(::std::wstring &dir)
   {
    wchar_t  ch = 0;
    wchar_t *buf = &ch;
    DWORD size = ::GetWindowsDirectoryW(buf, 1);
    if (!size) { dir = ::std::wstring(); return; }
    buf = (wchar_t*)_alloca(size*sizeof(wchar_t));
    ::GetWindowsDirectoryW(buf, size);
    dir = ::std::wstring(buf);
   }
//--------------------------------------------------------------------
inline
tstring getCurrentDirectory()
   {
    TCHAR  ch = 0;
    TCHAR *buf = &ch;
    DWORD size = ::GetCurrentDirectory(1, buf);
    if (!size) return tstring();
    buf = (TCHAR*)_alloca(size*sizeof(TCHAR));
    ::GetCurrentDirectory(size, buf);
    return tstring(buf);
   }

//--------------------------------------------------------------------
inline
void getCurrentDirectory(::std::string &dir)
   {
    char  ch = 0;
    char *buf = &ch;
    DWORD size = ::GetCurrentDirectoryA(1, buf);
    if (!size) { dir = ::std::string(); return; }
    buf = (char*)_alloca(size*sizeof(char));
    ::GetCurrentDirectoryA(size, buf);
    dir = ::std::string(buf);
   }

//--------------------------------------------------------------------
inline
void getCurrentDirectory(::std::wstring &dir)
   {
    wchar_t  ch = 0;
    wchar_t *buf = &ch;
    DWORD size = ::GetCurrentDirectoryW(1, buf);
    if (!size) { dir = ::std::wstring(); return; }
    buf = (wchar_t*)_alloca(size*sizeof(wchar_t));
    ::GetCurrentDirectoryW(size, buf);
    dir = ::std::wstring(buf);
   }

//--------------------------------------------------------------------
inline
BOOL setCurrentDirectory(const tstring &dirName)
   {
    if (dirName.empty())
       {
        //SetLastError(ERROR_CANNOT_MAKE);
        SetLastError(ERROR_INVALID_NAME);
        return FALSE;
       }

    return ::SetCurrentDirectory(dirName.c_str());
   }

::std::string
makeUnicodeLongFilename( const ::std::string &name );
::std::wstring
makeUnicodeLongFilename( const ::std::wstring &name );

inline
DWORD getFileAttributes( const ::std::string &path )
   {
    ::std::string canonicalPath = MARTY_FILENAME::makeCanonical(path);
    if (canonicalPath.size()==2 && canonicalPath[1]==':')
       canonicalPath.append(1,'\\');
    return GetFileAttributesA( canonicalPath.c_str() );
   }

inline
DWORD getFileAttributes( const ::std::wstring &path )
   {
    ::std::wstring canonicalPath = MARTY_FILENAME::makeCanonical(path);
    if (canonicalPath.size()==2 && canonicalPath[1]==L':')
       {
        canonicalPath.append(1,L'\\');
        return GetFileAttributesW( canonicalPath.c_str() );
       }
    return GetFileAttributesW( makeUnicodeLongFilename(canonicalPath).c_str() );
   }



//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

template < typename CharType
         , typename Traits
         , typename Allocator
         >
::std::basic_string<CharType, Traits, Allocator>
makeUnicodeLongFilenameImpl( const ::std::basic_string<CharType, Traits, Allocator>   &name
                           , const ::std::basic_string<CharType, Traits, Allocator>   &slashDotStr // "\\\\."
                           , const ::std::basic_string<CharType, Traits, Allocator>   &slashQmStr // "\\\\?"
                           , const ::std::basic_string<CharType, Traits, Allocator>   &slashQmSlashStr // "\\\\?\\"
                           , const ::std::basic_string<CharType, Traits, Allocator>   &slashQmSlashUncStr // "\\\\?\\UNC"
                           , const CharType *sepList // "/\\"
                           , CharType sep            // '\\'
                           )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator>       string_type;
    if (name.size()>=3 && (string_type(name, 0, 3)==slashDotStr || string_type(name, 0, 3)==slashQmStr) )
       {
        // already long name or device name (such as \\.\COMX)
        return name; // return untouched name
       }

    if (MARTY_FILENAME::isDriveAbsolutePath(name, sepList)) // make \\?\D:\<path>
       return slashQmSlashStr + filename::makeCanonical(name, sepList, sep );

    if (MARTY_FILENAME::isUncAbsolutePath(name, sepList)) // make \\?\UNC\Server\Share from \\Server\Share
       return slashQmSlashUncStr + string_type(filename::makeCanonical(name, sepList, sep ), 1, tstring::npos);

    return name; // other names can't be longer than 260 chars
   }

inline
::std::string
makeUnicodeLongFilename( const ::std::string &name )
   {
    return makeUnicodeLongFilenameImpl( name, ::std::string("\\\\."), ::std::string("\\\\?"), ::std::string("\\\\?\\"), ::std::string("\\\\?\\UNC"), "/\\", '\\' );
   }

inline
::std::wstring
makeUnicodeLongFilename( const ::std::wstring &name )
   {
    return makeUnicodeLongFilenameImpl( name, ::std::wstring(L"\\\\."), ::std::wstring(L"\\\\?"), ::std::wstring(L"\\\\?\\"), ::std::wstring(L"\\\\?\\UNC"), L"/\\", L'\\' );
   }
/*
inline
tstring makeUnicodeLongFilename(const tstring &name)
   {
    if (name.size()>=3 && (tstring(name, 0, 3)==_T("\\\\.") || tstring(name, 0, 3)==_T("\\\\?")) )
       {
        // already long name or device name (such as \\.\COMX)
        return name; // return untouched name
       }

    const TCHAR* sepList = _T("/\\");
    const TCHAR sep = _T('\\');

    if (filename::isDriveAbsolutePath(name, sepList)) // make \\?\D:\<path>
       return tstring(_T("\\\\?\\")) + filename::makeCanonical(name, sepList, sep );

    if (filename::isUncAbsolutePath(name, sepList)) // make \\?\UNC\Server\Share from \\Server\Share
       return tstring(_T("\\\\?\\UNC")) + tstring(filename::makeCanonical(name, sepList, sep ), 1, tstring::npos);

    return name; // other names can't be longer than 260 chars
   }
*/

//-----------------------------------------------------------------------------
template < typename CharType
         , typename Traits
         , typename Allocator
         >
::std::basic_string<CharType, Traits, Allocator>
makeFilenameFromLongUnicodeImpl( const ::std::basic_string<CharType, Traits, Allocator> &name
                               , const ::std::basic_string<CharType, Traits, Allocator>   &longNamePrefix // "\\\\?\\"
                               , const ::std::basic_string<CharType, Traits, Allocator>   &uncPrefix // "\\\\?\\UNC"
                               , const CharType *sepList // "/\\"
                               , CharType sep            // '\\'
                               )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator>       string_type;
    string_type canon = filename::makeCanonical(name, sepList, sep );

    if (!canon.compare(0, uncPrefix.size(), uncPrefix, 0, uncPrefix.size()))
       { // match
        string_type res( 1, sep ); // _T("\\");
        res.append(canon, uncPrefix.size(), canon.size() - uncPrefix.size());
        return res;
       }
    if (!canon.compare(0, longNamePrefix.size(), longNamePrefix, 0, longNamePrefix.size()))
       { // match
        return string_type(canon, longNamePrefix.size());
       }
    return name;
   }

inline
::std::string makeFilenameFromLongUnicode( const ::std::string &name )
   {
    return makeFilenameFromLongUnicodeImpl( name, ::std::string("\\\\?\\"), ::std::string("\\\\?\\UNC"), "/\\", '\\' );
   }

inline
::std::wstring makeFilenameFromLongUnicode( const ::std::wstring &name )
   {
    return makeFilenameFromLongUnicodeImpl( name, ::std::wstring(L"\\\\?\\"), ::std::wstring(L"\\\\?\\UNC"), L"/\\", L'\\' );
   }

/*
inline
tstring makeFilenameFromLongUnicode(const tstring &name)
   {
    const TCHAR* sepList = _T("/\\");
    const TCHAR sep = _T('\\');
    tstring canon = filename::makeCanonical(name, sepList, sep );

    tstring uncPrefix(_T("\\\\?\\UNC"));
    tstring lnPrefix(_T("\\\\?\\"));

    if (!canon.compare(0, uncPrefix.size(), uncPrefix, 0, uncPrefix.size()))
       { // match
        tstring res = _T("\\");
        res.append(canon, uncPrefix.size(), canon.size() - uncPrefix.size());
        return res;
       }
    if (!canon.compare(0, lnPrefix.size(), lnPrefix, 0, lnPrefix.size()))
       { // match
        return tstring(canon, lnPrefix.size());
       }
    return name;
   }
*/
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
inline
void fileTimeToUlargeInteger( const FILETIME * const pf, ULARGE_INTEGER *pu)
   {
    pu->LowPart  = pf->dwLowDateTime;
    pu->HighPart = pf->dwHighDateTime;
   }

//--------------------------------------------------------------------
inline
BOOL getFileTime(
                  HANDLE hFile,
                  LPFILETIME lpCreationTime,
                  LPFILETIME lpLastAccessTime,
                  LPFILETIME lpLastWriteTime
                )
   {
    return ::GetFileTime( hFile, lpCreationTime,
                          lpLastAccessTime, lpLastWriteTime);
   }

//--------------------------------------------------------------------
inline
BOOL getFileTime(
                 HANDLE hFile,
                 PULARGE_INTEGER lpCreationTime,
                 PULARGE_INTEGER lpLastAccessTime,
                 PULARGE_INTEGER lpLastWriteTime
                )
   {
    FILETIME creationTime, lastAccessTime, lastWriteTime;
    BOOL res = ::GetFileTime( hFile, &creationTime, &lastAccessTime, &lastWriteTime);
    if (!res) return res;

    if (lpCreationTime) fileTimeToUlargeInteger( &creationTime, lpCreationTime);
    if (lpLastAccessTime) fileTimeToUlargeInteger( &lastAccessTime, lpLastAccessTime);
    if (lpLastWriteTime) fileTimeToUlargeInteger( &lastWriteTime, lpLastWriteTime);

    return TRUE;
   }

//--------------------------------------------------------------------
inline
BOOL getFileTime(
                 const tstring &filename,
                 LPFILETIME lpCreationTime,
                 LPFILETIME lpLastAccessTime,
                 LPFILETIME lpLastWriteTime
                )
   {
    HANDLE hFile = CreateFile(
                               #ifndef WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
                               makeUnicodeLongFilename(filename).c_str(),
                               #else
                               filename.c_str(),
                               #endif
                               GENERIC_READ,
                               FILE_SHARE_READ|FILE_SHARE_WRITE, 0,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );

    if (hFile==INVALID_HANDLE_VALUE) return false;
    BOOL res = getFileTime( hFile, lpCreationTime, lpLastAccessTime, lpLastWriteTime);
    CloseHandle(hFile);
    return res;
   }

//--------------------------------------------------------------------
inline
BOOL getFileTime(
                 const tstring &filename,
                 PULARGE_INTEGER lpCreationTime,
                 PULARGE_INTEGER lpLastAccessTime,
                 PULARGE_INTEGER lpLastWriteTime
                )
   {
    HANDLE hFile = CreateFile(
                               #ifndef WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
                               makeUnicodeLongFilename(filename).c_str(),
                               #else
                               filename.c_str(),
                               #endif
                               GENERIC_READ,
                               FILE_SHARE_READ|FILE_SHARE_WRITE, 0,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );

    if (hFile==INVALID_HANDLE_VALUE) return false;
    BOOL res = getFileTime( hFile, lpCreationTime, lpLastAccessTime, lpLastWriteTime);
    CloseHandle(hFile);
    return res;
   }

//--------------------------------------------------------------------
/*
inline
BOOL createDirectory(const tstring &dirName, LPSECURITY_ATTRIBUTES lpSecurityAttributes = 0)
   {
    if (dirName.empty())
       {
        //SetLastError(ERROR_CANNOT_MAKE);
        SetLastError(ERROR_INVALID_NAME);
        return FALSE;
       }

    return ::CreateDirectory(
                             #ifndef WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
                             makeUnicodeLongFilename(dirName).c_str(),
                             #else
                             dirName.c_str(),
                             #endif
                             lpSecurityAttributes
                            );
   }
*/

inline
BOOL createDirectory(const ::std::string &dirName, LPSECURITY_ATTRIBUTES lpSecurityAttributes = 0)
   {
    if (dirName.empty())
       {
        //SetLastError(ERROR_CANNOT_MAKE);
        SetLastError(ERROR_INVALID_NAME);
        return FALSE;
       }

    return ::CreateDirectoryA(
                             //#ifndef WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
                             //makeUnicodeLongFilename(dirName).c_str(),
                             //#else
                             dirName.c_str(),
                             //#endif
                             lpSecurityAttributes
                            );
   }

inline
BOOL createDirectory(const ::std::wstring &dirName, LPSECURITY_ATTRIBUTES lpSecurityAttributes = 0)
   {
    if (dirName.empty())
       {
        //SetLastError(ERROR_CANNOT_MAKE);
        SetLastError(ERROR_INVALID_NAME);
        return FALSE;
       }

    return ::CreateDirectoryW(
                             //#ifndef WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
                             makeUnicodeLongFilename(dirName).c_str(),
                             //#else
                             //dirName.c_str(),
                             //#endif
                             lpSecurityAttributes
                            );
   }


//--------------------------------------------------------------------
template < typename CharType
         , typename Traits
         , typename Allocator
         >
BOOL forceCreateDirectory(const ::std::basic_string<CharType, Traits, Allocator>  &dirName, LPSECURITY_ATTRIBUTES lpSecurityAttributes = 0)
   {
    ::std::basic_string<CharType, Traits, Allocator>  canonDirName = MARTY_NS filename::makeCanonical(dirName);
    ::std::vector< ::std::basic_string<CharType, Traits, Allocator>  > pathParts;
    MARTY_NS filename::splitPath( canonDirName, pathParts );
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    typename ::std::vector< string_type >::const_iterator pit = pathParts.begin();

    ::std::basic_string<CharType, Traits, Allocator> newName;
    for( ; pit!=pathParts.end(); ++pit)
       {
        MARTY_NS filename::appendPathInplace(newName, *pit);
        if (!createDirectory(newName))
           {
            DWORD err = ::GetLastError();
            if (err==ERROR_ACCESS_DENIED && pit==pathParts.begin())
               continue;
            if (err==ERROR_ALREADY_EXISTS)
               continue;
            return FALSE;
           }
       }
    return TRUE;
   }

//QuadPart




//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------


/* #ifndef CSIDL_FLAG_CREATE
 *     #define CSIDL_FLAG_CREATE               0x8000        // combine with CSIDL_ value to force folder creation in SHGetFolderPath()
 * #endif
 *
 * #ifndef CSIDL_FLAG_DONT_VERIFY
 *     #define CSIDL_FLAG_DONT_VERIFY          0x4000        // combine with CSIDL_ value to return an unverified folder path
 * #endif
 *
 * #ifndef CSIDL_FLAG_MASK
 *     #define CSIDL_FLAG_MASK                 0xFF00        // mask for all possible flag values
 * #endif
 */

/* typedef HRESULT (__stdcall * PFNSHGETFOLDERPATHA)(HWND, int, HANDLE, DWORD, LPSTR);  // "SHGetFolderPathA"
 * typedef HRESULT (__stdcall * PFNSHGETFOLDERPATHW)(HWND, int, HANDLE, DWORD, LPWSTR); // "SHGetFolderPathW"
 *
 * #ifdef UNICODE
 * #define SHGetFolderPath     SHGetFolderPathW
 * #define PFNSHGETFOLDERPATH  PFNSHGETFOLDERPATHW
 * #else
 * #define SHGetFolderPath     SHGetFolderPathA
 * #define PFNSHGETFOLDERPATH  PFNSHGETFOLDERPATHA
 * #endif
 */

#if !defined(WINAPI_NO_SHFOLDER)

#define SHGETFOLDERPATHA_PROCNAME "SHGetFolderPathA"
#define SHGETFOLDERPATHW_PROCNAME "SHGetFolderPathW"

// same as in ShFolder.h
typedef HRESULT (__stdcall * PFS_PFNSHGETFOLDERPATHA)(HWND, int, HANDLE, DWORD, LPSTR);  // "SHGetFolderPathA"
typedef HRESULT (__stdcall * PFS_PFNSHGETFOLDERPATHW)(HWND, int, HANDLE, DWORD, LPWSTR); // "SHGetFolderPathW"

#if defined(_UNICODE) || defined(UNICODE)
    #define SHGETFOLDERPATH_PROCNAME  SHGETFOLDERPATHW_PROCNAME
    #define PFS_PFNSHGETFOLDERPATH    PFS_PFNSHGETFOLDERPATHW
#else
    #define SHGETFOLDERPATH_PROCNAME  SHGETFOLDERPATHA_PROCNAME
    #define PFS_PFNSHGETFOLDERPATH    PFS_PFNSHGETFOLDERPATHA
#endif



// ������� ��� ShGetFolderPath - ����� ���������� false �� ������ ��������,
// ��� ��� ����� �������,
inline
bool shGetFolderPath( HWND hwndOwner,
                      int nFolder,
                      tstring &path,
                      DWORD dwFlags
                    )
   {
    CModule mod(_T("shell32.dll"));

    PFS_PFNSHGETFOLDERPATH proc = mod.getProcAddress<PFS_PFNSHGETFOLDERPATH>(SHGETFOLDERPATH_PROCNAME);
    if (!proc) return false;

    TCHAR buf[MAX_PATH];
    HRESULT hRes = proc(hwndOwner, nFolder, 0, dwFlags, buf);
    if (hRes==S_FALSE) return false;
    if (hRes==E_FAIL) return false;
    if (hRes==E_INVALIDARG ) return false;

    if (hRes==S_OK)
    //if (S_OK==proc(hwndOwner, nFolder, 0, dwFlags, buf))
       {
        path = buf;
        return true;
       }

    return false;
   }

#endif /* WINAPI_NO_SHFOLDER */





#define SHELLEXECUTEA_PROCNAME "ShellExecuteA"
#define SHELLEXECUTEW_PROCNAME "ShellExecuteW"

typedef HINSTANCE (STDAPICALLTYPE * PFS_PFNSHELLEXECUTEA)(HWND, LPCSTR , LPCSTR , LPCSTR , LPCSTR , INT);  // "ShellExecuteA"
typedef HINSTANCE (STDAPICALLTYPE * PFS_PFNSHELLEXECUTEW)(HWND, LPCWSTR, LPCWSTR, LPCWSTR, LPCWSTR, INT);  // "ShellExecuteW"

#if defined(_UNICODE) || defined(UNICODE)
    #define SHELLEXECUTE_PROCNAME     SHELLEXECUTEW_PROCNAME
    #define PFS_PFNSHELLEXECUTE       PFS_PFNSHELLEXECUTEW
#else
    #define SHELLEXECUTE_PROCNAME     SHELLEXECUTEA_PROCNAME
    #define PFS_PFNSHELLEXECUTE       PFS_PFNSHELLEXECUTEA
#endif

inline
HINSTANCE shellExecute( HWND hwnd
                      , const ::std::string &lpOperation
                      , const ::std::string &lpFile
                      , const ::std::string &lpParameters
                      , const ::std::string &lpDirectory
                      , int nShowCmd
                    )
   {
    CModule mod(_T("shell32.dll"));
    PFS_PFNSHELLEXECUTEA proc = mod.getProcAddress<PFS_PFNSHELLEXECUTEA>(SHELLEXECUTEA_PROCNAME);
    if (!proc) return 0;

    return proc( hwnd
               , lpOperation.empty()  ? (LPCSTR)0 : (LPCSTR)lpOperation.c_str()
               , lpFile.empty()       ? (LPCSTR)0 : (LPCSTR)lpFile.c_str()
               , lpParameters.empty() ? (LPCSTR)0 : (LPCSTR)lpParameters.c_str()
               , lpDirectory.empty()  ? (LPCSTR)0 : (LPCSTR)lpDirectory.c_str()
               , (INT)nShowCmd
               );
   }

inline
HINSTANCE shellExecute( HWND hwnd
                      , const ::std::wstring &lpOperation
                      , const ::std::wstring &lpFile
                      , const ::std::wstring &lpParameters
                      , const ::std::wstring &lpDirectory
                      , int nShowCmd
                    )
   {
    CModule mod(_T("shell32.dll"));
    PFS_PFNSHELLEXECUTEW proc = mod.getProcAddress<PFS_PFNSHELLEXECUTEW>(SHELLEXECUTEW_PROCNAME);
    if (!proc) return 0;

    return proc( hwnd
               , lpOperation.empty()  ? (LPCWSTR)0 : (LPCWSTR)lpOperation.c_str()
               , lpFile.empty()       ? (LPCWSTR)0 : (LPCWSTR)lpFile.c_str()
               , lpParameters.empty() ? (LPCWSTR)0 : (LPCWSTR)lpParameters.c_str()
               , lpDirectory.empty()  ? (LPCWSTR)0 : (LPCWSTR)lpDirectory.c_str()
               , (INT)nShowCmd
               );
   }



//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------




template< typename TEnumerator >
struct CThreadWindowEnumeratorConstImpl
{
    static
    BOOL CALLBACK EnumProc( HWND hwnd, LPARAM lParam )
       {
        const TEnumerator* pEnum = (const TEnumerator*)lParam;
        return pEnum->operator()(hwnd) ? TRUE : FALSE;
       }
};

template< typename TEnumerator >
struct CThreadWindowEnumeratorImpl
{
    static
    BOOL CALLBACK EnumProc( HWND hwnd, LPARAM lParam )
       {
        TEnumerator* pEnum = (TEnumerator*)lParam;
        return pEnum->operator()(hwnd) ? TRUE : FALSE;
       }
};

template< typename TEnumerator >
bool enumThreadWindows( DWORD dwThreadId, const TEnumerator &enumerator )
   {
    //CThreadWindowEnumeratorConstImpl<TEnumerator> enumeratorImpl;
    return ::EnumThreadWindows( dwThreadId
                              , CThreadWindowEnumeratorConstImpl<TEnumerator>::EnumProc
                              ,(LPARAM)&enumerator
                              ) ? true : false;
   }

template< typename TEnumerator >
bool enumThreadWindows( DWORD dwThreadId, TEnumerator &enumerator )
   {
    //CThreadWindowEnumeratorConstImpl<TEnumerator> enumeratorImpl;
    return ::EnumThreadWindows( dwThreadId
                              , CThreadWindowEnumeratorImpl<TEnumerator>::EnumProc
                              ,(LPARAM)&enumerator
                              ) ? true : false;
   }






//-----------------------------------------------------------------------------
#if defined(UNICODE) || defined(_UNICODE)
     // do not touch WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
    //#if defined(WINAPI_DISABLE_UNICODE_LONG_FILENAMES_SUPPORT)
#else /* ANSI verison compiled, force disable lfn support */
    #if !defined(WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT)
        #define WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
    #endif
#endif

//-----------------------------------------------------------------------------




//-----------------------------------------------------------------------------
// FindFirstFile/FindNextFile wrappers
//-----------------------------------------------------------------------------


/* Sample handler
 * struct CPrintFileFindData
 * {
 *     bool operator()(tstring &path, const WIN32_FIND_DATA &fndData)
 *        {
 *         std::cout<<getAttrString(fndData.dwFileAttributes)<<"  "<<fndData.cFileName<<"\n";
 *         return true;
 *        }
 * }
 */


//-----------------------------------------------------------------------------
// ����� ����� �� �����
// ������� ������ ������� ��� WinAPI ������� FindFirstFile/FindNextFile
template <typename TFindHandler>
DWORD findFile(const tstring path, const tstring mask, TFindHandler handler)
   {
    tstring pathMask = filename::appendPath(path,
                                            (mask.empty() ? tstring(_T("*")) : mask),
                                            _T("/\\"), _T('\\')
                                           );
    #ifndef WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
    pathMask = makeUnicodeLongFilename(pathMask);
    #endif

    WIN32_FIND_DATA fndData;
    HANDLE hFind = ::FindFirstFile( pathMask.c_str(), &fndData );
    if (hFind==INVALID_HANDLE_VALUE) return ::GetLastError();

    /* if (!handler(path, fndData))
     *    {
     *     CloseHandle(hFind);
     *     return 0;
     *    }
     */

    do{
       if (!handler(path, fndData))
          break;
      } while(::FindNextFile( hFind, &fndData ));

    /* while(::FindNextFile( hFind, &fndData ))
     *    {
     *     if (!handler(path, fndData))
     *        break;
     *    }
     */

    ::FindClose(hFind);
    return 0;
   }

//-----------------------------------------------------------------------------
// Borland C++ can't convert char to tstring
//#ifdef __BORLANDC__
/* template <typename TFindHandler>
 * DWORD findFile(const TCHAR* path, const tstring &mask, TFindHandler handler)
 *    {
 *     findFile(tstring(path), mask, handler);
 *    }
 * template <typename TFindHandler>
 * DWORD findFile(const tstring &path, const TCHAR* &mask, TFindHandler handler)
 *    {
 *     findFile(path, tstring(mask), handler);
 *    }
 * template <typename TFindHandler>
 * DWORD findFile(const TCHAR* path, const TCHAR* mask, TFindHandler handler)
 *    {
 *     findFile(tstring(path), tstring(mask), handler);
 *    }
 */
//#endif

//-----------------------------------------------------------------------------
template <typename TFindHandler>
DWORD findFile(const tstring pathMask, TFindHandler handler)
   {
    return findFile( MARTY_FILENAME_NS getPath( pathMask /* , _T("/\\") */ )
                   , MARTY_FILENAME_NS getFile( pathMask /* , _T("/\\") */ )
                   , handler
                   );
    //return findFile(filename::path( pathMask, _T("/\\")), filename::file( pathMask, _T("/\\")), handler);
   }

/* //#ifdef __BORLANDC__
 * template <typename TFindHandler>
 * DWORD findFile(const TCHAR* pathMask, TFindHandler handler)
 *    {
 *     return findFile(filename::path( pathMask, _T("/\\")), filename::file( pathMask, _T("/\\")), handler);
 *    }
 * //#endif
 */

//-----------------------------------------------------------------------------

namespace utils
{

struct CFindCounter
{
    int &count;
    CFindCounter(int &c) : count(c) {}
    bool operator()(const tstring &path, const WIN32_FIND_DATA &fndData)
       { ++count; return true; }

};

}; // namespace utils


//-----------------------------------------------------------------------------
inline
int fileExist(const tstring &pathName )
   {
    //HANDLE hFile
    /*
    int counter = 0;
    findFile<utils::CFindCounter>(pathName, utils::CFindCounter(counter));
    //winapi::findFile<winapi::utils::CFindCounter>(pathName, winapi::utils::CFindCounter(counter));
    //winapi::findFile<winapi::utils::CFindCounter>(winapi::utils::CFindCounter(counter), pathName, tstring(_T("*")));
    return counter;
    */
    if (pathName.empty()) return 0;

    HANDLE hFile = CreateFile(
                               #ifndef WINAPI_NO_UNICODE_LONG_FILENAMES_SUPPORT
                               makeUnicodeLongFilename(pathName).c_str(),
                               #else
                               pathName.c_str(),
                               #endif
                               GENERIC_READ,
                               FILE_SHARE_READ|FILE_SHARE_WRITE, 0,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
    DWORD err = GetLastError();
    CloseHandle(hFile);
    if (hFile!=INVALID_HANDLE_VALUE)
       return 1; // no error, file exist and readable

    if (err==ERROR_SHARING_VIOLATION)
       return 1; // file exist, but share access mode invalid

    //ERROR_FILE_NOT_FOUND
    return 0;
   }

//-----------------------------------------------------------------------------
// return number of found files
/* mask allowed */
inline
int maskExist(const tstring &pathName )
   {
    int counter = 0;
    findFile<utils::CFindCounter>(pathName, utils::CFindCounter(counter));
    //winapi::findFile<winapi::utils::CFindCounter>(pathName, winapi::utils::CFindCounter(counter));
    //winapi::findFile<winapi::utils::CFindCounter>(winapi::utils::CFindCounter(counter), pathName, tstring(_T("*")));
    return counter;
   }


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

namespace utils
{

//-----------------------------------------------------------------------------
struct removeTralingSlash
{
    void operator() (tstring &path)
       { filename::pathRemoveTrailingSlashInplace(path, _T("/\\")); }
};

//-----------------------------------------------------------------------------
// ��������� ���� � ������, ���� ��� ��� ������ ���
inline
void addPathIfNotFound(std::vector<tstring> &pathList, const tstring& path, const tstring& subDir, const std::vector<tstring> *pExcludePathList)
   {
    tstring newPath = filename::appendPath(path, subDir, _T("/\\"), _T('\\'));

    std::vector<tstring>::const_iterator it = std::find_if(
                                                     pathList.begin(),
                                                     pathList.end(),
                                                     filename::compareTo<filename::compareProcType>(newPath, filename::equal)
                                                    );
    if (it!=pathList.end())
       return; // path allready in list

    if (pExcludePathList)
       {
        it = std::find_if(
                          pExcludePathList->begin(),
                          pExcludePathList->end(),
                          filename::compareTo<filename::compareProcType>(newPath, filename::equal)
                         );
        if (it!=pExcludePathList->end())
           return; // path found in exclude list
       }

    pathList.push_back(newPath);
   }

//-----------------------------------------------------------------------------
template <typename TH>
struct CFindFilesRecurceProxy
{
    TH                    handler;
    bool                  recurceAllowed;
    bool                  buildDirListMode;
    bool                  callHandlerAllowed;
    std::vector<tstring>  &pathList;
    const std::vector<tstring> * pExcludePathList;
    bool                  &breakFlag;

    CFindFilesRecurceProxy( TH h,
                            std::vector<tstring> &pl,
                            const std::vector<tstring> *pEx,
                            bool bRecurce,
                            bool bdl,
                            bool cha,
                            bool &brf)
       : handler(h)
       , pathList(pl)
       , pExcludePathList(pEx)
       , recurceAllowed(bRecurce)
       , buildDirListMode(bdl)
       , callHandlerAllowed(cha)
       , breakFlag(brf)
       { }

    void setup( bool bRecurce, bool bdl, bool cha)
       {
        recurceAllowed     = bRecurce;
        buildDirListMode    = bdl;
        callHandlerAllowed = cha;
        //breakFlag = false;
       }


    bool operator()(const tstring &path, const WIN32_FIND_DATA &fndData)
       {
        if ((fndData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY) && recurceAllowed && buildDirListMode)
           {
            if (fndData.cFileName!=tstring(_T(".")) && fndData.cFileName!=tstring(_T("..")))
               addPathIfNotFound( pathList, path, fndData.cFileName, pExcludePathList);
            //std::cout<<"*** PathList size: "<<(unsigned)pathList.size()<<"\n";
           }

        if (callHandlerAllowed)
           {
            if (!handler(path, fndData))
               {
                breakFlag = true;
                return false;
               }
           }
        return true;
       }
}; // struct CFindFilesRecurceProxy

}; // namespace utils

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
// ����������� ����� �� �����. ��������������� �������
// ���� ����� ������ �������� �� *, �� ������� ������������ ����� ��������� �� ����� *
template <typename TFindHandler>
DWORD findFileAux( const std::vector<tstring> &pathList,
                   const std::vector<tstring> *pExcludePathList,
                   const tstring &mask,
                   TFindHandler handler,
                   bool traverseSubFolders)
   {
    std::vector<tstring> pathListCopy = pathList;
    std::for_each(pathListCopy.begin(), pathListCopy.end(), utils::removeTralingSlash());

    bool breakFlag = false;
    utils::CFindFilesRecurceProxy<TFindHandler> proxy(handler, pathListCopy, pExcludePathList, true, true, false, breakFlag);

    if (mask!=_T("*") && traverseSubFolders)
       {
        std::vector<tstring>::size_type i = 0;
        for(; i<pathListCopy.size(); ++i)
            findFile(pathListCopy[i], _T("*"), proxy);
       }

    proxy.setup( traverseSubFolders, mask==_T("*") && traverseSubFolders, true);
    std::vector<tstring>::size_type i = 0;
    for(; i<pathListCopy.size(); ++i)
       {
        findFile( pathListCopy[i], mask, proxy);
        if (breakFlag) return 0;
       }

    return 0;
   }

//
template <typename TFindHandler>
DWORD findFile( const std::vector<tstring> &pathList,
                const std::vector<tstring> &excludePathList,
                const tstring &mask,
                TFindHandler handler,
                bool traverseSubFolders)
   {
    return findFileAux( pathList, &excludePathList, mask, handler, traverseSubFolders);
   }

template <typename TFindHandler>
DWORD findFile( const std::vector<tstring> &pathList,
                const std::vector<tstring> &excludePathList,
                const TCHAR *mask,
                TFindHandler handler,
                bool traverseSubFolders)
   {
    return findFileAux( pathList, &excludePathList, tstring(mask), handler, traverseSubFolders);
   }

template <typename TFindHandler>
DWORD findFile( const std::vector<tstring> &pathList,
                const tstring &mask,
                TFindHandler handler,
                bool traverseSubFolders)
   {
    return findFileAux( pathList, 0, mask, handler, traverseSubFolders);
   }

template <typename TFindHandler>
DWORD findFile( const std::vector<tstring> &pathList,
                const TCHAR *mask,
                TFindHandler handler,
                bool traverseSubFolders)
   {
    return findFileAux( pathList, 0, tstring(mask), handler, traverseSubFolders);
   }

/*
 *
 * template <typename TFindHandler>
 * DWORD findFile(const std::vector<tstring> &pathList, const TCHAR *mask, TFindHandler handler, bool traverseSubFolders = true)
 *    {
 *     return findFile(pathList, tstring(mask), handler, traverseSubFolders);
 *    }
 */


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
struct CWin32EnumDrivesData
{
    TCHAR     driveName[4];
    UINT      driveType;

    BOOL      driveInfoValid;
    TCHAR     volumeName[_MAX_PATH];
    DWORD     volumeSerial;
    DWORD     maxComponentLength;
    DWORD     filesystemFlags;
    TCHAR     filesystemName[_MAX_PATH];

    BOOL      spaceInfoValid;
    DWORD     sectorsPerCluster;
    DWORD     bytesPerSector;
    DWORD     numOfFreeClusters;
    DWORD     numOfTotalClusters;

};

inline
void getDriveTypeDisplayString( const CWin32EnumDrivesData &data, ::std::string &str)
   {   
    switch(data.driveType)
       {
        case DRIVE_RAMDISK  :  str = "Ramdisk"; break;
        case DRIVE_CDROM    :  str = "CD-ROM"; break;
        case DRIVE_REMOTE   :  str = "Network drive"; break;
        case DRIVE_FIXED    :  str = "Local drive"; break;
        case DRIVE_REMOVABLE:  str = "Removable"; break;
        //case :  str = ""; break;
        default:               str = "Unknown";
       }
   }

inline
void getDriveTypeDisplayString( const CWin32EnumDrivesData &data, ::std::wstring &str)
   {   
    switch(data.driveType)
       {
        case DRIVE_RAMDISK  :  str = L"Ramdisk"; break;
        case DRIVE_CDROM    :  str = L"CD-ROM"; break;
        case DRIVE_REMOTE   :  str = L"Network drive"; break;
        case DRIVE_FIXED    :  str = L"Local drive"; break;
        case DRIVE_REMOVABLE:  str = L"Removable"; break;
        //case :  str = ""; break;
        default:               str = L"Unknown";
       }
   }

inline
void getDriveTypeString( const CWin32EnumDrivesData &data, ::std::string &str)
   {   
    switch(data.driveType)
       {
        case DRIVE_RAMDISK  :  str = "ramdisk"; break;
        case DRIVE_CDROM    :  str = "cd-rom"; break;
        case DRIVE_REMOTE   :  str = "network"; break;
        case DRIVE_FIXED    :  str = "hdd"; break;
        case DRIVE_REMOVABLE:  str = "removable"; break;
        //case :  str = ""; break;
        default:               str = "unknown";
       }
   }

inline
void getDriveTypeString( const CWin32EnumDrivesData &data, ::std::wstring &str)
   {   
    switch(data.driveType)
       {
        case DRIVE_RAMDISK  :  str = L"ramdisk"; break;
        case DRIVE_CDROM    :  str = L"cd-rom"; break;
        case DRIVE_REMOTE   :  str = L"network"; break;
        case DRIVE_FIXED    :  str = L"hdd"; break;
        case DRIVE_REMOVABLE:  str = L"removable"; break;
        //case :  str = ""; break;
        default:               str = L"Unknown";
       }
   }



// void Handler(const CWin32EnumDrivesData &enumData)

template <typename THandler>
void enumLogicalDrives(THandler handler)
   {
    CWin32EnumDrivesData enumData;
    //tstrcpy(enumData.driveName, _T("C:\\"));
    _tcscpy(enumData.driveName, _T("C:\\"));

    UINT prevErrMode = ::SetErrorMode( SEM_FAILCRITICALERRORS );


    DWORD logicalDrivesMask = ::GetLogicalDrives();
    for(unsigned driveIndex = 0; driveIndex <= ('Z'-'A'); ++driveIndex, logicalDrivesMask>>=1)
       {
        if (!(logicalDrivesMask&1)) continue;

        TCHAR driveLetter=_T('A') + (TCHAR)driveIndex;

        enumData.driveName[0] = driveLetter;
        enumData.driveType = ::GetDriveType(enumData.driveName);

        enumData.volumeName[0]     = 0;
        enumData.filesystemName[0] = 0;
        if (driveIndex<2) 
           {
            handler(enumData);
            //if (enumData.driveType) DRIVE_CDROM
            continue; // skip 
           }

        enumData.driveInfoValid = ::GetVolumeInformation( enumData.driveName,
                                                          enumData.volumeName,
                                                          DWORD(sizeof(enumData.volumeName)/sizeof(enumData.volumeName[0])),
                                                          &enumData.volumeSerial,
                                                          &enumData.maxComponentLength,
                                                          &enumData.filesystemFlags,
                                                          enumData.filesystemName,
                                                          DWORD(sizeof(enumData.filesystemName)/sizeof(enumData.filesystemName[0]))
                                                        );

        if (enumData.driveType!=DRIVE_REMOTE && enumData.driveType!=DRIVE_UNKNOWN)
           {
            enumData.spaceInfoValid = ::GetDiskFreeSpace( enumData.driveName,
                                                          &enumData.sectorsPerCluster,
                                                          &enumData.bytesPerSector,
                                                          &enumData.numOfFreeClusters,
                                                          &enumData.numOfTotalClusters
                                                        );
           }
        else
           {
            enumData.spaceInfoValid     = 0;
            enumData.sectorsPerCluster  = 0;
            enumData.bytesPerSector     = 0;
            enumData.numOfFreeClusters  = 0;
            enumData.numOfTotalClusters = 0;
           }
        //enumData.driveInfoValid = 0;
        //enumData.spaceInfoValid = 0;
        handler(enumData);
       }
    ::SetErrorMode( prevErrMode );
   }

struct CEnumLogicalDrivesVectorCollector
{
    ::std::vector< CWin32EnumDrivesData >  &drivesInfo;
    CEnumLogicalDrivesVectorCollector( ::std::vector< CWin32EnumDrivesData > &v) : drivesInfo(v) {}
    void operator()( const CWin32EnumDrivesData data )
       {
        drivesInfo.push_back(data);
       }
};

inline
void enumLogicalDrives( ::std::vector< CWin32EnumDrivesData > &drivesInfo )
   {
    CEnumLogicalDrivesVectorCollector handler( drivesInfo );
    enumLogicalDrives(handler);
   }


inline
std::string loadResourseString(UINT uID, const std::string &strDef, HINSTANCE hInstance = 0)
{
    if (!hInstance) hInstance = GetModuleHandle(0);
    char buf[4096];
    int res = LoadStringA( hInstance, uID, buf, sizeof(buf)/sizeof(buf[0]) );
    if (!res) return strDef;
    return std::string(buf);
}

inline
std::wstring loadResourseString(UINT uID, const std::wstring &strDef, HINSTANCE hInstance = 0)
{
    if (!hInstance) hInstance = GetModuleHandle(0);
    wchar_t buf[4096];
    int res = LoadStringW( hInstance, uID, buf, sizeof(buf)/sizeof(buf[0]) );
    if (!res) return strDef;
    return std::wstring(buf);
}

inline
std::string loadResourseStringLen(UINT uID, const std::string &strDef, std::string::size_type maxLen, HINSTANCE hInstance = 0)
{
    std::string strRes = loadResourseString(uID, strDef, hInstance );
    if (strRes.size()>maxLen)
       {
        strRes.erase(maxLen, strRes.npos);
       }
    return strRes;
}

inline
std::wstring loadResourseStringLen(UINT uID, const std::wstring &strDef, std::wstring::size_type maxLen, HINSTANCE hInstance = 0)
{
    std::wstring strRes = loadResourseString(uID, strDef, hInstance );
    if (strRes.size()>maxLen)
       {
        strRes.erase(maxLen, strRes.npos);
       }
    return strRes;
}




namespace registry
{

enum BoolNames
{
    BoolNames_YesNo     = 0,
    BoolNames_TrueFalse = 1,
    BoolNames_Numeric   = 2
};



template<typename CharType>
struct CAutoHeapAlloc
{
    SIZE_T allocSize;
    LPVOID lpvBuf;

    CharType* getBuf()  { return (CharType*)lpvBuf; }
    BYTE* getBufRaw()   { return (BYTE*)lpvBuf; }
    SIZE_T getSize()    { return allocSize; }
    SIZE_T getSizeRaw() { return sizeof(CharType)*allocSize; }
    bool allocate(SIZE_T s)
    {
     if (lpvBuf) ::HeapFree( ::GetProcessHeap(), 0, lpvBuf ) ;
     allocSize = s;
     lpvBuf = ::HeapAlloc( ::GetProcessHeap(), HEAP_ZERO_MEMORY, getSizeRaw() );
     return lpvBuf!=0;
    }

    CAutoHeapAlloc(SIZE_T s) : allocSize(s), lpvBuf(0)
    {
        lpvBuf = ::HeapAlloc( ::GetProcessHeap(), HEAP_ZERO_MEMORY, getSizeRaw() );
    }
    ~CAutoHeapAlloc()
    {
        if (lpvBuf) ::HeapFree( ::GetProcessHeap(), 0, lpvBuf ) ;
    }
    


}; // struct CAutoHeapAlloc


typedef CAutoHeapAlloc<BYTE>   CAutoHeapAllocRawBytes;

inline
DWORD keyGetSamDesired(DWORD defSam, bool share64ForBoth)
{
    DWORD dwSD = defSam;
    if (!IsRunningUnderWindows64())
       share64ForBoth = false;
    if (share64ForBoth)
       {
        if (getWinVer()>0x0500)
           dwSD |= KEY_WOW64_64KEY;
       }
    return dwSD;
}


inline
LONG createKey( HKEY hKeyRoot, const std::string &path, HKEY *hKeyCreated, bool share64ForBoth)
{
    /* return ERROR_SUCCESS if Ok */
    DWORD dwDisposition;
    return ::RegCreateKeyExA( hKeyRoot, path.c_str(), 0  /* Reserved */, 0  /* lpClass */, REG_OPTION_NON_VOLATILE
                  , keyGetSamDesired(KEY_WRITE|KEY_READ, share64ForBoth), 0 /* lpSecurityAttributes */, hKeyCreated, &dwDisposition );
}

inline
LONG createKey( HKEY hKeyRoot, const std::wstring &path, HKEY *hKeyCreated, bool share64ForBoth)
{
    /* return ERROR_SUCCESS if Ok */
    DWORD dwDisposition;
    return ::RegCreateKeyExW( hKeyRoot, path.c_str(), 0  /* Reserved */, 0  /* lpClass */, REG_OPTION_NON_VOLATILE
                  , keyGetSamDesired(KEY_WRITE|KEY_READ, share64ForBoth), 0 /* lpSecurityAttributes */, hKeyCreated, &dwDisposition );
}

inline
LONG openKey( HKEY hKeyRoot, const std::string &path, HKEY *hKeyCreated, bool share64ForBoth)
{
    /* return ERROR_SUCCESS if Ok */
    return ::RegOpenKeyExA( hKeyRoot, path.c_str(), 0  /* ulOptions  */, keyGetSamDesired(KEY_READ, share64ForBoth), hKeyCreated );
}

inline
LONG openKey( HKEY hKeyRoot, const std::wstring &path, HKEY *hKeyCreated, bool share64ForBoth)
{
    /* return ERROR_SUCCESS if Ok */
    return ::RegOpenKeyExW( hKeyRoot, path.c_str(), 0  /* ulOptions  */, keyGetSamDesired(KEY_READ, share64ForBoth), hKeyCreated );
}

inline
LONG deleteValue( HKEY hkey, const std::string &val )
{
    return ::RegDeleteValueA( hkey, val.c_str() );
}

inline
LONG deleteValue( HKEY hkey, const std::wstring &val )
{
    return ::RegDeleteValueW( hkey, val.c_str() );
}

inline
LONG closeKey( HKEY hKey )
{
    return ::RegCloseKey(hKey);
}

inline
LONG enumKey( HKEY hKey, DWORD idx, std::string &name, PFILETIME lpftLastWriteTime = 0)
{
    char buf[260]; // reg key name len limited to 255 symbols
    DWORD bufLen = sizeof(buf)/sizeof(buf[0]);
    LONG res = ::RegEnumKeyExA( hKey, idx, &buf[0], &bufLen, 0, 0, 0, lpftLastWriteTime );
    if (res==ERROR_SUCCESS) 
       {
        name.assign(buf);
       }
    return res;
}

inline
LONG enumKey( HKEY hKey, DWORD idx, std::string &name, std::string &cls, PFILETIME lpftLastWriteTime = 0)
{
    char buf[260]; // reg key name len limited to 255 symbols
    DWORD bufLen = sizeof(buf)/sizeof(buf[0]);
    CAutoHeapAlloc<char> clsBufAlloc(4096);
    DWORD clsBufLen  = (DWORD)(clsBufAlloc.getSize());
    LONG res = ::RegEnumKeyExA( hKey, idx, &buf[0], &bufLen, 0, clsBufAlloc.getBuf(), &clsBufLen, lpftLastWriteTime );
    if (res==ERROR_SUCCESS) 
       {
        name.assign(buf);
        cls  = clsBufAlloc.getBuf();
       }
    return res;
}

inline
LONG enumKey( HKEY hKey, DWORD idx, std::wstring &name, PFILETIME lpftLastWriteTime = 0)
{
    wchar_t buf[260]; // reg key name len limited to 255 symbols
    DWORD bufLen = sizeof(buf)/sizeof(buf[0]);
    LONG res = ::RegEnumKeyExW( hKey, idx, &buf[0], &bufLen, 0, 0, 0, lpftLastWriteTime );
    if (res==ERROR_SUCCESS) 
       {
        name.assign(buf);
       }
    return res;
}

inline
LONG enumKey( HKEY hKey, DWORD idx, std::wstring &name, std::wstring &cls, PFILETIME lpftLastWriteTime = 0)
{
    wchar_t buf[260]; // reg key name len limited to 255 symbols
    DWORD bufLen = sizeof(buf)/sizeof(buf[0]);
    CAutoHeapAlloc<wchar_t> clsBufAlloc(4096);
    DWORD clsBufLen  = (DWORD)(clsBufAlloc.getSize());
    LONG res = ::RegEnumKeyExW( hKey, idx, &buf[0], &bufLen, 0, clsBufAlloc.getBuf(), &clsBufLen, lpftLastWriteTime );
    if (res==ERROR_SUCCESS) 
       {
        name.assign(buf);
        cls  = clsBufAlloc.getBuf();
       }
    return res;
}


inline
LONG enumValue( HKEY hKey, DWORD idx, std::string &name, DWORD &dwType )
{
    // Windows 2000:  260 ANSI characters or 16,383 Unicode characters
    CAutoHeapAlloc<char> bufAlloc(16400);
    DWORD bufLen = (DWORD)(bufAlloc.getSize());
    LONG res = ::RegEnumValueA( hKey, idx, bufAlloc.getBuf(), &bufLen, 0 /* reserved */, &dwType, 0, 0 );
    if (res==ERROR_SUCCESS)
       {
        name.assign(bufAlloc.getBuf());
       }
    return res;
}

inline
LONG enumValue( HKEY hKey, DWORD idx, std::string &name, DWORD &dwType, std::vector<unsigned char> &data )
{
    // Windows 2000:  260 ANSI characters or 16,383 Unicode characters
    CAutoHeapAlloc<char> bufAlloc(16400);
    DWORD bufLen = (DWORD)(bufAlloc.getSize());
    DWORD dataLen = 0;
    LONG res = ::RegEnumValueA( hKey, idx, bufAlloc.getBuf(), &bufLen, 0 /* reserved */, &dwType, 0, &dataLen );
    if (res==ERROR_SUCCESS ) 
       {
        if (dataLen)
           {
            data.resize(dataLen);
            bufLen = (DWORD)(bufAlloc.getSize());
            res = ::RegEnumValueA( hKey, idx, bufAlloc.getBuf(), &bufLen, 0 /* reserved */, &dwType, &data[0], &dataLen );
           }
        else
           data.clear();
       }
    if (res==ERROR_SUCCESS)
       {
        name.assign(bufAlloc.getBuf());
       }
    return res;
}

inline
LONG enumValue( HKEY hKey, DWORD idx, std::wstring &name, DWORD &dwType )
{
    // Windows 2000:  260 ANSI characters or 16,383 Unicode characters
    CAutoHeapAlloc<wchar_t> bufAlloc(16400);
    DWORD bufLen = (DWORD)(bufAlloc.getSize());
    LONG res = ::RegEnumValueW( hKey, idx, bufAlloc.getBuf(), &bufLen, 0 /* reserved */, &dwType, 0, 0 );
    if (res==ERROR_SUCCESS)
       {
        name.assign(bufAlloc.getBuf());
       }
    return res;
}

inline
LONG enumValue( HKEY hKey, DWORD idx, std::wstring &name, DWORD &dwType, std::vector<unsigned char> &data )
{
    // Windows 2000:  260 ANSI characters or 16,383 Unicode characters
    CAutoHeapAlloc<wchar_t> bufAlloc(16400);
    DWORD bufLen = (DWORD)(bufAlloc.getSize());
    DWORD dataLen = 0;
    LONG res = ::RegEnumValueW( hKey, idx, bufAlloc.getBuf(), &bufLen, 0 /* reserved */, &dwType, 0, &dataLen );
    if (res==ERROR_SUCCESS )
       {
        if (dataLen)
           {
            data.resize(dataLen);
            bufLen = (DWORD)(bufAlloc.getSize());
            res = ::RegEnumValueW( hKey, idx, bufAlloc.getBuf(), &bufLen, 0 /* reserved */, &dwType, &data[0], &dataLen );
           }
        else
           data.clear();
       }
    if (res==ERROR_SUCCESS)
       {
        name.assign(bufAlloc.getBuf());
       }
    return res;
}



inline
LONG setValue( HKEY hKey, const std::string &name, const std::string &value )
{
    return ::RegSetValueExA( hKey, name.c_str(), 0 /* Reserved */, REG_SZ, (LPBYTE)value.c_str(), (DWORD)value.size() );
}

inline
LONG setValue( HKEY hKeyRoot, const std::string &path, const std::string &name, const std::string &value, bool share64ForBoth )
{
    HKEY hKeyCreated;
    LONG lRes = createKey( hKeyRoot, path, &hKeyCreated, share64ForBoth);
    if (lRes!=ERROR_SUCCESS) return lRes;
    lRes = setValue( hKeyCreated, name, value );
    closeKey(hKeyCreated);
    return lRes;
}

inline
LONG setValue( HKEY hKey, const std::wstring &name, const std::wstring &value )
{
    return ::RegSetValueExW( hKey, name.c_str(), 0 /* Reserved */, REG_SZ, (LPBYTE)value.c_str(), (DWORD)value.size()*sizeof(wchar_t) );
}

inline
LONG setValue( HKEY hKeyRoot, const std::wstring &path, const std::wstring &name, const std::wstring &value, bool share64ForBoth )
{
    HKEY hKeyCreated;
    LONG lRes = createKey( hKeyRoot, path, &hKeyCreated, share64ForBoth);
    if (lRes!=ERROR_SUCCESS) return lRes;
    lRes = setValue( hKeyCreated, name, value );
    closeKey(hKeyCreated);
    return lRes;
}

inline
std::string getBoolStringA( bool value, BoolNames bnType )
{
    if (bnType==BoolNames_YesNo)            return value ? std::string("Yes") : std::string("No");
    else if (bnType==BoolNames_TrueFalse)   return value ? std::string("True") : std::string("False");
    else                                    return value ? std::string("1") : std::string("0"); 
}

inline
std::wstring getBoolStringW( bool value, BoolNames bnType )
{
    if (bnType==BoolNames_YesNo)            return value ? std::wstring(L"Yes") : std::wstring(L"No");
    else if (bnType==BoolNames_TrueFalse)   return value ? std::wstring(L"True") : std::wstring(L"False");
    else                                    return value ? std::wstring(L"1") : std::wstring(L"0");
}



inline
LONG setValue( HKEY hKey, const std::string &name, bool value, BoolNames bnType = BoolNames_YesNo )
{
    return setValue( hKey, name, getBoolStringA(value, bnType) );
}

inline 
LONG setValue( HKEY hKeyRoot, const std::string &path, const std::string &name, bool value, bool share64ForBoth, BoolNames bnType = BoolNames_YesNo)
{
    return setValue( hKeyRoot, path, name, getBoolStringA(value, bnType), share64ForBoth );
}

inline
LONG setValue( HKEY hKey, const std::wstring &name, bool value, BoolNames bnType = BoolNames_YesNo )
{
    return setValue( hKey, name, getBoolStringW(value, bnType) );
}

inline
LONG setValue( HKEY hKeyRoot, const std::wstring &path, const std::wstring &name, bool value, bool share64ForBoth, BoolNames bnType = BoolNames_YesNo )
{
    return setValue( hKeyRoot, path, name, getBoolStringW(value, bnType), share64ForBoth );
}



//--------------------
// getters
//--------------------


inline
std::string getValue( HKEY hKey, const std::string &name, const std::string &defVal )
{
    CAutoHeapAlloc<char> bufAlloc(0x1000);
    DWORD cbData = (DWORD)(bufAlloc.getSize() - 1);
    DWORD type = REG_SZ;
    if (::RegQueryValueExA(hKey, name.c_str(), 0 /* lpReserved */, &type, bufAlloc.getBufRaw(), &cbData )!=ERROR_SUCCESS || type!=REG_SZ)
       return defVal;
    bufAlloc.getBuf()[cbData] = 0;
    return bufAlloc.getBuf();
}

inline
std::wstring getValue( HKEY hKey, const std::wstring &name, const std::wstring &defVal )
{
    CAutoHeapAlloc<wchar_t> bufAlloc(0x1000);
    DWORD cbData = (DWORD)(bufAlloc.getSizeRaw() - sizeof(wchar_t));
    DWORD type = REG_SZ;
    if (::RegQueryValueExW(hKey, name.c_str(), 0 /* lpReserved */, &type, bufAlloc.getBufRaw(), &cbData )!=ERROR_SUCCESS || type!=REG_SZ)
       return defVal;
    bufAlloc.getBuf()[cbData/sizeof(wchar_t)] = 0;
    return bufAlloc.getBuf();
}

inline
std::string getValue( HKEY hKeyRoot, const std::string &path, const std::string &name, const std::string &defVal, bool share64ForBoth )
{
    HKEY hKeyCreated;
    LONG lRes = openKey( hKeyRoot, path, &hKeyCreated, share64ForBoth);
    if (lRes!=ERROR_SUCCESS) return defVal;
    std::string res = getValue( hKeyCreated, name, defVal );
    ::RegCloseKey(hKeyCreated);
    return res;
}

inline
std::wstring getValue( HKEY hKeyRoot, const std::wstring &path, const std::wstring &name, const std::wstring &defVal, bool share64ForBoth )
{
    HKEY hKeyCreated;
    LONG lRes = openKey( hKeyRoot, path, &hKeyCreated, share64ForBoth);
    if (lRes!=ERROR_SUCCESS) return defVal;
    std::wstring res = getValue( hKeyCreated, name, defVal );
    ::RegCloseKey(hKeyCreated);
    return res;
}


inline
std::string toUpperCopy( const std::string &str )
{
    std::string s;
    std::string::size_type i = 0;
    for(; i!=str.size(); ++i)
       {
        char ch = str[i];
        if (ch>='a' && ch<='z')
           ch &= 0xD0;
        s.append(1, ch);
       }
    return s;
}

inline
std::string toLowerCopy( const std::string &str )
{
    std::string s;
    std::string::size_type i = 0;
    for(; i!=str.size(); ++i)
       {
        char ch = str[i];
        if (ch>='A' && ch<='Z')
           ch |= 0x20;
        s.append(1, ch);
       }
    return s;
}

inline
std::wstring toUpperCopy( const std::wstring &str )
{
    std::wstring s;
    std::wstring::size_type i = 0;
    for(; i!=str.size(); ++i)
       {
        wchar_t ch = str[i];
        if (ch>=L'a' && ch<=L'z')
           ch &= 0xD0;
        s.append(1, ch);
       }
    return s;
}

inline
std::wstring toLowerCopy( const std::wstring &str )
{
    std::wstring s;
    std::wstring::size_type i = 0;
    for(; i!=str.size(); ++i)
       {
        wchar_t ch = str[i];
        if (ch>=L'A' && ch<=L'Z')
           ch |= 0x20;
        s.append(1, ch);
       }
    return s;
}




inline
bool convertStringToBool( std::string strVal, bool defVal )
{
    strVal = toLowerCopy(strVal);
    if (strVal=="yes" || strVal=="true" || strVal=="1") return true;
    else if (strVal=="no" || strVal=="false" || strVal=="0") return false;
    else return defVal;
}

inline
bool convertStringToBool( std::wstring strVal, bool defVal )
{
    strVal = toLowerCopy(strVal);
    if (strVal==L"yes" || strVal==L"true" || strVal==L"1") return true;
    else if (strVal==L"no" || strVal==L"false" || strVal==L"0") return false;
    else return defVal;
}




template <typename T>
bool Cast2Bool( const T &t )
{
    return t ? true : false;
}




inline
unsigned getValue( HKEY hKey, const std::string &name, unsigned defVal )
{
    DWORD data   = 0;
    DWORD cbData = sizeof(data);
    DWORD type = REG_DWORD;
    if (::RegQueryValueExA(hKey, name.c_str(), 0 /* lpReserved */, &type, (LPBYTE)&data, &cbData )!=ERROR_SUCCESS || type!=REG_DWORD || cbData != sizeof(data))
       return defVal;
    return (unsigned)data;
}

inline
unsigned getValue( HKEY hKey, const std::wstring &name, unsigned defVal )
{
    DWORD data   = 0;
    DWORD cbData = sizeof(data);
    DWORD type = REG_DWORD;
    if (::RegQueryValueExW(hKey, name.c_str(), 0 /* lpReserved */, &type, (LPBYTE)&data, &cbData )!=ERROR_SUCCESS || type!=REG_DWORD || cbData != sizeof(data))
       return defVal;
    return (unsigned)data;
}

inline
unsigned getValue( HKEY hKeyRoot, const std::string &path, const std::string &name, unsigned defVal, bool share64ForBoth )
{
    HKEY hKeyCreated;
    LONG lRes = openKey( hKeyRoot, path, &hKeyCreated, share64ForBoth);
    if (lRes!=ERROR_SUCCESS) return defVal;
    unsigned r = getValue( hKeyCreated, name, defVal );
    ::RegCloseKey(hKeyCreated);
    return r;
}

inline
unsigned getValue( HKEY hKeyRoot, const std::wstring &path, const std::wstring &name, unsigned defVal, bool share64ForBoth)
{
    HKEY hKeyCreated;
    LONG lRes = openKey( hKeyRoot, path, &hKeyCreated, share64ForBoth);
    if (lRes!=ERROR_SUCCESS) return defVal;
    unsigned r = getValue( hKeyCreated, name, defVal );
    ::RegCloseKey(hKeyCreated);
    return r;
}

inline
LONG setValue( HKEY hKey, const std::string &name, unsigned value )
{
    return ::RegSetValueExA( hKey, name.c_str(), 0 /* Reserved */, REG_DWORD, (LPBYTE)&value, (DWORD)sizeof(value) );
}

inline
LONG setValue( HKEY hKeyRoot, const std::string &path, const std::string &name, unsigned value, bool share64ForBoth )
{
    HKEY hKeyCreated;
    LONG lRes = createKey( hKeyRoot, path, &hKeyCreated, share64ForBoth);
    if (lRes!=ERROR_SUCCESS) return lRes;
    lRes = setValue( hKeyCreated, name, value );
    ::RegCloseKey(hKeyCreated);
    return lRes;
}

inline
LONG setValue( HKEY hKey, const std::wstring &name, unsigned value )
{
    return ::RegSetValueExW( hKey, name.c_str(), 0 /* Reserved */, REG_DWORD, (LPBYTE)&value, (DWORD)sizeof(value) );
}

inline
LONG setValue( HKEY hKeyRoot, const std::wstring &path, const std::wstring &name, unsigned value, bool share64ForBoth )
{
    HKEY hKeyCreated;
    LONG lRes = createKey( hKeyRoot, path, &hKeyCreated, share64ForBoth);
    if (lRes!=ERROR_SUCCESS) return lRes;
    lRes = setValue( hKeyCreated, name, value );
    ::RegCloseKey(hKeyCreated);
    return lRes;
}

inline int getValue( HKEY hKey, const std::string &name, int defVal )                                                     { return (int)getValue( hKey    , name, (unsigned)defVal ); }
inline int getValue( HKEY hKey, const std::wstring &name, int defVal )                                                    { return (int)getValue( hKey    , name, (unsigned)defVal ); }
inline int getValue( HKEY hKeyRoot, const std::string &path, const std::string &name, int defVal, bool share64ForBoth )   { return (int)getValue( hKeyRoot, name, path, (unsigned)defVal, share64ForBoth ); }
inline int getValue( HKEY hKeyRoot, const std::wstring &path, const std::wstring &name, int defVal, bool share64ForBoth ) { return (int)getValue( hKeyRoot, name, path, (unsigned)defVal, share64ForBoth ); }
inline LONG setValue( HKEY hKey, const std::string &name, int value )                                                     { return setValue( hKey    , name, (unsigned)value ); }
inline LONG setValue( HKEY hKey, const std::wstring &name, int value )                                                    { return setValue( hKey    , name, (unsigned)value ); }
inline LONG setValue( HKEY hKeyRoot, const std::string &path, const std::string &name, int value, bool share64ForBoth )   { return setValue( hKeyRoot, name, path, (unsigned)value, share64ForBoth ); }
inline LONG setValue( HKEY hKeyRoot, const std::wstring &path, const std::wstring &name, int value, bool share64ForBoth ) { return setValue( hKeyRoot, name, path, (unsigned)value, share64ForBoth ); }


inline
bool getValue( HKEY hKey, const std::string &name, bool defVal )
{
    std::string strRes = getValue( hKey, name, std::string() );
    if (strRes.empty())
       {
        unsigned uv = getValue( hKey, name, (unsigned)-1 );
        if (uv==(unsigned)-1) return defVal;
        return uv ? true : false;
       }
    return convertStringToBool( strRes, defVal );
}

inline
bool getValue( HKEY hKey, const std::wstring &name, bool defVal )
{
    std::wstring strRes = getValue( hKey, name, std::wstring() );
    if (strRes.empty())
       {
        unsigned uv = getValue( hKey, name, (unsigned)-1 );
        if (uv==(unsigned)-1) return defVal;
        return uv ? true : false;
       }
    return convertStringToBool( strRes, defVal );
}

inline
bool getValue( HKEY hKeyRoot, const std::string &path, const std::string &name, bool defVal, bool share64ForBoth )
{
    std::string strRes = getValue( hKeyRoot, path, name, std::string(), share64ForBoth );
    if (strRes.empty())
       {
        unsigned uv = getValue( hKeyRoot, path, name, (unsigned)-1, share64ForBoth );
        if (uv==(unsigned)-1) return defVal;
        return uv ? true : false;
       }
    return convertStringToBool( strRes, defVal );
}

inline
bool getValue( HKEY hKeyRoot, const std::wstring &path, const std::wstring &name, bool defVal, bool share64ForBoth )
{
    std::wstring strRes = getValue( hKeyRoot, path, name, std::wstring(), share64ForBoth );
    if (strRes.empty())
       {
        unsigned uv = getValue( hKeyRoot, path, name, (unsigned)-1, share64ForBoth );
        if (uv==(unsigned)-1) return defVal;
        return uv ? true : false;
       }
    return convertStringToBool( strRes, defVal );
}











}; // namespace registry


}; // namespace winapi

#ifdef WINAPI_IN_MARTY_NAMESPACE
}; // namespace marty
#endif



#endif /* MARTY_WINAPI_H */

