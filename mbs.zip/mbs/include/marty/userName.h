#include <marty/ponce.h>
#ifdef MARTY_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef MARTY_USERNAME_H
#define MARTY_USERNAME_H

/* add this lines to your scr
#ifndef MARTY_USERNAME_H
    #include <marty/userName.h>
#endif
*/

#if defined(WIN32) || defined(_WIN32)
    #include <marty/winapi.h>
#else
    #include <sys/types.h>
    #include <pwd.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif


namespace marty
{

#if defined(WIN32) || defined(_WIN32)

//-----------------------------------------------------------------------------
inline
bool getUserName( ::std::string &name )
   {
    return MARTY_WINAPI::getUserName(name);
   }

//-----------------------------------------------------------------------------
inline
bool getUserName( ::std::wstring &name )
   {
    return MARTY_WINAPI::getUserName(name);
   }

//-----------------------------------------------------------------------------

#else

//-----------------------------------------------------------------------------
inline
bool getUserName( ::std::string &name )
   {
    #ifdef NO_GETPWUID_R
    struct passwd* pwPtr = getpwuid( getuid() );
    if (!pwPtr) return false;
    if (!pwPtr->pw_name) return false;
    name = pwPtr->pw_name;
    return true;
    #else
    char buf[1024];
    struct passwd pwBuf;
    struct passwd *pwBufPtr;
    if (getpwuid_r( getuid(), &pwBuf, buf, sizeof(buf), &pwBufPtr ))
       return false;
    if (!pwBufPtr) return false;
    if (!pwBufPtr->pw_name) return false;
    name = pwBufPtr->pw_name;
    return true;
    #endif
   }

//-----------------------------------------------------------------------------
inline
bool getUserName( ::std::wstring &name )
   {
    ::std::string strName;
    if (!getUserName(strName)) return false;
    name = MARTY_UTF::fromUtf8( strName );
    return true;
   }

//-----------------------------------------------------------------------------

#endif

}; // namespace marty


#endif /* MARTY_USERNAME_H */

