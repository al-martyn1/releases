#if !defined(_DEBUG)
    #if defined(_MSC_VER)
        #pragma optimize( "gt", on ) /* preffered faster code */
    #endif
#endif
