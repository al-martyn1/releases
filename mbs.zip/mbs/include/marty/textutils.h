#ifndef MARTY_TEXTUTILS_H
#define MARTY_TEXTUTILS_H

/* add this lines to your scr
#ifndef MARTY_TEXTUTILS_H
    #include <marty/textutils.h>
#endif
*/


#if !defined(_ITERATOR_) && !defined(_STLP_ITERATOR) && !defined(__STD_ITERATOR__) && !defined(_CPP_ITERATOR) && !defined(_GLIBCXX_ITERATOR)
    #include <iterator>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_STACK_) && !defined(_STLP_STACK) && !defined(__STD_STACK__) && !defined(_CPP_STACK) && !defined(_GLIBCXX_STACK)
    #include <stack>
#endif


#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

// ::marty::textutils::

namespace marty
{
namespace textutils
{

// http://www.cplusplus.com/reference/iterator/iterator_traits/
// value_type

const unsigned ENC_UNKNOWN  = 0;
const unsigned ENC_ERR      = 0;
const unsigned ENC_UNKNOWN_SINGLE_BYTE  = 1;
const unsigned ENC_OEM      = 2;
const unsigned ENC_ANSI     = 3;
const unsigned ENC_UTF8     = 4;
const unsigned ENC_UTF16LE  = 5; /* (x86) */
const unsigned ENC_UTF16BE  = 6;


/*
FE FF               UTF-16, big-endian
FF FE               UTF-16, little-endian
EF BB BF            UTF-8
*/

template<typename IterType>
inline
unsigned
detectEncoding( IterType b, IterType e )
{
    if (b==e) 
       return ENC_UNKNOWN;
    if ((*b)==(typename std::iterator_traits<IterType>::value_type)(0xFE) )
       {
        ++b;
        if (b==e) 
           return ENC_UNKNOWN;
        if ((*b)!=(typename std::iterator_traits<IterType>::value_type)(0xFF) )
           return ENC_UNKNOWN;
        return ENC_UTF16BE;
       }

    if ((*b)==(typename std::iterator_traits<IterType>::value_type)(0xFF) )
       {
        ++b;
        if (b==e) 
           return ENC_UNKNOWN;
        if ((*b)!=(typename std::iterator_traits<IterType>::value_type)(0xFE) )
           return ENC_UNKNOWN;
        return ENC_UTF16LE;
       }

    if ((*b)==(typename std::iterator_traits<IterType>::value_type)(0xEF) )
       {
        ++b;
        if (b==e) 
           return ENC_UNKNOWN;
        if ((*b)!=(typename std::iterator_traits<IterType>::value_type)(0xBB) )
           return ENC_UNKNOWN;
        ++b;
        if (b==e) 
           return ENC_UNKNOWN;
        if ((*b)!=(typename std::iterator_traits<IterType>::value_type)(0xBF) )
           return ENC_UNKNOWN;
        return ENC_UTF8;
       }

    return ENC_UNKNOWN_SINGLE_BYTE;
/*
    if (b==(typename std::iterator_traits<IterType>::value_type)() )
       {
       
       }
*/
}


inline
void assignBom( std::string &strTo, unsigned bomType )
{
   switch(bomType)
      {
       case ENC_UTF8:  
            {
             unsigned char bom[] = { 0xEF, 0xBB, 0xBF };
             strTo.assign((const char*)&bom[0], sizeof(bom) );
            }
            break;

       case ENC_UTF16LE:  
            {
             unsigned char bom[] = { 0xFF, 0xFE }; // le
             strTo.assign((const char*)&bom[0], sizeof(bom) );
            }
            break;

       case ENC_UTF16BE:  
            {
             unsigned char bom[] = { 0xFE, 0xFF }; // be
             strTo.assign((const char*)&bom[0], sizeof(bom) );
            }
            break;
      }
}

inline
std::string addBomCopy( const std::string &strTo, unsigned bomType )
{
   std::string res; res.reserve( strTo.size() + 4 );
   assignBom( res, bomType );
   res.append( strTo.begin(), strTo.end() );
   return res;
}

inline
void addBom( std::string &strTo, unsigned bomType )
{
   std::string res = addBomCopy(strTo, bomType);
   res.swap(strTo);
}

template<typename IterType>
inline
::std::wstring
textDecodeToWide ( IterType b
           , IterType e
           #if defined(WIN32) || defined(_WIN32)
           , unsigned defBomType = ENC_ANSI
           #else
           , unsigned defBomType = ENC_UTF8
           #endif
           )
{
    unsigned bomType = detectEncoding( b, e );
    if (bomType==ENC_ERR)
       return ::std::wstring();

    int numSkip = 0;
    switch(bomType)
       {
        case ENC_UTF8    : numSkip = 3; break;
        case ENC_UTF16LE : numSkip = 2; break;
        case ENC_UTF16BE : numSkip = 2; break;
       }

    for(int skip = 0; skip!=numSkip && b!=e; ++skip, ++b) {}
    if (b==e)
       return ::std::wstring();

    if (bomType==ENC_UNKNOWN_SINGLE_BYTE)
       bomType = defBomType;

    switch(bomType)
       {
        #if defined(WIN32) || defined(_WIN32)
        case ENC_OEM:
             {
              return MARTY_CON::strToWide(std::string(b,e), CP_OEMCP );
             }

        case ENC_ANSI:
             {
              return MARTY_CON::strToWide(std::string(b,e), CP_ACP );
             }
        #endif

        case ENC_UTF8:
             {
              return MARTY_UTF::fromUtf8(std::string(b,e));
             }

        case ENC_UTF16LE:
             {
              ::std::wstring res;
              res.reserve(e-b);
              MARTY_UTF::CCharsCollector<wchar_t> collector(res);
              MARTY_UTF::CByteStreamLeToUcs2Decoder< MARTY_UTF::CCharsCollector<wchar_t> > decoder(collector);
              decoder( &(*b), (int)(e-b) );
              return res;
             }
             break;

        case ENC_UTF16BE:
             {
              ::std::wstring res;
              res.reserve(e-b);
              MARTY_UTF::CCharsCollector<wchar_t> collector(res);
              MARTY_UTF::CByteStreamBeToUcs2Decoder< MARTY_UTF::CCharsCollector<wchar_t> > decoder(collector);
              decoder( &(*b), (int)(e-b) );
              return res;
             }
             break;

        /*
        case :
             {
             }
             break;
        */
        default:            
             return ::std::wstring();
       }
}


template<typename CharType>
struct CIsExactChar
{
    CharType ch;
    CIsExactChar(CharType c) : ch(c) {}
    bool operator()(CharType c) const { return c==ch; }
};

template<typename CharType>
struct CIsAnyChar
{
    bool operator()(CharType c) const { return true; }
};

template<typename CharType>
struct CIsNeitherChar
{
    bool operator()(CharType c) const { return false; }
};

template<typename CharType>
struct CIsOneOfChar
{
    const CharType *pChars;
    CIsOneOfChar(const CharType *pc) : pChars(pc) {}
    bool operator()(CharType c) const
    {
     for(const CharType *pc=pChars; *pc; ++pc)
        {
         if (*pc==c) return true;
        }
     return false;
    }
};

template<typename CharType>
struct CIsNotOneOfChar
{
    const CharType *pChars;
    CIsNotOneOfChar(const CharType *pc) : pChars(pc) {}
    bool operator()(CharType c) const
    {
     for(const CharType *pc=pChars; *pc; ++pc)
        {
         if (*pc==c) return false;
        }
     return true;
    }
};


template< typename IterFrom, typename BackInsertIter, typename StopPred >
inline
IterFrom 
parseBasicEscapesC( IterFrom b, IterFrom e, BackInsertIter insIter, const StopPred &stopPred )
{
   bool fWaitCtrl = false;
   for(; b!=e; ++b)
      {
       if (!fWaitCtrl)
          {
           if (stopPred(*b)) return b;
           if ( *b == (typename std::iterator_traits<IterFrom>::value_type)('\\') ) fWaitCtrl = true;
           else *(insIter++) = *b;
           continue;
          }
       switch(*b)
          {
           case '\\': *(insIter++) = (typename std::iterator_traits<IterFrom>::value_type)('\\'); break;
           case '\'': *(insIter++) = (typename std::iterator_traits<IterFrom>::value_type)('\''); break;
           case '\"': *(insIter++) = (typename std::iterator_traits<IterFrom>::value_type)('\"'); break;
           case 'n' : *(insIter++) = (typename std::iterator_traits<IterFrom>::value_type)('\n'); break;
           case 'r' : *(insIter++) = (typename std::iterator_traits<IterFrom>::value_type)('\r'); break;
           case 't' : *(insIter++) = (typename std::iterator_traits<IterFrom>::value_type)('\t'); break;
           case '0' : *(insIter++) = (typename std::iterator_traits<IterFrom>::value_type)(0); 
                      ++b;
                      if (b==e) return b;
                      ++b;
                      if (b==e) return b;
                      break;
           //case '\\': *(insIter++) = (typename std::iterator_traits<IterFrom>::value_type)('\\'); break;
           default:  *(insIter++) = *b;
          }
       fWaitCtrl = false;
      }
   return b;
}

template< typename IterFrom, typename BackInsertIter >
inline
IterFrom 
parseBasicEscapesC( IterFrom b, IterFrom e, BackInsertIter insIter )
{
    return parseBasicEscapesC( b, e, insIter, CIsNeitherChar< typename std::iterator_traits<IterFrom>::value_type >() );
}

template<typename IterFrom, typename BackInsertIter, typename CharType>
inline
IterFrom basicEscapeC(IterFrom b, IterFrom e, BackInsertIter insIter, CharType quoteType, bool bDontEscapeCRLF = false )
{
    //typedef typename std::iterator_traits<IterFrom>::value_type CharType;
    for(; b!=e; ++b)
       {
        switch(*b)
           {
            case (CharType)'\\':
                 *(insIter++) = (CharType)'\\';
                 *(insIter++) = (CharType)'\\';
                 break;

            case (CharType)'\'':
            case (CharType)'\"':
                 if (quoteType==(CharType)0)
                    {
                     *(insIter++) = (CharType)'\\';
                     *(insIter++) = *b;
                    }
                 else if (quoteType==*b)
                    {
                     *(insIter++) = (CharType)'\\';
                     *(insIter++) = *b;
                    }
                 else
                    {
                     *(insIter++) = *b;
                    }

                 break;

            case (CharType)'\n':
            case (CharType)'\r':
                 if (bDontEscapeCRLF)
                    {
                     *(insIter++) = *b;
                    }
                 else
                    {
                     *(insIter++) = (CharType)'\\';
                     if (*b==(CharType)'\n')
                        *(insIter++) = (CharType)'n';
                     else
                        *(insIter++) = (CharType)'r';
                    }
                 break;

            case (CharType)'\t':
                 *(insIter++) = (CharType)'\\';
                 *(insIter++) = (CharType)'t';
                 break;
            //case (CharType)'':
            //     *(insIter++) = (CharType)'\\';
            //     *(insIter++) = (CharType)'';
            case (CharType)0:
                 *(insIter++) = (CharType)'\\';
                 *(insIter++) = (CharType)'0';
                 *(insIter++) = (CharType)'0';
                 *(insIter++) = (CharType)'0';
                 break;

            default:
                 *(insIter++) = *b;
           }

       }
    return b;
}



template< typename IterFrom, typename BackInsertIter, typename ContinuePred >
inline
IterFrom 
copyWhile( IterFrom b, IterFrom e, BackInsertIter insIter, const ContinuePred &continuePred )
{
   for(; b!=e && continuePred(*b); ++b)
      {
       *(insIter++) = *b;
      }
   return b;
}

template< typename IterFrom, typename BackInsertIter, typename StopPred >
inline
IterFrom 
copyWhileNot( IterFrom b, IterFrom e, BackInsertIter insIter, const StopPred &stopPred )
{
   for(; b!=e && !stopPred(*b); ++b)
      {
       *(insIter++) = *b;
      }
   return b;
}

template< typename IterFrom, typename ContinuePred >
inline
IterFrom 
moveWhile( IterFrom b, IterFrom e, const ContinuePred &continuePred )
{
   for(; b!=e && continuePred(*b); ++b)
      {
       // allow step by step debugging
      }
   return b;
}

template< typename IterFrom, typename StopPred >
inline
IterFrom 
moveWhileNot( IterFrom b, IterFrom e, const StopPred &stopPred )
{
   for(; b!=e && !stopPred(*b); ++b)
      {
       // allow step by step debugging
      }
   return b;
}


template<typename CharType>
inline
int char2digit(CharType c)
{
    if (c>=(CharType)'0' && c<=(CharType)'9') return (int)(c-(CharType)'0');
    if (c>=(CharType)'a' && c<=(CharType)'z') return (int)(c-(CharType)'a'+10);
    if (c>=(CharType)'A' && c<=(CharType)'Z') return (int)(c-(CharType)'A'+10);
    return -1;
}

template<typename CharType>
inline
CharType digit2char(int d, bool bUppercase)
{
    if (d<10) return (CharType)'0' + (CharType)d;
    if (d>35) return (CharType)'?';
    d -= 10;
    if (bUppercase) return (CharType)'A' + (CharType)d;
    else            return (CharType)'a' + (CharType)d;
}

template< typename IterFrom, typename ConvertTo >
inline
IterFrom
convertString2Number( IterFrom b, IterFrom e, ConvertTo & convertTo, ConvertTo base )
{
    if (base==0) base = (ConvertTo)16;

    convertTo = 0;
    for(; b!=e; ++b)
       {
        int d = char2digit< typename std::iterator_traits<IterFrom>::value_type >(*b);
        if (d<0) return b;
        ConvertTo tmp = (ConvertTo)d;
        if (tmp>=base) return b;
        convertTo *= base;
        convertTo += tmp;
       }
    return b;
}

// vector version
template< typename IterFrom, typename BackInsertIter, typename ItemType, typename SeqPred, typename SpacePred>
inline
IterFrom
convertString2NumberSequence( IterFrom b, IterFrom e
                     , BackInsertIter insIter
                     //, typename std::iterator_traits<BackInsertIter>::value_type base
                     , ItemType base
                     , const SeqPred &seqPred, const SpacePred &spacePred
                     )
{
    if (base==0) base = (ItemType)16;

    for(; ; )
       {
        if (b==e)
           return b;

        b = moveWhile( b, e, spacePred );
        if (b==e)
           return b;
        b = moveWhile( b, e, seqPred );
        if (b==e)
           return b;
        b = moveWhile( b, e, spacePred );
        if (b==e)
           return b;

        //typename std::iterator_traits<BackInsertIter>::value_type tmpVal;
        ItemType tmpVal;
        IterFrom tmpIter = convertString2Number( b, e, tmpVal, base );
        if (tmpIter==b)
           return b; // nothing was processed
        // something processed
        b = tmpIter;
        *(insIter++) = tmpVal;

        if (b==e)
           return b;
       }
}

// width - -1 exact, 0 - auto (by type size), N - at least N number of digits

template< typename IntType, typename CharType, typename BackInsertIter>
inline
void
convertNumber2String( IntType v, IntType base, CharType fillChar, BackInsertIter insIter, int width = 0, bool bUpper = false )
{
    if (base==0) base = (IntType)16;

    std::stack< CharType > s;
    typedef typename std::stack< CharType >::size_type  stack_size_type;
    while(v)
       {
        IntType d = v % base;
        v /= base;
        s.push( digit2char< CharType >( (int)d, bUpper ) );
       }

    if (s.empty())
       s.push( (CharType)'0' );

    stack_size_type minChars = 1;
    if (width==0)
       {
        stack_size_type targetNumBits = sizeof(IntType)*CHAR_BIT;        
        switch(base)
           {
            case 2: minChars = targetNumBits;
                    break;
            case 4: minChars = targetNumBits/2;
                    break;
            case 8: minChars = targetNumBits/3;
                    break;
            case 16: minChars = targetNumBits/4;
                    break;
            case 32: minChars = targetNumBits/5;
                    break;
            //case 10: width = 5*targetNumBits/(4*4);  // 10 dec from 8 hex - targetNumBits/4  5/4
            //case 10: width = 5*targetNumBits/(4*4);  // 10 dec from 8 hex - targetNumBits/4  5/4
            //        break;
            //default:width = 1;
           }
       }
    else if (width>0)
       minChars = (stack_size_type)width;


    if (width<0)
       width = 1;

    if (width>32)
       width = 32;

    while(s.size() < minChars )
       s.push(fillChar);

    while(!s.empty())
       {
        *(insIter++) = s.top();
        s.pop();
       }
}


template<typename Iter1, typename Iter2>
inline
typename std::iterator_traits< Iter1 >::difference_type
getSequenceEqualLen(Iter1 b1, Iter1 e1, Iter2 b2, Iter2 e2 )
{
    std::iterator_traits< Iter1 >::difference_type len = 0;
    for( ; b1!=e1 && b2!=e2; ++b1, ++b2, ++len )
       {
        if ( *b1 != *b2 ) return len;
       }
    return len;
}

template<typename Sec1, typename Sec2>
inline
typename Sec1::difference_type
getSequenceEqualLen(const Sec1 &sec1, const Sec2 &sec2 )
{
    return getSequenceEqualLen(sec1.begin(), sec1.end(), sec2.begin(), sec2.end());
}



}; // namespace textutils
}; // namespace marty


#endif /* MARTY_TEXTUTILS_H */

