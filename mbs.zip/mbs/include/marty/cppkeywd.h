#include <marty/ponce.h>
#ifdef MARTY_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef MARTY_CPPKEYWD_H
#define MARTY_CPPKEYWD_H

/* add this lines to your scr
#ifndef MARTY_CPPKEYWD_H
    #include <marty/cppkeywd.h>
#endif
*/

/*
Reports the major and minor versions of the compiler. 
For example, 1310 for Microsoft Visual C++ .NET 2003. 
1310 represents version 13 and a 1.0 point release. 
The Visual C++ 2005 compiler version is 1400.

MSVC 5: 1100 
MSVC 6: 1200 
MSVC 7.0 (.NET 2002): 1300 
MSVC 7.1 (.NET 2003): 1310 
MSVC 8.0 (.NET 2005): 1400 
MSVS 9.0 (.NET 2007): 1500 (???) 
MSVS 10.0 (.NET 2010): 1600 (???) 

http://msdn.microsoft.com/en-us/library/b0084kay.aspx
For example, if the version number of the Visual C++ compiler is 15.00.20706.01, 
the _MSC_VER macro evaluates to 1500.

In Visual Studio 2010, _MSC_VER is defined as 1600.


http://en.wikipedia.org/wiki/Microsoft_codenames
http://bink.nu/Codenames.bink

*/

// GCC allows such keywords, but older MSVC not
#ifdef _MSC_VER
    #if _MSC_VER < 1600
        #define not !
        #define or  ||
        #define and &&
    #endif
#endif


// Also, we undefine Win32 macroses min/max to avoid conflicts with stl
#ifdef min
    #undef min
#endif

#ifdef max
    #undef max
#endif


#endif /* MARTY_CPPKEYWD_H */

