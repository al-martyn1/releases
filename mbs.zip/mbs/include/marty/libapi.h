/*
   Copyright (c) 2007-2009 Alex Martynov, amart at mail.ru
   This code can be used without any limitations.
   This code provided as is, use it on your own risk.
*/

#include <marty/ponce.h>
#ifdef MARTY_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef MARTY_LIBAPI_H
#define MARTY_LIBAPI_H

// see boost/tools/jam/src/boehm_gc/threadlibs.c

#ifdef WIN32
    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif
#else
    #include <dlfcn.h>
    #include <unistd.h>
    #include <errno.h>
#endif

#ifndef MARTY_BASICTCHARDEFS_H
    #include <marty/basictchardefs.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef MARTY_FILESYS_H
    #include <marty/filesys.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifdef WIN32
    #include <marty/winapi.h>
#endif

#ifndef MARTY_MHDLDEF_H
    #include <marty/mhdldef.h>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif


//#if defined(LINUX) || defined(FREEBSD)
// requred for proc/self/maps parsing
#include <marty/util.h>
//#endif // LINUX || FREEBSD

#if defined(LINUX) || defined(FREEBSD)
    #if defined(__GNUC__)
        #include <cxxabi.h>
    #endif
#endif // LINUX || FREEBSD



#if !defined(_INC_STDIO) && !defined(_STDIO_H_) && !defined(_STDIO_H)
    #include <stdio.h>
#endif



#ifndef MARTY_STRING
    #define MARTY_STRING(TC) ::std::basic_string<TC>
#endif

#ifndef MARTY_TCSTRING
    #define MARTY_TCSTRING   MARTY_STRING(TC)
#endif

#ifdef USE_MARTY_NAMESPACE
    #ifndef LIBAPI_IN_MARTY_NAMESPACE
        #define LIBAPI_IN_MARTY_NAMESPACE
    #endif
#endif

#ifdef LIBAPI_IN_MARTY_NAMESPACE
    #ifndef MARTY_NS
        #define BEGIN_MARTY_NS          namespace marty {
        #define END_MARTY_NS            };
        #define MARTY_NS                ::marty::
     #endif
#else
    #ifndef MARTY_NS
        #define BEGIN_MARTY_NS
        #define END_MARTY_NS
        #define MARTY_NS                ::
     #endif
#endif

#define MARTY_LIBAPI               MARTY_NS libapi
#define MARTY_LIBAPI_NS            MARTY_NS libapi::
#define BEGIN_MARTY_LIBAPI_NS      BEGIN_MARTY_NS namespace libapi {
#define END_MARTY_LIBAPI_NS        END_MARTY_NS   };





BEGIN_MARTY_LIBAPI_NS

#ifdef LIBAPI_IN_MARTY_NAMESPACE
using ::marty::filename::tstring;
#else
using ::filename::tstring;
#endif



//#if defined(LINUX) || defined(FREEBSD)
#if !defined(WIN32) && !defined(_WIN32)
namespace libdl
{

inline
void* getSomeAddrInModule()
   {
    return (void*)&getSomeAddrInModule;
   }

inline
bool getCurrentModuleFileName( ::std::string &moduleName )
   {
    Dl_info info;
    int dladdrRes = dladdr( getSomeAddrInModule(), &info);
    if (!dladdrRes) return false; // can't get module name
    moduleName = info.dli_fname;
    return true;
   }

inline
bool getCurrentModuleFileName( ::std::wstring &moduleName )
   {
    ::std::string strModName;
    if (!getCurrentModuleFileName( strModName )) return false;
    //::std::string wideModName;
    //MARTY_FILESYSTEM::filenameDecode(wideModName, strModName);
    //return wideModName;
    MARTY_FILESYSTEM::filenameDecode(moduleName, strModName);
    return true;
   }

inline
::std::string getAddressName( void *pAddr )
   {
    Dl_info info;
    int dladdrRes = dladdr( pAddr, &info);
    if (!dladdrRes) return ::std::string("<unknown>"); // can't get module name
    return ::std::string(info.dli_sname);
   }

}; // namespace libdl
#endif




namespace procfs
{

#if defined(LINUX) || defined(FREEBSD)

inline
bool readSelfMaps( ::std::string &selfMaps )
   {
    int fd = open("/proc/self/maps", O_RDONLY );
    if (fd<0) return false;

    selfMaps.clear();
    char buf[4096];

    ssize_t res = read( fd, (void*)&buf[0], sizeof(buf));
    while(res>0)
       {
        selfMaps.append( buf, res );
        res = read( fd, (void*)&buf[0], sizeof(buf));
       }
    close(fd);
    return !selfMaps.empty();
   }

inline
bool readProcSelfExeName( ::std::string &exename)
   {
    char buf[4096];
    int len = readlink("/proc/self/exe", buf, sizeof(buf)/sizeof(buf[0])-1);
    if (len>=0)
       {
        exename.assign( buf, len );
        return !exename.empty();
       }
    return false;
   }

#endif

inline
void prepareSelfMaps( const ::std::string &selfMaps, ::std::vector< ::std::string > &selfMapsLineByLine )
   {
    ::marty::util::split( selfMapsLineByLine, selfMaps, ::marty::util::CIsExactChar<'\n'>(), 0 );
    ::std::vector< ::std::string >::iterator it = selfMapsLineByLine.begin();
    for(; it != selfMapsLineByLine.end(); ++it )
       {
        ::marty::util::trim( *it, ::marty::util::CIsSpace<char>() );
       }
   }

inline
void prepareSelfMapsLine( const ::std::string &selfMapsLine, ::std::vector< ::std::string > &lineItemByItem )
   {
    ::marty::util::split( lineItemByItem, selfMapsLine, ::marty::util::CIsExactChar<' '>(), 0 );
    ::std::vector< ::std::string >::iterator it = lineItemByItem.begin();
    for(; it != lineItemByItem.end(); ++it )
       {
        ::marty::util::trim( *it, ::marty::util::CIsSpace<char>() );
       }
   }


// http://linux.die.net/man/5/proc
// address           perms offset  dev   inode      pathname
// 08048000-08056000 r-xp 00000000 03:0c 64593      /usr/sbin/gpm

struct CMemMapItem
{

    static const unsigned int permRead    = 4; // r
    static const unsigned int permWrite   = 2; // w
    static const unsigned int permExecute = 1; // x
    static const unsigned int permShared  = 8; // s (mutualy exclusive with p)
    static const unsigned int permPrivate =16; // p private (copy-on-write)

    void*          startAddr;
    void*          nextAddr;
    unsigned int   perms;
    void*          offset;    // ptr, what it means?
    int            devMajor;
    int            devMinor;
    int            iNode;
    ::std::string  pathname;

}; // CMemMapItem




inline
void parseSelfMaps( ::std::vector<CMemMapItem> &memMap, const ::std::string &selfMaps )
   {
    // address           perms offset  dev   inode   pathname
    // 08048000-08056000 r-xp 00000000 03:0c 64593   /usr/sbin/gpm

    // address - This is the starting and ending address of the region in the process's address space
    // permissions - This describes how pages in the region can be accessed. 
    //               There are four different permissions: read, write, execute, and shared. 
    //               If read/write/execute are disabled, a '-' will appear instead of the 'r'/'w'/'x'. 
    //               If a region is not shared, it is private, so a 'p' will appear instead of an 's'. 
    //               If the process attempts to access memory in a way that is not permitted, a segmentation fault is generated. 
    //               Permissions can be changed using the mprotect system call.
    // offset      - If the region was mapped from a file (using mmap), this is the offset in the file where the mapping begins. 
    //               If the memory was not mapped from a file, it's just 0.
    // device      - If the region was mapped from a file, this is the major and minor device number (in hex) where the file lives.
    // inode       - If the region was mapped from a file, this is the file number.
    // pathname    - If the region was mapped from a file, this is the name of the file. 
    //               This field is blank for anonymous mapped regions. 
    //               There are also special regions with names like [heap], [stack], or [vdso]. 
    //               [vdso] stands for virtual dynamic shared object. 
    //               It's used by system calls to switch to kernel mode. 
    //               http://www.trilithium.com/johan/2005/08/linux-gate/

    ::std::vector< ::std::string > selfMapsLines;
    prepareSelfMaps( selfMaps, selfMapsLines );
    for(::std::vector< ::std::string >::const_iterator lineIt = selfMapsLines.begin(); lineIt != selfMapsLines.end(); ++lineIt)
       {
        if (lineIt->empty()) continue;
        ::std::vector< ::std::string > line;
        prepareSelfMapsLine( *lineIt, line );
         {
          ::std::vector< ::std::string > tmp;
          ::std::vector< ::std::string >::const_iterator tmpIt = line.begin();
          for(; tmpIt != line.end(); ++tmpIt)
             {
              if (tmpIt->empty()) continue;
              tmp.push_back(*tmpIt);
             }
          tmp.swap(line);
         }

        if (line.size()<5) continue;

        CMemMapItem mapItem;

        if (line[0].empty()) continue;
        int ssres = sscanf( line[0].c_str(), "%p-%p", &mapItem.startAddr, &mapItem.nextAddr);
        if (ssres!=2) continue;

        mapItem.perms = 0;
        ::std::string::size_type pos = 0, size = line[1].size();
        for(; pos!=size; ++pos)
           {
            if (line[1][pos]=='r') mapItem.perms |= CMemMapItem::permRead; // use also CMemMapItem::
            if (line[1][pos]=='w') mapItem.perms |= CMemMapItem::permWrite;
            if (line[1][pos]=='x') mapItem.perms |= CMemMapItem::permExecute;
            if (line[1][pos]=='s') mapItem.perms |= CMemMapItem::permShared;
            if (line[1][pos]=='p') mapItem.perms |= CMemMapItem::permPrivate;
           }

        if (line[2].empty()) continue;
        // If the region was mapped from a file (using mmap), this is the offset in the file 
        // where the mapping begins. If the memory was not mapped from a file, it's just 0.
        ssres = sscanf( line[2].c_str(), "%p", &mapItem.offset);
        if (ssres!=1) continue;


        if (line[3].empty()) continue;
        ssres = sscanf( line[3].c_str(), "%d:%d", &mapItem.devMajor, &mapItem.devMinor);
        if (ssres!=2) continue;

        if (line[4].empty()) continue;
        ssres = sscanf( line[4].c_str(), "%d", &mapItem.iNode);
        if (ssres!=1) continue;

        #if !defined(_MSC_VER) || _MSC_VER<1400
            #ifndef _sprintf
                #define _sprintf sprintf
                #define _snprintf snprintf
                #define __marty_libapi_undef_sprintf
            #endif
        #endif


        if (line.size()>5)
           mapItem.pathname = line[5];
        if (mapItem.pathname.empty())
           {
            char buf[128];
            _snprintf(buf, sizeof(buf)/sizeof(buf[0]), "[undef %d]", ((int)memMap.size())+1 );
            mapItem.pathname = buf;
           }

        #ifdef __marty_libapi_undef_sprintf
            #undef __mbs_undef_sprintf
            #undef _sprintf
            #undef __marty_libapi_undef_sprintf
        #endif
        memMap.push_back(mapItem);
       }
   }

#if defined(LINUX) || defined(FREEBSD)
inline
void parseSelfMaps( ::std::vector<CMemMapItem> &memMap )
   {
    memMap.clear();
    ::std::string selfMaps;
    if (!readSelfMaps( selfMaps )) return;
    parseSelfMaps( memMap, selfMaps );
   }
#endif

inline
const CMemMapItem* findMemMapItemByAddr( const ::std::vector<CMemMapItem> &memMap, void *ptr )
   {
    ::std::vector<CMemMapItem>::const_iterator it = memMap.begin();
    for(; it != memMap.end(); ++it)
       {
        //if ( ptr >= it->startAddr && ptr < it->nextAddr ) return &(*it);
        if ( it->startAddr <= ptr && ptr < it->nextAddr ) return &(*it);
       }
    return 0;
   }

inline
::std::string getMemMapInfo( void *ptr )
   {
    #if defined(LINUX) || defined(FREEBSD)
    ::std::vector<CMemMapItem> memMap;
    parseSelfMaps( memMap );
    const CMemMapItem* pmmi = findMemMapItemByAddr( memMap, ptr );
    if (!pmmi) return ::std::string("<unknown>");
    return pmmi->pathname;
    #else
    return ::std::string("<unknown>");
    #endif
   }

inline
::std::string getShortMemMapInfo( void *ptr )
   {
    #if defined(LINUX) || defined(FREEBSD)
    ::std::vector<CMemMapItem> memMap;
    parseSelfMaps( memMap );
    const CMemMapItem* pmmi = findMemMapItemByAddr( memMap, ptr );
    if (!pmmi) return ::std::string("<unknown>");
    return MARTY_FILENAME::getFile(pmmi->pathname);
    #else
    return ::std::string("<unknown>");
    #endif
    //return pmmi->pathname;
   }

inline
::std::string getMemMapInfoEx( void *ptr
                             , bool shortFilename = true
                             , bool addAddressName = true
                             , bool demangleAddrName = true
                             )
   {
    #if defined(LINUX) || defined(FREEBSD)
    ::std::vector<CMemMapItem> memMap;
    parseSelfMaps( memMap );
    const CMemMapItem* pmmi = findMemMapItemByAddr( memMap, ptr );
    if (!pmmi) return ::std::string("<unknown>");
    ::std::string strRes = pmmi->pathname;
    if (!strRes.empty() && strRes[0]!='<' && strRes[0]!='[' && shortFilename)
       strRes = MARTY_FILENAME::getFile(pmmi->pathname);
    if (!strRes.empty() && strRes[0]!='<' && strRes[0]!='[' && addAddressName)
       {
        ::std::string strName = libdl::getAddressName( ptr );
        if (!strName.empty() && strName[0]!='<' && demangleAddrName)
           {
            //size_t  demangledLength = 0;
            int status = 0;
            char* pDemangled = abi::__cxa_demangle( strName.c_str(), 0, 0 /* &demangledLength */ , &status );
            if (pDemangled && !status)
               strName = pDemangled;
            if (pDemangled)
               free(pDemangled);
           }
        strRes += ::std::string(" ") + strName;
       }
    return strRes;
    #else
    return ::std::string("<unknown>");
    #endif
   }



}; // namespace procfs
//#endif // LINUX || FREEBSD




#ifdef DL_DEBUG
inline void printModuleDebugInfoPrefix( const char *prefix )
   {
    if (prefix) printf("%s: ", prefix);
   }

inline
void printModuleHandleDebugInfo( ABSTRACT_MODULE_HANDLE pModule, const char *prefix = 0 )
   {
    if (pModule)
       {
        Dl_info info;
        int dladdrRes = dladdr((void*)(((char*)pModule)+0), &info);
        if (!dladdrRes)
           {
            printModuleDebugInfoPrefix(prefix);
            printf("handle: %p - dladdr failed\n", (void*)pModule );
            const char *errMsg = dlerror();
            printModuleDebugInfoPrefix(prefix);
            printf("message - %s\n", errMsg );
           }
        else
           { // print info
            printModuleDebugInfoPrefix(prefix);
            printf(" Module          : %s\n", info.dli_fname);
            printModuleDebugInfoPrefix(prefix);
            printf(" ModBase         : %p\n", (void*)info.dli_fbase);
            printModuleDebugInfoPrefix(prefix);
            printf(" Symbol          : %s\n", info.dli_sname);
            printModuleDebugInfoPrefix(prefix);
            printf(" Nearest sym addr: %p\n", (void*)info.dli_saddr);
           }

        ::std::vector<procfs::CMemMapItem> memMap;
        procfs::parseSelfMaps( memMap );
        printModuleDebugInfoPrefix(prefix);
        const procfs::CMemMapItem *infoPtr = procfs::findMemMapItemByAddr( memMap, pModule );
        if (infoPtr)
           printf("(/proc/self/maps) Address (%p) assigned to %s\n", pModule, infoPtr->pathname.c_str() );
        else
           printf("(/proc/self/maps) Address (%p) is unassigned\n", pModule );
       }
    else
       {
        printModuleDebugInfoPrefix(prefix);
        printf("pModule==0\n");
       }
   }
#endif

//-----------------------------------------------------------------------------
// return module handle or zero if error
template < typename CharType
         , typename Traits
         , typename Allocator
         >
ABSTRACT_MODULE_HANDLE
loadModule(const ::std::basic_string<CharType, Traits, Allocator> &modname)
   {
    #ifdef WIN32
    UINT prevErrMode = ::SetErrorMode(SEM_NOOPENFILEERRORBOX|SEM_FAILCRITICALERRORS);
    ABSTRACT_MODULE_HANDLE res = ::LoadLibrary( MARTY_FILESYSTEM_NS osFilename(modname).c_str() );
    DWORD lastErr = ::GetLastError();
    ::SetErrorMode(prevErrMode);
    ::SetLastError(lastErr);
    return res;
    #else
    ::std::string fname = MARTY_FILESYSTEM::osFilename(modname);
    #ifdef DL_DEBUG
    printf("loadModule: try to load %s\n", fname.c_str() );
    #endif
    void *pModule = ::dlopen( fname.c_str(),  RTLD_NOW|RTLD_LOCAL);
    #ifdef DL_DEBUG
    printf("loadModule: module handle - %p\n", pModule );
    #endif

    #ifdef DL_DEBUG
    printModuleHandleDebugInfo( pModule, "loadModule" );
    #endif

    return pModule;
    // if (!dlopenRet) err = dlerror(); // get the human printable error message
    #endif
   }

//-----------------------------------------------------------------------------
// return error code or zero (under linux/posix error code undefined/unknown, but not zero)
inline
int freeModule(ABSTRACT_MODULE_HANDLE handle)
   {
    #ifdef WIN32
    // If the FreeLibrary function succeeds, the return value is nonzero.
    if (!::FreeLibrary(handle)) return ::GetLastError();
    return 0;
    #else
    // The function dlclose() returns 0 on success, and non-zero on error.
    return ::dlclose(handle);
    #endif
   }

//-----------------------------------------------------------------------------
//tstring getModuleFileName(ABSTRACT_MODULE_HANDLE handle);
//-----------------------------------------------------------------------------
// return 0 on siccess, error code if error
// http://gentoo.theserverside.ru/book/index.html
// http://gentoo.theserverside.ru/book/linuxndi.html
// http://gentoo.theserverside.ru/book/ar68s15.html

// http://stackoverflow.com/questions/1023306/finding-current-executables-path-without-proc-self-exe

inline
int getModuleFileName(ABSTRACT_MODULE_HANDLE handle, ::std::string &retFileName)
   {
    #if defined(_WIN32) || defined(WIN32)
    ::std::string res;
    MARTY_WINAPI::getModuleFileName(handle, res);
    if (res.empty()) return GetLastError(); // keep retFileName untouched
    retFileName.swap(res);
    return 0;
    #else
    if (!handle)
       {
        #ifdef DL_DEBUG
        printf("getModuleFileName: Null handle taken, try to get main module name from /proc/self/exe\n");
        #endif

        #if defined(LIBAPI_PROCFS_DISABLE)
            #error "Filesystem /proc unsopporteg on this target"
        #else
        if (!procfs::readProcSelfExeName(retFileName))
           return ENOENT;
        return 0;
        #endif
       }

    #ifdef DL_DEBUG
    printf("getModuleFileName: Non-Null handle taken, lookup for one of symbols\n");
    #endif

    // non-null handle taken, try dlsym
    static const char* names[] = { "_init", "_fini", "main"
                                 , "_abort", "__assert", "_atexit"
                                 , "___dllonexit", "___chkstk"
                                 , 0
                                 };
    size_t i = 0;
    const char *pName = names[i++];
    void* pAddr = 0;
    while(pName && !pAddr)
       {
        #ifdef DL_DEBUG
        printf("getModuleFileName: try dlsym( %p, %s )\n", handle, pName );
        #endif
        pAddr = dlsym( handle, pName );
        pName = names[i++];
       }

    #ifdef DL_DEBUG
    printf("getModuleFileName: found pAddr: %p\n", pAddr );
    #endif

    if (!pAddr)
       return ENOENT;

    Dl_info info;
    int dladdRes = dladdr(pAddr, &info);

    if (!dladdRes || !info.dli_fname)
       {
        return ENOENT;
       }

    retFileName.assign(info.dli_fname);
    return 0;
    #endif
   }

inline
int getModuleFileName(ABSTRACT_MODULE_HANDLE handle, ::std::wstring &retFileName)
   {
    #if defined(_WIN32) || defined(WIN32)
    ::std::wstring res;
    MARTY_WINAPI::getModuleFileName(handle, res);
    if (res.empty()) return GetLastError(); // keep retFileName untouched
    retFileName.swap(res);
    return 0;
    #else
    ::std::string resCharStr;
    int res = getModuleFileName(handle, resCharStr );
    if (res) return res;
    MARTY_FILESYSTEM::fromOsFilename2(retFileName, resCharStr);
    return 0;
    #endif
   }

inline
ABSTRACT_MODULE_HANDLE getModuleHandle( const ::std::string &filename, bool bGlobal = false )
   {
    #if defined(_WIN32) || defined(WIN32)
    return (ABSTRACT_MODULE_HANDLE)MARTY_WINAPI::getModuleHandle(filename);
    #else
    int dlFlags = RTLD_NOW|RTLD_NOLOAD;
    if (bGlobal) dlFlags |= RTLD_GLOBAL;
    else         dlFlags |= RTLD_LOCAL;
    return (ABSTRACT_MODULE_HANDLE)dlopen( filename.c_str(), dlFlags );
    #endif
   }

inline
ABSTRACT_MODULE_HANDLE getModuleHandle( const ::std::wstring &filename, bool bGlobal = false )
   {
    #if defined(_WIN32) || defined(WIN32)
    return (ABSTRACT_MODULE_HANDLE)MARTY_WINAPI::getModuleHandle(filename);
    #else
    int dlFlags = RTLD_NOW|RTLD_NOLOAD;
    if (bGlobal) dlFlags |= RTLD_GLOBAL;
    else         dlFlags |= RTLD_LOCAL;
    return (ABSTRACT_MODULE_HANDLE)dlopen( MARTY_FILESYSTEM::osFilename(filename).c_str(), dlFlags );
    #endif
   }

/*
template < typename CharType
         , typename Traits
         , typename Allocator
         >
int getModuleFileName(ABSTRACT_MODULE_HANDLE handle, ::std::basic_string<CharType, Traits, Allocator> &retFileName)
   {
    #ifdef WIN32
    ::std::basic_string<CharType, Traits, Allocator> res;
    MARTY_WINAPI_NS getModuleFileName(handle, res);
    if (res.empty()) return GetLastError(); // keep retFileName untouched
    retFileName.swap(res);
    return 0;
    #else
    // ldd -v elf
    // nm elf
    // nm elf | grep " T "
    // are good helpers

    #ifdef DL_DEBUG
    #endif

    bool needFree = false;
    void* pAddr = 0;
    if (!handle)
       {
        #ifdef DL_DEBUG
        printf("getModuleFileName: Null handle taken, try to get main module handle\n");
        #endif
        //ABSTRACT_MODULE_HANDLE
        int dlflags = RTLD_LAZY; // 0
        #ifdef RTLD_NOLOAD
        dlflags |= RTLD_NOLOAD;
        #endif
        handle = ::dlopen( (const char*)0, dlflags ); // get main module handle
        //pAddr = dlsym(handle, "main");
        needFree = true;
        #ifdef DL_DEBUG
        //printf("CP 1\n");
        if (!handle)
           printf("getModuleFileName: dlopen(0) failed\n");
        else
           {
            printf("getModuleFileName: dlopen(0) OK, info about obtained handle:\n");
            printModuleHandleDebugInfo( handle, "getModuleFileName" );
           }
        #endif
       }
    else
       {
        #ifdef DL_DEBUG
        printf("getModuleFileName: taken good module handle\n");
        #endif
        // see boost/tools/jam/src/boehm_gc/dyn_load.c
        //pAddr = dlsym(handle, "_DYNAMIC");
       }

    #ifdef DL_DEBUG
    printf("getModuleFileName: Try to get '_init' function ptr (Mod Handle: %p)\n", handle );
    #endif
    #ifdef DL_DEBUG
    printf("getModuleFileName: handle information\n" );
    printModuleHandleDebugInfo( handle, "getModuleFileName" );
    #endif

    pAddr = dlsym(handle, "_init"); // this works for test module
    if (!pAddr)
       {
        #ifdef DL_DEBUG
        printf("getModuleFileName: Get '_init' function failed, try to get '_fini' function ptr (Mod Handle: %p)\n", handle );
        #endif
        //printf("CP 2\n");
        pAddr = dlsym(handle, "_fini");
       }

    #ifdef DL_DEBUG
    printf("getModuleFileName: There is no '_init' or '_fini' functions in module\n" );
    #endif

    if (!pAddr && needFree)  // needFree signals that the name of main module requested
       {
        char buf[4096];
        int len = readlink("/proc/self/exe", buf, sizeof(buf)/sizeof(buf[0])-1);
        if (len>=0)
           {
            buf[len] = 0;
            ::dlclose(handle);
            //::std::basic_string<CharType, Traits, Allocator> res = MARTY_FILESYSTEM_NS fromOsFilename(::std::string(buf));
            ::std::basic_string<CharType, Traits, Allocator> res;
            MARTY_FILESYSTEM_NS fromOsFilename2(res, ::std::string(buf));
            if (res.empty())
                return ENOENT;
            retFileName.swap(res);
            return 0;
           }

        //printf("CP 3\n");
        // none of below calls works for main module, why?
        pAddr = dlsym(handle, "main");
        if (!pAddr)
           pAddr = dlsym(handle, "_main");
        if (!pAddr)
           pAddr = dlsym(handle, "start");
        if (!pAddr)
           pAddr = dlsym(handle, "_start");


        //// getModuleFileName modified to template fn, code below  not work in new version
        //if (!pAddr) // none of above calls are success for main module (handle=0)
        //   pAddr = (void*)getModuleFileName; // this is a work-around
       }

    if (!pAddr)
       {
        if (needFree)
           ::dlclose(handle);
        //printf("CP 4\n");
        return ENOENT; // invalid handle or other error
       }

    Dl_info info;
    int dladdRes = dladdr(pAddr, &info);

    if (needFree)
       ::dlclose(handle);

    if (!dladdRes || !info.dli_fname)
       {
        //printf("CP 5\n");
        return ENOENT;
       }

    //::std::basic_string<CharType, Traits, Allocator> res = MARTY_FILESYSTEM_NS fromOsFilename(info.dli_fname);
    ::std::basic_string<CharType, Traits, Allocator> res;
    MARTY_FILESYSTEM_NS fromOsFilename2(res, info.dli_fname);
    if (res.empty())
       {
        //printf("CP 6\n");
        return ENOENT;
       }
    retFileName.swap(res);
    //printf("CP 7\n");
    return 0;
    #endif
   }
*/

//-----------------------------------------------------------------------------
/*
inline
tstring getModuleFileName(ABSTRACT_MODULE_HANDLE handle)
   {
    tstring res;
    if (getModuleFileName(handle, res)) return tstring();
    return res;
   }
*/
//-----------------------------------------------------------------------------
typedef void (*function_pointer_t)();

/*
template<typename TypeTo, typename TypeFrom>
TypeTo union_cast(TypeFrom f)
{
    union dummy{ TypeFrom from; TypeTo to; }  u;
    u.from = f;
    return u.to;
}
*/


/* dont work in GCC 3.4 and older - template with only return template value couses duplicated synmbol */
/* inline
 * function_pointer_t rawGetProcAddress(ABSTRACT_MODULE_HANDLE handle, const char *procName)
 *    {
 *     #ifdef WIN32
 *     //return reinterpret_cast<void*>(::GetProcAddress(handle, procName));
 *     //return union_cast<function_pointer_t>(::GetProcAddress(handle, procName));
 *     return (function_pointer_t)::GetProcAddress(handle, procName);
 *     #else
 *     //return ::dlsym(handle, procName);
 *     //return union_cast<function_pointer_t>(::dlsym(handle, procName)); // union cast generates some other error messages
 *     return (function_pointer_t)::dlsym(handle, procName);
 *     #endif
 *    }
 *
 *
 * template<typename ProcTypeT>
 * ProcTypeT getProcAddress(ABSTRACT_MODULE_HANDLE handle, const char *procName)
 *    {
 *     return reinterpret_cast<ProcTypeT>(rawGetProcAddress(handle, procName));
 *    }
 */

//-----------------------------------------------------------------------------
// this works anywhere, but need explicit casting
// use reinterpret_cast<fn_type>(getProcAddress(handle, procName));
inline
function_pointer_t getProcAddress(ABSTRACT_MODULE_HANDLE handle, const char *procName)
   {
    #ifdef WIN32
    //return reinterpret_cast<void*>(::GetProcAddress(handle, procName));
    //return union_cast<function_pointer_t>(::GetProcAddress(handle, procName));
    return (function_pointer_t)::GetProcAddress(handle, procName);
    #else
    //return ::dlsym(handle, procName);
    //return union_cast<function_pointer_t>(::dlsym(handle, procName)); // union cast generates some other error messages
    return (function_pointer_t)::dlsym(handle, procName);
    #endif
   }



//#ifdef WIN32

#ifdef WIN32

inline
std::string formatSystemError(DWORD err)
   {
    char buf[1024];
    return std::string(MARTY_WINAPI_NS formatMessageA(err, buf, sizeof(buf)));
   }

inline
void formatSystemError(DWORD err, std::string &strFormatTo)
   {
    char buf[1024];
    strFormatTo = MARTY_WINAPI_NS formatMessageA(err, buf, sizeof(buf));
   }

inline
void formatSystemError(DWORD err, std::wstring &strFormatTo)
   {
    wchar_t buf[1024];
    strFormatTo = MARTY_WINAPI_NS formatMessageW(err, buf, sizeof(buf));
   }

#endif


class libapi_error : public std::runtime_error
{
        unsigned m_code;
    public:
        #ifdef WIN32
        libapi_error(DWORD err) : std::runtime_error(formatSystemError(err).c_str()), m_code(err) {}
        #endif
        //libapi_error(char *errMsg) : std::runtime_error(errMsg), m_code(EINVAL) {}
        libapi_error(const char *errMsg) : std::runtime_error(errMsg), m_code(EINVAL) {}
        libapi_error(unsigned c, const char *errMsg) : std::runtime_error(errMsg), m_code(c) {}

        // ~libapi_error() {}
        libapi_error(const libapi_error& le) : std::runtime_error(le), m_code(le.m_code) {}
        //libapi_error(const libapi_error& le) : std::runtime_error(le), code(le.code) {}

        unsigned code() const { return m_code; }
};


class CModuleHandle
{
        ABSTRACT_MODULE_HANDLE     handle;
        bool                       bFree;
        CModuleHandle& operator=(const CModuleHandle &mh) { return *this; }
        CModuleHandle(const CModuleHandle &mh) : handle(0), bFree(false) {}

    public:
        CModuleHandle() : handle(0), bFree(false)
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::CModuleHandle: default constructor\n" );
            #endif
           }

        CModuleHandle(ABSTRACT_MODULE_HANDLE h, bool bGetOwnersheep = false)
           : handle(h)
           , bFree(bGetOwnersheep)
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::CModuleHandle: handle constructor\n" );
            #endif
           }

    private:
        void modfree()
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::modfree: enter\n" );
            #endif

            if (handle && bFree)
               {
                #ifdef DL_DEBUG
                printf("CModuleHandle::modfree: need free, call freeModule\n" );
                #endif
                freeModule(handle);
               }
            #ifdef DL_DEBUG
            printf("CModuleHandle::modfree: clear members\n" );
            #endif
            handle = 0; bFree = false;
           }

    public:

        ~CModuleHandle()
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::~CModuleHandle: destroy modHandle\n" );
            #endif
            modfree();
           }

        ABSTRACT_MODULE_HANDLE get() const
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::get: return handle\n" );
            #endif
            return handle;
           }

        // return stored handle and replace it with 0 value
        // don't free prev module, this takes handle ownersheep to another routines/objects
        ABSTRACT_MODULE_HANDLE release()
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::release: releasing ownershop\n" );
            #endif
            ABSTRACT_MODULE_HANDLE res = handle;
            handle = 0;
            bFree = false;
            return res;
           }

        // replace stored handle with newly loaded (with auto free mode)
        // free previously stored handle if needed
        // return newly loaded module handle
        // throws an exception if load error occurs
        ABSTRACT_MODULE_HANDLE load(const TCHAR* modName)
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::load: name - %s\n", modName );
            #endif
            modfree();

            if (!modName)
               {
                #ifdef DL_DEBUG
                printf("CModuleHandle::load: name is null, throw error\n" );
                #endif
                throw libapi_error((const char*)"Error: CModuleHandle::load(modName==0)");
               }

            #ifdef WIN32
            handle = loadModule(tstring(modName));
            if (!handle)
               throw libapi_error(::GetLastError());
            #else

            #ifdef DL_DEBUG
            printf("CModuleHandle::load: clearing error state with dlerror()\n" );
            #endif
            dlerror(); // clear the error
            #ifdef DL_DEBUG
            printf("CModuleHandle::load: loading through loadModule()\n" );
            #endif
            handle = loadModule(tstring(modName));
            #ifdef DL_DEBUG
            printf("CModuleHandle::load: may be loaded\n" );
            #endif

            if (!handle)
               {
                #ifdef DL_DEBUG
                printf("CModuleHandle::load: NOT loaded\n" );
                #endif

                const char *err = dlerror();
                if (!err)
                   err = "loadModule failed, but no any error information given";
                //#ifdef ENOFILE
                //    throw libapi_error(ENOFILE, err);
                //#else
                #ifdef DL_DEBUG
                printf("CModuleHandle::load: throw error: %s\n", err );
                #endif

                    throw libapi_error(ENOENT, err);
                //#endif
               }
            #endif
            bFree = true;
            #ifdef DL_DEBUG
            printf("CModuleHandle::load: module loaded OK\n" );
            #endif
            return handle;
           }

        CModuleHandle(const TCHAR* modName)
           : handle(0), bFree(true)
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::CModuleHandle: constructor with module name\n" );
            #endif
            load(modName);
           }

        function_pointer_t getProcAddress(const char *procName) const
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::getProcAddress: using MARTY_LIBAPI::getProcAddress\n" );
            #endif
            return MARTY_LIBAPI::getProcAddress(handle, procName);
           }

        tstring getFileName() const
           {
            #ifdef DL_DEBUG
            printf("CModuleHandle::getFileName: using MARTY_LIBAPI::getModuleFileName\n" );
            #endif
            tstring name;
            int res = getModuleFileName(handle, name);
            if (res)
               {
                #ifdef WIN32
                throw libapi_error(res);
                #else
                #ifdef DL_DEBUG
                printf("CModuleHandle::getFileName: throw error\n" );
                #endif

                throw libapi_error(res, "function not supported by underlaying API");
                #endif
               }
            #ifdef DL_DEBUG
            printf("CModuleHandle::getFileName: Ok, returning\n" );
            #endif
            return name;
           }
};






END_MARTY_LIBAPI_NS



#endif /* MARTY_LIBAPI_H */

