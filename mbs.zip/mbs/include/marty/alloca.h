#ifndef MARTY_ALLOCA_H
#define MARTY_ALLOCA_H

/* add this lines to your scr
#ifndef MARTY_ALLOCA_H
    #include <marty/alloca.h>
#endif
*/

#ifdef _WIN32
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else
    #include <alloca.h>
    #ifndef _alloca
        #define _alloca  alloca
    #endif
#endif

#ifndef MARTY_AUTO_ALLOCA_ALLOCA_MAX
    #define MARTY_AUTO_ALLOCA_ALLOCA_MAX 16384
#endif


namespace marty
{


template< typename ArrayValueType>
class CAllocaAutoArray
{
    ArrayValueType     *pArray;
    bool                dontDelete;

private:

    void reset(ArrayValueType *pa = 0, bool dd = false )
    {
     if (!dontDelete) delete[] pArray;
     pArray = pa;
     dontDelete = dd;
    }

public:

    //ArrayValueType* release() { pArray = 0; }
    ArrayValueType* release() { ArrayValueType* tmp = pArray; pArray = 0; return tmp; }
    ArrayValueType* get() { return pArray; }
    const ArrayValueType* get() const { return pArray; }


    struct NewTag    { int dummy; NewTag() : dummy(0) {} };
    struct AllocaTag { int dummy; AllocaTag() : dummy(0) {} };

    CAllocaAutoArray( ArrayValueType *pa, const AllocaTag & ) : pArray(pa), dontDelete(true) {}
    CAllocaAutoArray( size_t numItems   , const NewTag    & ) : pArray(new ArrayValueType[numItems]), dontDelete(false) {}
    CAllocaAutoArray( ) : pArray(0), dontDelete(true) {}
    CAllocaAutoArray( const CAllocaAutoArray<ArrayValueType> &a ) : pArray(const_cast< CAllocaAutoArray<ArrayValueType>* >(&a)->release()), dontDelete(a.dontDelete) {} // pArray(a.release())

    ~CAllocaAutoArray() { if (!dontDelete) delete[] pArray; }

    CAllocaAutoArray<ArrayValueType>& operator=( const CAllocaAutoArray<ArrayValueType> &a )
    {
     if (this!=&a) reset( const_cast< CAllocaAutoArray<ArrayValueType>* >(&a)->release(), a.dontDelete ); // a.release()
     return *this;
    }

    operator ArrayValueType*() const { return pArray; }

private:

    //CAllocaAutoArray( const CAllocaAutoArray<ArrayValueType> &a );
    template < typename T > CAllocaAutoArray( T *pt );
    template < typename T > CAllocaAutoArray( const T *pt );
};



#define MARTY_AUTO_ALLOCA_VAR(type, name)                    ::marty::CAllocaAutoArray< type >  name


#define MARTY_AUTO_ALLOCA_ALLOC_IMPL_ALLOCA(type, size)      ::marty::CAllocaAutoArray< type >( (type*)_alloca((size)*sizeof(type)), ::marty::CAllocaAutoArray< type > :: AllocaTag() )

#define MARTY_AUTO_ALLOCA_ALLOC_IMPL_NEW(type, size)         ::marty::CAllocaAutoArray< type >( size , ::marty::CAllocaAutoArray< type > :: NewTag() )

#define MARTY_AUTO_ALLOCA_ALLOC(type,size)                   ( ( size > MARTY_AUTO_ALLOCA_ALLOCA_MAX )              \
                                                             ? ( MARTY_AUTO_ALLOCA_ALLOC_IMPL_NEW(type, size) )     \
                                                             : ( MARTY_AUTO_ALLOCA_ALLOC_IMPL_ALLOCA(type, size) )  \
                                                             )

#define MARTY_AUTO_ALLOCA(type,varname,size)                 MARTY_AUTO_ALLOCA_VAR(type, varname) = MARTY_AUTO_ALLOCA_ALLOC(type,size)

// MARTY_AUTO_ALLOCA_VAR(type, name) = MARTY_AUTO_ALLOCA(type,size);

}; // namespace marty



#endif /* MARTY_ALLOCA_H */

