#ifndef MARTY_TRIE_DOT_H
#define MARTY_TRIE_DOT_H

/* add this lines to your scr
#ifndef MARTY_TRIE_DOT_H
    #include <marty/trie_dot.h>
#endif
*/

#ifndef MARTY_TRIE_H
    #include <marty/trie.h>
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
    #include <sstream>
#endif



namespace marty
{
// Abstract data types
namespace adt
{


template <typename T>
struct trie_key_formatter
{
    void operator()( std::ostream &s, const T &t) const
       {
        s<<t;
       }
}; // trie_key_formatter, also used to format values


template <>
struct trie_key_formatter< std::wstring >
{
    void operator()( std::ostream &s, const std::wstring &t) const
       {
        s<<MARTY_UTF::toUtf8(t);
       }
};


struct CGraphVizDotSpec
{
    int dummy;
};

struct CGraphVizDotSpecRecord
{
    int dummy;
};


inline
std::string get_common_sep( std::size_t s)
{
    if (s>=256) return "8.0";
    if (s>=128) return "7.0";
    if (s>=64 ) return "6.0";
    if (s>=32 ) return "5.0";
    if (s>=16 ) return "4.0";
    if (s>=8  ) return "3.0";
    if (s>=4  ) return "2.0";
    return "1.0";
}

/*
inline
std::string get_common_sep( std::size_t s)
{
    if (s>=256) return "5.0";
    if (s>=128) return "4.0";
    if (s>=64 ) return "3.0";
    if (s>=32 ) return "2.0";
    if (s>=16 ) return "1.5";
    if (s>=8  ) return "1.0";
    if (s>=4  ) return "0.75";
    return "0.5";
}
*/

template<>
class trie_inspector<CGraphVizDotSpec>
{

public:

    std::string make_label_text( const std::string &s ) const
       {
        std::string res; 
        std::string::size_type i = 0, size = s.size();
        res.reserve(size);
   
        //res.append(1,'\"');
        for(;i!=size; ++i)
           {
            if (s[i]=='\"') res.append(1,'\\');
            res.append(1,s[i]);
           }
        //res.append(1,'\"');
        return res;
       }

    template<typename KeyType, typename KeyTypeFormatter>
    std::string format_key( const KeyType &k, const KeyTypeFormatter &f) const
       {
        std::ostringstream s;
        f(s,k);
        return make_label_text(s.str());
       }

    template<typename ValueType, typename ValueTypeFormatter>
    std::string format_value( const ValueType &v, const ValueTypeFormatter &f) const
       {
        std::ostringstream s;
        f(s,v);
        return make_label_text(s.str());
       }

    std::string make_node_id( size_t nodeIdx ) const
       {
        std::ostringstream s; s<<"n"<<nodeIdx;
        return s.str();
       }

    std::string make_value_id( size_t valIdx ) const
       {
        std::ostringstream s; s<<"v"<<valIdx;
        return s.str();
       }

    std::string make_node_item_id( size_t nodeIdx, size_t itemIdx ) const
       {
        std::ostringstream s; s<<nodeIdx<<"_"<<itemIdx;
        return s.str();
       }

    template < typename KeyType
             , typename ValueType
             , typename Traits
             , typename KeyTypeFormatter
             , typename ValueTypeFormatter
             >
    void makeDot( std::ostream &s
                , const trie<KeyType,ValueType,Traits> &t
                , const std::string &topName
                , const KeyTypeFormatter   &keyfmt
                , const ValueTypeFormatter &valfmt
                , bool printVals = false
                , bool reduceNodeSize = false
                ) const
       {
        using std::ostringstream;
        //typedef std::vector< mapped_type >                   values_holder;
        //values_holder                 values;
        //typedef std::vector< trie_node >                     trie_nodes_holder;

        typedef trie<KeyType,ValueType,Traits> trie_type;
        
        typename trie_type::trie_node_index nodeIdx = 0, nodesSize = t.trie_nodes.size();
        for(; nodeIdx != nodesSize; ++nodeIdx)
           {
            if (!t.trie_nodes[nodeIdx].keys_size()) continue;

            trie_type::trie_node_data_item_index itemIdx = 0, itemsSize = t.trie_nodes[nodeIdx].keys_size();
            s<<"    subgraph cluster_"<<make_node_id( nodeIdx )<<" {\n" // cluster_
               "        rank=same;\n"
               "        style=invis;\n"
               "        ranksep=\""<<get_common_sep(itemsSize)<<"\";\n"
               ;
            
            for(;itemIdx != itemsSize; ++itemIdx)
               {
                s<<"        \""<<make_node_item_id(nodeIdx,itemIdx)<<"\" [ label = \""<<format_key( t.trie_nodes[nodeIdx].data_items[itemIdx].key, keyfmt )<<"\" ];\n";
                if (printVals && t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx!=t.value_index_npos)
                   {
                    s<<"            \""<<make_value_id(t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx)<<"\" [ label = \""<<format_value( t.values[t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx], valfmt )<<"\", shape = \"box\", width=.01, height=.01 ];\n";
                    s<<"            \""<<make_node_item_id(nodeIdx,itemIdx)<<"\"->\""<<make_value_id(t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx)<<"\" [ dir = none, constraint = false ];\n";
                   }

               }

            /*
            if (printVals)
               {
                for(itemIdx = 0; itemIdx != itemsSize; ++itemIdx)
                   {
                    if (t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx!=t.value_index_npos)
                       {
                        s<<"        \""<<make_value_id(t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx)<<"\" [ label = \""<<format_value( t.values[t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx], valfmt )<<"\", shape = \"box\", width=.01, height=.01 ];\n";
                        s<<"        \""<<make_node_item_id(nodeIdx,itemIdx)<<"\"->\""<<make_value_id(t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx)<<"\" [ dir = none, constraint = false ];\n";
                       }
                   }
               }
            */
            s<<"    }\n";
           }

        trie_type::trie_node_data_item_index 
        itemIdx = 0, itemsSize = t.trie_nodes[0].keys_size();
        for(;itemIdx != itemsSize; ++itemIdx)
           {
            s<<"    \""<<make_label_text(topName)<<"\"->\""<<make_node_item_id(0,itemIdx)<<"\";\n";
           }

        //typename trie_type::trie_node_index 
        nodeIdx = 0, nodesSize = t.trie_nodes.size();
        for(; nodeIdx != nodesSize; ++nodeIdx)
           {
            if (!t.trie_nodes[nodeIdx].keys_size()) continue;
            trie_type::trie_node_data_item_index itemIdx = 0, itemsSize = t.trie_nodes[nodeIdx].keys_size();
            for(;itemIdx != itemsSize; ++itemIdx)
               {
                typename trie_type::trie_node_index childNodeIdx = t.trie_nodes[nodeIdx].data_items[itemIdx].child_idx;
                if (childNodeIdx==t.trie_node_index_npos) continue;
                trie_type::trie_node_data_item_index childItemIdx = 0, childItemsSize = t.trie_nodes[childNodeIdx].keys_size();
                for(; childItemIdx!=childItemsSize; ++childItemIdx)
                   {
                    s<<"    \""<<make_node_item_id(nodeIdx,itemIdx)<<"\"->\""<<make_node_item_id(childNodeIdx,childItemIdx)<<"\";\n";
                   }
               }
           }
       }

    template < typename KeyType
             , typename ValueType
             , typename Traits
             , typename KeyTypeFormatter
             , typename ValueTypeFormatter
             >
    void operator()( std::ostream &s
                   , const trie<KeyType,ValueType,Traits> &t
                   , const std::string &graphName
                   , const std::string &topName
                   , bool printVals = false
                   , bool reduceNodeSize = false
                   , bool bVerticalGraph = true
                   , unsigned dpi = 96
                   ) const
    {
     s<<"digraph \""<<make_label_text(graphName)<<"\" {\n";
     s<<"    graph [rankdir="<< (bVerticalGraph?"TB":"LR")<<" dpi="<<dpi<<"];\n"; // nodesep=0.2
     if (reduceNodeSize)
        s<<"    node [ width=.1, height=.1 ];\n";
 
     if (t.trie_nodes.empty() || !t.trie_nodes[0].keys_size())
        {
         s<<"\""<<make_label_text(topName)<<"\";\n";
        }
     else
        {
         makeDot( s, t, topName, KeyTypeFormatter(), ValueTypeFormatter(), printVals, reduceNodeSize );
        }


     s<<"\n}\n";
    }


};




template<>
class trie_inspector<CGraphVizDotSpecRecord>
{

public:

    std::string make_label_text( const std::string &s ) const
       {
        std::string res; 
        std::string::size_type i = 0, size = s.size();
        res.reserve(size);
   
        //res.append(1,'\"');
        for(;i!=size; ++i)
           {
            if (s[i]=='\"') res.append(1,'\\');
            res.append(1,s[i]);
           }
        //res.append(1,'\"');
        return res;
       }

    std::string make_record_label_text( const std::string &s ) const
       {
        std::string res; 
        std::string::size_type i = 0, size = s.size();
        res.reserve(size);
   
        for(;i!=size; ++i)
           {
            switch(s[i])
               {
                case '\"': res.append(1,'\\');
                         break;
                case '<': res.append(1,'\\');
                         break;
                case '>': res.append(1,'\\');
                         break;
                case '{': res.append(1,'\\');
                         break;
                case '}': res.append(1,'\\');
                         break;
                case '|': res.append(1,'\\');
                         break;
                case ' ': if (i==0 || i==size-1)
                             res.append(1,'\\');
                         break;
               }
            res.append(1,s[i]);
           }
        return res;
       }

    template<typename KeyType, typename KeyTypeFormatter>
    std::string make_key_string( const KeyType &k, const KeyTypeFormatter &f ) const
       {
        std::ostringstream s;
        f(s,k);
        return s.str();
       }

    template<typename ValueType, typename ValueTypeFormatter>
    std::string make_value_string( const ValueType &v, const ValueTypeFormatter &f ) const
       {
        std::ostringstream s;
        f(s,v);
        return s.str();
       }

    template<typename KeyType, typename KeyTypeFormatter>
    std::string format_key( const KeyType &k, const KeyTypeFormatter &f) const
       {
        std::ostringstream s;
        f(s,k);
        return make_label_text(s.str());
       }

    template<typename ValueType, typename ValueTypeFormatter>
    std::string format_value( const ValueType &v, const ValueTypeFormatter &f) const
       {
        std::ostringstream s;
        f(s,v);
        return make_label_text(s.str());
       }

    std::string make_node_id( size_t nodeIdx ) const
       {
        std::ostringstream s; s<<"n"<<nodeIdx;
        return s.str();
       }

    std::string make_value_id( size_t valIdx ) const
       {
        std::ostringstream s; s<<"v"<<valIdx;
        return s.str();
       }

    std::string make_node_item_id( size_t nodeIdx, size_t itemIdx ) const
       {
        std::ostringstream s; s<<nodeIdx<<"_"<<itemIdx;
        return s.str();
       }

    template < typename KeyType
             , typename ValueType
             , typename Traits
             , typename KeyTypeFormatter
             , typename ValueTypeFormatter
             >
    void makeDot( std::ostream &s
                , const trie<KeyType,ValueType,Traits> &t
                , const std::string &topName
                , const KeyTypeFormatter   &keyfmt
                , const ValueTypeFormatter &valfmt
                , bool printVals = false
                , bool reduceNodeSize = false
                ) const
       {
        using std::ostringstream;
        //typedef std::vector< mapped_type >                   values_holder;
        //values_holder                 values;
        //typedef std::vector< trie_node >                     trie_nodes_holder;

        typedef trie<KeyType,ValueType,Traits> trie_type;
        
        typename trie_type::trie_node_index nodeIdx = 0, nodesSize = t.trie_nodes.size();
        for(; nodeIdx != nodesSize; ++nodeIdx)
           {
            trie_type::trie_node_data_item_index itemIdx = 0, itemsSize = t.trie_nodes[nodeIdx].keys_size();
            if (!itemsSize) continue;

            cout<<"    "<<make_node_id( nodeIdx )<<" [shape=record,ranksep=\""<<get_common_sep(itemsSize)<<"\","
                  "label=\"";

            for(;itemIdx != itemsSize; ++itemIdx)
               {
                if (itemIdx) cout<<"|";
                if (printVals && t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx!=t.value_index_npos)
                   {
                    cout<<"{<"<<make_node_item_id(nodeIdx,itemIdx)<<"> "
                        <<make_record_label_text(make_key_string(t.trie_nodes[nodeIdx].data_items[itemIdx].key,keyfmt))
                        <<"|<"<<make_value_id(t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx)<<"> "
                        <<make_record_label_text(make_value_string(t.values[t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx],valfmt))
                        <<"}";
                   }
                else
                   {
                    cout<<"<"<<make_node_item_id(nodeIdx,itemIdx)<<"> "
                        <<make_record_label_text(make_key_string(t.trie_nodes[nodeIdx].data_items[itemIdx].key,keyfmt));
                   }
               }
            cout<<"\"];\n";
           }


        s<<"    \""<<make_label_text(topName)<<"\"->\""<<make_node_id( 0 )<<"\";\n";

        //typename trie_type::trie_node_index 
        nodeIdx = 0, nodesSize = t.trie_nodes.size();
        for(; nodeIdx != nodesSize; ++nodeIdx)
           {
            if (!t.trie_nodes[nodeIdx].keys_size()) continue;
            trie_type::trie_node_data_item_index itemIdx = 0, itemsSize = t.trie_nodes[nodeIdx].keys_size();
            for(;itemIdx != itemsSize; ++itemIdx)
               {
                typename trie_type::trie_node_index childNodeIdx = t.trie_nodes[nodeIdx].data_items[itemIdx].child_idx;
                if (childNodeIdx==t.trie_node_index_npos) continue;
                if (printVals && t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx!=t.value_index_npos)
                   {
                    s<<"    \""<<make_node_id(nodeIdx)<<"\":\""<<make_value_id(t.trie_nodes[nodeIdx].data_items[itemIdx].value_idx)<<"\"->\""<<make_node_id(childNodeIdx)<<"\";\n";
                   }
                else
                   {
                    s<<"    \""<<make_node_id(nodeIdx)<<"\":\""<<make_node_item_id(nodeIdx,itemIdx)<<"\"->\""<<make_node_id(childNodeIdx)<<"\";\n";
                   }
               }
           }
        /*
        */
       }

    template < typename KeyType
             , typename ValueType
             , typename Traits
             , typename KeyTypeFormatter
             , typename ValueTypeFormatter
             >
    void operator()( std::ostream &s
                   , const trie<KeyType,ValueType,Traits> &t
                   , const std::string &graphName
                   , const std::string &topName
                   , bool printVals = false
                   , bool reduceNodeSize = false
                   , bool bVerticalGraph = true
                   , unsigned dpi = 96
                   ) const
    {
     s<<"digraph \""<<make_label_text(graphName)<<"\" {\n";
     s<<"    graph [rankdir="<< (bVerticalGraph?"TB":"LR")<<" dpi="<<dpi<<"];\n"; // nodesep=0.2
     s<<"    node  [shape=record"; // nodesep=0.2
     if (reduceNodeSize)
        s<<"    ,width=.1,height=.1 ];\n";
     s<<"];\n"; // nodesep=0.2
 
     if (t.trie_nodes.empty() || !t.trie_nodes[0].keys_size())
        {
         s<<"\""<<make_label_text(topName)<<"\";\n";
        }
     else
        {
         makeDot( s, t, topName, KeyTypeFormatter(), ValueTypeFormatter(), printVals, reduceNodeSize );
        }


     s<<"\n}\n";
    }


};


//typedef trie_inspector<CGraphVizDotSpec> trie_to_graphviz_dot_script;














template < typename KeyType
         , typename ValueType
         , typename Traits
         , typename KeyTypeFormatter   = trie_key_formatter<KeyType>
         , typename ValueTypeFormatter = trie_key_formatter<ValueType>
         >
class graphviz_dot_script_generator_for_trie
{

public:

    graphviz_dot_script_generator_for_trie() {}

    void operator()( std::ostream &s
                   , const trie<KeyType,ValueType,Traits> &t
                   , const std::string &graphName
                   , const std::string &topName
                   , bool printVals = false
                   , bool reduceNodeSize = false
                   , bool bVerticalGraph = true
                   , unsigned dpi = 96
                   ) const
    {
     trie_inspector<CGraphVizDotSpec> tmp;
     tmp.operator()<KeyType, ValueType, Traits, KeyTypeFormatter, ValueTypeFormatter>( s, t, graphName, topName, printVals, reduceNodeSize, bVerticalGraph, dpi );
    }
};



template < typename KeyType
         , typename ValueType
         , typename Traits
         , typename KeyTypeFormatter   = trie_key_formatter<KeyType>
         , typename ValueTypeFormatter = trie_key_formatter<ValueType>
         >
class graphviz_dot_script_record_generator_for_trie
{

public:

    graphviz_dot_script_record_generator_for_trie() {}

    void operator()( std::ostream &s
                   , const trie<KeyType,ValueType,Traits> &t
                   , const std::string &graphName
                   , const std::string &topName
                   , bool printVals = false
                   , bool reduceNodeSize = false
                   , bool bVerticalGraph = true
                   , unsigned dpi = 96
                   ) const
    {
     trie_inspector<CGraphVizDotSpecRecord> tmp;
     tmp.operator()<KeyType, ValueType, Traits, KeyTypeFormatter, ValueTypeFormatter>( s, t, graphName, topName, printVals, reduceNodeSize, bVerticalGraph, dpi );
    }
};



}; // namespace adt
}; // namespace marty




#endif /* MARTY_TRIE_DOT_H */

