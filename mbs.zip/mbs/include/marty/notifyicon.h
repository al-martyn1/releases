/*
Use this snippet with WTL window
Include this header into window?dialog class definition

tstring must be defined as shown below

    #if defined(UNICODE) || defined(_UNICODE)
    typedef ::std::wstring  tstring;
    #else
    typedef ::std::string   tstring;
    #endif

*/

/*
BOOL NotifyIcon( DWORD dwMsg, PNOTIFYICONDATA lpdata )
BOOL ShowTrayIconBalloon( UINT iconId, DWORD dwFlags, BOOL noSound, std::basic_string<TCHAR> balloonTitle, std::basic_string<TCHAR> balloonText )
BOOL AddTrayIcon( UINT iconId, UINT iconResourceId, UINT callbackMsgId )
BOOL ModifyTrayIcon( UINT iconId, UINT iconResourceId, UINT callbackMsgId )
BOOL RemoveTrayIcon( UINT iconId )
BOOL SetTrayIconTooltip( int iconId, std::basic_string<TCHAR> tooltipText )
*/

/*
Shell_NotifyIcon function
    http://msdn.microsoft.com/en-us/library/windows/desktop/bb762159(v=vs.85).aspx
NOTIFYICONDATA structure
    http://msdn.microsoft.com/en-us/library/windows/desktop/bb773352(v=vs.85).aspx
*/


#ifdef MARTY_NOTIFYICON_FREE_FUNCTIONS
    #define MARTY_NOTIFYICON_CONST
#else
    #define MARTY_NOTIFYICON_CONST const /* class members (by default) */
#endif


BOOL NotifyIcon( DWORD dwMsg, PNOTIFYICONDATA lpdata ) MARTY_NOTIFYICON_CONST
{
    lpdata->cbSize = sizeof(*lpdata);
    lpdata->hWnd   = m_hWnd;
    return Shell_NotifyIcon( dwMsg, lpdata );
}

/*
NIIF_NONE (0x00000000)    0x00000000. No icon.
NIIF_INFO (0x00000001)    0x00000001. An information icon.
NIIF_WARNING (0x00000002) 0x00000002. A warning icon.
NIIF_ERROR (0x00000003)   0x00000003. An error icon.
NIIF_USER (0x00000004)    0x00000004. Windows XP SP2 and later.
                          Windows XP: Use the icon identified in hIcon as the notification balloon's title icon.
                          Windows Vista and later: Use the icon identified in hBalloonIcon as the notification balloon's title icon.
*/
BOOL ShowTrayIconBalloon( UINT iconId, DWORD dwFlags, BOOL noSound, std::basic_string<TCHAR> balloonTitle, std::basic_string<TCHAR> balloonText ) MARTY_NOTIFYICON_CONST
{
    NOTIFYICONDATA iconData = { 0 };
    iconData.uID = iconId;

    // NIIF_ERROR (0x00000003)
    dwFlags &= 0x00000003;
   
    #if defined(NIF_INFO)
        iconData.uFlags = NIF_INFO;
    #else
        iconData.uFlags = 0x00000010;
    #endif

    if (noSound)
       {
        #if defined(NIIF_NOSOUND)
            iconData.dwInfoFlags = dwFlags | NIIF_NOSOUND;
        #else
            iconData.dwInfoFlags = dwFlags | 0x00000010;
        #endif
       }
    else
       {
        iconData.dwInfoFlags = dwFlags;
       }

    //iconData.uTimeout = 5000;
    //iconData.uTimeout = 1000;
   
    SIZE_T titleMaxLen = sizeof(iconData.szInfoTitle)/sizeof(iconData.szInfoTitle[0])-1;
    SIZE_T textMaxLen  = sizeof(iconData.szInfo)     /sizeof(iconData.szInfo     [0])-1;
   
    if (balloonTitle.size()>titleMaxLen)  balloonTitle.erase(titleMaxLen, balloonTitle.npos);
    if (balloonText.size() >textMaxLen)   balloonText .erase(textMaxLen , balloonText.npos );
   
    lstrcpy( &iconData.szInfoTitle[0], balloonTitle.c_str() );
    lstrcpy( &iconData.szInfo     [0], balloonText.c_str() );
   
   
    return NotifyIcon( NIM_MODIFY, &iconData );
}

BOOL AddTrayIcon( UINT iconId, UINT iconResourceId, UINT callbackMsgId ) MARTY_NOTIFYICON_CONST
{
    HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(iconResourceId), 
        IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);

    NOTIFYICONDATA iconData;
    iconData.uID    = iconId;
    iconData.uFlags =  /* NIF_TIP | */ NIF_ICON|NIF_MESSAGE;
    iconData.uCallbackMessage = callbackMsgId;
    iconData.hIcon  = hIconSmall;
    return NotifyIcon( NIM_ADD, &iconData );
}

BOOL ModifyTrayIcon( UINT iconId, UINT iconResourceId, UINT callbackMsgId ) MARTY_NOTIFYICON_CONST
{
    HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(iconResourceId), 
        IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);

    NOTIFYICONDATA iconData;
    iconData.uID    = iconId;
    iconData.uFlags =  /* NIF_TIP | */ NIF_ICON|NIF_MESSAGE;
    iconData.uCallbackMessage = callbackMsgId;
    iconData.hIcon  = hIconSmall;
    return NotifyIcon( NIM_MODIFY , &iconData );
}

BOOL RemoveTrayIcon( UINT iconId ) MARTY_NOTIFYICON_CONST
{
    NOTIFYICONDATA iconData;
    iconData.uID    = iconId;
    iconData.uFlags = 0;
    return NotifyIcon( NIM_DELETE, &iconData );
}

BOOL SetTrayIconTooltip( int iconId, std::basic_string<TCHAR> tooltipText ) MARTY_NOTIFYICON_CONST
{
    NOTIFYICONDATA iconData;
    SIZE_T tooltipTextMax = sizeof(iconData.szTip)/sizeof(iconData.szTip[0])-1;
    if (tooltipText.size()>tooltipTextMax)  tooltipText.erase(tooltipTextMax, tooltipText.npos);

    iconData.uID    = iconId;
    iconData.uFlags = NIF_TIP;
    lstrcpy( &iconData.szTip[0], tooltipText.c_str() );
    return NotifyIcon( NIM_MODIFY, &iconData );
}

CMenuHandle LoadTrayContextMenu( CMenu &menu, UINT trayContextMenuResId, UINT popupMenuNo ) MARTY_NOTIFYICON_CONST
{
    SetForegroundWindow( m_hWnd );
    menu.LoadMenu(trayContextMenuResId);
    return menu.GetSubMenu(popupMenuNo);
}

POINT GetTrayIconMenuPos() MARTY_NOTIFYICON_CONST
{
    POINT mpos = { 0 };
    ::GetCursorPos( &mpos ); 
    return mpos;
}


#if(WINVER < 0x0601)

/*
 * Message filter info values (CHANGEFILTERSTRUCT.ExtStatus)
 */
#define MSGFLTINFO_NONE                         (0)
#define MSGFLTINFO_ALREADYALLOWED_FORWND        (1)
#define MSGFLTINFO_ALREADYDISALLOWED_FORWND     (2)
#define MSGFLTINFO_ALLOWED_HIGHER               (3)

typedef struct tagCHANGEFILTERSTRUCT {
    DWORD cbSize;
    DWORD ExtStatus;
} CHANGEFILTERSTRUCT, *PCHANGEFILTERSTRUCT;

/*
 * Message filter action values (action parameter to ChangeWindowMessageFilterEx)
 */
#define MSGFLT_RESET                            (0)
#define MSGFLT_ALLOW                            (1)
#define MSGFLT_DISALLOW                         (2)

WINUSERAPI
BOOL
WINAPI
ChangeWindowMessageFilterEx(
    __in HWND hwnd,                                         // Window
    __in UINT message,                                      // WM_ message
    __in DWORD action,                                      // Message filter action value
    __inout_opt PCHANGEFILTERSTRUCT pChangeFilterStruct);   // Optional

#endif /* WINVER < 0x0601 */


typedef BOOL (WINAPI *CHANGEWINDOWMESSAGEFILTEREX_PROC_T)( HWND hWnd, UINT message, DWORD action, PCHANGEFILTERSTRUCT pChangeFilterStruct );

BOOL ChangeWindowMessageFilterImpl( HWND hWnd, UINT message, DWORD action, PCHANGEFILTERSTRUCT pChangeFilterStruct = 0) MARTY_NOTIFYICON_CONST
{
    HMODULE hUser = ::GetModuleHandle( _T("User32.dll" ) );
    if (!hUser) return FALSE;

    CHANGEWINDOWMESSAGEFILTEREX_PROC_T ChangeWindowMessageFilterProc = (CHANGEWINDOWMESSAGEFILTEREX_PROC_T)GetProcAddress(hUser, "ChangeWindowMessageFilterEx");
    if (!ChangeWindowMessageFilterProc) return FALSE;

    return ChangeWindowMessageFilterProc( hWnd, message, action, pChangeFilterStruct );
}

