#if !defined(_DEBUG)
    #if defined(_MSC_VER) && !defined(_DEBUG)
        #pragma optimize( "", on ) /* reset optimization to the /O compiler parameter */
    #endif
#endif
