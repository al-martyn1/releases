/*
   Copyright (c) 2007-2014 Alex Martynov, amart at mail.ru
   This code can be used without any limitations.
   This code provided as is, use it on your own risk.
*/

#include <marty/ponce.h>
#ifdef MARTY_PRAGMA_ONCE_SUPPORTED
    #pragma once
#endif

#ifndef MARTY_WINHKCFG_H
#define MARTY_WINHKCFG_H

/* add this lines to your scr
#ifndef MARTY_WINHKCFG_H
    #include <marty/winhkcfg.h>
#endif
*/

#ifndef MARTY_WINAPI_H
    #include <marty/winapi.h>
#endif


// List of all registered hotkeys - http://www.wasm.ru/wault/article/show/gui_subsystem
// See also - http://forum.sysinternals.com/registerhotkey-list_topic18909_page1.html

namespace marty {
namespace winapi
{

/*

hkStrip

    unsigned hkStrip;
       , hkStrip(0)

    void saveToKey( HKEY hKey ) const
       {
        win32RegSetValue( hKey, _T("Strip HotKey")          , hkStrip                         );
        ...

    void loadFromKey( HKEY hKey )
       {
         hkStrip      = (int)win32RegGetValue( hKey, _T("Strip HotKey")          , 0                  );
         ...


    void RegisterStripHotkey()
    {
        //if (settings.hk)
        RegisterStripHotkey(CLSTRIPPER_HOTKEY_ID               , settings.hkStrip);
        RegisterStripHotkey(CLSTRIPPER_AUTOSTRIP_MODE_HOTKEY_ID, settings.hkAutostrip);
    }


    void updateControlsState()
    {
    ...
     DoDataExchange( DDX_LOAD );

     //int res = 
     :: SendDlgItemMessage(m_hWnd, IDC_STRIP_HOTKEY         , HKM_SETHOTKEY, (WPARAM)settings.hkStrip, 0 );
     ...

*/

struct CHotKeyConfig{
    unsigned      hk;
    int           hkEnabled;
    int           registerId;

    typedef TCHAR CharType;
    ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > hkName;
    ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > hkEnabledName;

    CHotKeyConfig( const ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > &hkn
                 , const ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > &hken
                 , int rId
                 , unsigned p_hk = 0, int hke = 0
                 ) : hk(p_hk), hkEnabled(hke), registerId(rId), hkName(hkn), hkEnabledName(hken) {}

    template<typename CharType>
    static
    ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> >
    strRawConvert( const std::string &str)
    {
        ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > strRes;
        std::string::size_type i = 0, size = str.size();
        for(; i!=size; ++i)
           {
            strRes.append(1, (CharType)str[i]);
           }
        return strRes;
    }

    template<typename CharType>
    static
    ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> >
    appendHotkeyTitleStrHelper( ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > &hkStr, const std::string &strAppend)
    {
        if (hkStr.empty() && strAppend.empty()) return hkStr;
        //if (strAppend.empty()) return hkStr; // nothing to append
        if (!hkStr.empty())
           {
            //hkStr.append( strRawConvert(" + "));
            hkStr.append( strRawConvert<CharType>(" + "));
            hkStr.append( strRawConvert<CharType>(strAppend));
           }
        else
           {
            hkStr.assign( strRawConvert<CharType>(strAppend));
           }
        return hkStr;
    }

    template<typename CharType>
    static
    ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> >
    getHotkeyTitle(UINT mods, UINT vk)
    {
        ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > resStr;

        // Ctrl + Shift + Alt + X
        if (mods&HOTKEYF_CONTROL) appendHotkeyTitleStrHelper(resStr, std::string("Ctrl"));
        if (mods&HOTKEYF_SHIFT  ) appendHotkeyTitleStrHelper(resStr, std::string("Shift"));
        if (mods&HOTKEYF_ALT    ) appendHotkeyTitleStrHelper(resStr, std::string("Alt"));
        if (vk==0) return appendHotkeyTitleStrHelper(resStr, std::string());
        if (vk>='A' && vk<='Z') return appendHotkeyTitleStrHelper(resStr, std::string(1, (char)vk));
        if (vk>='0' && vk<='9') return appendHotkeyTitleStrHelper(resStr, std::string(1, (char)vk));
        switch(vk)
           {
            //case '-'           :  return appendHotkeyTitleStrHelper(resStr, std::string("-"));
            //case '='           :  return appendHotkeyTitleStrHelper(resStr, std::string("="));
            case VK_BACK       :  return appendHotkeyTitleStrHelper(resStr, std::string("Back"));
            case VK_TAB        :  return appendHotkeyTitleStrHelper(resStr, std::string("Tab"));
            case VK_CLEAR      :  return appendHotkeyTitleStrHelper(resStr, std::string("Clear"));
            case VK_RETURN     :  return appendHotkeyTitleStrHelper(resStr, std::string("Enter"));
            case VK_PAUSE      :  return appendHotkeyTitleStrHelper(resStr, std::string("Pause"));
            case VK_CAPITAL    :  return appendHotkeyTitleStrHelper(resStr, std::string("Capital"));
            case VK_ESCAPE     :  return appendHotkeyTitleStrHelper(resStr, std::string("Esc"));
            case VK_SPACE      :  return appendHotkeyTitleStrHelper(resStr, std::string("Space"));
            case VK_PRIOR      :  return appendHotkeyTitleStrHelper(resStr, std::string("Prior"));
            case VK_NEXT       :  return appendHotkeyTitleStrHelper(resStr, std::string("Next"));
            case VK_END        :  return appendHotkeyTitleStrHelper(resStr, std::string("End"));
            case VK_HOME       :  return appendHotkeyTitleStrHelper(resStr, std::string("Home"));
            case VK_LEFT       :  return appendHotkeyTitleStrHelper(resStr, std::string("Left"));
            case VK_UP         :  return appendHotkeyTitleStrHelper(resStr, std::string("Up"));
            case VK_RIGHT      :  return appendHotkeyTitleStrHelper(resStr, std::string("Right"));
            case VK_DOWN       :  return appendHotkeyTitleStrHelper(resStr, std::string("Down"));
            case VK_SELECT     :  return appendHotkeyTitleStrHelper(resStr, std::string("Select"));
            case VK_PRINT      :  return appendHotkeyTitleStrHelper(resStr, std::string("Print"));
            case VK_EXECUTE    :  return appendHotkeyTitleStrHelper(resStr, std::string("Execute"));
            case VK_SNAPSHOT   :  return appendHotkeyTitleStrHelper(resStr, std::string("Snapshot"));
            case VK_INSERT     :  return appendHotkeyTitleStrHelper(resStr, std::string("Ins"));
            case VK_DELETE     :  return appendHotkeyTitleStrHelper(resStr, std::string("Del"));
            case VK_HELP       :  return appendHotkeyTitleStrHelper(resStr, std::string("Help"));
            case VK_LWIN       :  return appendHotkeyTitleStrHelper(resStr, std::string("LWin"));
            case VK_RWIN       :  return appendHotkeyTitleStrHelper(resStr, std::string("RWin"));
            case VK_APPS       :  return appendHotkeyTitleStrHelper(resStr, std::string("Apps"));
            case VK_SLEEP      :  return appendHotkeyTitleStrHelper(resStr, std::string("Sleep"));
            case VK_NUMPAD0    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 1"));
            case VK_NUMPAD1    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 2"));
            case VK_NUMPAD2    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 3"));
            case VK_NUMPAD3    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 4"));
            case VK_NUMPAD4    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 5"));
            case VK_NUMPAD5    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 6"));
            case VK_NUMPAD6    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 7"));
            case VK_NUMPAD7    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 8"));
            case VK_NUMPAD8    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 9"));
            case VK_NUMPAD9    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num 0"));
            case VK_MULTIPLY   :  return appendHotkeyTitleStrHelper(resStr, std::string("Num *"));
            case VK_ADD        :  return appendHotkeyTitleStrHelper(resStr, std::string("Num +"));
            case VK_SEPARATOR  :  return appendHotkeyTitleStrHelper(resStr, std::string("Separator"));
            case VK_SUBTRACT   :  return appendHotkeyTitleStrHelper(resStr, std::string("Num -"));
            case VK_DECIMAL    :  return appendHotkeyTitleStrHelper(resStr, std::string("Num ."));
            case VK_DIVIDE     :  return appendHotkeyTitleStrHelper(resStr, std::string("Num /"));
            case VK_F1         :  return appendHotkeyTitleStrHelper(resStr, std::string("F1"));
            case VK_F2         :  return appendHotkeyTitleStrHelper(resStr, std::string("F2"));
            case VK_F3         :  return appendHotkeyTitleStrHelper(resStr, std::string("F3"));
            case VK_F4         :  return appendHotkeyTitleStrHelper(resStr, std::string("F4"));
            case VK_F5         :  return appendHotkeyTitleStrHelper(resStr, std::string("F5"));
            case VK_F6         :  return appendHotkeyTitleStrHelper(resStr, std::string("F6"));
            case VK_F7         :  return appendHotkeyTitleStrHelper(resStr, std::string("F7"));
            case VK_F8         :  return appendHotkeyTitleStrHelper(resStr, std::string("F8"));
            case VK_F9         :  return appendHotkeyTitleStrHelper(resStr, std::string("F9"));
            case VK_F10        :  return appendHotkeyTitleStrHelper(resStr, std::string("F10"));
            case VK_F11        :  return appendHotkeyTitleStrHelper(resStr, std::string("F11"));
            case VK_F12        :  return appendHotkeyTitleStrHelper(resStr, std::string("F12"));
            case VK_F13        :  return appendHotkeyTitleStrHelper(resStr, std::string("F13"));
            case VK_F14        :  return appendHotkeyTitleStrHelper(resStr, std::string("F14"));
            case VK_F15        :  return appendHotkeyTitleStrHelper(resStr, std::string("F15"));
            case VK_F16        :  return appendHotkeyTitleStrHelper(resStr, std::string("F16"));
            case VK_F17        :  return appendHotkeyTitleStrHelper(resStr, std::string("F17"));
            case VK_F18        :  return appendHotkeyTitleStrHelper(resStr, std::string("F18"));
            case VK_F19        :  return appendHotkeyTitleStrHelper(resStr, std::string("F19"));
            case VK_F20        :  return appendHotkeyTitleStrHelper(resStr, std::string("F20"));
            case VK_F21        :  return appendHotkeyTitleStrHelper(resStr, std::string("F21"));
            case VK_F22        :  return appendHotkeyTitleStrHelper(resStr, std::string("F22"));
            case VK_F23        :  return appendHotkeyTitleStrHelper(resStr, std::string("F23"));
            case VK_F24        :  return appendHotkeyTitleStrHelper(resStr, std::string("F24"));
            case VK_NUMLOCK    :  return appendHotkeyTitleStrHelper(resStr, std::string("NumLock"));
            case VK_SCROLL     :  return appendHotkeyTitleStrHelper(resStr, std::string("ScrollLock"));
            case VK_LSHIFT     :  return appendHotkeyTitleStrHelper(resStr, std::string("LShift"));
            case VK_RSHIFT     :  return appendHotkeyTitleStrHelper(resStr, std::string("RShift"));
            case VK_LCONTROL   :  return appendHotkeyTitleStrHelper(resStr, std::string("LCtrl"));
            case VK_RCONTROL   :  return appendHotkeyTitleStrHelper(resStr, std::string("RCtrl"));
            case VK_LMENU      :  return appendHotkeyTitleStrHelper(resStr, std::string("LMenu"));
            case VK_RMENU      :  return appendHotkeyTitleStrHelper(resStr, std::string("RMenu"));
            case VK_OEM_1      :  return appendHotkeyTitleStrHelper(resStr, std::string(";"));
            case VK_OEM_PLUS   :  return appendHotkeyTitleStrHelper(resStr, std::string("="));
            case VK_OEM_COMMA  :  return appendHotkeyTitleStrHelper(resStr, std::string(","));
            case VK_OEM_MINUS  :  return appendHotkeyTitleStrHelper(resStr, std::string("-"));
            case VK_OEM_PERIOD :  return appendHotkeyTitleStrHelper(resStr, std::string("."));
            case VK_OEM_2      :  return appendHotkeyTitleStrHelper(resStr, std::string("/"));
            case VK_OEM_3      :  return appendHotkeyTitleStrHelper(resStr, std::string("`"));
            case VK_OEM_4      :  return appendHotkeyTitleStrHelper(resStr, std::string("["));
            case VK_OEM_5      :  return appendHotkeyTitleStrHelper(resStr, std::string("\\"));
            case VK_OEM_6      :  return appendHotkeyTitleStrHelper(resStr, std::string("]"));
            case VK_OEM_7      :  return appendHotkeyTitleStrHelper(resStr, std::string("\'"));
            case VK_OEM_8      :  return appendHotkeyTitleStrHelper(resStr, std::string("OEM8"));
            //case           :  return appendHotkeyTitleStrHelper(resStr, std::string(""));

            default: return appendHotkeyTitleStrHelper(resStr, "Unknown");
           }

        //if (vk>='a' && vk<='z') return appendHotkeyTitleStrHelper(resStr, std::string(1, (char)vk));
        //return appendHotkeyTitleStrHelper(resStr, "Unk");


        //if (mods&HOTKEYF_EXT    ) fsModifiers |= ;
        //if (mods&) fsModifiers |= ;

        /* MOD_ALT Either ALT key must be held down. 
         * MOD_CONTROL Either CTRL key must be held down. 
         * MOD_KEYUP Both key up events and key down events generate a WM_HOTKEY message.  
         * MOD_SHIFT Either SHIFT key must be held down. 
         * MOD_WIN 
         */

/*
    #define MOD_ALT         0x0001
    #define MOD_CONTROL     0x0002
    #define MOD_SHIFT       0x0004
    #define MOD_WIN         0x0008
*/    
    }


    template<typename CharType>
    ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> >
    getHotkeyTitle() const
    {
        ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > resStr;
        if (!hk) return resStr;

        // split hotkey vk/modifiers
        WORD wvk = LOWORD(hk);

        BYTE vk   = LOBYTE(wvk);
        BYTE mods = HIBYTE(wvk);
        return getHotkeyTitle<CharType>(mods, vk);
    }


    template<typename CharType>
    void saveToKey( HKEY hKey
                  , const ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > &hkn 
                  , const ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > &hken 
                  ) const
    {
        using namespace MARTY_WINAPI::registry;
        setValue( hKey, hkn , hk );
        setValue( hKey, hken, Cast2Bool(hkEnabled) );
    }

    void saveToKey( HKEY hKey ) const
    {
        saveToKey( hKey, hkName, hkEnabledName );
    }

    template<typename CharType>
    void loadFromKey( HKEY hKey
                  , const ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > &hkn
                  , const ::std::basic_string<CharType, ::std::char_traits<CharType>, ::std::allocator<CharType> > &hken
                  )
    {
        using namespace MARTY_WINAPI::registry;
        hk         =      getValue( hKey, hkn , hk );
        hkEnabled  = (int)getValue( hKey, hken, Cast2Bool(hkEnabled) );
    }

    void loadFromKey( HKEY hKey )
    {
        loadFromKey( hKey, hkName, hkEnabledName );
    }

    static void RegisterHotkeyHelper(HWND hwndRegisterFor, int keyId, int hkey)
    {
        // hkey is in format of "Hotkey" control
        if (!hkey) return; // nothing to register

        // split hotkey vk/modifiers
        WORD wvk = LOWORD(hkey);

        BYTE vk   = LOBYTE(wvk);
        BYTE mods = HIBYTE(wvk);

        UINT fsModifiers = 0;
        if (mods&HOTKEYF_ALT    ) fsModifiers |= MOD_ALT;
        if (mods&HOTKEYF_CONTROL) fsModifiers |= MOD_CONTROL;
        //if (mods&HOTKEYF_EXT    ) fsModifiers |= ;
        if (mods&HOTKEYF_SHIFT  ) fsModifiers |= MOD_SHIFT;
        //if (mods&) fsModifiers |= ;

        /* MOD_ALT Either ALT key must be held down. 
         * MOD_CONTROL Either CTRL key must be held down. 
         * MOD_KEYUP Both key up events and key down events generate a WM_HOTKEY message.  
         * MOD_SHIFT Either SHIFT key must be held down. 
         * MOD_WIN 
         */
        ::RegisterHotKey( hwndRegisterFor, keyId, fsModifiers, vk );
    }


    void registerHotkey( HWND hwndRegisterFor ) const
    {
        if (!hkEnabled) return;
        if (hk==0)      return;
        RegisterHotkeyHelper( hwndRegisterFor, registerId, hk );
    }

    void unregisterHotkey( HWND hwndRegisterFor ) const
    {
        ::UnregisterHotKey( hwndRegisterFor, registerId );
    }

    /*

    #define MOD_ALT         0x0001
    #define MOD_CONTROL     0x0002
    #define MOD_SHIFT       0x0004
    #define MOD_WIN         0x0008


    #define IDHOT_SNAPWINDOW        (-1)    // SHIFT-PRINTSCRN
    #define IDHOT_SNAPDESKTOP       (-2)    // PRINTSCRN

    MSG_WM_HOTKEY(OnHotKey)

    void OnHotKey(int nHotKeyID, UINT uModifiers, UINT uVirtKey)
        {
         SetMsgHandled(FALSE);
         switch(nHotKeyID)
            {
             case IDHOT_SNAPDESKTOP:
                     break;
             case IDHOT_SNAPWINDOW:
                     break;
            }
        }
    
    */


}; // CHotKeyConfig


}; // namespace winapi
}; // namespace marty



#endif /* MARTY_WINHKCFG_H */

