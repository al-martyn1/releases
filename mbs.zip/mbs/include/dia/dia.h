#ifndef DIA_DIA_H
#define DIA_DIA_H

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_INC_ERRNO) && !defined(_ERRNO_H_) && !defined(_ERRNO_H)
    #include <errno.h>
#endif

#if defined(DIA_USE_OLD_SIXML)
    #include <sixml/sixmlx.h>
    #include <sixml/serializ.h>
#else
    #include <cli/xml/sixml/pugixml/serializer.h>
    #ifndef CLI_MISC_READUTILS_H
        #include <cli/misc/readutils.h>
    #endif
    
    #ifndef CLI_MISC_WRITEUTILS_H
        #include <cli/misc/writeutils.h>
    #endif
#endif


namespace dia
{

// <dia:composite type="grid">
// <dia:attribute name="width_x">

#ifndef DIA_TSTRING_DEFINED
#define DIA_TSTRING_DEFINED
typedef ::std::basic_string< TCHAR > tstring;
#endif


//-----------------------------------------------------------------------------
template <typename T>
struct CDiaAttrValBase
{
    T val;
    CDiaAttrValBase() : val() {}
    CDiaAttrValBase(const T &t) : val(t) {}
    CDiaAttrValBase(const CDiaAttrValBase &dab) : val(dab.val) {}
    CDiaAttrValBase& operator=(const CDiaAttrValBase &dab)
       {
        val = dab.val;
        return *this;
       }

    operator T()
       {
        return val;
       }
};

//-----------------------------------------------------------------------------
struct CAttrValBool : public CDiaAttrValBase<bool>
{
    CAttrValBool() : CDiaAttrValBase() {}
    CAttrValBool(const bool &v) : CDiaAttrValBase(v) {}

    STRUCT_LAYOUT_DEFAULT(CAttrValBool)
            attribute(_T("val")              , &CDiaAttrValBase<bool>::val   , false);
    END_STRUCT_LAYOUT()
};

struct CDiaBoolAttr
{
    std::string                         name;
    CAttrValBool                        val;

//    CDiaBoolAttr() : val() {}
//    CDiaBoolAttr(const T &t) : val(t) {}


    STRUCT_LAYOUT_DEFAULT(CDiaBoolAttr)
            attribute(_T("name")      , &CDiaBoolAttr::name   , tstring(_T("")));
            complex(_T("dia:boolean") , &CDiaBoolAttr::val    , CAttrValBool());
    END_STRUCT_LAYOUT()
};

//-----------------------------------------------------------------------------
struct CAttrValInt : public CDiaAttrValBase<int>
{
    CAttrValInt() : CDiaAttrValBase() {}
    CAttrValInt(const int &v) : CDiaAttrValBase(v) {}

    STRUCT_LAYOUT_DEFAULT(CAttrValInt)
            attribute(_T("val")    , &CDiaAttrValBase<int>::val   , int(0));
    END_STRUCT_LAYOUT()
};

struct CDiaIntAttr
{
    std::string                         name;
    CAttrValInt                         val;

    STRUCT_LAYOUT_DEFAULT(CDiaIntAttr)
            attribute(_T("name")   , &CDiaIntAttr::name   , tstring(_T("")));
            complex(_T("dia:int")  , &CDiaIntAttr::val    , CAttrValInt());
    END_STRUCT_LAYOUT()
};

//-----------------------------------------------------------------------------
struct CAttrValEnum : public CDiaAttrValBase<int>
{
    CAttrValEnum() : CDiaAttrValBase() {}
    CAttrValEnum(const int &v) : CDiaAttrValBase(v) {}

    STRUCT_LAYOUT_DEFAULT(CAttrValEnum)
            attribute(_T("val")    , &CDiaAttrValBase<int>::val   , int(0));
    END_STRUCT_LAYOUT()
};

struct CDiaEnumAttr
{
    std::string                         name;
    CAttrValEnum                        val;

    STRUCT_LAYOUT_DEFAULT(CDiaEnumAttr)
            attribute(_T("name")   , &CDiaEnumAttr::name   , tstring(_T("")));
            complex(_T("dia:enum") , &CDiaEnumAttr::val    , CAttrValEnum());
    END_STRUCT_LAYOUT()
};

//-----------------------------------------------------------------------------
struct CAttrValReal : public CDiaAttrValBase<double>
{
    CAttrValReal() : CDiaAttrValBase() {}
    CAttrValReal(const double &v) : CDiaAttrValBase(v) {}

    STRUCT_LAYOUT_DEFAULT(CAttrValReal)
            attribute(_T("val")              , &CDiaAttrValBase<double>::val   , double(0.0));
    END_STRUCT_LAYOUT()
};

struct CDiaRealAttr
{
    std::string                         name;
    CAttrValReal                        val;

    STRUCT_LAYOUT_DEFAULT(CDiaRealAttr)
            attribute(_T("name")              , &CDiaRealAttr::name   , tstring(_T("")));
            complex(_T("dia:real")            , &CDiaRealAttr::val    , CAttrValReal());
    END_STRUCT_LAYOUT()
};

//-----------------------------------------------------------------------------
struct CAttrValString : public CDiaAttrValBase<tstring>
{
    CAttrValString() : CDiaAttrValBase() {}
    CAttrValString(const tstring &v) : CDiaAttrValBase(v) {}

    operator std::string()
       {
        return val;
       }

    STRUCT_LAYOUT_DEFAULT(CAttrValString)
            attribute(_T("val")              , &CDiaAttrValBase<tstring>::val   , tstring());
    END_STRUCT_LAYOUT()
};

struct CDiaStringAttr
{
    std::string                         name;
    std::string                         val;

    //CAttrValString                      val;
    //simple(tchar* name, PrimFieldType StructType::* ofset, PrimFieldType def)

    STRUCT_LAYOUT_DEFAULT(CDiaStringAttr)
            attribute(_T("name")              , &CDiaStringAttr::name   , tstring(_T("")));
            //complex(_T("dia:string")          , &CDiaStringAttr::val    , CAttrValString());
            simple(0                          , &CDiaStringAttr::val    , tstring(_T("")));
    END_STRUCT_LAYOUT()
};


struct CDiaAttr;

struct CDiaComposite
{
    std::string            type;
    std::vector<CDiaAttr>  attrs;

    const CDiaAttr* findAttr(const tstring& attrName) const;

    CDiaComposite() : type(), attrs() {}
    CDiaComposite(const std::string &t) : type(t), attrs() {}

    void addAttr(const CDiaAttr &attr) { attrs.push_back(attr); }

    STRUCT_LAYOUT_DEFAULT(CDiaComposite)
            attribute(_T("type") , &CDiaComposite::type  , tstring(_T("")));
            array(0              , &CDiaComposite::attrs , _T("dia:attribute"));
    END_STRUCT_LAYOUT()
};



struct CDiaAttr
{
    //std::
    tstring                             name;
    CAttrValBool                        boolVal  ;
    CAttrValInt                         intVal   ;
    CAttrValEnum                        enumVal  ;
    CAttrValReal                        realVal  ;
    //CAttrValString                      stringVal;
    std::string                         stringVal;
    std::vector<CDiaComposite>          composite;

    CDiaAttr() 
       : name() 
       , boolVal()  
       , intVal()   
       , enumVal()   
       , realVal()  
       , stringVal()
       , composite()
       {}

    CDiaAttr(const std::string &n) 
       : name(n) 
       , boolVal()  
       , intVal()   
       , enumVal()
       , realVal()  
       , stringVal()
       , composite()
       {
        composite.push_back(CDiaComposite(n));
       }

    CDiaAttr(const std::string &n, const tstring &v) 
       : name(n) 
       , boolVal()  
       , intVal()   
       , enumVal()
       , realVal()  
       , stringVal(v)
       , composite()
       {}

    CDiaAttr(const std::string &n, int v) 
       : name(n) 
       , boolVal()  
       , intVal(v)   
       , enumVal()
       , realVal()  
       , stringVal()
       , composite()
       {}

    CDiaAttr(const std::string &n, int v, int dummyUseEnum)
       : name(n) 
       , boolVal()  
       , intVal()   
       , enumVal(v)
       , realVal()  
       , stringVal()
       , composite()
       {}

    CDiaAttr(const std::string &n, double v) 
       : name(n) 
       , boolVal()  
       , intVal()   
       , enumVal()
       , realVal(v)  
       , stringVal()
       , composite()
       {}

    CDiaAttr(const std::string &n, bool v) 
       : name(n) 
       , boolVal(v)  
       , intVal()   
       , enumVal()
       , realVal()  
       , stringVal()
       , composite()
       {}

    void addCompositeAttr(const CDiaAttr &attr)
       { 
        CDiaComposite c;
        c.addAttr(attr);

        composite.push_back(c);
       }
    /*
    void addAttr(const CDiaAttr &attr)
       { 
        composite.addAttr(attr); 
       }
    */

    STRUCT_LAYOUT_DEFAULT(CDiaAttr)
            attribute(_T("name")              , &CDiaAttr::name   , tstring(_T("")));

            complex(_T("dia:boolean") , &CDiaAttr::boolVal    , CAttrValBool());
            complex(_T("dia:int")     , &CDiaAttr::intVal     , CAttrValInt());
            complex(_T("dia:enum")    , &CDiaAttr::enumVal    , CAttrValEnum());
            complex(_T("dia:real")    , &CDiaAttr::realVal    , CAttrValReal());
            //complex(_T("dia:string")  , &CDiaAttr::stringVal  , CAttrValString());
            simple(_T("dia:string")   , &CDiaAttr::stringVal    , tstring(_T("")));
            //complex(_T("dia:composite")   , &CDiaAttr::composite  , CDiaComposite());            
            array(0                   , &CDiaAttr::composite  , _T("dia:composite"));
    END_STRUCT_LAYOUT()
};


inline
const CDiaAttr* CDiaComposite::findAttr(const tstring& attrName) const
   {
    std::vector<CDiaAttr>::const_iterator it = attrs.begin();
    for(; it!=attrs.end(); ++it)
       {
        if (it->name==attrName) return &(*it);
       }
    return 0;
   }




struct CDiaConnection
{
    std::string     handle;
    std::string     to;
    std::string     connection;

    STRUCT_LAYOUT_DEFAULT(CDiaConnection)
            attribute(_T("handle")      , &CDiaConnection::handle     , tstring(_T("")));
            attribute(_T("to")          , &CDiaConnection::to         , tstring(_T("")));
            attribute(_T("connection")  , &CDiaConnection::connection , tstring(_T("")));
    END_STRUCT_LAYOUT()

};



/*
<dia:real val="1"/>
<dia:int val="1"/>

        <dia:attribute name="visible_x">
          <dia:int val="1"/>
        </dia:attribute>

    <dia:object type="UML - State Term" version="0" id="O0">
      <dia:attribute name="is_final">
        <dia:boolean val="true"/>
      </dia:attribute>
      <dia:attribute name="obj_pos">
        <dia:point val="7.5,4.5"/>
      </dia:attribute>

    <dia:object type="UML - Transition" version="2" id="O1">
      <dia:attribute name="trigger">
        <dia:string>#first_trigger#</dia:string>
      </dia:attribute>
      <dia:attribute name="action">
        <dia:string>#first_action#</dia:string>
      </dia:attribute>
      <dia:attribute name="guard">
        <dia:string>#first_saver#</dia:string>
      </dia:attribute>
      <dia:connections>
        <dia:connection handle="0" to="O0" connection="6"/>
        <dia:connection handle="1" to="O4" connection="1"/>
      </dia:connections>

    <dia:object type="UML - State" version="0" id="O4">
      <dia:attribute name="text">
        <dia:composite type="text">
          <dia:attribute name="string">
            <dia:string>#STATE1#</dia:string>
          </dia:attribute>
          <dia:attribute name="font">
            <dia:font family="sans" style="0" name="Helvetica"/>
          </dia:attribute>
          <dia:attribute name="height">
            <dia:real val="0.80000000000000004"/>
          </dia:attribute>
          <dia:attribute name="pos">
            <dia:point val="6.2,12.6775"/>
          </dia:attribute>
          <dia:attribute name="color">
            <dia:color val="#000000"/>
          </dia:attribute>
          <dia:attribute name="alignment">
            <dia:enum val="1"/>
          </dia:attribute>
        </dia:composite>
      </dia:attribute>

      <dia:attribute name="entry_action">
        <dia:string>#pre_event#</dia:string>
      </dia:attribute>
      <dia:attribute name="do_action">
        <dia:string>#do_event#</dia:string>
      </dia:attribute>
      <dia:attribute name="exit_action">
        <dia:string>#post_event#</dia:string>
      </dia:attribute>
*/


//-----------------------------------------------------------------------------
struct CDiargamData
{
    CDiargamData() {}

    STRUCT_LAYOUT_DEFAULT(CDiargamData)
    END_STRUCT_LAYOUT()
};

enum EObjectType
{
     objtypeUnknown,
     objtypeUmlTransition,
     objtypeUmlStateTerm,
     objtypeUmlState,
     objtypeUmlNote,
     objtypeUmlActivity,
     objtypeUmlDependency,
     objtypeUmlGeneralization,
     objtypeUmlClass//,
     //objtypeUml,
};



/*
UML - Transition
UML - State Term
UML - State
UML - Note
UML - Activity
UML - Dependency
UML - Generalization
UML - Class

*/


struct CObject
{
    tstring               type;
    tstring               version;
    tstring               id;
    std::vector<CDiaAttr>         attrs;
    std::vector<CDiaConnection>   connections;

    const CDiaConnection* findConnection(const tstring &handle) const
       {
        std::vector<dia::CDiaConnection>::const_iterator connIt = connections.begin();
        for(; connIt!=connections.end(); ++connIt)
           {
            if (connIt->handle==handle)
               return &(*connIt);
           }
        return 0;       
       }

    EObjectType getObjectType() const 
       {
        static std::map<tstring, EObjectType> typeMap;
        if (typeMap.empty())
           {
            typeMap[_T("UML - Transition")]     = objtypeUmlTransition;
            typeMap[_T("UML - State Term")]     = objtypeUmlStateTerm;
            typeMap[_T("UML - State")]          = objtypeUmlState;
            typeMap[_T("UML - Note")]           = objtypeUmlNote;
            typeMap[_T("UML - Activity")]       = objtypeUmlActivity;
            typeMap[_T("UML - Dependency")]     = objtypeUmlDependency;
            typeMap[_T("UML - Generalization")] = objtypeUmlGeneralization;
            typeMap[_T("UML - Class")]          = objtypeUmlClass;
            //typeMap[_T("")] = ;
           }
        std::map<tstring, EObjectType>::const_iterator it = typeMap.find(type);
        if (it==typeMap.end()) return objtypeUnknown;
        return it->second;
       }

    const CDiaAttr* findAttr(const tstring& attrName) const
       {
        std::vector<CDiaAttr>::const_iterator it = attrs.begin();
        for(; it!=attrs.end(); ++it)
           {
            if (it->name==attrName) return &(*it);
           }
        return 0;
       }
    

    void addAttr(const CDiaAttr &attr)
       { attrs.push_back(attr); }

    CObject() : type(), version(), id(), attrs(), connections() {}
    CObject(const tstring &t)                                     : type(t), version() , id() , attrs(), connections() {}
    CObject(const tstring &t, const tstring &v)                   : type(t), version(v), id() , attrs(), connections() {}
    CObject(const tstring &t, const tstring &v, const tstring &i) : type(t), version(v), id(i), attrs(), connections() {}

    STRUCT_LAYOUT_DEFAULT(CObject)
            attribute(_T("type")       , &CObject::type   , tstring(_T("")));
            attribute(_T("version")    , &CObject::version, tstring(_T("")));
            attribute(_T("id")         , &CObject::id     , tstring(_T("")));
            array(0                    , &CObject::attrs , _T("dia:attribute"));
            array(_T("dia:connections") , &CObject::connections , _T("dia:connection"));
    END_STRUCT_LAYOUT()

};

//-----------------------------------------------------------------------------
struct CDiargamLayer
{
    tstring                name;
    bool                   visible;
    std::vector<CObject>   objects;

    CDiargamLayer() : name(), visible(), objects() {}
    CDiargamLayer(const tstring &n) : name(n), visible(), objects() {}
    CDiargamLayer(const tstring &n, bool v) : name(n), visible(v), objects() {}

    void addObject(const CObject &o) { objects.push_back(o); }
    

    STRUCT_LAYOUT_DEFAULT(CDiargamLayer)
            attribute(_T("name")              , &CDiargamLayer::name   , tstring(_T("")));
            attribute(_T("visible")           , &CDiargamLayer::visible, true);
            array(0                           , &CDiargamLayer::objects , _T("dia:object"));
    END_STRUCT_LAYOUT()
};

//-----------------------------------------------------------------------------
struct CDiargam
{
    std::string                   xmlns_dia;
    CDiargamData                  data;
    std::vector<CDiargamLayer>    layers;


    void getObjects(std::vector<CObject> &objList) const
       {
        std::vector<CDiargamLayer>::const_iterator it = layers.begin();
        for(; it!=layers.end(); ++it)
           {
            objList.insert(objList.end(), it->objects.begin(), it->objects.end());
           }
       }

/*
    CDiaBoolAttr                  testBoolean;
    CDiaIntAttr                   testInt;
    CDiaRealAttr                  testReal;
    CDiaStringAttr                testString;
*/
    //CDiaAttr                      testAttr;

    CDiargam()
       : xmlns_dia("http://www.lysator.liu.se/~alla/dia/")
       , data()
       , layers()
       {}

    void addLayer(const CDiargamLayer &l) { layers.push_back(l); }

    STRUCT_LAYOUT_DEFAULT(CDiargam)
            //attribute(_T("xmlns:dia")              , &CDiargam::xmlns_dia    , tstring(_T(""http://www.lysator.liu.se/~alla/dia/"")));
            attribute(_T("xmlns:dia")              , &CDiargam::xmlns_dia   , tstring(_T("")));
            complex  (_T("dia:diagramdata")        , &CDiargam::data        , CDiargamData());
            array    ( 0                           , &CDiargam::layers      , _T("dia:layer"));

            //complex  (_T("dia:attribute")          , &CDiargam::testAttr , CDiaAttr());
            
/*
            complex  (_T("dia:attribute")          , &CDiargam::testBoolean , CDiaBoolAttr());
            complex  (_T("dia:attribute")          , &CDiargam::testInt     , CDiaIntAttr());
            complex  (_T("dia:attribute")          , &CDiargam::testReal    , CDiaRealAttr());
            complex  (0                            , &CDiargam::testString  , CDiaStringAttr());
*/
    END_STRUCT_LAYOUT()

    #if !defined(DIA_USE_OLD_SIXML)
    INLINE_SIXML_SIMPLE_SAVELOAD_METHODS( "dia:diagram" )
    #endif

};

//-----------------------------------------------------------------------------
inline
void save_diagram(const std::string &filename, const CDiargam &diagram)
   {   
    #if defined(DIA_USE_OLD_SIXML)
    sixml::serializer::write_xml( filename.c_str(),  
                                  "dia:diagram", 
                                  diagram, 
                                  sixml::serializer::write_attr::more_indent, // default_method, less_indent, more_indent
                                  true
                                );
    #else
    ::std::string diagramXml;
    diagram.save(diagramXml);
    ::cli::misc::utils::writeFile( filename, diagramXml );
    #endif
   }

//-----------------------------------------------------------------------------
inline
void load_diagram(const std::string &filename, CDiargam &diagram)
   {
    #if defined(DIA_USE_OLD_SIXML)
    sixml::serializer::load_xml<dia::CDiargam>(filename.c_str(), diagram);
    #else
    ::std::string diagramXml;
    //RCODE res = 
    ::cli::misc::utils::readFile( filename, diagramXml );
    diagram.load(diagramXml);
    #endif
   }

//-----------------------------------------------------------------------------
inline
tstring  /* dia */ textUnquote(const tstring &txt)
   {
    if (txt.size()<2) return txt;
    if (txt[0]!='#' || txt[txt.size()-1]!='#')
       return txt;
    return tstring(txt, 1, txt.size()-2);
   }


}; // namespace dia




/*
struct CMsvcProjectFile
{
    tstring       ProjectType;
    tstring       Version;
    tstring       Name;
    tstring       ProjectGUID;
    tstring       RootNamespace;
    tstring       Keyword;

    std::vector<CMsvcProjectPlatformInfo>        Platforms;
    std::vector<CMsvcProjectConfigurationInfo>   Configurations;
    std::vector<CMsvcProjectFilesFilterInfo>     Files;

    STRUCT_LAYOUT_DEFAULT(CMsvcProjectFile)
            attribute(_T("ProjectType")    , &CMsvcProjectFile::ProjectType    , tstring(_T("")));
            attribute(_T("Version")        , &CMsvcProjectFile::Version        , tstring(_T("")));
            attribute(_T("ProjectGUID")    , &CMsvcProjectFile::ProjectGUID    , tstring(_T("")));
            attribute(_T("RootNamespace")  , &CMsvcProjectFile::RootNamespace  , tstring(_T("")));
            attribute(_T("Keyword")        , &CMsvcProjectFile::Keyword        , tstring(_T("")));
            array(    _T("Platforms")      , &CMsvcProjectFile::Platforms      , _T("Platform"));
            array(    _T("Configurations") , &CMsvcProjectFile::Configurations , _T("Configuration"));
            array(    _T("Files")          , &CMsvcProjectFile::Files , _T("Filter"));
            //attribute(_T(""), &CMsvcProjectFile::, tstring(_T("")));
    END_STRUCT_LAYOUT()

*/


#endif /* DIA_DIA_H */

