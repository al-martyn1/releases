#ifndef DIA_DIAIOS_H
#define DIA_DIAIOS_H

#ifndef DIA_DIA_H
    #include "dia.h"
#endif



#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif


//-----------------------------------------------------------------------------
std::ostream& operator<<(std::ostream& os, const dia::CDiaConnection &dc)
   {
    os<<"handle: "<<dc.handle<<", to: "<<dc.to<<", connection: "<<dc.connection;
    return os;
   }

//-----------------------------------------------------------------------------
std::ostream& operator<<(std::ostream& os, const std::vector<dia::CDiaConnection> &vdc)
   {
    std::vector<dia::CDiaConnection>::const_iterator it = vdc.begin();
    os<<"    connections\n";
    for(; it!=vdc.end(); ++it)
       os<<"        "<<*it<<"\n";
    return os;
   }

//-----------------------------------------------------------------------------
std::ostream& operator<<(std::ostream& os, const dia::CObject &obj)
   {
    os<<"Object id:"<<obj.id<<", type: "<<obj.type<<", version: "<<obj.version<<"\n";
    const dia::CDiaAttr *pAttr = obj.findAttr("text");
    if (pAttr)
       {
        if (!pAttr->composite.empty())
           {
            pAttr = pAttr->composite[0].findAttr("string");
            if (pAttr)
               os<<"    text: "<<pAttr->stringVal<<"\n";
               //os<<"    text: "<<pAttr->stringVal.val<<"\n";
               //os<<"    text: "<<std::string(pAttr->stringVal)<<"\n";
           }
       }

    // UML - State
    pAttr = obj.findAttr("entry_action");
    if (pAttr)
       os<<"    entry_action: "<<pAttr->stringVal<<"\n";

    pAttr = obj.findAttr("do_action");
    if (pAttr)
       os<<"    do_action: "<<pAttr->stringVal<<"\n";

    pAttr = obj.findAttr("exit_action");
    if (pAttr)
       os<<"    exit_action: "<<pAttr->stringVal<<"\n";

    // UML - Transition
    pAttr = obj.findAttr("trigger");
    if (pAttr)
       os<<"    trigger: "<<pAttr->stringVal<<"\n";
    
    pAttr = obj.findAttr("action");
    if (pAttr)
       os<<"    action: "<<pAttr->stringVal<<"\n";
    
    pAttr = obj.findAttr("guard");
    if (pAttr)
       os<<"    guard: "<<pAttr->stringVal<<"\n";

    // UML - State Term
    pAttr = obj.findAttr("is_final");
    if (pAttr)
       os<<"    is_final: "<<pAttr->boolVal.val<<"\n";

    // UML - Class
    pAttr = obj.findAttr("name");
    if (pAttr)
       os<<"    name: "<<pAttr->stringVal<<"\n";

    pAttr = obj.findAttr("stereotype");
    if (pAttr)
       os<<"    stereotype: "<<pAttr->stringVal<<"\n";

    pAttr = obj.findAttr("comment");
    if (pAttr)
       os<<"    comment: "<<pAttr->stringVal<<"\n";

    pAttr = obj.findAttr("abstract");
    if (pAttr)
       os<<"    abstract: "<<pAttr->boolVal.val<<"\n";

    pAttr = obj.findAttr("attributes");
    if (pAttr)
       {
        /* const dia::CDiaAttr *pAttr2 = pAttr->composite.findAttr("string");
         * if (pAttr)
         *    os<<"    text: "<<pAttr->stringVal<<"\n";
         */
       }


    
    /*
    pAttr = obj.findAttr("");
    if (pAttr)
       os<<"    text: "<<pAttr->stringVal<<"\n";
    */

    if (!obj.connections.empty())
       std::cout<<obj.connections<<"\n";
    //os<<"handle: "<<dc.handle<<", to: "<<dc.to<<", connection: "<<dc.connection;
    return os;
   }


//CDiaAttr* findAttr(const tstring& attrName) const

#endif /* DIA_DIAIOS_H */

