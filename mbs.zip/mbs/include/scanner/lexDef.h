#ifndef SCANNER_LEXDEF_H
#define SCANNER_LEXDEF_H


/* Lexem type flags */

#define LTF_UNCAT                    0x00000000   /* Uncategorized */

#define LTF_KEYWORD                  0x10000000
#define LTF_OPERATOR                 0x20000000
#define LTF_STATEMENT                0x40000000
#define LTF_MS_SPECIFIC              0x80000000

#define LTF_ATTRIBUTE                0x01000000   /* storage-class attribute */
#define LTF_BASETYPE                 0x02000000   /* Fundamental C++ type */
#define LTF_BASETYPE_MODIFIER        0x04000000   /* Fundamental C++ type modifier */
#define LTF_TYPEDEF                  0x08000000   /* defines new type or typename - typedef, class, struct etc */
#define LTF_BASE_TYPE                LTF_BASETYPE
#define LTF_BASE_TYPE_MODIFIER       LTF_BASETYPE_MODIFIER


#define LTF_PAIR                     0x00100000   /* Paired token */
#define LTF_BEGIN                    0x00200000   /* Begin token of paired tokens */
#define LTF_COMMENT                  0x00400000   
#define LTF_PREPROCESSOR             0x00800000   
#define LTF_STRING_LITERAL           0x00010000   
#define LTF_NUMBER                   0x00020000   

#define LTF_WHITESPACE               0x00040000   /* non-significant spaces */
#define LTF_CUSTOM                   0x00080000   /* custom (user) keywords/types etc */
#define LTF_CUSTOM_ATTRIBUTE         0x01080000   /* custom (user) attributes */
#define LTF_CUSTOMTYPE               0x02080000   /* custom (user) types */
#define LTF_CUSTOMTYPE_MODIFIER      0x04080000   /* custom (user) type modifier */
#define LTF_CUSTOM_KEYWORD           0x10080000   /* custom (user) keywords */
#define LTF_CUSTOM_TYPE              LTF_CUSTOMTYPE
#define LTF_CUSTOM_TYPE_MODIFIER     LTF_CUSTOMTYPE_MODIFIER
//#define LTF_CUSTOM                   0x00080000   /* custom (user) keywords/types etc */


#define LT_IS_A(code, flag)          (((code)&(flag))==(flag))

#define LT_IS_KEYWORD(code)          LT_IS_A((code), LTF_KEYWORD)
#define LT_IS_OPERATOR(code)         LT_IS_A((code), LTF_OPERATOR)
#define LT_IS_STATEMENT(code)        LT_IS_A((code), LTF_STATEMENT)
#define LT_IS_MS_SPECIFIC(code)      LT_IS_A((code), LTF_MS_SPECIFIC)

#define LT_IS_ATTRIBUTE(code)        LT_IS_A((code), LTF_ATTRIBUTE)
#define LT_IS_BASETYPE(code)         LT_IS_A((code), LTF_BASETYPE)
#define LT_IS_BASETYPE_MODIFIER(code)   LT_IS_A((code), LTF_BASETYPE_MODIFIER)
#define LT_IS_TYPEDEF(code)          LT_IS_A((code), LTF_TYPEDEF)

#define LT_IS_COMMENT(code)          LT_IS_A((code), LTF_COMMENT)
#define LT_IS_PREPROCESSOR(code)     LT_IS_A((code), LTF_PREPROCESSOR)
#define LT_IS_STRING_LITERAL(code)   LT_IS_A((code), LTF_STRING_LITERAL)
#define LT_IS_NUMBER(code)           LT_IS_A((code), LTF_NUMBER)
#define LT_IS_WHITESPACE(code)       LT_IS_A((code), LTF_WHITESPACE)
#define LT_IS_CUSTOM(code)           LT_IS_A((code), LTF_CUSTOM)

#define LT_IS_SPACEORCOMMENT(code)   (LT_IS_WHITESPACE(code) || LT_IS_COMMENT(code))

//#define LT_IS_(code)                 LT_IS_A((code), )


#define LT_GETTYPE(tok)              ((tok)&0xFFFF0000)


// #define LTF_
//#define LTF_


/* LT helpers macroses */

#define LT_DECLARE_KEYWORD(code, exFlags)     ((LTF_KEYWORD)|(exFlags)|(code))
#define LT_DECLARE_KEYWORD_MS(code, exFlags)  LT_DECLARE_KEYWORD(code, (exFlags)|LTF_MS_SPECIFIC)
#define LT_DECLARE_OPERATOR(code, exFlags)    ((LTF_OPERATOR)|(exFlags)|(code))
#define LT_DECLARE_PREPROCESSOR(code)         ((LTF_PREPROCESSOR)|(code))
#define LT_DECLARE_COMMENT(code)              ((LTF_COMMENT)|(code))
#define LT_DECLARE_STRLIT(code)               ((LTF_STRING_LITERAL)|(code))
#define LT_DECLARE_NUMBER(code)               ((LTF_NUMBER)|(code))

#define LT_DECLARE_WHITESPACE(code)           ((LTF_WHITESPACE)|(code))




#define LT_END                        0

#define LT_PREPROCESSOR_START         LT_DECLARE_PREPROCESSOR(0x0001)
#define LT_PREPROCESSOR               LT_DECLARE_PREPROCESSOR(0x0002)
#define LT_PREPROCESSOR_NEW_LINE      LT_DECLARE_PREPROCESSOR(0x0003)
#define LT_PREPROCESSOR_END           LT_DECLARE_PREPROCESSOR(0x0004)
#define LT_PREPROCESSOR_NEXT_LINE     LT_DECLARE_PREPROCESSOR(0x0005)

#define LT_STRING                     LT_DECLARE_STRLIT(0x0008)
#define LT_STRING_NO_END              LT_DECLARE_STRLIT(0x0009)
#define LT_STRING_NO_START            LT_DECLARE_STRLIT(0x000A)

//#define LT_IDENT                      LT_DECLARE_STRLIT(0x000B)
#define LT_IDENT                      0x000B
#define LT_NUMBER                     LT_DECLARE_NUMBER(0x000C)

#define LT_COMMENT_SINGLE_LINE        LT_DECLARE_COMMENT(0x0010)
#define LT_COMMENT                    LT_DECLARE_COMMENT(0x0011)
#define LT_COMMENT_END                LT_DECLARE_COMMENT(0x0012)

#define LT_HEX_NUMBER                 LT_DECLARE_NUMBER(0x0018)
#define LT_BIN_NUMBER                 LT_DECLARE_NUMBER(0x0019)
#define LT_OCT_NUMBER                 LT_DECLARE_NUMBER(0x001A)
#define LT_FLOAT_NUMBER               LT_DECLARE_NUMBER(0x001B)

#define LT_HASH                       0x0020        //   #
#define LT_BACKSLASH                  0x0021        //   

#define LT_LINEFEED                   LT_DECLARE_WHITESPACE(0x001C) // line feed
#define LT_SPACE                      LT_DECLARE_WHITESPACE(0x001D) // one or more spaces

#define LT_CUSTOM_ATTRIBUTE           (LTF_CUSTOM_ATTRIBUTE    | 0x0020)
#define LT_CUSTOM_KEYWORD             (LTF_CUSTOM_KEYWORD      | 0x0021)
#define LT_CUSTOMTYPE                 (LTF_CUSTOMTYPE          | 0x0022)
#define LT_CUSTOMTYPE_MODIFIER        (LTF_CUSTOMTYPE_MODIFIER | 0x0023)
#define LT_CUSTOM_TYPE                (LTF_CUSTOM_TYPE         | 0x0024)
#define LT_CUSTOM_TYPE_MODIFIER       (LTF_CUSTOM_TYPE_MODIFIER| 0x0025)


#define LT_UNKNOWN                    0x0030


#define LT_OPERATOR_END               LT_DECLARE_OPERATOR(0x0100, 0) /* semicolon */
#define LT_BLOCK_START                LT_DECLARE_OPERATOR(0x0101, LTF_PAIR|LTF_BEGIN)
#define LT_BLOCK_END                  LT_DECLARE_OPERATOR(0x0102, LTF_PAIR)
#define LT_BRACKET_START              LT_DECLARE_OPERATOR(0x0103, LTF_PAIR|LTF_BEGIN)
#define LT_BRACKET_END                LT_DECLARE_OPERATOR(0x0104, LTF_PAIR)
#define LT_INDEX_START                LT_DECLARE_OPERATOR(0x0105, LTF_PAIR|LTF_BEGIN)
#define LT_INDEX_END                  LT_DECLARE_OPERATOR(0x0106, LTF_PAIR)

#define LT_DIV                        LT_DECLARE_OPERATOR(0x0110, 0)
#define LT_DIV_ASSIGN                 LT_DECLARE_OPERATOR(0x0120, 0)
#define LT_COLON                      LT_DECLARE_OPERATOR(0x0130, 0)
#define LT_DOUBLE_COLON               LT_DECLARE_OPERATOR(0x0140, 0)
#define LT_DOT                        LT_DECLARE_OPERATOR(0x0150, 0)
#define LT_COMMA                      LT_DECLARE_OPERATOR(0x0160, 0)
#define LT_PLUS                       LT_DECLARE_OPERATOR(0x0170, 0)
#define LT_PLUS_PLUS                  LT_DECLARE_OPERATOR(0x0180, 0)
#define LT_PLUS_ASSIGN                LT_DECLARE_OPERATOR(0x0190, 0)
#define LT_BIN_NOT                    LT_DECLARE_OPERATOR(0x01A0, 0)
#define LT_BOOL_NOT                   LT_DECLARE_OPERATOR(0x01B0, 0)
#define LT_NOT_EQ                     LT_DECLARE_OPERATOR(0x01C0, 0)
#define LT_BIN_AND                    LT_DECLARE_OPERATOR(0x01D0, 0)
#define LT_BIN_AND_ASSIGN             LT_DECLARE_OPERATOR(0x01E0, 0)
#define LT_BOOL_AND                   LT_DECLARE_OPERATOR(0x01F0, 0)
#define LT_MULT_ASSIGN                LT_DECLARE_OPERATOR(0x0200, 0)
#define LT_MULT                       LT_DECLARE_OPERATOR(0x0210, 0)
#define LT_DOT_MULT                   LT_DECLARE_OPERATOR(0x0220, 0)
#define LT_PTR_ACC_MULT               LT_DECLARE_OPERATOR(0x0230, 0)
#define LT_PTR_ACC                    LT_DECLARE_OPERATOR(0x0240, 0)
#define LT_MINUS                      LT_DECLARE_OPERATOR(0x0250, 0)
#define LT_MINUS_MINUS                LT_DECLARE_OPERATOR(0x0260, 0)
#define LT_MINUS_ASSIGN               LT_DECLARE_OPERATOR(0x0270, 0)
#define LT_MOD                        LT_DECLARE_OPERATOR(0x0280, 0)
#define LT_MOD_ASSIGN                 LT_DECLARE_OPERATOR(0x0290, 0)
#define LT_LESS                       LT_DECLARE_OPERATOR(0x02A0, 0)
#define LT_LESS_EQ                    LT_DECLARE_OPERATOR(0x02B0, 0)
#define LT_SHIFT_LEFT                 LT_DECLARE_OPERATOR(0x02C0, 0)
#define LT_SHIFT_LEFT_ASSIGN          LT_DECLARE_OPERATOR(0x02D0, 0)
#define LT_GREATER                    LT_DECLARE_OPERATOR(0x02E0, 0)
#define LT_GREATER_EQ                 LT_DECLARE_OPERATOR(0x02F0, 0)
#define LT_SHIFT_RIGHT                LT_DECLARE_OPERATOR(0x0300, 0)
#define LT_SHIFT_RIGHT_ASSIGN         LT_DECLARE_OPERATOR(0x0310, 0)
#define LT_ASSIGN                     LT_DECLARE_OPERATOR(0x0320, 0)
#define LT_EQ                         LT_DECLARE_OPERATOR(0x0330, 0)
#define LT_BIN_XOR                    LT_DECLARE_OPERATOR(0x0340, 0)
#define LT_BIN_XOR_ASSIGN             LT_DECLARE_OPERATOR(0x0350, 0)
#define LT_BIN_OR                     LT_DECLARE_OPERATOR(0x0360, 0)
#define LT_BIN_OR_ASSIGN              LT_DECLARE_OPERATOR(0x0370, 0)
#define LT_BOOL_OR                    LT_DECLARE_OPERATOR(0x0380, 0)
#define LT_QUESTION                   LT_DECLARE_OPERATOR(0x0390, 0)


/*
#define LTF_KEYWORD                  0x10000000
#define LTF_OPERATOR                 0x20000000
#define LTF_STATEMENT                0x40000000
#define LTF_MS_SPECIFIC              0x80000000

#define LTF_ATTRIBUTE                0x01000000   
#define LTF_BASETYPE                 0x02000000   
#define LTF_BASETYPE_MODIFIER        0x04000000   
#define LTF_TYPEDEF                  0x08000000   
*/

#define LT_KWD_MS_ABSTRACT                  LT_DECLARE_KEYWORD_MS(0x0400, 0)
#define LT_KWD_MS_ALIGNOF                   LT_DECLARE_KEYWORD_MS(0x0401, 0)
#define LT_KWD_MS_ASM                       LT_DECLARE_KEYWORD_MS(0x0402, 0)
#define LT_KWD_MS_ASSUME                    LT_DECLARE_KEYWORD_MS(0x0403, 0)
#define LT_KWD_MS_BASED                     LT_DECLARE_KEYWORD_MS(0x0404, 0)
#define LT_KWD_MS_BOX                       LT_DECLARE_KEYWORD_MS(0x0405, 0)
#define LT_KWD_MS_CDECL                     LT_DECLARE_KEYWORD_MS(0x0406, 0)
#define LT_KWD_MS_DECLSPEC                  LT_DECLARE_KEYWORD_MS(0x0407, 0)
#define LT_KWD_MS_DELEGATE                  LT_DECLARE_KEYWORD_MS(0x0408, 0)
#define LT_KWD_MS_EVENT                     LT_DECLARE_KEYWORD_MS(0x0409, 0)
#define LT_KWD_MS_EXCEPT                    LT_DECLARE_KEYWORD_MS(0x040A, 0)
#define LT_KWD_MS_FASTCALL                  LT_DECLARE_KEYWORD_MS(0x040B, 0)
#define LT_KWD_MS_FINALY                    LT_DECLARE_KEYWORD_MS(0x040C, 0)
#define LT_KWD_MS_FORCEINLINE               LT_DECLARE_KEYWORD_MS(0x040D, 0)
#define LT_KWD_MS_GC                        LT_DECLARE_KEYWORD_MS(0x040E, 0)
#define LT_KWD_MS_HOOK                      LT_DECLARE_KEYWORD_MS(0x040F, 0)
#define LT_KWD_MS_IDENTIFIER                LT_DECLARE_KEYWORD_MS(0x0410, 0)
#define LT_KWD_MS_IF_EXIST                  LT_DECLARE_KEYWORD_MS(0x0411, 0)
#define LT_KWD_MS_IF_NOT_EXIST              LT_DECLARE_KEYWORD_MS(0x0412, 0)
#define LT_KWD_MS_INLINE                    LT_DECLARE_KEYWORD_MS(0x0413, 0)
#define LT_KWD_MS_INT8                      LT_DECLARE_KEYWORD_MS(0x0414, LTF_BASETYPE)
#define LT_KWD_MS_INT16                     LT_DECLARE_KEYWORD_MS(0x0415, LTF_BASETYPE)
#define LT_KWD_MS_INT32                     LT_DECLARE_KEYWORD_MS(0x0416, LTF_BASETYPE)
#define LT_KWD_MS_INT64                     LT_DECLARE_KEYWORD_MS(0x0417, LTF_BASETYPE)
#define LT_KWD_MS_INTERFACE                 LT_DECLARE_KEYWORD_MS(0x0418, 0)
#define LT_KWD_MS_LEAVE                     LT_DECLARE_KEYWORD_MS(0x0419, 0)
#define LT_KWD_MS_M64                       LT_DECLARE_KEYWORD_MS(0x041A, LTF_BASETYPE)
#define LT_KWD_MS_M128                      LT_DECLARE_KEYWORD_MS(0x041B, LTF_BASETYPE)
#define LT_KWD_MS_M128D                     LT_DECLARE_KEYWORD_MS(0x041C, LTF_BASETYPE)
#define LT_KWD_MS_M128I                     LT_DECLARE_KEYWORD_MS(0x041D, LTF_BASETYPE)
#define LT_KWD_MS_MULTIPLE_INHERITANCE      LT_DECLARE_KEYWORD_MS(0x041E, 0)
#define LT_KWD_MS_NOGC                      LT_DECLARE_KEYWORD_MS(0x041F, 0)
#define LT_KWD_MS_NOOP                      LT_DECLARE_KEYWORD_MS(0x0420, 0)
#define LT_KWD_MS_PIN                       LT_DECLARE_KEYWORD_MS(0x0421, 0)
#define LT_KWD_MS_PROPERTY                  LT_DECLARE_KEYWORD_MS(0x0422, 0)
#define LT_KWD_MS_RAISE                     LT_DECLARE_KEYWORD_MS(0x0423, 0)
#define LT_KWD_MS_SEALED                    LT_DECLARE_KEYWORD_MS(0x0424, 0)
#define LT_KWD_MS_SINGLE_INHERITANCE        LT_DECLARE_KEYWORD_MS(0x0425, 0)
#define LT_KWD_MS_STDCALL                   LT_DECLARE_KEYWORD_MS(0x0426, 0)
#define LT_KWD_MS_SUPER                     LT_DECLARE_KEYWORD_MS(0x0427, 0)
#define LT_KWD_MS_TRY_CAST                  LT_DECLARE_KEYWORD_MS(0x0428, 0)
#define LT_KWD_MS_TRY                       LT_DECLARE_KEYWORD_MS(0x0429, 0)
//#define LT_KWD_MS_EXCEPT                    LT_DECLARE_KEYWORD_MS(0x042A, 0)
//#define LT_KWD_MS_FINALY                    LT_DECLARE_KEYWORD_MS(0x042B, 0)
#define LT_KWD_MS_UNHOOK                    LT_DECLARE_KEYWORD_MS(0x042C, 0)
#define LT_KWD_MS_UUIDOF                    LT_DECLARE_KEYWORD_MS(0x042D, 0)
#define LT_KWD_MS_VALUE                     LT_DECLARE_KEYWORD_MS(0x042E, 0)
#define LT_KWD_MS_VIRTUAL_INHERITANCE       LT_DECLARE_KEYWORD_MS(0x042F, 0)
#define LT_KWD_MS_W64                       LT_DECLARE_KEYWORD_MS(0x0430, LTF_BASETYPE_MODIFIER)
#define LT_KWD_MS_WCHAR_T                   LT_DECLARE_KEYWORD_MS(0x0431, LTF_BASETYPE)
#define LT_KWD_BOOL                         LT_DECLARE_KEYWORD(0x0432, LTF_BASETYPE)
#define LT_KWD_BREAK                        LT_DECLARE_KEYWORD(0x0433, 0)
#define LT_KWD_CASE                         LT_DECLARE_KEYWORD(0x0434, 0)
#define LT_KWD_CATCH                        LT_DECLARE_KEYWORD(0x0435, 0)
#define LT_KWD_CHAR                         LT_DECLARE_KEYWORD(0x0436, LTF_BASETYPE)
#define LT_KWD_CLASS                        LT_DECLARE_KEYWORD(0x0437, LTF_TYPEDEF)
#define LT_KWD_CONST                        LT_DECLARE_KEYWORD(0x0438, 0)
#define LT_KWD_CONST_CAST                   LT_DECLARE_KEYWORD(0x0439, 0)
#define LT_KWD_CONTINUE                     LT_DECLARE_KEYWORD(0x043A, 0)
#define LT_KWD_DEFAULT                      LT_DECLARE_KEYWORD(0x043B, 0)
#define LT_KWD_DELETE                       LT_DECLARE_KEYWORD(0x043C, 0)
#define LT_KWD_DEPRECATED                   LT_DECLARE_KEYWORD(0x043D, 0)
#define LT_KWD_DLLEXPORT                    LT_DECLARE_KEYWORD(0x043E, 0)
#define LT_KWD_DLLIMPORT                    LT_DECLARE_KEYWORD(0x043F, 0)
#define LT_KWD_DO                           LT_DECLARE_KEYWORD(0x0440, 0)
#define LT_KWD_DOUBLE                       LT_DECLARE_KEYWORD(0x0441, LTF_BASETYPE)
#define LT_KWD_DYNAMIC_CAST                 LT_DECLARE_KEYWORD(0x0442, 0)
#define LT_KWD_ELSE                         LT_DECLARE_KEYWORD(0x0443, 0)
#define LT_KWD_ENUM                         LT_DECLARE_KEYWORD(0x0444, LTF_TYPEDEF)
#define LT_KWD_EXPLICIT                     LT_DECLARE_KEYWORD(0x0445, 0)
#define LT_KWD_EXTERN                       LT_DECLARE_KEYWORD(0x0446, 0)
#define LT_KWD_FALSE                        LT_DECLARE_KEYWORD(0x0447, 0)
#define LT_KWD_FLOAT                        LT_DECLARE_KEYWORD(0x0448, LTF_BASETYPE)
#define LT_KWD_FOR                          LT_DECLARE_KEYWORD(0x0449, 0)
#define LT_KWD_FRIEND                       LT_DECLARE_KEYWORD(0x044A, 0)
#define LT_KWD_GOTO                         LT_DECLARE_KEYWORD(0x044B, 0)
#define LT_KWD_IF                           LT_DECLARE_KEYWORD(0x044C, 0)
#define LT_KWD_INLINE                       LT_DECLARE_KEYWORD(0x044D, 0)
#define LT_KWD_INT                          LT_DECLARE_KEYWORD(0x044E, LTF_BASETYPE)
#define LT_KWD_LONG                         LT_DECLARE_KEYWORD(0x044F, LTF_BASETYPE_MODIFIER)
#define LT_KWD_MUTABLE                      LT_DECLARE_KEYWORD(0x0450, 0)
#define LT_KWD_NAKED                        LT_DECLARE_KEYWORD(0x0451, 0)
#define LT_KWD_NAMESPACE                    LT_DECLARE_KEYWORD(0x0452, 0)
#define LT_KWD_NEW                          LT_DECLARE_KEYWORD(0x0453, 0)
#define LT_KWD_NOINLINE                     LT_DECLARE_KEYWORD(0x0454, 0)
#define LT_KWD_NORETURN                     LT_DECLARE_KEYWORD(0x0455, 0)
#define LT_KWD_NOTHROW                      LT_DECLARE_KEYWORD(0x0456, 0)
#define LT_KWD_NOVTABLE                     LT_DECLARE_KEYWORD(0x0457, 0)
#define LT_KWD_OPERATOR                     LT_DECLARE_KEYWORD(0x0458, 0)
#define LT_KWD_PRIVATE                      LT_DECLARE_KEYWORD(0x0459, 0)
#define LT_KWD_PROPERTY                     LT_DECLARE_KEYWORD(0x045A, 0)
#define LT_KWD_PROTECTED                    LT_DECLARE_KEYWORD(0x045B, 0)
#define LT_KWD_PUBLIC                       LT_DECLARE_KEYWORD(0x045C, 0)
#define LT_KWD_REGISTER                     LT_DECLARE_KEYWORD(0x045D, LTF_BASETYPE_MODIFIER)
#define LT_KWD_REINTERPRET_CAST             LT_DECLARE_KEYWORD(0x045E, 0)
#define LT_KWD_RETURN                       LT_DECLARE_KEYWORD(0x045F, 0)
#define LT_KWD_SELECTANY                    LT_DECLARE_KEYWORD(0x0460, 0)
#define LT_KWD_SHORT                        LT_DECLARE_KEYWORD(0x0461, LTF_BASETYPE_MODIFIER)
#define LT_KWD_SIGNED                       LT_DECLARE_KEYWORD(0x0462, LTF_BASETYPE_MODIFIER)
#define LT_KWD_SIZEOF                       LT_DECLARE_KEYWORD(0x0463, 0)
#define LT_KWD_STATIC                       LT_DECLARE_KEYWORD(0x0464, 0)
#define LT_KWD_STATIC_CAST                  LT_DECLARE_KEYWORD(0x0465, 0)
#define LT_KWD_STRUCT                       LT_DECLARE_KEYWORD(0x0466, LTF_TYPEDEF)
#define LT_KWD_SWITCH                       LT_DECLARE_KEYWORD(0x0467, 0)
#define LT_KWD_TEMPLATE                     LT_DECLARE_KEYWORD(0x0468, LTF_TYPEDEF)
#define LT_KWD_THIS                         LT_DECLARE_KEYWORD(0x0469, 0)
#define LT_KWD_THREAD                       LT_DECLARE_KEYWORD(0x046A, 0)
#define LT_KWD_THROW                        LT_DECLARE_KEYWORD(0x046B, 0)
#define LT_KWD_TRUE                         LT_DECLARE_KEYWORD(0x046C, 0)
#define LT_KWD_TRY                          LT_DECLARE_KEYWORD(0x046D, 0)
#define LT_KWD_TYPEDEF                      LT_DECLARE_KEYWORD(0x046E, LTF_TYPEDEF)
#define LT_KWD_TYPEID                       LT_DECLARE_KEYWORD(0x046F, 0)
#define LT_KWD_TYPENAME                     LT_DECLARE_KEYWORD(0x0470, 0)
#define LT_KWD_UNION                        LT_DECLARE_KEYWORD(0x0471, LTF_TYPEDEF)
#define LT_KWD_UNSIGNED                     LT_DECLARE_KEYWORD(0x0472, LTF_BASETYPE_MODIFIER)
#define LT_KWD_USING                        LT_DECLARE_KEYWORD(0x0473, 0)
#define LT_KWD_DECLARATION                  LT_DECLARE_KEYWORD(0x0474, 0)
#define LT_KWD_DIRECTIVE                    LT_DECLARE_KEYWORD(0x0475, 0)
#define LT_KWD_UUID                         LT_DECLARE_KEYWORD(0x0476, 0)
#define LT_KWD_VIRTUAL                      LT_DECLARE_KEYWORD(0x0477, 0)
#define LT_KWD_VOID                         LT_DECLARE_KEYWORD(0x0478, LTF_BASETYPE)
#define LT_KWD_VOLATILE                     LT_DECLARE_KEYWORD(0x0479, 0)
#define LT_KWD_WCHAR_T                      LT_DECLARE_KEYWORD(0x047A, LTF_BASETYPE)
#define LT_KWD_WHILE                        LT_DECLARE_KEYWORD(0x047B, 0)
//#define LT_KWD_                          LT_DECLARE_KEYWORD(0x0400, 0)


#endif /* SCANNER_LEXDEF_H */

