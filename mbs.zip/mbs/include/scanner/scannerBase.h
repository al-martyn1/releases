#ifndef SCANNER_SCANNERBASE_H
#define SCANNER_SCANNERBASE_H


struct text_position_t
{
    int    pos;
    int    line;

    text_position_t() : pos(0), line(0) {}
    text_position_t(int p, int l) : pos(p), line(l) {}

    void inc() { pos++; }
    void newLine() { line++; pos = 0;}
};


struct CFilePosition
{
    text_position_t  pos;
    unsigned         filenameId;
    CFilePosition() : pos(), filenameId(0) {}
    CFilePosition(const text_position_t &tp, unsigned fid) : pos(tp), filenameId(fid) {}
    CFilePosition(const CFilePosition &fp) : pos(fp.pos), filenameId(fp.filenameId) {}

};



#endif /* SCANNER_SCANNERBASE_H */

