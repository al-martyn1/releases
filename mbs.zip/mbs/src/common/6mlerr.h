#ifndef MBS_6MLERR_H
#define MBS_6MLERR_H


#define CATCH_6ML_ERRORS(bFlagErr, strErr)                                                                                                                                                    \
    catch(sixml::parser_error & e)                                                                                                                                                            \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Parser error: %s, in '%s' at line %d pos %d\n", sixml::__to_tstr(e.what()).c_str(), e.where_file(), e.where_line(), e.where_pos());                                    \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(sixml::mandatory_field_expected & e)                                                                                                                                                \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Mandatory field error: %s, in %s at line %d pos %d (node: %s)\n", sixml::__to_tstr(e.what()).c_str(), e.where_file(), e.where_line(), e.where_pos(), e.where_node());  \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(sixml::parse_value_exception & e)                                                                                                                                                   \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Parse value error: %s, in %s at line %d pos %d (node: %s)\n", sixml::__to_tstr(e.what()).c_str(), e.where_file(), e.where_line(), e.where_pos(), e.where_node());      \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(sixml::generic_exception_at_pos & e)                                                                                                                                                \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Generic error: %s, in '%s' at line %d pos %d (node: %s)\n", sixml::__to_tstr(e.what()).c_str(), e.where_file(), e.where_line(), e.where_pos(), e.where_node());        \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(sixml::not_specialised & e)                                                                                                                                                         \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Template not specialised: %s\n", sixml::__to_tstr(e.what()).c_str());                                                                                                  \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(sixml::copying_not_alowed & e)                                                                                                                                                      \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Call to copy constructor is not allowed, file: %s, line% %d\n", sixml::__to_tstr(e.what()).c_str(), e.where_line());                                                   \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(sixml::generic_exception & e)                                                                                                                                                       \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Generic error: %s\n", sixml::__to_tstr(e.what()).c_str());                                                                                                             \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(sixml::winapi_error & e)                                                                                                                                                            \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "I/O error: %s\n", sixml::__to_tstr(e.what()).c_str());                                                                                                                 \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(std::exception & e)                                                                                                                                                                 \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Generic error: %s\n", sixml::__to_tstr(e.what()).c_str());                                                                                                             \
        strErr = buf;                                                                                                                                                                         \
       }                                                                                                                                                                                      \
    catch(...)                                                                                                                                                                                \
       {                                                                                                                                                                                      \
        char buf[1024];                                                                                                                                                                       \
        bFlagErr = true;                                                                                                                                                                      \
        wsprintf(buf, "Unknown error\n");                                                                                                                                                     \
        strErr = buf;                                                                                                                                                                         \
       }



#endif /* MBS_6MLERR_H */

