#ifndef TLSIMPL_H
#define TLSIMPL_H


#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_TLS_H
    #include <cli/tls.h>
#endif

VOID*
CLICALL
cliGetCliTlsData( );

BOOL
CLICALL
cliSetCliTlsData( VOID *pData );

#if defined(WIN32) || defined(_WIN32)
#if !defined(CLI_MONOLITHIC) && !defined(CLI_MONOLITH)
VOID
CLICALL
cliCallTlsDestructorFunction( );
#endif
#endif


#endif /* TLSIMPL_H */

