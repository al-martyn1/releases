#ifndef CORE_CLI2INIT_H
#define CORE_CLI2INIT_H

#ifndef CLI_EMBEDDED
    #if !defined(_INC_TIME) && !defined(_TIME_H_) && !defined(_TIME_H)
        #include <time.h>
    #endif
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef MACHINE_SPEED_VERY_SLOW
    #define MACHINE_SPEED_VERY_SLOW         0
    #define MACHINE_SPEED_SLOW              1
    #define MACHINE_SPEED_ABOVE_SLOW        2
    #define MACHINE_SPEED_MEDIUM            3
    #define MACHINE_SPEED_ABOVE_MEDIUM      4
    #define MACHINE_SPEED_HIGH              5
    #define MACHINE_SPEED_ABOVE_HIGH        6
    #define MACHINE_SPEED_VERY_HIGH         7
#endif

/*
#if defined(_MSC_VER)
    #define WANT_ISDEBUGGERPRESENT_WRAPPER
    #if defined(WANT_ISDEBUGGERPRESENT_WRAPPER)
        #if (defined(_WIN32) || defined(WIN32)) && defined(_DEBUG)
            #define WANT_ISDEBUGGERPRESENT_WRAPPER
            #include <NewAPIs.h>
        #endif
    #endif
#endif
*/

#if (defined(_WIN32) || defined(WIN32)) && defined(_DEBUG)
#define IsDebuggerPresent _IsDebuggerPresent
extern BOOL (CALLBACK *IsDebuggerPresent)(VOID);
#endif


#ifndef CLI_EMBEDDED


    #if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
        #include <string>
    #endif

    #if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
        #include <map>
    #endif

    #ifdef LINUX
        #if !defined(_SCHED_H)
            #include <sched.h>
        #endif
    #endif

    #include <marty/filesys.h>
    #include <marty/concvt.h>
    #include <marty/env.h>
    #include <marty/macroses.h>


    #include <stdio.h>
    #include <stdlib.h>

    #include <cli/cliutilx.h>


    #if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
        #include <string>
    #endif

    #if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
        #include <algorithm>
    #endif


    #ifdef _WIN32
        #define CLI2_SYSTEM_PATHS_SEPARATOR _T(';')
    #else
        #define CLI2_SYSTEM_PATHS_SEPARATOR _T(':')
    #endif


    namespace cli
    {

    #ifndef CLI_MONOLITHIC
    bool getCliModuleName(::std::basic_string<TCHAR> &cliModuleName);
    bool findCliConfig   (::std::basic_string<TCHAR> &foundConfFile);
    #endif
    bool getAppExeName   (::std::basic_string<TCHAR> &appExeName);
    // return non-canonical absolute exe name
    bool findCliAppConfig(::std::basic_string<TCHAR> &foundConfFile, const ::std::basic_string<TCHAR> &appExeName);
    bool findCliAppConfig(::std::basic_string<TCHAR> &foundConfFile);

    struct CCliOptions;

    CCliOptions* getCliRuntimeOptions();


    class CMachideSpeedStringConverter
       {
        public:
            typedef ::std::basic_string< TCHAR,
                                         ::std::char_traits<TCHAR>,
                                         ::std::allocator<TCHAR> >  tstring;
        protected:

            const ::std::map< tstring, DWORD>& getMachineNamesMap() const
               {
                static ::std::map< tstring, DWORD> machineSpeedNames;
                if (machineSpeedNames.empty())
                   {
                    machineSpeedNames[tstring(_T("0"))]         = MACHINE_SPEED_VERY_SLOW;
                    machineSpeedNames[tstring(_T("VERY_SLOW"))] = MACHINE_SPEED_VERY_SLOW;
                    machineSpeedNames[tstring(_T("very_slow"))] = MACHINE_SPEED_VERY_SLOW;
                    machineSpeedNames[tstring(_T("VERY-SLOW"))] = MACHINE_SPEED_VERY_SLOW;
                    machineSpeedNames[tstring(_T("very-slow"))] = MACHINE_SPEED_VERY_SLOW;

                    machineSpeedNames[tstring(_T("1"))]    = MACHINE_SPEED_SLOW;
                    machineSpeedNames[tstring(_T("SLOW"))] = MACHINE_SPEED_SLOW;
                    machineSpeedNames[tstring(_T("slow"))] = MACHINE_SPEED_SLOW;

                    machineSpeedNames[tstring(_T("2"))]          = MACHINE_SPEED_ABOVE_SLOW;
                    machineSpeedNames[tstring(_T("ABOVE_SLOW"))] = MACHINE_SPEED_ABOVE_SLOW;
                    machineSpeedNames[tstring(_T("above_slow"))] = MACHINE_SPEED_ABOVE_SLOW;
                    machineSpeedNames[tstring(_T("ABOVE-SLOW"))] = MACHINE_SPEED_ABOVE_SLOW;
                    machineSpeedNames[tstring(_T("above-slow"))] = MACHINE_SPEED_ABOVE_SLOW;

                    machineSpeedNames[tstring(_T("3"))]      = MACHINE_SPEED_MEDIUM;
                    machineSpeedNames[tstring(_T("MEDIUM"))] = MACHINE_SPEED_MEDIUM;
                    machineSpeedNames[tstring(_T("medium"))] = MACHINE_SPEED_MEDIUM;

                    machineSpeedNames[tstring(_T("4"))] = MACHINE_SPEED_ABOVE_MEDIUM;
                    machineSpeedNames[tstring(_T("ABOVE_MEDIUM"))] = MACHINE_SPEED_ABOVE_MEDIUM;
                    machineSpeedNames[tstring(_T("above_medium"))] = MACHINE_SPEED_ABOVE_MEDIUM;
                    machineSpeedNames[tstring(_T("ABOVE-MEDIUM"))] = MACHINE_SPEED_ABOVE_MEDIUM;
                    machineSpeedNames[tstring(_T("above-medium"))] = MACHINE_SPEED_ABOVE_MEDIUM;

                    machineSpeedNames[tstring(_T("5"))]    = MACHINE_SPEED_HIGH;
                    machineSpeedNames[tstring(_T("HIGH"))] = MACHINE_SPEED_HIGH;
                    machineSpeedNames[tstring(_T("high"))] = MACHINE_SPEED_HIGH;

                    machineSpeedNames[tstring(_T("6"))]          = MACHINE_SPEED_ABOVE_HIGH;
                    machineSpeedNames[tstring(_T("ABOVE_HIGH"))] = MACHINE_SPEED_ABOVE_HIGH;
                    machineSpeedNames[tstring(_T("above_high"))] = MACHINE_SPEED_ABOVE_HIGH;
                    machineSpeedNames[tstring(_T("ABOVE-HIGH"))] = MACHINE_SPEED_ABOVE_HIGH;
                    machineSpeedNames[tstring(_T("above-high"))] = MACHINE_SPEED_ABOVE_HIGH;

                    machineSpeedNames[tstring(_T("7"))]         = MACHINE_SPEED_VERY_HIGH;
                    machineSpeedNames[tstring(_T("VERY_HIGH"))] = MACHINE_SPEED_VERY_HIGH;
                    machineSpeedNames[tstring(_T("very_high"))] = MACHINE_SPEED_VERY_HIGH;
                    machineSpeedNames[tstring(_T("VERY-HIGH"))] = MACHINE_SPEED_VERY_HIGH;
                    machineSpeedNames[tstring(_T("very-high"))] = MACHINE_SPEED_VERY_HIGH;
                   }
                return machineSpeedNames;
               }

        public:

            const TCHAR* getSpeedConstantName(DWORD speedVal) const
               {
                static const TCHAR * names[8] = { _T("VERY_SLOW")
                                          , _T("SLOW")
                                          , _T("ABOVE_SLOW")
                                          , _T("MEDIUM")
                                          , _T("ABOVE_MEDIUM")
                                          , _T("HIGH")
                                          , _T("ABOVE_HIGH")
                                          , _T("VERY_HIGH")
                                          };
                if (speedVal>7) return names[7];
                return names[speedVal];
               }

            // CMachideSpeedStringConverter
            // getSpeedConstantName
            DWORD convertMachineSpeedValue(const tstring &speedValStr) const
               {
                const ::std::map< tstring, DWORD> &machineSpeedNames = getMachineNamesMap();
                ::std::map< tstring, DWORD>::const_iterator it = machineSpeedNames.find(speedValStr);
                if (it==machineSpeedNames.end()) return (DWORD)-1;
                return it->second;

               }
       };

    //-----------------------------------------------------------------------------
    struct CCliOptions
    {

            //-----------------------------------------------------------------------------
            typedef ::std::basic_string< TCHAR,
                                         ::std::char_traits<TCHAR>,
                                         ::std::allocator<TCHAR> >  tstring;

            #ifdef _WIN32
            typedef  DWORD_PTR affinity_mask_t;
            #else
            typedef  DWORD_PTR affinity_mask_t;
            #endif

            //-----------------------------------------------------------------------------
            const static int ignoreCliPath                 = 0x0001;
            const static int ignoreAppPath                 = 0x0002;
            const static int ignoreCliConfig               = 0x0004;
            const static int ignoreAppConfig               = 0x0008;
            const static int flagUseCache                  = 0x0010;
            const static int forceSingleProcessorStrategy  = 0x0020;
            const static int ignoreStdExt                  = 0x0040;
            const static int ignoreStdExcludePaths         = 0x0080;
            const static int ignoreStdExcludeMods          = 0x0100;

            const static affinity_mask_t  affinityMaskAllCpu = (affinity_mask_t)-1;

            class CLog;
            /* const handle_t hStdin   = 0;
             * const handle_t hStdout  = 1;
             * const handle_t hStderr  = 2;
             */
            MARTY_FILESYSTEM_NS handle_t               logTo;
            tstring                                    curLogName;

            int                                        flags;
            ::std::map<tstring, tstring>               envCache;
            bool                                       newLineFlag;

            tstring                                    cliPath;
            tstring                                    appPath;

            ::std::vector<tstring>                     modPath;
            ::std::vector<tstring>                     excludeModPath;
            ::std::vector<tstring>                     extList;
            ::std::vector<tstring>                     excludeModulesMaskList;
            //::std::string

            affinity_mask_t                            affinityMask;
            unsigned                                   numberOfSystemCpu;
            unsigned                                   numberOfCliCpu;
            unsigned                                   machineSpeed;


            bool useCache()
               {
                if (flags&flagUseCache) return true;
                return false;
               }

            bool forceSingleCpuStrategy()
               {
                return flags&forceSingleProcessorStrategy ? true : false;
               }

            unsigned getNumberOfCliProcessors()
               {
                if (!numberOfCliCpu)
                   {
                    affinity_mask_t tmp = affinityMask;
                    while(tmp)
                       {
                        if (tmp&1) ++numberOfCliCpu;
                        tmp>>=1;
                       }
                   }
                return numberOfCliCpu;
               }

            DWORD getMachineSpeed() const { return machineSpeed; }

            //-----------------------------------------------------------------------------
            CCliOptions()
               : logTo(MARTY_FILESYSTEM_NS hStdin)
               , curLogName(_T("0"))
               , flags(0)
               , envCache()
               , newLineFlag(true)
               , cliPath()
               , appPath()
               , modPath()
               , excludeModPath()
               , extList()
               , excludeModulesMaskList()
               , affinityMask(affinityMaskAllCpu)
               , numberOfSystemCpu(0)
               , numberOfCliCpu(0)
               , machineSpeed((unsigned)-1)
               {}

            //-----------------------------------------------------------------------------
            CCliOptions(const ::std::map<tstring, tstring> &ec)
               : logTo(MARTY_FILESYSTEM_NS hStdin)
               , curLogName(_T("0"))
               , flags(0)
               , envCache(ec)
               , newLineFlag(true)
               , cliPath()
               , appPath()
               , modPath()
               , excludeModPath()
               , extList()
               , excludeModulesMaskList()
               , affinityMask(affinityMaskAllCpu)
               , numberOfSystemCpu(0)
               , numberOfCliCpu(0)
               , machineSpeed((unsigned)-1)
               {}

            //-----------------------------------------------------------------------------
            ~CCliOptions()
               {
                if (logTo>2)
                   MARTY_FILESYSTEM_NS closeFile(logTo);
               }

            //-----------------------------------------------------------------------------
            CLog log() { return CLog(logTo, &newLineFlag); }

            //-----------------------------------------------------------------------------
            void reopenLogToDefault()
               {
                tstring val;
                //log()<<"Getting value of CLI2_LOG environment variable\n";
                bool bRes = ::marty::env::getVar(envCache, tstring(_T("CLI2_LOG")), val);
                if (!bRes)
                   {
                   val = _T("stderr");
                   }
                reopenLog(val);
               }

            void reopenLog(const tstring &_newStreamName)
               {
                std::map<tstring, tstring> tmpVars;
                tstring newStreamName = ::marty::macro::substMacroses(tmpVars, _newStreamName, false, false, &envCache, ::marty::macro::smf_EnvVarsAllowed);

                //if (curLogName==newStreamName) return; // not need to reopen log, nothng to do
                if (MARTY_FILENAME_NS equal(curLogName, newStreamName)) return;

                MARTY_FILESYSTEM_NS handle_t tmpNewHandle = -1;
                if      (newStreamName==_T("0") || newStreamName==_T("")) { tmpNewHandle = 0; }
                else if (newStreamName==_T("1") || newStreamName==_T("stdout") || newStreamName==_T("STDOUT")) { tmpNewHandle = 1; }
                else if (newStreamName==_T("2") || newStreamName==_T("stderr") || newStreamName==_T("STDERR")) { tmpNewHandle = 2; }

                if (logTo==tmpNewHandle)
                   {
                    /*
                    log()<<"Nothing to do - stream allready attached to: "
                         <<( tmpNewHandle!=0
                           ? ( tmpNewHandle>1 ?"stderr":"stdout")
                           : "off"
                           )<<"\n";
                    */
                    return;
                   }

                log()<<"Set new log stream to: "<<newStreamName<<"\n";
                if (logTo>MARTY_FILESYSTEM_NS hStderr)
                   {
                    log()<<"Close previously opened stream\n";
                    MARTY_FILESYSTEM_NS closeFile(logTo);
                   }

                if (tmpNewHandle==0) { log()<<"Logging disabled\n"; return; }
                if (tmpNewHandle==1) { log()<<"Logg attached to: stdout\n"; logTo = 1; return; }
                if (tmpNewHandle==2) { log()<<"Logg attached to: stderr\n"; logTo = 2; return; }

                int newLog = MARTY_FILESYSTEM_NS openFile(newStreamName.c_str(), MARTY_FILESYSTEM_NS o_append | MARTY_FILESYSTEM_NS o_creat | MARTY_FILESYSTEM_NS o_wronly | MARTY_FILESYSTEM_NS o_trunc);
                if (newLog==MARTY_FILESYSTEM_NS hInvalidHandle)
                   {
                    log()<<"Failed to attach log to: "<<newStreamName<<"\nPrevious stream still used\n";
                    return;
                   }
                logTo = newLog;
                curLogName = newStreamName;
                log()<<"Log attached to: "<<newStreamName<<"\n";
               }

            //-----------------------------------------------------------------------------
            void getFlagFromEnvironment( const tstring &flagName, const ::std::string &msg, int flagBitmask)
               {
                tstring val;
                log()<<"Getting value of "<<flagName<<" environment variable\n";

                if (!::marty::env::getVar(envCache, flagName, val))
                    log()<<"Environment variable not found, flag untouched\n";
                else
                   {
                    log()<<msg<<" - ";
                    if (val==tstring(_T("0")))
                       {
                        flags &= ~flagBitmask;
                        log()<<"off\n";
                       }
                    else
                       {
                        flags |=  flagBitmask;
                        log()<<"on\n";
                       }
                   }
               }

            //-----------------------------------------------------------------------------
            void getFlagsFromEnvironment()
               {
                //::std::string val;
                tstring val;

                log()<<"Getting value of CLI2_LOG environment variable\n";
                bool bRes = ::marty::env::getVar(envCache, tstring(_T("CLI2_LOG")), val);
                if (bRes) reopenLog(val);

                #ifndef CLI_MONOLITHIC
                getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_CLI_CONFIG")), ::std::string("Ignore CLI config"), ignoreCliConfig);
                #endif

                getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_APP_CONFIG")), ::std::string("Ignore App config"), ignoreAppPath);

                if (::marty::env::getVar(envCache, tstring(_T("CLI2_CPU_AFFINITY_MASK")), val) && !val.empty())
                   { // get affinity mask - Ok
                    ::std::string affMaskStr = MARTY_CON_NS str2con(val);
                    affinity_mask_t affMaskTmp = 0;
                    affMaskTmp = (affinity_mask_t)strtol( affMaskStr.c_str(), 0, 0);
                    if (affMaskTmp!=0)
                       {
                        affinityMask = affinityMask & affMaskTmp;
                       }
                   }

                //getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_CLI_PATH")), ::std::string("Ignore CLI path"), ignoreCliPath);
                //getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_APP_PATH")), ::std::string("Ignore App path"), ignoreAppPath);
                //getFlagFromEnvironment( ::std::string(_T("")), ::std::string(""), );
               }

            //-----------------------------------------------------------------------------
            void getMoreFlagsFromEnvironment()
               {
                //::std::string val;
                tstring val;

                log()<<"Getting value of CLI2_LOG environment variable\n";
                bool bRes = ::marty::env::getVar(envCache, tstring(_T("CLI2_LOG")), val);
                if (bRes) reopenLog(val);

                #ifndef CLI_MONOLITHIC
                getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_CLI_CONFIG")), ::std::string("Ignore CLI config"), ignoreCliConfig);
                getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_CLI_PATH")), ::std::string("Ignore CLI path"), ignoreCliPath);
                #endif

                getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_APP_CONFIG")), ::std::string("Ignore App config"), ignoreAppPath);
                getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_APP_PATH")), ::std::string("Ignore App path"), ignoreAppPath);
                getFlagFromEnvironment( tstring(_T("CLI2_IGNORE_STD_EXT")), ::std::string("Ignore standart extentions"), ignoreStdExt);

                getFlagFromEnvironment( tstring(_T("CLI2_USE_CACHE")), ::std::string("Use component info cache"), flagUseCache);
                getFlagFromEnvironment( tstring(_T("CLI2_SINGLE_PROCESSOR_STRATEGY")), ::std::string("Force single processor strategy"), forceSingleProcessorStrategy);

                getFlagFromEnvironment( tstring(_T("CLI2_NO_STD_MOD_PATH_EXCLUDE")), ::std::string("Ignore built-in exclusion paths"), ignoreStdExcludePaths);
                getFlagFromEnvironment( tstring(_T("CLI2_NO_STD_MOD_MASKS_EXCLUDE")), ::std::string("Ignore built-in module exclusion masks"), ignoreStdExcludeMods);

                if (::marty::env::getVar(envCache, tstring(_T("CLI2_CPU_AFFINITY_MASK")), val) && !val.empty())
                   { // get affinity mask - Ok
                    ::std::string affMaskStr = MARTY_CON_NS str2con(val);
                    affinity_mask_t affMaskTmp = 0;
                    affMaskTmp = (affinity_mask_t)strtol( affMaskStr.c_str(), 0, 0);
                    if (affMaskTmp!=0)
                       {
                        affinityMask = affinityMask & affMaskTmp;
                       }
                   }

                if (::marty::env::getVar(envCache, tstring(_T("CLI2_MACHINE_SPEED")), val) && !val.empty())
                   {
                    DWORD newMachineSpeedVal = CMachideSpeedStringConverter().convertMachineSpeedValue(val);
                    if (newMachineSpeedVal!=(DWORD)-1)
                       machineSpeed = newMachineSpeedVal;
                   }

                //getFlagFromEnvironment( ::std::string(_T("")), ::std::string(""), );
               }

            //-----------------------------------------------------------------------------
            #ifndef CLI_MONOLITHIC
            MARTY_FILESYSTEM_NS handle_t findCliConfig(tstring &foundConfFile)
               {
                tstring cliModName;
                if (!getCliModuleName(cliModName)) return MARTY_FILESYSTEM_NS hInvalidHandle;

                envCache[tstring(_T("CliModule"))] = cliModName;

                cliPath = MARTY_FILENAME_NS stripSlashCopy (MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS getPath(cliModName)));
                envCache[tstring(_T("CliPath"))] = cliPath;

                //::std::string
                tstring cliConfName = MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS appendPath(cliPath, tstring(_T("../conf/cli2.conf"))));
                log()<<"Try to open '"<<cliConfName<<"': ";

                MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile(cliConfName, MARTY_FILESYSTEM_NS o_rdonly );
                if (MARTY_FILESYSTEM_NS hInvalidHandle!=hFile)
                   {
                    log()<<"Ok\n";  foundConfFile = cliConfName;  return hFile;
                   }
                log()<<MARTY_FILESYSTEM_NS errorStr(errno)<<"\n";

                cliConfName = MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS appendPath(cliPath, tstring(_T("cli2.conf"))));
                log()<<"Try to open '"<<cliConfName<<"': ";

                hFile = MARTY_FILESYSTEM_NS openFile(cliConfName, MARTY_FILESYSTEM_NS o_rdonly );
                if (MARTY_FILESYSTEM_NS hInvalidHandle!=hFile)
                   {
                    log()<<"Ok\n";  foundConfFile = cliConfName;  return hFile;
                   }
                log()<<MARTY_FILESYSTEM_NS errorStr(errno)<<"\n";

                return MARTY_FILESYSTEM_NS hInvalidHandle;
               }
            #endif

            //-----------------------------------------------------------------------------
            MARTY_FILESYSTEM_NS handle_t findCliAppConfig(tstring &foundConfFile)
               {
                tstring appExeName;
                if (!getAppExeName(appExeName)) return MARTY_FILESYSTEM_NS hInvalidHandle;

                envCache[tstring(_T("App"))] = appExeName;

                //appPath = MARTY_FILENAME_NS stripSlashCopy (MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS getPath(appExeName)));
                appPath = MARTY_FILENAME::stripSlashCopy (MARTY_FILENAME::makeCanonical(MARTY_FILENAME::getPath(appExeName)));
                envCache[tstring(_T("AppPath"))] = appPath;

                // name+ext
                tstring appFile     = MARTY_FILENAME::stripSlashCopy (MARTY_FILENAME::makeCanonical(MARTY_FILENAME::getFile(appExeName)));
                tstring appFileName = MARTY_FILENAME::makeCanonical(MARTY_FILENAME::getName(appExeName));
                tstring appFileExt  = MARTY_FILENAME::makeCanonical(MARTY_FILENAME::getExtention(appExeName));
                envCache[tstring(_T("AppFile"))]     = appFile    ;
                envCache[tstring(_T("AppFileName"))] = appFileName;
                envCache[tstring(_T("AppFileExt"))]  = appFileExt ;

                tstring _cli2_conf = tstring(_T(".cli2.conf"));
                tstring appConfOnlyFile = MARTY_FILENAME_NS appendExtention(MARTY_FILENAME_NS getName(appExeName), _cli2_conf);
                tstring appConfName = MARTY_FILENAME_NS appendPath(appPath, tstring(_T("../conf")));
                appConfName = MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS appendPath(appConfName, appConfOnlyFile));

                log()<<"Try to open '"<<appConfName<<"': ";
                MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile(appConfName, MARTY_FILESYSTEM_NS o_rdonly );
                if (MARTY_FILESYSTEM_NS hInvalidHandle!=hFile)
                   {
                    log()<<"Ok\n";  foundConfFile = appConfName;  return hFile;
                   }
                log()<<MARTY_FILESYSTEM_NS errorStr(errno)<<"\n";

                appConfName = MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS appendPath(appPath, appConfOnlyFile));
                log()<<"Try to open '"<<appConfName<<"': ";
                hFile = MARTY_FILESYSTEM_NS openFile(appConfName, MARTY_FILESYSTEM_NS o_rdonly );
                if (MARTY_FILESYSTEM_NS hInvalidHandle!=hFile)
                   {
                    log()<<"Ok\n";  foundConfFile = appConfName;  return hFile;
                   }
                log()<<MARTY_FILESYSTEM_NS errorStr(errno)<<"\n";

                return MARTY_FILESYSTEM_NS hInvalidHandle;
               }


            //-----------------------------------------------------------------------------
            struct CConfigLineParser
            {
                 std::map<tstring, tstring> &envCache;
                 std::map<tstring, tstring> tmpVars;

                 CConfigLineParser(std::map<tstring, tstring> &ec) : envCache(ec), tmpVars() {}
                 CConfigLineParser(const CConfigLineParser &p) : envCache(p.envCache), tmpVars() {}

                 //void operator()(const ::std::string &str)
                 bool operator()(const char *line, unsigned size)
                    {
                     tstring str = MARTY_CON_NS con2str(::std::string(line, size));
                     tstring name, val;
                     if (!::cli::util::splitConfigLine(str, name, val)) return true;
                     envCache[name] = ::marty::macro::substMacroses(tmpVars, val, false, false, &envCache, ::marty::macro::smf_EnvVarsAllowed);
                     return true;
                    }
            };

            //-----------------------------------------------------------------------------
            affinity_mask_t setAffinityMask(affinity_mask_t newMask)
               {

                affinity_mask_t curProcessMask = 0;

                #ifdef _WIN32
                affinity_mask_t curSystemMask  = 0;
                if (!GetProcessAffinityMask(GetCurrentProcess(), &curProcessMask, &curSystemMask))
                   {
                    log()<<"GetProcessAffinityMask failed, code: "<<(int)GetLastError()<<"\n";
                    return newMask; // not changed
                   }
                #else

                // pthread_attr_getaffinity_np - POSIX, include pthread.h
                // only first 32 cpu's can be set
                cpu_set_t cpuSet;
                //cpu_set.__bits[0] = curProcessMask;
                unsigned int len = sizeof(cpuSet.__bits[0]);
                // UNDONE: need to port to 64 bit
                if (sched_getaffinity( 0, len, &cpuSet) < 0)
                   {
                    log()<<"sched_getaffinity failed: "<<MARTY_FILESYSTEM_NS errorStr()<<"\n";
                    return newMask; // not changed
                   }
                curProcessMask = cpuSet.__bits[0];
                #endif

                if (newMask==affinityMaskAllCpu)
                   {
                    log()<<"Default mask (0x"<<(unsigned)curProcessMask<<") used, don't change\n";
                    return curProcessMask;
                   }

                newMask = newMask & curProcessMask;
                if (!newMask)
                   {
                    log()<<"Can't set CPU affinity mask - zero mask taken\n";
                    return curProcessMask;
                   }

                #ifdef _WIN32
                if (!SetProcessAffinityMask(GetCurrentProcess(), newMask))
                   {
                    log()<<"SetProcessAffinityMask failed, code: "<<(int)GetLastError()<<"\n";
                    return curProcessMask; // not changed
                   }
                #else
                //cpu_set_t cpuSet;
                cpuSet.__bits[0] = newMask;
                //unsigned int
                len = sizeof(cpuSet.__bits[0]);
                // pthread_attr_setaffinity_np - POSIX, include pthread.h
                if (sched_setaffinity( 0, len, &cpuSet)<0)
                   {
                    log()<<"sched_setaffinity failed: "<<MARTY_FILESYSTEM_NS errorStr()<<"\n";
                    return curProcessMask;
                   }
                #endif


                log()<<"Cpu affinity mask applied to process: 0x" <<(unsigned)newMask<< ", previos system value: 0x"<<(unsigned)curProcessMask<<"\n";
                return newMask;
               }


            void uniqueHelper( ::std::vector<tstring> &vec) const
               {
                ::std::set<tstring> uniqItems;
                ::std::vector<tstring> resVec; resVec.reserve(vec.size());
                ::std::vector<tstring>::const_iterator it = vec.begin();
                for(; it != vec.end(); ++it)
                   {
                    if (uniqItems.find(*it)!=uniqItems.end()) continue; // allready exist
                    uniqItems.insert(*it);
                    resVec.push_back(*it);
                   }
                resVec.swap(vec);
               }


            void readCliConfigs()
               {
                using MARTY_FILESYSTEM_NS   closeFile;
                using MARTY_FILESYSTEM_NS   hInvalidHandle;


                tstring appExeName;
                if (getAppExeName(appExeName))
                   {
                    envCache[tstring(_T("App"))] = appExeName;
                    appPath = MARTY_FILENAME_NS stripSlashCopy (MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS getPath(appExeName)));
                    envCache[tstring(_T("AppPath"))] = appPath;
                    //tstring appFile = MARTY_FILENAME_NS getFile(appExeName);
                    //envCache[tstring(_T("AppFile"))] = appFile;

                    tstring appFile     = MARTY_FILENAME::stripSlashCopy (MARTY_FILENAME::makeCanonical(MARTY_FILENAME::getFile(appExeName)));
                    tstring appFileName = MARTY_FILENAME::makeCanonical(MARTY_FILENAME::getName(appExeName));
                    tstring appFileExt  = MARTY_FILENAME::makeCanonical(MARTY_FILENAME::getExtention(appExeName));
                    envCache[tstring(_T("AppFile"))]     = appFile    ;
                    envCache[tstring(_T("AppFileName"))] = appFileName;
                    envCache[tstring(_T("AppFileExt"))]  = appFileExt ;

                    // Now we can use next log file name
                    // $(AppPath)\$(AppFileName).log

                   }

                getFlagsFromEnvironment();
                //::std::string
                tstring foundConfFile;

                CConfigLineParser configLineParser(envCache);

                #ifndef CLI_MONOLITHIC
                // read cli2.conf
                if ((flags&ignoreCliConfig)==0)
                   {
                    log()<<"Lookup for main cli2.conf config\n";
                    MARTY_FILESYSTEM_NS handle_t hCliConfHandle = findCliConfig(foundConfFile);
                    if (hCliConfHandle!=hInvalidHandle)
                       {
                        log()<<"Reading cli2 main config: "<<foundConfFile<<"\n";
                        //template <typename THandler, unsigned maxLineSize, char delim>
                        MARTY_FILESYSTEM_NS readFileLines<CConfigLineParser, 4096, '\n'>(hCliConfHandle, configLineParser);
                        closeFile(hCliConfHandle);
                       }
                    else
                       {
                        log()<<"Cli2 main config not found\n";
                       }
                   }
                else
                   {
                    log()<<"Main cli2.conf disabled by CLI2_IGNORE_CLI_CONFIG\n";
                   }
                #endif

                getFlagsFromEnvironment();

                if ((flags&ignoreAppConfig)==0)
                   {
                    log()<<"Lookup for app cli2.conf config\n";
                    MARTY_FILESYSTEM_NS handle_t hCliConfHandle = findCliAppConfig(foundConfFile);
                    if (hCliConfHandle!=hInvalidHandle)
                       {
                        log()<<"Reading cli2 app config: "<<foundConfFile<<"\n";
                        MARTY_FILESYSTEM_NS readFileLines<CConfigLineParser, 4096, '\n'>(hCliConfHandle, configLineParser);
                        closeFile(hCliConfHandle);
                       }
                    else
                       {
                        log()<<"Cli2 app config not found\n";
                       }
                   }
                else
                   {
                    log()<<"App cli2.conf disabled by CLI2_IGNORE_APP_CONFIG\n";
                   }

                // read app.cli2.conf

                getMoreFlagsFromEnvironment();

                // read vals from environment

                ::marty::env::flushVars(envCache);

                log()<<"Setting new affinity mask to: 0x"<<(unsigned)affinityMask<<"\n";

                affinityMask = setAffinityMask(affinityMask);

                if (machineSpeed==(DWORD)-1)
                   {
                    // autodetect machine speed here
                    machineSpeed = MACHINE_SPEED_ABOVE_MEDIUM;
                   }
                log()<<"Machine speed: "<<CMachideSpeedStringConverter().getSpeedConstantName(machineSpeed)<<"\n";


                modPath.clear();

                #ifndef CLI_MONOLITHIC

                if ((flags&ignoreAppPath)==0)  modPath.push_back(appPath);
                if ((flags&ignoreCliPath)==0)  modPath.push_back(cliPath);

                #ifdef _WIN32
                ::cli::util::CIsExactChar<TCHAR, CLI2_SYSTEM_PATHS_SEPARATOR> pathListSeparatorPred;
                #else
                ::cli::util::CIsExactChar<TCHAR, CLI2_SYSTEM_PATHS_SEPARATOR> pathListSeparatorPred;
                #endif


                // get system library paths
                //

                tstring librarySearchSystemPathVarName;
                if (::marty::env::getVar(envCache, tstring(_T("CLI2_LIBRARY_PATH_VAR_NAME")), librarySearchSystemPathVarName))
                   {
                    log()<<"Found library search system path variable name: "<<librarySearchSystemPathVarName<<"\n";
                   }
                else
                   {
                    #if defined(WIN32) || defined(_WIN32)
                    librarySearchSystemPathVarName = _T("PATH");
                    #else
                    librarySearchSystemPathVarName = _T("LD_LIBRARY_PATH");
                    #endif
                    log()<<"Used default name for library search system path variable name: "<<librarySearchSystemPathVarName<<"\n";
                   }

                tstring librarySearchSystemPath;
                ::marty::env::getVar(envCache, librarySearchSystemPathVarName, librarySearchSystemPath);

                tstring librarySearchAdditionalPath;
                if (::marty::env::getVar(envCache, tstring(_T("CLI2_LIBRARY_SEARCH_ADDITIONAL_PATH")), librarySearchAdditionalPath))
                   {
                    librarySearchSystemPath.append(1, CLI2_SYSTEM_PATHS_SEPARATOR);
                    librarySearchSystemPath.append( librarySearchAdditionalPath, 0, librarySearchAdditionalPath.size() );

                    ::std::vector<tstring> librariesPathList;
                    ::cli::util::splitString(librarySearchSystemPath, librariesPathList, pathListSeparatorPred);
                    uniqueHelper(librariesPathList);

                    librarySearchSystemPath.clear();

                    ::std::vector<tstring>::const_iterator it = librariesPathList.begin();
                    for(; it != librariesPathList.end(); ++it)
                       {
                        if (!librarySearchSystemPath.empty()) librarySearchSystemPath.append(1, CLI2_SYSTEM_PATHS_SEPARATOR);
                        librarySearchSystemPath.append( *it, 0, it->size() );
                       }
                    //librariesPathList.push_back();
                    ::marty::env::putVar( librarySearchSystemPathVarName, librarySearchSystemPath);
                    log()<<"Found additional library search path (CLI2_LIBRARY_SEARCH_ADDITIONAL_PATH): "<<librarySearchAdditionalPath<<"\n";
                   }
                else
                   {
                    log()<<"Additional library search path (CLI2_LIBRARY_SEARCH_ADDITIONAL_PATH) not found\n";
                   }

                log()<<"Library search path is:\n"; // "<<librarySearchSystemPath<<"\n";
                {
                  ::std::vector<tstring> librariesPaths;
                  ::cli::util::splitString(librarySearchSystemPath, librariesPaths, pathListSeparatorPred);
                  ::std::vector<tstring>::const_iterator libpathIt = librariesPaths.begin();
                  for(; libpathIt!=librariesPaths.end(); ++libpathIt)
                     {
                      log()<<"    "<<*libpathIt<<"\n";
                     }
                }

                /////////////////////
                // module lookup path
                tstring strPath;
                if (::marty::env::getVar(envCache, tstring(_T("CLI2_MOD_PATH")), strPath))
                   {
                    ::cli::util::splitString(strPath, modPath, pathListSeparatorPred);
                   }

                //::std::vector<tstring>::iterator newEnd = ::std::unique(modPath.begin(), modPath.end(), MARTY_FILENAME::predEqual());
                //modPath.erase(newEnd, modPath.end());

                uniqueHelper(modPath);

                log()<<"Modules search path list:\n";
                ::std::vector<tstring>::const_iterator pit = modPath.begin();
                for(; pit!=modPath.end(); ++pit)
                   {
                    log()<<"    "<<*pit<<"\n";
                   }
                //log()<<"\n";

                /////////////////////////////
                // module lookup path exclude
                //tstring
                //log()<<"CP0, excludeModPath.size(): "<<excludeModPath.size()<<"\n";
                strPath.clear(); excludeModPath.clear();
                if (::marty::env::getVar(envCache, tstring(_T("CLI2_MOD_PATH_EXCLUDE")), strPath))
                   {
                    //log()<<"CP0.1, CLI2_MOD_PATH_EXCLUDE: "<<strPath<<"\n";
                    ::cli::util::splitString(strPath, excludeModPath, pathListSeparatorPred);
                   }

                //log()<<"CP1, excludeModPath.size(): "<<excludeModPath.size()<<"\n";
                if ((flags&ignoreStdExcludePaths)==0)
                   {
                    excludeModPath.push_back(MARTY_FILENAME::makeCanonical(tstring(_T("$(AppPath)/wx"))));
                    excludeModPath.push_back(MARTY_FILENAME::makeCanonical(tstring(_T("$(AppPath)/qt"))));
                    excludeModPath.push_back(MARTY_FILENAME::makeCanonical(tstring(_T("$(AppPath)/_*"))));
                    //strPath.push_back(tstring(_T("")));
                   }
                //log()<<"CP2, excludeModPath.size(): "<<excludeModPath.size()<<"\n";

                //::std::vector<tstring>::iterator

                ::std::vector<tstring>::iterator strVecIt = excludeModPath.begin();
                for(; strVecIt!=excludeModPath.end(); ++strVecIt)
                   *strVecIt = MARTY_FILENAME::makeCanonical(*strVecIt);

                uniqueHelper(excludeModPath);

                //newEnd = ::std::unique(excludeModPath.begin(), excludeModPath.end(), MARTY_FILENAME::predEqual());
                //excludeModPath.erase(newEnd, excludeModPath.end());

                //log()<<"CP3, excludeModPath.size(): "<<excludeModPath.size()<<"\n";

                   {
                    std::vector<tstring> tmpExcludeModPath;  tmpExcludeModPath.reserve(excludeModPath.size());
                    //::std::vector<tstring>::const_iterator
                    pit = excludeModPath.begin();
                    for(; pit!=excludeModPath.end(); ++pit)
                       {
                        std::map<tstring, tstring> tmpVars;
                        tstring strPath = MARTY_FILENAME::stripSlashCopy( MARTY_FILENAME::makeCanonical( ::marty::macro::substMacroses(tmpVars, *pit, false, false, &envCache, ::marty::macro::smf_EnvVarsAllowed) ) );
                        //log()<<"    "<<*pit<<" (" <<strPath<<")\n";
                        tmpExcludeModPath.push_back(strPath);
                       }
                    //log()<<"\n";
                    tmpExcludeModPath.swap(excludeModPath);
                   }

                strVecIt = excludeModPath.begin();
                for(; strVecIt!=excludeModPath.end(); ++strVecIt)
                   *strVecIt = MARTY_FILENAME::makeCanonical(*strVecIt);

                //newEnd = ::std::unique(excludeModPath.begin(), excludeModPath.end(), MARTY_FILENAME::predEqual());
                //excludeModPath.erase(newEnd, excludeModPath.end());
                uniqueHelper(excludeModPath);

                log()<<"Modules search path exclude list:\n";
                pit = excludeModPath.begin();
                for(; pit!=excludeModPath.end(); ++pit)
                   {
                    log()<<"    "<<*pit<<"\n";
                   }

                //log()<<"CP4, excludeModPath.size(): "<<excludeModPath.size()<<"\n";

                //newEnd = ::std::unique(excludeModPath.begin(), excludeModPath.end(), MARTY_FILENAME::predEqual());
                //excludeModPath.erase(newEnd, excludeModPath.end());


                /////////////////////////////
                // filename excludes mask list
                //tstring
                //CLI2_MOD_PATH_EXCLUDE
                strPath.clear(); excludeModulesMaskList.clear();
                if (::marty::env::getVar(envCache, tstring(_T("CLI2_MOD_EXCLUDE")), strPath))
                   {
                    ::cli::util::splitString(strPath, excludeModulesMaskList, pathListSeparatorPred);
                   }

                if ((flags&ignoreStdExcludeMods)==0)
                   {
                    #if defined(WIN32) || defined(_WIN32)
                    // MSVC runtime
                    excludeModulesMaskList.push_back(tstring(_T("msvcp*")));
                    excludeModulesMaskList.push_back(tstring(_T("msvcr*")));
                    // wxWidgets
                    excludeModulesMaskList.push_back(tstring(_T("wxbase*")));
                    excludeModulesMaskList.push_back(tstring(_T("wxmsw*")));
                    // Qt
                    excludeModulesMaskList.push_back(tstring(_T("Qt*Support*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtAssistant*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtCLucene*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtCore*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtDesigner*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtGui*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtHelp*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtNetwork*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtOpenGL*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtScript*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtSql*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtSvg*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtTest*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtWebKit*")));
                    excludeModulesMaskList.push_back(tstring(_T("QtXml*")));
                    //excludeModulesMaskList.push_back(tstring(_T("")));
                    #else
                    // wxWidgets
                    excludeModulesMaskList.push_back(tstring(_T("libwx_base*")));
                    excludeModulesMaskList.push_back(tstring(_T("libwx_gtk*")));
                    excludeModulesMaskList.push_back(tstring(_T("libwx_mgl*")));
                    excludeModulesMaskList.push_back(tstring(_T("libwx_motif*")));
                    excludeModulesMaskList.push_back(tstring(_T("libwx_X11*")));
                    excludeModulesMaskList.push_back(tstring(_T("libwx_x11")));
                    // Qt
                    excludeModulesMaskList.push_back(tstring(_T("libQt*Support*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtAssistant*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtCLucene*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtCore*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtDesigner*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtGui*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtHelp*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtNetwork*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtOpenGL*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtScript*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtSql*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtSvg*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtTest*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtWebKit*")));
                    excludeModulesMaskList.push_back(tstring(_T("libQtXml*")));
                    //excludeModulesMaskList.push_back(tstring(_T("")));
                    #endif
                    excludeModulesMaskList.push_back(tstring(_T("cli2tls*")));
                    //excludeModulesMaskList.push_back(tstring(_T("")));
                   }

                //newEnd = ::std::unique(excludeModulesMaskList.begin(), excludeModulesMaskList.end(), MARTY_FILENAME::predEqual());
                //excludeModulesMaskList.erase(newEnd, excludeModulesMaskList.end());
                uniqueHelper(excludeModulesMaskList);

                ////////////////////////////

                if ((flags&ignoreStdExt)==0)
                   {
                    #ifdef _WIN32
                    extList.push_back(_T(".dll"));
                    #else
                    extList.push_back(_T(".so"));
                    #endif
                   }

                tstring strExts;
                if (::marty::env::getVar(envCache, tstring(_T("CLI2_EXT")), strExts))
                   {
                    #ifdef _WIN32
                    ::cli::util::CIsExactChar<TCHAR, CLI2_SYSTEM_PATHS_SEPARATOR> pred;
                    #else
                    ::cli::util::CIsExactChar<TCHAR, CLI2_SYSTEM_PATHS_SEPARATOR> pred;
                    #endif
                    ::cli::util::splitString(strExts, extList, pred);
                   }

                //::std::vector<tstring>::const_iterator
                //newEnd = ::std::unique(extList.begin(), extList.end(), MARTY_FILENAME_NS predEqual());
                //extList.erase(newEnd, extList.end());

                uniqueHelper(extList);

                if (extList.empty())
                   {
                    log()<<"CLI2 extension list empty, force adding standart extension\n";
                    #ifdef _WIN32
                    extList.push_back(_T(".dll"));
                    #else
                    extList.push_back(_T(".so"));
                    #endif
                   }


                log()<<"CLI2 extentions: ";
                //::std::vector<tstring>::const_iterator
                pit = extList.begin();
                for(; pit!=extList.end(); ++pit)
                   {
                    log()<<*pit<<" ";
                   }
                log()<<"\n";

                #endif /* CLI_MONOLITHIC */

/*

            const static int ignoreCliPath                 = 0x0001;
            const static int ignoreAppPath                 = 0x0002;
            const static int ignoreCliConfig               = 0x0004;
            const static int ignoreAppConfig               = 0x0008;
            const static int flagUseCache                  = 0x0010;
            const static int forceSingleProcessorStrategy  = 0x0020;
            const static int ignoreStdExt                  = 0x0040;


            ::std::vector<tstring>                     modPath;
            ::std::vector<tstring>                     extList;

                tstring val;
                log()<<"Getting value of "<<flagName<<" environment variable\n";

                if (!::marty::env::getVar(envCache, flagName, val))
                    log()<<"Environment variable not found, flag untouched\n";
                else
                   {
                    log()<<msg<<" - ";
                    if (val==tstring(_T("0")))
                       {
                        flags &= ~flagBitmask;
                        log()<<"off\n";
                       }
                    else
                       {
                        flags |=  flagBitmask;
                        log()<<"on\n";
                       }
                   }
*/

/*
void splitString( const ::std::basic_string<CharType, Traits, Allocator> &str
                , ::std::vector< ::std::basic_string<CharType, Traits, Allocator> > &strings
                , PredSepType predSep
                )
*/

               }



            class CLog
            {
                protected:
                   int           handle;
                   bool         *pNewLineFlag;


                public:
                   CLog(int h, bool *pnlf) : handle(h), pNewLineFlag(pnlf) {}
                   CLog(const CLog &l) : handle(l.handle), pNewLineFlag(l.pNewLineFlag) {}

                protected:

                   bool testHandle() const { return handle<1 ? false : true; }
                   bool isConsoleHandle() const { return handle<=2; }

                   #if !defined(_MSC_VER) || _MSC_VER<1400
                       #ifndef _sprintf
                           #define _sprintf sprintf
                           #define _snprintf snprintf
                           #define __cli2init_undef_sprintf
                       #endif
                   #endif

                   ::std::string getCurTimeStr() const
                      {
                       time_t timeVal;
                       time(&timeVal);

                       struct tm localTime;
                       char buf[128];
                       #ifdef _WIN32
                           #ifdef _MSC_VER
                               #ifdef _USE_32BIT_TIME_T
                                   _localtime32_s(&localTime,&timeVal);
                               #else
                                   _localtime64_s(&localTime,&timeVal);
                               #endif
                           #else
                           struct tm * tmp = localtime(&timeVal);
                           if (tmp)
                              {
                               memcpy( (void*)&localTime, (void*)tmp, sizeof(struct tm));
                              }
                           #endif
                       //asctime_s( buf, sizeof(buf)/sizeof(buf[0]), &localTime);
                       #else
                       localtime_r(&timeVal, &localTime);
                       //asctime_r(&localTime, buf);
                       #endif

                           static char wday_name[7][4] = {
                               "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
                           };
                           static char mon_name[12][4] = {
                               "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                           };
                           //static char result[26];

                           _snprintf(buf, sizeof(buf)/sizeof(buf[0])
                                    , "[%.3s %.3s%3d %.2d:%.2d:%.2d %d] "
                                    , wday_name[localTime.tm_wday]
                                    , mon_name[localTime.tm_mon]
                                    , localTime.tm_mday
                                    , localTime.tm_hour
                                    , localTime.tm_min
                                    , localTime.tm_sec
                                    , (int)(1900 + localTime.tm_year)
                                    );
                       return ::std::string(buf);
                      }

                   void writeString(const ::std::string &str) const
                      {
                       if (!testHandle()) return;

                       ::std::string res; res.reserve(str.size());
                       ::std::string::const_iterator it = str.begin();
                       for(; it!=str.end(); ++it)
                          {
                           if (pNewLineFlag && *pNewLineFlag)
                              {
                               res.append(getCurTimeStr());
                               *pNewLineFlag = false;
                              }

                           if (*it=='\n')
                              {
                               #ifdef _WIN32
                               if (!isConsoleHandle())
                                  res.append(1, '\r');
                               #endif
                               res.append(1, *it);
                               // res.append(1, ' ');
                               if (pNewLineFlag)
                                  *pNewLineFlag = true;
                              }
                           else
                              {
                               res.append(1, *it);
                              }
                          }
                       MARTY_FILESYSTEM_NS writeFile(handle, res.data(), (unsigned)res.size());

                       #if (defined(_WIN32) || defined(WIN32)) && defined(_DEBUG)
                       // if IsDebuggerPresent not found, uncomment #define WANT_ISDEBUGGERPRESENT_WRAPPER on top of  this file
                       #if defined(_MSC_VER)
                       if (IsDebuggerPresent())
                       #endif
                          {
                           OutputDebugStringW( MARTY_CON_NS strToWide(res, CP_OEMCP).c_str() );
                          }
                       #endif
                      }

                   void writeString(const ::std::wstring &str) const
                      {
                       if (!testHandle()) return;
                       #ifdef _WIN32
                       //writeString(MARTY_CON_NS strToAnsi(str));
                       writeString(MARTY_CON_NS str2con(str));
                       #else
                       writeString(MARTY_CON_NS str2con(str));
                       #endif
                      }


                   ::std::string intToStr(int i) const
                      {
                       char tmpBuf[128];
                       char *tmpBufPtr = tmpBuf;
                       _snprintf(tmpBuf, sizeof(tmpBuf)/sizeof(tmpBuf[0]), "%d", i);
                       tmpBuf[sizeof(tmpBuf)/sizeof(tmpBuf[0])-1] = 0;

                       ::std::string res;
                       for(; *tmpBufPtr; ++tmpBufPtr) res.append(1, *tmpBufPtr);
                       return res;
                      }

                   ::std::string intToStr(unsigned i) const
                      {
                       char tmpBuf[128];
                       char *tmpBufPtr = tmpBuf;
                       _snprintf(tmpBuf, sizeof(tmpBuf)/sizeof(tmpBuf[0]), "%X", i);
                       tmpBuf[sizeof(tmpBuf)/sizeof(tmpBuf[0])-1] = 0;

                       ::std::string res;
                       for(; *tmpBufPtr; ++tmpBufPtr) res.append(1, *tmpBufPtr);
                       return res;
                      }

                   #ifdef __cli2init_undef_sprintf
                       #undef __mbs_undef_sprintf
                       #undef _sprintf
                       #undef __cli2init_undef_sprintf
                   #endif

                public:

                   CLog& operator<<(const ::std::string &str)  { writeString(str); return *this; }
                   CLog& operator<<(const ::std::wstring &str) { writeString(str); return *this; }
                   CLog& operator<<(const char *str)           { if (str) writeString(::std::string(str)); return *this; }
                   CLog& operator<<(const wchar_t *str)        { if (str) writeString(::std::wstring(str)); return *this; }
                   CLog& operator<<(int i)                     { if (testHandle()) writeString(intToStr(i)); return *this; }
                   CLog& operator<<(unsigned i)                { if (testHandle()) writeString(intToStr(i)); return *this; }
                   CLog& operator<<(bool b)                    { writeString(::std::string(b?"1":"0")); return *this; }

            };





    }; // struct CCliOptions

    }; // namespace cli


#endif /* CLI_EMBEDDED */

#endif /* CORE_CLI2INIT_H */

