#ifndef CORE_CLIALLOC_H
#define CORE_CLIALLOC_H

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

#ifndef CLI_CLI2BASE_H
    #include <cli/cli2base.h>
#endif



// functions can't allocate mem portion with size greater than MAX SIZE_T (2^32)
// for big allocations use other APIs

EXTERN_C void* CLICALL cliAlloc(SIZE_T nBytesToAlloc);
EXTERN_C void* CLICALL cliCalloc(SIZE_T nItemsToAlloc, SIZE_T itemSize);
EXTERN_C void  CLICALL cliFree(void *pMem);
EXTERN_C void* CLICALL cliRealloc(void *pMem, SIZE_T nBytesToAlloc);
EXTERN_C void* CLICALL cliRecalloc(void *pMem, SIZE_T nItemsToAlloc, SIZE_T itemSize);


EXTERN_C void  CLICALL cliInitStaticAlloc(BYTE *buf, SIZE_T bufSize);
EXTERN_C void* CLICALL cliStaticAlloc(SIZE_T nBytesToAlloc);






#endif /* CORE_CLIALLOC_H */

