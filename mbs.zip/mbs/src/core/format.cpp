#define CLI_INTERNAL

#ifndef CLI_FORMAT_H
    #include <cli/format.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#include "alvariant.h"
#include "fp_AFormatParser_Automata.h"

#include <cli/interlocked.h>
#include "dateTimeHlp.h"

#ifndef SRC_CORE_CLRCONV_H
    #include "clrconv.h"
#endif


//-----------------------------------------------------------------------------
namespace cli
{
namespace format
{
namespace impl
{

//-----------------------------------------------------------------------------
const bool allowAutomataLogging = false;


//-----------------------------------------------------------------------------
class CFormatParserImpl : public CFormatParser
{
    public: 

    bool allowLogging;
    bool emptyOutOfRangeArgs;

    CFormatParserImpl( bool al
                     , ::std::wstring &buf
                     , INTERFACE_CLI_IARGLIST *pa
                     , DWORD flags
                     , const INT           *t
                     , SIZE_T               ts
                     )
       : CFormatParser()
       , allowLogging(al)
       , emptyOutOfRangeArgs(false)
       {
        pResBuf  = &buf;
        pArgs    = pa;
        tabs     = t;
        tabsSize = ts;
        bAllowAsciiCtrlChars = (flags&FMF_ALLOW_ASCII_CTRL_CHARS  ) ? true : false;
        bIgnoreFormatLf      = (flags&FMF_IGNORE_FORMAT_LF        ) ? true : false;
        fLongTabs            = (flags&FMF_LONG_TABS               ) ? true : false;
        emptyOutOfRangeArgs  = (flags&FMF_EMPTY_OUT_OF_RANGE_ARGS ) ? true : false;
        tabIndex = 0;
        formatGlobalFlags = flags;
       }

    void
    customResetAutomata
                       ( 
                       )
       {
        linePos = 0;

        #ifdef CLI_FORMAT_IMPL_CFORMATPARSER_LOGGING_USED
        if (allowLogging)
           {
            cliWriteLogStringC("-------- Start Format parser --------\n");
           }
        #endif

        return;
       }

    #ifdef CLI_FORMAT_IMPL_CFORMATPARSER_LOGGING_USED
    void
    logEvent
            ( int         eventTypeCode //!< 0x0100 - event info flag, 0x0200 - action info flag, 0 - event message, 0x0010 - guard variable (C++ only, if -GL2|-GL+ command line options used), 2 - event message on inadmissible event, 0x0101 - from, 0x0102 - to, 0x0103 - event, 0x0104 - quard, 0x0201 - entry action, 0x0202 - trigger action, 0x0203 - do action, 0x0204 - exit action
            , int         fromState    //!< transition start state, can be used for event filtration
            , int         toState      //!< transition end state, can be used for event filtration
            , const char *eventMsg     //!< from/to state name, event name, guard condition, entry/trigger/do/exit action text or info message
            )
       {
        if (allowLogging)
           {
            if (!eventTypeCode)
               cliWriteLogStringC("----------------\n");
            cliWriteLogStringC(eventMsg); cliWriteLogStringC("\n");
           }
       }
    #endif

    static const unsigned flagLeft      = 0x0001;
    static const unsigned flagPrecision = 0x0002;
    static const unsigned flagSign      = 0x0004;
    static const unsigned flagSpace     = 0x0008;
    static const unsigned flagOctotorp  = 0x0010;
    static const unsigned flagZero      = 0x0020;
    static const unsigned flagClass     = 0x0040;
    static const unsigned flagQuot      = 0x0080;


    ::std::wstring composeFormat(
                 const ::std::wstring &formatFlags 
               , const ::std::wstring &formatWidth 
               , const ::std::wstring &formatPrecision
               , const ::std::wstring &formatType  
                                   ) const
       {
        ::std::wstring str;
        str.append(formatFlags);
        str.append(formatWidth);
        if (!formatPrecision.empty())
           {
            str.append(1, L'.');
            str.append(formatPrecision);
           }
        str.append(formatType);
        return str;
       }

    ::std::wstring composeBadFormat(
                 const ::std::wstring &formatFlags 
               , const ::std::wstring &formatWidth 
               , const ::std::wstring &formatPrecision
               , const ::std::wstring &formatType  
                                   ) const
       {
        //::std::wstring(L"!");
        return ::std::wstring(L"!") + composeFormat(formatFlags, formatWidth, formatPrecision, formatType) + ::std::wstring(L"!");
       }

    ::std::wstring getAsString(int idx)
       {
        CCliStr tmp_str; CCliStr_init( tmp_str );
        pArgs->getString( idx , &tmp_str );
        ::std::wstring str;
        CCliStr_copyFromIfModified( str, tmp_str);
        return str;
       }

    wchar_t getIntChar( unsigned i, const wchar_t *strSymbols, unsigned strSymbolsLen )
       {
        if (i>=strSymbolsLen) return L'_';
        return strSymbols[i];
       }
    wchar_t getIntChar( unsigned i, bool bSmall )
       {
        static const wchar_t *symbols      = L"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        static const wchar_t *symbolsSmall = L"0123456789abcdefghijklmnopqrstuvwxyz";
        return getIntChar( i, bSmall?symbolsSmall:symbols, 36 );
       }

    #ifndef FORMAT_USE_OLD_INT_PRINTER
    ::std::wstring getAsInt64String(int idx, int width, int prec, const ::std::wstring &flags, unsigned uflags)
    #else
    ::std::wstring getAsInt64String(int idx, bool bHex, bool bSmall, int width, int prec, const ::std::wstring &flags)
    #endif
       {
        INT64 val;
        pArgs->getInt64( idx , &val );

        #ifndef FORMAT_USE_OLD_INT_PRINTER

        if (width<0) width = -width;
        if (prec<0)  prec  = -prec;

        if (uflags&flagLeft)
           uflags &= ~flagZero; // If 0 and - appear, the 0 is ignored

        if (uflags&flagPrecision)
           uflags &= ~flagZero; // If 0 is specified with an integer format (i, u, x, X, o, d) and a precision specification is also present (for example, %04.d), the 0 is ignored. 

        bool neg = false;
        if (val<0) { val = -val; neg = true; }

        const INT64 radix = 10;
        ::std::wstring resStr;
        for(; val!=0; )
           {
            resStr.append( 1, getIntChar( (unsigned)(val % radix), false ) );
            val /= radix;
           }
        //unsigned 
        int appendSign = 0;
        if (neg || uflags&flagSign)
           appendSign = 1;

        if (uflags&flagPrecision)
           {
            if ( (int)resStr.size() < prec )
               { //  ��������� ����� ������
                resStr.append( (::std::wstring::size_type)(prec - (int)resStr.size()), L'0' );
               }

            if (appendSign>0)
                resStr.append( 1, neg?L'-':L'+');

            if (!(uflags&flagLeft))
               {
                if ( (int)resStr.size() < width )
                   resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L' ' );
               }

            ::std::reverse(resStr.begin(), resStr.end());

            if (uflags&flagLeft)
               {
                if ( (int)resStr.size() < width )
                   resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L' ' );
               }           
           }
        else
           {
            width -= appendSign;
            if (width<0) width = 0;

            if ( (uflags&flagZero) && (int)resStr.size() < width )
               { //  ��������� ����� ������
                resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L'0' );
               }

            if (appendSign>0)
               {
                resStr.append( 1, neg?L'-':L'+');
               }           

            if (!(uflags&flagLeft))
               {
                if ( (int)resStr.size() < width )
                   resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L' ' );
               }

            ::std::reverse(resStr.begin(), resStr.end());

            if (uflags&flagLeft)
               {
                if ( (int)resStr.size() < width+appendSign )
                   resStr.append( (::std::wstring::size_type)(width + appendSign - (int)resStr.size()), L' ' );
               }           
           }





/*
                case '-' :  flags  |= flagLeft; break;
                case '+' :  flags  |= flagSign; break;
                case ' ' :  flags  |= flagSpace; break;
                case '\'':  flags  |= flagClass; break;
                case '#' :  flags  |= flagOctotorp; break;
                case '0' :  flags  |= flagZero; break;
                         // flagPrecision;
*/


        return ::std::wstring(resStr);

        #else
        ::std::wstring fmt = L"%";
        fmt.append(flags);

        if (width) 
           {
            //fmt.append(1, L'*');
            fmt.append( ::cli::arglist::impl::toStr((INT64)width) );
           }
        if (prec)
           {
            fmt.append(L".");
            if (prec<0) { prec = -prec; fmt.append(L"0"); }
            fmt.append( ::cli::arglist::impl::toStr((INT64)prec) );
            //fmt.append(L"*");
           }

        //if (width) fmt.append(1, L'*');
        //if (prec) fmt.append(L".*");
        if (bHex) 
           {
            if (bSmall) fmt.append(L"llx");
            else        fmt.append(L"llX");
           }
        else
           {
            fmt.append(L"lld");
           }

        WCHAR buf[256];
        #ifdef _WIN32
        _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), fmt.c_str(), val, width, prec );
        #else
        swprintf  (buf, sizeof(buf)/sizeof(buf[0]), fmt.c_str(), val, width, prec );
        #endif
        return ::std::wstring(buf);
        #endif
       }

    ::std::wstring formatRomanNumber(UINT64 arab, const wchar_t  **romanar)
       {
        const UINT64    arabar[]       = {  1,   4,    5,   9,    10,  40,  50,   90,  100, 400,  500, 900,  1000};
        //const wchar_t  *romanarUpper[] = { "I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"};

        const SIZE_T m            = sizeof(arabar)/sizeof(arabar[0])-1, arabmax=arabar[m];
        const wchar_t romanmax = romanar[m][0];
        
        if (!arab)
           {
            return ::std::wstring(L"-");
           }

        ::std::wstring roman;
        int  /* i = 0, */  n = 0;
        while(arab>arabmax)
           {
            //roman[i++] = romanmax;
            roman.append(1, romanmax);
            arab -= arabmax;
           }
        n=m;
        while(arab > 0)
           {
            if (arab >= arabar[n])
               {
                //roman[i++] = romanar[n][0];
                roman.append(1, romanar[n][0]);
                if (n&1)
                   {
                    //roman[i++] = romanar[n][1];
                    roman.append(1, romanar[n][1]);
                   }
                arab -= arabar[n];
               }
            else
               {
                n--;
               }
           }
        //roman[i]=0;
        return roman;
       }

    ::std::wstring getAsUInt64RomanString(int idx, bool bSmall, int width, int prec, const ::std::wstring &flags, unsigned uflags)
       {
        // width, prec, flags, uflags are ignored, reserved for future use
        UINT64 val;
        pArgs->getUInt64( idx , &val );
        ::std::wstring romanString;

        if (!bSmall)
           {
            const wchar_t  *romanarUpper[] = { L"I", L"IV", L"V", L"IX", L"X", L"XL", L"L", L"XC", L"C", L"CD", L"D", L"CM", L"M"};
            romanString = formatRomanNumber( val, romanarUpper );
           }
        else
           {
            const wchar_t  *romanarLower[] = { L"i", L"iv", L"v", L"ix", L"x", L"xl", L"l", L"xc", L"c", L"cd", L"d", L"cm", L"m"};
            romanString = formatRomanNumber( val, romanarLower );
           }

        width -= (int)romanString.size();
        if (width<0) width = 0;
        if (uflags&flagLeft)
           return romanString + ::std::wstring( (SIZE_T)width, L' ');
        else
           return ::std::wstring( (SIZE_T)width, L' ') + romanString;
       }

    ::std::wstring getAsUInt64String(int idx, unsigned radix, bool bSmall, int width, int prec, const ::std::wstring &flags, unsigned uflags)
       {
        UINT64 val;
        pArgs->getUInt64( idx , &val );

        if (radix<2) radix = 2;
        if (radix>=36) radix = 36;
        //bool bHex = (radix==16);

        #ifndef FORMAT_USE_OLD_INT_PRINTER

        if (width<0) width = -width;
        if (prec<0)  prec  = -prec;

        if (uflags&flagLeft)
           uflags &= ~flagZero; // If 0 and - appear, the 0 is ignored

        if (uflags&flagPrecision)
           uflags &= ~flagZero; // If 0 is specified with an integer format (i, u, x, X, o, d) and a precision specification is also present (for example, %04.d), the 0 is ignored. 


        unsigned addOctotorp = 0;
        wchar_t octoChar = L' ';
        if (uflags&flagOctotorp)
           {
            if (radix==2) { addOctotorp = 2; octoChar = bSmall ? L'b' : L'B'; }
            else if (radix==16) { addOctotorp = 2; octoChar = bSmall ? L'x' : L'X'; }
            else if (radix==8)  { addOctotorp = 2; } // for octal, add only zero as prefix
           }

        ::std::wstring resStr;
        for(; val!=0; )
           {
            resStr.append( 1, getIntChar( (unsigned)(val % radix), bSmall ) );
            val /= radix;
           }

        
        if (uflags&flagPrecision)
           {
            if ( (int)resStr.size() < prec )
               { //  ��������� ����� ������
                resStr.append( (::std::wstring::size_type)(prec - (int)resStr.size()), L'0' );
               }
            if (addOctotorp)
               {
                if (addOctotorp>1) resStr.append( 1, octoChar );
                resStr.append( 1, L'0' );
               }

            //width += addOctotorp;

            if (!(uflags&flagLeft))
               {
                if ( (int)resStr.size() < width )
                   resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L' ' );
               }

            ::std::reverse(resStr.begin(), resStr.end());

            if (uflags&flagLeft)
               {
                if ( (int)resStr.size() < width )
                   resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L' ' );
               }
           }
        else // precision not taken
           {
            //width += addOctotorp;

            if (uflags&flagLeft)
               {
                if (addOctotorp)
                   {
                    if (addOctotorp>1) resStr.append( 1, octoChar );
                    resStr.append( 1, L'0' );
                   }
                
                ::std::reverse(resStr.begin(), resStr.end());
                if ( (int)resStr.size() < width )
                   resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L' ' );
               }
            else // align right
               {
                int zeroFillWidth = width - addOctotorp;
                if (!(uflags&flagZero))
                   zeroFillWidth = 0;
                else if (zeroFillWidth<0) zeroFillWidth = 0;
                if ( (int)resStr.size() < zeroFillWidth )
                   resStr.append( (::std::wstring::size_type)(zeroFillWidth - (int)resStr.size()), L'0' );
                if (addOctotorp)
                   {
                    if (addOctotorp>1) resStr.append( 1, octoChar );
                    resStr.append( 1, L'0' );
                   }

                //width -= addOctotorp;
                if (width<0) width = 0;

                if (!(uflags&flagLeft))
                   {
                    if ( (int)resStr.size() < width )
                       resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L' ' );
                   }
    
                ::std::reverse(resStr.begin(), resStr.end());
    
                if (uflags&flagLeft)
                   {
                    if ( (int)resStr.size() < width )
                       resStr.append( (::std::wstring::size_type)(width - (int)resStr.size()), L' ' );
                   }
               }
           }

        return resStr;

        #else // old version
        ::std::wstring fmt = L"%";
        fmt.append(flags);

        if (width) 
           {
            //fmt.append(1, L'*');
            fmt.append( ::cli::arglist::impl::toStr((INT64)width) );
           }
        if (prec)
           {
            fmt.append(L".");
            if (prec<0) { prec = -prec; fmt.append(L"0"); }
            fmt.append( ::cli::arglist::impl::toStr((INT64)prec) );
            //fmt.append(L"*");
           }

        //if (width) fmt.append(1, L'*');
        //if (prec) fmt.append(L".*");
        if (bHex) 
           {
            if (bSmall) fmt.append(L"llx");
            else        fmt.append(L"llX");
           }
        else
           {
            fmt.append(L"llu");
           }

        WCHAR buf[256];
        #ifdef _WIN32
        _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), fmt.c_str(), val, width, prec );
        #else
        swprintf  (buf, sizeof(buf)/sizeof(buf[0]), fmt.c_str(), val, width, prec );
        #endif
        return ::std::wstring(buf);
        #endif
       }

    ::std::wstring getAsDoubleString(int idx, int width, int prec, const ::std::wstring &flags, const ::std::wstring &type)
       {
        double val;
        pArgs->getDouble( idx , &val );
        ::std::wstring fmt = L"%";
        fmt.append(flags);
        if (width) 
           {
            //fmt.append(1, L'*');
            fmt.append( ::cli::impl::toStr((INT64)width) );
           }
        if (prec)
           {
            fmt.append(L".");
            if (prec<0) { prec = -prec; fmt.append(L"0"); }
            fmt.append( ::cli::impl::toStr((INT64)prec) );
            //fmt.append(L"*");
           }
        fmt.append(type);

        WCHAR buf[256];
        #ifdef _WIN32
        _snwprintf(buf, sizeof(buf)/sizeof(buf[0]), fmt.c_str(), val, width, prec );
        #else
        swprintf  (buf, sizeof(buf)/sizeof(buf[0]), fmt.c_str(), val, width, prec );
        #endif
        return ::std::wstring(buf);
       }


    bool parseFormatFlags( const ::std::wstring& strFlags, unsigned &uFlags )
       {
        uFlags = 0;
        ::std::wstring::size_type i = 0, size = strFlags.size();
        for(; i!=size; ++i)
           {
            switch(strFlags[i])
               {
                case '-' :  uFlags  |= flagLeft; break;
                case '+' :  uFlags  |= flagSign; break;
                case ' ' :  uFlags  |= flagSpace; break;
                case '\'':  uFlags  |= flagClass; break;
                case '#' :  uFlags  |= flagOctotorp; break;
                case '0' :  uFlags  |= flagZero; break;
                case 'q' :  uFlags  |= flagQuot; break;
                         // flagPrecision;
                default: // wrong format
                    //str = getAsString(valIdx) + composeBadFormat(_formatFlags, formatWidth, formatPrecision, formatType);
                    return false;
               }
           }
        return true;
       }

    ::std::wstring makeQuotedString( const ::std::wstring &str, DWORD quoteFlags )
       {
        quoteFlags &= FMF_QUTATION_MASK;
        //if (!quoteFlags) return str;
        switch(quoteFlags)
           {
            case FMF_QUOTE_SQL:  
                   {
                    ::std::wstring tmp; // ( 1, L'\'' );
                    tmp.reserve(str.size()+2);
                    tmp.append( 1, L'\'' );
                    ::std::wstring::size_type i = 0, size = str.size();
                    for(; i!=size; ++i)
                       {
                        if (str[i]==L'\'') tmp.append( 1, L'\'' );
                        tmp.append( 1, str[i] );
                       }
                    tmp.append( 1, L'\'' );
                    //tmp.swap(str);
                    return tmp;
                   }
            case FMF_QUOTE_APOS:
                   return ::std::wstring(1,L'\'') + str + ::std::wstring(1,L'\'');

            case FMF_QUOTE_QUOT:
                   return ::std::wstring(1,L'\"') + str + ::std::wstring(1,L'\"');

            case FMF_QUOTE_XML:
                   {
                    ::std::wstring tmp; tmp.reserve(str.size()+2);
                    ::std::wstring::size_type i = 0, size = str.size();
                    for(; i!=size; ++i)
                       {
                        switch(str[i])
                           {
                            case L'\'':  tmp.append(L"&apos;"); break;
                            case L'\"':  tmp.append(L"&quot;"); break;
                            case L'&' :  tmp.append(L"&amp;"); break;
                            case L'<' :  tmp.append(L"&lt;"); break;
                            case L'>' :  tmp.append(L"&gt;"); break;
                            default:     tmp.append( 1, str[i] );
                           }
                       }
                    return tmp;
                   }

            case FMF_QUOTE_CSV:
                   {
                    ::std::wstring tmp; tmp.reserve(str.size()+2);
                    ::std::wstring::size_type i = 0, size = str.size();
                    bool needQuote = false;
                    for(; i!=size; ++i)
                       {
                        switch(str[i])
                           {
                            case L'\t': 
                            case L'\n': 
                            case L'\r': 
                            case L'\b': 
                            case L'\"': 
                            case L',': 
                            case L';': 
                                 if (str[i]==L'\"') tmp.append( 1, str[i] ); // make dup
                                 tmp.append( 1, str[i] );
                                 needQuote = true;
                            default:     tmp.append( 1, str[i] );
                           }
                       }
                    if (needQuote) return ::std::wstring(1,L'\"') + tmp + ::std::wstring(1,L'\"');
                    return tmp;
                   }

            default: return str;           
           }
       }


    void
    formatCustom
                ( ::std::wstring       &str         
                , int                   idx         
                , const ::std::wstring &formatFlags 
                , const ::std::wstring &formatWidth 
                , const ::std::wstring &formatPrecision
                , const ::std::wstring &formaterName
                , const ::std::wstring &_customFormatStr
                , DWORD                 formatGlobalFlags
                )
       {
        //if (!pArgs) return;

        int valIdx = idx++;


        //::std::wstring tmp;
        /*
        if (!pArgs || (pArgs->getCount() >= (SIZE_T)valIdx && emptyOutOfRangeArgs))
           {
            // simply formata empty string
           }
        */
        ::std::wstring customFormatStr = _customFormatStr;

        unsigned flags = 0;
        if (!parseFormatFlags( formatFlags, flags ))
           {
            str = getAsString(valIdx) + composeBadFormat( formatFlags, formatWidth, formatPrecision
                                                        , ::std::wstring(L":") + formaterName + ::std::wstring(L":") + _customFormatStr);
            return;
           }


       INT width = 0;
       if (!formatWidth.empty())
          {
           if (formatWidth[0]==L'*')
              {
               INT w = 0;
               pArgs->getInt( idx++ , &w );
               if (w<0) width = -w;
               else     width = w;
              }
           else
              {
               for(::std::wstring::size_type i=0; i<formatWidth.size(); ++i)
                  {
                   if (formatWidth[i]>=L'0' && formatWidth[i]<=L'9')
                      {
                       width *= 10; width += formatWidth[i] - L'0';
                      }
                   else
                      {
                       str = getAsString(valIdx) + composeBadFormat( formatFlags, formatWidth, formatPrecision
                                                                   , ::std::wstring(L":") + formaterName + ::std::wstring(L":") + _customFormatStr);
                       return;
                      }
                  }
              }
          }

       INT precision = 0;
       bool floatFlagZero = false;
       if (!formatPrecision.empty())
          {
           flags |= flagPrecision;
           if (formatPrecision[0]==L'*')
              {
               INT p = 0;
               pArgs->getInt( idx++ , &p );
               if (p<0) precision = -p;
               else     precision = p;
              }
           else
              {
               ::std::wstring::size_type i=0;
               if (formatPrecision[0]!=L'.')
                  {
                   str = getAsString(valIdx) + composeBadFormat( formatFlags, formatWidth, formatPrecision
                                                               , ::std::wstring(L":") + formaterName + ::std::wstring(L":") + _customFormatStr);
                   return;
                  }
               ++i;
               if (i<formatPrecision.size() && formatPrecision[0]==L'0')
                  {
                   floatFlagZero = true;
                   ++i;
                  }

               for( ; i<formatPrecision.size(); ++i)
                  {
                   if (formatPrecision[i]>=L'0' && formatPrecision[i]<=L'9')
                      {
                       precision *= 10; precision += formatPrecision[i] - L'0';
                      }
                   else
                      {
                       str = getAsString(valIdx) + composeBadFormat( formatFlags, formatWidth, formatPrecision
                                                                   , ::std::wstring(L":") + formaterName + ::std::wstring(L":") + _customFormatStr);
                       return;
                      }
                  }
              }
          }

        if (_customFormatStr==L"*")
           {
            int fmtIdx = idx;
            customFormatStr = getAsString(fmtIdx);
           }


        //str = ::cli::format::customFormat( MARTY_CON_NS strToAnsi(formaterName), customFormatStr, pArgs, valIdx );
        //str = ::cli::format::customFormat( formaterName, customFormatStr, pArgs, valIdx );

        ::std::wstring tmp = ::cli::format::customFormat( formaterName, customFormatStr, pArgs, valIdx );
        if ((flags&flagPrecision) && precision)
           {
            if (tmp.size()>(::std::wstring::size_type)precision)
               {
                tmp.erase( (::std::wstring::size_type)precision, ::std::wstring::npos );
               }
           }
 
        if (width && (INT)tmp.size() < width)
           {
            if (!(flags&flagLeft))
               str.append( SIZE_T(width - (INT)tmp.size()), L' ');
            str.append(tmp);
            if (flags&flagLeft)
               str.append( SIZE_T(width - (INT)tmp.size()), L' ');
           }
        else
           {
            str = tmp;
           }

        str = makeQuotedString( str, formatGlobalFlags );
       }




    //::std::wstring       &str

    void
    formatValue
               ( ::std::wstring       &str         
               , int                   idx         
               , const ::std::wstring &_formatFlags 
               , const ::std::wstring &formatWidth 
               , const ::std::wstring &formatPrecision
               , const ::std::wstring &formatType 
               , DWORD                 formatGlobalFlags
               )
       {
        if (!pArgs) return; // empty string
        //if (formatType.empty()) formatType = L"s"; // default - string
        int valIdx = idx++;

        //if (formatGlobalFlags&FMF_EMPTY_ARG_AS_NA)
        //FMF_EMPTY_ARG_AS_NA

        if ((SIZE_T)valIdx >= pArgs->getCount())
           {
            if (formatGlobalFlags&FMF_EMPTY_OUT_OF_RANGE_ARGS) // (emptyOutOfRangeArgs)
               {
                return; // simply return empty string
               }
            else if (formatGlobalFlags&FMF_EMPTY_ARG_AS_NA)
               {
                str = L"N/A"; // Not Available string
                return;
               }              
           }
        else // index is good (in range of arg count)
           {
            if (pArgs->getType((SIZE_T)valIdx)==CLI_VARIANTTYPE_VT_EMPTY && formatGlobalFlags&FMF_EMPTY_ARG_AS_NA)
               {
                str = L"N/A"; // Not Available string
                return;
               }
           }

        unsigned flags = 0;
        if (!parseFormatFlags( _formatFlags, flags ))
           {
            str = getAsString(valIdx) + composeBadFormat(_formatFlags, formatWidth, formatPrecision, formatType);
            return;
           }

       ::std::wstring formatFlags;
       //formatFlags.clear();

       if (flags&flagLeft)
          formatFlags.append(1, L'-');

       if (flags&flagSign)
          formatFlags.append(1, L'+');

       //if (flags&flagOctotorp)
       //   formatFlags.append(1, L'');

       if (flags&flagZero)
          formatFlags.append(1, L'0');

       if (flags&flagSpace)
          formatFlags.append(1, L' ');

       //#define FORMAT_VALUE_FMT_CLASS_SUPPORTED
       #ifdef FORMAT_VALUE_FMT_CLASS_SUPPORTED
       if (flags&flagClass)
          formatFlags.append(1, L'\'');
       #endif

       INT width = 0;
       if (!formatWidth.empty())
          {
           if (formatWidth[0]==L'*')
              {
               INT w = 0;
               pArgs->getInt( idx++ , &w );
               if (w<0) width = -w;
               else     width = w;
              }
           else
              {
               for(::std::wstring::size_type i=0; i<formatWidth.size(); ++i)
                  {
                   if (formatWidth[i]>=L'0' && formatWidth[i]<=L'9')
                      {
                       width *= 10; width += formatWidth[i] - L'0';
                      }
                   else
                      {
                       str = getAsString(valIdx) + composeBadFormat(formatFlags, formatWidth, formatPrecision, formatType);
                       return;
                      }
                  }
              }
          }

       INT precision = 0;
       bool floatFlagZero = false;
       if (!formatPrecision.empty())
          {
           flags |= flagPrecision;
           if (formatPrecision[0]==L'*')
              {
               INT p = 0;
               pArgs->getInt( idx++ , &p );
               if (p<0) precision = -p;
               else     precision = p;
              }
           else
              {
               ::std::wstring::size_type i=0;
               if (formatPrecision[0]!=L'.')
                  {
                   str = getAsString(idx) + composeBadFormat(formatFlags, formatWidth, formatPrecision, formatType);
                   return;
                  }
               ++i;
               if (i<formatPrecision.size() && formatPrecision[0]==L'0')
                  {
                   floatFlagZero = true;
                   ++i;
                  }

               for( ; i<formatPrecision.size(); ++i)
                  {
                   if (formatPrecision[i]>=L'0' && formatPrecision[i]<=L'9')
                      {
                       precision *= 10; precision += formatPrecision[i] - L'0';
                      }
                   else
                      {
                       str = getAsString(idx) + composeBadFormat(formatFlags, formatWidth, formatPrecision, formatType);
                       return;
                      }
                  }
              }
          }

       if (floatFlagZero) precision = -precision;

       if (formatType==L"d" || formatType==L"D" || formatType==L"i" || formatType==L"I")
          str = getAsInt64String(valIdx, width, precision, formatFlags, flags);
       else if (formatType==L"u" || formatType==L"U")
          {
           str = getAsUInt64String(valIdx, 10, false, width, precision, formatFlags, flags); 
          }
       else if (formatType==L"r")
          {
           str = getAsUInt64RomanString(valIdx, true, width, precision, formatFlags, flags); 
          }
       else if (formatType==L"R")
          {
           str = getAsUInt64RomanString(valIdx, false, width, precision, formatFlags, flags); 
          }
       else if (formatType==L"x")
          { 
           //if (flags&flagOctotorp) str.append(L"0x"); 
           str.append(getAsUInt64String(valIdx, 16, true, width, precision, formatFlags, flags));
          }
       else if (formatType==L"p")
          { 
           //if (flags&flagOctotorp) str.append(L"0x"); 
           int ptrSize = 8; // size in symbols
           #if SIZEOF_SIZE_T>4
           ptrSize = 16;
           #endif
           if (flags&flagOctotorp) ptrSize += 2;
           str.append(getAsUInt64String(valIdx, 16, true, (width ? width : ptrSize), precision, formatFlags, (width ? flags : flags|flagZero) ));
          }
       else if (formatType==L"X")
          { 
           //if (flags&flagOctotorp) str.append(L"0X");
           str.append(getAsUInt64String(valIdx, 16, false, width, precision, formatFlags, flags));
          }
       else if (formatType==L"P")
          { 
           //if (flags&flagOctotorp) str.append(L"0X");
           int ptrSize = 8; // size in symbols
           #if SIZEOF_SIZE_T>4
           ptrSize = 16;
           #endif
           if (flags&flagOctotorp) ptrSize += 2;
           str.append(getAsUInt64String(valIdx, 16, false, (width ? width : ptrSize), precision, formatFlags, (width ? flags : flags|flagZero)));
          }
       else if (formatType==L"o" || formatType==L"O")
          { 
           str.append(getAsUInt64String(valIdx, 8, false, width, precision, formatFlags, flags));
          }
       else if (formatType==L"b" || formatType==L"B")
          { 
           //if (flags&flagOctotorp) str.append( ((formatType==L"b") ? L"0b" : L"0B")); 
           str.append(getAsUInt64String(valIdx, 2, false, width, precision, formatFlags, flags));
          }
       else if (formatType==L"g" || formatType==L"G" || formatType==L"a" || formatType==L"A" || formatType==L"e" || formatType==L"E" || formatType==L"f" || formatType==L"F")
          str = getAsDoubleString(valIdx, width, precision, formatFlags, formatType);
       else if (formatType==L"c" || formatType==L"C")
          {
           WCHAR ch;
           pArgs->getWChar( valIdx , &ch );
           if (formatType==L"C")
              {
               ch &= 0xFF;
               if (ch==L'\n') str = L"\\n";
               else if (ch==L'\r') str = L"\\r";
               else if (ch==L'\t') str = L"\\t";
               else if (ch<L' ')
                  {
                   str = L"\\0x";
                   str.append(getAsUInt64String(valIdx, 16, true, 0, 0, ::std::wstring(), 0 ));
                  }
               else
                  {
                   str.append(1, ch);
                  }
              }
           else
              {
               str.append(1, ch);
              }
          }
       else
          {
           ::std::wstring tmp = getAsString(valIdx);
           if ((flags&flagPrecision) && precision)
              {
               if (tmp.size()>(::std::wstring::size_type)precision)
                  {
                   tmp.erase( (::std::wstring::size_type)precision, ::std::wstring::npos );
                  }
              }

           if (width && (INT)tmp.size() < width)
              {
               if (!(flags&flagLeft))
                  str.append( SIZE_T(width - (INT)tmp.size()), L' ');
               str.append(tmp);
               if (flags&flagLeft)
                  str.append( SIZE_T(width - (INT)tmp.size()), L' ');
              }
           else
              {
               str = tmp;
              }
          }

       str = makeQuotedString( str, formatGlobalFlags );

       // getAsUInt64String(bool bHex, bool bSmall)
       //ws


        /*
        if (fmt.empty())
           { // assume plain string
            CCliStr tmp_str; CCliStr_init( tmp_str );
            pArgs->getString( idx , &tmp_str );
            CCliStr_copyFromIfModified( str, tmp_str);
           }
        else
           { // at this moment, same as above
            CCliStr tmp_str; CCliStr_init( tmp_str );
            pArgs->getString( idx , &tmp_str );
            CCliStr_copyFromIfModified( str, tmp_str);
           }
        */
       }


}; // class CFormatParserImpl


static ilint_t cliFormatMessageInitFlag = 0;

//-----------------------------------------------------------------------------
void
cliFormatMessage( ::std::wstring &strBuf
                , const WCHAR *fmtString
                , INTERFACE_CLI_IARGLIST* pArgs
                , DWORD flags /* FMF_* */
                , const INT *tabs
                , SIZE_T tabsSize
                )
   {
    if (interlockedCompareExchange( &cliFormatMessageInitFlag, 1, 0))
       {
        cliRegisterFormaterProc( L"datetime", &::cli::format::impl::dateTimeFormaterImpl);
        cliRegisterFormaterProc( L"time"    , &::cli::format::impl::timeFormaterImpl);
        cliRegisterFormaterProc( L"tmdiff"  , &::cli::format::impl::timeFormaterImpl);
        cliRegisterFormaterProc( L"deg"     , &::cli::format::impl::degreeFormaterImpl);
        cliRegisterFormaterProc( L"degree"  , &::cli::format::impl::degreeFormaterImpl);
        cliRegisterFormaterProc( L"clr"     , &::cli::format::impl::colorrefFormaterImpl);
        cliRegisterFormaterProc( L"color"   , &::cli::format::impl::colorrefFormaterImpl);
        cliRegisterFormaterProc( L"colorref", &::cli::format::impl::colorrefFormaterImpl);
        // call autoregistrations here
       }

    if (!fmtString) { if (pArgs) pArgs->release(); return; }

    if (!pArgs) pArgs = cliGetArgList();
    //if (fmtString)
    //   strBuf = fmtString;

    CFormatParserImpl parser( allowAutomataLogging, strBuf, pArgs, flags, tabs, tabsSize);
    parser.resetAutomata( );

    while(*fmtString)
       parser.putChar(*fmtString++);

    parser.eod();

    pArgs->release();

    if (!strBuf.empty() && strBuf[strBuf.size()-1]!=L'\n' && (flags& FMF_AUTO_APPEND_LF))
       strBuf.append(1,'\n');
    // return 0;
   }

//-----------------------------------------------------------------------------

}; // namespace impl
}; // namespace format
}; // namespace cli
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
CLIAPIENTRY
RCODE
CLICALL
cliFormatMessageEx( CLIPSTR *resStr
                  , const WCHAR *fmtString
                  , INTERFACE_CLI_IARGLIST* pArgs
                  , DWORD flags /* FMF_* */
                  , const INT *tabs
                  , SIZE_T tabsSize
                  )
   {
    ::std::wstring strBuf;
    ::cli::format::impl::cliFormatMessage( strBuf, fmtString, pArgs, flags, tabs, tabsSize );

    if (resStr)
       clipstr_alloc( resStr, strBuf.c_str() );
    return EC_OK;
   }

//-----------------------------------------------------------------------------
CLIAPIENTRY
RCODE
CLICALL
cliFormatMessage( CLIPSTR *resStr
                , const WCHAR *fmtString
                , INTERFACE_CLI_IARGLIST* pArgs
                )
   {
    return cliFormatMessageEx(resStr, fmtString, pArgs, FMF_IGNORE_ASCII_CTRL_CHARS, 0, 0 );
   }

//-----------------------------------------------------------------------------
CLIAPIENTRY
RCODE
CLICALL
cliWriteLogMessageEx( const WCHAR *fmtString
                    , INTERFACE_CLI_IARGLIST* pArgs
                    , DWORD flags /* FMF_* */
                    , const INT *tabs
                    , SIZE_T tabsSize
                    )
   {
    ::std::wstring strBuf;
    ::cli::format::impl::cliFormatMessage( strBuf, fmtString, pArgs, flags, tabs, tabsSize );
    cliWriteLogStringW( strBuf.c_str() );
    return EC_OK;   
   }

//-----------------------------------------------------------------------------
CLIAPIENTRY
RCODE
CLICALL
cliWriteLogMessage( const WCHAR *fmtString
                  , INTERFACE_CLI_IARGLIST* pArgs
                  )
   {
    return cliWriteLogMessageEx(fmtString, pArgs, FMF_ALLOW_ASCII_CTRL_CHARS|FMF_AUTO_APPEND_LF, 0, 0 );
   }

//-----------------------------------------------------------------------------


