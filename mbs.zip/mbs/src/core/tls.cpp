#define CLI_INTERNAL

//#include <cli/tls.h>
#include "tlsimpl.h"
#include "tlsdata.h"


/* Need to be called at cli startup */
TLS_INDEX_T
CLICALL
cliGetCliTlsIndex( );

/* Need to be called at cli cleanup */
VOID
CLICALL
cliFreeCliTlsIndex( );

BOOL
CLICALL
cliIsCliTlsIndexAllocated( VOID *pData );



//-----------------------------------------------------------------------------
#if defined(WIN32) || defined(_WIN32)
#if !defined(CLI_MONOLITHIC) && !defined(CLI_MONOLITH)
static CLI_TLS_DESTUCTION_FN cliTlsDestructor = 0;


VOID
CLICALL
cliCallTlsDestructorFunction( )
   {
    if (cliTlsDestructor) cliTlsDestructor();
   }

CLIAPIENTRY
CLI_TLS_DESTUCTION_FN
CLICALL
cliSetTlsDestructorFunction( CLI_TLS_DESTUCTION_FN pfn )
   {
    CLI_TLS_DESTUCTION_FN ret = cliTlsDestructor;
    cliTlsDestructor = pfn;
    return ret;
   }

CLIAPIENTRY
CLI_TLS_DESTUCTION_FN
CLICALL
cliGetTlsDestructorFunction( )
   {
    return cliTlsDestructor;
   }

#endif // !defined(CLI_MONOLITHIC) && !defined(CLI_MONOLITH)
#endif // defined(WIN32) || defined(_WIN32)

//-----------------------------------------------------------------------------
static TLS_INDEX_T cliTlsIndex = INVALID_TLS_INDEX;

//-----------------------------------------------------------------------------

#if defined(WIN32) || defined(_WIN32)
static CLI_TLS_KEY_DESTUCTION_FN pfnCliTlsKeyDestructor = 0;

void CLICALL cliInternalTlsDestructor();
void CLICALL cliInternalTlsDestructor()
   {
    if (pfnCliTlsKeyDestructor && cliTlsIndex!=INVALID_TLS_INDEX)
       pfnCliTlsKeyDestructor(TlsGetValue(cliTlsIndex));
   }

void CLICALL cliTlsKeyDestructor( void * pvKeyValue );
void CLICALL cliTlsKeyDestructor( void * pvKeyValue )
#else
void cliTlsKeyDestructor(void *pvKeyValue);
void cliTlsKeyDestructor(void *pvKeyValue)
#endif
   { // cliTlsKeyDestructor function code
    ::cli::CThreadLocalData *pData = (::cli::CThreadLocalData*)pvKeyValue;
    delete pData;
    cliSetCliTlsData( 0 );
   }


class CInitCliTlsClass
{
    public:
        CInitCliTlsClass()
           {
            #if defined(WIN32) || defined(_WIN32)
            cliSetTlsDestructorFunction( cliInternalTlsDestructor );
            pfnCliTlsKeyDestructor = cliTlsKeyDestructor;
            #endif
            cliGetCliTlsIndex( );
           }
        ~CInitCliTlsClass()
           {
            
            #if !defined(CLI_MONOLITHIC) && !defined(CLI_MONOLITH)
            #if defined(WIN32) || defined(_WIN32)
            cliCallTlsDestructorFunction( );
            #else
            //TLS_INDEX_T cliTlsIdx = cliGetCliTlsIndex( );
            //if (cliTlsIndex!=INVALID_TLS_INDEX)
            //    cliTlsKeyDestructor(pthread_getspecific(cliTlsIdx));
            #endif
            #endif

            cliFreeCliTlsIndex( );
           }
};


CInitCliTlsClass initCliTlsObj;


//-----------------------------------------------------------------------------
TLS_INDEX_T
CLICALL
cliGetCliTlsIndex( )
   {
    if (cliTlsIndex==INVALID_TLS_INDEX)
       { // allocate index
        #if defined(WIN32) || defined(_WIN32)
        cliTlsIndex = TlsAlloc();
        #else
        if (pthread_key_create(&cliTlsIndex, &cliTlsKeyDestructor))
           cliTlsIndex = INVALID_TLS_INDEX;
        #endif
       }
    return cliTlsIndex;
   }

//-----------------------------------------------------------------------------
VOID
CLICALL
cliFreeCliTlsIndex( )
   {
    if (cliTlsIndex!=INVALID_TLS_INDEX)
       {
        #if defined(WIN32) || defined(_WIN32)
        TlsFree( cliTlsIndex );
        #else
        pthread_key_delete(cliTlsIndex);
        #endif
        cliTlsIndex = INVALID_TLS_INDEX;
       }
   }

//-----------------------------------------------------------------------------
BOOL
CLICALL
cliIsCliTlsIndexAllocated( VOID *pData )
   {
    return cliTlsIndex!=INVALID_TLS_INDEX ? TRUE : FALSE;
   }

//-----------------------------------------------------------------------------
VOID*
CLICALL
cliGetCliTlsData( )
   {
    TLS_INDEX_T cliTlsIdx = cliGetCliTlsIndex( );
    if (cliTlsIndex==INVALID_TLS_INDEX) return 0;
    #if defined(WIN32) || defined(_WIN32)
    return TlsGetValue(cliTlsIdx);
    #else
    return pthread_getspecific(cliTlsIdx);
    #endif
   }

//-----------------------------------------------------------------------------
BOOL
CLICALL
cliSetCliTlsData( VOID *pData )
   {
    TLS_INDEX_T cliTlsIdx = cliGetCliTlsIndex( );
    if (cliTlsIndex==INVALID_TLS_INDEX) return FALSE;
    #if defined(WIN32) || defined(_WIN32)
    if (TlsSetValue(cliTlsIdx, pData)) return TRUE;
    #else
    if (!pthread_setspecific(cliTlsIdx, pData)) return TRUE;
    #endif
    return FALSE;
   }

//-----------------------------------------------------------------------------
CLIAPIENTRY
VOID
CLICALL
cliTouchTls( )
   {
    ::cli::CThreadLocalData::get();
   }


