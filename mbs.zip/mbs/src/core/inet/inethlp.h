#ifndef CORE_INET_INETHLP_H
#define CORE_INET_INETHLP_H

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif


#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_INC_MEMORY) && !defined(_MEMORY_H_) && !defined(_MEMORY_H)
    #include <memory.h>
#endif


#if defined(_WIN32) || defined(WIN32)
    #if defined(__GNUC__) // mingw has wrong headers
        #if (_WIN32_WINNT < 0x0501) // getaddrinfo not defined for WinVer 0x0501 or less
            #ifdef __cplusplus
            extern "C"{
            #endif
            void WSAAPI freeaddrinfo (struct addrinfo*);
            int WSAAPI getaddrinfo (const char*,const char*,const struct addrinfo*,
                            struct addrinfo**);
            int WSAAPI getnameinfo(const struct sockaddr*,socklen_t,char*,DWORD,
                           char*,DWORD,int);
            #ifdef __cplusplus
            };
            #endif
        #endif

        // MinGW has not typedefs below
        #ifndef MINGW_HAS_GETADDRINFOW

        #include <cli/pshpack4.h>
        typedef struct addrinfoW
        {
            int                 ai_flags;       // AI_PASSIVE, AI_CANONNAME, AI_NUMERICHOST
            int                 ai_family;      // PF_xxx
            int                 ai_socktype;    // SOCK_xxx
            int                 ai_protocol;    // 0 or IPPROTO_xxx for IPv4 and IPv6
            size_t              ai_addrlen;     // Length of ai_addr
            PWSTR               ai_canonname;   // Canonical name for nodename
            struct sockaddr *   ai_addr;        // Binary address
            struct addrinfoW *  ai_next;        // Next structure in linked list
        }
        ADDRINFOW, *PADDRINFOW;
        #include <cli/poppack.h>

        typedef
        int
        (WSAAPI * LPFN_GETADDRINFOW)(
            IN      PCWSTR              pNodeName,
            IN      PCWSTR              pServiceName,
            IN      const ADDRINFOW *   pHints,
            OUT     PADDRINFOW *        ppResult
            );

        typedef
        void
        (WSAAPI * LPFN_FREEADDRINFOW)(
            IN  PADDRINFOW      pAddrInfo
            );

        #endif /* MINGW_HAS_GETADDRINFOW */

    #endif
#else // *nix/Posix/GNU

    #include <netdb.h>
    extern "C" int h_errno;
    extern "C" int errno;

#endif

#ifndef CLI_INET_IPTYPES_H
    #include <cli/inet/ipTypes.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif


#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif



namespace cli
{
namespace inet
{

static const WCHAR *knownDomainSuffixes[] =
   { L".arpa", L".com" , L".edu" , L".gov" , L".int" , L".mil" , L".net" , L".org"
   , L".au"  , L".at"  , L".az"  , L".ax"  , L".al"  , L".dz"  , L".um"  , L".vi"
   , L".as"  , L".ai"  , L".ao"  , L".ad"  , L".aq"  , L".ag"  , L".ar"  , L".am"
   , L".aw"  , L".af"  , L".bs"  , L".bd"  , L".bb"  , L".bh"  , L".bz"  , L".by"
   , L".be"  , L".bj"  , L".bm"  , L".bg"  , L".bo"  , L".ba"  , L".bw"  , L".br"
   , L".io"  , L".vg"  , L".bn"  , L".bf"  , L".bi"  , L".bt"  , L".vu"  , L".va"
   , L".gb"  , L".hu"  , L".ve"  , L".tl"  , L".vn"  , L".ga"  , L".ht"  , L".gy"
   , L".gm"  , L".gh"  , L".gp"  , L".gt"  , L".gn"  , L".gw"  , L".de"  , L".gi"
   , L".hn"  , L".hk"  , L".gd"  , L".gl"  , L".gr"  , L".ge"  , L".gu"  , L".dk"
   , L".cd"  , L".dj"  , L".dm"  , L".do"  , L".eu"  , L".eg"  , L".zm"  , L".eh"
   , L".zw"  , L".il"  , L".in"  , L".id"  , L".jo"  , L".iq"  , L".ir"  , L".ie"
   , L".is"  , L".es"  , L".it"  , L".ye"  , L".kp"  , L".cv"  , L".kz"  , L".ky"
   , L".kh"  , L".cm"  , L".ca"  , L".qa"  , L".ke"  , L".cy"  , L".kg"  , L".ki"
   , L".cn"  , L".cc"  , L".co"  , L".km"  , L".cr"  , L".ci"  , L".cu"  , L".kw"
   , L".la"  , L".lv"  , L".ls"  , L".lr"  , L".lb"  , L".ly"  , L".lt"  , L".li"
   , L".lu"  , L".mu"  , L".mr"  , L".mg"  , L".yt"  , L".mo"  , L".mk"  , L".mw"
   , L".my"  , L".ml"  , L".mv"  , L".mt"  , L".ma"  , L".mq"  , L".mh"  , L".mx"
   , L".mz"  , L".md"  , L".mc"  , L".mn"  , L".ms"  , L".mm"  , L".na"  , L".nr"
   , L".np"  , L".ne"  , L".ng"  , L".an"  , L".nl"  , L".ni"  , L".nu"  , L".nc"
   , L".nz"  , L".no"  , L".ae"  , L".om"  , L".cx"  , L".ck"  , L".hm"  , L".pk"
   , L".pw"  , L".ps"  , L".pa"  , L".pg"  , L".py"  , L".pe"  , L".pn"  , L".pl"
   , L".pt"  , L".pr"  , L".cg"  , L".re"  , L".ru"  , L".rw"  , L".ro"  , L".us"
   , L".sv"  , L".ws"  , L".sm"  , L".st"  , L".sa"  , L".sz"  , L".sj"  , L".mp"
   , L".sc"  , L".sn"  , L".vc"  , L".kn"  , L".lc"  , L".pm"  , L".rs"  , L".cs"
   , L".sg"  , L".sy"  , L".sk"  , L".si"  , L".sb"  , L".so"  , L".sd"  , L".sr"
   , L".sl"  , L".su"  , L".tj"  , L".th"  , L".tw"  , L".tz"  , L".tg"  , L".tk"
   , L".to"  , L".tt"  , L".tv"  , L".tn"  , L".tm"  , L".tr"  , L".ug"  , L".uz"
   , L".ua"  , L".uy"  , L".fo"  , L".fm"  , L".fj"  , L".ph"  , L".fi"  , L".fk"
   , L".fr"  , L".gf"  , L".pf"  , L".tf"  , L".hr"  , L".cf"  , L".td"  , L".me"
   , L".cz"  , L".cl"  , L".ch"  , L".se"  , L".lk"  , L".ec"  , L".gq"  , L".er"
   , L".ee"  , L".et"  , L".za"  , L".kr"  , L".gs"  , L".jm"  , L".jp"  , L".bv"
   , L".nf"  , L".sh"  , L".tc"  , L".wf"
   //, L"."
   };



inline
bool isInetDomainName( const ::std::wstring &host)
   {
    ::std::wstring::size_type hostDotCount = 0;
    ::std::wstring::size_type hostPos = 0, hostSize = host.size();
    for(; hostPos!=hostSize; ++hostPos)
       {
        if (host[hostPos]==L'.') ++hostDotCount;
       }
    if ((hostDotCount*2+1)>=hostSize) return false;

    bool endsWithKnownRootDomain = false;
    SIZE_T domainIdx = 0, domainsNum = sizeof(knownDomainSuffixes)/sizeof(knownDomainSuffixes[0]);
    for(; domainIdx!=domainsNum; ++domainIdx)
       {
        if (!::cli::util::endsWithI(host, ::std::wstring(knownDomainSuffixes[domainIdx]) )) continue;
        endsWithKnownRootDomain = true;
        break;
       }

    return endsWithKnownRootDomain;
   }

inline
int char2digit(wchar_t ch)
   {
    if (ch>=L'0' && ch<=L'9') return int(ch - L'0');
    if (ch>=L'a' && ch<=L'z') return int(ch - L'a') + 10;
    if (ch>=L'A' && ch<=L'Z') return int(ch - L'A') + 10;
    return -1;
   }

inline
char digit2char(int d)
   {
    if (d<10) return (char)d+'0';
    return (char)d+'A'-10;
   }

inline
wchar_t digit2wchar(int d)
   {
    if (d<10) return (wchar_t)d+L'0';
    return (wchar_t)d+L'A'-10;
   }

inline
::std::wstring int2wstr(int t, int ss = 10, int width = 0, wchar_t fill=L' ')
   {
    ::std::wstring res;
    bool neg = false;
    if (t<0) { neg = true; t = -t; }
    while(t)
       {
        res.append( 1, digit2wchar( t % ss) );
        t = t / ss;
       }

    if (neg && fill==L' ') res.append( 1, L'-' );

    if (width>0 && (int)res.size()<width)
       res.append( width - res.size(), fill );

    if (neg && fill!=L' ') res.append( 1, L'-' );

    ::std::reverse( res.begin(), res.end() );
    if (res.empty()) return L"0";
    return res;
   }

inline
::std::string int2str(int t, int ss = 10, int width = 0, char fill=' ')
   {
    ::std::string res;
    bool neg = false;
    if (t<0) { neg = true; t = -t; }
    while(t)
       {
        res.append( 1, digit2char( t % ss) );
        t = t / ss;
       }

    if (neg && fill==' ') res.append( 1, '-' );

    if (width>0 && (int)res.size()<width)
       res.append( width - res.size(), fill );

    if (neg && fill!=' ') res.append( 1, '-' );

    ::std::reverse( res.begin(), res.end() );
    if (res.empty()) return "0";
    return res;
   }

/*
inline
::std::string int2str(int i)
   {
    ::std::string res;
    bool neg = false;
    if (i<0) { neg = true; i = -i; }
    while(i)
       {
        res.append( 1, digit2char( i % 10 ));
        i = i / 10;
       }
    if (neg) res.append( 1, '-' );
    ::std::reverse( res.begin(), res.end() );
    return res;
   }
*/


inline
bool isIpV4( const ::std::wstring &host)
   {
    ::std::wstring::size_type hostDotCount = 0;
    ::std::wstring::size_type hostPos = 0, hostSize = host.size();

    if (hostSize<7)    return false; // 0.0.0.0 - mimum len is 7
    if (host[0]==L'.') return false;
    if (host[host.size()-1]==L'.') return false;
    if (host.find(L"..")!=host.npos) return false; // intervals allowed only in IPv6

    for(; hostPos!=hostSize; ++hostPos)
       {
        if (host[hostPos]==L'.') ++hostDotCount;
        else
           {
            int chNum = char2digit(host[hostPos]);
            if (chNum<0 || chNum>=10) return false;
           }
       }
    if (hostDotCount!=3) return false;
    return true;
   }

// 8 ��������� �� 16  ��������
inline
bool isIpV6( const ::std::wstring &host, SIZE_T *pDotCount = 0, SIZE_T *pColoCount=0)
   {
    ::std::wstring::size_type hostDotCount = 0;
    ::std::wstring::size_type hostColonCount = 0;
    ::std::wstring::size_type hostPos = 0, hostSize = host.size();

    if (hostSize<2)    return false;
    if (host[0]==L'.' || host[0]==L':') return false;
    if (host[host.size()-1]==L'.' || host[host.size()-1]==L':') return false;

    for(; hostPos!=hostSize; ++hostPos)
       {
        if (host[hostPos]==L'.') ++hostDotCount;
        else if (host[hostPos]==L':') ++hostColonCount;
        else
           {
            int chNum = char2digit(host[hostPos]);
            if (chNum<0 || chNum>=16) return false;
           }
       }
    if (hostColonCount>0 && hostDotCount>0) return false; // mixed dots and colons - error

    if ((hostColonCount+hostDotCount)>7) return false;
    ::std::wstring dblColon( 2, hostDotCount ? L'.' : L':');
    if ((hostColonCount+hostDotCount)==7 && host.find(dblColon)!=host.npos) return false;

    if (pDotCount)  *pDotCount  = hostDotCount;
    if (pColoCount) *pColoCount = hostColonCount;
    return true;
   }




// network IP address to platform unsigned int vector
inline
void networkIp4toVector( const unsigned char *paddr, ::std::vector< unsigned short > &addrVec)
   {
    addrVec.push_back( *paddr++ );
    addrVec.push_back( *paddr++ );
    addrVec.push_back( *paddr++ );
    addrVec.push_back( *paddr++ );
   }

// paddr must be enough
inline
bool ip4VectorToNetwork( const ::std::vector< unsigned short > &addrVec, unsigned char *paddr )
   {
    if (addrVec.size()!=4) return false;

    for( ::std::vector< unsigned short >::const_iterator it = addrVec.begin()
       ; it!=addrVec.end()
       ; ++it
       )
       {
        if (*it>255) return false;
        *paddr++ = (unsigned char)*it;
       }
     return true;
   }

inline
bool ipV4VectorToWideString( const ::std::vector< unsigned short > &addrVec, ::std::wstring &str, wchar_t sep = L'.')
   {
    if (addrVec.size()!=4) return false;
    for( ::std::vector< unsigned short >::const_iterator it = addrVec.begin()
       ; it!=addrVec.end()
       ; ++it
       )
       {
        if (!str.empty()) str.append( 1, sep);
        if (*it>255) return false;
        str.append(int2wstr( *it, 10 ));
       }
    return true;
   }

inline
bool ipV4VectorToString( const ::std::vector< unsigned short > &addrVec, ::std::string &str, char sep = '.')
   {
    if (addrVec.size()!=4) return false;
    for( ::std::vector< unsigned short >::const_iterator it = addrVec.begin()
       ; it!=addrVec.end()
       ; ++it
       )
       {
        if (!str.empty()) str.append( 1, sep);
        if (*it>255) return false;
        str.append(int2str( *it, 10 ));
       }
    return true;
   }

inline
bool ipV4NetworkToWideString( const unsigned char *pAddr, ::std::wstring &str, wchar_t sep = L'.')
   {
    for( int i=0; i!=4; ++i)
       {
        if (!str.empty()) str.append( 1, sep);
        str.append(int2wstr( pAddr[i], 10 ));
       }
    return true;
   }


// network IP address to platform unsigned int vector
inline
void networkIp6toVector( const unsigned char *paddr, ::std::vector< unsigned short > &addrVec)
   {
    for(size_t i=0; i!=8; ++i)
       {
        addrVec.push_back(((unsigned short)paddr[i*2]<<8) | paddr[i*2+1]);
       }
   }

// paddr must be enough
inline
bool ip6VectorToNetwork( const ::std::vector< unsigned short > &addrVec, unsigned char *paddr )
   {
    if (addrVec.size()!=8) return false;

    for( ::std::vector< unsigned short >::const_iterator it = addrVec.begin()
       ; it!=addrVec.end()
       ; ++it
       )
       {
        *paddr++ = (unsigned char)(((*it)>>8)&0xFF);
        *paddr++ = (unsigned char)(((*it)   )&0xFF);
       }
     return true;
   }

inline
bool ipV6VectorToWideString( const ::std::vector< unsigned short > &addrVec, ::std::wstring &str, wchar_t sep = L'.')
   {
    if (addrVec.size()!=8) return false;
    for( ::std::vector< unsigned short >::const_iterator it = addrVec.begin()
       ; it!=addrVec.end()
       ; ++it
       )
       {
        if (!str.empty()) str.append( 1, sep);
        str.append(int2wstr( *it, 16 ));
       }
    return true;
   }

inline
bool ipV6VectorToString( const ::std::vector< unsigned short > &addrVec, ::std::string &str, char sep = L'.')
   {
    if (addrVec.size()!=8) return false;
    for( ::std::vector< unsigned short >::const_iterator it = addrVec.begin()
       ; it!=addrVec.end()
       ; ++it
       )
       {
        if (!str.empty()) str.append( 1, sep);
        str.append(int2str( *it, 16 ));
       }
    return true;
   }

inline
bool ipV6NetworkToWideString( const unsigned char *pAddr, ::std::wstring &str, wchar_t sep = L'.')
   {
    for( int i=0; i!=8; ++i)
       {
        if (!str.empty()) str.append( 1, sep);
        str.append(int2wstr( ((unsigned short)pAddr[i*2]<<8) | pAddr[i*2+1], 16 ));
       }
    return true;
   }

inline
std::wstring ipNetworkToWideString( int af, const unsigned char *pAddr, wchar_t sep = L'.')
   {
    std::wstring res;
    if (pAddr)
       {
        if (af==AF_INET)
           {
            ipV4NetworkToWideString( pAddr, res, sep );
           }
        if (af==AF_INET6)
           {
            ipV6NetworkToWideString( pAddr, res, sep );
           }
       }
    return res;
   }

//void networkIp4toVector( const unsigned char *paddr, ::std::vector< unsigned short > &addrVec)

/*
Win32
struct sockaddr_in {
    short   sin_family;
    u_short sin_port;
    struct  in_addr sin_addr;
    char    sin_zero[8];
};

struct in_addr {
    union {
        struct { u_char s_b1,s_b2,s_b3,s_b4; } S_un_b;
        struct { u_short s_w1,s_w2; } S_un_w;
        u_long S_addr;
    } S_un;
#define s_addr  S_un.S_addr
#define s_host  S_un.S_un_b.s_b2
#define s_net   S_un.S_un_b.s_b1
#define s_imp   S_un.S_un_w.s_w2
#define s_impno S_un.S_un_b.s_b4
#define s_lh    S_un.S_un_b.s_b3
};

Linux
typedef uint32_t in_addr_t;
struct in_addr
  {
    in_addr_t s_addr;
  };


*/

inline
unsigned char* getAddrPtr( struct sockaddr *psa )
   {
    if (!psa) return 0;
    if (psa->sa_family==AF_INET)
       return (unsigned char*)&(((sockaddr_in *)psa)->sin_addr.s_addr);
    else if (psa->sa_family==AF_INET6)
       return (unsigned char*)&(((sockaddr_in6*)psa)->sin6_addr.s6_addr[0]);
    return 0;
   }

inline
const unsigned char* getAddrPtr( const struct sockaddr *psa )
   {
    if (!psa) return 0;
    if (psa->sa_family==AF_INET)
       return (const unsigned char*)&(((const sockaddr_in *)psa)->sin_addr.s_addr);
    else if (psa->sa_family==AF_INET6)
       return (const unsigned char*)&(((const sockaddr_in6*)psa)->sin6_addr.s6_addr[0]);
    return 0;
   }

// UNDONE: punycode need to be used in next in functions encodeDomainNameToWide, encodeDomainNameToStr

inline
::std::wstring encodeDomainNameToWide( const ::std::wstring &dn)
   {
    ::std::wstring res; res.reserve(dn.size());
    ::std::wstring::size_type i = 0, size = dn.size();
    for(; i!=size; ++i)
       {
        res.append( 1, dn[i]&0x7F );
       }
    return res;
   }

inline
::std::string encodeDomainNameToStr( const ::std::wstring &dn)
   {
    ::std::string res; res.reserve(dn.size());
    ::std::wstring::size_type i = 0, size = dn.size();
    for(; i!=size; ++i)
       {
        res.append( 1, ::std::string::value_type(dn[i]&0x7F) );
       }
    return res;
   }

inline
::std::wstring decodeDomainName( const ::std::wstring &dn )
   {
    return dn;
   }

inline
::std::wstring decodeDomainName( const wchar_t *dn )
   {
    if (!dn) return ::std::wstring();
    return ::std::wstring(dn);
   }

inline
::std::wstring decodeDomainName( const ::std::string &dn )
   {
    ::std::wstring res; res.reserve(dn.size());
    ::std::string::size_type i = 0, size = dn.size();
    for(; i!=size; ++i)
       {
        res.append( 1, ::std::wstring::value_type(dn[i]&0x7F) );
       }
    return res;
   }

inline
::std::wstring decodeDomainName( const char* dn )
   {
    if (!dn) return ::std::wstring();
    return decodeDomainName( ::std::string(dn) );
   }



inline
bool convertPort(const std::wstring &portStr, unsigned &port)
   {
    if (portStr.empty()) return false;
    port = 0;
    std::wstring::size_type i = 0, size = portStr.size();
    for(; i!=size; ++i)
       {
        port *= 10;
        unsigned digit = (unsigned)char2digit(portStr[i]);
        if (digit<0)   return false;
        if (digit>=10) return false;
        port += digit;
       }
    return port<=65535;
   }

bool portToNetwork(unsigned port, char *netPort)
   {
    if (port>65535) return false;
    *netPort++ = (unsigned char)((port>>8)&0xFF);
    *netPort++ = (unsigned char)( port    &0xFF);
    return true;
   }

bool portToNetwork(unsigned port, unsigned &netPort)
   {
    netPort = 0;
    return portToNetwork( port, (char*)&netPort);
   }

bool portToNetwork(unsigned port, USHORT &netPort)
   {
    netPort = 0;
    return portToNetwork( port, (char*)&netPort);
   }

bool portToNetwork(unsigned port, int &netPort)
   {
    netPort = 0;
    return portToNetwork( port, (char*)&netPort);
   }

bool portToWideString(unsigned port, ::std::wstring &portStr)
   {
    portStr = int2wstr( port );
    if (port>65535) return false;
    return true;
   }

unsigned charToUnsigned(char *p)
   {
    return (unsigned char)*p;
   }

bool networkToPort(unsigned &port, char *netPort)
   {
    port = charToUnsigned(netPort++) << 8; // ������� �����
    port|= charToUnsigned(netPort);        // ������� �����
    return port<=65535;
   }



struct CIpAddress
{
    int                             addrType;
    ::std::vector< unsigned short > addrVec;
    unsigned                        port;

    // uninitialized IP
    CIpAddress( ) : addrType(AF_UNSPEC), addrVec(), port(0) {}
    // zero filld IP of af IP address family
    CIpAddress( int af ) : addrType(af), addrVec(), port(0)
       {
        size_t num = 0;
        if (addrType==AF_INET)       num = 4;
        else if (addrType==AF_INET6) num = 8;
        if (!num) return;
        for(size_t i=0; i!=num; ++i) addrVec.push_back(0);
       }

    int  getType() const { return addrType; }

    bool checkType() const
       {
        size_t num = 0;
        if (addrType==AF_INET)       num = 4;
        else if (addrType==AF_INET6) num = 8;
        if (!num) return false;
        if (num!=addrVec.size()) return false;
        return true;
       }

    CIpAddress( int af, const char* pAddr) : addrType(af), addrVec()
       {
        if (addrType==AF_INET)       networkIp4toVector( (const unsigned char*)pAddr, addrVec );
        else if (addrType==AF_INET6) networkIp6toVector( (const unsigned char*)pAddr, addrVec );
       }

    CIpAddress( int af, const unsigned char* pAddr) : addrType(af), addrVec()
       {
        if (addrType==AF_INET)       networkIp4toVector( pAddr, addrVec );
        else if (addrType==AF_INET6) networkIp6toVector( pAddr, addrVec );
       }

    CIpAddress(const CIpAddress &ipa) : addrType(ipa.addrType), addrVec(ipa.addrVec) {}
    CIpAddress& operator=(const CIpAddress &ipa)
       {
        if (&ipa==this) return *this;
        addrType = ipa.addrType;
        addrVec  = ipa.addrVec;
        return *this;
       }

    ::std::string toString() const
       {
        ::std::string res;
        if (addrType==AF_INET)       ipV4VectorToString( addrVec, res );
        else if (addrType==AF_INET6) ipV6VectorToString( addrVec, res );
        return res;
       }

    ::std::wstring toWideString() const
       {
        ::std::wstring res;
        if (addrType==AF_INET)       ipV4VectorToWideString( addrVec, res );
        else if (addrType==AF_INET6) ipV6VectorToWideString( addrVec, res );
        return res;
       }

    ::std::wstring toWideStringPort() const
       {
        ::std::wstring addrStr;
        if (addrType==AF_INET)
           {
            ipV4VectorToWideString( addrVec, addrStr );
           }
        else if (addrType==AF_INET6)
           {
            ipV6VectorToWideString( addrVec, addrStr );
            addrStr = ::std::wstring(1, L'[') + addrStr + ::std::wstring(1, L']');
           }

        ::std::wstring portStr;
        portToWideString( port, portStr );
        return addrStr + ::std::wstring(1, L':') + portStr;
       }

//checkType()
    bool toNetwork( char *pNetAddr, SIZE_T &netAddrLen ) const
       {
        if (addrType==AF_INET)
           {
            if (netAddrLen<4) return false;
            bool res = ip4VectorToNetwork(addrVec, (unsigned char*)pNetAddr);
            if (!res) return false;
            netAddrLen = 4;
            return true;
           }
        else if (addrType==AF_INET6)
           {
            if (netAddrLen<16) return false;
            bool res = ip6VectorToNetwork(addrVec, (unsigned char*)pNetAddr);
            if (!res) return false;
            netAddrLen = 16;
            return true;
           }
        return false;
       }

    bool toPlain(STRUCT_CLI_INET_IPADDRESS *pIpAddress) const
       {
        if ( (addrType==AF_INET && addrVec.size()==4)
           ||(addrType==AF_INET6 && addrVec.size()==8)
           )
           {
            pIpAddress->af = addrType;
            ::std::copy( addrVec.begin(), addrVec.end(), &pIpAddress->addr[0]);
            return true;
           }
        pIpAddress->af = CLI_INET_IPADDRESSFAMILY_UNSPEC;
        return false;
       }

    bool toPlain(STRUCT_CLI_INET_SOCKETADDRESS *pIpAddress) const
       {
        if ( (addrType==AF_INET && addrVec.size()==4)
           ||(addrType==AF_INET6 && addrVec.size()==8)
           )
           {
            pIpAddress->af = addrType;
            ::std::copy( addrVec.begin(), addrVec.end(), &pIpAddress->addr[0]);
            pIpAddress->port = port;
            return true;
           }
        pIpAddress->af = CLI_INET_IPADDRESSFAMILY_UNSPEC;
        return false;
       }

    bool fromPlain( const STRUCT_CLI_INET_IPADDRESS *pIpAddress )
       {
        if (pIpAddress->af == CLI_INET_IPADDRESSFAMILY_UNSPEC) return false;
        addrType = pIpAddress->af;
        addrVec.clear();
        SIZE_T numToCopy = addrType==AF_INET ? 4 : 8;
        ::std::copy( &pIpAddress->addr[0], &pIpAddress->addr[numToCopy], ::std::back_inserter(addrVec) );
        return true;
       }

    bool fromPlain( const STRUCT_CLI_INET_SOCKETADDRESS *pIpAddress )
       {
        if (pIpAddress->af == CLI_INET_IPADDRESSFAMILY_UNSPEC) return false;
        addrType = pIpAddress->af;
        port = pIpAddress->port;
        addrVec.clear();
        SIZE_T numToCopy = addrType==AF_INET ? 4 : 8;
        ::std::copy( &pIpAddress->addr[0], &pIpAddress->addr[numToCopy], ::std::back_inserter(addrVec) );
        return true;
       }

    void makeAddrAny( unsigned _port, ENUM_CLI_INET_IPADDRESSFAMILY af)
       {
        addrType = af;
        addrVec.clear();
        port = _port;
        SIZE_T numZeros = addrType==AF_INET ? 4 : 8;
        addrVec = ::std::vector<unsigned short>( numZeros, (unsigned short)0);
       }

    RCODE fromSockAddr( const struct sockaddr_in &sa)
       {
        if (sa.sin_family!=AF_INET) return EC_INVALID_AF;
        addrType = AF_INET;
        if (!networkToPort( port, (char*)&sa.sin_port ))
           return EC_INVALID_PORT;
        addrVec.clear();
        networkIp4toVector( (unsigned char *)&sa.sin_addr, addrVec );
        return EC_OK;
       }

    RCODE fromSockAddr( DWORD dsa )
       {
        struct sockaddr_in sa;
        *((DWORD*)&sa.sin_addr) = dsa;
        sa.sin_family = AF_INET;
        sa.sin_port   = 0;
        return fromSockAddr( sa );
       }

    RCODE fromSockAddr( const struct sockaddr_in6 &sa)
       {
        if (sa.sin6_family!=AF_INET6) return EC_INVALID_AF;
        addrType = AF_INET6;
        if (!networkToPort( port, (char*)&sa.sin6_port ))
           return EC_INVALID_PORT;
        addrVec.clear();
        networkIp6toVector( (unsigned char *)&sa.sin6_addr, addrVec );
        return EC_OK;
       }

    RCODE makeSockAddr( struct sockaddr_in &sa)
       {
        if (addrType!=AF_INET) return EC_INVALID_AF;

        memset( (void*)&sa, 0, sizeof(sa) );
        /*
        struct sockaddr_in {
                short   sin_family;         // X
                u_short sin_port;           // X
                struct  in_addr sin_addr;   // X
                char    sin_zero[8];        // X
        };
        */

        sa.sin_family = AF_INET;
        if (!::cli::inet::portToNetwork(port, sa.sin_port))
           return EC_INVALID_PORT;
        SIZE_T netSize = 4;
        toNetwork( (char*)&sa.sin_addr, netSize );
        //sin_zero[0] = sin_zero[1] = sin_zero[2] = sin_zero[3] =
        //sin_zero[4] = sin_zero[5] = sin_zero[6] = sin_zero[7] = 0;
        return EC_OK;
       }

    RCODE makeSockAddr( DWORD &dsa )
       {
        struct sockaddr_in sa;
        RCODE res = makeSockAddr( sa );
        if (res) return res;
        dsa = *((DWORD*)&sa.sin_addr);
        return res;
       }

    RCODE makeSockAddr( struct sockaddr_in6 &sa)
       {
        if (addrType!=AF_INET6) return EC_INVALID_AF;

        memset( (void*)&sa, 0, sizeof(sa) );
        /*
        struct sockaddr_in6 {
                short   sin6_family;         // X
                u_short sin6_port;           // X
                u_long  sin6_flowinfo;       // X
                struct  in6_addr sin6_addr;  // X
                u_long  sin6_scope_id;       // X
        };
        */

        sa.sin6_family = AF_INET6;
        if (!::cli::inet::portToNetwork(port, sa.sin6_port))
           return EC_INVALID_PORT;
        sa.sin6_flowinfo = 0;
        SIZE_T netSize = 16;
        toNetwork( (char*)&sa.sin6_addr, netSize );
        sa.sin6_scope_id = 0;
        return EC_OK;
       }

    RCODE fromInAddr( const struct in_addr &ina)
       {
        addrType = AF_INET;
        port     = 0;
        addrVec.clear();
        networkIp4toVector( (unsigned char *)&ina, addrVec );
        return EC_OK;
       }

    RCODE makeInAddr( struct in_addr &ina)
       {
        if (addrType!=AF_INET) return EC_INVALID_AF;
        SIZE_T netSize = 4;
        toNetwork( (char*)&ina, netSize );
        return EC_OK;
       }
};


inline
bool ip6makeFullLenAddr( ::std::wstring &_addr)
   {
    ::std::wstring addr = _addr;
    SIZE_T addrDotCount = 0;
    SIZE_T addrColonCount = 0;
    //::std::wstring host = _host;
    if (isIpV6(addr, &addrDotCount, &addrColonCount) && addrDotCount>0)
       {
        ::std::wstring::size_type i=0, size = addr.size();
        for(; i!=size; ++i) if (addr[i]==L'.') addr[i] = L':';
       }
    // check there is no implicit zeros in form XXXX::XXXX
    ::std::wstring::size_type dblColonPos = addr.find(L"::");
    if (dblColonPos==addr.npos)
       {
        if ((addrDotCount+addrColonCount)==7) return true;
        // implicit zeros not found
        return false;
       }
    if ((addrDotCount+addrColonCount)>7) return false;

    ::std::wstring insertion;
    SIZE_T neededColons = 7 - (addrDotCount+addrColonCount);
    SIZE_T neededZeros = neededColons + 1;
    for(SIZE_T i=0; i!=neededZeros; ++i)
       {
        if (i) insertion.append( 1, L':' );
        insertion.append( 1, L'0' );
       }

    //addr.erase(dblColonPos, 2);
    addr.insert(dblColonPos+1, insertion);
    if (!isIpV6(addr)) return false;
    _addr = addr;
    return true;
   }



inline
bool convertIpAddress( const std::wstring &addr, ::std::vector< unsigned short > &addrVec, unsigned ss, unsigned ipPartMax)
   {
    std::wstring::size_type i = 0, size = addr.size();
    while(i!=size)
       {
        if (addr[i]==L'.' || addr[i]==L':') return false;
        unsigned ipPart = 0; //ipPartMax+1; // ipPartMax
        while(i!=size)
           {
            if (addr[i]==L'.' || addr[i]==L':')
               { // next part starts here
                if (ipPart>ipPartMax) return false;
                addrVec.push_back((unsigned short)ipPart);
                ++i;
                break;
               }
            ipPart *= ss;
            unsigned digit = (unsigned)char2digit(addr[i++]);
            if (digit<0) return false;
            if (digit>=ss) return false;
            ipPart += digit;
           }
        if (i==size)
           {
            if (addr[i-1]==L'.' || addr[i-1]==L':') return false;
            if (ipPart>ipPartMax) return false;
            addrVec.push_back((unsigned short)ipPart);
           }
       }
    return true;
   }

bool convertIp4( const std::wstring &addr, ::std::vector< unsigned short > &addrVec)
   {
    return convertIpAddress( addr, addrVec, 10, 255);
   }

bool convertIp6( const std::wstring &addr, ::std::vector< unsigned short > &addrVec)
   {
    return convertIpAddress( addr, addrVec, 16, 65535);
   }

bool convertIpAddress(const std::wstring &addr, CIpAddress &ipAddr)
   {
    ipAddr.addrVec.clear();
    if (convertIp4( addr, ipAddr.addrVec ) && ipAddr.addrVec.size()==4)
       {
        ipAddr.addrType = AF_INET;
        return true;
       }
    std::wstring addrCopy = addr;
    if (!ip6makeFullLenAddr( addrCopy )) return false;
    ipAddr.addrVec.clear();
    if (convertIp6( addrCopy, ipAddr.addrVec ) && ipAddr.addrVec.size()==8)
       {
        ipAddr.addrType = AF_INET6;
        return true;
       }
    return false;
   }


//int char2digit(wchar_t ch)


#if defined(WIN32) || defined(_WIN32)

inline
RCODE resolvErrToRCode( DWORD err )
   {
    switch(err)
       {
        case 0                :  return 0;
        case WSANO_RECOVERY   :  return EC_RESOLV_NO_RECOVERY;
        case WSATRY_AGAIN     :  return EC_RESOLV_TRY_AGAIN;
        case WSAHOST_NOT_FOUND:  return EC_RESOLV_HOST_NOT_FOUND;
        case WSANO_DATA       :  return EC_RESOLV_NO_DATA;
        default:                 return WIN2RC(err);
       }
   }

inline
RCODE resolvSetErrInfo( DWORD err, const std::wstring &host )
   {
    switch(err)
       {
        case 0                :  return 0;
        case WSANO_RECOVERY   :  return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_NO_RECOVERY   , 0, 0, ::cli::format::arg(host) );
        case WSATRY_AGAIN     :  return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_TRY_AGAIN     , 0, 0, ::cli::format::arg(host) );
        case WSAHOST_NOT_FOUND:  return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_HOST_NOT_FOUND, 0, 0, ::cli::format::arg(host) );
        case WSANO_DATA       :  return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_NO_DATA       , 0, 0, ::cli::format::arg(host) );
        default:                 return CLI_SET_WIN_ERROR_INFO_ARGS( err, 0, 0, ::cli::format::arg(host) );
       }
   }


#else // POSIX



inline
RCODE resolvErrToRCode( int err )
   {
    switch(err)
       {
        case 0                :  return 0; // NETDB_SUCCESS
        case NETDB_INTERNAL   :  return POSIX2RC(errno);
        case NO_RECOVERY      :  return EC_RESOLV_NO_RECOVERY;
        case TRY_AGAIN        :  return EC_RESOLV_TRY_AGAIN;
        case HOST_NOT_FOUND   :  return EC_RESOLV_HOST_NOT_FOUND;
        case NO_DATA          :  return EC_RESOLV_NO_DATA;
        default:                 return EC_UNKNOWN;
       }
   }

inline
RCODE resolvSetErrInfo( int err, const std::wstring &host )
   {
    switch(err)
       {
        case 0                :  return 0;
        case NETDB_INTERNAL   :  return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, ::cli::format::arg(host) );
        case NO_RECOVERY      :  return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_NO_RECOVERY   , 0, 0, ::cli::format::arg(host) );
        case TRY_AGAIN        :  return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_TRY_AGAIN     , 0, 0, ::cli::format::arg(host) );
        case HOST_NOT_FOUND   :  return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_HOST_NOT_FOUND, 0, 0, ::cli::format::arg(host) );
        case NO_DATA          :  return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_NO_DATA       , 0, 0, ::cli::format::arg(host) );
        default:                 return CLI_SET_ERROR_INFO_ARGS( EC_UNKNOWN, 0, 0, ::cli::format::arg(host) );
       }
   }

#endif



inline
RCODE resolvReturnError( int err, const ::std::wstring &host, bool bSetErrInfo = false)
   {
    if (bSetErrInfo) return resolvSetErrInfo( err, host );
    else             return resolvErrToRCode( err );
   }


#if defined(WIN32) || defined(_WIN32)
    bool hasAddrInfoFunctions()
       {
        HMODULE hWs2_32 = ::GetModuleHandleA("ws2_32.dll" );

        LPFN_GETADDRINFOW  getAddrInfoFn  = (LPFN_GETADDRINFOW) ::GetProcAddress( hWs2_32, "GetAddrInfoW" );
        LPFN_FREEADDRINFOW freeAddrInfoFn = (LPFN_FREEADDRINFOW)::GetProcAddress( hWs2_32, "FreeAddrInfoW" );

        if (getAddrInfoFn && freeAddrInfoFn) return true;
        return false;
       }
#endif



inline
RCODE getHostInfo( const ::std::wstring &host
                 , int afRequested
                 , ::std::vector< CIpAddress > &addrList
                 , ::std::wstring *pCanonicalName = 0
                 , bool bSetErrInfo = false
                 )
   {
    if (host.empty() || (afRequested!=AF_INET && afRequested!=AF_INET6) ) return EC_INVALID_PARAM;

    //bool convertIpAddress(const std::wstring &addr, CIpAddress &ipAddr)

    //if (afRequested==AF_INET)
       {
        CIpAddress ipa;
        if (convertIp4( host, ipa.addrVec ) && ipa.addrVec.size()==4)
           {
            ipa.addrType = AF_INET;
            addrList.push_back(ipa);
            return EC_RESOLV_SUCCESS; // found IPv4 address
           }
       }

    /*
    std::wstring addrCopy = addr;
    if (!ip6makeFullLenAddr( addrCopy )) return false;
    if (convertIp6( addr, ipAddr.addrVec ))
       {
        ipAddr.addrType = AF_INET6;
        return true;
       }
    return false;
    */

    //if (afRequested==AF_INET6)
       {
        SIZE_T addrDotCount = 0;
        std::wstring addrCopy = host;
        if (isIpV6(addrCopy, &addrDotCount) && addrDotCount>0)
           {
            ::std::wstring::size_type i=0, size = addrCopy.size();
            for(; i!=size; ++i) if (addrCopy[i]==L'.') addrCopy[i] = L':';
           }

        if (ip6makeFullLenAddr( addrCopy ))
           {
            CIpAddress ipa;
            if (convertIp6( addrCopy, ipa.addrVec ) && ipa.addrVec.size()==8)
               {
                ipa.addrType = AF_INET6;
                addrList.push_back(ipa);
                return EC_RESOLV_SUCCESS; // found IPv6 address
               }
           }
       }

    //if (pCanonicalName) pCanonicalName->clear();

    #if defined(WIN32) || defined(_WIN32)

    // INCL_WINSOCK_API_TYPEDEFS may be need to be defined

    HMODULE hWs2_32 = ::GetModuleHandleA("ws2_32.dll" );

    LPFN_GETADDRINFOW  getAddrInfoFn  = (LPFN_GETADDRINFOW) ::GetProcAddress( hWs2_32, "GetAddrInfoW" );
    LPFN_FREEADDRINFOW freeAddrInfoFn = (LPFN_FREEADDRINFOW)::GetProcAddress( hWs2_32, "FreeAddrInfoW" );

    if (getAddrInfoFn && freeAddrInfoFn)
       {
        //struct addrinfo hints;
        ADDRINFOW hints;
        hints.ai_flags = AI_CANONNAME; // AI_PASSIVE, AI_CANONNAME, or AI_NUMERICHOST
        hints.ai_family = afRequested; // PF_INET6; // PF_UNSPEC; // or 0
        hints.ai_socktype = 0; // SOCK_RAW, SOCK_STREAM, or SOCK_DGRAM
        hints.ai_protocol = 0; // IPPROTO_TCP or IPPROTO_UDP, For protocols other than IPv4 and IPv6, set ai_protocol to zero

        hints.ai_addrlen = 0;
        hints.ai_canonname = 0;
        hints.ai_addr = 0;
        hints.ai_next = 0;

        //struct addrinfo* addrRes = 0;
        PADDRINFOW addrRes = 0;

        //#if defined(UNICODE) || defined(_UNICODE)
        int res = getAddrInfoFn( host.c_str(), 0, &hints, &addrRes );
        //#else
        //int res = :: getaddrinfo( encodeDomainNameToStr(host).c_str() , 0, &hints, &addrRes );
        //#endif

        if (res || !addrRes) return resolvReturnError( res, host, bSetErrInfo);

        //struct addrinfo* orgAddrInfo = addrRes;
        PADDRINFOW orgAddrInfo = addrRes;

        if (addrRes->ai_canonname && pCanonicalName && pCanonicalName->empty())
           *pCanonicalName = decodeDomainName( addrRes->ai_canonname );

        while(addrRes)
           {
            addrList.push_back( CIpAddress( addrRes->ai_addr->sa_family, ::cli::inet::getAddrPtr(addrRes->ai_addr) ) );
            addrRes = addrRes->ai_next;
           }

        freeAddrInfoFn(orgAddrInfo);
       }
    else
       { // unsafe version
        struct hostent *phe = gethostbyname( encodeDomainNameToStr(host).c_str() );
        if (!phe) return resolvReturnError( WSAGetLastError(), host, bSetErrInfo);
        if (phe->h_name && pCanonicalName && pCanonicalName->empty())
           *pCanonicalName = decodeDomainName( phe->h_name );

        if (phe->h_addr_list)
           {
            size_t i = 0;
            char *pAddr = (char*)phe->h_addr_list[i++];
            while(pAddr)
               {
                addrList.push_back( CIpAddress( phe->h_addrtype, pAddr ) );
                pAddr = (char*)phe->h_addr_list[i++];
               }
           }
       }

    return EC_RESOLV_SUCCESS;

    #else // *nux/Posix

    struct hostent he, *phe = 0;
    char buf[4096];
    int herr = 0;
    int grRes = gethostbyname2_r( encodeDomainNameToStr(host).c_str(), afRequested, &he, buf, sizeof(buf), &phe, &herr);
    if (grRes || !phe) return resolvReturnError( herr, host, bSetErrInfo);

    if (he.h_name && pCanonicalName && pCanonicalName->empty())
       *pCanonicalName = decodeDomainName( he.h_name );

    if (he.h_addr_list)
       {
        size_t i = 0;
        char *pAddr = (char*)he.h_addr_list[i++];
        while(pAddr)
           {
            addrList.push_back( CIpAddress( he.h_addrtype, pAddr ) );
            pAddr = (char*)he.h_addr_list[i++];
           }
       }

    return EC_RESOLV_SUCCESS;

    #endif
   }


inline
RCODE getHostName( ::std::wstring &name, bool bSetErrInfo = false )
   {
    char hostNameBuf[1024];
    int res = gethostname( hostNameBuf, sizeof(hostNameBuf));
    #if defined(WIN32) || defined(_WIN32)
    if (res) return WIN2RC(WSAGetLastError());
    #else
    if (res) return POSIX2RC(errno);
    #endif
    hostNameBuf[sizeof(hostNameBuf)-1] = 0;

    name = MARTY_CON_NS a2wide( ::std::string(hostNameBuf) );
    return EC_RESOLV_SUCCESS;
   }


// NOTE: thread unsafe
inline
RCODE getHostByAddr( const CIpAddress &ipAddress
                   , ::std::wstring &name
                   , std::vector< ::std::wstring > aliasList
                   , bool bSetErrInfo = false )
   {
    char   netAddr[128];
    SIZE_T netAddrSize = sizeof(netAddr);
    if (!ipAddress.toNetwork( netAddr, netAddrSize ))
       {
        return EC_RESOLV_INVALID_ADDR;
       }

    struct hostent *phe = :: gethostbyaddr( netAddr, (int)netAddrSize, ipAddress.getType() );
    if (!phe)
       {
        #if defined(WIN32) || defined(_WIN32)
        return resolvReturnError( ::WSAGetLastError(), ipAddress.toWideString() , bSetErrInfo);
        #else
        return resolvReturnError( h_errno, ipAddress.toWideString(), bSetErrInfo);
        #endif
       }

    if (phe->h_name)
       {
        name = decodeDomainName(phe->h_name);
       }

    if (phe->h_aliases)
       {
        size_t i = 0;
        char *pAlias = phe->h_aliases[i++];
        while(pAlias)
           {
            aliasList.push_back( decodeDomainName(pAlias) );
            pAlias = phe->h_aliases[i++];
           }
       }

    return EC_RESOLV_SUCCESS;
   }


//return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, ::cli::format::arg(host) );



// Application can define this values before call initSocketsAPI()
#ifndef WINSOCK_VERSION_REQUIRED_HIGH
    #define WINSOCK_VERSION_REQUIRED_HIGH  2
#endif

#ifndef WINSOCK_VERSION_REQUIRED_LOW
    #define WINSOCK_VERSION_REQUIRED_LOW   0
#endif

inline
void initSocketsAPI()
   {
    #if defined(WIN32) || defined(_WIN32)
    WORD versionRequested = MAKEWORD( WINSOCK_VERSION_REQUIRED_HIGH, WINSOCK_VERSION_REQUIRED_LOW );
    WSADATA   wsaData;
    int wsaRes = WSAStartup( versionRequested , &wsaData );
    if (wsaRes)
       throw ::std::runtime_error( (::std::string("Failed to init windows sockets, error code: ") + int2str(wsaRes)).c_str() );

    if ( LOBYTE( wsaData.wVersion ) != WINSOCK_VERSION_REQUIRED_HIGH
       ||HIBYTE( wsaData.wVersion ) != WINSOCK_VERSION_REQUIRED_LOW
       )
       {
        WSACleanup( );
        throw ::std::runtime_error( (::std::string("Failed to init windows sockets, version taken: ") + int2str(LOBYTE( wsaData.wVersion )) + ::std::string(1,'.') + int2str(HIBYTE( wsaData.wVersion )) ).c_str() );
       }
    #else
    return ;
    #endif
   }

}; // namespace inet
}; // namespace cli

#endif /* CORE_INET_INETHLP_H */

