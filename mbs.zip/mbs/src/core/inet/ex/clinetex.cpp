/*! \project Cli inet additional classes
    \libraries cli2

    \platform win32
        \libraries Iphlpapi

    \platform mingw
        \libraries Iphlpapi

*/
#define CLI_INTERNAL
#define CLI_INTERNAL_DONT_LINK_CLI_LIB

//#include "io/factory.h"
//#include "io/fileios.h"
//#include "io/serialImpl.h"
//#include "io/pipeImpl.h"
//#include "io/sockImpl.h"


// NOTE: if not works under W2K, disable resolver by uncommenting preprocessor directives below
//#if defined(WIN32_WINNT) && WIN32_WINNT>=0x0501
//    #include "inet/resolvImpl.h"
//#endif



#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif


#include "NetInterfaceInfo.h"
#include "RouteInfo.h"



/*
#ifndef CLI_IUNKNOWN_H
    #include <cli/iunknown.h>
#endif
*/



DECLARE_COMPONENT_CREATION_PROC( create_cli_netInterfaceInfoImpl      , ::cli::inet::impl::CNetInterfaceInfoImpl, INTERFACE_CLI_INET_INETINTERFACEINFO)
DECLARE_COMPONENT_CREATION_PROC(create__cli__inet__impl__CRouteInfoImpl, ::cli::inet::impl::CRouteInfoImpl, INTERFACE_CLI_INET_IROUTEINFO)



//static 
static unsigned infoInitialized = 0;
static
CCliComponentCreationInfo moduleComponentsInfo[] = 
   {
      // ---
      { 
        { "/cli/inet/netinterfaceinfo"
        , INTERFACE_CLI_INET_INETINTERFACEINFO_IID
        , "en:Object gathering information about network interfaces;"
        }
      , &create_cli_netInterfaceInfoImpl
      }
      , // ---
      {
        { "/cli/inet/routeinfo" // !!! Don't forget to modufy component name as you need
        ,      INTERFACE_CLI_INET_IROUTEINFO_IID
        , "en:Object gathering information about network routes;"
        }
      , &create__cli__inet__impl__CRouteInfoImpl
      }
   };



DECLARE_CLI_MODULE_INFO(moduleComponentsInfo, infoInitialized, registerCliModule, "clinetex")


