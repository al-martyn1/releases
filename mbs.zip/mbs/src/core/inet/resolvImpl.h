#ifndef RESOLVIMPL_H
#define RESOLVIMPL_H

#ifndef CORE_INET_INETHLP_H
    #include "inethlp.h"
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif


namespace cli
{
namespace inet
{
namespace impl
{

struct CResolverImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                     , public INTERFACE_CLI_INET_IRESOLVER
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    //CLI_BEGIN_INTERFACE_MAP2(CResolverImpl, INTERFACE_CLI_INET_IRESOLVER)
    CLI_BEGIN_INTERFACE_MAP(CResolverImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INET_IRESOLVER )
    CLI_END_INTERFACE_MAP(CResolverImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    static ::cli::CCriticalSection csGetHostByAddrGuard;

    // property holders
    ::std::wstring                           canonicalName;
    ::std::vector< ::cli::inet::CIpAddress > addrList;
    ::std::vector< ::std::wstring >          aliasList;

    ::std::wstring                           serviceName   ;
    unsigned                                 servicePort   ;
    ::std::vector< ::std::wstring >          serviceAliases;
    ::std::wstring                           serviceProtocolStr;
    ENUM_CLI_INET_PROTOCOLTYPE               serviceProtocol;


    CResolverImpl()
       : base_impl(DEF_MODULE)
       , canonicalName()
       , addrList()
       , aliasList()
       , serviceName()
       , servicePort(0)
       , serviceAliases()
       , serviceProtocolStr()
       , serviceProtocol(CLI_INET_PROTOCOLTYPE_UNSPEC)
       {
        CLI_AUTOLOCK(csGetHostByAddrGuard);
        ::cli::inet::initSocketsAPI();
       }

    CLIMETHOD(stringToIp) (THIS_ const CLISTR*     ipStr
                               , STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [out] ::cli::inet::IpAddress ipAddr  */
                          )
       {
        if (!ipStr || !ipAddr) return EC_INVALID_PARAM;
        ::cli::inet::CIpAddress tmpIpAddr;
        if (!convertIpAddress( stdstr(ipStr), tmpIpAddr))
           return EC_RESOLV_INVALID_ADDR;

        if (!tmpIpAddr.toPlain(ipAddr))
           return EC_RESOLV_INVALID_ADDR;

        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(stringToIpChars) (THIS_ const WCHAR*    ipBuf /* [in,flat] wchar  ipBuf[]  */
                                    , SIZE_T    ipBufSize /* [in] size_t  ipBufSize  */
                                    , STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [out] ::cli::inet::IpAddress ipAddr  */
                               )
       {
        if (!ipBuf || !ipAddr) return EC_INVALID_PARAM;
        ::cli::inet::CIpAddress tmpIpAddr;
        //::std::wstring tmpIpStr = (nameSize==SIZE_T_NPOS ? ::std::wstring(ipBuf) : ::std::wstring(ipBuf, ipBufSize));

        if (!convertIpAddress( stdstr(ipBuf, ipBufSize), tmpIpAddr))
           return EC_RESOLV_INVALID_ADDR;

        if (!tmpIpAddr.toPlain(ipAddr))
           return EC_RESOLV_INVALID_ADDR;

        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(ipToString) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [in,ref] ::cli::inet::IpAddress  ipAddr  */
                               , CLISTR*           ipStr
                          )
       {
        if (!ipStr || !ipAddr) return EC_INVALID_PARAM;
        ::cli::inet::CIpAddress tmpIpAddr;
        if (!tmpIpAddr.fromPlain( ipAddr ) || !tmpIpAddr.checkType())
           return EC_RESOLV_INVALID_ADDR;

        ::std::wstring tmpAddrStr = tmpIpAddr.toWideString();
        if (ipStr)    CCliStr_copyTo(ipStr , tmpAddrStr );

        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(macAddrToString) (THIS_ const BYTE*    mac /* [in,flat] byte  mac[]  */
                                    , SIZE_T    macSize /* [in] size_t  macSzie  */
                                    , CLISTR*           macStr
                               )
       {
        if (!mac || macSize!=6) return EC_INVALID_PARAM;
        ::std::wstring macStdStr;
        for(SIZE_T i=0; i!=6; ++i)
           {
            if (i) macStdStr.append( 1, L' ' );
            macStdStr.append( ::cli::inet::int2wstr( (unsigned)mac[i], 16, 2, L'0' ) );
           }
        if (macStr) CCliStr_copyTo( macStr , macStdStr );
        return EC_OK;
       }

    CLIMETHOD(sockAddrToString) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sockAddr /* [in,ref] ::cli::inet::SocketAddress  sockAddr  */
                                     , CLISTR*           ipStr
                                )
       {
        if (!ipStr || !sockAddr) return EC_INVALID_PARAM;
        ::cli::inet::CIpAddress tmpIpAddr;
        if (!tmpIpAddr.fromPlain( sockAddr ) || !tmpIpAddr.checkType())
           return EC_RESOLV_INVALID_ADDR;

        ::std::wstring tmpAddrStr = tmpIpAddr.toWideStringPort();
        if (ipStr)    CCliStr_copyTo(ipStr , tmpAddrStr );

        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(sockAddrToAddrPortString) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sockAddr /* [in,ref] ::cli::inet::SocketAddress  sockAddr  */
                                             , CLISTR*           ipStr
                                             , CLISTR*           portStr
                                        )
       {
        if (!sockAddr) return EC_INVALID_PARAM;
        ::cli::inet::CIpAddress tmpIpAddr;
        if (!tmpIpAddr.fromPlain( sockAddr ) || !tmpIpAddr.checkType())
           return EC_RESOLV_INVALID_ADDR;

        ::std::wstring tmpAddrStr = tmpIpAddr.toWideString();
        ::std::wstring tmpPortStr;
        portToWideString( sockAddr->port, tmpPortStr );

        if (ipStr)      CCliStr_copyTo(ipStr   , tmpAddrStr );
        if (portStr)    CCliStr_copyTo(portStr , tmpPortStr );

        return EC_RESOLV_SUCCESS;
       }


    CLIMETHOD(getHostName) (THIS_ CLISTR*           name)
       {
        if (!name) return EC_INVALID_PARAM;
        ::std::wstring hostName;
        RCODE res = ::cli::inet::getHostName( hostName, true );
        if (res) return res;
        if (name)    CCliStr_copyTo(name , hostName );
        return EC_RESOLV_SUCCESS;
       }

    #if 0 // obsolete methods
    CLIMETHOD(makeIpAddrAny) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                  , STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [out,ref] ::cli::inet::IpAddress ipAddr  */
                             )
       {
        if (!ipAddr) return EC_INVALID_PARAM;

        //void makeAddrAny( unsigned _port, ENUM_CLI_INET_IPADDRESSFAMILY af)
        ::cli::inet::CIpAddress tmpIpAddr;
        //tmpIpAddr.addrType = af;
        tmpIpAddr.makeAddrAny( 0, af );
        /*
        if (af==AF_INET)
           {
            tmpIpAddr.addrVec.insert( tmpIpAddr.addrVec.end(), 4, (unsigned short)255 );
           }
        else if (af==AF_INET6)
           {
            return EC_NOT_IMPLEMENTED; // UNDONE: implement broadcast addr for IPv6
           }
        else
           {
            return EC_INVALID_PARAM;
           }
        */
        tmpIpAddr.toPlain(ipAddr);
        return EC_OK;
       }

    CLIMETHOD(makeSockAddrAny) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                    , UINT    port /* [in] uint  port  */
                                    , STRUCT_CLI_INET_SOCKETADDRESS*    sockAddr /* [out,ref] ::cli::inet::SocketAddress sockAddr  */
                               )
       {
        if (!sockAddr)  return EC_INVALID_PARAM;
        if (port>65535) return EC_INVALID_PARAM;

        ::cli::inet::CIpAddress tmpIpAddr;
        tmpIpAddr.makeAddrAny( port, af );
        /*
        tmpIpAddr.addrType = af;
        if (af==AF_INET)
           {
            tmpIpAddr.addrVec.insert( tmpIpAddr.addrVec.end(), 4, (unsigned short)255 );
           }
        else if (af==AF_INET6)
           {
            return EC_NOT_IMPLEMENTED; // UNDONE: implement broadcast addr for IPv6
           }
        else
           {
            return EC_INVALID_PARAM;
           }
        tmpIpAddr.port = port;
        */
        tmpIpAddr.toPlain(sockAddr);
        return EC_OK;
       }

    //0:0:0:0:0:0:0:1
    // ff05::1 All nodes on the local network site (roughly equivalent to the IPv4 local broadcast addresses 10.255.255.255 and 192.168.255.255) 


    CLIMETHOD(makeBroadcastIpAddr) (THIS_ UINT    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                        , STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [out,ref] ::cli::inet::IpAddress ipAddr  */
                                   )
       {
        if (!ipAddr) return EC_INVALID_PARAM;

        ::cli::inet::CIpAddress tmpIpAddr;
        tmpIpAddr.addrType = af;
        if (af==AF_INET)
           {
            tmpIpAddr.addrVec.insert( tmpIpAddr.addrVec.end(), 4, (unsigned short)255 );
           }
        else if (af==AF_INET6)
           {
            //return EC_NOT_IMPLEMENTED; // UNDONE: implement broadcast addr for IPv6
            tmpIpAddr.addrVec.push_back( 0xFF02 );
            tmpIpAddr.addrVec.insert( tmpIpAddr.addrVec.end(), 6, 0 );
            tmpIpAddr.addrVec.push_back( 1 );
           }
        else
           {
            return EC_INVALID_PARAM;
           }
        tmpIpAddr.toPlain(ipAddr);
        return EC_OK;
       }

    CLIMETHOD(makeBroadcastSockAddr) (THIS_ UINT    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                          , UINT    port /* [in] uint  port  */
                                          , STRUCT_CLI_INET_SOCKETADDRESS*    sockAddr /* [out,ref] ::cli::inet::SocketAddress sockAddr  */
                                     )
       {
        if (!sockAddr)  return EC_INVALID_PARAM;
        if (port>65535) return EC_INVALID_PARAM;

        ::cli::inet::CIpAddress tmpIpAddr;
        tmpIpAddr.addrType = af;
        if (af==AF_INET)
           {
            tmpIpAddr.addrVec.insert( tmpIpAddr.addrVec.end(), 4, (unsigned short)255 );
           }
        else if (af==AF_INET6)
           {
            tmpIpAddr.addrVec.push_back( 0xFF02 );
            tmpIpAddr.addrVec.insert( tmpIpAddr.addrVec.end(), 6, 0 );
            tmpIpAddr.addrVec.push_back( 1 );
            //return EC_NOT_IMPLEMENTED; // UNDONE: implement broadcast addr for IPv6
           }
        else
           {
            return EC_INVALID_PARAM;
           }
        tmpIpAddr.port = port;
        tmpIpAddr.toPlain(sockAddr);
        return EC_OK;
       }
    #endif // end of obsolete methods


    void makeIpAddrHelper( ::cli::inet::CIpAddress &ipAddr
                         , unsigned short first
                         , unsigned fillCount
                         , unsigned short last
                         , unsigned short fill = 0
                         )
       {
        ipAddr.addrVec.push_back( first );
        ipAddr.addrVec.insert( ipAddr.addrVec.end(), fillCount, fill );
        ipAddr.addrVec.push_back( last );
       }

    template <typename TAddrType>
    RCODE makeAddrByTypeImpl( ENUM_CLI_INET_IPADDRESSFAMILY          af
                            , ENUM_CLI_INET_EMULTICASTADDRESSTYPE    addrType
                            , UINT                                   port
                            , TAddrType                             &resAddr
                            )
       {
        if (af!=AF_INET && af!=AF_INET6) return EC_INVALID_PARAM;
        ::cli::inet::CIpAddress tmpIpAddr;
        tmpIpAddr.addrType = af;
        tmpIpAddr.port     = port;
        switch(addrType)
           {
            case CLI_INET_EMULTICASTADDRESSTYPE_ADDRANY:
                    tmpIpAddr.makeAddrAny( port, af );
                    break;

            case CLI_INET_EMULTICASTADDRESSTYPE_LOCALHOST:
                    if (af==AF_INET) makeIpAddrHelper( tmpIpAddr, 127, 2, 1 ); // 127.0.0.1
                    else             makeIpAddrHelper( tmpIpAddr, 0, 6, 1 ); // ::1
                    break;

            case CLI_INET_EMULTICASTADDRESSTYPE_BROADCAST:                    
                    if (af==AF_INET) tmpIpAddr.addrVec.insert( tmpIpAddr.addrVec.end(), 4, (unsigned short)255 ); // 255.255.255.255
                    else             makeIpAddrHelper( tmpIpAddr, 0xFF02, 6, 1 ); // ff02::1
                    break;

            case CLI_INET_EMULTICASTADDRESSTYPE_LINKLOCAL:
                    if (af==AF_INET) makeIpAddrHelper( tmpIpAddr, 224, 2, 1 ); // 224.0.0.1
                    else             makeIpAddrHelper( tmpIpAddr, 0xFF02, 6, 1 ); // ff02::1
                    break;

            case CLI_INET_EMULTICASTADDRESSTYPE_SITELOCAL:
                    if (af==AF_INET) 
                       { // 192.168.255.255
                        tmpIpAddr.addrVec.push_back( 192 );
                        tmpIpAddr.addrVec.push_back( 168 );
                        tmpIpAddr.addrVec.push_back( 255 );
                        tmpIpAddr.addrVec.push_back( 255 );
                       }
                    else             makeIpAddrHelper( tmpIpAddr, 0xFF05, 6, 1 ); // ff05::1
                    break;

            case CLI_INET_EMULTICASTADDRESSTYPE_ORGANIZATIONLOCAL:
                    if (af==AF_INET) 
                       { // 192.168.255.255
                        tmpIpAddr.addrVec.push_back( 192 );
                        tmpIpAddr.addrVec.push_back( 168 );
                        tmpIpAddr.addrVec.push_back( 255 );
                        tmpIpAddr.addrVec.push_back( 255 );
                       }
                    else             makeIpAddrHelper( tmpIpAddr, 0xFF08, 6, 1 ); // ff08::1
                    break;

            case CLI_INET_EMULTICASTADDRESSTYPE_INVALID:
                    if (af==AF_INET) makeIpAddrHelper( tmpIpAddr, 255, 2, 255, 255 ); // 255.255.255.255
                    else             makeIpAddrHelper( tmpIpAddr, 0xffff, 6, 0xffff, 0xffff ); // ffff.ffff.ffff.ffff.ffff.ffff.ffff.ffff
                    break;

            default: return EC_INVALID_PARAM;
           }
        
        tmpIpAddr.toPlain(&resAddr);
        return EC_OK;
       }

    CLIMETHOD(makeByTypeIpAddr) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                     , ENUM_CLI_INET_EMULTICASTADDRESSTYPE    addrType /* [in] ::cli::inet::EMulticastAddressType  addrType  */
                                     , STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [out,ref] ::cli::inet::IpAddress ipAddr  */
                                )
       {
        if (!ipAddr) return EC_INVALID_PARAM;
        return makeAddrByTypeImpl( af, addrType, 0, *ipAddr );
       }

    CLIMETHOD(makeByTypeSockAddr) (THIS_ ENUM_CLI_INET_IPADDRESSFAMILY    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                       , ENUM_CLI_INET_EMULTICASTADDRESSTYPE    addrType /* [in] ::cli::inet::EMulticastAddressType  addrType  */
                                       , UINT    port /* [in] uint  port  */
                                       , STRUCT_CLI_INET_SOCKETADDRESS*    sockAddr /* [out,ref] ::cli::inet::SocketAddress sockAddr  */
                                  )
       {
        if (!sockAddr) return EC_INVALID_PARAM;
        return makeAddrByTypeImpl( af, addrType, port, *sockAddr );
       }

    CLIMETHOD(canonicalNameGet) (THIS_ CLISTR*           _canonicalName)
       {
        if (!_canonicalName) return EC_INVALID_PARAM;
        if (_canonicalName) CCliStr_copyTo(_canonicalName , canonicalName );
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(addrListGet) (THIS_ STRUCT_CLI_INET_IPADDRESS*    _ipAddr /* [out] ::cli::inet::IpAddress addrList  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                           )
       {
        if (!_ipAddr) return EC_INVALID_PARAM;
        if (idx1>=addrList.size()) return EC_OUT_OF_RANGE;
        const ::cli::inet::CIpAddress &ipAddr = addrList[idx1];
        if (!ipAddr.toPlain(_ipAddr))
           return EC_RESOLV_INVALID_ADDR;
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(addrListGetSocketAddress) (THIS_ STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [out] ::cli::inet::SocketAddress sa  */
                                             , SIZE_T    addrIdx /* [in] size_t  addrIdx  */
                                        )
       {
        if (!sa) return EC_INVALID_PARAM;
        if (addrIdx>=addrList.size()) return EC_OUT_OF_RANGE;
        const ::cli::inet::CIpAddress &ipAddr = addrList[addrIdx];
        if (!ipAddr.toPlain(sa))
           return EC_RESOLV_INVALID_ADDR;
        sa->port = servicePort;
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(addrListSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        if (size) *size = addrList.size();
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(aliasListGet) (THIS_ CLISTR*           aliasStr
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       {
        if (idx1>=aliasList.size()) return EC_OUT_OF_RANGE;
        const ::std::wstring &alias = aliasList[idx1];
        if (aliasStr) CCliStr_copyTo(aliasStr , alias );
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(aliasListSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        if (size) *size = aliasList.size();
        return EC_RESOLV_SUCCESS;
       }


    RCODE thread_unsafe_getHostInfoByName( const ::std::wstring &host
                                         , UINT    afRequested /* [in] ::cli::inet::IpAddressFamily  afRequested  */
                                         )
       {
        canonicalName.clear();
        addrList.clear();
        aliasList.clear();

        if (afRequested==AF_INET || afRequested==AF_INET6)
           {
            return ::cli::inet::getHostInfo( host
                                           , afRequested
                                           , addrList
                                           , &canonicalName
                                           , true
                                           );
           }

        RCODE res1 = ::cli::inet::getHostInfo( host
                                       , AF_INET
                                       , addrList
                                       , &canonicalName
                                       , true
                                       );
        #if defined(WIN32) || defined(_WIN32)
            if (hasAddrInfoFunctions())
        #endif
        //RCODE res2 =
               ::cli::inet::getHostInfo( host
                                       , AF_INET6
                                       , addrList
                                       , res1 ? &canonicalName : (::std::wstring*)0
                                       , true
                                       );

        //if ()
        return res1;
       }



    CLIMETHOD(getHostInfoByName) (THIS_ const CLISTR*     host
                                      , UINT    afRequested /* [in] ::cli::inet::IpAddressFamily  afRequested  */
                                 )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (hasAddrInfoFunctions())
           {
            return thread_unsafe_getHostInfoByName( stdstr(host), afRequested );
           }
        else
           {
            CLI_AUTOLOCK(csGetHostByAddrGuard);
            return thread_unsafe_getHostInfoByName( stdstr(host), afRequested );
           }
        #else
        return thread_unsafe_getHostInfoByName( stdstr(host), afRequested );
        #endif
       }

    CLIMETHOD(getHostInfoByNameChars) (THIS_ const WCHAR*    hostStr /* [in,flat] wchar  hostStr[]  */
                                           , SIZE_T    hostStrSize /* [in] size_t  hostStrSize  */
                                           , UINT    afRequested /* [in] ::cli::inet::IpAddressFamily  afRequested  */
                                      )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (hasAddrInfoFunctions())
           {
            return thread_unsafe_getHostInfoByName( stdstr(hostStr, hostStrSize), afRequested );
           }
        else
           {
            CLI_AUTOLOCK(csGetHostByAddrGuard);
            return thread_unsafe_getHostInfoByName( stdstr(hostStr, hostStrSize), afRequested );
           }
        #else
        return thread_unsafe_getHostInfoByName( stdstr(hostStr, hostStrSize), afRequested );
        #endif
       }
/*
    ::std::wstring                           canonicalName;
    ::std::vector< ::cli::inet::CIpAddress > addrList;
    ::std::vector< ::std::wstring >          aliasList;
*/

    CLIMETHOD(getHostByAddress) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    ipAddr /* [in,ref] ::cli::inet::IpAddress  ipAddr  */)
       {
        canonicalName.clear();
        addrList.clear();
        aliasList.clear();

        ::cli::inet::CIpAddress tmpIpAddress;
        if (!tmpIpAddress.fromPlain(ipAddr))
           return EC_RESOLV_INVALID_ADDR;

        CLI_AUTOLOCK(csGetHostByAddrGuard);

        RCODE res = getHostByAddr( tmpIpAddress
                                 , canonicalName
                                 , aliasList
                                 , true
                                 );
        return res;
       }

    CLIMETHOD(getHostByAddressString) (THIS_ const CLISTR*     ipStr)
       {
        canonicalName.clear();
        addrList.clear();
        aliasList.clear();

        ::cli::inet::CIpAddress tmpIpAddr;
        if (!convertIpAddress( stdstr(ipStr), tmpIpAddr))
           return EC_RESOLV_INVALID_ADDR;

        RCODE res = getHostByAddr( tmpIpAddr
                                 , canonicalName
                                 , aliasList
                                 , true
                                 );
        return res;
       }

    CLIMETHOD(getHostByAddressStringChars) (THIS_ const WCHAR*    ipStr /* [in,flat] wchar  ipStr[]  */
                                                , SIZE_T    ipStrSize /* [in] size_t  ipStrSize  */
                                           )
       {
        canonicalName.clear();
        addrList.clear();
        aliasList.clear();

        //::std::wstring tmpIpStr = (ipStrSize==SIZE_T_NPOS ? ::std::wstring(ipStr) : ::std::wstring(ipStr, ipStrSize));
        ::cli::inet::CIpAddress tmpIpAddr;
        if (!convertIpAddress( stdstr(ipStr, ipStrSize), tmpIpAddr))
           return EC_RESOLV_INVALID_ADDR;

        RCODE res = getHostByAddr( tmpIpAddr
                                 , canonicalName
                                 , aliasList
                                 , true
                                 );
        return res;
       }


    CLIMETHOD(serviceNameGet) (THIS_ CLISTR*           _serviceName)
       {
        if (_serviceName) CCliStr_copyTo(_serviceName , serviceName );
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(serviceAliasesGet) (THIS_ CLISTR*           aliasStr
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
       {
        if (idx1>=serviceAliases.size()) return EC_OUT_OF_RANGE;
        const ::std::wstring &alias = serviceAliases[idx1];
        if (aliasStr) CCliStr_copyTo(aliasStr , alias );
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(serviceAliasesSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        if (size) *size = serviceAliases.size();
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(portGet) (THIS_ UINT*    port /* [out] uint port  */)
       {
        if (port) *port = servicePort;
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(serviceProtocolStrGet) (THIS_ CLISTR*           _serviceProtocolStr)
       {
        if (_serviceProtocolStr) CCliStr_copyTo(_serviceProtocolStr , serviceProtocolStr );
        return EC_RESOLV_SUCCESS;
       }

    CLIMETHOD(serviceProtocolGet) (THIS_ ENUM_CLI_INET_PROTOCOLTYPE*    _serviceProtocol /* [out] ::cli::inet::ProtocolType serviceProtocol  */)
       {
        if (_serviceProtocol) *_serviceProtocol = serviceProtocol;
        return EC_RESOLV_SUCCESS;
       }


    RCODE extractServiceInfo( const struct servent* pse, const ::std::wstring &serv, const ::std::wstring &proto )
       {
        if (!pse)
           {
            ::std::wstring protoCopy = proto;
            if (protoCopy.empty()) protoCopy = L"<empty>";            
            return CLI_SET_ERROR_INFO_ARGS( EC_INVALID_SERV_PROTO , 0, 0, (::cli::format::arg(serv) % protoCopy) );
           }

        if (pse->s_name)
           serviceName = MARTY_CON_NS a2wide(pse->s_name);

        if (pse->s_aliases)
           {
            SIZE_T i = 0;
            char *pAlias = pse->s_aliases[i++];
            while(pAlias)
               {
                serviceAliases.push_back( MARTY_CON_NS a2wide(pAlias) );
                pAlias = pse->s_aliases[i++];
               }
           }

        ::cli::inet::networkToPort( servicePort, (char*)&pse->s_port );

        if (pse->s_proto)
           serviceProtocolStr = MARTY_CON_NS a2wide(pse->s_proto);

        if (serviceProtocolStr==L"tcp")
           serviceProtocol = CLI_INET_PROTOCOLTYPE_TCP;
        else if (serviceProtocolStr==L"udp")
           serviceProtocol = CLI_INET_PROTOCOLTYPE_UDP;

        return EC_OK;
       }

    RCODE getServiceInfoImpl( const ::std::wstring &serv, const ::std::wstring &proto)
       {
        unsigned uport = 0;
        if ( ::cli::inet::convertPort( serv, uport ))
           {
            return getServiceInfoImpl(uport, proto);
           }

        serviceName.clear();
        servicePort = 0;
        serviceAliases.clear();
        serviceProtocolStr.clear();
        serviceProtocol = CLI_INET_PROTOCOLTYPE_UNSPEC;

        ::std::string strServ  = MARTY_CON_NS w2ansi(serv);
        if (strServ.empty())
           {
            return CLI_SET_ERROR_INFO_ARGS( EC_INVALID_PORT       , 0, 0, ::cli::format::arg(L"<empty>") );
           }

        ::std::string strProto = MARTY_CON_NS w2ansi(proto);

        #if !defined(WIN32) && !defined(_WIN32)
        CLI_AUTOLOCK(csGetHostByAddrGuard);
        #endif
        const struct servent* pse = getservbyname( strServ.c_str(), strProto.empty() ? (char*)0 : strProto.c_str() );
        //if (pse)
           return extractServiceInfo( pse
                                    , serv, proto
                                    );
        //struct servent* pse = getservbyname( strServ.c_str(), strProto.empty() ? (char*)0 : strProto.c_str() );
       }

    RCODE getServiceInfoImpl( unsigned port, const ::std::wstring &proto)
       {
        int netPort = 0;
        ::std::wstring portStr;
        portToWideString( port, portStr );

        if (!portToNetwork(port, netPort))
           {
            return CLI_SET_ERROR_INFO_ARGS( EC_INVALID_PORT       , 0, 0, ::cli::format::arg(portStr) );
           }

        ::std::string strProto = MARTY_CON_NS w2ansi(proto);
        #if !defined(WIN32) && !defined(_WIN32)
        CLI_AUTOLOCK(csGetHostByAddrGuard);
        #endif
        const struct servent* pse = getservbyport( netPort, strProto.empty() ? (char*)0 : strProto.c_str() ) ;
        if (pse)
           return extractServiceInfo( pse
                                    , portStr, proto
                                    );
        //else
        serviceName = portStr;
        servicePort = port;

        //::cli::inet::networkToPort( servicePort, (char*)&pse->s_port );

        //serviceProtocolStr = MARTY_CON_NS a2wide(pse->s_proto);

        if (proto==L"tcp")
           serviceProtocol = CLI_INET_PROTOCOLTYPE_TCP;
        else if (proto==L"udp")
           serviceProtocol = CLI_INET_PROTOCOLTYPE_UDP;

        return EC_OK;
       }

    CLIMETHOD(getServiceInfo) (THIS_ UINT    port /* [in] uint  port  */
                                   , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                              )
       {
        ::std::wstring protoStr;
        if (protocol==CLI_INET_PROTOCOLTYPE_TCP)      protoStr = L"tcp";
        else if (protocol==CLI_INET_PROTOCOLTYPE_UDP) protoStr = L"udp";
        return getServiceInfoImpl( port, protoStr );
       }

    CLIMETHOD(getServiceInfoStr) (THIS_ const CLISTR*     portOrName
                                      , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                 )
       {
        ::std::wstring protoStr;
        if (protocol==CLI_INET_PROTOCOLTYPE_TCP)      protoStr = L"tcp";
        else if (protocol==CLI_INET_PROTOCOLTYPE_UDP) protoStr = L"udp";
        return getServiceInfoImpl( stdstr(portOrName), protoStr );
       }

    CLIMETHOD(getServiceInfoStrChars) (THIS_ const WCHAR*    portOrNameStr /* [in,flat] wchar  portOrNameStr[]  */
                                           , SIZE_T    portOrNameStrSize /* [in] size_t  portOrNameStrSize  */
                                           , INT    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                      )
       {
        ::std::wstring protoStr;
        if (protocol==CLI_INET_PROTOCOLTYPE_TCP)      protoStr = L"tcp";
        else if (protocol==CLI_INET_PROTOCOLTYPE_UDP) protoStr = L"udp";
        return getServiceInfoImpl( stdstr(portOrNameStr, portOrNameStrSize), protoStr );
       }

    CLIMETHOD(getServiceInfoStr2) (THIS_ const CLISTR*     portOrName
                                       , const CLISTR*     protocol
                                  )
       {
        return getServiceInfoImpl( stdstr(portOrName), stdstr(protocol) );
       }

    CLIMETHOD(getServiceInfoStr2Chars) (THIS_ const WCHAR*    portOrNameStr /* [in,flat] wchar  portOrNameStr[]  */
                                            , SIZE_T    portOrNameStrSize /* [in] size_t  portOrNameStrSize  */
                                            , const WCHAR*    protocolStr /* [in,flat] wchar  protocolStr[]  */
                                            , SIZE_T    protocolStrSize /* [in] size_t  protocolStrSize  */
                                       )
       {
        return getServiceInfoImpl( stdstr(portOrNameStr, portOrNameStrSize), stdstr(protocolStr, protocolStrSize) );
       }




/*
inline 
RCODE getHostInfo( const ::std::wstring &host
                 , int afRequested
                 , ::std::vector< CIpAddress > &addrList
                 , ::std::wstring *pCanonicalName = 0
                 , bool bSetErrInfo = false
                 )


RCODE getHostName( ::std::wstring &name, bool bSetErrInfo = false )

RCODE getHostByAddr( const CIpAddress &ipAddress
                   , ::std::wstring &name
                   , std::vector< ::std::wstring > aliasList
                   , bool bSetErrInfo = false )
*/


}; // struct CResolverImpl


::cli::CCriticalSection CResolverImpl::csGetHostByAddrGuard;






}; // namespace impl
}; // namespace inet
}; // namespace cli



#endif /* RESOLVIMPL_H */


