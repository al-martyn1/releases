#ifndef SRC_CORE_GUIDGEN_H
#define SRC_CORE_GUIDGEN_H

/* add this lines to your scr
#ifndef SRC_CORE_GUIDGEN_H
    #include "src/core/guidgen.h"
#endif
*/

#ifndef CLI_IGUID_H
    #include <cli/iguid.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_DATETIME_H
    #include <cli/dateTime.h>
#endif

#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif

#include "strconvutil.h"



namespace cli
{
namespace impl
{





struct CGuidGenImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IGUID
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    UINT64 seqNo;
    CGuidGenImpl() : base_impl(DEF_MODULE), seqNo(1)
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CGuidGenImpl()
       {
       }

    CLI_BEGIN_INTERFACE_MAP(CGuidGenImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IGUID )
    CLI_END_INTERFACE_MAP(CGuidGenImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    
       { 
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }

/*
INTERNET-DRAFT                         Rich Salz, Open Group
<draft-leach-uuids-guids-00.txt>
Expires August 24, 1997                    February 24, 1997

                             UUIDs and GUIDs

   Field                      Data      Octet  Note
                              Type      #

   time_low                   unsigned  0-3    The low field of the
                              32 bit           timestamp.
                              integer

   time_mid                   unsigned  4-5    The middle field of the
                              16 bit           timestamp.
                              integer

   time_hi_and_version        unsigned  6-7    The high field of the
                              16 bit           timestamp multiplexed
                              integer          with the version number.

   clock_seq_hi_and_reserved  unsigned         The high field of the
                              8 bit            clock sequence                                        8
                              integer          multiplexed with the
                                               variant.

   clock_seq_low              unsigned  9      The low field of the
                              8 bit            clock sequence.
                              integer

   node                       unsigned         The spatially unique
                              48 bit           node identifier.                                        10-15
                              integer

  To minimize confusion about bit assignments within octets, the UUID
  record definition is defined only in terms of fields that are
  integral numbers of octets. The version number is in the most
  significant 4 bits of the time stamp (time_hi), and the variant field
  is in the most significant 3 bits of the clock sequence
  (clock_seq_high).

*/
    void convertToGuid(STRUCT_CLI_GUID* g, UINT64 p1, UINT64 p2)
       {
        /*
        g->Data4[0] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[1] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[2] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[3] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[4] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[5] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[6] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[7] = (BYTE)(p2&0xFF); p2>>=8;
        */
        g->Data4[7] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[6] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[5] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[4] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[3] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[2] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[1] = (BYTE)(p2&0xFF); p2>>=8;
        g->Data4[0] = (BYTE)(p2&0xFF); p2>>=8;

        g->Data3    = (WORD) (p1&0xFFFF); p1>>=16;
        g->Data2    = (WORD) (p1&0xFFFF); p1>>=16;
        g->Data1    = (DWORD)(p1&0xFFFFFFFF);
       }


    void mixUint(UINT32 uiNow, UINT32 tickNow, UINT32 &p1, UINT32 &p2)
       {
        p1 = 0; p2 = 0;

        SIZE_T i = 0;
        for(;i!=16; ++i)
           {
            if (tickNow&1) p1 += 1;
            p1<<=1; tickNow>>=1;
            if (uiNow&1) p1 += 1;
            p1<<=1; uiNow>>=1;
           }

        i = 0;
        for(;i!=16; ++i)
           {
            if (tickNow&1) p2 += 1;
            p2<<=1; tickNow>>=1;
            if (uiNow&1) p2 += 1;
            p2<<=1; uiNow>>=1;
           }
       }

    UINT64 mixUint64(UINT64 val)
       {
        //UINT64 res = 0;
        UINT32 p32_1 = 0, p32_p2 = 0;
        mixUint((UINT32)(val>>32), (UINT32)(val&0xFFFFFFFF), p32_1, p32_p2);
        return (((UINT64)p32_1)<<32) | ((UINT64)p32_p2);
       }

    void mixUint64(UINT64 uiNow, UINT64 tickNow, UINT64 &p1, UINT64 &p2)
       {
        p1 = 0; p2 = 0;

        SIZE_T i = 0;
        for(;i!=32; ++i)
           {
            if (uiNow&1) p1 += 1;
            p1<<=1; uiNow>>=1;
            if (tickNow&1) p1 += 1;
            p1<<=1; tickNow>>=1;
           }

        i = 0;
        for(;i!=32; ++i)
           {
            if (uiNow&1) p2 += 1;
            p2<<=1; uiNow>>=1;
            if (tickNow&1) p2 += 1;
            p2<<=1; tickNow>>=1;
           }
        UINT64 s1 = p1;
        UINT64 s2 = p2;
        p1 = mixUint64(s2);
        p2 = mixUint64(s1);
       }

    CLIMETHOD(generateGuidEx) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                   , const BYTE*    customPart /* [in,flat] byte  customPart[]  */
                              )
       {
        if (!g) return EC_OK;
        UINT64 uiNow   = (CLI_TIME_T)CDateTime::now();
        UINT64 tickNow = cliGetTickCount();

        UINT64 p1 = uiNow<<32;
        p1 |= ((uiNow>>32)&0xFFFF)<<16;

        //p1 |= ((uiNow>>48)&0xFF);
        ////p1 |= (seqNo&0xFF)<<8;
        //////p1 |= ((uiNow>>48)&0xFFFF);
        ////////p1 |= (((uiNow>>48)&0xFFFF)*seqNo)&0xFFFF;
        p1 |= (((uiNow>>48)&0xFFFF)*seqNo)&0xFFFF;

        ++seqNo;
        //if ((seqNo%16)==0) cli::sched::sleepMs(10);


        //UINT64 p2 = ((tickNow>>48)&0xFFFF)<<48;
        UINT64 p2 = ((tickNow)&0xFFFF)<<48;
        for(SIZE_T i = 0; i!=6; ++i)
           {
            p2 |= ((UINT64)customPart[i])<<(40-i*8);
           }

        mixUint64(p1, p2, p1, p2);

        convertToGuid(g, p1, p2);

        return EC_OK;
       }

    /* interface ::cli::iGuid methods */
    CLIMETHOD(generateGuid) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */)
       {
        BYTE bytes[6] = { 0 };
        //BYTE bytes[6] = { 0x85, 0x02, 0x14, 0xA1, 0x3E, 0x21 };
        return generateGuidEx(g, &bytes[0]);       
        /*
        if (!g) return EC_OK;
        UINT64 uiNow   = (CLI_TIME_T)CDateTime::now();
        UINT64 tickNow = cliGetTickCount();

        UINT64 p1 = 0, p2 = 0;

        mixUint64(uiNow, tickNow, p1, p2);
        convertToGuid(g, p1, p2);

        return EC_OK;
        */
       }

    template<typename CharType>
    void formatImpl( CharType *pBuf, CharType sepChar, bool bUpperCase, const STRUCT_CLI_GUID* g )
    {
     DWORD d1 = g->Data1;
     pBuf[7] = digit2char<CharType>( (unsigned)(d1&0xF), bUpperCase ); d1>>=4;
     pBuf[6] = digit2char<CharType>( (unsigned)(d1&0xF), bUpperCase ); d1>>=4;
     pBuf[5] = digit2char<CharType>( (unsigned)(d1&0xF), bUpperCase ); d1>>=4;
     pBuf[4] = digit2char<CharType>( (unsigned)(d1&0xF), bUpperCase ); d1>>=4;
     pBuf[3] = digit2char<CharType>( (unsigned)(d1&0xF), bUpperCase ); d1>>=4;
     pBuf[2] = digit2char<CharType>( (unsigned)(d1&0xF), bUpperCase ); d1>>=4;
     pBuf[1] = digit2char<CharType>( (unsigned)(d1&0xF), bUpperCase ); d1>>=4;
     pBuf[0] = digit2char<CharType>( (unsigned)(d1&0xF), bUpperCase );

     pBuf[8] = sepChar;

     WORD d2 = g->Data2;
     pBuf[12] = digit2char<CharType>( (unsigned)(d2&0xF), bUpperCase ); d2>>=4;
     pBuf[11] = digit2char<CharType>( (unsigned)(d2&0xF), bUpperCase ); d2>>=4;
     pBuf[10] = digit2char<CharType>( (unsigned)(d2&0xF), bUpperCase ); d2>>=4;
     pBuf[ 9] = digit2char<CharType>( (unsigned)(d2&0xF), bUpperCase );

     pBuf[13] = sepChar;

     d2 = g->Data3;
     pBuf[17] = digit2char<CharType>( (unsigned)(d2&0xF), bUpperCase ); d2>>=4;
     pBuf[16] = digit2char<CharType>( (unsigned)(d2&0xF), bUpperCase ); d2>>=4;
     pBuf[15] = digit2char<CharType>( (unsigned)(d2&0xF), bUpperCase ); d2>>=4;
     pBuf[14] = digit2char<CharType>( (unsigned)(d2&0xF), bUpperCase );

     pBuf[18] = sepChar;

     BYTE d4  = g->Data4[0];
     pBuf[20] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase ); d4>>=4;
     pBuf[19] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase );
     d4  = g->Data4[1];
     pBuf[22] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase ); d4>>=4;
     pBuf[21] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase );

     pBuf[23] = sepChar;

     d4  = g->Data4[2];
     pBuf[25] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase ); d4>>=4;
     pBuf[24] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase );
     d4  = g->Data4[3];
     pBuf[27] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase ); d4>>=4;
     pBuf[26] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase );
     d4  = g->Data4[4];
     pBuf[29] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase ); d4>>=4;
     pBuf[28] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase );
     d4  = g->Data4[5];
     pBuf[31] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase ); d4>>=4;
     pBuf[30] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase );
     d4  = g->Data4[6];
     pBuf[33] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase ); d4>>=4;
     pBuf[32] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase );
     d4  = g->Data4[7];
     pBuf[35] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase ); d4>>=4;
     pBuf[34] = digit2char<CharType>( (unsigned)(d4&0xF), bUpperCase );

     pBuf[36] = 0;
    }
    
    CLIMETHOD_(BOOL, isEqualGuid) (THIS_ const STRUCT_CLI_GUID*    g1 /* [in,ref] ::cli::Guid  g1  */
                                       , const STRUCT_CLI_GUID*    g2 /* [in,ref] ::cli::Guid  g2  */
                                  )
    {
     if (!g1 || !g2) return 0; //EC_INVALID_PARAM;
     return memcmp(g1,g2,sizeof(STRUCT_CLI_GUID)) ? 0 : 1;
    }

    template<typename StringType>
    bool parseStringToGuidImplHlp( const StringType &str
                                 , typename StringType::size_type &curPos
                                 , typename StringType::size_type strSize
                                 , typename StringType::size_type partSize
                                 , UINT64 &res
                                 , bool checkGuidSep = true )
    {
        res = 0;
        typename StringType::size_type i = 0;
        for(; i!=partSize && curPos!=strSize; ++curPos)
           {
            int dig = char2digit( str[curPos] );
            if (dig>=0)
               {
                res<<=4;
                res |= dig&0xF;
                ++i;
                continue;
               }
            //if (str[curPos]==(typename StringType::value_type )'-' || str[curPos]==(typename StringType::value_type )'_')
            //   continue;
            return false;
           }

        if (checkGuidSep)
           {
            int dig = char2digit( str[curPos] );
            if (dig<0) ++curPos;
           }

        return true;
    }

    template<typename StringType>
    bool parseStringToGuidImpl(STRUCT_CLI_GUID* g, const StringType &str )
    {
        UINT64 p = 0;

        typename StringType::size_type curPos = 0, size = str.size();

        if (!parseStringToGuidImplHlp( str, curPos, size, 8, p ))
           return false;
        g->Data1 = p;

        if (!parseStringToGuidImplHlp( str, curPos, size, 4, p ))
           return false;
        g->Data2 = (WORD)p;

        if (!parseStringToGuidImplHlp( str, curPos, size, 4, p ))
           return false;
        g->Data3 = (WORD)p;

        if (!parseStringToGuidImplHlp( str, curPos, size, 4, p ))
           return false;
        g->Data4[0] = (BYTE)((p>>8)&0x0FF);
        g->Data4[1] = (BYTE)((p   )&0x0FF);

        if (!parseStringToGuidImplHlp( str, curPos, size, 2, p ))
           return false;
        g->Data4[2] = (BYTE)((p   )&0x0FF);

        if (!parseStringToGuidImplHlp( str, curPos, size, 2, p ))
           return false;
        g->Data4[3] = (BYTE)((p   )&0x0FF);

        if (!parseStringToGuidImplHlp( str, curPos, size, 2, p ))
           return false;
        g->Data4[4] = (BYTE)((p   )&0x0FF);

        if (!parseStringToGuidImplHlp( str, curPos, size, 2, p ))
           return false;
        g->Data4[5] = (BYTE)((p   )&0x0FF);

        if (!parseStringToGuidImplHlp( str, curPos, size, 2, p ))
           return false;
        g->Data4[6] = (BYTE)((p   )&0x0FF);

        if (!parseStringToGuidImplHlp( str, curPos, size, 2, p, false ))
           return false;
        g->Data4[7] = (BYTE)((p   )&0x0FF);

        return true;
    }

    CLIMETHOD(parseStringToGuid) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                      , const CLISTR*     str
                                 )
    {
        if (!g || !str) return EC_INVALID_PARAM;
        CLI_TRY{
                if (!parseStringToGuidImpl(g, stdstr(str) ))
                   return EC_INVALID_FORMAT;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(parseCharStringToGuid) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                          , const CLICSTR*    str
                                     )
    {
        if (!g || !str) return EC_INVALID_PARAM;
        CLI_TRY{
                if (!parseStringToGuidImpl(g, stdstr(str) ))
                   return EC_INVALID_FORMAT;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(parseStringToGuidChars) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                           , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                           , SIZE_T    strSize /* [in] size_t  strSize  */
                                      )
    {
        if (!g || !str) return EC_INVALID_PARAM;
        CLI_TRY{
                if (!parseStringToGuidImpl(g, stdstr(str, strSize) ))
                   return EC_INVALID_FORMAT;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(parseCharStringToGuidChars) (THIS_ STRUCT_CLI_GUID*    g /* [out] ::cli::Guid g  */
                                               , const CHAR*    str /* [in,flat] char  str[]  */
                                               , SIZE_T    strSize /* [in] size_t  strSize  */
                                          )
    {
        if (!g || !str) return EC_INVALID_PARAM;
        CLI_TRY{
                if (!parseStringToGuidImpl(g, stdstr(str, strSize) ))
                   return EC_INVALID_FORMAT;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(formatGuidToString) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                       , CLISTR*           s
                                  )
    {
        if (!g || !s) return EC_INVALID_PARAM;
        CLI_TRY{
                WCHAR buf[40];
                formatImpl( &buf[0], L'-', true, g );
                return ::cli::propertyGetImpl(s, std::wstring(buf) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(formatGuidToCharString) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                           , CLICSTR*          s
                                      )
    {
        if (!g || !s) return EC_INVALID_PARAM;
        CLI_TRY{
                CHAR buf[40];
                formatImpl( &buf[0], '-', true, g );
                return ::cli::propertyGetImpl(s, std::string(buf) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(formatGuidToStringEx) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                         , CLISTR*           s
                                         , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                         , WCHAR    chSep /* [in] wchar  chSep  */
                                    )
    {
        if (!g || !s) return EC_INVALID_PARAM;
        CLI_TRY{
                WCHAR buf[40];
                formatImpl( &buf[0], chSep, bLowerCase ? false : true, g );
                return ::cli::propertyGetImpl(s, std::wstring(buf) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(formatGuidToCharStringEx) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                             , CLICSTR*          s
                                             , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                             , CHAR    chSep /* [in] char  chSep  */
                                        )
    {
        if (!g || !s) return EC_INVALID_PARAM;
        CLI_TRY{
                CHAR buf[40];
                formatImpl( &buf[0], chSep, bLowerCase ? false : true, g );
                return ::cli::propertyGetImpl(s, std::string(buf) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(formatGuidToStringBuf) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                          , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                     )
    {
        if (!g || !buf) return EC_INVALID_PARAM;
        CLI_TRY{
                formatImpl( &buf[0], L'-', true, g );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(formatGuidToCharStringBuf) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                              , CHAR*    buf /* [out,flat] char buf[]  */
                                         )
    {
        if (!g || !buf) return EC_INVALID_PARAM;
        CLI_TRY{
                formatImpl( &buf[0], '-', true, g );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(formatGuidToStringExBuf) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                            , WCHAR*    buf /* [out,flat] wchar buf[]  */
                                            , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                            , WCHAR    chSep /* [in] wchar  chSep  */
                                       )
    {
        if (!g || !buf) return EC_INVALID_PARAM;
        CLI_TRY{
                formatImpl( &buf[0], chSep, bLowerCase ? false : true, g );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }

    CLIMETHOD(formatGuidToCharStringExBuf) (THIS_ const STRUCT_CLI_GUID*    g /* [in,ref] ::cli::Guid  g  */
                                                , CHAR*    buf /* [out,flat] char buf[]  */
                                                , BOOL    bLowerCase /* [in] bool  bLowerCase  */
                                                , CHAR    chSep /* [in] char  chSep  */
                                           )
    {
        if (!g || !buf) return EC_INVALID_PARAM;
        CLI_TRY{
                formatImpl( &buf[0], chSep, bLowerCase ? false : true, g );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
    }




}; // struct CGuidGenImpl


}; // namespace impl
}; // namespace cli


#endif /* SRC_CORE_GUIDGEN_H */

