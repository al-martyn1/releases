#define CLI_INTERNAL

#ifndef CLI_FORMAT_H
    #include <cli/format.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#include "alvariant.h"

#include <marty/readersWriters.h>
#include <cli/csec.h>

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

//-----------------------------------------------------------------------------
namespace cli
{
namespace format
{
namespace impl
{

struct CFormaterProcListEntry
{
    ::std::wstring      formaterName;
    cliFormaterProcT    proc;

    CFormaterProcListEntry( ) : formaterName(), proc(0) {}
    CFormaterProcListEntry( const ::std::wstring &fn, cliFormaterProcT p) : formaterName(fn), proc(p) {}

    bool operator<( const CFormaterProcListEntry &e) const
       { return formaterName<e.formaterName; }
    bool operator<=( const CFormaterProcListEntry &e) const
       { return formaterName<=e.formaterName; }
    bool operator>( const CFormaterProcListEntry &e) const
       { return formaterName>e.formaterName; }
    bool operator>=( const CFormaterProcListEntry &e) const
       { return formaterName>=e.formaterName; }
    bool operator==( const CFormaterProcListEntry &e) const
       { return formaterName==e.formaterName; }
    bool operator!=( const CFormaterProcListEntry &e) const
       { return formaterName!=e.formaterName; }

};

struct CFormaterObjectListEntry
{
    ::std::wstring               formaterName;
    //INTERFACE_CLI_IFORMATER     *pFormater;
    CiFormater                   formater;

    CFormaterObjectListEntry() : formaterName(), formater() {}
    CFormaterObjectListEntry(const ::std::wstring &fn, INTERFACE_CLI_IFORMATER *pFormater) : formaterName(fn), formater(pFormater) {}
    CFormaterObjectListEntry& operator=( const CFormaterObjectListEntry &e)
       {
        if (&e==this) return *this;
        formaterName = e.formaterName;
        formater     = e.formater;
        return *this;
       }

    bool operator<( const CFormaterObjectListEntry &e) const
       { return formaterName<e.formaterName; }
    bool operator<=( const CFormaterObjectListEntry &e) const
       { return formaterName<=e.formaterName; }
    bool operator>( const CFormaterObjectListEntry &e) const
       { return formaterName>e.formaterName; }
    bool operator>=( const CFormaterObjectListEntry &e) const
       { return formaterName>=e.formaterName; }
    bool operator==( const CFormaterObjectListEntry &e) const
       { return formaterName==e.formaterName; }
    bool operator!=( const CFormaterObjectListEntry &e) const
       { return formaterName!=e.formaterName; }
};

typedef 
::marty::rwu::CMultipleReadersWritersDataHolder< ::cli::CCriticalSection
                                               , ::cli::CSpinWaitFlag
                                               , ::cli::CInterlockedCounterWithPassTroughOnZero
                                               , ::std::vector< CFormaterProcListEntry >
                                               , ::marty::rwu::CDoNothing // TStorageConstructorObject
                                               , ::marty::rwu::CDoNothing // TStorageDestructObject
                                               > CFormaterProcList; // formaterProcList

typedef
::marty::rwu::CMultipleReadersWritersDataHolder< ::cli::CCriticalSection
                                               , ::cli::CSpinWaitFlag
                                               , ::cli::CInterlockedCounterWithPassTroughOnZero
                                               , ::std::vector< CFormaterObjectListEntry >
                                               , ::marty::rwu::CDoNothing // TStorageConstructorObject
                                               , ::marty::rwu::CDoNothing // TStorageDestructObject
                                               > CFormaterObjectList; // formaterObjectList

struct CProcListAddItem
{
    CFormaterProcListEntry entryToAdd;
    CProcListAddItem( const CFormaterProcListEntry &e) : entryToAdd(e) {}

    void operator()( ::std::vector< CFormaterProcListEntry > &v) const
       {
        using namespace ::cli::util;

        ::std::vector< CFormaterProcListEntry >::iterator it = binary_find(v.begin(), v.end(), entryToAdd );
        if (it!=v.end())
           {
            it->proc = entryToAdd.proc;
           }
        else
           {
            v.push_back(entryToAdd);
            std::sort(v.begin(), v.end());
           }
       }
};

struct CProcListGetItem
{
    CFormaterProcListEntry foundEntry;

    CProcListGetItem( const ::std::wstring &fn ) : foundEntry( fn, 0 ) {}

    void operator()( const ::std::vector< CFormaterProcListEntry > &v)
       {      
        using namespace ::cli::util;

        ::std::vector< CFormaterProcListEntry >::const_iterator it = binary_find(v.begin(), v.end(), foundEntry );
        if (it!=v.end())
           {
            foundEntry.proc = it->proc;
           }       
       }
};
/*
    void readData( ReadOperator &op) const 
    void readData( const ReadOperator &op) const 
    void writeData( const WriteOperator &op)
*/

}; // namespace impl
}; // namespace format
}; // namespace cli



::cli::format::impl::CFormaterProcList      formaterProcList;
::cli::format::impl::CFormaterObjectList    formaterObjectList;


CLIAPIENTRY
RCODE
CLICALL
cliRegisterFormaterProc( const WCHAR *fmtName, cliFormaterProcT proc)
   {
    using namespace ::cli::format::impl;
    CLI_TRY{
            if (!fmtName || !proc) return EC_INVALID_PARAM;
            //::cli::format::impl::
            formaterProcList.writeData( CProcListAddItem( CFormaterProcListEntry( fmtName, proc ) ) );
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }

CLIAPIENTRY
RCODE
CLICALL
cliRegisterFormaterObject( const WCHAR *fmtName, INTERFACE_CLI_IFORMATER *pFormater)
   {
    //using namespace ::cli::format::impl;
    return EC_NOT_IMPLEMENTED;
   }



CLIAPIENTRY
RCODE
CLICALL
cliProcFormatStringEx( cliFormaterProcT proc
                       , WCHAR*    charBuf
                       , SIZE_T   *charBufSize
                       , const WCHAR*    fmtStrChars
                       , SIZE_T    fmtStrCharsSize
                       , INTERFACE_CLI_IARGLIST*    arglist
                       , SIZE_T    argNo
                       )
   {
/*
SIZE_T
(CLICALL *cliFormaterProcT)( WCHAR*    charBuf
                           , SIZE_T    charBufSize
                           , const WCHAR*    fmtStrChars
                           , SIZE_T    fmtStrCharsSize
                           , INTERFACE_CLI_IARGLIST*    arglist
                           , SIZE_T    argNo
                           );

*/
    using namespace ::cli::format::impl;
    if (!charBufSize)  return EC_INVALID_PARAM;
    if (!charBuf && !charBufSize) return EC_INVALID_PARAM;

    if (!charBuf) // only calc required space
       {
        SIZE_T resLen = proc( 0 /* charBuf */
                            , 0  /* charBufSize */
                            , fmtStrChars
                            , fmtStrCharsSize
                            , arglist
                            , argNo
                            );
        *charBufSize = resLen;
        return EC_OK;
       }
    else
       {
        SIZE_T takenSize = *charBufSize;
        SIZE_T resLen = proc( charBuf
                            , takenSize
                            , fmtStrChars
                            , fmtStrCharsSize
                            , arglist
                            , argNo
                            );
       *charBufSize = resLen;
        if ((takenSize-1) == resLen) return EC_NOT_ENOUGH_MEM;
        return EC_OK;
       }
   }

CLIAPIENTRY
RCODE
CLICALL
cliCustomFormatStringEx( const WCHAR *fmtName
                       , WCHAR*    charBuf
                       , SIZE_T   *charBufSize
                       , const WCHAR*    fmtStrChars
                       , SIZE_T    fmtStrCharsSize
                       , INTERFACE_CLI_IARGLIST*    arglist
                       , SIZE_T    argNo
                       )
   {
    using namespace ::cli::format::impl;
    CLI_TRY{
            if (!fmtName) return EC_INVALID_PARAM;

            CProcListGetItem getter( fmtName );
            //::cli::format::impl::
            formaterProcList.readData( getter );
            if (getter.foundEntry.proc)
               return cliProcFormatStringEx( getter.foundEntry.proc
                                           , charBuf
                                           , charBufSize
                                           , fmtStrChars
                                           , fmtStrCharsSize
                                           , arglist
                                           , argNo
                                           );

           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_NO_SUCH_OBJECT;
   }

CLIAPIENTRY
RCODE
CLICALL
cliCustomFormatString( const WCHAR *fmtName
                     , WCHAR*    charBuf
                     , SIZE_T   *charBufSize
                     , const WCHAR*    fmtStrChars
                     , SIZE_T    fmtStrCharsSize
                     , INTERFACE_CLI_IARGLIST*    arglist
                     )
   {
    return cliCustomFormatStringEx( fmtName, charBuf, charBufSize, fmtStrChars, fmtStrCharsSize, arglist, 0 );
   }


