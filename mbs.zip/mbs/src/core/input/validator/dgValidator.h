#ifndef CORE_INPUT_VALIDATOR_DGVALIDATOR_H
#define CORE_INPUT_VALIDATOR_DGVALIDATOR_H

#ifndef CLI_INPUT_IVALIDATOR_H
    #include <cli/input/ivalidator.h>
#endif

#ifndef CLI_INPUT_VALIDATORIMPLBASE_H
    #include <cli/input/validatorImplBase.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CORE_INPUT_VALIDATOR_BASEPARSER_H
    #include "baseParser.h"
#endif

#include "../../fp_ADGParser_Automata.h"
#include "../../dateTimeHlp.h"

#ifndef MARTY_CASECONV_H
    #include <marty/caseconv.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef MARTY_ENV_H
    #include <marty/env.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif


namespace cli
{
namespace input
{
namespace validator
{
namespace impl
{



template <typename TINT, typename TDOUBLE>
struct CDegreeValue
{
    TINT      sign;
    TINT      degrees;
    TINT      minutes;
    TINT      seconds;
    //bool      bMinutesFloat; // if false, floatPart used as second float part
    unsigned  fpType;   // 0 - unknown, 1 - degrees, 2 - minutes, 3 - seconds
    TDOUBLE   floatPart;
    TINT      iFloatPart;

    TDOUBLE   radan; // angle in radians

    CDegreeValue() : sign(), degrees(), minutes(), seconds(), fpType(0), floatPart(), radan() {}
    CDegreeValue( TINT ti, TDOUBLE td) : sign(ti), degrees(ti), minutes(ti), seconds(ti), fpType(0), floatPart(td), radan(td) {}
};




class CDegreeParser : public CFormatParserImplBase, public ::cli::format::impl::CDGFormatParser
{
    public:

        CDegreeValue< INT64, DOUBLE >   degreeVal;

    protected:

        CDegreeValue< ::std::wstring::size_type, ::std::wstring::size_type >   fParsed;

        INT64 degreeLimLow;
        INT64 degreeLimHigh;


    /*
        class CFormatParserImplBase members
        const ::std::wstring         &parsedString;
        ::std::wstring::size_type    curPos;
        bool                         fParsingFailed;
        unsigned                     ignoreNextStatement;
        UINT64                       curVal;
        bool                         inQuote;
        ::std::wstring               quotedBuf;
    */

    protected:

        void skipSpaces()
           {
            ::std::wstring::size_type size = parsedString.size();
            for(; curPos!=size; ++curPos)
               {
                if (parsedString[curPos]!=L' ') break;
               }
           }

        void readSign(WCHAR negSign, WCHAR posSign)
           {
            if (isFieldParsed(fParsed.sign)) { fParsingFailed = true; return; }
            fParsed.sign = curPos;
            skipSpaces();
            ::std::wstring::size_type psSize = parsedString.size();
            if (curPos==psSize) { fParsingFailed = true; return; }
            if (parsedString[curPos]==posSign) { degreeVal.sign = 1; ++curPos; }
            else if (parsedString[curPos]==negSign) { degreeVal.sign = -1; ++curPos; }
            else { degreeVal.sign = 1; }
           }

        //INT64
        void readMicroVal( unsigned width, bool bLeadingZeros )
           {
            //if (microVal>=1000000) microVal = 999999;
            unsigned tmp = width;
            if (!bLeadingZeros) tmp = 0;

            if (width>5) width = 5;
            INT64 scale = 1;
            for(unsigned i=0; i!=(5-width); ++i) scale *= 10;

            readInt(width+1, tmp+1);
            if (fParsingFailed) return;
            curVal *= scale;
           }



        void
        implParseEvent
                   ( WCHAR    ch
                   , UINT     dtField
                   , unsigned width
                   )
           {
            if (width>2)
               {
                //if ((dtField&DTF_PARTMASK) == DTF_MICROSEC)
                //   width = 5;
                //else if ((dtField&DTF_PARTMASK) != DTF_EQ)
                //   width = 3;
               }

            if (!dtField) // not a field, just symbol
               {
                if (ch==L' ') // space in parse format string means that we must ignore
                   {          // all continious space sequences (including zero-len sequence)
                    skipSpaces();
                   }
               }
            else
               {
                switch(dtField&DTF_PARTMASK)
                   {
                    case DTF_IGNORE:  ignoreNextStatement = DTF_IGNORE;  break;
                    case DTF_SIGNORE: ignoreNextStatement = DTF_SIGNORE; break;

                    case DTF_DSTR:
                    case DTF_MSTR:
                    case DTF_SSTR:
                          if ((dtField&DTF_PARTMASK)==DTF_DSTR)
                             quotedBuf = ::std::wstring(L"\xb0");
                          else if ((dtField&DTF_PARTMASK)==DTF_MSTR)
                             quotedBuf = ::std::wstring(L"\'");
                          else if ((dtField&DTF_PARTMASK)==DTF_SSTR)
                             quotedBuf = ::std::wstring(L"\"");
                          width = (unsigned)quotedBuf.size();

                    case DTF_EQ:
                         {
                          if (!ignoreNextStatement)
                             { // parsed string must exact match to template
                              ::std::wstring::size_type psSize = parsedString.size();
                              ::std::wstring::size_type qbi = 0, qbSize  = quotedBuf.size();
                              for(; qbi!=qbSize && curPos!=psSize; ++curPos, ++qbi)
                                 {
                                  if (parsedString[curPos]!=quotedBuf[qbi])
                                     {
                                      fParsingFailed = true;
                                      return;
                                     }
                                 }
                             }
                          else if (ignoreNextStatement==DTF_SIGNORE)
                             {
                              ::std::wstring::size_type sizeToIgnore = quotedBuf.size();
                              ::std::wstring::size_type tailSize = parsedString.size() - curPos;
                              if (sizeToIgnore > tailSize) sizeToIgnore = tailSize;
                              curPos += sizeToIgnore;
                              ignoreNextStatement = 0;
                             }
                          else
                             {
                              ::std::wstring::size_type psSize = parsedString.size();
                              ::std::wstring::size_type qbi = 0, qbSize  = quotedBuf.size();
                              for(; qbi!=qbSize && curPos!=psSize; ++curPos, ++qbi)
                                 { // ignoring only matched part
                                  if (parsedString[curPos]!=quotedBuf[qbi]) break;
                                 }
                              ignoreNextStatement = 0;
                             }
                         }
                         break;

                case DTF_LAT:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          readSign(L'S', L'N');
                          degreeLimLow = 0;
                          degreeLimHigh = 90;
                          break;
                         }

                case DTF_LONG:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          readSign(L'W', L'E');
                          degreeLimLow = 0;
                          degreeLimHigh = 180;
                          break;
                         }

                case DTF_SIGN:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          readSign(L'-', L'+');
                          break;
                         }

                case DTF_DEG:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          if (isFieldParsed(fParsed.degrees)) { fParsingFailed = true; return; }
                          if (degreeVal.fpType && degreeVal.fpType!=1) { fParsingFailed = true; return; }

                          //if (curPos==psSize) { fParsingFailed = true; return; }
                          fParsed.degrees = curPos;
                          skipSpaces();

                          readInt( 3 );
                          degreeVal.degrees = curVal;
                          break;
                         }

                case DTF_MIN:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          if (isFieldParsed(fParsed.minutes)) { fParsingFailed = true; return; }
                          if (degreeVal.fpType && degreeVal.fpType!=2) { fParsingFailed = true; return; }

                          //if (curPos==psSize) { fParsingFailed = true; return; }
                          fParsed.minutes = curPos;
                          skipSpaces();

                          readInt( 2 );
                          degreeVal.minutes = curVal;
                          break;
                         }

                case DTF_SEC:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          if (isFieldParsed(fParsed.seconds)) { fParsingFailed = true; return; }
                          if (degreeVal.fpType && degreeVal.fpType!=2) { fParsingFailed = true; return; }

                          //if (curPos==psSize) { fParsingFailed = true; return; }
                          fParsed.seconds = curPos;
                          skipSpaces();

                          readInt( 2 );
                          degreeVal.seconds = curVal;
                          break;
                         }

                case DTF_MDEG:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          // if degrees not parsed, float part of degrees not allowed
                          if (!isFieldParsed(fParsed.degrees)) { fParsingFailed = true; return; }
                          // float part allready parsed
                          if (degreeVal.fpType) { fParsingFailed = true; return; }
                          readMicroVal( width, (dtField&DTF_ZEROS ? true : false) );
                          if (fParsingFailed) return;
                          degreeVal.floatPart = (double)curVal / 1000000.0;
                          degreeVal.iFloatPart = curVal;
                          degreeVal.fpType = 1;
                          break;
                         }

                case DTF_MMIN:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          // if minutes not parsed, float part of minutes not allowed
                          if (!isFieldParsed(fParsed.minutes)) { fParsingFailed = true; return; }
                          // float part allready parsed
                          if (degreeVal.fpType) { fParsingFailed = true; return; }
                          readMicroVal( width, (dtField&DTF_ZEROS ? true : false) );
                          if (fParsingFailed) return;
                          degreeVal.floatPart = (double)curVal / 1000000.0;
                          degreeVal.iFloatPart = curVal;
                          degreeVal.fpType = 2;
                          break;
                         }

                case DTF_MICROSEC:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          // if seconds not parsed, float part of seconds not allowed
                          if (!isFieldParsed(fParsed.seconds)) { fParsingFailed = true; return; }
                          // float part allready parsed
                          if (degreeVal.fpType) { fParsingFailed = true; return; }
                          readMicroVal( width, (dtField&DTF_ZEROS ? true : false) );
                          if (fParsingFailed) return;
                          degreeVal.floatPart = (double)curVal / 1000000.0;
                          degreeVal.iFloatPart = curVal;
                          degreeVal.fpType = 2;
                          break;
                         }


/*
                    case DTF_MICROSEC:
                            break;
                    case :
                            break;
                    case :
                            break;
                    case :
                            break;
                    default:
*/
                   }
               }
           }

        void
        appendToOut
                   ( WCHAR  ch
                   , UINT   dtField
                   , int    width
                   )
           {
            return CFormatParserImplBase::appendToOut( ch, dtField, width );
           }

        virtual
        void
        customResetAutomata
                           (
                           )
           {
            _dtField = 0;
            _width   = 0;

            curPos                = 0;
            fParsingFailed        = false;
            ignoreNextStatement   = 0;
            curVal                = 0;
            degreeVal.sign        = 1;

            /*
            twoDigitYear          = false;
            yearParsed            = ::std::wstring::npos;
            monthParsed           = ::std::wstring::npos;
            monthNameParsed       = ::std::wstring::npos;
            dayOfWeekParsed       = ::std::wstring::npos;
            dayParsed             = ::std::wstring::npos;
            hourParsed            = ::std::wstring::npos;
            minuteParsed          = ::std::wstring::npos;
            secondParsed          = ::std::wstring::npos;
            microsecParsed        = ::std::wstring::npos;
            gmOffsetParsed        = ::std::wstring::npos;
            ampmParsed            = ::std::wstring::npos;
            ampm                  = false;
            hour12                = false;

            dateTime.year         = 0;
            dateTime.month        = 1;
            dateTime.dayOfWeek    = 0;
            dateTime.day          = 1;
            dateTime.hour         = 0;
            dateTime.minute       = 0;
            dateTime.second       = 0;
            dateTime.microsec     = 0;
            dateTime.gmOffset     = 0;
            */
           }

        bool isFieldParsed( ::std::wstring::size_type pos)
           {
            return pos!=::std::wstring::npos;
           }

    public:

        CDegreeParser( const ::std::wstring &_parsedString
                     )
           : CFormatParserImplBase(_parsedString)
           , degreeVal( 0, 0.0 )
           , fParsed( ::std::wstring::npos, ::std::wstring::npos )
           , degreeLimLow(0)
           , degreeLimHigh(0)
           {
           }

        bool checkDataIntegrity()
           {
            double degrees = 0;
            if (isFieldParsed(fParsed.degrees))
               {
                if (degreeLimHigh)
                   {
                    if (degreeVal.degrees<degreeLimLow)
                       { fParsingFailed = true; curPos = fParsed.degrees; return false; }

                    if (degreeVal.degrees==degreeLimHigh)
                       {
                        if ( (isFieldParsed(fParsed.minutes) && (degreeVal.minutes!=0))
                          || (isFieldParsed(fParsed.seconds) && (degreeVal.seconds!=0))
                          || ((degreeVal.fpType>0) && (degreeVal.iFloatPart>0))
                           )
                           { fParsingFailed = true; curPos = fParsed.degrees; return false; }
                        else
                           { // exact high
                           }
                       }
                    else if (degreeVal.degrees>degreeLimHigh)
                       {
                        fParsingFailed = true; curPos = fParsed.degrees; return false;
                       }
                   }
                degrees = (double)degreeVal.degrees;
                //if (degreeVal.fpType==1) degrees += degreeVal.floatPart;
                if (degreeVal.fpType==1) degrees += (double)degreeVal.iFloatPart / 1000000.0;

               }

            if (isFieldParsed(fParsed.minutes))
               {
                if (degreeVal.minutes<0 || degreeVal.minutes>59)
                   { fParsingFailed = true; curPos = fParsed.minutes; return false; }

                double minutes = (double)degreeVal.minutes;
                //if (degreeVal.fpType==2) minutes += degreeVal.floatPart;
                if (degreeVal.fpType==2) minutes += (double)degreeVal.iFloatPart / 1000000.0;
                degrees += minutes/60.0;
               }

            if (isFieldParsed(fParsed.seconds))
               {
                if (degreeVal.seconds<0 || degreeVal.seconds>59)
                   { fParsingFailed = true; curPos = fParsed.seconds; return false; }

                double seconds = (double)degreeVal.seconds;
                //if (degreeVal.fpType==3) seconds += degreeVal.floatPart;
                if (degreeVal.fpType==3) seconds += (double)degreeVal.iFloatPart / 1000000.0;
                degrees += seconds/3600.0;
               }

            if (isFieldParsed(fParsed.sign))
               {
                if (degreeVal.sign<0)
                degrees = -degrees;
               }

            static double PI_number = 3.14159265358979323846; // 26433832795;
            degreeVal.radan = degrees * PI_number / 180.0;
            //fmtParser.dDegrees * PI_number / 180.0 = radianAngle;
            return true;
           }

}; // class CDegreeParser




struct CDegreeValidatorImpl : public CValidatorImplBase
{

    /*
     CValidatorImplBase members:
        std::wstring             formatString;
        std::wstring             testString;
        std::wstring::size_type  validLen;
    */

    public:

        CDegreeValidatorImpl()
           : CValidatorImplBase()
           {}

        void destroy() { delete this; }

        CLI_BEGIN_INTERFACE_MAP2(CDegreeValidatorImpl, INTERFACE_CLI_INPUT_IVALIDATOR)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INPUT_IVALIDATOR )
        CLI_END_INTERFACE_MAP(CDegreeValidatorImpl)

        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

        bool parseDateTime( CDegreeValue< INT64, DOUBLE > &degreeVal )
           {
            CDegreeParser fmtParser(testString); // string to convert

            //fmtParser.pDateTime = (STRUCT_CLI_CLISYSTEMTIME*)&dateTime;
            fmtParser.resetAutomata();
            ::std::wstring::size_type i = 0, size = formatString.size();
            for(; i!=size && !fmtParser.isFailed(); ++i)
               {
                fmtParser.putChar( formatString[i] );
               }
            if (!fmtParser.isFailed())
               {
                fmtParser.eod();
                fmtParser.checkDataIntegrity();
               }
            validLen = fmtParser.getValidPos();
            degreeVal = fmtParser.degreeVal;

            return !fmtParser.isFailed();
           }


        CLIMETHOD(validateString) (THIS)
           {
            CDegreeValue< INT64, DOUBLE > degreeVal;
            if (!parseDateTime( degreeVal ))
               return EC_TEST_FAILED;
            return EC_OK;
           }

        CLIMETHOD(convertString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                 )
           {
            CDegreeValue< INT64, DOUBLE > degreeVal;
            if (!parseDateTime( degreeVal ))
               {
                data->setEmpty(idx);
                return EC_TEST_FAILED;
               }

            data->setDouble(idx, degreeVal.radan);
            return EC_OK;
            //return EC_NOT_IMPLEMENTED;
           }

        CLIMETHOD(buildSampleString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                          , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                     )
           {
            ::std::wstring fmt = ::cli::format::message( L"%%%1%2!c!:degree:%3%2!c!", ::cli::format::arg( (unsigned)(idx+1) ) % (WCHAR)L'!' % formatString );
            testString = ::cli::format::message( fmt, data );
            validLen = testString.size();
            return EC_OK;
           }

};



}; // namespace impl
}; // namespace validator
}; // namespace format
}; // namespace cli


#endif /* CORE_INPUT_VALIDATOR_DGVALIDATOR_H */

