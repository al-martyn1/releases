#ifndef CORE_INPUT_VALIDATOR_DTVALIDATOR_H
#define CORE_INPUT_VALIDATOR_DTVALIDATOR_H

#ifndef CLI_INPUT_IVALIDATOR_H
    #include <cli/input/ivalidator.h>
#endif

#ifndef CLI_INPUT_VALIDATORIMPLBASE_H
    #include <cli/input/validatorImplBase.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CORE_INPUT_VALIDATOR_BASEPARSER_H
    #include "baseParser.h"
#endif

#include "../../fp_ADTParser_Automata.h"
#include "../../dateTimeHlp.h"

#ifndef MARTY_CASECONV_H
    #include <marty/caseconv.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef MARTY_ENV_H
    #include <marty/env.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif


namespace cli
{
namespace input
{
namespace validator
{
namespace impl
{


const WCHAR *wdays[] = { L"Monday", L"Mon", L"Tuesday", L"Tue", L"Wednesday", L"Wed", L"Thursday", L"Thu", L"Friday", L"Fri", L"Saturday", L"Sat", L"Sunday", L"Sun" };
const WCHAR *months[]= { L"January", L"Jan", L"February", L"Feb", L"March", L"Mar", L"April", L"Apr", L"May", L"May", L"June", L"Jun", L"July", L"Jul", L"August", L"Aug", L"September", L"Sep", L"October", L"Oct", L"November", L"Nov", L"December", L"Dec" };


template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
::std::basic_string<CharType, Traits, Allocator>
upperCase( const ::std::basic_string<CharType, Traits, Allocator> &str)
   {
    #if !(defined(WIN32) || defined(_WIN32))
    ::std::string lang;
    if (!marty::env::getVar(::std::string("LANG"), lang))
       lang = "C";
    #endif
    return ::marty::util::upperCase( str
                                   #if defined(WIN32) || defined(_WIN32)
                                   , MARTY_NS filename::utils::makeCurrentLocale()
                                   #else
                                   , ::std::locale(lang.c_str())
                                   #endif
                                   );
   }

template< typename CharType 
        , typename Traits   
        , typename Allocator
        >
::std::basic_string<CharType, Traits, Allocator>
lowerCase( const ::std::basic_string<CharType, Traits, Allocator> &str)
   {
    #if !(defined(WIN32) || defined(_WIN32))
    ::std::string lang;
    if (!marty::env::getVar(::std::string("LANG"), lang))
       lang = "C";
    #endif
    return ::marty::util::lowerCase( str
                                   #if defined(WIN32) || defined(_WIN32)
                                   , MARTY_NS filename::utils::makeCurrentLocale()
                                   #else
                                   , ::std::locale(lang.c_str())
                                   #endif
                                   );
   }



class CDatetimeParser : public CFormatParserImplBase, public ::cli::format::impl::CDTFormatParser
{

    /*
        class CFormatParserImplBase members
        const ::std::wstring         &parsedString;
        ::std::wstring::size_type    curPos;
        bool                         fParsingFailed;
        unsigned                     ignoreNextStatement;
        UINT64                       curVal;
        bool                         inQuote;
        ::std::wstring               quotedBuf;
    */

        ::std::map< ::std::wstring, unsigned >      wdayNames;
        ::std::map< ::std::wstring, unsigned >      monthNames;
        ::std::map< ::std::wstring, unsigned >      ampmNames;
        STRUCT_CLI_CLISYSTEMTIME                    &dateTime;

        bool                        twoDigitYear;
        ::std::wstring::size_type   yearParsed;
        ::std::wstring::size_type   monthParsed;
        ::std::wstring::size_type   monthNameParsed;
        ::std::wstring::size_type   dayOfWeekParsed;
        ::std::wstring::size_type   dayParsed;
        ::std::wstring::size_type   hourParsed;
        ::std::wstring::size_type   minuteParsed;
        ::std::wstring::size_type   secondParsed;
        ::std::wstring::size_type   microsecParsed;
        ::std::wstring::size_type   gmOffsetParsed;
        ::std::wstring::size_type   ampmParsed;
        bool                        ampm;
        bool                        hour12;


    protected:

        void skipSpaces()
           {
            ::std::wstring::size_type size = parsedString.size();
            for(; curPos!=size; ++curPos)
               {
                if (parsedString[curPos]!=L' ') break;
               }
           }


        void parseStringValue( WORD &v, const ::std::map< ::std::wstring, unsigned > &m)
           {
            ::std::wstring::size_type psSize = parsedString.size();
            if (curPos==psSize)
               {
                fParsingFailed = true;
                return;
               }
            ::std::wstring::size_type maxStrLen = getMaxKeyLen( m );
            ::std::wstring::size_type tailLen = psSize - curPos;
            if (maxStrLen>tailLen) maxStrLen = tailLen;

            ::std::wstring::size_type len = maxStrLen;

            bool bFound = false;
            //for(; len!=0 && (curPos+len-1)!=psSize; --len)
            for(; len!=0; --len)
               {
                ::std::map< ::std::wstring, unsigned >::const_iterator 
                       mit = m.find( upperCase( ::std::wstring( parsedString
                                                              , curPos
                                                              , len
                                                              )
                                              )
                                   );
                if (mit!=m.end()) // found name
                   {
                    v = (WORD)mit->second;
                    bFound = true;
                    curPos += len; // add len of name
                    break;
                   }
               }
            if (!bFound)
               {
                fParsingFailed = true;
               }
           }


        void
        implParseEvent
                   ( WCHAR    ch          
                   , UINT     dtField     
                   , unsigned width       
                   )
           {
            if (width>2)
               {
                if ((dtField&DTF_PARTMASK) == DTF_MICROSEC)
                   width = 5;
                else if ((dtField&DTF_PARTMASK) != DTF_EQ)
                   width = 3;
               }

            if (!dtField) // not a field, just symbol
               {
                if (ch==L' ') // space in parse format string means that we must ignore 
                   {          // all continious space sequences (including zero-len sequence)
                    skipSpaces();
                   }
               }
            else
               {
                switch(dtField&DTF_PARTMASK)
                   {
                    case DTF_IGNORE:  ignoreNextStatement = DTF_IGNORE;  break;
                    case DTF_SIGNORE: ignoreNextStatement = DTF_SIGNORE; break;

                    case DTF_TIMESEP:
                    case DTF_DATESEP:
                          if ((dtField&DTF_PARTMASK)==DTF_TIMESEP)
                             quotedBuf = ::cli::format::impl::getLocaleTimeSeparator( );
                          else
                             quotedBuf = ::cli::format::impl::getLocaleDateSeparator( );
                          width = (unsigned)quotedBuf.size();

                    case DTF_EQ:
                         {
                          if (!ignoreNextStatement)
                             { // parsed string must exact match to template
                              ::std::wstring::size_type psSize = parsedString.size();
                              ::std::wstring::size_type qbi = 0, qbSize  = quotedBuf.size();
                              for(; qbi!=qbSize && curPos!=psSize; ++curPos, ++qbi)
                                 {
                                  if (parsedString[curPos]!=quotedBuf[qbi])
                                     {
                                      fParsingFailed = true;
                                      return;
                                     }
                                 }
                             }
                          else if (ignoreNextStatement==DTF_SIGNORE)
                             {
                              ::std::wstring::size_type sizeToIgnore = quotedBuf.size();
                              ::std::wstring::size_type tailSize = parsedString.size() - curPos;
                              if (sizeToIgnore > tailSize) sizeToIgnore = tailSize;
                              curPos += sizeToIgnore;
                              ignoreNextStatement = 0;
                             }
                          else
                             {
                              ::std::wstring::size_type psSize = parsedString.size();
                              ::std::wstring::size_type qbi = 0, qbSize  = quotedBuf.size();
                              for(; qbi!=qbSize && curPos!=psSize; ++curPos, ++qbi)
                                 { // ignoring only matched part 
                                  if (parsedString[curPos]!=quotedBuf[qbi]) break;
                                 }
                              ignoreNextStatement = 0;
                             }
                         }
                         break;

                    case DTF_YEAR:  
                         ignoreNextStatement = 0; // reset ignore state
                         if (isFieldParsed(yearParsed)) // allready parsed
                            {
                             fParsingFailed = true;
                             return;
                            }

                         if (!width) width = 1;
                         //WCHAR fillChar = '0';
                         if (width<2)
                            {
                             twoDigitYear = true;
                            }

                         yearParsed = curPos;
                         skipSpaces();

                         if (width==2)
                             width = 3;

                         readInt( width+1 );
                         dateTime.year = (WORD)curVal;
                         break;

                    case DTF_MONTH:  
                         ignoreNextStatement = 0; // reset ignore state

                         if (isFieldParsed(monthNameParsed) && isFieldParsed(monthParsed))
                            { fParsingFailed = true; return; } // both variants allready parsed

                         if (width<2) // one-or-two digit month number
                            {
                             if (isFieldParsed(monthParsed)) // allready parsed
                                { fParsingFailed = true; return; }
    
                             monthParsed = curPos;
                             skipSpaces();

                             readInt( width+1 );
                             if (isFieldParsed(monthNameParsed) && dateTime.month!=(WORD)curVal)
                                { fParsingFailed = true; return; }
                             dateTime.month = (WORD)curVal;
                            }
                         else
                            {
                             if (isFieldParsed(monthNameParsed)) // allready parsed
                                { fParsingFailed = true; return; }
    
                             monthNameParsed = curPos;
                             skipSpaces();

                             WORD tmp = 0;
                             parseStringValue( tmp, monthNames );
                             if (isFieldParsed(monthParsed) && dateTime.month!=tmp)
                                { fParsingFailed = true; return; }
                             dateTime.month = tmp;
                            }
                         break;

                    case DTF_MDAY:  
                    case DTF_WDAY:  
                         ignoreNextStatement = 0; // reset ignore state
                         if (width<2) // one-or-two digit day number
                            {
                             if (isFieldParsed(dayParsed)) // allready parsed
                                { fParsingFailed = true; return; }

                             dayParsed = curPos;
                             skipSpaces();
                             readInt( width+1 );
                             dateTime.day = (WORD)curVal;
                            }
                         else
                            {
                             if (isFieldParsed(dayOfWeekParsed)) // allready parsed
                                { fParsingFailed = true; return; }

                             dayOfWeekParsed = curPos;
                             skipSpaces();

                             parseStringValue( dateTime.dayOfWeek, wdayNames );
                            }
                         break;

                    case DTF_HOUR:
                         ignoreNextStatement = 0; // reset ignore state
                         if (isFieldParsed(hourParsed)) // allready parsed
                            { fParsingFailed = true; return; }

                         if (dtField&DTF_12H) hour12 = true;
                         hourParsed = curPos;
                         skipSpaces();
                         readInt( 2 );
                         dateTime.hour = (WORD)curVal;
                         break;

                    case DTF_MIN:
                         ignoreNextStatement = 0; // reset ignore state
                         if (isFieldParsed(minuteParsed)) // allready parsed
                            { fParsingFailed = true; return; }

                         minuteParsed = curPos;
                         skipSpaces();
                         readInt( 2 );
                         dateTime.minute = (WORD)curVal;
                         break;

                    case DTF_SEC:
                         ignoreNextStatement = 0; // reset ignore state
                         if (isFieldParsed(secondParsed)) // allready parsed
                            { fParsingFailed = true; return; }

                         secondParsed = curPos;
                         skipSpaces();
                         readInt( 2 );
                         dateTime.second = (WORD)curVal;
                         break;

                    case DTF_MICROSEC:
                         ignoreNextStatement = 0; // reset ignore state
                         if (isFieldParsed(microsecParsed)) { fParsingFailed = true; return; }

                         microsecParsed = curPos;
                         skipSpaces();

                         if (dtField&DTF_ZEROS)
                            {
                             readInt( width+1, width+1 );
                             switch(width)
                                {
                                 case 0: curVal *= 100000; break;
                                 case 1: curVal *= 10000 ; break;
                                 case 2: curVal *= 1000  ; break;
                                 case 3: curVal *= 100   ; break;
                                 case 4: curVal *= 10    ; break;
                                }
                            }
                         else
                            {
                             readInt( width+1 );
                            }

                         dateTime.microsec = (DWORD)curVal;
                         break;

                    case DTF_AP:
                         {
                          ignoreNextStatement = 0; // reset ignore state
                          if (isFieldParsed(ampmParsed)) // allready parsed
                             { fParsingFailed = true; return; }
 
                          ampmParsed = curPos;
                          skipSpaces();
                          WORD ampmVal = 0;
                          parseStringValue( ampmVal, ampmNames );
                          ampm = ampmVal ? true : false;
                          break;
                         }

                    case DTF_GM:
                         {
                          if (isFieldParsed(gmOffsetParsed)) { fParsingFailed = true; return; }

                          ::std::wstring::size_type psSize = parsedString.size();

                          gmOffsetParsed = curPos;
                          skipSpaces();
                          if (curPos==psSize) { fParsingFailed = true; return; }

                          short neg = 1;
                          if (parsedString[curPos]==L'-') { neg = -1; ++curPos; }
                          else if (parsedString[curPos]==L'+') { ++curPos; }
                          if (curPos==psSize) { fParsingFailed = true; return; }

                          skipSpaces();
                          if (curPos==psSize) { fParsingFailed = true; return; }

                          WORD gmH = 0, gmM = 0;

                          readInt( 2 );
                          if (fParsingFailed) return;
                          gmH = (WORD)curVal;

                          if (width>=2)
                             {
                              skipSpaces();
                              if (curPos!=psSize && parsedString[curPos]==L':')
                                 { // minutes are optional
                                  if (parsedString[curPos]==L':') { ++curPos; }
                                  skipSpaces();
                                  if (curPos==psSize) { fParsingFailed = true; return; }
                                  readInt( 2 );
                                  if (fParsingFailed) return;
                                  gmM = (WORD)curVal;
                                 }
                             }
                          
                          dateTime.gmOffset = neg*(gmH*60+gmM);
                         }

/*
                    case DTF_MICROSEC:
                            break;
                    case :  
                            break;
                    case :  
                            break;
                    case :  
                            break;
                    case :  
                            break;
                    case :  
                            break;
                    case :  
                            break;
                    case :  
                            break;
                    default:            
*/
                   }
               }
           }



        void
        appendToOut
                   ( WCHAR  ch          
                   , UINT   dtField     
                   , int    width       
                   )
           {
            return CFormatParserImplBase::appendToOut( ch, dtField, width );
           }

        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            _dtField = 0;
            _width   = 0;

            curPos                = 0;
            fParsingFailed        = false;
            ignoreNextStatement   = 0;
            curVal                = 0;
            twoDigitYear          = false;
            yearParsed            = ::std::wstring::npos;
            monthParsed           = ::std::wstring::npos;
            monthNameParsed       = ::std::wstring::npos;
            dayOfWeekParsed       = ::std::wstring::npos;
            dayParsed             = ::std::wstring::npos;
            hourParsed            = ::std::wstring::npos;
            minuteParsed          = ::std::wstring::npos;
            secondParsed          = ::std::wstring::npos;
            microsecParsed        = ::std::wstring::npos;
            gmOffsetParsed        = ::std::wstring::npos;
            ampmParsed            = ::std::wstring::npos;
            ampm                  = false;
            hour12                = false;

            dateTime.year         = 0;
            dateTime.month        = 1;
            dateTime.dayOfWeek    = 0;
            dateTime.day          = 1;
            dateTime.hour         = 0;
            dateTime.minute       = 0;
            dateTime.second       = 0;
            dateTime.microsec     = 0;
            dateTime.gmOffset     = 0;
           }

        bool isFieldParsed( ::std::wstring::size_type pos)
           {
            return pos!=::std::wstring::npos;
           }

    public:

        CDatetimeParser( const ::std::wstring &_parsedString
                       , STRUCT_CLI_CLISYSTEMTIME &_dateTime
                       ) 
           : CFormatParserImplBase(_parsedString)
           , wdayNames()
           , monthNames()
           , ampmNames()
           , dateTime(_dateTime)
           {
            /*
            getLocaleDayOfWeekName( unsigned dayOfWeek, bool bShort )
            getLocaleMonthName( unsigned month, bool bShort )
            getLocaleDateSeparator( )
            getLocaleTimeSeparator( )
            */
            unsigned i = 1;
            for(; i!=12; ++i)
               {
                monthNames[ upperCase( ::cli::format::impl::getLocaleMonthName( i-1, false ) ) ] = i;
                monthNames[ upperCase( ::cli::format::impl::getLocaleMonthName( i-1, true  ) ) ] = i;
                monthNames[ upperCase( ::std::wstring(months[ (i-1)*2   ]) ) ] = i;
                monthNames[ upperCase( ::std::wstring(months[ (i-1)*2+1 ]) ) ] = i;
               }

            for( i=0; i!=7; ++i)
               {
                wdayNames[ upperCase( ::cli::format::impl::getLocaleDayOfWeekName( i, false ) ) ] = i;
                wdayNames[ upperCase( ::cli::format::impl::getLocaleDayOfWeekName( i, true  ) ) ] = i;
                wdayNames[ upperCase( ::std::wstring(wdays[ (i)*2   ]) ) ] = i;
                wdayNames[ upperCase( ::std::wstring(wdays[ (i)*2+1 ]) ) ] = i;
               }

            ampmNames[L"AM"] = 0;
            ampmNames[L"A"]  = 0;
            ampmNames[L"PM"] = 1;
            ampmNames[L"P"]  = 1;
           }

        bool checkDataIntegrity()
           {
            if (isFieldParsed(yearParsed))
               {
                if (twoDigitYear && dateTime.year<100)
                   {
                    if (dateTime.year<38) dateTime.year += 2000;
                    else                  dateTime.year += 1900;
                   }
               }

            if (isFieldParsed(monthParsed))
               {
                if (dateTime.month<1 || dateTime.month>12)
                   {
                    fParsingFailed = true;
                    curPos = monthParsed;
                    return false;
                   }
               }

            if (isFieldParsed(dayParsed))
               {               
                if (!isFieldParsed(monthParsed))
                   {
                    fParsingFailed = true;
                    curPos = dayParsed;
                    return false;
                   }

                WORD lim = 30;
                switch(dateTime.month)
                   {
                    case 1:  lim = 31; break;
                    case 2:  lim = 29; break;
                    case 3:  lim = 31; break;
                    case 4:  lim = 30; break;
                    case 5:  lim = 31; break;
                    case 6:  lim = 30; break;
                    case 7:  lim = 31; break;
                    case 8:  lim = 31; break;
                    case 9:  lim = 30; break;
                    case 10: lim = 31; break;
                    case 11: lim = 30; break;
                    case 12: lim = 31; break;
                   }

                if (dateTime.day<1 || dateTime.day>lim)
                   {
                    fParsingFailed = true;
                    curPos = dayParsed;
                    return false;
                   }
               }

            if (isFieldParsed(dayOfWeekParsed))
               {
                if (dateTime.dayOfWeek>6)
                   {
                    fParsingFailed = true;
                    curPos = dayOfWeekParsed;
                    return false;
                   }
               }

            if (isFieldParsed(hourParsed))
               {
                if ((hour12 && dateTime.hour>11) || dateTime.hour>23)
                   {
                    fParsingFailed = true;
                    curPos = hourParsed;
                    return false;                   
                   }
                if (hour12 && isFieldParsed(ampmParsed))
                   {
                    if (ampm) // pm > 12
                       dateTime.hour += 12;
                   }
               }

            if (isFieldParsed(minuteParsed) && dateTime.minute>59)
               {
                fParsingFailed = true;
                curPos = minuteParsed;
                return false;                   
               }

            if (isFieldParsed(secondParsed) && dateTime.second>59)
               {
                fParsingFailed = true;
                curPos = secondParsed;
                return false;                   
               }

            if (isFieldParsed(microsecParsed) && dateTime.microsec>999999)
               {
                fParsingFailed = true;
                curPos = microsecParsed;
                return false;                   
               }

            if (isFieldParsed(gmOffsetParsed))
               {
                // add here gmOffset correction/checking
               }

            #if 0 
            /* Theese checkings not needed.
               If all fields in template parsed successfully, all is Ok.
             */ 
            if ( isFieldParsed(yearParsed) 
              && isFieldParsed(monthParsed) 
              //&& isFieldParsed(dayParsed)       // optional, 1 assumed by default
              && isFieldParsed(hourParsed) 
              && isFieldParsed(minuteParsed) 
              // && isFieldParsed(secondParsed)   // optional
              // && isFieldParsed(microsecParsed) // optional
              // && isFieldParsed(gmOffsetParsed) // optional
               ) return true; // full datetime

            if ( isFieldParsed(yearParsed) 
              && isFieldParsed(monthParsed) 
              // && isFieldParsed(dayParsed)      // optional, 1 assumed by default
               ) return true; // only date

            if ( isFieldParsed(hourParsed) 
              && isFieldParsed(minuteParsed) 
               ) return true; // only time

            if ( isFieldParsed(secondParsed) 
              && isFieldParsed(microsecParsed) 
               ) return true; // only sec.microsec

            if ( isFieldParsed(gmOffsetParsed)) return true; // only GMT

            return false;
            #endif

            return true;
           }

}; // class CDatetimeParser




struct CDateTimeValidatorImpl : public CValidatorImplBase
{

    /*
     CValidatorImplBase members:
        std::wstring             formatString;
        std::wstring             testString;
        std::wstring::size_type  validLen;
    */

    public:

        CDateTimeValidatorImpl()
           : CValidatorImplBase()
           {}

        void destroy() { delete this; }
    
        CLI_BEGIN_INTERFACE_MAP2(CDateTimeValidatorImpl, INTERFACE_CLI_INPUT_IVALIDATOR)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INPUT_IVALIDATOR )
        CLI_END_INTERFACE_MAP(CDateTimeValidatorImpl)
    
        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

        bool parseDateTime( STRUCT_CLI_CLISYSTEMTIME &dateTime )
           {
            CDatetimeParser fmtParser(testString, dateTime); // string to convert

            //fmtParser.pDateTime = (STRUCT_CLI_CLISYSTEMTIME*)&dateTime;
            fmtParser.resetAutomata();
            ::std::wstring::size_type i = 0, size = formatString.size();
            for(; i!=size && !fmtParser.isFailed(); ++i)
               {
                fmtParser.putChar( formatString[i] );       
               }
            if (!fmtParser.isFailed())
               {
                fmtParser.eod();
                fmtParser.checkDataIntegrity();
               }
            
            validLen = fmtParser.getValidPos();

            return !fmtParser.isFailed();
           }

        CLIMETHOD(validateString) (THIS)
           {
            STRUCT_CLI_CLISYSTEMTIME dateTime;
            if (!parseDateTime( dateTime ))
               return EC_TEST_FAILED;
            return EC_OK;
           }

        CLIMETHOD(convertString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                 )
           {
            STRUCT_CLI_CLISYSTEMTIME dateTime;
            if (!parseDateTime( dateTime ))
               {
                data->setEmpty(idx);
                return EC_TEST_FAILED;
               }
            data->setDate(idx, &dateTime);
            return EC_OK;
            //return EC_NOT_IMPLEMENTED;
           }

        CLIMETHOD(buildSampleString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                          , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                     )
           {
            ::std::wstring fmt = ::cli::format::message( L"%%%1%2!c!:datetime:%3%2!c!", ::cli::format::arg( (unsigned)(idx+1) ) % (WCHAR)L'!' % formatString );
            testString = ::cli::format::message( fmt, data );
            validLen = testString.size();
            return EC_OK;
           }

};



}; // namespace impl
}; // namespace validator
}; // namespace format
}; // namespace cli


#endif /* CORE_INPUT_VALIDATOR_DTVALIDATOR_H */

