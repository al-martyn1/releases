#ifndef CORE_INPUT_VALIDATOR_NULLVALIDATOR_H
#define CORE_INPUT_VALIDATOR_NULLVALIDATOR_H

#ifndef CLI_INPUT_IVALIDATOR_H
    #include <cli/input/ivalidator.h>
#endif

#ifndef CLI_INPUT_VALIDATORIMPLBASE_H
    #include <cli/input/validatorImplBase.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif


namespace cli
{
namespace input
{
namespace validator
{
namespace impl
{

struct CNullValidatorImpl : public CValidatorImplBase
{

    public:

        CNullValidatorImpl()
           : CValidatorImplBase()
           {}

        void destroy() { delete this; }
    
        CLI_BEGIN_INTERFACE_MAP2(CNullValidatorImpl, INTERFACE_CLI_INPUT_IVALIDATOR)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INPUT_IVALIDATOR )
        CLI_END_INTERFACE_MAP(CNullValidatorImpl)
    
        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

        CLIMETHOD(validateString) (THIS)
           {
            validLen = testString.size();
            return EC_OK;
           }

        CLIMETHOD(convertString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                 )
           {
            data->setStringChars( idx, testString.data(), testString.size() );
            validLen = testString.size();
            return EC_OK;
           }

        CLIMETHOD(buildSampleString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                          , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                     )
           {
            ::std::wstring tmp = formatString;
            if (tmp.empty()) tmp = testString;
            data->setStringChars( idx, tmp.data(), tmp.size() );
            return EC_OK;
           }

};

}; // namespace impl
}; // namespace validator
}; // namespace format
}; // namespace cli


#endif /* CORE_INPUT_VALIDATOR_NULLVALIDATOR_H */

