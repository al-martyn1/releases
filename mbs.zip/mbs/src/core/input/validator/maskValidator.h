#ifndef CORE_INPUT_VALIDATOR_MASKVALIDATOR_H
#define CORE_INPUT_VALIDATOR_MASKVALIDATOR_H

#ifndef CLI_INPUT_IVALIDATOR_H
    #include <cli/input/ivalidator.h>
#endif

#ifndef CLI_INPUT_VALIDATORIMPLBASE_H
    #include <cli/input/validatorImplBase.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

namespace cli
{
namespace input
{
namespace validator
{
namespace impl
{

template <bool bCaseSensitive >
struct CMaskValidatorImpl : public CValidatorImplBase
{

    public:

        CMaskValidatorImpl()
           : CValidatorImplBase()
           {}

        void destroy() { delete this; }
    
        CLI_BEGIN_INTERFACE_MAP2(CMaskValidatorImpl, INTERFACE_CLI_INPUT_IVALIDATOR)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INPUT_IVALIDATOR )
        CLI_END_INTERFACE_MAP(CMaskValidatorImpl)
    
        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


        CLIMETHOD(validateString) (THIS)
           {
            bool res = false;
            if (bCaseSensitive)
               res = MARTY_FILENAME_NS matchMaskE( testString, formatString );
            else
               res = MARTY_FILENAME_NS matchMaskI( testString, formatString );

            if (res)
               {
                validLen = testString.size();
                return EC_OK;
               }

            validLen = 0;
            return EC_TEST_FAILED;
           }

        CLIMETHOD(convertString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                 )
           {
            bool res = false;
            if (bCaseSensitive)
               res = MARTY_FILENAME_NS matchMaskE( testString, formatString );
            else
               res = MARTY_FILENAME_NS matchMaskI( testString, formatString );

            if (res)
               {
                data->setStringChars( idx, testString.data(), testString.size() );
                validLen = testString.size();
                return EC_OK;
               }

            data->setEmpty(idx);
            validLen = 0;
            return EC_TEST_FAILED;
           }

        CLIMETHOD(buildSampleString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                          , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                     )
           {
            ::std::wstring tmp;
            MARTY_FILENAME_NS buildMaskTestString( formatString 
                                                 , MARTY_FILENAME_NS CCaseCompare<MARTY_FILENAME_NS utils::keepcaseChar>(MARTY_FILENAME_NS utils::keepcaseChar())
                                                 , L'*'
                                                 , L'?'
                                                 , ::std::back_inserter(tmp)
                                                 );
            data->setStringChars( idx, tmp.data(), tmp.size() );
            return EC_OK;
           }
}; // CMaskValidatorImpl

typedef CMaskValidatorImpl<true>  CEMaskValidatorImpl;
typedef CMaskValidatorImpl<false> CIMaskValidatorImpl;

}; // namespace impl
}; // namespace validator
}; // namespace format
}; // namespace cli


#endif /* CORE_INPUT_VALIDATOR_MASKVALIDATOR_H */

