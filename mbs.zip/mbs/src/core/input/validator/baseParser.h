#ifndef CORE_INPUT_VALIDATOR_BASEPARSER_H
#define CORE_INPUT_VALIDATOR_BASEPARSER_H


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#include "../../dateTimeHlp.h"


namespace cli
{
namespace input
{
namespace validator
{
namespace impl
{


class CFormatParserImplBase
{
    protected:  

        const ::std::wstring         &parsedString;
        ::std::wstring::size_type    curPos;
        bool                         fParsingFailed;
        unsigned                     ignoreNextStatement;
        UINT64                       curVal;
        bool                         inQuote;
        ::std::wstring               quotedBuf;


        template <typename TVAL>
        ::std::wstring::size_type
        getMaxKeyLen( const ::std::map< ::std::wstring, TVAL > &m)
           {
            ::std::wstring::size_type maxLen = 0;
            typename ::std::map< ::std::wstring, TVAL >::const_iterator it = m.begin();
            for(; it!=m.end(); ++it)
               {
                if (maxLen<it->first.size()) maxLen = it->first.size();
               }
            return maxLen;
           }

        
        UINT char2int(WCHAR ch) const
           {
            if (ch>=L'0' && ch<=L'9') return (UINT)(ch - L'0');
            return 36;
           }

        bool readInt(unsigned maxLen, unsigned minLen = 1, bool errorOnBadChar = false)
           {
            if (maxLen<minLen) maxLen = minLen;
            ::std::wstring::size_type size = parsedString.size();
            curVal = 0;
            unsigned i=0;
            for( 
               ; curPos!=size && i!=maxLen && !fParsingFailed
               ; ++i
               )
               {
                UINT digit = char2int(parsedString[curPos]);
                if (digit>=10)
                   {
                    if (i<minLen || errorOnBadChar)
                       fParsingFailed = true;
                    return !fParsingFailed;
                   }
                curVal *= 10;
                curVal += digit;
                ++curPos;
               }
            return !fParsingFailed;
           }

        virtual
        void
        implParseEvent
                   ( WCHAR    ch          
                   , UINT     dtField     
                   , unsigned width       
                   ) = 0;

        void
        appendToOut
                   ( WCHAR  ch          
                   , UINT   dtField     
                   , int    width       
                   )
           {
            if (!dtField)
               {
                if (inQuote)
                   {
                    quotedBuf.append( 1, ch );
                   }
                else if (ch==L' ')
                   {
                    implParseEvent(ch, 0, (unsigned)quotedBuf.size());
                   }
                else
                   {
                    quotedBuf.clear();
                    quotedBuf.append( 1, ch );
                    implParseEvent(0, DTF_EQ, (unsigned)quotedBuf.size());
                    quotedBuf.clear();
                   }
               }
            else if (dtField==DTF_EQ)
               {
                implParseEvent(ch, dtField, (unsigned)quotedBuf.size());
                quotedBuf.clear();
                inQuote = false;
               }
            //else if (inQuote)
            //   {
            //    if (ch) quotedBuf.append( 1, ch );
            //   }
            else if (dtField==DTF_SQ)
               {
                inQuote = true;
                quotedBuf.clear();
               }
            else
               {
                implParseEvent(ch, dtField, width);
               }
           }


    public:

        CFormatParserImplBase(const ::std::wstring &_parsedString)
           : parsedString(_parsedString)
           , curPos(0)
           , fParsingFailed(0)
           , ignoreNextStatement(0)
           , inQuote(false)
           , quotedBuf()
           {}

        bool isFailed() const { return fParsingFailed; }
        ::std::wstring::size_type getValidPos() const { return curPos; }

}; // class CFormatParserImplBase


}; // namespace impl
}; // namespace validator
}; // namespace format
}; // namespace cli



#endif /* CORE_INPUT_VALIDATOR_BASEPARSER_H */

