/*!
\project ����� ����������� - ����������� ����������� �����
    \libraries cli2
    \libpath 
    \incpath 

    \platform win32
        \libraries cli2

    \platform mingw
        \libraries cli2

    \platform linux
        \libraries cli2
        \libpath 
        \incpath 
*/

//#define CLI_INTERNAL
//#define CLI_INTERNAL_DONT_LINK_CLI_LIB

#include <cli/cli2.h>
#include "dtValidator.h"
#include "dgValidator.h"
#include "intValidator.h"
#include "nullValidator.h"
#include "maskValidator.h"




DECLARE_COMPONENT_CREATION_PROC( create_cli_datetime_validator, ::cli::input::validator::impl::CDateTimeValidatorImpl, INTERFACE_CLI_INPUT_IVALIDATOR )
DECLARE_COMPONENT_CREATION_PROC( create_cli_degree_validator  , ::cli::input::validator::impl::CDegreeValidatorImpl  , INTERFACE_CLI_INPUT_IVALIDATOR )
DECLARE_COMPONENT_CREATION_PROC( create_cli_integer_validator , ::cli::input::validator::impl::CIntegerValidatorImpl , INTERFACE_CLI_INPUT_IVALIDATOR )
DECLARE_COMPONENT_CREATION_PROC( create_cli_null_validator    , ::cli::input::validator::impl::CNullValidatorImpl    , INTERFACE_CLI_INPUT_IVALIDATOR )
DECLARE_COMPONENT_CREATION_PROC( create_cli_emask_validator   , ::cli::input::validator::impl::CEMaskValidatorImpl   , INTERFACE_CLI_INPUT_IVALIDATOR )
DECLARE_COMPONENT_CREATION_PROC( create_cli_imask_validator   , ::cli::input::validator::impl::CIMaskValidatorImpl   , INTERFACE_CLI_INPUT_IVALIDATOR )


//DECLARE_COMPONENT_CREATION_PROC( create_cli_moxa_moxafinderimpl , ::cli::moxa::impl::CMoxaFinderImpl , INTERFACE_CLI_MOXA_IMOXAFINDER )
//DECLARE_COMPONENT_CREATION_PROC( create_cli_inet_udpserver_impl, ::cli::inet::impl::CUdpServerImpl, INTERFACE_CLI_INET_IUDPSERVER)


//static 
static unsigned infoInitialized = 0;
static
CCliComponentCreationInfo moduleComponentsInfo[] = 
   {
    
      // ---
      { 
        { "/cli/input/validator/datetime"
        , INTERFACE_CLI_INPUT_IVALIDATOR_IID
        , "en:Validate and convert date and time strings;"
        }
      , &create_cli_datetime_validator
      },
      // ---
      { 
        { "/cli/input/validator/degree"
        , INTERFACE_CLI_INPUT_IVALIDATOR_IID
        , "en:Validate and convert degrees strings;"
        }
      , &create_cli_degree_validator
      },
      // ---
      { 
        { "/cli/input/validator/int"
        , INTERFACE_CLI_INPUT_IVALIDATOR_IID
        , "en:Validate and convert integer values using native language conventions;"
        }
      , &create_cli_integer_validator
      },
      // ---
      { 
        { "/cli/input/validator/cint"
        , INTERFACE_CLI_INPUT_IVALIDATOR_IID
        , "en:Validate and convert integer values using \"C\" language conventions;"
        }
      , &create_cli_integer_validator
      },
      // ---
      { 
        { "/cli/input/validator/null"
        , INTERFACE_CLI_INPUT_IVALIDATOR_IID
        , "en:Simple convert value to string;"
        }
      , &create_cli_null_validator
      },
      // ---
      { 
        { "/cli/input/validator/imask"
        , INTERFACE_CLI_INPUT_IVALIDATOR_IID
        , "en:Test string to match simple mask, case insensitive;"
        }
      , &create_cli_imask_validator
      },
      // ---
      { 
        { "/cli/input/validator/mask"
        , INTERFACE_CLI_INPUT_IVALIDATOR_IID
        , "en:Test string to match simple mask, case insensitive, same as imask;"
        }
      , &create_cli_imask_validator
      },
      // ---
      { 
        { "/cli/input/validator/emask"
        , INTERFACE_CLI_INPUT_IVALIDATOR_IID
        , "en:Test string to match simple mask, case sensitive, exact match;"
        }
      , &create_cli_emask_validator
      }

   };



DECLARE_CLI_MODULE_INFO(moduleComponentsInfo, infoInitialized, registerCliValidator, "clivalidator")


