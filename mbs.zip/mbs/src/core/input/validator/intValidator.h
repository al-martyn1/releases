#ifndef CORE_INPUT_VALIDATOR_INTVALIDATOR_H
#define CORE_INPUT_VALIDATOR_INTVALIDATOR_H

#ifndef CLI_INPUT_IVALIDATOR_H
    #include <cli/input/ivalidator.h>
#endif

#ifndef CLI_INPUT_VALIDATORIMPLBASE_H
    #include <cli/input/validatorImplBase.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif


namespace cli
{
namespace input
{
namespace validator
{
namespace impl
{

struct CIntegerValidatorImpl : public CValidatorImplBase
{

    public:

        CIntegerValidatorImpl()
           : CValidatorImplBase()
           {}

        void destroy() { delete this; }
    
        CLI_BEGIN_INTERFACE_MAP2(CIntegerValidatorImpl, INTERFACE_CLI_INPUT_IVALIDATOR)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INPUT_IVALIDATOR )
        CLI_END_INTERFACE_MAP(CIntegerValidatorImpl)
    
        CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
        CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


        const static unsigned flagPrefix   = 1;
        const static unsigned flagUnsigned = 2;
        const static unsigned flagUpper    = 4;
        const static unsigned flagSpace    = 8;

        unsigned parseFormat( unsigned &radix ) const
           {
            radix = 0; // auto
            ::std::wstring::size_type i = 0, size = formatString.size();
            if (i==size) return 0;

            unsigned flags = 0;
            for(; i!=size; ++i)
               {               
                if (formatString[i]==L'#')
                   flags |= flagPrefix;
                else if (formatString[i]==L' ')
                   flags |= flagSpace;
                else break; // not a flag
               }

            unsigned tmpFlags = 0;
            for(; i!=size; ++i)
               {               
                tmpFlags = 0;
                const wchar_t &ch = formatString[i];
                switch(ch)
                   {
                    case L'u': case L'U':  tmpFlags |= flagUnsigned;
                    case L'i': case L'I':
                    case L'd': case L'D':  radix = 10; break;
                    case L'x': case L'X':  radix = 16; tmpFlags |= flagUnsigned; break;
                    case L'o': case L'O':  radix = 8;  tmpFlags |= flagUnsigned; break;
                    case L'b': case L'B':  radix = 2;  tmpFlags |= flagUnsigned; break;
                   }
                if (ch==L'X' || ch==L'O' || ch==L'B') tmpFlags |= flagUpper;
               }

            flags |= tmpFlags;

            if (!radix || radix==10) flags &= ~flagPrefix;

            return flags;
           }

        bool skipSpaces()
           {
            ::std::wstring::size_type size = testString.size();
            for(; validLen!=size; ++validLen)
               {
                if (testString[validLen]!=L' ') return true; // can continue;
               }
            return false; // stops on end of line
           }

        unsigned char2digit(wchar_t ch) const
           {
            if (ch>=L'0' && ch<=L'9') return ch-L'0';
            if (ch>=L'A' && ch<=L'Z') return ch-L'A'+10;
            if (ch>=L'a' && ch<=L'z') return ch-L'a'+10;
            return 64;
           }

        RCODE readValue(unsigned radix, UINT64 &val, unsigned flags)
           {
            std::wstring::size_type size = testString.size();
            //if (validLen==size) return EC_INVALID_FORMAT; // no value in str
            val = 0;
            for(; validLen!=size; ++validLen)
               {
                if (testString[validLen]==L' ' && (flags&flagSpace)) 
                   return EC_OK; // stops converting
                unsigned d = char2digit(testString[validLen]);
                if (d>=radix) return EC_INVALID_FORMAT;
                UINT64 prevVal = val;
                val *= (UINT64)radix;
                if (prevVal>val) // overflow check
                   return EC_OUT_OF_LIMIT;
                val += d;
               }
            return EC_OK;
           }

        RCODE parseInt( UINT64 &val, unsigned &flags )
           {
            unsigned radix = 0;
            flags = parseFormat( radix );
            val = 0;

            /*
            CValidatorImplBase members
            std::wstring             formatString;
            std::wstring             testString;
            std::wstring::size_type  validLen;
            */

            validLen = 0;
            std::wstring::size_type size = testString.size();
            if (!skipSpaces()) return EC_INVALID_FORMAT;

            bool neg = false;

            if (!radix)
               { // detect radix
                if (testString[validLen]==L'+' || testString[validLen]==L'-')
                   {
                    radix = 10; // decimal int detected
                    if (testString[validLen]==L'-') neg = true;
                    else flags |= flagUnsigned;
                    ++validLen;
                    if (validLen==size) return EC_INVALID_FORMAT;
                    RCODE res = readValue(radix, val, flags);
                    if (res) return res;
                   }
                else
                   {
                    flags |= flagUnsigned; // all of int types below are unsigned
                    if (testString[validLen]==L'0')
                       { // octal value, or hex or binary, or simple zero
                        ++validLen;
                        if (validLen==size) return EC_OK; // simple zero
                        if (testString[validLen]==L' ' && (flags&flagSpace)) 
                           return EC_OK; // stops converting, simple zero followed by space

                        if (testString[validLen]==L'x' || testString[validLen]==L'X')
                           {
                            ++validLen;
                            if (validLen==size) return EC_INVALID_FORMAT;
                            if (testString[validLen]==L' ') return EC_INVALID_FORMAT; // space not allowed here
                            return readValue(16, val, flags);
                           }
                        else if (testString[validLen]==L'b' || testString[validLen]==L'B')
                           {
                            ++validLen;
                            if (validLen==size) return EC_INVALID_FORMAT;
                            if (testString[validLen]==L' ') return EC_INVALID_FORMAT; // space not allowed here
                            return readValue(2, val, flags);
                           }
                        else
                           {
                            unsigned d = char2digit(testString[validLen]);
                            if (d<8) return readValue(8, val, flags);
                            return readValue(10, val, flags); // default - decimal
                           }
                       }
                    else // first symbol not zero
                       {
                        unsigned maxDigit = 0;
                        std::wstring::size_type i = validLen;
                        for(; i!=size; ++i) 
                           {
                            if (testString[i]==L' ') break;
                            unsigned d = char2digit(testString[i]);
                            if (d>maxDigit) maxDigit = d;
                           }
                        //if (d>=10)    return EC_INVALID_FORMAT;
                        if (maxDigit>=10) return readValue(16, val, flags);
                        return readValue(10, val, flags);
                        //unsigned d = char2digit(testString[validLen]);
                        //if (d>10 && d<16) return readValue(16, val);
                        //else if (d>=8) return readValue(16, val);
                        //return readValue(10, val); // default - decimal
                       }
                   }
               }
            else
               { // radix taken
                if (flags&flagPrefix)
                   { // prefix must be present
                    if (testString[validLen]!=L'0') return EC_INVALID_FORMAT;
                    ++validLen;
                    if (validLen==size) return EC_INVALID_FORMAT;
                    switch(radix)
                       {
                        case 2: if (testString[validLen]!=L'b' && testString[validLen]!=L'B') return EC_INVALID_FORMAT;
                                ++validLen;
                                break;
                        case 8: // only '0' prefixes octal values
                                break;
                        case 16: if (testString[validLen]!=L'x' && testString[validLen]!=L'X') return EC_INVALID_FORMAT;
                                ++validLen;
                                break;
                       }
                    if (validLen==size) return EC_INVALID_FORMAT;
                   }

                if (testString[validLen]==L'+' || testString[validLen]==L'-')
                   {
                    if (radix!=10 || (testString[validLen]==L'-' && (flags&flagUnsigned)))
                       return EC_INVALID_FORMAT;
                    if (testString[validLen]==L'-') neg = true;
                    ++validLen;
                    if (validLen==size) return EC_INVALID_FORMAT;
                   }

                RCODE res = readValue(radix, val, flags);
                if (res) return res;
               }

            if (neg)
               {
                const UINT64 intMax = 0x7FFFFFFFFFFFFFFFull;
                if (val>intMax) return EC_OUT_OF_LIMIT;
                val = (UINT64)(-((INT64)val));
               }

            return EC_OK;
           }

        CLIMETHOD(validateString) (THIS)
           {
            UINT64 v;
            unsigned f;
            return parseInt(v,f);
            //return EC_NOT_IMPLEMENTED;
           }

        CLIMETHOD(convertString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                 )
           {
            UINT64 v;
            unsigned f;
            RCODE res = parseInt(v,f);
            if (res)
               {
                data->setEmpty(idx);
                return EC_TEST_FAILED;
               }

            if (f&flagUnsigned)
               data->setUInt64(idx, v);
            else
               data->setInt64(idx, (INT64)v);
            return EC_OK;
            //return EC_NOT_IMPLEMENTED;
           }

        CLIMETHOD(buildSampleString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                          , INTERFACE_CLI_IARGLIST*    data /* [in] ::cli::iArgList*  data  */
                                     )
           {
            unsigned radix = 0;
            unsigned flags = parseFormat( radix );
            wchar_t fmtChar = L'd';
            switch(radix)
               {
                //case 0:
                case 10: if (flags&flagUnsigned) fmtChar = L'u'; break;
                case 2:  fmtChar = (flags&flagUpper)?L'B':L'b'; break;
                case 8:  fmtChar = (flags&flagUpper)?L'O':L'o'; break;
                case 16: fmtChar = (flags&flagUpper)?L'X':L'x'; break;
               }
            ::std::wstring preFmt;
            if (flags&flagPrefix) preFmt.append(1, L'#');
            preFmt.append(1, fmtChar);

            ::std::wstring fmt = ::cli::format::message( L"%%%1%2!c!%3%2!c!"
                                                       , ::cli::format::arg( (unsigned)(idx+1) ) 
                                                         % (WCHAR)L'!' 
                                                         % preFmt
                                                       );

            testString = ::cli::format::message( fmt, data );
            validLen = testString.size();
            return EC_OK;
           }

};

}; // namespace impl
}; // namespace validator
}; // namespace format
}; // namespace cli


#endif /* CORE_INPUT_VALIDATOR_INTVALIDATOR_H */

