#include "cli2init.h"

#ifndef CLI_EMBEDDED
    #include <marty/filename.h>
    #include <marty/concvt.h>
    #include <marty/libapi.h>
    #include <marty/filesys.h>


#if (defined(_WIN32) || defined(WIN32)) && defined(_DEBUG)
/*
 * The version to use if we are forced to emulate.
 */
static BOOL WINAPI
Emulate_IsDebuggerPresent(VOID)
{
    /* No way to tell, so just say "no". */
    return FALSE;
}

/*
 * The stub that probes to decide which version to use.
 */
static BOOL WINAPI
Probe_IsDebuggerPresent(VOID)
{
    HINSTANCE hinst;
    FARPROC fp;
    //BOOL (CALLBACK *RealIsDebuggerPresent)(VOID);

    hinst = GetModuleHandle(TEXT("KERNEL32"));
    fp = GetProcAddress(hinst, "IsDebuggerPresent");

    if (fp) {
        *(FARPROC *)&IsDebuggerPresent = fp;
    } else {
        IsDebuggerPresent = Emulate_IsDebuggerPresent;
    }

    return IsDebuggerPresent();
}

BOOL (CALLBACK *IsDebuggerPresent)(VOID) =
        Probe_IsDebuggerPresent;

#endif

namespace cli
{


//-----------------------------------------------------------------------------
bool getAppExeName   (::std::basic_string<TCHAR> &appExeName)
   {
    using MARTY_FILENAME_NS     makeCanonical;
    using MARTY_FILENAME_NS     appendPath;
    using MARTY_FILENAME_NS     isAbsolutePath;
    using MARTY_FILESYSTEM_NS   getCurrentDirectory;

    int getModNameRes = MARTY_LIBAPI_NS getModuleFileName(0, appExeName);
    if (getModNameRes) return false;

    if (!isAbsolutePath(appExeName))
       {
        appExeName = appendPath(getCurrentDirectory(), appExeName);
       }        
    return true;
   }

//-----------------------------------------------------------------------------
bool findCliAppConfig(::std::basic_string<TCHAR> &foundConfFile, const ::std::basic_string<TCHAR> &appExeName)
   {
    using MARTY_FILENAME_NS     makeCanonical;
    using MARTY_FILENAME_NS     getPath;
    using MARTY_FILENAME_NS     getName;
    using MARTY_FILENAME_NS     appendPath;
    using MARTY_FILENAME_NS     appendExtention;
    using MARTY_FILENAME_NS     isAbsolutePath;
    //using MARTY_FILESYSTEM_NS   CFindFileInfo;
    //using MARTY_FILESYSTEM_NS   findFiles;
    using MARTY_FILESYSTEM_NS   handle_t;
    using MARTY_FILESYSTEM_NS   openFile;
    using MARTY_FILESYSTEM_NS   closeFile;
    using MARTY_FILESYSTEM_NS   o_rdonly;
    using MARTY_FILESYSTEM_NS   hInvalidHandle;
    
    //::std::basic_string<TCHAR> appModName;
    //if (!getAppExeName(appModName)) return false;

    ::std::basic_string<TCHAR> appPath = getPath(appExeName);

    ::std::basic_string<TCHAR> _cli2_conf = ::std::basic_string<TCHAR>(_T(".cli2.conf"));
    ::std::basic_string<TCHAR> appConfOnlyFile = appendExtention(getName(appExeName), _cli2_conf);
    ::std::basic_string<TCHAR> appConfName = appendPath(appPath, ::std::basic_string<TCHAR>(_T("../conf")));
    appConfName = makeCanonical(appendPath(appConfName, appConfOnlyFile));
    
    handle_t hFile = openFile(appConfName, o_rdonly );
    if (hInvalidHandle!=hFile)
       {
        closeFile(hFile);
        foundConfFile = appConfName;
        return true;
       }

    appConfName = makeCanonical(appendPath(appPath, appConfOnlyFile));
    hFile = openFile(appConfName, o_rdonly );
    if (hInvalidHandle!=hFile)
       {
        closeFile(hFile);
        foundConfFile = appConfName;
        return true;
       }

    return false;
   }

//-----------------------------------------------------------------------------
bool findCliAppConfig(::std::basic_string<TCHAR> &foundConfFile)
   {
    ::std::basic_string<TCHAR> appModName;
    if (!getAppExeName(appModName)) return false;
    return findCliAppConfig(foundConfFile, appModName);
   }

//-----------------------------------------------------------------------------



}; // namespace cli


#endif /* CLI_EMBEDDED */



