/*!
\project ��������� ��� ���������� � ����������� ������. ��� ����������� � ����� � �������������� ����������� .cli
    \libraries cli2
    \libpath
    \incpath

\platform linux
    \libraries dl

*/

#define CLICOMPONENTINFO_CONST_FIELD


#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_SSTREAM_) && !defined(_STLP_SSTREAM) && !defined(__STD_SSTREAM__) && !defined(_CPP_SSTREAM) && !defined(_GLIBCXX_SSTREAM)
    #include <sstream>
#endif

#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#include <cli/cli2.h>
#include <cli/cliutilx.h>


#include <marty/libapi.h>
#include <marty/filename.h>
#include <marty/filesys.h>
#include <marty/concvt.h>


using MARTY_FILESYSTEM_NS      getCurrentDirectory;
using MARTY_FILESYSTEM_NS      findFiles;
using MARTY_FILESYSTEM_NS      CFindFileInfo;
using MARTY_FILESYSTEM_NS      efIsDir;
using MARTY_FILESYSTEM_NS      openFile;
using MARTY_FILESYSTEM_NS      closeFile;
using MARTY_FILESYSTEM_NS      writeFile;

using MARTY_FILENAME_NS        makeFullPath;
using MARTY_FILENAME_NS        getPath;
using MARTY_FILENAME_NS        getFile;
using MARTY_FILENAME_NS        appendPath;
using MARTY_FILENAME_NS        appendExtention;


using MARTY_FILENAME_NS        makeCanonical;
using MARTY_LIBAPI_NS          CModuleHandle;

using MARTY_CON_NS             str2con;
using MARTY_CON_NS             con2str;
using MARTY_CON_NS             arg2str;

typedef MARTY_LIBAPI_NS tstring string;


void generateCacheForModule(const string &modFilename);
void generateCacheForFiles(const string &mask);

//CLI_MODULE_INFO_CACHE_SUFFIX

#if defined(_WIN32) && defined(_MSC_VER)
int _tmain(int argc, TCHAR* argv[])
#else
int main(int argc, char* argv[])
#endif
   {
    try{
        std::vector<string> argsVec;
        for(int i=0; i<argc; ++i)
           argsVec.push_back(arg2str(argv[i]));

        bool byMask = false;
        if (argsVec.size()<=1)
           {
            #ifdef _WIN32
                string dir = appendPath(getCurrentDirectory(), string(_T("*.dll")));
            #else
                string dir = appendPath(getCurrentDirectory(), string(_T("*.so")));
            #endif
            //std::cout<<"No files/mask taken, processing files under current directory, mask: '"<<dir<<"'\n";
            std::cout<<"No files/mask taken, processing files under current directory\n";
            argsVec.push_back(string(_T("-m")));
            argsVec.push_back(dir);
           }

        std::vector<string>::const_iterator ait = argsVec.begin();
        ++ait;

        for(; ait!=argsVec.end(); ++ait)
           {
            if (*ait==_T("-m"))
               {
                byMask = true;
                continue;
               }
            else if (*ait==_T("-h") || *ait==_T("-?"))
               {
                std::cout<<"Usage: cli2mkcache pathfile1 pathfile2 -m pathmask1 pathfile3 -m pathmask2 ...";
                continue;
               }
            else
               {
                if (byMask) generateCacheForFiles(*ait);
                else        generateCacheForModule(*ait);
                byMask = false;
               }
           }

        //char ch;
        //std::cout<<"Program terminated, press any key to close window\n";
        //std::cin>>ch;
    }
    catch(const std::exception &e)
       {
        std::cout<<"Error: "<<e.what()<<"\n";
        //std::cout<<"Locale:"<<MARTY_FILENAME_NS utils::localeAux::getLocaleCrtNameA(LOCALE_USER_DEFAULT, false)<<"\n";
       }
    catch(...)
       {
        std::cout<<"Error: unknown error\n";
       }

    return 0;
   }

void generateCacheForFiles(const string &mask)
   {
    std::cout<<"Processing mask: "<<str2con(mask)<<" ...\n";
    std::vector< CFindFileInfo< string::value_type > > matches;
    //std::cout<<"CP1\n";
    int res = findFiles(matches, getPath(mask), getFile(mask), true  /* recurse */ , false  /* dont force compare full path */ );
    //std::cout<<"CP2\n";
    if (res)
       {
        std::cout<<"Error: can't find files with '"<<str2con(mask)<<"' mask - system error "<<res<<"\n";
        //std::cerr<<"Error: can't find files with '"<<mask<<"' mask - system error "<<res<<"\n";
       }
    //std::cout<<"CP3\n";
    std::vector< CFindFileInfo< string::value_type > >::const_iterator it = matches.begin();
    //std::cout<<"CP3\n";
    for(; it!=matches.end(); ++it)
       {
        //std::cout<<"CP5\n";
        if (efIsDir(it->attrs)) continue;
        generateCacheForModule(appendPath(it->path, it->file));
       }
   }


#ifdef _WIN32
    #define CRLF "\r\n"
#else
    #define CRLF "\n"
#endif

void generateCacheForModule(const string &modFilename)
   {
    string modFullName = makeCanonical(makeFullPath(getCurrentDirectory(), modFilename));
    std::cout<<"Processing file: "<<str2con(modFullName)<<": ";

    string cacheFullName = appendExtention(modFullName, CLI_MODULE_INFO_CACHE_SUFFIX);

    std::stringstream oss;
    std::stringstream ess;

    try{
        CModuleHandle modHandle /*  = CModuleHandle */ (modFullName.c_str());
        cliEnumModuleComponentsProcT enumProc = reinterpret_cast<cliEnumModuleComponentsProcT>(modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME));
        //cliEnumModuleComponentsProcT proc = (cliEnumModuleComponentsProcT)modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME);
        if (!enumProc)
           {
            ess<<"error, not a CLI module\n";
           }
        else
           {
            unsigned idx = 0;
            CCliComponentInfo ci = { 0, 0, 0 };
            while(enumProc(idx++, &ci))
               {
                if (!ci.name)
                   {
                    ess<<"empty component name\n";
                    continue;
                   }

                oss<<"Component: "<<ci.name<< CRLF;

                if (ci.categories)
                   oss<<"Categories: "<<ci.categories<< CRLF;

                if (ci.description)
                   {
                    ::std::string description = ci.description;
                    ::std::map< ::std::string, ::std::string> md;
                    ::cli::util::splitStringToMap(md, description, ::cli::util::CIsExactChar<char,';'>(), ::cli::util::CIsExactChar<char, ':'>());
                    if (md.size())
                       {
                        oss<<"Description:" CRLF;
                        ::std::map< ::std::string, ::std::string>::const_iterator it = md.begin();
                        for(; it!=md.end(); ++it)
                           {
                            if (it->first.empty()) oss<<"en:"<<it->second<<CRLF;
                            else                   oss<<it->first<<":"<<it->second<<CRLF;
                           }
                       }
                   }
                oss<<"."<< CRLF;
               }
           }

       }
    catch(const std::exception &e)
       {
        ess<<"error, failed to load module "<<str2con(modFullName)<<": "<<e.what()<<"\n";
       }
    catch(...)
       {
        ess<<"error, failed to load module "<<str2con(modFullName)<<": unknown error\n";
       }

    if (ess.str().empty())
       std::cout<<"Ok\n";
    else
       {
        std::cout<<ess.str();
        //std::cerr<<"Processing file: "<<modFullName<<": "<<ess.str();
       }

    ::std::string ossStr = oss.str();

    //std::cout<<ossStr<<"\n";
    if (ossStr.size())
       {
        MARTY_FILESYSTEM_NS handle_t hFile = openFile(cacheFullName, MARTY_FILESYSTEM_NS o_creat | MARTY_FILESYSTEM_NS o_wronly | MARTY_FILESYSTEM_NS  o_trunc, false);
        if (MARTY_FILESYSTEM_NS hInvalidHandle == hFile)
           {
            std::cout<<"Failed to create file "<<str2con(cacheFullName)<<"\n";
            //std::cerr<<"Failed to create file "<<cacheFullName<<"\n";
           }
        else
           {
            int wrRes = writeFile(hFile, (const void*)ossStr.c_str(), (unsigned)ossStr.size());
            if (wrRes<0)
               {
                std::cout<<"Failed to write, error: "<<errno<<strerror(errno)<<"\n";
                //std::cerr<<"Failed to write, error: "<<errno<<strerror(errno)<<"\n";
               }
            closeFile(hFile);
           }
       }

   }

