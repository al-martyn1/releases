#define CLI_INTERNAL

#include "modules.h"


#ifdef CLI_MONOLITHIC
    #include "monomod.cpp"
#else
    #include "dynmod.cpp"
#endif

GENERIC_OBJ_PTR
CLICALL
cli_create( CHAR const * componentId, 
          CHAR const * interfaceId, 
          CLI_IUNKNOWN_PTR outer)
   {
    GENERIC_OBJ_PTR resPtr = 0;
    RCODE res = cliCreateObject( componentId, interfaceId, outer, &resPtr );
    if (res) return 0;
    return resPtr;
   }



