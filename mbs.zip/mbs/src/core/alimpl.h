#ifndef CORE_ALIMPL_H
#define CORE_ALIMPL_H

// iArgList implementation

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

/*
#ifndef CLI_STRAPI_H
    #include <cli/strapi.h>
#endif
*/

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifndef CORE_ALVARIANT_H
    #include "alvariant.h"
#endif

#ifndef CLI_VARIANT_H
    #include <cli/variant.h>
#endif


namespace cli
{
//namespace arglist
//{
namespace impl
{

using ::cli::VariantType::vt_empty   ;
using ::cli::VariantType::vt_none    ;
using ::cli::VariantType::vt_char    ;
using ::cli::VariantType::vt_wchar   ;
using ::cli::VariantType::vt_short   ;
using ::cli::VariantType::vt_ushort  ;
using ::cli::VariantType::vt_int     ;
using ::cli::VariantType::vt_uint    ;
using ::cli::VariantType::vt_int64   ;
using ::cli::VariantType::vt_uint64  ;
using ::cli::VariantType::vt_int_ptr ;
using ::cli::VariantType::vt_uint_ptr;
using ::cli::VariantType::vt_float   ;
using ::cli::VariantType::vt_double  ;
using ::cli::VariantType::vt_pstring ;
using ::cli::VariantType::vt_ptr     ;
using ::cli::VariantType::vt_dump    ;
using ::cli::VariantType::vt_datetime;
using ::cli::VariantType::vt_colorref;
using ::cli::VariantType::vt_iUnknown;
using ::cli::VariantType::vt_bigint  ;
using ::cli::VariantType::vt_rational;
            


template < bool allowUseArgList >
class CArgList : public INTERFACE_CLI_IARGLIST
{

    protected:

        ::std::vector< CVariant >    varList;
        CVariant                     defValue;

        ::cli::CRefCounter           refCounter;

    public:

        //CArgList() : varList(), defValue((INT)0), refCounter(0) {}
        CArgList() : varList(), defValue(), refCounter(0) {}

        // ������� ������ ���������� ��� ������������ �������������
        // CVariant ��� ��������� ��� �� �����
        void clearArgList() { varList.clear(); }

/*
    CLI_BEGIN_INTERFACE_MAP(CSatMapDrawHelperImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IARGLIST )
    CLI_END_INTERFACE_MAP(CSatMapDrawHelperImpl)
    CLIMETHOD_(ULONG, addRef) (THIS)    { return (ilint_t)++refCounter;  }
    CLIMETHOD_(ULONG, release) (THIS)   { if (! --refCounter) { destroy(); return 0; }  return (ilint_t)refCounter; }
*/

        CLIMETHOD(shiftArgs1) (THIS)
           {
            if (varList.size() > 0)
               {
                varList.erase( varList.begin() );
                return EC_OK;
               }
            return EC_NO_MORE_DATA;
           }

        CLIMETHOD(shiftArgs) (THIS_ SIZE_T    shiftCount /* [in] size_t  shiftCount  */)
           {
            SIZE_T i = 0;
            for( ; i!=shiftCount && varList.size()>0; ++i )
               {
                varList.erase( varList.begin() );
               }
            if (i==shiftCount) return EC_OK;
            return EC_NO_MORE_DATA;
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, clearArgs) (THIS)
           {
            clearArgList();
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setCopyFrom) (THIS_ SIZE_T    thisListIdx /* [in] size_t  thisListIdx  */
                                                              , INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                              , SIZE_T    copyFromIdx /* [in] size_t  copyFromIdx  */
                                                         )
           {
            if (!copyFrom)
               { // do nothing
                return static_cast<INTERFACE_CLI_IARGLIST*>(this);
               }

            SIZE_T thatSize = copyFrom->getCount();
            if (copyFromIdx>=thatSize)
               {
                return setEmpty(thisListIdx);
               }

            ENUM_CLI_VARIANTTYPE thatType = copyFrom->getType(copyFromIdx);
            switch(thatType)
               {
                //case ::cli::arglist::VariantType::vt_none    :  
                case ::cli::VariantType::vt_bool    : 
                     {
                      BOOL b = (BOOL)-1; 
                      copyFrom->getBool( copyFromIdx, &b );
                      setBool( thisListIdx, b );
                     } break;

                case ::cli::VariantType::vt_char    : 
                     {
                      CHAR ch = 0; 
                      copyFrom->getChar( copyFromIdx, &ch );
                      setChar( thisListIdx, ch );
                     } break;

                case ::cli::VariantType::vt_wchar   :  
                     {
                      WCHAR ch = 0; 
                      copyFrom->getWChar( copyFromIdx, &ch );
                      setWChar( thisListIdx, ch );
                     } break;

                case ::cli::VariantType::vt_short   :  
                     {
                      SHORT sh = 0;
                      copyFrom->getShort( copyFromIdx, &sh );
                      setShort( thisListIdx, sh );
                     } break;

                case ::cli::VariantType::vt_ushort  :  
                     {
                      USHORT sh = 0;
                      copyFrom->getUShort( copyFromIdx, &sh );
                      setUShort( thisListIdx, sh );
                     } break;

                case ::cli::VariantType::vt_int     :  
                     {
                      INT i = 0;
                      copyFrom->getInt( copyFromIdx, &i );
                      setInt( thisListIdx, i );
                     } break;

                case ::cli::VariantType::vt_uint    :  
                     {
                      UINT i = 0;
                      copyFrom->getUInt( copyFromIdx, &i );
                      setUInt( thisListIdx, i );
                     } break;

                case ::cli::VariantType::vt_colorref    :  
                     {
                      COLORREF i = 0;
                      copyFrom->getColorref( copyFromIdx, &i );
                      setColorref( thisListIdx, i );
                     } break;

                case ::cli::VariantType::vt_int64   :  
                     {
                      INT64 i = 0;
                      copyFrom->getInt64( copyFromIdx, &i );
                      setInt64( thisListIdx, i );
                     } break;

                case ::cli::VariantType::vt_uint64  :  
                     {
                      UINT64 i = 0;
                      copyFrom->getUInt64( copyFromIdx, &i );
                      setUInt64( thisListIdx, i );
                     } break;

                case ::cli::VariantType::vt_int_ptr :  
                     {
                      INT_PTR i = 0;
                      copyFrom->getIntPtr( copyFromIdx, &i );
                      setIntPtr( thisListIdx, i );
                     } break;

                case ::cli::VariantType::vt_uint_ptr:  
                     {
                      UINT_PTR i = 0;
                      copyFrom->getUIntPtr( copyFromIdx, &i );
                      setUIntPtr( thisListIdx, i );
                     } break;

                case ::cli::VariantType::vt_float   :  
                     {
                      FLOAT f = 0;
                      copyFrom->getFloat( copyFromIdx, &f );
                      setFloat( thisListIdx, f );
                     } break;

                case ::cli::VariantType::vt_double  :  
                     {
                      DOUBLE f = 0;
                      copyFrom->getDouble( copyFromIdx, &f );
                      setDouble( thisListIdx, f );
                     } break;

                case ::cli::VariantType::vt_dump    :  
                     {
                      CLIPCSTR pcstr = 0;
                      if (!copyFrom->getDump( copyFromIdx, &pcstr ))
                         {
                          setDump(thisListIdx, (const BYTE*)clipstr_data(pcstr), clipstr_size(pcstr) );
                          clipstr_free(&pcstr);
                         }
                     } break;

                case ::cli::VariantType::vt_pstring :  
                     {
                      CLIPSTR pstr = 0;
                      if (!copyFrom->getStringPStr( copyFromIdx, &pstr ))
                         {
                          setStringPStr(thisListIdx, pstr);
                          clipstr_free(&pstr);
                         }
                     } break;

                case ::cli::VariantType::vt_ptr     :  
                     {
                      VOID* p = 0;
                      copyFrom->getPtr( copyFromIdx, &p );
                      setPtr( thisListIdx, p );
                     } break;

                case ::cli::VariantType::vt_datetime:  
                     {
                      STRUCT_CLI_CLISYSTEMTIME dt;
                      copyFrom->getDate( copyFromIdx, &dt );
                      setDate( thisListIdx, &dt );
                     } break;
                //case :  

                case ::cli::VariantType::vt_iUnknown:  
                     {
                      INTERFACE_CLI_IUNKNOWN*  pUnknown = 0;
                      copyFrom->getUnknown(copyFromIdx,&pUnknown);
                      setUnknown(thisListIdx, pUnknown);
                      if (pUnknown) pUnknown->release();
                     } break;

                case ::cli::VariantType::vt_bigint:  
                     {
                      STRUCT_CLI_BIGINTEGER bi;
                      copyFrom->getBigInteger( copyFromIdx, &bi );
                      setBigInteger( thisListIdx, &bi );
                     } break;

                case ::cli::VariantType::vt_rational:  
                     {
                      STRUCT_CLI_RATIONALNUMBER r;
                      copyFrom->getRationalNumber( copyFromIdx, &r );
                      setRationalNumber( thisListIdx, &r );
                     } break;

                case ::cli::VariantType::vt_empty   :  
                default:  return setEmpty(thisListIdx);
               }

            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putCopyFrom) (THIS_ INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                              , SIZE_T    copyFromIdx /* [in] size_t  copyFromIdx  */
                                                         )
           {
            return setCopyFrom( SIZE_T_NPOS, copyFrom, copyFromIdx );
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putArgList) (THIS_ INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */
                                                             , SIZE_T    copyFromIdxBegin /* [in] size_t  copyFromIdxBegin  */
                                                             , SIZE_T    copyFromIdxEnd /* [in] size_t  copyFromIdxEnd  */
                                                        )
           {
            if (!copyFrom)
               { // do nothing
                return static_cast<INTERFACE_CLI_IARGLIST*>(this);
               }

            SIZE_T thatSize = copyFrom->getCount();
            if (copyFromIdxBegin>=thatSize)
               {
                return static_cast<INTERFACE_CLI_IARGLIST*>(this);
               }

            if (copyFromIdxEnd>=thatSize)
               copyFromIdxEnd = thatSize;

            for(; copyFromIdxBegin!=copyFromIdxEnd; ++copyFromIdxBegin)
               putCopyFrom(copyFrom, copyFromIdxBegin);

            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putArgListAll) (THIS_ INTERFACE_CLI_IARGLIST*    copyFrom /* [in] ::cli::iArgList*  copyFrom  */)
           {
            return putArgList( copyFrom, 0, SIZE_T_NPOS );
           }

        CLIMETHOD_(DWORD, getType) (THIS_ SIZE_T    idx /* [in] size_t  idx  */)
           {
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            return val.valType;
           }

        CLIMETHOD(convertType) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                    , ENUM_CLI_VARIANTTYPE    newType /* [in] ::cli::VariantType  newType  */
                               )
           {
            CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            if (val.valType==newType) return EC_OK;
            val.convert( (DWORD)newType, false);
            return EC_OK;
           }

        CLIMETHOD(getTypeStringChars) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                 , WCHAR*    buf /* [out] wchar buf[]  */
                                                 , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                            )
           {
            if (!buf && !bufSize) return EC_INVALID_PARAM;
            //if (!buf) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;

            if (!buf) // but bufSize taken
               {
                *bufSize = val.typeName(L'W').size() + 1;
                return EC_OK;
               }
            if (!bufSize) return EC_INVALID_PARAM;
            ::cli::util::copyStr2buf( val.typeName(L'W'), buf, *bufSize, bufSize );
            return EC_OK;
           }

        CLIMETHOD_(SIZE_T, getCount) (THIS)
           {
            return varList.size();
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putEmpty) (THIS)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putBool) (THIS_ BOOL    b /* [in] bool  b  */)
           {
            if (allowUseArgList)
               {
                //varList.push_back( CVariant( (BOOL)b ) );
                varList.push_back( CVariant::makeBool( b ) );                
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putChar) (THIS_ CHAR    ch /* [in] char  ch  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( ch ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putWChar) (THIS_ WCHAR    wch /* [in] wchar  wch  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( wch ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putShort) (THIS_ SHORT    s /* [in] short  s  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( s ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUShort) (THIS_ USHORT    us /* [in] ushort  us  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( us ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putInt) (THIS_ INT    i /* [in] int  i  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( i ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUInt) (THIS_ UINT    i /* [in] uint  i  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( i ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putInt64) (THIS_ INT64    i /* [in] int64  i  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( i ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUInt64) (THIS_ UINT64    i /* [in] uint64  i  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( i ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putIntPtr) (THIS_ INT_PTR    i /* [in] int_ptr  i  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( (INT_PTR)i, true /* dummy */ ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUIntPtr) (THIS_ UINT_PTR    i /* [in] uint_ptr  i  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( (UINT_PTR)i, true /* dummy */ ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putFloat) (THIS_ FLOAT    f /* [in] float  f  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( f ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putDouble) (THIS_ DOUBLE    d /* [in] double  d  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( d ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putPtr) (THIS_ const VOID*    vptr /* [in] void*  vptr  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( const_cast<VOID*>(vptr) ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putUnknown) (THIS_ INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( pUnknown ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putString) (THIS_ const CLISTR*     str)
           {
            if (allowUseArgList)
               {
                CLIPSTR pstr = 0;
                if (!str)
                   {
                    clipstr_alloc( &pstr, L"<NULL>" );
                   }
                else
                   {
                    CCliStr *pCliStr = (CCliStr*)str;
                    if (!pCliStr->data())
                       {
                        clipstr_alloc( &pstr, L"<NULL>" );
                       }
                    else
                       {
                        clipstr_alloc( &pstr, pCliStr->data(), pCliStr->size() );
                       }
                   }

                varList.push_back( CVariant( pstr ) ); // takes ownership of allocated pstr to CVariant
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putStringPStr) (THIS_ CLIPSTR           str)
           {
            if (allowUseArgList)
               {
                if (!str)
                   {
                    CLIPSTR pstr = 0;
                    clipstr_alloc( &pstr, L"<NULL>" );
                    varList.push_back( CVariant( pstr ) );
                   }
                else
                   {
                    varList.push_back( CVariant( str ) );
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putStringChars) (THIS_ const WCHAR*    str /* [in] wchar  str[]  */
                                       , SIZE_T    strSize /* [in] size_t  strSize  */
                                  )
           {
            if (allowUseArgList)
               {
                CLIPSTR pstr = 0;
                if (!str)
                   {
                    clipstr_alloc( &pstr, L"<NULL>" );
                   }
                else
                   {
                    if (strSize==SIZE_T_NPOS)
                       clipstr_alloc( &pstr, str );
                    else
                       clipstr_alloc( &pstr, str, strSize );
                   }

                varList.push_back( CVariant( pstr ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putDump) (THIS_ const BYTE*    d /* [in] byte  d[]  */
                                                          , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                                                     )
           {
            if (!d || !dumpSize)
               {
                varList.push_back( CVariant( (UINT)0 ) );
               }
            else
               {
                CLIPCSTR pstr = 0;
                clipstr_alloc( &pstr, (const CHAR*)d, dumpSize );
                varList.push_back( CVariant( pstr ) );
               }
            return EC_OK;
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putDate) (THIS_ const STRUCT_CLI_CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */)
           {
            //STRUCT_CLI_CLISYSTEMTIME
            if (allowUseArgList)
               {
                if (!datetime)
                   varList.push_back( CVariant( (INT64)0 ) );
                else
                   varList.push_back( CVariant( *datetime ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putBigInteger) (THIS_ const STRUCT_CLI_BIGINTEGER*    bigint /* [in,ref] ::cli::BigInteger  bigint  */)
           {
            if (allowUseArgList)
               {
                if (!bigint)
                   varList.push_back( CVariant( ::cli::numeric::extended_int128_t(0) ) );
                   //varList.push_back( CVariant( (INT64)0 ) );
                else
                   varList.push_back( CVariant( *bigint ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putRationalNumber) (THIS_ const STRUCT_CLI_RATIONALNUMBER*    rational /* [in,ref] ::cli::RationalNumber  rational  */)
           {
            if (allowUseArgList)
               {
                if (!rational)
                   varList.push_back( CVariant( ::cli::numeric::rational_number_t(0) ) );
                   //varList.push_back( CVariant( (INT64)0 ) );
                else
                   varList.push_back( CVariant( *rational ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        void expandToSize( SIZE_T newSize )
           {
            while(varList.size()!=newSize) varList.push_back( CVariant() );
           }

        template <typename T>
        INTERFACE_CLI_IARGLIST* setVal(SIZE_T idx, T t)
           {
            if (allowUseArgList)
               {
                if (idx==SIZE_T_NPOS)
                   {
                    varList.push_back( CVariant( t ) );
                   }
                else
                   {
                    expandToSize(idx+1);
                    //while(varList.size()!=(idx+1)) varList.push_back( CVariant() );
                    varList[idx] = CVariant( t );
                   }
                /*
                if (varList.size()>=idx)
                   varList.push_back( CVariant( t ) );
                else
                   varList[idx] = CVariant( t );
                */
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);           
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setEmpty) (THIS_ SIZE_T    idx /* [in] size_t  idx  */)
           {
            if (allowUseArgList)
               {
                if (idx==SIZE_T_NPOS)
                   {
                    varList.push_back( CVariant( ) );
                   }
                else
                   {
                    //while(varList.size()!=(idx+1)) varList.push_back( CVariant() );
                    expandToSize(idx+1);
                    varList[idx] = CVariant( );
                   }
                /*
                if (varList.size()>=idx)
                   varList.push_back( CVariant( t ) );
                else
                   varList[idx] = CVariant( t );
                */
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setBool) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                          , BOOL    b /* [in] bool  b  */
                                                     )
           {
            if (allowUseArgList)
               {
                if (idx==SIZE_T_NPOS)
                   {
                    varList.push_back( CVariant::makeBool( b ) );
                   }
                else
                   {
                    //while(varList.size()!=(idx+1)) varList.push_back( CVariant() );
                    expandToSize(idx+1);
                    varList[idx] = CVariant::makeBool( b );
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);           
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setChar) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                          , CHAR    ch /* [in] char  ch  */
                                                     )
           {
            return setVal(idx, ch);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setWChar) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                           , WCHAR    wch /* [in] wchar  wch  */
                                                      )
           {
            return setVal(idx, wch);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setShort) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                           , SHORT    s /* [in] short  s  */
                                                      )
           {
            return setVal(idx, s);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUShort) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                            , USHORT    us /* [in] ushort  us  */
                                                       )
           {
            return setVal(idx, us);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setInt) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                         , INT    i /* [in] int  i  */
                                                    )
           {
            return setVal(idx, i);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUInt) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                          , UINT    i /* [in] uint  i  */
                                                     )
           {
            return setVal(idx, i);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setInt64) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                           , INT64    i /* [in] int64  i  */
                                                      )
           {
            return setVal(idx, i);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUInt64) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                            , UINT64    i /* [in] uint64  i  */
                                                       )
           {
            return setVal(idx, i);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setIntPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                            , INT_PTR    i /* [in] int_ptr  i  */
                                                       )
           {
            if (allowUseArgList)
               {
                //if (varList.size()>=idx)
                if (idx==SIZE_T_NPOS)
                   varList.push_back( CVariant( (INT_PTR)i, true /* dummy */ ) );
                else
                   {
                    expandToSize(idx+1);
                    varList[idx] = CVariant( (INT_PTR)i, true /* dummy */ );
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUIntPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                             , UINT_PTR    i /* [in] uint_ptr  i  */
                                                        )
           {
            if (allowUseArgList)
               {
                //if (varList.size()>=idx)
                if (idx==SIZE_T_NPOS)
                   varList.push_back( CVariant( (UINT_PTR)i, true /* dummy */ ) );
                else
                   {
                    expandToSize(idx+1);
                    varList[idx] = CVariant( (UINT_PTR)i, true /* dummy */ );
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setFloat) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                           , FLOAT    f /* [in] float  f  */
                                                      )
           {
            return setVal(idx, f);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setDouble) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                            , DOUBLE    d /* [in] double  d  */
                                                       )
           {
            return setVal(idx, d);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                         , const VOID*    vptr /* [in] void*  vptr  */
                                                    )
           {
            if (allowUseArgList)
               {
                //if (varList.size()>=idx)
                if (idx==SIZE_T_NPOS)
                   varList.push_back( CVariant( const_cast<VOID*>(vptr) ) );
                else
                   {
                    expandToSize(idx+1);
                    varList[idx] = CVariant( const_cast<VOID*>(vptr) );
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setUnknown) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                             , INTERFACE_CLI_IUNKNOWN*    pUnknown /* [in] ::cli::iUnknown*  pUnknown  */
                                                        )
           {
            if (allowUseArgList)
               {
                if (idx==SIZE_T_NPOS)
                   varList.push_back( CVariant( pUnknown ) );
                else
                   {
                    expandToSize(idx+1);
                    varList[idx] = CVariant( pUnknown );
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                            , const CLISTR*     str
                                                       )
           {
            if (allowUseArgList)
               {
                CLIPSTR pstr = 0;
                if (!str)
                   {
                    clipstr_alloc( &pstr, L"<NULL>" );
                   }
                else
                   {
                    CCliStr *pCliStr = (CCliStr*)str;
                    if (!pCliStr->data())
                       {
                        clipstr_alloc( &pstr, L"<NULL>" );
                       }
                    else
                       {
                        clipstr_alloc( &pstr, pCliStr->data(), pCliStr->size() );
                       }
                   }

                //if (varList.size()>=idx)
                if (idx==SIZE_T_NPOS)
                   varList.push_back( CVariant( pstr ) ); // takes ownership of allocated pstr to CVariant
                else
                   {
                    expandToSize(idx+1);
                    varList[idx] = CVariant( pstr ); // takes ownership of allocated pstr to CVariant
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }
        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setStringPStr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                , CLIPSTR           str
                                                           )
           {
            if (allowUseArgList)
               {
                if (!str)
                   {
                    CLIPSTR pstr = 0;
                    clipstr_alloc( &pstr, L"<NULL>" );
                    //if (varList.size()>=idx)
                    if (idx==SIZE_T_NPOS)
                       varList.push_back( CVariant( pstr ) );
                    else
                       {
                        expandToSize(idx+1);
                        varList[idx] = CVariant( pstr );
                       }
                   }
                else
                   {
                    CLIPSTR pstr = 0;
                    //clipstr_data
                    //clipstr_size
                    clipstr_alloc( &pstr, str );
                    //if (varList.size()>=idx)
                    if (idx==SIZE_T_NPOS)
                       varList.push_back( CVariant( pstr ) ); // str
                    else
                       {
                        expandToSize(idx+1);
                        varList[idx] = CVariant( pstr ); // str
                       }
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setStringChars) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                 , const WCHAR*    str /* [in,flat] wchar  str[]  */
                                                                 , SIZE_T    strSize /* [in] size_t  strSize  */
                                                            )
           {
            if (allowUseArgList)
               {
                CLIPSTR pstr = 0;
                if (!str)
                   {
                    clipstr_alloc( &pstr, L"<NULL>" );
                   }
                else
                   {
                    if (strSize==SIZE_T_NPOS)
                       clipstr_alloc( &pstr, str );
                    else
                       clipstr_alloc( &pstr, str, strSize );
                   }
                //if (varList.size()>=idx)
                if (idx==SIZE_T_NPOS)
                   varList.push_back( CVariant( pstr ) );
                else
                   {
                    expandToSize(idx+1);
                    varList[idx] = CVariant( pstr );
                   }
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setDump) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                          , const BYTE*    d /* [in,flat] byte  d[]  */
                                                          , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                                                     )
           {
            if (!d || !dumpSize)
               {
                varList.push_back( CVariant( (UINT)0 ) );
               }
            else
               {
                CLIPCSTR pstr = 0;
                clipstr_alloc( &pstr, (const CHAR*)d, dumpSize );
                //if (varList.size()>=idx)
                if (idx==SIZE_T_NPOS)
                   varList.push_back( CVariant( pstr ) );
                else
                   {
                    expandToSize(idx+1);
                    varList[idx] = CVariant( pstr );
                   }
               }
            return EC_OK;
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setDate) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                          , const STRUCT_CLI_CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */
                                                     )
           {
            if (!datetime)
               return setVal(idx, (INT64)0);
            else
               return setVal(idx, *datetime);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setBigInteger) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                , const STRUCT_CLI_BIGINTEGER*    bigint /* [in,ref] ::cli::BigInteger  bigint  */
                                                           )
           {
            if (!bigint)
               return setVal(idx, ::cli::numeric::extended_int128_t(0));
            else
               return setVal(idx, *bigint);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setRationalNumber) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                    , const STRUCT_CLI_RATIONALNUMBER*    rational /* [in,ref] ::cli::RationalNumber  rational  */
                                                               )
           {
            if (!rational)
               return setVal(idx, ::cli::numeric::rational_number_t(0));
            else
               return setVal(idx, *rational);
           }

        CLIMETHOD(getBool) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                , BOOL*    b /* [out] bool b  */
                           )
           {
            if (!b) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *b = val.asBool();
            return EC_OK;
           }

        CLIMETHOD(getChar) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                , CHAR*    ch /* [out] char ch  */
                           )
           {
            if (!ch) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *ch = val.asChar();
            return EC_OK;
           }

        CLIMETHOD(getWChar) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                 , WCHAR*    wch /* [out] wchar wch  */
                            )
           {
            if (!wch) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *wch = val.asWChar();
            return EC_OK;            
           }

        CLIMETHOD(getShort) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                 , SHORT*    s /* [out] short s  */
                            )
           {
            if (!s) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *s = val.asShort();
            return EC_OK;            
           }

        CLIMETHOD(getUShort) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                  , USHORT*    us /* [out] ushort us  */
                             )
           {
            if (!us) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *us = val.asUShort();
            return EC_OK;            
           }

        CLIMETHOD(getInt) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                               , INT*    i /* [out] int i  */
                          )
           {
            if (!i) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *i = val.asInt();
            return EC_OK;            
           }

        CLIMETHOD(getUInt) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                , UINT*    i /* [out] uint i  */
                           )
           {
            if (!i) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *i = val.asUInt();
            return EC_OK;            
           }

        CLIMETHOD(getInt64) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                 , INT64*    i /* [out] int64 i  */
                            )
           {
            if (!i) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *i = val.asInt64();
            return EC_OK;            
           }

        CLIMETHOD(getUInt64) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                  , UINT64*    i /* [out] uint64 i  */
                             )
           {
            if (!i) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *i = val.asUInt64();
            return EC_OK;            
           }

        CLIMETHOD(getIntPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                  , INT_PTR*    i /* [out] int_ptr i  */
                             )
           {
            if (!i) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *i = val.asIntPtr();
            return EC_OK;            
           }

        CLIMETHOD(getUIntPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                   , UINT_PTR*    i /* [out] uint_ptr i  */
                              )
           {
            if (!i) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *i = val.asUIntPtr();
            return EC_OK;            
           }

        CLIMETHOD(getFloat) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                 , FLOAT*    f /* [out] float f  */
                            )
           {
            if (!f) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *f = val.asFloat();
            return EC_OK;            
           }

        CLIMETHOD(getDouble) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                  , DOUBLE*    d /* [out] double d  */
                             )
           {
            if (!d) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *d = val.asDouble();
            return EC_OK;            
           }

        CLIMETHOD(getPtr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                               , VOID**    vptr /* [out] void* vptr  */
                          )
           {
            if (!vptr) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *vptr = val.asPtr();
            return EC_OK;            
           }

        CLIMETHOD(getUnknown) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                   , INTERFACE_CLI_IUNKNOWN**    pUnknown /* [out] ::cli::iUnknown* pUnknown  */
                              )
           {
            if (!pUnknown) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *pUnknown = val.asUnknown();
            if (*pUnknown) (*pUnknown)->addRef();
            return EC_OK;
           }

        CLIMETHOD(getString) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                  , CLISTR*           str
                             )
           {
            if (!str) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            CCliStr_copyTo( *((CCliStr*)str), val.asString() );
            return EC_OK;            
           }

        CLIMETHOD(getStringPStr) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , CLIPSTR*          str
                                 )
           {
            if (!str) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            CLIPSTR_copyTo( *str, val.asString() );
            return EC_OK;            
           }

        CLIMETHOD(getStringChars) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                       , WCHAR*    buf /* [out] wchar buf[]  */
                                       , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                                  )
           {
            if (!buf && !bufSize) return EC_INVALID_PARAM;
            //if (!buf) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;

            if (!buf) // but bufSize taken
               {
                *bufSize = val.asString().size() + 1;
                return EC_OK;
               }
            if (!bufSize) return EC_INVALID_PARAM;
            ::cli::util::copyStr2buf( val.asString(), buf, *bufSize, bufSize );
            return EC_OK;
           }

        CLIMETHOD(getDate) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                , STRUCT_CLI_CLISYSTEMTIME*    datetime /* [out] ::cli::CLISYSTEMTIME datetime  */
                           )
           {
            if (!datetime) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *datetime = val.asDatetime();
            return EC_OK;
           }

        CLIMETHOD(getBigInteger) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                      , STRUCT_CLI_BIGINTEGER*    bigint /* [out] ::cli::BigInteger bigint  */
                                 )
           {
            if (!bigint) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *bigint = val.asBigInteger();
            return EC_OK;
           }

        CLIMETHOD(getRationalNumber) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                          , STRUCT_CLI_RATIONALNUMBER*    rational /* [out] ::cli::RationalNumber rational  */
                                     )
           {
            if (!rational) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *rational = val.asRational();
            return EC_OK;
           }

        CLIMETHOD(getDump) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                , CLIPCSTR*         str
                           )
           {
            if (!str) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            if (val.valType != ::cli::VariantType::vt_dump)
               {
                clipstr_assign(str, "", 0);
               }
            else
               {
                clipstr_assign(str, clipstr_data(val.value.vDump), clipstr_size(val.value.vDump) );
               }
            return EC_OK;
           }


        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putVariant) (THIS_ INTERFACE_CLI_IVARIANT*    v /* [in] ::cli::iVariant*  v  */)
           {
            if (allowUseArgList)
               {
                if (!v)
                   {
                    varList.push_back( CVariant( ) );
                   }
                else
                   {
                    return putVariantRaw(v->getVariantRawPtr());
                   }
               }
            return EC_OK;
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putVariantRaw) (THIS_ const STRUCT_CLI_VARIANT*    v /* [in,ref] ::cli::Variant  v  */)
           {
            if (allowUseArgList)
               {
                if (!v)
                   {
                    varList.push_back( CVariant( ) );
                   }
                else
                   {
                    varList.push_back( CVariant( *v ) );
                   }
               }           
            return EC_OK;
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setVariant) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                             , INTERFACE_CLI_IVARIANT*    v /* [in] ::cli::iVariant*  v  */
                                                        )
           {
            if (allowUseArgList)
               {
                if (!v)
                   {
                    if (idx==SIZE_T_NPOS)
                       varList.push_back( CVariant( ) );
                    else
                       expandToSize(idx+1);
                   }
                else
                   {
                    return setVariantRaw(idx, v->getVariantRawPtr());
                   }
               }           
            return EC_OK;
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setVariantRaw) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                                , const STRUCT_CLI_VARIANT*    v /* [in,ref] ::cli::Variant  v  */
                                                           )
           {
            if (allowUseArgList)
               {
                CVariant variantTmp; // empty variant
                if (v)
                   {
                    CVariant tmp(*v);
                    variantTmp.swap(tmp);
                   }
                if (idx==SIZE_T_NPOS)
                    idx = varList.size();
                expandToSize(idx+1);
                varList[idx].swap(variantTmp);
               }
            return EC_OK;
           }

        INTERFACE_CLI_IVARIANT* createIVariant( INTERFACE_CLI_IVARIANT* referenceVar )
           {
            if (referenceVar) 
               {
                INTERFACE_CLI_IVARIANT * pvEmpty = 0;
                referenceVar->createEmptyVariant( &pvEmpty );
                return pvEmpty;
               }
            else return cliGetVariant();
           }

        CLIMETHOD(splitIntoVariantsEx) (THIS_ INTERFACE_CLI_IVARIANT**    v /* [out,flat] ::cli::iVariant* v[]  */
                                            , SIZE_T    count /* [in] size_t  count  */
                                            , INTERFACE_CLI_IVARIANT*    referenceVar /* [in] ::cli::iVariant*  referenceVar  */
                                            , SIZE_T    startIdx /* [in] size_t  startIdx  */
                                       )
           {
            if (!v) return EC_INVALID_PARAM;
            for( SIZE_T idx = startIdx, endIdx = startIdx + count, vPos = 0
               ; idx != endIdx
               ; ++idx, ++vPos
               )
               {
                v[vPos] = createIVariant( referenceVar );
                if (!v[vPos]) continue;
                if ( idx >= varList.size() ) continue;
                v[vPos]->assignRawVariant( &varList[idx] );
               }
            return EC_OK;
           }


        CLIMETHOD(splitIntoVariants) (THIS_ INTERFACE_CLI_IVARIANT**    v /* [out,flat] ::cli::iVariant* v[]  */
                                          , SIZE_T    count /* [in] size_t  count  */
                                     )
           {
            return splitIntoVariantsEx( v, count, 0, 0 );
           }

        CLIMETHOD(putFromVariants) (THIS_ INTERFACE_CLI_IVARIANT**    v /* [in,flat] ::cli::iVariant*  v[]  */
                                        , SIZE_T    count /* [in] size_t  count  */
                                   )
           {
            if (!v) return EC_INVALID_PARAM;
            for(SIZE_T idx = 0; idx!=count; ++idx )
               {
                putVariant( v[idx] );
               }
            return EC_OK;
           }

        CLIMETHOD(assignFromVariants) (THIS_ INTERFACE_CLI_IVARIANT**    v /* [in,flat] ::cli::iVariant*  v[]  */
                                           , SIZE_T    count /* [in] size_t  count  */
                                      )
           {
            clearArgList();
            return putFromVariants( v, count );
           }


        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, putColorref) (THIS_ COLORREF    i /* [in] colorref  i  */)
           {
            if (allowUseArgList)
               {
                varList.push_back( CVariant( i, vt_colorref ) );
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);
           }

        CLIMETHOD_(INTERFACE_CLI_IARGLIST*, setColorref) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                                              , COLORREF    i /* [in] colorref  i  */
                                                         )
           {
            if (allowUseArgList)
               {
                if (idx==SIZE_T_NPOS)
                   {
                    varList.push_back( CVariant( i, vt_colorref ) );
                   }
                else
                   {
                    expandToSize(idx+1);
                    //while(varList.size()!=(idx+1)) varList.push_back( CVariant() );
                    varList[idx] = CVariant( i, vt_colorref );
                   }
                /*
                if (varList.size()>=idx)
                   varList.push_back( CVariant( t ) );
                else
                   varList[idx] = CVariant( t );
                */
               }
            return static_cast<INTERFACE_CLI_IARGLIST*>(this);           
           }

        CLIMETHOD(getColorref) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                    , COLORREF*    i /* [out] colorref i  */
                               )
           {
            if (!i) return EC_OK;
            const CVariant &val = (idx < varList.size()) ? varList[idx] : defValue;
            *i = val.asColorref();
            return EC_OK;            
           }

        CLIMETHOD(valueQueryInterface) (THIS_ SIZE_T    idx /* [in] size_t  idx  */
                                            , const CHAR*    interfaceId /* [in] char*  interfaceId  */
                                            , VOID**    ifPtr /* [out] void* ifPtr  */
                                       )
           {
            CLI_TRY{
                    if (!interfaceId) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"interfaceId" );  }
                    if (!ifPtr)       { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"ifPtr" );  }

                    if (idx >= varList.size()) return EC_OUT_OF_RANGE;

                    if (varList[idx].valType!=::cli::VariantType::vt_iUnknown)
                        return EC_NOT_OBJECT;

                    if (!varList[idx].value.vUnknown)
                       return EC_NO_OBJECT;

                    return varList[idx].value.vUnknown->queryInterface( interfaceId, ifPtr );
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }




}; // class CArgList

}; // namespace impl
//}; // namespace arglist
}; // namespace cli





#endif /* CORE_ALIMPL_H */


