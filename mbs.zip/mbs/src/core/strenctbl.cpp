struct CEncodingInfo{
  unsigned encCode;
  unsigned encNameIdx;
  const char *encInfoString;
};

struct CEncNameToIndex{
 const char *encName;
  unsigned encIdx;
};

static
CEncodingInfo encInfo[105] = {
  { 3, 57, "International charsets to ASCI mapping" }, // translit, transliteration
  { 437, 35, "OEM United States" }, // ibm-437, ibm437
  { 708, 2, "Arabic (ASMO 708)" }, // asmo-708
  { 709, 1, "ASMO-449+, BCON V4" }, // asmo-449
  { 710, 0, "Transparent Arabic" }, // arabic
  { 720, 27, "Arabic (Transparent ASMO); Arabic (DOS)" }, // dos-720
  { 737, 13, "OEM Greek (formerly 437G); Greek (DOS)" }, // cp-737, cp737, ibm-737, ibm737
  { 775, 14, "OEM Baltic; Baltic (DOS)" }, // cp-775, cp775, ibm-775, ibm775
  { 850, 15, "OEM Multilingual Latin 1; Western European (DOS)" }, // cp-850, cp850, ibm-850, ibm850
  { 852, 16, "OEM Latin 2; Central European (DOS)" }, // cp-852, cp852, ibm-852, ibm852
  { 855, 17, "OEM Cyrillic (primarily Russian)" }, // cp-855, cp855, ibm-855, ibm855
  { 857, 18, "OEM Turkish; Turkish (DOS)" }, // cp-857, cp857, ibm-857, ibm857
  { 858, 36, "OEM Multilingual Latin 1 + Euro symbol" }, // ibm00858
  { 860, 19, "OEM Portuguese; Portuguese (DOS)" }, // cp-860, cp860, ibm-860, ibm860
  { 861, 20, "OEM Icelandic; Icelandic (DOS)" }, // cp-861, cp861, ibm-861, ibm861
  { 862, 28, "OEM Hebrew; Hebrew (DOS)" }, // dos-862
  { 863, 21, "OEM French Canadian; French Canadian (DOS)" }, // cp-863, cp863, ibm-863, ibm863
  { 864, 22, "OEM Arabic; Arabic (864)" }, // cp-864, cp864, ibm-864, ibm864
  { 865, 23, "OEM Nordic; Nordic (DOS)" }, // cp-865, cp865, ibm-865, ibm865
  { 866, 24, "OEM Russian; Cyrillic (DOS)" }, // cp-866, cp866, ibm-866, ibm866
  { 869, 25, "OEM Modern Greek; Greek, Modern (DOS)" }, // cp-869, cp869, ibm-869, ibm869
  { 874, 63, "ANSI/OEM Thai (same as 28605, ISO 8859-15); Thai (Windows)" }, // windows-874
  { 932, 56, "ANSI/OEM Japanese; Japanese (Shift-JIS)" }, // shift-jis, shift_jis
  { 936, 33, "ANSI/OEM Simplified Chinese (PRC, Singapore); Chinese Simplified (GB2312)" }, // gb2312
  { 949, 54, "ANSI/OEM Korean (Unified Hangul Code)" }, // ks-c-5601-1987, ks_c_5601-1987
  { 950, 3, "ANSI/OEM Traditional Chinese (Taiwan; Hong Kong SAR, PRC); Chinese Traditional (Big5)" }, // big5
  { 1200, 58, "Unicode (UTF-16) little endian" }, // unicodeFEFF, utf-16, utf-16(le), utf-16le
  { 1201, 59, "Unicode (UTF-16) big endian" }, // unicodeFFFE, utf-16(be), utf-16be
  { 1250, 4, "ANSI Central European; Central European (Windows)" }, // cp-1250, cp1250, windows-1250, windows1250
  { 1251, 5, "ANSI Cyrillic; Cyrillic (Windows)" }, // cp-1251, cp1251, windows-1251, windows1251
  { 1252, 6, "ANSI Latin 1; Western European (Windows)" }, // cp-1252, cp1252, windows-1252, windows1252
  { 1253, 7, "ANSI Greek; Greek (Windows)" }, // cp-1253, cp1253, windows-1253, windows1253
  { 1254, 8, "ANSI Turkish; Turkish (Windows)" }, // cp-1254, cp1254, windows-1254, windows1254
  { 1255, 9, "ANSI Hebrew; Hebrew (Windows)" }, // cp-1255, cp1255, windows-1255, windows1255
  { 1256, 10, "ANSI Arabic; Arabic (Windows)" }, // cp-1256, cp1256, windows-1256, windows1256
  { 1257, 11, "ANSI Baltic; Baltic (Windows)" }, // cp-1257, cp1257, windows-1257, windows1257
  { 1258, 12, "ANSI/OEM Vietnamese; Vietnamese (Windows)" }, // cp-1258, cp1258, windows-1258, windows1258
  { 10000, 55, "macintosh MAC Roman; Western European (Mac)" }, // macintosh
  { 10001, 101, "Japanese (Mac)" }, // x-mac-japanese
  { 10002, 95, "MAC Traditional Chinese (Big5); Chinese Traditional (Mac)" }, // x-mac-chinesetrad
  { 10003, 102, "Korean (Mac)" }, // x-mac-korean
  { 10004, 92, "Arabic (Mac)" }, // x-mac-arabic
  { 10005, 99, "Hebrew (Mac)" }, // x-mac-hebrew
  { 10006, 98, "Greek (Mac)" }, // x-mac-greek
  { 10007, 97, "Cyrillic (Mac)" }, // x-mac-cyrillic
  { 10008, 94, "MAC Simplified Chinese (GB 2312); Chinese Simplified (Mac)" }, // x-mac-chinesesimp
  { 10010, 103, "Romanian (Mac)" }, // x-mac-romanian
  { 10017, 106, "Ukrainian (Mac)" }, // x-mac-ukrainian
  { 10021, 104, "Thai (Mac)" }, // x-mac-thai
  { 10029, 93, "MAC Latin 2; Central European (Mac)" }, // x-mac-ce
  { 10079, 100, "Icelandic (Mac)" }, // x-mac-icelandic
  { 10081, 105, "Turkish (Mac)" }, // x-mac-turkish
  { 10082, 96, "Croatian (Mac)" }, // x-mac-croatian
  { 20000, 64, "CNS Taiwan; Chinese Traditional (CNS)" }, // x-chinese-cns, x-chinese_cns
  { 20001, 67, "TCA Taiwan" }, // x-cp20001
  { 20002, 65, "Eten Taiwan; Chinese Traditional (Eten)" }, // x-chinese-eten, x_chinese-eten
  { 20003, 68, "IBM5550 Taiwan" }, // x-cp20003
  { 20004, 69, "TeleText Taiwan" }, // x-cp20004
  { 20005, 70, "Wang Taiwan" }, // x-cp20005
  { 20105, 78, "IA5 (IRV International Alphabet No. 5, 7-bit); Western European (IA5)" }, // x-ia5
  { 20106, 79, "IA5 German (7-bit)" }, // x-ia5-german
  { 20107, 81, "IA5 Swedish (7-bit)" }, // x-ia5-swedish
  { 20108, 80, "IA5 Norwegian (7-bit)" }, // x-ia5-norwegian
  { 20127, 60, "US-ASCII (7-bit)" }, // us-ascii
  { 20261, 71, "T.61" }, // x-cp20261
  { 20269, 72, "ISO 6937 Non-Spacing Accent" }, // x-cp20269
  { 20866, 52, "Russian (KOI8-R); Cyrillic (KOI8-R)" }, // koi8-r
  { 20936, 73, "Simplified Chinese (GB2312); Chinese Simplified (GB2312-80)" }, // x-cp20936
  { 20949, 74, "Korean Wansung" }, // x-cp20949
  { 21866, 53, "Ukrainian (KOI8-U); Cyrillic (KOI8-U)" }, // koi8-u
  { 28591, 40, "ISO 8859-1 Latin 1; Western European (ISO)" }, // iso-8859-1
  { 28592, 43, "ISO 8859-2 Central European; Central European (ISO)" }, // iso-8859-2
  { 28593, 44, "ISO 8859-3 Latin 3" }, // iso-8859-3
  { 28594, 45, "ISO 8859-4 Baltic" }, // iso-8859-4
  { 28595, 46, "ISO 8859-5 Cyrillic" }, // iso-8859-5
  { 28596, 47, "ISO 8859-6 Arabic" }, // iso-8859-6
  { 28597, 48, "ISO 8859-7 Greek" }, // iso-8859-7
  { 28598, 49, "ISO 8859-8 Hebrew; Hebrew (ISO-Visual)" }, // iso-8859-8
  { 28599, 51, "ISO 8859-9 Turkish" }, // iso-8859-9
  { 28603, 41, "ISO 8859-13 Estonian" }, // iso-8859-13
  { 28605, 42, "ISO 8859-15 Latin 9" }, // iso-8859-15
  { 29001, 77, "Europa 3" }, // x-europa
  { 38598, 50, "ISO 8859-8 Hebrew; Hebrew (ISO-Logical)" }, // iso-8859-8-i
  { 50221, 26, "ISO 2022 Japanese with halfwidth Katakana; Japanese (JIS-Allow 1 byte Kana)" }, // csiso2022jp
  { 50222, 38, "ISO 2022 Japanese JIS X 0201-1989; Japanese (JIS-Allow 1 byte Kana - SO/SI)" }, // iso-2022-jp
  { 50225, 39, "ISO 2022 Korean" }, // iso-2022-kr
  { 50227, 75, "ISO 2022 Simplified Chinese; Chinese Simplified (ISO 2022)" }, // x-cp50227
  { 50229, 76, "ISO 2022 Traditional Chinese" }, // x-cp50229
  { 51932, 31, "EUC Japanese" }, // euc-jp
  { 51936, 30, "EUC Simplified Chinese; Chinese Simplified (EUC)" }, // euc-cn
  { 51949, 32, "EUC Korean" }, // euc-kr
  { 51950, 29, "Traditional Chinese" }, // euc
  { 52936, 34, "HZ-GB2312 Simplified Chinese; Chinese Simplified (HZ)" }, // hz-gb-2312
  { 57002, 84, "ISCII Devanagari" }, // x-iscii-de
  { 57003, 83, "ISCII Bengali" }, // x-iscii-be
  { 57004, 90, "ISCII Tamil" }, // x-iscii-ta
  { 57005, 91, "ISCII Telugu" }, // x-iscii-te
  { 57006, 82, "ISCII Assamese" }, // x-iscii-as
  { 57007, 88, "ISCII Oriya" }, // x-iscii-or
  { 57008, 86, "ISCII Kannada" }, // x-iscii-ka
  { 57009, 87, "ISCII Malayalam" }, // x-iscii-ma
  { 57010, 85, "ISCII Gujarati" }, // x-iscii-gu
  { 57011, 89, "ISCII Punjabi" }, // x-iscii-pa
  { 65000, 61, "Unicode (UTF-7)" }, // utf-7
  { 65001, 62, "Unicode (UTF-8)" } // utf-8
};

static
CEncNameToIndex encNameToIndex[182] = {
  { "arabic", 4 }, // 710
  { "asmo-449", 3 }, // 709
  { "asmo-708", 2 }, // 708
  { "big5", 25 }, // 950
  { "cp-1250", 28 }, // 1250
  { "cp-1251", 29 }, // 1251
  { "cp-1252", 30 }, // 1252
  { "cp-1253", 31 }, // 1253
  { "cp-1254", 32 }, // 1254
  { "cp-1255", 33 }, // 1255
  { "cp-1256", 34 }, // 1256
  { "cp-1257", 35 }, // 1257
  { "cp-1258", 36 }, // 1258
  { "cp-737", 6 }, // 737
  { "cp-775", 7 }, // 775
  { "cp-850", 8 }, // 850
  { "cp-852", 9 }, // 852
  { "cp-855", 10 }, // 855
  { "cp-857", 11 }, // 857
  { "cp-860", 13 }, // 860
  { "cp-861", 14 }, // 861
  { "cp-863", 16 }, // 863
  { "cp-864", 17 }, // 864
  { "cp-865", 18 }, // 865
  { "cp-866", 19 }, // 866
  { "cp-869", 20 }, // 869
  { "cp1250", 28 }, // 1250
  { "cp1251", 29 }, // 1251
  { "cp1252", 30 }, // 1252
  { "cp1253", 31 }, // 1253
  { "cp1254", 32 }, // 1254
  { "cp1255", 33 }, // 1255
  { "cp1256", 34 }, // 1256
  { "cp1257", 35 }, // 1257
  { "cp1258", 36 }, // 1258
  { "cp737", 6 }, // 737
  { "cp775", 7 }, // 775
  { "cp850", 8 }, // 850
  { "cp852", 9 }, // 852
  { "cp855", 10 }, // 855
  { "cp857", 11 }, // 857
  { "cp860", 13 }, // 860
  { "cp861", 14 }, // 861
  { "cp863", 16 }, // 863
  { "cp864", 17 }, // 864
  { "cp865", 18 }, // 865
  { "cp866", 19 }, // 866
  { "cp869", 20 }, // 869
  { "csiso2022jp", 83 }, // 50221
  { "dos-720", 5 }, // 720
  { "dos-862", 15 }, // 862
  { "euc", 91 }, // 51950
  { "euc-cn", 89 }, // 51936
  { "euc-jp", 88 }, // 51932
  { "euc-kr", 90 }, // 51949
  { "gb2312", 23 }, // 936
  { "hz-gb-2312", 92 }, // 52936
  { "ibm-437", 1 }, // 437
  { "ibm-737", 6 }, // 737
  { "ibm-775", 7 }, // 775
  { "ibm-850", 8 }, // 850
  { "ibm-852", 9 }, // 852
  { "ibm-855", 10 }, // 855
  { "ibm-857", 11 }, // 857
  { "ibm-860", 13 }, // 860
  { "ibm-861", 14 }, // 861
  { "ibm-863", 16 }, // 863
  { "ibm-864", 17 }, // 864
  { "ibm-865", 18 }, // 865
  { "ibm-866", 19 }, // 866
  { "ibm-869", 20 }, // 869
  { "ibm00858", 12 }, // 858
  { "ibm437", 1 }, // 437
  { "ibm737", 6 }, // 737
  { "ibm775", 7 }, // 775
  { "ibm850", 8 }, // 850
  { "ibm852", 9 }, // 852
  { "ibm855", 10 }, // 855
  { "ibm857", 11 }, // 857
  { "ibm860", 13 }, // 860
  { "ibm861", 14 }, // 861
  { "ibm863", 16 }, // 863
  { "ibm864", 17 }, // 864
  { "ibm865", 18 }, // 865
  { "ibm866", 19 }, // 866
  { "ibm869", 20 }, // 869
  { "iso-2022-jp", 84 }, // 50222
  { "iso-2022-kr", 85 }, // 50225
  { "iso-8859-1", 70 }, // 28591
  { "iso-8859-13", 79 }, // 28603
  { "iso-8859-15", 80 }, // 28605
  { "iso-8859-2", 71 }, // 28592
  { "iso-8859-3", 72 }, // 28593
  { "iso-8859-4", 73 }, // 28594
  { "iso-8859-5", 74 }, // 28595
  { "iso-8859-6", 75 }, // 28596
  { "iso-8859-7", 76 }, // 28597
  { "iso-8859-8", 77 }, // 28598
  { "iso-8859-8-i", 82 }, // 38598
  { "iso-8859-9", 78 }, // 28599
  { "koi8-r", 66 }, // 20866
  { "koi8-u", 69 }, // 21866
  { "ks-c-5601-1987", 24 }, // 949
  { "ks_c_5601-1987", 24 }, // 949
  { "macintosh", 37 }, // 10000
  { "shift-jis", 22 }, // 932
  { "shift_jis", 22 }, // 932
  { "translit", 0 }, // 3
  { "transliteration", 0 }, // 3
  { "unicodeFEFF", 26 }, // 1200
  { "unicodeFFFE", 27 }, // 1201
  { "us-ascii", 63 }, // 20127
  { "utf-16", 26 }, // 1200
  { "utf-16(be)", 27 }, // 1201
  { "utf-16(le)", 26 }, // 1200
  { "utf-16be", 27 }, // 1201
  { "utf-16le", 26 }, // 1200
  { "utf-7", 103 }, // 65000
  { "utf-8", 104 }, // 65001
  { "windows-1250", 28 }, // 1250
  { "windows-1251", 29 }, // 1251
  { "windows-1252", 30 }, // 1252
  { "windows-1253", 31 }, // 1253
  { "windows-1254", 32 }, // 1254
  { "windows-1255", 33 }, // 1255
  { "windows-1256", 34 }, // 1256
  { "windows-1257", 35 }, // 1257
  { "windows-1258", 36 }, // 1258
  { "windows-874", 21 }, // 874
  { "windows1250", 28 }, // 1250
  { "windows1251", 29 }, // 1251
  { "windows1252", 30 }, // 1252
  { "windows1253", 31 }, // 1253
  { "windows1254", 32 }, // 1254
  { "windows1255", 33 }, // 1255
  { "windows1256", 34 }, // 1256
  { "windows1257", 35 }, // 1257
  { "windows1258", 36 }, // 1258
  { "x-chinese-cns", 53 }, // 20000
  { "x-chinese-eten", 55 }, // 20002
  { "x-chinese_cns", 53 }, // 20000
  { "x-cp20001", 54 }, // 20001
  { "x-cp20003", 56 }, // 20003
  { "x-cp20004", 57 }, // 20004
  { "x-cp20005", 58 }, // 20005
  { "x-cp20261", 64 }, // 20261
  { "x-cp20269", 65 }, // 20269
  { "x-cp20936", 67 }, // 20936
  { "x-cp20949", 68 }, // 20949
  { "x-cp50227", 86 }, // 50227
  { "x-cp50229", 87 }, // 50229
  { "x-europa", 81 }, // 29001
  { "x-ia5", 59 }, // 20105
  { "x-ia5-german", 60 }, // 20106
  { "x-ia5-norwegian", 62 }, // 20108
  { "x-ia5-swedish", 61 }, // 20107
  { "x-iscii-as", 97 }, // 57006
  { "x-iscii-be", 94 }, // 57003
  { "x-iscii-de", 93 }, // 57002
  { "x-iscii-gu", 101 }, // 57010
  { "x-iscii-ka", 99 }, // 57008
  { "x-iscii-ma", 100 }, // 57009
  { "x-iscii-or", 98 }, // 57007
  { "x-iscii-pa", 102 }, // 57011
  { "x-iscii-ta", 95 }, // 57004
  { "x-iscii-te", 96 }, // 57005
  { "x-mac-arabic", 41 }, // 10004
  { "x-mac-ce", 49 }, // 10029
  { "x-mac-chinesesimp", 45 }, // 10008
  { "x-mac-chinesetrad", 39 }, // 10002
  { "x-mac-croatian", 52 }, // 10082
  { "x-mac-cyrillic", 44 }, // 10007
  { "x-mac-greek", 43 }, // 10006
  { "x-mac-hebrew", 42 }, // 10005
  { "x-mac-icelandic", 50 }, // 10079
  { "x-mac-japanese", 38 }, // 10001
  { "x-mac-korean", 40 }, // 10003
  { "x-mac-romanian", 46 }, // 10010
  { "x-mac-thai", 48 }, // 10021
  { "x-mac-turkish", 51 }, // 10081
  { "x-mac-ukrainian", 47 }, // 10017
  { "x_chinese-eten", 55 } // 20002
};

static
const char* encCanonicalNames[107] = {
  "arabic", // 0
  "asmo-449", // 1
  "asmo-708", // 2
  "big5", // 3
  "Windows-1250", // 4
  "Windows-1251", // 5
  "Windows-1252", // 6
  "Windows-1253", // 7
  "Windows-1254", // 8
  "Windows-1255", // 9
  "Windows-1256", // 10
  "Windows-1257", // 11
  "Windows-1258", // 12
  "cp737", // 13
  "cp775", // 14
  "cp850", // 15
  "cp852", // 16
  "cp855", // 17
  "cp857", // 18
  "cp860", // 19
  "cp861", // 20
  "cp863", // 21
  "cp864", // 22
  "cp865", // 23
  "cp866", // 24
  "cp869", // 25
  "csiso2022jp", // 26
  "dos-720", // 27
  "dos-862", // 28
  "euc", // 29
  "euc-cn", // 30
  "euc-jp", // 31
  "euc-kr", // 32
  "gb2312", // 33
  "hz-gb-2312", // 34
  "ibm-437", // 35
  "ibm00858", // 36
  "ibm437", // 37
  "iso-2022-jp", // 38
  "iso-2022-kr", // 39
  "iso-8859-1", // 40
  "iso-8859-13", // 41
  "iso-8859-15", // 42
  "iso-8859-2", // 43
  "iso-8859-3", // 44
  "iso-8859-4", // 45
  "iso-8859-5", // 46
  "iso-8859-6", // 47
  "iso-8859-7", // 48
  "iso-8859-8", // 49
  "iso-8859-8-i", // 50
  "iso-8859-9", // 51
  "koi8-r", // 52
  "koi8-u", // 53
  "ks-c-5601-1987", // 54
  "macintosh", // 55
  "shift-jis", // 56
  "translit", // 57
  "utf-16", // 58
  "utf-16be", // 59
  "us-ascii", // 60
  "utf-7", // 61
  "utf-8", // 62
  "windows-874", // 63
  "x-chinese-cns", // 64
  "x-chinese-eten", // 65
  "x-chinese_cns", // 66
  "x-cp20001", // 67
  "x-cp20003", // 68
  "x-cp20004", // 69
  "x-cp20005", // 70
  "x-cp20261", // 71
  "x-cp20269", // 72
  "x-cp20936", // 73
  "x-cp20949", // 74
  "x-cp50227", // 75
  "x-cp50229", // 76
  "x-europa", // 77
  "x-ia5", // 78
  "x-ia5-german", // 79
  "x-ia5-norwegian", // 80
  "x-ia5-swedish", // 81
  "x-iscii-as", // 82
  "x-iscii-be", // 83
  "x-iscii-de", // 84
  "x-iscii-gu", // 85
  "x-iscii-ka", // 86
  "x-iscii-ma", // 87
  "x-iscii-or", // 88
  "x-iscii-pa", // 89
  "x-iscii-ta", // 90
  "x-iscii-te", // 91
  "x-mac-arabic", // 92
  "x-mac-ce", // 93
  "x-mac-chinesesimp", // 94
  "x-mac-chinesetrad", // 95
  "x-mac-croatian", // 96
  "x-mac-cyrillic", // 97
  "x-mac-greek", // 98
  "x-mac-hebrew", // 99
  "x-mac-icelandic", // 100
  "x-mac-japanese", // 101
  "x-mac-korean", // 102
  "x-mac-romanian", // 103
  "x-mac-thai", // 104
  "x-mac-turkish", // 105
  "x-mac-ukrainian" // 106
};

static
wchar_t encTranslitChars[138] = {
  0xA5, // 0 "Y"
  0xA6, // 1 "|"
  0xA7, // 2 "$"
  0xA8, // 3 ":"
  0xA9, // 4 "(c)"
  0xAB, // 5 "\""
  0xAC, // 6 "!"
  0xAD, // 7 "shy"
  0xAE, // 8 "(R)"
  0xB0, // 9 "deg"
  0xB1, // 10 "+-"
  0xB2, // 11 "^2"
  0xB3, // 12 "^3"
  0xB4, // 13 "`"
  0xB5, // 14 "u"
  0xB6, // 15 "$"
  0xB7, // 16 "."
  0xB8, // 17 ","
  0xB9, // 18 "^1"
  0xBB, // 19 "\""
  0xBC, // 20 "1/4"
  0xBD, // 21 "1/2"
  0xBE, // 22 "3/4"
  0xBF, // 23 "?"
  0xC1, // 24 "A"
  0xC4, // 25 "A"
  0xC7, // 26 "C"
  0xC9, // 27 "E"
  0xCD, // 28 "I"
  0xD1, // 29 "N"
  0xD3, // 30 "O"
  0xD6, // 31 "O"
  0xDA, // 32 "U"
  0xDC, // 33 "U"
  0xE1, // 34 "a"
  0xE4, // 35 "a"
  0xE7, // 36 "c"
  0xE9, // 37 "e"
  0xED, // 38 "i"
  0xF1, // 39 "n"
  0xF3, // 40 "o"
  0xF6, // 41 "o"
  0xFA, // 42 "u"
  0xFC, // 43 "u"
  0x02C6, // 44 "o"
  0x02DC, // 45 "~"
  0x0401, // 46 "E"
  0x0403, // 47 "G"
  0x0404, // 48 "Je"
  0x0406, // 49 "I"
  0x0407, // 50 "Ji"
  0x0410, // 51 "A"
  0x0411, // 52 "B"
  0x0412, // 53 "V"
  0x0413, // 54 "G"
  0x0414, // 55 "D"
  0x0415, // 56 "E"
  0x0416, // 57 "Zh"
  0x0417, // 58 "Z"
  0x0418, // 59 "I"
  0x0419, // 60 "Y"
  0x041A, // 61 "K"
  0x041B, // 62 "L"
  0x041C, // 63 "M"
  0x041D, // 64 "N"
  0x041E, // 65 "O"
  0x041F, // 66 "P"
  0x0420, // 67 "R"
  0x0421, // 68 "S"
  0x0422, // 69 "T"
  0x0423, // 70 "U"
  0x0424, // 71 "F"
  0x0425, // 72 "Kh"
  0x0426, // 73 "Ts"
  0x0427, // 74 "Ch"
  0x0428, // 75 "Sh"
  0x0429, // 76 "Shch"
  0x042A, // 77 "\'"
  0x042B, // 78 "Y"
  0x042C, // 79 "\'"
  0x042D, // 80 "E"
  0x042E, // 81 "Ju"
  0x042F, // 82 "Ja"
  0x0430, // 83 "a"
  0x0431, // 84 "b"
  0x0432, // 85 "v"
  0x0433, // 86 "g"
  0x0434, // 87 "d"
  0x0435, // 88 "e"
  0x0436, // 89 "zh"
  0x0437, // 90 "z"
  0x0438, // 91 "i"
  0x0439, // 92 "y"
  0x043A, // 93 "k"
  0x043B, // 94 "l"
  0x043C, // 95 "m"
  0x043D, // 96 "n"
  0x043E, // 97 "o"
  0x043F, // 98 "p"
  0x0440, // 99 "r"
  0x0441, // 100 "s"
  0x0442, // 101 "t"
  0x0443, // 102 "u"
  0x0444, // 103 "f"
  0x0445, // 104 "kh"
  0x0446, // 105 "ts"
  0x0447, // 106 "ch"
  0x0448, // 107 "sh"
  0x0449, // 108 "shch"
  0x044A, // 109 "\'"
  0x044B, // 110 "y"
  0x044C, // 111 "\'"
  0x044D, // 112 "e"
  0x044E, // 113 "ju"
  0x044F, // 114 "ja"
  0x0451, // 115 "e"
  0x0453, // 116 "g"
  0x0454, // 117 "je"
  0x0456, // 118 "i"
  0x0457, // 119 "ji"
  0x2002, // 120 " "
  0x2003, // 121 " "
  0x2009, // 122 " "
  0x2013, // 123 "-"
  0x2014, // 124 "-"
  0x2018, // 125 "\'"
  0x2019, // 126 "\'"
  0x201A, // 127 ","
  0x201C, // 128 "\""
  0x201D, // 129 "\""
  0x201E, // 130 ",,"
  0x2030, // 131 "permil"
  0x2039, // 132 "\""
  0x203A, // 133 "\""
  0x20AC, // 134 "E"
  0x2122, // 135 "(tm)"
  0x2264, // 136 "<="
  0x2265 // 137 ">="
};

static
const char* encTranslitSubsts[138] = {
  "Y", // 0 (0xA5)
  "|", // 1 (0xA6)
  "$", // 2 (0xA7)
  ":", // 3 (0xA8)
  "(c)", // 4 (0xA9)
  "\"", // 5 (0xAB)
  "!", // 6 (0xAC)
  "shy", // 7 (0xAD)
  "(R)", // 8 (0xAE)
  "deg", // 9 (0xB0)
  "+-", // 10 (0xB1)
  "^2", // 11 (0xB2)
  "^3", // 12 (0xB3)
  "`", // 13 (0xB4)
  "u", // 14 (0xB5)
  "$", // 15 (0xB6)
  ".", // 16 (0xB7)
  ",", // 17 (0xB8)
  "^1", // 18 (0xB9)
  "\"", // 19 (0xBB)
  "1/4", // 20 (0xBC)
  "1/2", // 21 (0xBD)
  "3/4", // 22 (0xBE)
  "?", // 23 (0xBF)
  "A", // 24 (0xC1)
  "A", // 25 (0xC4)
  "C", // 26 (0xC7)
  "E", // 27 (0xC9)
  "I", // 28 (0xCD)
  "N", // 29 (0xD1)
  "O", // 30 (0xD3)
  "O", // 31 (0xD6)
  "U", // 32 (0xDA)
  "U", // 33 (0xDC)
  "a", // 34 (0xE1)
  "a", // 35 (0xE4)
  "c", // 36 (0xE7)
  "e", // 37 (0xE9)
  "i", // 38 (0xED)
  "n", // 39 (0xF1)
  "o", // 40 (0xF3)
  "o", // 41 (0xF6)
  "u", // 42 (0xFA)
  "u", // 43 (0xFC)
  "o", // 44 (0x02C6)
  "~", // 45 (0x02DC)
  "E", // 46 (0x0401)
  "G", // 47 (0x0403)
  "Je", // 48 (0x0404)
  "I", // 49 (0x0406)
  "Ji", // 50 (0x0407)
  "A", // 51 (0x0410)
  "B", // 52 (0x0411)
  "V", // 53 (0x0412)
  "G", // 54 (0x0413)
  "D", // 55 (0x0414)
  "E", // 56 (0x0415)
  "Zh", // 57 (0x0416)
  "Z", // 58 (0x0417)
  "I", // 59 (0x0418)
  "Y", // 60 (0x0419)
  "K", // 61 (0x041A)
  "L", // 62 (0x041B)
  "M", // 63 (0x041C)
  "N", // 64 (0x041D)
  "O", // 65 (0x041E)
  "P", // 66 (0x041F)
  "R", // 67 (0x0420)
  "S", // 68 (0x0421)
  "T", // 69 (0x0422)
  "U", // 70 (0x0423)
  "F", // 71 (0x0424)
  "Kh", // 72 (0x0425)
  "Ts", // 73 (0x0426)
  "Ch", // 74 (0x0427)
  "Sh", // 75 (0x0428)
  "Shch", // 76 (0x0429)
  "\'", // 77 (0x042A)
  "Y", // 78 (0x042B)
  "\'", // 79 (0x042C)
  "E", // 80 (0x042D)
  "Ju", // 81 (0x042E)
  "Ja", // 82 (0x042F)
  "a", // 83 (0x0430)
  "b", // 84 (0x0431)
  "v", // 85 (0x0432)
  "g", // 86 (0x0433)
  "d", // 87 (0x0434)
  "e", // 88 (0x0435)
  "zh", // 89 (0x0436)
  "z", // 90 (0x0437)
  "i", // 91 (0x0438)
  "y", // 92 (0x0439)
  "k", // 93 (0x043A)
  "l", // 94 (0x043B)
  "m", // 95 (0x043C)
  "n", // 96 (0x043D)
  "o", // 97 (0x043E)
  "p", // 98 (0x043F)
  "r", // 99 (0x0440)
  "s", // 100 (0x0441)
  "t", // 101 (0x0442)
  "u", // 102 (0x0443)
  "f", // 103 (0x0444)
  "kh", // 104 (0x0445)
  "ts", // 105 (0x0446)
  "ch", // 106 (0x0447)
  "sh", // 107 (0x0448)
  "shch", // 108 (0x0449)
  "\'", // 109 (0x044A)
  "y", // 110 (0x044B)
  "\'", // 111 (0x044C)
  "e", // 112 (0x044D)
  "ju", // 113 (0x044E)
  "ja", // 114 (0x044F)
  "e", // 115 (0x0451)
  "g", // 116 (0x0453)
  "je", // 117 (0x0454)
  "i", // 118 (0x0456)
  "ji", // 119 (0x0457)
  " ", // 120 (0x2002)
  " ", // 121 (0x2003)
  " ", // 122 (0x2009)
  "-", // 123 (0x2013)
  "-", // 124 (0x2014)
  "\'", // 125 (0x2018)
  "\'", // 126 (0x2019)
  ",", // 127 (0x201A)
  "\"", // 128 (0x201C)
  "\"", // 129 (0x201D)
  ",,", // 130 (0x201E)
  "permil", // 131 (0x2030)
  "\"", // 132 (0x2039)
  "\"", // 133 (0x203A)
  "E", // 134 (0x20AC)
  "(tm)", // 135 (0x2122)
  "<=", // 136 (0x2264)
  ">=" // 137 (0x2265)
};

