#ifndef DATETIMEHLP_H
#define DATETIMEHLP_H

#ifndef CLI_DATETIMETYPES_H
    #include <cli/dateTimeTypes.h>
#endif

#if defined(WIN32) || defined(_WIN32)

    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif

#else // Linux
    
    #if !defined(_INC_TIME) && !defined(_TIME_H_) && !defined(_TIME_H)
        #include <time.h>
    #endif

    #ifndef MARTY_UTF_H
        #include <marty/utf.h>
    #endif

#endif


#define DTF_PARTMASK          CLI_EDATETIMEFORMATFLAGS_PARTMASK
#define DTF_YEAR              CLI_EDATETIMEFORMATFLAGS_PYEAR
#define DTF_MONTH             CLI_EDATETIMEFORMATFLAGS_PMONTH
#define DTF_WDAY              CLI_EDATETIMEFORMATFLAGS_PDAYOFWEEK
#define DTF_MDAY              CLI_EDATETIMEFORMATFLAGS_PDAY
#define DTF_DAY               DTF_MDAY
#define DTF_HOUR              CLI_EDATETIMEFORMATFLAGS_PHOUR
#define DTF_MIN               CLI_EDATETIMEFORMATFLAGS_PMINUTE
#define DTF_SEC               CLI_EDATETIMEFORMATFLAGS_PSECOND
#define DTF_MICROSEC          CLI_EDATETIMEFORMATFLAGS_PMICROSEC
#define DTF_MSEC              CLI_EDATETIMEFORMATFLAGS_PMICROSEC
#define DTF_AP                CLI_EDATETIMEFORMATFLAGS_PAPINDICATOR
#define DTF_MASKNUMDIGITS     CLI_EDATETIMEFORMATFLAGS_MASKNUMDIGITS
#define DTF_ENG               CLI_EDATETIMEFORMATFLAGS_FENGLISH
#define DTF_ZEROS             CLI_EDATETIMEFORMATFLAGS_FLEADINGZERO
#define DTF_12H               CLI_EDATETIMEFORMATFLAGS_F12HOUR
#define DTF_GM                CLI_EDATETIMEFORMATFLAGS_PGMOFFSET
#define DTF_WEEK              CLI_EDATETIMEFORMATFLAGS_PWEEK

#define DTF_EWDAY             (DTF_WDAY|DTF_ENG)
#define DTF_EMDAY             (DTF_MDAY|DTF_ENG)
#define DTF_EMONTH            (DTF_MONTH|DTF_ENG)

#define DTF_HOUR12            (DTF_HOUR|DTF_12H)
#define DTF_UPCASE            (DTF_12H)
#define DTF_LOCAL             (DTF_12H)
#define DTF_APU               (DTF_AP|DTF_UPCASE)
#define DTF_GML               (DTF_GM|DTF_LOCAL)


#define DTF_IGNORE            CLI_EDATETIMEFORMATFLAGS_PSIGNIGNORE 
#define DTF_SIGNORE           CLI_EDATETIMEFORMATFLAGS_PSIGNIGNORESTRONG
#define DTF_DATESEP           CLI_EDATETIMEFORMATFLAGS_PSIGNDATESEP
#define DTF_TIMESEP           CLI_EDATETIMEFORMATFLAGS_PSIGNTIMESEP


#define DTF_SQ                CLI_EDATETIMEFORMATFLAGS_PSTARTQUOTE
#define DTF_EQ                CLI_EDATETIMEFORMATFLAGS_PENDQUOTE


#define DTF_SIGON             CLI_EDATETIMEFORMATFLAGS_PSIGNPLUS
#define DTF_SIGOFF            CLI_EDATETIMEFORMATFLAGS_PSIGNMINUS
#define DTF_SIGAUTO           0

// Degrees parser defines
#define DTF_DEGREE            DTF_DAY
#define DTF_DEG               DTF_DEGREE
#define DTF_MMIN              DTF_MONTH  /* microminutes */
#define DTF_MDEG              DTF_YEAR   /* microdegrees */


#define DTF_SIGN              0x00010000
#define DTF_LONG              0x00020000
#define DTF_LAT               0x00030000
#define DTF_DSTR              0x00040000
#define DTF_MSTR              0x00050000
#define DTF_SSTR              0x00060000





/*
DTF_MIN     
DTF_SEC     
DTF_MICROSEC
*/


namespace cli
{
namespace format
{
namespace impl
{

SIZE_T
CLICALL dateTimeFormaterImpl( WCHAR*    charBuf
                        , SIZE_T    charBufSize
                        , const WCHAR*    fmtStrChars
                        , SIZE_T    fmtStrCharsSize
                        , INTERFACE_CLI_IARGLIST*    arglist
                        , SIZE_T    argNo
                        );
SIZE_T
CLICALL timeFormaterImpl( WCHAR*    charBuf
                        , SIZE_T    charBufSize
                        , const WCHAR*    fmtStrChars
                        , SIZE_T    fmtStrCharsSize
                        , INTERFACE_CLI_IARGLIST*    arglist
                        , SIZE_T    argNo
                        );

SIZE_T
CLICALL degreeFormaterImpl( WCHAR*    charBuf
                        , SIZE_T    charBufSize
                        , const WCHAR*    fmtStrChars
                        , SIZE_T    fmtStrCharsSize
                        , INTERFACE_CLI_IARGLIST*    arglist
                        , SIZE_T    argNo
                        );


        #if defined(WIN32) || defined(_WIN32)
        
            inline
            ::std::wstring getLocaleDayOfWeekName( unsigned dayOfWeek, bool bShort )
               {
                if (dayOfWeek>6) dayOfWeek = 6;
                WCHAR buf[256];
                int bufSize = (int)(sizeof(buf)/sizeof(buf[0]));
                int res = GetLocaleInfoW( LOCALE_USER_DEFAULT, (bShort ? LOCALE_SABBREVDAYNAME1 : LOCALE_SDAYNAME1) + dayOfWeek, buf, bufSize );
                if (res>=bufSize) buf[bufSize-1] = 0;
                else              buf[res]       = 0;
                return ::std::wstring(buf);
               }
        
            inline
            ::std::wstring getLocaleMonthName( unsigned month, bool bShort )
               {
                if (month>11) month = 11;
                WCHAR buf[256];
                int bufSize = (int)(sizeof(buf)/sizeof(buf[0]));
                int res = GetLocaleInfoW( LOCALE_USER_DEFAULT, (bShort ? LOCALE_SABBREVMONTHNAME1 : LOCALE_SMONTHNAME1) + month, buf, bufSize );
                if (res>=bufSize) buf[bufSize-1] = 0;
                else              buf[res]       = 0;
                return ::std::wstring(buf);
               }

            inline
            ::std::wstring getLocaleDateSeparator( )
               {
                WCHAR buf[256];
                int bufSize = (int)(sizeof(buf)/sizeof(buf[0]));
                int res = GetLocaleInfoW( LOCALE_USER_DEFAULT, LOCALE_SDATE , buf, bufSize );
                if (res>=bufSize) buf[bufSize-1] = 0;
                else              buf[res]       = 0;
                return ::std::wstring(buf);
               }
        
            inline
            ::std::wstring getLocaleTimeSeparator( )
               {
                WCHAR buf[256];
                int bufSize = (int)(sizeof(buf)/sizeof(buf[0]));
                int res = GetLocaleInfoW( LOCALE_USER_DEFAULT, LOCALE_STIME , buf, bufSize );
                if (res>=bufSize) buf[bufSize-1] = 0;
                else              buf[res]       = 0;
                return ::std::wstring(buf);
               }
        
        
        #else // Linux
        
            inline
            ::std::wstring getLocaleDayOfWeekName( unsigned dayOfWeek, bool bShort )
               {
                if (dayOfWeek>6) dayOfWeek = 6;
                struct tm tmstruct;
                tmstruct.tm_wday = (dayOfWeek==6 ? 0 : dayOfWeek+1);
                char buf[256];
                size_t bufSize = sizeof(buf);
                size_t res = strftime( buf, bufSize, (bShort ? "%a" : "%A") , &tmstruct );
                if (res>=bufSize) buf[bufSize-1] = 0;
                else              buf[res]       = 0;
                return MARTY_UTF_NS fromUtf8(buf);
               }
        
            inline
            ::std::wstring getLocaleMonthName( unsigned month, bool bShort )
               {
                if (month>11) month = 11;
                struct tm tmstruct;
                tmstruct.tm_mon = month;
                char buf[256];
                size_t bufSize = sizeof(buf);
                size_t res = strftime( buf, bufSize, (bShort ? "%b" : "%B") , &tmstruct );
                if (res>=bufSize) buf[bufSize-1] = 0;
                else              buf[res]       = 0;
                return MARTY_UTF_NS fromUtf8(buf);
               }
        
            // I don't know how to get date/time separators from system under Linux, so I use default chars
            inline
            ::std::wstring getLocaleDateSeparator( )
               {
                return ::std::wstring(L"/");
               }

            inline
            ::std::wstring getLocaleTimeSeparator( )
               {
                return ::std::wstring(L"/");
               }

        #endif


}; // namespace impl
}; // namespace format
}; // namespace cli

#endif /* DATETIMEHLP_H */

