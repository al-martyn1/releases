struct CNoEntitiesEntityProcessing : public CEntityProcessingBase {

    static  wchar_t entityChars[2];
    static  unsigned charToEntity[2];
    static  const wchar_t *entities[2];
    static  wchar_t entityToChar[2];


    const wchar_t* getEntitiesCharString() const
       {
        return &entityChars[0];
       }


    // convert entiry name to char
    bool convertEntityToChar( const std::wstring &entityName, std::wstring &val ) const
       {
        const wchar_t ** pBegin = &entities[0];
        const wchar_t ** pEnd   = pBegin + 1;
        const wchar_t **pFoundEntityName = (const wchar_t **)util::binary_find( pBegin, pEnd, entityName.c_str(), wstringLess );
        if (pFoundEntityName!=pEnd)
           {
            SIZE_T entityIdx = pFoundEntityName - &entities[0];
            val.assign(1,entityToChar[entityIdx]);
            return true;
           }
        return false;
       }


    // convert entiry char to entity name
    bool convertCharToEntity( wchar_t ch, std::wstring &entityNameAppendTo ) const
       {
        const wchar_t* pEntityChar = util::binary_find( entityChars, entityChars+1, ch );
        if (pEntityChar!=(entityChars+1))
           {
            SIZE_T charIdx = (pEntityChar - entityChars);
            SIZE_T entityIdx = charToEntity[charIdx];
            entityNameAppendTo.append(entities[entityIdx]);
            return true;
           }
        return false;
       }


}; // struct CNoEntitiesEntityProcessing

wchar_t CNoEntitiesEntityProcessing::entityChars[2] = {
  0x1F, // 0  (#x1F)
  0
};

unsigned CNoEntitiesEntityProcessing::charToEntity[2] = {
  0, // 0  (#x1F)
  0xFA
};

const wchar_t* CNoEntitiesEntityProcessing::entities[2] = {
  L"#x1F", // 0 (0x1F)
  L"END"
};

wchar_t CNoEntitiesEntityProcessing::entityToChar[2] = {
  0x1F, // 0 (#x1F)
  0xFA
};

