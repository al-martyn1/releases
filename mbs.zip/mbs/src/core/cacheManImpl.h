#ifndef SRC_CORE_CACHEMANIMPL_H
#define SRC_CORE_CACHEMANIMPL_H

/* add this lines to your scr
#ifndef SRC_CORE_CACHEMANIMPL_H
    #include "src/core/cacheManImpl.h"
#endif
*/

#ifndef CLI_ICACHEMAN_H
    #include <cli/icacheman.h>
#endif

#include <sstream>

#include "cli2init.h"


namespace cli
{
namespace impl
{


using MARTY_FILESYSTEM_NS      getCurrentDirectory;
using MARTY_FILESYSTEM_NS      findFiles;
using MARTY_FILESYSTEM_NS      CFindFileInfo;
using MARTY_FILESYSTEM_NS      efIsDir;
using MARTY_FILESYSTEM_NS      openFile;
using MARTY_FILESYSTEM_NS      closeFile;
using MARTY_FILESYSTEM_NS      writeFile;

using MARTY_FILENAME_NS        makeFullPath;
using MARTY_FILENAME_NS        getPath;
using MARTY_FILENAME_NS        getFile;
using MARTY_FILENAME_NS        appendPath;
using MARTY_FILENAME_NS        appendExtention;

using MARTY_FILENAME_NS        makeCanonical;
using MARTY_LIBAPI_NS          CModuleHandle;

using MARTY_CON_NS             str2con;
using MARTY_CON_NS             con2str;
using MARTY_CON_NS             arg2str;

typedef MARTY_LIBAPI_NS tstring string;


#if defined(WIN32) || defined(_WIN32)
    static const char * CRLF = "\r\n";
#else
    static const char * CRLF = "\n";
#endif


struct CComponentCacheManagerImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_ICOMPONENTCACHEMANAGER
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CComponentCacheManagerImpl() : base_impl(DEF_MODULE) // , objList(), cs()
       {
       }

    ~CComponentCacheManagerImpl()
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
        #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CComponentCacheManagerImpl, INTERFACE_CLI_ICOMPONENTCACHEMANAGER)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICOMPONENTCACHEMANAGER )
    CLI_END_INTERFACE_MAP(CComponentCacheManagerImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


    /* interface ::cli::iComponentCacheManager methods */
    CLIMETHOD(getExecutableName) (THIS_ CLISTR*           _exeName)
       {
        CLI_TRY{
                ::std::wstring exeName;
                int getModNameRes = MARTY_LIBAPI_NS getModuleFileName(0, exeName);
                if (getModNameRes) return getModNameRes;
                return ::cli::propertyGetImpl(_exeName, exeName );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getExecutablePath) (THIS_ CLISTR*           _exePath)
       {
        CLI_TRY{
                ::std::wstring exeName;
                int getModNameRes = MARTY_LIBAPI_NS getModuleFileName(0, exeName);
                if (getModNameRes) return getModNameRes;
                using MARTY_FILENAME_NS     getPath;
                //return getPath(p);
                return ::cli::propertyGetImpl(_exePath, getPath(exeName) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(isCliComponentsModule) (THIS_ const CLISTR*     modNamePath
                                          , BOOL*    fIsModule /* [out] bool fIsModule  */
                                     )
       {
        CLI_TRY{
                if (!modNamePath && !fIsModule) return EC_INVALID_PARAM;
                try{
                    //std::w
                    string curDir;// = 
                    getCurrentDirectory(curDir);
                    //std::w
                    string modFullName = makeCanonical(makeFullPath(curDir, MARTY_CON::toTstr(stdstr(modNamePath)) ));
                    CModuleHandle modHandle /*  = CModuleHandle */ (modFullName.c_str());
                    cliEnumModuleComponentsProcT enumProc = reinterpret_cast<cliEnumModuleComponentsProcT>(modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME));
                    //cliEnumModuleComponentsProcT proc = (cliEnumModuleComponentsProcT)modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME);
                    if (!enumProc)
                        *fIsModule = FALSE;
                    else
                        *fIsModule = TRUE;
                   }
                catch(...)
                   {
                    *fIsModule = FALSE;
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    bool createCacheStrForModuleImpl( const std::wstring &modNamePath, bool addModuleInfo, std::string &strCache)
       {
        //std::w
        string curDir;// = 
        getCurrentDirectory(curDir);
        //std::w
        string modFullName = makeCanonical(makeFullPath(curDir, MARTY_CON::toTstr(stdstr(modNamePath)) ));
        CModuleHandle modHandle /*  = CModuleHandle */ (modFullName.c_str());
        cliEnumModuleComponentsProcT enumProc = reinterpret_cast<cliEnumModuleComponentsProcT>(modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME));
        if (!enumProc) return false;

        std::stringstream oss;
        //std::stringstream ess;

        //if (addModuleInfo) oss<<"Module:"<<MARTY_CON::strToAnsi(modFullName)<<CRLF;

        unsigned idx = 0;
        CCliComponentInfo ci = { 0, 0, 0 };
        while(enumProc(idx++, &ci))
           {
            if (!ci.name)
               {
                //ess<<"empty component name\n";
                continue;
               }

            //if (addModuleInfo) oss<<"Module:"<<MARTY_CON::strToAnsi(modFullName)<<CRLF;
            if (addModuleInfo) oss<<"Module:"<<MARTY_UTF::toUtf8(MARTY_CON::strToWide(modFullName))<<CRLF;
            //info.moduleName = MARTY_UTF_NS fromUtf8(trim_copy(::std::string(line, strModule.size())));

            oss<<"Component: "<<ci.name<< CRLF;

            if (ci.categories)
               oss<<"Categories: "<<ci.categories<< CRLF;

            if (ci.description)
               {
                ::std::string description = ci.description;
                ::std::map< ::std::string, ::std::string> md;
                ::cli::util::splitStringToMap(md, description, ::cli::util::CIsExactChar<char,';'>(), ::cli::util::CIsExactChar<char, ':'>());
                if (md.size())
                   {
                    oss<<"Description:"<<CRLF;
                    ::std::map< ::std::string, ::std::string>::const_iterator it = md.begin();
                    for(; it!=md.end(); ++it)
                       {
                        if (it->first.empty()) oss<<"en:"<<it->second<<CRLF;
                        else                   oss<<it->first<<":"<<it->second<<CRLF;
                       }
                   }
               }
            oss<<"."<< CRLF;
           }
        // EC_NOT_CLI_MODULE
        strCache = oss.str();
        return true;
       }

    CLIMETHOD(createCacheStrForModule) (THIS_ const CLISTR*     modNamePath
                                            , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                            , CLICSTR*          _strCache
                                       )
       {
        CLI_TRY{
                if (!modNamePath) return EC_INVALID_PARAM;
                if (!_strCache) return EC_INVALID_OUT_PTR;
                std::string strCache;
                if (!createCacheStrForModuleImpl( stdstr(modNamePath), addModuleInfo ? true : false, strCache ))
                   return EC_NOT_CLI_MODULE;
                return ::cli::propertyGetImpl(_strCache, strCache );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getCacheFilename) (THIS_ const CLISTR*     modNamePath
                                     , CLISTR*           _modCacheName
                                )
       {
        CLI_TRY{
                //string modFullName = makeCanonical(makeFullPath(getCurrentDirectory(), stdstr(modNamePath) ));
                if (!modNamePath) return EC_INVALID_PARAM;
                if (!_modCacheName) return EC_INVALID_OUT_PTR;
                std::wstring curDir;// = 
                getCurrentDirectory(curDir);
                std::wstring modFullName = makeCanonical(makeFullPath(curDir, stdstr(modNamePath) ));
                std::wstring modCacheName = appendExtention(modFullName, MARTY_CON::strToWide(CLI_MODULE_INFO_CACHE_SUFFIX));
                return ::cli::propertyGetImpl(_modCacheName, modCacheName );
                //stdstr(nodeTagName)
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    RCODE createCacheForModuleImpl( const std::wstring &modNamePath, BOOL addModuleInfo )
       {
        std::string strCache;
        if (!createCacheStrForModuleImpl( modNamePath, addModuleInfo ? true : false, strCache ))
           return EC_NOT_CLI_MODULE;
        //return ::cli::propertyGetImpl(_strCache, strCache );

        std::wstring curDir;// = 
        getCurrentDirectory(curDir);
        std::wstring modFullName = makeCanonical(makeFullPath(curDir, modNamePath ));
        std::wstring modCacheName = appendExtention(modFullName, MARTY_CON::strToWide(CLI_MODULE_INFO_CACHE_SUFFIX));

        //EC_NO_SUCH_FILE
        if (strCache.size())
           {
            MARTY_FILESYSTEM_NS handle_t hFile = openFile(modCacheName, MARTY_FILESYSTEM_NS o_creat | MARTY_FILESYSTEM_NS o_wronly | MARTY_FILESYSTEM_NS  o_trunc, false);
            if (MARTY_FILESYSTEM_NS hInvalidHandle == hFile)
               {
                //std::cout<<"Failed to create file "<<str2con(cacheFullName)<<"\n";
                //std::cerr<<"Failed to create file "<<cacheFullName<<"\n";
                return EC_NO_SUCH_FILE;
               }
            else
               {
                int wrRes = writeFile(hFile, (const void*)strCache.c_str(), (unsigned)strCache.size());
                if (wrRes<0)
                   {
                    return EC_IOSTREAM_IO_ERROR;
                    //std::cout<<"Failed to write, error: "<<errno<<strerror(errno)<<"\n";
                    //std::cerr<<"Failed to write, error: "<<errno<<strerror(errno)<<"\n";
                   }
                closeFile(hFile);
               }
           }
        return EC_OK;
       }

    CLIMETHOD(createCacheForModule) (THIS_ const CLISTR*     modNamePath
                                         , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                    )
       {
        CLI_TRY{
                if (!modNamePath) return EC_INVALID_PARAM;
                //if (!_strCache) return EC_INVALID_OUT_PTR;
                return createCacheForModuleImpl( stdstr(modNamePath), addModuleInfo );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createCacheForModuleMask) (THIS_ const CLISTR*     _modNamePathMask
                                             , BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                             , BOOL    recurseSubdirs
                                        )
       {
        CLI_TRY{
                if (!_modNamePathMask) return EC_INVALID_PARAM;
                std::wstring modNamePathMask = stdstr(_modNamePathMask);
                std::vector< CFindFileInfo< std::wstring::value_type > > matches;
                //std::cout<<"CP1\n";
                int res = findFiles(matches, getPath(modNamePathMask), getFile(modNamePathMask), recurseSubdirs ? true : false, false  /* dont force compare full path */ );
                //std::cout<<"CP2\n";
                if (res)
                   {
                    //std::cout<<"Error: can't find files with '"<<str2con(mask)<<"' mask - system error "<<res<<"\n";
                    //std::cerr<<"Error: can't find files with '"<<mask<<"' mask - system error "<<res<<"\n";
                   }
                //std::cout<<"CP3\n";
                std::vector< CFindFileInfo< std::wstring::value_type > >::const_iterator it = matches.begin();
                //std::cout<<"CP3\n";
                for(; it!=matches.end(); ++it)
                   {
                    //std::cout<<"CP5\n";
                    if (efIsDir(it->attrs)) continue;
                    createCacheForModuleImpl(appendPath(it->path, it->file), addModuleInfo);
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    bool isFilenameExcludedByMask( const string &fullFilename
                                 , const ::std::vector<string> &excludeFilesMasks
                                 )
       {
        string filename = MARTY_FILENAME::getFile(fullFilename);
    
        ::std::vector<string>::const_iterator maskIt = excludeFilesMasks.begin();
        for(; maskIt != excludeFilesMasks.end(); ++maskIt)
           {
            #if defined(WIN32) || defined(_WIN32)
            if (MARTY_FILENAME::matchMaskI( filename, *maskIt ) )
            #else
            if (MARTY_FILENAME::matchMaskE( filename, *maskIt ) )
            #endif
               {
                return true; // excluded, no further processing needed
               }
           }
        return false;
       }


    CLIMETHOD(createCacheForModules) (THIS_ BOOL    addModuleInfo /* [in] bool  addModuleInfo  */
                                          , BOOL    recurseSubdirs /* [in] bool  recurseSubdirs  */
                                     )
       {
        CLI_TRY{
                ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
                //::std::vector< string > tmpStrVec;
                ::std::vector< string > masks;

                ::std::vector< string > extList           = pOpts ? pOpts->extList                : ::std::vector< string >();
                ::std::vector< string > path              = pOpts ? pOpts->modPath                : ::std::vector< string >();
                ::std::vector< string > excludeModPath    = pOpts ? pOpts->excludeModPath         : ::std::vector< string >();
                ::std::vector< string > excludeFilesMasks = pOpts ? pOpts->excludeModulesMaskList : ::std::vector< string >();

                ::std::vector< string >::const_iterator elIt = extList.begin();
                for(; elIt!=extList.end(); ++elIt)
                   {
                    string mask(_T("*"));
                    mask = MARTY_FILENAME_NS appendExtention(mask, *elIt);
                    //if (useCache)
                    //   mask = MARTY_FILENAME_NS appendExtention(mask, tstring(CLI_MODULE_INFO_CACHE_SUFFIX));
                    masks.push_back(mask);
                   }

                if (masks.empty()) masks.push_back( string(_T("*.dll")) );
                if (path.empty())  
                   {
                    //::std::w
                    string exeName;
                    if (!MARTY_LIBAPI_NS getModuleFileName(0, exeName))
                       {
                        path.push_back(getPath(exeName));
                       }
                   }

                std::vector<MARTY_FILESYSTEM_NS CFindFileInfo<TCHAR> > matchedFiles;
                //int findRes = 
                MARTY_FILESYSTEM::findFilesPathListEx( matchedFiles
                                                                   , path
                                                                   , excludeModPath // excludePathList
                                                                   , masks
                                                                   , true // recurseSubdirs - TODO - add an environment flag to control this option
                                                                   , false // forceCmpWithPath
                                                                   , true  // threat excludePathList as masks
                                                                   );
                std::vector<MARTY_FILESYSTEM_NS CFindFileInfo<TCHAR> >::const_iterator mfIt = matchedFiles.begin();
                for(; mfIt!=matchedFiles.end(); ++mfIt)
                   {
                    if (efIsDir(mfIt->attrs)) continue;
                    //std::wstring modName = MARTY_CON::strToWide(appendPath(mfIt->path, mfIt->file));
                    string modNameT = appendPath(mfIt->path, mfIt->file);

                    //SIZE_T maskId = 0;
                    if ( isFilenameExcludedByMask( modNameT, excludeFilesMasks /* , maskId excludedByMask */  ) )
                       {
                        //pOpts->log()<<"excluded by mask '"<< excludeFilesMasks[maskId]<<"'\n";
                        continue;
                       }

                    createCacheForModuleImpl(MARTY_CON::strToWide(modNameT), addModuleInfo);
                   }

               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


//       ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
//    loadModulesInformation(pOpts->modPath, pOpts->excludeModPath, pOpts->extList, pOpts->excludeModulesMaskList, false);
/*
            ::std::vector<tstring>                     modPath;
            ::std::vector<tstring>                     excludeModPath;
            ::std::vector<tstring>                     extList;
            ::std::vector<tstring>                     excludeModulesMaskList;

*/



#if 0
            ::std::vector<tstring>                     modPath;
            ::std::vector<tstring>                     excludeModPath;
            ::std::vector<tstring>                     extList;
            ::std::vector<tstring>                     excludeModulesMaskList;


    CLIMETHOD(pushObject) (THIS_ INTERFACE_CLI_IUNKNOWN*    pObj /* [in] ::cli::iUnknown*  pObj  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (pObj) 
                   {
                    objList.push_back(pObj);
                    pObj->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(insertObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */
                                 , INTERFACE_CLI_IUNKNOWN*    pObj /* [in] ::cli::iUnknown*  pObj  */
                            )
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (pos>=objList.size()) return pushObject(pObj);
                if (pObj) 
                   {
                    objList.insert( objList.begin() + pos, pObj );
                    pObj->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getObjectCount) (THIS_ SIZE_T*    s /* [out] size_t pos  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (s) *s = objList.size();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(objectCountGet) (THIS_ SIZE_T*    _objectCount /* [out] size_t _objectCount  */)
       {
        return getObjectCount(_objectCount);
       }       

    CLIMETHOD(getObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */
                              , INTERFACE_CLI_IUNKNOWN**    pObj /* [out] ::cli::iUnknown* pObj  */
                         )
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (pos>=objList.size()) 
                   {
                    if (pObj) *pObj = 0;
                    return EC_OUT_OF_RANGE;
                   }
                if (pObj)
                   {
                    *pObj = objList[pos];
                    (*pObj)->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(removeObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (pos>=objList.size()) return EC_OUT_OF_RANGE;
                INTERFACE_CLI_IUNKNOWN* pObj = objList[pos];
                if (pObj) pObj->release();
                objList.erase(objList.begin()+pos);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(clearList) (THIS)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                for(::std::vector< INTERFACE_CLI_IUNKNOWN* >::iterator it = objList.begin(); it!=objList.end(); ++it)
                   {
                    INTERFACE_CLI_IUNKNOWN* pObj = *it;
                    pObj->release();
                   }
                objList.clear();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(assignList) (THIS_ INTERFACE_CLI_IOBJECTLIST*    pObjList /* [in] ::cli::iObjectList*  pObjList  */)
       {
        clearList();
        appendList(pObjList);
        return EC_OK;
       }

    CLIMETHOD(appendList) (THIS_ INTERFACE_CLI_IOBJECTLIST*    pObjList /* [in] ::cli::iObjectList*  pObjList  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!pObjList) return EC_OK;
                SIZE_T i = 0;
                INTERFACE_CLI_IUNKNOWN* pObj = 0;
                while( !pObjList->getObject(i++,&pObj) && pObj)
                   {
                    objList.push_back(pObj);
                    pObj = 0;
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }
#endif

}; // struct CComponentCacheManagerImpl

}; // namespace impl
}; //namespace cli






#endif /* SRC_CORE_CACHEMANIMPL_H */

