#include "clialloc.h"


static BYTE     *staticAllocBuf = 0;
static BYTE     *staticAllocTop = 0;
static SIZE_T   staticAllocBufSize      = 0;
static SIZE_T   staticAllocMemAvailable = 0;

/*---------------------------------------------------------------------------*/
EXTERN_C void CLICALL cliInitStaticAlloc(BYTE *buf, SIZE_T bufSize)
   {
    staticAllocBuf = buf;
    staticAllocTop = buf;

    staticAllocBufSize      = bufSize;
    staticAllocMemAvailable = bufSize;
   }

/*---------------------------------------------------------------------------*/
EXTERN_C void* CLICALL cliStaticAlloc(SIZE_T nBytesToAlloc)
   {
    const SIZE_T granularity = 8;
    BYTE *res = staticAllocTop;
    if (!res) return res;

    nBytesToAlloc = (nBytesToAlloc/granularity + ((nBytesToAlloc%granularity) ? 1 : 0)) * granularity;
    if (staticAllocMemAvailable<nBytesToAlloc) return 0; // no memory

    staticAllocTop += nBytesToAlloc;
    staticAllocMemAvailable -= nBytesToAlloc;

    return (void*)res;
   }

/*---------------------------------------------------------------------------*/

#ifdef _WIN32

#include <windows.h>

/*---------------------------------------------------------------------------*/
EXTERN_C void* CLICALL cliAlloc(SIZE_T nBytesToAlloc)
   {
    return HeapAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, nBytesToAlloc);
   }

/*---------------------------------------------------------------------------*/
EXTERN_C void* CLICALL cliCalloc(SIZE_T nItemsToAlloc, SIZE_T itemSize)
   {
    return HeapAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, (SIZE_T)nItemsToAlloc*(SIZE_T)itemSize);
   }

/*---------------------------------------------------------------------------*/
EXTERN_C void CLICALL cliFree(void *pMem)
   {
    HeapFree( GetProcessHeap(), 0, pMem );
   }

EXTERN_C void* CLICALL cliRealloc(void *pMem, SIZE_T nBytesToAlloc)
   {
    return HeapReAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, pMem, nBytesToAlloc);
   }

EXTERN_C void* CLICALL cliRecalloc(void *pMem, SIZE_T nItemsToAlloc, SIZE_T itemSize)
   {
    return HeapReAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, pMem, (SIZE_T)nItemsToAlloc*(SIZE_T)itemSize);
   }

#else /* non Win32, using crt/posix functions */

#include <stdlib.h>
#include <malloc.h>

EXTERN_C void* CLICALL cliAlloc(SIZE_T nBytesToAlloc)
   {
    return malloc(nBytesToAlloc);
   }

EXTERN_C void* CLICALL cliCalloc(SIZE_T nItemsToAlloc, SIZE_T itemSize)
   {
    return calloc(nItemsToAlloc, itemSize);
   }

EXTERN_C void  CLICALL cliFree(void *pMem)
   {
    free(pMem);
   }

EXTERN_C void* CLICALL cliRealloc(void *pMem, SIZE_T nBytesToAlloc)
   {
    return realloc(pMem, nBytesToAlloc);
   }

EXTERN_C void* CLICALL cliRecalloc(void *pMem, SIZE_T nItemsToAlloc, SIZE_T itemSize)
   {
    return realloc(pMem, (size_t)nItemsToAlloc*(size_t)itemSize);
   }

#endif

