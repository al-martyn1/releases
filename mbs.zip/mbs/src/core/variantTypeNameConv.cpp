#define CLI_INTERNAL

#ifndef SRC_CORE_VARIANTTYPENAMECONV_H
    #include "variantTypeNameConv.h"
#endif

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif


CVariantTypeNameConverter::type_name_vector  CVariantTypeNameConverter::typeToName;
CVariantTypeNameConverter::name_type_vector  CVariantTypeNameConverter::nameToType;

static CVariantTypeNameConverter variantTypeNameConverter;

ENUM_CLI_VARIANTTYPE convertVariantTypeNameFromString( const ::std::wstring &_str )
   {
    return variantTypeNameConverter.convertFromString( _str );
   }

::std::wstring convertVariantTypeNameToString( ENUM_CLI_VARIANTTYPE clr, bool bUpper )
   {
    return variantTypeNameConverter.convertToString(clr, bUpper);
   }



