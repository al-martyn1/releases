#define CLI_INTERNAL

#include <cli/clialloc.h>
#include <cli/interlocked.h>

#ifndef CLI_REFCNT_H
    #include <cli/refcnt.h>
#endif


#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif

#if !defined(_INC_STRING) && !defined(__STRING_H_) && !defined(_STRING_H)
    #include <string.h>
#endif

#ifdef _WIN32
    #include <windows.h>
#else
    #include <cstdlib>
#endif


namespace cli
{

/*
#include <cli/pshpack8.h>
struct CCliAllocatorMemBlockIno
{
    UINT_PTR    orgPtr;
    SIZE_T      orgSize;
}
#include <cli/poppack.h>
*/

template < typename RefCnt , int initialHeapSizeInKb >
struct cliAllocatorImpl : public INTERFACE_CLI_IALLOCATOR
{
    RefCnt counter;

    #ifdef _WIN32
        HANDLE hHeap;
    #endif

    cliAllocatorImpl() : counter(1)
        #ifdef _WIN32
        , hHeap(0)
        #endif
       {
        #ifdef _WIN32
            hHeap = HeapCreate( HEAP_GENERATE_EXCEPTIONS
                              ,  initialHeapSizeInKb * 1024 // 16*4096 /* dwInitialSize */
                              , 0  /* dwMaximumSize, 0 - the heap is growable */
                              );
        #endif
       }

    ~cliAllocatorImpl()
       {
        #ifdef _WIN32
            HeapDestroy( hHeap );
        #endif
       }

    virtual void destroy() 
    { 
    #include <cli/compspec/delthis.h>
    }

// #define CLI_ERR_UNKNOWN                       0x80000000
// #define CLI_ERR_INVALID_OUT_PTR               0x80000001
// CLI_ERR_UNKNOWN_INTERFACE

    CLI_BEGIN_INTERFACE_MAP(cliAllocatorImpl)
        CLI_IMPLEMENT_INTERFACE(INTERFACE_CLI_IALLOCATOR)
    CLI_END_INTERFACE_MAP(cliAllocatorImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)
       {
        return (ilint_t)++counter;
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        if (! --counter) { destroy(); return 0; }
        return (ilint_t)counter;
       }
    
    /* interface ::cli::iAllocator methods */
    CLIMETHOD_(VOID*, allocate) (THIS_ SIZE_T    blockSize /* [in] size_t  blockSize  */
                                     , UINT    flags /* [in] uint  flags  */
                                     , BYTE    bFill /* [in] byte  bFill  */
                                )
       {
        /*
        DWORD alignFlagBit = CLI_ALLOCATOR_FLAG_ALIGN512;
        DWORD align        = 512;
        while(alignFlagBit && !(flags&alignFlagBit))
           {
            alignFlagBit >>= 1;
            align        >>= 1;
           }

        if (align<8) align = 8;

        blockSize += sizeof(UINT_PTR); // reserve some space
        */

        //SIZE_T nBytesToAlloc = (blockSize/align + 1) * align;
        SIZE_T nBytesToAlloc = blockSize;

        bool needFill = flags&CLI_ALLOCATOR_FLAG_FILL_MEMORY ? true : false;

        #ifdef _WIN32

            DWORD heapAllocFlags = 0;
            if (needFill && !bFill)
               {
                heapAllocFlags |= HEAP_ZERO_MEMORY;
                needFill = false; // filling perfomed by HeapAlloc, not needed to manually fill
               }

            UINT_PTR  /* uiPtrOrg */ uiPtr = (UINT_PTR)HeapAlloc(hHeap, heapAllocFlags, nBytesToAlloc);

        #else

            UINT_PTR  /* uiPtrOrg */ uiPtr = (UINT_PTR)::std::malloc(nBytesToAlloc);

        #endif

        /*
        UINT_PTR uiPtr = uiPtrOrg + sizeof(UINT_PTR); // reserve space to hold original pointer

        UINT_PTR adjustmentSize = align - uiPtr%align;
        uiPtr += adjustmentSize;

        // adjustmentSize not greater than 512 (max 4096)

        if (uiPtr%align)
           { // make pointer aligned
            uiPtr += (align - uiPtr%align);
           }
        */

        if (needFill)
           {
            //memset((void*)uiPtr, bFill, (uiPtr/align)*align);
            memset((void*)uiPtr, bFill, blockSize);
           }

        return (VOID*)uiPtr;
       }

    CLIMETHOD_(VOID*, reallocate) (THIS_ const VOID*    pMem /* [in] void*  pMem  */
                                       , SIZE_T    newBlockSize /* [in] size_t  newBlockSize  */
                                       , UINT    flags /* [in] uint  flags  */
                                       , BYTE    bFill /* [in] byte  bFill  */
                                  )
       {
        // bFill used only if zero

        //bool needFill = flags&CLI_ALLOCATOR_FLAG_FILL_MEMORY ? true : false;

        #ifdef _WIN32

            bool needFill = flags&CLI_ALLOCATOR_FLAG_FILL_MEMORY ? true : false;

            DWORD heapAllocFlags = 0;
            if (needFill && !bFill)
               {
                heapAllocFlags |= HEAP_ZERO_MEMORY;
                needFill = false; // filling perfomed by HeapAlloc, not needed to manually fill
               }

            UINT_PTR  /* uiPtrOrg */ uiPtr = pMem 
                                           ? (UINT_PTR)HeapReAlloc(hHeap, heapAllocFlags, (LPVOID)pMem, newBlockSize)
                                           : (UINT_PTR)HeapAlloc  (hHeap, heapAllocFlags, newBlockSize);

        #else

            UINT_PTR  /* uiPtrOrg */ uiPtr = (UINT_PTR)::std::realloc((void*)pMem, newBlockSize);

        #endif

        /* Filling memory on realloc not implemented for generic platforms
        if (needFill)
           {
            //memset((void*)uiPtr, bFill, (uiPtr/align)*align);
            memset((void*)uiPtr, bFill, blockSize);
           }
        */
        return (VOID*)uiPtr;
       }

    CLIMETHOD(deallocate) (THIS_ const VOID*    pMem /* [in] void*  pMem  */)
       {
        #ifdef _WIN32

            HeapFree(hHeap, 0, (LPVOID)pMem);

        #else

            ::std::free((void*)pMem);

        #endif

        return CLI_OK;
       }


}; // cliAllocatorImpl


}; // namespace cli


CLIAPIENTRY
RCODE
CLICALL
cliCreateAllocator( INTERFACE_CLI_IALLOCATOR ** piAllocator )
   {
    if (!piAllocator) return CLI_ERR_INVALID_OUT_PTR;
    *piAllocator = static_cast<INTERFACE_CLI_IALLOCATOR*>( new ::cli::cliAllocatorImpl< ::cli::CRefCounter , 64  /* Kb */ >() );  /* CFakeRefCounter */ 
    return CLI_OK;
   }

CLIAPIENTRY
RCODE
CLICALL
cliCreateFastAllocator( INTERFACE_CLI_IALLOCATOR ** piAllocator )
   {
    if (!piAllocator) return CLI_ERR_INVALID_OUT_PTR;
    *piAllocator = static_cast<INTERFACE_CLI_IALLOCATOR*>( new ::cli::cliAllocatorImpl< ::cli::CRefCounter , 3  /* Kb */ >() );  /* CFakeRefCounter */ 
    return CLI_OK;
   }

static INTERFACE_CLI_IALLOCATOR *pStdAllocatorObject = 0;

namespace cli
{

void initStringHelpers();

void createStdAllocatorObject()
   {
    if (!pStdAllocatorObject)
       pStdAllocatorObject = static_cast<INTERFACE_CLI_IALLOCATOR*>( new ::cli::cliAllocatorImpl< ::cli::CFakeRefCounter , 1024 /* Kb */ >() );

    initStringHelpers();
   }

}; // namespace cli


CLIAPIENTRY
RCODE
CLICALL
cliGetAllocator( INTERFACE_CLI_IALLOCATOR ** piAllocator )
   {
    if (!piAllocator) return CLI_ERR_INVALID_OUT_PTR;
    *piAllocator = pStdAllocatorObject;
    return CLI_OK;
   }

