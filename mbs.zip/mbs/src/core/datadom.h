#ifndef SRC_CORE_DATADOM_H
#define SRC_CORE_DATADOM_H

/* add this lines to your src
#ifndef CORE_DATADOM_H
    #include "datadom.h"
#endif
*/

#if defined(CLI_BUILTIN_CLIPONENTS_DATADOM)
    #if defined(CLI_STANDALONE_CLIPONENTS_DATADOM)
        #undef CLI_STANDALONE_CLIPONENTS_DATADOM
    #endif
#else
    #if !defined(CLI_STANDALONE_CLIPONENTS_DATADOM)
        #define CLI_STANDALONE_CLIPONENTS_DATADOM
    #endif
#endif

#ifndef CLI_DATADOM_H
    #include <cli/datadom.h>
#endif

#ifndef CLI_IDATADOM_H
    #include <cli/idatadom.h>
#endif

#ifndef CLI_STRENC_H
    #include <cli/strenc.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#ifndef CLI_STANDALONE_CLIPONENTS_DATADOM
    #ifndef CLI_VARIANTIMPL_H
        #include "variantImpl.h"
    #endif
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef CLI_XML_SIXML_SIXMLHELPERS_H
    #include <cli/xml/sixml/sixmlHelpers.h>
#endif

#include <cli/xml/sixml/pugixml/pugixml.hpp>

#ifndef CLI_XML_SIXML_PUGIXML_HELPERS_H
    #include <cli/xml/sixml/pugixml/helpers.h>
#endif

#ifndef CLI_XML_SIXML_6MLEXCEP_H
    #include <cli\xml\sixml\6mlexcep.h>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif


#if !defined(_DEQUE_) && !defined(_STLP_DEQUE) && !defined(__STD_DEQUE__) && !defined(_CPP_DEQUE) && !defined(_GLIBCXX_DEQUE)
    #include <deque>
#endif

#if !defined(_QUEUE_) && !defined(_STLP_QUEUE) && !defined(__STD_QUEUE__) && !defined(_CPP_QUEUE) && !defined(_GLIBCXX_QUEUE)
    #include <queue>
#endif



#include "ddxpath.h"
//#include "util.h"

#include "strconvutil.h"


namespace cli
{
namespace impl
{

namespace boring_copypaste
{

/*
::cli::impl::boring_copypaste
int char2digit( TCHAR ch )
const char* parseIntegerSkipLeadingSpace(const TCHAR* pStr)
const TC* parseInteger( const TC* pStr, int base, int &intVal )
*/

inline
const char* parseIntegerSkipLeadingSpace(const char* pStr)
{
    while(*pStr==' ') ++pStr;
    return pStr;
}

inline
const wchar_t* parseIntegerSkipLeadingSpace(const wchar_t* pStr)
{
    while(*pStr==L' ') ++pStr;
    return pStr;
}

template <typename TC>
const TC* parseInteger( const TC* pStr, int base, int &intVal )
{
    intVal = 0;
    for(;*pStr; ++pStr)
       {
        int d = char2digit( *pStr );
        if (d<0) return pStr;
        if (d>=base) return pStr;
        intVal *= base;
        intVal += d;
       }
    return pStr;
}

}; // namespace boring_copypaste






// http://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references
//
/*
static
const std::map< wchar_t, std::wstring >* getCharToEntityMap()
{
    static std::map< wchar_t, std::wstring > charEntities;
    if (!charEntities.empty()) return &charEntities;

    charEntities[(wchar_t)0x00A0] = L"nbsp";
    charEntities[(wchar_t)0x00A1] = L"iexcl";
    charEntities[(wchar_t)0x00A2] = L"cent";
    charEntities[(wchar_t)0x00A3] = L"pound";
    charEntities[(wchar_t)0x00A4] = L"curren";
    charEntities[(wchar_t)0x00A5] = L"yen";
    charEntities[(wchar_t)0x00A6] = L"brvbar";
    charEntities[(wchar_t)0x00A7] = L"sect";
    charEntities[(wchar_t)0x00A8] = L"uml";
    charEntities[(wchar_t)0x00A9] = L"copy";
    charEntities[(wchar_t)0x00AB] = L"laquo";
    charEntities[(wchar_t)0x00AC] = L"not";
    charEntities[(wchar_t)0x00AD] = L"shy";
    charEntities[(wchar_t)0x00AE] = L"reg";
    charEntities[(wchar_t)0x00B0] = L"deg";
    charEntities[(wchar_t)0x00B1] = L"plusmn";
    charEntities[(wchar_t)0x00B2] = L"sup2";
    charEntities[(wchar_t)0x00B3] = L"sup3";
    charEntities[(wchar_t)0x00B4] = L"acute";
    charEntities[(wchar_t)0x00B5] = L"micro";
    charEntities[(wchar_t)0x00B6] = L"para";
    charEntities[(wchar_t)0x00B7] = L"middot";
    charEntities[(wchar_t)0x00B8] = L"cedil";
    charEntities[(wchar_t)0x00B9] = L"sup1";
    charEntities[(wchar_t)0x00BB] = L"raquo";
    charEntities[(wchar_t)0x00BC] = L"frac14";
    charEntities[(wchar_t)0x00BD] = L"frac12";
    charEntities[(wchar_t)0x00BE] = L"frac34";
    charEntities[(wchar_t)0x00BF] = L"iquest";

    charEntities[(wchar_t)0x02C6] = L"circ";
    charEntities[(wchar_t)0x02DC] = L"tilde";
    charEntities[(wchar_t)0x2002] = L"ensp";
    charEntities[(wchar_t)0x2003] = L"emsp";
    charEntities[(wchar_t)0x2009] = L"thinsp";
    charEntities[(wchar_t)0x2013] = L"ndash";
    charEntities[(wchar_t)0x2014] = L"mdash";
    charEntities[(wchar_t)0x2018] = L"lsquo";
    charEntities[(wchar_t)0x2019] = L"rsquo";
    charEntities[(wchar_t)0x201A] = L"sbquo";
    charEntities[(wchar_t)0x201C] = L"ldquo";
    charEntities[(wchar_t)0x201D] = L"rdquo";
    charEntities[(wchar_t)0x201E] = L"bdquo";
    charEntities[(wchar_t)0x2030] = L"permil";
    charEntities[(wchar_t)0x2039] = L"lsaquo";
    charEntities[(wchar_t)0x203A] = L"rsaquo";
    charEntities[(wchar_t)0x20AC] = L"euro";
    charEntities[(wchar_t)0x2122] = L"trade";
    charEntities[(wchar_t)0x2264] = L"le";
    charEntities[(wchar_t)0x2265] = L"ge";
    //charEntities[(wchar_t)0x2000] = L"";
    //charEntities[(wchar_t)0x0000] = L"";

    return &charEntities;
}

static
const std::map< std::wstring, wchar_t >* getEntityToCharMap()
{
    static std::map< std::wstring, wchar_t > entityChars;
    if (!entityChars.empty()) return &entityChars;

    const std::map< wchar_t, std::wstring > *pBaseMap = getCharToEntityMap();
    if (!pBaseMap) return &entityChars;

    const std::map< wchar_t, std::wstring > &charEntities = *pBaseMap;
    std::map< wchar_t, std::wstring >::const_iterator it = charEntities.begin();
    for(; it != charEntities.end(); ++it)
       {
        entityChars[it->second] = it->first;
       }
    return &entityChars;
}
*/

/*
inline
void convertXmlToStringHelperParseEntity(std::wstring &wstrRes, const std::map< std::wstring, wchar_t > &entityToCharMap, const std::wstring &strEntity )
{
    if (strEntity.empty()) // nothing to do, just append "&;" string
       {
        wstrRes.append(L"&;");
       }
    else
       {
        int digit = boring_copypaste::char2digit(strEntity[0]);
        if (digit!=-1 && digit<10) // decimal integer entity
           {
            int intVal = 0;
            boring_copypaste::parseInteger( strEntity.c_str(), 10, intVal );
            //UINT uintCh = uintFromString( strEntity.c_str(), 0 );
            wstrRes.append(1, (wchar_t)(unsigned)intVal);
           }
        else if (strEntity[0]==L'#') // hexadecimal integer entity
           {
            //UINT uintCh = uintFromXString( strEntity.c_str()+1, 0 );
            int intVal = 0;
            boring_copypaste::parseInteger( strEntity.c_str()+1, 16, intVal );
            //wstrRes.append(1, (wchar_t)uintCh);
            wstrRes.append(1, (wchar_t)(unsigned)intVal);
           }
        else // try to find named entity
           {
            std::map< std::wstring, wchar_t >::const_iterator it = entityToCharMap.find(strEntity);
            if (it==entityToCharMap.end())
               { // entity not found
                wstrRes.append(1, L'&');
                wstrRes.append(1, L';');
               }
            else
               {
                wstrRes.append(1, it->second);
               }
           }
       }
    //wstrRes.append(strEntity);
}
*/

inline
std::string convertStringToXmlHelper( const std::wstring &str, ENUM_CLI_EDATANODESERIALIZEFLAG flags, bool bAttribute )
{
    std::wstring res; res.reserve(str.size());
    std::wstring::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        if (str[i]==L'\n') res.append(1,L'\r');
        res.append(1,str[i]);
       }
    return MARTY_UTF::toUtf8(res);
}


/*
inline
std::wstring convertXmlToStringHelper( const std::string &str, ENUM_CLI_EDATANODESERIALIZEFLAG flags, bool bAttribute )
{
    const std::map< std::wstring, wchar_t > *pEntityToCharMap = getEntityToCharMap();

    std::wstring wstr = MARTY_UTF::fromUtf8(str);
    std::wstring wstrRes;

    std::wstring::size_type maxEntLen = 32;
    std::wstring::size_type i = 0, size = wstr.size(), entLen = 0;
    wstrRes.reserve(wstr.size());
    for(; i!=size; ++i)
       {
        wchar_t ch = wstr[i];
        if (entLen) // processing entity
           {
            if (ch==L'&' || ch==L';' || entLen>=maxEntLen) // entity end found
               {
                std::wstring strEntity( wstr, i - entLen + 1, entLen-1);;
                entLen = 0;
                convertXmlToStringHelperParseEntity(wstrRes, *pEntityToCharMap, strEntity );
               }
            else
               {
                ++entLen;
               }
           }
        else
           {
            if (ch==L'&')
               {
                ++entLen;
               }
            else
               {
                wstrRes.append(1, ch);
               }
           }
       }
    if (entLen)
       {
        std::wstring strEntity( wstr, i - entLen + 1, entLen-1);;
        convertXmlToStringHelperParseEntity(wstrRes, *pEntityToCharMap, strEntity );
       }

    return wstrRes;
}
*/
inline
std::wstring getAttributeValueHelper( ::cli::CiStringSpecialEncoder &spEncoder, const pugi::xml_attribute &attr, ENUM_CLI_EDATANODESERIALIZEFLAG flags)
{
    const char* nodeValue = attr.value();
    if (!nodeValue || !strlen(nodeValue)) return ::std::wstring();
    //return convertXmlToStringHelper(nodeValue, flags, true);
    std::wstring strDecoded;
    RCODE rcRes = spEncoder.decodeMultibyteString( TRUE // precompose
                               , nodeValue // strToDecode
                               , SIZE_T_NPOS
                               , 0 // pEncoder - use default
                               , strDecoded
                               );
    if (rcRes) return std::wstring();
    return strDecoded;
}

inline
std::wstring getAttributeValueHelperRaw( const pugi::xml_attribute &attr, ENUM_CLI_EDATANODESERIALIZEFLAG flags)
{
    const char* nodeValue = attr.value();
    if (!nodeValue || !strlen(nodeValue)) return ::std::wstring();
    return MARTY_UTF::fromUtf8(nodeValue);
}

inline
std::wstring getNodeValueHelper( ::cli::CiStringSpecialEncoder &spEncoder, const pugi::xml_node &c, ENUM_CLI_EDATANODESERIALIZEFLAG flags)
{
    const char* nodeValue = c.value();
    if (!nodeValue || !strlen(nodeValue)) return ::std::wstring();
    //return convertXmlToStringHelper(nodeValue, flags, false);
    std::wstring strDecoded;
    RCODE rcRes = spEncoder.decodeMultibyteString( TRUE // precompose
                               , nodeValue // strToDecode
                               , SIZE_T_NPOS
                               , 0 // pEncoder - use default
                               , strDecoded
                               );
    if (rcRes) return std::wstring();
    return strDecoded;
}


/*
if
*/


// ::sixml::serializer::pugi_helpers::xml_string_writer


// pugi::xml_node pugiNode = pDoc->append_child(pugi::node_element);
// CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO
// ENUM_CLI_EDATANODESERIALIZEFLAG flags
/* pugi::xml_node n = m_node.append_child(pugi::node_element);
 * n.set_name(TSTR2PUGI( stdstr(nodeTagName) ));
 * n.append_child(pugi::node_pcdata).set_value(TSTR2PUGI( stdstr(nodeText) ));
 */


inline
void serializeToXmlNode( pugi::xml_node &pugiNode, INTERFACE_CLI_IDATANODE *pNode, ENUM_CLI_EDATANODESERIALIZEFLAG flags )
   {
    ::cli::CiDataNode_tmp dataNode(pNode);
    ENUM_CLI_EDATANODEFLAGS nodeFlags = dataNode.nodeFlags;
    if ((nodeFlags&CLI_EDATANODEFLAGS_NONSERIALIZABLE) && !(flags&CLI_EDATANODESERIALIZEFLAG_FORCENONSERIALIZABLE))
       return;

    ENUM_CLI_EDATANODETYPE curNodeType = CLI_EDATANODETYPE_ATTRIBUTE;
    pNode->nodeTypeGet(&curNodeType);

    ::std::wstring nodeName = dataNode.nodeName;
    if (curNodeType==CLI_EDATANODETYPE_NODE || curNodeType==CLI_EDATANODETYPE_ATTRIBUTE)
       pugiNode.set_name(MARTY_UTF::toUtf8(nodeName).c_str());

    if (dataNode.hasValue(TRUE))
       {
        ::std::wstring strVal;
        if (flags&CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO)
           dataNode.serializeValueSimple(strVal);
        else
           dataNode.serializeValueAdvanced(strVal);
        //pugiNode.append_child(pugi::node_pcdata).set_value(MARTY_UTF::toUtf8(strVal).c_str());
        pugiNode.append_attribute( "_internal_:_value_" ).set_value( convertStringToXmlHelper(strVal, flags, true ).c_str() );
       }

    if (flags&CLI_EDATANODESERIALIZEFLAG_WRITESTAMP && curNodeType==CLI_EDATANODETYPE_NODE)
       {
        ::cli::CiVariant variant( cliGetVariant( ), true  /* noAddRef */  );
        variant.setUInt64(pNode->getStamp());
        //variant.setString(val);
        if (flags&CLI_EDATANODESERIALIZEFLAG_WRITESTAMPASDATETIME)
           {
            variant.convertType(CLI_VARIANTTYPE_VT_DATETIME);
           }
        ::std::wstring strStamp;
        variant.getString(strStamp);
        pugiNode.append_attribute( "_internal_:_stamp_" ).set_value( convertStringToXmlHelper(strStamp, flags, true ).c_str() );
       }

    // getting childs
    //INTERFACE_CLI_IDATANODELIST *pChildNodes = 0;
    ::cli::CiDataNodeList nodeList;
    dataNode.getChildNodes(nodeList.getPP());
    if (!!nodeList)
       {
        SIZE_T listSize = nodeList.listSize;
        for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
           {
            ::cli::CiDataNode childNode;
            nodeList.getDataNode(childNode.getPP(), nodeIndex);
            if (!childNode) continue;

            ENUM_CLI_EDATANODETYPE nodeType = childNode.nodeType;
            if (nodeType==CLI_EDATANODETYPE_ATTRIBUTE)
               {
                ::std::wstring attrName = childNode.nodeName;
                ::std::wstring attrVal;
                if (flags&CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO)
                   childNode.serializeValueSimple(attrVal);
                else
                   childNode.serializeValueAdvanced(attrVal);
                pugiNode.append_attribute(  MARTY_UTF::toUtf8(attrName).c_str() ).set_value( convertStringToXmlHelper(attrVal, flags, true ).c_str() );
               }
            else if (nodeType==CLI_EDATANODETYPE_NODE)
               { // nodeType==CLI_EDATANODETYPE_NODE
                if (flags&CLI_EDATANODESERIALIZEFLAG_WRITEPRETTY)
                   {
                    pugi::xml_node pugiChildNode = pugiNode.append_child(pugi::node_pcdata);
                    unsigned levelNo = childNode.levelNo;
                    pugiChildNode.set_value((std::string("\r\n") + std::string(levelNo*2, ' ')).c_str());
                   }

                pugi::xml_node pugiChildNode = pugiNode.append_child(pugi::node_element);
                serializeToXmlNode( pugiChildNode, childNode.getIfPtr(), flags );

                if (flags&CLI_EDATANODESERIALIZEFLAG_WRITEPRETTY)
                   {
                    pugi::xml_node pugiChildNode = pugiNode.append_child(pugi::node_pcdata);
                    unsigned levelNo = childNode.levelNo;
                    if (levelNo) --levelNo;
                    pugiChildNode.set_value((std::string("\r\n") + std::string(levelNo*2, ' ')).c_str());
                    //pugiChildNode.set_value("\r\n");
                   }
               }
            else // nodeType==CLI_EDATANODETYPE_TEXT
               {
                if (childNode.hasValue(TRUE))
                   {
                    ::std::wstring strVal;
                    if (flags&CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO)
                       childNode.serializeValueSimple(strVal);
                    else
                       childNode.serializeValueAdvanced(strVal);
                    pugi::xml_node pugiChildNode = pugiNode.append_child(pugi::node_pcdata);
                    pugiChildNode.set_value(convertStringToXmlHelper(strVal, flags, false ).c_str());
                   }
               }
           }

        /*
        if (flags&CLI_EDATANODESERIALIZEFLAG_WRITEPRETTY)
           {
            pugi::xml_node pugiChildNode = pugiNode.append_child(pugi::node_pcdata);
            unsigned levelNo = childNode.levelNo;
            pugiChildNode.set_value("\r\n");
           }
        */
       }
   }

/*
                deserializeFromXmlNode( specialEncoderText, specialEncoderAttr, rootNode, this, flags );

                ::cli::CiStringSpecialEncoder specialEncoderText("/cli/string-special-encoder/html-text");
                ::cli::CiStringSpecialEncoder specialEncoderAttr("/cli/string-special-encoder/html-attr");
*/
inline
void deserializeFromXmlNode( ::cli::CiStringSpecialEncoder &textEncoder, ::cli::CiStringSpecialEncoder attrEncoder
                           , pugi::xml_node &pugiNode, INTERFACE_CLI_IDATANODE *pNode, ENUM_CLI_EDATANODESERIALIZEFLAG flags )
   {
    //::std::wstring nodeText = ::sixml::serializer::pugi_helpers::getNodeTextHelper( pugiNode );
    ::cli::CiDataNode_tmp dataNode(pNode);
    //dataNode.deserializeValueAdvanced( ::sixml::serializer::pugi_helpers::getNodeTextHelperEx( pugiNode ) );

    //std::wstring wstrNodeValue;

    for (pugi::xml_attribute a = pugiNode.first_attribute(); a; a = a.next_attribute())
        {
         const char* attrName = a.name();
         if (!attrName) continue;

         std::wstring wstrAttrName  = MARTY_UTF::fromUtf8(attrName);

         //const char* attrValue = a.value();
         //std::wstring wstrAttrValue;
         //if (attrValue)
         //   wstrAttrValue = MARTY_UTF::fromUtf8(attrValue);
         std::wstring wstrAttrValue = getAttributeValueHelper( attrEncoder, a, flags );
         if (wstrAttrName==L"_internal_:_stamp_")
            {
             ::cli::CiVariant variant( cliGetVariant( ), true  /* noAddRef */  );
             variant.setString(wstrAttrValue);
             variant.convertType(CLI_VARIANTTYPE_VT_DATETIME);
             UINT64  stamp;
             if (variant.getUInt64(&stamp)==0)
                {
                 pNode->putStampEx( stamp );
                }
            }
         else if (wstrAttrName==L"_internal_:_value_")
            {
             //wstrNodeValue = wstrAttrValue;
             if (flags&CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO)
                dataNode.deserializeValueSimple(wstrAttrValue);
             else
                dataNode.deserializeValueAdvanced(wstrAttrValue);
            }
         else
            {
             ::cli::CiDataNode attrNode;
             dataNode.createChildDataNode( attrNode.getPP()
                                         , CLI_EDATANODETYPE_ATTRIBUTE
                                         , MARTY_UTF::fromUtf8(attrName)
                                         , 0 // pValue
                                         );
             if (!!attrNode)
                {
                 //attrNode.deserializeValueAdvanced( ::sixml::serializer::pugi_helpers::getNodeTextHelper( a ) );
                 attrNode.deserializeValueAdvanced( wstrAttrValue );
                }
            }
         //INTERFACE_CLI_IDATANODE*    pNewAttrNode = 0;
        }

    for (pugi::xml_node c = pugiNode.first_child(); c; c = c.next_sibling())
        {
         pugi::xml_node_type childType = c.type();
         if (childType!=pugi::node_element && childType!=pugi::node_pcdata && childType!=pugi::node_cdata) continue;

         const char* nodeName = c.name();
         if (!nodeName)
            {
             if (childType==pugi::node_element) continue;
             nodeName = "text";
            }

         ENUM_CLI_EDATANODETYPE nodeType = (childType==pugi::node_element) ? CLI_EDATANODETYPE_NODE : CLI_EDATANODETYPE_TEXT;

         ::cli::CiDataNode childNode;
         dataNode.createChildDataNode( childNode.getPP()
                                     , nodeType
                                     , MARTY_UTF::fromUtf8(nodeName)
                                     , 0 // pValue
                                     );
         if (!!childNode)
            {
             if (childType==pugi::node_element)
                deserializeFromXmlNode( textEncoder, attrEncoder, c, childNode.getIfPtr(), flags );
             else
                {
                 if (flags&CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO)
                    childNode.deserializeValueSimple(getNodeValueHelper(textEncoder, c, flags));
                 else
                    childNode.deserializeValueAdvanced(getNodeValueHelper(textEncoder, c, flags));
                 /*
                 const char* nodeValue = c.value();
                 if (nodeValue)
                    {
                     if (flags&CLI_EDATANODESERIALIZEFLAG_NOTYPEINFO)
                        childNode.deserializeValueSimple(MARTY_UTF::fromUtf8(nodeValue));
                     else
                        childNode.deserializeValueAdvanced(MARTY_UTF::fromUtf8(nodeValue));
                    }
                 */
                 //::sixml::serializer::pugi_helpers::getNodeTextHelper( a )
                }
            }
         /*
         const char* nodeValue = c.value();
         if (!!childNode)
            deserializeFromXmlNode( c, childNode.getIfPtr(), flags );
         */
        }
   }

//deserializeFromXmlNode( rootNode, this, flags );

struct CDataNodeListImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IDATANODELIST
                      , public INTERFACE_CLI_IVARIANTCONVERT
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    ::std::vector<INTERFACE_CLI_IDATANODE*>   nodes;

    CDataNodeListImpl() : base_impl(DEF_MODULE), nodes()
       {
       }

    CDataNodeListImpl( const CDataNodeListImpl &list) : base_impl(DEF_MODULE), nodes(list.nodes)
       {
        ::std::vector<INTERFACE_CLI_IDATANODE*>::iterator it = nodes.begin();
        for(; it != nodes.end(); ++it)
           if (*it) (*it)->addRef();
       }

    CDataNodeListImpl( const CDataNodeListImpl &list, bool cloneDummy) : base_impl(DEF_MODULE), nodes()
       {
        nodes.reserve(list.nodes.size());
        ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = list.nodes.begin();
        for(; it != list.nodes.end(); ++it)
           {
            INTERFACE_CLI_IDATANODE* pNode = *it;
            INTERFACE_CLI_IDATANODE* pNodeCopy = 0;
            if (!pNode) continue;
            pNode->cloneDataNode(&pNodeCopy);
            nodes.push_back(pNodeCopy);
           }
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CDataNodeListImpl()
       {
        clearList();
       }

    CLI_BEGIN_INTERFACE_MAP2(CDataNodeListImpl, INTERFACE_CLI_IDATANODELIST)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IDATANODELIST )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IVARIANTCONVERT )
    CLI_END_INTERFACE_MAP(CDataNodeListImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)
       {
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }

    CLIMETHOD(listSizeGet) (THIS_ SIZE_T*    _listSize /* [out] size_t _listSize  */)
       {
        if (_listSize) *_listSize = nodes.size();
        return EC_OK;
       }

    CLIMETHOD(cloneNodeList) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */)
       {
        CLI_TRY{
                if (!pNodes) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodes" );  }
                *pNodes = static_cast<INTERFACE_CLI_IDATANODELIST*>(new CDataNodeListImpl( *this ));
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(cloneDataNodesToNewList) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */)
       {
        CLI_TRY{
                if (!pNodes) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodes" );  }
                *pNodes = new CDataNodeListImpl( *this, true );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(cloneDataNodesToNode) (THIS_ INTERFACE_CLI_IDATANODE*    pListRootNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        CLI_TRY{
                if (!pListRootNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pListRootNode" );  }
                ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin();
                for(; it != nodes.end(); ++it)
                   {
                    INTERFACE_CLI_IDATANODE* pNode = *it;
                    INTERFACE_CLI_IDATANODE* pNodeCopy = 0;
                    if (!pNode) continue;
                    pNode->cloneDataNode(&pNodeCopy);
                    pListRootNode->pushBackChildNode(pNodeCopy);
                    pNodeCopy->release();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(makeCleanNodeListClone) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodes /* [out] ::cli::iDataNodeList* pNodes  */)
       {
        CLI_TRY{
                if (!pNodes) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodes" );  }
                *pNodes = new CDataNodeListImpl( );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(insertDataNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                   , SIZE_T    where /* [in] size_t  where  */
                              )
       {
        CLI_TRY{
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
                pNode->addRef();
                if (where>=nodes.size()) nodes.insert( nodes.begin() + nodes.size(), pNode );
                else                     nodes.insert( nodes.begin() + where, pNode );
                pNode->addRef();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(pushBackDataNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                )
       {
        CLI_TRY{
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
                pNode->addRef();
                nodes.insert( nodes.begin() + nodes.size(), pNode );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(swapDataNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeNew /* [in] ::cli::iDataNode*  pNodeNew  */
                                 , SIZE_T    where /* [in] size_t  where  */
                                 , ENUM_CLI_EDATANODESWAPFLAGS    flags /* [in] ::cli::EDataNodeSwapFlags  flags  */
                                 , INTERFACE_CLI_IDATANODE**    pNodePrev /* [out,optional] ::cli::iDataNode* pNodePrev  */
                            )
       {
        CLI_TRY{
                if (!pNodeNew) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeNew" );  }
                if (where >= nodes.size()) return EC_OUT_OF_RANGE;

                INTERFACE_CLI_IDATANODE* pPrev = nodes[where];
                pNodeNew->addRef();
                nodes[where] = pNodeNew;

                if (pPrev)
                   {
                    SIZE_T s = 0;
                    if (flags&CLI_EDATANODESWAPFLAGS_UPDATEINPUTSTREAMID && pPrev->inputStreamIdGet(&s)==EC_OK)
                       {
                        pNodeNew->inputStreamIdSet(s);
                       }
                    if (flags&CLI_EDATANODESWAPFLAGS_UPDATESTREAMID && pPrev->streamIdGet(&s)==EC_OK)
                       {
                        pNodeNew->streamIdSet(s);
                       }
                    if (flags&CLI_EDATANODESWAPFLAGS_UPDATELINENO && pPrev->lineNoGet(&s)==EC_OK)
                       {
                        pNodeNew->lineNoSet(s);
                       }
                    if (flags&CLI_EDATANODESWAPFLAGS_UPDATELINEPOS && pPrev->linePosGet(&s)==EC_OK)
                       {
                        pNodeNew->linePosSet(s);
                       }
                   }

                if (pNodePrev)
                   {
                    *pNodePrev = pPrev; // need to be released
                   }
                else
                   {
                    if (pPrev) pPrev->release();
                   }

                //nodes.insert( nodes.begin() + nodes.size(), pNode );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


    CLIMETHOD(eraseDataNode) (THIS_ SIZE_T    where /* [in] size_t  where  */)
       {
        CLI_TRY{
                if (where>=nodes.size()) return EC_OUT_OF_RANGE;
                nodes[where]->release();
                nodes.erase( nodes.begin() + where );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(eraseDataNodeEx) (THIS_ SIZE_T    where /* [in] size_t  where  */
                                    , BOOL    fClearParent /* [in] bool  fClearParent  */
                               )
       {
        CLI_TRY{
                if (where>=nodes.size()) return EC_OUT_OF_RANGE;
                if (fClearParent) nodes[where]->setParentNode(0);
                nodes[where]->release();
                nodes.erase( nodes.begin() + where );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(setParentNode) (THIS_ INTERFACE_CLI_IDATANODE*    pParentNode /* [in] ::cli::iDataNode*  pParentNode  */)
       {
        CLI_TRY{
                //if (!pParentNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pParentNode" );  }
                ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin();
                for(; it != nodes.end(); ++it)
                   {
                    (*it)->setParentNode(pParentNode);
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    #if 0
    CLIMETHOD(setLevelNo) (THIS_ SIZE_T    lvl /* [in] size_t  lvl  */)
       {
        CLI_TRY{
                //if (!pParentNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pParentNode" );  }
                ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin();
                for(; it != nodes.end(); ++it)
                   {
                    (*it)->levelNoSet(lvl);
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }
    #endif

    CLIMETHOD(clearList) (THIS)
       {
        ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin();
        for(; it != nodes.end(); ++it)
           {
            (*it)->release();
           }

        nodes.erase( nodes.begin(), nodes.end() );
        return EC_OK;
       }

    CLIMETHOD(objectValueToString) (THIS_ CLISTR*           str)
       {
        CLI_TRY{
                if (!str) return EC_OK;
                ::std::wstring allText;
                ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin();
                for(; it != nodes.end(); ++it)
                   {
                    CiVariantConvert vconv;
                    (*it)->queryInterface( INTERFACE_CLI_IVARIANTCONVERT_IID, (VOID**)vconv.getPP() );
                    if (!!vconv)
                       {
                        ::std::wstring objAsStr;
                        if (!vconv.objectValueToString( objAsStr ))
                           {
                            allText += objAsStr;
                           }
                       }
                   }
                return ::cli::propertyGetImpl( str, allText );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getText) (THIS_ CLISTR*           str)
       {
        CLI_TRY{
                if (!str) return EC_OK;
                ::std::wstring allText;
                ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin();
                for(; it != nodes.end(); ++it)
                   {
                    CiDataNode_tmp tmp(*it);
                    if (tmp.nodeType != CLI_EDATANODETYPE_NODE && tmp.nodeType != CLI_EDATANODETYPE_TEXT ) continue;
                    ::std::wstring nodeText;
                    tmp.getText( TRUE, nodeText );
                    allText += nodeText;
                   }
                return ::cli::propertyGetImpl( str, allText );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getNodeName) (THIS_ CLISTR*           str
                                , SIZE_T    idx /* [in] size_t  idx  */
                           )
       {
        //CLI_TRY{
                if (!str) return EC_INVALID_PARAM;
                if (idx>=nodes.size()) return EC_OUT_OF_RANGE;
                return nodes[idx]->nodeNameGet(str);
        //       }
        //CLI_CATCH_RETURN_CLI_EXCEPTION()
        //CLI_CATCH_RETURN_STD_EXCEPTIONS()
        //return EC_OK;
       }

    CLIMETHOD(getNodeType) (THIS_ ENUM_CLI_EDATANODETYPE*    type /* [out] ::cli::EDataNodeType type  */
                                , SIZE_T    idx /* [in] size_t  idx  */
                           )
       {
        //CLI_TRY{
                if (!type) return EC_INVALID_PARAM;
                if (idx>=nodes.size()) return EC_OUT_OF_RANGE;
                return nodes[idx]->nodeTypeGet(type);
        //       }
        //CLI_CATCH_RETURN_CLI_EXCEPTION()
        //CLI_CATCH_RETURN_STD_EXCEPTIONS()
        //return EC_OK;
       }

    CLIMETHOD(clearListEx) (THIS_ BOOL    fClearParents /* [in] bool  fClearParents  */
                                , ENUM_CLI_EDATANODETYPE    keepTypes /* [in] ::cli::EDataNodeType  keepTypes  */
                           )
       {
        ::std::vector<INTERFACE_CLI_IDATANODE*> nodesTmp;
        ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin();
        for(; it != nodes.end(); ++it)
           {
            CiDataNode_tmp tmp(*it);
            ENUM_CLI_EDATANODETYPE tmpType = tmp.nodeType;
            if (tmpType&keepTypes)
               nodesTmp.push_back(*it);
            else
               {
                if (fClearParents) tmp.setParentNode(0);
                (*it)->release();
               }
            /*
            if (fClearParents)
               (*it)->setParentNode(0);
            (*it)->release();
            */
           }
        nodes.swap(nodesTmp);
        //nodes.erase( nodes.begin(), nodes.end() );
        return EC_OK;
       }

    CLIMETHOD(getDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                , SIZE_T    where /* [in] size_t  where  */
                           )
       {
        CLI_TRY{
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
                if (where>=nodes.size()) return EC_OUT_OF_RANGE;
                *pNode = nodes[where];
                (*pNode)->addRef();
                return EC_OK;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(appendNodeList) (THIS_ INTERFACE_CLI_IDATANODELIST*    pNodes /* [in] ::cli::iDataNodeList*  pNodes  */)
       {
        if (!pNodes) return EC_INVALID_PARAM;
        ::cli::CiDataNodeList_tmp nodeList(pNodes);
        SIZE_T listSize = nodeList.listSize;
        for( SIZE_T idx = 0; idx!=listSize; ++idx )
           {
            ::cli::CiDataNode node;
            if (nodeList.getDataNode(node.getPP(),idx)) continue;
            this->pushBackDataNode( node.getIfPtr() );
           }
        return EC_OK;
       }

    CLIMETHOD_(BOOL, findNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (!pNode) return FALSE;
        ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin(), end = nodes.end();
        for(; it!=end; ++it)
           {
            INTERFACE_CLI_IDATANODE* pn = *it;
            if (pn==pNode) return TRUE;
           }
        return FALSE;
       }

    CLIMETHOD_(SIZE_T, getNodeIndex) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (!pNode) return SIZE_T_NPOS;
        SIZE_T idx = 0;
        ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin(), end = nodes.end();
        for(; it!=end; ++it, ++idx)
           {
            INTERFACE_CLI_IDATANODE* pn = *it;
            if (pn==pNode) return idx;
           }
        return SIZE_T_NPOS;
       }

    CLIMETHOD_(SIZE_T, findNodeByName) (THIS_ const CLISTR*     nodeName)
       {
        ::std::vector< INTERFACE_CLI_IDATANODE* >::const_iterator nodeIt = nodes.begin();
        for(; nodeIt != nodes.end(); ++nodeIt)
           {
            INTERFACE_CLI_IDATANODE *pNode = *nodeIt;
            if (!pNode) continue;

            if (pNode->compareName(nodeName))
               return (SIZE_T)(nodeIt - nodes.begin());
           }
        return SIZE_T_NPOS;
       }

    CLIMETHOD_(SIZE_T, findNodeByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        ::std::vector< INTERFACE_CLI_IDATANODE* >::const_iterator nodeIt = nodes.begin();
        for(; nodeIt != nodes.end(); ++nodeIt)
           {
            INTERFACE_CLI_IDATANODE *pNode = *nodeIt;
            if (!pNode) continue;

            if (pNode->compareNameChars(name))
               return (SIZE_T)(nodeIt - nodes.begin());
           }
        return SIZE_T_NPOS;
       }

    CLIMETHOD_(SIZE_T, findNodeByNameType) (THIS_ const CLISTR*     nodeName
                                                , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                           )
       {
        ::std::vector< INTERFACE_CLI_IDATANODE* >::const_iterator nodeIt = nodes.begin();
        for(; nodeIt != nodes.end(); ++nodeIt)
           {
            INTERFACE_CLI_IDATANODE *pNode = *nodeIt;
            if (!pNode) continue;

            if (pNode->compareNameType( nodeName, type ))
               return (SIZE_T)(nodeIt - nodes.begin());
           }
        return SIZE_T_NPOS;
       }

    CLIMETHOD_(SIZE_T, findNodeByNameTypeChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                     , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                )
       {
        ::std::vector< INTERFACE_CLI_IDATANODE* >::const_iterator nodeIt = nodes.begin();
        for(; nodeIt != nodes.end(); ++nodeIt)
           {
            INTERFACE_CLI_IDATANODE *pNode = *nodeIt;
            if (!pNode) continue;

            if (pNode->compareNameTypeChars( name, type ))
               return (SIZE_T)(nodeIt - nodes.begin());
           }
        return SIZE_T_NPOS;
       }

    CLIMETHOD(getDataNodeValue) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    pValue /* [out] ::cli::iReadOnlyVariant* pValue  */
                                     , SIZE_T    idx /* [in] size_t  idx  */
                                )
       {
        CLI_TRY{
                if (!pValue) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pValue" );  }
                if (idx>=nodes.size()) return EC_OUT_OF_RANGE;
                INTERFACE_CLI_IDATANODE *pNode = nodes[idx];
                return pNode->getDataNodeValue(pValue);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(mergeNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        CLI_TRY{
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
                if (findNode(pNode)) return EC_ALLREADY;
                pNode->addRef();
                nodes.insert( nodes.begin() + nodes.size(), pNode );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(mergeNodeList) (THIS_ INTERFACE_CLI_IDATANODELIST*    pNodes /* [in] ::cli::iDataNodeList*  pNodes  */)
       {
        CLI_TRY{
                if (!pNodes) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodes" );  }

                //::std::set< INTERFACE_CLI_IDATANODELIST* > existingNodes;
                //::cli::util::CAutoSortVector< INTERFACE_CLI_IDATANODE* >  existingNodes;
                //existingNodes.reserve( nodes.size() );
                ::std::set< INTERFACE_CLI_IDATANODE* > existingNodes;
                ::std::vector<INTERFACE_CLI_IDATANODE*>::const_iterator it = nodes.begin(), end = nodes.end();
                for(; it!=end; ++it)
                   {
                    //existingNodes.unsorted_push_back( *it );
                    existingNodes.insert(*it);
                   }
                //existingNodes.sort();

                ::cli::CiDataNodeList_tmp nodeList(pNodes);
                SIZE_T listSize = nodeList.listSize;
                for( SIZE_T idx = 0; idx!=listSize; ++idx )
                   {
                    ::cli::CiDataNode node;
                    if (nodeList.getDataNode(node.getPP(),idx)) continue;
                    if (existingNodes.find(node.getIfPtr()) != existingNodes.end() ) continue;
                    //this->pushBackDataNode( node.getIfPtr() );
                    node.getIfPtr()->addRef();
                    nodes.insert( nodes.begin() + nodes.size(), node.getIfPtr() );
                    existingNodes.insert(node.getIfPtr());
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


}; // struct CDataNodeListImpl


struct CEventListImpl : public INTERFACE_CLI_IDATANODE
{
    ::std::vector< ::std::pair< INTERFACE_CLI_IDATAEVENTHANDLER*, ENUM_CLI_EDATANODEEVENTMASK > > eventHandlers;
    CEventListImpl() : eventHandlers() {}
    ~CEventListImpl()
       {
        clearEventHandlers();
       }

private:
    CEventListImpl(const CEventListImpl&);
    CEventListImpl& operator=(const CEventListImpl&);
public:

    CLIMETHOD(addEventHandler) (THIS_ INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */
                                    , ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */
                               )
       {
        CLI_TRY{
                if (!pHandler) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pHandler" );  }
                pHandler->addRef();
                eventHandlers.push_back( ::std::make_pair(pHandler, eventMask) );

               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD_(SIZE_T, findEventHandler) (THIS_ INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */)
       {
        ::std::vector< ::std::pair< INTERFACE_CLI_IDATAEVENTHANDLER*, ENUM_CLI_EDATANODEEVENTMASK > >::const_iterator evIt =  eventHandlers.begin();
        for(; evIt != eventHandlers.end(); ++evIt)
           {
            if (evIt->first == pHandler) return (SIZE_T)(evIt-eventHandlers.begin());
           }
        return SIZE_T_NPOS;
       }

    CLIMETHOD(removeEventHandler) (THIS_ INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */)
       {
        ::std::vector< ::std::pair< INTERFACE_CLI_IDATAEVENTHANDLER*, ENUM_CLI_EDATANODEEVENTMASK > >::iterator evIt =  eventHandlers.begin();
        for(; evIt != eventHandlers.end(); ++evIt)
           {
            if (evIt->first == pHandler)
               {
                evIt->first->release();
                eventHandlers.erase( evIt );
                return EC_OK;
               }
           }
        return EC_NOT_FOUND;
       }

    CLIMETHOD(removeEventHandlerByIndex) (THIS_ SIZE_T    handlerIndex /* [in] size_t  handlerIndex  */)
       {
        if (handlerIndex>=(SIZE_T)eventHandlers.size()) return EC_OUT_OF_RANGE;
        eventHandlers[handlerIndex].first->release();
        eventHandlers.erase( eventHandlers.begin()+handlerIndex );
        return EC_OK;
       }

    CLIMETHOD(clearEventHandlers) (THIS)
       {
        ::std::vector< ::std::pair< INTERFACE_CLI_IDATAEVENTHANDLER*, ENUM_CLI_EDATANODEEVENTMASK > >::iterator evIt =  eventHandlers.begin();
        for(; evIt != eventHandlers.end(); ++evIt)
           {
            evIt->first->release();
           }
        eventHandlers.clear();
        return EC_OK;
       }

    CLIMETHOD(childGenerateEvent) (THIS_ ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */)
       {
        return generateEvent( eventMask );
       }

};




struct CDataNodeImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                     //, public INTERFACE_CLI_IDATANODE
                     , public CEventListImpl
                     , public INTERFACE_CLI_IVARIANTCONVERT
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    //::std::vector<INTERFACE_CLI_IDATANODE*>   nodes;
    INTERFACE_CLI_IDATANODELIST *pChildList;
    ENUM_CLI_EDATANODETYPE       nodeType;
    ::std::wstring               nodeName;
    ENUM_CLI_EDATANODEFLAGS      nodeFlags;
    INTERFACE_CLI_IVARIANT      *pValue;
    CCriticalSection             childListLock;
    INTERFACE_CLI_IDATANODE     *parentNode;
    ilint_t ILVOLATILE           eventLockCounter;
    CLI_TIME_T                   stamp;
    SIZE_T                       inputStreamId;
    SIZE_T                       streamId;
    SIZE_T                       lineNo;
    SIZE_T                       linePos;
    SIZE_T                       levelNoCached;


    CDataNodeImpl() : base_impl(DEF_MODULE)
                    , CEventListImpl()
                    , pChildList( new CDataNodeListImpl() )
                    , nodeType(CLI_EDATANODETYPE_NODE)
                    , nodeName()
                    , nodeFlags(0)
                    , pValue()
                    , childListLock()
                    , parentNode(0)
                    , eventLockCounter(0)
                    , stamp( createStampConst() )
                    , inputStreamId(SIZE_T_NPOS)
                    , streamId(SIZE_T_NPOS)
                    , lineNo(SIZE_T_NPOS)
                    , linePos(SIZE_T_NPOS)
                    , levelNoCached(SIZE_T_NPOS)
       {
       }

    CDataNodeImpl(ENUM_CLI_EDATANODETYPE nt, const ::std::wstring &name, INTERFACE_CLI_IVARIANT *pv)
       : base_impl(DEF_MODULE)
       , CEventListImpl()
       , pChildList( 0 )
       , nodeType(nt)
       , nodeName(name)
       , nodeFlags(0)
       , pValue(pv)
       , childListLock()
       , parentNode(0)
       , eventLockCounter(0)
       , stamp( createStampConst() )
       , inputStreamId(SIZE_T_NPOS)
       , streamId(SIZE_T_NPOS)
       , lineNo(SIZE_T_NPOS)
       , linePos(SIZE_T_NPOS)
       , levelNoCached(SIZE_T_NPOS)
       {
        if (nodeType==CLI_EDATANODETYPE_NODE)
           pChildList = new CDataNodeListImpl();
        if (pValue) pValue->addRef();
       }

    CDataNodeImpl( const CDataNodeImpl &dn ) : base_impl(DEF_MODULE)
                    , CEventListImpl()
                    , pChildList( 0 )
                    , nodeType(dn.nodeType)
                    , nodeName(dn.nodeName)
                    , nodeFlags(dn.nodeFlags)
                    , pValue(0)
                    , childListLock()
                    , parentNode(0)
                    , eventLockCounter(0)
                    , stamp( dn.getStamp() )
                    , inputStreamId(SIZE_T_NPOS)
                    , streamId(SIZE_T_NPOS)
                    , lineNo(SIZE_T_NPOS)
                    , linePos(SIZE_T_NPOS)
                    , levelNoCached(SIZE_T_NPOS)
       {
        if (dn.pValue)
           dn.pValue->cloneVariant( &pValue );
        if (dn.pChildList)
           {
            INTERFACE_CLI_IDATANODE *pRightDataNode = const_cast<INTERFACE_CLI_IDATANODE*>(static_cast<const INTERFACE_CLI_IDATANODE*>(&dn));
            pRightDataNode->lockChildNodes();
            dn.pChildList->cloneDataNodesToNewList( &pChildList );
            pRightDataNode->unlockChildNodes();
            pChildList->setParentNode( this );
           }
       }

    ~CDataNodeImpl()
       {
        if (pChildList)
           {
            pChildList->setParentNode(0);
            pChildList->release();
           }
        if (pValue) pValue->release();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CDataNodeImpl,INTERFACE_CLI_IDATANODE)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IDATANODE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IVARIANTCONVERT )
    CLI_END_INTERFACE_MAP(CDataNodeImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)
       {
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }

    CLIMETHOD(nodeFlagsGet) (THIS_ ENUM_CLI_EDATANODEFLAGS*    _nodeFlags /* [out] ::cli::EDataNodeFlags _nodeFlags  */)
       {
        if (_nodeFlags) *_nodeFlags = nodeFlags;
        return EC_OK;
       }

    CLIMETHOD(nodeFlagsSet) (THIS_ ENUM_CLI_EDATANODEFLAGS    _nodeFlags /* [in] ::cli::EDataNodeFlags  _nodeFlags  */)
       {
        nodeFlags = _nodeFlags;
        return EC_OK;
       }

    CLIMETHOD(levelNoGet) (THIS_ SIZE_T*    _levelNo /* [out] size_t _levelNo  */)
       {
        if (!_levelNo) return EC_OK;
        if (levelNoCached!=SIZE_T_NPOS)
           {
            *_levelNo = levelNoCached;
            return EC_OK;
           }

        SIZE_T parentLevel = SIZE_T_NPOS;
        if (parentNode) parentNode->levelNoGet(&parentLevel);
        if (parentLevel == SIZE_T_NPOS) levelNoCached = 0;
        else                            levelNoCached = parentLevel+1;

        *_levelNo = levelNoCached;
        return EC_OK;
       }

    #if 0
    CLIMETHOD(levelNoSet) (THIS_ SIZE_T    _levelNo /* [in] size_t  _levelNo  */)
       {
        levelNo = _levelNo;
        CLI_SCOPED_LOCK(childListLock);
        if (pChildList) pChildList->setLevelNo(levelNo+1);
        return EC_OK;
       }
    #endif

    CLIMETHOD(inputStreamIdGet) (THIS_ SIZE_T*    _streamId /* [out] size_t _streamId  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, _streamId );

        *_streamId = inputStreamId;

        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(inputStreamIdSet) (THIS_ SIZE_T    _streamId /* [in] size_t  _streamId  */)
       {
        inputStreamId = _streamId;
        return EC_OK;
       }

    CLIMETHOD(streamIdGet) (THIS_ SIZE_T*    _streamId /* [out] size_t _streamId  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, _streamId );

        *_streamId = streamId;

        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(streamIdSet) (THIS_ SIZE_T    _streamId /* [in] size_t  _streamId  */)
       {
        streamId = _streamId;
        return EC_OK;
       }

    CLIMETHOD(lineNoGet) (THIS_ SIZE_T*    _lineNo /* [out] size_t _lineNo  */)
       {
        CLI_TRY{
                if (!_lineNo) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pLineNo" );  }
                *_lineNo = lineNo;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(lineNoSet) (THIS_ SIZE_T    _lineNo /* [in] size_t  _lineNo  */)
       {
        lineNo = _lineNo;
        return EC_OK;
       }

    CLIMETHOD(linePosGet) (THIS_ SIZE_T*    _linePos /* [out] size_t _linePos  */)
       {
        CLI_TRY{
                if (!_linePos) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pLinePos" );  }
                *_linePos = linePos;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(linePosSet) (THIS_ SIZE_T    _linePos /* [in] size_t  _linePos  */)
       {
        linePos = _linePos;
        return EC_OK;
       }

    // ----------
    RCODE getChildsToListByTypeAndNameImpl( INTERFACE_CLI_IDATANODELIST *pNodeList
                                          , ENUM_CLI_EDATANODETYPE    nodeTypeCmp
                                          , const std::vector< std::wstring > &names
                                          )
       {
        //INTERFACE_CLI_IDATANODELIST *pChildList;
        if (!pChildList) return 0;
        SIZE_T nodeIdx = 0, nodesSize = 0;
        pChildList->listSizeGet( &nodesSize );
        for(; nodeIdx!=nodesSize; ++nodeIdx)
           {
            cli::CiDataNode node; // ( nodes[idx] );
            pChildList->getDataNode(node.getPP(), nodeIdx);

            std::wstring           nodeName = node.nodeName;
            ENUM_CLI_EDATANODETYPE nodeType = node.nodeType;

            if (nodeType!=CLI_EDATANODETYPE_ANY && nodeType!=nodeTypeCmp) continue;

            std::vector< std::wstring >::const_iterator nit = names.begin();
            for(; nit != names.end(); ++nit)
               {
                if (nodeName==*nit) break;
               }
            if (nit == names.end()) continue;

            pNodeList->pushBackDataNode( node.getIfPtr() );
           }
        return 0;
       }

    CLIMETHOD(getChildsToListByTypeAndName) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                 , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                 , const CLISTR*     _names
                                            )
       {
        CLI_TRY{
                if (!pNodeList) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeList" );  }
                if (!_names)    { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 3) % L"names" );  }
                INTERFACE_CLI_IDATANODELIST *nodeList = new CDataNodeListImpl( );
                *pNodeList = nodeList;
                ::std::wstring strNames;
                ::cli::propertySetImpl( _names, strNames );
                ::std::vector< ::std::wstring > namesVec;
                ::cli::util::splitString( strNames, namesVec, ::cli::util::CIsExactChar< wchar_t, L','>() );
                CLI_SCOPED_LOCK(childListLock);
                return getChildsToListByTypeAndNameImpl( nodeList, nodeType, namesVec );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getChildsToListByTypeAndNameChars) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                      , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                      , const WCHAR*    _names /* [in,flat] wchar  names[]  */
                                                 )
       {
        CLI_TRY{
                if (!pNodeList) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeList" );  }
                if (!_names)    { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 3) % L"names" );  }
                INTERFACE_CLI_IDATANODELIST *nodeList = new CDataNodeListImpl( );
                *pNodeList = nodeList;
                ::std::wstring strNames;
                ::cli::propertySetImpl( _names, strNames );
                ::std::vector< ::std::wstring > namesVec;
                ::cli::util::splitString( strNames, namesVec, ::cli::util::CIsExactChar< wchar_t, L','>() );
                CLI_SCOPED_LOCK(childListLock);
                return getChildsToListByTypeAndNameImpl( nodeList, nodeType, namesVec );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getChildsToListByType) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                          , ENUM_CLI_EDATANODETYPE    nodeTypeCmp /* [in] ::cli::EDataNodeType  nodeType  */
                                     )
       {
        CLI_TRY{
                if (!pNodeList) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeList" );  }
                INTERFACE_CLI_IDATANODELIST *nodeList = new CDataNodeListImpl( );
                *pNodeList = nodeList;
                if (!pChildList) return 0;

                CLI_SCOPED_LOCK(childListLock);

                SIZE_T nodeIdx = 0, nodesSize = 0;
                pChildList->listSizeGet( &nodesSize );
                for(; nodeIdx!=nodesSize; ++nodeIdx)
                   {
                    cli::CiDataNode node; // ( nodes[idx] );
                    pChildList->getDataNode(node.getPP(), nodeIdx);
                    ENUM_CLI_EDATANODETYPE nodeType = node.nodeType;

                    if (nodeType!=CLI_EDATANODETYPE_ANY && nodeType!=nodeTypeCmp) continue;

                    nodeList->pushBackDataNode( node.getIfPtr() );
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getChildList) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */)
       {
        CLI_TRY{
                if (!pNodeList) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeList" );  }
                *pNodeList = pChildList;
                if (pChildList) pChildList->addRef();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(setChildList) (THIS_ INTERFACE_CLI_IDATANODELIST*    pNodeList /* [in] ::cli::iDataNodeList*  pNodeList  */)
       {
        if (pChildList)
           {
            pChildList->setParentNode(0);
            pChildList->release();
           }
        pChildList = pNodeList;

        if (pChildList)
           {
            pChildList->addRef();
            pChildList->setParentNode(this);
           }
        return EC_OK;
       }

    CLIMETHOD(swapChilds) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        CLI_TRY{
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
                INTERFACE_CLI_IDATANODELIST *rightNodeList = 0;
                pNode->getChildList( &rightNodeList );

                lockNodeEvents();
                pNode->lockNodeEvents();

                if (pChildList)
                   {
                    pChildList->setParentNode(0);
                   }

                pNode->setChildList(pChildList);

                if (pChildList)
                   {
                    pChildList->release();
                   }

                pChildList = rightNodeList;
                if (pChildList)
                   {
                    pChildList->setParentNode(this);
                   }

                unlockNodeEvents();
                pNode->unlockNodeEvents();

                pNode->generateEvent(CLI_EDATANODEEVENTMASK_CHILDSMODIFIED);
                generateEvent(CLI_EDATANODEEVENTMASK_CHILDSMODIFIED);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    RCODE callDataEvent( INTERFACE_CLI_IDATAEVENTHANDLER* pHandler, INTERFACE_CLI_IDATANODE* pDataNodeFrom, ENUM_CLI_EDATANODEEVENTMASK eventMask )
       {
        INTERFACE_CLI_IDATANODE* pRootNode = 0;
        getRootNode( &pRootNode );
        if (!pRootNode)
           {
            return pHandler->onDataEvent( pDataNodeFrom, eventMask );
           }

        ::cli::CiDataNode rootNode(pRootNode); // need for query interface
        //getRootNode( rootNode.getPP() );
        ::cli::CiDataEventsQueue dataEventQueue;
        rootNode.queryInterface( dataEventQueue.getPP() );
        if ( !dataEventQueue )
           {
            return pHandler->onDataEvent( pDataNodeFrom, eventMask );
           }
        return dataEventQueue.postEvent( pHandler, pDataNodeFrom, eventMask );
       }

    CLIMETHOD(generateEvent) (THIS_ ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */)
       {
        if (isNodeEventsLocked()) return EC_OK;

        ENUM_CLI_EDATANODEEVENTMASK handledMask = 0;
        ::std::vector< ::std::pair< INTERFACE_CLI_IDATAEVENTHANDLER*, ENUM_CLI_EDATANODEEVENTMASK > >::const_iterator evIt =  eventHandlers.begin();
        for(; evIt != eventHandlers.end(); ++evIt)
           {
            ENUM_CLI_EDATANODEEVENTMASK curMask = evIt->second & eventMask;
            if (!curMask) continue;
            handledMask |= curMask;
            callDataEvent( evIt->first, static_cast< INTERFACE_CLI_IDATANODE* >(this), curMask );
            //evIt->first->onDataEvent( static_cast< INTERFACE_CLI_IDATANODE* >(this), curMask );
           }

        if ( (eventMask&CLI_EDATANODEEVENTMASK_VALUECHANGED) && !(handledMask&CLI_EDATANODEEVENTMASK_VALUECHANGED) )
           { // value changed event not handled
            if (!(handledMask&CLI_EDATANODEEVENTMASK_CHILDVALUECHANGED))
               { // also, child value changed not taken
                eventMask |= CLI_EDATANODEEVENTMASK_CHILDVALUECHANGED;
                eventMask &= ~CLI_EDATANODEEVENTMASK_VALUECHANGED;
               }
           }

        //ENUM_CLI_EDATANODEEVENTMASK unhandledMask = eventMask
        //ENUM_CLI_EDATANODEEVENTMASK unhandledMask = eventMask & ~handledMask; // clear handled bits in eventMask
        if ( eventMask && /* unhandledMask */ parentNode)
           return parentNode->childGenerateEvent( eventMask  /* unhandledMask */  );
        return EC_OK;
       }

    //ilint_t ILVOLATILE           eventLockCounter;
    CLIMETHOD(lockNodeEvents) (THIS)
       {
        interlockedIncrement(&eventLockCounter);
        return EC_OK;
       }

    CLIMETHOD(unlockNodeEvents) (THIS)
       {
        interlockedDecrement(&eventLockCounter);
        return EC_OK;
       }

    CLIMETHOD_(BOOL, isNodeEventsLocked) (THIS)
       {
        if (eventLockCounter > 0 ) return TRUE;
        if (parentNode) return parentNode->isNodeEventsLocked();
        return FALSE;
       }

    CLIMETHOD(setParentNode) (THIS_ INTERFACE_CLI_IDATANODE*    pParentNode /* [in] ::cli::iDataNode*  pParentNode  */)
       {
        INTERFACE_CLI_IDATANODE* pPrevParentNode = parentNode;
        parentNode = pParentNode;

        if (pPrevParentNode)
           pPrevParentNode->generateEvent(CLI_EDATANODEEVENTMASK_CHILDREMOVED);
        levelNoCached = SIZE_T_NPOS; // reset cached levelNo
        if (parentNode)
           {
            parentNode->generateEvent(CLI_EDATANODEEVENTMASK_CHILDADDED);
            /*
            SIZE_T parentLevel = SIZE_T_NPOS;
            parentNode->levelNoGet(&parentLevel);
            if (parentLevel == SIZE_T_NPOS)
               levelNo = 0;
            else
               levelNo = parentLevel + 1;
            */
            //CLI_SCOPED_LOCK(childListLock);
            //if (pChildList) pChildList->setLevelNo(levelNo+1);
           }
        return EC_OK;
       }

    CLIMETHOD(getParentNode) (THIS_ INTERFACE_CLI_IDATANODE**    pParentNode /* [out] ::cli::iDataNode* pParentNode  */)
       {
        if (pParentNode) *pParentNode = parentNode;
        return EC_OK;
       }

    CLIMETHOD(getRootNode) (THIS_ INTERFACE_CLI_IDATANODE**    pRootNode /* [out] ::cli::iDataNode* pParentNode  */)
       {
        INTERFACE_CLI_IDATANODE *pRoot = this; // parentNode;
        if (!pRoot) return EC_NOT_FOUND;

        INTERFACE_CLI_IDATANODE *pRootParent = 0;
        pRoot->getParentNode(&pRootParent);
        while( pRootParent )
           {
            pRoot = pRootParent;
            pRootParent = 0;
            pRoot->getParentNode(&pRootParent);
           }
        if (pRootNode) *pRootNode = pRoot;
        return EC_OK;
       }

    CLIMETHOD(createDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                   , ENUM_CLI_EDATANODETYPE    newNodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                   , const CLISTR*     nodeName
                                   , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                              )
       {
        CLI_TRY{
                if (!pNewNode) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewNode" );  }
                *pNewNode = new CDataNodeImpl( newNodeType, stdstr(nodeName), pValue );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createDataNodeChars) (THIS_ INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                        , ENUM_CLI_EDATANODETYPE    newNodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                        , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                        , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                   )
       {
        CLI_TRY{
                if (!pNewNode) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewNode" );  }
                *pNewNode = new CDataNodeImpl( newNodeType, stdstr(nodeName), pValue );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createChildDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                        , ENUM_CLI_EDATANODETYPE    newNodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                        , const CLISTR*     nodeName
                                        , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                   )
       {
        CLI_TRY{
                if (nodeType!=CLI_EDATANODETYPE_NODE) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"nodeType!=CLI_EDATANODETYPE_NODE" );  }
                INTERFACE_CLI_IDATANODE *pNewNode = new CDataNodeImpl( newNodeType, stdstr(nodeName), pValue );
                pChildList->pushBackDataNode(pNewNode);
                pNewNode->setParentNode( this );
                if (pNewChildNode) *pNewChildNode = pNewNode;
                else pNewNode->release();
                //pNewNode->addRef();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createChildDataNodeChars) (THIS_ INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                             , ENUM_CLI_EDATANODETYPE    newNodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                             , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                             , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                        )
       {
        CLI_TRY{
                if (nodeType!=CLI_EDATANODETYPE_NODE) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"nodeType!=CLI_EDATANODETYPE_NODE" );  }
                INTERFACE_CLI_IDATANODE *pNewNode = new CDataNodeImpl( newNodeType, stdstr(nodeName), pValue );
                pChildList->pushBackDataNode(pNewNode);
                pNewNode->setParentNode( this );
                if (pNewChildNode) *pNewChildNode = pNewNode;
                else pNewNode->release();
                //pNewNode->addRef();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(cloneDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeCopy /* [out] ::cli::iDataNode* pNodeCopy  */)
       {
        CLI_TRY{
                if (!pNodeCopy) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeCopy" );  }
                CLI_SCOPED_LOCK(childListLock);
                *pNodeCopy = new CDataNodeImpl(*this);
                (*pNodeCopy)->setParentNode( 0 );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(lockChildNodes) (THIS)
       {
        childListLock.lock();
        return EC_OK;
       }

    CLIMETHOD(unlockChildNodes) (THIS)
       {
        childListLock.unlock();
        return EC_OK;
       }

    CLIMETHOD(getChildsCount) (THIS_ SIZE_T*    childsCount /* [out] size_t childsCount  */)
       {
        CLI_TRY{
                if (!childsCount) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"childsCount" );  }
                RCODE res = EC_OK;
                CLI_SCOPED_LOCK(childListLock);
                if (pChildList) res = pChildList->listSizeGet( childsCount );
                return res;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD_(SIZE_T, getChildsCountSimple) (THIS)
       {
        SIZE_T chCnt = 0;
        CLI_SCOPED_LOCK(childListLock);
        if (pChildList) pChildList->listSizeGet( &chCnt );
        return chCnt;
       }

    CLIMETHOD(getChildNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                 , SIZE_T    nodeIndex /* [in] size_t  nodeIndex  */
                            )
       {
        if (pChildList)
           {
            CLI_SCOPED_LOCK(childListLock);
            return pChildList->getDataNode( pNode, nodeIndex );
           }
        return EC_NO_OBJECT;
       }

    CLIMETHOD(insertChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                    , SIZE_T    where /* [in] size_t  where  */
                               )
       {
        if (pChildList)
           {
            if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
            pNode->setParentNode( this );
            CLI_SCOPED_LOCK(childListLock);
            return pChildList->insertDataNode( pNode, where );
           }
        return EC_NO_OBJECT;
       }

    CLIMETHOD(swapChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeNew /* [in] ::cli::iDataNode*  pNodeNew  */
                                  , SIZE_T    where /* [in] size_t  where  */
                                  , ENUM_CLI_EDATANODESWAPFLAGS    flags /* [in] ::cli::EDataNodeSwapFlags  flags  */
                                  , INTERFACE_CLI_IDATANODE**    pNodePrev /* [out,optional] ::cli::iDataNode* pNodePrev  */
                             )
       {
        if (pChildList)
           {
            //if (!pNodeNew) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeNew" );  }
            //pNode->setParentNode( this );

            INTERFACE_CLI_IDATANODE*    pNodePrevTmp = 0;
            CLI_SCOPED_LOCK(childListLock);
            RCODE tmpRes = pChildList->swapDataNode( pNodeNew, where, flags, &pNodePrevTmp );
            if (tmpRes!=EC_OK) return tmpRes;

            pNodeNew->setParentNode( this );
            pNodePrevTmp->setParentNode(0);

            if (pNodePrev)
               {
                *pNodePrev = pNodePrevTmp; // need to be released
               }
            else
               {
                if (pNodePrevTmp) pNodePrevTmp->release();
               }
            return EC_OK;
           }
        return EC_NO_OBJECT;
       }

    CLIMETHOD(pushBackChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (pChildList)
           {
            if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
            pNode->setParentNode( this );
            CLI_SCOPED_LOCK(childListLock);
            return pChildList->pushBackDataNode( pNode );
           }
        return EC_NO_OBJECT;
       }

    CLIMETHOD(getChildNodeType) (THIS_ ENUM_CLI_EDATANODETYPE*    childType /* [out] ::cli::EDataNodeType childType  */
                                     , SIZE_T    where /* [in] size_t  where  */
                                )
       {
        CLIMETHOD_IMPL_BEGIN();
        //CLIMETHOD_IMPL_CHECK_PARAM_PTR(pNode, 1);
        if (pChildList)
           {
            CLI_SCOPED_LOCK(childListLock);
            return pChildList->getNodeType( childType, where );
           }
        return EC_NO_OBJECT;
        CLIMETHOD_IMPL_END();
       }

    // ???
    #if 0
    CLIMETHOD(appendChildNodesFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, pNode);

        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( this , thisChildsLocker );
        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( pNode, nodeChildsLocker );

        ::cli::CiDataNodeList rightNodeList;
        RCODE rcRes = pNode->getChildList( rightNodeList.getPP() );
        if (rcRes) return rcRes;

        SIZE_T rightListSize = rightNodeList.listSize;
        for(SIZE_T rightChildIndex = 0; rightChildIndex!=rightListSize; ++rightChildIndex)
           {
            ::cli::CiDataNode childNode;
            rightNodeList.getDataNode(childNode.getPP(), rightChildIndex);
            pushBackChildNode(childNode.getIfPtr());
           }
        CLIMETHOD_IMPL_END();
       }
    #endif

    CLIMETHOD(moveChildNodeFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeFrom /* [in] ::cli::iDataNode*  pNodeFrom  */
                                      , SIZE_T    moveFromIdx /* [in] size_t  moveFromIdx  */
                                      , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                 )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, pNodeFrom);

        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( this     , thisChildsLocker );
        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( pNodeFrom, nodeChildsLocker );

        ::cli::CiDataNode childNode;
        RCODE rcRes = pNodeFrom->getChildNode(childNode.getPP(), moveFromIdx);
        if (rcRes) return rcRes;
        pNodeFrom->eraseChildNode( moveFromIdx );
        if (!childNode) return EC_OK;

        return insertChildNode( childNode.getIfPtr(), insertWhere );

        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(moveChildNodesByTypeFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                       , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                  )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, pNode);

        if (!moveTypes) moveTypes = CLI_EDATANODETYPE_NODE|CLI_EDATANODETYPE_ATTRIBUTE|CLI_EDATANODETYPE_TEXT;

        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( this , thisChildsLocker );
        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( pNode, nodeChildsLocker );

        SIZE_T numRightChilds = 0;
        RCODE rcRes = pNode->getChildsCount(&numRightChilds);
        if (rcRes) return EC_OK;

        SIZE_T rightChildIndex = 0;
        for(; rightChildIndex!=numRightChilds; )
           {
            ENUM_CLI_EDATANODETYPE childType = 0;
            RCODE rcRes = pNode->getChildNodeType(&childType,rightChildIndex);
            if (rcRes)
               {
                ++rightChildIndex;
                continue;
               }
            if (!(childType&moveTypes))
               {
                ++rightChildIndex; // move to next child
                continue;
               }

            moveChildNodeFrom( pNode, rightChildIndex, SIZE_T_NPOS );
            pNode->getChildsCount(&numRightChilds);
           }
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(moveChildNodesByTypeFromEx) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                               , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                               , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                          )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, pNode);

        if (!moveTypes) moveTypes = CLI_EDATANODETYPE_NODE|CLI_EDATANODETYPE_ATTRIBUTE|CLI_EDATANODETYPE_TEXT;

        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( this , thisChildsLocker );
        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( pNode, nodeChildsLocker );

        SIZE_T numRightChilds = 0;
        RCODE rcRes = pNode->getChildsCount(&numRightChilds);
        if (rcRes) return EC_OK;

        SIZE_T rightChildIndex = 0;
        for(; rightChildIndex!=numRightChilds; )
           {
            ENUM_CLI_EDATANODETYPE childType = 0;
            RCODE rcRes = pNode->getChildNodeType(&childType,rightChildIndex);
            if (rcRes)
               {
                ++rightChildIndex;
                continue;
               }
            if (!(childType&moveTypes))
               {
                ++rightChildIndex; // move to next child
                continue;
               }

            moveChildNodeFrom( pNode, rightChildIndex, insertWhere++ );
            pNode->getChildsCount(&numRightChilds);
           }
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(eraseChildNode) (THIS_ SIZE_T    where /* [in] size_t  where  */)
       {
        if (pChildList)
           {
            CLI_SCOPED_LOCK(childListLock);
            return pChildList->eraseDataNodeEx( where, TRUE );
           }
        return EC_NO_OBJECT;
       }

    CLIMETHOD(clearChilds) (THIS)
       {
        if (pChildList)
           {
            CLI_SCOPED_LOCK(childListLock);
            return pChildList->clearListEx( TRUE, 0 );
           }
        return EC_NO_OBJECT;
       }

    CLIMETHOD(clearChildsEx) (THIS_ ENUM_CLI_EDATANODETYPE    keepTypes /* [in] ::cli::EDataNodeType  keepTypes  */)
       {
        if (pChildList)
           {
            CLI_SCOPED_LOCK(childListLock);
            return pChildList->clearListEx( TRUE, keepTypes );
           }
        return EC_NO_OBJECT;
       }

    CLIMETHOD(getChildNodes) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_OUT_PTR(1, pNodeList);
        *pNodeList = 0;
        if (!pChildList) return EC_NO_OBJECT;

        CLI_SCOPED_LOCK(childListLock);
        RCODE res = pChildList->cloneNodeList( pNodeList );
        return res;

        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(childsGet) (THIS_ INTERFACE_CLI_IDATANODE**    _childs /* [out] ::cli::iDataNode* _childs  */
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                         )
       {
        CLI_TRY{
                if (!_childs) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pChild" );  }
                //if (!idx1)        { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"idx1" );  }

                if (!pChildList) return EC_OUT_OF_RANGE;
                CLI_SCOPED_LOCK(childListLock);
                RCODE res = pChildList->getDataNode( _childs, idx1 );
                if (!res) (*_childs)->release();
                return res;
                //return EC_OK;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(childsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (_size)
           {
            if (!pChildList) *_size = 0;
            else return pChildList->listSizeGet(_size);
           }
        return EC_OK;
       }

    CLIMETHOD(getChildNodeByIndex) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                        , SIZE_T    idx /* [in] size_t  idx  */
                                   )
       {
        if (!pChildList) return EC_OUT_OF_RANGE;
        CLI_SCOPED_LOCK(childListLock);
        return pChildList->getDataNode( pNode, idx );
       }


    CLIMETHOD_(BOOL, findChild) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        //INTERFACE_CLI_IDATANODE *
        if (!pChildList) return FALSE;
        CLI_SCOPED_LOCK(childListLock);
        return pChildList->findNode(pNode);
       }

    CLIMETHOD_(SIZE_T, getChildIndex) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (!pChildList) return SIZE_T_NPOS;
        CLI_SCOPED_LOCK(childListLock);
        return pChildList->getNodeIndex(pNode);
       }

    CLIMETHOD_(SIZE_T, getChildIndexByName) (THIS_ const CLISTR*     name)
       {
        if (!pChildList) return SIZE_T_NPOS;
        CLI_SCOPED_LOCK(childListLock);
        return pChildList->findNodeByName(name);
       }

    CLIMETHOD(childIndexGet) (THIS_ SIZE_T*    _childIndex /* [out] size_t _childIndex  */
                                  , const CLISTR*     idx1
                             )
       {
        CLI_TRY{
                if (!_childIndex) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pChildIndex" );  }
                if (!idx1)        { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"idx1" );  }

                *_childIndex = this->getChildIndexByNameType( idx1, CLI_EDATANODETYPE_NODE );
                //return EC_OK;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(childIndexSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(attrIndexGet) (THIS_ SIZE_T*    _attrIndex /* [out] size_t _attrIndex  */
                                 , const CLISTR*     idx1
                            )
       {
        CLI_TRY{
                if (!_attrIndex) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pAttrIndex" );  }
                if (!idx1)        { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"idx1" );  }

                *_attrIndex = this->getChildIndexByNameType( idx1, CLI_EDATANODETYPE_ATTRIBUTE );
                //return EC_OK;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(attrIndexSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD_(SIZE_T, getChildIndexByNameType) (THIS_ const CLISTR*     name
                                                     , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                )
       {
        if (!pChildList) return SIZE_T_NPOS;
        CLI_SCOPED_LOCK(childListLock);
        return pChildList->findNodeByNameType(name, type);
       }

    CLIMETHOD_(SIZE_T, getChildIndexByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        if (!pChildList) return SIZE_T_NPOS;
        CLI_SCOPED_LOCK(childListLock);
        return pChildList->findNodeByNameChars(name);
       }

    CLIMETHOD_(SIZE_T, getChildIndexByNameTypeChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                          , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                     )
       {
        if (!pChildList) return SIZE_T_NPOS;
        CLI_SCOPED_LOCK(childListLock);
        return pChildList->findNodeByNameTypeChars(name,type);
       }

    CLIMETHOD(getNextSibling) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeSibling /* [out] ::cli::iDataNode* pNode  */)
       {
        if (!parentNode) return EC_NO_SUCH_OBJECT; // no parent - no sibling
        CLI_SCOPED_LOCK(childListLock);
        SIZE_T selfIdx = parentNode->getChildIndex( static_cast<INTERFACE_CLI_IDATANODE*>(this) );
        if (selfIdx==SIZE_T_NPOS) return EC_OUT_OF_RANGE; // this node is unknown in parent - is it realy child?
        return parentNode->getChildNodeByIndex( pNodeSibling, selfIdx+1 );
       }

    CLIMETHOD(getPrevSibling) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeSibling /* [out] ::cli::iDataNode* pNode  */)
       {
        if (!parentNode) return EC_NO_SUCH_OBJECT; // no parent - no sibling
        CLI_SCOPED_LOCK(childListLock);
        SIZE_T selfIdx = parentNode->getChildIndex( static_cast<INTERFACE_CLI_IDATANODE*>(this) );
        if (selfIdx==SIZE_T_NPOS) return EC_OUT_OF_RANGE; // this node is unknown in parent - is it realy child?
        if (!selfIdx) return EC_OUT_OF_RANGE; // we are the first child, no prev childs at all
        return parentNode->getChildNodeByIndex( pNodeSibling, selfIdx-1 );
       }

    CLIMETHOD(nodeTypeGet) (THIS_ ENUM_CLI_EDATANODETYPE*    _nodeType /* [out] ::cli::EDataNodeType _nodeType  */)
       {
        if (_nodeType) *_nodeType = nodeType;
        return EC_OK;
       }

    CLIMETHOD(nodeTypeSet) (THIS_ ENUM_CLI_EDATANODETYPE    _nodeType /* [in] ::cli::EDataNodeType  _nodeType  */)
       {
        bool typeChanged = (nodeType != _nodeType);
        nodeType = _nodeType;
        if (typeChanged)
           {
            if (nodeType==CLI_EDATANODETYPE_NODE)
               {
                if (!pChildList) pChildList = new CDataNodeListImpl();
               }
            if (nodeType==CLI_EDATANODETYPE_ATTRIBUTE || nodeType==CLI_EDATANODETYPE_TEXT)
               {
                if (pChildList) pChildList->release();
                pChildList = 0;
               }
           }
        return EC_OK;
       }

    CLIMETHOD(nodeNameGet) (THIS_ CLISTR*           _nodeName)
       {
        return ::cli::propertyGetImpl( _nodeName, nodeName );
       }

    CLIMETHOD(nodeNameSet) (THIS_ const CLISTR*     _nodeName)
       {
        return ::cli::propertySetImpl( _nodeName, nodeName );
       }

    CLIMETHOD(getDataNodeValue) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    _pValue /* [out] ::cli::iReadOnlyVariant* pValue  */)
       {
        if (_pValue)
           {
            if (pValue)
                pValue->queryInterface( INTERFACE_CLI_IREADONLYVARIANT_IID, (VOID**)_pValue );
            else
                *_pValue = 0;
           }
        return EC_OK;
       }

    CLIMETHOD_(BOOL, hasValue) (THIS_ BOOL    emptyAsNoValue /* [in] bool  emptyAsNoValue  */)
       {
        if (!pValue) return FALSE;
        if (pValue->getType()==CLI_VARIANTTYPE_VT_EMPTY && emptyAsNoValue!=FALSE) return FALSE;
        return TRUE;
       }

    CLIMETHOD_(BOOL, compareName) (THIS_ const CLISTR*     name)
       {
        ::std::wstring strName = stdstr(name);
        if (strName==L"*") return TRUE;
        if (strName==nodeName) return TRUE;
        return FALSE;
       }

    CLIMETHOD_(BOOL, compareNameType) (THIS_ const CLISTR*     name
                                           , ENUM_CLI_EDATANODETYPE    _nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                      )
       {
        if (_nodeType!=CLI_EDATANODETYPE_ANY && _nodeType!=nodeType) return FALSE;
        ::std::wstring strName = stdstr(name);
        if (strName==L"*") return TRUE;
        if (strName==nodeName) return TRUE;
        return FALSE;
       }

    CLIMETHOD_(BOOL, compareNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        CLI_TRY{
                if (!name) return FALSE;
                if (*name==L'*' && !*(name+1)) return TRUE;
                //::std::wstring strName = stdstr(name);
                //if (strName==L"*") return TRUE;
                //if (strName==nodeName) return TRUE;
                if (nodeName==name) return TRUE;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return FALSE;
       }

    CLIMETHOD_(BOOL, compareNameTypeChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                , ENUM_CLI_EDATANODETYPE    _nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                           )
       {
        if (_nodeType!=CLI_EDATANODETYPE_ANY && _nodeType!=nodeType) return FALSE;
        CLI_TRY{
                if (!name) return FALSE;
                if (*name==L'*' && !*(name+1)) return TRUE;
                //::std::wstring strName = stdstr(name);
                //if (strName==L"*") return TRUE;
                //if (strName==nodeName) return TRUE;
                if (nodeName==name) return TRUE;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return FALSE;
       }




    struct CAutoCreateValueGuard
       {
        CDataNodeImpl *pNodeImpl;
        CAutoCreateValueGuard( CDataNodeImpl *_pNodeImpl ) : pNodeImpl(_pNodeImpl)
           {
            if (pNodeImpl && !pNodeImpl->pValue)
               {
                #if defined(CLI_STANDALONE_CLIPONENTS_DATADOM)
                cliCreateObject( "/cli/variant", INTERFACE_CLI_IVARIANT_IID, 0, (GENERIC_OBJ_PTR*)&(pNodeImpl->pValue) );
                #else
                pNodeImpl->pValue = new CVariantFreeImpl();
                #endif
               }
           }
        ~CAutoCreateValueGuard()
           {
           }
       }; // CValueModifyEventGeneratorGuard

    struct CValueModifyEventGeneratorGuard : public CAutoCreateValueGuard
       {
        //CDataNodeImpl *pNodevalueOwner;
        CValueModifyEventGeneratorGuard( CDataNodeImpl *_pNodeImpl ) : CAutoCreateValueGuard(_pNodeImpl)
           {
           }
        ~CValueModifyEventGeneratorGuard()
           {
            if (pNodeImpl)
               {
                pNodeImpl->putStamp(); // stamp this
                pNodeImpl->generateEvent(CLI_EDATANODEEVENTMASK_VALUECHANGED);
               }
           }
       }; // CValueModifyEventGeneratorGuard


    CLIMETHOD_(ENUM_CLI_VARIANTTYPE, getValueType) (THIS)
       {
        if (pValue) return pValue->getType( );
        return CLI_VARIANTTYPE_VT_EMPTY;
       }

    CLIMETHOD(setValue) (THIS_ INTERFACE_CLI_IVARIANT*    _pValue /* [in] ::cli::iVariant*  pValue  */)
       {
        CLI_TRY{
                if (!_pValue) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pValue" );  }
                CValueModifyEventGeneratorGuard guard(this);
                if (pValue) pValue->release();
                pValue = _pValue;
                pValue->addRef();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(setValueCopy) (THIS_ INTERFACE_CLI_IVARIANT*    _pValue /* [in] ::cli::iVariant*  pValue  */)
       {
        CLI_TRY{
                if (!_pValue) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pValue" );  }
                CValueModifyEventGeneratorGuard guard(this);
                if (pValue) pValue->release();
                pValue = 0;
                _pValue->cloneVariant( &pValue );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(setValueToNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (pNode)
           pNode->setValue(pValue);
        return EC_OK;
       }

    CLIMETHOD(setValueToNodeCopy) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (pNode)
           pNode->setValueCopy(pValue);
        return EC_OK;
       }

    CLIMETHOD(copyValueToNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        CLI_TRY{
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
                if (!pValue)
                   {
                    pNode->removeValue();
                   }
                else
                   {
                    pNode->setValueCopy(pValue);
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(removeValue) (THIS)
       {
        if (pValue)
           {
            CValueModifyEventGeneratorGuard guard(this);
            pValue->release();
            pValue = 0;
           }
        return EC_OK;
       }

    CLIMETHOD(setEmpty) (THIS)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setEmpty( );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setChar) (THIS_ CHAR    ch /* [in] char  ch  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setChar( ch );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setWChar) (THIS_ WCHAR    wch /* [in] wchar  wch  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setWChar( wch );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setShort) (THIS_ SHORT    s /* [in] short  s  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setShort( s );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setUShort) (THIS_ USHORT    us /* [in] ushort  us  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setUShort( us );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setInt) (THIS_ INT    i /* [in] int  i  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setInt( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setUInt) (THIS_ UINT    i /* [in] uint  i  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setUInt( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setColorref) (THIS_ COLORREF    i /* [in] colorref  i  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setColorref( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setInt64) (THIS_ INT64    i /* [in] int64  i  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setInt64( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setUInt64) (THIS_ UINT64    i /* [in] uint64  i  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setUInt64( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setIntPtr) (THIS_ INT_PTR    i /* [in] int_ptr  i  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setIntPtr( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setUIntPtr) (THIS_ UINT_PTR    i /* [in] uint_ptr  i  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setUIntPtr( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setFloat) (THIS_ FLOAT    f /* [in] float  f  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setFloat( f );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setDouble) (THIS_ DOUBLE    d /* [in] double  d  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setDouble( d );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setPtr) (THIS_ const VOID*    vptr /* [in] void*  vptr  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setPtr( vptr );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setString) (THIS_ const CLISTR*     str)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setString( str );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setStringPStr) (THIS_ CLIPSTR           str)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setStringPStr( str );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setStringChars) (THIS_ const WCHAR*    str /* [in,flat] wchar  str[]  */
                                   , SIZE_T    strSize /* [in] size_t  strSize  */
                              )
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setStringChars( str, strSize );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setDump) (THIS_ const BYTE*    d /* [in,flat] byte  d[]  */
                            , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                       )
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setDump( d, dumpSize );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setDate) (THIS_ const ::cli::CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setDate( datetime );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(setBool) (THIS_ BOOL    b /* [in] bool  b  */)
       {
        CValueModifyEventGeneratorGuard guard(this);
        if (pValue) return pValue->setBool( b );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getChar) (THIS_ CHAR*    ch /* [out] char ch  */)
       {
        if (pValue) return pValue->getChar( ch );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getWChar) (THIS_ WCHAR*    wch /* [out] wchar wch  */)
       {
        if (pValue) return pValue->getWChar( wch );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getShort) (THIS_ SHORT*    s /* [out] short s  */)
       {
        if (pValue) return pValue->getShort( s );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getUShort) (THIS_ USHORT*    us /* [out] ushort us  */)
       {
        if (pValue) return pValue->getUShort( us );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getInt) (THIS_ INT*    i /* [out] int i  */)
       {
        if (pValue) return pValue->getInt( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getUInt) (THIS_ UINT*    i /* [out] uint i  */)
       {
        if (pValue) return pValue->getUInt( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getColorref) (THIS_ COLORREF*    i /* [out] colorref i  */)
       {
        if (pValue) return pValue->getColorref( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getInt64) (THIS_ INT64*    i /* [out] int64 i  */)
       {
        if (pValue) return pValue->getInt64( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getUInt64) (THIS_ UINT64*    i /* [out] uint64 i  */)
       {
        if (pValue) return pValue->getUInt64( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getIntPtr) (THIS_ INT_PTR*    i /* [out] int_ptr i  */)
       {
        if (pValue) return pValue->getIntPtr( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getUIntPtr) (THIS_ UINT_PTR*    i /* [out] uint_ptr i  */)
       {
        if (pValue) return pValue->getUIntPtr( i );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getFloat) (THIS_ FLOAT*    f /* [out] float f  */)
       {
        if (pValue) return pValue->getFloat( f );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getDouble) (THIS_ DOUBLE*    d /* [out] double d  */)
       {
        if (pValue) return pValue->getDouble( d );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getPtr) (THIS_ VOID**    vptr /* [out] void* vptr  */)
       {
        if (pValue) return pValue->getPtr( vptr );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getString) (THIS_ CLISTR*           str)
       {
        if (pValue) return pValue->getString( str );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getText) (THIS_ BOOL    fRecurse /* [in] bool  allText  */
                            , CLISTR*           str
                       )
       {
        if (nodeType!=CLI_EDATANODETYPE_NODE && nodeType!=CLI_EDATANODETYPE_TEXT)
           {
            return ::cli::propertyGetImpl( str, ::std::wstring() );
           }
        else
           {
            ::std::wstring allText;
            if (pValue)
               {
                ::cli::CiVariant_tmp tmp(pValue);
                tmp.getString(allText);
               }
            if (nodeType==CLI_EDATANODETYPE_NODE && fRecurse && pChildList)
               {
                ::cli::CiDataNodeList_tmp tmp(pChildList);
                ::std::wstring childsText;
                tmp.getText(childsText);
                allText += childsText;
               }
            return ::cli::propertyGetImpl( str, allText );
           }
       }

    CLIMETHOD(objectValueToString) (THIS_ CLISTR*           str)
       {
        if (pValue) return pValue->getString( str );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getStringPStr) (THIS_ CLIPSTR*          str)
       {
        if (pValue) return pValue->getStringPStr( str );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getStringChars) (THIS_ WCHAR*    buf /* [out,flat] wchar buf[]  */
                                   , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                              )
       {
        if (pValue) return pValue->getStringChars( buf, bufSize );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getDump) (THIS_ CLIPCSTR*         str)
       {
        if (pValue) return pValue->getDump( str );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getDate) (THIS_ ::cli::CLISYSTEMTIME*    datetime /* [out] ::cli::CLISYSTEMTIME datetime  */)
       {
        if (pValue) return pValue->getDate( datetime );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(getBool) (THIS_ BOOL*    b /* [out] bool b  */)
       {
        if (pValue) return pValue->getBool( b );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(serializeValueSimple) (THIS_ CLISTR*           str)
       {
        if (pValue) return pValue->serializeSimple( str );
        else return EC_OK; // EC_DELEGATION_FAILED;
       }

    CLIMETHOD(serializeValueAdvanced) (THIS_ CLISTR*           str)
       {
        if (pValue) return pValue->serializeAdvanced( str );
        else return EC_OK; // EC_DELEGATION_FAILED;
       }

    CLIMETHOD(serializeValueAdvancedSeparate) (THIS_ CLISTR*           strValue
                                                   , CLISTR*           strType
                                              )
       {
        if (pValue) return pValue->serializeAdvancedSeparate( strValue, strType );
        else return EC_OK; // EC_DELEGATION_FAILED;
       }

    CLIMETHOD(deserializeValueSimple) (THIS_ const CLISTR*     str)
       {
        if (!str || !str->stringSize || !str->pData ) return EC_OK; // empty value
        CAutoCreateValueGuard guard(this);
        if (pValue) return pValue->deserializeSimple( str );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(deserializeValueAdvanced) (THIS_ const CLISTR*     str)
       {
        if (!str || !str->stringSize || !str->pData ) return EC_OK; // empty value
        CAutoCreateValueGuard guard(this);
        if (pValue) return pValue->deserializeAdvanced( str );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(deserializeValueAdvancedSeparate) (THIS_ const CLISTR*     strValue
                                                     , const CLISTR*     strType
                                                )
       {
        if (!strValue || !strValue->stringSize || !strValue->pData ) return EC_OK; // empty value
        CAutoCreateValueGuard guard(this);
        if (pValue) return pValue->deserializeAdvancedSeparate( strValue, strType );
        else return EC_DELEGATION_FAILED;
       }

    CLIMETHOD(serializeXml) (THIS_ CLICSTR*          strTo
                                 , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                            )
       {
        pugi::xml_document doc;

        pugi::xml_node pugiNode = doc.append_child(pugi::node_element);
        // generate XML Dom here
        serializeToXmlNode( pugiNode, this, flags );

        // yes - parse_cdata|parse_ws_pcdata|parse_wnorm_attribute|parse_wconv_attribute
        // no  - parse_escapes|parse_eol
        // const unsigned int parse_default            = parse_cdata | parse_escapes | parse_wconv_attribute | parse_eol;
        unsigned int pugiFlags = pugi::parse_cdata|pugi::parse_ws_pcdata|pugi::parse_wnorm_attribute|pugi::parse_wconv_attribute; // 0;
        if (flags&CLI_EDATANODESERIALIZEFLAG_WRITEBOM)           pugiFlags |= pugi::format_write_bom_utf8;
        if (flags&CLI_EDATANODESERIALIZEFLAG_NOXMLDECLARATION)   pugiFlags |= pugi::format_no_declaration;
        if (flags&CLI_EDATANODESERIALIZEFLAG_WRITECONDENCED)     pugiFlags |= pugi::format_raw;
        else                                                     pugiFlags |= pugi::format_indent;

        ::std::string xmlString;
        //xml_string_writer
        ::sixml::serializer::pugi_helpers::xml_string_writer stringWriter(xmlString);
        //pugi::xml_parse_result parseResult =
        doc.save( stringWriter, (flags&CLI_EDATANODESERIALIZEFLAG_WRITECONDENCED ? "" : "    "), pugiFlags);

        ::std::string replaceTo = "<?xml version=\"1.0\" encoding=\"UTF-8\"";
        if (flags&CLI_EDATANODESERIALIZEFLAG_XMLSTANDALONE) replaceTo.append(" standalone=\"yes\"");
        replaceTo.append(" ?>");
        if (flags&CLI_EDATANODESERIALIZEFLAG_NOXMLDECLARATION) replaceTo.clear();
        ::sixml::helpers::replaceFirstInplace( xmlString, "<?xml version=\"1.0\"?>", replaceTo);

        return ::cli::propertyGetImpl( strTo, xmlString );
       }

    bool hasBom( const char *data, size_t size )
       {
        if (!data || !size) return false;
        if (   size>=3
            && ((unsigned char)data[0])==0xEF
            && ((unsigned char)data[1])==0xBB
            && ((unsigned char)data[2])==0xBF
           ) return true; // UTF-8
        if (   size>=2
            && ((unsigned char)data[0])==0xFE
            && ((unsigned char)data[1])==0xFF
           ) return true; // UTF-16BE
        if (   size>=2
            && ((unsigned char)data[0])==0xFF
            && ((unsigned char)data[1])==0xFE
           ) return true; // UTF-16LE
        if (   size>=4
            && ((unsigned char)data[0])==0x00
            && ((unsigned char)data[1])==0x00
            && ((unsigned char)data[2])==0xFE
            && ((unsigned char)data[3])==0xFF
           ) return true; //
        if (   size>=4
            && ((unsigned char)data[0])==0xFF
            && ((unsigned char)data[1])==0xFE
            && ((unsigned char)data[2])==0x00
            && ((unsigned char)data[3])==0x00
           ) return true; //

        return false;
       }

    CLIMETHOD(deserializeXmlBuf) (THIS_ const CHAR*    buf /* [in,flat] byte  buf[]  */
                                      , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                      , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                 )
       {
        CLI_TRY{
                if (!buf || !bufSize) return EC_XML_DOCUMENT_EMPTY;

                SIZE_T resBomSize = 0;
                ENUM_CLI_EBOMTYPE resBomType = ::cli::detectEncodingBomImplementation((const char*)buf,bufSize,resBomSize);

                if (resBomType!=CLI_EBOMTYPE_BOMNONE && resBomType!=CLI_EBOMTYPE_BOMUTF8) return EC_DOCUMENT_UNSUPPORTED_UTF_ENCODING;

                char* strCopy = 0;

                if (resBomType==CLI_EBOMTYPE_BOMNONE)
                   {
                    if (bufSize>5 && strncmp( buf, "<?xml", 5 )!=0)
                       { // no xml declaration
                        static const char *xmlDeclaration = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n";
                        SIZE_T xmlDeclarationLen = (SIZE_T)strlen(xmlDeclaration);
                        strCopy = new char[xmlDeclarationLen + bufSize + 1];
                        memcpy( (void*) strCopy                   , (const void*)xmlDeclaration, xmlDeclarationLen );
                        memcpy( (void*)(strCopy+xmlDeclarationLen), (const void*)buf           , bufSize           );
                        strCopy[xmlDeclarationLen + bufSize] = 0;
                       }
                    else // found xml declaration
                       {
                       }
                   }

                if (!strCopy)
                   {
                    strCopy = new char[bufSize + 1];
                    memcpy( (void*)strCopy, (const void*)buf, bufSize );
                    strCopy[bufSize] = 0;
                   }

                /*
                // add BOM
                if (!hasBom( strXml->pData, strXml->stringSize ) && (strXml->stringSize>5 && 0!=strncmp( strXml->pData, "<?xml", 5 )))
                   {
                    ::std::string xmlString = ::std::string("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n") + stdstr(strXml);
                    size_t xmlStringSize = xmlString.size();
                    strCopy = new char[xmlStringSize+1];
                    xmlString.copy( strCopy, xmlStringSize );
                    strCopy[xmlStringSize] = 0;
                   }
                else
                   {
                    strCopy = new char[strXml->stringSize+1];
                    memcpy( (void*)strCopy, (const void*)strXml->pData, strXml->stringSize );
                    strCopy[strXml->stringSize] = 0;
                   }
                */

                // yes - parse_cdata|parse_ws_pcdata|parse_wnorm_attribute|parse_wconv_attribute
                // no  - parse_escapes|parse_eol
                // const unsigned int parse_default            = parse_cdata | parse_escapes | parse_wconv_attribute | parse_eol;
                unsigned int pugiFlags = pugi::parse_pi|pugi::parse_cdata|pugi::parse_ws_pcdata|pugi::parse_wnorm_attribute|pugi::parse_wconv_attribute|pugi::parse_declaration; // 0;
                pugi::xml_document doc;
                pugi::xml_parse_result parseResult = doc.parse( pugi::transfer_ownership_tag(), strCopy
                                                              , pugiFlags
                                                              /*pugi::parse_pi  | pugi::parse_cdata | pugi::parse_escapes
                                                              | pugi::parse_eol | pugi::parse_wnorm_attribute
                                                              | pugi::parse_wconv_attribute | pugi::parse_declaration*/
                                                              );
                if (parseResult.status!=pugi::status_ok)
                   {
                    int line = 0, pos = 0;
                    ::sixml::serializer::pugi_helpers::getLinePos( strCopy /* stdstr(strXml) */ , parseResult.offset, line, pos);
                    ::sixml::throw_parse_error( ::sixml::serializer::pugi_helpers::pugi2rcode(parseResult.status)
                                              , line, pos );  /* no line pos info provided */
                   }

                pugi::xml_node rootNode = doc.root();

                std::wstring documentEncodingName;
                std::wstring documentXmlVersion;

                bool stopLookupForEncoding = false;
                // looking for <?xml ...> to find encoding
                for(pugi::xml_node node = rootNode.first_child(); node && !stopLookupForEncoding; node = node.next_sibling())
                   {
                    if (node.type()==pugi::node_declaration)
                       {
                        pugi::xml_node xmlNode = node;

                        for (pugi::xml_attribute a = xmlNode.first_attribute(); a; a = a.next_attribute())
                            {
                             const char* attrName = a.name();
                             if (!attrName) continue;

                             std::wstring wstrAttrName  = MARTY_UTF::fromUtf8(attrName);
                             if (wstrAttrName==L"version")
                                {
                                 documentXmlVersion = getAttributeValueHelperRaw( a, flags );
                                 continue;
                                }

                             if (wstrAttrName!=L"encoding") continue;

                             documentEncodingName = getAttributeValueHelperRaw( a, flags );
                             stopLookupForEncoding = true;
                             break;
                            }
                       }
                   }

                if (documentEncodingName.empty()) documentEncodingName = L"utf-8";
                if (resBomType==CLI_EBOMTYPE_BOMUTF8) documentEncodingName = L"utf-8";
                //::cli::propertySetImpl( documentEncodingName, encodingName );

                ::cli::CiStringEncoderManager encMan("/cli/string-encman");
                ::cli::CiStringSpecialEncoder specialEncoderText("/cli/string-special-encoder/html-text");
                ::cli::CiStringSpecialEncoder specialEncoderAttr("/cli/string-special-encoder/html-attr");

                UINT encId = 0;
                if (encMan.getEncodingIdByName(documentEncodingName, &encId))
                   {
                    throw ::cli::CException( false, EC_XML_HTML_UNKNOWN_ENCODING, __FILE__, __LINE__, ::cli::format::arg( documentEncodingName ) );
                   }

                ::cli::CiStringEncoder encoder;
                RCODE geRes = encMan.getStringEncoder(encId, encoder.getPP());
                if (geRes)
                   {
                    throw ::cli::CException( false, geRes, __FILE__, __LINE__ /* , ::cli::format::arg( documentEncodingName ) */  );
                   }

                specialEncoderText.defEncoder = encoder.getIfPtr();
                specialEncoderAttr.defEncoder = encoder.getIfPtr();


                for(pugi::xml_node node = rootNode.first_child(); node; node = node.next_sibling())
                   {
                    if (node.type()==pugi::node_element)
                       {
                        rootNode = node;
                        break;
                       }
                   }

                if (flags&CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME)
                   {
                    ::std::wstring rootTagName = MARTY_UTF::fromUtf8(rootNode.name());
                    ::cli::propertySetImpl( rootTagName, nodeName );
                   }

                clearChilds();

                if (parentNode)
                   {
                    ::cli::CiDataNode pn(parentNode);
                    ::cli::CiDataRoot rootNode;
                    if (!pn.queryInterface(rootNode.getPP()) && !!rootNode)
                       {
                        rootNode.encodingName = encMan.encodingCanonicalName[encId];
                        if (!documentXmlVersion.empty())
                           rootNode.xmlVersion   = documentXmlVersion;
                       }
                   }

                deserializeFromXmlNode( specialEncoderText, specialEncoderAttr, rootNode, this, flags );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(deserializeXml) (THIS_ const CLICSTR*    strXml
                                   , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                              )
       { // CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME

        CLI_TRY{
                if (!strXml) return EC_XML_DOCUMENT_EMPTY;
                return deserializeXmlBuf( strXml->pData
                                        , strXml->stringSize
                                        , flags
                                        );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(buildXPathQueryVarMapSpec) (THIS_ INTERFACE_CLI_IVARIANTMAP*    pVarMapSpec /* [in] ::cli::iVariantMap*  pVarMapSpec  */
                                              , ENUM_CLI_EXPATHEXPRESSIONFLAGS  flags   /* [in] ::cli::EXPathExpressionFlags  flags  */
                                              , CLISTR*           query
                                         )
       {
        //::std::vector< ::std::wstring > queryTmp;
        //CiDataNode_tmp tmp( static_cast<INTERFACE_CLI_IDATANODE>(this) );

        ::std::wstring queryTmp;

        if (parentNode)
           {
            ::cli::CiDataNode_tmp parentTmp( parentNode );
            bool buildParentPath = true;
            if (pVarMapSpec)
               {
                ::cli::CiVariantMap_tmp varMapTmp(pVarMapSpec);
                ::std::wstring parentName = parentTmp.nodeName;
                ::std::wstring specStr;
                  {
                   ::cli::CiVariant specVariant;
                   varMapTmp.queryValueByName( parentName, specVariant.getPP() );
                   if (!!specVariant)
                      specVariant.getString(specStr);
                  }
                ::std::vector< ::std::wstring > spec;
                ::cli::util::splitString( specStr, spec, ::cli::util::CIsExactChar< wchar_t, L','>() );
                ::std::vector< ::std::wstring >::const_iterator specIt = spec.begin();
                for(; specIt != spec.end(); ++specIt)
                   {
                    if (*specIt==L"!")
                       {
                        buildParentPath = false;
                        break;
                       }
                   }
               }

            if (buildParentPath)
               parentTmp.buildXPathQueryVarMapSpec( pVarMapSpec, flags, queryTmp );
           }

        if (!nodeName.empty())
           {
            if (!queryTmp.empty() && queryTmp[queryTmp.size()-1]!=L'/' )
               queryTmp.append(1,L'/');
            if ((flags&CLI_EXPATHEXPRESSIONFLAGS_EXPRSHORT))
               queryTmp.append( L"child::" );
            queryTmp.append( nodeName );
            if (pVarMapSpec) // spec taken
               {
                ::cli::CiVariantMap_tmp varMapTmp(pVarMapSpec);
                // get spec for current node
                ::std::wstring specStr;
                  {
                   ::cli::CiVariant specVariant;
                   varMapTmp.queryValueByName( nodeName, specVariant.getPP() );
                   if (!!specVariant)
                      specVariant.getString(specStr);
                  }

                ::std::wstring predicateStr;
                if (pChildList)
                   {
                    ::cli::CiDataNodeList_tmp childList(pChildList);
                    ::std::vector< ::std::wstring > spec;
                    ::cli::util::splitString( specStr, spec, ::cli::util::CIsExactChar< wchar_t, L','>() );
                    ::std::vector< ::std::wstring >::const_iterator specIt = spec.begin();
                    for(; specIt != spec.end(); ++specIt)
                       {
                        if (specIt->empty()) continue;
                        bool isSpecAttr = (*specIt)[0]==L'@' ? true : false;
                        ::std::wstring singleSpec( *specIt, isSpecAttr ? 1 : 0, specIt->npos );
                        SIZE_T childIdx = childList.findNodeByNameType( singleSpec, isSpecAttr ? CLI_EDATANODETYPE_ATTRIBUTE : CLI_EDATANODETYPE_NODE );
                        if (childIdx==SIZE_T_NPOS) continue;

                        //::cli::CiVariant childVariant;
                        cli::CiReadOnlyVariant childVariant;
                        childList.getDataNodeValue( childVariant.getPP(), childIdx );
                        if (!childVariant) continue; // no value (null variant), simple skip. NOTE: can be changed

                        //attribute::node()

                        ENUM_CLI_VARIANTTYPE childVt = childVariant.getType();
                        ::std::wstring childStrValue;
                        childVariant.getString(childStrValue);

                        if (!predicateStr.empty())
                           predicateStr.append(L" and ");

                        if ((flags&CLI_EXPATHEXPRESSIONFLAGS_EXPRSHORT))
                           {
                            if (isSpecAttr) queryTmp.append( L"attribute::" );
                            else            queryTmp.append( L"child::" );
                           }
                        predicateStr.append(*specIt);
                        predicateStr.append(1, L'=');

                        if (childVt>=CLI_VARIANTTYPE_VT_SHORT && childVt<=CLI_VARIANTTYPE_VT_UINT64)
                           {
                            predicateStr.append(childStrValue);
                           }
                        else
                           {
                            predicateStr.append(1, L'\'');
                            predicateStr.append(childStrValue);
                            predicateStr.append(1, L'\'');
                           }
                       }
                   }
                if (!predicateStr.empty())
                   {
                    queryTmp.append(1,L'[');
                    queryTmp.append(predicateStr);
                    queryTmp.append(1,L']');
                   }
               }
           }
        return ::cli::propertyGetImpl( query, queryTmp );
       }

    CLIMETHOD(buildXPathQueryStringSpec) (THIS_ const CLISTR*     strSpec
                                              , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                              , CLISTR*           query
                                         )
       {
        CLI_TRY{
                if (!query) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"query" );  }
                return buildXPathQueryStringSpecImpl( stdstr(strSpec), flags, query );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(buildXPathQueryStringSpecChars) (THIS_ const WCHAR*    strSpec /* [in,flat] wchar  strSpec[]  */
                                                   , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                                   , CLISTR*           query
                                              )
       {
        CLI_TRY{
                if (!query) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"query" );  }
                return buildXPathQueryStringSpecImpl( stdstr(strSpec), flags, query );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(buildXPathQueryStringSpecImpl) (THIS_ const ::std::wstring &strSpec
                                                   , ENUM_CLI_EXPATHEXPRESSIONFLAGS    flags /* [in] ::cli::EXPathExpressionFlags  flags  */
                                              , CLISTR*           query
                                             )
       {
        ::cli::CiVariantMap varMap( "/cli/varmap" );

        ::std::vector< ::std::wstring > specVec;
        ::cli::util::splitString( strSpec, specVec, ::cli::util::CIsExactChar< wchar_t, L';'>() );
        ::std::vector< ::std::wstring >::const_iterator specIt = specVec.begin();
        for(; specIt != specVec.end(); ++specIt)
           {
            ::std::wstring key, val;
            ::cli::util::splitToPair( *specIt, ::std::wstring(L":"), key, val );

            ::cli::CiVariant variant( cliGetVariant( ), true  /* noAddRef */  );
            variant.setString(val);
            varMap.insertValue( key, TRUE, FALSE, variant.getIfPtr() );
           }
        return buildXPathQueryVarMapSpec( varMap.getIfPtr(), flags, query );
       }

    CLI_TIME_T createStampConst() const
       {
        return ::cli::CDateTime::now();
       }

    CLIMETHOD_(CLI_TIME_T, createStamp) (THIS)
       {
        return createStampConst();
       }

    CLIMETHOD(putStamp) (THIS)
       {
        stamp = createStamp();
        return EC_OK;
       }

    CLIMETHOD(putStampEx) (THIS_ CLI_TIME_T    st /* [in] cli_time_t  st  */)
       {
        stamp = st;
        return EC_OK;
       }

    CLIMETHOD_(CLI_TIME_T, getStamp) (THIS)
       {
        return stamp;
       }

    CLI_TIME_T getStamp() const
       {
        return stamp;
       }

}; // struct CDataNodeImpl






struct CDataRootImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                     //, public INTERFACE_CLI_IDATANODE
                     , public CEventListImpl
                     , public INTERFACE_CLI_IVARIANTCONVERT
                     , public INTERFACE_CLI_IDATAEVENTSQUEUE
                     , public INTERFACE_CLI_IDATAROOT
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    struct CEventTriple
    {
     INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler;
     INTERFACE_CLI_IDATANODE*            pDataNodeFrom;
     ENUM_CLI_EDATANODEEVENTMASK         eventMask;
     CEventTriple()
        : pHandler(0)
        , pDataNodeFrom(0)
        , eventMask(0)
        {}
     CEventTriple( INTERFACE_CLI_IDATAEVENTHANDLER* ph
                 , INTERFACE_CLI_IDATANODE* pdn
                 , ENUM_CLI_EDATANODEEVENTMASK em
                 )
        : pHandler(ph)
        , pDataNodeFrom(pdn)
        , eventMask(em)
        {}
    };

    //::std::vector<INTERFACE_CLI_IDATANODE*>   nodes;
    INTERFACE_CLI_IDATANODE     *pChild;
    ilint_t ILVOLATILE           eventLockCounter;
    CCriticalSection             eventQueueLock;
    ::std::deque< CEventTriple > eventQueue;
    BOOL                         mergeEvents;
    BOOL                         queueEnabled;

    SIZE_T                       inputStreamId;
    SIZE_T                       streamId;

    std::wstring                 encodingName;
    std::wstring                 xmlVersion;

/*
    CLIMETHOD(lockChildNodes) (THIS)
       {
        childListLock.lock();
        return EC_OK;
       }

    CLIMETHOD(unlockChildNodes) (THIS)
       {
        childListLock.unlock();
        return EC_OK;
       }
*/

    //ENUM_CLI_EDATANODETYPE       nodeType;
    //::std::wstring               nodeName;
    //INTERFACE_CLI_IVARIANT      *pValue;
    //CCriticalSection             childListLock;
    //INTERFACE_CLI_IDATANODE                  *parentNode;


    CDataRootImpl() : base_impl(DEF_MODULE)
                    , CEventListImpl()
                    , pChild( 0 )
                    , eventLockCounter(0)
                    , eventQueueLock()
                    , eventQueue()
                    , mergeEvents(1)
                    , queueEnabled(0)
                    , inputStreamId(SIZE_T_NPOS)
                    , streamId(SIZE_T_NPOS)
                    , encodingName()
                    , xmlVersion()
       {
        //getEntityToCharMap();
       }
/*
    CDataNodeImpl(ENUM_CLI_EDATANODETYPE nt, const ::std::wstring &name, INTERFACE_CLI_IVARIANT *pv)
       : base_impl(DEF_MODULE)
       , pChild( 0 )
       {
       }

    CDataNodeImpl( const CDataNodeImpl &dn ) : base_impl(DEF_MODULE)
                    , pChild( 0 )
       {
       }
*/
    ~CDataRootImpl()
       {
        if (pChild) pChild->release();
        clearEventsQueue();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CDataRootImpl,INTERFACE_CLI_IDATANODE)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IDATANODE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IDATAROOT )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IDATAEVENTSQUEUE )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IVARIANTCONVERT )
    CLI_END_INTERFACE_MAP(CDataRootImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)
       {
        return addRefImpl() ;
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }

    //return dataEventQueue.postEvent( pHandler, pDataNodeFrom, eventMask );

    CLIMETHOD(inputStreamIdGet) (THIS_ SIZE_T*    _streamId /* [out] size_t _streamId  */)
       {
        CLI_TRY{
                if (!_streamId) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStreamId" );  }
                *_streamId = inputStreamId;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(inputStreamIdSet) (THIS_ SIZE_T    _streamId /* [in] size_t  _streamId  */)
       {
        inputStreamId = _streamId;
        return EC_OK;
       }

    CLIMETHOD(streamIdGet) (THIS_ SIZE_T*    _streamId /* [out] size_t _streamId  */)
       {
        CLI_TRY{
                if (!_streamId) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pStreamId" );  }
                *_streamId = streamId;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(streamIdSet) (THIS_ SIZE_T    _streamId /* [in] size_t  _streamId  */)
       {
        streamId = _streamId;
        return EC_OK;
       }

    CLIMETHOD(encodingNameGet) (THIS_ CLISTR*           _encodingName)
       {
        CLI_TRY{
                if (!_encodingName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"encodingName" );  }
                return ::cli::propertyGetImpl( _encodingName, encodingName );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(encodingNameSet) (THIS_ const CLISTR*     _encodingName)
       {
        CLI_TRY{
                if (!_encodingName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"encodingName" );  }
                encodingName = stdstr(_encodingName);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(xmlVersionGet) (THIS_ CLISTR*           _xmlVersion)
       {
        CLI_TRY{
                if (!_xmlVersion) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"xmlVersion" );  }
                return ::cli::propertyGetImpl( _xmlVersion, xmlVersion );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(xmlVersionSet) (THIS_ const CLISTR*     _xmlVersion)
       {
        CLI_TRY{
                if (!_xmlVersion) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"xmlVersion" );  }
                xmlVersion = stdstr(_xmlVersion);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(levelNoGet) (THIS_ SIZE_T*    _levelNo /* [out] size_t _levelNo  */)
       {
        if (_levelNo) *_levelNo = SIZE_T_NPOS;
        return EC_OK;
       }

    CLIMETHOD(levelNoSet) (THIS_ SIZE_T    _levelNo /* [in] size_t  _levelNo  */)
       {
        return EC_OK;
       }

    CLIMETHOD(lineNoGet) (THIS_ SIZE_T*    _lineNo /* [out] size_t _lineNo  */)
       {
        CLI_TRY{
                if (!_lineNo) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pLineNo" );  }
                *_lineNo = SIZE_T_NPOS;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(lineNoSet) (THIS_ SIZE_T    _lineNo /* [in] size_t  _lineNo  */)
       {
        return EC_OK;
       }

    CLIMETHOD(linePosGet) (THIS_ SIZE_T*    _linePos /* [out] size_t _linePos  */)
       {
        CLI_TRY{
                if (!_linePos) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pLinePos" );  }
                *_linePos = SIZE_T_NPOS;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(linePosSet) (THIS_ SIZE_T    _linePos /* [in] size_t  _linePos  */)
       {
        return EC_OK;
       }


    CLIMETHOD(nodeFlagsGet) (THIS_ ENUM_CLI_EDATANODEFLAGS*    _nodeFlags /* [out] ::cli::EDataNodeFlags _nodeFlags  */)
       {
        if (_nodeFlags) *_nodeFlags = 0;
        return EC_OK;
       }

    CLIMETHOD(nodeFlagsSet) (THIS_ ENUM_CLI_EDATANODEFLAGS    _nodeFlags /* [in] ::cli::EDataNodeFlags  _nodeFlags  */)
       {
        return EC_OK;
       }

    CLIMETHOD(getChildList) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setChildList) (THIS_ INTERFACE_CLI_IDATANODELIST*    pNodeList /* [in] ::cli::iDataNodeList*  pNodeList  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(swapChilds) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(queueSizeGet) (THIS_ SIZE_T*    _queueSize /* [out] size_t _queueSize  */)
       {
        CLI_SCOPED_LOCK(eventQueueLock);
        if (_queueSize) *_queueSize = eventQueue.size();
        return EC_OK;
       }

    CLIMETHOD(clearEventsQueue) (THIS)
       {
        CLI_SCOPED_LOCK(eventQueueLock);
        while(eventQueue.size())
           {
            CEventTriple item = eventQueue.front();
            eventQueue.pop_front();
            item.pHandler->release();
            item.pDataNodeFrom->release();
           }
        return EC_OK;
       }
/*
    struct CEventTriple
    {
     INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler;
     INTERFACE_CLI_IDATANODE*            pDataNodeFrom;
     ENUM_CLI_EDATANODEEVENTMASK         eventMask;
*/

    CLIMETHOD(mergeEventsGet) (THIS_ BOOL*    _mergeEvents /* [out] bool _mergeEvents  */)
       {
        if (_mergeEvents) *_mergeEvents = mergeEvents;
        return EC_OK;
       }

    CLIMETHOD(mergeEventsSet) (THIS_ BOOL    _mergeEvents /* [in] bool  _mergeEvents  */)
       {
        mergeEvents = _mergeEvents;
        return EC_OK;
       }

    CLIMETHOD(enabledGet) (THIS_ BOOL*    _enabled /* [out] bool _enabled  */)
       {
        if (_enabled) *_enabled = queueEnabled;
        return EC_OK;
       }

    CLIMETHOD(enabledSet) (THIS_ BOOL    _enabled /* [in] bool  _enabled  */)
       {
        queueEnabled = _enabled;
        return EC_OK;
       }

    CLIMETHOD(postEvent) (THIS_ INTERFACE_CLI_IDATAEVENTHANDLER*    pHandler /* [in] ::cli::iDataEventHandler*  pHandler  */
                              , INTERFACE_CLI_IDATANODE*    pDataNodeFrom /* [in] ::cli::iDataNode*  pDataNodeFrom  */
                              , ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */
                         )
       {
        CLI_TRY{
                if (!pHandler)      { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pHandler" );  }
                if (!pDataNodeFrom) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"pDataNodeFrom" );  }
                if (!queueEnabled) return EC_OK;

                CLI_SCOPED_LOCK(eventQueueLock);

                if (mergeEvents)
                   {
                    ::std::deque< CEventTriple >::iterator evqIt = eventQueue.begin();
                    for(; evqIt != eventQueue.end(); ++evqIt)
                       {
                        if (evqIt->pHandler==pHandler && evqIt->pDataNodeFrom==pDataNodeFrom)
                           {
                            evqIt->eventMask |= eventMask;
                            return EC_OK;
                           }
                       }
                   }
                pHandler->addRef();
                pDataNodeFrom->addRef();
                eventQueue.push_back( CEventTriple( pHandler, pDataNodeFrom, eventMask ) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(callAllQueuedEvents) (THIS)
       {
        SIZE_T qs = 0;
        queueSizeGet( &qs );
        while(qs)
           {
            callQueuedEvent();
            queueSizeGet( &qs );
           }
        return EC_OK;
       }

    CLIMETHOD(callQueuedEvent) (THIS)
       {
        CLI_TRY{
                CEventTriple item;
                   {
                    CLI_SCOPED_LOCK(eventQueueLock);
                    if (!eventQueue.size()) return EC_NO_DATA;
                    item = eventQueue.front();
                    eventQueue.pop_front();
                   }
                item.pHandler->onDataEvent( item.pDataNodeFrom, item.eventMask );
                item.pHandler->release();
                item.pDataNodeFrom->release();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(generateEvent) (THIS_ ENUM_CLI_EDATANODEEVENTMASK    eventMask /* [in] ::cli::EDataNodeEventMask  eventMask  */)
       {
        if (isNodeEventsLocked()) return EC_OK;

        ENUM_CLI_EDATANODEEVENTMASK handledMask = 0;
        ::std::vector< ::std::pair< INTERFACE_CLI_IDATAEVENTHANDLER*, ENUM_CLI_EDATANODEEVENTMASK > >::const_iterator evIt =  eventHandlers.begin();
        for(; evIt != eventHandlers.end(); ++evIt)
           {
            ENUM_CLI_EDATANODEEVENTMASK curMask = evIt->second & eventMask;
            if (!curMask) continue;
            handledMask |= curMask;
            postEvent( evIt->first, static_cast< INTERFACE_CLI_IDATANODE* >(this), curMask );
            //evIt->first->onDataEvent( static_cast< INTERFACE_CLI_IDATANODE* >(this), curMask );
           }
        return EC_OK;
       }

    //ilint_t ILVOLATILE           eventLockCounter;
    CLIMETHOD(lockNodeEvents) (THIS)
       {
        interlockedIncrement(&eventLockCounter);
        return EC_OK;
       }

    CLIMETHOD(unlockNodeEvents) (THIS)
       {
        interlockedDecrement(&eventLockCounter);
        return EC_OK;
       }

    CLIMETHOD_(BOOL, isNodeEventsLocked) (THIS)
       {
        if (eventLockCounter > 0 ) return TRUE;
        return FALSE;
       }

    CLIMETHOD(setParentNode) (THIS_ INTERFACE_CLI_IDATANODE*    pParentNode /* [in] ::cli::iDataNode*  pParentNode  */)
       {
        return EC_OK;
       }

    CLIMETHOD(getParentNode) (THIS_ INTERFACE_CLI_IDATANODE**    pParentNode /* [out] ::cli::iDataNode* pParentNode  */)
       {
        if (pParentNode) *pParentNode = 0;
        return EC_OK;
       }

    CLIMETHOD(getRootNode) (THIS_ INTERFACE_CLI_IDATANODE**    pRootNode /* [out] ::cli::iDataNode* pParentNode  */)
       {
        if (pRootNode) *pRootNode = static_cast<INTERFACE_CLI_IDATANODE*>(this);
        return EC_OK;
       }

    RCODE getChildsToListByTypeAndNameImpl( INTERFACE_CLI_IDATANODELIST *pNodeList
                                          , ENUM_CLI_EDATANODETYPE    nodeTypeCmp
                                          , const std::vector< std::wstring > &names
                                          )
       {
        if (!pChild) return 0;
        cli::CiDataNode node(pChild);
        std::wstring           nodeName = node.nodeName;
        ENUM_CLI_EDATANODETYPE nodeType = node.nodeType;
        if (nodeType!=CLI_EDATANODETYPE_ANY && nodeType!=nodeTypeCmp) return 0;

        std::vector< std::wstring >::const_iterator nit = names.begin();
        for(; nit != names.end(); ++nit)
           {
            if (nodeName==*nit) break;
           }
        if (nit == names.end()) return 0;

        pNodeList->pushBackDataNode( node.getIfPtr() );
        return 0;
       }

    CLIMETHOD(getChildsToListByTypeAndName) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                 , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                 , const CLISTR*     _names
                                            )
       {
        CLI_TRY{
                if (!pNodeList) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeList" );  }
                if (!_names)    { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 3) % L"names" );  }
                INTERFACE_CLI_IDATANODELIST *nodeList = new CDataNodeListImpl( );
                *pNodeList = nodeList;
                ::std::wstring strNames;
                ::cli::propertySetImpl( _names, strNames );
                ::std::vector< ::std::wstring > namesVec;
                ::cli::util::splitString( strNames, namesVec, ::cli::util::CIsExactChar< wchar_t, L','>() );
                //CLI_SCOPED_LOCK(childListLock);
                return getChildsToListByTypeAndNameImpl( nodeList, nodeType, namesVec );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getChildsToListByTypeAndNameChars) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                                      , ENUM_CLI_EDATANODETYPE    nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                                      , const WCHAR*    _names /* [in,flat] wchar  names[]  */
                                                 )
       {
        CLI_TRY{
                if (!pNodeList) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeList" );  }
                if (!_names)    { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 3) % L"names" );  }
                INTERFACE_CLI_IDATANODELIST *nodeList = new CDataNodeListImpl( );
                *pNodeList = nodeList;
                ::std::wstring strNames;
                ::cli::propertySetImpl( _names, strNames );
                ::std::vector< ::std::wstring > namesVec;
                ::cli::util::splitString( strNames, namesVec, ::cli::util::CIsExactChar< wchar_t, L','>() );
                //CLI_SCOPED_LOCK(childListLock);
                return getChildsToListByTypeAndNameImpl( nodeList, nodeType, namesVec );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getChildsToListByType) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */
                                          , ENUM_CLI_EDATANODETYPE    nodeTypeCmp /* [in] ::cli::EDataNodeType  nodeType  */
                                     )
       {
        CLI_TRY{
                if (!pNodeList) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeList" );  }
                INTERFACE_CLI_IDATANODELIST *nodeList = new CDataNodeListImpl( );
                *pNodeList = nodeList;
                if (!pChild) return 0;

                //CLI_SCOPED_LOCK(childListLock);

                cli::CiDataNode node(pChild);
                ENUM_CLI_EDATANODETYPE nodeType = node.nodeType;
                if (nodeType!=CLI_EDATANODETYPE_ANY && nodeType!=nodeTypeCmp) return 0;

                nodeList->pushBackDataNode( node.getIfPtr() );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                   , ENUM_CLI_EDATANODETYPE    newNodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                   , const CLISTR*     nodeName
                                   , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                              )
       {
        CLI_TRY{
                if (!pNewNode) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewNode" );  }
                *pNewNode = new CDataNodeImpl( newNodeType, stdstr(nodeName), pValue );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createDataNodeChars) (THIS_ INTERFACE_CLI_IDATANODE**    pNewNode /* [out] ::cli::iDataNode* pNewNode  */
                                        , ENUM_CLI_EDATANODETYPE    newNodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                        , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                        , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                   )
       {
        CLI_TRY{
                if (!pNewNode) { throw ::cli::CException( false, EC_INVALID_OUT_PTR, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNewNode" );  }
                *pNewNode = new CDataNodeImpl( newNodeType, stdstr(nodeName), pValue );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createChildDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                        , ENUM_CLI_EDATANODETYPE    newNodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                        , const CLISTR*     nodeName
                                        , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                   )
       {
        CLI_TRY{
                if (newNodeType!=CLI_EDATANODETYPE_NODE && newNodeType!=CLI_EDATANODETYPE_TEXT) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"newNodeType" );  }
                if (pChild) pChild->release();
                pChild = new CDataNodeImpl( newNodeType, stdstr(nodeName), pValue );
                pChild->setParentNode( this );
                if (pNewChildNode)
                   {
                    *pNewChildNode = pChild;
                    (*pNewChildNode)->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createChildDataNodeChars) (THIS_ INTERFACE_CLI_IDATANODE**    pNewChildNode /* [out,optional] ::cli::iDataNode* pNewChildNode  */
                                             , ENUM_CLI_EDATANODETYPE    newNodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                             , const WCHAR*    nodeName /* [in,flat] wchar  nodeName[]  */
                                             , INTERFACE_CLI_IVARIANT*    pValue /* [in] ::cli::iVariant*  pValue  */
                                        )
       {
        CLI_TRY{
                if (newNodeType!=CLI_EDATANODETYPE_NODE && newNodeType!=CLI_EDATANODETYPE_TEXT) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"newNodeType" );  }
                if (pChild) pChild->release();
                pChild = new CDataNodeImpl( newNodeType, stdstr(nodeName), pValue );
                pChild->setParentNode( this );
                if (pNewChildNode)
                   {
                    *pNewChildNode = pChild;
                    (*pNewChildNode)->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(cloneDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeCopy /* [out] ::cli::iDataNode* pNodeCopy  */)
       {
        CLI_TRY{
                return EC_NOT_IMPLEMENTED;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(lockChildNodes) (THIS)
       {
        //childListLock.lock();
        return EC_OK;
       }

    CLIMETHOD(unlockChildNodes) (THIS)
       {
        //childListLock.unlock();
        return EC_OK;
       }

    CLIMETHOD_(SIZE_T, getChildsCountSimple) (THIS)
       {
        if (pChild) return 1;
        return 0;
       }


    CLIMETHOD(getChildsCount) (THIS_ SIZE_T*    childsCount /* [out] size_t childsCount  */)
       {
        if (!childsCount) return EC_OK;
        //childListLock.lock();
        *childsCount = getChildsCountSimple();
        //childListLock.unlock();
        return EC_OK;
       }

    CLIMETHOD(getChildNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                 , SIZE_T    nodeIndex /* [in] size_t  nodeIndex  */
                            )
       {
        if (pNode)
           {
            *pNode = pChild;
            if (pChild) pChild->addRef();
            return EC_OK;
           }
        return EC_NO_OBJECT;
       }

    CLIMETHOD(insertChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                    , SIZE_T    where /* [in] size_t  where  */
                               )
       {
        // ignoring where
        if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
        if (pChild) pChild->release();
        pChild = pNode;
        pChild->addRef();
        pChild->setParentNode( this );
        return EC_OK;
       }

    CLIMETHOD(pushBackChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
        if (pChild) pChild->release();
        pChild = pNode;
        pChild->addRef();
        pChild->setParentNode( this );
        return EC_OK;
       }

    #if 0
    CLIMETHOD(appendChildNodesFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, pNode);

        if (!pChild)
           {
            RCODE rcRes = pNode->cloneDataNode(&pChild);
            pChild->setParentNode( this );
            return rcRes;
           }

        //CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( this, thisChildsLocker );
        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( pNode, nodeChildsLocker );

        ::cli::CiDataNodeList rightNodeList;
        RCODE rcRes = pNode->getChildList( rightNodeList.getPP() );
        if (rcRes) return rcRes;

        SIZE_T rightListSize = rightNodeList.listSize;
        for(SIZE_T rightChildIndex = 0; rightChildIndex!=rightListSize; ++rightChildIndex)
           {
            ::cli::CiDataNode childNode;
            rightNodeList.getDataNode(childNode.getPP(), rightChildIndex);
            pChild->pushBackChildNode(childNode.getIfPtr());
           }
        CLIMETHOD_IMPL_END();
       }
    #endif

    CLIMETHOD(moveChildNodeFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeFrom /* [in] ::cli::iDataNode*  pNodeFrom  */
                                      , SIZE_T    moveFromIdx /* [in] size_t  moveFromIdx  */
                                      , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                 )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, pNodeFrom);

        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( this     , thisChildsLocker );
        CLI_DATADOM_CHILD_LIST_SCOPED_LOCK_EX( pNodeFrom, nodeChildsLocker );

        ::cli::CiDataNode childNode;
        RCODE rcRes = pNodeFrom->getChildNode(childNode.getPP(), moveFromIdx);
        if (rcRes) return rcRes;
        pNodeFrom->eraseChildNode( moveFromIdx );
        if (!childNode) return EC_OK;

        return pushBackChildNode( childNode.getIfPtr() );

        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(getChildNodeType) (THIS_ ENUM_CLI_EDATANODETYPE*    childType /* [out] ::cli::EDataNodeType childType  */
                                     , SIZE_T    where /* [in] size_t  where  */
                                )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, childType);
        if (!pChild) return EC_NO_OBJECT;
        return pChild->nodeTypeGet(childType);
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(moveChildNodesByTypeFrom) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                       , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                  )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(moveChildNodesByTypeFromEx) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                               , ENUM_CLI_EDATANODETYPE    moveTypes /* [in] ::cli::EDataNodeType  moveTypes  */
                                               , SIZE_T    insertWhere /* [in] size_t  insertWhere  */
                                          )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(swapChildNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNodeNew /* [in] ::cli::iDataNode*  pNodeNew  */
                                  , SIZE_T    where /* [in] size_t  where  */
                                  , ENUM_CLI_EDATANODESWAPFLAGS    flags /* [in] ::cli::EDataNodeSwapFlags  flags  */
                                  , INTERFACE_CLI_IDATANODE**    pNodePrev /* [out,optional] ::cli::iDataNode* pNodePrev  */
                             )
       {
        CLI_TRY{
                if (!pNodeNew) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNodeNew" );  }
                if (where>0) return EC_OUT_OF_RANGE;

                INTERFACE_CLI_IDATANODE* pPrev = pChild;
                pNodeNew->addRef();
                pChild = pNodeNew;

                if (pPrev)
                   {
                    SIZE_T s = 0;
                    if (flags&CLI_EDATANODESWAPFLAGS_UPDATESTREAMID && pPrev->streamIdGet(&s)==EC_OK)
                       {
                        pNodeNew->streamIdSet(s);
                       }
                    if (flags&CLI_EDATANODESWAPFLAGS_UPDATELINENO && pPrev->lineNoGet(&s)==EC_OK)
                       {
                        pNodeNew->lineNoSet(s);
                       }
                    if (flags&CLI_EDATANODESWAPFLAGS_UPDATELINEPOS && pPrev->linePosGet(&s)==EC_OK)
                       {
                        pNodeNew->linePosSet(s);
                       }
                   }

                if (pPrev)  pPrev->setParentNode( 0 );
                if (pChild) pChild->setParentNode( this );

                if (pNodePrev)
                   {
                    *pNodePrev = pPrev; // need to be released
                   }
                else
                   {
                    if (pPrev) pPrev->release();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(childIndexGet) (THIS_ SIZE_T*    _childIndex /* [out] size_t _childIndex  */
                                  , const CLISTR*     idx1
                             )
       {
        CLI_TRY{
                if (!_childIndex) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pChildIndex" );  }
                if (!idx1)        { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"idx1" );  }

                *_childIndex = this->getChildIndexByNameType( idx1, CLI_EDATANODETYPE_NODE );
                //return EC_OK;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(childIndexSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(attrIndexGet) (THIS_ SIZE_T*    _attrIndex /* [out] size_t _attrIndex  */
                                 , const CLISTR*     idx1
                            )
       {
        CLI_TRY{
                if (!_attrIndex) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pAttrIndex" );  }
                if (!idx1)        { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"idx1" );  }

                *_attrIndex = this->getChildIndexByNameType( idx1, CLI_EDATANODETYPE_ATTRIBUTE );
                //return EC_OK;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(attrIndexSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(eraseChildNode) (THIS_ SIZE_T    where /* [in] size_t  where  */)
       {
        if (pChild) pChild->release();
        pChild = 0;
        return EC_OK;
       }

    CLIMETHOD(clearChilds) (THIS)
       {
        if (pChild) pChild->release();
        pChild = 0;
        return EC_OK;
       }

    CLIMETHOD(clearChildsEx) (THIS_ ENUM_CLI_EDATANODETYPE    keepTypes /* [in] ::cli::EDataNodeType  keepTypes  */)
       {
        if (!pChild) return EC_OK;

        CiDataNode_tmp tmp(pChild);
        ENUM_CLI_EDATANODETYPE tmpType = tmp.nodeType;
        if (tmpType&keepTypes) return EC_OK;
        return clearChilds();
       }

    CLIMETHOD(getChildNodes) (THIS_ INTERFACE_CLI_IDATANODELIST**    pNodeList /* [out] ::cli::iDataNodeList* pNodeList  */)
       {
        CLI_TRY{
                if (pNodeList)
                   {
                    *pNodeList = new CDataNodeListImpl();
                    if (pChild)
                       (*pNodeList)->pushBackDataNode( pChild );
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(childsGet) (THIS_ INTERFACE_CLI_IDATANODE**    _childs /* [out] ::cli::iDataNode* _childs  */
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                         )
       {
        CLI_TRY{
                if (!_childs) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pChild" );  }
                //if (!idx1)        { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 2) % L"idx1" );  }

                RCODE res = this->getChildNodeByIndex( _childs, idx1 );
                if (!res) (*_childs)->release();
                return res;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(childsSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        if (_size)
           {
            if (!pChild) *_size = 0;
            else *_size = 1;
           }
        return EC_OK;
       }

    CLIMETHOD(getChildNodeByIndex) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */
                                        , SIZE_T    idx /* [in] size_t  idx  */
                                   )
       {
        if (pNode) { *pNode = pChild; pChild->addRef(); }
        return EC_OK;
       }

    CLIMETHOD_(BOOL, findChild) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (pNode==pChild) return TRUE;
        return FALSE;
       }

    CLIMETHOD_(SIZE_T, getChildIndex) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        if (pNode==pChild) return 0;
        return SIZE_T_NPOS;
       }



    CLIMETHOD_(SIZE_T, getChildIndexByName) (THIS_ const CLISTR*     name)
       {
        if (pChild && pChild->compareName( name )) return 0;
        return SIZE_T_NPOS;
       }

    CLIMETHOD_(SIZE_T, getChildIndexByNameType) (THIS_ const CLISTR*     name
                                                     , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                )
       {
        if (pChild && pChild->compareNameType( name, type )) return 0;
        return SIZE_T_NPOS;
       }

    CLIMETHOD_(SIZE_T, getChildIndexByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        if (pChild && pChild->compareNameChars( name )) return 0;
        return SIZE_T_NPOS;
       }

    CLIMETHOD_(SIZE_T, getChildIndexByNameTypeChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                                          , ENUM_CLI_EDATANODETYPE    type /* [in] ::cli::EDataNodeType  type  */
                                                     )
       {
        if (pChild && pChild->compareNameTypeChars( name, type )) return 0;
        return SIZE_T_NPOS;
       }

    CLIMETHOD(getNextSibling) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeSibling /* [out] ::cli::iDataNode* pNode  */)
       {
        return EC_NO_SUCH_OBJECT; // no parent - no sibling
       }

    CLIMETHOD(getPrevSibling) (THIS_ INTERFACE_CLI_IDATANODE**    pNodeSibling /* [out] ::cli::iDataNode* pNode  */)
       {
        return EC_NO_SUCH_OBJECT; // no parent - no sibling
       }

    CLIMETHOD(nodeTypeGet) (THIS_ ENUM_CLI_EDATANODETYPE*    _nodeType /* [out] ::cli::EDataNodeType _nodeType  */)
       {
        if (_nodeType) *_nodeType = CLI_EDATANODETYPE_NODE;
        return EC_OK;
       }

    CLIMETHOD(nodeTypeSet) (THIS_ ENUM_CLI_EDATANODETYPE    _nodeType /* [in] ::cli::EDataNodeType  _nodeType  */)
       {
        return EC_OK;
       }

    CLIMETHOD(nodeNameGet) (THIS_ CLISTR*           _nodeName)
       {
        return ::cli::propertyGetImpl( _nodeName, ::std::wstring() );
       }

    CLIMETHOD(nodeNameSet) (THIS_ const CLISTR*     _nodeName)
       {
        return EC_OK;
       }

    CLIMETHOD(getDataNodeValue) (THIS_ INTERFACE_CLI_IREADONLYVARIANT**    _pValue /* [out] ::cli::iReadOnlyVariant* pValue  */)
       {
        if (_pValue)
           *_pValue = 0;
        return EC_OK;
       }

    CLIMETHOD_(BOOL, hasValue) (THIS_ BOOL    emptyAsNoValue /* [in] bool  emptyAsNoValue  */)
       {
        return FALSE;
       }

    CLIMETHOD_(BOOL, compareName) (THIS_ const CLISTR*     name)
       {
        return FALSE;
       }

    CLIMETHOD_(BOOL, compareNameType) (THIS_ const CLISTR*     name
                                      , ENUM_CLI_EDATANODETYPE    _nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                      )
       {
        return FALSE;
       }

    CLIMETHOD_(BOOL, compareNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        return FALSE;
       }

    CLIMETHOD_(BOOL, compareNameTypeChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                                           , ENUM_CLI_EDATANODETYPE    _nodeType /* [in] ::cli::EDataNodeType  nodeType  */
                                           )
       {
        return FALSE;
       }

    CLIMETHOD_(ENUM_CLI_VARIANTTYPE, getValueType) (THIS)
       {
        return CLI_VARIANTTYPE_VT_EMPTY;
       }

    CLIMETHOD(setValue) (THIS_ INTERFACE_CLI_IVARIANT*    _pValue /* [in] ::cli::iVariant*  pValue  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setValueCopy) (THIS_ INTERFACE_CLI_IVARIANT*    _pValue /* [in] ::cli::iVariant*  pValue  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setValueToNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setValueToNodeCopy) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(copyValueToNode) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(removeValue) (THIS)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setEmpty) (THIS)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setChar) (THIS_ CHAR    ch /* [in] char  ch  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setWChar) (THIS_ WCHAR    wch /* [in] wchar  wch  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setShort) (THIS_ SHORT    s /* [in] short  s  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setUShort) (THIS_ USHORT    us /* [in] ushort  us  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setInt) (THIS_ INT    i /* [in] int  i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setUInt) (THIS_ UINT    i /* [in] uint  i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setColorref) (THIS_ COLORREF    i /* [in] colorref  i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setInt64) (THIS_ INT64    i /* [in] int64  i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setUInt64) (THIS_ UINT64    i /* [in] uint64  i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setIntPtr) (THIS_ INT_PTR    i /* [in] int_ptr  i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setUIntPtr) (THIS_ UINT_PTR    i /* [in] uint_ptr  i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setFloat) (THIS_ FLOAT    f /* [in] float  f  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setDouble) (THIS_ DOUBLE    d /* [in] double  d  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setPtr) (THIS_ const VOID*    vptr /* [in] void*  vptr  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setString) (THIS_ const CLISTR*     str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setStringPStr) (THIS_ CLIPSTR           str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setStringChars) (THIS_ const WCHAR*    str /* [in,flat] wchar  str[]  */
                                   , SIZE_T    strSize /* [in] size_t  strSize  */
                              )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setDump) (THIS_ const BYTE*    d /* [in,flat] byte  d[]  */
                            , SIZE_T    dumpSize /* [in] size_t  dumpSize  */
                       )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setDate) (THIS_ const ::cli::CLISYSTEMTIME*    datetime /* [in,ref] ::cli::CLISYSTEMTIME  datetime  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(setBool) (THIS_ BOOL    b /* [in] bool  b  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getChar) (THIS_ CHAR*    ch /* [out] char ch  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getWChar) (THIS_ WCHAR*    wch /* [out] wchar wch  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getShort) (THIS_ SHORT*    s /* [out] short s  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getUShort) (THIS_ USHORT*    us /* [out] ushort us  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getInt) (THIS_ INT*    i /* [out] int i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getUInt) (THIS_ UINT*    i /* [out] uint i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getColorref) (THIS_ COLORREF*    i /* [out] colorref i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getInt64) (THIS_ INT64*    i /* [out] int64 i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getUInt64) (THIS_ UINT64*    i /* [out] uint64 i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getIntPtr) (THIS_ INT_PTR*    i /* [out] int_ptr i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getUIntPtr) (THIS_ UINT_PTR*    i /* [out] uint_ptr i  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getFloat) (THIS_ FLOAT*    f /* [out] float f  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getDouble) (THIS_ DOUBLE*    d /* [out] double d  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getPtr) (THIS_ VOID**    vptr /* [out] void* vptr  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getString) (THIS_ CLISTR*           str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getText) (THIS_ BOOL    fRecurse /* [in] bool  allText  */
                            , CLISTR*           str
                       )
       {
        return ::cli::propertyGetImpl( str, ::std::wstring() );
       }

    CLIMETHOD(objectValueToString) (THIS_ CLISTR*           str)
       {
        return ::cli::propertyGetImpl( str, ::std::wstring() );
       }

    CLIMETHOD(getStringPStr) (THIS_ CLIPSTR*          str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getStringChars) (THIS_ WCHAR*    buf /* [out,flat] wchar buf[]  */
                                   , SIZE_T*    bufSize /* [in,out] size_t bufSize  */
                              )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getDump) (THIS_ CLIPCSTR*         str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getDate) (THIS_ ::cli::CLISYSTEMTIME*    datetime /* [out] ::cli::CLISYSTEMTIME datetime  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getBool) (THIS_ BOOL*    b /* [out] bool b  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(serializeValueSimple) (THIS_ CLISTR*           str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(serializeValueAdvanced) (THIS_ CLISTR*           str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(serializeValueAdvancedSeparate) (THIS_ CLISTR*           strValue
                                                   , CLISTR*           strType
                                              )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(deserializeValueSimple) (THIS_ const CLISTR*     str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(deserializeValueAdvanced) (THIS_ const CLISTR*     str)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(deserializeValueAdvancedSeparate) (THIS_ const CLISTR*     strValue
                                                     , const CLISTR*     strType
                                                )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(serializeXml) (THIS_ CLICSTR*          strTo
                                 , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                            )
       {
        if (pChild) return pChild->serializeXml( strTo, flags );
        return ::cli::propertyGetImpl( strTo, ::std::string() );
       }

    CLIMETHOD(deserializeXmlBuf) (THIS_ const CHAR*    buf /* [in,flat] char  buf[]  */
                                      , SIZE_T    bufSize /* [in] size_t  bufSize  */
                                      , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                                 )
       { // CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME
        if (!pChild)
           createChildDataNodeChars( 0, CLI_EDATANODETYPE_NODE, L"", 0 );
        pChild->lockNodeEvents();
        RCODE res = pChild->deserializeXmlBuf( buf, bufSize, flags | CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME );
        pChild->unlockNodeEvents();
        return res;
       }

    CLIMETHOD(deserializeXml) (THIS_ const CLICSTR*    strXml
                                   , ENUM_CLI_EDATANODESERIALIZEFLAG    flags /* [in] ::cli::EDataNodeSerializeFlag  flags  */
                              )
       { // CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME
        if (!pChild)
           createChildDataNodeChars( 0, CLI_EDATANODETYPE_NODE, L"", 0 );
        pChild->lockNodeEvents();
        RCODE res = pChild->deserializeXml( strXml, flags | CLI_EDATANODESERIALIZEFLAG_UPDATENODENAME );
        pChild->unlockNodeEvents();
        return res;
       }

    CLIMETHOD(buildXPathQueryVarMapSpec) (THIS_ INTERFACE_CLI_IVARIANTMAP*    pVarMapSpec /* [in] ::cli::iVariantMap*  pVarMapSpec  */
                                              , ENUM_CLI_EXPATHEXPRESSIONFLAGS  flags   /* [in] ::cli::EXPathExpressionFlags  flags  */
                                              , CLISTR*           query
                                         )
       {
        return ::cli::propertyGetImpl( query, ::std::wstring(L"/") );
       }

    CLIMETHOD(buildXPathQueryStringSpec) (THIS_ const CLISTR*     strSpec
                                              , ENUM_CLI_EXPATHEXPRESSIONFLAGS  flags   /* [in] ::cli::EXPathExpressionFlags  flags  */
                                              , CLISTR*           query
                                         )
       {
        return ::cli::propertyGetImpl( query, ::std::wstring(L"/") );
       }

    CLIMETHOD(buildXPathQueryStringSpecChars) (THIS_ const WCHAR*    strSpec /* [in,flat] wchar  strSpec[]  */
                                                   , ENUM_CLI_EXPATHEXPRESSIONFLAGS  flags   /* [in] ::cli::EXPathExpressionFlags  flags  */
                                                   , CLISTR*           query
                                              )
       {
        return ::cli::propertyGetImpl( query, ::std::wstring(L"/") );
       }
    #if 0
    CLIMETHOD(buildXPathQueryStringSpecImpl) (THIS_ const ::std::wstring &strSpec
                                              , ENUM_CLI_EXPATHEXPRESSIONFLAGS  flags   /* [in] ::cli::EXPathExpressionFlags  flags  */
                                              , CLISTR*           query
                                             )
       {
        return ::cli::propertyGetImpl( query, ::std::wstring(L"/") );
       }
    #endif

    CLIMETHOD(getChildDataNode) (THIS_ INTERFACE_CLI_IDATANODE**    pNode /* [out] ::cli::iDataNode* pNode  */)
       {
        if (pNode)
           {
            *pNode = pChild;
            if (pChild)
               {
                pChild->addRef();
                return EC_OK;
               }
           }
        //return EC_NO_OBJECT;
        return EC_OK;
       }

    CLI_TIME_T createStampConst() const
       {
        return ::cli::CDateTime::now();
       }

    CLIMETHOD_(CLI_TIME_T, createStamp) (THIS)
       {
        return createStampConst();
       }

    CLIMETHOD(putStamp) (THIS)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(putStampEx) (THIS_ CLI_TIME_T    st /* [in] cli_time_t  st  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD_(CLI_TIME_T, getStamp) (THIS)
       {
        return ::cli::CDateTime::now();
       }

    CLI_TIME_T getStamp() const
       {
        return ::cli::CDateTime::now();
       }


}; // struct CDataRootImpl























struct CDataXPathQueryImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IDATAXPATHQUERY
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    //::std::vector<INTERFACE_CLI_IDATANODE*>   nodes;
    ::std::wstring           orgQueryString;
    ::std::vector< ::cli::datadom::xpath::CToken >  queryTokens;

    CDataXPathQueryImpl() : base_impl(DEF_MODULE), orgQueryString(), queryTokens()
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CDataXPathQueryImpl()
       {
       }

    CLI_BEGIN_INTERFACE_MAP2(CDataXPathQueryImpl, INTERFACE_CLI_IDATAXPATHQUERY)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IDATAXPATHQUERY )
    CLI_END_INTERFACE_MAP(CDataXPathQueryImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)
       {
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }

    CLIMETHOD(setQueryString) (THIS_ const CLISTR*     queryStr)
       {
        if (!queryStr) return EC_INVALID_PARAM;
        return setQueryStringImpl( stdstr(queryStr) );
       }

    CLIMETHOD(setQueryStringChars) (THIS_ const WCHAR*    queryStr /* [in,flat] wchar  queryStr[]  */)
       {
        if (!queryStr) return EC_INVALID_PARAM;
        return setQueryStringImpl( stdstr(queryStr) );
       }

    CLIMETHOD(setQueryStringImpl) (THIS_ const ::std::wstring &str /* [in,flat] wchar  queryStr[]  */)
       {
        CLI_TRY{
                orgQueryString = str;
                SIZE_T errPos, errLine, errLinePos;

                queryTokens.clear();

                if (!baseTokenizeXPathExpression( orgQueryString, queryTokens, &errPos, &errLine, &errLinePos ))
                   throw ::cli::CException( false, EC_XPATH_INVALID_EXPRESSION, __FILE__, __LINE__, ::cli::format::arg( (UINT)errPos ) % (UINT)errLine % (UINT)errLinePos );

                if (!normalizeXPathExpression( queryTokens, orgQueryString, &errPos, &errLine, &errLinePos ))
                   throw ::cli::CException( false, EC_XPATH_INVALID_EXPRESSION, __FILE__, __LINE__, ::cli::format::arg( (UINT)errPos ) % (UINT)errLine % (UINT)errLinePos );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


    CLIMETHOD(getQueryString) (THIS_ CLISTR*           queryStr)
       {
        return ::cli::propertyGetImpl( queryStr, orgQueryString );
       }

    CLIMETHOD(getNormalizedQueryString) (THIS_ CLISTR*           queryStr)
       {
        CLI_TRY{
                return ::cli::propertyGetImpl( queryStr, buildXPathExpressionFromTokens( queryTokens, orgQueryString ) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(executeQuery) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                 , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                 , INTERFACE_CLI_IDATANODELIST**    pResultNodes /* [out] ::cli::iDataNodeList* pResultNodes  */
                            )
       {
        CLI_TRY{
                if (queryTokens.empty()) return EC_NOT_INITIALIZED;
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }

                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"CLIMETHOD(executeQuery)" );
                ::cli::format::cli_log::message(L"Query string: %1", ::cli::format::arg( orgQueryString ) );
                #endif

                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"tokens dump" );
                ::std::vector< ::cli::datadom::xpath::CToken >::const_iterator first = queryTokens.begin();
                SIZE_T i = 0;
                for(; first != queryTokens.end(); ++first, ++i)
                   ::cli::format::cli_log::message(L"    %1!02d!: %2 (%3), pos: %4", ::cli::format::arg( (UINT)i ) % first->toTypeString() % first->toString(orgQueryString) % (UINT)first->tokenPos);
                #endif

                ::cli::CiDataNodeList resultNodeList("/cli/datanodelist");

                ::cli::datadom::xpath::executeParsed( pNode, resultNodeList, pVarMap, queryTokens.begin(), queryTokens.end(), orgQueryString, false );
                if (pResultNodes)
                   {
                    *pResultNodes = resultNodeList.getIfPtr();
                    (*pResultNodes)->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(executeCreationQuery) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                         , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                    )
       {
        CLI_TRY{
                if (queryTokens.empty()) return EC_NOT_INITIALIZED;
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }

                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"CLIMETHOD(executeCreationQuery)" );
                ::cli::format::cli_log::message(L"Query string: %1", ::cli::format::arg( orgQueryString ) );
                #endif

                ::cli::CiDataNodeList resultNodeList("/cli/datanodelist");
                ::cli::datadom::xpath::executeParsed( pNode, resultNodeList, pVarMap, queryTokens.begin(), queryTokens.end(), orgQueryString, true );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


    CLIMETHOD(executeQuerySingleNodeResult) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                 , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                 , BOOL    bClone /* [in] bool  bClone  */
                                                 , INTERFACE_CLI_IDATANODE**    pResultNode /* [out,optional] ::cli::iDataNode* pResultNode  */
                                            )
       {
        CLI_TRY{
                if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"pNode" );  }
                if (!pResultNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 4 ) % L"pResultNode" );  }
                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"CLIMETHOD(executeQuerySingleNodeResult)" );
                ::cli::format::cli_log::message(L"Query string: %1", ::cli::format::arg( orgQueryString ) );
                #endif

                    #if 0
                    ::cli::CiDataNodeList resultNodeList;
                    RCODE res = executeQuery( pNode, pVarMap, resultNodeList.getPP() );
                    if (res) return res;

                    ::cli::CiDataNode xpathResRoot("/cli/datanode");
                    xpathResRoot.nodeName = newParentName; // stdstr(newParentName); // L"newParentName";
                    resultNodeList.cloneDataNodesToNode(xpathResRoot.getIfPtr());
                    *pResultNode = xpathResRoot.getIfPtr();
                    (*pResultNode)->addRef();
                    #endif

                ::cli::CiDataNodeList resultNodeList;
                RCODE res = executeQuery( pNode, pVarMap, resultNodeList.getPP() );
                if (res) return res;
                SIZE_T listSize = resultNodeList.listSize;
                if (listSize!=1) { throw ::cli::CException( false, EC_XPATH_UNEXPECTED_RESULT_SET, __FILE__, __LINE__, ::cli::format::arg( 1) % L"executeQuery" );  }

                ::cli::CiDataNode tmpResNode;
                res = resultNodeList.getDataNode( tmpResNode.getPP(), 0 );
                if (res) return res;

                if (bClone)
                   tmpResNode.cloneDataNode(pResultNode);
                else
                   {
                    *pResultNode = tmpResNode.getIfPtr();
                    (*pResultNode)->addRef();
                   }
                return EC_OK;

                /*
        ::cli::CiDataNode xpathResRoot("/cli/datanode");
        xpathResRoot.nodeName = newParentName; // stdstr(newParentName); // L"newParentName";
        resultNodeList.cloneDataNodesToNode(xpathResRoot.getIfPtr());
        *pResultNode = xpathResRoot.getIfPtr();
        (*pResultNode)->addRef();
        return EC_OK;

                */
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


    CLIMETHOD(executeQueryCloneToParent) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                              , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                              , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                         )
       {
        CLI_TRY{
                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"CLIMETHOD(executeQueryCloneToParent)" );
                ::cli::format::cli_log::message(L"Query string: %1", ::cli::format::arg( orgQueryString ) );
                #endif

                return executeQueryCloneToParentExImpl( pNode, pVarMap, pResultNode, L"root" );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(executeQueryCloneToParentEx) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                                , const CLISTR*     newParentName
                                           )
       {
        CLI_TRY{
                if (!newParentName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 4 ) % L"newParentName" );  }

                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"CLIMETHOD(executeQueryCloneToParentEx)" );
                ::cli::format::cli_log::message(L"Query string: %1", ::cli::format::arg( orgQueryString ) );
                #endif

                return executeQueryCloneToParentExImpl( pNode, pVarMap, pResultNode, stdstr(newParentName) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(executeQueryCloneToParentExChars) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                     , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                     , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                                     , const WCHAR*    newParentName /* [in,flat] wchar  newParentName[]  */
                                                )
       {
        CLI_TRY{
                if (!newParentName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 4 ) % L"newParentName" );  }

                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"CLIMETHOD(executeQueryCloneToParentExChars)" );
                ::cli::format::cli_log::message(L"Query string: %1", ::cli::format::arg( orgQueryString ) );
                #endif

                return executeQueryCloneToParentExImpl( pNode, pVarMap, pResultNode, stdstr(newParentName) );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(executeQueryCloneToParentExImpl) (THIS_ INTERFACE_CLI_IDATANODE*    pNode /* [in] ::cli::iDataNode*  pNode  */
                                                     , INTERFACE_CLI_IVARIANTMAP*    pVarMap /* [in] ::cli::iVariantMap*  pVarMap  */
                                                     , INTERFACE_CLI_IDATANODE**    pResultNode /* [out] ::cli::iDataNode* pResultNode  */
                                                     , const ::std::wstring &newParentName /* [in,flat] wchar  newParentName[]  */
                                                )
       {
        CLI_TRY{
                if (!pResultNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 3 ) % L"pResultNode" );  }

                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"CLIMETHOD(executeQueryCloneToParentExImpl)" );
                        ::cli::format::cli_log::message(L"Query string: %1", ::cli::format::arg( orgQueryString ) );
                #endif

                ::cli::CiDataNodeList resultNodeList;
                RCODE res = executeQuery( pNode, pVarMap, resultNodeList.getPP() );
                if (res) return res;

                ::cli::CiDataNode xpathResRoot("/cli/datanode");
                xpathResRoot.nodeName = newParentName; // stdstr(newParentName); // L"newParentName";
                resultNodeList.cloneDataNodesToNode(xpathResRoot.getIfPtr());
                *pResultNode = xpathResRoot.getIfPtr();
                (*pResultNode)->addRef();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


}; // struct CDataXPathQueryImpl













}; // namespace impl
}; // namespace cli

// http://www.psychological.ru/default.aspx?s=0&p=38&0a1=288&0o1=3&0s1=1&0p1=4
// http://www.lovebody.by/pi892/LoveBody.html
// http://www.naritsyn.ru/selfhelp/all/vkons/vkons01.htm
// http://maksbotvinikov.com/category/filosofiya-uspexa/koncentraciya/
// http://maksbotvinikov.com/category/filosofiya-uspexa/koncentraciya/
// http://blog.zound.ru/2010/leni-ne-sushhestvuet-2/


#endif /* SRC_CORE_DATADOM_H */

