#define CLI_INTERNAL

#include <cli/clicmdline.h>


/*
cliSplitCommandLine uses the following rules when interpreting 
arguments given in the input command line: 

Arguments are delimited by white space, which is either a space or a tab.

A string surrounded by double quotation marks is interpreted as a single argument, 
regardless of white space contained within. A quoted string can be embedded in an argument. 
Note that the caret (^) is not recognized as an escape character or delimiter. 

A double quotation mark preceded by a backslash, \", is interpreted as a literal double quotation mark (").

Backslashes are interpreted literally, unless they immediately precede a double quotation mark.

If an even (���) number of backslashes is followed by a double quotation mark, 
then one backslash (\) is placed in the argv array for every pair of backslashes (\\), 
and the double quotation mark (") is interpreted as a string delimiter.

If an odd (�����) number of backslashes is followed by a double quotation mark, 
then one backslash (\) is placed in the argv array for every pair of backslashes (\\) 
and the double quotation mark is interpreted as an escape sequence by the remaining backslash, 
causing a literal double quotation mark (") to be placed in argv.

This list illustrates the rules above by showing the interpreted result passed to argv 
for several examples of command-line arguments. The output listed in the second, 
third, and fourth columns is from the ARGS.C program that follows the list.

Command-Line Input  argv[1]  argv[2]  argv[3]  
"a b c" d e         a b c       d       e
"ab\"c" "\\" d      ab"c        \       d
a\\\b d"e f"g h     a\\\b       de fg   h
a\\\"b c d          a\"b        c       d
a\\\\"b c" d e      a\\b c      d       e
"a\\\"b c" d e      a\"b c      d       e
"a\\\\"b c" d" e    a\\b        c d     e

Unix shell syntax http://montaque.appm.ru/doc/man/Linux/manpages/SH2.htm#quoting

*/

//-----------------------------------------------------------------------------
CLIAPIENTRY
RCODE
CLICALL
cliSplitCommandLine( const WCHAR *cmdLine
                   , INTERFACE_CLI_IARGLIST** ppArgs
                   )
   {
    if (!cmdLine) return EC_INVALID_PARAM;
    if (ppArgs) *ppArgs = cliGetArgList();

    bool inQuot = false;
    int slashCnt = 0;

    ::std::wstring argBuf;

    for(;*cmdLine; ++cmdLine)
       {
        if (*cmdLine==L'\\')
           {
            ++slashCnt;
            continue;
           }

        if (*cmdLine==L' ' || *cmdLine==L'\t')
           {
            if (slashCnt)
               { // append saved slashes as simple literals
                argBuf.append(slashCnt, L'\\');
                slashCnt = 0;
               }
            if (inQuot) 
               { // space quoted
                argBuf.append(1, *cmdLine);
               }
            else
               {
                // leading spaces are ignored
                if (!argBuf.empty())
                   {
                    if (ppArgs) (*ppArgs)->putStringChars( argBuf.data(), argBuf.size() );
                    argBuf.clear(); // ignoring space
                   }
               }
            continue;
           }

        if (*cmdLine==L'\"')
           {
            if (!slashCnt)
               { // double quot is simple quotation, change inQuot flag
                inQuot = !inQuot;
               }
            else
               {
                if (slashCnt%2) // odd
                   {
                    argBuf.append(slashCnt/2, L'\\');
                    argBuf.append(1, L'\"');
                   }
                else // even
                   {
                    argBuf.append(slashCnt/2, L'\\');
                    inQuot = !inQuot;
                   }
                slashCnt = 0;
               }
            continue;
           }
        // all other literals
        if (slashCnt)
           { // append saved slashes as simple literals
            argBuf.append(slashCnt, L'\\');
            slashCnt = 0;
           }
        argBuf.append(1, *cmdLine);
       }

    if (slashCnt)
       { // append saved slashes as simple literals
        argBuf.append(slashCnt, L'\\');
        slashCnt = 0;
       }

    if (!argBuf.empty())
       {
        if (ppArgs) (*ppArgs)->putStringChars( argBuf.data(), argBuf.size() );
        argBuf.clear(); // ignoring space
       }
    //return EC_NOT_IMPLEMENTED;
    return EC_OK;
   }

//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
RCODE
CLICALL
cliComposeCommandLineStdStr( ::std::wstring &resStr
                     , INTERFACE_CLI_IARGLIST* pArgs
                     )
   {
    if (!pArgs) return EC_OK; // no args, nothing to do

    ::cli::CiArgList args(pArgs);
    for(SIZE_T i=0, numArgs = args.getCount(); i!=numArgs; ++i)
       {
        ::std::wstring strArg;
        RCODE tmpRes = args.getString( i, strArg );
        if (tmpRes) 
            strArg.clear();

        ::std::wstring composedArg = ::cli::cmd_line::composeSingleArg( strArg );
        if (!resStr.empty())
           resStr.append(1,L' ');
        resStr.append(composedArg);
       }
    return EC_OK;
   }


CLIAPIENTRY
RCODE
CLICALL
cliComposeCommandLine( CLIPSTR *resStr
                     , INTERFACE_CLI_IARGLIST* pArgs
                     )
   {
    ::std::wstring resStdStr;
    RCODE res = cliComposeCommandLineStdStr( resStdStr, pArgs );
    if (pArgs) pArgs->release();
    if (res) return res;

    if (resStr)
       clipstr_alloc( resStr, resStdStr.c_str() );
    return EC_OK;
   }



#if 0
//-----------------------------------------------------------------------------
CLIAPIENTRY
RCODE
CLICALL
cliFormatMessageEx( CLIPSTR *resStr
                  , const WCHAR *fmtString
                  , INTERFACE_CLI_IARGLIST* pArgs
                  , DWORD flags
                  , const INT *tabs
                  , SIZE_T tabsSize
                  )
   {
    ::std::wstring strBuf;
    ::cli::format::impl::cliFormatMessage( strBuf, fmtString, pArgs, flags, tabs, tabsSize );

    if (resStr)
       clipstr_alloc( resStr, strBuf.c_str() );
    return EC_OK;
   }



inline
TCHAR** ParseWinMainCommandLine(int *argc, TCHAR *cmd_line)
{
    static TCHAR arg_buf[65535]; /* NOTE: I think this size is enough */
    static TCHAR *argv[512];     /* NOTE: I think that program argument 
                                    count is always less than 512 */
    int cur_arg_idx = 0;
    DWORD size = sizeof(arg_buf)/sizeof(TCHAR);
    DWORD res = GetModuleFileName( 0, arg_buf, size);
    arg_buf[res] = _T('\0');
    argv[cur_arg_idx] = arg_buf;
    TCHAR *next_arg_ptr = arg_buf + res + 1;

    argv[++cur_arg_idx] = next_arg_ptr;

    int quot_cnt = 0;

    bool slash_mod = false;
    //bool prev_quot = false;
    for (;*cmd_line && cur_arg_idx<512; cmd_line++)
        {
         if (*cmd_line==_T(' ') && !(quot_cnt%2))
            { // end of param reached
             if (slash_mod) 
                { *next_arg_ptr++ = _T('\\'); slash_mod = false; }
             *next_arg_ptr++ = _T('\0');
             argv[++cur_arg_idx] = next_arg_ptr;
             continue;
            }

         if (!slash_mod && *cmd_line==_T('\\'))
            { slash_mod = true; continue; }

         if (slash_mod)
            {
             if (*cmd_line!=_T('\\') && *cmd_line!=_T('\"'))
                *next_arg_ptr++ = _T('\\');
             *next_arg_ptr++ = *cmd_line;
             slash_mod = false;
            }
         else
            {
             if (*cmd_line==_T('\"'))
                { // quot found
                 if (*(cmd_line+1)==_T('\"'))
                    { // double quot found
                     *next_arg_ptr++ = *cmd_line++;
                     //continue;
                    }
                 else
                    { // single quot found
                     quot_cnt++;
                    }
                }
             else
                { // no quot. simple copy character
                 *next_arg_ptr++ = *cmd_line;
                }
            }
        }

    if (slash_mod) 
       { *next_arg_ptr++ = _T('\\'); }
    if (argv[cur_arg_idx]!=next_arg_ptr)
       {
        *next_arg_ptr++ = _T('\0');
        argv[++cur_arg_idx] = next_arg_ptr;
       }
    if (argc) *argc = cur_arg_idx;



    return argv;
}

#endif // 0


