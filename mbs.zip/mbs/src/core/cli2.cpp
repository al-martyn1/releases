#define CLI_INTERNAL

/*!
\project Common library interface v2 core runtime
    \libraries
    \libpath 
    \incpath

\platform linux
    \libraries dl pthread

\platform mingw
    \libraries ws2_32

\platform win32
    \libraries ws2_32

*/
/*
    libpath #(BOOST.lib) #(MARTYUSR.lib)
    incpath #(BOOST.include) #(MARTYUSR.include)
*/

#include <marty/mbs.h>

#include <cli/cli2.h>

#ifdef _WIN32
    #include <windows.h>
#else
    #include <stdio.h>
    #include <unistd.h>
#endif

#ifdef _WIN32
    #define COMPILE_NEWAPIS_STUBS
#endif

#include "cli2init.h"

#ifndef CLI_EMBEDDED
    #ifndef MARTY_FILENAME_H
        #include <marty/filename.h>
    #endif

    #include <marty/concvt.h>
    #include <marty/libapi.h>
    #include <marty/filesys.h>

#endif

#include <cli/csec.h>


#ifndef CLI_MONOLITHIC
    #include <cli/climod.h>
    extern ::cli::CModule cliModule;
#endif




#ifndef CLI_EMBEDDED


    ::cli::CCriticalSection initCs(0, true); // force single processor

    namespace cli
    {
        void createStdAllocatorObject();
    }; // namespace cli



    #if !defined(_MEMORY_) && !defined(_STLP_MEMORY) && !defined(__STD_MEMORY__) && !defined(_CPP_MEMORY) && !defined(_GLIBCXX_MEMORY)
        #include <memory>
    #endif
        
    static ::std::auto_ptr< ::cli::CCliOptions > pCliRuntimeOptions(0);
    
    namespace cli
    {
    ::cli::CCliOptions* getCliRuntimeOptions()
       {
        CLI_AUTOLOCK(initCs);
        if (!pCliRuntimeOptions.get())
           {
            ::cli::CCliOptions* pOpts = new ::cli::CCliOptions();
            pOpts->readCliConfigs();
            pCliRuntimeOptions.reset(pOpts);
           }

        cli::createStdAllocatorObject();
        return pCliRuntimeOptions.get();
       }
    }; // namespace cli



    #ifndef CLI_MONOLITHIC
    
        //ABSTRACT_MODULE_HANDLE  hCliDll = cliModule.getModuleHandle();
        #define hCliDll cliModule.getModuleHandle()

        #ifdef _WIN32
        
            /*
            EXTERN_C
            BOOL WINAPI DllMain( HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved );
            BOOL WINAPI DllMain( HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved )
               {
                if (dwReason==DLL_PROCESS_ATTACH)
                   hCliDll = (ABSTRACT_MODULE_HANDLE)hinstDLL;
                return TRUE;
               }
            */

        #elif defined( __GNUC__ )
            //#if _GNUC_VER<=27000 /* gcc 2.7 not support __attribute__ ((constructor)) */
            #if (__GNUC__ * 10000 + __GNUC_MINOR__ * 100) <= 27000 /* gcc 2.7 not support __attribute__ ((constructor)) */
                #error "gcc v < 2.7 not support __attribute__ ((constructor))"
            #endif
        
            /*

            #include <dlfcn.h>
            
            void __attribute__ ((constructor)) init_module(void)
               {
                Dl_info info;
                int res = dladdr((void*)init_module, &info);
                if (!res || !info.dli_fname) 
                   {
                    return;
                   }
                hCliDll = ::dlopen(info.dli_fname,  RTLD_LAZY|RTLD_LOCAL|RTLD_NOLOAD);
               }
            */
        #else
            #error "Unsupported compiler"
        #endif

        bool cli::getCliModuleName (::std::basic_string<TCHAR> &cliModuleName)
           {
            ::std::basic_string<TCHAR> cliModName;
            int getModNameRes = MARTY_LIBAPI_NS getModuleFileName( hCliDll, cliModName);
            if (getModNameRes) return false;
    
            if (!MARTY_FILENAME_NS isAbsolutePath(cliModName))
                cliModName = MARTY_FILENAME_NS appendPath(MARTY_FILESYSTEM_NS getCurrentDirectory(), cliModName);
    
            cliModuleName = MARTY_FILENAME_NS makeCanonical(cliModName);
            return true;
           }

        bool cli::findCliConfig   (::std::basic_string<TCHAR> &foundConfFile)
           {
            using MARTY_FILENAME_NS     makeCanonical;
            using MARTY_FILENAME_NS     getPath;
            using MARTY_FILENAME_NS     appendPath;
            using MARTY_FILESYSTEM_NS   handle_t;
            using MARTY_FILESYSTEM_NS   openFile;
            using MARTY_FILESYSTEM_NS   closeFile;
            using MARTY_FILESYSTEM_NS   o_rdonly;
            using MARTY_FILESYSTEM_NS   hInvalidHandle;
            using MARTY_FILESYSTEM_NS   getCurrentDirectory;
            
            ::std::basic_string<TCHAR> cliModName;
            int getModNameRes = getCliModuleName(cliModName);
            if (getModNameRes) return false;
    
            ::std::basic_string<TCHAR> cliPath = getPath(cliModName);
            ::std::basic_string<TCHAR> cliConfName = makeCanonical(appendPath(cliPath, ::std::basic_string<TCHAR>(_T("../conf/cli2.conf"))));
            
            handle_t hFile = openFile(cliConfName, o_rdonly );
            if (hInvalidHandle!=hFile)
               {
                closeFile(hFile);
                foundConfFile = cliConfName;
                return true;
               }
    
            cliConfName = makeCanonical(appendPath(cliPath, ::std::basic_string<TCHAR>(_T("cli2.conf"))));
            hFile = openFile(cliConfName, o_rdonly );
            if (hInvalidHandle!=hFile)
               {
                closeFile(hFile);
                foundConfFile = cliConfName;
                return true;
               }
    
            return false;
           }

        
    #endif /* CLI_MONOLITHIC */



#endif /* CLI_EMBEDDED */


#ifndef CLI_EMBEDDED
static ULONG getNumberOfSystemProcessors()
   {
    #ifdef _WIN32
        SYSTEM_INFO siSysInfo;
        GetSystemInfo(&siSysInfo);
        return (ULONG)siSysInfo.dwNumberOfProcessors;
    #else // http://www.rsdn.ru/forum/message/2694534.1.aspx
        #if defined(LINUX)
            #if defined(_SC_NPROCESSORS_CONF)
                return sysconf(_SC_NPROCESSORS_CONF);
            #else
                return 1;
            #endif
        #elif defined(FREEBSD)
            int ncpus ;
            size_t len = sizeof(ncpus);
            int mib[2];
            mib[0] = CTL_HW ;
            mib[1] = HW_NCPU ;
            if (sysctl(&mib[0], 2, &ncpus, &len, NULL, 0)!=0) return 1;
            return ncpus;
        #else
            #error "Platform not supported"
            return 1;
        #endif
    /*
    HPUX
    #include <stdio.h>
    #include <sys/mpctl.h>
    int main(void)
    {
        int ncpus ;
        ncpus = mpctl(MPC_GETNUMSPUS, NULL, NULL);
        printf("cpus: %d\n", ncpus);
        return 0 ;
    }
    AIX, Solaris:#include <stdio.h>
    #include <unistd.h>
    
    int main(int argc, char * argv[])
    {
        int ncpus ;
        ncpus = sysconf(_SC_NPROCESSORS_ONLN);
        printf("cpus: %d\n", ncpus);
        return 0 ;
    }
     

    */ 

    #endif
   }
#endif /* CLI_EMBEDDED */

CLIAPIENTRY
DWORD
CLICALL
cliGetMachineSpeed( )
   {
    #ifndef CLI_EMBEDDED
    CLI_AUTOLOCK(initCs);
    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
    return pOpts->getMachineSpeed();
    #else
    return MACHINE_SPEED_SLOW;    
    //return 1;
    #endif
   }


CLIAPIENTRY
ULONG
CLICALL
cliGetNumOfCliProcessors( )
   {
    #ifndef CLI_EMBEDDED
    CLI_AUTOLOCK(initCs);
    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
    return pOpts->getNumberOfCliProcessors();
    #else
        #error "Number of CPU awailable for CLI for embedded systems is undefined"
    //return 1;
    #endif
   }


CLIAPIENTRY
ULONG
CLICALL
cliGetNumOfSystemProcessors( )
   {
    #ifndef CLI_EMBEDDED
    CLI_AUTOLOCK(initCs);
    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
    if (!pOpts->numberOfSystemCpu)
       pOpts->numberOfSystemCpu = getNumberOfSystemProcessors();
    return pOpts->numberOfSystemCpu;
    #else
        #error "Number of CPU for embedded systems is undefined"
    //return 1;
    #endif
   }

// TODO: CLI can be force turned to single cpu mode, in the future update code below
CLIAPIENTRY
BOOL
CLICALL
cliGetMpStrategy( )
   {
    #ifndef CLI_EMBEDDED
    CLI_AUTOLOCK(initCs);
    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
    if (pOpts->forceSingleCpuStrategy()) return 0;  // mp off
    return cliGetNumOfCliProcessors( ) > 1 ? 1 : 0; // defult strategy based on number of processors
    #else
        //#error "Number of CPU awailable for CLI for embedded systems is undefined"
        return 0;
    #endif
   }

CLIAPIENTRY
VOID
CLICALL
cliWriteLogStringC( const CHAR *str)
   {
    #ifndef CLI_EMBEDDED
    CLI_AUTOLOCK(initCs);
    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
    if (str) pOpts->log()<<str;
    #else
    #endif
   }

CLIAPIENTRY
VOID
CLICALL
cliWriteLogStringW( const WCHAR *str)
   {
    #ifndef CLI_EMBEDDED
    CLI_AUTOLOCK(initCs);
    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
    if (str) pOpts->log()<<str;
    #else
    #endif
   }

CLIAPIENTRY
VOID
CLICALL
cliSetLogFileName( const TCHAR *logFileName)
   {
    #ifndef CLI_EMBEDDED
    CLI_AUTOLOCK(initCs);
    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
    if (logFileName) pOpts->reopenLog(logFileName);
    else             pOpts->reopenLogToDefault();
    #else
    #endif
   }



#ifndef CLI_EMBEDDED
CLIAPIENTRY
BOOL
CLICALL
cliMatchMaskC( const CHAR * s1, const CHAR * s2 )
   {
    if (!s1 || !s2) return 0;
    if (MARTY_FILENAME_NS matchMaskE( ::std::string(s1), ::std::string(s2))) return 1;
    return 0;
   }

CLIAPIENTRY
BOOL
CLICALL
cliMatchMaskCI( const CHAR * s1, const CHAR * s2 )
   {
    if (!s1 || !s2) return 0;
    if (MARTY_FILENAME_NS matchMaskI( ::std::string(s1), ::std::string(s2))) return 1;
    return 0;
   }

CLIAPIENTRY
BOOL
CLICALL
cliMatchMaskW( const WCHAR * s1, const WCHAR * s2 )
   {
    if (!s1 || !s2) return 0;
    if (MARTY_FILENAME_NS matchMaskE( ::std::wstring(s1), ::std::wstring(s2))) return 1;
    return 0;
   }


CLIAPIENTRY
BOOL
CLICALL
cliMatchMaskWI( const WCHAR * s1, const WCHAR * s2 )
   {
    if (!s1 || !s2) return 0;
    if (MARTY_FILENAME_NS matchMaskI( ::std::wstring(s1), ::std::wstring(s2))) return 1;
    return 0;
   }
#endif // CLI_EMBEDDED

typedef ::std::basic_string< TCHAR, 
                             ::std::char_traits<TCHAR>, 
                             ::std::allocator<TCHAR> >  tstring;

#ifdef CLI_MONOLITHIC

#include "clialloc.h"

// Monolithic configurations specific functions

CLIAPIENTRY
UINT
CLICALL
cliInitMonolithic( BYTE * componentDbBuf, SIZE_T bufSize)
   {
    cliInitStaticAlloc(componentDbBuf, bufSize);
    return 0;
   }

// internal monolithic initialization
UINT initCliMonolithicInt();

#else /* !CLI_MONOLITHIC */

void loadModulesInformation( const ::std::vector<tstring> &path
                           , const ::std::vector<tstring> &excludeModPath
                           , const ::std::vector<tstring> &extList
                           , const ::std::vector<tstring> &excludeFilesMasks
                           , bool clearComponentInfo
                           );

#endif /* CLI_MONOLITHIC */



CLIAPIENTRY
UINT
CLICALL
cliInit( )
   {

    // #ifndef CLI_EMBEDDED
    // CLI_AUTOLOCK(initCs);
    // ::cli::CCliOptions* pOpts = getCliRuntimeOptions(); 
    // #endif

    #ifdef CLI_MONOLITHIC

    // initialize options only needed for 
    // reading following configuration flags - CLI2_SINGLE_PROCESSOR_STRATEGY and CLI2_CPU_AFFINITY_MASK
    // also, CLI2_LOG option readed for use cli logging.
    // Other flags and options ignored

    return initCliMonolithicInt();

    #else

    CLI_AUTOLOCK(initCs);
    ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
    loadModulesInformation(pOpts->modPath, pOpts->excludeModPath, pOpts->extList, pOpts->excludeModulesMaskList, false);
    return 0;

    #endif
   }

