#define CLI_INTERNAL

#include "eiimpl.h"

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#ifndef CLI_OBJPOOLX_H
    #include <cli/objpoolx.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_MESSAGES_H
    #include <cli/messages.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef CLI_TLS_H
    #include <cli/tls.h>
#endif

#ifndef TLSDATA_H
    #include "tlsdata.h"
#endif




//static CLI_TLS INTERFACE_CLI_IERRORINFO* pErrorInfo = 0;
//static CLI_TLS  ::std::vector< INTERFACE_CLI_IERRORINFO* >  * pErrorInfoList = 0;


namespace cli
{
namespace errinfo
{
namespace impl
{

class CDefaultErrorInfo : public CErrorInfoBase
{
        typedef CErrorInfoBase baseClass;

    public:

        CDefaultErrorInfo() : baseClass() {}

        CLI_BEGIN_INTERFACE_MAP2(CDefaultErrorInfo, INTERFACE_CLI_IERRORINFO)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IERRORINFO )
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICREATEERRORINFO )
        CLI_END_INTERFACE_MAP(CDefaultErrorInfo)
        CLIMETHOD_(ULONG, addRef) (THIS)    
           { 
            return (ilint_t)++refCounter;
           }

        CLIMETHOD_(ULONG, release) (THIS)   
           {
            if (! --refCounter) 
               { 
                clear(); // �������
                return 0;
               }
            return (ilint_t)refCounter;
           }

        /* interfaces ::cli::iCreateErrorInfo, ::cli::iErrorInfo method */
        CLIMETHOD(chainErrorInfo) (THIS_ INTERFACE_CLI_IERRORINFO*    pei /* [in] ::cli::iErrorInfo*  pei  */)
           {
            return EC_OK;
           }

};


struct CErrorInfoListHeadCleanup
{
    CErrorInfoListHeadCleanup()
    {
    }

    void operator()() const
    {
     //pErrorInfo = 0;
     //pErrorInfoList = 0;
    };
};

class CPooledErrorInfo;

typedef ::cli::CObjectPool< CDefaultErrorInfo
                          , CPooledErrorInfo
                          , INTERFACE_CLI_IERRORINFO
                          , ::cli::CCriticalSection
                          , CErrorInfoListHeadCleanup
                          > CErrorInfoPool;


class CPooledErrorInfo : public CErrorInfoBase
{
        typedef CErrorInfoBase baseClass;

        CErrorInfoPool  &ownerPool;

    public:

        CPooledErrorInfo(CErrorInfoPool  &op) : baseClass(), ownerPool(op) {}

        CLI_BEGIN_INTERFACE_MAP2(CPooledErrorInfo, INTERFACE_CLI_IERRORINFO)
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IERRORINFO )
            CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ICREATEERRORINFO )
        CLI_END_INTERFACE_MAP(CPooledErrorInfo)
        CLIMETHOD_(ULONG, addRef) (THIS)    
           { 
            return (ilint_t)++refCounter;
           }
        CLIMETHOD_(ULONG, release) (THIS)   
           {
            if (! --refCounter) 
               { 
                clear(); // �������
                ownerPool.putBack(this); // ������ ����� � ���
                return 0;
               }
            #ifdef _WIN32
            if ( (ilint_t)refCounter < 0 ) DebugBreak();
            #endif

            return (ilint_t)refCounter;
           }

        void dumpPooledObject( ::std::wstring &dumpStr )
           {
           }

};


}; // namespace impl
}; // namespace errinfo
}; // namespace cli


::cli::errinfo::impl::CErrorInfoPool errorInfoPool(L"errorInfoPool");

CLIAPIENTRY
INTERFACE_CLI_IERRORINFO*
CLICALL
cliCreateErrorInfo( INTERFACE_CLI_IERRORINFO **pei, INTERFACE_CLI_ICREATEERRORINFO **pcei)
   {
    INTERFACE_CLI_IERRORINFO* pRet = errorInfoPool.getInstance();
    if (pei)  *pei  = pRet;
    if (pcei)
       {        
        pRet->queryInterface( INTERFACE_CLI_ICREATEERRORINFO_IID, (VOID**)pcei );
       }
    return pRet;
   }



//static CLI_TLS ::cli::CCliPtr<INTERFACE_CLI_IERRORINFO> pErrorInfo(0);


CLIAPIENTRY
RCODE 
CLICALL cliGetErrorInfo(INTERFACE_CLI_IERRORINFO** ppi)
   {
    ::cli::CThreadLocalData *ptls = ::cli::CThreadLocalData::get();
    if (!ptls) return EC_TLS_FAIL;

    if (!ptls->pErrorInfo) return EC_NO_ERROR_INFO;
    if (!ppi)   return EC_OK; // simple test call, return Ok, info available
    ptls->pErrorInfo->addRef();
    *ppi = ptls->pErrorInfo;
    return EC_OK;
   }

CLIAPIENTRY
VOID
CLICALL cliClearErrorInfo()
   {
    ::cli::CThreadLocalData *ptls = ::cli::CThreadLocalData::get();
    if (!ptls) return;

    if (!ptls->pErrorInfo) return;
    ptls->pErrorInfo->release();
    ptls->pErrorInfo = 0;
   }

CLIAPIENTRY
BOOL
CLICALL cliErrorInfoAvailable()
   {
    ::cli::CThreadLocalData *ptls = ::cli::CThreadLocalData::get();
    if (!ptls) return FALSE;

    if (!ptls->pErrorInfo) return FALSE;
    return TRUE;
   }


CLIAPIENTRY
RCODE 
CLICALL cliChainErrorInfo(INTERFACE_CLI_IERRORINFO* pi)
   {
    ::cli::CThreadLocalData *ptls = ::cli::CThreadLocalData::get();
    if (!ptls) return EC_TLS_FAIL;

    if (!pi) return EC_OK;
    if (!ptls->pErrorInfo) // is zero ptr?
       { 
        ptls->pErrorInfo = pi; 
        ptls->pErrorInfo->addRef();
        return EC_OK;
       }
    pi->chainErrorInfo(ptls->pErrorInfo);
    //if (ptls->pErrorInfo) alwais non-zero ptr, see above
       ptls->pErrorInfo->release();
    ptls->pErrorInfo = pi; // pi is alwais non-zero
    //if (ptls->pErrorInfo) // see line above
       ptls->pErrorInfo->addRef();
    return EC_OK;
   }



CLIAPIENTRY
VOID
CLICALL cliClearErrorInfoList(BOOL bFinalClear)
   {
    ::cli::CThreadLocalData *ptls = ::cli::CThreadLocalData::get();
    if (!ptls) return; // EC_TLS_FAIL;

    //if (!pErrorInfoList) return;
    ::std::vector< INTERFACE_CLI_IERRORINFO* > &errList = ptls->errorInfoList; //*pErrorInfoList;
    ::std::vector< INTERFACE_CLI_IERRORINFO* >::iterator it = errList.begin();
    for(; it!=errList.end(); ++it)
       {
        (*it)->release();
       }
    errList.clear();
    //if (bFinalClear) delete pErrorInfoList;
   }

CLIAPIENTRY
SIZE_T
CLICALL cliGetErrorInfoList(INTERFACE_CLI_IERRORINFO** ppEL, SIZE_T nItems)
   {
    ::cli::CThreadLocalData *ptls = ::cli::CThreadLocalData::get();
    
    if (!ppEL)
       {
        if (!ptls) return 0;
        else       return (SIZE_T)ptls->errorInfoList.size();
       }
    if (!ptls) return EC_TLS_FAIL;

    //if (!pErrorInfoList) return 0;
    const ::std::vector< INTERFACE_CLI_IERRORINFO* > &errList = ptls->errorInfoList; //*pErrorInfoList;
    ::std::vector< INTERFACE_CLI_IERRORINFO* >::const_iterator it = errList.begin();
    SIZE_T i = 0;
    for(; it!=errList.end() && i!=nItems; ++it, ++i)
       {
        ppEL[i] = *it;
        ppEL[i]->addRef();
       }
    return i;
   }

CLIAPIENTRY
RCODE 
CLICALL cliAppendErrorInfoList(INTERFACE_CLI_IERRORINFO* pErrInfo)
   {
    ::cli::CThreadLocalData *ptls = ::cli::CThreadLocalData::get();
    if (!ptls) return EC_TLS_FAIL;

    /*
    if (!pErrorInfoList)
       {
        try{
            pErrorInfoList = new ::std::vector< INTERFACE_CLI_IERRORINFO* >();
           }
        catch(...)
           {
            return EC_NO_MEM;
           }
       }
    */
    pErrInfo->addRef();   
    ptls->errorInfoList.push_back(pErrInfo); //pErrorInfoList->push_back(pErrInfo);
    return EC_OK;
   }

::std::wstring cliLogErrorInfoAux(INTERFACE_CLI_IERRORINFO* pi, SIZE_T chainIndent)
   {
    ::std::wstring str;
    ::std::wstring indent;
    // ::cli::CiErrorInfo destructor calls release, so for first ptr we need addRef
    ::cli::CiErrorInfo ie(pi);
    //pi->addRef();
    //while(pi)
    while(!!ie)
       {        
        RCODE code = ie.getErrorCode( );
        
        ::std::wstring moduleName;
        ie.getModuleName( moduleName );

        ::std::wstring srcFile; UINT srcLine = 0;
        ie.getSourceFileLine( srcFile, &srcLine );

        INTERFACE_CLI_IARGLIST* arglist = 0;
        ie.getArgList( &arglist );
        if (arglist) arglist->addRef();

        //pi = 0;
        //ie.getChainErrorInfo( &pi );

        str.append(indent);

        switch(code&EC_SOURCE_MASK)
           {
            case EC_SOURCE_CLI:  
                    str.append( ::cli::format::message(L"%1!#08X!", ::cli::format::arg((UINT)code) ) );
                    break;
            case EC_SOURCE_COM:  
                    str.append( ::cli::format::message(L"%1!#08X! (HRESULT: %2!#08X!)", ::cli::format::arg((UINT)code) % (UINT)RC2HR(code) ) );
                    break;
            case EC_SOURCE_WIN32:  
                    str.append( ::cli::format::message(L"%1!#08X! (Win32: %2)", ::cli::format::arg((UINT)code) % (UINT)RC2WIN(code) ) );
                    break;
            case EC_SOURCE_POSIX:  
                    str.append( ::cli::format::message(L"%1!#08X! (Posix/Crt: %2)", ::cli::format::arg((UINT)code) % (INT)RC2POSIX(code) ) );
                    break;
            //default:            
           }
        str.append(1, L' ');

        str.append( ::cli::formatErrorMessage( (moduleName.empty() ? 0 : moduleName.c_str())
                                             , code
                                             , 0 // locale
                                             ,  /* FMF_AUTO_APPEND_LF| */ FMF_IGNORE_FORMAT_LF
                                             , ::cli::format::arg(arglist)
                                             )
                  );

        str.append(L"\n");

        if (!srcFile.empty())
           {
            str.append(indent);
            str.append( ::cli::format::messageEx( L"File: %1, line: %2"
                                                , ::cli::format::arg(srcFile) % srcLine
                                                , FMF_AUTO_APPEND_LF|FMF_IGNORE_FORMAT_LF
                                                )
                      );
           }

        if (arglist && arglist->getCount()>0)
           {
            SIZE_T maxArgs = arglist->getCount();
            for(SIZE_T i=0; i<maxArgs; ++i )
               {
                CCliStr tmp_str; CCliStr_init( tmp_str );
                arglist->getString( i , &tmp_str );
                ::std::wstring dataStr;
                CCliStr_copyFromIfModified( dataStr, tmp_str);
    
                ::std::wstring fmtDataStr = ::cli::format::message(L"[%1] %2", ::cli::format::arg(int(i+1)) % dataStr );
                str.append(indent);
                str.append(fmtDataStr);
                str.append(1, L'\n');
               }
           }

        if (arglist)
           arglist->release();

        //indent.append(4, L' ');
        indent.append(chainIndent, L' ');

        INTERFACE_CLI_IERRORINFO* pTmp = 0;
        ie.getChainErrorInfo( &pTmp );
        if (pTmp) pTmp->release();
        ie = pTmp;
       }

    //cliWriteLogStringW( str.c_str() );
    return str;
   }


CLIAPIENTRY
RCODE 
CLICALL cliLogErrorInfo(INTERFACE_CLI_IERRORINFO* pi, SIZE_T chainIndent)
   {
    ::std::wstring str = cliLogErrorInfoAux(pi, chainIndent);
    cliWriteLogStringW( str.c_str() );
    return EC_OK;
   }

CLIAPIENTRY
RCODE 
CLICALL cliLogErrorInfoList(INTERFACE_CLI_IERRORINFO** ppEL, SIZE_T nItems, SIZE_T chainIndent)
   {
    if (!ppEL) return EC_OK;
    ::std::wstring str;
    for(SIZE_T i=0; i!=nItems; ++i)
       {
        str.append(cliLogErrorInfoAux(const_cast<INTERFACE_CLI_IERRORINFO*>(ppEL[i]), chainIndent));
       }
    cliWriteLogStringW( str.c_str() );
    return EC_OK;
   }

