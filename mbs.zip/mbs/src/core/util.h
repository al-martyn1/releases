#ifndef CORE_UTIL_H
#define CORE_UTIL_H


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_CLI2TYPES_H
    #include <cli/cli2types.h>
#endif

namespace cli
{
namespace util
{

inline
INT isDigit(WCHAR ch)
   {
    if (ch>=L'0' && ch<=L'9') return INT(ch - L'0');
    else return INT(-1);
   }

inline
INT isXDigit(WCHAR ch)
   {
    if (ch>=L'0' && ch<=L'9') return INT(ch - L'0');
    if (ch>=L'a' && ch<=L'f') return INT(ch - L'a') + 10;
    if (ch>=L'A' && ch<=L'F') return INT(ch - L'A') + 10;
    return INT(-1);
   }

inline
UINT uintFromString( const ::std::wstring &str, ::std::wstring::size_type &pos)
   {
    UINT res = 0;
    ::std::wstring::size_type size = str.size(); 
    if (pos==size) return 0; // check there is no digits at all
    // pos = 0; // start pos must be initialized
    for(; pos!=size; ++pos)
       {
        INT d = isDigit(str[pos]);
        if (d<0) return res;
        res *= 10; res += UINT(d);
       }
    pos = str.npos; // signals that all string is digits
    return res;
   }

inline
UINT uintFromString( const ::std::wstring &str, ::std::wstring::size_type *ppos= 0)
   {
    ::std::wstring::size_type pos = ppos ? *ppos : 0;
    UINT res = uintFromString( str, pos );
    if (ppos) *ppos = pos;
    return res;
   }

inline
UINT uintFromXString( const ::std::wstring &str, ::std::wstring::size_type &pos)
   {
    UINT res = 0;
    ::std::wstring::size_type size = str.size(); 
    if (pos==size) return 0; // check there is no digits at all
    // pos = 0; // start pos must be initialized
    for(; pos!=size; ++pos)
       {
        INT d = isXDigit(str[pos]);
        if (d<0) return res;
        res *= 16; res += UINT(d);
       }
    pos = str.npos; // signals that all string is digits
    return res;
   }

inline
UINT uintFromXString( const ::std::wstring &str, ::std::wstring::size_type *ppos= 0)
   {
    ::std::wstring::size_type pos = ppos ? *ppos : 0;
    UINT res = uintFromString( str, pos );
    if (ppos) *ppos = pos;
    return res;
   }


}; // namespace util
}; // namespace cli


#endif /* CORE_UTIL_H */

