/*!
\project ����� ���������� � ����������� ������ - �������� ��� ������� readComponentInfoFromModule.
    \libpath 
    \incpath 
\platform linux
    \libraries dl

*/

#define CLICOMPONENTINFO_CONST_FIELD

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_EXCEPTION_) && !defined(__EXCEPTION__) && !defined(_STLP_EXCEPTION) && !defined(__STD_EXCEPTION)
    #include <exception>
#endif

#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#if defined(LINUX) && defined(_DEBUG) // && defined(MACHINE_ARM)
    #define DL_DEBUG
#endif

#include <cli/cli2.h>

#include <marty/libapi.h>
#include <marty/filename.h>
#include <marty/filesys.h>


using MARTY_FILESYSTEM_NS      getCurrentDirectory;
using MARTY_FILENAME_NS        makeFullPath;
using MARTY_FILENAME_NS        makeCanonical;
using MARTY_LIBAPI_NS          CModuleHandle;

typedef MARTY_LIBAPI_NS tstring string;

int main(int argc, char* argv[])
   {
    if (argc<2)
       {
        std::cout<<"Usage: "<<argv[0]<<" modulename\n";
        return 0;
       }

    for(int i=1; i<argc; ++i)
       {
        string modFullName = makeCanonical(makeFullPath(getCurrentDirectory(), string(argv[i])));
        std::cout<<"\n---------------\nModule: "<<modFullName<<"\n";

        try{
            #ifdef _DEBUG
            std::cout<<"Try to create modHandle\n";
            #endif
            CModuleHandle modHandle /*  = CModuleHandle */ (modFullName.c_str());
            #ifdef _DEBUG
            std::cout<<"Try to get enumProc\n";
            #endif
            cliEnumModuleComponentsProcT enumProc = reinterpret_cast<cliEnumModuleComponentsProcT>(modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME));
            //cliEnumModuleComponentsProcT proc = (cliEnumModuleComponentsProcT)modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME);
            if (!enumProc)
               {
                std::cout<<"Error: not a CLI module\n";
               }
            else
               {
                #ifdef _DEBUG
                std::cout<<"Try to enumerate components\n";
                #endif
                unsigned idx = 0; 
                CCliComponentInfo ci = { 0, 0, 0 };
                while(enumProc(idx++, &ci))
                   {
                    if (!ci.name)
                       {
                        std::cout<<"    \n---\n    Component: error - module takes null name\n";
                       }
                    else
                       {
                        std::cout<<"    \n---\n    Component: "<<ci.name<<"\n";
                       }

                    if (ci.categories)
                       std::cout<<"    Categories: "<<ci.categories<<"\n";

                    /*
                    cli_create_proc_t createProc = reinterpret_cast<cli_create_proc_t>(modHandle.getProcAddress(OLD_CLICREATEPROCNAME));
                    if (createProc)
                       {
                        if (!createProc(ci.name, "IUnknown", 0))
                           {
                            std::cout<<"    Can't create component '"<<ci.name<<"'\n";
                           }
                       }
                    */
                   }
                std::cout<<"    \n---\nTotal "<<idx-1<<" components/classes in module\n";


               }

           }
        catch(const std::exception &e)
           {
            std::cout<<"Error: failed to load module "<<modFullName<<": "<<e.what()<<"\n";
           }
       }

    return 0;
   }


