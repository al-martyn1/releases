#ifndef FP_ATIPARSER_AUTOMATA_H
#define FP_ATIPARSER_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */

#include <stack>
#include "dateTimeHlp.h"


#ifndef CLI_FORMAT_IMPL_CTIFORMATPARSER_STACK_USED
#define CLI_FORMAT_IMPL_CTIFORMATPARSER_STACK_USED
#endif

#ifndef CLI_FORMAT_IMPL_CTIFORMATPARSER_NO_OVERFLOW_CALLS
#define CLI_FORMAT_IMPL_CTIFORMATPARSER_NO_OVERFLOW_CALLS
#endif




namespace cli {
namespace format {
namespace impl {

class CTIFormatParser {

    public:     ::std::wstring       formatedOut ;
    protected:  UINT                 _dtField    ;
    protected:  int                  _width      ;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state
    public:     static const int     ST_atiparser0D1 = 0x00000001; //!< ATIParser:D1
    public:     static const int     ST_atiparser0Eod = 0x80000002; //!< ATIParser:EOD
    public:     static const int     ST_atiparser0Hour1 = 0x00000003; //!< ATIParser:HOUR1
    public:     static const int     ST_atiparser0Min1 = 0x00000004; //!< ATIParser:MIN1
    public:     static const int     ST_atiparser0Msec1 = 0x00000005; //!< ATIParser:MSEC1
    public:     static const int     ST_atiparser0Msec2 = 0x00000006; //!< ATIParser:MSEC2
    public:     static const int     ST_atiparser0Msec3 = 0x00000007; //!< ATIParser:MSEC3
    public:     static const int     ST_atiparser0Msec4 = 0x00000008; //!< ATIParser:MSEC4
    public:     static const int     ST_atiparser0Quot1 = 0x00000009; //!< ATIParser:QUOT1
    public:     static const int     ST_atiparser0Quot2 = 0x0000000A; //!< ATIParser:QUOT2
    public:     static const int     ST_atiparser0Sec1 = 0x0000000B; //!< ATIParser:SEC1
    public:     static const int     ST_atiparser0Spawn1 = 0x0000000C; //!< ATIParser:SPAWN1
    public:     static const int     ST_atiparser0Start = 0x0000000D; //!< ATIParser:START
    public:     static const int     ST_atiparser0W1 = 0x0000000E; //!< ATIParser:W1
    public:     static const int     ST_d1        = 0x0000000F; //!< ATIParser:D1
    public:     static const int     ST_eOD       = 0x80000010; //!< ATIParser:EOD
    public:     static const int     ST_hOUR1     = 0x00000011; //!< ATIParser:HOUR1
    public:     static const int     ST_mIN1      = 0x00000012; //!< ATIParser:MIN1
    public:     static const int     ST_mSEC1     = 0x00000013; //!< ATIParser:MSEC1
    public:     static const int     ST_mSEC2     = 0x00000014; //!< ATIParser:MSEC2
    public:     static const int     ST_mSEC3     = 0x00000015; //!< ATIParser:MSEC3
    public:     static const int     ST_mSEC4     = 0x00000016; //!< ATIParser:MSEC4
    public:     static const int     ST_qUOT1     = 0x00000017; //!< ATIParser:QUOT1
    public:     static const int     ST_qUOT2     = 0x00000018; //!< ATIParser:QUOT2
    public:     static const int     ST_sEC1      = 0x00000019; //!< ATIParser:SEC1
    public:     static const int     ST_sPAWN1    = 0x0000001A; //!< ATIParser:SPAWN1
    public:     static const int     ST_sTART     = 0x0000001B; //!< ATIParser:START
    public:     static const int     ST_w1        = 0x0000001C; //!< ATIParser:W1
    public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__
    public:     static const int     ST_intStateinadmissibleend                                   = 0x8000001D; //!< :
    public:     static const int     LIM_stackSizeMax = 256; //!< Automaticaly generated stack size limit constant
    protected:  std::stack<int>      stateStack  ; //!< Automaticaly generated state stack


    public:     
        void
        putChar
               ( WCHAR  ch          
               )
           {
            /* guard variable - ch */
            switch(this->curState)
               {
                case ST_atiparser0D1:    /* ATIParser:D1 */
                        if ((ch==L'd') && (_width<2)) /* Guard: ['d',(_width<2)] */
                           {
                               /* Transition from ATIParser_0_D1 to ATIParser_0_D1 actions */
                               { ++_width; }
                               /* State ATIParser_0_D1 - do_action empty */
                            this->curState = ST_atiparser0D1;
                           }
                        else
                           {
                               /* State ATIParser_0_D1 - exit_action empty */
                               /* Transition from ATIParser_0_D1 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Hour1:    /* ATIParser:HOUR1 */
                        if ((ch==L'h') && (_width<2)) /* Guard: ['h',(_width<2)] */
                           {
                               /* Transition from ATIParser_0_HOUR1 to ATIParser_0_HOUR1 actions */
                               { ++_width; }
                               /* State ATIParser_0_HOUR1 - do_action empty */
                            this->curState = ST_atiparser0Hour1;
                           }
                        else
                           {
                               /* State ATIParser_0_HOUR1 - exit_action empty */
                               /* Transition from ATIParser_0_HOUR1 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Min1:    /* ATIParser:MIN1 */
                        if ((ch==L'm') && (_width<2)) /* Guard: ['m',(_width<2)] */
                           {
                               /* Transition from ATIParser_0_MIN1 to ATIParser_0_MIN1 actions */
                               { ++_width; }
                               /* State ATIParser_0_MIN1 - do_action empty */
                            this->curState = ST_atiparser0Min1;
                           }
                        else
                           {
                               /* State ATIParser_0_MIN1 - exit_action empty */
                               /* Transition from ATIParser_0_MIN1 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Msec1:    /* ATIParser:MSEC1 */
                        if ((ch==L'c') && (_width<5)) /* Guard: ['c',(_width<5)] */
                           {
                               /* Transition from ATIParser_0_MSEC1 to ATIParser_0_MSEC1 actions */
                               { ++_width; }
                               /* State ATIParser_0_MSEC1 - do_action empty */
                            this->curState = ST_atiparser0Msec1;
                           }
                        else
                           {
                               /* State ATIParser_0_MSEC1 - exit_action empty */
                               /* Transition from ATIParser_0_MSEC1 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Msec2:    /* ATIParser:MSEC2 */
                        if ((ch==L'z') && (_width<5)) /* Guard: ['z',(_width<5)] */
                           {
                               /* Transition from ATIParser_0_MSEC2 to ATIParser_0_MSEC2 actions */
                               { ++_width; }
                               /* State ATIParser_0_MSEC2 - do_action empty */
                            this->curState = ST_atiparser0Msec2;
                           }
                        else
                           {
                               /* State ATIParser_0_MSEC2 - exit_action empty */
                               /* Transition from ATIParser_0_MSEC2 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Msec3:    /* ATIParser:MSEC3 */
                        if ((ch==L'C') && (_width<5)) /* Guard: ['C',(_width<5)] */
                           {
                               /* Transition from ATIParser_0_MSEC3 to ATIParser_0_MSEC3 actions */
                               { ++_width; }
                               /* State ATIParser_0_MSEC3 - do_action empty */
                            this->curState = ST_atiparser0Msec3;
                           }
                        else
                           {
                               /* State ATIParser_0_MSEC3 - exit_action empty */
                               /* Transition from ATIParser_0_MSEC3 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Msec4:    /* ATIParser:MSEC4 */
                        if ((ch==L'Z') && (_width<5)) /* Guard: ['Z',(_width<5)] */
                           {
                               /* Transition from ATIParser_0_MSEC4 to ATIParser_0_MSEC4 actions */
                               { ++_width; }
                               /* State ATIParser_0_MSEC4 - do_action empty */
                            this->curState = ST_atiparser0Msec4;
                           }
                        else
                           {
                               /* State ATIParser_0_MSEC4 - exit_action empty */
                               /* Transition from ATIParser_0_MSEC4 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Quot1:    /* ATIParser:QUOT1 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ATIParser_0_QUOT1 - exit_action empty */
                               /* Transition from ATIParser_0_QUOT1 to ATIParser_0_QUOT2 actions */
                               /* State ATIParser_0_QUOT2 - entry_action empty */
                            this->curState = ST_atiparser0Quot2;
                           }
                        else
                           {
                               /* Transition from ATIParser_0_QUOT1 to ATIParser_0_QUOT1 actions */
                               { aI(ch); }
                               /* State ATIParser_0_QUOT1 - do_action empty */
                            this->curState = ST_atiparser0Quot1;
                           }
                     break;
                case ST_atiparser0Quot2:    /* ATIParser:QUOT2 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ATIParser_0_QUOT2 - exit_action empty */
                               /* Transition from ATIParser_0_QUOT2 to ATIParser_0_QUOT1 actions */
                               { aI(ch); }
                               /* State ATIParser_0_QUOT1 - entry_action empty */
                            this->curState = ST_atiparser0Quot1;
                           }
                        else
                           {
                               /* State ATIParser_0_QUOT2 - exit_action empty */
                               /* Transition from ATIParser_0_QUOT2 to ATIParser_0_SPAWN1 actions */
                               { aFE(DTF_EQ); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Sec1:    /* ATIParser:SEC1 */
                        if ((ch==L's') && (_width<2)) /* Guard: ['s',(_width<2)] */
                           {
                               /* Transition from ATIParser_0_SEC1 to ATIParser_0_SEC1 actions */
                               { ++_width; }
                               /* State ATIParser_0_SEC1 - do_action empty */
                            this->curState = ST_atiparser0Sec1;
                           }
                        else
                           {
                               /* State ATIParser_0_SEC1 - exit_action empty */
                               /* Transition from ATIParser_0_SEC1 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_atiparser0Start:    /* ATIParser:START */
                        if (ch==L'z') /* Guard: ['z'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_MSEC2 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State ATIParser_0_MSEC2 - entry_action empty */
                            this->curState = ST_atiparser0Msec2;
                           }
                        else if (ch==L'w') /* Guard: ['w'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_W1 actions */
                               { _dtField=DTF_WEEK; }
                               /* State ATIParser_0_W1 - entry_action empty */
                            this->curState = ST_atiparser0W1;
                           }
                        else if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_SEC1 actions */
                               { _dtField=DTF_SEC; }
                               /* State ATIParser_0_SEC1 - entry_action empty */
                            this->curState = ST_atiparser0Sec1;
                           }
                        else if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_MIN1 actions */
                               { _dtField=DTF_MIN; }
                               /* State ATIParser_0_MIN1 - entry_action empty */
                            this->curState = ST_atiparser0Min1;
                           }
                        else if (ch==L'h' || ch==L'H') /* Guard: ['h','H'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_HOUR1 actions */
                               { _dtField=DTF_HOUR; }
                               /* State ATIParser_0_HOUR1 - entry_action empty */
                            this->curState = ST_atiparser0Hour1;
                           }
                        else if (ch==L'd') /* Guard: ['d'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_D1 actions */
                               { _dtField=DTF_MDAY; }
                               /* State ATIParser_0_D1 - entry_action empty */
                            this->curState = ST_atiparser0D1;
                           }
                        else if (ch==L'c') /* Guard: ['c'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_MSEC1 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State ATIParser_0_MSEC1 - entry_action empty */
                            this->curState = ST_atiparser0Msec1;
                           }
                        else if (ch==L'_') /* Guard: ['_'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_START actions */
                               { aFE(DTF_DATESEP); }
                               /* State ATIParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_atiparser0Start;
                           }
                        else if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_QUOT1 actions */
                               { aFE(DTF_SQ); }
                               /* State ATIParser_0_QUOT1 - entry_action empty */
                            this->curState = ST_atiparser0Quot1;
                           }
                        else if (ch==L'Z') /* Guard: ['Z'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_MSEC4 actions */
                               { _dtField=DTF_MSEC; }
                               /* State ATIParser_0_MSEC4 - entry_action empty */
                            this->curState = ST_atiparser0Msec4;
                           }
                        else if (ch==L'C') /* Guard: ['C'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_MSEC3 actions */
                               { _dtField=DTF_MSEC; }
                               /* State ATIParser_0_MSEC3 - entry_action empty */
                            this->curState = ST_atiparser0Msec3;
                           }
                        else if (ch==L'?') /* Guard: ['?'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_START actions */
                               { aFE(DTF_IGNORE); }
                               /* State ATIParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_atiparser0Start;
                           }
                        else if (ch==L'=') /* Guard: ['='] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_START actions */
                               { aFE(DTF_TIMESEP); }
                               /* State ATIParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_atiparser0Start;
                           }
                        else if (ch==L'-') /* Guard: ['-'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_START actions */
                               { aFE(DTF_SIGOFF); }
                               /* State ATIParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_atiparser0Start;
                           }
                        else if (ch==L'+') /* Guard: ['+'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_START actions */
                               { aFE(DTF_SIGON); }
                               /* State ATIParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_atiparser0Start;
                           }
                        else if (ch==L'#') /* Guard: ['#'] */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_START actions */
                               { aFE(DTF_SIGNORE); }
                               /* State ATIParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_atiparser0Start;
                           }
                        else
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_START actions */
                               { aI(ch); }
                               /* State ATIParser_0_START - entry_action */
                               { _width=0; }
                            this->curState = ST_atiparser0Start;
                           }
                     break;
                case ST_atiparser0W1:    /* ATIParser:W1 */
                        if ((ch==L'w') && (_width<2)) /* Guard: ['w',(_width<2)] */
                           {
                               /* Transition from ATIParser_0_W1 to ATIParser_0_W1 actions */
                               { ++_width; }
                               /* State ATIParser_0_W1 - do_action empty */
                            this->curState = ST_atiparser0W1;
                           }
                        else
                           {
                               /* State ATIParser_0_W1 - exit_action empty */
                               /* Transition from ATIParser_0_W1 to ATIParser_0_SPAWN1 actions */
                               { aF(); }
                               /* State ATIParser_0_SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_d1:    /* ATIParser:D1 */
                        if ((ch==L'd') && (_width<2)) /* Guard: ['d',(_width<2)] */
                           {
                               /* Transition from D1 to D1 actions */
                               { ++_width; }
                               /* State D1 - do_action empty */
                            this->curState = ST_d1;
                           }
                        else
                           {
                               /* State D1 - exit_action empty */
                               /* Transition from D1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_hOUR1:    /* ATIParser:HOUR1 */
                        if ((ch==L'h') && (_width<2)) /* Guard: ['h',(_width<2)] */
                           {
                               /* Transition from HOUR1 to HOUR1 actions */
                               { ++_width; }
                               /* State HOUR1 - do_action empty */
                            this->curState = ST_hOUR1;
                           }
                        else
                           {
                               /* State HOUR1 - exit_action empty */
                               /* Transition from HOUR1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mIN1:    /* ATIParser:MIN1 */
                        if ((ch==L'm') && (_width<2)) /* Guard: ['m',(_width<2)] */
                           {
                               /* Transition from MIN1 to MIN1 actions */
                               { ++_width; }
                               /* State MIN1 - do_action empty */
                            this->curState = ST_mIN1;
                           }
                        else
                           {
                               /* State MIN1 - exit_action empty */
                               /* Transition from MIN1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC1:    /* ATIParser:MSEC1 */
                        if ((ch==L'c') && (_width<5)) /* Guard: ['c',(_width<5)] */
                           {
                               /* Transition from MSEC1 to MSEC1 actions */
                               { ++_width; }
                               /* State MSEC1 - do_action empty */
                            this->curState = ST_mSEC1;
                           }
                        else
                           {
                               /* State MSEC1 - exit_action empty */
                               /* Transition from MSEC1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC2:    /* ATIParser:MSEC2 */
                        if ((ch==L'z') && (_width<5)) /* Guard: ['z',(_width<5)] */
                           {
                               /* Transition from MSEC2 to MSEC2 actions */
                               { ++_width; }
                               /* State MSEC2 - do_action empty */
                            this->curState = ST_mSEC2;
                           }
                        else
                           {
                               /* State MSEC2 - exit_action empty */
                               /* Transition from MSEC2 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC3:    /* ATIParser:MSEC3 */
                        if ((ch==L'C') && (_width<5)) /* Guard: ['C',(_width<5)] */
                           {
                               /* Transition from MSEC3 to MSEC3 actions */
                               { ++_width; }
                               /* State MSEC3 - do_action empty */
                            this->curState = ST_mSEC3;
                           }
                        else
                           {
                               /* State MSEC3 - exit_action empty */
                               /* Transition from MSEC3 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_mSEC4:    /* ATIParser:MSEC4 */
                        if ((ch==L'Z') && (_width<5)) /* Guard: ['Z',(_width<5)] */
                           {
                               /* Transition from MSEC4 to MSEC4 actions */
                               { ++_width; }
                               /* State MSEC4 - do_action empty */
                            this->curState = ST_mSEC4;
                           }
                        else
                           {
                               /* State MSEC4 - exit_action empty */
                               /* Transition from MSEC4 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_qUOT1:    /* ATIParser:QUOT1 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State QUOT1 - exit_action empty */
                               /* Transition from QUOT1 to QUOT2 actions */
                               /* State QUOT2 - entry_action empty */
                            this->curState = ST_qUOT2;
                           }
                        else
                           {
                               /* Transition from QUOT1 to QUOT1 actions */
                               { aI(ch); }
                               /* State QUOT1 - do_action empty */
                            this->curState = ST_qUOT1;
                           }
                     break;
                case ST_qUOT2:    /* ATIParser:QUOT2 */
                        if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to QUOT1 actions */
                               { aI(ch); }
                               /* State QUOT1 - entry_action empty */
                            this->curState = ST_qUOT1;
                           }
                        else
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to SPAWN1 actions */
                               { aFE(DTF_EQ); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_sEC1:    /* ATIParser:SEC1 */
                        if ((ch==L's') && (_width<2)) /* Guard: ['s',(_width<2)] */
                           {
                               /* Transition from SEC1 to SEC1 actions */
                               { ++_width; }
                               /* State SEC1 - do_action empty */
                            this->curState = ST_sEC1;
                           }
                        else
                           {
                               /* State SEC1 - exit_action empty */
                               /* Transition from SEC1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
                case ST_sTART:    /* ATIParser:START */
                        if (ch==L'z') /* Guard: ['z'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC2 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State MSEC2 - entry_action empty */
                            this->curState = ST_mSEC2;
                           }
                        else if (ch==L'w') /* Guard: ['w'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to W1 actions */
                               { _dtField=DTF_WEEK; }
                               /* State W1 - entry_action empty */
                            this->curState = ST_w1;
                           }
                        else if (ch==L's') /* Guard: ['s'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to SEC1 actions */
                               { _dtField=DTF_SEC; }
                               /* State SEC1 - entry_action empty */
                            this->curState = ST_sEC1;
                           }
                        else if (ch==L'm') /* Guard: ['m'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MIN1 actions */
                               { _dtField=DTF_MIN; }
                               /* State MIN1 - entry_action empty */
                            this->curState = ST_mIN1;
                           }
                        else if (ch==L'h' || ch==L'H') /* Guard: ['h','H'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to HOUR1 actions */
                               { _dtField=DTF_HOUR; }
                               /* State HOUR1 - entry_action empty */
                            this->curState = ST_hOUR1;
                           }
                        else if (ch==L'd') /* Guard: ['d'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to D1 actions */
                               { _dtField=DTF_MDAY; }
                               /* State D1 - entry_action empty */
                            this->curState = ST_d1;
                           }
                        else if (ch==L'c') /* Guard: ['c'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC1 actions */
                               { _dtField=DTF_MSEC|DTF_ZEROS; }
                               /* State MSEC1 - entry_action empty */
                            this->curState = ST_mSEC1;
                           }
                        else if (ch==L'_') /* Guard: ['_'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_DATESEP); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'\'') /* Guard: ['\''] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to QUOT1 actions */
                               { aFE(DTF_SQ); }
                               /* State QUOT1 - entry_action empty */
                            this->curState = ST_qUOT1;
                           }
                        else if (ch==L'Z') /* Guard: ['Z'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC4 actions */
                               { _dtField=DTF_MSEC; }
                               /* State MSEC4 - entry_action empty */
                            this->curState = ST_mSEC4;
                           }
                        else if (ch==L'C') /* Guard: ['C'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to MSEC3 actions */
                               { _dtField=DTF_MSEC; }
                               /* State MSEC3 - entry_action empty */
                            this->curState = ST_mSEC3;
                           }
                        else if (ch==L'?') /* Guard: ['?'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_IGNORE); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'=') /* Guard: ['='] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_TIMESEP); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'-') /* Guard: ['-'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_SIGOFF); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'+') /* Guard: ['+'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_SIGON); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else if (ch==L'#') /* Guard: ['#'] */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aFE(DTF_SIGNORE); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                        else
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to START actions */
                               { aI(ch); }
                               /* State START - entry_action */
                               { _width=0; }
                            this->curState = ST_sTART;
                           }
                     break;
                case ST_w1:    /* ATIParser:W1 */
                        if ((ch==L'w') && (_width<2)) /* Guard: ['w',(_width<2)] */
                           {
                               /* Transition from W1 to W1 actions */
                               { ++_width; }
                               /* State W1 - do_action empty */
                            this->curState = ST_w1;
                           }
                        else
                           {
                               /* State W1 - exit_action empty */
                               /* Transition from W1 to SPAWN1 actions */
                               { aF(); }
                               /* State SPAWN1 - entry_action empty */
                               /* Called state ATIParser_0_START - call_entry_action empty */
                               /* Called State ATIParser_0_START - entry_action */
                               { _width=0; }
                            spawnState(ST_atiparser0Start);
                            /* Recursive send event to called state */
                            this->putChar( ch );
                           }
                     break;
               };

           }

    public:     
        void
        eod
           ( 
           )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_atiparser0D1:    /* ATIParser:D1 */
                           {
                               /* State ATIParser_0_D1 - exit_action empty */
                               /* Transition from ATIParser_0_D1 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Hour1:    /* ATIParser:HOUR1 */
                           {
                               /* State ATIParser_0_HOUR1 - exit_action empty */
                               /* Transition from ATIParser_0_HOUR1 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Min1:    /* ATIParser:MIN1 */
                           {
                               /* State ATIParser_0_MIN1 - exit_action empty */
                               /* Transition from ATIParser_0_MIN1 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Msec1:    /* ATIParser:MSEC1 */
                           {
                               /* State ATIParser_0_MSEC1 - exit_action empty */
                               /* Transition from ATIParser_0_MSEC1 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Msec2:    /* ATIParser:MSEC2 */
                           {
                               /* State ATIParser_0_MSEC2 - exit_action empty */
                               /* Transition from ATIParser_0_MSEC2 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Msec3:    /* ATIParser:MSEC3 */
                           {
                               /* State ATIParser_0_MSEC3 - exit_action empty */
                               /* Transition from ATIParser_0_MSEC3 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Msec4:    /* ATIParser:MSEC4 */
                           {
                               /* State ATIParser_0_MSEC4 - exit_action empty */
                               /* Transition from ATIParser_0_MSEC4 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Quot1:    /* ATIParser:QUOT1 */
                           {
                               /* State ATIParser_0_QUOT1 - exit_action empty */
                               /* Transition from ATIParser_0_QUOT1 to ATIParser_0_EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Quot2:    /* ATIParser:QUOT2 */
                           {
                               /* State ATIParser_0_QUOT2 - exit_action empty */
                               /* Transition from ATIParser_0_QUOT2 to ATIParser_0_EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Sec1:    /* ATIParser:SEC1 */
                           {
                               /* State ATIParser_0_SEC1 - exit_action empty */
                               /* Transition from ATIParser_0_SEC1 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0Start:    /* ATIParser:START */
                           {
                               /* State ATIParser_0_START - exit_action empty */
                               /* Transition from ATIParser_0_START to ATIParser_0_EOD actions */
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_atiparser0W1:    /* ATIParser:W1 */
                           {
                               /* State ATIParser_0_W1 - exit_action empty */
                               /* Transition from ATIParser_0_W1 to ATIParser_0_EOD actions */
                               { aF(); }
                               /* End state ATIParser_0_EOD - entry_action empty */
                               /* Jump to state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_d1:    /* ATIParser:D1 */
                           {
                               /* State D1 - exit_action empty */
                               /* Transition from D1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_hOUR1:    /* ATIParser:HOUR1 */
                           {
                               /* State HOUR1 - exit_action empty */
                               /* Transition from HOUR1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mIN1:    /* ATIParser:MIN1 */
                           {
                               /* State MIN1 - exit_action empty */
                               /* Transition from MIN1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC1:    /* ATIParser:MSEC1 */
                           {
                               /* State MSEC1 - exit_action empty */
                               /* Transition from MSEC1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC2:    /* ATIParser:MSEC2 */
                           {
                               /* State MSEC2 - exit_action empty */
                               /* Transition from MSEC2 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC3:    /* ATIParser:MSEC3 */
                           {
                               /* State MSEC3 - exit_action empty */
                               /* Transition from MSEC3 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_mSEC4:    /* ATIParser:MSEC4 */
                           {
                               /* State MSEC4 - exit_action empty */
                               /* Transition from MSEC4 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_qUOT1:    /* ATIParser:QUOT1 */
                           {
                               /* State QUOT1 - exit_action empty */
                               /* Transition from QUOT1 to EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_qUOT2:    /* ATIParser:QUOT2 */
                           {
                               /* State QUOT2 - exit_action empty */
                               /* Transition from QUOT2 to EOD actions */
                               { aFE(DTF_EQ); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_sEC1:    /* ATIParser:SEC1 */
                           {
                               /* State SEC1 - exit_action empty */
                               /* Transition from SEC1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_sTART:    /* ATIParser:START */
                           {
                               /* State START - exit_action empty */
                               /* Transition from START to EOD actions */
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_w1:    /* ATIParser:W1 */
                           {
                               /* State W1 - exit_action empty */
                               /* Transition from W1 to EOD actions */
                               { aF(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
               };

           }

    protected:  
        virtual
        void
        appendToOut
                   ( WCHAR  ch          
                   , UINT   dtField     
                   , int    width       
                   ) = 0;

    protected:  
        void
        aI
          ( WCHAR  ch          
          )
           {
            appendToOut(ch, 0, 0);
           }

    protected:  
        void
        aF
          ( 
          )
           {
            appendToOut(0, _dtField, _width);
           }

    protected:  
        void
        aFI
           ( WCHAR  ch          
           )
           {
            aF(); aI(ch);
           }

    protected:  
        void
        aFE
           ( unsigned  f           
           )
           {
            appendToOut(0, f, 0);
           }

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->clearStateStack(  );
            this->customResetAutomata(  );
            this->curState = ST_sTART;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return this->curState==ST_intStateinadmissibleend ? 1 : 0;
           }

    protected:  
        int
        callState
                 ( int  newState     //!< new state code
                 )
           {
            try{
                this->stateStack.push(this->curState);
                this->curState = newState;
               }
            catch(...)
               {
                /* calling stackOverflow disabled by generator options */
               }
            return this->curState;
           }

    protected:  
        int
        spawnState
                  ( int  newState     //!< new state code
                  )
           {
                this->curState = newState;
                return this->curState;

           }

    protected:  
        int
        returnFromState
                       ( 
                       )
           {
            if (this->stateStack.empty())
               {
                /* calling stackUnderflow disabled by generator options */
               }
            else
               {
                this->curState = this->stateStack.top();
                this->stateStack.pop();
               }
            return this->curState;
           }

    protected:  
        void
        clearStateStack
                       ( 
                       )
           {
            while(!this->stateStack.empty()) this->stateStack.pop();
           }


};


}; // namespace impl {
}; // namespace format {
}; // namespace cli {

#endif /* FP_ATIPARSER_AUTOMATA_H */
