#ifndef SRC_CORE_STRENC_H
#define SRC_CORE_STRENC_H

/* add this lines to your src
#ifndef CORE_STRENC_H
    #include "strenc.h"
#endif
*/

#ifndef CLI_ISTRENC_H
    #include <cli/istrenc.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#ifndef CLI_STRENC_H
    #include <cli/strenc.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#include "strconvutil.h"



namespace cli
{
namespace impl
{

const unsigned CP_TRANSLIT = 3;
const unsigned CP_UTF16LE  = 1200;
const unsigned CP_UTF16BE  = 1201;


namespace enchlp
{

inline
std::string fromWidePlain( const std::wstring &str)
{
    std::string res; res.reserve(str.size());
    std::wstring::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        res.append(1, (char)(unsigned char)(unsigned)str[i]);
       }
    return res;
}

inline
std::wstring toWidePlain( const std::string &str)
{
    std::wstring res; res.reserve(str.size());
    std::string::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        res.append(1, (wchar_t)(unsigned char)str[i]);
       }
    return res;
}

inline
std::wstring toLowerCopy( const std::wstring &str)
{
    std::wstring res; res.reserve(str.size());
    std::wstring::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        wchar_t ch = str[i];
        if (ch>=L'A' && ch<=L'Z') res.append(1, ch-L'A'+L'a'); 
        else                      res.append(1, ch); 
       }
    return res;
}

inline
std::string toLowerCopy( const std::string &str)
{
    std::string res; res.reserve(str.size());
    std::string::size_type i = 0, size = str.size();
    for(; i!=size; ++i)
       {
        char ch = str[i];
        if (ch>='A' && ch<='Z') res.append(1, ch-'A'+'a'); 
        else                    res.append(1, ch); 
       }
    return res;
}

template <typename TC>
const TC* parseInteger( const TC* pStr, int base, SIZE_T maxCharsParse, int &intVal )
{
    SIZE_T i = 0;
    if (maxCharsParse==0) maxCharsParse = SIZE_T_NPOS;
    intVal = 0;
    for( ;*pStr && i!=maxCharsParse; ++pStr, ++i)
       {
        int d = char2digit( *pStr );
        if (d<0) return pStr;
        if (d>=base) return pStr;
        intVal *= base;
        intVal += d;
       }
    return pStr;
}

template <typename TC>
const TC* parseInteger( const TC* pStr, int base, SIZE_T maxCharsParse, unsigned &intVal )
{
    SIZE_T i = 0;
    if (maxCharsParse==0) maxCharsParse = SIZE_T_NPOS;
    intVal = 0;
    for( ;*pStr && i!=maxCharsParse; ++pStr, ++i)
       {
        int d = char2digit( *pStr );
        if (d<0) return pStr;
        if (d>=base) return pStr;
        intVal *= (unsigned)base;
        intVal += (unsigned)d;
       }
    return pStr;
}


template< typename CharType 
        , typename Traits
        , typename Allocator
        >
bool formatUnsigned( ::std::basic_string<CharType, Traits, Allocator> &strFormatTo
                   , unsigned i, unsigned base = 10
                   , typename ::std::basic_string<CharType, Traits, Allocator>::size_type width = 0
                   , bool upperCase = true
                   )
{
    typedef ::std::basic_string<CharType, Traits, Allocator> string_type;
    typedef typename string_type::size_type  size_type;

    if (base==0) base = 10;

    if (base<2 || base>36) return false;
    size_type startPos = strFormatTo.size();
    size_type numCharsAdded = 0;
    for(; i>0; ++numCharsAdded )
       {
        strFormatTo.append( 1, digit2char<CharType>(i%base) );
        i /= base;
       }
    if (!numCharsAdded) { ++numCharsAdded; strFormatTo.append( 1, (CharType)'0' ); }
    for(; numCharsAdded<width; ++numCharsAdded) strFormatTo.append( 1, (CharType)'0' );
    ::std::reverse( strFormatTo.begin()+startPos, strFormatTo.begin()+startPos+numCharsAdded);
    return true;
} 

inline
SIZE_T getCharSize( const WCHAR *chPtr )
   {
    #if defined(WIN32) || defined(_WIN32)
    const WCHAR *nextChPtr = (const WCHAR*)::CharNextW( chPtr );
    return (nextChPtr - chPtr);
    #else
    return 1;
    #endif
   }

inline
unsigned convertCharToUnsigned( const WCHAR *chPtr, SIZE_T charSize )
   {
    if (charSize<2) return (unsigned)*chPtr;
    return *((unsigned*)chPtr);
   }

inline
unsigned convertCharToUnsigned( const WCHAR *chPtr )
   {
    return convertCharToUnsigned(chPtr,getCharSize(chPtr));
   }



#include "strenctbl.h"

/*
CLI_ARG_USED(encCanonicalNames);
CLI_ARG_USED(encTranslitChars);
CLI_ARG_USED(encTranslitSubsts);
*/

inline
bool operator<(const CEncNameToIndex &e1, const CEncNameToIndex &e2)
   {
    return strcmp(e1.encName, e2.encName)<0 ? true : false;
   }

inline
bool operator<(const CEncodingInfo &e1, const CEncodingInfo &e2)
   {
    return e1.encCode < e2.encCode;
   }

inline
const CEncNameToIndex* findEncodingIndex( const char *encName )
{
    CEncNameToIndex nti; nti.encName = (char *)encName;
    const CEncNameToIndex* pRes = util::binary_find( &encNameToIndex[0], &encNameToIndex[0] + (sizeof(encNameToIndex)/sizeof(encNameToIndex[0])) , nti );
    if (pRes== (&encNameToIndex[0] + (sizeof(encNameToIndex)/sizeof(encNameToIndex[0])))) return 0; // end
    return pRes;
}

inline
const CEncNameToIndex* findEncodingIndex( const std::string &encName )
{
    return findEncodingIndex(toLowerCopy(encName).c_str());
}

inline
const CEncNameToIndex* findEncodingIndex( const std::wstring &encName )
{
    return findEncodingIndex(toLowerCopy(fromWidePlain(encName)));
}

inline
const CEncodingInfo* findEncodingInfo( const char *encName )
{
    const CEncNameToIndex * pNtiRes = findEncodingIndex(encName);
    if (!pNtiRes) return 0;
    return &encInfo[pNtiRes->encIdx];
}

inline
const CEncodingInfo* findEncodingInfo( const std::string &encName )
{
    return findEncodingInfo(toLowerCopy(encName).c_str());
}

inline
const CEncodingInfo* findEncodingInfo( const std::wstring &encName )
{
    return findEncodingInfo(toLowerCopy(fromWidePlain(encName)));
}

inline
const CEncodingInfo* findEncodingInfo( unsigned code )
{
    CEncodingInfo ei; ei.encCode = code;
    const CEncodingInfo* pRes = util::binary_find( &encInfo[0], &encInfo[0] + (sizeof(encInfo)/sizeof(encInfo[0])) , ei );
    if (pRes== (&encInfo[0] + (sizeof(encInfo)/sizeof(encInfo[0]))) ) return 0;
    return pRes;
}


struct CEntityProcessingBase
{
virtual const wchar_t* getEntitiesCharString() const = 0;
virtual bool convertEntityToChar( const std::wstring &entityName, std::wstring &val ) const = 0;
virtual bool convertCharToEntity( wchar_t ch, std::wstring &entityNameAppendTo ) const = 0;
};

bool wstringLess( const wchar_t *str1, const wchar_t *str2)
{
    //return lstrcmpW(str1,str2)<0 ? true : false;
    return ((wcscmp(str1,str2)<0) ? true : false);
}


#include "entitytblHtmlAttr.h"
#include "entitytblHtmlText.h"
#include "entitytblNoEntities.h"
#include "entitytblXmlAttr.h"
#include "entitytblXmlHtmlEntities.h"
#include "entitytblXmlText.h"








}; // namespace enchlp




struct CStringEncoderImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_ISTRINGENCODER
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    //::std::vector<INTERFACE_CLI_IDATANODE*>   nodes;
    UINT codePage;

    CStringEncoderImpl( UINT cp ) : base_impl(DEF_MODULE), codePage(cp)
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CStringEncoderImpl()
       {
       }

    CLI_BEGIN_INTERFACE_MAP(CStringEncoderImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISTRINGENCODER )
    CLI_END_INTERFACE_MAP(CStringEncoderImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    
       { 
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }


    CLIMETHOD(encodingCanonicalNameGet) (THIS_ CLISTR*           _encodingCanonicalName)
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!_encodingCanonicalName) return EC_INVALID_PARAM;

        if (codePage==CP_ACP)   return ::cli::propertyGetImpl( _encodingCanonicalName, std::wstring(L"ansi") );
        if (codePage==CP_OEMCP) return ::cli::propertyGetImpl( _encodingCanonicalName, std::wstring(L"oem") );

        const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( codePage );
        if (!pEncInfo) return EC_NOT_FOUND;
        return ::cli::propertyGetImpl( _encodingCanonicalName, enchlp::toWidePlain( enchlp::encCanonicalNames[pEncInfo->encNameIdx] ) );
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(encodingDescriptionGet) (THIS_ CLISTR*           _encodingDescription)
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!_encodingDescription) return EC_INVALID_PARAM;

        if (codePage==CP_ACP)   return ::cli::propertyGetImpl( _encodingDescription, std::wstring(L"ANSI code page") );
        if (codePage==CP_OEMCP) return ::cli::propertyGetImpl( _encodingDescription, std::wstring(L"OEM  code page") );

        const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( codePage );
        if (!pEncInfo) return EC_NOT_FOUND;
        return ::cli::propertyGetImpl( _encodingDescription, enchlp::toWidePlain( pEncInfo->encInfoString ) );
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    //--------------------

    CLIMETHOD(fromMultibyteExGet) (THIS_ CLISTR*           _fromMultibyteEx
                                       , const CLICSTR*    idx1
                                       , BOOL    idx2 /* [in] bool  idx2  */
                                  )
       {
        if (!_fromMultibyteEx) return EC_INVALID_PARAM;
        if (!idx1) return EC_INVALID_PARAM;

        const CCliCStr *pCliStrToDecode = reinterpret_cast<const CCliCStr*>(idx1);

        return decodeMultibyteString( idx2 // precompose
                                    , pCliStrToDecode->data()
                                    , pCliStrToDecode->size()
                                    , _fromMultibyteEx
                                    );
       }

    CLIMETHOD(fromMultibyteExSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(fromMultibyteExSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                         , const CLICSTR*    idx1
                                    )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(fromMultibyteGet) (THIS_ CLISTR*           _fromMultibyte
                                     , const CLICSTR*    idx1
                                )
       {
        if (!_fromMultibyte) return EC_INVALID_PARAM;
        if (!idx1) return EC_INVALID_PARAM;

        const CCliCStr *pCliStrToDecode = reinterpret_cast<const CCliCStr*>(idx1);

        return decodeMultibyteString( TRUE // precompose
                                    , pCliStrToDecode->data()
                                    , pCliStrToDecode->size()
                                    , _fromMultibyte
                                    );
       }

    CLIMETHOD(fromMultibyteSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(toMultibyteExGet) (THIS_ CLICSTR*          _toMultibyteEx
                                     , const CLISTR*     idx1
                                     , BOOL    idx2 /* [in] bool  idx2  */
                                )
       {
        if (!_toMultibyteEx) return EC_INVALID_PARAM;
        if (!idx1) return EC_INVALID_PARAM;

        const CCliStr *pCliStrToEncode = reinterpret_cast<const CCliStr*>(idx1);

        return encodeWideString( idx2 // compositeCheck
                               , pCliStrToEncode->data()
                               , pCliStrToEncode->size()
                               , 0
                               , 0
                               , _toMultibyteEx
                               );
       }

    CLIMETHOD(toMultibyteExSize1) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(toMultibyteExSize2) (THIS_ SIZE_T*    _size /* [out] size_t _size  */
                                       , const CLISTR*     idx1
                                  )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(toMultibyteGet) (THIS_ CLICSTR*          _toMultibyte
                                   , const CLISTR*     idx1
                              )
       {
        if (!_toMultibyte) return EC_INVALID_PARAM;
        if (!idx1) return EC_INVALID_PARAM;

        const CCliStr *pCliStrToEncode = reinterpret_cast<const CCliStr*>(idx1);

        return encodeWideString( TRUE // compositeCheck
                               , pCliStrToEncode->data()
                               , pCliStrToEncode->size()
                               , 0
                               , 0
                               , _toMultibyte
                               );
       }

    CLIMETHOD(toMultibyteSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }
/*
    BOOL GetCPInfo(
  UINT CodePage,      
  LPCPINFO lpCPInfo   
);
*/

    CLIMETHOD_(DWORD,makeFlagsForEncode)(THIS_ BOOL    compositeCheck)
       {
        #if defined(WIN32) || defined(_WIN32)
        DWORD flags = compositeCheck ? WC_COMPOSITECHECK : 0;
        if (codePage==50220 || codePage==50221 || codePage==50222 || codePage==50225 || codePage==50227 || codePage==50229 ||
            codePage==52936 || codePage==54936 || (codePage>=57002 && codePage<=57011) || codePage==65000 || codePage==65001 || codePage==42
           ) flags = 0;
        return flags;
        #else
        return 0;
        #endif
       }

/*
    CLIMETHOD_(bool, checkIsForceCallbackChar) (THIS_ WCHAR ch
                                               , const WCHAR*    forceCallbackForChars
                                               , SIZE_T    numForceCallbackForChars
                                               )
       {
        SIZE_T i = 0;
        for(; i!=numForceCallbackForChars; ++i, ++forceCallbackForChars)
          {
           if (*forceCallbackForChars==ch) return true;
          }
        return false;
       }
*/

    CLIMETHOD_(bool, checkIsNonconvertableChar) (THIS_ const WCHAR *chPtr
                                          , SIZE_T    numWchars // number of wchar_t's with wich char is represented
                                          , DWORD     wcmbFlags
                                          )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (codePage==CP_UTF7 || codePage==CP_UTF8) return false; // in this encodings any char can be represented

        //CHAR defChar = '?';
        BOOL defCharUsed = 0;

        CHAR bufTmp[64];

        int wtombRes = WideCharToMultiByte( codePage
                                          , wcmbFlags
                                          , chPtr
                                          , (int)numWchars
                                          , &bufTmp[0]
                                          , (int)sizeof(bufTmp)
                                          , 0 // &defChar
                                          , &defCharUsed
                                          );
        if (!wtombRes)    return false; // error
        if (!defCharUsed) return false;
        return true;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    // convert wide string to multibyte
    CLIMETHOD(encodeWideStringBufEx) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                          , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                          , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                          , INTERFACE_CLI_ISTRINGENCODERCALLBACK*    pCallback /* [in] ::cli::iStringEncoderCallback*  callback  */
                                          , const WCHAR*    forceCallbackForChars /* [in,flat] wchar  forceCallbackForChars[]  */
                                          , SIZE_T    numForceCallbackForChars /* [in] size_t  numForceCallbackForChars  */
                                          , CHAR    defChar /* [in] char  defChar  */
                                          , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                          , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                          , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                     )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!pCallback)
           {
            return encodeWideStringBuf(compositeCheck
                                      , strToEncode
                                      , numCharsToEncode
                                      , defChar
                                      , defCharUsed
                                      , bufEncodeTo
                                      , bufEncodeToSize
                                      );
           }

        if (!strToEncode)     return EC_INVALID_PARAM;
        if (!bufEncodeToSize) return EC_INVALID_PARAM;

        // calculate strings len if required
        if (numCharsToEncode        ==SIZE_T_NPOS) numCharsToEncode         = lstrlenW(strToEncode);
        if (forceCallbackForChars)
           {
            if (numForceCallbackForChars==SIZE_T_NPOS) numForceCallbackForChars = lstrlenW(forceCallbackForChars);
           }

        // buffer for temporary string
        std::wstring tmpStr; tmpStr.reserve(numCharsToEncode);

        // make set of force callback chars
        std::set<unsigned> forceCallbackChars;
        SIZE_T charNo = 0;
        SIZE_T charSize = 1;
        if (forceCallbackForChars)
           {
            for(; charNo<numForceCallbackForChars; charNo += charSize)
               {
                charSize = enchlp::getCharSize(&forceCallbackForChars[charNo]);
                forceCallbackChars.insert( enchlp::convertCharToUnsigned(&forceCallbackForChars[charNo], charSize) );
               }
           }
        // prepare source string to convert
        WCHAR callbackConvertBuf[1024];
        SIZE_T callbackConvertBufSize = sizeof(callbackConvertBuf)/sizeof(callbackConvertBuf[0]);

        DWORD wcmbFlags = makeFlagsForEncode(compositeCheck);

        charNo = 0;
        charSize = 1;
        for(; charNo<numCharsToEncode; charNo += charSize)
           {
            charSize = enchlp::getCharSize(&strToEncode[charNo]);
            bool bNeedCallback = false;
            unsigned uChar = enchlp::convertCharToUnsigned(&strToEncode[charNo], charSize);

            if (forceCallbackForChars)
               {
                if (forceCallbackChars.find(uChar)!=forceCallbackChars.end())
                   bNeedCallback = true;
               }
            /*
            if (!bNeedCallback)
               {
                if ( pCallback->isCallbackRequiredForChar( this, &strToEncode[charNo], charSize ))
                   bNeedCallback = true;
               }
            */
            if (!bNeedCallback)
               {
                bNeedCallback = checkIsNonconvertableChar( &strToEncode[charNo], charSize, wcmbFlags );
               }

            if (!bNeedCallback)
               {
                tmpStr.append(&strToEncode[charNo], charSize);
               }
            else
               {
                SIZE_T cbSize = callbackConvertBufSize;
                RCODE cbRes = pCallback->getSpecialReplaceChars( this, &strToEncode[charNo], charSize, &callbackConvertBuf[0], &cbSize );
                if (cbRes) // if error occurs we ignore current processed char
                   {
                    tmpStr.append(&strToEncode[charNo], charSize);
                   }
                else
                   {
                    if (cbSize>callbackConvertBufSize) cbSize = callbackConvertBufSize;
                    tmpStr.append(&callbackConvertBuf[0], cbSize);
                   }
               }
           }

        return encodeWideStringBuf( compositeCheck
                                  , tmpStr.data()
                                  , tmpStr.size()
                                  , defChar
                                  , defCharUsed
                                  , bufEncodeTo
                                  , bufEncodeToSize
                                  );
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(encodeWideStringEx) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                       , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                       , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                       , INTERFACE_CLI_ISTRINGENCODERCALLBACK*    callback /* [in] ::cli::iStringEncoderCallback*  callback  */
                                       , const WCHAR*    forceCallbackForChars /* [in,flat] wchar  forceCallbackForChars[]  */
                                       , SIZE_T    numForceCallbackForChars /* [in] size_t  numForceCallbackForChars  */
                                       , CHAR    defChar /* [in] char  defChar  */
                                       , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                       , CLICSTR*          strEncoded
                                  )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!strToEncode)  return EC_INVALID_PARAM;
        if (!strEncoded)   return EC_INVALID_PARAM;

        CCliCStr *pCliStrEncoded = reinterpret_cast<CCliCStr*>(strEncoded);

        SIZE_T bufEncodeToRequiredSize = 0;

        RCODE tmpRes = encodeWideStringBufEx(compositeCheck
                                          , strToEncode
                                          , numCharsToEncode
                                          , callback
                                          , forceCallbackForChars
                                          , numForceCallbackForChars
                                          , defChar
                                          , defCharUsed
                                          , 0 // get required len
                                          , &bufEncodeToRequiredSize
                                          );
        if (tmpRes) return tmpRes;
        if (!pCliStrEncoded->hasAllocator()) pCliStrEncoded->createAllocator();
        if (!pCliStrEncoded->reserve(bufEncodeToRequiredSize-1))
           return EC_NOT_ENOUGH_MEM;

        tmpRes = encodeWideStringBufEx(compositeCheck
                                          , strToEncode
                                          , numCharsToEncode
                                          , callback
                                          , forceCallbackForChars
                                          , numForceCallbackForChars
                                          , defChar
                                          , defCharUsed
                                          , pCliStrEncoded->data() // get required len
                                          , &bufEncodeToRequiredSize
                                          );
        if (tmpRes) return tmpRes;
        pCliStrEncoded->setStringSize(bufEncodeToRequiredSize);
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    void swapUint16Bytes( UINT16 *pu )
       {
        UINT8 *pu8 = (UINT8*)pu;
        UINT8 *pu8_next = pu8+1;

        UINT8 tmp = *pu8;
        *pu8 = *pu8_next;
        *pu8_next = tmp;
       }

    void swapUint32Words( UINT32 *pu )
       {
        UINT16 *pu16 = (UINT16*)pu;
        UINT16 *pu16_next = pu16+1;

        UINT16 tmp = *pu16;
        *pu16 = *pu16_next;
        *pu16_next = tmp;
       }

    void swapUint32Bytes( UINT32 *pu )
       {
        swapUint32Words( pu );
        swapUint16Bytes( ((UINT16*)pu) );
        swapUint16Bytes( ((UINT16*)pu) + 1 );
       }

    void swapWcharBytes( WCHAR *pw )
       {
        if (sizeof(WCHAR)==sizeof(UINT16)) swapUint16Bytes( (UINT16*)pw );
        else                               swapUint32Bytes( (UINT32*)pw );
       }


    CLIMETHOD(encodeWideStringBuf) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                        , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                        , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                        , CHAR    defChar /* [in] char  defChar  */
                                        , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                        , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                        , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                   )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!strToEncode)     return EC_INVALID_PARAM;
        if (!bufEncodeToSize) return EC_INVALID_PARAM;

        if (codePage==CP_UTF16LE || codePage==CP_UTF16BE)
           {
            #if !defined(CLI_PLATFORM_BIG_ENDIAN) && !defined(CLI_PLATFORM_LITTLE_ENDIAN)
                #error "Undefined platform endiannes"
            #endif

            if (numCharsToEncode==SIZE_T_NPOS) numCharsToEncode = lstrlenW(strToEncode);

            if (!bufEncodeTo)
               {
                *bufEncodeToSize = numCharsToEncode*sizeof(WCHAR) + 1;
                return EC_OK;
               }
            bool needReorderCharBytes = false;
            
            #if defined(CLI_PLATFORM_LITTLE_ENDIAN)
            if (codePage==CP_UTF16BE) needReorderCharBytes = true;
            #else // big endian platform
            if (codePage!=CP_UTF16LE) needReorderCharBytes = true;
            #endif

            SIZE_T numBytesToWrite  = *bufEncodeToSize - 1;
            SIZE_T numWcharsToWrite = numBytesToWrite / sizeof(WCHAR);
            if (numWcharsToWrite>numCharsToEncode)  numWcharsToWrite = numCharsToEncode;
            SIZE_T wci = 0;
            WCHAR *pwDest      = (WCHAR*)bufEncodeTo;
            const WCHAR* pwSrc = strToEncode;
            for(; wci!=numWcharsToWrite; ++wci, ++pwSrc, ++pwDest )
               {
                *pwDest = *pwSrc;
                if (needReorderCharBytes) swapWcharBytes(pwDest);
               }
            SIZE_T numBytesWritten = numWcharsToWrite * sizeof(WCHAR);
            bufEncodeTo[numBytesWritten] = 0;
            *bufEncodeToSize = numBytesWritten+1;
           }
        else if (codePage==CP_TRANSLIT)
           {
            if (numCharsToEncode==SIZE_T_NPOS) numCharsToEncode = lstrlenW(strToEncode);

            if (!bufEncodeTo)
               {
                *bufEncodeToSize = numCharsToEncode + 1;
                return EC_OK;
               }
            if (!defChar) defChar = '?';

            std::string res; res.reserve(numCharsToEncode);
            SIZE_T i = 0;
            for(; i!=numCharsToEncode; ++i, ++strToEncode)
               {
                if (*strToEncode<127)
                   {
                    res.append(1, (char)(unsigned char)*strToEncode);
                   }
                else
                   {
                    const wchar_t *pFoundTranslit = util::binary_find( enchlp::encTranslitChars, enchlp::encTranslitChars+(sizeof(enchlp::encTranslitChars)/sizeof(enchlp::encTranslitChars[0])), *strToEncode );
                    if (pFoundTranslit!=( enchlp::encTranslitChars+(sizeof(enchlp::encTranslitChars)/sizeof(enchlp::encTranslitChars[0])) ))
                       {
                        SIZE_T translitIdx = pFoundTranslit - enchlp::encTranslitChars;
                        res.append(enchlp::encTranslitSubsts[translitIdx]);
                       }
                    else
                       {
                        res.append(1,defChar);
                        if (defCharUsed) *defCharUsed = TRUE;
                       }
                   }
               }

            SIZE_T numCharsToCopy = *bufEncodeToSize - 1;
            if (numCharsToCopy>res.size()) numCharsToCopy = res.size();
    
            res.copy( bufEncodeTo, numCharsToCopy );
            bufEncodeTo[numCharsToCopy] = 0;
            *bufEncodeToSize = numCharsToCopy+1;
           }
        else
           {
            DWORD flags = makeFlagsForEncode(compositeCheck);
    
            if ((defChar<' ' || defChar>126) && defChar!=0) defChar = '?';
            LPCSTR lpDefaultChar = &defChar;
    
            BOOL defCharUsedTmp = 0;
            LPBOOL lpUsedDefaultChar = &defCharUsedTmp;
            if (defCharUsed)
               {
                *defCharUsed = 0;
                lpUsedDefaultChar = defCharUsed;
               }
    
            if (codePage==CP_UTF7 || codePage==CP_UTF8)
               {
                lpDefaultChar = 0;
                lpUsedDefaultChar = 0;
               }
    
            if (defChar==0) // use system default defChar
               lpDefaultChar = 0;
    
            int cchWideChar = (numCharsToEncode==SIZE_T_NPOS) ? (int)-1 : (int)numCharsToEncode;
    
            int cbMultiByte = 0;
            if (bufEncodeTo)
               cbMultiByte = (int)*bufEncodeToSize;
            int wtombRes = WideCharToMultiByte( codePage
                                              , flags
                                              , strToEncode
                                              , cchWideChar
                                              , bufEncodeTo
                                              , cbMultiByte
                                              , lpDefaultChar
                                              , lpUsedDefaultChar
                                              );
            if (!wtombRes) return WIN2RC(GetLastError());
            *bufEncodeToSize = (unsigned)wtombRes;
           }
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(encodeWideString) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                     , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                     , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                     , CHAR    defChar /* [in] char  defChar  */
                                     , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                     , CLICSTR*          strEncoded
                                )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!strToEncode)  return EC_INVALID_PARAM;
        if (!strEncoded)   return EC_INVALID_PARAM;

        CCliCStr *pCliStrEncoded = reinterpret_cast<CCliCStr*>(strEncoded);

        SIZE_T bufEncodeToRequiredSize = 0;

        RCODE tmpRes = encodeWideStringBuf(compositeCheck
                                          , strToEncode
                                          , numCharsToEncode
                                          , defChar
                                          , defCharUsed
                                          , 0 // get required len
                                          , &bufEncodeToRequiredSize
                                          );
        if (tmpRes) return tmpRes;
        if (!pCliStrEncoded->hasAllocator()) pCliStrEncoded->createAllocator();
        if (!pCliStrEncoded->reserve(bufEncodeToRequiredSize-1))
           return EC_NOT_ENOUGH_MEM;

        tmpRes = encodeWideStringBuf(compositeCheck
                                          , strToEncode
                                          , numCharsToEncode
                                          , defChar
                                          , defCharUsed
                                          , pCliStrEncoded->data() // get required len
                                          , &bufEncodeToRequiredSize
                                          );
        if (tmpRes) return tmpRes;
        pCliStrEncoded->setStringSize(bufEncodeToRequiredSize);
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(decodeMultibyteStringBuf) (THIS_ BOOL    precompose /* [in] bool  precompose  */
                                             , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                             , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                             , WCHAR*    bufDecodeTo /* [out,flat] wchar bufDecodeTo[]  */
                                             , SIZE_T*    bufDecodeToSize /* [in,out] size_t bufDecodeToSize  */
                                        )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!strToDecode)     return EC_INVALID_PARAM;
        if (!bufDecodeToSize) return EC_INVALID_PARAM;

        if (codePage==CP_UTF16LE || codePage==CP_UTF16BE)
           {
            #if !defined(CLI_PLATFORM_BIG_ENDIAN) && !defined(CLI_PLATFORM_LITTLE_ENDIAN)
                #error "Undefined platform endiannes"
            #endif

            if (numCharsToDecode==SIZE_T_NPOS) return EC_INVALID_PARAM;
            SIZE_T numWideCharsToDecode = numCharsToDecode / sizeof(WCHAR);

            if (!bufDecodeTo)
               {
                *bufDecodeToSize = numWideCharsToDecode + 1;
                return EC_OK;
               }
            bool needReorderCharBytes = false;
            
            #if defined(CLI_PLATFORM_LITTLE_ENDIAN)
            if (codePage==CP_UTF16BE) needReorderCharBytes = true;
            #else // big endian platform
            if (codePage!=CP_UTF16LE) needReorderCharBytes = true;
            #endif

            SIZE_T numWcharsToWrite = *bufDecodeToSize - 1;
            if (numWcharsToWrite > numWideCharsToDecode) numWcharsToWrite = numWideCharsToDecode;

            WCHAR *pwDest      = bufDecodeTo;
            const WCHAR *pwSrc = (const WCHAR*)strToDecode;

            SIZE_T wci = 0;
            for(; wci!=numWcharsToWrite; ++wci, ++pwSrc, ++pwDest )
               {
                *pwDest = *pwSrc;
                if (needReorderCharBytes) swapWcharBytes(pwDest);
               }

            bufDecodeTo[numWcharsToWrite] = 0;
            *bufDecodeToSize = numWcharsToWrite+1;
           }
        else if (codePage==CP_TRANSLIT)
           {
            if (numCharsToDecode==SIZE_T_NPOS) numCharsToDecode = lstrlenA(strToDecode);

            if (!bufDecodeTo)
               {
                *bufDecodeToSize = numCharsToDecode + 1;
                return EC_OK;
               }

            std::wstring res; res.reserve(numCharsToDecode);
            SIZE_T i = 0;
            for(; i!=numCharsToDecode; ++i, ++strToDecode)
               {
                res.append(1, (wchar_t)(unsigned char)*strToDecode);
               }

            SIZE_T numCharsToCopy = *bufDecodeToSize - 1;
            if (numCharsToCopy>res.size()) numCharsToCopy = res.size();
    
            res.copy( bufDecodeTo, numCharsToCopy );
            bufDecodeTo[numCharsToCopy] = 0;
            *bufDecodeToSize = numCharsToCopy+1;        
           }
        else
           {
            DWORD flags = precompose ? MB_PRECOMPOSED : MB_COMPOSITE;
            if (codePage==50220 || codePage==50221 || codePage==50222 || codePage==50225 || codePage==50227 || codePage==50229 ||
                codePage==52936 || codePage==54936 || (codePage>=57002 && codePage<=57011) || codePage==65000 || codePage==65001 || codePage==42
               ) flags = 0;
    
            if (numCharsToDecode==SIZE_T_NPOS) 
               numCharsToDecode = lstrlenA(strToDecode);
            int cbMultiByte = (numCharsToDecode==SIZE_T_NPOS) ? (int)-1 : (int)numCharsToDecode;
            int cchWideChar = 0;
            if (bufDecodeTo)
               cchWideChar = (int)*bufDecodeToSize;
            
            int mbtowcRes = numCharsToDecode ? MultiByteToWideChar( codePage
                                               , flags
                                               , strToDecode
                                               , cbMultiByte
                                               , bufDecodeTo
                                               , cchWideChar
                                               )
                                             : 1 ;
            if (!mbtowcRes) 
               return WIN2RC(GetLastError());
            *bufDecodeToSize = (unsigned)mbtowcRes;
           }
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(decodeMultibyteString) (THIS_ BOOL    precompose /* [in] bool  precompose  */
                                          , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                          , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                          , CLISTR*          strDecoded
                                     )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!strToDecode)  return EC_INVALID_PARAM;
        if (!strDecoded)   return EC_INVALID_PARAM;

        CCliStr *pCliStrDecoded = reinterpret_cast<CCliStr*>(strDecoded);

        SIZE_T bufDecodeToRequiredSize = 0;

        RCODE tmpRes = decodeMultibyteStringBuf( precompose
                                          , strToDecode
                                          , numCharsToDecode
                                          , 0 // get required len
                                          , &bufDecodeToRequiredSize
                                          );
        if (tmpRes) return tmpRes;
        if (!pCliStrDecoded->hasAllocator()) pCliStrDecoded->createAllocator();
        if (!pCliStrDecoded->reserve(bufDecodeToRequiredSize-1))
           return EC_NOT_ENOUGH_MEM;

        tmpRes = decodeMultibyteStringBuf( precompose
                                          , strToDecode
                                          , numCharsToDecode
                                          , pCliStrDecoded->data() // get required len
                                          , &bufDecodeToRequiredSize
                                          );
        if (tmpRes) return tmpRes;
        pCliStrDecoded->setStringSize(bufDecodeToRequiredSize);
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }




}; // CStringEncoderImpl






struct CEncoderManagerImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_ISTRINGENCODERMANAGER
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    //::std::vector<INTERFACE_CLI_IDATANODE*>   nodes;
    

    CEncoderManagerImpl() : base_impl(DEF_MODULE)
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CEncoderManagerImpl()
       {
       }

    CLI_BEGIN_INTERFACE_MAP(CEncoderManagerImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISTRINGENCODERMANAGER )
    CLI_END_INTERFACE_MAP(CEncoderManagerImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    
       { 
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }

    CLIMETHOD(encodingCanonicalNameGet) (THIS_ CLISTR*           _encodingCanonicalName
                                             , UINT    idx1 /* [in] uint  idx1  */
                                        )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!_encodingCanonicalName) return EC_INVALID_PARAM;

        if (idx1==CP_ACP)   return ::cli::propertyGetImpl( _encodingCanonicalName, std::wstring(L"ansi") );
        if (idx1==CP_OEMCP) return ::cli::propertyGetImpl( _encodingCanonicalName, std::wstring(L"oem") );

        const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( idx1 );
        if (!pEncInfo) return EC_NOT_FOUND;
        return ::cli::propertyGetImpl( _encodingCanonicalName, enchlp::toWidePlain( enchlp::encCanonicalNames[pEncInfo->encNameIdx] ) );
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(encodingCanonicalNameSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(encodingDescriptionGet) (THIS_ CLISTR*           _encodingDescription
                                           , UINT    idx1 /* [in] uint  idx1  */
                                      )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!_encodingDescription) return EC_INVALID_PARAM;

        if (idx1==CP_ACP)   return ::cli::propertyGetImpl( _encodingDescription, std::wstring(L"ANSI code page") );
        if (idx1==CP_OEMCP) return ::cli::propertyGetImpl( _encodingDescription, std::wstring(L"OEM  code page") );

        const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( idx1 );
        if (!pEncInfo) return EC_NOT_FOUND;
        return ::cli::propertyGetImpl( _encodingDescription, enchlp::toWidePlain( pEncInfo->encInfoString ) );
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(encodingDescriptionSize) (THIS_ SIZE_T*    _size /* [out] size_t _size  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(getEncodingIdByName) (THIS_ const CLISTR*     encodingName
                                        , UINT*    id /* [out] uint id  */
                                   )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!encodingName) return EC_INVALID_PARAM;

        std::wstring strEncName = enchlp::toLowerCopy(stdstr(encodingName));
        if (strEncName==L"ansi")
           {
            if (id) *id = CP_ACP;
            return EC_OK;
           }
        if (strEncName==L"oem")
           {
            if (id) *id = CP_OEMCP;
            return EC_OK;
           }

        const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( strEncName );
        if (!pEncInfo) return EC_NOT_FOUND;
        if (id) *id = pEncInfo->encCode;
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(getEncodingIdByNameChars) (THIS_ const WCHAR*    encodingName /* [in,flat] wchar  encodingName[]  */
                                           , UINT*    id /* [out] uint id  */
                                      )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!encodingName) return EC_INVALID_PARAM;

        std::wstring strEncName = enchlp::toLowerCopy(stdstr(encodingName));
        if (strEncName==L"ansi")
           {
            if (id) *id = CP_ACP;
            return EC_OK;
           }
        if (strEncName==L"oem")
           {
            if (id) *id = CP_OEMCP;
            return EC_OK;
           }

        const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( strEncName );
        if (!pEncInfo) return EC_NOT_FOUND;
        if (id) *id = pEncInfo->encCode;
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(getEncodingIdByMultibyteName) (THIS_ const CLICSTR*    encodingName
                                                 , UINT*    id /* [out] uint id  */
                                            )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!encodingName) return EC_INVALID_PARAM;

        std::string strEncName = enchlp::toLowerCopy(stdstr(encodingName));
        if (strEncName=="ansi")
           {
            if (id) *id = CP_ACP;
            return EC_OK;
           }
        if (strEncName=="oem")
           {
            if (id) *id = CP_OEMCP;
            return EC_OK;
           }

        const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( strEncName );
        if (!pEncInfo) return EC_NOT_FOUND;
        if (id) *id = pEncInfo->encCode;
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(getEncodingIdByMultibyteNameChars) (THIS_ const CHAR*    encodingName /* [in,flat] char  encodingName[]  */
                                                    , UINT*    id /* [out] uint id  */
                                               )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!encodingName) return EC_INVALID_PARAM;

        std::string strEncName = enchlp::toLowerCopy(stdstr(encodingName));
        if (strEncName=="ansi")
           {
            if (id) *id = CP_ACP;
            return EC_OK;
           }
        if (strEncName=="oem")
           {
            if (id) *id = CP_OEMCP;
            return EC_OK;
           }

        const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( strEncName );
        if (!pEncInfo) return EC_NOT_FOUND;
        if (id) *id = pEncInfo->encCode;
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(getStringEncoder) (THIS_ UINT    encId /* [in] uint  encId  */
                                     , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                )
       {
        #if defined(WIN32) || defined(_WIN32)
        if (!pStringEncoder) return EC_INVALID_PARAM;

        if (encId!=CP_ACP && encId!=CP_OEMCP) // not a well-known encoding
           { // check
            const enchlp::CEncodingInfo* pEncInfo = enchlp::findEncodingInfo( encId );
            if (!pEncInfo) return EC_INVALID_PARAM;
           }

        *pStringEncoder = new CStringEncoderImpl(encId);
        return EC_OK;
        #else
        return EC_NOT_IMPLEMENTED;
        #endif
       }

    CLIMETHOD(getStringEncoderByName) (THIS_ const CLISTR*     encodingName
                                           , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                      )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, encodingName );
        CLIMETHOD_IMPL_CHECK_OUT_PTR(2, pStringEncoder );
        UINT encId = 0;
        RCODE rcRes = getEncodingIdByName( encodingName, &encId );
        if (rcRes) return rcRes;
        return getStringEncoder( encId, pStringEncoder );
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(getStringEncoderByMultibyteName) (THIS_ const CLICSTR*    encodingName
                                                    , INTERFACE_CLI_ISTRINGENCODER**    pStringEncoder /* [out] ::cli::iStringEncoder* pStringEncoder  */
                                               )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, encodingName );
        CLIMETHOD_IMPL_CHECK_OUT_PTR(2, pStringEncoder );
        UINT encId = 0;
        RCODE rcRes = getEncodingIdByMultibyteName( encodingName, &encId );
        if (rcRes) return rcRes;
        return getStringEncoder( encId, pStringEncoder );
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(detectBomBuf) (THIS_ ENUM_CLI_EBOMTYPE*    bomType /* [out] ::cli::EBomType bomType  */
                                 , SIZE_T*    bomSize /* [out,optional] size_t bomSize  */
                                 , const CHAR*    docData /* [in,flat] char  docData[]  */
                                 , SIZE_T    docDataSize /* [in] size_t  docDataSize  */
                            )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, bomType );
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(3, docData );
        if (!docDataSize) CLIMETHOD_IMPL_THROW_PARAM_ERROR( 4, docDataSize, EC_NO_DATA_FOR_READING );
        SIZE_T resBomSize = 0;
        ENUM_CLI_EBOMTYPE resBomType = detectEncodingBomImplementation(docData,docDataSize,resBomSize);
        *bomType = resBomType;
        if (bomSize) *bomSize = resBomSize;
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(detectBom) (THIS_ ENUM_CLI_EBOMTYPE*    bomType /* [out] ::cli::EBomType bomType  */
                              , SIZE_T*    bomSize /* [out,optional] size_t bomSize  */
                              , const CLICSTR*    docData
                         )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, bomType );
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(3, docData );
        return detectBomBuf(bomType,bomSize,clipstr_data((const CLIPCSTR)docData), clipstr_size((const CLIPCSTR)docData));
        CLIMETHOD_IMPL_END();
       }

}; // struct CEncoderManagerImpl





struct CStringSpecialEncoderXmlHtmlBaseImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_ISTRINGENCODERCALLBACK
                      , public INTERFACE_CLI_ISTRINGSPECIALENCODER
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    INTERFACE_CLI_ISTRINGENCODER *pDefEncoder;

    enchlp::CEntityProcessingBase *pBaseEntities;
    enchlp::CEntityProcessingBase *pExtendedEntities;

    std::map< std::wstring, std::wstring> customEntities;
    std::map< WCHAR, std::wstring>        customCharEntities;

    std::wstring allEntitiesString;

    void makeAllEntitiesString()
    {
        allEntitiesString.clear();
        if (pBaseEntities)     allEntitiesString.append( pBaseEntities    ->getEntitiesCharString() );
        if (pExtendedEntities) allEntitiesString.append( pExtendedEntities->getEntitiesCharString() );
    }

    CStringSpecialEncoderXmlHtmlBaseImpl( enchlp::CEntityProcessingBase *pbe, enchlp::CEntityProcessingBase *pxe ) 
         : base_impl(DEF_MODULE), pDefEncoder(0)
         , pBaseEntities(pbe)
         , pExtendedEntities(pxe)
         , customEntities()
         , customCharEntities()
         , allEntitiesString()
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CStringSpecialEncoderXmlHtmlBaseImpl()
       {
        if (pDefEncoder) pDefEncoder->release();
       }
/*
    // finds char in predefined set to replace with entity name
    CLIMETHOD_(bool, isWellKnownEntityChar)( const WCHAR *chPtr, SIZE_T charSize ) const
       {
        return false;
       }

    // finds char in user set to replace with entity name
    CLIMETHOD_(bool, isUserEntityChar)( const WCHAR *chPtr, SIZE_T charSize ) const
       {
        return false;
       }

    // finds entity in predefined set to replace with single char or string
    CLIMETHOD_(bool, isWellKnownEntity)( const WCHAR *entityName, SIZE_T len ) const
       {
        return false;
       }

    // finds entity in user set to replace with single char or string
    CLIMETHOD_(bool, isUserEntity)( const WCHAR *entityName, SIZE_T len ) const
       {
        return false;
       }
*/

    CLI_BEGIN_INTERFACE_MAP2(CStringSpecialEncoderXmlHtmlBaseImpl, INTERFACE_CLI_ISTRINGENCODERCALLBACK)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISTRINGENCODERCALLBACK )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISTRINGSPECIALENCODER )
    CLI_END_INTERFACE_MAP(CStringSpecialEncoderXmlHtmlBaseImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    
       { 
        return addRefImpl();
       }

    CLIMETHOD_(ULONG, release) (THIS)
       {
        return releaseImpl();
       }

    CLIMETHOD_(bool, convertEntity)( const std::wstring &entityName, std::wstring &val ) const
       {
        std::map< std::wstring, std::wstring>::const_iterator ceIt = customEntities.begin();
        if (ceIt != customEntities.end())
           {
            val = ceIt->second;
            return true;
           }

        if (pBaseEntities    ->convertEntityToChar( entityName, val )) return true;
        if (pExtendedEntities->convertEntityToChar( entityName, val )) return true;

        return false;
       }

    /* interface ::cli::iStringSpecialEncoder methods */
    CLIMETHOD(defEncoderGet) (THIS_ INTERFACE_CLI_ISTRINGENCODER**    _defEncoder /* [out] ::cli::iStringEncoder* _defEncoder  */)
       {
        if (!_defEncoder) return EC_INVALID_PARAM;
        *_defEncoder = pDefEncoder;
        return EC_OK;
       }

    CLIMETHOD(defEncoderSet) (THIS_ INTERFACE_CLI_ISTRINGENCODER*    _defEncoder /* [in] ::cli::iStringEncoder*  _defEncoder  */)
       {
        if (pDefEncoder) pDefEncoder->release();
        pDefEncoder = _defEncoder;
        if (pDefEncoder) pDefEncoder->addRef();
        return EC_OK;
       }

    CLIMETHOD(addEntity) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */
                              , const WCHAR*    val /* [in,flat] wchar  val[]  */
                         )
       {
        if (!name) return EC_INVALID_PARAM;
        if (!val)  return EC_INVALID_PARAM;

        std::wstring entityVal = stdstr(val);
        std::wstring entityName = stdstr(name);
        if (!entityName.empty()) return EC_INVALID_PARAM;
        if (!entityVal.empty())  return EC_INVALID_PARAM;

        if (entityVal.size()==1) customCharEntities[entityVal[0]] = entityName;
        customEntities[entityName] = entityVal;
        return EC_OK;
       }

    CLIMETHOD(encodeWideStringBuf) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                        , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                        , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                        , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                        , CHAR    defChar /* [in] char  defChar  */
                                        , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                        , CHAR*    bufEncodeTo /* [out,flat] char bufEncodeTo[]  */
                                        , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                   )
       {
        if (!pEncoder) pEncoder = pDefEncoder;
        if (!pEncoder) return EC_INVALID_PARAM;

        return pEncoder->encodeWideStringBufEx( compositeCheck
                                              , strToEncode
                                              , numCharsToEncode
                                              , this
                                              , allEntitiesString.c_str() // forceCallbackForChars
                                              , 0 // tablesSize - charsOffset  numForceCallbackForChars
                                              , defChar
                                              , defCharUsed
                                              , bufEncodeTo
                                              , bufEncodeToSize
                                              );
       }

    CLIMETHOD(encodeWideString) (THIS_ BOOL    compositeCheck /* [in] bool  compositeCheck  */
                                     , const WCHAR*    strToEncode /* [in,flat] wchar  strToEncode[]  */
                                     , SIZE_T    numCharsToEncode /* [in] size_t  numCharsToEncode  */
                                     , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                     , CHAR    defChar /* [in] char  defChar  */
                                     , BOOL*    defCharUsed /* [out] bool defCharUsed  */
                                     , CLICSTR*          strEncoded
                                )
       {
        if (!pEncoder) pEncoder = pDefEncoder;
        if (!pEncoder) return EC_INVALID_PARAM;

        return pEncoder->encodeWideStringEx( compositeCheck
                                              , strToEncode
                                              , numCharsToEncode
                                              , this
                                              , allEntitiesString.c_str() // forceCallbackForChars
                                              , 0 // tablesSize - charsOffset  numForceCallbackForChars
                                              , defChar
                                              , defCharUsed
                                              , strEncoded
                                              );
       }

    CLIMETHOD_(std::wstring, expandEntities)( const std::wstring &str ) const
       {
        std::wstring strRes; strRes.reserve(str.size());
        std::wstring::size_type i=0, size=str.size();
        for(; i!=size; ++i)
           {
            wchar_t ch = str[i];
            if (ch!=L'&') strRes.append(1,ch);
            else
               {
                ++i;
                if (i==size)
                   {
                    strRes.append(1,L'&');
                    return strRes;
                   }
                std::wstring::size_type entEnd = i;
                for(; entEnd!=size; ++entEnd)
                   {
                    if (str[entEnd]==L';') break;
                   }

                std::wstring::size_type entLen = entEnd - i;
                if (entLen==0)
                   {
                    strRes.append(1,L'&');
                    if (entEnd!=size) strRes.append(1,L';');
                    return strRes;
                   }

                std::wstring entityVal;
                if (!convertEntity(std::wstring(str,i,entLen), entityVal))
                   {
                    strRes.append(1,L'&');
                    strRes.append(str,i,entLen);
                    if (entEnd!=size) strRes.append(1,L';');
                   }
                else
                   {
                    strRes.append(entityVal);
                   }

                if (entEnd==size) return strRes;

                i = entEnd;
               }
           }
        return strRes;
       }

    CLIMETHOD(decodeMultibyteStringBuf) (THIS_ BOOL    precompose /* [in] bool  precompose  */
                                             , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                             , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                             , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                             , WCHAR*    bufDecodeTo /* [out,flat] wchar bufDecodeTo[]  */
                                             , SIZE_T*    bufDecodeToSize /* [in,out] size_t bufDecodeToSize  */
                                        )
       {
        if (!pEncoder) pEncoder = pDefEncoder;
        if (!pEncoder) return EC_INVALID_PARAM;
        if (!bufDecodeToSize) return EC_INVALID_PARAM;

        CiStringEncoder_tmp encoder(pEncoder);
        std::wstring decodedWideString;

        RCODE decodeRes = encoder.decodeMultibyteString( precompose
                                                       , strToDecode
                                                       , numCharsToDecode
                                                       , decodedWideString
                                                       );
        if (decodeRes) return decodeRes;

        decodedWideString = expandEntities( decodedWideString );
        if (!bufDecodeTo)
           {
            *bufDecodeToSize = decodedWideString.size()+1;
            return EC_OK;
           }

        SIZE_T numCharsToCopy = *bufDecodeToSize - 1;
        if (numCharsToCopy>decodedWideString.size()) numCharsToCopy = decodedWideString.size();

        decodedWideString.copy( bufDecodeTo, numCharsToCopy );
        bufDecodeTo[numCharsToCopy] = 0;
        *bufDecodeToSize = numCharsToCopy+1;        

        return EC_OK;
       }

    CLIMETHOD(decodeMultibyteString) (THIS_ BOOL    precompose /* [in] bool  precompose  */
                                          , const CHAR*    strToDecode /* [in,flat] char  strToDecode[]  */
                                          , SIZE_T    numCharsToDecode /* [in] size_t  numCharsToDecode  */
                                          , INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                          , CLISTR*           strDecoded
                                     )
       {
        if (!pEncoder) pEncoder = pDefEncoder;
        if (!pEncoder) return EC_INVALID_PARAM;
        if (!strDecoded) return EC_INVALID_PARAM;

        CiStringEncoder_tmp encoder(pEncoder);
        std::wstring decodedWideString;

        RCODE decodeRes = encoder.decodeMultibyteString( precompose
                                                       , strToDecode
                                                       , numCharsToDecode
                                                       , decodedWideString
                                                       );
        if (decodeRes) return decodeRes;

        decodedWideString = expandEntities( decodedWideString );


        CCliStr *pCliStrDecoded = reinterpret_cast<CCliStr*>(strDecoded);

        if (!pCliStrDecoded->hasAllocator()) pCliStrDecoded->createAllocator();
        if (!pCliStrDecoded->reserve(decodedWideString.size()))
           return EC_NOT_ENOUGH_MEM;

        decodedWideString.copy( pCliStrDecoded->data(), decodedWideString.size() );
        //*bufDecodeToSize = decodedWideString.size()+1;        
        pCliStrDecoded->setStringSize(decodedWideString.size());

        return EC_OK;
       }

    bool convertCharToPredefinedEntityName( WCHAR ch, std::wstring &strEntityNameAppendTo )
       {
        if (pBaseEntities    ->convertCharToEntity( ch, strEntityNameAppendTo )) return true;
        if (pExtendedEntities->convertCharToEntity( ch, strEntityNameAppendTo )) return true;
        return false;
       }

    /* interface ::cli::iStringEncoderCallback methods */
    CLIMETHOD(getSpecialReplaceChars) (THIS_ INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                           , const WCHAR*    strWideChars /* [in,flat] wchar  strWideChars[]  */
                                           , SIZE_T    numWideChars /* [in] size_t  numWideChars  */
                                           , WCHAR*    bufEncodeTo /* [out,flat] wchar bufEncodeTo[]  */
                                           , SIZE_T*    bufEncodeToSize /* [in,out] size_t bufEncodeToSize  */
                                      )
       {
        if (!strWideChars)    return EC_INVALID_PARAM;
        if (!numWideChars)    return EC_INVALID_PARAM;
        if (!bufEncodeToSize) return EC_INVALID_PARAM;

        std::wstring strEntity = L"&";
        // try to find custom entity char

        if (numWideChars>1)
           {
            strEntity.append(L"#x");
            enchlp::formatUnsigned( strEntity
                          , enchlp::convertCharToUnsigned( strWideChars, 2 /* numWideChars */  ), 16
                          , 8
                          , true // upperCase
                          );
            strEntity.append(1, L';');
           }
        else
           {
            std::map< WCHAR, std::wstring>::const_iterator cceIt = customCharEntities.find(*strWideChars);
            if (cceIt!=customCharEntities.end())
               {
                strEntity.append(cceIt->second);
                strEntity.append(1, L';');
               }
            else
               {
                if (convertCharToPredefinedEntityName(*strWideChars, strEntity))
                   {
                    strEntity.append(1, L';');
                   }
                else
                   {
                    strEntity.append(L"#x");
                    unsigned uch = enchlp::convertCharToUnsigned( strWideChars, 1 /* numWideChars */  );
                    enchlp::formatUnsigned( strEntity
                                  , uch, 16
                                  , (uch > 255) ? 4 : 2
                                  , true // upperCase
                                  );
                    strEntity.append(1, L';');
                   }
               }
           }
        
        if (!bufEncodeTo)
           {
            *bufEncodeToSize = strEntity.size()+1;
            return EC_OK;
           }

        if (!(*bufEncodeToSize)) return EC_INVALID_PARAM;
        SIZE_T numCharsToCopy = *bufEncodeToSize - 1;
        if (numCharsToCopy>strEntity.size()) numCharsToCopy = strEntity.size();
        strEntity.copy( bufEncodeTo, numCharsToCopy );
        bufEncodeTo[numCharsToCopy] = 0;

        return EC_OK;
       }
#if 0
    CLIMETHOD_(BOOL, isCallbackRequiredForChar) (THIS_ INTERFACE_CLI_ISTRINGENCODER*    pEncoder /* [in] ::cli::iStringEncoder*  pEncoder  */
                                                     , const WCHAR*    strWideChars /* [in,flat] wchar  strWideChars[]  */
                                                     , SIZE_T    numWideChars /* [in] size_t  numWideChars  */
                                                )
       {
        return EC_NOT_IMPLEMENTED;
       }
#endif


}; // CStringSpecialEncoderXmlHtmlBaseImpl



template <typename TBase, typename TEx>
struct CStringSpecialEncoderHtmlXmlImpl : public CStringSpecialEncoderXmlHtmlBaseImpl
{
    TBase           baseEntityProcessing;
    TEx    exEntityProcessing;

    CStringSpecialEncoderHtmlXmlImpl(  ) 
         : CStringSpecialEncoderXmlHtmlBaseImpl(&baseEntityProcessing,&exEntityProcessing)
         , baseEntityProcessing()
         , exEntityProcessing()
       {
        makeAllEntitiesString();
       }

}; // CStringSpecialEncoderHtmlImpl


typedef CStringSpecialEncoderHtmlXmlImpl< enchlp::CHtmlTextEntityProcessing , enchlp::CXmlHtmlEntitiesEntityProcessing > CStringSpecialEncoderHtmlTextImpl;
typedef CStringSpecialEncoderHtmlXmlImpl< enchlp::CHtmlAttrEntityProcessing , enchlp::CXmlHtmlEntitiesEntityProcessing > CStringSpecialEncoderHtmlAttrImpl;

typedef CStringSpecialEncoderHtmlXmlImpl< enchlp::CXmlTextEntityProcessing  , enchlp::CNoEntitiesEntityProcessing > CStringSpecialEncoderXmlTextImpl;
typedef CStringSpecialEncoderHtmlXmlImpl< enchlp::CXmlAttrEntityProcessing  , enchlp::CNoEntitiesEntityProcessing > CStringSpecialEncoderXmlAttrImpl;




}; // namespace impl
}; // namespace cli



#endif /* SRC_CORE_STRENC_H */

