#ifndef CORE_IO_SERIALIMPL_H
#define CORE_IO_SERIALIMPL_H

#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef CLI_IO_ISERIAL_H
    #include <cli/io/iserial.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_CLI2X_H
    #include <cli/cli2x.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef MARTY_CONFUTILS_H
    #include <marty/confUtils.h>    
#endif

#ifndef MARTY_ENV_H
    #include <marty/env.h>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif

#ifdef _WIN32
    #ifndef MARTY_WINAPI_H
        #include <marty/winapi.h>
    #endif
#endif

#ifndef CORE_UTIL_H
    #include "../util.h"
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#if !defined(_WIN32) && !defined(WIN32)

    #include <termios.h>
    #include <unistd.h>
    #include <errno.h>
    #include <sys/select.h>
    #include <sys/time.h>
    #include <sys/types.h>
    #include <sys/errno.h>
    

    #ifndef MARTY_UTF_H
        #include <marty/utf.h>
    #endif    

    #ifndef MARTY_CONCVT_H
        #include <marty/concvt.h>
    #endif    

#endif

#ifndef CLI_IO_SERIALHLP_H
    #include <cli/io/serialHlp.h>
#endif

#ifndef CLI_IO_IOLOCKPX_H
    #include <cli/io/iolockpx.h>
#endif


// ::cli::io::impl

namespace cli  {
namespace io   {
namespace impl {



template< WCHAR OPT_SEP_CHAR
        , WCHAR OPT_EQU_CHAR
        , WCHAR OPT_QUOT_CHAR
        >
struct CSerialHelperImplBase : public INTERFACE_CLI_IO_ISERIALHELPER
{

    CLIMETHOD(buildOptionsString) (THIS_ const STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [in,ref] ::cli::io::serial::COptions  options  */
                                       , CLISTR*           optString
                                  )
       {
        std::wstring strOptString;
        if (!options) return CLI_SET_ERROR_INFO( EC_INVALID_PARAM, 0, 0 );        

        // baud=b,parity=p,data=d,stop=s

        strOptString.append(L"baud=");
        switch(options->baudRate)
           {
            case 50    :  strOptString.append(L"50");      break;
            case 75    :  strOptString.append(L"75");      break;
            case 110   :  strOptString.append(L"110");     break;
            case 134   :  strOptString.append(L"134");     break;
            case 150   :  strOptString.append(L"150");     break;
            case 200   :  strOptString.append(L"200");     break;
            case 300   :  strOptString.append(L"300");     break;
            case 600   :  strOptString.append(L"600");     break;
            case 1200  :  strOptString.append(L"1200");    break;
            case 2400  :  strOptString.append(L"2400");    break;
            case 4800  :  strOptString.append(L"4800");    break;
            case 7200  :  strOptString.append(L"7200");    break;
            case 9600  :  strOptString.append(L"9600");    break;
            case 14400 :  strOptString.append(L"14400");   break;
            case 19200 :  strOptString.append(L"19200");   break;
            case 38400 :  strOptString.append(L"38400");   break;
            case 56000 :  strOptString.append(L"56000");   break;
            case 57600 :  strOptString.append(L"57600");   break;
            case 115200:  strOptString.append(L"115200");  break;
            case 230400:  strOptString.append(L"230400");  break;
            case 460800:  strOptString.append(L"460800");  break;
            case 921600:  strOptString.append(L"921600");  break;
            //case 115200:  strOptString.append(L"115200");  break;
            //case 115200:  strOptString.append(L"115200");  break;
            default:      return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_BAUD, 0, 0, (::cli::format::arg((UINT)options->baudRate)) );
           }

        strOptString.append(L",parity=");
        
        switch(options->parity)
           {
            case CLI_IO_SERIAL_PARITY_NONE :  strOptString.append(L"no");     break;
            case CLI_IO_SERIAL_PARITY_ODD  :  strOptString.append(L"odd");    break;
            case CLI_IO_SERIAL_PARITY_EVEN :  strOptString.append(L"even");   break;
            case CLI_IO_SERIAL_PARITY_MARK :  strOptString.append(L"mark");   break;
            case CLI_IO_SERIAL_PARITY_SPACE:  strOptString.append(L"space");  break;
            default:      return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_PARITY, 0, 0, (::cli::format::arg((UINT)options->parity)) );
           }

        strOptString.append(L",data=");

        switch(options->dataBits)
           {
            case CLI_IO_SERIAL_DATABITS_DATABITS5:  strOptString.append(L"5");  break;
            case CLI_IO_SERIAL_DATABITS_DATABITS6:  strOptString.append(L"6");  break;
            case CLI_IO_SERIAL_DATABITS_DATABITS7:  strOptString.append(L"7");  break;
            case CLI_IO_SERIAL_DATABITS_DATABITS8:  strOptString.append(L"8");  break;
            default:      return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_DATABITS, 0, 0, (::cli::format::arg((UINT)options->dataBits)) );
           }

        strOptString.append(L",stop=");

        switch(options->stopBits)
           {
            case CLI_IO_SERIAL_STOPBITS_STOPBITS1:  strOptString.append(L"1");  break;
            case CLI_IO_SERIAL_STOPBITS_STOPBITS2:  strOptString.append(L"2");  break;
            default:      return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_STOPBITS, 0, 0, (::cli::format::arg((UINT)options->stopBits)) );
           }

        if (optString)    CCliStr_copyTo(optString, strOptString );

        return EC_OK;
       }

    CLIMETHOD(parseOptionsString) (THIS_ const CLISTR*     optString
                                       , STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [out] ::cli::io::serial::COptions options  */
                                  )
       {
        ::std::map< ::std::wstring, ::std::wstring > optionsMap;

        ::marty::confUtils::splitOptionsString( optionsMap, stdstr(optString)
                                              , OPT_SEP_CHAR, OPT_EQU_CHAR, OPT_QUOT_CHAR
                                              , ::marty::confUtils::IsSpacePred()
                                              );
        return serialHelperParseOptionsMap( optionsMap, options );
       }

    RCODE serialHelperParseOptionsMap( const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                     , STRUCT_CLI_IO_SERIAL_COPTIONS*    options
                                     , const std::wstring streamName = std::wstring()
                                     )
       {
        STRUCT_CLI_IO_SERIAL_COPTIONS opts;
        opts.baudRate = 9600;
        opts.parity   = CLI_IO_SERIAL_PARITY_USEDEFAULT;
        opts.dataBits = CLI_IO_SERIAL_DATABITS_USEDEFAULT;
        opts.stopBits = CLI_IO_SERIAL_STOPBITS_USEDEFAULT;

        const int baudTaken   = 1;
        const int parityTaken = 2;
        const int dataTaken   = 4;
        const int stopTaken   = 8;

        int flagsTaken = 0;

        ::std::map< ::std::wstring, ::std::wstring >::const_iterator optIt = optionsMap.begin();
        for(; optIt!=optionsMap.end(); ++optIt)
           {
            ::std::wstring first  = MARTY_FILENAME_NS utils::lowerCase(optIt->first , MARTY_FILENAME_NS utils::makeUserLocale());
            ::std::wstring second = MARTY_FILENAME_NS utils::lowerCase(optIt->second, MARTY_FILENAME_NS utils::makeUserLocale());
            if (first==L"baud" || first==L"speed")
               {
                if (flagsTaken&baudTaken)
                   return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_OPT_MULTIPLE, 0, 0, (::cli::format::arg(optIt->first) % streamName) );

                // most used checked first
                if (second==L"115200")     opts.baudRate = 115200;
                else if (second==L"38400") opts.baudRate = 38400;
                else if (second==L"19200") opts.baudRate = 19200;
                else if (second==L"9600")  opts.baudRate = 9600;
                else if (second==L"4800")  opts.baudRate = 4800;
                else if (second==L"230400") opts.baudRate = 230400;
                else if (second==L"460800") opts.baudRate = 460800;
                else if (second==L"921600") opts.baudRate = 921600;
                // most rare used 
                else if (second==L"57600") opts.baudRate = 57600;
                else if (second==L"14400") opts.baudRate = 14400;
                else if (second==L"2400")  opts.baudRate = 2400;
                else if (second==L"1200")  opts.baudRate = 1200;
                else if (second==L"600")   opts.baudRate = 600;
                else if (second==L"300")   opts.baudRate = 300;
                else if (second==L"110")   opts.baudRate = 110;
                else if (second==L"56000") opts.baudRate = 56000; // only windows support this value
                // only linux/posix support next value
                else if (second==L"50")    opts.baudRate = 50; 
                else if (second==L"75")    opts.baudRate = 75;
                else if (second==L"134")   opts.baudRate = 134;
                else if (second==L"150")   opts.baudRate = 150;
                else if (second==L"200")   opts.baudRate = 200;
                else if (second==L"500000") opts.baudRate = 500000 ;
                else if (second==L"576000") opts.baudRate = 576000 ;
                else if (second==L"1000000") opts.baudRate = 1000000;
                else if (second==L"1152000") opts.baudRate = 1152000;
                else if (second==L"1500000") opts.baudRate = 1500000;
                else if (second==L"2000000") opts.baudRate = 2000000;
                else if (second==L"2500000") opts.baudRate = 2500000;
                else if (second==L"3000000") opts.baudRate = 3000000;
                else if (second==L"3500000") opts.baudRate = 3500000;
                else if (second==L"4000000") opts.baudRate = 4000000;
                //else if (second==L"") opts.baudRate = ;
                else return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_BAUD, 0, 0, (::cli::format::arg(optIt->second) ) );
                flagsTaken |= baudTaken;
               }
            else if (first==L"parity" || first==L"p")
               {
                if (flagsTaken&parityTaken)
                   return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_OPT_MULTIPLE, 0, 0, (::cli::format::arg(optIt->first) % streamName) );

                if (second==L"d" || second==L"default")                     opts.parity = CLI_IO_SERIAL_PARITY_USEDEFAULT;
                else if (second==L"none"  || second==L"no" || second==L"n") opts.parity = CLI_IO_SERIAL_PARITY_NONE;
                else if (second==L"odd"   || second==L"o")                  opts.parity = CLI_IO_SERIAL_PARITY_ODD;
                else if (second==L"even"  || second==L"e")                  opts.parity = CLI_IO_SERIAL_PARITY_EVEN;
                else if (second==L"mark"  || second==L"m")                  opts.parity = CLI_IO_SERIAL_PARITY_MARK;
                else if (second==L"space" || second==L"s")                  opts.parity = CLI_IO_SERIAL_PARITY_SPACE;
                else return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_PARITY, 0, 0, (::cli::format::arg(optIt->second) ) );
                flagsTaken |= parityTaken;
               }
            else if (first==L"data" || first==L"d" || first==L"databits")
               {
                if (flagsTaken&dataTaken)
                   return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_OPT_MULTIPLE, 0, 0, (::cli::format::arg(optIt->first) % streamName) );

                if (second==L"d" || second==L"default") opts.dataBits = CLI_IO_SERIAL_DATABITS_USEDEFAULT;
                else if (second==L"8")                  opts.dataBits = CLI_IO_SERIAL_DATABITS_DATABITS8;
                else if (second==L"7")                  opts.dataBits = CLI_IO_SERIAL_DATABITS_DATABITS7;
                else if (second==L"6")                  opts.dataBits = CLI_IO_SERIAL_DATABITS_DATABITS6;
                else if (second==L"5")                  opts.dataBits = CLI_IO_SERIAL_DATABITS_DATABITS5;
                else return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_DATABITS, 0, 0, (::cli::format::arg(optIt->second) ) );
                flagsTaken |= dataTaken;
               }
            else if (first==L"stop" || first==L"s" || first==L"stopbits")
               {
                if (flagsTaken&stopTaken)
                   return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_OPT_MULTIPLE, 0, 0, (::cli::format::arg(optIt->first) % streamName) );

                if (second==L"d" || second==L"default") opts.stopBits = CLI_IO_SERIAL_STOPBITS_USEDEFAULT;
                else if (second==L"1")                  opts.stopBits = CLI_IO_SERIAL_STOPBITS_STOPBITS1;
                else if (second==L"2")                  opts.stopBits = CLI_IO_SERIAL_STOPBITS_STOPBITS2;
                else return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_STOPBITS, 0, 0, (::cli::format::arg(optIt->second) ) );
                flagsTaken |= stopTaken;
               }
            else
               {
                return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_UNKNOWN_OPTION, 0, 0, (::cli::format::arg(optIt->first) % streamName) );
               }

            //flagsTaken |= baudTaken;
        /* const int parityTaken = 2;
         * const int dataTaken   = 4;
         * const int stopTaken   = 8;
         */
           }

        /*
        if (!(flagsTaken&baudTaken))
           opts.baudRate = 0;
        if (!(flagsTaken&parityTaken))
           opts.parity   = CLI_IO_SERIAL_PARITY_DONTTOUCH;
        if (!(flagsTaken&dataTaken))
           opts.dataBits = CLI_IO_SERIAL_DATABITS_DONTTOUCH;
        if (!(flagsTaken&stopTaken))
           opts.stopBits = CLI_IO_SERIAL_STOPBITS_DONTTOUCH;
        */

        if (options) *options = opts;
        return EC_OK;
       }



    /* return -1 if error, or device no if ok */
    int extractDeviceNo( const ::std::wstring &usnDevicePath)
       {
        //::std::wstring usndp = MARTY_FILENAME_NS utils::lowerCase(usnDevicePath , MARTY_FILENAME_NS utils::makeUserLocale());
        //int res = -1;
        int add = 0;
        ::std::wstring::size_type startPos = 0;
        if (::cli::util::startsWithI(usnDevicePath, L"/serial"))
           {
            startPos = 7; // len of '/serial' string, zero based
           }
        else if (::cli::util::startsWithI(usnDevicePath, L"/ttys") || ::cli::util::startsWithI(usnDevicePath, L"/ttyd"))
           {
            startPos = 5; // len of '/ttyX' string, zero based
           }
        else if (::cli::util::startsWithI(usnDevicePath, L"/com"))
           {
            startPos = 4; // len of '/com' string
            add = -1; // 1 based
           }
        else if (::cli::util::startsWithI(usnDevicePath, L"/tty"))
           {
            startPos = 4; // len of '/tty' string, zero based
           }

        ::std::wstring::size_type pos = startPos;

        int devNo = ::cli::util::uintFromString( usnDevicePath, pos);
        if (pos==startPos)
           return -1; // no digits at all in device name

        devNo += add;
        if (devNo<0) return -1; // string such as COM0 taken - invalid

        return devNo;
       }

    RCODE internalMakeSystemDeviceName( const ::std::wstring &usnDevicePath, ::std::wstring &sysDeviceName)
       {
        if (::cli::util::startsWith(usnDevicePath, L"/dev"))
           {
            sysDeviceName = usnDevicePath;
            return EC_OK;
           }

        int devNo = extractDeviceNo( usnDevicePath );
        if (devNo<0)
           {
            return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_DEVICE_NAME, 0, 0, (::cli::format::arg(usnDevicePath) ) );
           }

        ::std::wstring deviceNameFmt, deviceDisplayNameFmt /* not used */;
        int deviceNoAdd = 0;

        ::cli::io::getSerialDevicesInfo( deviceNameFmt, deviceDisplayNameFmt, deviceNoAdd );

        sysDeviceName = ::cli::format::message( deviceNameFmt, ::cli::format::arg(UINT(devNo+deviceNoAdd)) );

        return EC_OK;
       }

    CLIMETHOD(makeSystemDeviceName) (THIS_ const CLISTR*     usnDevicePath
                                         , CLISTR*           sysDeviceName
                                    )
       {
        ::std::wstring sysDeviceNameStr;
        RCODE res = internalMakeSystemDeviceName( stdstr(usnDevicePath), sysDeviceNameStr );
        if (RC_FAIL(res)) return res;
        if (sysDeviceName) CCliStr_copyTo(sysDeviceName, sysDeviceNameStr );
        return EC_OK;
       }

    RCODE internalMakeDisplayDeviceName( const ::std::wstring &usnDevicePath, ::std::wstring &sysDeviceName)
       {
        int devNo = extractDeviceNo( usnDevicePath );
        if (devNo<0)
           {
            return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_DEVICE_NAME, 0, 0, (::cli::format::arg(usnDevicePath) ) );
           }

        ::std::wstring deviceNameFmt, deviceDisplayNameFmt /* not used */;
        int deviceNoAdd = 0;

        ::cli::io::getSerialDevicesInfo( deviceNameFmt, deviceDisplayNameFmt, deviceNoAdd );

        sysDeviceName = ::cli::format::message( deviceDisplayNameFmt, ::cli::format::arg(UINT(devNo+deviceNoAdd)) );

        return EC_OK;       
       }


    CLIMETHOD(makeDisplayDeviceName) (THIS_ const CLISTR*     usnDevicePath
                                          , CLISTR*           sysDeviceName
                                     )
       {
        ::std::wstring sysDeviceNameStr;
        RCODE res = internalMakeDisplayDeviceName( stdstr(usnDevicePath), sysDeviceNameStr );
        if (RC_FAIL(res)) return res;
        if (sysDeviceName) CCliStr_copyTo(sysDeviceName, sysDeviceNameStr );
        return EC_OK;
       }
}; // CSerialHelperImplBase




struct CSerialHelperImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                         , public CSerialHelperImplBase< L',', L'=', L'\'' >
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    typedef CSerialHelperImplBase< L',', L'=', L'\'' > serial_helper_impl_base_class;

    //::std::wstring streamNameInfo;

    CSerialHelperImpl() : base_impl(DEF_MODULE), serial_helper_impl_base_class() //, streamNameInfo()
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CSerialHelperImpl, INTERFACE_CLI_IO_ISERIALHELPER)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISERIALHELPER )
    CLI_END_INTERFACE_MAP(CSerialHelperImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

}; // CSerialHelperImpl





struct CSerialImpl : public CIosImplBase< L',', L'=', L'\'' >
                   , public CSerialHelperImplBase< L',', L'=', L'\'' >
                   , public INTERFACE_CLI_IO_ISERIAL
{
      
    typedef CIosImplBase< L',', L'=', L'\'' >            ios_impl_base_class;
    typedef CSerialHelperImplBase< L',', L'=', L'\'' >   serial_helper_impl_base_class;


    STRUCT_CLI_IO_SERIAL_COPTIONS    savedOptions;
    #ifdef _WIN32
        HANDLE hCom;
    #else
        int    fSerial;
        struct termios savedTios;
        bool   bTiosSaved;
        ::std::string lockFileName;
    #endif


    CSerialImpl() : ios_impl_base_class(), serial_helper_impl_base_class(), savedOptions()
                  #ifdef _WIN32
                  , hCom(INVALID_HANDLE_VALUE)
                  #else
                  , fSerial(-1)
                  , savedTios()
                  , bTiosSaved(false)
                  , lockFileName()
                  #endif
       {
        #ifndef _WIN32
        memset((void*)&savedTios, 0, sizeof(savedTios));
        #endif
        savedOptions.baudRate = 9600;
        savedOptions.parity   = CLI_IO_SERIAL_PARITY_USEDEFAULT;
        savedOptions.dataBits = CLI_IO_SERIAL_DATABITS_USEDEFAULT;
        savedOptions.stopBits = CLI_IO_SERIAL_STOPBITS_USEDEFAULT;
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CSerialImpl, INTERFACE_CLI_IO_IIOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISERIAL   )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISERIALHELPER )
    CLI_END_INTERFACE_MAP(CSerialImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    ~CSerialImpl()
       {
        closeStream();
       }

    CLIMETHOD(closeStream) (THIS)
       {
        #ifdef _WIN32
        if (hCom != INVALID_HANDLE_VALUE)
           {
            ::CloseHandle(hCom);
            hCom = INVALID_HANDLE_VALUE;
           }
        #else
        if (fSerial!=-1)
           {
            if (bTiosSaved)
               {
                tcsetattr( fSerial, TCSANOW, &savedTios );
               }
            tcflush(fSerial, TCIOFLUSH);
            ::close(fSerial);
            if (!lockFileName.empty()) unlockExclusiveLock( lockFileName.c_str() );
            fSerial = -1;
           }
        #endif
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        closeStream();
        #ifdef _WIN32
        hCom = (HANDLE)handle;
        #else
        fSerial = (int)handle;
        bTiosSaved = false;
        #endif
        return EC_OK;
       }

    RCODE applySerialOptions(const STRUCT_CLI_IO_SERIAL_COPTIONS*    options)
       {
        if (options->dataBits<5 || options->dataBits>8) 
           return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_DATABITS, 0, 0, (::cli::format::arg((UINT)options->dataBits) ) );

        if (  options->parity!= CLI_IO_SERIAL_PARITY_NONE
           && options->parity!= CLI_IO_SERIAL_PARITY_ODD
           && options->parity!= CLI_IO_SERIAL_PARITY_EVEN
           && options->parity!= CLI_IO_SERIAL_PARITY_MARK
           && options->parity!= CLI_IO_SERIAL_PARITY_SPACE
           && options->parity!= CLI_IO_SERIAL_PARITY_DONTTOUCH
           )
           return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_PARITY, 0, 0, (::cli::format::arg((UINT)options->parity) ) );

        if (  options->stopBits!= CLI_IO_SERIAL_STOPBITS_STOPBITS1
           && options->stopBits!= CLI_IO_SERIAL_STOPBITS_STOPBITS2
           && options->stopBits!= CLI_IO_SERIAL_STOPBITS_DONTTOUCH
           )
           return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_STOPBITS, 0, 0, (::cli::format::arg((UINT)options->stopBits) ) );

        if (  options->dataBits!= CLI_IO_SERIAL_DATABITS_DATABITS5
           && options->dataBits!= CLI_IO_SERIAL_DATABITS_DATABITS6
           && options->dataBits!= CLI_IO_SERIAL_DATABITS_DATABITS7
           && options->dataBits!= CLI_IO_SERIAL_DATABITS_DATABITS8
           && options->dataBits!= CLI_IO_SERIAL_DATABITS_DONTTOUCH
           )
           return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_DATABITS, 0, 0, (::cli::format::arg((UINT)options->dataBits) ) );


        #ifdef _WIN32
            DCB dcb = { 0 };
            // memset((void*)&dcb, 0, sizeof(dcb));
       
            dcb.DCBlength=sizeof(DCB); 
            if (!::GetCommState( hCom, &dcb ))
               return CLI_SET_WIN_ERROR_INFO( ::GetLastError(), 0, 0 );

            dcb.DCBlength=sizeof(DCB); 

            switch(options->baudRate)
               {
                case 0: break; // don't toch
                case 110    :  dcb.BaudRate = CBR_110   ; break;    case 300   :  dcb.BaudRate = CBR_300   ; break;
                case 600    :  dcb.BaudRate = CBR_600   ; break;    case 1200  :  dcb.BaudRate = CBR_1200  ; break;
                case 2400   :  dcb.BaudRate = CBR_2400  ; break;    case 4800  :  dcb.BaudRate = CBR_4800  ; break;
                case 9600   :  dcb.BaudRate = CBR_9600  ; break;    case 14400 :  dcb.BaudRate = CBR_14400 ; break;
                case 19200  :  dcb.BaudRate = CBR_19200 ; break;    case 38400 :  dcb.BaudRate = CBR_38400 ; break;
                case 56000  :  dcb.BaudRate = CBR_56000 ; break;    case 57600 :  dcb.BaudRate = CBR_57600 ; break;
                case 115200 :  dcb.BaudRate = CBR_115200; break;    case 230400 :  dcb.BaudRate = 230400    ; break;
                case 460800 :  dcb.BaudRate = 460800    ; break;    case 500000 :  dcb.BaudRate = 500000    ; break;
                case 576000 :  dcb.BaudRate = 576000    ; break;    case 921600 :  dcb.BaudRate = 921600    ; break;
                case 1000000:  dcb.BaudRate = 1000000   ; break;    case 1152000:  dcb.BaudRate = 1152000   ; break;
                case 1500000:  dcb.BaudRate = 1500000   ; break;    case 2000000:  dcb.BaudRate = 2000000   ; break;
                case 2500000:  dcb.BaudRate = 2500000   ; break;    case 3000000:  dcb.BaudRate = 3000000   ; break;
                case 3500000:  dcb.BaudRate = 3500000   ; break;    case 4000000:  dcb.BaudRate = 4000000   ; break;
                //case :  dcb.BaudRate = CBR_; break;
                default:      return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_BAUD_NOT_SUPPORTED, 0, 0, (::cli::format::arg((UINT)options->baudRate) ) );
               }

            dcb.fBinary = TRUE;
            dcb.fParity = ( (options->parity&CLI_IO_SERIAL_PARITY_FPARITY) ? TRUE : FALSE);
            dcb.fOutxCtsFlow = FALSE;     
            dcb.fOutxDsrFlow = FALSE;
            dcb.fDtrControl = DTR_CONTROL_HANDSHAKE; /*DTR_CONTROL_DISABLE;*/
            dcb.fDsrSensitivity = FALSE;
            dcb.fOutX = FALSE;
            dcb.fInX = FALSE;
            dcb.fErrorChar = FALSE;         
            dcb.fNull = FALSE;
            dcb.fRtsControl = RTS_CONTROL_DISABLE;
            dcb.fAbortOnError = FALSE;
            // dcb.fAbortOnError = TRUE;
            //dcb.wReserved = 0;
            if (options->dataBits!= CLI_IO_SERIAL_DATABITS_DONTTOUCH)
               dcb.ByteSize = options->dataBits;

            dcb.Parity = NOPARITY;
            if ( options->parity == CLI_IO_SERIAL_PARITY_ODD )  dcb.Parity = ODDPARITY;
            if ( options->parity == CLI_IO_SERIAL_PARITY_EVEN)  dcb.Parity = EVENPARITY;
            if ( options->parity == CLI_IO_SERIAL_PARITY_MARK)  dcb.Parity = MARKPARITY;
            if ( options->parity == CLI_IO_SERIAL_PARITY_SPACE) dcb.Parity = SPACEPARITY;
            // UNDONE: MARKPARITY, SPACEPARITY need to be implemented

            if (options->stopBits!=CLI_IO_SERIAL_STOPBITS_DONTTOUCH)
               {
                dcb.StopBits = ONESTOPBIT;
                if ( options->stopBits == CLI_IO_SERIAL_STOPBITS_STOPBITS2)
                   dcb.StopBits = TWOSTOPBITS;
               }
            // 1.5 stop bits not supported

            if (!SetCommState(hCom, &dcb))
               return CLI_SET_WIN_ERROR_INFO( ::GetLastError(), 0, 0 );
        
        #else

            #if defined(_HAVE_STRUCT_TERMIOS_C_ISPEED) && _HAVE_STRUCT_TERMIOS_C_ISPEED==1
                #define TIOS_OLD_SETISPEED( opts, val ) do { (opts)->c_ispeed = val;  } while(0)
            #else
                #define TIOS_OLD_SETISPEED( opts, val )
            #endif
            #if defined(_HAVE_STRUCT_TERMIOS_C_OSPEED) && _HAVE_STRUCT_TERMIOS_C_OSPEED==1
                #define TIOS_OLD_SETOSPEED( opts, val ) do { (opts)->c_ospeed = val;  } while(0)
            #else
                #define TIOS_OLD_SETOSPEED( opts, val )
            #endif

            #define TIOS_SETSPEED( opts, val ) do { \
                                                    TIOS_OLD_SETISPEED((opts), val);  \
                                                    TIOS_OLD_SETOSPEED((opts), val);  \
                                                    cfsetispeed( (opts), val );       \
                                                    cfsetospeed( (opts), val );       \
                                                    (opts)->c_cflag |= val;           \
                                                   } while(0)

            if (fSerial<0)
               return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_HANDLE, 0, 0, (::cli::format::arg(streamNameInfo) ) );

            // save original port configuration
            if (!bTiosSaved)
               {
                if ( tcgetattr( fSerial, &savedTios ) <0 )
                   { /* do nothing */}
                else bTiosSaved = true;
               }


            struct termios newTios = { 0 };
            memset((void*)&newTios, 0, sizeof(newTios));

            switch(options->baudRate)
               {
                case 0: break; // don't set
                case 50     : TIOS_SETSPEED( &newTios, B50      ); break;    case 75     : TIOS_SETSPEED( &newTios, B75      ); break;
                case 110    : TIOS_SETSPEED( &newTios, B110     ); break;    case 134    : TIOS_SETSPEED( &newTios, B134     ); break;
                case 150    : TIOS_SETSPEED( &newTios, B150     ); break;    case 200    : TIOS_SETSPEED( &newTios, B200     ); break;
                case 300    : TIOS_SETSPEED( &newTios, B300     ); break;    case 600    : TIOS_SETSPEED( &newTios, B600     ); break;
                case 1200   : TIOS_SETSPEED( &newTios, B1200    ); break;    case 1800   : TIOS_SETSPEED( &newTios, B1800    ); break;
                case 2400   : TIOS_SETSPEED( &newTios, B2400    ); break;    case 4800   : TIOS_SETSPEED( &newTios, B4800    ); break;
                case 9600   : TIOS_SETSPEED( &newTios, B9600    ); break;    case 19200  : TIOS_SETSPEED( &newTios, B19200   ); break;
                case 38400  : TIOS_SETSPEED( &newTios, B38400   ); break;    case 57600  : TIOS_SETSPEED( &newTios, B57600   ); break;
                case 115200 : TIOS_SETSPEED( &newTios, B115200  ); break;    case 230400 : TIOS_SETSPEED( &newTios, B230400  ); break;
                case 460800 : TIOS_SETSPEED( &newTios, B460800  ); break;    case 500000 : TIOS_SETSPEED( &newTios, B500000  ); break;
                case 576000 : TIOS_SETSPEED( &newTios, B576000  ); break;    case 921600 : TIOS_SETSPEED( &newTios, B921600  ); break;
                case 1000000: TIOS_SETSPEED( &newTios, B1000000 ); break;    case 1152000: TIOS_SETSPEED( &newTios, B1152000 ); break;
                case 1500000: TIOS_SETSPEED( &newTios, B1500000 ); break;    case 2000000: TIOS_SETSPEED( &newTios, B2000000 ); break;
                case 2500000: TIOS_SETSPEED( &newTios, B2500000 ); break;    case 3000000: TIOS_SETSPEED( &newTios, B3000000 ); break;
                case 3500000: TIOS_SETSPEED( &newTios, B3500000 ); break;    case 4000000: TIOS_SETSPEED( &newTios, B4000000 ); break;
                //case : TIOS_SETSPEED( &newTios, B ); break;
                default:     return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_BAUD_NOT_SUPPORTED, 0, 0, (::cli::format::arg((UINT)options->baudRate) ) );
               }

            #undef TIOS_SETSPEED
            #undef TIOS_OLD_SETISPEED
            #undef TIOS_OLD_SETOSPEED

            switch(options->dataBits)
               {
                case CLI_IO_SERIAL_DATABITS_DATABITS5:  newTios.c_cflag |= CS5; break;
                case CLI_IO_SERIAL_DATABITS_DATABITS6:  newTios.c_cflag |= CS6; break;
                case CLI_IO_SERIAL_DATABITS_DATABITS7:  newTios.c_cflag |= CS7; break;
                case CLI_IO_SERIAL_DATABITS_DATABITS8:  newTios.c_cflag |= CS8; break;
               }

            if ( options->stopBits == CLI_IO_SERIAL_STOPBITS_STOPBITS2)
               newTios.c_cflag |= CSTOPB;

            if (options->parity&CLI_IO_SERIAL_PARITY_FPARITY)
               {
                newTios.c_cflag |= PARENB; // enable parity
                newTios.c_iflag |= (INPCK | ISTRIP); // Enable parity check and Strip parity bits
                switch(options->parity)
                   {
                    case CLI_IO_SERIAL_PARITY_EVEN :    /* newTios.c_cflag |= ; */         break;
                    case CLI_IO_SERIAL_PARITY_ODD  :   newTios.c_cflag |= PARODD         ; break;
                    #ifdef CMSPAR
                    case CLI_IO_SERIAL_PARITY_MARK :   newTios.c_cflag |= CMSPAR | PARODD; break;
                    case CLI_IO_SERIAL_PARITY_SPACE:   newTios.c_cflag |= CMSPAR         ; break;
                    #endif
                   };
               }

            // Enable the receiver and set local mode...
            newTios.c_cflag |= CLOCAL|CREAD;

            newTios.c_oflag = 0;

            // Ignore parity errors - high level protocol must check incoming data
            newTios.c_iflag |= IGNPAR;
            newTios.c_cc[VMIN]  = 0;
            newTios.c_cc[VTIME] = 1;

            //if ( tcsetattr( fSerial, TCSAFLUSH, &newTios ) <0 )
            if ( tcsetattr( fSerial, TCSANOW, &newTios ) <0 )
               return CLI_SET_POSIX_ERROR_INFO( errno, 0, 0 );
            tcflush(fSerial, TCIOFLUSH);

        #endif

        return EC_OK;
       }

    CLIMETHOD(setSerialOptions) (THIS_ const STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [in,ref] ::cli::io::serial::COptions  options  */)
       { 
        if (!options) return EC_INVALID_PARAM;
        RCODE res = applySerialOptions(options);
        if (RC_FAIL(res)) return res;

        /*
        STRUCT_CLI_IO_SERIAL_COPTIONS newOptions = *options;
        if (newOptions.baudRate==0)
           newOptions.baudRate = 9600;

        
        //if (newOptions.parity==0)
        //   newOptions.parity = CLI_IO_SERIAL_PARITY_NONE;
        

        if (newOptions.dataBits==CLI_IO_SERIAL_DATABITS_DONTTOUCH)
           newOptions.dataBits = 8;


        if (!(flagsTaken&baudTaken))
           opts.baudRate = 0;
        if (!(flagsTaken&parityTaken))
           opts.parity   = CLI_IO_SERIAL_PARITY_DONTTOUCH;
        if (!(flagsTaken&dataTaken))
           opts.dataBits = CLI_IO_SERIAL_DATABITS_DONTTOUCH;
        if (!(flagsTaken&stopTaken))
           opts.stopBits = CLI_IO_SERIAL_STOPBITS_DONTTOUCH;
        */

        savedOptions.baudRate = options->baudRate;
        savedOptions.parity   = options->parity  ;
        savedOptions.dataBits = options->dataBits;
        savedOptions.stopBits = options->stopBits;
        return EC_OK;
       }

    CLIMETHOD(getSerialOptions) (THIS_ STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [out] ::cli::io::serial::COptions options  */)
       {
        if (!options) return EC_INVALID_PARAM;
        options->baudRate = savedOptions.baudRate;
        options->parity   = savedOptions.parity  ;
        options->dataBits = savedOptions.dataBits;
        options->stopBits = savedOptions.stopBits;
        return EC_OK;
       }

    RCODE internalOpenParsedOpts( const ::std::wstring &host
                                , const ::std::wstring &port
                                , const ::std::wstring &path
                                , const ::std::wstring &options
                                , const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                )
       {
        RCODE res = serialHelperParseOptionsMap( optionsMap, &savedOptions, streamNameInfo );
        if (RC_FAIL(res)) return res;

        ::std::wstring sysDeviceName;
        res = internalMakeSystemDeviceName( path, sysDeviceName);
        if (RC_FAIL(res))
           return res; //return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_BAUD_NOT_SUPPORTED, 0, 0, (::cli::format::arg(streamNameInfo) ) );

        if (sysDeviceName.empty())
           return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_INTERNAL_DEVICE_NAME, 0, 0, (::cli::format::arg(streamNameInfo) ) );

        ::cli::io::CiConnectingStateWatcher watcher(pConWatcher);

        #ifdef _WIN32
        hCom = CreateFileW( sysDeviceName.c_str(), 
                        GENERIC_READ | GENERIC_WRITE, 
                        0, 0,
                        OPEN_EXISTING, 
                        0, 0);
        if (hCom==INVALID_HANDLE_VALUE)
           {
            if (!!watcher) watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED     , L"");
            if ( ::GetLastError()==ERROR_ACCESS_DENIED )
               return CLI_SET_ERROR_INFO( EC_FILE_IN_USE, 0, 0 );
               //return CLI_SET_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo) ) );

            if ( ::GetLastError()==ERROR_FILE_NOT_FOUND )
               return CLI_SET_ERROR_INFO( EC_NO_SUCH_FILE, 0, 0 );

            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo) ) );
           }
        #else

        //fSerial = :: open( MARTY_CON_NS w2ansi(sysDeviceName).c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
        fSerial = :: open( MARTY_CON_NS w2ansi(sysDeviceName).c_str(), O_RDWR | O_NOCTTY  | O_NDELAY );
        if (fSerial==-1)
           {
            if (!!watcher) watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED     , L"");
            if (errno==ENOENT)
               return CLI_SET_ERROR_INFO_ARGS( EC_NO_SUCH_FILE, 0, 0, (::cli::format::arg(streamNameInfo) % sysDeviceName) );
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo) % sysDeviceName) );
           }

        lockFileName = ::cli::io::makeLockFileName( sysDeviceName );
        PID_T pidOwner = 0;
        if (!::cli::io::makeExclusiveLock( lockFileName.c_str(), &pidOwner))
           {
            close(fSerial);
            fSerial = -1;
            lockFileName.clear();
            if (!!watcher) watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED     , L"");
            return CLI_SET_ERROR_INFO_ARGS( EC_FILE_IN_USE, 0, 0, ::cli::format::arg(pidOwner) );
           }

/*
        if ( :: fcntl(fSerial, F_SETFL, FNDELAY) < 0 ) // set non-blocking mode
           return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo) ) );
*/
        #endif

        res = applySerialOptions(&savedOptions);
        if (RC_FAIL(res))
           return res;

        #ifdef _WIN32

        COMMTIMEOUTS cto;
        cto.ReadIntervalTimeout        = 1;
        cto.ReadTotalTimeoutMultiplier = 0;
        cto.ReadTotalTimeoutConstant   = 10;   // 10 ms constant timeout
        cto.WriteTotalTimeoutMultiplier    = 0;
        cto.WriteTotalTimeoutConstant      = 10;
        if (!::SetCommTimeouts( hCom, &cto ))
           return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo) ) );
        
        #else

        tcflush(fSerial, TCIOFLUSH);

        #endif

        if (!!watcher) watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATECONNECTED  , L"");

        return EC_OK;
       }

    CLIMETHOD_(DWORD, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_SERIAL;
       }

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out] byte buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       { 
        return this->readTimeout(buf, numBytesToRead, numBytesReaded, 0);
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*     buf /* [out] byte buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*   numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        #ifdef _WIN32

        COMMTIMEOUTS cto;
        if (!GetCommTimeouts( hCom, &cto ))
           return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo) ) );

        /*
        http://vsokovikov.narod.ru/New_MSDN_API/Comm_res/str_commtimeouts.htm

        I. ReadIntervalTimeout 
        �������� MAXDWORD, ������������ � �������� ���������� � ��� ����� 
        ReadTotalTimeoutConstant, � ��� ����� ReadTotalTimeoutMultiplier 
        ����������, ��� �������� ������ ������ ���������� ���������� �������� 
        � ���������, ������� ���� ��� ��������, ���� ���� ������� �������� 
        �� ���� �������.

        II. ���� ���������� ��������� ������������� ����� ��������� 
        ReadIntervalTimeout � ReadTotalTimeoutMultiplier � MAXDWORD, 
        � ���� �������� ReadTotalTimeoutConstant ��������������� � 
        �������� ������ ��� ���� � ������, ��� MAXDWORD, ����� 
        ���������� ������� ReadFile, ���������� ���� �� ���� ��������������:
        
           1) ���� ���� �����-���� ������� � ������ ����� ������, ReadFile 
              ���������� ���������� �������� � ��������� � ������. 
           2) ���� � ������ ����� ������ ��� ������� ��������, ReadFile 
              ���� �� ��� ���, ���� �� �������� ������, � ����� 
              ���������� ���������� ��������. 
           3) ���� � �������� �������, ��������� ������ ReadTotalTimeoutConstant, 
              �������� ������� �� ���������, ReadFile ��������� ������. 
        */

        if (millisecTimeout>=MAXDWORD) millisecTimeout = MAXDWORD - 1;
        if (!millisecTimeout)
           { // ����� ������� ��,��� ��� �������, ��� �������� ()
            cto.ReadIntervalTimeout        = MAXDWORD;
            cto.ReadTotalTimeoutMultiplier = 0;
            cto.ReadTotalTimeoutConstant   = 0;
           }
        else
           {
            cto.ReadIntervalTimeout        = MAXDWORD;
            cto.ReadTotalTimeoutMultiplier = MAXDWORD;
            cto.ReadTotalTimeoutConstant   = (DWORD)millisecTimeout;
           }

        if (!::SetCommTimeouts( hCom, &cto ))
           return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo) ) );

        DWORD readed = 0;
        if (!::ReadFile( hCom, buf, (DWORD)numBytesToRead, &readed, 0 ))
           {
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesReaded) *numBytesReaded = (SIZE_T)readed;
        return EC_OK;

        #else

        struct timeval Timeout;
        Timeout.tv_usec = (millisecTimeout%1000)*1000;  // � ������������
        Timeout.tv_sec  = millisecTimeout/1000;  // �������

        fd_set readFs;
        FD_ZERO( &readFs );
        FD_SET( fSerial, &readFs );

        int selectRes = select(fSerial+1, &readFs, NULL, NULL, &Timeout );

        #ifdef ERESTARTNOHAND
        if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
        #else
        if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
        #endif
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }

        if (selectRes==-1 || selectRes==0 || (!FD_ISSET( fSerial, &readFs )) )
           {
            // �������� �������� ��������,
            // ��� ����� ������� ��� ���������� �� � ������ ������������, ������� ��� ������
            // ����������, ���  ������ �� ���������
            if (numBytesReaded) *numBytesReaded = 0; 
            return EC_OK; 
           }

        // ����� ������, ������ �� �������������
        ssize_t readRes = :: read(fSerial, buf, numBytesToRead);
        if (readRes==-1)
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesReaded) *numBytesReaded = (SIZE_T)readRes;
        return EC_OK;

        #endif
       }

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in] byte  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        return this->writeTimeout(buf, numBytesToWrite, numBytesWritten, 0);
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in] byte  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        #ifdef _WIN32

        /*
        http://vsokovikov.narod.ru/New_MSDN_API/Comm_res/str_commtimeouts.htm

        WriteTotalTimeoutMultiplier 
        ���������, ������������, ����� ��������� ������ ������ ������� ������� ��� �������� ������, 
        � �������������. ��� ������ �������� ������, ��� �������� ���������� �� ����� ������������ ������.

        WriteTotalTimeoutConstant 
        ���������, ������������, ����� ��������� ������ ������ ������� ������� ��� �������� ������, 
        � �������������. ��� ������ �������� ������, ��� �������� ����������� � ������������ ����� 
        ��������� WriteTotalTimeoutMultiplier � ����������� ����� ������.

        �������� ���� � ��� �����  WriteTotalTimeoutMultiplier, � ��� ����� WriteTotalTimeoutConstant 
        ���������, ��� ������ ����� ������� �� ������������ ��� �������� ������.
        */

        COMMTIMEOUTS cto;
        if (!GetCommTimeouts( hCom, &cto ))
           return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo) ) );

        if (millisecTimeout>=MAXDWORD) millisecTimeout = MAXDWORD - 1;
        if (!millisecTimeout)          millisecTimeout = 1;

        cto.WriteTotalTimeoutMultiplier    = 0;
        cto.WriteTotalTimeoutConstant      = (DWORD)millisecTimeout;

        if (!::SetCommTimeouts( hCom, &cto ))
           return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo) ) );

        DWORD written = 0;
        if (!::WriteFile( hCom, buf, (DWORD)numBytesToWrite, &written, 0 ))
           {
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesWritten) *numBytesWritten = (SIZE_T)written;
        return EC_OK;

        #else

        struct timeval Timeout;
        Timeout.tv_usec = (millisecTimeout%1000)*1000;  // � ������������
        Timeout.tv_sec  = millisecTimeout/1000;  // �������

        fd_set writeFs;
        FD_ZERO( &writeFs );
        FD_SET( fSerial, &writeFs );

        int selectRes = select(fSerial+1, NULL, &writeFs, NULL, &Timeout );

        #ifdef ERESTARTNOHAND
        if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
        #else
        if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
        #endif
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }

        if (selectRes==-1 || selectRes==0 || (!FD_ISSET( fSerial, &writeFs )) )
           {
            // �������� �������� ��������,
            // ��� ����� ������� ��� ���������� �� � ������ ������������, ������� ��� ������
            // ����������, ���  ������ �� ���������
            if (numBytesWritten) *numBytesWritten = 0; 
            return EC_OK; 
           }

        ssize_t writeRes = :: write(fSerial, buf, numBytesToWrite);
        if (writeRes==-1)
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesWritten) *numBytesWritten = (SIZE_T)writeRes;
        return EC_OK;

        #endif
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }


}; // CSerialImpl



}; // namespace impl
}; // namespace io
}; // namespace cli







/*
Serial impl sample
main()
{
  int    fd1, fd2; // ��������� ������ 1 � 2
  fd_set readfs;   // ����� �������� ������������
  int    maxfd;    // ����. ����� ��������������� �����������
  int    loop=1;   // ������������� ���� TRUE

  // open_input_source ��������� ����������, ��������� �����������
  // ���� � ���������� �������� ����������
  fd1 = open_input_source("/dev/ttyS1");   // COM2
  if (fd1<0) exit(0);
  fd2 = open_input_source("/dev/ttyS2");   // COM3
  if (fd2<0) exit(0);
  maxfd = MAX (fd1, fd2)+1; // ������������ ������� ������� (fd) ��� ��������

  // ���� �����
  while (loop) {
  FD_SET(fd1, &readfs);  // �������� �������� ��� ��������� 1
  FD_SET(fd2, &readfs);  // �������� �������� ��� ��������� 2

  // ����������� �� ��������� ������ �� �����
  select(maxfd, &readfs, NULL, NULL, NULL);
  if (FD_ISSET(fd1))         // ������ �� ��������� 1 ��������
    handle_input_from_source1();
  if (FD_ISSET(fd2))         // ������ �� ��������� 2 ��������
    handle_input_from_source2();
  }
}


int res;
struct timeval Timeout;

// ������������� �������� �������� � ����� �����
Timeout.tv_usec = 0;  // ������������
Timeout.tv_sec  = 1;  // �������
res = select(maxfd, &readfs, NULL, NULL, &Timeout);
if (res==0)
// ���������� ������������ � ����������� = 0, �������� �������.



*/

/*
Serial Programming Guide for POSIX Operating Systems:
    http://www.easysw.com/~mike/serial/serial.html
http://www.opennet.ru/docs/RUS/serial_guide/
http://www.citforum.ru/hardware/articles/comports/
BuildCommDCB function [Base]
*/


#endif /* CORE_IO_SERIALIMPL_H */

