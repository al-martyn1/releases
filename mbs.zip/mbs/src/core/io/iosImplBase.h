#ifndef CORE_IO_IOSIMPLBASE_H
#define CORE_IO_IOSIMPLBASE_H

#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_CLI2X_H
    #include <cli/cli2x.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef MARTY_CONFUTILS_H
    #include <marty/confUtils.h>    
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif


// ::cli::io::impl

namespace cli  {
namespace io   {
namespace impl {


template< WCHAR OPT_SEP_CHAR
        , WCHAR OPT_EQU_CHAR
        , WCHAR OPT_QUOT_CHAR
        >
struct CIosImplBase : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_IO_IIOSTREAM
                    , public INTERFACE_CLI_IO_IISTREAM
                    , public INTERFACE_CLI_IO_IOSTREAM
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    ::std::wstring          streamNameInfo;
    ::cli::CCriticalSection streamNameLocker;

    CIosImplBase() : base_impl(DEF_MODULE), streamNameInfo(L"generic io stream"), streamNameLocker()
       {
       }

    //void destroy() { delete this; }

    CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName)
       {
        CLI_SCOPED_LOCK(streamNameLocker);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertyGetImpl(_streamName, streamNameInfo);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       
       }

    CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName)
       {
        CLI_SCOPED_LOCK(streamNameLocker);
        CLI_TRY{
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  }
                return ::cli::propertySetImpl(_streamName, streamNameInfo);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLI_BEGIN_INTERFACE_MAP2(CIosImplBase, INTERFACE_CLI_IO_IIOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM  )
    CLI_END_INTERFACE_MAP(CIosImplBase)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


    static const unsigned openModeR         = 0x01;
    static const unsigned openModeW         = 0x02;
    static const unsigned openModeA         = 0x04;
    static const unsigned openModeB         = 0x08; // Binary
    static const unsigned openModePlus      = 0x10;
    static const unsigned openModeTemporary = 0x20; /* Temporary mean delete on close */

    unsigned parseFileOpenModeString( const ::std::wstring &modeStr, ::std::wstring::size_type *pFailPos )
       {
        unsigned resFlags = 0;
        ::std::wstring::size_type pos = 0, size = modeStr.size();
        for(; pos!=size; ++pos)
           {           
            switch(modeStr[pos])
               {
                case L'r': if (resFlags&(openModeW|openModeA))
                              { // r mode is mutually exclusive with 'w' and 'a'
                               if (pFailPos) { *pFailPos = pos; } 
                               return (unsigned)-1;
                              }
                           resFlags |= openModeR;
                           break;

                case L'w': if (resFlags&(openModeR|openModeA))
                              { // w mode is mutually exclusive with 'r' and 'a'
                               if (pFailPos) { *pFailPos = pos; } 
                               return (unsigned)-1;
                              }
                           resFlags |= openModeW;
                           break;

                case L'a': if (resFlags&(openModeR|openModeW))
                              { // a mode is mutually exclusive with 'r' and 'w'
                               if (pFailPos) { *pFailPos = pos; } 
                               return (unsigned)-1;
                              }
                           resFlags |= openModeA; 
                           break;

                case L'+': resFlags |= openModePlus     ; break;
                case L'b': resFlags |= openModeB        ; break; // ignored
                case L'T': resFlags |= openModeTemporary; break; // delete on close
                //case L'T': resFlags |= ; break;
                default: if (pFailPos) { *pFailPos = pos; } return (unsigned)-1;
               }
           }
        return resFlags;
       }




    virtual RCODE internalOpenParsedOpts( const ::std::wstring &host
                                        , const ::std::wstring &port
                                        , const ::std::wstring &path
                                        , const ::std::wstring &options
                                        , const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                        , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                        ) = 0;

    inline
    RCODE internalOpen( const ::std::wstring &streamName
                      , const ::std::wstring &host
                      , const ::std::wstring &port
                      , const ::std::wstring &path
                      , const ::std::wstring &options
                      , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                      )
       {
         {
          CLI_SCOPED_LOCK(streamNameLocker);
          streamNameInfo.assign(streamName);
         }

        ::std::map< ::std::wstring, ::std::wstring > optionsMap;

        ::marty::confUtils::splitOptionsString( optionsMap, options
                                              , OPT_SEP_CHAR, OPT_EQU_CHAR, OPT_QUOT_CHAR
                                              , ::marty::confUtils::IsSpacePred()
                                              );

        return internalOpenParsedOpts( host, port, path, options, optionsMap, pConWatcher );
       }

    CLIMETHOD(open) (THIS_ const CLISTR*     streamName
                         , const CLISTR*     host
                         , const CLISTR*     port
                         , const CLISTR*     path
                         , const CLISTR*     options
                         , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                    )
       {
        return internalOpen( stdstr(streamName), stdstr(host), stdstr(port), stdstr(path), stdstr(options), pConWatcher );
       }

    CLIMETHOD(openPStr) (THIS_ CLIPSTR           streamName
                             , CLIPSTR           host
                             , CLIPSTR           port
                             , CLIPSTR           path
                             , CLIPSTR           options
                             , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                        )
       {       
        return internalOpen( stdstr(streamName), stdstr(host), stdstr(port), stdstr(path), stdstr(options), pConWatcher );
       }

};



}; // namespace impl
}; // namespace io
}; // namespace cli



#endif /* CORE_IO_IOSIMPLBASE_H */

