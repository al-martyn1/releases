#ifndef PIPEIMPL_H
#define PIPEIMPL_H

#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef CLI_IO_IPIPE_H
    #include <cli/io/ipipe.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_CLI2X_H
    #include <cli/cli2x.h>
#endif

#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif

#if !defined(_WIN32) && !defined(WIN32)

    #include <unistd.h>
    #include <errno.h>
    #include <sys/select.h>
    #include <sys/time.h>
    #include <sys/types.h>
    #include <sys/errno.h>

#endif


namespace cli  {
namespace io   {
namespace impl {


#ifdef WIN32
    typedef BOOL (WINAPI *SwitchToThreadFnPtrType)( VOID );
    // Kernel32.dll
#endif


#define CPIPESTREAMIMPLBASE_IMPLEMENT_STREAMNAME_PROPERTY() \
    CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName)                               \
       {                                                                                         \
        CLI_SCOPED_LOCK(streamNameLocker);                                                       \
        CLI_TRY{                                                                                 \
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  } \
                return ::cli::propertyGetImpl(_streamName, streamNameInfo);                      \
               }                                                                                 \
        CLI_CATCH_RETURN_CLI_EXCEPTION()                                                         \
        CLI_CATCH_RETURN_STD_EXCEPTIONS()                                                        \
        return EC_OK;                                                                            \
                                                                                                 \
       }                                                                                         \
                                                                                                 \
    CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName)                               \
       {                                                                                         \
        CLI_SCOPED_LOCK(streamNameLocker);                                                       \
        CLI_TRY{                                                                                 \
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  } \
                return ::cli::propertySetImpl(_streamName, streamNameInfo);                      \
               }                                                                                 \
        CLI_CATCH_RETURN_CLI_EXCEPTION()                                                         \
        CLI_CATCH_RETURN_STD_EXCEPTIONS()                                                        \
        return EC_OK;                                                                            \
       }



struct CPipeHelperImplBase
{
    ::std::wstring               streamNameInfo;
    ::cli::CCriticalSection      streamNameLocker;
    CPipeHelperImplBase() : streamNameInfo(L"generic pipe iostream"), streamNameLocker() {}

    static
    void closePipeHandle( SYS_PIPE_HANDLE &handle )
       {
        if (handle!=INVALID_SYS_PIPE_HANDLE)
           {
            #if defined(WIN32) || defined(_WIN32)
            ::CloseHandle(handle); handle = INVALID_SYS_PIPE_HANDLE;
            #else
            ::close(handle); handle = INVALID_SYS_PIPE_HANDLE;
            #endif
           }
       }
}; // CPipeHelperImplBase


struct CPipeIStreamImplBase : public INTERFACE_CLI_IO_IISTREAM
                            , public virtual CPipeHelperImplBase
{
    SYS_PIPE_HANDLE   hRead;
    #if defined(WIN32) || defined(_WIN32)
    SwitchToThreadFnPtrType    SwitchToThreadFn;
    #endif

    CPipeIStreamImplBase() 
       : CPipeHelperImplBase()
       , hRead(INVALID_SYS_PIPE_HANDLE)
       #if defined(WIN32) || defined(_WIN32)
       , SwitchToThreadFn(0) 
       #endif
       {
        #if defined(WIN32) || defined(_WIN32)
        HMODULE hKernelModule = ::GetModuleHandleA( "Kernel32.dll" ); 
        if (hKernelModule)
           {
            SwitchToThreadFn = (SwitchToThreadFnPtrType) ::GetProcAddress( hKernelModule, "SwitchToThread" );
           }
        #endif
       }

    //CPIPESTREAMIMPLBASE_IMPLEMENT_STREAMNAME_PROPERTY()

    CLIMETHOD(closeStream) (THIS)
       {
        closePipeHandle( hRead );
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        closePipeHandle( hRead );
        hRead = (SYS_PIPE_HANDLE)handle;
        return EC_OK;
       }

    ~CPipeIStreamImplBase()
       {
        closeStream();
       }

    CLIMETHOD_(DWORD, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_PIPE;
       }

    #if defined(WIN32) || defined(_WIN32)
    void win32yield()
       {
        if (SwitchToThreadFn) SwitchToThreadFn();
        else                     Sleep(10);
       }
    #endif

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        if (hRead==INVALID_SYS_PIPE_HANDLE) return EC_IOSTREAM_NOT_READABLE;

        #if defined(WIN32) || defined(_WIN32)

        DWORD bytesAvail = 0;
        BOOL bRes = :: PeekNamedPipe( hRead, 0, 0, 0, &bytesAvail, 0 );
        if (!bRes)
           {
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }

        if (!bytesAvail)
           { // ��� ������ ��� ������
            if (numBytesReaded) *numBytesReaded = 0;
            return EC_OK;
           }

        DWORD readed = 0;
        if (!:: ReadFile( hRead, buf, (DWORD)numBytesToRead, &readed, 0 ))
           {
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesReaded) *numBytesReaded = (SIZE_T)readed;
        return EC_OK;

        #else

        return readTimeout( buf, numBytesToRead, numBytesReaded, 0 );

        #endif
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        if (hRead==INVALID_SYS_PIPE_HANDLE) return EC_IOSTREAM_NOT_READABLE;

        #if defined(WIN32) || defined(_WIN32)

        TICK_T startTick = cliGetTickCount();
        TICK_DIFF_T tickDiff = 0;

        RCODE res = this->read(buf, numBytesToRead, numBytesReaded);
        if (res) return res;
        if (!numBytesReaded) return EC_OK; // ����������, ������� �����������
        if (*numBytesReaded) return EC_OK; // ����������� ������ ���� ����

        while( ((TICK_T)tickDiff)<millisecTimeout )
           {
            win32yield();

            res = this->read(buf, numBytesToRead, numBytesReaded);
            if (res) return res;
            if (!numBytesReaded) return EC_OK; // ����������, ������� �����������
            if (*numBytesReaded) return EC_OK; // ����������� ������ ���� ����

            tickDiff = cliGetCurrentTickDiff(startTick);
           }

        if (numBytesReaded) *numBytesReaded = 0; // ����� �������, � ������ �� �����������
        return EC_OK;

        #else

        struct timeval Timeout;
        Timeout.tv_usec = (millisecTimeout%1000)*1000;  // � ������������
        Timeout.tv_sec  = millisecTimeout/1000;  // �������

        fd_set readFs;
        FD_ZERO( &readFs );
        FD_SET( hRead, &readFs );

        int selectRes = select(hRead+1, &readFs, NULL, NULL, &Timeout );

        #ifdef ERESTARTNOHAND
        if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
        #else
        if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
        #endif
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }

        if (selectRes==-1 || selectRes==0 || (!FD_ISSET( hRead, &readFs )) )
           {
            // �������� �������� ��������,
            // ��� ����� ������� ��� ���������� �� � ������ ������������, ������� ��� ������
            // ����������, ���  ������ �� ���������
            if (numBytesReaded) *numBytesReaded = 0; 
            return EC_OK; 
           }

        // ����� ������, ������ �� �������������
        ssize_t readRes = :: read(hRead, buf, numBytesToRead);
        if (readRes==-1)
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesReaded) *numBytesReaded = (SIZE_T)readRes;
        return EC_OK;

        #endif

        //return EC_NOT_IMPLEMENTED;
       }


}; // CPipeIStreamImplBase



struct CPipeOStreamImplBase : public INTERFACE_CLI_IO_IOSTREAM
                            , public virtual CPipeHelperImplBase
{
    SYS_PIPE_HANDLE   hWrite;
    CPipeOStreamImplBase() : CPipeHelperImplBase(), hWrite(INVALID_SYS_PIPE_HANDLE) {}

    //CPIPESTREAMIMPLBASE_IMPLEMENT_STREAMNAME_PROPERTY()

    CLIMETHOD(closeStream) (THIS)
       {
        closePipeHandle( hWrite );
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        closePipeHandle( hWrite );
        hWrite = (SYS_PIPE_HANDLE)handle;
        return EC_OK;
       }

    ~CPipeOStreamImplBase()
       {
        closeStream();
       }

    CLIMETHOD_(DWORD, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_PIPE;
       }

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        if (hWrite==INVALID_SYS_PIPE_HANDLE) return EC_IOSTREAM_NOT_WRITEABLE;

        #ifdef _WIN32

        DWORD written = 0;
        if (!::WriteFile( hWrite, buf, (DWORD)numBytesToWrite, &written, 0 ))
           {
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesWritten) *numBytesWritten = (SIZE_T)written;
        return EC_OK;
        
        #else
        
        ssize_t res = :: write(hWrite, buf, numBytesToWrite);
        if (res==-1)
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesWritten) *numBytesWritten = (SIZE_T)res;
        return EC_OK;

        #endif
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        if (hWrite==INVALID_SYS_PIPE_HANDLE) return EC_IOSTREAM_NOT_WRITEABLE;

        return this->write(buf, numBytesToWrite, numBytesWritten );
       }

}; // CPipeOStreamImplBase





struct CPipeImplBase : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_IO_IIOSTREAM
                    //, public INTERFACE_CLI_IO_IISTREAM
                    //, public INTERFACE_CLI_IO_IOSTREAM
                    , public CPipeIStreamImplBase
                    , public CPipeOStreamImplBase
                    , public INTERFACE_CLI_IO_IPIPE
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    //SYS_PIPE_HANDLE   hRead;
    //SYS_PIPE_HANDLE   hWrite;

    CPipeImplBase()
       : base_impl(DEF_MODULE)
       //, streamNameInfo(L"pipe")
       //, hRead(INVALID_SYS_PIPE_HANDLE)
       //, hWrite(INVALID_SYS_PIPE_HANDLE)
       //#if defined(WIN32) || defined(_WIN32)
       //, SwitchToThreadFn(0)
       //#endif
       {
       }

    ~CPipeImplBase()
       {
        closeStream();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CPipeImplBase, INTERFACE_CLI_IO_IIOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        //CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM  )
        CLI_IMPLEMENT_INTERFACE2(INTERFACE_CLI_IO_IISTREAM, CPipeIStreamImplBase)
        //CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM  )
        CLI_IMPLEMENT_INTERFACE2(INTERFACE_CLI_IO_IOSTREAM, CPipeOStreamImplBase)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IPIPE     )
    CLI_END_INTERFACE_MAP(CPipeImplBase)

    CPIPESTREAMIMPLBASE_IMPLEMENT_STREAMNAME_PROPERTY()

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    CLIMETHOD_(DWORD, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_PIPE;
       }

    CLIMETHOD(closeStream) (THIS)
       {
        CPipeIStreamImplBase::closeStream();
        CPipeOStreamImplBase::closeStream();
        //closePipeHandle( hRead );
        //closePipeHandle( hWrite );
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        return CPipeIStreamImplBase::read( buf, numBytesToRead, numBytesReaded );
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        return CPipeIStreamImplBase::readTimeout( buf, numBytesToRead, numBytesReaded, millisecTimeout );
       }

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        return CPipeOStreamImplBase::write( buf, numBytesToWrite, numBytesWritten );
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        return CPipeOStreamImplBase::writeTimeout( buf, numBytesToWrite, numBytesWritten, millisecTimeout );
       }

    virtual RCODE internalOpenParsedOpts( const ::std::wstring &host
                                        , const ::std::wstring &port
                                        , const ::std::wstring &path
                                        , const ::std::wstring &options
                                        , const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                        , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                        )
        {
         return EC_NOT_IMPLEMENTED;
         //return EC_OK;
        }

    inline
    RCODE internalOpen( const ::std::wstring &streamName
                      , const ::std::wstring &host
                      , const ::std::wstring &port
                      , const ::std::wstring &path
                      , const ::std::wstring &options
                      , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                      )
       {
        streamNameInfo.assign(streamName);

        ::std::map< ::std::wstring, ::std::wstring > optionsMap;

        ::marty::confUtils::splitOptionsString( optionsMap, options
                                              //, OPT_SEP_CHAR, OPT_EQU_CHAR, OPT_QUOT_CHAR
                                              , L',', L'=', L'\''
                                              , ::marty::confUtils::IsSpacePred()
                                              );

        return internalOpenParsedOpts( host, port, path, options, optionsMap, pConWatcher );
       }

    CLIMETHOD(open) (THIS_ const CLISTR*     streamName
                         , const CLISTR*     host
                         , const CLISTR*     port
                         , const CLISTR*     path
                         , const CLISTR*     options
                         , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                    )
       {
        return EC_NOT_IMPLEMENTED;
        //return internalOpen( stdstr(streamName), stdstr(host), stdstr(port), stdstr(path), stdstr(options), pConWatcher );
       }

    CLIMETHOD(openPStr) (THIS_ CLIPSTR           streamName
                             , CLIPSTR           host
                             , CLIPSTR           port
                             , CLIPSTR           path
                             , CLIPSTR           options
                             , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                        )
       {
        return EC_NOT_IMPLEMENTED;
        //return internalOpen( stdstr(streamName), stdstr(host), stdstr(port), stdstr(path), stdstr(options), pConWatcher );
       }


    CLIMETHOD(initPipe) (THIS_ SYS_PIPE_HANDLE    _hRead /* [in] sys_pipe_handle  hRead  */
                             , SYS_PIPE_HANDLE    _hWrite /* [in] sys_pipe_handle  hWrite  */
                        )
       {
        if (_hRead!=this->hRead)
           {
            closePipeHandle( this->hRead );
            this->hRead = _hRead;
           }
        if (_hWrite!=this->hWrite)
           {
            closePipeHandle( this->hWrite );
            this->hWrite = _hWrite;
           }
        return EC_OK;
       }

    CLIMETHOD(getHandles) (THIS_ SYS_PIPE_HANDLE*    _hRead /* [out] sys_pipe_handle hRead  */
                               , SYS_PIPE_HANDLE*    _hWrite /* [out] sys_pipe_handle hWrite  */
                          )
       {
        if (_hRead)  *_hRead  = this->hRead ;
        if (_hWrite) *_hWrite = this->hWrite;
        return EC_OK;
       }


    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }

}; // CPipeImplBase



}; // namespace impl
}; // namespace io
}; // namespace cli


#endif /* PIPEIMPL_H */

