#ifndef CLI_IO_CLICOMSCAN_H
#define CLI_IO_CLICOMSCAN_H

#ifndef CLI_IO_COMSCAN_H
    #include <cli/io/comscan.h>
#endif

#ifndef CLI_IO_MOXA_MOXA_H
    #include <cli/io/moxa/moxa.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#ifndef CLI_IO_SERIALHLP_H
    #include <cli/io/serialHlp.h>
#endif

#ifndef CLI_IO_IOLOCKPX_H
    #include <cli/io/iolockpx.h>
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#ifndef CLI_IO_MOXA_MOXA_H
    #include <cli/io/moxa/moxa.h>
#endif

#ifndef CLI_ARGLIST_H
    #include <cli/arglist.h>
#endif

namespace cli
{
namespace io
{
namespace impl
{


struct CPortFinderImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                       , public INTERFACE_CLI_IO_IPORTFINDER
{

    ::std::vector< ::std::wstring >                  searchAddrList;
    ::std::vector< ::std::wstring >                  ports;
    ::std::vector< ::std::wstring >                  portDescriptions;
    ::std::vector< ::std::wstring >                  portHosts;
    ::std::vector< ::std::wstring >                  portServerNames;
    ::std::vector<STRUCT_CLI_IO_CIOPORTINFO>         portsInfo;

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    CPortFinderImpl()
       : base_impl(DEF_MODULE)
       , searchAddrList()
       , ports()
       , portsInfo()
       {}

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CPortFinderImpl, INTERFACE_CLI_IO_IPORTFINDER)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IPORTFINDER )
    CLI_END_INTERFACE_MAP(CPortFinderImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


    CLIMETHOD(addrListGet) (THIS_ CLISTR*           addrListItem
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                           )
       {
        return ::cli::propertyVectorGetImpl( idx1, addrListItem , searchAddrList);
        /*
        if (!addrListItem) return EC_INVALID_PARAM;
        if (idx1>=searchAddrList.size()) return EC_OUT_OF_RANGE;

        if (addrListItem) CCliStr_copyTo(addrListItem , searchAddrList[idx1] );
        return EC_OK;
        */
       }

    CLIMETHOD(addrListSet) (THIS_ const CLISTR*     addrListItem
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                           )
       {
        if (!addrListItem) return EC_INVALID_PARAM;
        if (idx1>=searchAddrList.size())
           {
            searchAddrList.push_back( stdstr(addrListItem) );
           }
        else
           {
            searchAddrList[idx1] = stdstr(addrListItem);
           }
        return EC_OK;
       }

    CLIMETHOD(addrListSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        return ::cli::propertyVectorGetSizeImpl(size, searchAddrList);
        /*
        if (!size) return EC_INVALID_PARAM;
        *size = searchAddrList.size();
        return EC_OK;
        */
       }

    CLIMETHOD(portsInfoGet) (THIS_ STRUCT_CLI_IO_CIOPORTINFO*    portsInfoItem /* [out] ::cli::io::CIOPortInfo portsInfo  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       {
        return ::cli::propertyVectorGetImpl( idx1, portsInfoItem, portsInfo);
       }

    CLIMETHOD(portsInfoSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        return ::cli::propertyVectorGetSizeImpl(size, portsInfo);
       }

    CLIMETHOD(portsDescriptionGet) (THIS_ CLISTR*           portsDescriptionItem
                                        , SIZE_T    idx1 /* [in] size_t  idx1  */
                                   )
       {
        return ::cli::propertyVectorGetImpl( idx1, portsDescriptionItem, portDescriptions);
       }

    CLIMETHOD(portsDescriptionSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        return ::cli::propertyVectorGetSizeImpl(size, portDescriptions);
       }

    CLIMETHOD(portsGet) (THIS_ CLISTR*           portsItem
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                        )
       {
        return ::cli::propertyVectorGetImpl( idx1, portsItem, ports);
       }

    CLIMETHOD(portsSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        return ::cli::propertyVectorGetSizeImpl(size, portsInfo);
       }

    CLIMETHOD(portHostsGet) (THIS_ CLISTR*           portServersItem
                                   , SIZE_T    idx1 /* [in] size_t  idx1  */
                              )
       {
        return ::cli::propertyVectorGetImpl( idx1, portServersItem, portHosts);
       }

    CLIMETHOD(portHostsSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        return ::cli::propertyVectorGetSizeImpl(size, portHosts);
       }

    CLIMETHOD(portServerNamesGet) (THIS_ CLISTR*           portServerNamesItem
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
       {
        return ::cli::propertyVectorGetImpl( idx1, portServerNamesItem, portServerNames);
       }

    CLIMETHOD(portServerNamesSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        return ::cli::propertyVectorGetSizeImpl(size, portServerNames);
       }

    CLIMETHOD(clearAddrList) (THIS)
       {
        searchAddrList.clear();
        return EC_OK;
       }

    CLIMETHOD(searchForPorts) (THIS_ DWORD    flags /* [in] ::cli::io::PortFlags  flags  */
                                   , DWORD*   resFlags /* [out] ::cli::io::PortFlags resFlags  */
                              )
       {
        if (!(flags&(CLI_IO_PORTFLAGS_LOCALPORT|CLI_IO_PORTFLAGS_NETWORKPORT)))
           flags |= CLI_IO_PORTFLAGS_LOCALPORT;

        if (!(flags&(CLI_IO_PORTFLAGS_ONLYDATA|CLI_IO_PORTFLAGS_DATAANDCONTROL)))
           flags |= CLI_IO_PORTFLAGS_DATAANDCONTROL;

        if (resFlags) *resFlags = 0;

        CLI_TRY{        

                ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                ::std::wstring localhostName;
                resolver.getHostName(localhostName);

                if (flags&CLI_IO_PORTFLAGS_LOCALPORT)
                   {
                    if (resFlags) *resFlags |= CLI_IO_PORTFLAGS_LOCALPORT;

                    ::std::wstring deviceNameFmt, deviceDisplayNameFmt;
                    int deviceNoAdd = 0;
                    ::cli::io::getSerialDevicesInfo( deviceNameFmt, deviceDisplayNameFmt, deviceNoAdd );

                    unsigned maxPort = 20;
                   
                    for(unsigned i = 0; i<maxPort; ++i)
                       {
                        ::std::wstring sysDeviceName = ::cli::format::message( deviceNameFmt, ::cli::format::arg(UINT(i+deviceNoAdd)) );
                        #ifdef _WIN32
        
                        HANDLE hCom = CreateFileW( sysDeviceName.c_str(), 
                                        0, //GENERIC_READ | GENERIC_WRITE, 
                                        0, 0,
                                        OPEN_EXISTING, 
                                        0, 0);
                        if (hCom!=INVALID_HANDLE_VALUE || GetLastError()==ERROR_ACCESS_DENIED)
                           { // port found
                            if (i>15) 
                               maxPort = 256;
                            STRUCT_CLI_IO_CIOPORTINFO ioPi;
                            // CLI_IO_PORTSTATE_AVAILABLE, CLI_IO_PORTSTATE_INUSE
                            if (GetLastError()==ERROR_ACCESS_DENIED)
                               ioPi.state = CLI_IO_PORTSTATE_INUSE;
                            else
                               ioPi.state = CLI_IO_PORTSTATE_AVAILABLE;
                            // UNDONE: add code for obtaining ports owner pid
                            ioPi.ownerPid = 0;
        
                            ioPi.flags = CLI_IO_PORTFLAGS_LOCALPORT | CLI_IO_PORTFLAGS_DATAANDCONTROL;
                            portsInfo.push_back(ioPi);
        
                            ports.push_back(
                                            ::cli::format::message( L"serial:///serial%1", ::cli::format::arg(i) )
                                           );
                                           
                            portDescriptions.push_back( 
                                           ::cli::format::message( deviceDisplayNameFmt, ::cli::format::arg(UINT(i+deviceNoAdd)) )
                                                      );
                            portHosts.push_back( L"localhost" );
                            portServerNames.push_back( localhostName );
                            
                            if (hCom!=INVALID_HANDLE_VALUE) ::CloseHandle(hCom);
                           }
                        /*
                        DWORD lastErr = GetLastError();
                        if (lastErr)
                           {
                           }
                        */
                        #else
                        //fSerial = :: open( MARTY_CON_NS w2ansi(sysDeviceName).c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
                        int hSerial = :: open( MARTY_CON_NS w2ansi(sysDeviceName).c_str(), O_RDWR | O_NOCTTY  | O_NDELAY );
                        if (hSerial!=-1)
                           {
                            STRUCT_CLI_IO_CIOPORTINFO ioPi;
                            if (i>15) 
                               maxPort = 256;

                            ::std::string lockFileName = ::cli::io::makeLockFileName( sysDeviceName );
                            PID_T pidOwner = 0;
                            if (!::cli::io::makeExclusiveLock( lockFileName.c_str(), &pidOwner))
                               {
                                ioPi.state = CLI_IO_PORTSTATE_INUSE;
                                ioPi.ownerPid = pidOwner;
                               }
                            else
                               {
                                ioPi.state = CLI_IO_PORTSTATE_AVAILABLE;
                                ioPi.ownerPid = 0;
                                ::cli::io::unlockExclusiveLock( lockFileName.c_str() );
                               }

                            ioPi.flags = CLI_IO_PORTFLAGS_LOCALPORT | CLI_IO_PORTFLAGS_DATAANDCONTROL;
                            portsInfo.push_back(ioPi);
        
                            ports.push_back(
                                            ::cli::format::message( L"serial:///serial%1", ::cli::format::arg(i) )
                                           );
                                           
                            portDescriptions.push_back( 
                                           ::cli::format::message( deviceDisplayNameFmt, ::cli::format::arg(UINT(i+deviceNoAdd)) )
                                                      );
                            portHosts.push_back( L"localhost" );
                            portServerNames.push_back( localhostName );
                            close(hSerial);
                           }
                        //errno==ENOENT
                        #endif
                       }
                   }

                if (flags&CLI_IO_PORTFLAGS_NETWORKPORT && !searchAddrList.empty())
                   {
                    ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                    ::cli::moxa::CiMoxaManager mxMan("/cli/moxa/manager");
                    ::cli::moxa::CiMoxaFinder finder;

                    INTERFACE_CLI_IARGLIST* pArgList = cliGetArgList( );
                    ::std::vector< ::std::wstring >::const_iterator salIt = searchAddrList.begin();
                    for(; pArgList && salIt!=searchAddrList.end(); ++salIt)
                       {
                        pArgList->putStringChars( salIt->data(), salIt->size() );
                       }

                    if (resFlags) *resFlags |= CLI_IO_PORTFLAGS_NETWORKPORT;

                    RCODE res = mxMan.createFinderExList( pArgList, finder.getPP(), 2, 1000, 200 );
                    CLI_THROW_IF_NOK(res);

                    SIZE_T foundServersCount = 0;
                    finder.foundServersSize( &foundServersCount );

                    for(SIZE_T serverNo = 0; serverNo!=foundServersCount; ++serverNo)
                       {
                        STRUCT_CLI_MOXA_CMOXASERVERINFO srvInfo;
                        if (!finder.foundServersGet( srvInfo, serverNo ))
                           {
                            std::wstring moxaHost, moxaHostIp;
                            //std::wstring ipMoxaStr;
                            resolver.ipToString( srvInfo.serverAddr, moxaHostIp );
    
                            //resolver.getHostByAddressString
                            // BUG: ��� �� ࠡ�⠥� ��宦� ���⭮� ��।������ ����� ��� �� �����
                            if (!resolver.getHostByAddress(srvInfo.serverAddr))
                               resolver.canonicalNameGet(moxaHost);
                            else
                               moxaHost = moxaHostIp;
    
                            ::std::wstring moxaName(srvInfo.serverName);
                            ::std::wstring moxaProductName(srvInfo.productName);
                            
    
                            for(SIZE_T portNo = 0; portNo!=srvInfo.numberOfPorts; ++portNo)
                               {
                                if (  srvInfo.portInfo[portNo].opMode!=CLI_MOXA_PORTOPMODE_REALCOM
                                   && srvInfo.portInfo[portNo].opMode!=CLI_MOXA_PORTOPMODE_TCPSERVER)
                                   continue;
    
                                ::std::wstring portAlias = srvInfo.portInfo[portNo].portAlias;
                                ::std::wstring descriptionString = portAlias.empty() 
                                                                 ? ::cli::format::message( L"COM%1, %2", ::cli::format::arg((unsigned)portNo+1) % moxaProductName )
                                                                 : ::cli::format::message( L"COM%1 (%3), %2", ::cli::format::arg((unsigned)portNo+1) % moxaProductName % portAlias);

                                //::std::wstring descriptionString = ::cli::format::message( L"COM%1, %2", ::cli::format::arg(i+1) )
    
    
                                STRUCT_CLI_IO_CIOPORTINFO ioPi;
                                ioPi.state = CLI_IO_PORTSTATE_AVAILABLE;
                                ioPi.ownerPid = 0;
    
                                if (flags&CLI_IO_PORTFLAGS_ONLYDATA)
                                   {
                                    ioPi.flags = CLI_IO_PORTFLAGS_NETWORKPORT | CLI_IO_PORTFLAGS_ONLYDATA;
                                    portsInfo.push_back(ioPi);
                                    ports.push_back(
                                                    ::cli::format::message( L"tcp://%1:%2"
                                                                          , ::cli::format::arg(moxaHost) 
                                                                            % srvInfo.portInfo[portNo].tcpDataPort
                                                                          )
                                                   );
                                    
                                    portDescriptions.push_back( descriptionString );
                                    portHosts.push_back( moxaHostIp );
                                    //portHosts.push_back( moxaHost );
                                    portServerNames.push_back( moxaName );
                                   }

                                if (flags&CLI_IO_PORTFLAGS_DATAANDCONTROL)
                                   {
                                    ioPi.flags = CLI_IO_PORTFLAGS_NETWORKPORT | CLI_IO_PORTFLAGS_DATAANDCONTROL;
                                    portsInfo.push_back(ioPi);
                                    if (srvInfo.portInfo[portNo].opMode==CLI_MOXA_PORTOPMODE_REALCOM)
                                       {
                                        ports.push_back(
                                                        ::cli::format::message( L"nport://%1/serial%2"
                                                                              , ::cli::format::arg(moxaHost) 
                                                                                % (unsigned)portNo
                                                                              )
                                                       );
                                       }
                                    else
                                       {
                                        ports.push_back(
                                                        ::cli::format::message( L"nport://%1:%2/serial%3?ctrlport=%4"
                                                                              , ::cli::format::arg(moxaHost) 
                                                                                % srvInfo.portInfo[portNo].tcpDataPort
                                                                                % (unsigned)portNo
                                                                                % srvInfo.portInfo[portNo].tcpCommandPort
                                                                              )
                                                       );
                                       }
                                    portDescriptions.push_back( descriptionString );
                                    portHosts.push_back( moxaHostIp );
                                    //portHosts.push_back( moxaHost );
                                    portServerNames.push_back( moxaName );
                                   }
                               }
                            //srvInfo.portInfo[portNo].opMode
                            //srvInfo.portInfo[portNo].tcpDataPort
                           }
                       }
                   }

               } // try
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_OK;


        return EC_NOT_IMPLEMENTED;
       }

/*
    ::std::vector< ::std::wstring >                  ports;
    ::std::vector< ::std::wstring >                  portDescriptions;
    ::std::vector< ::std::wstring >                  portServers;
    ::std::vector< ::std::wstring >                  portServerNames;
    ::std::vector<STRUCT_CLI_IO_CIOPORTINFO>         portsInfo;
*/

}; // CPortFinderImpl





}; // namespace impl
}; // namespace io
}; // namespace cli




#endif /* CLI_IO_CLICOMSCAN_H */

