#ifndef CORE_IO_RCIMPL_H
#define CORE_IO_RCIMPL_H

/* add this lines to your src
#ifndef CORE_IO_RCIMPL_H
    #include "io/rcImpl.h"
#endif
*/

#ifndef CORE_IO_IOSIMPLBASE_H
    #include "iosImplBase.h"
#endif

#include <cli/clirc.h>
#include <cli/unknown.h>


namespace cli  {
namespace io   {
namespace impl {

struct CRcIosImpl : public CIosImplBase< L',', L'=', L'\'' >, INTERFACE_CLI_IO_ISEEKABLE
{
      
    typedef CIosImplBase< L',', L'=', L'\'' > base_class;
    INTERFACE_CLI_IO_IIOSTREAM    *m_pIOStream;
    INTERFACE_CLI_IO_ISEEKABLE    *m_pSeekable;

    //CLI_BEGIN_INTERFACE_MAP2(CIosImplBase, INTERFACE_CLI_IO_IIOSTREAM)
    CLI_BEGIN_INTERFACE_MAP2(CRcIosImpl, INTERFACE_CLI_IO_IIOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )
    CLI_END_INTERFACE_MAP(CIosImplBase)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    CRcIosImpl() 
       : base_class()
       , m_pIOStream(0)
       , m_pSeekable(0)
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CRcIosImpl()
       {
        if (m_pIOStream) m_pIOStream->release();
        if (m_pSeekable) m_pSeekable->release();
       }

        CLIMETHOD(getPos) (THIS_ FILE_SIZE_T*    curPos /* [out] file_size_t curPos  */)
           {
            if (m_pSeekable) return m_pSeekable->getPos( curPos );
            else return EC_DELEGATION_FAILED;
           }

        CLIMETHOD(setPos) (THIS_ ENUM_CLI_IO_ESEEKMOVEMETHOD    method /* [in] ::cli::io::ESeekMoveMethod  method  */
                               , FILE_DIFF_T    distanceToMove /* [in] file_diff_t  distanceToMove  */
                               , FILE_SIZE_T*    newPos /* [out,optional] file_size_t newPos  */
                          )
           {
            if (m_pSeekable) return m_pSeekable->setPos( method, distanceToMove, newPos );
            else return EC_DELEGATION_FAILED;
           }

        CLIMETHOD(getSize) (THIS_ FILE_SIZE_T*    size /* [out] file_size_t size  */)
           {
            if (m_pSeekable) return m_pSeekable->getSize( size );
            else return EC_DELEGATION_FAILED;
           }

        CLIMETHOD(setSize) (THIS_ FILE_SIZE_T    newSize /* [in] file_size_t  newSize  */)
           {
            if (m_pSeekable) return m_pSeekable->setSize( newSize );
            else return EC_DELEGATION_FAILED;
           }

        // GENERATOR: METHOD - getStreamType
        // GENERATOR: METHOD SIGNATURE - G!P0?__cli__io__IOStreamType#getStreamType@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iIStream
        // GENERATOR: INTERFACE - ::cli::io::iOStream
        CLIMETHOD_(ENUM_CLI_IO_IOSTREAMTYPE, getStreamType) (THIS)
           {
            if (m_pIOStream) return m_pIOStream->getStreamType( );
            else return 0;
           }

        RCODE internalOpenParsedOpts( const ::std::wstring &host
                                    , const ::std::wstring &port
                                    , const ::std::wstring &path
                                    , const ::std::wstring &options
                                    , const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                    , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                    )
           {
            CLI_TRY{
                    ::std::map< ::std::wstring, ::std::wstring >::const_iterator optIt = optionsMap.find(L"lang");
                    if (optIt == optionsMap.end()) optIt = optionsMap.find(L"locale");
         
                    ::std::wstring lang;
                    if (optIt != optionsMap.end())
                       lang = optIt->second;
         
                    ::cli::CiResourceManager_tmp rcMan = cliGetRcMan( );

                    ::cli::CiObjectList foundRcFilesList;
                    rcMan.findResources(lang, path, foundRcFilesList.getPP(), 0 );

                    SIZE_T totalFound = foundRcFilesList.objectCount;
                    if (!totalFound) { throw ::cli::CException( false, EC_RESOURCE_NOT_FOUND, __FILE__, __LINE__, ::cli::format::arg( path ) % lang ); }

                    ::cli::CiUnknown unk;
                    if (foundRcFilesList.getObject(0, unk.getPP()) || !unk)
                       { throw ::cli::CException( false, EC_RESOURCE_NOT_FOUND, __FILE__, __LINE__, ::cli::format::arg( path ) % lang ); }

                    ::cli::io::CiIOStream ios;
                    if (unk.queryInterface(ios.getPP())) 
                       { throw ::cli::CException( false, EC_UNKNOWN_INTERFACE, __FILE__, __LINE__ ); }
                    
                    ios.queryInterface(&m_pIOStream);
                    ios.queryInterface(&m_pSeekable);

                    ::cli::io::CiConnectingStateWatcher watcher(pConWatcher);
                    if (!!watcher)
                       {
                        //if (res) watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED     , L"");
                        //else     
                        watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATECONNECTED  , L"");
                       }
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
           }


        // GENERATOR: METHOD - read
        // GENERATOR: METHOD SIGNATURE - G!P0R#read@OVF!P0o@IVS!P0T@OVS!P0T@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iIStream
        CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                             , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                             , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                        )
           {
            if (m_pIOStream) return m_pIOStream->read( buf, numBytesToRead, numBytesReaded );
            else return EC_DELEGATION_FAILED;
           }

        // GENERATOR: METHOD - readTimeout
        // GENERATOR: METHOD SIGNATURE - G!P0R#readTimeout@OVF!P0o@IVS!P0T@OVS!P0T@IVS!P0K@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iIStream
        CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                    , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                    , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                    , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                               )
           {
            if (m_pIOStream) return m_pIOStream->readTimeout( buf, numBytesToRead, numBytesReaded, millisecTimeout );
            else return EC_DELEGATION_FAILED;
           }

        // GENERATOR: METHOD - write
        // GENERATOR: METHOD SIGNATURE - G!P0R#write@IVF!P0o@IVS!P0T@OVS!P0T@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iOStream
        CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                              , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                              , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                         )
           {
            if (m_pIOStream) return m_pIOStream->write( buf, numBytesToWrite, numBytesWritten );
            else return EC_DELEGATION_FAILED;
           }

        // GENERATOR: METHOD - writeTimeout
        // GENERATOR: METHOD SIGNATURE - G!P0R#writeTimeout@IVF!P0o@IVS!P0T@OVS!P0T@IVS!P0K@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iOStream
        CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                     , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                     , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                     , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                )
           {
            if (m_pIOStream) return m_pIOStream->writeTimeout( buf, numBytesToWrite, numBytesWritten, millisecTimeout );
            else return EC_DELEGATION_FAILED;
           }

        // GENERATOR: METHOD - closeStream
        // GENERATOR: METHOD SIGNATURE - G!P0R#closeStream@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iIStream
        // GENERATOR: INTERFACE - ::cli::io::iOStream
        CLIMETHOD(closeStream) (THIS)
           {
            if (m_pIOStream) return m_pIOStream->closeStream( );
            else return EC_DELEGATION_FAILED;
           }

        // GENERATOR: METHOD - initStreamWithHandle
        // GENERATOR: METHOD SIGNATURE - G!P0R#initStreamWithHandle@IVS!P0?sys_generic_io_handle@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iIStream
        // GENERATOR: INTERFACE - ::cli::io::iOStream
        CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
           {
            if (m_pIOStream) return m_pIOStream->initStreamWithHandle( handle );
            else return EC_DELEGATION_FAILED;
           }

        // GENERATOR: METHOD - createReadEnd
        // GENERATOR: METHOD SIGNATURE - G!P0R#createReadEnd@OVS!P1?__cli__io__iIStream@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iOStream
        CLIMETHOD(createReadEnd) (THIS_ ::cli::io::iIStream**    pStream /* [out] ::cli::io::iIStream* pStream  */)
           {
            if (m_pIOStream) return m_pIOStream->createReadEnd( pStream );
            else return EC_DELEGATION_FAILED;
           }

        // GENERATOR: METHOD - createWriteEnd
        // GENERATOR: METHOD SIGNATURE - G!P0R#createWriteEnd@OVS!P1?__cli__io__iOStream@
        // GENERATOR: INTERFACE - ::cli::io::iIOStream
        // GENERATOR: INTERFACE - ::cli::io::iIStream
        CLIMETHOD(createWriteEnd) (THIS_ ::cli::io::iOStream**    pStream /* [out] ::cli::io::iOStream* pStream  */)
           {
            if (m_pIOStream) return m_pIOStream->createWriteEnd( pStream );
            else return EC_DELEGATION_FAILED;
           }

}; // CRcIosImpl

}; // namespace impl
}; // namespace io
}; // namespace cli




#endif /* CORE_IO_RCIMPL_H */

