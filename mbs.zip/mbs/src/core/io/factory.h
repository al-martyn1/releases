#ifndef CLI_IO_FACTORY_H
#define CLI_IO_FACTORY_H

#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef CLI_IO_IPIPE_H
    #include <cli/io/ipipe.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif


#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_CLI2X_H
    #include <cli/cli2x.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#ifndef MARTY_FILESYS_H
    #include <marty/filesys.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#if defined(_WIN32) || defined(WIN32)
    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif

    #ifndef MARTY_WINAPI_H
        #include <marty/winapi.h>
    #endif

#else
     #if !defined(_UNISTD_H) && !defined(_UNISTD_H_)
         #include <unistd.h>
     #endif
#endif

#ifndef CORE_INET_INETHLP_H
    #include "../inet/inethlp.h"
#endif


/*
#ifndef MARTY_CASECONV_H
    #include <marty/caseconv.h>
#endif
*/

// ::cli::io::impl

namespace cli  {
namespace io   {
namespace impl {




struct CIOFactoryImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_IO_IIOFACTORY
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    ::std::set   < ::std::string > knownStreams;
    ::std::string                  componentNamePrefix;

    CIOFactoryImpl() : base_impl(DEF_MODULE), knownStreams(), componentNamePrefix("/cli/io-stream/")
       {
        // build list of components that support iIOStream interface
        // theese components names must be in form '/cli/io-stream/STREAM-TYPE'
        ::std::string componentMask = componentNamePrefix; //("/cli/io-stream/*");
        componentMask.append(1,'*');

        SIZE_T idx = 0;
        ::std::string componentName;
        while(::cli::enumCategoryComponents( INTERFACE_CLI_IO_IIOSTREAM_IID, idx, componentName))
           {
            if ( ::cli::matchMask(componentName, componentMask) )
               {
                knownStreams.insert( ::std::string(componentName, componentNamePrefix.size(), componentName.npos) );
               }
            ++idx;
           }
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP(CIOFactoryImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOFACTORY )
    CLI_END_INTERFACE_MAP(CIOFactoryImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    bool isLatinAlpha( wchar_t ch )
       {
        if (ch>=L'A' && ch<=L'Z') return true;
        if (ch>=L'a' && ch<=L'z') return true;
        return false;
       }

    bool isDigit( wchar_t ch )
       {
        if (ch>=L'0' && ch<=L'9') return true;
        return false;
       }

    RCODE splitName(const std::wstring &streamName
                   , std::wstring &           type
                   , std::wstring &           host
                   , std::wstring &           port
                   , std::wstring &           path
                   , std::wstring &           options
                   )
       {
        // type://host:port/path/to/stream?options
        std::wstring::size_type pos = 0;
        std::wstring::size_type tmp = streamName.find(L"://");
        if (tmp==streamName.npos)
           {
            tmp = streamName.find(L":\\\\"); // fix for allowing usage windows style back slashes
           }

        if (tmp!=streamName.npos)
           {
            type.assign(streamName, pos, tmp-pos);
            pos = tmp+3;
           }

        /*
        tmp = streamName.find(L'/', pos);
        if (tmp==streamName.npos) // fix for allowing usage windows style back slashes
           tmp = streamName.find(L'\\', pos);
        */

        tmp = streamName.find_first_of ( L"/\\", pos );

        std::wstring hostPort;
        if (tmp==streamName.npos)
           {
            //hostPort.assign(streamName, pos, tmp); // path part not found - only host name taken
            // but may be options part taken
            tmp = streamName.find(L'?', pos);
            if (tmp!=streamName.npos)
               {
                hostPort.assign(streamName, pos, tmp-pos);
                options.assign (streamName, tmp+1, streamName.npos);
               }
            else
               {
                hostPort.assign(streamName, pos, tmp);
               }
           }
        else
           { // path part was found
            hostPort.assign(streamName, pos, tmp-pos);
            pos = tmp+1;

            tmp = streamName.find(L'?', pos);
            if (tmp!=streamName.npos)
               {
                path.assign   (streamName, pos, tmp-pos);
                options.assign(streamName, tmp+1, streamName.npos);
               }
            else
               {
                path.assign(streamName, pos, tmp);
               }
           }

        if (!path.empty() && path[0]!=L'/' && path[0]!=L'\\')
           {
            ::std::wstring tmpPath(1, L'/');
            tmpPath.append(path);
            tmpPath.swap(path);
           }
/*
        if (hostPort==L"." || hostPort==L"..")
           {
            ::std::wstring tmpPath(hostPort); tmpPath.append(path); tmpPath.swap(path); hostPort.clear();
           }
*/
        if (hostPort.size()==2 && isLatinAlpha(hostPort[0]) && hostPort[1]==L':')
           {
            ::std::wstring tmpPath(1, L'/');
            tmpPath.append(hostPort);
            tmpPath.append(1,L'/');
            tmpPath.append(path);
            tmpPath.swap(path);
            hostPort.clear();
           }
        else
           {
            if (!hostPort.empty() && hostPort[0]==L'[')
               {
                tmp = hostPort.find(L']');
                if (tmp!=streamName.npos)
                   {
                    host.assign(hostPort, 1, tmp-1);
                    ++tmp;
                    if (tmp<hostPort.size() && hostPort[tmp]==L':') ++tmp;
                    if (tmp<hostPort.size())
                       port.assign(hostPort, tmp, streamName.npos);
    
                   }
                else
                   {
                    host.assign(hostPort);
                   }
               }
            else
               {
                tmp = hostPort.find(L':');
                if (tmp!=streamName.npos)
                   {
                    host.assign(hostPort, 0, tmp);
                    port.assign(hostPort, tmp+1, streamName.npos);
                   }
                else
                   {
                    host.assign(hostPort);
                   }
               }
           }
        return EC_OK;
       }

    RCODE mergeName( std::wstring &streamName
                   , const std::wstring &           type
                   , const std::wstring &           host
                   , const std::wstring &           port
                   , const std::wstring &           path
                   , const std::wstring &           options
                   )
       {
        //streamName.clear();
        std::wstring tmp = type;
        if (!tmp.empty()) tmp.append(L"://");

        ::cli::inet::CIpAddress tmpIpAddr;
        if (::cli::inet::convertIpAddress( host, tmpIpAddr) && tmpIpAddr.addrType == AF_INET6)
           {
            tmp.append(1,L'[');
            tmp.append(host);
            tmp.append(1,L']');
           }
        else
           {
            tmp.append(host);
           }

        if (!port.empty())
           {
            tmp.append(1, L':');
            tmp.append(port);
           }

        if (!path.empty())
           {
            //tmp.append(1, L'/');
            tmp.append(path);
           }

        if (!options.empty())
           {
            tmp.append(1, L'?');
            tmp.append(options);
           }

        tmp.swap(streamName);
        return EC_OK;
       }

    /* interface ::cli::io::iIOFactory methods */
    CLIMETHOD(splitName) (THIS_ const CLISTR*     streamName
                              , CLISTR*           type
                              , CLISTR*           host
                              , CLISTR*           port
                              , CLISTR*           path
                              , CLISTR*           options
                         )
       {
        std::wstring tmpStreamName = stdstr(streamName);
        std::wstring tmpType
                   , tmpHost
                   , tmpPort
                   , tmpPath
                   , tmpOptions
                   ;

        RCODE res = splitName( tmpStreamName, tmpType, tmpHost, tmpPort, tmpPath, tmpOptions );
        if (res!=EC_OK) return res;

        if (type)    CCliStr_copyTo(type   , tmpType   );
        if (host)    CCliStr_copyTo(host   , tmpHost   );
        if (port)    CCliStr_copyTo(port   , tmpPort   );
        if (path)    CCliStr_copyTo(path   , tmpPath   );
        if (options) CCliStr_copyTo(options, tmpOptions);

        return res;
       }

    CLIMETHOD(splitNamePStr) (THIS_ CLIPSTR           streamName
                                  , CLIPSTR*          type
                                  , CLIPSTR*          host
                                  , CLIPSTR*          port
                                  , CLIPSTR*          path
                                  , CLIPSTR*          options
                             )
       {
        std::wstring tmpStreamName = stdstr(streamName);
        std::wstring tmpType
                   , tmpHost
                   , tmpPort
                   , tmpPath
                   , tmpOptions
                   ;

        RCODE res = splitName( tmpStreamName, tmpType, tmpHost, tmpPort, tmpPath, tmpOptions );
        if (res!=EC_OK) return res;

        if (type)    *type    = clipstr( tmpType   );
        if (host)    *host    = clipstr( tmpHost   );
        if (port)    *port    = clipstr( tmpPort   );
        if (path)    *path    = clipstr( tmpPath   );
        if (options) *options = clipstr( tmpOptions);

        return res;
       }

    CLIMETHOD(mergeName) (THIS_ CLISTR*           streamName
                              , const CLISTR*     type
                              , const CLISTR*     host
                              , const CLISTR*     port
                              , const CLISTR*     path
                              , const CLISTR*     options
                         )
       {
        std::wstring tmpStreamName;
        RCODE res = mergeName( tmpStreamName, stdstr(type), stdstr(host), stdstr(port), stdstr(path), stdstr(options) );
        if (res!=EC_OK) return res;

        if (streamName) CCliStr_copyTo(streamName , tmpStreamName ); // *((CCliStr*)streamName) = tmpStreamName;

        return res;
       }

    CLIMETHOD(mergeNamePStr) (THIS_ CLIPSTR*          streamName
                                  , CLIPSTR           type
                                  , CLIPSTR           host
                                  , CLIPSTR           port
                                  , CLIPSTR           path
                                  , CLIPSTR           options
                             )
       {
        std::wstring tmpStreamName;
        RCODE res = mergeName( tmpStreamName, stdstr(type), stdstr(host), stdstr(port), stdstr(path), stdstr(options) );
        if (res!=EC_OK) return res;

        if (streamName) clipstr_alloc(streamName, tmpStreamName);

        return res;
       }

    inline bool isUpperLatinChar(WCHAR w) { return w>=L'A' && w<=L'Z'; }
    inline bool isLowerLatinChar(WCHAR w) { return w>=L'a' && w<=L'z'; }
    inline bool isLatinChar(WCHAR w) { return isUpperLatinChar(w) || isLowerLatinChar(w); }

    RCODE makeFullQualifiedName(::std::wstring &streamName)
       {
        std::wstring  type
                    , host
                    , port
                    , path
                    , options
                   ;

        RCODE res = splitName( streamName
                             , type
                             , host
                             , port
                             , path
                             , options
                             );
        if (res) return res;

        ::std::wstring::size_type hostDotCount = 0;
        ::std::wstring::size_type hostPos = 0, hostSize = host.size();
        for(; hostPos!=hostSize; ++hostPos)
           {
            if (host[hostPos]==L'.') ++hostDotCount;
           }

        if ( type.empty() && hostSize==1 && isLatinChar(host[0]) && port.size()>1 )
           { // Win32 DRIVE:\path\to\file parsed incorrect, correction needed
            path.assign( 1, L'/' );
            path.append(host);
            path.append( 1, L':' );
            path.append(port);
            host.clear();
            port.clear();
            type.assign(L"file");
           }
        else if (type.empty() && (!host.empty() && path.empty()) &&
                      (  ::cli::util::startsWithI(host, L"com")
                      || ::cli::util::startsWithI(host, L"tty")
                      || ::cli::util::startsWithI(host, L"ttyd")
                      || ::cli::util::startsWithI(host, L"ttys")
                      || ::cli::util::startsWithI(host, L"serial")
                      || ::cli::util::startsWith(host, L"/dev/") // raw *nix device support
                      )
                )
           {
            path.assign( 1, L'/' );
            path.append(host);
            host.clear();
            type.assign(L"serial");
           }
        else if (type.empty() && !host.empty() &&
                      (  ::cli::util::startsWithI(path, L"/com")
                      || ::cli::util::startsWithI(path, L"/tty")
                      || ::cli::util::startsWithI(path, L"/ttyd")
                      || ::cli::util::startsWithI(path, L"/ttys")
                      || ::cli::util::startsWithI(path, L"/serial")
                      )
                )
           {
            //path.assign( 1, L'/' );
            //path.append(host);
            //host.clear();
            type.assign(L"nport");
           }
        else if (type==L"file" && path.size()>1 && path[0]==L'/' && path[1]==L'.')
           {
            ::std::wstring curDir;
            MARTY_FILESYSTEM_NS getCurrentDirectory(curDir);
            path = MARTY_FILENAME_NS appendPath(curDir, ::std::wstring( path, 1, path.npos ) );
            path = ::std::wstring(1, L'/') + MARTY_FILENAME_NS makeCanonical(path);
           }
        else if (type.empty() && host.empty() && port.empty() && !path.empty())
           {
            type.assign(L"file");
           }
        else if ( type.empty()
                  && ((hostSize>0 && host[0]==L'.') // host - ���������� � �����
                      || ((hostDotCount*2+1)<hostSize)                   // ����� � ����� ����� ������ ��� ������ ��������,������
                      || (hostSize>0 && host[hostSize-1]=='.')          // ������������� �� �����
                      || port.empty()
                      || (hostDotCount && (hostDotCount<3) && (hostDotCount==hostSize))        // ".", ".."
                     )
                )
           { // path relative to current dir
            //
            if ((host==L"." || host==L"..") && !path.empty())
               host.append(path);

            type.assign(L"file");
            ::std::wstring curDir; // full name
            MARTY_FILESYSTEM::getCurrentDirectory(curDir);

            using MARTY_FILENAME::appendPath;
            using MARTY_FILENAME::makeCanonical;
            using MARTY_FILENAME::getFile;

            std::vector<MARTY_FILESYSTEM::CFindFileInfo<wchar_t> > matchedFiles;
            MARTY_FILESYSTEM::findFiles( matchedFiles, curDir, host, false, false );

            // only one file must match matchedFiles

            /*
            std::vector<MARTY_FILESYSTEM::CFindFileInfo<wchar_t> >::const_iterator mfIt = matchedFiles.begin();
            for(; mfIt!=matchedFiles.end(); ++mfIt)
               {
                if (MARTY_FILESYSTEM_NS efIsDir(mfIt->attrs)) continue; // skip dirs
                tstring modName = MARTY_FILENAME_NS appendPath(mfIt->path, mfIt->file);
                pOpts->log()<<"Processing module";
            */

            //::std::wstring onlyDirCurDirName = getFile(curDir);
            //if (makeCanonical(onlyDirCurDirName)==makeCanonical(host))
            if (matchedFiles.size()==1)
               {
                path = ::std::wstring(1, L'/') + MARTY_FILENAME::makeCanonical(appendPath(curDir,appendPath(host,path)));
                //path = appendPath(curDir, path );
                //MARTY_FILENAME::getPath()
               }
            else
               {
                /*
                path = makeCanonical(
                                     appendPath( appendPath(curDir, host ), path )
                                    )
                                   ;
                */
                path = MARTY_FILENAME::appendPath(curDir, host );
                path = ::std::wstring(1, L'/') + MARTY_FILENAME::makeCanonical(path);
               }
            host.clear();
            port.clear();
           }

/*

::cli::util::startsWith( const ::std::basic_string<CharType, Traits, Allocator> &strCompareTo
          , const ::std::basic_string<CharType, Traits, Allocator> &strStartsWith )
*/
        // Add more correction here

        if (type.empty()) // default is file streams
           type.assign(L"file");

        return mergeName( streamName, type, host, port, path, options );
       }

    CLIMETHOD(makeFullQualifiedName) (THIS_ CLISTR*           streamName)
       {
        ::std::wstring sn = stdstr(streamName);
        RCODE res = makeFullQualifiedName(sn);
        if (res) return res;
        if (streamName) CCliStr_copyTo( streamName, sn);
        return res;
       }

    CLIMETHOD(makeFullQualifiedNamePStr) (THIS_ CLIPSTR*          streamName)
       {
        ::std::wstring sn = stdstr(streamName);
        RCODE res = makeFullQualifiedName(sn);
        if (res) return res;
        if (streamName) clipstr_assign(streamName, sn);
        return res;
       }


    CLIMETHOD(createStream) (THIS_ const CLISTR*     streamName
                                 , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                 , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                            )
       {
        return createStream( stdstr(streamName), ios, pConWatcher );
       }

    CLIMETHOD(createStreamPstr) (THIS_ CLIPSTR           streamName
                                     , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                     , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                )
       {
        return createStream( stdstr(streamName), ios, pConWatcher );
       }

    CLIMETHOD(createStreamChars) (THIS_ const WCHAR*    streamName /* [in] wchar  streamName[]  */
                                      , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                      , INTERFACE_CLI_IO_IIOSTREAM**    ios /* [out] ::cli::io::iIOStream* ios  */
                                      , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                 )
       {
        if (!streamName) return CLI_SET_ERROR_INFO( EC_INVALID_PARAM, 0, 0 );
        if (nameSize==SIZE_T_NPOS) return createStream( ::std::wstring(streamName), ios, pConWatcher );
        else             return createStream( ::std::wstring(streamName, nameSize), ios, pConWatcher );
       }

    RCODE createStream(const ::std::wstring &streamName, INTERFACE_CLI_IO_IIOSTREAM** pios, INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER* pConWatcher)
       {
        if (!pios) return CLI_SET_ERROR_INFO( EC_INVALID_PARAM, 0, 0 );

        ::cli::errinfo::clear();

        std::wstring  type
                    , host
                    , port
                    , path
                    , options
                   ;

        RCODE res = splitName( streamName
                             , type
                             , host
                             , port
                             , path
                             , options
                             );
        if (res) return CLI_SET_ERROR_INFO_ARGS( EC_INVALID_IOSTREAM_NAME, 0, 0, ::cli::format::arg(streamName) );

        if (type.empty()) type = L"file";

        ::std::set< ::std::string >::const_iterator ksit = knownStreams.find( MARTY_CON_NS w2ansi(type) );
        if (ksit==knownStreams.end())
           return CLI_SET_ERROR_INFO_ARGS( EC_UNKNOWN_IOSTREAM_TYPE, 0, 0, (::cli::format::arg(type) % streamName) );

        ::std::string componentName = componentNamePrefix;
        componentName.append( MARTY_CON_NS w2ansi(type) );

        //INTERFACE_CLI_IO_IIOSTREAM pUnk = 0;
        res = cliCreateObject( componentName.c_str()
                             , INTERFACE_CLI_IO_IIOSTREAM_IID
                             , 0 // outer
                             , (GENERIC_OBJ_PTR*)pios
                             );
        if (res || !(*pios))
           {
            CLI_SET_ERROR_INFO_ARGS( res, 0, 0, ::cli::format::arg( MARTY_CON_NS a2wide(componentName) ) );
            return CLI_CHAIN_ERROR_INFO_ARGS( EC_UNKNOWN_IOSTREAM_TYPE, 0, 0, (::cli::format::arg(type) % streamName) );
           }

        // iostream.open sets apropriate error info itself
        ::cli::io::CiIOStream io(*pios);
        res = io.open( streamName, host, port, path, options, pConWatcher );
        if (RC_FAIL(res))
           {
            (*pios)->release();
            *pios = 0; // clear invalidated object pointer
            if (::cli::errinfo::available())
               {
                return res;
               }
            else
               {
                //return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_OPEN_FAILED, 0, 0, ::cli::format::arg(streamName) );
                return CLI_SET_ERROR_INFO_ARGS( res, 0, 0, ::cli::format::arg(streamName) );
               }
           }

        return res;
       }

    CLIMETHOD(createPipeStreams) (THIS_ INTERFACE_CLI_IO_IIOSTREAM**    ioReadEnd /* [out] ::cli::io::iIOStream* ioReadEnd  */
                                      , INTERFACE_CLI_IO_IIOSTREAM**    ioWriteEnd /* [out] ::cli::io::iIOStream* ioWriteEnd  */
                                 )
       {
        CLI_TRY{
                #if defined(_WIN32) || defined(WIN32)

                using MARTY_WINAPI_NS isWinNt;

                HANDLE hReadPipe  = INVALID_SYS_PIPE_HANDLE;
                HANDLE hWritePipe = INVALID_SYS_PIPE_HANDLE;

                SECURITY_ATTRIBUTES secAttrs;
                secAttrs.nLength = sizeof(secAttrs);
                secAttrs.lpSecurityDescriptor = 0;
                secAttrs.bInheritHandle = TRUE; // handle can be inherited by childs

                LPSECURITY_ATTRIBUTES pSec = isWinNt() ? &secAttrs : (LPSECURITY_ATTRIBUTES)0;

                BOOL bRes = CreatePipe( &hReadPipe
                                      , &hWritePipe
                                      , pSec
                                      , 0
                                      );

                if (!bRes)
                   return CLI_SET_WIN_ERROR_INFO( ::GetLastError(), 0, 0 );

                ::cli::io::CiPipe pipeObj1("/cli/io-stream/anon-pipe");
                ::cli::io::CiPipe pipeObj2("/cli/io-stream/anon-pipe");

                pipeObj1.initPipe( hReadPipe, INVALID_SYS_PIPE_HANDLE );
                pipeObj2.initPipe( INVALID_SYS_PIPE_HANDLE, hWritePipe );

                #else

                // pipe  ������  ����  ��������  ������������,  �����������  �� ��������� ���������� (inode)
                // ������ � �������� �� � ������ filedes.  filedes[0] ��� ������, filedes[1] ��� ������

                int pipeRW[2]; // pipeRW[0] - read, pipeRW[1] - write
                int res = pipe( pipeRW );
                if (res==-1)
                   return CLI_SET_POSIX_ERROR_INFO( errno, 0, 0 );

                ::cli::io::CiPipe pipeObj1("/cli/io-stream/anon-pipe");
                ::cli::io::CiPipe pipeObj2("/cli/io-stream/anon-pipe");

                pipeObj1.initPipe( pipeRW[0], INVALID_SYS_PIPE_HANDLE );
                pipeObj2.initPipe( INVALID_SYS_PIPE_HANDLE, pipeRW[1] );

                #endif

                pipeObj1.queryInterface( ioReadEnd  );
                pipeObj2.queryInterface( ioWriteEnd );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()

        return EC_OK;
       }

    CLIMETHOD(createPipe) (THIS_ INTERFACE_CLI_IO_IPIPE**    ipipe /* [out] ::cli::io::iPipe* ipipe  */)
       {
        CLI_TRY{
                #if defined(_WIN32) || defined(WIN32)

                using MARTY_WINAPI_NS isWinNt;

                HANDLE hReadPipe  = INVALID_SYS_PIPE_HANDLE;
                HANDLE hWritePipe = INVALID_SYS_PIPE_HANDLE;

                SECURITY_ATTRIBUTES secAttrs;
                secAttrs.nLength = sizeof(secAttrs);
                secAttrs.lpSecurityDescriptor = 0;
                secAttrs.bInheritHandle = TRUE; // handle can be inherited by childs

                LPSECURITY_ATTRIBUTES pSec = isWinNt() ? &secAttrs : (LPSECURITY_ATTRIBUTES)0;

                BOOL bRes = CreatePipe( &hReadPipe
                                      , &hWritePipe
                                      , pSec
                                      , 0
                                      );

                if (!bRes)
                   return CLI_SET_WIN_ERROR_INFO( ::GetLastError(), 0, 0 );

                ::cli::io::CiPipe pipe("/cli/io-stream/anon-pipe");
                pipe.initPipe( hReadPipe, hWritePipe );

                #else

                // pipe  ������  ����  ��������  ������������,  �����������  �� ��������� ���������� (inode)
                // ������ � �������� �� � ������ filedes.  filedes[0] ��� ������, filedes[1] ��� ������

                int pipeRW[2]; // pipeRW[0] - read, pipeRW[1] - write
                int res = pipe( pipeRW );
                if (res==-1)
                   return CLI_SET_POSIX_ERROR_INFO( errno, 0, 0 );

                ::cli::io::CiPipe pipe("/cli/io-stream/anon-pipe");
                pipe.initPipe( pipeRW[0], pipeRW[1] );

                #endif

                pipe.queryInterface( ipipe  );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()

        return EC_OK;
       }


    CLIMETHOD(createBidiPipeStreams) (THIS_ INTERFACE_CLI_IO_IIOSTREAM**    ioEnd1 /* [out] ::cli::io::iIOStream* ioEnd1  */
                                          , INTERFACE_CLI_IO_IIOSTREAM**    ioEnd2 /* [out] ::cli::io::iIOStream* ioEnd2  */
                                     )
       {
        CLI_TRY{
                #if defined(_WIN32) || defined(WIN32)

                using MARTY_WINAPI_NS isWinNt;

                HANDLE hReadPipe1  = INVALID_SYS_PIPE_HANDLE;
                HANDLE hWritePipe1 = INVALID_SYS_PIPE_HANDLE;
                HANDLE hReadPipe2  = INVALID_SYS_PIPE_HANDLE;
                HANDLE hWritePipe2 = INVALID_SYS_PIPE_HANDLE;

                SECURITY_ATTRIBUTES secAttrs;
                secAttrs.nLength = sizeof(secAttrs);
                secAttrs.lpSecurityDescriptor = 0;
                secAttrs.bInheritHandle = TRUE; // handle can be inherited by childs

                LPSECURITY_ATTRIBUTES pSec = isWinNt() ? &secAttrs : (LPSECURITY_ATTRIBUTES)0;

                BOOL bRes = CreatePipe( &hReadPipe1
                                      , &hWritePipe1
                                      , pSec
                                      , 0
                                      );

                if (!bRes)
                   return CLI_SET_WIN_ERROR_INFO( ::GetLastError(), 0, 0 );

                bRes = CreatePipe( &hReadPipe2
                                 , &hWritePipe2
                                 , pSec
                                 , 0
                                 );
                if (!bRes)
                   {
                    DWORD err = ::GetLastError();
                    :: CloseHandle(hReadPipe1);
                    :: CloseHandle(hWritePipe1);
                    return CLI_SET_WIN_ERROR_INFO( err, 0, 0 );
                   }

                ::cli::io::CiPipe pipeObj1("/cli/io-stream/anon-pipe");
                ::cli::io::CiPipe pipeObj2("/cli/io-stream/anon-pipe");

                pipeObj1.initPipe( hReadPipe1, hWritePipe2 );
                pipeObj2.initPipe( hReadPipe2, hWritePipe1 );

                #else

                // pipe  ������  ����  ��������  ������������,  �����������  �� ��������� ���������� (inode)
                // ������ � �������� �� � ������ filedes.  filedes[0] ��� ������, filedes[1] ��� ������

                int pipeRW1[2]; // pipeRW[0] - read, pipeRW[1] - write
                int res = ::pipe( pipeRW1 );
                if (res==-1)
                   return CLI_SET_POSIX_ERROR_INFO( errno, 0, 0 );

                int pipeRW2[2]; // pipeRW[0] - read, pipeRW[1] - write
                res = ::pipe( pipeRW2 );
                if (res==-1)
                   {
                    int e = errno;
                    ::close(pipeRW1[0]);
                    ::close(pipeRW1[1]);
                    return CLI_SET_POSIX_ERROR_INFO( e, 0, 0 );
                   }

                ::cli::io::CiPipe pipeObj1("/cli/io-stream/anon-pipe");
                ::cli::io::CiPipe pipeObj2("/cli/io-stream/anon-pipe");

                pipeObj1.initPipe( pipeRW1[0], pipeRW2[1] );
                pipeObj2.initPipe( pipeRW2[0], pipeRW1[1] );

                #endif

                pipeObj1.queryInterface( ioEnd1 );
                pipeObj2.queryInterface( ioEnd2 );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()

        return EC_OK;
       }

};


}; // namespace impl
}; // namespace io
}; // namespace cli


#endif /* CLI_IO_FACTORY_H */

