#ifndef CORE_IO_FILEIOS_H
#define CORE_IO_FILEIOS_H

#ifndef CORE_IO_IOSIMPLBASE_H
    #include "iosImplBase.h"
#endif

#ifndef _WIN32
       #include <sys/types.h>
       #include <sys/stat.h>
       #include <fcntl.h>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#ifndef CLI_YIELD_H
    #include <cli/yield.h>
#endif


#ifndef MARTY_FILESYS_H
    #include <marty/filesys.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif


#ifdef _WIN32
    #ifndef MARTY_WINAPI_H
        #include <marty/winapi.h>
    #endif
#endif

#if !defined(_INC_ERRNO) && !defined(_ERRNO_H_) && !defined(_ERRNO_H)
    #include <errno.h>
#endif


// Mingw uses _0x400 WINVER by default
#if defined(_WIN32) && defined(__GNUC__)
    #ifdef __cplusplus
    extern "C" {
    #endif
        WINBASEAPI BOOL WINAPI GetFileSizeEx(HANDLE,PLARGE_INTEGER);
    #ifdef __cplusplus
    };
    #endif

#endif


// ::cli::io::impl

namespace cli  {
namespace io   {
namespace impl {


/*
 Unix man
       r      Open text file for reading.  The stream is positioned at the beginning of the file.

       r+     Open for reading and writing.  The stream is positioned at  the  beginning  of  the
              file.

       w      Truncate  file to zero length or create text file for writing.  The stream is posi?
              tioned at the beginning of the file.

       w+     Open for reading and writing.  The file is created if it does not exist,  otherwise
              it is truncated.  The stream is positioned at the beginning of the file.

       a      Open  for  appending  (writing at end of file).  The file is created if it does not
              exist.  The stream is positioned at the end of the file.

       a+     Open for reading and appending (writing at end of file).  The file is created if it
              does  not  exist.  The initial file position for reading is at the beginning of the
              file, but output is always appended to the end of the file.

 MSDN
       r      Opens for reading. If the file does not exist or cannot be found, the fopen call fails.
              _O_RDONLY
              GENERIC_READ, OPEN_EXISTING

       w      Opens an empty file for writing. If the given file exists, its contents are destroyed.
              _O_WRONLY (usually _O_WRONLY | _O_CREAT | _O_TRUNC)
              GENERIC_WRITE, CREATE_ALWAYS,

       a      Opens for writing at the end of the file (appending) without removing the EOF marker before writing new data to the file; creates the file first if it doesn't exist.
              _O_WRONLY | _O_APPEND (usually _O_WRONLY | _O_CREAT | _O_APPEND)
              GENERIC_WRITE, CREATE_ALWAYS, + ��������� ������ ����������� �� ����� �����

       r+     Opens for both reading and writing. (The file must exist.)
              _O_RDWR
              GENERIC_READ+GENERIC_WRITE, OPEN_EXISTING

       w+     Opens an empty file for both reading and writing. If the given file exists, its contents are destroyed.
              _O_RDWR (usually _O_RDWR | _O_CREAT | _O_TRUNC)

       a+     Opens for reading and appending; the appending operation includes the removal of the EOF marker before new data is written to the file and the EOF marker is restored after writing is complete; creates the file first if it doesn't exist.
              _O_RDWR | _O_APPEND (usually _O_RDWR | _O_APPEND | _O_CREAT )

       _O_APPEND       Moves file pointer to end of file before every write operation.

       _O_BINARY       Opens file in binary (untranslated) mode. (See fopen for a description of binary mode.)

       _O_CREAT       Creates and opens a new file for writing. Has no effect if the file specified by filename exists. pmode argument is required when _O_CREAT is specified.

       _O_CREAT| _O_SHORT_LIVED     Create a file as temporary and if possible do not flush to disk. pmode argument is required when _O_CREAT is specified.

       _O_CREAT| _O_TEMPORARY       Create a file as temporary; the file is deleted when the last file descriptor is closed. pmode argument is required when _O_CREAT is specified.

       _O_CREAT| _O_EXCL       Returns an error value if the file specified by filename exists. Applies only when used with _O_CREAT.

       _O_NOINHERIT       Prevents creation of a shared file descriptor.

       _O_RANDOM       Specifies that caching is optimized for, but not restricted to, random access from disk.

       _O_RDONLY       Opens a file for reading only; cannot be specified with _O_RDWR or _O_WRONLY.

       _O_RDWR       Opens file for both reading and writing; you cannot specify this flag with _O_RDONLY or _O_WRONLY.

       _O_SEQUENTIAL       Specifies that caching is optimized for, but not restricted to, sequential access from disk.

       _O_TEXT       Opens a file in text (translated) mode. (For more information, see Text and Binary Mode File I/O and fopen.)

       _O_TRUNC       Opens a file and truncates it to zero length; the file must have write permission. You cannot specify this flag with _O_RDONLY. _O_TRUNC used with _O_CREAT opens an existing file or creates a new file.



*/


struct CFileIosImpl : public CIosImplBase< L',', L'=', L'\'' >, INTERFACE_CLI_IO_ISEEKABLE
{

    typedef CIosImplBase< L',', L'=', L'\'' > base_class;

    #ifdef _WIN32

    static const int o_creat  = _O_CREAT;
    static const int o_append = _O_APPEND; // Moves file pointer to end of file before every write operation.
    //static const int o_binary = _O_BINARY;
    static const int o_excl   = _O_EXCL; // only with _O_CREAT
    static const int o_rdwr   = _O_RDWR;
    static const int o_rdonly = _O_RDONLY;
    static const int o_wronly = _O_WRONLY; //O_LARGEFILE
    static const int o_trunc  = _O_TRUNC;

    HANDLE hFile;

    #else

    static const int o_creat  = O_CREAT;
    static const int o_append = O_APPEND; // Moves file pointer to end of file before every write operation.
    //static const int o_binary = O_BINARY;
    static const int o_excl   = O_EXCL; // only with _O_CREAT
    static const int o_rdwr   = O_RDWR;
    static const int o_rdonly = O_RDONLY;
    static const int o_wronly = O_WRONLY; //O_LARGEFILE
    static const int o_trunc  = O_TRUNC;
    static const int o_largefile = O_LARGEFILE;

    int    fd;

    #endif


    //CLI_BEGIN_INTERFACE_MAP2(CIosImplBase, INTERFACE_CLI_IO_IIOSTREAM)
    CLI_BEGIN_INTERFACE_MAP2(CFileIosImpl, INTERFACE_CLI_IO_IIOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISEEKABLE )
    CLI_END_INTERFACE_MAP(CIosImplBase)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    //int modeflag; // posix ModeFlags
    unsigned modeFlags;
    ::cli::CCriticalSection appendSeekLocker;
    bool ignoreReadTimeout;

    CFileIosImpl()
       : base_class()
       //CIosImplBase()
       #ifdef _WIN32
       , hFile(INVALID_HANDLE_VALUE)
       #else
       , fd(-1)
       #endif
       //, modeflag(0)
       //, uModeFlags(0)
       , modeFlags(0)
       , appendSeekLocker()
       , ignoreReadTimeout(true)
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CFileIosImpl()
       {
        closeStream();
       }


   CLIMETHOD(closeStream) (THIS)
      {
       #ifdef _WIN32
       if (hFile != INVALID_HANDLE_VALUE)
          {
           ::CloseHandle(hFile);
           hFile = INVALID_HANDLE_VALUE;
          }
       #else
       if (fd!=-1)
          {
           close(fd);
           fd = -1;
          }
       #endif
       return EC_OK;
      }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        closeStream();
        #ifdef _WIN32
        hFile = (HANDLE)handle;
        #else
        fd    = (int)handle;
        #endif
        return EC_OK;
       }


/* DECLARE_CLI_ERROR(EC_IOSTREAM_OPEN_FAILED     , 0xC000000E, "Open '%1' stream failed")
 * DECLARE_CLI_ERROR(EC_IOSTREAM_UNKNOWN_OPTION  , 0xC0000010, "Unknown option '%1' taken (stream name: '%2')")
 * DECLARE_CLI_ERROR(EC_IOSTREAM_INVALID_OPTVAL  , 0xC0000011, "Invalid option '%1' value '%3' taken (stream name: '%2')")
 * DECLARE_CLI_ERROR(EC_IOSTREAM_OPT_MULTIPLE    , 0xC0000012, "Option '%1' taken multiple times (stream name: '%2')")
   DECLARE_CLI_ERROR(EC_IOSTREAM_INVALID_OPENMODE, 0xC0000013, "Invalid open mode '%1' taken (stream name: '%2')")

 */
    // return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPTVAL, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo % optIt->second) );
    // return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
    // return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
    CLIMETHOD(getPos) (THIS_ FILE_SIZE_T*    curPos /* [out] file_size_t curPos  */)
       {
            CLI_TRY{
                    if (!curPos) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"curPos" );  }

                    #ifdef _WIN32
                    LARGE_INTEGER distanceToMove;
                    distanceToMove.LowPart  = 0;
                    distanceToMove.HighPart = 0;
                    LARGE_INTEGER filePointer;
                    if (!::SetFilePointerEx( hFile, distanceToMove, &filePointer, FILE_CURRENT ) )
                       {
                        //DWORD err = ::GetLastError();
                        return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
                       }
                    *curPos = filePointer.QuadPart;
                    #else
                    off_t res = lseek( fd, (off_t)0, SEEK_CUR );
                    if (res==(off_t)-1)
                       {
                        return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
                       }
                    *curPos = res;
                    #endif
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
       }

    CLIMETHOD(setPos) (THIS_ ENUM_CLI_IO_ESEEKMOVEMETHOD    method /* [in] ::cli::io::ESeekMoveMethod  method  */
                           , FILE_DIFF_T    distanceToMove /* [in] file_diff_t  distanceToMove  */
                           , FILE_SIZE_T*    newPos /* [out,optional] file_size_t newPos  */
                      )
       {
            CLI_TRY{
                    #ifdef _WIN32
                    DWORD dwMoveMethod = 0;
                    switch(method)
                       {
                        case CLI_IO_ESEEKMOVEMETHOD_BEGIN  : dwMoveMethod = FILE_BEGIN  ; break;
                        case CLI_IO_ESEEKMOVEMETHOD_CURRENT: dwMoveMethod = FILE_CURRENT; break;
                        case CLI_IO_ESEEKMOVEMETHOD_END    : dwMoveMethod = FILE_END    ; break;
                        default:
                             throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"method" );
                       };

                    LARGE_INTEGER dTM;
                    //distanceToMove.LowPart  = 0;
                    //distanceToMove.HighPart = 0;
                    dTM.QuadPart = distanceToMove;
                    LARGE_INTEGER filePointer;
                    if (!::SetFilePointerEx( hFile, dTM, &filePointer, dwMoveMethod ) )
                       {
                        //DWORD err = ::GetLastError();
                        return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
                       }
                    if (newPos) *newPos = filePointer.QuadPart;
                    #else
                    int whence = 0;
                    switch(method)
                       {
                        case CLI_IO_ESEEKMOVEMETHOD_BEGIN  : whence = SEEK_SET; break;
                        case CLI_IO_ESEEKMOVEMETHOD_CURRENT: whence = SEEK_CUR; break;
                        case CLI_IO_ESEEKMOVEMETHOD_END    : whence = SEEK_END; break;
                        default:
                             throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"method" );
                       };
                    off_t res = lseek( fd, (off_t)distanceToMove, whence );
                    if (res==(off_t)-1)
                       {
                        return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
                       }
                    if (newPos) *newPos = res;
                    #endif
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
       }


    CLIMETHOD(getSize) (THIS_ FILE_SIZE_T*    size /* [out] file_size_t curPos  */)
       {
            CLI_TRY{
                    if (!size) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1 ) % L"size" );  }

                    #ifdef _WIN32
                    LARGE_INTEGER fileSize;
                    if (!::GetFileSizeEx( hFile, &fileSize ) )
                       {
                        //DWORD err = ::GetLastError();
                        return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
                       }
                    *size = fileSize.QuadPart;
                    #else
                    off_t savedPos = lseek( fd, (off_t)0, SEEK_END );
                    if (savedPos==(off_t)-1)
                       {
                        return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
                       }
                    off_t sizePos = lseek( fd, (off_t)0, SEEK_END );
                    if (sizePos==(off_t)-1)
                       {
                        return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
                       }
                    *size = sizePos;
                    lseek( fd, savedPos, SEEK_SET );
                    #endif
                   }
            CLI_CATCH_RETURN_CLI_EXCEPTION()
            CLI_CATCH_RETURN_STD_EXCEPTIONS()
            return EC_OK;
       }

    CLIMETHOD(setSize) (THIS_ FILE_SIZE_T    newSize /* [in] file_size_t  newSize  */)
       {
        #ifdef _WIN32
        FILE_SIZE_T curPos;
        RCODE res = getPos( &curPos );
        if (res) return res;
        res = setPos( CLI_IO_ESEEKMOVEMETHOD_BEGIN, newSize, 0 );
        if (res) return res;
        if (!::SetEndOfFile( hFile ))
           {
            //DWORD err = ::GetLastError();
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        return setPos( CLI_IO_ESEEKMOVEMETHOD_BEGIN, curPos, 0 );
        #else
        // I am not shure that ftruncate don't move file pointer, so I save it
        FILE_SIZE_T curPos;
        RCODE rRes = getPos( &curPos );
        if (rRes) return rRes;

        int iRes = ftruncate( fd, (off_t)newSize);
        if (iRes==-1)
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        return setPos( CLI_IO_ESEEKMOVEMETHOD_BEGIN, curPos, 0 );
        #endif
       }

    RCODE internalOpenParsedOpts( const ::std::wstring &host
                                , const ::std::wstring &port
                                , const ::std::wstring &path
                                , const ::std::wstring &options
                                , const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                )
       {
        if (path.empty())
           return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_PATH, 0, 0, (::cli::format::arg(path) % streamNameInfo) );

        #if defined(_WIN32) || defined(WIN32)
        if (hFile != INVALID_HANDLE_VALUE)
           return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_ALLREADY_OPENED, 0, 0, (::cli::format::arg(streamNameInfo)) );
        #else
        if (fd != -1)
           return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_ALLREADY_OPENED, 0, 0, (::cli::format::arg(streamNameInfo)) );
        #endif

        #if defined(_WIN32) || defined(WIN32)
        DWORD w32OpenMode = 0;
        DWORD w32desiredAccess = 0;
        DWORD w32FileAttributes = FILE_ATTRIBUTE_NORMAL;
        #else
        int posixModeFlags = 0;
        #endif
        //int
        //bool modeTaken = false;
        ::std::wstring modeStr;
        bool toTaken = false;
        ::std::map< ::std::wstring, ::std::wstring >::const_iterator optIt = optionsMap.begin();
        for(; optIt!=optionsMap.end(); ++optIt)
           {
            ::std::wstring first  = MARTY_FILENAME_NS utils::lowerCase(optIt->first , MARTY_FILENAME_NS utils::makeUserLocale());
            ::std::wstring second = MARTY_FILENAME_NS utils::lowerCase(optIt->second, MARTY_FILENAME_NS utils::makeUserLocale());
            if (first==L"timeout")
               {
                if (toTaken)
                   return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_OPT_MULTIPLE, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo) );
                toTaken = true;

                if (second==L"i" || second==L"ignore" || second==L"n" || second==L"no")
                   {
                    ignoreReadTimeout = true;
                   }
                else if (second==L"u" || second==L"use" || second==L"y" || second==L"yes")
                   {
                    ignoreReadTimeout = false;
                   }
                else
                   {
                    return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPTVAL, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo % optIt->second) );
                   }
               }
            else if (first==L"mode")
               { // parse mode string
                if (!modeStr.empty())
                   return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_OPT_MULTIPLE, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo) );

                const ::std::wstring mode = second;
                modeStr = second;
                if (optIt->second.empty())
                   {
                    return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPTVAL, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo % optIt->second) );
                   }

                ::std::wstring::size_type errPos;
                modeFlags = parseFileOpenModeString( modeStr, &errPos );
                if (modeFlags==(unsigned)-1)
                   {
                    return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPTVAL, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo % optIt->second % modeStr[errPos] % errPos ) );
                   }

                if (!modeFlags) modeFlags = openModeR;

                if ( (modeFlags&openModeR) && (modeFlags&openModeTemporary) )
                   {
                    return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPTVAL, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo % optIt->second % modeStr[errPos] ) );
                   }

                if (modeFlags&openModeR)
                   { // 'r+' - Opens for both reading and writing. (The file must exist.)
                     // 'r'  - Opens for reading. If the file does not exist or cannot be found, the fopen call fails.
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_READ;
                    if (modeFlags&openModePlus) w32desiredAccess |= GENERIC_WRITE;
                    w32OpenMode      = OPEN_EXISTING; // both for r and r+
                    #else
                    if (modeFlags&openModePlus) posixModeFlags = o_rdwr;
                    else                        posixModeFlags = o_rdonly;
                    #endif
                   }
                else if (modeFlags&openModeW)
                   { // 'w+' - Opens an empty file for both reading and writing.
                     // If the given file exists, its contents are destroyed.
                     // 'w' - Opens an empty file for writing. If the given file exists, its contents are destroyed.
                    //modeflag = o_rdwr | o_creat | o_trunc;
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_WRITE;
                    if (modeFlags&openModePlus) w32desiredAccess |= GENERIC_READ;
                    w32OpenMode      = CREATE_ALWAYS;
                    #else
                    if (modeFlags&openModePlus) posixModeFlags = o_rdwr;
                    else                        posixModeFlags = o_wronly;
                    posixModeFlags |= o_creat | o_trunc;
                    #endif
                   }
                else if (modeFlags&openModeA)
                   {
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_WRITE;
                    if (modeFlags&openModePlus) w32desiredAccess |= GENERIC_READ;
                    w32OpenMode      = CREATE_ALWAYS;
                    #else
                    if (modeFlags&openModePlus) posixModeFlags = o_rdwr;
                    else                        posixModeFlags = o_wronly;
                    posixModeFlags |= o_creat | o_append;
                    #endif
                   }

                #if defined(_WIN32) || defined(WIN32)
                if (modeFlags&openModeTemporary)
                   w32FileAttributes |= FILE_FLAG_DELETE_ON_CLOSE;
                #endif

                /*
                size_t readedModeChars = 0;

                if (mode==L"r+")
                   { // Opens for both reading and writing. (The file must exist.)
                    modeflag = o_rdwr;
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_READ|GENERIC_WRITE;
                    w32OpenMode      = OPEN_EXISTING;
                    #endif
                    readedModeChars += 2;
                   }
                else if (mode==L"w+")
                   { // Opens an empty file for both reading and writing.
                     // If the given file exists, its contents are destroyed.
                    modeflag = o_rdwr | o_creat | o_trunc;
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_READ|GENERIC_WRITE;
                    w32OpenMode      = CREATE_ALWAYS;
                    #endif
                    readedModeChars += 2;
                   }
                else if (mode==L"a+")
                   { // Opens for reading and appending; the appending operation includes the
                     // removal of the EOF marker before new data is written to the file and
                     // the EOF marker is restored after writing is complete; creates the file
                     // first if it doesn't exist.
                    modeflag = o_rdwr | o_creat | o_append;
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_READ|GENERIC_WRITE;
                    w32OpenMode      = CREATE_ALWAYS;
                    #endif
                    readedModeChars += 2;
                   }
                else if (mode==L"r")
                   { // Opens for reading. If the file does not exist or cannot be found, the fopen call fails.
                    modeflag = o_rdonly;
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_READ;
                    w32OpenMode      = OPEN_EXISTING;
                    #endif
                    readedModeChars += 1;
                   }
                else if (mode==L"w")
                   { // Opens an empty file for writing. If the given file exists, its contents are destroyed.
                    modeflag = o_wronly | o_creat | o_trunc;
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_WRITE;
                    w32OpenMode      = CREATE_ALWAYS;
                    #endif
                    readedModeChars += 1;
                   }
                else if (mode==L"a")
                   { // Opens for writing at the end of the file (appending) without removing
                     // the EOF marker before writing new data to the file;
                     // creates the file first if it doesn't exist.
                    modeflag = o_wronly | o_creat | o_append;
                    #if defined(_WIN32) || defined(WIN32)
                    w32desiredAccess = GENERIC_WRITE;
                    w32OpenMode      = OPEN_ALWAYS;
                    #endif
                    readedModeChars += 1;
                   }


                FILE_FLAG_DELETE_ON_CLOSE
                */
                /*

                ::std::wstring::size_type pos = 0;
                switch (mode[pos])
                   {
                    case L'r': modeflag = o_rdonly;
                               break;
                    case L'w': modeflag = o_wronly | o_creat | o_trunc;
                               break;
                    case L'a': modeflag = o_wronly | o_creat | o_append;
                               break;
                    default:
                               return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPENMODE, 0, 0, (::cli::format::arg(mode) % streamNameInfo) );
                   };

                ++pos;
                if (pos<mode.size())
                   {
                    if (mode[pos]!=L'+')
                       return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPENMODE, 0, 0, (::cli::format::arg(mode) % streamNameInfo) );
                    if (modeflag & o_rdwr)
                       {
                            //whileflag=0;
                       }
                    else
                       {
                        modeflag |= o_rdwr;
                        modeflag &= ~(o_rdonly | o_wronly);
                       }
                   }

                ++pos;
                if (pos<mode.size()) // ������� ����� �������� � ������, ������
                   return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPENMODE, 0, 0, (::cli::format::arg(mode) % streamNameInfo) );
                */


               }
            // else if (optIt->first=="") // Add additional options parsing here
            else
               { // "Unknown option '%1' taken (stream name: '%2')"
                return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_UNKNOWN_OPTION, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo) );
               }
           }

/*
        if (!modeflag)
           {
            // use default "r" mode
            modeflag = o_rdonly;
            #if defined(_WIN32) || defined(WIN32)
            w32desiredAccess = GENERIC_READ;
            w32OpenMode      = OPEN_EXISTING;
            #endif
           }
*/

        // Used flags: o_rdonly o_wronly o_creat o_trunc o_append o_rdwr

        #if defined(_WIN32) || defined(WIN32)
        //DWORD fileaccess = 0;               /* OS file access (requested) */
        if (!w32desiredAccess) // if nothing options taken, open in read only mode
           w32desiredAccess |= GENERIC_READ;

        if (!w32OpenMode)
           w32OpenMode |= OPEN_EXISTING;

        DWORD fileshare  = FILE_SHARE_READ|FILE_SHARE_WRITE;               /* OS file sharing mode */
        //if (modeFlags&openModeTemporary)
        //DWORD filecreate = 0;               /* OS method of opening/creating */
        //DWORD w32FileAttributes = FILE_ATTRIBUTE_NORMAL;               /* OS file attribute flags */

        /*
        switch( modeflag & (o_rdonly | o_wronly | o_rdwr) )
           {
            case o_rdonly:         // read access
                    fileaccess = GENERIC_READ;
                    break;
            case o_wronly:         // write access
                    fileaccess = GENERIC_WRITE;
                    break;
            case o_rdwr:           // read and write access
                    fileaccess = GENERIC_READ | GENERIC_WRITE;
                    break;
            default:               // error, bad oflag
                    return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPENMODE, 0, 0, (::cli::format::arg(modeStr) % streamNameInfo) );
           };


        switch ( modeflag & (o_creat | o_excl | o_trunc) )
           {
            case 0:
            case o_excl:                   // ignore EXCL w/o CREAT
                filecreate = OPEN_EXISTING;
                break;

            case o_creat:
                filecreate = OPEN_ALWAYS;
                break;

            case o_creat | o_excl:
            case o_creat | o_trunc | o_excl:
                filecreate = CREATE_NEW;
                break;

            case o_trunc:
            case o_trunc | o_excl:        // ignore EXCL w/o CREAT
                filecreate = TRUNCATE_EXISTING;
                break;

            case o_creat | o_trunc:
                filecreate = CREATE_ALWAYS;
                break;

            default:
                return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_INVALID_OPENMODE, 0, 0, (::cli::format::arg(modeStr) % streamNameInfo) );
           };
        */
        /*
        if ( oflag & _O_TEMPORARY ) {
            fileattrib |= FILE_FLAG_DELETE_ON_CLOSE;
            fileaccess |= DELETE;
            if (osplatform == VER_PLATFORM_WIN32_NT )
                fileshare  |= FILE_SHARE_DELETE;
        */

        ::cli::io::CiConnectingStateWatcher watcher(pConWatcher);
        //if (res && !!watcher /*  && !plainIp */ )
        //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , host);

        /*
        #if defined(_WIN32) || defined(WIN32)
        ::std::wstring path = _path;
        if (::cli::util::startsWithI(path, L"/") && !::cli::util::startsWithI(path, L"//") && path.size()>=3 && path[2]==L':')
           path.erase();
        #else
        ::std::wstring path = _path;
        #endif
        */

        #if defined(_UNICODE) || defined(UNICODE)
        ::std::wstring filename = MARTY_WINAPI_NS makeUnicodeLongFilename(path[0]==L'/' ? ::std::wstring(path, 1, path.npos) : path);
        #else
        ::std::string  filename = MARTY_CON_NS w2ansi( path[0]==L'/' ? ::std::wstring(path, 1, path.npos) : path );
        #endif

        if ( (hFile = CreateFile( (LPTSTR)filename.c_str(),
                                 w32desiredAccess,
                                 fileshare,
                                 0, // &SecurityAttributes
                                 w32OpenMode,
                                 w32FileAttributes,
                                 NULL ))
             == INVALID_HANDLE_VALUE )
           {
            if (!!watcher)
               {
                //RCODE res = WIN2RC(::GetLastError());
                //if (res)
                watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED     , L"");
                //else     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATECONNECTED  , L"");
               }
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo) % filename ) );
           }

        #else

        ::cli::io::CiConnectingStateWatcher watcher(pConWatcher);

        // TODO - add file system misc encoding support
        ::std::string filename = MARTY_UTF_NS toUtf8(path[0]!=L'/' ? ::std::wstring(1, L'/') + path : path);
        if (!posixModeFlags)
           posixModeFlags = o_rdonly;
        fd = :: open( filename.c_str(), posixModeFlags | o_largefile,  S_IRWXU|S_IRWXG|S_IRWXO ); // use chmod to change flags
        if (fd==-1)
           {
            if (!!watcher)
               {
                //if (res)
                watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED     , L"");
                //else     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATECONNECTED  , L"");
               }
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }

        if (modeFlags&openModeTemporary)
           {
            unlink( filename.c_str() );
           }
        #endif

        if (!!watcher) watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATECONNECTED  , L"");

        //EC_IOSTREAM_INVALID_OPTION
        return EC_OK;
       }

    CLIMETHOD_(DWORD, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_FILE;
       }

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out] byte buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        #ifdef _WIN32

        DWORD readed = 0;
        if (!::ReadFile( hFile, buf, (DWORD)numBytesToRead, &readed, 0 ))
           {
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesReaded) *numBytesReaded = (SIZE_T)readed;
        if (readed) return EC_OK;
        return EC_EOF;

        #else

        ssize_t res = :: read(fd, buf, numBytesToRead);
        if (res==-1)
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesReaded) *numBytesReaded = (SIZE_T)res;
        if (res>0) return EC_OK;
        return EC_EOF;

        #endif
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out] byte buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        // for file read operation we ignore millisecTimeout if flag ignoreReadTimeout is set
        if (!ignoreReadTimeout)
           ::cli::sched::sleepMs((unsigned)millisecTimeout);

        return this->read(buf, numBytesToRead, numBytesReaded);
       }

    inline
    RCODE unsafeWrite(const VOID*    buf
                     , SIZE_T    numBytesToWrite
                     , SIZE_T*    numBytesWritten
                     )
       {
        #ifdef _WIN32

        DWORD written = 0;
        if (!::WriteFile( hFile, buf, (DWORD)numBytesToWrite, &written, 0 ))
           {
            return CLI_SET_WIN_ERROR_INFO_ARGS( ::GetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesWritten) *numBytesWritten = (SIZE_T)written;
        return EC_OK;

        #else

        ssize_t res = :: write(fd, buf, numBytesToWrite);
        if (res==-1)
           {
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        if (numBytesWritten) *numBytesWritten = (SIZE_T)res;
        return EC_OK;

        #endif

       }

    #ifdef _WIN32

    static const int seek_whence_begin    = FILE_BEGIN;
    static const int seek_whence_current  = FILE_CURRENT;
    static const int seek_whence_end      = FILE_END;

    typedef __int64 file_offset_t;
    inline
    file_offset_t myFileSeek (HANDLE hf, __int64 distance, DWORD MoveMethod)
       {
          LARGE_INTEGER li;

          li.QuadPart = distance;

          li.LowPart = SetFilePointer (hf,
                                       li.LowPart,
                                       &li.HighPart,
                                       MoveMethod);

          if (li.LowPart == INVALID_SET_FILE_POINTER && GetLastError()
              != NO_ERROR)
          {
             li.QuadPart = -1;
          }

          return li.QuadPart;
       }

    #else

    static const int seek_whence_begin    = SEEK_SET;
    static const int seek_whence_current  = SEEK_CUR;
    static const int seek_whence_end      = SEEK_END;

    typedef off_t file_offset_t;
    inline
    file_offset_t myFileSeek(int _fd, file_offset_t ofs, int whence)
       {
        return lseek(_fd, ofs, whence);
       }

    #endif


    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in] byte  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        file_offset_t prevPos;
        //if (modeflag&o_append)
        if (modeFlags&openModeA)
           {
            appendSeekLocker.lock();
            #ifdef _WIN32
            prevPos = myFileSeek( hFile, 0, seek_whence_end);
            #else
            prevPos = myFileSeek( fd, 0, seek_whence_end);
            #endif
            if (prevPos==(file_offset_t)-1) // error
               {
                #ifdef _WIN32
                DWORD err = WIN2RC(::GetLastError());
                #else
                int   err = errno;
                #endif
                appendSeekLocker.unlock();
                return CLI_SET_ERROR_INFO_ARGS( err, 0, 0, (::cli::format::arg(streamNameInfo)) );
               }
           }

        RCODE res = unsafeWrite( buf, numBytesToWrite, numBytesWritten);

        //if (modeflag&o_append)
        if (modeFlags&openModeA)
           {
            #ifdef _WIN32
            myFileSeek( hFile, prevPos, seek_whence_begin);
            #else
            myFileSeek( fd, prevPos, seek_whence_begin);
            #endif
            appendSeekLocker.unlock();
           }

        if (res) return CLI_SET_ERROR_INFO_ARGS( res, 0, 0, (::cli::format::arg(streamNameInfo)) );

        return EC_OK;
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in] byte  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        // for file write operation we ignore millisecTimeout
        return this->write( buf, numBytesToWrite, numBytesWritten);
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }

}; // CFileIosImpl

}; // namespace impl
}; // namespace io
}; // namespace cli



#endif /* CORE_IO_FILEIOS_H */

