/*!
\project ��������� /cli/io-comscanner
    \libraries cli2
    \libpath 
    \incpath 

    \platform mingw win32
        \libraries cli2

    \platform linux
        \libraries cli2
        \libpath 
        \incpath 
*/

//#define CLI_INTERNAL
//#define CLI_INTERNAL_DONT_LINK_CLI_LIB

#include <cli/cli2.h>
#include "clicomscan.h"


// NOTE: if not works under W2K, disable resolver by uncommenting preprocessor directives below
//#if defined(WIN32_WINNT) && WIN32_WINNT>=0x0501
//    #include "inet/resolvImpl.h"
//#endif



DECLARE_COMPONENT_CREATION_PROC( create_cli_io_portfinder, ::cli::io::impl::CPortFinderImpl, INTERFACE_CLI_IO_IPORTFINDER )
//DECLARE_COMPONENT_CREATION_PROC( create_cli_moxa_moxafinderimpl , ::cli::moxa::impl::CMoxaFinderImpl , INTERFACE_CLI_MOXA_IMOXAFINDER )
//DECLARE_COMPONENT_CREATION_PROC( create_cli_inet_udpserver_impl, ::cli::inet::impl::CUdpServerImpl, INTERFACE_CLI_INET_IUDPSERVER)


CLI_BEGIN_COMPONENT_TABLE()
      CLI_COMPONENT_TABLE_ENTRY1("/cli/io/port-finder", create_cli_io_portfinder, INTERFACE_CLI_IO_IPORTFINDER_IID, "en:Component that scans environment for serial ports;")
CLI_END_COMPONENT_TABLE(registerCliComScan, "clicomscan")


