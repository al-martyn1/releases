#ifndef SOCKIMPL_H
#define SOCKIMPL_H

#ifndef CLI_IO_I_IO_H
    #include <cli/io/i_io.h>
#endif

#ifndef CLI_IO_ISOCK_H
    #include <cli/inet/isock.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_CLI2X_H
    #include <cli/cli2x.h>
#endif

#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif

#ifndef CLI_CLIEXCEPT_H
    #include <cli/cliexcept.h>
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#ifndef CLI_YIELD_H
    #include <cli/yield.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif


#include "../inet/inethlp.h"



#if !defined(_WIN32) && !defined(WIN32)

    #include <unistd.h>
    #include <errno.h>
    #include <sys/select.h>
    #include <sys/time.h>
    #include <sys/types.h>
    #include <sys/errno.h>

    #include <netinet/tcp.h>

#endif


#ifdef _WIN32
    #if !defined(_INC_MALLOC) && !defined(_MALLOC_H_) && !defined(_MALLOC_H)
        #include <malloc.h>
    #endif
#else
    #include <alloca.h>
    #ifndef _alloca
        #define _alloca  alloca
    #endif
#endif


namespace cli  {
namespace io   {
namespace impl {


#ifdef WIN32
    typedef BOOL (WINAPI *SwitchToThreadFnPtrType)( VOID );
    // Kernel32.dll
#endif


#define CSOCKETIMPL_IMPLEMENT_STREAMNAME_PROPERTY() \
    CLIMETHOD(streamNameGet) (THIS_ CLISTR*           _streamName)                               \
       {                                                                                         \
        CLI_SCOPED_LOCK(streamNameLocker);                                                       \
        CLI_TRY{                                                                                 \
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  } \
                return ::cli::propertyGetImpl(_streamName, streamNameInfo);                      \
               }                                                                                 \
        CLI_CATCH_RETURN_CLI_EXCEPTION()                                                         \
        CLI_CATCH_RETURN_STD_EXCEPTIONS()                                                        \
        return EC_OK;                                                                            \
                                                                                                 \
       }                                                                                         \
                                                                                                 \
    CLIMETHOD(streamNameSet) (THIS_ const CLISTR*     _streamName)                               \
       {                                                                                         \
        CLI_SCOPED_LOCK(streamNameLocker);                                                       \
        CLI_TRY{                                                                                 \
                if (!_streamName) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"_streamName" );  } \
                return ::cli::propertySetImpl(_streamName, streamNameInfo);                      \
               }                                                                                 \
        CLI_CATCH_RETURN_CLI_EXCEPTION()                                                         \
        CLI_CATCH_RETURN_STD_EXCEPTIONS()                                                        \
        return EC_OK;                                                                            \
       }




struct CSocketImplBase : public INTERFACE_CLI_INET_ISOCKET
{
    SYS_SOCKET_HANDLE            hSock;
    ENUM_CLI_INET_SOCKETTYPE     sockType;
    ::std::wstring               streamNameInfo;
    ::cli::CCriticalSection      streamNameLocker;

    STRUCT_CLI_INET_SOCKETADDRESS localAddr;
    STRUCT_CLI_INET_SOCKETADDRESS peerAddr;
    STRUCT_CLI_INET_IPADDRESS     defMulticastGroupInterface;


    #if defined(WIN32) || defined(_WIN32)
    SwitchToThreadFnPtrType    SwitchToThreadFn;
    #endif

    CSocketImplBase()
       : hSock(INVALID_SYS_SOCKET_HANDLE)
       , sockType(CLI_INET_SOCKETTYPE_DGRAM)
       , streamNameInfo(L"generic socket io stream")
       , streamNameLocker()
       , localAddr()
       , peerAddr()
       , defMulticastGroupInterface()
       #if defined(WIN32) || defined(_WIN32)
       , SwitchToThreadFn(0)
       #endif
       {
        ::cli::inet::initSocketsAPI();

        ::cli::inet::CIpAddress ipAddrHelper;
        ipAddrHelper.makeAddrAny( 0, AF_INET );
        ipAddrHelper.toPlain(&defMulticastGroupInterface);

        #if defined(WIN32) || defined(_WIN32)
        HMODULE hKernelModule = ::GetModuleHandleA( "Kernel32.dll" );
        if (hKernelModule)
           {
            SwitchToThreadFn = (SwitchToThreadFnPtrType) ::GetProcAddress( hKernelModule, "SwitchToThread" );
           }
        #endif
       }

    #if defined(WIN32) || defined(_WIN32)
    void win32yield()
       {
        if (SwitchToThreadFn) SwitchToThreadFn();
        else                  Sleep(10);
       }
    #endif

    ~CSocketImplBase()
       {
        closeSocket();
       }

    CLIMETHOD(closeStream) (THIS)
       {
        closeSocket();
        return EC_OK;
       }

    CLIMETHOD(handleGet) (THIS_ SYS_SOCKET_HANDLE*    handle /* [out] sys_socket_handle handle  */)
       {
        if (handle) *handle = hSock;
        return EC_OK;
       }

    CLIMETHOD(handleSet) (THIS_ SYS_SOCKET_HANDLE    handle /* [in] sys_socket_handle  handle  */)
       {
        if (hSock!=INVALID_SYS_SOCKET_HANDLE)
           {
            closeSocket();
           }
        hSock = handle;
        return EC_OK;
       }

    CLIMETHOD(socketTypeGet) (THIS_ INT*    pSocketType /* [out] ::cli::inet::SocketType socketType  */)
       {
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_INVALID_SOCKET;
        if (pSocketType) *pSocketType = sockType;
        return EC_OK;
       }

    CLIMETHOD(localAddrGet) (THIS_ STRUCT_CLI_INET_SOCKETADDRESS*    _localAddr /* [out] ::cli::inet::SocketAddress localAddr  */)
       {
        if (_localAddr) *_localAddr = localAddr;
        return EC_OK;
       }

    CLIMETHOD(peerAddrGet) (THIS_ STRUCT_CLI_INET_SOCKETADDRESS*    _peerAddr /* [out] ::cli::inet::SocketAddress peerAddr  */)
       {
        if (_peerAddr) *_peerAddr = peerAddr;
        return EC_OK;
       }

    template <typename T>
    RCODE getSockOption( int level, int optName, T *pval)
       {
        if (!pval) return EC_INVALID_PARAM;
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_BROKEN_STREAM;

        T tmp;
        #if defined(WIN32) || defined(_WIN32)
        int optLen = sizeof(tmp);
        int gsRes = getsockopt( hSock, level, optName, (char*)&tmp, &optLen );
        if (gsRes==SOCKET_ERROR)
            return WIN2RC(WSAGetLastError());
        #else
        socklen_t optLen = sizeof(tmp);
        int gsRes = getsockopt( hSock, level, optName, (void*)&tmp, &optLen );
        if (gsRes==-1)
            return POSIX2RC(errno);
        #endif

        *pval = tmp;
        return EC_OK;
       }

    template <typename T>
    RCODE setSockOption( int level, int optName, T val)
       {
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_BROKEN_STREAM;

        #if defined(WIN32) || defined(_WIN32)
        int gsRes = setsockopt( hSock, level, optName, (char*)&val, sizeof(val) );
        if (gsRes==SOCKET_ERROR)
            return WIN2RC(WSAGetLastError());
        #else
        int gsRes = setsockopt( hSock, level, optName, (void*)&val, sizeof(val) );
        if (gsRes==-1)
            return POSIX2RC(errno);
        #endif
        return EC_OK;
       }

    RCODE convertIpAddrStrHelper( ::cli::inet::CIpAddress &ipAddr, const CLISTR* addrPlain, const ::std::wstring &strAddr, ::cli::inet::CiResolver &resolver, bool allowAny )
       {
        RCODE res = EC_OK;
        if (strAddr==L"*" || strAddr==L"*4" || strAddr==L"any" || strAddr==L"ANY" || strAddr==L"any4" || strAddr==L"ANY4")
           {
            if (!allowAny) return EC_RESOLV_INVALID_ADDR;
            ipAddr.makeAddrAny( 0, AF_INET );
           }
        else if (strAddr==L"*6" || strAddr==L"any6" || strAddr==L"ANY6")
           {
            if (!allowAny) return EC_RESOLV_INVALID_ADDR;
            ipAddr.makeAddrAny( 0, AF_INET6 );
           }
        else
           {
            STRUCT_CLI_INET_IPADDRESS ipAddrPlain;
            res = resolver.getIfPtr()->stringToIp( addrPlain, (STRUCT_CLI_INET_IPADDRESS*)&ipAddrPlain);
            if (res) return res;
            if (!ipAddr.fromPlain(&ipAddrPlain))
               return EC_RESOLV_INVALID_ADDR;
           }
        return res;
       }

    CLIMETHOD(defMulticastGroupInterfaceGet) (THIS_ STRUCT_CLI_INET_IPADDRESS*    _defMulticastGroupInterface /* [out] ::cli::inet::IpAddress _defMulticastGroupInterface  */)
       {
        CLI_TRY{
                if (!_defMulticastGroupInterface) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"defMulticastGroupInterface" );  }
                *_defMulticastGroupInterface = defMulticastGroupInterface;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(defMulticastGroupInterfaceSet) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    _defMulticastGroupInterface /* [in,ref] ::cli::inet::IpAddress  _defMulticastGroupInterface  */)
       {
        CLI_TRY{
                if (!_defMulticastGroupInterface) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"defMulticastGroupInterface" );  }
                defMulticastGroupInterface = *_defMulticastGroupInterface;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(prepareMulticastGroupRec)(THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */
                                 , const STRUCT_CLI_INET_IPADDRESS*    _ifAddr /* [in,ref] ::cli::inet::IpAddress  ifAddr  */
                                 , ip_mreq &mreg
                                 )
       {
        if (!addr) return EC_INVALID_PARAM;
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_BROKEN_STREAM;
        if (addr->af!=AF_INET) return EC_INVALID_AF;
        if (!_ifAddr) _ifAddr  = &defMulticastGroupInterface;
        if (_ifAddr->af!=addr->af) return EC_INVALID_AF;

        ::cli::inet::CIpAddress ifAddr;
        if (!ifAddr.fromPlain(_ifAddr))
           return EC_RESOLV_INVALID_ADDR;

        ::cli::inet::CIpAddress groupAddr;
        if (!groupAddr.fromPlain(addr))
           return EC_RESOLV_INVALID_ADDR;

        #if defined(DEBUG) || defined(_DEBUG)
        ::std::wstring ifAddrStr    = ifAddr.toWideString();
        ::std::wstring groupAddrStr = groupAddr.toWideString();
        ::cli::format::cli_log::message("joinToMulticastGroup, imr_interface: %1, imr_multiaddr: %2", ::cli::arglist(ifAddrStr) % groupAddrStr );
        #endif

        RCODE res = ifAddr.makeInAddr( mreg.imr_interface );
        if (res) return res;
        res = groupAddr.makeInAddr( mreg.imr_multiaddr );
        if (res) return res;
        return EC_OK;
       }

    CLIMETHOD(joinToMulticastGroupEx) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */
                                           , const STRUCT_CLI_INET_IPADDRESS*    ifAddr /* [in,ref] ::cli::inet::IpAddress  ifAddr  */
                                      )
       {
        ip_mreq mreg;
        RCODE res = prepareMulticastGroupRec(addr, ifAddr, mreg );
        if (res) return res;

        //DWORD forceMulticastLoopOn = 1;
        //setSockOption( IPPROTO_IP, IP_MULTICAST_LOOP, forceMulticastLoopOn);

        return setSockOption( IPPROTO_IP, IP_ADD_MEMBERSHIP, mreg);
       }

    CLIMETHOD(leaveMulticastGroupEx) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */
                                          , const STRUCT_CLI_INET_IPADDRESS*    ifAddr /* [in,ref] ::cli::inet::IpAddress  ifAddr  */
                                     )
       {
        ip_mreq mreg;
        RCODE res = prepareMulticastGroupRec(addr, ifAddr, mreg );
        if (res) return res;

        return setSockOption( IPPROTO_IP, IP_DROP_MEMBERSHIP, mreg);
       }

    CLIMETHOD(joinToMulticastGroupExStr) (THIS_ const CLISTR*     addr
                                              , const CLISTR*     _ifAddr
                                         )
       {
        if (!addr) return EC_INVALID_PARAM;

        CLI_TRY{
                ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");

                STRUCT_CLI_INET_IPADDRESS joinAddrPlain;
                ::cli::inet::CIpAddress   joinAddr;
                RCODE res = convertIpAddrStrHelper( joinAddr, addr, stdstr(addr), resolver, true /* allowAny */);
                if (res) return res;
                if (!joinAddr.toPlain(&joinAddrPlain))
                   CLI_THROW(EC_RESOLV_INVALID_ADDR);

                if (!_ifAddr)
                   return joinToMulticastGroupEx( &joinAddrPlain, 0 );

                STRUCT_CLI_INET_IPADDRESS ifAddrPlain;
                ::cli::inet::CIpAddress   ifAddr;
                res = convertIpAddrStrHelper( ifAddr, _ifAddr, stdstr(_ifAddr), resolver, true /* allowAny */);
                if (res) return res;
                if (!ifAddr.toPlain(&ifAddrPlain))
                   CLI_THROW(EC_RESOLV_INVALID_ADDR);

                return joinToMulticastGroupEx( &joinAddrPlain, &ifAddrPlain );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(leaveMulticastGroupExStr) (THIS_ const CLISTR*     addr
                                             , const CLISTR*     _ifAddr
                                        )
       {
        if (!addr) return EC_INVALID_PARAM;

        CLI_TRY{
                ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");

                STRUCT_CLI_INET_IPADDRESS joinAddrPlain;
                ::cli::inet::CIpAddress   joinAddr;
                RCODE res = convertIpAddrStrHelper( joinAddr, addr, stdstr(addr), resolver, true /* allowAny */);
                if (res) return res;
                if (!joinAddr.toPlain(&joinAddrPlain))
                   CLI_THROW(EC_RESOLV_INVALID_ADDR);

                if (!_ifAddr)
                   return leaveMulticastGroupEx( &joinAddrPlain, 0 );

                STRUCT_CLI_INET_IPADDRESS ifAddrPlain;
                ::cli::inet::CIpAddress   ifAddr;
                res = convertIpAddrStrHelper( ifAddr, _ifAddr, stdstr(_ifAddr), resolver, true /* allowAny */);
                if (res) return res;
                if (!ifAddr.toPlain(&ifAddrPlain))
                   CLI_THROW(EC_RESOLV_INVALID_ADDR);

                return leaveMulticastGroupEx( &joinAddrPlain, &ifAddrPlain );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(joinToMulticastGroup) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */)
       {
        return joinToMulticastGroupEx( addr, 0);
       }


    CLIMETHOD(joinToMulticastGroupStr) (THIS_ const CLISTR*     addr)
       {
        return joinToMulticastGroupExStr( addr, 0);
       }

    CLIMETHOD(leaveMulticastGroup) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */)
       {
        return leaveMulticastGroupEx( addr, 0);
       }

    CLIMETHOD(leaveMulticastGroupStr) (THIS_ const CLISTR*     addr)
       {
        return leaveMulticastGroupExStr( addr, 0);
       }

    CLIMETHOD(multicastTTLGet) (THIS_ UINT*    _multicastTTL /* [out] uint _multicastTTL  */)
       {
        if (!_multicastTTL) return EC_INVALID_PARAM;
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_BROKEN_STREAM;
        return getSockOption( IPPROTO_IP, IP_MULTICAST_TTL, _multicastTTL);
       }

    CLIMETHOD(multicastTTLSet) (THIS_ UINT    _multicastTTL /* [in] uint  _multicastTTL  */)
       {
        if (!_multicastTTL) return EC_INVALID_PARAM;
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_BROKEN_STREAM;
        return setSockOption( IPPROTO_IP, IP_MULTICAST_TTL, _multicastTTL);
       }

    CLIMETHOD(broadcastModeGet) (THIS_ BOOL*    broadcastMode /* [out] bool broadcastMode  */)
       {
        BOOL brMode = 0;
        RCODE res = getSockOption( SOL_SOCKET, SO_BROADCAST, &brMode);
        if (res) return res;

        if (broadcastMode)
           {
            if (brMode) *broadcastMode = TRUE;
            else        *broadcastMode = FALSE;
           }

        return res;
       }

    CLIMETHOD(broadcastModeSet) (THIS_ BOOL    broadcastMode /* [in] bool  broadcastMode  */)
       {
        if (broadcastMode) broadcastMode = 1;
        else               broadcastMode = 0;

        return setSockOption( SOL_SOCKET, SO_BROADCAST, broadcastMode);
       }

    CLIMETHOD(reuseAddrGet) (THIS_ BOOL*    reuseAddr /* [out] bool reuseAddr  */)
       {
        BOOL ra = 0;
        RCODE res = getSockOption( SOL_SOCKET, SO_REUSEADDR, &ra);
        if (res) return res;

        if (reuseAddr)
           {
            if (ra) *reuseAddr = TRUE;
            else    *reuseAddr = FALSE;
           }
        return res;
       }

    CLIMETHOD(reuseAddrSet) (THIS_ BOOL    reuseAddr /* [in] bool  reuseAddr  */)
       {
        if (reuseAddr) reuseAddr = 1;
        else           reuseAddr = 0;

        return setSockOption( SOL_SOCKET, SO_REUSEADDR, reuseAddr);
       }

    CLIMETHOD(reusePortGet) (THIS_ BOOL*    _reusePort /* [out] bool _reusePort  */)
       {
        #ifdef SO_REUSEPORT
        BOOL rp = 0;
        RCODE res = getSockOption( SOL_SOCKET, SO_REUSEPORT, &rp);
        if (res) return res;

        if (reuseAddr)
           {
            if (rp) *reuseAddr = TRUE;
            else    *reuseAddr = FALSE;
           }
        #else
        if (_reusePort) *_reusePort = FALSE;
        #endif
        return EC_OK;
       }

    CLIMETHOD(reusePortSet) (THIS_ BOOL    _reusePort /* [in] bool  _reusePort  */)
       {
        #ifdef SO_REUSEPORT
        if (_reusePort) _reusePort = 1;
        else            _reusePort = 0;
        return setSockOption( SOL_SOCKET, SO_REUSEPORT, _reusePort);
        #else
        return EC_OK;
        #endif
       }

    CLIMETHOD(exclusiveAddrUseGet) (THIS_ BOOL*    _exclusiveAddrUse /* [out] bool _exclusiveAddrUse  */)
       {
        #ifdef SO_EXCLUSIVEADDRUSE
        BOOL eau = 0;
        RCODE res = getSockOption( SOL_SOCKET, SO_EXCLUSIVEADDRUSE, &eau);
        if (res) return res;

        if (_exclusiveAddrUse)
           {
            if (eau) *_exclusiveAddrUse = TRUE;
            else     *_exclusiveAddrUse = FALSE;
           }
        #else
        if (_exclusiveAddrUse) *_exclusiveAddrUse = FALSE;
        #endif
        return EC_OK;
       }

    CLIMETHOD(exclusiveAddrUseSet) (THIS_ BOOL    _exclusiveAddrUse /* [in] bool  _exclusiveAddrUse  */)
       {
        #ifdef SO_EXCLUSIVEADDRUSE
        if (_exclusiveAddrUse) _exclusiveAddrUse = 1;
        else                  _exclusiveAddrUse = 0;
        return setSockOption( SOL_SOCKET, SO_EXCLUSIVEADDRUSE, _exclusiveAddrUse);
        #else
        return EC_OK;
        #endif
       }

    CLIMETHOD(tcpNoDelayGet) (THIS_ BOOL*    noDelay /* [out] bool noDelay  */)
       {
        BOOL nd = 0;
                                // SOL_TCP
        RCODE res = getSockOption( IPPROTO_TCP, TCP_NODELAY, &nd);
        if (res) return res;

        if (nd) *noDelay = TRUE;
        else    *noDelay = FALSE;

        return res;
       }

    CLIMETHOD(tcpNoDelaySet) (THIS_ BOOL    noDelay /* [in] bool  noDelay  */)
       {
        if (noDelay) noDelay = 1;
        else         noDelay = 0;
                           // SOL_TCP
        return setSockOption( IPPROTO_TCP, TCP_NODELAY, noDelay);
       }


    CLIMETHOD(createSocketEx) (THIS_ UINT    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                   , INT    type /* [in] ::cli::inet::SocketType  type  */
                                   , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                   , BOOL    bNonBlock /* [in] bool  bNonBlock  */
                              )
       {
        RCODE res = createSocket( af, type, protocol );
        if (res) return res;

        if (bNonBlock)
           {
            #if defined(WIN32) || defined(_WIN32)
            u_long nb = 1;
            if (::ioctlsocket( hSock, FIONBIO, &nb) == SOCKET_ERROR)
               {
                DWORD wsaErr = WSAGetLastError();
                closeSocket();
                return WIN2RC(wsaErr);
               }
            #else
            int flags = ::fcntl(hSock, F_GETFL);
            if (flags==-1)
               {
                int e = errno;
                closeSocket();
                return POSIX2RC(e);
               }
            flags |= O_NONBLOCK;
            if (::fcntl(hSock, F_SETFL, flags)==-1)
               {
                int e = errno;
                closeSocket();
                return POSIX2RC(e);
               }
            #endif
           }

        return EC_OK;
       }

    CLIMETHOD(createSocket) (THIS_ UINT    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                 , INT    type /* [in] ::cli::inet::SocketType  type  */
                                 , ENUM_CLI_INET_PROTOCOLTYPE    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                            )
       {
        closeSocket();

        hSock = :: socket( af, type, protocol );
        if (hSock==INVALID_SYS_SOCKET_HANDLE)
           #if defined(WIN32) || defined(_WIN32)
           return WIN2RC(WSAGetLastError());
           #else
           return POSIX2RC(errno);
           #endif

        sockType = type;
        localAddr.af = af;
        peerAddr.af  = af;

        return EC_OK;
       }

    CLIMETHOD(closeSocket) (THIS)
       {
        #if defined(WIN32) || defined(_WIN32)
        if (hSock!=INVALID_SYS_SOCKET_HANDLE)  ::closesocket(hSock);
        #else
        if (hSock!=INVALID_SYS_SOCKET_HANDLE)  ::close(hSock);
        #endif
        hSock = INVALID_SYS_SOCKET_HANDLE;
        sockType = CLI_INET_SOCKETTYPE_DGRAM;
        return EC_OK;
       }

    CLIMETHOD(connectSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */)
       {
        if (!sa) return EC_INVALID_PARAM;
        if (sa->af!=localAddr.af || sa->af!=peerAddr.af) return EC_INVALID_AF;

        peerAddr = *sa;
        ::cli::inet::CIpAddress ipAddr;
        if (!ipAddr.fromPlain(&peerAddr))
           {
            closeSocket();
            return EC_INVALID_PARAM;
           }

        int conRes = 0;

        if (peerAddr.af==AF_INET)
           {
            sockaddr_in addr;
            RCODE msaRes = ipAddr.makeSockAddr( addr );
            if (msaRes)
               {
                closeSocket();
                return msaRes;
               }
            conRes = ::connect( hSock, (const sockaddr *)&addr, sizeof(addr) );
           }
        else
           {
            sockaddr_in6 addr;
            RCODE msaRes = ipAddr.makeSockAddr( addr );
            if (msaRes)
               {
                closeSocket();
                return msaRes;
               }
            conRes = ::connect( hSock, (const sockaddr *)&addr, sizeof(addr) );
           }

        #if defined(WIN32) || defined(_WIN32)
        if (conRes==SOCKET_ERROR)
           {
            DWORD e = WSAGetLastError();
            if (e==WSAEINPROGRESS || e==WSAEWOULDBLOCK) return EC_IN_PROGRESS;
            //if (e==WSAEWOULDBLOCK) return EC_IN_PROGRESS;
            closeSocket();
            return WIN2RC(e);
           }
        #else
        if (conRes==-1)
           {
            int e = errno;
            if (e==EINPROGRESS || e==EWOULDBLOCK) return EC_IN_PROGRESS;
            //if (e==EWOULDBLOCK) return EC_IN_PROGRESS;
            closeSocket();
            return POSIX2RC(e);
           }
        #endif

        /* bool */
        getSockNameHelper( localAddr, peerAddr.af );

        return EC_OK;
       }

    bool getSockNameHelper( STRUCT_CLI_INET_SOCKETADDRESS &lsa, UINT af )
       {
        ::cli::inet::CIpAddress tmp;
        tmp.makeAddrAny( 0, af);

        #if defined(WIN32) || defined(_WIN32)
        int localAddrLen = 0;
        #else
        socklen_t localAddrLen = 0;
        #endif

        if (af==AF_INET)
           {
            sockaddr_in addr;
            localAddrLen = sizeof(addr);
            int gsnRes = getsockname( hSock, (struct sockaddr*)&addr, &localAddrLen);
            #if defined(WIN32) || defined(_WIN32)
            if (gsnRes!=SOCKET_ERROR)
            #else
            if (gsnRes!=-1)
            #endif
               {
                if (tmp.fromSockAddr(addr))
                   {
                    tmp.toPlain(&lsa);
                    return true;
                   }
               }
           }
        else
           {
            sockaddr_in6 addr;
            localAddrLen = sizeof(addr);
            int gsnRes = getsockname( hSock, (struct sockaddr*)&addr, &localAddrLen);
            #if defined(WIN32) || defined(_WIN32)
            if (gsnRes!=SOCKET_ERROR)
            #else
            if (gsnRes!=-1)
            #endif
               {
                if (tmp.fromSockAddr(addr))
                   {
                    tmp.toPlain(&lsa);
                    return true;
                   }
               }
           }
        return false;
       }

    CLIMETHOD(waitAsyncConnect) (THIS_ TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */)
       {
        fd_set rset, wset;
        FD_ZERO(&rset); FD_ZERO(&wset);
        FD_SET(hSock, &rset);
        FD_SET(hSock, &wset);

        struct timeval Timeout;
        Timeout.tv_usec = (unsigned)(millisecTimeout%1000)*1000;  // � ������������
        Timeout.tv_sec  = (unsigned)millisecTimeout/1000;  // �������
        // BUG: Check condition then select returns ok and socket is in rd set and wr set,
        // What it means?
        #if defined(WIN32) || defined(_WIN32)
        int selectRes = select(0/*ign*/, &rset, &wset, NULL, &Timeout );
        #else
        int selectRes = select(hSock+1 , &rset, &wset, NULL, &Timeout );
        #endif

        #if defined(WIN32) || defined(_WIN32)
            if (selectRes==SOCKET_ERROR)
        #else
            #ifdef ERESTARTNOHAND
            if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
            #else
            if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
            #endif
        #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            DWORD e = WSAGetLastError();
            closeSocket();
            return WIN2RC(e);
            #else
            int e = errno;
            closeSocket();
            return POSIX2RC(e);
            #endif
           }

        if (selectRes==-1 || selectRes==0)
           return EC_IN_PROGRESS;

        if (FD_ISSET(hSock, &rset) && FD_ISSET(hSock, &wset))
           {
            int err;
            #if defined(WIN32) || defined(_WIN32)
            int errLen = sizeof(err);
            #else
            socklen_t errLen = sizeof(err);
            #endif
            int gsoRes = ::getsockopt( hSock, SOL_SOCKET, SO_ERROR, (char*)&err, &errLen);
            #if defined(WIN32) || defined(_WIN32)
            if (gsoRes==SOCKET_ERROR)
               { // ������ ��� ��������� ������
                DWORD e = WSAGetLastError();
                closeSocket();
                return WIN2RC(e);
               }
            // ���������� ������ �������������� ������
            closeSocket();
            return WIN2RC(err);
            #else
            if (gsoRes==-1)
               { // ������ ��� ��������� ������
                int e = errno;
                closeSocket();
                return POSIX2RC(e);
               }
            // ���������� ������ �������������� ������
            closeSocket();
            return POSIX2RC(err);
            #endif
           }
        return EC_OK;
       }


    CLIMETHOD(bindSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */)
       {
        if (!sa) return EC_INVALID_PARAM;
        if (sa->af!=localAddr.af) return EC_INVALID_AF;
        localAddr = *sa;

        ::cli::inet::CIpAddress ipAddr;
        if (!ipAddr.fromPlain(&localAddr))
           {
            //closeSocket();
            return EC_RESOLV_INVALID_ADDR;
           }

        int conRes = 0;

        if (localAddr.af==AF_INET)
           {
            sockaddr_in addr;
            RCODE msaRes = ipAddr.makeSockAddr( addr );
            if (msaRes)
               {
                //closeSocket();
                return msaRes;
               }
            conRes = ::bind( hSock, (const sockaddr *)&addr, sizeof(addr) );
           }
        else
           {
            sockaddr_in6 addr;
            RCODE msaRes = ipAddr.makeSockAddr( addr );
            if (msaRes)
               {
                //closeSocket();
                return msaRes;
               }
            conRes = ::bind( hSock, (const sockaddr *)&addr, sizeof(addr) );
           }

        #if defined(WIN32) || defined(_WIN32)
        if (conRes==SOCKET_ERROR)
           {
            return WIN2RC(WSAGetLastError());
           }
        #else
        if (conRes==-1)
           {
            return POSIX2RC(errno);
           }
        #endif

        return EC_OK;
       }

    CLIMETHOD(bindSocketStr) (THIS_ const CLISTR*     addr
                                  , const CLISTR*     port
                                  , const CLISTR*     protocol
                             )
       {
        STRUCT_CLI_INET_SOCKETADDRESS bindToAddr;

        CLI_TRY{
                ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                RCODE res = resolver.getIfPtr()->getServiceInfoStr2( port, protocol );
                CLI_THROW_IF_NOK(res);

                UINT p = 0;
                resolver.portGet(&p);

                ::cli::inet::CIpAddress ipAddr;

                res = convertIpAddrStrHelper( ipAddr, addr, stdstr(addr), resolver, true /* allowAny */ );
                CLI_THROW_IF_NOK(res);
                if (!ipAddr.toPlain(&bindToAddr))
                   CLI_THROW(EC_RESOLV_INVALID_ADDR);
                bindToAddr.port = p;

                return bindSocket(&bindToAddr);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(listenSocket) (THIS)
       {
        // UNDONE: need to use env var CLI2_TCP_LISTEN_BACKLOG
        #if defined(SOMAXCONN)
        int res = ::listen( hSock, SOMAXCONN );
        #else // I think all system cant have 4 connections in queue
        int res = ::listen( hSock, 4 );
        #endif

        #if defined(WIN32) || defined(_WIN32)
        if (res==SOCKET_ERROR)
           {
            return WIN2RC(WSAGetLastError());
           }
        #else
        if (res==-1)
           {
            return POSIX2RC(errno);
           }
        #endif

        return EC_OK;
       }

    CLIMETHOD(setMulticastInterfaceId) (THIS_ UINT    ifId /* [in] uint  ifId  */)
       {
        if (localAddr.af==AF_INET)
           {
            return setSockOption( IPPROTO_IP, IP_MULTICAST_IF, htonl((long)ifId) );
           }
        else
           {
            return setSockOption( IPPROTO_IPV6, IPV6_MULTICAST_IF, htonl((long)ifId) );
           }
       }

    CLIMETHOD(getMulticastInterfaceId) (THIS_ UINT*    ifId /* [out] uint ifId  */)
       {
        if (!ifId) return EC_INVALID_PARAM;
        RCODE res = 0;
        if (localAddr.af==AF_INET)
           {
            res = getSockOption( IPPROTO_IP, IP_MULTICAST_IF, ifId );
           }
        else
           {
            res = getSockOption( IPPROTO_IPV6, IPV6_MULTICAST_IF, ifId );
           }
        if (!res)
           *ifId = htonl((long)*ifId);
        return res;
       }

    // const IPV6_MULTICAST_IF = 17;

    //http://www.qnx.com/developers/docs/6.5.0/index.jsp?topic=%2Fcom.qnx.doc.neutrino_lib_ref%2Fi%2Fip6_proto.html
    // IPv6 not currently supported
    CLIMETHOD(setMulticastInterface) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */)
       {
        if (!addr) return EC_INVALID_PARAM;
        if (addr->af!=localAddr.af) return EC_INVALID_AF;

        if (addr->af!=AF_INET) return EC_INVALID_AF;

        ::cli::inet::CIpAddress ipAddr;
        if (!ipAddr.fromPlain(addr))
           {
            //closeSocket();
            return EC_RESOLV_INVALID_ADDR;
           }

        DWORD dwIp = 0;
        RCODE res = ipAddr.makeSockAddr( dwIp );
        if (res) return res;

        return setSockOption( IPPROTO_IP, IP_MULTICAST_IF, dwIp );
       }

    CLIMETHOD(getMulticastInterface) (THIS_ STRUCT_CLI_INET_IPADDRESS*    addr /* [out] ::cli::inet::IpAddress addr  */)
       {
        if (!addr) return EC_INVALID_PARAM;
        //if (localAddr.af==AF_INET)
        DWORD dwIp = 0;
        RCODE res = getSockOption( IPPROTO_IP, IP_MULTICAST_IF, &dwIp );
        if (res) return res;

        ::cli::inet::CIpAddress ipAddr;
        res = ipAddr.fromSockAddr( dwIp );
        if (res) return res;
        if (!ipAddr.toPlain(addr))
           return EC_RESOLV_INVALID_ADDR;
        return EC_OK;
       }

    CLIMETHOD(setMulticastInterfaceStr) (THIS_ const CLISTR*     addr)
       {
        STRUCT_CLI_INET_IPADDRESS mifAddr;

        CLI_TRY{
                ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                ::cli::inet::CIpAddress ipAddr;

                RCODE res = convertIpAddrStrHelper( ipAddr, addr, stdstr(addr), resolver, true /* allowAny */ );
                CLI_THROW_IF_NOK(res);
                if (!ipAddr.toPlain(&mifAddr))
                   CLI_THROW(EC_RESOLV_INVALID_ADDR);
                return setMulticastInterface(&mifAddr);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       
       }

    CLIMETHOD(getMulticastInterfaceStr) (THIS_ CLISTR*           strAddr)
       {
        CLI_TRY{
                if (!strAddr) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"strAddr" );  }
                STRUCT_CLI_INET_IPADDRESS addr;
                RCODE res = getMulticastInterface( &addr );
                if (res) return res;
                ::cli::inet::CIpAddress ipAddr;
                ipAddr.fromPlain( &addr );
                
                return ::cli::propertyGetImpl(strAddr, ipAddr.toWideString() );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    
    CLIMETHOD(setMulticastLoop) (THIS_ BOOL    loopOn /* [in] bool  loopOn  */)
       {
        #if defined(WIN32) || defined(_WIN32)
        DWORD v = loopOn ? TRUE : FALSE;
        #else
        u_char v = loopOn ? 1 : 0;
        #endif
        if (localAddr.af==AF_INET)
           return setSockOption( IPPROTO_IP, IP_MULTICAST_LOOP, v );
        else
           return setSockOption( IPPROTO_IPV6, IPV6_MULTICAST_LOOP, v );
       }

    CLIMETHOD(getMulticastLoop) (THIS_ BOOL*    loopState /* [out] bool loopState  */)
       {
        #if defined(WIN32) || defined(_WIN32)
        DWORD v = 0;
        #else
        u_char v = 0;
        #endif
        RCODE gsRes = 0;
        if (localAddr.af==AF_INET)
           gsRes = getSockOption( IPPROTO_IP, IP_MULTICAST_LOOP, &v );
        else
           gsRes = getSockOption( IPPROTO_IPV6, IPV6_MULTICAST_LOOP, &v );

        if (gsRes) return gsRes;

        if (loopState)
           {
            *loopState = v ? 1 : 0;
           }

        return EC_OK;
       }

    CLIMETHOD(selectSocket) (THIS_ DWORD     selectFor /* [in] ::cli::inet::SelectWhat  selectFor  */
                                 , DWORD*    readyFor /* [out] ::cli::inet::SelectWhat readyFor  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        if (!selectFor) return EC_INVALID_PARAM;
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_BROKEN_STREAM;

        fd_set readFs           , writeFs                  , exceptFs ;
        FD_ZERO(&readFs)        ; FD_ZERO(&writeFs)        ; FD_ZERO(&exceptFs);

        if (selectFor&CLI_INET_SELECTWHAT_SELECTREAD  )
           FD_SET( hSock, &readFs );

        if (selectFor&CLI_INET_SELECTWHAT_SELECTWRITE)
           FD_SET( hSock, &writeFs );

        if (selectFor&CLI_INET_SELECTWHAT_SELECTEXCEPT)
           FD_SET( hSock, &exceptFs );

        struct timeval Timeout;
        Timeout.tv_usec = (unsigned)(millisecTimeout%1000)*1000;  // � ������������
        Timeout.tv_sec  = (unsigned)millisecTimeout/1000;  // �������

        int selectRes = ::select(
                                #if defined(WIN32) || defined(_WIN32)
                                0/*ign*/
                                #else
                                hSock+1
                                #endif
                              , (selectFor&CLI_INET_SELECTWHAT_SELECTREAD  ) ? &readFs : 0
                              , (selectFor&CLI_INET_SELECTWHAT_SELECTWRITE ) ? &writeFs : 0
                              , (selectFor&CLI_INET_SELECTWHAT_SELECTEXCEPT) ? &exceptFs : 0
                              , &Timeout
                              );

        #if defined(WIN32) || defined(_WIN32)
            if (selectRes==SOCKET_ERROR)
        #else
            #ifdef ERESTARTNOHAND
            if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
            #else
            if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
            #endif
        #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            return CLI_SET_WIN_ERROR_INFO_ARGS(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
            #else
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
            #endif
           }

        if (!selectRes) return EC_TIMED_OUT;

        ENUM_CLI_INET_SELECTWHAT whatSelected = 0;

        if ((selectFor&CLI_INET_SELECTWHAT_SELECTREAD  ) && FD_ISSET( hSock, &readFs ))
           whatSelected |= CLI_INET_SELECTWHAT_SELECTREAD;

        if ((selectFor&CLI_INET_SELECTWHAT_SELECTWRITE) && FD_ISSET( hSock, &writeFs ))
           whatSelected |= CLI_INET_SELECTWHAT_SELECTWRITE;

        if ((selectFor&CLI_INET_SELECTWHAT_SELECTEXCEPT) && FD_ISSET( hSock, &exceptFs ))
           whatSelected |= CLI_INET_SELECTWHAT_SELECTEXCEPT;

        if (readyFor) *readyFor = whatSelected;

        return EC_OK;
       }



    CLIMETHOD(acceptSocketConnection) (THIS_ SYS_SOCKET_HANDLE*    hAccepted /* [out] sys_socket_handle hAccepted  */
                                           , STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [out] ::cli::inet::SocketAddress sa  */
                                           , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                      )
       {
        if (!hAccepted) return EC_INVALID_PARAM;

        struct timeval Timeout;
        Timeout.tv_usec = (unsigned)(millisecTimeout%1000)*1000;  // � ������������
        Timeout.tv_sec  = (unsigned)millisecTimeout/1000;  // �������

        fd_set readFs;
        FD_ZERO( &readFs );
        FD_SET( hSock, &readFs );

        #if defined(WIN32) || defined(_WIN32)
        int selectRes = select(0/*ign*/, &readFs, NULL, NULL, &Timeout );
        #else
        int selectRes = select(hSock+1 , &readFs, NULL, NULL, &Timeout );
        #endif

        #if defined(WIN32) || defined(_WIN32)
            if (selectRes==SOCKET_ERROR)
        #else
            #ifdef ERESTARTNOHAND
            if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
            #else
            if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
            #endif
        #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            return CLI_SET_WIN_ERROR_INFO_ARGS(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
            #else
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
            #endif
           }

        if (!selectRes || !FD_ISSET( hSock, &readFs ))
           return EC_TIMED_OUT;


        SYS_SOCKET_HANDLE newSock;
        #if defined(WIN32) || defined(_WIN32)
        int addrLen = 0;
        #else
        socklen_t addrLen = 0;
        #endif

        RCODE res;
        ::cli::inet::CIpAddress ipAddr;

        if (localAddr.af==AF_INET)
           {
            sockaddr_in addr;
            addrLen = sizeof(addr);
            newSock = ::accept( hSock, (struct sockaddr*)&addr, &addrLen);
            res = ipAddr.fromSockAddr( addr );
           }
        else
           {
            sockaddr_in6 addr;
            addrLen = sizeof(addr);
            newSock = ::accept( hSock, (struct sockaddr*)&addr, &addrLen);
            res = ipAddr.fromSockAddr( addr );
           }

        if (newSock==INVALID_SYS_SOCKET_HANDLE)
           {
            #if defined(WIN32) || defined(_WIN32)
            return CLI_SET_WIN_ERROR_INFO_ARGS(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
            #else
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
            #endif
           }

        if (res) // conversion failed
           {
            ipAddr.makeAddrAny( 0, localAddr.af );
           }

        if (sa)
           ipAddr.toPlain(sa);

        *hAccepted = newSock;
        return EC_OK;
       }

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        return readTimeout( buf, numBytesToRead, numBytesReaded, 0 );
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_BROKEN_STREAM;

        struct timeval Timeout;
        Timeout.tv_usec = (unsigned)(millisecTimeout%1000)*1000;  // � ������������
        Timeout.tv_sec  = (unsigned)millisecTimeout/1000;  // �������

        fd_set readFs;
        FD_ZERO( &readFs );
        FD_SET( hSock, &readFs );

        #if defined(WIN32) || defined(_WIN32)
        int selectRes = select(0/*ign*/, &readFs, NULL, NULL, &Timeout );
        #else
        int selectRes = select(hSock+1 , &readFs, NULL, NULL, &Timeout );
        #endif

        #if defined(WIN32) || defined(_WIN32)
            if (selectRes==SOCKET_ERROR)
        #else
            #ifdef ERESTARTNOHAND
            if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
            #else
            if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
            #endif
        #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            return CLI_SET_WIN_ERROR_INFO_ARGS(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
            #else
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
            #endif
           }

        if (selectRes==-1 || selectRes==0 || (!FD_ISSET( hSock, &readFs )) )
           {
            // �������� �������� ��������,
            // ��� ����� ������� ��� ���������� �� � ������ ������������, ������� ��� ������
            // ����������, ���  ������ �� ���������
            if (numBytesReaded) *numBytesReaded = 0;
            return EC_OK;
           }

        // ����� ������, ������ �� �������������
        //ssize_t readRes = :: read(hRead, buf, numBytesToRead);
        #if defined(WIN32) || defined(_WIN32)
        int recvRes = recv( hSock, (char*)buf, (int)numBytesToRead, 0);
        #else
        int recvRes = recv( hSock,        buf,      numBytesToRead, 0);
        #endif

        #if defined(WIN32) || defined(_WIN32)
            if (recvRes==SOCKET_ERROR)
        #else
            if (recvRes==-1)
        #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            return CLI_SET_WIN_ERROR_INFO_ARGS(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
            #else
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
            #endif
           }

        if (!recvRes)
           { // ���������� ��������� ������� ������ ��������
            if (numBytesReaded) *numBytesReaded = 0;
            //closeCurrentHandle();
            closeSocket();
            return CLI_SET_ERROR_INFO_ARGS( EC_CONNECTION_CLOSED, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }

        if (numBytesReaded) *numBytesReaded = (SIZE_T)recvRes;
        return EC_OK;
       }

    // UNDONE: send() ����� ������� ������ SIGPIPE, ���� ���������� ������� �
    // ������ ������� (��� ����� ���������, ���� ������ MSG_NOSIGNAL,
    // ���� ������ ������, ���� ������ ��������� ��������� ���� ������).
    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_IOSTREAM_NOT_WRITEABLE;

        #if defined(WIN32) || defined(_WIN32)
        int sndRes = send( hSock, (char*)buf, (int)numBytesToWrite, 0 );
        #else
        int sndRes = send( hSock,        buf,      numBytesToWrite, 0 );
        #endif

        #if defined(WIN32) || defined(_WIN32)
        if (sndRes==SOCKET_ERROR)
           {
            if (WSAGetLastError()==WSAEWOULDBLOCK)
               { // ��� ���������, ������ ��� ����������� ��������� ������, ���� ��������� �����
                if (numBytesWritten) *numBytesWritten = 0;
                return EC_OK;
               }
            // ��������� �����-�� ����
            return CLI_SET_WIN_ERROR_INFO_ARGS(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        #else
        if (sndRes==-1)
           {
            if (errno==EAGAIN || errno==EWOULDBLOCK)
               {
               if (numBytesWritten) *numBytesWritten = 0;
                return EC_OK;
               }
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        #endif

        // ��� ���������,���-�� �����������
        if (numBytesWritten) *numBytesWritten = (SIZE_T)sndRes;

        return EC_OK;

/*
WSAEWOULDBLOCK The socket is marked as nonblocking and the requested operation would block.

EAGAIN ��� EWOULDBLOCK
����� ������� ��� �������������, � ����������� �������� ������ ���� �� ������������� ���.

ENOBUFS ���������  �������  ��������  ����������  ���������.
������ ��� ��������, ��� ��������� ��������� ��������, ��
����� ���� ����� ������� ��������� �����������. (����� �� �����
��������� ��� Linux, ������ ��� ����� ������ ������ �������������,
����� ������� ���������� �������������.)

*/
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        return this->write(buf, numBytesToWrite, numBytesWritten );
       }


    CLIMETHOD(recvFrom) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                             , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                             , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                             , STRUCT_CLI_INET_SOCKETADDRESS*    pLocalAddr /* [out,ref] ::cli::inet::SocketAddress localAddr  */
                             , STRUCT_CLI_INET_SOCKETADDRESS*    peerAddr /* [out,ref] ::cli::inet::SocketAddress peerAddr  */
                        )
       {

        #if defined(WIN32) || defined(_WIN32)
        int addrLen = 0;
        #else
        socklen_t addrLen = 0;
        #endif

        //RCODE res;
        //::cli::inet::CIpAddress ipAddr;
        int res;
        ::cli::inet::CIpAddress ipAddr;
        ipAddr.makeAddrAny( 0, localAddr.af );

        //if (localAddr) getSockNameHelper( *localAddr, UINT af )

        if (pLocalAddr) *pLocalAddr = localAddr;

        if (localAddr.af==AF_INET)
           {
            sockaddr_in addr;
            addrLen = sizeof(addr);
            res = recvfrom( hSock, (char*)buf, (unsigned)numBytesToRead, 0, (sockaddr*)&addr, &addrLen);
            if (res>=0)
               {
                if (numBytesReaded) *numBytesReaded = res;
                if (!ipAddr.fromSockAddr(addr))
                   ipAddr.toPlain(peerAddr);
               }
           }
        else
           {
            sockaddr_in6 addr;
            addrLen = sizeof(addr);
            res = recvfrom( hSock, (char*)buf, (unsigned)numBytesToRead, 0, (sockaddr*)&addr, &addrLen);
            if (res>=0)
               {
                if (numBytesReaded) *numBytesReaded = res;
                if (!ipAddr.fromSockAddr(addr))
                   ipAddr.toPlain(peerAddr);
               }
           }

        if (res>=0)
           {
            if (*numBytesReaded) *numBytesReaded = res;
            return EC_OK;
           }

        #if defined(WIN32) || defined(_WIN32)
        return WIN2RC(WSAGetLastError());
        #else
        return POSIX2RC(errno);
        #endif
       }

    CLIMETHOD(recvFromTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                    , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                    , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                    , STRUCT_CLI_INET_SOCKETADDRESS*    localAddr /* [out,ref] ::cli::inet::SocketAddress localAddr  */
                                    , STRUCT_CLI_INET_SOCKETADDRESS*    peerAddr /* [out,ref] ::cli::inet::SocketAddress peerAddr  */
                                    , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                               )
       {
        ENUM_CLI_INET_SELECTWHAT readyFor = 0;
        RCODE res = selectSocket( CLI_INET_SELECTWHAT_SELECTREAD, &readyFor, millisecTimeout );
        if (res) return res;
        if (!(readyFor&CLI_INET_SELECTWHAT_SELECTREAD))
           {
            //return EC_NO_DATA_FOR_READING;
            return EC_TIMED_OUT;
           }

        return recvFrom( buf, numBytesToRead, numBytesReaded, localAddr, peerAddr );
       }

    CLIMETHOD(sendTo) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                           , SIZE_T     numBytesToWrite /* [in] size_t  numBytesToWrite  */
                           , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                           , const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */
                      )
       {
        if (sa->af!=localAddr.af) return EC_INVALID_AF;
        //localAddr = *sa;

        ::cli::inet::CIpAddress ipAddr;
        if (!ipAddr.fromPlain(sa))
           {
            return EC_RESOLV_INVALID_ADDR;
           }

        int sendRes = 0;

        #if defined(WIN32) || defined(_WIN32)
        int addrLen = 0;
        #else
        socklen_t addrLen = 0;
        #endif

        if (localAddr.af==AF_INET)
           {
            sockaddr_in addr;
            RCODE msaRes = ipAddr.makeSockAddr( addr );
            if (msaRes) return msaRes;
            addrLen = sizeof(addr);
            sendRes = sendto( hSock, (char*)buf, (unsigned)numBytesToWrite, 0, (sockaddr*)&addr, addrLen);
           }
        else
           {
            sockaddr_in6 addr;
            RCODE msaRes = ipAddr.makeSockAddr( addr );
            if (msaRes) return msaRes;
            addrLen = sizeof(addr);
            sendRes = sendto( hSock, (char*)buf, (unsigned)numBytesToWrite, 0, (sockaddr*)&addr, addrLen);
           }

        if ((sendRes>0) || (!sendRes && !numBytesToWrite))
           {
            if (numBytesWritten) *numBytesWritten = sendRes;
            return EC_OK;
           }

        #if defined(WIN32) || defined(_WIN32)
        return WIN2RC(WSAGetLastError());
        #else
        return POSIX2RC(errno);
        #endif
       }

    CLIMETHOD(sendToTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                  , SIZE_T     numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                  , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                  , const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */
                                  , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                             )
       {
        ENUM_CLI_INET_SELECTWHAT readyFor = 0;
        RCODE res = selectSocket( CLI_INET_SELECTWHAT_SELECTWRITE, &readyFor, millisecTimeout );
        if (res) return res;
        if (!(readyFor&CLI_INET_SELECTWHAT_SELECTWRITE))
           {
            //return EC_NO_DATA_FOR_READING;
            return EC_TIMED_OUT;
           }

        return sendTo( buf, numBytesToWrite, numBytesWritten, sa );
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }


};








struct CTcpClientSocket : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_IO_IIOSTREAM
                    , public INTERFACE_CLI_IO_IISTREAM
                    , public INTERFACE_CLI_IO_IOSTREAM
                    , public CSocketImplBase
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CTcpClientSocket()
       : base_impl(DEF_MODULE)
       , CSocketImplBase()
       {
       }

    void closeCurrentHandle()
       {
        #if defined(WIN32) || defined(_WIN32)
        if (hSock!=INVALID_SYS_SOCKET_HANDLE)  ::closesocket(hSock);
        #else
        if (hSock!=INVALID_SYS_SOCKET_HANDLE)  ::close(hSock);
        #endif
        hSock = INVALID_SYS_SOCKET_HANDLE;
       }

    ~CTcpClientSocket()
       {
        //closeSocket
        //closeCurrentHandle();
        closeStream();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CTcpClientSocketImpl, INTERFACE_CLI_IO_IIOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INET_ISOCKET   )
    CLI_END_INTERFACE_MAP(CTcpClientSocketImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    CSOCKETIMPL_IMPLEMENT_STREAMNAME_PROPERTY()

    CLIMETHOD(closeStream) (THIS)
       {
        closeSocket();
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        return handleSet( (SYS_SOCKET_HANDLE)handle );
       }

    virtual RCODE internalOpenParsedOpts( const ::std::wstring &host
                                        , const ::std::wstring &port
                                        , const ::std::wstring &path
                                        , const ::std::wstring &options
                                        , const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                        , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                        )
        {
         RCODE lastConnErr = 0;
         CLI_TRY{

                 ::std::wstring hostPortSrc;
                   {
                    ::cli::inet::CIpAddress ipAddrTmp;
                    if (::cli::inet::convertIpAddress(host, ipAddrTmp) && ipAddrTmp.addrType==AF_INET6)
                       hostPortSrc = ::std::wstring(1,L'[') + host + ::std::wstring(L"]:") + port;
                    else
                       hostPortSrc = host + ::std::wstring(1, L':') + port;
                   }

                 ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");

                 STRUCT_CLI_INET_IPADDRESS tmpIpAddr;
                 bool plainIp = true;
                 if (resolver.stringToIp(host,tmpIpAddr))
                    plainIp = false;


                 /*
                 STRUCT_CLI_INET_IPADDRESS tmpIpAddr;
                 bool plainIp = true;
                 if (resolver.ipToString(tmpIpAddr, host))
                    plainIp = false;
                 */
                 //::cli::io::CiConnectingStateWatcher watcher(pConWatcher, true /*noAddRef*/);
                 ::cli::io::CiConnectingStateWatcher watcher(pConWatcher);

                 //RCODE watcher.watch( conState , const ::std::wstring    &infoStr )
                 if (!!watcher && !plainIp )
                    watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING, host);
                    //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING, hostPortSrc);

                 // �������� ����� �����
                 RCODE res = resolver.getServiceInfoStr2( port, L"tcp" );
                 if (res && !!watcher && !plainIp )
                    {
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, port);
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , port);
                     //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, hostPortSrc);
                     //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , hostPortSrc);
                     //pConWatcher->release();
                    }
                 CLI_THROW_IF_NOK(res);

                 // �������� ������ �����
                 res = resolver.getHostInfoByName( host, AF_UNSPEC );
                 if (res && !!watcher /*  && !plainIp */ )
                    {
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, host);
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , host);
                     //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, hostPortSrc);
                     //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , hostPortSrc);
                     //pConWatcher->release();
                    }
                 CLI_THROW_IF_NOK(res);

                 ::std::wstring canonicalName;
                 resolver.canonicalNameGet( canonicalName );
                 if (!!watcher && !plainIp )
                    {
                     if (!canonicalName.empty())
                        watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING, canonicalName );
                     else
                        watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING, host );
                    }

                 // ������ ������, ���� ��� ����������� ��������
                 // � 100 ������,���� ����� connWatcher � ���� ����������� ����������
                 SIZE_T tryCountMax = pConWatcher ? 300 : 10;

                 SIZE_T i = 0;
                 SIZE_T addrListSize = 0;
                 resolver.addrListSize(&addrListSize);
                 for(; i!=addrListSize; ++i)
                    {
                     STRUCT_CLI_INET_SOCKETADDRESS sa;
                     res = resolver.addrListGetSocketAddress( sa, i );
                     if (res) continue;

                     ::std::wstring hostPortResolved;

                     if (!!watcher)
                        {
                         ::std::wstring portStr;
                         ::cli::inet::portToWideString( sa.port, portStr );

                         ::cli::inet::CIpAddress ipAddrTmp;
                         ipAddrTmp.fromPlain(&sa);
                         if (ipAddrTmp.addrType==AF_INET6)
                            hostPortResolved = ::std::wstring(1,L'[') + ipAddrTmp.toWideString() + ::std::wstring(L"]:") + portStr;
                         else
                            hostPortResolved = ipAddrTmp.toWideString() + ::std::wstring(1,L':') + portStr;

                         watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_BEGINCONNECTING, hostPortResolved );
                        }


                     res = createSocketEx( sa.af, CLI_INET_SOCKETTYPE_STREAM, CLI_INET_PROTOCOLTYPE_TCP, TRUE );
                     if (res && !!watcher)
                        {
                         watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING, hostPortResolved );
                         watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED   , hostPortSrc);
                         //pConWatcher->release();
                        }
                     CLI_THROW_IF_NOK(res);

                     res = connectSocket( &sa );
                     if (res && res!=EC_IN_PROGRESS)
                        {
                         if (!!watcher)
                            {
                             watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING, hostPortResolved );
                             //watcher.watch( CLI_IO_IOCONNECTINGSTATE_STATEFAILED   , hostPortResolved );
                            }
                         //CLI_THROW(res);
                         // try next
                         lastConnErr = res;
                         continue;
                        }

                     if (!res)
                        {
                         if (!!watcher)
                            {
                             watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSCONNECTING, hostPortResolved );
                             watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATECONNECTED   , hostPortSrc );
                             //pConWatcher->release();
                            }
                         return res;
                        }

                     SIZE_T tryCount = 0; // tryCountMax
                     while(res==EC_IN_PROGRESS && tryCount!=tryCountMax)
                        {
                         ++tryCount;
                         if (!!watcher)
                            {
                             RCODE watchRes = watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_ABORTREQUEST, hostPortResolved );
                             if (watchRes==EC_ABORTED)
                                {
                                 watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING, hostPortResolved );
                                 watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED   , hostPortSrc );
                                 //pConWatcher->release();
                                 //CLI_THROW(res);
                                 CLI_THROW(EC_ABORTED);
                                }
                            }
                         res = waitAsyncConnect(1000);
                        }

                     if (res && tryCount==tryCountMax) res = EC_TIMED_OUT;

                     if (res)
                        {
                         if (!!watcher)
                            {
                             watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING, hostPortResolved );
                             watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED   , hostPortSrc );
                            }
                         //CLI_THROW(res);
                         // try next
                         lastConnErr = res;
                         continue;
                        }

                     if (!!watcher)
                        {
                         watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSCONNECTING, hostPortResolved );
                         watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATECONNECTED   , hostPortSrc );
                         //pConWatcher->release();
                        }

                     return EC_OK;
                    }
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return lastConnErr;
        }

    inline
    RCODE internalOpen( const ::std::wstring &streamName
                      , const ::std::wstring &host
                      , const ::std::wstring &port
                      , const ::std::wstring &path
                      , const ::std::wstring &options
                      , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                      )
       {
        streamNameInfo.assign(streamName);

        ::std::map< ::std::wstring, ::std::wstring > optionsMap;

        ::marty::confUtils::splitOptionsString( optionsMap, options
                                              //, OPT_SEP_CHAR, OPT_EQU_CHAR, OPT_QUOT_CHAR
                                              , L',', L'=', L'\''
                                              , ::marty::confUtils::IsSpacePred()
                                              );

        return internalOpenParsedOpts( host, port, path, options, optionsMap, pConWatcher );
       }

    CLIMETHOD(open) (THIS_ const CLISTR*     streamName
                         , const CLISTR*     host
                         , const CLISTR*     port
                         , const CLISTR*     path
                         , const CLISTR*     options
                         , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                    )
       {
        //return EC_NOT_IMPLEMENTED;
        return internalOpen( stdstr(streamName), stdstr(host), stdstr(port), stdstr(path), stdstr(options), pConWatcher );
       }

    CLIMETHOD(openPStr) (THIS_ CLIPSTR           streamName
                             , CLIPSTR           host
                             , CLIPSTR           port
                             , CLIPSTR           path
                             , CLIPSTR           options
                             , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                        )
       {
        //return EC_NOT_IMPLEMENTED;
        return internalOpen( stdstr(streamName), stdstr(host), stdstr(port), stdstr(path), stdstr(options), pConWatcher );
       }

    CLIMETHOD_(DWORD, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_TCP;
       }


    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        return CSocketImplBase::read( buf, numBytesToRead, numBytesReaded );
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        return CSocketImplBase::readTimeout( buf, numBytesToRead, numBytesReaded, millisecTimeout );
       }

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        return CSocketImplBase::write(buf, numBytesToWrite, numBytesWritten );
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        return CSocketImplBase::writeTimeout(buf, numBytesToWrite, numBytesWritten, millisecTimeout );
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }


}; // CTcpClientSocket




struct CUdpClientSocket : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_IO_IIOSTREAM
                    , public INTERFACE_CLI_IO_IISTREAM
                    , public INTERFACE_CLI_IO_IOSTREAM
                    , public CSocketImplBase
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CUdpClientSocket()
       : base_impl(DEF_MODULE)
       , CSocketImplBase()
       {
       }

    void closeCurrentHandle()
       {
        #if defined(WIN32) || defined(_WIN32)
        if (hSock!=INVALID_SYS_SOCKET_HANDLE)  ::closesocket(hSock);
        #else
        if (hSock!=INVALID_SYS_SOCKET_HANDLE)  ::close(hSock);
        #endif
        hSock = INVALID_SYS_SOCKET_HANDLE;
       }

    ~CUdpClientSocket()
       {
        //closeSocket
        //closeCurrentHandle();
        closeStream();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CUdpClientSocketImpl, INTERFACE_CLI_IO_IIOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INET_ISOCKET   )
    CLI_END_INTERFACE_MAP(CUdpClientSocketImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    CSOCKETIMPL_IMPLEMENT_STREAMNAME_PROPERTY()

    CLIMETHOD(closeStream) (THIS)
       {
        closeSocket();
        return EC_OK;
       }

    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        return handleSet( (SYS_SOCKET_HANDLE)handle );
       }

    virtual RCODE internalOpenParsedOpts( const ::std::wstring &host
                                        , const ::std::wstring &port
                                        , const ::std::wstring &path
                                        , const ::std::wstring &options
                                        , const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                        , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                        )
        {
         RCODE lastConnErr = 0;
         CLI_TRY{

                 ::std::wstring hostPortSrc;
                   {
                    ::cli::inet::CIpAddress ipAddrTmp;
                    if (::cli::inet::convertIpAddress(host, ipAddrTmp) && ipAddrTmp.addrType==AF_INET6)
                       hostPortSrc = ::std::wstring(1,L'[') + host + ::std::wstring(L"]:") + port;
                    else
                       hostPortSrc = host + ::std::wstring(1, L':') + port;
                   }

                 ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");

                 STRUCT_CLI_INET_IPADDRESS tmpIpAddr;
                 bool plainIp = true;
                 if (resolver.stringToIp(host,tmpIpAddr))
                    plainIp = false;


                 /*
                 STRUCT_CLI_INET_IPADDRESS tmpIpAddr;
                 bool plainIp = true;
                 if (resolver.ipToString(tmpIpAddr, host))
                    plainIp = false;
                 */
                 //::cli::io::CiConnectingStateWatcher watcher(pConWatcher, true /*noAddRef*/);
                 ::cli::io::CiConnectingStateWatcher watcher(pConWatcher);

                 //RCODE watcher.watch( conState , const ::std::wstring    &infoStr )
                 if (!!watcher && !plainIp )
                    watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING, host);
                    //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING, hostPortSrc);

                 // �������� ����� �����
                 RCODE res = resolver.getServiceInfoStr2( port, L"udp" );
                 if (res && !!watcher && !plainIp )
                    {
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, port);
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , port);
                     //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, hostPortSrc);
                     //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , hostPortSrc);
                     //pConWatcher->release();
                    }
                 CLI_THROW_IF_NOK(res);

                 // �������� ������ �����
                 res = resolver.getHostInfoByName( host, AF_UNSPEC );
                 if (res && !!watcher /*  && !plainIp */ )
                    {
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, host);
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , host);
                     //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, hostPortSrc);
                     //watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , hostPortSrc);
                     //pConWatcher->release();
                    }
                 CLI_THROW_IF_NOK(res);

                 ::std::wstring canonicalName;
                 resolver.canonicalNameGet( canonicalName );
                 if (!!watcher && !plainIp )
                    {
                     if (!canonicalName.empty())
                        watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING, canonicalName );
                     else
                        watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING, host );
                    }

                 //SIZE_T addrListSize = 0;
                 //resolver.addrListSize(&addrListSize);

                 STRUCT_CLI_INET_SOCKETADDRESS sa;
                 res = resolver.addrListGetSocketAddress( sa, 0 );
                 if (res && !!watcher /*  && !plainIp */ )
                    {
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, host);
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED  , host);
                    }
                 CLI_THROW_IF_NOK(res);
                 ::std::wstring hostPortResolved;

                 if (!!watcher)
                    {
                     ::std::wstring portStr;
                     ::cli::inet::portToWideString( sa.port, portStr );

                     ::cli::inet::CIpAddress ipAddrTmp;
                     ipAddrTmp.fromPlain(&sa);
                     if (ipAddrTmp.addrType==AF_INET6)
                        hostPortResolved = ::std::wstring(1,L'[') + ipAddrTmp.toWideString() + ::std::wstring(L"]:") + portStr;
                     else
                        hostPortResolved = ipAddrTmp.toWideString() + ::std::wstring(1,L':') + portStr;

                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_BEGINCONNECTING, hostPortResolved );
                    }

                 res = createSocketEx( sa.af, CLI_INET_SOCKETTYPE_STREAM, CLI_INET_PROTOCOLTYPE_TCP, TRUE );
                 if (res && !!watcher)
                    {
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING, hostPortResolved );
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED   , hostPortSrc);
                     //pConWatcher->release();
                    }
                 CLI_THROW_IF_NOK(res);

                 //res =  /* newSock. */ bindSocket( bindToAddr );
                 //if (res && !!watcher)
                 //   {
                 //    watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING, hostPortResolved );
                 //    watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATEFAILED   , hostPortSrc);
                 //    //pConWatcher->release();
                 //   }
                 //CLI_THROW_IF_NOK(res);

                 res = connectSocket( &sa );
                 if (res && res!=EC_IN_PROGRESS)
                    {
                     if (!!watcher)
                        {
                         watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILCONNECTING, hostPortResolved );
                         //watcher.watch( CLI_IO_IOCONNECTINGSTATE_STATEFAILED   , hostPortResolved );
                        }
                     CLI_THROW(res);
                    }

                 if (!!watcher)
                    {
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSCONNECTING, hostPortResolved );
                     watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_STATECONNECTED   , hostPortSrc );
                     //pConWatcher->release();
                    }
                 /*
                 res = newSock.createSocket( bindToAddr.af, CLI_INET_SOCKETTYPE_DGRAM
                                           , CLI_INET_PROTOCOLTYPE_UDP);
                 if (res) return res;

                 res = newSock.bindSocket( bindToAddr );
                 if (res) return res;

                 *pNewSock = newSock.getIfPtr();
                 (*pNewSock)->addRef();
                 */

                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return lastConnErr;
        }

    inline
    RCODE internalOpen( const ::std::wstring &streamName
                      , const ::std::wstring &host
                      , const ::std::wstring &port
                      , const ::std::wstring &path
                      , const ::std::wstring &options
                      , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                      )
       {
        streamNameInfo.assign(streamName);

        ::std::map< ::std::wstring, ::std::wstring > optionsMap;

        ::marty::confUtils::splitOptionsString( optionsMap, options
                                              //, OPT_SEP_CHAR, OPT_EQU_CHAR, OPT_QUOT_CHAR
                                              , L',', L'=', L'\''
                                              , ::marty::confUtils::IsSpacePred()
                                              );

        return internalOpenParsedOpts( host, port, path, options, optionsMap, pConWatcher );
       }

    CLIMETHOD(open) (THIS_ const CLISTR*     streamName
                         , const CLISTR*     host
                         , const CLISTR*     port
                         , const CLISTR*     path
                         , const CLISTR*     options
                         , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                    )
       {
        //return EC_NOT_IMPLEMENTED;
        return internalOpen( stdstr(streamName), stdstr(host), stdstr(port), stdstr(path), stdstr(options), pConWatcher );
       }

    CLIMETHOD(openPStr) (THIS_ CLIPSTR           streamName
                             , CLIPSTR           host
                             , CLIPSTR           port
                             , CLIPSTR           path
                             , CLIPSTR           options
                             , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                        )
       {
        //return EC_NOT_IMPLEMENTED;
        return internalOpen( stdstr(streamName), stdstr(host), stdstr(port), stdstr(path), stdstr(options), pConWatcher );
       }

    CLIMETHOD_(DWORD, getStreamType) (THIS)
       {
        return CLI_IO_IOSTREAMTYPE_UDP;
       }


    RCODE udpRead(THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_IOSTREAM_NOT_WRITEABLE;

        #if defined(WIN32) || defined(_WIN32)
        int recvRes = recv( hSock, (char*)buf, (int)numBytesToRead, 0);
        #else
        int recvRes = recv( hSock,        buf,      numBytesToRead, 0);
        #endif

        #if defined(WIN32) || defined(_WIN32)
            if (recvRes==SOCKET_ERROR)
        #else
            if (recvRes==-1)
        #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            return CLI_SET_WIN_ERROR_INFO_ARGS(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
            #else
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
            #endif
           }

        if (numBytesReaded) *numBytesReaded = (SIZE_T)recvRes;
        return EC_OK;
       }

    CLIMETHOD(udpWrite) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {

        if (hSock==INVALID_SYS_SOCKET_HANDLE) return EC_IOSTREAM_NOT_WRITEABLE;

        #if defined(WIN32) || defined(_WIN32)
        int sndRes = send( hSock, (char*)buf, (int)numBytesToWrite, 0 );
        #else
        int sndRes = send( hSock,        buf,      numBytesToWrite, 0 );
        #endif

        #if defined(WIN32) || defined(_WIN32)
        if (sndRes==SOCKET_ERROR)
           {
            if (WSAGetLastError()==WSAEWOULDBLOCK)
               { // ��� ���������, ������ ��� ����������� ��������� ������, ���� ��������� �����
                if (numBytesWritten) *numBytesWritten = 0;
                return EC_OK;
               }
            // ��������� �����-�� ����
            return CLI_SET_WIN_ERROR_INFO_ARGS(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        #else
        if (sndRes==-1)
           {
            if (errno==EAGAIN || errno==EWOULDBLOCK)
               {
               if (numBytesWritten) *numBytesWritten = 0;
                return EC_OK;
               }
            return CLI_SET_POSIX_ERROR_INFO_ARGS( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
           }
        #endif

        // ��� ���������,���-�� �����������
        if (numBytesWritten) *numBytesWritten = (SIZE_T)sndRes;

        return EC_OK;
       }


    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        return udpRead( buf, numBytesToRead, numBytesReaded );
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T   numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*  numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T   millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        RCODE res = udpRead( buf, numBytesToRead, numBytesReaded );
        if (res) return res;
        if ((numBytesReaded && *numBytesReaded) || !millisecTimeout) return res;
        cli::sched::sleepMs((unsigned)millisecTimeout);
        return udpRead( buf, numBytesToRead, numBytesReaded );
       }

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        return udpWrite(buf, numBytesToWrite, numBytesWritten );
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        RCODE res = udpWrite( buf, numBytesToWrite, numBytesWritten );
        if (res) return res;
        if ((numBytesWritten && *numBytesWritten) || !millisecTimeout) return res;
        cli::sched::sleepMs((unsigned)millisecTimeout);
        return udpWrite( buf, numBytesToWrite, numBytesWritten );
       }

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
       {
        return EC_NOT_SUPPORTED;
       }


}; // CUdpClientSocket



}; // namespace impl
}; // namespace io



namespace inet
{
namespace impl
{


struct CTcpServerImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_INET_ITCPSERVER
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CTcpServerImpl()
       : base_impl(DEF_MODULE)
       {
        ::cli::inet::initSocketsAPI();
       }


    ~CTcpServerImpl()
       {
        //closeStream();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CTcpServerImpl, INTERFACE_CLI_INET_ITCPSERVER)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INET_ITCPSERVER )
    CLI_END_INTERFACE_MAP(CTcpServerImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    /*
    CLIMETHOD(closeStream) (THIS)
       {
        closeSocket();
        return EC_OK;
       }
    */
    CLIMETHOD(createServerSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */
                                       , INTERFACE_CLI_INET_ISOCKET**    pNewSock /* [out] ::cli::inet::iSocket* newSock  */
                                  )
        {
         if (!sa || !pNewSock) return EC_INVALID_PARAM;

         CLI_TRY{
                 ::cli::inet::CiSocket newSock( new ::cli::io::impl::CTcpClientSocket(), true /*noAddRef*/);
                 //INTERFACE_CLI_INET_ISOCKET* newSock = new CTcpClientSocket();
                 RCODE res = newSock.createSocketEx( sa->af, CLI_INET_SOCKETTYPE_STREAM
                                                   , CLI_INET_PROTOCOLTYPE_TCP, TRUE /*bNonBlock*/ );
                 if (res) return res;

                 res = newSock.reuseAddrSet(TRUE);
                 if (res) return res;

                 res = newSock.bindSocket(*sa);
                 if (res) return res;

                 res = newSock.listenSocket( );
                 if (res) return res;

                 *pNewSock = newSock.getIfPtr();
                 (*pNewSock)->addRef();
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_OK;
        }

    CLIMETHOD(createServerSocketStr) (THIS_ const CLISTR*     addr
                                          , const CLISTR*     port
                                          , INTERFACE_CLI_INET_ISOCKET**    pNewSock /* [out] ::cli::inet::iSocket* newSock  */
                                     )
        {
         if (!addr || !port || !pNewSock) return EC_INVALID_PARAM;

         CLI_TRY{
                 STRUCT_CLI_INET_SOCKETADDRESS bindToAddr;

                 ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                 ::std::wstring protocolStr(L"tcp");
                 CCliStr tmp_protocol; CCliStr_lightCopyTo( tmp_protocol, protocolStr );

                 RCODE res = resolver.getIfPtr()->getServiceInfoStr2( port, &tmp_protocol );
                 CLI_THROW_IF_NOK(res);

                 UINT p = 0;
                 resolver.portGet(&p);

                 ::cli::inet::CIpAddress ipAddr;

                 ::std::wstring strAddr = stdstr(addr);
                 if (strAddr==L"*" || strAddr==L"*4" || strAddr==L"any" || strAddr==L"ANY" || strAddr==L"any4" || strAddr==L"ANY4")
                    {
                     ipAddr.makeAddrAny( p, AF_INET );
                     if (!ipAddr.toPlain(&bindToAddr))
                        CLI_THROW(EC_RESOLV_INVALID_ADDR);
                    }
                 else if (strAddr==L"*6" || strAddr==L"any6" || strAddr==L"ANY6")
                    {
                     ipAddr.makeAddrAny( p, AF_INET6 );
                     if (!ipAddr.toPlain(&bindToAddr))
                        CLI_THROW(EC_RESOLV_INVALID_ADDR);
                    }
                 else
                    {
                     res = resolver.getIfPtr()->stringToIp( addr, (STRUCT_CLI_INET_IPADDRESS*)&bindToAddr);
                     CLI_THROW_IF_NOK(res);
                     bindToAddr.port = p;
                    }


                 ::cli::inet::CiSocket newSock( new ::cli::io::impl::CTcpClientSocket(), true /*noAddRef*/);
                 //INTERFACE_CLI_INET_ISOCKET* newSock = new CTcpClientSocket();
                 //RCODE
                 res = newSock.createSocketEx( bindToAddr.af, CLI_INET_SOCKETTYPE_STREAM
                                             , CLI_INET_PROTOCOLTYPE_TCP, TRUE /*bNonBlock*/ );
                 if (res) return res;

                 /*
                 ::std::wstring protocolStr(L"tcp")
                 CCliStr tmp_protocol; CCliStr_lightCopyTo( tmp_protocol, protocolStr );

                 res = newSock.bindSocketStr( addr, port, &tmp_protocol );
                 */
                 res = newSock.bindSocket( bindToAddr );
                 if (res) return res;

                 res = newSock.listenSocket( );
                 if (res) return res;

                 *pNewSock = newSock.getIfPtr();
                 (*pNewSock)->addRef();
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_OK;
        }

    CLIMETHOD(acceptConnections) (THIS_ INTERFACE_CLI_INET_ISOCKET**    serverSockets /* [in,flat] ::cli::inet::iSocket*  serverSockets[]  */
                                      , SIZE_T    numSockets /* [in] size_t  numSockets  */
                                      , INTERFACE_CLI_IO_IIOSTREAM**    acceptedStreams /* [out,flat] ::cli::io::iIOStream* acceptedStreams[]  */
                                      , SIZE_T*    acceptedStreamsCount /* [in,out] size_t acceptedStreamsCount  */
                                      , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                 )
        {
         if (!serverSockets || !acceptedStreams || !acceptedStreamsCount)
            return EC_INVALID_PARAM;

         if (*acceptedStreamsCount < numSockets)
            return EC_INVALID_PARAM;


         struct timeval Timeout;
         Timeout.tv_usec = (unsigned)(millisecTimeout%1000)*1000;  // � ������������
         Timeout.tv_sec  = (unsigned)millisecTimeout/1000;  // �������

         fd_set readFs;
         FD_ZERO( &readFs );

         SIZE_T maxSelectSockets = numSockets>FD_SETSIZE ? FD_SETSIZE : numSockets;
         SYS_SOCKET_HANDLE *pHandles = (SYS_SOCKET_HANDLE*)_alloca( sizeof(SYS_SOCKET_HANDLE)*maxSelectSockets );

         SIZE_T i = 0;
         #if !defined(WIN32) && !defined(_WIN32)
         int maxSocket = 0;
         #endif
         for(; i!=maxSelectSockets; ++i)
            {
             pHandles[i] = 0;
             if (serverSockets[i])
                {
                 if (!serverSockets[i]->handleGet( &pHandles[i] ))
                    {
                     FD_SET( pHandles[i], &readFs );
                     #if !defined(WIN32) && !defined(_WIN32)
                     if (pHandles[i] > maxSocket) maxSocket = pHandles[i];
                     #endif
                    }
                }
            }


        #if defined(WIN32) || defined(_WIN32)
        int selectRes = select(0/*ign*/, &readFs, NULL, NULL, &Timeout );
        #else
        int selectRes = select(maxSocket+1 , &readFs, NULL, NULL, &Timeout );
        #endif

        #if defined(WIN32) || defined(_WIN32)
            if (selectRes==SOCKET_ERROR)
        #else
            #ifdef ERESTARTNOHAND
            if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
            #else
            if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
            #endif
        #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            return WIN2RC(WSAGetLastError()); // CLI_SET_WIN_ERROR_INFO(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
            #else
            return POSIX2RC(errno); //CLI_SET_POSIX_ERROR_INFO( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
            #endif
           }

         *acceptedStreamsCount = 0;

         if (selectRes==-1 || selectRes==0 )
            {
             // �������� �������� ��������,
             // ��� ����� ������� ��� ���������� �� � ������ ������������, ������� ��� ������
             // ����������, ��� �� ������ ���������� �� �������
             return EC_OK;
            }

         for( i=0 ; i!=maxSelectSockets; ++i)
            {
             if (!pHandles[i]) continue;

             if (!FD_ISSET( pHandles[i], &readFs )) continue;

             SYS_SOCKET_HANDLE             hAccepted;
             STRUCT_CLI_INET_SOCKETADDRESS peerAddr;

             if (serverSockets[i]->acceptSocketConnection( &hAccepted, &peerAddr, 0 )) continue;

             try{
                 ::cli::io::impl::CTcpClientSocket *pClient = new ::cli::io::impl::CTcpClientSocket();
                 pClient->hSock      = hAccepted;
                 pClient->sockType   = CLI_INET_SOCKETTYPE_STREAM;
                 pClient->streamNameInfo = L"client connection";  //UNDONE: add client address string
                 pClient->localAddr = peerAddr; //UNDONE: get local addr of socket and assign it to pClient->localAddr
                 pClient->peerAddr  = peerAddr;
                 SIZE_T &acceptedCount = *acceptedStreamsCount;
                 acceptedStreams[acceptedCount++] = pClient;
                }
             catch(...)
                {
                 #if defined(WIN32) || defined(_WIN32)
                 ::closesocket(hAccepted);
                 #else
                 ::close(hAccepted);
                 #endif

                }
            }

         return EC_OK;
        }




/*
        #if defined(WIN32) || defined(_WIN32)
        int localAddrLen = 0;
        #else
        socklen_t localAddrLen = 0;
        #endif

        if (peerAddr.af==AF_INET)
           {
            sockaddr_in addr;
            localAddrLen = sizeof(addr);
            int gsnRes = getsockname( hSock, (struct sockaddr*)&addr, &localAddrLen);
            #if defined(WIN32) || defined(_WIN32)
            if (gsnRes!=SOCKET_ERROR)
            #else
            if (gsnRes!=-1)
            #endif
               {
                ::cli::inet::CIpAddress tmp;
                if (tmp.fromSockAddr(addr))
                   tmp.toPlain(&localAddr);
               }
           }
        else
           {
            sockaddr_in6 addr;
            localAddrLen = sizeof(addr);
            int gsnRes = getsockname( hSock, (struct sockaddr*)&addr, &localAddrLen);
            #if defined(WIN32) || defined(_WIN32)
            if (gsnRes!=SOCKET_ERROR)
            #else
            if (gsnRes!=-1)
            #endif
               {
                ::cli::inet::CIpAddress tmp;
                if (tmp.fromSockAddr(addr))
                   tmp.toPlain(&localAddr);
               }
           }

*/

}; // struct CTcpServerImpl



struct CSocketImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                   , public ::cli::io::impl::CSocketImplBase
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CSocketImpl()
       : base_impl(DEF_MODULE)
       {
       }


    ~CSocketImpl()
       {
        closeStream();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CSocketImpl, INTERFACE_CLI_INET_ISOCKET)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INET_ISOCKET )
    CLI_END_INTERFACE_MAP(CSocketImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    //CSOCKETIMPL_IMPLEMENT_STREAMNAME_PROPERTY()


}; // CSocketImpl




struct CUdpServerImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_INET_IUDPSERVER
{


    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    CUdpServerImpl()
       : base_impl(DEF_MODULE)
       {
        ::cli::inet::initSocketsAPI();
       }


    ~CUdpServerImpl()
       {
        //closeStream();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CUdpServerImpl, INTERFACE_CLI_INET_IUDPSERVER)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INET_IUDPSERVER )
    CLI_END_INTERFACE_MAP(CUdpServerImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    CLIMETHOD(createServerSocketEx) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    bindToSockAddr /* [in,ref] ::cli::inet::SocketAddress  bindToSockAddr  */
                                         , ENUM_CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS    flags /* [in] ::cli::inet::EUdpServerCreateServerSocketFlags  flags  */
                                         , INTERFACE_CLI_INET_ISOCKET**    pNewSock /* [out] ::cli::inet::iSocket* newSock  */
                                    )
       {
         if (!bindToSockAddr || !pNewSock) return EC_INVALID_PARAM;

         CLI_TRY{
                 ::cli::inet::CiSocket newSock( new CSocketImpl(), true /*noAddRef*/);
                 //INTERFACE_CLI_INET_ISOCKET* newSock = new CTcpClientSocket();
                 RCODE res = newSock.createSocketEx( bindToSockAddr->af, CLI_INET_SOCKETTYPE_DGRAM
                                                   , CLI_INET_PROTOCOLTYPE_UDP, TRUE /*bNonBlock*/ );
                 if (res) return res;

                 if (flags&CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS_REUSEADDR)
                    {
                     #if defined(DEBUG) || defined(_DEBUG)
                     ::cli::format::cli_log::message("createServerSocketEx, reuseAddrSet, reusePortSet" );
                     #endif
            
                     newSock.reuseAddrSet(TRUE);
                     newSock.reusePortSet(TRUE);
                    }

                 #if defined(DEBUG) || defined(_DEBUG)
                 ::cli::format::cli_log::message("createServerSocketEx, bindSocket" );
                 #endif

                 res = newSock.bindSocket(*bindToSockAddr);
                 if (res) 
                    {
                     #if defined(DEBUG) || defined(_DEBUG)
                     ::cli::format::cli_log::message("createServerSocketEx, bindSocket failed, error: %1!08X!", cli::arglist(res) );
                     #endif
                     return res;
                    }

                 *pNewSock = newSock.getIfPtr();
                 (*pNewSock)->addRef();
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_OK;
       }

    CLIMETHOD(createServerSocketExStr) (THIS_ const CLISTR*     bindToAddrStr
                                            , const CLISTR*     bindToPortStr
                                            , ENUM_CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS    flags /* [in] ::cli::inet::EUdpServerCreateServerSocketFlags  flags  */
                                            , INTERFACE_CLI_INET_ISOCKET**    pNewSock /* [out] ::cli::inet::iSocket* newSock  */
                                       )
       {
        if (!bindToAddrStr || !bindToPortStr || !pNewSock) return EC_INVALID_PARAM;

        CLI_TRY{
                STRUCT_CLI_INET_SOCKETADDRESS bindToAddr;

                ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                ::std::wstring protocolStr(L"udp");
                CCliStr tmp_protocol; CCliStr_lightCopyTo( tmp_protocol, protocolStr );

                RCODE res = resolver.getIfPtr()->getServiceInfoStr2( bindToPortStr, &tmp_protocol );
                CLI_THROW_IF_NOK(res);

                UINT p = 0;
                resolver.portGet(&p);

                ::cli::inet::CIpAddress ipAddr;

                ::std::wstring strAddr = stdstr(bindToAddrStr);
                if (strAddr==L"*" || strAddr==L"*4" || strAddr==L"any" || strAddr==L"ANY" || strAddr==L"any4" || strAddr==L"ANY4")
                   {
                    ipAddr.makeAddrAny( p, AF_INET );
                    if (!ipAddr.toPlain(&bindToAddr))
                       CLI_THROW(EC_RESOLV_INVALID_ADDR);
                   }
                else if (strAddr==L"*6" || strAddr==L"any6" || strAddr==L"ANY6")
                   {
                    ipAddr.makeAddrAny( p, AF_INET6 );
                    if (!ipAddr.toPlain(&bindToAddr))
                       CLI_THROW(EC_RESOLV_INVALID_ADDR);
                   }
                else
                   {
                    res = resolver.getIfPtr()->stringToIp( bindToAddrStr, (STRUCT_CLI_INET_IPADDRESS*)&bindToAddr);
                    CLI_THROW_IF_NOK(res);
                    bindToAddr.port = p;
                   }


                ::cli::inet::CiSocket newSock( new CSocketImpl(), true /*noAddRef*/);
                //INTERFACE_CLI_INET_ISOCKET* newSock = new CTcpClientSocket();
                //RCODE
                // res = newSock.createSocketEx( bindToAddr.af, CLI_INET_SOCKETTYPE_DGRAM
                //                             , CLI_INET_PROTOCOLTYPE_UDP, TRUE /*bNonBlock*/ );
                res = newSock.createSocket( bindToAddr.af, CLI_INET_SOCKETTYPE_DGRAM
                                          , CLI_INET_PROTOCOLTYPE_UDP);
                if (res) return res;

                if (flags&CLI_INET_EUDPSERVERCREATESERVERSOCKETFLAGS_REUSEADDR)
                   {
                    newSock.reuseAddrSet(TRUE);
                    newSock.reusePortSet(TRUE);
                   }

                res = newSock.bindSocket( bindToAddr );
                if (res) return res;

                *pNewSock = newSock.getIfPtr();
                (*pNewSock)->addRef();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(createServerSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    bindToSockAddr /* [in,ref] ::cli::inet::SocketAddress  bindToSockAddr  */
                                       , INTERFACE_CLI_INET_ISOCKET**    pNewSock /* [out] ::cli::inet::iSocket* newSock  */
                                  )
       {
        return createServerSocketEx( bindToSockAddr, 0, pNewSock );
       }

    CLIMETHOD(createServerSocketStr) (THIS_ const CLISTR*     bindToAddrStr
                                          , const CLISTR*     bindToPortStr
                                          , INTERFACE_CLI_INET_ISOCKET**    pNewSock /* [out] ::cli::inet::iSocket* newSock  */
                                     )
       {
        return createServerSocketExStr( bindToAddrStr, bindToPortStr, 0, pNewSock );
       }

    CLIMETHOD(createUdpClientSocket) (THIS_ UINT    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                          , INTERFACE_CLI_INET_ISOCKET**    pNewSock /* [out] ::cli::inet::iSocket* newSock  */
                                     )
       {
        if ((af!=AF_INET && af!=AF_INET6) || !pNewSock) return EC_INVALID_PARAM;

        CLI_TRY{
                ::cli::inet::CiSocket newSock( new CSocketImpl(), true /*noAddRef*/);
                //INTERFACE_CLI_INET_ISOCKET* newSock = new CTcpClientSocket();
                // RCODE res = newSock.createSocketEx( af, CLI_INET_SOCKETTYPE_DGRAM
                //                                   , CLI_INET_PROTOCOLTYPE_UDP, TRUE /*bNonBlock*/ );
                RCODE res = newSock.createSocket( af, CLI_INET_SOCKETTYPE_DGRAM
                                                , CLI_INET_PROTOCOLTYPE_UDP);
                if (res) return res;

                *pNewSock = newSock.getIfPtr();
                (*pNewSock)->addRef();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(receiveFrom) (THIS_ INTERFACE_CLI_INET_ISOCKET**    sockets /* [in,flat] ::cli::inet::iSocket*  sockets[]  */
                                , SIZE_T    numSockets /* [in] size_t  numSockets  */
                                , SIZE_T    itemSize /* [in] size_t  itemSize  */
                                , STRUCT_CLI_INET_CUDPRECVDATA*    received /* [out,flat] ::cli::inet::CUdpRecvData received[]  */
                                , SIZE_T*    receivedCount /* [in,out] size_t receivedCount  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
         if (!sockets || !received || !receivedCount)
            return EC_INVALID_PARAM;

         if (*receivedCount < numSockets)
            return EC_INVALID_PARAM;

         struct timeval Timeout;
         Timeout.tv_usec = (unsigned)(millisecTimeout%1000)*1000;  // � ������������
         Timeout.tv_sec  = (unsigned)millisecTimeout/1000;  // �������

         fd_set readFs;
         FD_ZERO( &readFs );

         SIZE_T maxSelectSockets = numSockets>FD_SETSIZE ? FD_SETSIZE : numSockets;
         SYS_SOCKET_HANDLE *pHandles = (SYS_SOCKET_HANDLE*)_alloca( sizeof(SYS_SOCKET_HANDLE)*maxSelectSockets );

         SIZE_T i = 0;
         #if !defined(WIN32) && !defined(_WIN32)
         int maxSocket = 0;
         #endif
         for(; i!=maxSelectSockets; ++i)
            {
             pHandles[i] = 0;
             if (sockets[i])
                {
                 if (!sockets[i]->handleGet( &pHandles[i] ))
                    {
                     FD_SET( pHandles[i], &readFs );
                     #if !defined(WIN32) && !defined(_WIN32)
                     if (pHandles[i] > maxSocket) maxSocket = pHandles[i];
                     #endif
                    }
                }
            }


        #if defined(WIN32) || defined(_WIN32)
        int selectRes = select(0/*ign*/, &readFs, NULL, NULL, &Timeout );
        #else
        int selectRes = select(maxSocket+1 , &readFs, NULL, NULL, &Timeout );
        #endif

        #if defined(WIN32) || defined(_WIN32)
            if (selectRes==SOCKET_ERROR)
        #else
            #ifdef ERESTARTNOHAND
            if (selectRes==-1 && errno!=EINTR && errno!=ERESTARTNOHAND) // ������ � �� ������
            #else
            if (selectRes==-1 && errno!=EINTR) // ������ � �� ������
            #endif
        #endif
           {
            #if defined(WIN32) || defined(_WIN32)
            return WIN2RC(WSAGetLastError()); // CLI_SET_WIN_ERROR_INFO(  WSAGetLastError(), 0, 0, (::cli::format::arg(streamNameInfo)) );
            #else
            return POSIX2RC(errno); //CLI_SET_POSIX_ERROR_INFO( errno, 0, 0, (::cli::format::arg(streamNameInfo)) );
            #endif
           }

         SIZE_T &cnt = *receivedCount;
         //*receivedCount = 0;
         cnt = 0;

         if (selectRes==-1 || selectRes==0 )
            {
             // �������� �������� ��������,
             // ��� ����� ������� ��� ���������� �� � ������ ������������, ������� ��� ������
             // ����������, ��� �� ������ ���������� �� �������
             return EC_OK;
            }

         SIZE_T recvDataHdrSize = sizeof(received->socket) + sizeof(received->receivedBytes) + sizeof(received->localAddr) + sizeof(received->recevedFrom);
         BYTE *pBase = (BYTE*)received;

         for( i=0 ; i!=maxSelectSockets; ++i)
            {
             if (!pHandles[i]) continue;

             if (!FD_ISSET( pHandles[i], &readFs )) continue;

             STRUCT_CLI_INET_CUDPRECVDATA *pReceivedItem = (STRUCT_CLI_INET_CUDPRECVDATA*)(pBase + (itemSize*i));

             pReceivedItem->socket = sockets[i];

             RCODE recvRes = sockets[i]->recvFrom( pReceivedItem->dataBuf
                                                 , itemSize - recvDataHdrSize
                                                 , &(pReceivedItem->receivedBytes)
                                                 , &(pReceivedItem->localAddr)
                                                 , &(pReceivedItem->recevedFrom)
                                                 );
             if (recvRes) continue;
             cnt++;
            }

         return EC_OK;
       }



/*
        #if defined(WIN32) || defined(_WIN32)
        int localAddrLen = 0;
        #else
        socklen_t localAddrLen = 0;
        #endif

        if (peerAddr.af==AF_INET)
           {
            sockaddr_in addr;
            localAddrLen = sizeof(addr);
            int gsnRes = getsockname( hSock, (struct sockaddr*)&addr, &localAddrLen);
            #if defined(WIN32) || defined(_WIN32)
            if (gsnRes!=SOCKET_ERROR)
            #else
            if (gsnRes!=-1)
            #endif
               {
                ::cli::inet::CIpAddress tmp;
                if (tmp.fromSockAddr(addr))
                   tmp.toPlain(&localAddr);
               }
           }
        else
           {
            sockaddr_in6 addr;
            localAddrLen = sizeof(addr);
            int gsnRes = getsockname( hSock, (struct sockaddr*)&addr, &localAddrLen);
            #if defined(WIN32) || defined(_WIN32)
            if (gsnRes!=SOCKET_ERROR)
            #else
            if (gsnRes!=-1)
            #endif
               {
                ::cli::inet::CIpAddress tmp;
                if (tmp.fromSockAddr(addr))
                   tmp.toPlain(&localAddr);
               }
           }

*/

}; // struct CUdpServerImpl










}; // namespace impl
}; // namespace inet
}; // namespace cli


#endif /* SOCKIMPL_H */

