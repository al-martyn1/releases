#ifndef CORE_IO_MOXA_NPORTIMPL_H
#define CORE_IO_MOXA_NPORTIMPL_H

#ifndef CLI_INET_ISOCK_H
    #include <cli/inet/isock.h>
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#ifndef CLI_IO_MOXA_MOXA_H
    #include <cli/io/moxa/moxa.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif

#ifndef CLI_INET_ISOCK_H
    #include <cli/inet/isock.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#include "../iosImplBase.h"
#include "../serialImpl.h"

/*
1.     ������ � ������ RealCom:
a.     ����� �������� � ��������� ����������: 
       COM1 - ���� ������ 950, ���� �������� 966, 
       COM2 - ���� ������ 951, ���� �������� 967.
b.     �������� ����������� � ����������� ����, ��� ��������:
# ����� �������� 19200, 8, ���, 1, ���
1) 2c 0d 06 03 01 01 00 00 00 00 56 41 44 49 4d
2) 30 01 10
3) 18 02 11 13
4) 10 02 07 03
3) 18 02 11 13
���
# ����� �������� 9600, 8, ���, 1, ����������
1) 2c 0d 07 13 01 01 01 01 00 00 56 41 44 49 4d
2) 30 01 10
3) 18 02 11 13
4) 10 02 06 13
4) 10 02 06 03
3) 18 02 11 13
5) 11 04 01 01 00 00
2) 30 01 00
6) 12 02 01 01
- ��� 1 ���� ������ ������������ ������, 2 ���� ������ ������ ������, �����: 
����������� 1) 3 - 10 ���������� ��������� ����� (3 - ��������, 4 - ���� ������, ���� ����, 
               ��������, 5 - 10 ���������� ���������), 
               ����� ��� ������������� �������; ����������� 
            2) ������ � ����� �������� ��������; ����������� 
            3) �������� ���������� ����� � ����������; ����������� 
            4) �������� �������� � ���� �������� �����; ����������� 
            5) ���������� ���������; ����������� 
            6) ��������� � ���������� ����������.
c.     ����� �������� ������.
*/



// Reply result flags
#define RRF_CMD_PORT_INIT       0x00000001


#ifndef CLI_IO_MOXA_MOXAASPPDEFS_H
    #include <cli/io/moxa/moxaAsppDefs.h>
#endif


namespace cli  {
namespace moxa {
namespace impl {


struct CMoxaNameCacheItem
{
    STRUCT_CLI_INET_IPADDRESS ipAddr;
    TICK_T                    lastUpdate;
};

static ::std::map< ::std::wstring, CMoxaNameCacheItem >  moxaNameCache;
static ::cli::CCriticalSection                           moxaNameCacheCs;




struct CNPortImpl : public ::cli::io::impl::CIosImplBase< L',', L'=', L'\'' >
                  , public ::cli::io::impl::CSerialHelperImplBase< L',', L'=', L'\'' >
                  , public INTERFACE_CLI_IO_ISERIAL
                  , public INTERFACE_CLI_INET_ISOCKET
{
      
    typedef ::cli::io::impl::CIosImplBase< L',', L'=', L'\'' >            ios_impl_base_class;
    typedef ::cli::io::impl::CSerialHelperImplBase< L',', L'=', L'\'' >   serial_helper_impl_base_class;


    STRUCT_CLI_IO_SERIAL_COPTIONS    savedOptions;
    INTERFACE_CLI_INET_ISOCKET      *pDataSocket;
    INTERFACE_CLI_INET_ISOCKET      *pControlSocket;
    ::std::string                    clientHostName;

    CNPortImpl() 
       : ios_impl_base_class()
       , serial_helper_impl_base_class()
       , savedOptions()
       , pDataSocket(0)
       , pControlSocket()
       , clientHostName()
       {
        savedOptions.baudRate = 0;
        savedOptions.parity   = CLI_IO_SERIAL_PARITY_DONTTOUCH;
        savedOptions.dataBits = CLI_IO_SERIAL_DATABITS_DONTTOUCH;
        savedOptions.stopBits = CLI_IO_SERIAL_STOPBITS_DONTTOUCH;
       }

    ~CNPortImpl()
       {
        //if (pDataSocket) pDataSocket->release();
        //if (pControlSocket) pControlSocket->release();
        closeStream();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CNPortImpl, INTERFACE_CLI_IO_IIOSTREAM)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IIOSTREAM )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IISTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_IOSTREAM  )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISERIAL   )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IO_ISERIALHELPER )
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_INET_ISOCKET )
    CLI_END_INTERFACE_MAP(CNPortImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

   CLIMETHOD(closeStream) (THIS)
      {
       if (pDataSocket) 
          {
           pDataSocket->release();
           pDataSocket = 0;
          }
       if (pControlSocket) 
          {
           pControlSocket->release();
           pControlSocket = 0;
          }
       return EC_OK;
      }


    CLIMETHOD(initStreamWithHandle) (THIS_ SYS_GENERIC_IO_HANDLE    handle /* [in] sys_generic_io_handle  handle  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    /* interface ::cli::inet::iSocket methods */
    // all iSocket methods delegated to data socket

    CLIMETHOD(handleGet) (THIS_ SYS_SOCKET_HANDLE*    handle /* [out] sys_socket_handle handle  */)
       {
        //testAlive();
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->handleGet(handle);
       }

    CLIMETHOD(handleSet) (THIS_ SYS_SOCKET_HANDLE    handle /* [in] sys_socket_handle  handle  */)
       {
        //testAlive();
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->handleSet(handle);
       }

    CLIMETHOD(socketTypeGet) (THIS_ INT*    socketType /* [out] ::cli::inet::SocketType socketType  */)
       {
        //testAlive();
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->socketTypeGet(socketType);
       }

    CLIMETHOD(localAddrGet) (THIS_ STRUCT_CLI_INET_SOCKETADDRESS*    localAddr /* [out] ::cli::inet::SocketAddress localAddr  */)
       {
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->localAddrGet(localAddr);
       }

    CLIMETHOD(peerAddrGet) (THIS_ STRUCT_CLI_INET_SOCKETADDRESS*    peerAddr /* [out] ::cli::inet::SocketAddress peerAddr  */)
       {
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->peerAddrGet(peerAddr);
       }

    CLIMETHOD(broadcastModeGet) (THIS_ BOOL*    broadcastMode /* [out] bool broadcastMode  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(broadcastModeSet) (THIS_ BOOL    broadcastMode /* [in] bool  broadcastMode  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(reuseAddrGet) (THIS_ BOOL*    reuseAddr /* [out] bool reuseAddr  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(reuseAddrSet) (THIS_ BOOL    reuseAddr /* [in] bool  reuseAddr  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(reusePortGet) (THIS_ BOOL*    _reusePort /* [out] bool _reusePort  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(reusePortSet) (THIS_ BOOL    _reusePort /* [in] bool  _reusePort  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(exclusiveAddrUseGet) (THIS_ BOOL*    _exclusiveAddrUse /* [out] bool _exclusiveAddrUse  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(exclusiveAddrUseSet) (THIS_ BOOL    _exclusiveAddrUse /* [in] bool  _exclusiveAddrUse  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(tcpNoDelayGet) (THIS_ BOOL*    tcpNoDelay /* [out] bool tcpNoDelay  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(tcpNoDelaySet) (THIS_ BOOL    tcpNoDelay /* [in] bool  tcpNoDelay  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(joinToMulticastGroup) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(joinToMulticastGroupStr) (THIS_ const CLISTR*     addr)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(leaveMulticastGroup) (THIS_ const STRUCT_CLI_INET_IPADDRESS*    addr /* [in,ref] ::cli::inet::IpAddress  addr  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(leaveMulticastGroupStr) (THIS_ const CLISTR*     addr)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(multicastTTLGet) (THIS_ UINT*    _multicastTTL /* [out] uint _multicastTTL  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(multicastTTLSet) (THIS_ UINT    _multicastTTL /* [in] uint  _multicastTTL  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(createSocketEx) (THIS_ UINT    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                   , INT    type /* [in] ::cli::inet::SocketType  type  */
                                   , INT    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                                   , BOOL    bNonBlock /* [in] bool  bNonBlock  */
                              )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(createSocket) (THIS_ UINT    af /* [in] ::cli::inet::IpAddressFamily  af  */
                                 , INT    type /* [in] ::cli::inet::SocketType  type  */
                                 , INT    protocol /* [in] ::cli::inet::ProtocolType  protocol  */
                            )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(closeSocket) (THIS)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(connectSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(selectSocket) (THIS_ DWORD    selectFor /* [in] ::cli::inet::SelectWhat  selectFor  */
                                 , DWORD*    readyFor /* [out] ::cli::inet::SelectWhat readyFor  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(bindSocket) (THIS_ const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(bindSocketStr) (THIS_ const CLISTR*     addr
                                  , const CLISTR*     port
                                  , const CLISTR*     protocol
                             )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(listenSocket) (THIS)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(acceptSocketConnection) (THIS_ SYS_SOCKET_HANDLE*    hAccepted /* [out] sys_socket_handle hAccepted  */
                                           , STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [out] ::cli::inet::SocketAddress sa  */
                                           , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                                      )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(waitAsyncConnect) (THIS_ TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(recvFrom) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                             , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                             , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                             , STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [out,ref] ::cli::inet::SocketAddress sa  */
                        )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(recvFromTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                    , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                    , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                    , STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [out,ref] ::cli::inet::SocketAddress sa  */
                                    , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                               )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(sendTo) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                           , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                           , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                           , const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */
                      )
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(sendToTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                  , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                  , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                  , const STRUCT_CLI_INET_SOCKETADDRESS*    sa /* [in,ref] ::cli::inet::SocketAddress  sa  */
                                  , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                             )
       {
        return EC_NOT_IMPLEMENTED;
       }

    /* interface ::cli::inet::iSocket and
       interface ::cli::io::iIOStream 
       common methods 
     */

    CLIMETHOD(createReadEnd) (THIS_ INTERFACE_CLI_IO_IISTREAM**    pStream /* [out] ::cli::io::iIStream* pStream  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(createWriteEnd) (THIS_ INTERFACE_CLI_IO_IOSTREAM**    pStream /* [out] ::cli::io::iOStream* pStream  */)
       {
        return EC_NOT_IMPLEMENTED;
       }

    CLIMETHOD(read) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                         , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                         , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                    )
       {
        testAlive();
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->read(buf,numBytesToRead,numBytesReaded);
       }

    CLIMETHOD(readTimeout) (THIS_ VOID*    buf /* [out,flat] void buf[]  */
                                , SIZE_T    numBytesToRead /* [in] size_t  numBytesToRead  */
                                , SIZE_T*    numBytesReaded /* [out] size_t numBytesReaded  */
                                , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                           )
       {
        testAlive();
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->readTimeout(buf,numBytesToRead,numBytesReaded,millisecTimeout);
       }

    CLIMETHOD(write) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                          , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                          , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                     )
       {
        testAlive();
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->write(buf,numBytesToWrite,numBytesWritten);
       }

    CLIMETHOD(writeTimeout) (THIS_ const VOID*    buf /* [in,flat] void  buf[]  */
                                 , SIZE_T    numBytesToWrite /* [in] size_t  numBytesToWrite  */
                                 , SIZE_T*    numBytesWritten /* [out] size_t numBytesWritten  */
                                 , TICK_T    millisecTimeout /* [in] tick_t  millisecTimeout  */
                            )
       {
        testAlive();
        if (!pDataSocket) return EC_BROKEN_STREAM;
        return pDataSocket->writeTimeout(buf,numBytesToWrite,numBytesWritten,millisecTimeout);
       }

    /* interface ::cli::io::iIOStream methods */
    CLIMETHOD_(DWORD, getStreamType) (THIS)
       {
        testAlive();
        return CLI_IO_IOSTREAMTYPE_SERIAL_TCP;
       }




    /* Internal helper functions */
    RCODE mode2NPortIndex(const STRUCT_CLI_IO_SERIAL_COPTIONS &opts, BYTE *pMode)
       {
        *pMode = 0;

        switch(opts.dataBits)
           {
            case 8: *pMode = ASPP_IOCTL_BITS8; break;
            case 7: *pMode = ASPP_IOCTL_BITS7; break;
            case 6: *pMode = ASPP_IOCTL_BITS6; break;
            case 5: *pMode = ASPP_IOCTL_BITS5; break;
            default:return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_DATABITS, 0, 0, (::cli::format::arg((UINT)opts.dataBits) ) );
           }

        if (opts.parity&CLI_IO_SERIAL_PARITY_FPARITY)
           {
            switch(opts.parity)
               {
                case CLI_IO_SERIAL_PARITY_EVEN : *pMode |= ASPP_IOCTL_EVEN ; break;
                case CLI_IO_SERIAL_PARITY_ODD  : *pMode |= ASPP_IOCTL_ODD  ; break;
                case CLI_IO_SERIAL_PARITY_MARK : *pMode |= ASPP_IOCTL_MARK ; break;
                case CLI_IO_SERIAL_PARITY_SPACE: *pMode |= ASPP_IOCTL_SPACE; break;
                default:return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_PARITY, 0, 0, (::cli::format::arg((UINT)opts.parity) ) );
               }
           }

        if (opts.stopBits==1)
           {
            *pMode |= ASPP_IOCTL_STOP1;
           }
        else if (opts.stopBits==2)
           {
            *pMode |= ASPP_IOCTL_STOP2;
           }
        else
           {
            return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_STOPBITS, 0, 0, (::cli::format::arg((UINT)opts.stopBits) ) );
           }
        return EC_OK;
       }

    bool baudRate2NPortIndex(unsigned baud, BYTE *pIdx)
       {
        switch(baud)
           {
            case 921600: *pIdx = ASPP_IOCTL_B921600; break;
            case 460800: *pIdx = ASPP_IOCTL_B460800; break;
            case 230400: *pIdx = ASPP_IOCTL_B230400; break;
            case 115200: *pIdx = ASPP_IOCTL_B115200; break;
            case 57600 : *pIdx = ASPP_IOCTL_B57600; break;
            case 38400 : *pIdx = ASPP_IOCTL_B38400; break;
            case 19200 : *pIdx = ASPP_IOCTL_B19200; break;
            case 9600  : *pIdx = ASPP_IOCTL_B9600; break;
            case 7200  : *pIdx = ASPP_IOCTL_B7200; break;
            case 4800  : *pIdx = ASPP_IOCTL_B4800; break;
            case 2400  : *pIdx = ASPP_IOCTL_B2400; break;
            case 1200  : *pIdx = ASPP_IOCTL_B1200; break;
            case 600   : *pIdx = ASPP_IOCTL_B600; break;
            case 300   : *pIdx = ASPP_IOCTL_B300; break;
            case 150   : *pIdx = ASPP_IOCTL_B150; break;
            case 134   : *pIdx = ASPP_IOCTL_B134; break;
            case 110   : *pIdx = ASPP_IOCTL_B110; break;
            case 75    : *pIdx = ASPP_IOCTL_B75; break;
            case 50    : *pIdx = ASPP_IOCTL_B50; break;
            //case   : *pIdx = ; break;
            default:            return false;
           }
        return true;
       }

    SIZE_T calcCommas( const ::std::wstring &name )
       {
        SIZE_T res = 0;
        ::std::wstring::size_type pos = 0, size = name.size(); 
        for(; pos!=size; ++pos) if (name[pos]==L'.') ++res;
        return res;
       }

    RCODE broadcastFindMoxaAddressImpl( const ::std::wstring &_moxaName, STRUCT_CLI_INET_IPADDRESS &ipAddr )
       {
        bool bFound = false;
        CLI_TRY{
                ::std::wstring moxaName = MARTY_FILENAME::utils::upperCase(_moxaName);
                
                ::cli::moxa::CiMoxaManager mxMan("/cli/moxa/manager");
                ::cli::moxa::CiMoxaFinder finder;
        
                //INTERFACE_CLI_IARGLIST* pArgList = cliGetArgList( );
                //::std::vector< ::std::wstring >::const_iterator salIt = searchAddrList.begin();
                //for(; pArgList && salIt!=searchAddrList.end(); ++salIt)
                //   {
                //    pArgList->putStringChars( salIt->data(), salIt->size() );
                //   }
        
                //if (resFlags) *resFlags |= CLI_IO_PORTFLAGS_NETWORKPORT;
        
                //RCODE res = mxMan.createFinderExList( pArgList, finder.getPP(), 2, 1000, 200 );
                //CLI_THROW_IF_NOK(res);
                RCODE res = mxMan.createFinder( finder.getPP(), 3, 150, 50 );
        
                SIZE_T foundServersCount = 0;
                finder.foundServersSize( &foundServersCount );
        
                for(SIZE_T serverNo = 0; serverNo!=foundServersCount; ++serverNo)
                   {
                    STRUCT_CLI_MOXA_CMOXASERVERINFO srvInfo;
                    if (!finder.foundServersGet( srvInfo, serverNo ))
                       {
                        //std::wstring moxaHost, moxaHostIp;
                        //std::wstring ipMoxaStr;
                        //resolver.ipToString( srvInfo.serverAddr, moxaHostIp );
        
                        //resolver.getHostByAddressString
                        // BUG: ��� �� �������� ������ �������� ����������� ����� ����� �� ������
                        //if (!resolver.getHostByAddress(srvInfo.serverAddr))
                        //   resolver.canonicalNameGet(moxaHost);
                        //else
                        //   moxaHost = moxaHostIp;
        
                        ::std::wstring foundMoxaName(srvInfo.serverName);
                        //::std::wstring foundMoxaName(MARTY_FILENAME::utils::upperCase(::std::wstring(srvInfo.serverName)));
                        foundMoxaName = MARTY_FILENAME::utils::upperCase(foundMoxaName);
                        CMoxaNameCacheItem cacheItem;
                        cacheItem.ipAddr = srvInfo.serverAddr;
                        cacheItem.lastUpdate = cliGetTickCount();
                           {
                            CLI_AUTOLOCK(moxaNameCacheCs);
                            moxaNameCache[foundMoxaName] = cacheItem;
                           }

                        if (foundMoxaName==moxaName)
                           {
                            bFound = true;
                            ipAddr = srvInfo.serverAddr;
                            //return EC_OK;
                           }
                        //::std::wstring moxaProductName(srvInfo.productName);
                       }
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        if (bFound)
           return EC_OK;
        return EC_RESOLV_HOST_NOT_FOUND;
       }

    RCODE broadcastFindMoxaAddress( const ::std::wstring &_moxaName, STRUCT_CLI_INET_IPADDRESS &ipAddr )
       {
        CLI_TRY{
                ::std::wstring moxaName = MARTY_FILENAME::utils::upperCase(_moxaName);
                 {
                  // try to find in cache
                  CLI_AUTOLOCK(moxaNameCacheCs);
                  ::std::map< ::std::wstring, CMoxaNameCacheItem >::const_iterator mnIt = moxaNameCache.find(moxaName);
                  if (  mnIt != moxaNameCache.end() 
                     && cliGetCurrentTickDiff(mnIt->second.lastUpdate)<30000 // ������ �� ��������� 30 ������
                     )
                     {
                      ipAddr = mnIt->second.ipAddr;
                      return EC_OK;
                     }
                 }
                // not found in cache at all or data is too old
                // try to find again
                return broadcastFindMoxaAddressImpl( _moxaName, ipAddr );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    RCODE findMoxaAddressInCache( const ::std::wstring &_moxaName, STRUCT_CLI_INET_IPADDRESS &ipAddr )
       {
        CLI_TRY{
                ::std::wstring moxaName = MARTY_FILENAME::utils::upperCase(_moxaName);
                 {
                  // try to find in cache
                  CLI_AUTOLOCK(moxaNameCacheCs);
                  ::std::map< ::std::wstring, CMoxaNameCacheItem >::const_iterator mnIt = moxaNameCache.find(moxaName);
                  if (  mnIt != moxaNameCache.end() 
                     && cliGetCurrentTickDiff(mnIt->second.lastUpdate)<10000 // ������ �� ��������� 10 ������
                     )
                     {
                      ipAddr = mnIt->second.ipAddr;
                      return EC_OK;
                     }
                 }
                // not found in cache at all or data is too old
                return EC_RESOLV_HOST_NOT_FOUND;
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    RCODE internalOpenParsedOpts( const ::std::wstring &_host
                                , const ::std::wstring &port
                                , const ::std::wstring &path
                                , const ::std::wstring &options
                                , const ::std::map< ::std::wstring, ::std::wstring > &optionsMap
                                , INTERFACE_CLI_IO_ICONNECTINGSTATEWATCHER*    pConWatcher /* [in] ::cli::io::iConnectingStateWatcher*  pConWatcher  */
                                )
       {
        CLI_TRY{
                int deviceNo = extractDeviceNo( path );
                if (deviceNo<0)
                   {
                    return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_INVALID_DEVICE_NAME, 0, 0, (::cli::format::arg(path) ) );
                   }

                RCODE res = serialHelperParseOptionsMap( optionsMap, &savedOptions, streamNameInfo );
                if (RC_FAIL(res)) return res;
        
                ::std::wstring dataPort = port, host = _host, ctrlPort;
                bool detectOn = true;
        
                ::std::map< ::std::wstring, ::std::wstring >::const_iterator optIt = optionsMap.begin();
                for(; optIt!=optionsMap.end(); ++optIt)
                   {
                    ::std::wstring first  = MARTY_FILENAME_NS utils::lowerCase(optIt->first , MARTY_FILENAME_NS utils::makeUserLocale());
                    ::std::wstring second = MARTY_FILENAME_NS utils::lowerCase(optIt->second, MARTY_FILENAME_NS utils::makeUserLocale());
                    if (first==L"ctrlport" || first==L"ctrl")
                       {
                        if (!ctrlPort.empty())
                           return CLI_SET_ERROR_INFO_ARGS( EC_IOSTREAM_OPT_MULTIPLE, 0, 0, (::cli::format::arg(optIt->first) % streamNameInfo) );
                        ctrlPort = second;
                       }
                    if (first==L"detect" || first==L"autodetect"  /* || first==L"ctrl" */ )
                       {
                        if (second==L"true" || second==L"1" || second==L"on") detectOn = true;
                        else detectOn = false;
                       }
                   }

                 ::cli::io::CiConnectingStateWatcher watcher(pConWatcher);

        
                if (dataPort.empty() || ctrlPort.empty() || detectOn)
                   {
                    ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");

                    ::std::wstring clientHostNameW;
                    resolver.getHostName( clientHostNameW );
                    clientHostName = MARTY_CON_NS w2ansi( clientHostNameW );                    

                    STRUCT_CLI_INET_IPADDRESS tmpIpAddr;
                    bool ipResolved = true;
                    if (resolver.stringToIp(host,tmpIpAddr))
                       ipResolved = false;

                    if (!!watcher && !ipResolved) 
                       watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_BEGINRESOLVING, host);

                    if (!ipResolved)
                       {
                        if (!findMoxaAddressInCache( host, tmpIpAddr ))
                           {
                            resolver.ipToString( tmpIpAddr, host );
                            ipResolved = true;
                            if (!!watcher) 
                               watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING, host);
                           }
                       }

                    if (!ipResolved && !calcCommas(host))
                       { // it is possible that is the Internal name of moxa
                        if (!broadcastFindMoxaAddress( host, tmpIpAddr ))
                           {
                            resolver.ipToString( tmpIpAddr, host );
                            ipResolved = true;
                            if (!!watcher) 
                               watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING, host);
                           }
                       }

                    if (!ipResolved)
                       {
                        //res = resolver.getHostInfoByName( name, AF_UNSPEC );
                        res = resolver.getHostInfoByName( host, AF_INET );
                        SIZE_T addrListSize = 0;
                        if (RC_OK(res)) 
                           resolver.addrListSize(&addrListSize);
    
                        if (RC_FAIL(res) || addrListSize<1) 
                           {
                            // try to find moxa and get its name
                            //STRUCT_CLI_INET_IPADDRESS ip;
                            RCODE res2 = broadcastFindMoxaAddress( host, tmpIpAddr );
                            if (RC_FAIL(res2))
                               {
                                if (!!watcher) 
                                   watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_FAILRESOLVING, host);
                                if (RC_FAIL(res))
                                   return res;
                                return CLI_SET_ERROR_INFO_ARGS( EC_RESOLV_HOST_NOT_FOUND, 0, 0, (::cli::format::arg(host) % streamNameInfo) );
                               }
                            resolver.ipToString( tmpIpAddr, host );
                           }
                        else
                           {
                            //STRUCT_CLI_INET_IPADDRESS ip;
                            resolver.addrListGet( tmpIpAddr, 0 );
                            resolver.ipToString( tmpIpAddr, host );
                           }
                        ipResolved = true;
                        if (!!watcher) 
                           watcher.onConnectingStateEvent( CLI_IO_IOCONNECTINGSTATE_SUCCESSRESOLVING, host);
                       }

                    ::cli::moxa::CiMoxaManager mxMan("/cli/moxa/manager");
                    ::cli::moxa::CiMoxaFinder finder;

                    res = mxMan.createFinderEx( host, finder.getPP(), 3, 500, 150 );
                    if (RC_FAIL(res)) return res;
                    
                    SIZE_T foundServersCount = 0;
                    finder.foundServersSize( &foundServersCount );

                    if (foundServersCount<1) 
                       return CLI_SET_ERROR_INFO_ARGS( EC_NO_SERIAL_SERVER, 0, 0, (::cli::format::arg(L"Moxa NPort") % host) );

                    STRUCT_CLI_MOXA_CMOXASERVERINFO srvInfo;
                    res = finder.foundServersGet( srvInfo, 0 );
                    if (RC_FAIL(res)) return res;

                    //std::wstring moxaHost;
                    resolver.ipToString( srvInfo.serverAddr, host );

                    ::std::wstring moxaProductName(srvInfo.productName);

                    if (deviceNo>=(int)srvInfo.numberOfPorts)
                       return CLI_SET_ERROR_INFO_ARGS( EC_NO_PORT_ON_SERVER, 0, 0, (::cli::format::arg((UINT)deviceNo) % (UINT)srvInfo.numberOfPorts % moxaProductName) );

                    dataPort = ::cli::format::message( L"%1", ::cli::format::arg((UINT)srvInfo.portInfo[deviceNo].tcpDataPort) );
                    ctrlPort = ::cli::format::message( L"%1", ::cli::format::arg((UINT)srvInfo.portInfo[deviceNo].tcpCommandPort) );
                   }

                if (clientHostName.empty())
                   {
                    ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                    ::std::wstring clientHostNameW;
                    resolver.getHostName( clientHostNameW );
                    clientHostName = MARTY_CON_NS w2ansi( clientHostNameW );
                   }

                if (dataPort.empty())
                   {
                    dataPort = ::cli::format::message( L"%1", ::cli::format::arg((UINT)deviceNo+950) );
                   }

                if (ctrlPort.empty())
                   {
                    ctrlPort = ::cli::format::message( L"%1", ::cli::format::arg((UINT)deviceNo+966) );
                   }

                ::cli::io::CiIOFactory iof( "/cli/io-factory" );

                ::std::wstring iosCtrlStreamName = ::cli::format::message( L"tcp://%1:%2", ::cli::format::arg(host) % ctrlPort );
                ::cli::io::CiIOStream iosCtrl;
                res = iof.createStream( iosCtrlStreamName, iosCtrl.getPP(), pConWatcher );
                if (RC_FAIL(res)) return res;

                //::cli::format::cli_log::message( L"Connected to ctrl stream: %1", ::cli::format::arg( iosCtrlStreamName ) );

                ::std::wstring iosDataStreamName = ::cli::format::message( L"tcp://%1:%2", ::cli::format::arg(host) % dataPort );
                ::cli::io::CiIOStream iosData;
                res = iof.createStream( iosDataStreamName, iosData.getPP(), pConWatcher );
                if (RC_FAIL(res)) return res;

                //::cli::format::cli_log::message( L"Connected to data stream: %1", ::cli::format::arg( iosDataStreamName ) );

                res = iosData.queryInterface( &pDataSocket );
                if (RC_FAIL(res)) return res;

                res = iosCtrl.queryInterface( &pControlSocket );
                if (RC_FAIL(res)) 
                   {
                    pDataSocket->release();
                    pDataSocket = 0;
                    return res;
                   }

                pDataSocket   ->tcpNoDelaySet( TRUE );
                pControlSocket->tcpNoDelaySet( TRUE );

                SIZE_T written;

                BYTE initPacket[256];
                initPacket[0] = ASPP_CMD_PORT_INIT;
                //initPacket[1] = len;
                if (!baudRate2NPortIndex( savedOptions.baudRate, &initPacket[2]))
                   return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_BAUD_NOT_SUPPORTED, 0, 0, (::cli::format::arg((UINT)savedOptions.baudRate) ) );

                res = mode2NPortIndex( savedOptions, &initPacket[3]);
                if (RC_FAIL(res)) return res;
                   
                initPacket[4] = 0; // no DTR
                initPacket[5] = 0; // no RTS
                // H/W flow control
                initPacket[6] = 0;
                initPacket[7] = 0;

                initPacket[8] = 0; // no XON
                initPacket[9] = 0; // no XOFF

                size_t nCharsToCopy = clientHostName.size();
                if (nCharsToCopy>128) nCharsToCopy = 128;
                clientHostName.copy( (::std::string::value_type*)&initPacket[10], nCharsToCopy, 0 );

                size_t len = 8 + nCharsToCopy;
                initPacket[1] = (BYTE)len; // len
                size_t totalSize = len + 2;

                res = pControlSocket->writeTimeout( (VOID*)&initPacket[0], totalSize, &written, 1000 );
                if (RC_FAIL(res)) return res;
                //::cli::format::cli_log::message( L"Sent ctrl sequence, %1 bytes: %2", ::cli::format::arg( (UINT)written ) % ::cli::format::dump(initPacket, written) );

                // 2c 03 00 00 01 
                // 26 00 80 80
                /*
                totalSize = 0;
                initPacket[totalSize+0] = ASPP_CMD_PORT_INIT;
                initPacket[totalSize+1] = 3;
                initPacket[totalSize+2] = 0;
                initPacket[totalSize+3] = 0;
                initPacket[totalSize+4] = 1;
                totalSize = 5;

                initPacket[totalSize+0] = ASPP_CMD_NOTIFY;



                ASPP_CMD_NOTIFY

                ASPP_CMD_PORT_INIT
                */

                /*
                totalSize = 0;
                initPacket[totalSize  ] = ASPP_CMD_SETBAUD;
                initPacket[totalSize+1] = 4;
                memcpy(&initPacket[totalSize+2],&savedOptions.baudRate,4);
                totalSize += 6;

                res = pControlSocket->writeTimeout( (VOID*)&initPacket[0], totalSize, &written, 1000 );
                if (RC_FAIL(res)) return res;
                ::cli::format::cli_log::message( L"Sent ctrl sequence, %1 bytes: %2", ::cli::format::arg( (UINT)written ) % ::cli::format::dump(initPacket, written) );
                */

                /*
                totalSize = 0;
                initPacket[totalSize  ] = ASPP_CMD_TX_FIFO;
                initPacket[totalSize+1] = 1;
                initPacket[totalSize+2] = 0x10;
                totalSize += 3;

                res = pControlSocket->writeTimeout( (VOID*)&initPacket[0], totalSize, &written, 1000 );
                if (RC_FAIL(res)) return res;
                ::cli::format::cli_log::message( L"Sent ctrl sequence, %1 bytes: %2", ::cli::format::arg( (UINT)written ) % ::cli::format::dump(initPacket, written) );

                // flow ctrl 11 04 00 00 00 00
                totalSize = 0;
                initPacket[totalSize  ] = ASPP_CMD_FLOWCTRL;
                initPacket[totalSize+1] = 4;
                initPacket[totalSize+2] = 0;
                initPacket[totalSize+3] = 0;
                initPacket[totalSize+4] = 0;
                initPacket[totalSize+5] = 0;
                totalSize += 6;

                res = pControlSocket->writeTimeout( (VOID*)&initPacket[0], totalSize, &written, 1000 );
                if (RC_FAIL(res)) return res;
                ::cli::format::cli_log::message( L"Sent ctrl sequence, %1 bytes: %2", ::cli::format::arg( (UINT)written ) % ::cli::format::dump(initPacket, written) );

                totalSize = 0;
                initPacket[totalSize  ] = ASPP_CMD_LINECTRL;
                initPacket[totalSize+1] = 2;
                initPacket[totalSize+2] = 0;
                initPacket[totalSize+3] = 0;
                totalSize += 4;

                res = pControlSocket->writeTimeout( (VOID*)&initPacket[0], totalSize, &written, 1000 );
                if (RC_FAIL(res)) return res;
                ::cli::format::cli_log::message( L"Sent ctrl sequence, %1 bytes: %2", ::cli::format::arg( (UINT)written ) % ::cli::format::dump(initPacket, written) );

                totalSize = 0;
                initPacket[totalSize  ] = ASPP_CMD_IOCTL;
                initPacket[totalSize+1] = 2;
                initPacket[totalSize+2] = initPacket[2];
                initPacket[totalSize+3] = initPacket[3];
                totalSize += 4;

                res = pControlSocket->writeTimeout( (VOID*)&initPacket[0], totalSize, &written, 1000 );
                if (RC_FAIL(res)) return res;
                ::cli::format::cli_log::message( L"Sent ctrl sequence, %1 bytes: %2", ::cli::format::arg( (UINT)written ) % ::cli::format::dump(initPacket, written) );

                totalSize = 0;
                initPacket[totalSize  ] = ASPP_CMD_IOCTL;
                initPacket[totalSize+1] = 0;
                totalSize += 2;

                res = pControlSocket->writeTimeout( (VOID*)&initPacket[0], totalSize, &written, 1000 );
                if (RC_FAIL(res)) return res;
                ::cli::format::cli_log::message( L"Sent ctrl sequence, %1 bytes: %2", ::cli::format::arg( (UINT)written ) % ::cli::format::dump(initPacket, written) );
                */

/*
#define ASPP_CMD_IOCTL          16  // 0x10
#define ASPP_CMD_FLOWCTRL       17  // 0x11
#define ASPP_CMD_LSTATUS        19  // 0x13
#define ASPP_CMD_LINECTRL       18  // 0x12
#define ASPP_CMD_FLUSH          20  // 0x14
#define ASPP_CMD_OQUEUE         22  // 0x16
#define ASPP_CMD_SETBAUD        23  // 0x17
#define ASPP_CMD_START_BREAK    33  // 0x21
#define ASPP_CMD_STOP_BREAK     34  // 0x22
#define ASPP_CMD_START_NOTIFY   36  // 0x24
#define ASPP_CMD_STOP_NOTIFY    37  // 0x25
#define ASPP_CMD_HOST           43  // 0x2B
#define ASPP_CMD_PORT_INIT      44  // 0x2C
#define ASPP_CMD_WAIT_OQUEUE    47  // 0x2F

#define ASPP_CMD_IQUEUE         21  // 0x15
#define ASPP_CMD_XONXOFF        24  // 0x18
#define ASPP_CMD_PORT_RESET     32  // 0x20
#define ASPP_CMD_RESENT_TIME    46  // 0x2E
#define ASPP_CMD_TX_FIFO        48  // 0x30
#define ASPP_CMD_SETXON         51  // 0x33
#define ASPP_CMD_SETXOFF        52  // 0x34
*/


                //::cli::format::cli_log::message( L"Sent ctrl sequence, %1 bytes: %2", ::cli::format::arg( (UINT)written ) % ::cli::format::dump(initPacket, written) );

                SIZE_T readed = 0;
                BYTE replyBuf[512];
                res = pControlSocket->readTimeout( (VOID*)&replyBuf[0], sizeof(replyBuf), &readed, 3000 );
                if (RC_FAIL(res)) return res;

                // std reply: 2c 03 00 00 01 
                //            26 00 80 80
                if (readed<5 || replyBuf[0]!=ASPP_CMD_PORT_INIT || replyBuf[1]!=3)
                   {
                    return CLI_SET_ERROR_INFO_ARGS( EC_BAD_SERVER_REPLY, 0, 0, (::cli::format::arg(L"Moxa NPort") % (UINT)readed % ::cli::format::dump(replyBuf, readed) ) );
                    //DECLARE_CLI_ERROR(EC_BAD_SERVER_REPLY              , 0xC0000033, "Invalid reply from serial server (server model: %1, %2 bytes len reply: %3)")
                   }

                //#define ASPP_CMD_PORT_INIT      44  // 0x2C
                //#define ASPP_CMD_NOTIFY         38  // 0x26


                //::cli::format::cli_log::message( L"Reply from ctrl moxa port, %1 bytes: %2", ::cli::format::arg( (UINT)readed ) % ::cli::format::dump(replyBuf, readed) );                

                

                //return applySerialOptions( &savedOptions );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    RCODE applySerialOptions(const STRUCT_CLI_IO_SERIAL_COPTIONS*    options)
       {
        testAlive();

        SIZE_T written;

        BYTE initPacket[256];
        initPacket[0] = ASPP_CMD_PORT_INIT;
        //initPacket[1] = len;
        if (!baudRate2NPortIndex( options->baudRate, &initPacket[2]))
           return CLI_SET_ERROR_INFO_ARGS( EC_SERIAL_BAUD_NOT_SUPPORTED, 0, 0, (::cli::format::arg((UINT)options->baudRate) ) );

        RCODE res = mode2NPortIndex( *options, &initPacket[3]);
        if (RC_FAIL(res)) return res;
           
        initPacket[4] = 0; // no DTR
        initPacket[5] = 0; // no RTS
        // H/W flow control
        initPacket[6] = 0;
        initPacket[7] = 0;

        initPacket[8] = 0; // no XON
        initPacket[9] = 0; // no XOFF

        size_t nCharsToCopy = clientHostName.size();
        if (nCharsToCopy>128) nCharsToCopy = 128;
        clientHostName.copy( (::std::string::value_type*)&initPacket[10], nCharsToCopy, 0 );

        size_t len = 8;// + nCharsToCopy;
        initPacket[1] = (BYTE)len; // len
        size_t totalSize = len + 2;

        res = pControlSocket->writeTimeout( (VOID*)&initPacket[0], totalSize, &written, 1000 );
        if (RC_FAIL(res)) return res;

        /*
        SIZE_T readed = 0;
        BYTE replyBuf[512];
        res = pControlSocket->readTimeout( (VOID*)&replyBuf[0], sizeof(replyBuf), &readed, 3000 );
        if (RC_FAIL(res)) return res;
        */
        // std reply: 2c 03 00 00 01 
        //            26 00 80 80

        TICK_T startTick = cliGetTickCount();
        while( cliGetCurrentTickDiff(startTick) < 5000 ) // 5 seconds
           {
            DWORD tares = testAlive(100);
            if (tares&RRF_CMD_PORT_INIT)
               return EC_OK;
           }

        //return CLI_SET_ERROR_INFO_ARGS( EC_BAD_SERVER_REPLY, 0, 0, (::cli::format::arg(L"Moxa NPort") % (UINT)readed % ::cli::format::dump(replyBuf, readed) ) );
        return CLI_SET_ERROR_INFO( EC_NO_REPLY, 0, 0 );
        

        /*
        if (readed<5 || replyBuf[0]!=ASPP_CMD_PORT_INIT || replyBuf[1]!=3)
           {
            return CLI_SET_ERROR_INFO_ARGS( EC_BAD_SERVER_REPLY, 0, 0, (::cli::format::arg(L"Moxa NPort") % (UINT)readed % ::cli::format::dump(replyBuf, readed) ) );
            //DECLARE_CLI_ERROR(EC_BAD_SERVER_REPLY              , 0xC0000033, "Invalid reply from serial server (server model: %1, %2 bytes len reply: %3)")
           }
        */
        //return EC_OK;
       }

    CLIMETHOD(setSerialOptions) (THIS_ const STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [in,ref] ::cli::io::serial::COptions  options  */)
       { 
        if (!options) return EC_INVALID_PARAM;
        RCODE res = applySerialOptions(options);
        if (RC_FAIL(res)) return res;
        savedOptions.baudRate = options->baudRate;
        savedOptions.parity   = options->parity  ;
        savedOptions.dataBits = options->dataBits;
        savedOptions.stopBits = options->stopBits;
        return EC_OK;
       }

    CLIMETHOD(getSerialOptions) (THIS_ STRUCT_CLI_IO_SERIAL_COPTIONS*    options /* [out] ::cli::io::serial::COptions options  */)
       {
        if (!options) return EC_INVALID_PARAM;
        options->baudRate = savedOptions.baudRate;
        options->parity   = savedOptions.parity  ;
        options->dataBits = savedOptions.dataBits;
        options->stopBits = savedOptions.stopBits;
        return EC_OK;
       }

    DWORD processServerSinglePacket(const BYTE *pkt, SIZE_T pktSize)
       {
        DWORD resultFlags = 0;
        BYTE cmdBuf[512];
        size_t cmdSize = 0;
        if (pktSize>=3 && pkt[0]==ASPP_CMD_POLLING && pkt[1]==1)
           {
            cmdBuf[0] = ASPP_CMD_ALIVE;
            cmdBuf[1] = 1;
            cmdBuf[2] = pkt[2];
            cmdSize = 3;
           }
        else if (pktSize>=5 && pkt[0]==ASPP_CMD_PORT_INIT && pkt[1]==3)
           {
            resultFlags |= RRF_CMD_PORT_INIT;
           }
        SIZE_T written = 0;
        //RCODE res = 
        if (cmdSize>0) pControlSocket->writeTimeout( (VOID*)&cmdBuf[0], cmdSize, &written, 1000 );
        //if (RC_FAIL(res)) return res;

        return resultFlags;
       }

    DWORD processServerReply(const BYTE *pReply, SIZE_T replySize)
       {
        DWORD resultFlags = 0;
        SIZE_T pktStartPos = 0;
        while(pktStartPos<replySize)
           {
            const BYTE *pkt = &pReply[pktStartPos++];
            if (pktStartPos>=replySize) break;

            SIZE_T pktSize = pReply[pktStartPos++];
            if ((pktStartPos+pktSize) > replySize)
               {
                pktSize = replySize - pktStartPos;
               }
             
            resultFlags |= processServerSinglePacket( pkt, pktSize+2 );
            pktStartPos += pktSize;
           }
        return resultFlags;
       }

    DWORD testAlive(TICK_T timeout = 0)
       {
        if (!pControlSocket) return 0;
        SIZE_T readed = 0;
        BYTE replyBuf[4096];
        RCODE res = pControlSocket->readTimeout( (VOID*)&replyBuf[0], sizeof(replyBuf), &readed, timeout );
        if (!res && readed) return processServerReply(&replyBuf[0], readed);
        return 0;
       }

/* polling
    if ( servp->dev_type == 0 )
    {
        servp->next_sendtime = (time_t)((int32_t)(sys_info.uptime + 5 ));
        msg[0] = 1;
        msg[3] = 6;
        len = 6;
    }

*/


}; // struct CNPortImpl


}; // namespace impl 
}; // namespace moxa
}; // namespace cli  


#endif /* CORE_IO_MOXA_NPORTIMPL_H */

