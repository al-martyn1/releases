#ifndef CORE_IO_MOXA_MGRIMPL_H
#define CORE_IO_MOXA_MGRIMPL_H

#ifndef CLI_INET_ISOCK_H
    #include <cli/inet/isock.h>
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#ifndef CLI_IO_MOXA_MOXA_H
    #include <cli/io/moxa/moxa.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INET_IRESOLV_H
    #include <cli/inet/iResolv.h>
#endif

#ifndef CLI_TICKCOUNT_H
    #include <cli/tickcount.h>
#endif


#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#ifndef CLI_INET_IPHLP_H
    #include <cli/inet/iphlp.h>
#endif

#include "../../inet/inethlp.h"


#include <cli/formatx.h>

namespace cli {
namespace moxa {
namespace impl {


struct CMoxaProductInfo
   {
    DWORD          appId;
    WORD           hwId;
    const WCHAR*   productName;
    SIZE_T         portNumber;
   };

CMoxaProductInfo*  findMoxaProductInfo( DWORD appId, WORD hwId )
   {
    static
    CMoxaProductInfo pi[] = { { 0x80005000, 0x0504, L"NPort 5410", 4 }
                            , { 0x80005000, 0x0534, L"NPort 5430", 0 }
                            , { 0x80005000, 0x1534, L"NPort 5430I", 0 }

                            , { 0x80005400, 0x5401, L"NPort 5410 V3", 4 } // not from docs, received from MOXA NPort 5410 rev 3.2

                            , { 0x80000312, 0x0312, L"NPort 5230", 0 }
                            , { 0x80000312, 0x0322, L"NPort 5210", 2 }
                            , { 0x80000312, 0x0332, L"NPort 5232", 0 }
                            , { 0x80000312, 0x1332, L"NPort 5232I", 0 }

                            , { 0x80005610, 0x5618, L"NPort 5610-8", 0 }
                            , { 0x80005610, 0x5613, L"NPort 5610-16", 0 }
                            , { 0x80005610, 0x5638, L"NPort 5630-8", 0 }
                            , { 0x80005610, 0x5633, L"NPort 5630-16", 0 }
                            , { 0x80005610, 0x5658, L"NPort 5650-8", 0 }
                            , { 0x80005610, 0x5653, L"NPort 5650-16", 0 }

                            , { 0x80015610, 0x5700, L"NPort 5610-8-DT", 0 }
                            , { 0x80015610, 0x5702, L"NPort 5650-8-DT", 0 }
                            , { 0x80015610, 0x5703, L"NPort 5650I-8-DT", 0 }
                            , { 0x80015610, 0x5704, L"NPort 5610-8-DT-J", 0 }
                            , { 0x80015610, 0x5706, L"NPort 5650-8-DT-J", 0 }

                            };
    for(SIZE_T i = 0; i!=(sizeof(pi)/sizeof(pi[0])); ++i )
       {
        if (pi[i].appId==appId && pi[i].hwId==hwId) return &pi[i];
       }
    return 0;
   }

::std::wstring getMoxaProductNameById( DWORD appId, WORD hwId)
   {
    CMoxaProductInfo* ppi = findMoxaProductInfo( appId, hwId );
    if (!ppi) return ::std::wstring(L"Unknown");
    return ::std::wstring(ppi->productName);
   }


//STRUCT_CLI_INET_IPADDRESS

/* inline
 * UINT64 macToUint(const BYTE *macAddr)
 */

// moxa server info flags
// indicates that apropriate info received from srvers
const int msifAppId              = 0x0001;
const int msifHwId               = 0x0002;
const int msifMac                = 0x0004;
const int msifDeviceId           = 0x0007; // msifAppId|msifHwId|msifMac
const int msifSerialNum          = 0x0008;
const int msifProductName        = 0x0010;
const int msifServerName         = 0x0020;
const int msifServerAddr         = 0x0040;
const int msifUdpCommonPort      = 0x0080;
const int msifPortsInfoOpts      = 0x0100;
const int msifPortsInfoOpMode    = 0x0200;
const int msifPortsInfoTcpPorts  = 0x0400;

const int msifAll                = 0x07FF;
const int msifAllNoPorts         = 0x00FF;


struct CServerInfoEx
{
    int                               infoFlags;
    STRUCT_CLI_MOXA_CMOXASERVERINFO   info;
    //STRUCT_CLI_INET_IPADDRESS         serverRealAddr;
};


/*
STRUCT_CLI_MOXA_CMOXASERVERINFO
    dword                      appId;
    word                       hardwareId;
    byte                       macAddress[6];
    dword                      serialNumber;
    wchar                      productName[32];
    wchar                      serverName[32];

    ::cli::inet::IpAddress     serverAddr;
    uint                       udpCommonPort;

    size_t                     numberOfPorts;
    uint                       portMode[16]; // max 16 ports per server
*/

struct predIsAllInfoReceived
{
    int mask;
    predIsAllInfoReceived(int m) : mask(m) {}

    bool operator()( const ::std::map< UINT64 , CServerInfoEx >::value_type &v)
       {
        if ((v.second.infoFlags&mask)==mask) return true;
        return false;
       }
};

struct predNotAllInfoReceived
{
    int mask;
    predNotAllInfoReceived(int m) : mask(m) {}
    
    bool operator()( const ::std::map< UINT64 , CServerInfoEx >::value_type &v)
       {
        if ((v.second.infoFlags&mask)==mask) return false;
        return true;
       }
};


inline
bool checkServersInfoFull( const ::std::map< UINT64 , CServerInfoEx > &infoMap )
   {
    //if (infoMap.empty()) return false;
    // ���� ��������, ��� ������� ������� �� ��� ����������
    // ���� �������, �� ������ ���� ���-�� �� �����
    //if ( ::std::find_if( infoMap.begin(), infoMap.end(), predNotAllInfoReceived(msifAllNoPorts) ) != infoMap.end() )
    if ( ::std::find_if( infoMap.begin(), infoMap.end(), predNotAllInfoReceived(msifAll) ) != infoMap.end() )
       return false;
    return true;
   }


//bool ::cli::inet::isEqualAddr(const STRUCT_CLI_INET_IPADDRESS &ip1, const STRUCT_CLI_INET_IPADDRESS &ip2)
inline
RCODE searchForServersImpl( ::std::map< UINT64 , STRUCT_CLI_INET_IPADDRESS > &mac2ip
                          , ::std::map< UINT64 , CServerInfoEx > &infoMap
                          , ::cli::inet::CiResolver &resolver
                          , const STRUCT_CLI_INET_IPADDRESS &serverIpAddr
                          , TICK_T timeoutFixed     // fixed part of timeout
                          , TICK_T timeoutPerServer // per server timeout
                          )
   {
    CLI_TRY{
            ::cli::inet::CiUdpServer srv("/cli/inet/udp-server");

            ::cli::inet::CiSocket sock;
            RCODE res = srv.createUdpClientSocket( AF_INET, sock.getPP() );
            CLI_THROW_IF_NOK(res);

            sock.broadcastModeSet(TRUE);
            STRUCT_CLI_INET_SOCKETADDRESS servSockAddr = ::cli::inet::sockAddrFromIpAddr(serverIpAddr, 4800);

            const SIZE_T maxServers = 1024;

            BYTE initialQueryBuf[sizeof(STRUCT_CLI_MOXA_CPACKETHEADER) + maxServers*sizeof(STRUCT_CLI_MOXA_CDEVICEIDSTRUCT)];
            STRUCT_CLI_MOXA_CCOMMONREQUEST *pCommonRequest = (STRUCT_CLI_MOXA_CCOMMONREQUEST*)&initialQueryBuf[0];

            //SIZE_T numBytesToWrite = sizeof(STRUCT_CLI_MOXA_CPACKETHEADER) + infoMap.size()*sizeof(STRUCT_CLI_MOXA_CDEVICEIDSTRUCT);
            SIZE_T numBytesToWrite = sizeof(STRUCT_CLI_MOXA_CPACKETHEADER);

            pCommonRequest->header.pktid  = 0x01;
            pCommonRequest->header.result = 0;
            pCommonRequest->header.id     = 0;
            pCommonRequest->header.pktLen = htons( (USHORT)numBytesToWrite );

            // �������� ����� ��� ���� �����
            SIZE_T numBytesWritten;

            
            RCODE rc = sock.sendToTimeout( (VOID*)initialQueryBuf, numBytesToWrite, &numBytesWritten, servSockAddr, 1000);
            if (rc) return rc;

            // �������� ������, ��������������� �������� ��� ��������� � ���� ����������

            if (::cli::inet::isBroadcastAddr(servSockAddr))
               {
                SIZE_T cnt = 0;
                for( ::std::map< UINT64 , CServerInfoEx >::const_iterator imIt = infoMap.begin()
                   ; imIt!=infoMap.end()
                   ; ++imIt, ++cnt
                   )
                   {
                    pCommonRequest->deviceId[cnt] = imIt->second.info.deviceId;
                    numBytesToWrite = sizeof(STRUCT_CLI_MOXA_CPACKETHEADER) + cnt*sizeof(STRUCT_CLI_MOXA_CDEVICEIDSTRUCT);
                    pCommonRequest->header.pktLen = htons( (USHORT)numBytesToWrite );
                    sock.sendToTimeout( (VOID*)initialQueryBuf, numBytesToWrite, &numBytesWritten, servSockAddr, 1000);
                   }
               }

            TICK_T startTick = cliGetTickCount();

            while( 1 )
                {
                 TICK_DIFF_T timeout = (TICK_DIFF_T)(timeoutFixed + infoMap.size()*timeoutPerServer);
                 if (cliGetCurrentTickDiff(startTick) >= timeout) break;

                 if (cliGetCurrentTickDiff(startTick)>(TICK_DIFF_T)timeoutFixed && !infoMap.empty() && checkServersInfoFull(infoMap))
                    break;

                 STRUCT_CLI_INET_SOCKETADDRESS sockAddrFrom;
                 BYTE recvBuf[8192];
                 SIZE_T receivedCount = 0;
                 rc = sock.recvFromTimeout( (VOID*)recvBuf, sizeof(recvBuf)
                                          , &receivedCount, sockAddrFrom
                                          , 500
                                          );
                 if (rc) continue;

                 if (receivedCount<sizeof(STRUCT_CLI_MOXA_CPACKETHEADER))
                    continue;
                 
                 STRUCT_CLI_MOXA_CPACKETHEADER *pktHeader = (STRUCT_CLI_MOXA_CPACKETHEADER*)&recvBuf[0];
                 if (pktHeader->result!=0) // unknown result code, don't process
                    continue;

                 if (ntohs(pktHeader->pktLen)!=receivedCount)
                    continue; // invalid len of packet


                 if (  receivedCount==sizeof(STRUCT_CLI_MOXA_CDEVICEINFO4PACKET) 
                    && pktHeader->pktid==0x81
                    )
                    { // parse common server info reply
                     STRUCT_CLI_MOXA_CDEVICEINFO4PACKET *pkt = (STRUCT_CLI_MOXA_CDEVICEINFO4PACKET*)&recvBuf[0];

                     STRUCT_CLI_INET_IPADDRESS ipAddr;
                     /*
                     ipAddr.af = AF_INET;
                     ipAddr.addr[0] = (USHORT)pkt->ipAddress[0];
                     ipAddr.addr[1] = (USHORT)pkt->ipAddress[1];
                     ipAddr.addr[2] = (USHORT)pkt->ipAddress[2];
                     ipAddr.addr[3] = (USHORT)pkt->ipAddress[3];
                     */
                     ipAddr.af = sockAddrFrom.af;
                     ipAddr.addr[0] = sockAddrFrom.addr[0];
                     ipAddr.addr[1] = sockAddrFrom.addr[1];
                     ipAddr.addr[2] = sockAddrFrom.addr[2];
                     ipAddr.addr[3] = sockAddrFrom.addr[3];
                     ipAddr.addr[4] = sockAddrFrom.addr[4];
                     ipAddr.addr[5] = sockAddrFrom.addr[5];
                     ipAddr.addr[6] = sockAddrFrom.addr[6];
                     ipAddr.addr[7] = sockAddrFrom.addr[7];

                     UINT64 mac64  = ::cli::inet::macToUint( &pkt->header.deviceId.macAddress[0] );
                     mac2ip[mac64] = ipAddr;

                     CServerInfoEx newIinfoEx;
                     memset( (void*)&newIinfoEx, 0, sizeof(newIinfoEx) );

                     CServerInfoEx *pInfoEx = &newIinfoEx;
                     ::std::map< UINT64 , CServerInfoEx >::iterator imIt = infoMap.find(mac64);
                     if (imIt!=infoMap.end())
                        pInfoEx = &imIt->second;

                     if ( (pInfoEx->infoFlags&msifDeviceId )!=msifDeviceId)
                        {
                         pInfoEx->info.deviceId = pkt->header.deviceId;
                         pInfoEx->infoFlags |= msifDeviceId;
                        }

                     if (!(pInfoEx->infoFlags&msifServerAddr))
                        {
                         pInfoEx->info.serverAddr = ipAddr;
                         pInfoEx->infoFlags |= msifServerAddr;
                        }

                     if (!(pInfoEx->infoFlags&msifUdpCommonPort))
                        {
                         pInfoEx->info.udpCommonPort = sockAddrFrom.port;
                         pInfoEx->infoFlags |= msifUdpCommonPort;
                        }

                     // serial number request
                        {
                         STRUCT_CLI_MOXA_CREQUESTPACKET snRequest = { 0 };
                         //snRequest.header        = pkt.header; // copy full header
                         snRequest        = pkt->header; // copy full header
                         snRequest.pktid  = 0x16;
                         snRequest.pktLen = htons(sizeof(snRequest));
                         sock.sendToTimeout( (VOID*)&snRequest, sizeof(snRequest), &numBytesWritten, sockAddrFrom, 500);
                        }

                     // Sending port state request - speed, data bits, stop bits etc
                        {
                         STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET psStateQuery;
                         psStateQuery.header        = pkt->header;
                         psStateQuery.header.pktid  = 0x31;
                         psStateQuery.header.pktLen = htons((USHORT)sizeof(psStateQuery));
                         psStateQuery.cmd           = htons(1);
                         sock.sendToTimeout( (VOID*)&psStateQuery, sizeof(psStateQuery), &numBytesWritten, sockAddrFrom, 1000);
                        }
                     // Sending operating mode request - Real Com, TCP server or other
                        {
                         STRUCT_CLI_MOXA_COPMODEREQUESRPACKET opModeRequest;
                         opModeRequest.header        = pkt->header; // copy full header
                         opModeRequest.header.pktid  = 0x41;
                         opModeRequest.header.pktLen = htons((USHORT)sizeof(opModeRequest));
                         opModeRequest.cmd           = 0;
                         sock.sendToTimeout( (VOID*)&opModeRequest, sizeof(opModeRequest), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_CPORTALIASREQUESTPACKET portAliasRequest;
                         portAliasRequest.header = pkt->header;
                         portAliasRequest.header.pktid  = 0x37;
                         portAliasRequest.header.pktLen = htons((USHORT)sizeof(portAliasRequest));
                         portAliasRequest.cmd = 0;
                         sock.sendToTimeout( (VOID*)&portAliasRequest, sizeof(portAliasRequest), &numBytesWritten, sockAddrFrom, 1000);
                        }
                     // TCP Ports request
                        {
                         STRUCT_CLI_MOXA_CTCPSERVERINFOREQUESTPACKET tcpServerRequest;
                         tcpServerRequest.header = pkt->header;
                         tcpServerRequest.header.pktid  = 0x4F;
                         tcpServerRequest.header.pktLen = htons((USHORT)sizeof(tcpServerRequest));
                         tcpServerRequest.cmd = 0;
                         sock.sendToTimeout( (VOID*)&tcpServerRequest, sizeof(tcpServerRequest), &numBytesWritten, sockAddrFrom, 1000);
                        }

                     if (!(pInfoEx->infoFlags&msifProductName))
                        {
                         ::std::wstring productName = getMoxaProductNameById( pkt->header.deviceId.appId, pkt->header.deviceId.hardwareId );
                         //pInfoEx->info.udpCommonPort = sockAddrFrom.port;
                         size_t maxLen = sizeof(pInfoEx->info.productName)/sizeof(pInfoEx->info.productName[0]) - 1;
                         if (productName.size()<maxLen) maxLen = productName.size();
                         productName.copy( pInfoEx->info.productName, maxLen, 0 );
                         pInfoEx->info.productName[maxLen] = 0;
                         pInfoEx->infoFlags |= msifProductName;
                        }
                     if (imIt==infoMap.end())
                        {
                         infoMap[mac64] = *pInfoEx;
                        }
                    }
                 else if (receivedCount==sizeof(STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET) &&pktHeader->pktid==0x96)
                    {
                     STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET *snPkt = (STRUCT_CLI_MOXA_CDEVICESERIALNUMBERPACKET*)&recvBuf[0];

                     UINT64 mac64  = ::cli::inet::macToUint( &snPkt->header.deviceId.macAddress[0] );
                     CServerInfoEx *pInfoEx = &infoMap[mac64];

                     if (!(pInfoEx->infoFlags&msifSerialNum))
                        {
                         pInfoEx->info.serialNumber = snPkt->serialNumber;
                         pInfoEx->infoFlags |= msifSerialNum;
                        }

                     STRUCT_CLI_MOXA_CREQUESTPACKET servNameRequest = { 0 };
                     servNameRequest = snPkt->header;
                     servNameRequest.pktid  = 0x10;
                     servNameRequest.pktLen = htons(sizeof(servNameRequest));

                     sock.sendToTimeout( (VOID*)&servNameRequest, sizeof(servNameRequest), &numBytesWritten, servSockAddr, 500);
                    }
                 else if (receivedCount>=sizeof(STRUCT_CLI_MOXA_CPACKETFULLHEADER) &&pktHeader->pktid==0x90)
                    {
                     STRUCT_CLI_MOXA_CPACKETFULLHEADER *pkt = (STRUCT_CLI_MOXA_CPACKETFULLHEADER*)&recvBuf[0];
                     UINT64 mac64  = ::cli::inet::macToUint( &pkt->deviceId.macAddress[0] );
                     CServerInfoEx *pInfoEx = &infoMap[mac64];

                     //server name
                     if (!(pInfoEx->infoFlags&msifServerName))
                        {
                         SIZE_T pktLimCnt = sizeof(STRUCT_CLI_MOXA_CPACKETFULLHEADER);
                         const char *serverName = (char*)&recvBuf[pktLimCnt];
                         const char *tmp = serverName;
                         //SIZE_T nameLen = 0;
                         ::std::wstring wServerName;
                         for(; pktLimCnt!=receivedCount && *tmp; ++pktLimCnt, ++tmp) 
                            {
                             wServerName.append( 1, (WCHAR)(UCHAR)*tmp);
                            }

                         size_t maxLen = sizeof(pInfoEx->info.productName)/sizeof(pInfoEx->info.productName[0]) - 1;
                         if (wServerName.size()<maxLen) maxLen = wServerName.size();
                         wServerName.copy( pInfoEx->info.serverName, maxLen, 0 );
                         pInfoEx->info.serverName[maxLen] = 0;
                         pInfoEx->infoFlags |= msifServerName;
                        }

                    }
                 else if (receivedCount>=sizeof(STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED) &&pktHeader->pktid==0xB1)
                    {
                     STRUCT_CLI_MOXA_CPORTSTATEPACKET *pkt = (STRUCT_CLI_MOXA_CPORTSTATEPACKET*)&recvBuf[0];
                     UINT64 mac64  = ::cli::inet::macToUint( &pkt->header.deviceId.macAddress[0] );
                     CServerInfoEx *pInfoEx = &infoMap[mac64];

                     if (!(pInfoEx->infoFlags&msifPortsInfoOpts))
                        {
                         pInfoEx->infoFlags |= msifPortsInfoOpts;

                         size_t portCount = (receivedCount - sizeof(STRUCT_CLI_MOXA_CPORTSTATEPACKETFIXED)) / sizeof(STRUCT_CLI_MOXA_CPORTSTATEDATA);
                         pInfoEx->info.numberOfPorts = portCount;

                         for(size_t portNo=0; portNo!=portCount; ++portNo)
                            {
                             unsigned speed = pkt->portInfo[portNo].speed;
                             if (speed==0xC200)       speed = 0x1C200;
                             else if (speed==0x8400)  speed = 0x38400;
                             else if (speed==0x0800)  speed = 0x70800;
                             else if (speed==0x1000)  speed = 0xE1000;

                             pInfoEx->info.portInfo[portNo].options.baudRate = speed;
                             pInfoEx->info.portInfo[portNo].options.dataBits = pkt->portInfo[portNo].dataBits+5;
                             pInfoEx->info.portInfo[portNo].options.stopBits = pkt->portInfo[portNo].stopBits+1;
                             if (!pkt->portInfo[portNo].fParity)
                                pInfoEx->info.portInfo[portNo].options.parity = CLI_IO_SERIAL_PARITY_NONE;
                             else
                                {
                                 static
                                 ENUM_CLI_IO_SERIAL_PARITY serialParityVals[] = { CLI_IO_SERIAL_PARITY_ODD
                                                                                , CLI_IO_SERIAL_PARITY_EVEN
                                                                                , CLI_IO_SERIAL_PARITY_MARK
                                                                                , CLI_IO_SERIAL_PARITY_SPACE
                                                                                };
                                 pInfoEx->info.portInfo[portNo].options.parity = serialParityVals[pkt->portInfo[portNo].parity];
                                }
                            }
                        }
                    }
                 else if (receivedCount>=sizeof(STRUCT_CLI_MOXA_COPMODEPACKETFIXED) &&pktHeader->pktid==0xC1)
                    {
                     STRUCT_CLI_MOXA_COPMODEPACKET *pkt = (STRUCT_CLI_MOXA_COPMODEPACKET*)&recvBuf[0];
                     UINT64 mac64  = ::cli::inet::macToUint( &pkt->header.deviceId.macAddress[0] );
                     CServerInfoEx *pInfoEx = &infoMap[mac64];

                     if (!(pInfoEx->infoFlags&msifPortsInfoOpts))
                        { // resend port state request 
                         STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET psStateQuery;
                         psStateQuery.header        = pkt->header;
                         psStateQuery.header.pktid  = 0x31;
                         psStateQuery.header.pktLen = htons((USHORT)sizeof(psStateQuery));
                         psStateQuery.cmd           = htons(1);
                         sock.sendToTimeout( (VOID*)&psStateQuery, sizeof(psStateQuery), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_COPMODEREQUESRPACKET opModeRequest;
                         opModeRequest.header        = pkt->header; // copy full header
                         opModeRequest.header.pktid  = 0x41;
                         opModeRequest.header.pktLen = htons((USHORT)sizeof(opModeRequest));
                         opModeRequest.cmd           = 0;
                         sock.sendToTimeout( (VOID*)&opModeRequest, sizeof(opModeRequest), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_CPORTALIASREQUESTPACKET portAliasRequest;
                         portAliasRequest.header = pkt->header;
                         portAliasRequest.header.pktid  = 0x37;
                         portAliasRequest.header.pktLen = htons((USHORT)sizeof(portAliasRequest));
                         portAliasRequest.cmd = 0;
                         sock.sendToTimeout( (VOID*)&portAliasRequest, sizeof(portAliasRequest), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_CTCPSERVERINFOREQUESTPACKET tcpServerRequest;
                         tcpServerRequest.header = pkt->header;
                         tcpServerRequest.header.pktid  = 0x4F;
                         tcpServerRequest.header.pktLen = htons((USHORT)sizeof(tcpServerRequest));
                         tcpServerRequest.cmd = 0;
                         sock.sendToTimeout( (VOID*)&tcpServerRequest, sizeof(tcpServerRequest), &numBytesWritten, sockAddrFrom, 1000);
                        }
                     else if (!(pInfoEx->infoFlags&msifPortsInfoOpMode))
                        {    
                         pInfoEx->infoFlags |= msifPortsInfoOpMode;

                         size_t portCount = (receivedCount - sizeof(STRUCT_CLI_MOXA_COPMODEPACKETFIXED)) / sizeof(STRUCT_CLI_MOXA_CPORTOPMODEDATA);
                         if (pInfoEx->info.numberOfPorts < portCount)
                            portCount = pInfoEx->info.numberOfPorts;

                         for(size_t portNo=0; portNo!=portCount; ++portNo)
                            pInfoEx->info.portInfo[portNo].opMode = pkt->opMode[portNo].opMode;
                        }
                    }
                 else if (receivedCount>=sizeof(STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED) &&pktHeader->pktid==0xB7)
                    {
                     STRUCT_CLI_MOXA_CPORTALIASPACKET *pkt = (STRUCT_CLI_MOXA_CPORTALIASPACKET*)&recvBuf[0];
                     UINT64 mac64  = ::cli::inet::macToUint( &pkt->header.deviceId.macAddress[0] );
                     CServerInfoEx *pInfoEx = &infoMap[mac64];

                     size_t portCount = (receivedCount - sizeof(STRUCT_CLI_MOXA_CPORTALIASPACKETFIXED)) / sizeof(STRUCT_CLI_MOXA_CPORTALIASPORTDATA);
                     for(size_t portNo=0; portNo!=portCount; ++portNo)
                        {
                         size_t chNo=0;
                         for(; chNo!=sizeof(pkt->aliases[portNo].portAlias) && pkt->aliases[portNo].portAlias[chNo]; ++chNo)
                            {
                             pInfoEx->info.portInfo[portNo].portAlias[chNo] = (WCHAR)(unsigned char)pkt->aliases[portNo].portAlias[chNo];
                            }
                         pInfoEx->info.portInfo[portNo].portAlias[chNo] = 0;
                        }
                    }
                 else if (receivedCount>=sizeof(STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED) &&pktHeader->pktid==0xCF)
                    {
                     STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET *pkt = (STRUCT_CLI_MOXA_CTCPSERVERINFOPACKET*)&recvBuf[0];
                     UINT64 mac64  = ::cli::inet::macToUint( &pkt->header.deviceId.macAddress[0] );
                     CServerInfoEx *pInfoEx = &infoMap[mac64];

                     if (!(pInfoEx->infoFlags&msifPortsInfoOpts))
                        { // resend port state request 
                         STRUCT_CLI_MOXA_CPORTSTATEREQUESTPACKET psStateQuery;
                         psStateQuery.header        = pkt->header;
                         psStateQuery.header.pktid  = 0x31;
                         psStateQuery.header.pktLen = htons((USHORT)sizeof(psStateQuery));
                         psStateQuery.cmd           = htons(1);
                         sock.sendToTimeout( (VOID*)&psStateQuery, sizeof(psStateQuery), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_COPMODEREQUESRPACKET opModeRequest;
                         opModeRequest.header        = pkt->header; // copy full header
                         opModeRequest.header.pktid  = 0x41;
                         opModeRequest.header.pktLen = htons((USHORT)sizeof(opModeRequest));
                         opModeRequest.cmd           = 0;
                         sock.sendToTimeout( (VOID*)&opModeRequest, sizeof(opModeRequest), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_CPORTALIASREQUESTPACKET portAliasRequest;
                         portAliasRequest.header = pkt->header;
                         portAliasRequest.header.pktid  = 0x37;
                         portAliasRequest.header.pktLen = htons((USHORT)sizeof(portAliasRequest));
                         portAliasRequest.cmd = 0;
                         sock.sendToTimeout( (VOID*)&portAliasRequest, sizeof(portAliasRequest), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_CTCPSERVERINFOREQUESTPACKET tcpServerRequest;
                         tcpServerRequest.header = pkt->header;
                         tcpServerRequest.header.pktid  = 0x4F;
                         tcpServerRequest.header.pktLen = htons((USHORT)sizeof(tcpServerRequest));
                         tcpServerRequest.cmd = 0;
                         sock.sendToTimeout( (VOID*)&tcpServerRequest, sizeof(tcpServerRequest), &numBytesWritten, sockAddrFrom, 1000);
                        }
                     else if (!(pInfoEx->infoFlags&msifPortsInfoOpMode))
                        {// port options good, don't need to rerequest
                         // rerequest opmode
                         STRUCT_CLI_MOXA_COPMODEREQUESRPACKET opModeRequest;
                         opModeRequest.header        = pkt->header; // copy full header
                         opModeRequest.header.pktid  = 0x41;
                         opModeRequest.header.pktLen = htons((USHORT)sizeof(opModeRequest));
                         opModeRequest.cmd           = 0;
                         sock.sendToTimeout( (VOID*)&opModeRequest, sizeof(opModeRequest), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_CPORTALIASREQUESTPACKET portAliasRequest;
                         portAliasRequest.header = pkt->header;
                         portAliasRequest.header.pktid  = 0x37;
                         portAliasRequest.header.pktLen = htons((USHORT)sizeof(portAliasRequest));
                         portAliasRequest.cmd = 0;
                         sock.sendToTimeout( (VOID*)&portAliasRequest, sizeof(portAliasRequest), &numBytesWritten, sockAddrFrom, 1000);

                         STRUCT_CLI_MOXA_CTCPSERVERINFOREQUESTPACKET tcpServerRequest;
                         tcpServerRequest.header = pkt->header;
                         tcpServerRequest.header.pktid  = 0x4F;
                         tcpServerRequest.header.pktLen = htons((USHORT)sizeof(tcpServerRequest));
                         tcpServerRequest.cmd = 0;
                         sock.sendToTimeout( (VOID*)&tcpServerRequest, sizeof(tcpServerRequest), &numBytesWritten, sockAddrFrom, 1000);
                        }
                     else if (!(pInfoEx->infoFlags&msifPortsInfoTcpPorts))
                        {
                         pInfoEx->infoFlags |= msifPortsInfoTcpPorts;

                         size_t portCount = (receivedCount - sizeof(STRUCT_CLI_MOXA_CTCPSERVERINFOPACKETFIXED)) / sizeof(STRUCT_CLI_MOXA_CTCPSERVERPORTINFODATA);
                         if (pInfoEx->info.numberOfPorts < portCount)
                            portCount = pInfoEx->info.numberOfPorts;

                         for(size_t portNo=0; portNo!=portCount; ++portNo)
                            {
                             if (pInfoEx->info.portInfo[portNo].opMode==CLI_MOXA_PORTOPMODE_REALCOM)
                                {
                                 pInfoEx->info.portInfo[portNo].tcpDataPort    = (USHORT)(950+portNo);
                                 pInfoEx->info.portInfo[portNo].tcpCommandPort = (USHORT)(966+portNo);
                                }
                             else if (pInfoEx->info.portInfo[portNo].opMode==CLI_MOXA_PORTOPMODE_TCPSERVER)
                                {
                                 pInfoEx->info.portInfo[portNo].tcpDataPort    = pkt->portInfo[portNo].dataPort;
                                 pInfoEx->info.portInfo[portNo].tcpCommandPort = pkt->portInfo[portNo].commandPort;
                                }
                            }
                        }
                    }
                }
           }
    CLI_CATCH_RETURN_CLI_EXCEPTION()
    CLI_CATCH_RETURN_STD_EXCEPTIONS()
    return EC_OK;
   }



struct CMoxaFinderImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                        , public INTERFACE_CLI_MOXA_IMOXAFINDER
{

    ::std::vector< ::std::wstring >                  searchAddrList;
    ::std::vector<STRUCT_CLI_MOXA_CMOXASERVERINFO>   serverList;

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    CMoxaFinderImpl()
       : base_impl(DEF_MODULE)
       , searchAddrList()
       , serverList()
       {}

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CMoxaFinderImpl, INTERFACE_CLI_MOXA_IMOXAFINDER)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_MOXA_IMOXAFINDER )
    CLI_END_INTERFACE_MAP(CMoxaFinderImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }

    CLIMETHOD(searchAddressListGet) (THIS_ CLISTR*           searchAddressListItem
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    )
        {
         if (!searchAddressListItem) return EC_INVALID_PARAM;
         if (idx1>=searchAddrList.size()) return EC_OUT_OF_RANGE;

         if (searchAddressListItem) CCliStr_copyTo(searchAddressListItem , searchAddrList[idx1] );
         return EC_OK;
        }

    CLIMETHOD(searchAddressListSet) (THIS_ const CLISTR*     searchAddressListItem
                                         , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    )
        {
         if (!searchAddressListItem) return EC_INVALID_PARAM;
         if (idx1>=searchAddrList.size())
            {
             searchAddrList.push_back( stdstr(searchAddressListItem) );
            }
         else
            {
             searchAddrList[idx1] = stdstr(searchAddressListItem);
            }
         return EC_OK;
        }

    CLIMETHOD(searchAddressListSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
        {
         if (!size) return EC_INVALID_PARAM;
         *size = searchAddrList.size();
         return EC_OK;
        }

    CLIMETHOD(clearAll) (THIS)
        {
         searchAddrList.clear();
         serverList.clear();
         return EC_OK;
        }

    CLIMETHOD(foundServersGet) (THIS_ STRUCT_CLI_MOXA_CMOXASERVERINFO*    foundServersItem /* [out] ::cli::moxa::CMoxaServerInfo foundServers  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
        {
         if (!foundServersItem)       return EC_INVALID_PARAM;
         if (idx1>=serverList.size()) return EC_OUT_OF_RANGE;
         *foundServersItem = serverList[idx1];
         return EC_OK;
        }

    CLIMETHOD(foundServersSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
        {
         if (!size) return EC_INVALID_PARAM;
         *size = serverList.size();
         return EC_OK;
        }

    CLIMETHOD(searchForServers) (THIS_ SIZE_T    tryCount /* [in] size_t  tryCount  */
                                     , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                     , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                )
        {
         RCODE lastRes = EC_OK;
         CLI_TRY{
                 ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                 ::std::map< UINT64 , STRUCT_CLI_INET_IPADDRESS > mac2ip;
                 ::std::map< UINT64 , CServerInfoEx >             infoMap;

                 if (tryCount>32) tryCount = 32;

                 if (searchAddrList.empty()) searchAddrList.push_back( ::std::wstring(L"*") );
                 ::std::vector< ::std::wstring >::const_iterator saIt = searchAddrList.begin();
                 for(; saIt!=searchAddrList.end(); ++saIt)
                    {
                     RCODE res = 0;
                     STRUCT_CLI_INET_IPADDRESS serverIpAddr;
                     if (*saIt==L"*")
                         {
                          //res = resolver.makeBroadcastIpAddr( AF_INET, serverIpAddr );
                          res = resolver.makeByTypeIpAddr( AF_INET, CLI_INET_EMULTICASTADDRESSTYPE_BROADCAST, serverIpAddr );
                         }
                     else
                        {
                         res = resolver.getHostInfoByName( *saIt, AF_INET );
                         if (!res)
                            {
                             res = resolver.addrListGet( serverIpAddr, 0 ); // ���������� ������ ���������� �����
                            }
                        }

                     if (!lastRes) lastRes = res;
                     if (res) continue;

                     for(SIZE_T tryNo = 0; tryNo!=tryCount; ++tryNo)
                        {
                         res = searchForServersImpl( mac2ip, infoMap, resolver, serverIpAddr, timeoutFixed, timeoutMultiplier );
                         if (res) break;
                        }
                     if (!lastRes) lastRes = res;
                    }
        
                 // ::std::vector<STRUCT_CLI_MOXA_CMOXASERVERINFO>   serverList;
                 serverList.reserve(serverList.size() + infoMap.size());
                 ::std::map< UINT64 , CServerInfoEx >::const_iterator imIt = infoMap.begin();
                 for(; imIt!=infoMap.end(); ++imIt)
                    {
                     serverList.push_back( imIt->second.info );
                    }

                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return lastRes;
        }



}; // struct CMoxaManagerImpl





struct CMoxaManagerImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                        , public INTERFACE_CLI_MOXA_IMOXAMANAGER
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    CMoxaManagerImpl()
       : base_impl(DEF_MODULE)
       {}

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CMoxaManagerImpl, INTERFACE_CLI_MOXA_IMOXAMANAGER)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_MOXA_IMOXAMANAGER )
    CLI_END_INTERFACE_MAP(CMoxaManagerImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


    CLIMETHOD(createFinder) (THIS_ INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                 , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                 , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                 , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                            )
        {
         if (!finder) return EC_INVALID_PARAM;
         CLI_TRY{
                 *finder = 0;
                 ::cli::moxa::CiMoxaFinder newFinder( new CMoxaFinderImpl(), true ); // noAddRef
                 newFinder.searchAddressListSet( ::std::wstring(L"*"), 0 );
                 RCODE res = newFinder.searchForServers( tryCount, timeoutFixed, timeoutMultiplier );
                 if (res) return res;
                 *finder = newFinder.getIfPtr();
                 (*finder)->addRef();
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_OK;
        }

    CLIMETHOD(createFinderEx) (THIS_ const CLISTR*     srvAddrMask
                                   , INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                   , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                   , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                   , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                              )
        {
         if (!finder) return EC_INVALID_PARAM;
         CLI_TRY{
                 *finder = 0;
                 ::cli::moxa::CiMoxaFinder newFinder( new CMoxaFinderImpl(), true ); // noAddRef
                 newFinder.searchAddressListSet( stdstr(srvAddrMask), 0 );
                 RCODE res = newFinder.searchForServers( tryCount, timeoutFixed, timeoutMultiplier );
                 if (res) return res;
                 *finder = newFinder.getIfPtr();
                 (*finder)->addRef();
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_OK;
        }

    CLIMETHOD(createFinderExList) (THIS_ INTERFACE_CLI_IARGLIST*    addrList /* [in] ::cli::iArgList*  addrList  */
                                       , INTERFACE_CLI_MOXA_IMOXAFINDER**    finder /* [out] ::cli::moxa::iMoxaFinder* finder  */
                                       , SIZE_T    tryCount /* [in] size_t  tryCount  */
                                       , TICK_T    timeoutFixed /* [in] tick_t  timeoutFixed  */
                                       , TICK_T    timeoutMultiplier /* [in] tick_t  timeoutMultiplier  */
                                  )
        {
         if (!finder || !addrList) return EC_INVALID_PARAM;
         CLI_TRY{
                 *finder = 0;
                 ::cli::moxa::CiMoxaFinder newFinder( new CMoxaFinderImpl(), true ); // noAddRef

                 SIZE_T argsNum = addrList->getCount();
                 SIZE_T idx = 0;
                 for(; idx!=argsNum; ++idx)
                    {
                     CCliStr tmp_str; CCliStr_init( tmp_str );
                     addrList->getString( idx , &tmp_str );
                     ::std::wstring str;
                     CCliStr_copyFromIfModified( str, tmp_str);
                     newFinder.searchAddressListSet( str, idx );
                    }
                 addrList->release();

                 RCODE res = newFinder.searchForServers( tryCount, timeoutFixed, timeoutMultiplier );
                 if (res) return res;
                 *finder = newFinder.getIfPtr();
                 (*finder)->addRef();
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_OK;
        }

    CLIMETHOD(updateServerInfo) (THIS_ STRUCT_CLI_MOXA_CMOXASERVERINFO*    srvInfo /* [in,out] ::cli::moxa::CMoxaServerInfo srvInfo  */)
        {
         if (!srvInfo) return EC_INVALID_PARAM;
         RCODE lastRes = EC_OK;
         CLI_TRY{
                 ::cli::inet::CiResolver resolver("/cli/inet/std-resolver");
                 ::std::map< UINT64 , STRUCT_CLI_INET_IPADDRESS > mac2ip;
                 ::std::map< UINT64 , CServerInfoEx >             infoMap;

                 STRUCT_CLI_INET_IPADDRESS serverIpAddr = srvInfo->serverAddr;

                 lastRes = searchForServersImpl( mac2ip, infoMap, resolver, serverIpAddr, 2000, 500 );

                 if (lastRes) return lastRes;
        
                 ::std::map< UINT64 , CServerInfoEx >::const_iterator imIt = infoMap.begin();
                 for(; imIt!=infoMap.end(); ++imIt)
                    {
                     if (memcmp(&imIt->second.info.serverAddr, &srvInfo->serverAddr, sizeof(srvInfo->serverAddr)))
                        {
                         *srvInfo = imIt->second.info;
                         return lastRes;
                        }
                    }
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_NOT_FOUND;
        }

    CLIMETHOD(serverBeep) (THIS_ const STRUCT_CLI_MOXA_CMOXASERVERINFO*    mxSrvInfo /* [in,ref] ::cli::moxa::CMoxaServerInfo  srv  */
                               , BOOL    beepONOff /* [in] bool  beepONOff  */
                          )
        {
         if (!mxSrvInfo) return EC_INVALID_PARAM;
         if (!mxSrvInfo->deviceId.appId || !mxSrvInfo->deviceId.hardwareId) return EC_INVALID_PARAM;

         if (::cli::inet::isBroadcastAddr(mxSrvInfo->serverAddr)) return EC_INVALID_PARAM;

         CLI_TRY{

                 ::cli::inet::CiUdpServer srv("/cli/inet/udp-server");
         
                 ::cli::inet::CiSocket sock;
                 RCODE res = srv.createUdpClientSocket( AF_INET, sock.getPP() );
                 CLI_THROW_IF_NOK(res);

                 STRUCT_CLI_INET_SOCKETADDRESS servSockAddr = ::cli::inet::sockAddrFromIpAddr(mxSrvInfo->serverAddr, mxSrvInfo->udpCommonPort);

                 STRUCT_CLI_MOXA_CBEEPCONTROLPACKET beepPkt;
                 beepPkt.header.deviceId = mxSrvInfo->deviceId;
                 beepPkt.header.result = 0;
                 beepPkt.header.id     = 0;
                 beepPkt.header.pktid  = 0x02;
                 beepPkt.beepCmd = beepONOff ? 1 : 0;

                 SIZE_T numBytesToWrite = sizeof(beepPkt);
                 beepPkt.header.pktLen = htons((USHORT)numBytesToWrite);

                 SIZE_T numBytesWritten;
                 RCODE rc = sock.sendToTimeout( (VOID*)&beepPkt, numBytesToWrite, &numBytesWritten, servSockAddr, 200);
                 if (rc) return rc;

                 TICK_T startTick = cliGetTickCount();
     
                 while( cliGetCurrentTickDiff(startTick) < 3000 )
                     {
                      STRUCT_CLI_INET_SOCKETADDRESS sockAddrFrom;
                      BYTE recvBuf[8192];
                      SIZE_T receivedCount = 0;
                      rc = sock.recvFromTimeout( (VOID*)recvBuf, sizeof(recvBuf)
                                               , &receivedCount, sockAddrFrom
                                               , 500
                                               );
                      if (rc)
                         {
                          //cliWriteLogStringW(L"CP 1\n");
                          continue;     
                         }
                      if (receivedCount!=sizeof(STRUCT_CLI_MOXA_CPACKETFULLHEADER))
                         {
                          //cliWriteLogStringW(L"CP 2\n");
                          continue;
                         }
                      STRUCT_CLI_MOXA_CPACKETFULLHEADER *pkt = (STRUCT_CLI_MOXA_CPACKETFULLHEADER*)&recvBuf[0];
                      if (ntohs(pkt->pktLen)!=receivedCount)
                         {
                          //cliWriteLogStringW(L"CP 3\n");
                          continue; // invalid len of packet
                         }

                      if (pkt->pktid!=0x82)
                         {
                          //cliWriteLogStringW(L"CP 4\n");
                          continue;
                         }
                      const char *ptr1 = (const char*)&beepPkt;
                      const char *ptr2 = (const char*)&recvBuf[0];
                      ptr1 += 4;
                      ptr2 += 4;
                      /*
                      ptr1++;
                      ptr2++;
                      */
                      size_t cmpSize = sizeof(STRUCT_CLI_MOXA_CPACKETFULLHEADER)-4;

                      //cliWriteLogStringW(L"CP 5\n");
                      //::cli::format::cli_log::message( L"ptr1: %1", ::cli::format::arg (::cli::format::dump(ptr1, cmpSize )) );
                      //::cli::format::cli_log::message( L"ptr2: %1", ::cli::format::arg (::cli::format::dump(ptr2, cmpSize )) );

                      if (!memcmp( ptr1, ptr2, cmpSize ))
                         {
                          //cliWriteLogStringW(L"CP 6\n");
                          return EC_OK;
                         }
                      //cliWriteLogStringW(L"CP 7\n");
                     }
                 //cliWriteLogStringW(L"---\n");
                }
         CLI_CATCH_RETURN_CLI_EXCEPTION()
         CLI_CATCH_RETURN_STD_EXCEPTIONS()
         return EC_NO_REPLY;
        }

}; // struct CMoxaManagerImpl




}; // namespace impl
}; // namespace moxa
}; // namespace cli


#endif /* CORE_IO_MOXA_MGRIMPL_H */

