/*!
\project ���������� /cli/moxa/manager � /cli/moxa/finder, ����������� ���������� iMoxaManager � iMoxaFinder
    \libraries cli2
    \libpath 
    \incpath 

    \platform win32
        \libraries ws2_32 cli2

    \platform mingw
        \libraries ws2_32 cli2

    \platform linux
        \libraries cli2
        \libpath 
        \incpath 
*/

//#define CLI_INTERNAL
//#define CLI_INTERNAL_DONT_LINK_CLI_LIB

#include <cli/cli2.h>
#include "mgrImpl.h"
#include "nportImpl.h"


// NOTE: if not works under W2K, disable resolver by uncommenting preprocessor directives below
//#if defined(WIN32_WINNT) && WIN32_WINNT>=0x0501
//    #include "inet/resolvImpl.h"
//#endif



DECLARE_COMPONENT_CREATION_PROC( create_cli_moxa_moxamanagerimpl, ::cli::moxa::impl::CMoxaManagerImpl, INTERFACE_CLI_MOXA_IMOXAMANAGER )
DECLARE_COMPONENT_CREATION_PROC( create_cli_moxa_moxafinderimpl , ::cli::moxa::impl::CMoxaFinderImpl , INTERFACE_CLI_MOXA_IMOXAFINDER )
DECLARE_COMPONENT_CREATION_PROC( create_cli_io_stream_nportimpl , ::cli::moxa::impl::CNPortImpl      , INTERFACE_CLI_IO_ISERIAL)
//DECLARE_COMPONENT_CREATION_PROC( create_cli_inet_udpserver_impl, ::cli::inet::impl::CUdpServerImpl, INTERFACE_CLI_INET_IUDPSERVER)


CLI_BEGIN_COMPONENT_TABLE()
      CLI_COMPONENT_TABLE_ENTRY1("/cli/moxa/manager"   , create_cli_moxa_moxamanagerimpl, INTERFACE_CLI_MOXA_IMOXAMANAGER_IID, "en:Moxa servers manager;"),
      CLI_COMPONENT_TABLE_ENTRY1("/cli/moxa/finder"    , create_cli_moxa_moxafinderimpl , INTERFACE_CLI_MOXA_IMOXAFINDER_IID, "en:Moxa servers network search utility component;"),
      CLI_COMPONENT_TABLE_ENTRY6("/cli/io-stream/nport", create_cli_io_stream_nportimpl , INTERFACE_CLI_IO_IIOSTREAM_IID, INTERFACE_CLI_IO_IISTREAM_IID, INTERFACE_CLI_IO_IOSTREAM_IID, INTERFACE_CLI_IO_ISERIAL_IID, INTERFACE_CLI_IO_ISERIALHELPER_IID, INTERFACE_CLI_INET_ISOCKET_IID, "en:Moxa NPort server serial port;")
CLI_END_COMPONENT_TABLE(registerCliMoxaModule, "climoxa")

