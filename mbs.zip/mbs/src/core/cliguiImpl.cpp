#define CLI_INTERNAL

#include <cli/cligui.h>

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif


#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif


static ::cli::CCriticalSection                            guiCs(0, true);
static ::std::wstring                                     guiType;


inline
::std::wstring getDefGuiType()
   {
    #ifdef _WIN32
    return ::std::wstring(L"win"); // under windows, gui versioning not needed
    #else
    return ::std::wstring(L"wx"); // without version number, generic
    #endif
   }

inline
::std::wstring getGuiType()
   {
    CLI_SCOPED_LOCK(guiCs);
    if (guiType.empty()) return getDefGuiType();
    return guiType;
   }


EXTERN_CLI
CLIAPIENTRY
RCODE
CLICALL
cliGuiSetType( const WCHAR*    typeName /* [in] wchar  caption[]  */
             , SIZE_T    typeNameLen /* [in] size_t  captionLen  */
             )
   {
    CLI_SCOPED_LOCK(guiCs);

    if (typeNameLen==SIZE_T_NPOS)
       guiType.assign(typeName);
    else
       guiType.assign(typeName, typeNameLen);

    return EC_OK;
   }


EXTERN_CLI
CLIAPIENTRY
ENUM_CLI_GUI_DIALOGRESULT
CLICALL
cliGuiErrorDialog( WND_HANDLE    parentWnd
              , const WCHAR*    caption /* [in] wchar  caption[]  */
              , SIZE_T    captionLen /* [in] size_t  captionLen  */
              , INTERFACE_CLI_IERRORINFO**    errList /* [in] ::cli::iErrorInfo*  errList  */
              , SIZE_T    errListSize /* [in] size_t  errListSize  */
              , ENUM_CLI_GUI_ERRORDIALOGFLAGS    flags /* [in] ::cli::gui::ErrorDialogFlags  flags  */
              , const WCHAR*    locale
              )
   {
    ::std::wstring guiSuffix = getGuiType();
    ::std::wstring errDialogComponentName(L"/cli/core/gui/error_dialog/");
    errDialogComponentName.append(guiSuffix);

    if (!locale)
       {
       
       }

    ::std::vector<INTERFACE_CLI_IERRORINFO*> errListTmp;
    //bool needRelease = false;
    if (!errList)
       {
        if (flags & CLI_GUI_ERRORDIALOGFLAGS_USECLIERROR)
           {
            INTERFACE_CLI_IERRORINFO* pe = ::cli::errinfo::get();
            if (pe)
               errListTmp.push_back(pe);
           }
        else if (flags & CLI_GUI_ERRORDIALOGFLAGS_USECLIERRORLIST)
           {
            ::cli::errinfo::list::get( errListTmp );
           }

        flags &= ~(CLI_GUI_ERRORDIALOGFLAGS_USECLIERROR|CLI_GUI_ERRORDIALOGFLAGS_USECLIERRORLIST);

        if (!errListTmp.empty())
           {
            errList     = &errListTmp[0];
            errListSize = errListTmp.size();
           }
       }

    if (!errList)
       return (ENUM_CLI_GUI_DIALOGRESULT)EC_INVALID_PARAM;

    ENUM_CLI_GUI_DIALOGRESULT res = (ENUM_CLI_GUI_DIALOGRESULT)EC_OK;


    try{
        ::cli::gui::CiErrorDialog errDlg( MARTY_CON_NS w2ansi(errDialogComponentName) );
        RCODE rRes = errDlg.showModal( &res, parentWnd, caption, captionLen, errList, errListSize, flags, locale );
        if (rRes) res = (ENUM_CLI_GUI_DIALOGRESULT)rRes;
       }
    catch(...)
       {
        ::cli::format::cli_log::messageEx( L"Failed to create GUI component '%1'", ::cli::format::arg(errDialogComponentName), FMF_IGNORE_FORMAT_LF );
        res = CLI_GUI_DIALOGRESULT_FAILED;
       }

    ::cli::errinfo::list::release(errListTmp);

    return res;
   }

