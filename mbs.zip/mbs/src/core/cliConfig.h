#ifndef SRC_CORE_CLICONFIG_H
#define SRC_CORE_CLICONFIG_H

/* add this lines to your src
#ifndef SRC_CORE_CLICONFIG_H
    #include "cliConfig.h"
#endif
*/

#if !defined(CLI_BUILTIN_CLIPONENTS_DATADOM) && !defined(CLI_STANDALONE_CLIPONENTS_DATADOM)
    #define CLI_STANDALONE_CLIPONENTS_DATADOM
#endif

#if defined(CLI_BUILTIN_CLIPONENTS_DATADOM) && defined(CLI_STANDALONE_CLIPONENTS_DATADOM)
    #error "CLI_BUILTIN_CLIPONENTS_DATADOM conflicts with CLI_STANDALONE_CLIPONENTS_DATADOM option"
#endif

/*
// xml engine requred for DataDom components
#if defined(CLI_INTERNAL) && !defined(CLI_BUILTIN_CLIPONENTS_DATADOM)
    #define CLI_CORE_XML_ENGINE_NOT_REQURED
#endif

#ifndef CLI_CORE_XML_ENGINE_NOT_REQURED
    #define CLI_CORE_XML_ENGINE_REQURED
#endif

#ifdef CLI_CORE_XML_ENGINE_REQURED
    #ifndef CLI_CORE_USE_TINYXML_ENGINE
        #ifndef CLI_CORE_USE_PUGIXML_ENGINE
            #define CLI_CORE_USE_PUGIXML_ENGINE  1
        #endif
    #endif
#endif
*/

#endif /* SRC_CORE_CLICONFIG_H */

