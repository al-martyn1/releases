#ifndef CORE_MONOMOD_H
#define CORE_MONOMOD_H




#endif /* CORE_MONOMOD_H */

