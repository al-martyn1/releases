#ifndef CORE_EIIMPL_H
#define CORE_EIIMPL_H

#ifndef CLI_IERRINFO_H
    #include <cli/ierrinfo.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#ifndef CLI_INTERLOCKED_H
    #include <cli/interlocked.h>
#endif



namespace cli
{
namespace errinfo
{
namespace impl
{

class CErrorInfoBase : public INTERFACE_CLI_IERRORINFO, public INTERFACE_CLI_ICREATEERRORINFO
{

    protected:

            ::cli::CRefCounter        refCounter;

            RCODE                     errCode;
            ::std::wstring            moduleFileName;
            ::std::wstring            moduleInternalName;
                                     
            ::std::wstring            sourceName;
            UINT                      sourceLine;

            INTERFACE_CLI_IARGLIST   *pArgs;

            INTERFACE_CLI_IERRORINFO *chainedError;


    public:
            CErrorInfoBase() 
               : refCounter(0)
               , errCode(EC_OK)
               , moduleFileName()
               , moduleInternalName()
               , sourceName()
               , sourceLine(0)
               , pArgs(0)
               , chainedError(0)
               {}

            void clear() 
               {
                errCode = EC_OK;
                moduleFileName.clear();
                moduleInternalName.clear();
                sourceName.clear();
                sourceLine = 0;
                if (pArgs) pArgs->release();
                pArgs = 0;
                if (chainedError) chainedError->release();
                chainedError = 0;
               }

            virtual ~CErrorInfoBase()
               {
                if (pArgs) pArgs->release();
                if (chainedError) chainedError->release();
               }

            /* interface ::cli::iErrorInfo methods */
            CLIMETHOD(getErrorCode) (THIS)
               {
                return errCode;
               }

            CLIMETHOD(getModuleFileName) (THIS_ CLISTR*           str)
               {
                if (!str) return EC_OK;
                if (moduleFileName.empty()) return EC_NO_DATA;
                CCliStr_copyTo( *((CCliStr*)str), moduleFileName );
                return EC_OK;
               }

            CLIMETHOD(getModuleInternalName) (THIS_ CLISTR*           str)
               {
                if (!str) return EC_OK;
                if (moduleInternalName.empty()) return EC_NO_DATA;
                CCliStr_copyTo( *((CCliStr*)str), moduleInternalName );
                return EC_OK;
               }

            CLIMETHOD(getModuleName) (THIS_ CLISTR*           str)
               {
                #ifndef CLI_MONOLITHIC
                return getModuleInternalName(str);
                #else
                RCODE res = getModuleFileName(str);
                if (res==EC_NO_DATA)
                   return getModuleInternalName(str);
                return EC_OK;
                #endif               
               }

            CLIMETHOD(getSourceFileLine) (THIS_ CLISTR*           str
                                              , UINT*    line /* [out] uint line  */
                                         )
               {
                if (str)
                   CCliStr_copyTo( *((CCliStr*)str), sourceName );
                if (line)
                   *line = sourceLine;
                return EC_OK;
               }

            CLIMETHOD(getArgList) (THIS_ INTERFACE_CLI_IARGLIST**    arglist /* [out] ::cli::iArgList* arglist  */)
               {
                if (!arglist) return EC_INVALID_OUT_PTR;
                if (pArgs)
                   {
                    pArgs->addRef();
                    *arglist = pArgs;
                    return EC_OK;
                   }
                else
                   {
                    return EC_NO_DATA;
                   }
               }

            CLIMETHOD(getChainErrorInfo) (THIS_ INTERFACE_CLI_IERRORINFO**    pei /* [out] ::cli::iErrorInfo* pei  */)
               {
                if (!pei) return EC_INVALID_OUT_PTR;
                if (chainedError)
                   {
                    chainedError->addRef();
                    *pei = chainedError;
                    return EC_OK;
                   }
                else
                   {
                    return EC_NO_DATA;
                   }
               }

            /* interface ::cli::iCreateErrorInfo methods */
            CLIMETHOD(setErrorCode) (THIS_ RCODE    code /* [in] rcode  code  */)
               {
                errCode = code;
                return EC_OK;
               }

            CLIMETHOD(setModuleFileName) (THIS_ const CLISTR*     name)
               {
                if (name) 
                   {
                    CCliStr *pCliStr = (CCliStr*)name;
                    if (!pCliStr->size() || !pCliStr->data())
                       {
                        moduleFileName.clear();
                       }
                    else
                       {
                        moduleFileName.assign(pCliStr->data(), pCliStr->size());
                       }
                   }
                else
                   {
                    moduleFileName.clear();
                   }
                return EC_OK;
               }

            CLIMETHOD(setModuleFileNameChars) (THIS_ const WCHAR*    name /* [in] wchar  name[]  */
                                                   , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                              )
               {
                if (!name || !nameSize) 
                   {
                    moduleFileName.clear();
                   }
                else
                   {
                    if (nameSize==SIZE_T_NPOS)
                       moduleFileName.assign(name);
                    else
                       moduleFileName.assign(name, nameSize);
                   }
                return EC_OK;
               }

            CLIMETHOD(setModuleInternalName) (THIS_ const CLISTR*     name)
               {
                if (name) 
                   {
                    CCliStr *pCliStr = (CCliStr*)name;
                    if (!pCliStr->size() || !pCliStr->data())
                       {
                        moduleInternalName.clear();
                       }
                    else
                       {
                        moduleInternalName.assign(pCliStr->data(), pCliStr->size());
                       }
                   }
                else
                   {
                    moduleInternalName.clear();
                   }
                return EC_OK;
               }

            CLIMETHOD(setModuleInternalNameChars) (THIS_ const WCHAR*    name /* [in] wchar  name[]  */
                                                       , SIZE_T    nameSize /* [in] size_t  nameSize  */
                                                  )
               {
                if (!name || !nameSize) 
                   {
                    moduleInternalName.clear();
                   }
                else
                   {
                    if (nameSize==SIZE_T_NPOS)
                       moduleInternalName.assign(name);
                    else
                       moduleInternalName.assign(name, nameSize);
                   }
                return EC_OK;
               }

            CLIMETHOD(setSourceFileLine) (THIS_ const CLISTR*     srcName
                                              , UINT    line /* [in] uint  line  */
                                         )
               {
                if (srcName) 
                   {
                    CCliStr *pCliStr = (CCliStr*)srcName;
                    if (!pCliStr->size() || !pCliStr->data())
                       {
                        sourceName.clear();
                       }
                    else
                       {
                        sourceName.assign(pCliStr->data(), pCliStr->size());
                       }
                   }
                else
                   {
                    sourceName.clear();
                   }

                sourceLine = line;

                return EC_OK;
               }

            CLIMETHOD(setSourceFileLineChars) (THIS_ const WCHAR*    srcName /* [in] wchar  srcName[]  */
                                                   , SIZE_T    srcNameSize /* [in] size_t  srcNameSize  */
                                                   , UINT    line /* [in] uint  line  */
                                              )
               {
                if (!srcName || !srcNameSize) 
                   {
                    sourceName.clear();
                   }
                else
                   {
                    if (srcNameSize==SIZE_T_NPOS)
                       sourceName.assign(srcName);
                    else
                       sourceName.assign(srcName, srcNameSize);
                   }

                sourceLine = line;

                return EC_OK;
               }

            CLIMETHOD(setArgList) (THIS_ INTERFACE_CLI_IARGLIST*    arglist /* [in] ::cli::iArgList*  arglist  */)
               {
                if (pArgs) pArgs->release();
                pArgs = arglist;
                // if (pArgs) pArgs->addRef();
                return EC_OK;
               }

            /* interfaces ::cli::iCreateErrorInfo, ::cli::iErrorInfo method */
            CLIMETHOD(chainErrorInfo) (THIS_ INTERFACE_CLI_IERRORINFO*    pei /* [in] ::cli::iErrorInfo*  pei  */)
               {
                if (chainedError) chainedError->release();
                chainedError = pei;
                if (chainedError) chainedError->addRef();
                return EC_OK;
               }

};






}; // namespace impl
}; // namespace errinfo
}; // namespace cli


#endif /* CORE_EIIMPL_H */

