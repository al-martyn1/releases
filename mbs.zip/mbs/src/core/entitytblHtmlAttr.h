struct CHtmlAttrEntityProcessing : public CEntityProcessingBase {

    static  wchar_t entityChars[35];
    static  unsigned charToEntity[35];
    static  const wchar_t *entities[35];
    static  wchar_t entityToChar[35];


    const wchar_t* getEntitiesCharString() const
       {
        return &entityChars[0];
       }


    // convert entiry name to char
    bool convertEntityToChar( const std::wstring &entityName, std::wstring &val ) const
       {
        const wchar_t ** pBegin = &entities[0];
        const wchar_t ** pEnd   = pBegin + 34;
        const wchar_t **pFoundEntityName = (const wchar_t **)util::binary_find( pBegin, pEnd, entityName.c_str(), wstringLess );
        if (pFoundEntityName!=pEnd)
           {
            SIZE_T entityIdx = pFoundEntityName - &entities[0];
            val.assign(1,entityToChar[entityIdx]);
            return true;
           }
        return false;
       }


    // convert entiry char to entity name
    bool convertCharToEntity( wchar_t ch, std::wstring &entityNameAppendTo ) const
       {
        const wchar_t* pEntityChar = util::binary_find( entityChars, entityChars+34, ch );
        if (pEntityChar!=(entityChars+34))
           {
            SIZE_T charIdx = (pEntityChar - entityChars);
            SIZE_T entityIdx = charToEntity[charIdx];
            entityNameAppendTo.append(entities[entityIdx]);
            return true;
           }
        return false;
       }


}; // struct CHtmlAttrEntityProcessing

wchar_t CHtmlAttrEntityProcessing::entityChars[35] = {
  0x01, // 0  (#x01)
  0x02, // 1  (#x02)
  0x03, // 2  (#x03)
  0x04, // 3  (#x04)
  0x05, // 4  (#x05)
  0x06, // 5  (#x06)
  0x07, // 6  (#x07)
  0x08, // 7  (#x08)
  0x09, // 8  (#x09)
  0x0A, // 9  (#x0A)
  0x0B, // 10  (#x0B)
  0x0C, // 11  (#x0C)
  0x0D, // 12  (#x0D)
  0x0E, // 13  (#x0E)
  0x0F, // 14  (#x0F)
  0x10, // 15  (#x10)
  0x11, // 16  (#x11)
  0x12, // 17  (#x12)
  0x13, // 18  (#x13)
  0x14, // 19  (#x14)
  0x15, // 20  (#x15)
  0x16, // 21  (#x16)
  0x17, // 22  (#x17)
  0x18, // 23  (#x18)
  0x19, // 24  (#x19)
  0x1A, // 25  (#x1A)
  0x1B, // 26  (#x1B)
  0x1C, // 27  (#x1C)
  0x1D, // 28  (#x1D)
  0x1E, // 29  (#x1E)
  0x1F, // 30  (#x1F)
  0x22, // 31  (quot)
  0x26, // 32  (amp)
  0x27, // 33  (apos)
  0
};

unsigned CHtmlAttrEntityProcessing::charToEntity[35] = {
  0, // 0  (#x01)
  1, // 1  (#x02)
  2, // 2  (#x03)
  3, // 3  (#x04)
  4, // 4  (#x05)
  5, // 5  (#x06)
  6, // 6  (#x07)
  7, // 7  (#x08)
  8, // 8  (#x09)
  9, // 9  (#x0A)
  10, // 10  (#x0B)
  11, // 11  (#x0C)
  12, // 12  (#x0D)
  13, // 13  (#x0E)
  14, // 14  (#x0F)
  15, // 15  (#x10)
  16, // 16  (#x11)
  17, // 17  (#x12)
  18, // 18  (#x13)
  19, // 19  (#x14)
  20, // 20  (#x15)
  21, // 21  (#x16)
  22, // 22  (#x17)
  23, // 23  (#x18)
  24, // 24  (#x19)
  25, // 25  (#x1A)
  26, // 26  (#x1B)
  27, // 27  (#x1C)
  28, // 28  (#x1D)
  29, // 29  (#x1E)
  30, // 30  (#x1F)
  33, // 31  (quot)
  31, // 32  (amp)
  32, // 33  (apos)
  0xFA
};

const wchar_t* CHtmlAttrEntityProcessing::entities[35] = {
  L"#x01", // 0 (0x01)
  L"#x02", // 1 (0x02)
  L"#x03", // 2 (0x03)
  L"#x04", // 3 (0x04)
  L"#x05", // 4 (0x05)
  L"#x06", // 5 (0x06)
  L"#x07", // 6 (0x07)
  L"#x08", // 7 (0x08)
  L"#x09", // 8 (0x09)
  L"#x0A", // 9 (0x0A)
  L"#x0B", // 10 (0x0B)
  L"#x0C", // 11 (0x0C)
  L"#x0D", // 12 (0x0D)
  L"#x0E", // 13 (0x0E)
  L"#x0F", // 14 (0x0F)
  L"#x10", // 15 (0x10)
  L"#x11", // 16 (0x11)
  L"#x12", // 17 (0x12)
  L"#x13", // 18 (0x13)
  L"#x14", // 19 (0x14)
  L"#x15", // 20 (0x15)
  L"#x16", // 21 (0x16)
  L"#x17", // 22 (0x17)
  L"#x18", // 23 (0x18)
  L"#x19", // 24 (0x19)
  L"#x1A", // 25 (0x1A)
  L"#x1B", // 26 (0x1B)
  L"#x1C", // 27 (0x1C)
  L"#x1D", // 28 (0x1D)
  L"#x1E", // 29 (0x1E)
  L"#x1F", // 30 (0x1F)
  L"amp", // 31 (0x26)
  L"apos", // 32 (0x27)
  L"quot", // 33 (0x22)
  L"END"
};

wchar_t CHtmlAttrEntityProcessing::entityToChar[35] = {
  0x01, // 0 (#x01)
  0x02, // 1 (#x02)
  0x03, // 2 (#x03)
  0x04, // 3 (#x04)
  0x05, // 4 (#x05)
  0x06, // 5 (#x06)
  0x07, // 6 (#x07)
  0x08, // 7 (#x08)
  0x09, // 8 (#x09)
  0x0A, // 9 (#x0A)
  0x0B, // 10 (#x0B)
  0x0C, // 11 (#x0C)
  0x0D, // 12 (#x0D)
  0x0E, // 13 (#x0E)
  0x0F, // 14 (#x0F)
  0x10, // 15 (#x10)
  0x11, // 16 (#x11)
  0x12, // 17 (#x12)
  0x13, // 18 (#x13)
  0x14, // 19 (#x14)
  0x15, // 20 (#x15)
  0x16, // 21 (#x16)
  0x17, // 22 (#x17)
  0x18, // 23 (#x18)
  0x19, // 24 (#x19)
  0x1A, // 25 (#x1A)
  0x1B, // 26 (#x1B)
  0x1C, // 27 (#x1C)
  0x1D, // 28 (#x1D)
  0x1E, // 29 (#x1E)
  0x1F, // 30 (#x1F)
  0x26, // 31 (amp)
  0x27, // 32 (apos)
  0x22, // 33 (quot)
  0xFA
};

