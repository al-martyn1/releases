#define CLICOMPONENTINFO_CONST_FIELD

#include <cli/cli2base.h>
#include <cli/csec.h>

#ifndef CLI_CLIERR_H
    #include <cli/clierr.h>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif  

#include <stdlib.h>

#ifdef WIN32
    #include <search.h>
#endif

#include <string.h>

#include "clialloc.h"

#ifndef CLI_EMBEDDED
    #include "cli2init.h"

    ::cli::CCliOptions* getCliRuntimeOptions();

#endif

#ifndef SRC_CORE_LANGUTIL_H
    #include "langUtil.h"
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif



struct CModuleRegisterInfo
{
    CHAR                              *moduleName;
    cliEnumModuleComponentsProcT       enumProc;
    cli_create_proc_t                  legacyCreateProc;
    CliCreateProcT                     createProc;
};

typedef CModuleRegisterInfo * PModuleRegisterInfo;

static
#ifndef  __GNUC__
int CDECL compareModuleRegisterInfo(const void *p1, const void *p2) 
#else
int compareModuleRegisterInfo(const void *p1, const void *p2) 
#endif
   {
    // const PModuleRegisterInfo *pci1 = (PModuleRegisterInfo*)p1;
    // const PModuleRegisterInfo *pci2 = (PModuleRegisterInfo*)p2;
    // return strcmp((*pci1)->moduleName, (*pci2)->moduleName);
    const PModuleRegisterInfo pci1 = (PModuleRegisterInfo)p1;
    const PModuleRegisterInfo pci2 = (PModuleRegisterInfo)p2;
    return strcmp(pci1->moduleName, pci2->moduleName);
   }


struct CModuleRegisterInfoListEntry
{
    CModuleRegisterInfo             info;
    CModuleRegisterInfoListEntry   *next;
};


struct CStringListItem
{
    CHAR              *str;
    CStringListItem   *next;
};

struct CStringPairListItem
{
    CHAR                 *first;
    CHAR                 *second;
    CStringPairListItem  *next;
};

struct CComponentMonoInfo
{
    CHAR                   *componentName;
    SIZE_T                  moduleId;
    CStringListItem        *categoryList;
    CStringPairListItem    *descriptionList;
};

struct CCategoryListItem
{
    CHAR              *categoryName;
    CStringListItem   *categoryComponents;
    CCategoryListItem *next;

    // return found category (bFound==true) or last category in list (bFound==false)
    CCategoryListItem* findCategory(CHAR const *_categoryName, bool &bFound)
       {
        bFound = true;
        if (!strcmp(this->categoryName, _categoryName)) return this;

        CCategoryListItem* pItem = this;
        while(pItem->next)
           {
            if (!strcmp(pItem->next->categoryName, _categoryName)) return pItem->next;
            pItem = pItem->next;
           }
        bFound = false;
        return pItem;
       }

    // find existing component or add component to category
    bool addCategoryComponent(CHAR *componentName)
       {
        if (!categoryComponents)
           {
            categoryComponents = (CStringListItem*)cliStaticAlloc(sizeof(CStringListItem));
            if (!categoryComponents) return false; // not enough memory
            categoryComponents->next = 0;
            categoryComponents->str = componentName;
            return true;
           }

        if (!strcmp(categoryComponents->str, componentName))
           return true; // allready exist at head of list

        CStringListItem *tmp = categoryComponents;
        while(tmp->next)
           {
            if (!strcmp(tmp->next->str, componentName))
               return true; // allready exist
            tmp = tmp->next;
           }

        tmp->next = (CStringListItem*)cliStaticAlloc(sizeof(CStringListItem));
        if (!tmp->next) return false; // not enough memory
        tmp->next->next = 0;
        tmp->next->str = componentName;
        return true;
       }

    static
    bool addCategoryComponent(CHAR *categoryName, CHAR *componentName, CCategoryListItem **pHead)
       {
        if (!*pHead)
           {
            *pHead = (CCategoryListItem*)cliStaticAlloc(sizeof(CCategoryListItem));
            if (!*pHead)
               return false; // not enough memory
            (*pHead)->categoryName = categoryName;
            (*pHead)->categoryComponents = 0;
            (*pHead)->next = 0;
            return (*pHead)->addCategoryComponent(componentName);
           }
        bool bFound = false;
        CCategoryListItem* pItem = (*pHead)->findCategory(categoryName, bFound);
        if (!bFound)
           {
            pItem->next = (CCategoryListItem*)cliStaticAlloc(sizeof(CCategoryListItem));
            if (!pItem->next) 
               return false; // not enough memory

            pItem = pItem->next;
            pItem->categoryName = categoryName;
            pItem->categoryComponents = 0;
            pItem->next = 0;
           }

        return pItem->addCategoryComponent(componentName);
       }
};


static
#ifndef  __GNUC__
int CDECL compareComponentMonoInfo(const void *p1, const void *p2) 
#else
int compareComponentMonoInfo(const void *p1, const void *p2) 
#endif
   {
    const CComponentMonoInfo *pci1 = (CComponentMonoInfo*)p1;
    const CComponentMonoInfo *pci2 = (CComponentMonoInfo*)p2;
    return strcmp(pci1->componentName, pci2->componentName);
   }



static CModuleRegisterInfoListEntry *pModRegListHead = 0;
static CModuleRegisterInfoListEntry *pModRegListLast = 0;

static CModuleRegisterInfo          *pModRegInfo = 0;
static SIZE_T                        numberOfComponents = 0;
static CComponentMonoInfo           *pComponentInfo = 0;

static CCategoryListItem            *pCategoryComponents = 0;


static
CModuleRegisterInfoListEntry* findModule(CModuleRegisterInfoListEntry *pEntry, CHAR const *name)
   {
    //CModuleRegisterInfoListEntry *pEntry = pModRegListHead;
    while(pEntry)
       {
        if (!strcmp(pEntry->info.moduleName, name)) return pEntry;
        pEntry = pEntry->next;
       }
    return 0;
   }


CLIAPIENTRY
UINT
CLICALL
cliRegisterModule( CHAR const *moduleId
                 , cliEnumModuleComponentsProcT enumProc
                 , cli_create_proc_t legacyCreateProc
                 , CliCreateProcT createProc
                 )
   {
    #ifndef CLI_EMBEDDED
    ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
    #endif

    if (!moduleId) 
       {
        #ifndef CLI_EMBEDDED
        pOpts->log()<<"cliRegisterModule: moduleId parameter not taken\n";
        #endif
        return 1;
       }

    if (!enumProc) 
       {
        #ifndef CLI_EMBEDDED
        pOpts->log()<<"cliRegisterModule: enumProc parameter not taken\n";
        #endif
        return 2;
       }

    if (!legacyCreateProc && !createProc) 
       {
        #ifndef CLI_EMBEDDED
        pOpts->log()<<"cliRegisterModule: legacyCreateProc nor createProc parameter taken\n";
        #endif
        return 3;
       }
    
    CModuleRegisterInfoListEntry *pEntry = (CModuleRegisterInfoListEntry*)cliStaticAlloc(sizeof(CModuleRegisterInfoListEntry));
    if (!pEntry) 
       {
        #ifndef CLI_EMBEDDED
        pOpts->log()<<"cliRegisterModule: not enough memory, is cliInitMonolithic called?\n";
        #endif
        return 6; // error no mem
       }

    pEntry->info.moduleName = (CHAR*)cliStaticAlloc(strlen(moduleId)+1);
    if (!pEntry->info.moduleName) 
       {
        #ifndef CLI_EMBEDDED
        pOpts->log()<<"cliRegisterModule: not enough memory, is cliInitMonolithic called?\n";
        #endif
        return 6; // error no mem
       }

    strcpy(pEntry->info.moduleName, moduleId);

    pEntry->info.enumProc         = enumProc;
    pEntry->info.legacyCreateProc = legacyCreateProc;
    pEntry->info.createProc       = createProc;

    pEntry->next = 0;

    if (!pModRegListHead) pModRegListHead = pEntry;
    if (pModRegListLast) 
       {
        pModRegListLast->next = pEntry;
       }
    pModRegListLast = pEntry;

    return 0;
   }

//-----------------------------------------------------------------------------
namespace cli
{
    void createStdAllocatorObject();
}; // namespace cli

UINT initCliMonolithicInt()
   {
    #ifndef CLI_EMBEDDED
    ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
    #endif

    cli::createStdAllocatorObject();

    SIZE_T totalModules = 0;
    CModuleRegisterInfoListEntry *pEntry = pModRegListHead;
    //if (!pEntry) return 0; // nothing to do

    while(pEntry)
       {
        if (findModule(pEntry->next, pEntry->info.moduleName)) return 1; // error: duplicate module registered
        ++totalModules;
        pEntry = pEntry->next;
       }

    if (!totalModules) 
       {
        #ifndef CLI_EMBEDDED
        pOpts->log()<<"cliInit: there is no modules registered before cliInit called, use cliRegisterModule to register modules\n";
        #endif
        return 0; // nothing to do
       }

    pModRegInfo = (CModuleRegisterInfo*)cliStaticAlloc(sizeof(CModuleRegisterInfo)*totalModules);
    pEntry = pModRegListHead;
    for(SIZE_T t = 0; pEntry; pEntry = pEntry->next, ++t)
       {
        pModRegInfo[t] = pEntry->info;
       }

    qsort((void*)&pModRegInfo[0], totalModules, sizeof(CModuleRegisterInfo), compareModuleRegisterInfo);

    
    SIZE_T totalComponentCount = 0;
    for(SIZE_T t = 0; t<totalModules; ++t)
       {
        CCliComponentInfo ci = { 0, 0, 0 };
        SIZE_T idx = 0;
        while(pModRegInfo[t].enumProc(idx++, &ci))
           {
            ++totalComponentCount;
            if (!ci.name) continue;
           }
       }

    #ifndef CLI_EMBEDDED
    pOpts->log()<<"cliInit: total "<<(int)totalComponentCount<<" components in "<<(int)totalModules<<" modules\n";
    pOpts->log()<<"-------\nInitializing CLI2\n-------\n";
    #endif

    pComponentInfo = (CComponentMonoInfo*)cliStaticAlloc(sizeof(CComponentMonoInfo)*totalComponentCount);
    if (!pComponentInfo)
       {
        #ifndef CLI_EMBEDDED
        pOpts->log()<<"cliInit: not enough memory, is cliInitMonolithic called?\n";
        #endif
        return 6;
       }

    for(SIZE_T t = 0; t<totalModules; ++t)
       {
        #ifndef CLI_EMBEDDED
        pOpts->log()<<"Processing module: "<<pModRegInfo[t].moduleName<<"\n";
        #endif

        CCliComponentInfo ci = { 0 };
        SIZE_T idx = 0;
        while(pModRegInfo[t].enumProc(idx++, &ci))
           {
            if (!ci.name) continue;

            SIZE_T t2 = 0;
            for(; t2<numberOfComponents; ++t2)
               {
                if (!strcmp(pComponentInfo[t2].componentName, ci.name))
                   {
                    #ifndef CLI_EMBEDDED
                    pOpts->log()<<"Component '"<<pComponentInfo[t2].componentName
                                <<"' allready defined in module '"<<pModRegInfo[pComponentInfo[t2].moduleId].moduleName<<"'\n";
                    #endif
                    break;
                   }
               }
    
            if (t2<numberOfComponents) // �� ����� ����� ������, ��� ��� ��������� ��� ���� � ������
               continue; // ���������� ���������
    
            pComponentInfo[numberOfComponents].componentName    = ci.name;
            pComponentInfo[numberOfComponents].moduleId         = t; // index of module
    
            pComponentInfo[numberOfComponents].categoryList     = 0;
            CStringListItem *pLastCategory                      = 0;
            if (ci.categories)
               {
                SIZE_T catStrLen = strlen(ci.categories) + 1 + 1; // str term zero and additional zero byte
                CHAR *strCategories = (CHAR*)cliStaticAlloc(catStrLen);
                // UNDONE: failed alloc branch
                if (strCategories)
                   {
                    strcpy(strCategories, ci.categories);
                    strCategories[catStrLen-1] = 0; // additional zero
                    CHAR *strStart = strCategories;
                    while(*strStart)
                       {
                        CHAR *strEnd = strStart;
                        while(*strEnd && *strEnd!=';') ++strEnd;
                        *strEnd = 0; // if zero, byte unchanged, if ; - changed to zero
    
                        CStringListItem *pCategoryListEntry = (CStringListItem*)cliStaticAlloc(sizeof(CStringListItem));
                        // UNDONE: failed alloc branch
                        if (pCategoryListEntry)
                           {
                            pCategoryListEntry->next = 0;
                            pCategoryListEntry->str  = strStart;
                            if (pLastCategory)
                               pLastCategory->next = pCategoryListEntry;
                            pLastCategory = pCategoryListEntry;
                            if (!pComponentInfo[numberOfComponents].categoryList)
                               pComponentInfo[numberOfComponents].categoryList = pLastCategory;
                           }
    
                        strStart = strEnd + 1;
                       }
                   }
               }
    
            // UNDONE: need to add parsing of categories and description
            pComponentInfo[numberOfComponents].descriptionList  = 0;
    
            ++numberOfComponents;
           }
       }

    qsort((void*)&pComponentInfo[0], numberOfComponents, sizeof(CComponentMonoInfo), compareComponentMonoInfo);

    #ifndef CLI_EMBEDDED
    pOpts->log()<<"-------\nList of known components\n-------\n";
    #endif
    for(SIZE_T t = 0; t<numberOfComponents; ++t)
       {
        CStringListItem *pCategory = pComponentInfo[t].categoryList;
        while(pCategory)
           {
            if (!CCategoryListItem::addCategoryComponent(pCategory->str, pComponentInfo[t].componentName, &pCategoryComponents))
               {
                #ifndef CLI_EMBEDDED
                pOpts->log()<<"pComponentInfo[t].componentName: filed to add component to category - not enough memory, is cliInitMonolithic called?\n";
                #endif
                return 6;
               }
            pCategory = pCategory->next;
           }
        
        #ifndef CLI_EMBEDDED
        pOpts->log()<<pComponentInfo[t].componentName<<": "<<pModRegInfo[pComponentInfo[t].moduleId].moduleName<<"\n";
        #endif
       }
    #ifndef CLI_EMBEDDED
    pOpts->log()<<"-------\nEnd of list of known components (total found: "<<(int)numberOfComponents<<"\n-------\n";
    #endif

    return 0;
   }

//-----------------------------------------------------------------------------
//CLI_ERR_UNKNOWN
RCODE
CLICALL
cliCreateObject( CHAR const * componentId
               , CHAR const * interfaceId
               , CLI_IUNKNOWN_PTR outer
               , GENERIC_OBJ_PTR *pRes
               )
   {
    if (outer) return CLI_ERR_UNKNOWN; // not supported feature now

    if (!componentId || !interfaceId || !pRes) return CLI_ERR_UNKNOWN; // error, UNDONE: make error reporting with extended err info 

    // don't need to lock component list - after init, its never changed

    CComponentMonoInfo key;
    key.componentName = (CHAR*)componentId;

    CComponentMonoInfo *pFound = (CComponentMonoInfo*)bsearch( (void*)&key
                                                             , (void*)pComponentInfo
                                                             , numberOfComponents
                                                             , sizeof(CComponentMonoInfo)
                                                             , &compareComponentMonoInfo );
    if (!pFound)
       {
        #ifndef CLI_EMBEDDED
        ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
        pOpts->log()<<"Failed to find info for component '"<<componentId<<"' - unknown component\n";
        #endif
        return CLI_ERR_UNKNOWN;
       }

    if (!pModRegInfo[pFound->moduleId].legacyCreateProc)
       {
        #ifndef CLI_EMBEDDED
        ::cli::CCliOptions* pOpts = ::cli::getCliRuntimeOptions();
        pOpts->log()<<"Failed to create component '"<<componentId<<"' - there is no entry point "<<LEGACY_CLICREATEPROCNAME<<" in module "<<pModRegInfo[pFound->moduleId].moduleName<<"\n";
        #endif
        return CLI_ERR_UNKNOWN;
       }

    CLI_IUNKNOWN_PTR resPtr = (CLI_IUNKNOWN_PTR)pModRegInfo[pFound->moduleId].legacyCreateProc(componentId, interfaceId, outer);
    if (!resPtr)
       {
        return CLI_ERR_UNKNOWN;
       }

    *pRes = resPtr;
    return 0; // resPtr;
   }
   
//-----------------------------------------------------------------------------
/*
GENERIC_OBJ_PTR
CLICALL
cli_create( CHAR const * componentId, 
          CHAR const * interfaceId, 
          GENERIC_OBJ_PTR* outer)
   {

    if (outer) return 0; // not supported feature now

    if (!componentId || !interfaceId) return 0; // error, UNDONE: make error reporting with extended err info 

    // don't need to lock component list - after init, its never changed

    CComponentMonoInfo key;
    key.componentName = (CHAR*)componentId;

    CComponentMonoInfo *pFound = (CComponentMonoInfo*)bsearch( (void*)&key
                                                             , (void*)pComponentInfo
                                                             , numberOfComponents
                                                             , sizeof(CComponentMonoInfo)
                                                             , &compareComponentMonoInfo );
    if (!pFound)
       {
        #ifndef CLI_EMBEDDED
        ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
        pOpts->log()<<"Failed to find info for component '"<<componentId<<"' - unknown component\n";
        #endif
        return 0;
       }

    if (!pModRegInfo[pFound->moduleId].legacyCreateProc)
       {
        #ifndef CLI_EMBEDDED
        ::cli::CCliOptions* pOpts = getCliRuntimeOptions();
        pOpts->log()<<"Failed to create component '"<<componentId<<"' - there is no entry point "<<LEGACY_CLICREATEPROCNAME<<" in module "<<pModRegInfo[pFound->moduleId].moduleName<<"\n";
        #endif
        return 0;
       }

    GENERIC_OBJ_PTR resPtr = pModRegInfo[pFound->moduleId].legacyCreateProc(componentId, interfaceId, outer);
    if (!resPtr)
       {
        // 
       }

    return resPtr;
   }
*/
//-----------------------------------------------------------------------------
SIZE_T
CLICALL
cliGetComponentDecsription( CHAR const * componentId
                          , const WCHAR* requestedLang
                          , BOOL         findExactLang
                          , SIZE_T bufSize
                          , WCHAR *componentDescriptionBuf
                          )
   {
    if (!componentId) return 0; // error, enum stops 

    CComponentMonoInfo key;
    key.componentName = (CHAR*)componentId;

    CComponentMonoInfo *pFound = (CComponentMonoInfo*)bsearch( (void*)&key
                                                             , (void*)pComponentInfo
                                                             , numberOfComponents
                                                             , sizeof(CComponentMonoInfo)
                                                             , &compareComponentMonoInfo );
    if (!pFound)
       return 0;

    std::string strRequestedLang = requestedLang ? ::cli::impl::flat_str_utils::fromWidePlain( requestedLang ) : std::string();
    const char *pDescrStr = 0;
    CStringPairListItem *pDescrListItem = pFound->descriptionList;
    for(; pDescrListItem; pDescrListItem = pDescrListItem->next)
       {
        int cmpLangRes = ::cli::impl::isLangIdEqual(pDescrListItem->first, strRequestedLang.c_str());
        if (cmpLangRes<0) continue;
        if (cmpLangRes==0 || !findExactLang)
           {
            pDescrStr = pDescrListItem->second;
            break;
           }
       }

    if (!pDescrStr) return 0;

    std::wstring descrFound = MARTY_UTF::fromUtf8(pDescrStr);

    if (!componentDescriptionBuf) return descrFound.size()+1;

    SIZE_T numCharsToCopy = bufSize - 1;
    if (numCharsToCopy>descrFound.size()) numCharsToCopy = descrFound.size();
    descrFound.copy( componentDescriptionBuf, numCharsToCopy );
    componentDescriptionBuf[numCharsToCopy] = 0;
    return numCharsToCopy+1;
   }
//-----------------------------------------------------------------------------

SIZE_T
CLICALL
cliEnumComponentCategories( CHAR const * componentId
                          , SIZE_T categoryIdx
                          , SIZE_T bufSize
                          , CHAR *categoryNameBuf
                          )
   {
    if (!componentId) return 0; // error, enum stops 

    CComponentMonoInfo key;
    key.componentName = (CHAR*)componentId;

    CComponentMonoInfo *pFound = (CComponentMonoInfo*)bsearch( (void*)&key
                                                             , (void*)pComponentInfo
                                                             , numberOfComponents
                                                             , sizeof(CComponentMonoInfo)
                                                             , &compareComponentMonoInfo );
    if (!pFound)
       return 0;

    SIZE_T curIdx = 0;
    CStringListItem *pCat = pFound->categoryList;
    while(pCat && curIdx<categoryIdx)
       {
        ++curIdx;
        pCat = pCat->next;
       }

    if (!pCat || !pCat->str) return 0; // index out of range

    SIZE_T catLen = strlen(pCat->str);

    if (!categoryNameBuf) return catLen+1;

    if (!bufSize) return 0; // error - buf len is zero, enum stops

    SIZE_T numOfCharsToCopy = bufSize-1; // exclude terminating zero
    if (numOfCharsToCopy>catLen)
       numOfCharsToCopy = catLen;

    memcpy( (void*)categoryNameBuf, (void*)pCat->str, numOfCharsToCopy);
    categoryNameBuf[numOfCharsToCopy] = 0;

    return numOfCharsToCopy+1;
   }

//-----------------------------------------------------------------------------
SIZE_T
CLICALL
cliEnumCategories( SIZE_T categoryIdx
                 , SIZE_T bufSize
                 , CHAR *categoryNameBuf
                 )
   {
    if (!pCategoryComponents) return 0;

    // components staticaly  linked, not needed to lock list
    //CLI_AUTOLOCK_EX(componentListLocker, clCs);

    SIZE_T curIdx = 0;
    CCategoryListItem *pItem = pCategoryComponents;
    for(; pItem && curIdx<categoryIdx; pItem=pItem->next, ++curIdx) {}
    if (!pItem || !pItem->categoryName || curIdx!=categoryIdx) return 0; // index out of range, or name invalid

    //pItem->categoryName;

    SIZE_T nameLen = strlen(pItem->categoryName);

    if (!categoryNameBuf) return nameLen+1;

    if (!bufSize) return 0; // error - buf len is zero, enum stops

    SIZE_T numOfCharsToCopy = bufSize-1; // exclude terminating zero
    if (numOfCharsToCopy>nameLen)
       numOfCharsToCopy = nameLen;

    memcpy( (void*)categoryNameBuf, (void*)pItem->categoryName, numOfCharsToCopy);
    categoryNameBuf[numOfCharsToCopy] = 0;

    return numOfCharsToCopy+1;
   }

//-----------------------------------------------------------------------------
SIZE_T
CLICALL
cliEnumCategoryComponents( CHAR const * categoryId
                         , SIZE_T componentIdx
                         , SIZE_T bufSize
                         , CHAR *componentNameBuf
                         )
   {
    if (!categoryId) return 0;
    if (!pCategoryComponents) return 0;

    // components staticaly  linked, not needed to lock list
    //CLI_AUTOLOCK_EX(componentListLocker, clCs);

    bool bFound = false;
    CCategoryListItem* pItem = pCategoryComponents->findCategory(categoryId, bFound);
    if (!bFound)
       return 0; // category not found

    SIZE_T curIdx = 0;
    CStringListItem *pComp = pItem->categoryComponents;
    while(pComp && curIdx<componentIdx)
       {
        ++curIdx;
        pComp = pComp->next;
       }

    if (!pComp || !pComp->str) return 0; // index out of range

    SIZE_T compLen = strlen(pComp->str);

    if (!componentNameBuf) return compLen+1;

    if (!bufSize) return 0; // error - buf len is zero, enum stops

    SIZE_T numOfCharsToCopy = bufSize-1; // exclude terminating zero
    if (numOfCharsToCopy>compLen)
       numOfCharsToCopy = compLen;

    memcpy( (void*)componentNameBuf, (void*)pComp->str, numOfCharsToCopy);
    componentNameBuf[numOfCharsToCopy] = 0;

    return numOfCharsToCopy+1;
   }

//-----------------------------------------------------------------------------



