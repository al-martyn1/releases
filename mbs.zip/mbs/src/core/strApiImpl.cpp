#define CLI_INTERNAL

#ifndef CLI_STRAPI_H
    #include <cli/strapi.h>
#endif

static INTERFACE_CLI_STRINGHELPER    * pStringHelper   = 0;
static INTERFACE_CLI_CSTRINGHELPER   * pCStringHelper  = 0;
static INTERFACE_CLI_PSTRINGHELPER   * pPStringHelper  = 0;
static INTERFACE_CLI_PCSTRINGHELPER  * pPCStringHelper = 0;


namespace cli
{

struct stringHelperImpl : public ::cli::stringHelper
   {
    CLIMETHOD_(SIZE_T, size) (THIS_ const CLISTR*     cliStr)
       {
        const CCliStr *pCliStr = reinterpret_cast<const CCliStr*>(cliStr);
        return pCliStr->stringSize;
       }

    CLIMETHOD_(CONST_PWCHAR, c_str) (THIS_ const CLISTR*     cliStr)
       {
        const CCliStr *pCliStr = reinterpret_cast<const CCliStr*>(cliStr);
        return (CONST_PWCHAR)pCliStr->pData;
       }

    CLIMETHOD_(CONST_PWCHAR, data) (THIS_ const CLISTR*     cliStr)
       {
        const CCliStr *pCliStr = reinterpret_cast<const CCliStr*>(cliStr);
        return (CONST_PWCHAR)pCliStr->pData;
       }

    CLIMETHOD(alloc) ( CLISTR* cliStr, const WCHAR* str )
       {
        CCliStr *pCliStr = reinterpret_cast<CCliStr*>(cliStr);
        pCliStr->init();
        pCliStr->assign(str);
        return 0;
       }

    CLIMETHOD(allocLen) ( CLISTR* cliStr, const WCHAR* str, SIZE_T strLen )
       {
        CCliStr *pCliStr = reinterpret_cast<CCliStr*>(cliStr);
        pCliStr->init();
        pCliStr->assign(str, strLen);
        return 0;
       }

    CLIMETHOD(free) ( CLISTR* cliStr )
       {
        CCliStr *pCliStr = reinterpret_cast<CCliStr*>(cliStr);
        pCliStr->uninit();
        return 0;
       }

    CLIMETHOD(assign) ( CLISTR* cliStr, const WCHAR* str )
       {
        CCliStr *pCliStr = reinterpret_cast<CCliStr*>(cliStr);
        // allready initialized
        pCliStr->assign(str);
        return 0;
       }

    CLIMETHOD(assignLen) ( CLISTR* cliStr, const WCHAR* str, SIZE_T strLen )
       {
        CCliStr *pCliStr = reinterpret_cast<CCliStr*>(cliStr);
        // allready initialized
        pCliStr->assign(str, strLen);
        return 0;
       }

    CLIMETHOD(append) ( CLISTR* cliStr, const WCHAR* str )
       {
        CCliStr *pCliStr = reinterpret_cast<CCliStr*>(cliStr);
        // allready initialized
        pCliStr->append(str);
        return 0;
       }

    CLIMETHOD(appendLen) ( CLISTR* cliStr, const WCHAR* str, SIZE_T strLen )
       {
        CCliStr *pCliStr = reinterpret_cast<CCliStr*>(cliStr);
        // allready initialized
        pCliStr->append(str, strLen);
        return 0;
       }

   };


struct cstringHelperImpl : public ::cli::cstringHelper
   {
    CLIMETHOD_(SIZE_T, size) (THIS_ const CLICSTR*     cliStr)
       {
        const CCliCStr *pCliStr = reinterpret_cast<const CCliCStr*>(cliStr);
        return pCliStr->stringSize;
       }

    CLIMETHOD_(CONST_PCHAR, c_str) (THIS_ const CLICSTR*     cliStr)
       {
        const CCliCStr *pCliStr = reinterpret_cast<const CCliCStr*>(cliStr);
        return (CONST_PCHAR)pCliStr->pData;
       }

    CLIMETHOD_(CONST_PCHAR, data) (THIS_ const CLICSTR*     cliStr)
       {
        const CCliCStr *pCliStr = reinterpret_cast<const CCliCStr*>(cliStr);
        return (CONST_PCHAR)pCliStr->pData;
       }

    CLIMETHOD(alloc) ( CLICSTR* cliStr, const CHAR* str )
       {
        CCliCStr *pCliStr = reinterpret_cast<CCliCStr*>(cliStr);
        pCliStr->init();
        pCliStr->assign(str);
        return 0;
       }

    CLIMETHOD(allocLen) ( CLICSTR* cliStr, const CHAR* str, SIZE_T strLen )
       {
        CCliCStr *pCliStr = reinterpret_cast<CCliCStr*>(cliStr);
        pCliStr->init();
        pCliStr->assign(str, strLen);
        return 0;
       }

    CLIMETHOD(free) ( CLICSTR* cliStr )
       {
        CCliCStr *pCliStr = reinterpret_cast<CCliCStr*>(cliStr);
        pCliStr->uninit();
        return 0;
       }

    CLIMETHOD(assign) ( CLICSTR* cliStr, const CHAR* str )
       {
        CCliCStr *pCliStr = reinterpret_cast<CCliCStr*>(cliStr);
        // allready initialized
        pCliStr->assign(str);
        return 0;
       }

    CLIMETHOD(assignLen) ( CLICSTR* cliStr, const CHAR* str, SIZE_T strLen )
       {
        CCliCStr *pCliStr = reinterpret_cast<CCliCStr*>(cliStr);
        // allready initialized
        pCliStr->assign(str, strLen);
        return 0;
       }

    CLIMETHOD(append) ( CLICSTR* cliStr, const CHAR* str )
       {
        CCliCStr *pCliStr = reinterpret_cast<CCliCStr*>(cliStr);
        // allready initialized
        pCliStr->append(str);
        return 0;
       }

    CLIMETHOD(appendLen) ( CLICSTR* cliStr, const CHAR* str, SIZE_T strLen )
       {
        CCliCStr *pCliStr = reinterpret_cast<CCliCStr*>(cliStr);
        // allready initialized
        pCliStr->append(str, strLen);
        return 0;
       }

   };


// typedef struct tag_CLIPSTR
// {
//     SIZE_T                       strSize;        // 4/8
//     WCHAR                        str[1];
// } _CLIPSTR, *CLIPSTR;

struct pstringHelperImpl : public ::cli::pstringHelper
{
    /* interface ::cli::pstringHelper methods */
    CLIMETHOD_(SIZE_T, size) (THIS_ CLIPSTR           cliStr)
       {
        return cliStr->strSize;
       }

    CLIMETHOD_(CONST_PWCHAR, c_str) (THIS_ CLIPSTR           cliStr)
       {
        return (CONST_PWCHAR)&cliStr->str[0];
       }

    CLIMETHOD_(CONST_PWCHAR, data) (THIS_ CLIPSTR           cliStr)
       {
        return (CONST_PWCHAR)&cliStr->str[0];
       }

    CLIMETHOD(alloc) (THIS_ CLIPSTR*          cliStr
                          , const WCHAR*    str /* [in] wchar  str[]  */
                     )
       {
        clipstr_alloc( cliStr, str );
        return 0;
       }

    CLIMETHOD(allocLen) (THIS_ CLIPSTR*          cliStr
                             , const WCHAR*    str /* [in] wchar  str[]  */
                             , SIZE_T    strLen /* [in] size_t  strLen  */
                        )
       {
        clipstr_alloc( cliStr, str, strLen );
        return 0;
       }

    CLIMETHOD(free) (THIS_ CLIPSTR*          cliStr)
       {
        clipstr_free( cliStr );
        return 0;
       }

    CLIMETHOD(assign) (THIS_ CLIPSTR*          cliStr
                           , const WCHAR*    str /* [in] wchar  str[]  */
                      )
       {
        clipstr_assign( cliStr, str );
        return 0;
       }

    CLIMETHOD(assignLen) (THIS_ CLIPSTR*          cliStr
                              , const WCHAR*    str /* [in] wchar  str[]  */
                              , SIZE_T    strLen /* [in] size_t  strLen  */
                         )
       {
        clipstr_assign( cliStr, str, strLen );
        return 0;
       }

    CLIMETHOD(append) (THIS_ CLIPSTR*          cliStr
                           , const WCHAR*    str /* [in] wchar  str[]  */
                      )
       {
        clipstr_append( cliStr, str );
        return 0;
       }

    CLIMETHOD(appendLen) (THIS_ CLIPSTR*          cliStr
                              , const WCHAR*    str /* [in] wchar  str[]  */
                              , SIZE_T    strLen /* [in] size_t  strLen  */
                         )
       {
        clipstr_append( cliStr, str, strLen );
        return 0;
       }


};




struct pcstringHelperImpl : public ::cli::pcstringHelper
{
    /* interface ::cli::pstringHelper methods */
    CLIMETHOD_(SIZE_T, size) (THIS_ CLIPCSTR           cliStr)
       {
        return cliStr->strSize;
       }

    CLIMETHOD_(CONST_PCHAR, c_str) (THIS_ CLIPCSTR           cliStr)
       {
        return (CONST_PCHAR)&cliStr->str[0];
       }

    CLIMETHOD_(CONST_PCHAR, data) (THIS_ CLIPCSTR           cliStr)
       {
        return (CONST_PCHAR)&cliStr->str[0];
       }

    CLIMETHOD(alloc) (THIS_ CLIPCSTR*          cliStr
                          , const CHAR*    str /* [in] wchar  str[]  */
                     )
       {
        clipstr_alloc( cliStr, str );
        return 0;
       }

    CLIMETHOD(allocLen) (THIS_ CLIPCSTR*          cliStr
                             , const CHAR*    str /* [in] wchar  str[]  */
                             , SIZE_T    strLen /* [in] size_t  strLen  */
                        )
       {
        clipstr_alloc( cliStr, str, strLen );
        return 0;
       }

    CLIMETHOD(free) (THIS_ CLIPCSTR*          cliStr)
       {
        clipstr_free( cliStr );
        return 0;
       }

    CLIMETHOD(assign) (THIS_ CLIPCSTR*          cliStr
                           , const CHAR*    str /* [in] wchar  str[]  */
                      )
       {
        clipstr_assign( cliStr, str );
        return 0;
       }

    CLIMETHOD(assignLen) (THIS_ CLIPCSTR*          cliStr
                              , const CHAR*    str /* [in] wchar  str[]  */
                              , SIZE_T    strLen /* [in] size_t  strLen  */
                         )
       {
        clipstr_assign( cliStr, str, strLen );
        return 0;
       }

    CLIMETHOD(append) (THIS_ CLIPCSTR*          cliStr
                           , const CHAR*    str /* [in] wchar  str[]  */
                      )
       {
        clipstr_append( cliStr, str );
        return 0;
       }

    CLIMETHOD(appendLen) (THIS_ CLIPCSTR*          cliStr
                              , const CHAR*    str /* [in] wchar  str[]  */
                              , SIZE_T    strLen /* [in] size_t  strLen  */
                         )
       {
        clipstr_append( cliStr, str, strLen );
        return 0;
       }


};





void initStringHelpers()
   {
    if (!pStringHelper)
       pStringHelper = new stringHelperImpl();

    if (!pCStringHelper)
       pCStringHelper = new cstringHelperImpl();

    if (!pPStringHelper)
       pPStringHelper = new pstringHelperImpl();

    if (!pPCStringHelper)
       pPCStringHelper = new pcstringHelperImpl();
   }

}; // namespace cli

CLIAPIENTRY
INTERFACE_CLI_STRINGHELPER*
CLICALL
cliGetStringHelper( )
   {
    return pStringHelper;
   }

CLIAPIENTRY
INTERFACE_CLI_CSTRINGHELPER*
CLICALL
cliGetCStringHelper( )
   {
    return pCStringHelper;
   }

EXTERN_CLI
CLIAPIENTRY
INTERFACE_CLI_PSTRINGHELPER*
CLICALL
cliGetPStringHelper( )
   {
    return pPStringHelper;
   }

EXTERN_CLI
CLIAPIENTRY
INTERFACE_CLI_PCSTRINGHELPER*
CLICALL
cliGetPCStringHelper( )
   {
    return pPCStringHelper;
   }


