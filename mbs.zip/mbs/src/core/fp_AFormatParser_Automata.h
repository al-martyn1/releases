#ifndef FP_AFORMATPARSER_AUTOMATA_H
#define FP_AFORMATPARSER_AUTOMATA_H

/* Warning! Automaticaly generated file, do not edit */

#include <cli/format.h>
#include <string>
#include <cli/cliutilx.h>





namespace cli {
namespace format {
namespace impl {

class CFormatParser {

    protected:  ::std::wstring      *pResBuf     ;
    public:     SIZE_T               linePos     ;
    public:     SIZE_T               tabIndex    ;
    public:     ::std::wstring       fmtBuf      ;
    public:     int                  argNo       ;
    public:     bool                 bAllowAsciiCtrlChars;
    public:     bool                 bIgnoreFormatLf;
    public:     const INT           *tabs        ;
    public:     SIZE_T               tabsSize    ;
    public:     INTERFACE_CLI_IARGLIST*pArgs       ;
    public:     bool                 fLongTabs   ;
    protected:  int                  intVal      ;
    protected:  ::std::wstring       formatStr   ;
    protected:  ::std::wstring       fmtFlags    ;
    protected:  ::std::wstring       fmtWidth    ;
    public:     ::std::wstring       fmtPrecision;
    public:     ::std::wstring       fmtType     ;
    public:     ::std::wstring       customFmtName;
    public:     ::std::wstring       customFmtString;
    public:     DWORD                formatGlobalFlags;
    protected:  int                  curState    ; //!< Automaticaly added member for saving current automata state
    public:     static const int     ST_eOD       = 0x80000001; //!< EOD
    public:     static const int     ST_readArgno = 0x00000002; //!< READ_ARGNO
    public:     static const int     ST_readCustomFormat = 0x00000003; //!< READ_CUSTOM_FORMAT
    public:     static const int     ST_readCustomName = 0x00000004; //!< READ_CUSTOM_NAME
    public:     static const int     ST_readFmtFlags = 0x00000005; //!< READ_FMT_FLAGS
    public:     static const int     ST_readFmtPrecision = 0x00000006; //!< READ_FMT_PRECISION
    public:     static const int     ST_readFmtType = 0x00000007; //!< READ_FMT_TYPE
    public:     static const int     ST_readFmtWidth = 0x00000008; //!< READ_FMT_WIDTH
    public:     static const int     ST_readTabAbs = 0x00000009; //!< READ_TAB_ABS
    public:     static const int     ST_startTab  = 0x0000000A; //!< START_TAB
    public:     static const int     ST_waitEndExcl = 0x0000000B; //!< WAIT_END_EXCL
    public:     static const int     ST_waitFmtNext = 0x0000000C; //!< WAIT_FMT_NEXT
    public:     static const int     ST_waitFmtStart = 0x0000000D; //!< WAIT_FMT_START
    public:     static const int     ST_waitTabSize = 0x0000000E; //!< WAIT_TAB_SIZE
    public:     static const int     ST_waitTsiDigit = 0x0000000F; //!< WAIT_TSI_DIGIT
    public:     static const int     ST_intStatefinalmask = 0x80000000; //!< __int_stateFinalMask__


    public:     
        int
        putChar
               ( WCHAR  ch          
               )
           {
            /* guard variable - ch */
            switch(this->curState)
               {
                case ST_readArgno:    /* READ_ARGNO */
                        if ((isDigit(ch))) /* Guard: [(isDigit(GUARDVAR))] */
                           {
                               /* State READ_ARGNO - exit_action empty */
                               /* Transition from READ_ARGNO to READ_ARGNO actions */
                               { readIntVal(ch); }
                               /* State READ_ARGNO - entry_action empty */
                            this->curState = ST_readArgno;
                           }
                        else if (ch==L'%') /* Guard: ['%'] */
                           {
                               /* State READ_ARGNO - exit_action empty */
                               /* Transition from READ_ARGNO to WAIT_FMT_NEXT actions */
                               { addFormattedValue(intVal); }
                               /* State WAIT_FMT_NEXT - entry_action empty */
                            this->curState = ST_waitFmtNext;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State READ_ARGNO - exit_action empty */
                               /* Transition from READ_ARGNO to READ_FMT_FLAGS actions */
                               { clearFmt(); }
                               /* State READ_FMT_FLAGS - entry_action empty */
                            this->curState = ST_readFmtFlags;
                           }
                        else
                           {
                               /* State READ_ARGNO - exit_action empty */
                               /* Transition from READ_ARGNO to WAIT_FMT_START actions */
                               { addFormattedValue(intVal); appendChar(ch); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                     break;
                case ST_readCustomFormat:    /* READ_CUSTOM_FORMAT */
                        if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State READ_CUSTOM_FORMAT - exit_action empty */
                               /* Transition from READ_CUSTOM_FORMAT to WAIT_FMT_START actions */
                               { addCustomFormattedValue(intVal); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* Transition from READ_CUSTOM_FORMAT to READ_CUSTOM_FORMAT actions */
                               { customFmtString.append(1, ch); }
                               /* State READ_CUSTOM_FORMAT - do_action empty */
                            this->curState = ST_readCustomFormat;
                           }
                     break;
                case ST_readCustomName:    /* READ_CUSTOM_NAME */
                        if (ch==L':') /* Guard: [':'] */
                           {
                               /* State READ_CUSTOM_NAME - exit_action empty */
                               /* Transition from READ_CUSTOM_NAME to READ_CUSTOM_FORMAT actions */
                               /* State READ_CUSTOM_FORMAT - entry_action empty */
                            this->curState = ST_readCustomFormat;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State READ_CUSTOM_NAME - exit_action empty */
                               /* Transition from READ_CUSTOM_NAME to WAIT_FMT_START actions */
                               { addCustomFormattedValue(intVal); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* Transition from READ_CUSTOM_NAME to READ_CUSTOM_NAME actions */
                               { customFmtName.append(1, ch); }
                               /* State READ_CUSTOM_NAME - do_action empty */
                            this->curState = ST_readCustomName;
                           }
                     break;
                case ST_readFmtFlags:    /* READ_FMT_FLAGS */
                        if (ch==L':') /* Guard: [':'] */
                           {
                               /* State READ_FMT_FLAGS - exit_action empty */
                               /* Transition from READ_FMT_FLAGS to READ_CUSTOM_NAME actions */
                               /* State READ_CUSTOM_NAME - entry_action */
                               { clearFmtCustom(); }
                            this->curState = ST_readCustomName;
                           }
                        else if (ch>=L'1' && ch<=L'9') /* Guard: ['1'-'9'] */
                           {
                               /* State READ_FMT_FLAGS - exit_action empty */
                               /* Transition from READ_FMT_FLAGS to READ_FMT_WIDTH actions */
                               { fmtWidth.append(1, ch); }
                               /* State READ_FMT_WIDTH - entry_action empty */
                            this->curState = ST_readFmtWidth;
                           }
                        else if (ch==L'.') /* Guard: ['.'] */
                           {
                               /* State READ_FMT_FLAGS - exit_action empty */
                               /* Transition from READ_FMT_FLAGS to READ_FMT_PRECISION actions */
                               { fmtPrecision.append(1, ch); }
                               /* State READ_FMT_PRECISION - entry_action empty */
                            this->curState = ST_readFmtPrecision;
                           }
                        else if (ch==L'-' || ch==L'+' || ch==L' ' || ch==L'\'' || ch==L'#' || ch==L'0' || ch==L'q') /* Guard: ['-','+',' ','\'','#','0','q'] */
                           {
                               /* Transition from READ_FMT_FLAGS to READ_FMT_FLAGS actions */
                               { fmtFlags.append(1, ch); }
                               /* State READ_FMT_FLAGS - do_action empty */
                            this->curState = ST_readFmtFlags;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State READ_FMT_FLAGS - exit_action empty */
                               /* Transition from READ_FMT_FLAGS to WAIT_FMT_START actions */
                               { addFormattedValue(intVal); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* State READ_FMT_FLAGS - exit_action empty */
                               /* Transition from READ_FMT_FLAGS to READ_FMT_TYPE actions */
                               { fmtType.append(1, ch); }
                               /* State READ_FMT_TYPE - entry_action empty */
                            this->curState = ST_readFmtType;
                           }
                     break;
                case ST_readFmtPrecision:    /* READ_FMT_PRECISION */
                        if (ch==L':') /* Guard: [':'] */
                           {
                               /* State READ_FMT_PRECISION - exit_action empty */
                               /* Transition from READ_FMT_PRECISION to READ_CUSTOM_NAME actions */
                               /* State READ_CUSTOM_NAME - entry_action */
                               { clearFmtCustom(); }
                            this->curState = ST_readCustomName;
                           }
                        else if (ch>=L'0' && ch<=L'9') /* Guard: ['0'-'9'] */
                           {
                               /* Transition from READ_FMT_PRECISION to READ_FMT_PRECISION actions */
                               { fmtPrecision.append(1, ch); }
                               /* State READ_FMT_PRECISION - do_action empty */
                            this->curState = ST_readFmtPrecision;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State READ_FMT_PRECISION - exit_action empty */
                               /* Transition from READ_FMT_PRECISION to WAIT_FMT_START actions */
                               { addFormattedValue(intVal); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* State READ_FMT_PRECISION - exit_action empty */
                               /* Transition from READ_FMT_PRECISION to READ_FMT_TYPE actions */
                               { fmtType.append(1, ch); }
                               /* State READ_FMT_TYPE - entry_action empty */
                            this->curState = ST_readFmtType;
                           }
                     break;
                case ST_readFmtType:    /* READ_FMT_TYPE */
                        if (ch==L':') /* Guard: [':'] */
                           {
                               /* State READ_FMT_TYPE - exit_action empty */
                               /* Transition from READ_FMT_TYPE to READ_CUSTOM_NAME actions */
                               /* State READ_CUSTOM_NAME - entry_action */
                               { clearFmtCustom(); }
                            this->curState = ST_readCustomName;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State READ_FMT_TYPE - exit_action empty */
                               /* Transition from READ_FMT_TYPE to WAIT_FMT_START actions */
                               { addFormattedValue(intVal); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* Transition from READ_FMT_TYPE to READ_FMT_TYPE actions */
                               { fmtType.append(1, ch); }
                               /* State READ_FMT_TYPE - do_action empty */
                            this->curState = ST_readFmtType;
                           }
                     break;
                case ST_readFmtWidth:    /* READ_FMT_WIDTH */
                        if (ch==L':') /* Guard: [':'] */
                           {
                               /* State READ_FMT_WIDTH - exit_action empty */
                               /* Transition from READ_FMT_WIDTH to READ_CUSTOM_NAME actions */
                               /* State READ_CUSTOM_NAME - entry_action */
                               { clearFmtCustom(); }
                            this->curState = ST_readCustomName;
                           }
                        else if (ch>=L'0' && ch<=L'9') /* Guard: ['0'-'9'] */
                           {
                               /* Transition from READ_FMT_WIDTH to READ_FMT_WIDTH actions */
                               { fmtWidth.append(1, ch); }
                               /* State READ_FMT_WIDTH - do_action empty */
                            this->curState = ST_readFmtWidth;
                           }
                        else if (ch==L'.') /* Guard: ['.'] */
                           {
                               /* State READ_FMT_WIDTH - exit_action empty */
                               /* Transition from READ_FMT_WIDTH to READ_FMT_PRECISION actions */
                               { fmtPrecision.append(1, ch); }
                               /* State READ_FMT_PRECISION - entry_action empty */
                            this->curState = ST_readFmtPrecision;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State READ_FMT_WIDTH - exit_action empty */
                               /* Transition from READ_FMT_WIDTH to WAIT_FMT_START actions */
                               { addFormattedValue(intVal); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* State READ_FMT_WIDTH - exit_action empty */
                               /* Transition from READ_FMT_WIDTH to READ_FMT_TYPE actions */
                               { fmtType.append(1, ch); }
                               /* State READ_FMT_TYPE - entry_action empty */
                            this->curState = ST_readFmtType;
                           }
                     break;
                case ST_readTabAbs:    /* READ_TAB_ABS */
                        if ((isDigit(ch))) /* Guard: [(isDigit(GUARDVAR))] */
                           {
                               /* State READ_TAB_ABS - exit_action empty */
                               /* Transition from READ_TAB_ABS to READ_TAB_ABS actions */
                               { readIntVal(ch); }
                               /* State READ_TAB_ABS - entry_action empty */
                            this->curState = ST_readTabAbs;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State READ_TAB_ABS - exit_action empty */
                               /* Transition from READ_TAB_ABS to WAIT_FMT_START actions */
                               { makeTabAbs(intVal); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* State READ_TAB_ABS - exit_action empty */
                               /* Transition from READ_TAB_ABS to WAIT_END_EXCL actions */
                               { makeTabAbs(intVal); }
                               /* State WAIT_END_EXCL - entry_action empty */
                            this->curState = ST_waitEndExcl;
                           }
                     break;
                case ST_startTab:    /* START_TAB */
                        if (ch==L'%') /* Guard: ['%'] */
                           {
                               /* State START_TAB - exit_action empty */
                               /* Transition from START_TAB to WAIT_FMT_NEXT actions */
                               { makeTabByIndex(); }
                               /* State WAIT_FMT_NEXT - entry_action empty */
                            this->curState = ST_waitFmtNext;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State START_TAB - exit_action empty */
                               /* Transition from START_TAB to WAIT_TAB_SIZE actions */
                               { intVal = -1; }
                               /* State WAIT_TAB_SIZE - entry_action empty */
                            this->curState = ST_waitTabSize;
                           }
                        else
                           {
                               /* State START_TAB - exit_action empty */
                               /* Transition from START_TAB to WAIT_FMT_START actions */
                               { makeTabByIndex(); appendChar(ch); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                     break;
                case ST_waitEndExcl:    /* WAIT_END_EXCL */
                        if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State WAIT_END_EXCL - exit_action empty */
                               /* Transition from WAIT_END_EXCL to WAIT_FMT_START actions */
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* Transition from WAIT_END_EXCL to WAIT_END_EXCL actions */
                               /* State WAIT_END_EXCL - do_action empty */
                            this->curState = ST_waitEndExcl;
                           }
                     break;
                case ST_waitFmtNext:    /* WAIT_FMT_NEXT */
                        if ((isDigit(ch))) /* Guard: [(isDigit(GUARDVAR))] */
                           {
                               /* State WAIT_FMT_NEXT - exit_action empty */
                               /* Transition from WAIT_FMT_NEXT to READ_ARGNO actions */
                               { intVal=convertDigit(ch); }
                               /* State READ_ARGNO - entry_action empty */
                            this->curState = ST_readArgno;
                           }
                        else if (ch==L't') /* Guard: ['t'] */
                           {
                               /* State WAIT_FMT_NEXT - exit_action empty */
                               /* Transition from WAIT_FMT_NEXT to START_TAB actions */
                               /* State START_TAB - entry_action empty */
                            this->curState = ST_startTab;
                           }
                        else if (ch==L'n') /* Guard: ['n'] */
                           {
                               /* State WAIT_FMT_NEXT - exit_action empty */
                               /* Transition from WAIT_FMT_NEXT to WAIT_FMT_START actions */
                               { appendCharRaw(bIgnoreFormatLf?L' ':L'\n'); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else if (ch==L'%') /* Guard: ['%'] */
                           {
                               /* State WAIT_FMT_NEXT - exit_action empty */
                               /* Transition from WAIT_FMT_NEXT to WAIT_FMT_START actions */
                               { appendCharRaw(ch); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* State WAIT_FMT_NEXT - exit_action empty */
                               /* Transition from WAIT_FMT_NEXT to WAIT_FMT_START actions */
                               { appendChar(ch); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                     break;
                case ST_waitFmtStart:    /* WAIT_FMT_START */
                        if (ch==L'%') /* Guard: ['%'] */
                           {
                               /* State WAIT_FMT_START - exit_action empty */
                               /* Transition from WAIT_FMT_START to WAIT_FMT_NEXT actions */
                               /* State WAIT_FMT_NEXT - entry_action empty */
                            this->curState = ST_waitFmtNext;
                           }
                        else
                           {
                               /* Transition from WAIT_FMT_START to WAIT_FMT_START actions */
                               { appendChar(ch); }
                               /* State WAIT_FMT_START - do_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                     break;
                case ST_waitTabSize:    /* WAIT_TAB_SIZE */
                        if ((isDigit(ch))) /* Guard: [(isDigit(GUARDVAR))] */
                           {
                               /* State WAIT_TAB_SIZE - exit_action empty */
                               /* Transition from WAIT_TAB_SIZE to READ_TAB_ABS actions */
                               { intVal=convertDigit(ch); }
                               /* State READ_TAB_ABS - entry_action empty */
                            this->curState = ST_readTabAbs;
                           }
                        else if (ch==L'*') /* Guard: ['*'] */
                           {
                               /* State WAIT_TAB_SIZE - exit_action empty */
                               /* Transition from WAIT_TAB_SIZE to WAIT_TSI_DIGIT actions */
                               /* State WAIT_TSI_DIGIT - entry_action empty */
                            this->curState = ST_waitTsiDigit;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State WAIT_TAB_SIZE - exit_action empty */
                               /* Transition from WAIT_TAB_SIZE to WAIT_FMT_START actions */
                               { makeTabByIndex(); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* State WAIT_TAB_SIZE - exit_action empty */
                               /* Transition from WAIT_TAB_SIZE to WAIT_END_EXCL actions */
                               { makeTabByIndex(); }
                               /* State WAIT_END_EXCL - entry_action empty */
                            this->curState = ST_waitEndExcl;
                           }
                     break;
                case ST_waitTsiDigit:    /* WAIT_TSI_DIGIT */
                        if ((isDigit(ch))) /* Guard: [(isDigit(GUARDVAR))] */
                           {
                               /* State WAIT_TSI_DIGIT - exit_action empty */
                               /* Transition from WAIT_TSI_DIGIT to READ_TAB_ABS actions */
                               { intVal=-convertDigit(ch); }
                               /* State READ_TAB_ABS - entry_action empty */
                            this->curState = ST_readTabAbs;
                           }
                        else if (ch==L'!') /* Guard: ['!'] */
                           {
                               /* State WAIT_TSI_DIGIT - exit_action empty */
                               /* Transition from WAIT_TSI_DIGIT to WAIT_FMT_START actions */
                               { makeTabByIndex(); }
                               /* State WAIT_FMT_START - entry_action empty */
                            this->curState = ST_waitFmtStart;
                           }
                        else
                           {
                               /* State WAIT_TSI_DIGIT - exit_action empty */
                               /* Transition from WAIT_TSI_DIGIT to WAIT_END_EXCL actions */
                               { makeTabByIndex(); }
                               /* State WAIT_END_EXCL - entry_action empty */
                            this->curState = ST_waitEndExcl;
                           }
                     break;
               };
            return this->curState;
           }

    public:     
        int
        eod
           ( 
           )
           {
            /* there is no guard variable */
            switch(this->curState)
               {
                case ST_readArgno:    /* READ_ARGNO */
                           {
                               /* State READ_ARGNO - exit_action empty */
                               /* Transition from READ_ARGNO to EOD actions */
                               { addFormattedValue(intVal); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_readCustomFormat:    /* READ_CUSTOM_FORMAT */
                           {
                               /* State READ_CUSTOM_FORMAT - exit_action empty */
                               /* Transition from READ_CUSTOM_FORMAT to EOD actions */
                               { addCustomFormattedValue(intVal); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_readCustomName:    /* READ_CUSTOM_NAME */
                           {
                               /* State READ_CUSTOM_NAME - exit_action empty */
                               /* Transition from READ_CUSTOM_NAME to EOD actions */
                               { addCustomFormattedValue(intVal); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_readFmtFlags:    /* READ_FMT_FLAGS */
                           {
                               /* State READ_FMT_FLAGS - exit_action empty */
                               /* Transition from READ_FMT_FLAGS to EOD actions */
                               { addFormattedValue(intVal); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_readFmtPrecision:    /* READ_FMT_PRECISION */
                           {
                               /* State READ_FMT_PRECISION - exit_action empty */
                               /* Transition from READ_FMT_PRECISION to EOD actions */
                               { addFormattedValue(intVal); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_readFmtType:    /* READ_FMT_TYPE */
                           {
                               /* State READ_FMT_TYPE - exit_action empty */
                               /* Transition from READ_FMT_TYPE to EOD actions */
                               { addFormattedValue(intVal); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_readFmtWidth:    /* READ_FMT_WIDTH */
                           {
                               /* State READ_FMT_WIDTH - exit_action empty */
                               /* Transition from READ_FMT_WIDTH to EOD actions */
                               { addFormattedValue(intVal); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_readTabAbs:    /* READ_TAB_ABS */
                           {
                               /* State READ_TAB_ABS - exit_action empty */
                               /* Transition from READ_TAB_ABS to EOD actions */
                               { makeTabAbs(intVal); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_startTab:    /* START_TAB */
                           {
                               /* State START_TAB - exit_action empty */
                               /* Transition from START_TAB to EOD actions */
                               { makeTabByIndex(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_waitEndExcl:    /* WAIT_END_EXCL */
                           {
                               /* State WAIT_END_EXCL - exit_action empty */
                               /* Transition from WAIT_END_EXCL to EOD actions */
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_waitFmtNext:    /* WAIT_FMT_NEXT */
                           {
                               /* State WAIT_FMT_NEXT - exit_action empty */
                               /* Transition from WAIT_FMT_NEXT to EOD actions */
                               { appendChar(L'%'); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_waitFmtStart:    /* WAIT_FMT_START */
                           {
                               /* State WAIT_FMT_START - exit_action empty */
                               /* Transition from WAIT_FMT_START to EOD actions */
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_waitTabSize:    /* WAIT_TAB_SIZE */
                           {
                               /* State WAIT_TAB_SIZE - exit_action empty */
                               /* Transition from WAIT_TAB_SIZE to EOD actions */
                               { makeTabByIndex(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
                case ST_waitTsiDigit:    /* WAIT_TSI_DIGIT */
                           {
                               /* State WAIT_TSI_DIGIT - exit_action empty */
                               /* Transition from WAIT_TSI_DIGIT to EOD actions */
                               { makeTabByIndex(); }
                               /* End state EOD - entry_action empty */
                            this->curState = ST_eOD;
                           }
                     break;
               };
            return this->curState;
           }

    protected:  
        void
        appendCharRaw
                     ( WCHAR  ch          
                     )
           {
            pResBuf->append(1, ch);
            if (ch==L'\n') linePos = 0;
            else ++linePos;
           }

    protected:  
        void
        appendChar
                  ( WCHAR  ch          
                  )
           {
            if (isAsciiCtrlChar(ch) && !bAllowAsciiCtrlChars) return;
            appendCharRaw(ch);
           }

    protected:  
        void
        appendStringRaw
                       ( const ::std::wstring &str         
                       )
           {
            ::std::wstring::size_type i=0, size=str.size();
            for(; i!=size; ++i) appendCharRaw(str[i]);
           }

    protected:  
        void
        appendString
                    ( const ::std::wstring &str         
                    )
           {
            ::std::wstring::size_type i=0, size=str.size();
            for(; i!=size; ++i) appendChar(str[i]);
           }

    protected:  
        int
        convertDigit
                    ( WCHAR  ch          
                    )
           {
            if (ch>=L'0' && ch<=L'9') return ch-L'0';
            if (ch>=L'a' && ch<=L'z') return ch-L'a' + 10;
            if (ch>=L'A' && ch<=L'Z') return ch-L'A' + 10;
            return 36;
           }

    protected:  
        int
        isDigit
               ( WCHAR  ch          
               )
           {
            return convertDigit(ch)>9 ? 0 : 1;
           }

    protected:  
        int
        isAsciiCtrlChar
                       ( WCHAR  ch          
                       )
           {
            return (!ch || (ch>0 && ch<L' ')) ? 1 : 0;
           }

    protected:  
        void
        makeTabByIndex
                      ( 
                      )
           {
            INT tabPosition = 0;
            if (tabs && tabIndex<tabsSize)
                tabPosition = tabs[tabIndex++];
            else
               { const int tabSize = fLongTabs ? 8 : 4;
                //if (!(linePos%tabSize)) tabPosition = (INT)linePos;
                //else 
                tabPosition = (INT)((linePos/tabSize)+1)*tabSize;
               }
            makeTabAbs(tabPosition);
           }

    protected:  
        void
        makeTabAbs
                  ( INT  absPos      
                  )
           {
            if (absPos<0)
               {
                if (!pArgs) { makeTabByIndex(); return; }
                UINT pos = 0; pArgs->getUInt((-absPos)-1, &pos);
                absPos = (int)pos;
               }
            //if (absPos>0) --absPos;
            if ((INT)linePos<absPos)
               { 
                pResBuf->append(absPos-(INT)linePos, ' ');
                linePos = (SIZE_T)absPos;
               }
           }

    protected:  
        void
        readIntVal
                  ( WCHAR  ch          
                  )
           {
            intVal*=10; intVal+=convertDigit(ch);
           }

    protected:  
        void
        addFormattedValue
                         ( int  idx         
                         )
           {
            --idx; if (idx<0) idx = -idx;
            ::std::wstring formatted;
            formatValue( formatted, idx, fmtFlags
                       , fmtWidth, fmtPrecision, fmtType
                       , formatGlobalFlags );
            appendString(formatted);
            clearFmt(); // fmtWidth.clear(); fmtPrecision.clear();
                        // fmtFlags.clear(); fmtType.clear();
           }

    protected:  
        virtual
        void
        formatValue
                   ( ::std::wstring       &str         
                   , int                   idx         
                   , const ::std::wstring &formatFlags 
                   , const ::std::wstring &formatWidth 
                   , const ::std::wstring &formatPrecision
                   , const ::std::wstring &formatType  
                   , DWORD                 formatGlobalFlags
                   ) = 0;

    protected:  
        void
        clearFmt
                ( 
                )
           {
            fmtFlags.clear(); fmtWidth.clear();
            fmtPrecision.clear(); fmtType.clear();
           }

    protected:  
        virtual
        void
        formatCustom
                    ( ::std::wstring       &str         
                    , int                   idx         
                    , const ::std::wstring &formatFlags 
                    , const ::std::wstring &formatWidth 
                    , const ::std::wstring &formatPrecision
                    , const ::std::wstring &formaterName
                    , const ::std::wstring &customFormatStr
                    , DWORD                 formatGlobalFlags
                    ) = 0;

    protected:  
        void
        addCustomFormattedValue
                               ( int  idx         
                               )
           {
            --idx; if (idx<0) idx = -idx;
            ::std::wstring formatted;
            formatCustom( formatted, idx, fmtFlags
                        , fmtWidth, fmtPrecision
                        , customFmtName, customFmtString
                        , formatGlobalFlags );
            appendString(formatted);
            clearFmtCustom();
           }

    protected:  
        void
        clearFmtCustom
                      ( 
                      )
           {
            customFmtName.clear(); customFmtString.clear();
           }

    public:     
        int
        getCurState
                   ( 
                   ) const
           {
            return this->curState;
           }

    public:     
        int
        isInFinalState
                      ( 
                      ) const
           {
            return (this->curState & ST_intStatefinalmask) ? 1 : 0;
           }

    protected:  
        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            return;
           }

    public:     
        void
        resetAutomata
                     ( 
                     )
           {
            this->customResetAutomata(  );
            this->curState = ST_waitFmtStart;
           }

    public:     
        int
        isInInadmissibleFinalState
                                  ( 
                                  )
           {
            return 0;
           }


};


}; // namespace impl {
}; // namespace format {
}; // namespace cli {

#endif /* FP_AFORMATPARSER_AUTOMATA_H */
