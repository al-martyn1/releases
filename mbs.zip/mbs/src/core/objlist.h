#ifndef CORE_OBJLIST_H
#define CORE_OBJLIST_H

/* add this lines to your src
#ifndef CORE_OBJLIST_H
    #include "objlist.h"
#endif
*/

#ifndef CLI_IOBJLIST_H
    #include <cli/iobjlist.h>
#endif

#ifndef CLI_CSEC_H
    #include <cli/csec.h>
#endif


namespace cli
{
namespace impl
{

struct CObjListImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                    , public INTERFACE_CLI_IOBJECTLIST
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    ::std::vector< INTERFACE_CLI_IUNKNOWN* >                                 objList;
    ::cli::CCriticalSection                                                  cs;

    CObjListImpl() : base_impl(DEF_MODULE), objList(), cs()
       {
       }

    ~CObjListImpl()
       {
        clearList();
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP2(CObjListImpl, INTERFACE_CLI_IOBJECTLIST)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_IOBJECTLIST )
    CLI_END_INTERFACE_MAP(CObjListImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


    CLIMETHOD(pushObject) (THIS_ INTERFACE_CLI_IUNKNOWN*    pObj /* [in] ::cli::iUnknown*  pObj  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (pObj) 
                   {
                    objList.push_back(pObj);
                    pObj->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(insertObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */
                                 , INTERFACE_CLI_IUNKNOWN*    pObj /* [in] ::cli::iUnknown*  pObj  */
                            )
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (pos>=objList.size()) return pushObject(pObj);
                if (pObj) 
                   {
                    objList.insert( objList.begin() + pos, pObj );
                    pObj->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getObjectCount) (THIS_ SIZE_T*    s /* [out] size_t pos  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (s) *s = objList.size();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(objectCountGet) (THIS_ SIZE_T*    _objectCount /* [out] size_t _objectCount  */)
       {
        return getObjectCount(_objectCount);
       }       

    CLIMETHOD(getObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */
                              , INTERFACE_CLI_IUNKNOWN**    pObj /* [out] ::cli::iUnknown* pObj  */
                         )
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (pos>=objList.size()) 
                   {
                    if (pObj) *pObj = 0;
                    return EC_OUT_OF_RANGE;
                   }
                if (pObj)
                   {
                    *pObj = objList[pos];
                    (*pObj)->addRef();
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(removeObject) (THIS_ SIZE_T    pos /* [in] size_t  pos  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (pos>=objList.size()) return EC_OUT_OF_RANGE;
                INTERFACE_CLI_IUNKNOWN* pObj = objList[pos];
                if (pObj) pObj->release();
                objList.erase(objList.begin()+pos);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(clearList) (THIS)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                for(::std::vector< INTERFACE_CLI_IUNKNOWN* >::iterator it = objList.begin(); it!=objList.end(); ++it)
                   {
                    INTERFACE_CLI_IUNKNOWN* pObj = *it;
                    pObj->release();
                   }
                objList.clear();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(assignList) (THIS_ INTERFACE_CLI_IOBJECTLIST*    pObjList /* [in] ::cli::iObjectList*  pObjList  */)
       {
        clearList();
        appendList(pObjList);
        return EC_OK;
       }

    CLIMETHOD(appendList) (THIS_ INTERFACE_CLI_IOBJECTLIST*    pObjList /* [in] ::cli::iObjectList*  pObjList  */)
       {
        CLI_SCOPED_LOCK(cs);
        CLI_TRY{
                if (!pObjList) return EC_OK;
                SIZE_T i = 0;
                INTERFACE_CLI_IUNKNOWN* pObj = 0;
                while( !pObjList->getObject(i++,&pObj) && pObj)
                   {
                    objList.push_back(pObj);
                    pObj = 0;
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


}; // struct CObjListImpl

}; // namespace impl
}; //namespace cli


#endif /* CORE_OBJLIST_H */

