
#ifndef SRC_CORE_LANGUTIL_H
#define SRC_CORE_LANGUTIL_H

/* add this lines to your scr
#ifndef SRC_CORE_LANGUTIL_H
    #include "langUtil.h"
#endif
*/

#ifndef SRC_CORE_FLATSTRUTILS_H
    #include "flatStrUtils.h"
#endif


namespace cli
{
namespace impl
{


template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator>
normalizeLangIdString( const ::std::basic_string<CharType, Traits, Allocator> &langIdStr )
{
    ::std::basic_string<CharType, Traits, Allocator> resLangId;
    resLangId.reserve(langIdStr.size());

    bool secondPart = false;

    typename ::std::basic_string<CharType, Traits, Allocator>::size_type i = 0, size = langIdStr.size();
    for(; i!=size; ++i)
       {
        CharType ch = langIdStr[i];
        if ( (ch>=(CharType)'a' && ch<=(CharType)'z')
           ||(ch>=(CharType)'A' && ch<=(CharType)'Z')
           )
           {
            if (!secondPart)
                resLangId.append(1, flat_str_utils::toLowerCase<CharType>(ch));
            else
                resLangId.append(1, flat_str_utils::toUpperCase<CharType>(ch));
            continue;
           }
        if (ch==(CharType)'-' || ch==(CharType)'_')
           {
            resLangId.append(1, (CharType)'-');
            secondPart = true;
            continue;
           }
        return resLangId;
       }
    return resLangId;
}


template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator>
getLangIdPrimaryLang( ::std::basic_string<CharType, Traits, Allocator> langIdStr )
{
    langIdStr = normalizeLangIdString(langIdStr);

    //std::string resLangId;

    typename ::std::basic_string<CharType, Traits, Allocator>::size_type i = 0, size = langIdStr.size();
    for(; i!=size; ++i)
       {
        CharType ch = langIdStr[i];
        if (ch==(CharType)'-' || ch==(CharType)'_')
           return ::std::basic_string<CharType, Traits, Allocator>( langIdStr, 0, i );
       }
    return langIdStr;
}

template <typename CharType, typename Traits, typename Allocator>
::std::basic_string<CharType, Traits, Allocator>
getLangIdSubLang( ::std::basic_string<CharType, Traits, Allocator> langIdStr )
{
    langIdStr = normalizeLangIdString(langIdStr);

    //std::string resLangId;

    typename ::std::basic_string<CharType, Traits, Allocator>::size_type i = 0, size = langIdStr.size();
    for(; i!=size; ++i)
       {
        CharType ch = langIdStr[i];
        if (ch==(CharType)'-' || ch==(CharType)'_')
           return ::std::basic_string<CharType, Traits, Allocator>( langIdStr, i+1, std::string::npos );
       }
    return ::std::basic_string<CharType, Traits, Allocator>();
}


template <typename CharType, typename Traits, typename Allocator>
int isLangIdEqual( ::std::basic_string<CharType, Traits, Allocator> langId1, ::std::basic_string<CharType, Traits, Allocator> langId2 )
{
    langId1 = normalizeLangIdString( langId1 );
    langId2 = normalizeLangIdString( langId2 );

    if (langId1.empty() || langId2.empty()) return 0; // empty lang exact equal to any other

    if (langId1==langId2) return 0; // exact equal

    if (getLangIdPrimaryLang(langId1)==getLangIdPrimaryLang(langId2)) return 1;

    return -1; // not equal
}

inline
int isLangIdEqual( const char *langId1, const char *langId2 )
{
    return isLangIdEqual( langId1 ? std::string(langId1) : std::string(), langId2 ? std::string(langId2) : std::string() );
}



}; // namespace impl
}; // namespace cli


#endif /* SRC_CORE_LANGUTIL_H */

