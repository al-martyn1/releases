#ifndef SRC_CORE_DDXPATH_H
#define SRC_CORE_DDXPATH_H

/* add this lines to your src
#ifndef SRC_CORE_DDXPATH_H
    #include "ddxpath.h"
#endif
*/

#ifndef CLI_IDATADOM_H
    #include <cli/idatadom.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef CLI_VARIANT_H
    #include <cli/variant.h>
#endif

#ifndef CLI_IVARMAP_H
    #include <cli/ivarmap.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#include <marty/caseconv.h>
#include "langUtil.h"




// http://allxml.h1.ru/articles/xpath.htm
// http://msdn.microsoft.com/ru-ru/library/ms256236.aspx
// http://msdn.microsoft.com/ru-ru/library/ms256086.aspx

// ::cli::datadom::xpath::

// http://techyou.ru/archives/category/%d1%80%d0%b0%d1%81%d1%81%d1%82%d0%b0%d0%bd%d0%be%d0%b2%d0%ba%d0%b0-%d0%bf%d1%80%d0%b8%d0%be%d1%80%d0%b8%d1%82%d0%b5%d1%82%d0%be%d0%b2

namespace cli
{
namespace datadom
{
namespace xpath
{

    enum token_t
    {
        tokenNone = 0,


/*
1 ( )        �����������
2 [ ]        ����������
3 / � //     �������� � �����
4 div mod *
5 + -
6 < <= > >=  ���������
7 = !=       ���������
8 |          �����������
  not()      ������ "���" (processed as function call)
9 and        ������ "�"
10 or         ������ "���"
*/

        tokenOpenBrace        = 0x0101,
        tokenCloseBrace       = 0x0102,

        tokenOpenSquareBrace  = 0x0201,
        tokenCloseSquareBrace = 0x0202,

        tokenSlash            = 0x0301,
        tokenDoubleSlash      = 0x0302,

        // �������������� ���������
        // level 4

        tokenOperatorBegin    = 0x0401, // same as tokenDiv
     // tokenOperatorEnd

        tokenDiv              = 0x0401,
        tokenMod              = 0x0402,
        tokenMultiply         = 0x0403,
        // level 5
        tokenPlus             = 0x0501,
        tokenMinus            = 0x0502,

        // ���������� ���������
        // level 6
        tokenLess             = 0x0601,
        tokenGreater          = 0x0602,
        tokenLessOrEqual      = 0x0603,
        tokenGreaterOrEqual   = 0x0604,
        // level 7
        tokenEqual            = 0x0701,
        tokenNotEqual         = 0x0702,
        // level 8
        tokenUnion            = 0x0801,
        // level 9
        tokenAnd              = 0x0901,
        // level 10
        tokenOr               = 0x0A01,
        // ?

        tokenOperatorEnd      = 0x0B00,

        tokenVarRef           = 0x1001,
        tokenQuotedString,
        tokenNumber,
        tokenString,
        tokenComma,
        tokenAxisAttributeShort,
        tokenDot,
        tokenDoubleDot,
        tokenDoubleColon,
        tokenColon,
        tokenExclamation,

/*
���������� ��� ����� ���������
��� �������� ����� ��������� ����� �������������� ����������:

���������� ��������
            child::
@           attribute::
.           self::
..          parent::
//          /descendant-or-self/
�����       [position()='��������']
*/

        // ���
        tokenAxisAncestor           ,  // ���������� ��������� �������
        tokenAxisAncestorOrSelf     ,  // ���������� ��������� ������� � ������� �������
        tokenAxisAttribute          ,  // ���������� ��������� ��������� �������� ��������
        tokenAxisChild              ,  // ���������� ��������� �������� �� ���� ������� ����
        tokenAxisDescendant         ,  // ���������� ������ ��������� ��������
        tokenAxisDescendantOrSelf   ,  // ���������� ������ ��������� �������� � ������� �������
        tokenAxisFollowing          ,  // ���������� �������������� ���������, ���� �������� ��������
        tokenAxisFollowingSibling   ,  // ���������� ��������� ��������� �� ��� �� ������, ��������� �� �������
        tokenAxisNamespace          ,  // ���������� ��������� ������� ������������ ��� (�� ���� ������������ ������� xmlns)
        tokenAxisParent             ,  // ���������� ������ �� ���� ������� �����
        tokenAxisPreceding          ,  // ���������� ��������� ������������ ��������� �������� ��������� �������
        tokenAxisPrecedingSibling   ,  // ���������� ��������� ��������� �� ��� �� ������, �������������� ��������
        tokenAxisSelf               ,  // ���������� ������� �������

        // �������
        // ������� � �����������
        tokenFnNode             ,  // node-set node()        - ���������� ��� ����. ��� ���� ������� ����� ���������� ���������� '*', �� � ������� �� ��������� - node() ���������� � ��������� ����.
        tokenFnText             ,  // string text()          - ���������� ����� ��������� �����
        tokenFnValue            ,  // variant value(node)    - ���������� �������� ���� *** �� ����������� ������� ***
        tokenFnCurrent          ,  // node-set current()     - ���������� ��������� �� ������ ��������, ������� �������� �������. ���� �� ������ ��������� ��������� � ���������, �� ������������ �������� ���������� �� ����� ������� �� �������� �������� ����� ������ �������.
        tokenFnPosition         ,  // number position()      - ���������� ������� �������� � ���������. ��������� �������� ������ � ����� <xsl:for-each/>
        tokenFnLast             ,  // number last()          - ���������� ����� ���������� �������� � ���������. ��������� �������� ������ � ����� <xsl:for-each/>
        tokenFnCount            ,  // number count(node-set) - ���������� ���������� ��������� � node-set.
        tokenFnName             ,  // string name(node-set?) - ���������� ������ ��� ������� ���� � ���������.
        tokenFnNamespaceUri     ,  // string namespace-uri(node-set?) - ���������� ������ �� url ������������ ������������ ���.
        tokenFnLocalName        ,  // string local-name(node-set?) - ���������� ��� ������� ���� � ���������, ��� ������������ ���.
        tokenFnId               ,  // node-set id(object)    - ������� ������� � ���������� ���������������

        // ��������� �������
        tokenFnString           ,  // string string(object?) - ���������� ��������� ���������� ��������. �� ���� ���������� ������������ ��������� ��������� ��������� �� ���� ������� ����.
        tokenFnConcat           ,  // string concat(string, string, string*) - ���������� ��� ��� ����� �����
        tokenFnStringLength     ,  // number string-length(string?) - ���������� ����� ������.
        tokenFnContains         ,  // boolean contains(string, string) - ���������� ������, ���� ������ ������ �������� ������, ����� ���������� ����.
        tokenFnLowercase        ,
        tokenFnUppercase        ,
        tokenFnLangId           ,
        tokenFnPrimaryLang      ,
        tokenFnListContains     ,
        tokenFnListContainsOneOf,
        tokenFnSubstring        ,  // string substring(string, number, number?) - ���������� ������ ���������� �� ������ ������� � ���������� ������, � ���� ������ ������ ����� - ���������� ��������.
        tokenFnSubstringBefore  ,  // string substring-before(string, string) - ���� ������� ������ ������ � ������, ���������� ������ �� ������� ��������� ������ ������.
        tokenFnSubstringAfter   ,  // string substring-after(string, string)  - ���� ������� ������ ������ � ������, ���������� ������ ����� ������� ��������� ������ ������.
        tokenFnStartsWith       ,  // boolean starts-with(string, string)     - ���������� ������ ���� ������ ������ ������ � ������ ������, ����� ���������� ����.
        tokenFnEndsWith         ,  // boolean ends-with(string, string)       - ���������� ������ ���� ������ ������ ������ � ����� ������, ����� ���������� ����.
        tokenFnNormalizeSpace   ,  // string normalize-space(string?)         - ������� ������ � ��������� �������, � ����� ����������� �������, ������� �� ���������.
        tokenFnTranslate        ,  // string translate(string, string, string) - �������� ������� ������ ������, ������� ����������� �� ������ ������, �� ��������������� �� ������� �������� �� ������ ������ ������� �� ������� ������. translate(<bar>, <abc>, <ABC>) ������ BAr.

        // ���������� �������
        tokenFnBoolean          ,  // boolean boolean(object) - �������� ������ � ����������� ����;
        tokenFnTrue             ,  // boolean true()          - ���������� ������.
        tokenFnFalse            ,  // boolean false()         - ���������� ����.
        tokenFnNot              ,  // boolean not(boolean)    - ���������, ���������� ������ ���� �������� ���� � ��������.

        // �������� �������
        tokenFnNumber           ,  // number number(object?)  - ��������� ������ � �����.
        tokenFnSum              ,  // number sum(node-set)    - ������ ����� ���������, ������ ��� ��������� ����� ������������ � ������ � �� ���� �������� �����.
        tokenFnFloor            ,  // number floor(number)    - ���������� ���������� ����� �����, �� �������, ��� ��������.
        tokenFnCeiling          ,  // number ceiling(number)  - ���������� ���������� ����� �����, �� �������, ��� ��������.
        tokenFnRound            ,  // number round(number)    - ��������� ����� �� �������������� ��������.

        tokenLast  // unized, mark end of tokens


        //tokenName          // _A-Za-z0-9
    };

inline
bool isSpace( wchar_t ch )
   {
    return ch==L' ' || ch==L'\r' || ch==L'\n' || ch==L'\t';
   }

inline
bool isNameFirstChar( wchar_t ch )
   {
    if (ch==L'_' || (ch>=L'a' && ch<=L'z') || (ch>=L'A' && ch<=L'Z') ) return true;
    return false;
   }

inline
bool isNameNextChar( wchar_t ch )
   {
    if (ch==L'_' || ch==L'-' || (ch>=L'a' && ch<=L'z') || (ch>=L'A' && ch<=L'Z') || (ch>=L'0' && ch<=L'9') ) return true;
    return false;
   }

inline
bool isDigit( wchar_t ch )
   {
    if (ch>=L'0' && ch<=L'9') return true;
    return false;
   }

inline
void getLinePos( const ::std::wstring &data, SIZE_T errOffset, SIZE_T &line, SIZE_T &pos)
   {
    line = 0; pos = 0;
    SIZE_T i = 0, size = data.size();
    for(; i!=errOffset && i!=size; ++i)
       {
        if (data[i]==L'\n')
           {
            ++line;
            pos = 1;
           }
        else ++pos;
       }
    if (i>=size)
       {
        line = -1; pos = -1;
       }
    else
       {
        ++line; ++pos;
       }
   }

inline
bool isTokenAxis( token_t tt )
   {
    if (tt>=tokenAxisAncestor && tt<=tokenAxisSelf ) return true;
    return false;
   }

inline
bool isTokenFunction( token_t tt )
   {
    if (tt>=tokenFnCurrent && tt<=tokenFnRound ) return true;
    return false;
   }

inline
bool isTokenFunctionEx( token_t tt )
   {
    if (tt>=tokenFnNode && tt<=tokenFnRound ) return true;
    return false;
   }


inline
bool isTokenOperator( token_t tt )
   {
    if (tt >= tokenOperatorBegin && tt < tokenOperatorEnd ) return true;
    return false;
   }

inline
unsigned operatorLevel( token_t tt)
   {
    return (token_t)(((unsigned)tt) & 0x0F00);
   }

/*
bool isSpace( wchar_t ch )
bool isNameFirstChar( wchar_t ch )
bool isNameNextChar( wchar_t ch )
bool isDigit( wchar_t ch )
bool isTokenAxis( token_t tt )
bool isTokenFunction( token_t tt )
bool isTokenFunctionEx( token_t tt )
bool isTokenOperator( token_t tt )
unsigned operatorLevel( token_t tt)
*/


struct CToken
{
    token_t  tokenId;
    SIZE_T   tokenPos;
    SIZE_T   tokenLen;

    CToken()                                  : tokenId(tokenNone), tokenPos(0), tokenLen(0) {}
    CToken(token_t t)                         : tokenId(t)        , tokenPos(0), tokenLen(0) {}
    CToken(token_t t, SIZE_T p, SIZE_T l = 1) : tokenId(t)        , tokenPos(p), tokenLen(l) {}

    ::std::wstring toDisplayString( const ::std::wstring &strInput ) const
       {
        ::std::wstring res = toString(strInput);
        ::cli::util::trim( res, ::cli::util::CIsSpace<wchar_t>() );
        return res;
       }

    ::std::wstring toString( const ::std::wstring &strInput ) const
       {
        switch(tokenId)
           {
            case tokenNone             : return ::std::wstring(L" ");
            case tokenEqual            : return ::std::wstring(L"=");
            case tokenNotEqual         : return ::std::wstring(L"!=");
            case tokenLess             : return ::std::wstring(L"<");
            case tokenGreater          : return ::std::wstring(L">");
            case tokenLessOrEqual      : return ::std::wstring(L"<=");
            case tokenGreaterOrEqual   : return ::std::wstring(L">=");
            case tokenPlus             : return ::std::wstring(L"+");
            case tokenMinus            : return ::std::wstring(L" - ");
            case tokenMultiply         : return ::std::wstring(L"*");
            case tokenUnion            : return ::std::wstring(L"|");
            case tokenVarRef           : return ::std::wstring(L"$");
            case tokenOpenBrace        : return ::std::wstring(L"(");
            case tokenCloseBrace       : return ::std::wstring(L")");
            //case tokenQuotedString     : return ::std::wstring(L"");
            //case tokenNumber           : return ::std::wstring(L"");
            case tokenSlash            : return ::std::wstring(L"/");
            case tokenDoubleSlash      : return ::std::wstring(L"//");
            case tokenOpenSquareBrace  : return ::std::wstring(L"[");
            case tokenCloseSquareBrace : return ::std::wstring(L"]");
            //case tokenString           : return ::std::wstring(L"");
            case tokenComma            : return ::std::wstring(L",");
            case tokenAxisAttributeShort:return ::std::wstring(L"@");
            case tokenDot              : return ::std::wstring(L".");
            case tokenDoubleDot        : return ::std::wstring(L"..");
            case tokenColon            : return ::std::wstring(L":");
            case tokenDoubleColon      : return ::std::wstring(L"::");
            case tokenExclamation      : return ::std::wstring(L"!");
            case tokenOr               : return ::std::wstring(L" or ");
            case tokenAnd              : return ::std::wstring(L" and ");
            case tokenDiv              : return ::std::wstring(L" div ");
            case tokenMod              : return ::std::wstring(L" mod ");
            case tokenNumber           :
            case tokenString           : return ::std::wstring( strInput, tokenPos, tokenLen );
            case tokenQuotedString     :
                                        {
                                         wchar_t quot = '\'';
                                         ::std::wstring tmp = ::std::wstring( strInput, tokenPos, tokenLen );
                                         if (tmp.find(L'\'')!=tmp.npos) quot = '\"';
                                         return ::std::wstring( 1, quot )
                                              + tmp
                                              + ::std::wstring( 1, quot );
                                        }

            case tokenAxisAncestor         : return ::std::wstring(L"ancestor"          );
            case tokenAxisAncestorOrSelf   : return ::std::wstring(L"ancestor-or-self"  );
            case tokenAxisAttribute        : return ::std::wstring(L"attribute"         );
            case tokenAxisChild            : return ::std::wstring(L"child"             );
            case tokenAxisDescendant       : return ::std::wstring(L"descendant"        );
            case tokenAxisDescendantOrSelf : return ::std::wstring(L"descendant-or-self");
            case tokenAxisFollowing        : return ::std::wstring(L"following"         );
            case tokenAxisFollowingSibling : return ::std::wstring(L"following-sibling" );
            case tokenAxisNamespace        : return ::std::wstring(L"namespace"         );
            case tokenAxisParent           : return ::std::wstring(L"parent"            );
            case tokenAxisPreceding        : return ::std::wstring(L"preceding"         );
            case tokenAxisPrecedingSibling : return ::std::wstring(L"preceding-sibling" );
            case tokenAxisSelf             : return ::std::wstring(L"self"              );
            case tokenFnNode               : return ::std::wstring(L"node"              );
            case tokenFnText               : return ::std::wstring(L"text"              );
            case tokenFnValue              : return ::std::wstring(L"value"             );
            case tokenFnCurrent            : return ::std::wstring(L"current"           );
            case tokenFnPosition           : return ::std::wstring(L"position"          );
            case tokenFnLast               : return ::std::wstring(L"last"              );
            case tokenFnCount              : return ::std::wstring(L"count"             );
            case tokenFnName               : return ::std::wstring(L"name"              );
            case tokenFnNamespaceUri       : return ::std::wstring(L"namespace-uri"     );
            case tokenFnLocalName          : return ::std::wstring(L"local-name"        );
            case tokenFnId                 : return ::std::wstring(L"id"                );
            case tokenFnString             : return ::std::wstring(L"string"            );
            case tokenFnConcat             : return ::std::wstring(L"concat"            );
            case tokenFnStringLength       : return ::std::wstring(L"string-length"     );
            case tokenFnContains           : return ::std::wstring(L"contains"          );
            case tokenFnLowercase          : return ::std::wstring(L"lowercase"         );
            case tokenFnUppercase          : return ::std::wstring(L"uppercase"         );
            case tokenFnLangId             : return ::std::wstring(L"lang-id"           );
            case tokenFnPrimaryLang        : return ::std::wstring(L"primary-lang"      );
            case tokenFnListContains       : return ::std::wstring(L"list-contains"     );
            case tokenFnListContainsOneOf  : return ::std::wstring(L"list-contains-one-of");
            case tokenFnSubstring          : return ::std::wstring(L"substring"         );
            case tokenFnSubstringBefore    : return ::std::wstring(L"substring-before"  );
            case tokenFnSubstringAfter     : return ::std::wstring(L"substring-after"   );
            case tokenFnStartsWith         : return ::std::wstring(L"starts-with"       );
            case tokenFnEndsWith           : return ::std::wstring(L"ends-with"         );
            case tokenFnNormalizeSpace     : return ::std::wstring(L"normalize-space"   );
            case tokenFnTranslate          : return ::std::wstring(L"translate"         );
            case tokenFnBoolean            : return ::std::wstring(L"boolean"           );
            case tokenFnTrue               : return ::std::wstring(L"true"              );
            case tokenFnFalse              : return ::std::wstring(L"false"             );
            case tokenFnNot                : return ::std::wstring(L"not"               );
            case tokenFnNumber             : return ::std::wstring(L"number"            );
            case tokenFnSum                : return ::std::wstring(L"sum"               );
            case tokenFnFloor              : return ::std::wstring(L"floor"             );
            case tokenFnCeiling            : return ::std::wstring(L"ceiling"           );
            case tokenFnRound              : return ::std::wstring(L"round"             );
            //case              : return ::std::wstring(L"");

            default: return ::std::wstring(L"<UNKNOWN>");
            //case tokenName             : return ::std::wstring(L"");
           }
       }


    ::std::wstring toTypeString( ) const
       {
        switch(tokenId)
           {
            case tokenNone             : return ::std::wstring(L"tokenNone");
            case tokenEqual            : return ::std::wstring(L"tokenEqual");
            case tokenNotEqual         : return ::std::wstring(L"tokenNotEqual");
            case tokenLess             : return ::std::wstring(L"tokenLess");
            case tokenGreater          : return ::std::wstring(L"tokenGreater");
            case tokenLessOrEqual      : return ::std::wstring(L"tokenLessOrEqual");
            case tokenGreaterOrEqual   : return ::std::wstring(L"tokenGreaterOrEqual");
            case tokenPlus             : return ::std::wstring(L"tokenPlus");
            case tokenMinus            : return ::std::wstring(L"tokenMinus");
            case tokenMultiply         : return ::std::wstring(L"tokenMultiply");
            case tokenUnion            : return ::std::wstring(L"tokenUnion");
            case tokenVarRef           : return ::std::wstring(L"tokenVarRef");
            case tokenOpenBrace        : return ::std::wstring(L"tokenOpenBrace");
            case tokenCloseBrace       : return ::std::wstring(L"tokenCloseBrace");
            //case tokenQuotedString     : return ::std::wstring(L"");
            //case tokenNumber           : return ::std::wstring(L"");
            case tokenSlash            : return ::std::wstring(L"tokenSlash"                   );
            case tokenDoubleSlash      : return ::std::wstring(L"tokenDoubleSlash"             );
            case tokenOpenSquareBrace  : return ::std::wstring(L"tokenOpenSquareBrace"         );
            case tokenCloseSquareBrace : return ::std::wstring(L"tokenCloseSquareBrace"        );
            //case tokenString           : return ::std::wstring(L"");
            case tokenComma            : return ::std::wstring(L"tokenComma"                   );
            case tokenAxisAttributeShort:return ::std::wstring(L"tokenAxisAttributeShort"      );
            case tokenDot              : return ::std::wstring(L"tokenDot"                     );
            case tokenDoubleDot        : return ::std::wstring(L"tokenDoubleDot"               );
            case tokenColon            : return ::std::wstring(L"tokenColon"                   );
            case tokenDoubleColon      : return ::std::wstring(L"tokenDoubleColon"             );
            case tokenExclamation      : return ::std::wstring(L"tokenExclamation"             );
            case tokenOr               : return ::std::wstring(L"tokenOr"                      );
            case tokenAnd              : return ::std::wstring(L"tokenAnd"                     );
            case tokenDiv              : return ::std::wstring(L"tokenDiv"                     );
            case tokenMod              : return ::std::wstring(L"tokenMod"                     );
            case tokenNumber           : return ::std::wstring(L"tokenNumber"                  );
            case tokenString           : return ::std::wstring(L"tokenString"                  );
            case tokenQuotedString     : return ::std::wstring(L"tokenQuotedString"            );
            case tokenAxisAncestor         : return ::std::wstring(L"tokenAxisAncestor"        );
            case tokenAxisAncestorOrSelf   : return ::std::wstring(L"tokenAxisAncestorOrSelf"  );
            case tokenAxisAttribute        : return ::std::wstring(L"tokenAxisAttribute"       );
            case tokenAxisChild            : return ::std::wstring(L"tokenAxisChild"           );
            case tokenAxisDescendant       : return ::std::wstring(L"tokenAxisDescendant"      );
            case tokenAxisDescendantOrSelf : return ::std::wstring(L"tokenAxisDescendantOrSelf");
            case tokenAxisFollowing        : return ::std::wstring(L"tokenAxisFollowing"       );
            case tokenAxisFollowingSibling : return ::std::wstring(L"tokenAxisFollowingSibling");
            case tokenAxisNamespace        : return ::std::wstring(L"tokenAxisNamespace"       );
            case tokenAxisParent           : return ::std::wstring(L"tokenAxisParent"          );
            case tokenAxisPreceding        : return ::std::wstring(L"tokenAxisPreceding"       );
            case tokenAxisPrecedingSibling : return ::std::wstring(L"tokenAxisPrecedingSibling");
            case tokenAxisSelf             : return ::std::wstring(L"tokenAxisSelf"            );
            case tokenFnNode               : return ::std::wstring(L"tokenFnNode"              );
            case tokenFnText               : return ::std::wstring(L"tokenFnText"              );
            case tokenFnValue              : return ::std::wstring(L"tokenFnValue"             );
            case tokenFnCurrent            : return ::std::wstring(L"tokenFnCurrent"           );
            case tokenFnPosition           : return ::std::wstring(L"tokenFnPosition"          );
            case tokenFnLast               : return ::std::wstring(L"tokenFnLast"              );
            case tokenFnCount              : return ::std::wstring(L"tokenFnCount"             );
            case tokenFnName               : return ::std::wstring(L"tokenFnName"              );
            case tokenFnNamespaceUri       : return ::std::wstring(L"tokenFnNamespaceUri"      );
            case tokenFnLocalName          : return ::std::wstring(L"tokenFnLocalName"         );
            case tokenFnId                 : return ::std::wstring(L"tokenFnId"                );
            case tokenFnString             : return ::std::wstring(L"tokenFnString"            );
            case tokenFnConcat             : return ::std::wstring(L"tokenFnConcat"            );
            case tokenFnStringLength       : return ::std::wstring(L"tokenFnStringLength"      );
            case tokenFnContains           : return ::std::wstring(L"tokenFnContains"          );
            case tokenFnLowercase          : return ::std::wstring(L"tokenFnLowercase"         );
            case tokenFnUppercase          : return ::std::wstring(L"tokenFnUppercase"         );
            case tokenFnLangId             : return ::std::wstring(L"tokenFnLangId"            );
            case tokenFnPrimaryLang        : return ::std::wstring(L"tokenFnPrimaryLang"       );
            case tokenFnListContains       : return ::std::wstring(L"tokenFnListContains"      );
            case tokenFnListContainsOneOf  : return ::std::wstring(L"tokenFnListContainsOneOf" );
            case tokenFnSubstring          : return ::std::wstring(L"tokenFnSubstring"         );
            case tokenFnSubstringBefore    : return ::std::wstring(L"tokenFnSubstringBefore"   );
            case tokenFnSubstringAfter     : return ::std::wstring(L"tokenFnSubstringAfter"    );
            case tokenFnStartsWith         : return ::std::wstring(L"tokenFnStartsWith"        );
            case tokenFnEndsWith           : return ::std::wstring(L"tokenFnEndsWith"          );
            case tokenFnNormalizeSpace     : return ::std::wstring(L"tokenFnNormalizeSpace"    );
            case tokenFnTranslate          : return ::std::wstring(L"tokenFnTranslate"         );
            case tokenFnBoolean            : return ::std::wstring(L"tokenFnBoolean"           );
            case tokenFnTrue               : return ::std::wstring(L"tokenFnTrue"              );
            case tokenFnFalse              : return ::std::wstring(L"tokenFnFalse"             );
            case tokenFnNot                : return ::std::wstring(L"tokenFnNot"               );
            case tokenFnNumber             : return ::std::wstring(L"tokenFnNumber"            );
            case tokenFnSum                : return ::std::wstring(L"tokenFnSum"               );
            case tokenFnFloor              : return ::std::wstring(L"tokenFnFloor"             );
            case tokenFnCeiling            : return ::std::wstring(L"tokenFnCeiling"           );
            case tokenFnRound              : return ::std::wstring(L"tokenFnRound"             );
            //case              : return ::std::wstring(L"");

            default: return ::std::wstring(L"<UNKNOWN>");
            //case tokenName             : return ::std::wstring(L"");
           }
       }


};


struct CTokenizer
{
    enum tokenizer_state_t
    {
        stateNormal,
        waitDoubleDot,
        waitLtEqual,
        waitGtEqual,
        waitDoubleColon,
        waitNotEqual,
        waitDoubleSlash,
        waitQuotEnd,
        waitVarName,
        readString,
        readNumber,
        readNumber2,
        readOr,
        readAnd1,
        readAnd2,
    };

    ::std::vector< CToken > tokens;
    tokenizer_state_t       state;
    SIZE_T                  startPos;
    SIZE_T                  curPos;
    wchar_t                 quotSign;

    CTokenizer( ) : tokens(), state(stateNormal), startPos(0), curPos(0), quotSign(0) {}


    //CToken()                                  : tokenId(tokenNone), tokenPos(0), tokenLen(0) {}
    //CToken(token_t t)                         : tokenId(t)        , tokenPos(0), tokenLen(0) {}
    //CToken(token_t t, SIZE_T p, SIZE_T l = 1) : tokenId(t)        , tokenPos(p), tokenLen(l) {}

    bool finalize()
       {
        switch(state)
           {
            case stateNormal:  return true;
            case waitLtEqual:  tokens.push_back( CToken(tokenLess, curPos-1, 1));
                               return true;
            case waitGtEqual:  tokens.push_back( CToken(tokenGreater, curPos-1, 1));
                               return true;
            case waitNotEqual: tokens.push_back( CToken(tokenExclamation, curPos-1, 1 ));
                               return true;
            case waitDoubleColon: tokens.push_back( CToken(tokenColon, curPos-1, 1));
                               return true;
            case waitDoubleSlash: tokens.push_back( CToken(tokenSlash, curPos-1, 1));
                               return true;
            case waitQuotEnd:  return false; // unexpected end of quoted string
            case waitVarName:  return false;
            case readOr:
            case readAnd1:
            case readAnd2:
            case readString:   tokens.push_back( CToken(tokenString, startPos, curPos-startPos));
                               return true;
            case readNumber2:
            case readNumber:   tokens.push_back( CToken(tokenNumber, startPos, curPos-startPos));
                               return true;

            default:           return false; // unknown error
           }
       }

    bool tokenize( wchar_t ch )
       {
        //SIZE_T                  curPos;
        switch(state)
           {
            case stateNormal:
                    {
                     switch( ch )
                        {
                         case L'=': tokens.push_back( CToken(tokenEqual, curPos++)); return true;
                         case L'+': tokens.push_back( CToken(tokenPlus, curPos++)); return true;
                         case L'-': tokens.push_back( CToken(tokenMinus, curPos++)); return true;
                         case L'*': tokens.push_back( CToken(tokenMultiply, curPos++)); return true;
                         case L'|': tokens.push_back( CToken(tokenUnion, curPos++)); return true;
                         case L'$': tokens.push_back( CToken(tokenVarRef, curPos++)); state = waitVarName; return true;
                         case L'(': tokens.push_back( CToken(tokenOpenBrace, curPos++)); return true;
                         case L')': tokens.push_back( CToken(tokenCloseBrace, curPos++)); return true;
                         case L'[': tokens.push_back( CToken(tokenOpenSquareBrace, curPos++)); return true;
                         case L']': tokens.push_back( CToken(tokenCloseSquareBrace, curPos++)); return true;
                         case L',': tokens.push_back( CToken(tokenComma, curPos++)); return true;
                         case L'@': tokens.push_back( CToken(tokenAxisAttributeShort, curPos++)); return true;
                         case L'<': state = waitLtEqual;     ++curPos; return true;
                         case L'>': state = waitGtEqual;     ++curPos; return true;
                         case L'.': state = waitDoubleDot;   ++curPos; return true;
                         case L':': state = waitDoubleColon; ++curPos; return true;
                         case L'!': state = waitNotEqual;    ++curPos; return true;
                         case L'/': state = waitDoubleSlash; ++curPos; return true;
                         // redesigned - all keywords readed as normal names and later converted to tokens
                         //case L'O':
                         //case L'o': state = readOr;          ++curPos; return true;
                         //case L'A':
                         //case L'a': state = readAnd1;         ++curPos; return true;
                         case L'\'': startPos = curPos; quotSign = ch; state = waitQuotEnd; ++curPos; return true;
                         case L'\"': startPos = curPos; quotSign = ch; state = waitQuotEnd; ++curPos; return true;
                         default:
                                 //if (isSpace(ch))                                                { ++curPos; return true; } // skip space
                                 if (isSpace(ch)) { tokens.push_back( CToken(tokenNone, curPos++)); return true; }
                                 if (isNameFirstChar(ch)) { startPos = curPos; state = readString; ++curPos; return true; }
                                 if (isDigit(ch))         { startPos = curPos; state = readNumber; ++curPos; return true; }
                                 return false;
                        };
                    }
                    break;

            case waitVarName:
                    if (isNameFirstChar(ch)) { startPos = curPos; state = readString; ++curPos; return true; }
                    return false;

            case waitLtEqual:
                    if (ch==L'=') { tokens.push_back( CToken(tokenLessOrEqual, curPos-1, 2)); ++curPos; state = stateNormal; return true; }
                    tokens.push_back( CToken(tokenLess, curPos-1, 1));
                    state = stateNormal;
                    return tokenize( ch );

            case waitGtEqual:
                    if (ch==L'=') { tokens.push_back( CToken(tokenGreaterOrEqual, curPos-1, 2)); ++curPos; state = stateNormal; return true; }
                    tokens.push_back( CToken(tokenGreater, curPos-1, 1));
                    state = stateNormal;
                    return tokenize( ch );

            case waitNotEqual:
                    if (ch==L'=') { tokens.push_back( CToken(tokenNotEqual, curPos-1, 2)); ++curPos; state = stateNormal; return true; }
                    tokens.push_back( CToken(tokenExclamation, curPos-1, 1 ));
                    state = stateNormal;
                    return tokenize( ch );

            case waitDoubleColon:
                    if (ch==L':') { tokens.push_back( CToken(tokenDoubleColon, curPos-1, 2)); ++curPos; state = stateNormal; return true; }
                    tokens.push_back( CToken(tokenColon, curPos-1, 1));
                    state = stateNormal;
                    return tokenize( ch );

            case waitDoubleSlash:
                    if (ch==L'/') { tokens.push_back( CToken(tokenDoubleSlash, curPos-1, 2)); ++curPos; state = stateNormal; return true; }
                    tokens.push_back( CToken(tokenSlash, curPos-1, 1));
                    state = stateNormal;
                    return tokenize( ch );

            case waitDoubleDot:
                    if (ch==L'.') { tokens.push_back( CToken(tokenDoubleDot, curPos-1, 2)); ++curPos; state = stateNormal; return true; }
                    if (isDigit(ch)) { state=readNumber2; ++curPos; return true; }
                    tokens.push_back( CToken(tokenDot, curPos-1, 1));
                    state = stateNormal;
                    return tokenize( ch );
            /*
            case readOr:
                    if (ch==L'r' || ch==L'R') { tokens.push_back( CToken(tokenOr, curPos-1, 2)); ++curPos; state = stateNormal; return true; }
                    state = readString;
                    return tokenize( ch );

            case readAnd1:
                    if (ch==L'n' || ch==L'N') { ++curPos; state = readAnd2; return true; }
                    state = readString;
                    return tokenize( ch );

            case readAnd2:
                    if (ch==L'd' || ch==L'D') { tokens.push_back( CToken(tokenAnd, curPos-2, 3)); ++curPos; state = stateNormal; return true; }
                    state = readString;
                    return tokenize( ch );
            */
            case waitQuotEnd:
                    if (ch==quotSign)
                       {
                        tokens.push_back( CToken(tokenQuotedString, startPos+1, curPos-startPos-1));
                        state = stateNormal;
                       }
                    ++curPos; return true;

            case readString:
                    if (isNameNextChar(ch)) { ++curPos; return true; }
                    tokens.push_back( CToken(tokenString, startPos, curPos-startPos));
                    state = stateNormal;
                    return tokenize( ch );

            case readNumber:
                    if (isDigit(ch)) { ++curPos; return true; }
                    if (ch==L'.')    { ++curPos; state = readNumber2; return true; }
                    tokens.push_back( CToken(tokenNumber, startPos, curPos-startPos));
                    state = stateNormal;
                    return tokenize( ch );

            case readNumber2:
                    if (isDigit(ch)) { ++curPos; return true; }
                    tokens.push_back( CToken(tokenNumber, startPos, curPos-startPos));
                    state = stateNormal;
                    return tokenize( ch );

            default:
                    return false;
           }
       }

};

// http://www.zvon.org/xxl/XPathTutorial/Output_rus/
// http://ru.wikipedia.org/wiki/XPath
// http://msdn.microsoft.com/ru-ru/library/ms256086.aspx


// not only axis names converter, all keyword converted here
struct CTokenNameToTokenBase
{
    typedef ::std::pair< token_t, ::std::wstring > token_name_pair;
    typedef ::std::pair< ::std::wstring, token_t > name_token_pair;
    typedef ::cli::util::CAutoSortVector< token_name_pair, ::cli::util::pair_first_less< token_name_pair > >   token_name_vector;
    typedef ::cli::util::CAutoSortVector< name_token_pair, ::cli::util::pair_first_less< name_token_pair > >   name_token_vector;
    //static
    token_name_vector tokenToName;
    //static
    name_token_vector nameToToken;

    CTokenNameToTokenBase() : tokenToName(), nameToToken()
       {
       }
    CTokenNameToTokenBase( const CTokenNameToTokenBase & b) : tokenToName(b.tokenToName), nameToToken(b.nameToToken)
       {
       }

    void buildNameToTokenData()
       {
        if (nameToToken.empty())
           {
            token_name_vector::const_iterator cit = tokenToName.begin();
            for(; cit != tokenToName.end(); ++cit)
               {
                nameToToken.push_back( ::std::make_pair(cit->second, cit->first) );
               }
           }
       }

    token_t convertNameToToken( const ::std::wstring &name ) const
       {
        name_token_vector::const_iterator it = nameToToken.find( ::std::make_pair( name, tokenNone ) );
        if (it != nameToToken.end()) return it->second;
        return tokenNone;
       }
};


struct CAxisNameToToken : public CTokenNameToTokenBase
{
    CAxisNameToToken( const CAxisNameToToken &t) : CTokenNameToTokenBase(t) {}
    CAxisNameToToken() : CTokenNameToTokenBase()
       {
        if (tokenToName.empty())
           {
            tokenToName.push_back( ::std::make_pair( tokenAxisAncestor          , L"ancestor"          ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisAncestorOrSelf    , L"ancestor-or-self"  ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisAttribute         , L"attribute"         ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisChild             , L"child"             ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisDescendant        , L"descendant"        ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisDescendantOrSelf  , L"descendant-or-self") );
            tokenToName.push_back( ::std::make_pair( tokenAxisFollowing         , L"following"         ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisFollowingSibling  , L"following-sibling" ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisNamespace         , L"namespace"         ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisParent            , L"parent"            ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisPreceding         , L"preceding"         ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisPrecedingSibling  , L"preceding-sibling" ) );
            tokenToName.push_back( ::std::make_pair( tokenAxisSelf              , L"self"              ) );
           }

        buildNameToTokenData();
       }
};


struct COperatorNameToToken : public CTokenNameToTokenBase
{
    COperatorNameToToken( const COperatorNameToToken &t) : CTokenNameToTokenBase(t) {}
    COperatorNameToToken() : CTokenNameToTokenBase()
       {
        if (tokenToName.empty())
           {
            tokenToName.push_back( ::std::make_pair( tokenOr                    , L"or"                ) );
            tokenToName.push_back( ::std::make_pair( tokenAnd                   , L"and"               ) );
            tokenToName.push_back( ::std::make_pair( tokenDiv                   , L"div"               ) );
            tokenToName.push_back( ::std::make_pair( tokenMod                   , L"mod"               ) );
           }

        buildNameToTokenData();
       }
};


struct CFunctionNameToToken : public CTokenNameToTokenBase
{
    CFunctionNameToToken( const CFunctionNameToToken &t) : CTokenNameToTokenBase(t) {}
    CFunctionNameToToken() : CTokenNameToTokenBase()
       {
        if (tokenToName.empty())
           {
            tokenToName.push_back( ::std::make_pair( tokenFnNode                , L"node"              ) );
            tokenToName.push_back( ::std::make_pair( tokenFnText                , L"text"              ) );
            tokenToName.push_back( ::std::make_pair( tokenFnValue               , L"value"             ) );
            tokenToName.push_back( ::std::make_pair( tokenFnCurrent             , L"current"           ) );
            tokenToName.push_back( ::std::make_pair( tokenFnPosition            , L"position"          ) );
            tokenToName.push_back( ::std::make_pair( tokenFnLast                , L"last"              ) );
            tokenToName.push_back( ::std::make_pair( tokenFnCount               , L"count"             ) );
            tokenToName.push_back( ::std::make_pair( tokenFnName                , L"name"              ) );
            tokenToName.push_back( ::std::make_pair( tokenFnNamespaceUri        , L"namespace-uri"     ) );
            tokenToName.push_back( ::std::make_pair( tokenFnLocalName           , L"local-name"        ) );
            tokenToName.push_back( ::std::make_pair( tokenFnId                  , L"id"                ) );
            tokenToName.push_back( ::std::make_pair( tokenFnString              , L"string"            ) );
            tokenToName.push_back( ::std::make_pair( tokenFnConcat              , L"concat"            ) );
            tokenToName.push_back( ::std::make_pair( tokenFnStringLength        , L"string-length"     ) );
            tokenToName.push_back( ::std::make_pair( tokenFnContains            , L"contains"          ) );
            tokenToName.push_back( ::std::make_pair( tokenFnLowercase           , L"lowercase"         ) );
            tokenToName.push_back( ::std::make_pair( tokenFnUppercase           , L"uppercase"         ) );
            tokenToName.push_back( ::std::make_pair( tokenFnLangId              , L"lang-id"           ) );
            tokenToName.push_back( ::std::make_pair( tokenFnPrimaryLang         , L"primary-lang"      ) );
            tokenToName.push_back( ::std::make_pair( tokenFnListContains        , L"list-contains"       ) );
            tokenToName.push_back( ::std::make_pair( tokenFnListContainsOneOf   , L"list-contains-one-of") );
            tokenToName.push_back( ::std::make_pair( tokenFnSubstring           , L"substring"         ) );
            tokenToName.push_back( ::std::make_pair( tokenFnSubstringBefore     , L"substring-before"  ) );
            tokenToName.push_back( ::std::make_pair( tokenFnSubstringAfter      , L"substring-after"   ) );
            tokenToName.push_back( ::std::make_pair( tokenFnStartsWith          , L"starts-with"       ) );
            tokenToName.push_back( ::std::make_pair( tokenFnEndsWith            , L"ends-with"         ) );
            tokenToName.push_back( ::std::make_pair( tokenFnNormalizeSpace      , L"normalize-space"   ) );
            tokenToName.push_back( ::std::make_pair( tokenFnTranslate           , L"translate"         ) );
            tokenToName.push_back( ::std::make_pair( tokenFnBoolean             , L"boolean"           ) );
            tokenToName.push_back( ::std::make_pair( tokenFnTrue                , L"true"              ) );
            tokenToName.push_back( ::std::make_pair( tokenFnFalse               , L"false"             ) );
            tokenToName.push_back( ::std::make_pair( tokenFnNot                 , L"not"               ) );
            tokenToName.push_back( ::std::make_pair( tokenFnNumber              , L"number"            ) );
            tokenToName.push_back( ::std::make_pair( tokenFnSum                 , L"sum"               ) );
            tokenToName.push_back( ::std::make_pair( tokenFnFloor               , L"floor"             ) );
            tokenToName.push_back( ::std::make_pair( tokenFnCeiling             , L"ceiling"           ) );
            tokenToName.push_back( ::std::make_pair( tokenFnRound               , L"round"             ) );
           }

        buildNameToTokenData();
       }
};


struct CNameConverters
{
    CAxisNameToToken         axisNameToToken;
    COperatorNameToToken     opNameToToken;
    CFunctionNameToToken     fnNameToToken;

    CNameConverters()
       : axisNameToToken()
       , opNameToToken()
       , fnNameToToken()
       {}

    CNameConverters( const CNameConverters &c )
       : axisNameToToken(c.axisNameToToken)
       , opNameToToken(c.opNameToToken)
       , fnNameToToken(c.fnNameToToken)
       {}

}; // struct CNameConverters



struct CTokenVectorCollector
{
    ::std::vector< CToken > &tokensTo;
    CTokenVectorCollector( ::std::vector< CToken > &tt )
       : tokensTo(tt) {}
    CTokenVectorCollector( const CTokenVectorCollector &tvc )
       : tokensTo(tvc.tokensTo) {}

    bool finalize( SIZE_T * pErrPos = 0
                 ) const
       {
        return true;
       }

    bool filtrate( const CToken &token
                 , SIZE_T * pErrPos = 0
                 ) const
       {
        tokensTo.push_back(token);
        return true;
       }

}; // struct CTokenVectorCollector

template < typename TNextFilter>
struct CTokenFilterBase
{
    mutable ::std::vector< CToken > bufferedTokens;
    mutable SIZE_T                  curPos;
    mutable SIZE_T                  curLen;
    const   TNextFilter             &nextFilter;
    const ::std::wstring            &refStr;


    CTokenFilterBase( const TNextFilter &tn, const ::std::wstring &_refStr )
       : bufferedTokens(), curPos(0), curLen(0), nextFilter(tn), refStr(_refStr) {}

    bool callNextFinalize( SIZE_T * pErrPos ) const
       {
        return nextFilter.finalize( pErrPos );
       }
    // used to add new tokens to output
    bool callNextTokenFilter( token_t t, SIZE_T * pErrPos ) const
       {
        return nextFilter.filtrate( CToken(t, curPos, curLen), pErrPos );
       }

    bool callNextTokenFilter( const CToken &token, SIZE_T * pErrPos ) const
       {
        return nextFilter.filtrate( token, pErrPos );
       }

    void bufferizeToken( token_t t ) const
       {
        bufferedTokens.push_back( CToken(t, curPos, curLen) );
       }

    void bufferizeCompressToken( token_t t ) const
       {
        if ( !bufferedTokens.empty() && bufferedTokens[bufferedTokens.size()-1].tokenId==t )
           {
            bufferedTokens[bufferedTokens.size()-1].tokenLen = curPos - bufferedTokens[bufferedTokens.size()-1].tokenPos;
           }
        else
           {
            bufferizeToken( t );
           }
       }

    void bufferizeToken( const CToken &token ) const
       {
        bufferedTokens.push_back( token );
       }

    void bufferizeCompressToken( const CToken &token ) const
       {
        if ( !bufferedTokens.empty() && bufferedTokens[bufferedTokens.size()-1].tokenId==token.tokenId )
           {
            bufferedTokens[bufferedTokens.size()-1].tokenLen = curPos - bufferedTokens[bufferedTokens.size()-1].tokenPos;
           }
        else
           {
            bufferizeToken( token );
           }
       }

    bool flushBufferedTokensImpl( ::std::vector< CToken >::iterator end, SIZE_T * pErrPos ) const
       {
        ::std::vector< CToken >::iterator it = bufferedTokens.begin();
        for( ; it!=end; ++it )
           {
            if (!callNextTokenFilter( *it, pErrPos )) return false;
           }
        bufferedTokens.erase( bufferedTokens.begin(), end );
        return true;
       }

    void clearBufferedTokensImpl( ::std::vector< CToken >::iterator end ) const
       {
        bufferedTokens.erase( bufferedTokens.begin(), end );
       }

    void clearBufferedTokens( SIZE_T numFirstTokensToErase ) const
       {
        clearBufferedTokensImpl( (numFirstTokensToErase>=bufferedTokens.size()) ? bufferedTokens.end() : bufferedTokens.begin() + numFirstTokensToErase
                               );
       }

    ::std::wstring getRefString() const
       {
        return refStr;
       }

    ::std::wstring getRefString( SIZE_T startPos, SIZE_T substrLen ) const
       {
        if (startPos >= refStr.size()) startPos = refStr.size();
        if ((startPos+substrLen) >= refStr.size())
            substrLen = refStr.size() - startPos;
        return ::std::wstring( refStr, startPos, substrLen );
       }

    void clearBufferedTokens() const
       {
        bufferedTokens.clear( );
       }

    bool flushBufferedTokens( SIZE_T numFirstTokensToFlush, SIZE_T * pErrPos ) const
       {
        return flushBufferedTokensImpl( (numFirstTokensToFlush>=bufferedTokens.size()) ? bufferedTokens.end() : bufferedTokens.begin() + numFirstTokensToFlush
                               , pErrPos
                               );
       }

    bool flushBufferedTokens( SIZE_T * pErrPos ) const
       {
        return flushBufferedTokensImpl( bufferedTokens.end(), pErrPos );
       }

    void filtrateSavePos( const CToken &token ) const
       {
        curPos = token.tokenPos;
        curLen = token.tokenLen;
       }

    SIZE_T getCurPos() const { return curPos; }
    // do nothing methods
    bool finalize( SIZE_T * pErrPos = 0 ) const
       {
        return true;
       }

    bool filtrate( const CToken &token, SIZE_T * pErrPos = 0 ) const
       {
        return true;
       }

    // helper methods summary

    // bool callNextTokenFilter( token_t t, SIZE_T * pErrPos ) const
    // bool callNextTokenFilter( const CToken &token, SIZE_T * pErrPos ) const
    // void bufferizeToken( token_t t ) const
    // void bufferizeToken( const CToken &token ) const
    // bool flushBufferedTokensImpl( ::std::vector< CToken >::iterator end, SIZE_T * pErrPos ) const
    // void clearBufferedTokens() const
    // ::std::wstring getRefString() const
    // ::std::wstring getRefString( SIZE_T startPos, SIZE_T substrLen ) const
    // bool flushBufferedTokens( SIZE_T numFirstTokensToFlush, SIZE_T * pErrPos ) const
    // bool flushBufferedTokens( SIZE_T * pErrPos ) const
    // void filtrateSavePos( const CToken &token ) const
    // SIZE_T getCurPos() const { return curPos; }
    // bool finalize( SIZE_T * pErrPos = 0 ) const
    // bool filtrate( const CToken &token, SIZE_T * pErrPos = 0 ) const

}; // struct CTokenFilterBase

template< typename TFlt >
bool filtrateTokens( const ::std::vector< CToken > &tokens // source tokens
                   , const TFlt &flt
                   , SIZE_T *pErrPos
                   )
   {
    ::std::vector< CToken >::const_iterator it = tokens.begin(), end = tokens.end();
    for(; it!=end; ++it )
       {
        if (!flt.filtrate(*it,pErrPos))
           {
            return false;
           }
       }
    if (!flt.finalize(pErrPos))
       {
        return false;
       }
    return true;
   }

/*
���������� ��� ����� ���������
��� �������� ����� ��������� ����� �������������� ����������:

���������� ��������
@X           attribute::X
@           attribute::*
.           self::* (self::)
..          parent:: (parent::*)
//          /descendant-or-self::* / (/descendant-or-self/)
�����       [position()='��������']
*/


// performs basic transformations
template < typename TNextFilter>
struct CTokenFilterBasic : public CTokenFilterBase<TNextFilter>
{
    enum state_t { stateStart    = 0,
                   waitAttrName     ,
                   waitNextSpace    ,
                   waitNameMult     ,
                   waitNameMultOnly ,
                   stateLast
                 };

    typedef CTokenFilterBase<TNextFilter> base_filter;

    mutable state_t state;
    CTokenFilterBasic( const TNextFilter &tn, const ::std::wstring &_refStr )
       : CTokenFilterBase<TNextFilter>( tn , _refStr ), state(stateStart) {}
    CTokenFilterBasic( const TNextFilter &tn, const ::std::wstring &_refStr, const CNameConverters &cvt)
       : CTokenFilterBase<TNextFilter>( tn , _refStr ), state(stateStart) {}

    bool filtrate( const CToken &token, SIZE_T * pErrPos = 0 ) const
       {
        base_filter::filtrateSavePos( token ); // common action

        switch(state)
           {
            case stateStart:
                    {
                     switch(token.tokenId)
                        {
                         case tokenAxisAttributeShort:
                              base_filter::bufferizeToken( tokenAxisAttribute );
                              base_filter::bufferizeToken( tokenDoubleColon );
                              state = waitAttrName;
                              break;

                         case tokenDoubleDot:
                              if (!base_filter::callNextTokenFilter( tokenAxisParent, pErrPos ))   return false;
                              if (!base_filter::callNextTokenFilter( tokenDoubleColon, pErrPos ))  return false;
                              //if (!callNextTokenFilter( tokenMultiply, pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenFnNode, pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenOpenBrace , pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenCloseBrace, pErrPos ))     return false;
                              //callNextTokenFilter( tokensTo, tokenSlash );
                              break;

                         case tokenDot:
                              if (!base_filter::callNextTokenFilter( tokenAxisSelf, pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenDoubleColon, pErrPos ))  return false;
                              //if (!callNextTokenFilter( tokenMultiply, pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenFnNode, pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenOpenBrace , pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenCloseBrace, pErrPos ))     return false;
                              break;

                         case tokenDoubleSlash:
                              if (!base_filter::callNextTokenFilter( tokenSlash, pErrPos ))                return false;
                              if (!base_filter::callNextTokenFilter( tokenAxisDescendantOrSelf, pErrPos )) return false;
                              if (!base_filter::callNextTokenFilter( tokenDoubleColon, pErrPos ))          return false;
                              //if (!base_filter::callNextTokenFilter( tokenMultiply, pErrPos ))             return false;
                              if (!base_filter::callNextTokenFilter( tokenFnNode, pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenOpenBrace , pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenCloseBrace, pErrPos ))     return false;
                              if (!base_filter::callNextTokenFilter( tokenSlash, pErrPos ))                return false;
                              state = waitNameMult;
                              break;

                         case tokenSlash:
                              if (!base_filter::callNextTokenFilter( token, pErrPos ))                return false;
                              state = waitNameMult;
                              break;

                         case tokenDoubleColon:
                              base_filter::bufferizeToken( token );
                              state = waitNameMultOnly;
                              break;

                         case tokenOpenBrace:
                              //bufferizeToken( token );
                              //state = waitNameMult;
                              if (!base_filter::callNextTokenFilter( token, pErrPos ))                return false;
                              state = stateStart;
                              break;

                         case tokenNone:  // compress spaces
                              base_filter::bufferizeToken( tokenNone );
                              state = waitNextSpace;
                              break;

                         default:
                              if (!base_filter::callNextTokenFilter( token, pErrPos )) return false;
                        }
                    }
                    break;

            case waitNameMultOnly:
                    if (token.tokenId==tokenNone)
                       {
                        base_filter::bufferizeCompressToken( tokenNone );
                        break; // space are simple buffered
                       }

                    if (!base_filter::flushBufferedTokens( pErrPos )) return false;
                    state = stateStart;
                    if (token.tokenId==tokenMultiply)
                       {
                        if (!base_filter::callNextTokenFilter( tokenFnNode, pErrPos ))     return false;
                        if (!base_filter::callNextTokenFilter( tokenOpenBrace , pErrPos ))     return false;
                        if (!base_filter::callNextTokenFilter( tokenCloseBrace, pErrPos ))     return false;
                       }
                    else
                       {
                        if (!base_filter::callNextTokenFilter( token, pErrPos )) return false;
                       }
                    break;

            case waitNameMult:
                    if (token.tokenId==tokenNone)
                       {
                        base_filter::bufferizeCompressToken( tokenNone );
                        break; // space are simple buffered
                       }

                    if (!base_filter::flushBufferedTokens( pErrPos )) return false;

                    if (token.tokenId==tokenAxisAttributeShort)
                       {
                        if (!base_filter::callNextTokenFilter( tokenAxisAttribute, pErrPos ))   return false;
                        if (!base_filter::callNextTokenFilter( tokenDoubleColon, pErrPos ))  return false;
                        state = waitAttrName;
                        break;
                       }

                    state = stateStart;
                    if (token.tokenId==tokenMultiply)
                       {
                        if (!base_filter::callNextTokenFilter( tokenAxisChild, pErrPos ))   return false;
                        if (!base_filter::callNextTokenFilter( tokenDoubleColon, pErrPos ))  return false;
                        if (!base_filter::callNextTokenFilter( tokenFnNode, pErrPos ))     return false;
                        if (!base_filter::callNextTokenFilter( tokenOpenBrace , pErrPos ))     return false;
                        if (!base_filter::callNextTokenFilter( tokenCloseBrace, pErrPos ))     return false;
                       }
                    else
                       {
                        if (!base_filter::callNextTokenFilter( token, pErrPos )) return false;
                       }
                    break;

            case waitAttrName:
                    {
                     if (!base_filter::flushBufferedTokens( pErrPos )) return false;
                     if (token.tokenId==tokenString || token.tokenId==tokenMultiply)
                        {
                         if (token.tokenId==tokenString)
                            {
                             if (!base_filter::callNextTokenFilter( token, pErrPos )) return false;
                            }
                         else
                            {
                             if (!base_filter::callNextTokenFilter( tokenFnNode, pErrPos ))     return false;
                             if (!base_filter::callNextTokenFilter( tokenOpenBrace , pErrPos ))     return false;
                             if (!base_filter::callNextTokenFilter( tokenCloseBrace, pErrPos ))     return false;
                            }
                        }
                     else
                        {
                         if (!base_filter::callNextTokenFilter( tokenMultiply, pErrPos )) return false;
                        }
                     state = stateStart;
                    }
                    break;

            case waitNextSpace:
                    {
                     if (token.tokenId!=tokenNone)
                        {
                         if (!base_filter::bufferedTokens.empty())
                            {
                             base_filter::curLen  = (base_filter::curPos - base_filter::bufferedTokens[0].tokenPos);
                             base_filter::curPos  = base_filter::bufferedTokens[0].tokenPos;
                            }
                         if (!base_filter::callNextTokenFilter( tokenNone, pErrPos )) return false;
                         base_filter::clearBufferedTokens();
                         state = stateStart;
                         return filtrate( token, pErrPos );
                        }
                     else
                        {
                         base_filter::bufferizeCompressToken( tokenNone );
                        }

                    }
                    break;

            default:
                    return false;
           }
        return true;
       }

    bool finalize( SIZE_T * pErrPos ) const
       {
        switch(state)
           {
            case stateStart      : break;
            case waitNextSpace   : break;
            case waitNameMult    : return false;
            case waitNameMultOnly: return false;
            case waitAttrName:
                    if (!base_filter::flushBufferedTokens( pErrPos )) return false;
                    if (!base_filter::callNextTokenFilter( tokenMultiply, pErrPos )) return false;
                    break;
            default:
                    return false;
           }

        return base_filter::callNextFinalize( pErrPos );
       }

}; // // CTokenFilterBasic


// http://allxml.h1.ru/articles/xpath.htm
// ��������� W3C ��� ���������� ���������� ������� � ������ �����������, � ���������� ���������
// (������ 2.5)- ���� ������� ($). � ���������� W3C, �������� �������� ����� ����� $xxx$ �����
// ���� �������� ��� wsxxxws, ��� ws - ������������, ������� ����� ���� ������, ��������� ���
// ������� �������. ������� ���������, ��������, not(), ���������� �������������� ������.
// ���� ���������� ��������� � ������������ ��� ����������, �� ����������� ������������� �����
// ������������ ��������� W3C

// convert or, and, div, mod strings to their tokens
// token_t convertNameToToken( const ::std::wstring &name )
template < typename TNextFilter>
struct CTokenFilterBinaryOps : public CTokenFilterBase<TNextFilter>
{
    enum state_t { stateStart    = 0,
                   waitKeyword      ,
                   waitNextSpace    ,
                   stateLast
                 };

    typedef CTokenFilterBase<TNextFilter> base_filter;

    mutable state_t           state;
    const CNameConverters     &nameConverters;
    //token_t convertNameToToken( const ::std::wstring &name )

    CTokenFilterBinaryOps( const TNextFilter &tn, const ::std::wstring &_refStr, const CNameConverters &cvt)
       : CTokenFilterBase<TNextFilter>( tn , _refStr ), state(stateStart), nameConverters(cvt) {}

    bool filtrate( const CToken &token, SIZE_T * pErrPos = 0 ) const
       {
        base_filter::filtrateSavePos( token ); // common action

        switch(state)
           {
            case stateStart:
                    if (  token.tokenId==tokenNone
                       || token.tokenId==tokenQuotedString
                       )
                       {
                        base_filter::bufferizeToken(token);
                        state = waitKeyword;
                       }
                    else
                       {
                        return base_filter::callNextTokenFilter( token, pErrPos );
                       }
                    break;

            case waitKeyword:
                    if (token.tokenId==tokenString)
                       {
                        base_filter::bufferizeToken(token);
                        state = waitNextSpace;
                       }
                    else if (token.tokenId==tokenNone)
                       { // skip multiple spaces
                        // do nothing
                       }
                    else // something else
                       {
                        if (base_filter::bufferedTokens[0].tokenId==tokenNone)
                           base_filter::clearBufferedTokens(1);
                        if (!base_filter::flushBufferedTokens( pErrPos )) return false; // not needed realy
                        if (!base_filter::callNextTokenFilter( token, pErrPos )) return false;
                        state = stateStart;
                       }
                    break;

            case waitNextSpace:
                    {
                     if (  token.tokenId==tokenNone
                        || token.tokenId==tokenQuotedString
                        )
                        {
                         token_t tt = nameConverters.opNameToToken.convertNameToToken( base_filter::getRefString( base_filter::bufferedTokens[1].tokenPos, base_filter::bufferedTokens[1].tokenLen ) );
                         if (tt!=tokenNone)
                            {
                             base_filter::bufferedTokens[1].tokenId = tt;
                            }
                         // remove starting space if it is really space
                         if (base_filter::bufferedTokens[0].tokenId==tokenNone)
                            base_filter::clearBufferedTokens(1);
                         if (!base_filter::flushBufferedTokens( pErrPos )) return false;
                         if (token.tokenId!=tokenNone)
                            { // pass non-space to next filter
                             if (!base_filter::callNextTokenFilter( token, pErrPos )) return false;
                            }
                        }
                     else
                        { // generic token
                         if (base_filter::bufferedTokens[0].tokenId==tokenNone)
                            base_filter::clearBufferedTokens(1);
                         if (!base_filter::flushBufferedTokens( pErrPos )) return false;
                         if (!base_filter::callNextTokenFilter( token, pErrPos )) return false;
                        }
                     state = stateStart;
                    }
                    break;

            default:
                    return false;
           }


        return true;
       }

    bool finalize( SIZE_T * pErrPos ) const
       {
        switch(state)
           {
            case stateStart:  break;
            case waitKeyword: if (base_filter::bufferedTokens[0].tokenId==tokenNone)
                                 base_filter::clearBufferedTokens(1);
                              if (!base_filter::flushBufferedTokens( pErrPos )) return false;
                              break;
            case waitNextSpace: return false; // binary op can't be present as last token
            default:
                    return false;
           }

        return base_filter::callNextFinalize( pErrPos );
       }

    // CAxisNameToToken         axisNameToToken;
    // COperatorNameToToken     opNameToToken;
    // CFunctionNameToToken     fnNameToToken;
    // bool callNextTokenFilter( token_t t, SIZE_T * pErrPos ) const
    // bool callNextTokenFilter( const CToken &token, SIZE_T * pErrPos ) const
    // void bufferizeToken( token_t t ) const
    // void bufferizeToken( const CToken &token ) const
    // bool flushBufferedTokensImpl( ::std::vector< CToken >::iterator end, SIZE_T * pErrPos ) const
    // void clearBufferedTokens() const
    // void clearBufferedTokens( SIZE_T numFirstTokensToErase ) const
    // ::std::wstring getRefString() const
    // ::std::wstring getRefString( SIZE_T startPos, SIZE_T substrLen ) const
    // bool flushBufferedTokens( SIZE_T numFirstTokensToFlush, SIZE_T * pErrPos ) const
    // bool flushBufferedTokens( SIZE_T * pErrPos ) const
    // void filtrateSavePos( const CToken &token ) const
    // SIZE_T getCurPos() const { return curPos; }
    // bool finalize( SIZE_T * pErrPos = 0 ) const
    // bool filtrate( const CToken &token, SIZE_T * pErrPos = 0 ) const

}; // struct CTokenFilterBinaryOps


template < typename TNextFilter>
struct CTokenFilterAxisAndFunctionsConverter : public CTokenFilterBase<TNextFilter>
{
    enum state_t { stateStart    = 0,
                   waitDoubleColon  ,
                   stateLast
                 };

    typedef CTokenFilterBase<TNextFilter> base_filter;

    mutable state_t           state;
    const CNameConverters     &nameConverters;
    //token_t convertNameToToken( const ::std::wstring &name )

    CTokenFilterAxisAndFunctionsConverter( const TNextFilter &tn, const ::std::wstring &_refStr, const CNameConverters &cvt)
       : CTokenFilterBase<TNextFilter>( tn , _refStr ), state(stateStart), nameConverters(cvt) {}

    bool filtrate( const CToken &token, SIZE_T * pErrPos = 0 ) const
       {
        base_filter::filtrateSavePos( token ); // common action

        switch(state)
           {
            case stateStart:
                    if ( token.tokenId==tokenString )
                       {
                        base_filter::bufferizeToken(token);
                        state = waitDoubleColon;
                       }
                    else
                       {
                        return base_filter::callNextTokenFilter( token, pErrPos );
                       }
                    break;

            case waitDoubleColon:
                    if ( token.tokenId==tokenDoubleColon )
                       {
                        token_t tt = nameConverters.axisNameToToken.convertNameToToken( base_filter::getRefString( base_filter::bufferedTokens[0].tokenPos, base_filter::bufferedTokens[0].tokenLen ) );
                        if (tt!=tokenNone)
                           {
                            base_filter::bufferedTokens[0].tokenId = tt;
                           }
                       }
                    else if ( token.tokenId==tokenOpenBrace )
                       {
                        token_t tt = nameConverters.fnNameToToken.convertNameToToken( base_filter::getRefString( base_filter::bufferedTokens[0].tokenPos, base_filter::bufferedTokens[0].tokenLen ) );
                        if (tt!=tokenNone)
                           {
                            base_filter::bufferedTokens[0].tokenId = tt;
                           }
                       }

                    if (!base_filter::flushBufferedTokens( pErrPos )) return false;
                    state = stateStart;
                    return base_filter::callNextTokenFilter( token, pErrPos );
            default:
                    return false;
           }

        return true;
       }

    bool finalize( SIZE_T * pErrPos ) const
       {
        switch(state)
           {
            case stateStart:  break;
            case waitDoubleColon:
                              if (!base_filter::flushBufferedTokens( pErrPos )) return false;
                              break;
            default:
                    return false;
           }

        return base_filter::callNextFinalize( pErrPos );
       }

}; // CTokenFilterAxisAndFunctionsConverter

/*
���������� ��� ����� ���������
��� �������� ����� ��������� ����� �������������� ����������:

���������� ��������
            child::

*/
template < typename TNextFilter>
struct CTokenFilterChildConverter : public CTokenFilterBase<TNextFilter>
{
    enum state_t { stateStart    = 0,
                   stateNormal      ,
                   stateWaitAxis   ,
                   //stateWaitDoubleColon,
                   stateSkipVarName,
                   //waitAxisedIdent  ,
                   stateLast
                 };

    typedef CTokenFilterBase<TNextFilter> base_filter;

    mutable state_t           state;
    //const CNameConverters     &nameConverters;
    //token_t convertNameToToken( const ::std::wstring &name )

    CTokenFilterChildConverter( const TNextFilter &tn, const ::std::wstring &_refStr )
       : CTokenFilterBase<TNextFilter>( tn , _refStr ), state(stateStart) {}
    CTokenFilterChildConverter( const TNextFilter &tn, const ::std::wstring &_refStr, const CNameConverters &cvt)
       : CTokenFilterBase<TNextFilter>( tn , _refStr ), state(stateStart) {}

    bool filtrate( const CToken &token, SIZE_T * pErrPos = 0 ) const
       {
        base_filter::filtrateSavePos( token ); // common action

        switch(state)
           {
            case stateNormal:
                 if (token.tokenId==tokenSlash)
                    {
                     state = stateWaitAxis;
                     return base_filter::callNextTokenFilter( token, pErrPos );
                    }
                 else if (token.tokenId==tokenVarRef)
                    {
                     state = stateSkipVarName;
                     return base_filter::callNextTokenFilter( token, pErrPos );
                    }
                 else if (token.tokenId==tokenOpenBrace)
                    {
                     state = stateStart;
                     return base_filter::callNextTokenFilter( token, pErrPos );
                    }
                 else if (token.tokenId==tokenUnion)
                    {
                     state = stateStart;
                     return base_filter::callNextTokenFilter( token, pErrPos );
                    }
                 //if ( token.tokenId!=tokenMultiply && token.tokenId!=tokenString )
                    return base_filter::callNextTokenFilter( token, pErrPos );
                 // else continue performance
                 break;

            case stateStart:
                 if (token.tokenId==tokenNone)
                    {
                     return true; // simply skip space
                    }
                 else if (token.tokenId==tokenSlash)
                    {
                     state = stateWaitAxis;
                     return base_filter::callNextTokenFilter( token, pErrPos );
                    }
                 /*
                 else if (token.tokenId==tokenVarRef)
                    {
                     state = stateSkipVarName;
                     return callNextTokenFilter( token, pErrPos );
                    }
                 */
                 else if (token.tokenId==tokenOpenBrace)
                    {
                     state = stateStart;
                     return base_filter::callNextTokenFilter( token, pErrPos );
                    }

                 if (token.tokenId==tokenVarRef)
                    state = stateSkipVarName;
                 else
                    state = stateNormal;
                 if ( token.tokenId==tokenMultiply || token.tokenId==tokenString || token.tokenId==tokenVarRef)
                    {
                     if (!base_filter::callNextTokenFilter( tokenAxisChild, pErrPos )) return false;
                     if (!base_filter::callNextTokenFilter( tokenDoubleColon, pErrPos )) return false;
                     if (token.tokenId==tokenMultiply)
                        {
                         if (!base_filter::callNextTokenFilter( tokenFnNode, pErrPos ))     return false;
                         if (!base_filter::callNextTokenFilter( tokenOpenBrace , pErrPos ))     return false;
                         if (!base_filter::callNextTokenFilter( tokenCloseBrace, pErrPos ))     return false;
                         return true;
                        }
                     else
                        return base_filter::callNextTokenFilter( token, pErrPos );
                    }
                 return base_filter::callNextTokenFilter( token, pErrPos );

            case stateWaitAxis:
                 if (isTokenAxis(token.tokenId))
                    {
                     state = stateNormal;
                     return base_filter::callNextTokenFilter( token, pErrPos );
                    }
                 if ( token.tokenId==tokenMultiply || token.tokenId==tokenString || token.tokenId==tokenVarRef)
                    {
                     state = stateNormal;
                     if (!base_filter::callNextTokenFilter( tokenAxisChild, pErrPos )) return false;
                     if (!base_filter::callNextTokenFilter( tokenDoubleColon, pErrPos )) return false;
                     return base_filter::callNextTokenFilter( token, pErrPos );
                    }
                 return base_filter::callNextTokenFilter( token, pErrPos );

            case stateSkipVarName:
                 state = stateNormal;
                 return base_filter::callNextTokenFilter( token, pErrPos );

            default:
                    return false;
           }

        return true;
       }

    bool finalize( SIZE_T * pErrPos ) const
       {
        switch(state)
           {
            case stateNormal:
            case stateStart:  break;
            case stateSkipVarName:
            case stateWaitAxis: return false;

            //case waitAxisedIdent:
            //                  if (!flushBufferedTokens( pErrPos )) return false;
            //                  break;
            default:
                    return false;
           }

        return base_filter::callNextFinalize( pErrPos );
       }

}; // CTokenFilterChildConverter


template < typename TNextFilter>
struct CTokenFilterDoNothing : public CTokenFilterBase<TNextFilter>
{

    typedef CTokenFilterBase<TNextFilter> base_filter;

    CTokenFilterDoNothing( const TNextFilter &tn, const ::std::wstring &_refStr )
       : CTokenFilterBase<TNextFilter>( tn , _refStr )  {}
    CTokenFilterDoNothing( const TNextFilter &tn, const ::std::wstring &_refStr, const CNameConverters &cvt)
       : CTokenFilterBase<TNextFilter>( tn , _refStr ) {}

    bool filtrate( const CToken &token, SIZE_T * pErrPos = 0 ) const
       {
        base_filter::filtrateSavePos( token ); // common action
        return base_filter::callNextTokenFilter( token, pErrPos );
        //return true;
       }

    bool finalize( SIZE_T * pErrPos ) const
       {
        return base_filter::callNextFinalize( pErrPos );
       }

}; // CTokenFilterDoNothing










inline
::std::wstring buildXPathExpressionFromTokens( const ::std::vector< CToken > &tokens, const ::std::wstring &refStr )
   {
    ::std::wstring res;
    ::std::vector< CToken >::const_iterator it = tokens.begin(), end = tokens.end();
    for(; it!=end; ++it)
       {
        res.append( it->toString(refStr), 0, refStr.npos );
       }
    return res;
   }

inline
bool baseTokenizeXPathExpression( const ::std::wstring &expr
                            , ::std::vector< CToken > &tokensTo
                            , SIZE_T *pErrPos, SIZE_T *pErrLine, SIZE_T *pErrLinePos
                            )
   {
    CTokenizer tokenizer;
    SIZE_T size = expr.size(), pos = 0;
    for( ; pos!=size; ++pos )
       {
        if (!tokenizer.tokenize(expr[pos]))
           {
            SIZE_T errLine = -1, errPos = -1;
            getLinePos( expr, tokenizer.curPos, errLine, errPos );
            if (pErrPos)     *pErrPos     = tokenizer.curPos;
            if (pErrLine)    *pErrLine    = errLine;
            if (pErrLinePos) *pErrLinePos = errPos;
            return false;
           }
       }

    if (!tokenizer.finalize())
       {
        SIZE_T errLine = -1, errPos = -1;
        getLinePos( expr, tokenizer.curPos, errLine, errPos );
        if (pErrPos)     *pErrPos     = tokenizer.curPos;
        if (pErrLine)    *pErrLine    = errLine;
        if (pErrLinePos) *pErrLinePos = errPos;
        return false;
       }

    tokensTo.swap(tokenizer.tokens);
    return true;
   }

inline
bool normalizeXPathExpressionCopy( const ::std::vector< CToken > &tokens
                             , ::std::vector< CToken > &tokensOut
                             , const ::std::wstring          &expr // input expression
                             , SIZE_T *pErrPos, SIZE_T *pErrLine, SIZE_T *pErrLinePos
                             , const CNameConverters &nameConverters
                             )
   {
    typedef CTokenVectorCollector                                      final_converter_t;
    typedef CTokenFilterChildConverter<final_converter_t>              before1_converter_t;
    typedef CTokenFilterAxisAndFunctionsConverter<before1_converter_t> before2_converter_t;
    typedef CTokenFilterBinaryOps< before2_converter_t >               before3_converter_t;
    //typedef CTokenFilterDoNothing< before2_converter_t >             before3_converter_t;
    typedef CTokenFilterBasic< before3_converter_t >                   first_converter_t;


    final_converter_t   final_converter( tokensOut );
    before1_converter_t before1_converter( final_converter  , expr, nameConverters );
    before2_converter_t before2_converter( before1_converter, expr, nameConverters );
    before3_converter_t before3_converter( before2_converter, expr, nameConverters );
    first_converter_t   first_converter  ( before3_converter, expr );

    SIZE_T errPos = 0;
    bool res = filtrateTokens( tokens, first_converter, &errPos );
    if (!res )
       {
        if (pErrPos) *pErrPos = errPos;
        SIZE_T line = -1, pos = -1;
        getLinePos( expr, errPos, line, pos);
        if (pErrLine)    *pErrLine    = line;
        if (pErrLinePos) *pErrLinePos = pos;
       }
    return res;
   }

inline
bool normalizeXPathExpressionCopy( const ::std::vector< CToken > &tokens
                             , ::std::vector< CToken > &tokensOut
                             , const ::std::wstring          &expr // input expression
                             , SIZE_T *pErrPos, SIZE_T *pErrLine, SIZE_T *pErrLinePos
                             )
   {
    CNameConverters nameConverters;
    return normalizeXPathExpressionCopy( tokens, tokensOut, expr, pErrPos, pErrLine, pErrLinePos, nameConverters);
   }

inline
bool normalizeXPathExpression(::std::vector< CToken > &tokens
                             , const ::std::wstring          &expr // input expression
                             , SIZE_T *pErrPos, SIZE_T *pErrLine, SIZE_T *pErrLinePos
                             , const CNameConverters &nameConverters
                             )
   {
    ::std::vector< CToken > tokensOut;
    tokensOut.reserve( tokens.size() );
    if (!normalizeXPathExpressionCopy( tokens, tokensOut, expr, pErrPos, pErrLine, pErrLinePos, nameConverters))
       return false;
    tokensOut.swap(tokens);
    return true;
   }

inline
bool normalizeXPathExpression(::std::vector< CToken > &tokens
                             , const ::std::wstring          &expr // input expression
                             , SIZE_T *pErrPos, SIZE_T *pErrLine, SIZE_T *pErrLinePos
                             )
   {
    CNameConverters nameConverters;
    return normalizeXPathExpression( tokens, expr, pErrPos, pErrLine, pErrLinePos, nameConverters);
   }


inline
bool normalizeXPathExpression( const ::std::wstring &expr
                             , ::std::wstring &strTo
                             , SIZE_T *pErrPos, SIZE_T *pErrLine, SIZE_T *pErrLinePos
                             , const CNameConverters &nameConverters
                             )
   {
    ::std::vector< CToken > tokens;
    ::std::vector< CToken > tokensOut;
    if (!baseTokenizeXPathExpression( expr, tokens, pErrPos, pErrLine, pErrLinePos ))
       return false;

    if (!normalizeXPathExpressionCopy( tokens, tokensOut, expr, pErrPos, pErrLine, pErrLinePos, nameConverters))
       return false;

    strTo = buildXPathExpressionFromTokens( tokensOut, expr );
    return true;
   }

inline
bool normalizeXPathExpression( const ::std::wstring &expr
                             , ::std::wstring &strTo
                             , SIZE_T *pErrPos, SIZE_T *pErrLine, SIZE_T *pErrLinePos
                             )
   {
    CNameConverters nameConverters;
    return normalizeXPathExpression( expr, strTo, pErrPos, pErrLine, pErrLinePos, nameConverters );
   }


inline
void throwUnexpectedToken( const CToken &token, const ::std::wstring &refStr, const char *srcFile, int srcLine )
   {
    SIZE_T errLine = 0, errLinePos = 0;
    getLinePos( refStr, token.tokenPos, errLine, errLinePos );
    throw ::cli::CException( false, EC_XPATH_UNEXPECTED_TOKEN, srcFile, srcLine, ::cli::format::arg( (UINT)token.tokenPos ) % (UINT)errLine % (UINT)errLinePos % token.toDisplayString(refStr) );
   }

inline
void throwUnsupportedAxis( const CToken &token, const ::std::wstring &refStr, const char *srcFile, int srcLine )
   {
    SIZE_T errLine = 0, errLinePos = 0;
    getLinePos( refStr, token.tokenPos, errLine, errLinePos );
    throw ::cli::CException( false, EC_XPATH_UNSUPPORTED_AXIS, srcFile, srcLine, ::cli::format::arg( (UINT)token.tokenPos ) % (UINT)errLine % (UINT)errLinePos % token.toDisplayString(refStr) );
   }

inline
void throwUnsupportedFunction( const CToken &token, const ::std::wstring &refStr, const char *srcFile, int srcLine )
   {
    SIZE_T errLine = 0, errLinePos = 0;
    getLinePos( refStr, token.tokenPos, errLine, errLinePos );
    throw ::cli::CException( false, EC_XPATH_UNSUPPORTED_FUNCTION, srcFile, srcLine, ::cli::format::arg( (UINT)token.tokenPos ) % (UINT)errLine % (UINT)errLinePos % token.toDisplayString(refStr) );
   }

inline
void throwUnsupportedOperator( const CToken &token, const ::std::wstring &refStr, const char *srcFile, int srcLine )
   {
    SIZE_T errLine = 0, errLinePos = 0;
    getLinePos( refStr, token.tokenPos, errLine, errLinePos );
    throw ::cli::CException( false, EC_XPATH_UNSUPPORTED_OPERATOR, srcFile, srcLine, ::cli::format::arg( (UINT)token.tokenPos ) % (UINT)errLine % (UINT)errLinePos % token.toDisplayString(refStr) );
   }

inline
void throwFunctionOperandsMiscount( const CToken &token, unsigned numOps, const ::std::wstring &refStr, const char *srcFile, int srcLine )
   {
    SIZE_T errLine = 0, errLinePos = 0;
    getLinePos( refStr, token.tokenPos, errLine, errLinePos );
    throw ::cli::CException( false, EC_XPATH_FN_WRONG_NUM_OPERANDS, srcFile, srcLine, ::cli::format::arg( (UINT)token.tokenPos ) % (UINT)errLine % (UINT)errLinePos % token.toDisplayString(refStr) % (UINT)numOps );
   }

inline
void throwOperatorOperandsMiscount( const CToken &token, unsigned numOps, const ::std::wstring &refStr, const char *srcFile, int srcLine )
   {
    SIZE_T errLine = 0, errLinePos = 0;
    getLinePos( refStr, token.tokenPos, errLine, errLinePos );
    throw ::cli::CException( false, EC_XPATH_OP_WRONG_NUM_OPERANDS, srcFile, srcLine, ::cli::format::arg( (UINT)token.tokenPos ) % (UINT)errLine % (UINT)errLinePos % token.toDisplayString(refStr) % (UINT)numOps );
   }

inline
void throwUnexpectedEnd( const char *srcFile, int srcLine )
   {
    throw ::cli::CException( false, EC_XPATH_UNEXPECTED_END_OF_EXPRESSION, __FILE__, __LINE__, 0 );
   }


/*
http://msdn.microsoft.com/ru-ru/library/ms256081.aspx
http://www.farinadesign.narod.ru/deflt.html?XMLtech/Lectures/XSLT1.html
������� �������������� (�� ������� � �������) ��� ���������� ���������
� ������� ���������� �������� � ��������� �������.

1 ( )        �����������
2 [ ]        ����������
3 / � //     �������� � �����
4 div mod *
5 + -
6 < <= > >=  ���������
7 = !=       ���������
8 |          �����������
  not()      ������ "���" (processed as function call)
9 and        ������ "�"
10 or         ������ "���"
*/


//::std::vector< CToken >::const_iterator first


::std::vector< CToken >::const_iterator executeParsed( INTERFACE_CLI_IDATANODE *pNode
                  , ::cli::CiDataNodeList &resultNodeList
                  , INTERFACE_CLI_IVARIANTMAP *pVarMap
                  , ::std::vector< CToken >::const_iterator first
                  , ::std::vector< CToken >::const_iterator last
                  , const ::std::wstring &refStr
                  , bool allowCreateNewNodes
                  );



struct CExpressionTreeItem
{
    typedef ::std::vector< CToken >::const_iterator                          token_const_iterator_t;
    typedef ::std::vector< CToken >::iterator                                token_iterator_t;
    typedef ::std::pair< token_const_iterator_t , token_const_iterator_t >   expression_boundaries_t;

    CToken                               tokenOpCode;
    expression_boundaries_t              expr;   // if opCode==tokenNone
    ::std::vector< CExpressionTreeItem > subexpressions;
    bool                                 grouped;

    // ���� tokenOpCode.tokenId == tokenNone, �� ������� ���� - ��� ����,
    // ���������� ��������� ��������� ��� ���������� (xpath ���������, ��� �������, ���������� � ��)

    // subexpressions - ������������

    CExpressionTreeItem() : tokenOpCode(tokenNone), expr(), subexpressions(), grouped(false) {}
    CExpressionTreeItem(expression_boundaries_t b) : tokenOpCode(tokenNone), expr(b), subexpressions(), grouped(false) {}
    CExpressionTreeItem(token_iterator_t f, token_iterator_t s) : tokenOpCode(tokenNone), expr(f,s), subexpressions(), grouped(false) {}

    bool isFunctionNode( ) const
       {
        return isTokenFunction(tokenOpCode.tokenId);
       }

    bool isFunctionNodeEx( ) const
       {
        return isTokenFunctionEx(tokenOpCode.tokenId);
       }

    bool isOperatorNode( ) const
       {
        return isTokenOperator(tokenOpCode.tokenId);
       }

    unsigned getOperatorLevel() const
       {
        return operatorLevel(tokenOpCode.tokenId);
       }

    template< typename TStream >
    void printLeafExpression( TStream &stream, expression_boundaries_t expression, const ::std::wstring &refStr ) const
       {
        for( ; expression.first!=expression.second; ++expression.first )
           stream<< expression.first->toString(refStr);
       }

    template< typename TStream >
    void printExpression( TStream &stream, const ::std::wstring &refStr, SIZE_T levelNo = 0) const
       {
        if (tokenOpCode.tokenId == tokenNone)
           {
            stream << ::std::wstring( levelNo*4, ' ');
            printLeafExpression(stream,expr,refStr);
            stream << "\n";
           }
        else
           {
            stream << ::std::wstring( levelNo*4, ' ');
            stream << "Op: " << tokenOpCode.toString(refStr);
            stream << "\n";
            ::std::vector< CExpressionTreeItem >::const_iterator it = subexpressions.begin();
            for(; it != subexpressions.end(); ++it)
               {
                it->printExpression( stream, refStr, levelNo+1 );
               }
           }
       }

    template< typename TStream >
    void printExpression2Impl( TStream &stream, const ::std::wstring &refStr, SIZE_T levelNo = 0) const
       {
        if (tokenOpCode.tokenId == tokenNone)
           {
            //stream << ::std::wstring( levelNo*4, ' ');
            printLeafExpression(stream,expr,refStr);
            //stream << "\n";
           }
        else
           {
            //stream << ::std::wstring( levelNo*4, ' ');
            //stream << "Op: " << tokenOpCode.toString(refStr);
            stream << tokenOpCode.toString(refStr);
            stream << "(";
            ::std::vector< CExpressionTreeItem >::const_iterator it = subexpressions.begin();
            for(; it != subexpressions.end(); ++it)
               {
                if (it != subexpressions.begin()) stream<<",";
                it->printExpression2Impl( stream, refStr, levelNo+1 );
               }
            stream << ")";
           }
       }

    template< typename TStream >
    void printExpression2( TStream &stream, const ::std::wstring &refStr, SIZE_T levelNo = 0) const
       {
        printExpression2Impl( stream, refStr, levelNo );
        //stream<<"\n";
       }

    template< typename TStream >
    void printExpression3( TStream &stream, const ::std::wstring &refStr, SIZE_T levelNo = 0) const
       {
        if (tokenOpCode.tokenId == tokenNone)
           {
            //stream << ::std::wstring( levelNo*4, ' ');
            printLeafExpression(stream,expr,refStr);
            //stream << "\n";
           }
        else
           {
            //stream << ::std::wstring( levelNo*4, ' ');
            //stream << "Op: " << tokenOpCode.toString(refStr);
            if (!isTokenOperator(tokenOpCode.tokenId))
               stream << tokenOpCode.toString(refStr);
            stream << "(";
            ::std::vector< CExpressionTreeItem >::const_iterator it = subexpressions.begin();
            for(; it != subexpressions.end(); ++it)
               {
                if (it != subexpressions.begin())
                   {
                    if (!isTokenOperator(tokenOpCode.tokenId))
                       stream<<",";
                    else
                       stream << tokenOpCode.toString(refStr);
                   }
                it->printExpression3( stream, refStr, levelNo+1 );
               }
            stream << ")";
           }
       }

    bool rebalance( const ::std::wstring &refStr )
       {
        //return;
        if (!isOperatorNode())
           {
            if ( tokenOpCode.tokenId == tokenNone )
               {
                if (expr.first!=expr.second)
                   {
                    token_const_iterator_t tmp = expr.first;
                    ++tmp;
                    if (expr.first->tokenId==tokenQuotedString || expr.first->tokenId==tokenNumber)
                       {
                        if (tmp!=expr.second)
                           throwUnexpectedToken( *tmp, refStr, __FILE__, __LINE__ );
                        tokenOpCode = *(expr.first);
                       }
                    else
                       { // detect function here, parse it arguments to separate lists and build subexpressions

                       }
                   }
               }

            if (isFunctionNode())
               {
                ::std::vector< CExpressionTreeItem >::iterator it = subexpressions.begin();
                for(; it != subexpressions.end(); ++it)
                   it->rebalance(refStr);
               }
            return false;
           }

        if (grouped)
           {
            ::std::vector< CExpressionTreeItem >::iterator it = subexpressions.begin();
            for(; it != subexpressions.end(); ++it)
               it->rebalance(refStr);
            return false;
           }

        if (subexpressions.size()<2) return false;
        //if (!rightOperand.isOperatorNode())
        if (!subexpressions[1].isOperatorNode())
           {
            subexpressions[0].rebalance(refStr);
            subexpressions[1].rebalance(refStr);
            return false;
           }

        CExpressionTreeItem leftOperand  = subexpressions[0]; // single
        CExpressionTreeItem rightOperand = subexpressions[1];

        subexpressions.clear();
        CToken savedTokenOpCode = tokenOpCode;

        //unsigned leftLevel  = leftOperand.getOperatorLevel();
        unsigned curLevel   = getOperatorLevel();
        unsigned rightLevel = rightOperand.getOperatorLevel();
        //if ((leftLevel > rightLevel) || rightOperand.grouped)
        if ((curLevel > rightLevel) || rightOperand.grouped)
           { // ������ - ������������, ��� ����� ������
            tokenOpCode = savedTokenOpCode;
            leftOperand.rebalance(refStr);
            rightOperand.rebalance(refStr);
            subexpressions.push_back(leftOperand);
            subexpressions.push_back(rightOperand);
            return false;
           }
        else
           {
            CExpressionTreeItem tmp;
            tmp.tokenOpCode = savedTokenOpCode;
            tmp.subexpressions.push_back( leftOperand );
            tmp.subexpressions.push_back( rightOperand.subexpressions[0] );
            rightOperand.subexpressions[0] = tmp;
            *this = rightOperand;
            bool res = false;
            ::std::vector< CExpressionTreeItem >::iterator it = subexpressions.begin();
            for(; it != subexpressions.end(); ++it)
               {
                if (it == subexpressions.begin())
                   it->rebalance(refStr);
                else
                   res = it->rebalance(refStr);
               }
            //while (rebalance()) {}
            if (res) res = rebalance(refStr);
            return res;
           }
       }


    token_const_iterator_t parseExpression( token_const_iterator_t first, token_const_iterator_t last, const ::std::wstring &refStr )
       {
        expr.first = expr.second = first;
        int sqLevel = 0;
        for( ; first!=last;  /* ++first */ )
           {
            // ������������ ���, ��� ������ ���������� ������
            if (first->tokenId==tokenOpenSquareBrace)       { ++sqLevel; }
            else if (first->tokenId==tokenCloseSquareBrace) { --sqLevel; }
            // �������� ��� � ������� ����
            if (sqLevel>0) { expr.second = ++first; continue; }

            if (first->tokenId==tokenCloseBrace) return first;
            if (first->tokenId==tokenComma) return first;

            //if (first->tokenId==)
            if (isTokenOperator(first->tokenId))
               {
                //if (tokenOpCode.tokenId==tokenNone)
                   {
                    CToken savedTokenOpCode = *first;

                    CExpressionTreeItem leftOperand = *this; // copy empty node
                    ++first;
                    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );

                    CExpressionTreeItem rightOperand;
                    first = rightOperand.parseExpression( first, last, refStr );

                    tokenOpCode = savedTokenOpCode;
                    subexpressions.clear();
                    subexpressions.push_back(leftOperand);
                    subexpressions.push_back(rightOperand);
                   }
                //else // we are currently reading second operand
                //   {
                //    // throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                //   }
               }
            //else if (isTokenFunction(first->tokenId))
            else if (isTokenFunctionEx(first->tokenId))
               {
                if (tokenOpCode.tokenId!=tokenNone)
                   throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );


                if (!isTokenFunction( first->tokenId ))
                   {
                    expr.second = ++first;
                    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                    if (first->tokenId!=tokenOpenBrace)
                       throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                    expr.second = ++first;
                    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                    if (first->tokenId!=tokenCloseBrace)
                       throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                    expr.second = ++first;
                   }
                else
                   {
                    tokenOpCode = *first;
                    ++first;
                    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                    if (first->tokenId!=tokenOpenBrace)
                       throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                    ++first;
                    while(first!=last && first->tokenId!=tokenCloseBrace)
                       {
                        CExpressionTreeItem argument;
                        first = argument.parseExpression( first, last, refStr );
                        subexpressions.push_back(argument);
                        //if (first->tokenId==tokenCloseBrace) return first;
                        if (first->tokenId==tokenComma)
                           {
                            ++first;
                            if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                            if (first->tokenId==tokenCloseBrace)
                               throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                           }
                        else
                           {
                            if (first->tokenId!=tokenCloseBrace)
                               throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                           }
                       }
                    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                    ++first;
                   }
               }
            else if (first->tokenId==tokenOpenBrace)
               {
                if (tokenOpCode.tokenId!=tokenNone)
                   throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                ++first;
                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                first = parseExpression( first, last, refStr );
                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                if (first->tokenId!=tokenCloseBrace)
                   throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                ++first;
                grouped = true;
               }
            else
               { //
                expr.second = ++first;
               }
           }
        rebalance(refStr);
        return first;
       }
//throwUnexpectedToken( const CToken &token, const ::std::wstring &refStr, const char *srcFile, int srcLine )
/*
    token_const_iterator_t parseOperator( token_const_iterator_t first, token_const_iterator_t last )
       {
       }
*/

    /* check is variant contain void* ptr (realy nidelist ptr) and create nodelist if not */
    void checkCreateVariantNodeList( ::cli::iVariant *pVariant, ::cli::iDataNodeList **pNodeListRet, ::cli::iDataNodeList *pNodeListBase ) const
       {
        if (!pVariant) { if (pNodeListRet) *pNodeListRet = 0; return; }

        ::cli::iDataNodeList *tmpNodeListPtr = 0;
        RCODE tmpRes = pVariant->valueQueryInterface( INTERFACE_CLI_IDATANODELIST_IID, (VOID**)&tmpNodeListPtr );
        if (!tmpRes)
           {
            if (pNodeListRet) *pNodeListRet = tmpNodeListPtr;
            else if (tmpNodeListPtr) tmpNodeListPtr->release();
            return; // type is CLI_VARIANTTYPE_VT_IUNKNOWN, pUnknown not empty and INTERFACE_CLI_IDATANODELIST interface supported
           }

        // need to create new node list object

        tmpNodeListPtr = 0;
        pNodeListBase->makeCleanNodeListClone(&tmpNodeListPtr);
        if (!tmpNodeListPtr) { if (pNodeListRet) *pNodeListRet = 0; return; }

        ::cli::iUnknown *pUnk = 0;
        tmpNodeListPtr->queryInterface(INTERFACE_CLI_IUNKNOWN_IID, (VOID**)&pUnk );
        pVariant->setUnknown( pUnk );

        if (pNodeListRet) { *pNodeListRet = tmpNodeListPtr; (*pNodeListRet)->addRef(); }

        if (pUnk) pUnk->release();
        tmpNodeListPtr->release();
       }

    void checkCreateVariantNodeList( ::cli::iVariant *pVariant, ::cli::iDataNodeList **pNodeListRet ) const
       {
        if (!pVariant) { if (pNodeListRet) *pNodeListRet = 0; return; }

        ::cli::iDataNodeList *tmpNodeListPtr = 0;
        RCODE tmpRes = pVariant->valueQueryInterface( INTERFACE_CLI_IDATANODELIST_IID, (VOID**)&tmpNodeListPtr );
        if (!tmpRes)
           {
            if (pNodeListRet) *pNodeListRet = tmpNodeListPtr;
            else if (tmpNodeListPtr) tmpNodeListPtr->release();
            return; // type is CLI_VARIANTTYPE_VT_IUNKNOWN, pUnknown not empty and INTERFACE_CLI_IDATANODELIST interface supported
           }

        ::cli::CiDataNodeList tmpNodeList("/cli/datanodelist");

        ::cli::iUnknown *pUnk = 0;
        //tmpNodeList.queryInterface(INTERFACE_CLI_IUNKNOWN_IID, (VOID**)&pUnk );
        tmpNodeList.queryInterface( &pUnk );
        pVariant->setUnknown( pUnk );

        if (pNodeListRet) { *pNodeListRet = tmpNodeList.getIfPtr(); (*pNodeListRet)->addRef(); }

        if (pUnk)      pUnk->release();
       }

    bool evaluate( ::cli::CiDataNode &curDataNode
                 , SIZE_T nodeIndex
                 , INTERFACE_CLI_IVARIANTMAP *pVarMap
                 , ::cli::CiDataNodeList &currentNodes
                 , const ::std::wstring &refStr
                 , bool allowCreateNewNodes
                 ) const
       {
        ::cli::iVariant *pResVariant = 0;
        evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, &pResVariant, allowCreateNewNodes );
        bool res = false;
        if (pResVariant)
           {
            ENUM_CLI_VARIANTTYPE resType = pResVariant->getType();
            if (resType==CLI_VARIANTTYPE_VT_BOOL)
               {
                BOOL b = FALSE;
                pResVariant->getBool( &b );
                if (b) res = true;
               }
            else // result is an index of node
               {
                UINT idxTaken = 0;
                pResVariant->getUInt(&idxTaken);
                if (idxTaken && (idxTaken-1)==nodeIndex) res = true;
               }
            pResVariant->release();
           }
        return res;
       }

    void cleanVariantVector( ::std::vector< ::cli::iVariant* > &v ) const
       {
        ::std::vector< ::cli::iVariant* >::iterator evit = v.begin();
        for(; evit != v.end(); ++evit)
           {
            if (!(*evit)) continue;
            (*evit)->release();
           }
        v.clear();
       }

    void convertVariantVector( ::std::vector< ::cli::iVariant* > &v, ENUM_CLI_VARIANTTYPE newVt ) const
       {
        ::std::vector< ::cli::iVariant* >::iterator evit = v.begin();
        for(; evit != v.end(); ++evit)
           {
            (*evit)->convertType(newVt);
           }
       }

    bool findVariantType( ::std::vector< ::cli::iVariant* > &v, ENUM_CLI_VARIANTTYPE vtLookupFor ) const
       {
        ::std::vector< ::cli::iVariant* >::iterator evit = v.begin();
        for(; evit != v.end(); ++evit)
           {
            if ( (*evit)->getType()==vtLookupFor ) return true;
           }
        return false;
       }

    void evaluate( ::cli::CiDataNode &curDataNode
                 , SIZE_T nodeIndex
                 , INTERFACE_CLI_IVARIANTMAP *pVarMap
                 , ::cli::CiDataNodeList &currentNodes
                 , const ::std::wstring &refStr
                 , ::cli::iVariant **pVariantRes
                 , bool allowCreateNewNodes
                 ) const
       {
        if (isOperatorNode())
           {
            ::std::vector< ::cli::iVariant* > evaluatedArgs;

            ::std::vector< CExpressionTreeItem >::const_iterator subIt = subexpressions.begin();
            for(; subIt != subexpressions.end(); ++subIt)
               {
                ::cli::iVariant *pv = 0;
                subIt->evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, &pv, allowCreateNewNodes );
                evaluatedArgs.push_back(pv);
               }

            *pVariantRes = cliGetVariant( );
            (*pVariantRes)->setBool( FALSE );
            if (tokenOpCode.tokenId==tokenEqual && allowCreateNewNodes)
               {
                if (evaluatedArgs.size()!=2)
                   {
                    unsigned numOperands = (unsigned)evaluatedArgs.size();
                    cleanVariantVector(evaluatedArgs);
                    throwOperatorOperandsMiscount( tokenOpCode, numOperands, refStr, __FILE__, __LINE__ );
                   }

                ::cli::CiVariant_tmp tmp1( evaluatedArgs[0] );
                ::cli::CiVariant_tmp tmp2( evaluatedArgs[1] );

                ::cli::CiDataNodeList leftNodeList;
                tmp1.valueQueryInterface( INTERFACE_CLI_IDATANODELIST_IID, (VOID**)leftNodeList.getPP());
                if (!!leftNodeList)
                   {
                    SIZE_T listSize = leftNodeList.listSize;
                    if (listSize==1)
                       {
                        ::cli::CiDataNode leftDataNode;
                        leftNodeList.getDataNode( leftDataNode.getPP(), 0 );
                        if (!!leftDataNode)
                           {
                            ::cli::CiReadOnlyVariant roVariant;
                            leftDataNode.getDataNodeValue( roVariant.getPP() );

                            ::cli::CiVariant leftVariant;

                            if (!!roVariant)
                               {
                                roVariant.queryInterface( leftVariant );
                               }
                            else // no value at all
                               {
                                leftVariant.create("/cli/variant");
                               }

                            if (leftVariant.getType()==CLI_VARIANTTYPE_VT_EMPTY)
                               {
                                leftVariant.assignVariant(tmp2.getIfPtr());
                                (*pVariantRes)->setBool( TRUE );
                                cleanVariantVector(evaluatedArgs);
                                return;
                               }
                            // in all other cases we use standard behavior
                           }
                       }
                   }
               }

            if (tokenOpCode.tokenId==tokenUnion)
               {
                ::cli::iDataNodeList *pNodeListAddTo = 0;
                checkCreateVariantNodeList( *pVariantRes, &pNodeListAddTo, currentNodes.getIfPtr() );
                if (!pNodeListAddTo)
                   {
                    cleanVariantVector(evaluatedArgs);
                    return;
                   }
                ::std::vector< ::cli::iVariant* >::iterator evaIt = evaluatedArgs.begin();
                for(; evaIt != evaluatedArgs.end(); ++evaIt)
                   {
                    ::cli::iDataNodeList *pNodeListTmp = 0;
                    if (!(*evaIt)) continue;
                    (*evaIt)->valueQueryInterface( INTERFACE_CLI_IDATANODELIST_IID, (VOID**)&pNodeListTmp );
                    if (!pNodeListTmp) continue;
                    pNodeListAddTo->mergeNodeList( pNodeListTmp );
                    pNodeListTmp->release();
                   }
                pNodeListAddTo->release();
                cleanVariantVector(evaluatedArgs);
                return;
               }

            if (tokenOpCode.tokenId==tokenPlus || tokenOpCode.tokenId==tokenMinus)
               {
                if (evaluatedArgs.size()!=2 && evaluatedArgs.size()!=1)
                   {
                    unsigned numOperands = (unsigned)evaluatedArgs.size();
                    cleanVariantVector(evaluatedArgs);
                    throwOperatorOperandsMiscount( tokenOpCode, numOperands, refStr, __FILE__, __LINE__ );
                   }
               }
            else
               {
                if (evaluatedArgs.size()!=2)
                   {
                    unsigned numOperands = (unsigned)evaluatedArgs.size();
                    cleanVariantVector(evaluatedArgs);
                    throwOperatorOperandsMiscount( tokenOpCode, numOperands, refStr, __FILE__, __LINE__ );
                   }
               }

            bool resBool = false;
            INT64 iRes = 0;
            if (tokenOpCode.tokenId>=tokenLess && tokenOpCode.tokenId<=tokenNotEqual && findVariantType(evaluatedArgs,CLI_VARIANTTYPE_VT_PSTRING) )
               {
                ::std::wstring s1, s2;
                ::cli::CiVariant_tmp tmp1( evaluatedArgs[0] );
                ::cli::CiVariant_tmp tmp2( evaluatedArgs[1] );
                tmp1.getString(s1);
                tmp2.getString(s2);

                resBool = true;
                switch(tokenOpCode.tokenId)
                   {
                    case tokenLess:            iRes = s1 <  s2 ? 1 : 0; break;
                    case tokenGreater:         iRes = s1 >  s2 ? 1 : 0; break;
                    case tokenLessOrEqual:     iRes = s1 <= s2 ? 1 : 0; break;
                    case tokenGreaterOrEqual:  iRes = s1 >= s2 ? 1 : 0; break;
                    case tokenEqual:           iRes = s1 == s2 ? 1 : 0; break;
                    case tokenNotEqual:        iRes = s1 != s2 ? 1 : 0; break;
                    default: iRes = 0;
                   }
               }
            else
               {
                if ((tokenOpCode.tokenId==tokenPlus || tokenOpCode.tokenId==tokenMinus) && evaluatedArgs.size()==1)
                   {
                    INT64 i = 0;
                    evaluatedArgs[0]->getInt64( &i );
                    if (tokenOpCode.tokenId==tokenMinus)
                       iRes = -i; // if plus we do nothing
                   }
                else
                   {
                    INT64 i1 = 0, i2 = 0;
                    evaluatedArgs[0]->getInt64( &i1 );
                    evaluatedArgs[1]->getInt64( &i2 );
                    switch(tokenOpCode.tokenId)
                       {
                        case tokenDiv:             iRes = i1 /  i2; break;
                        case tokenMod:             iRes = i1 %  i2; break;
                        case tokenMultiply:        iRes = i1 *  i2; break;
                        case tokenPlus:            iRes = i1 +  i2; break;
                        case tokenMinus:           iRes = i1 -  i2; break;
                        case tokenLess:            iRes = i1 <  i2 ? 1 : 0; resBool = true; break;
                        case tokenGreater:         iRes = i1 >  i2 ? 1 : 0; resBool = true; break;
                        case tokenLessOrEqual:     iRes = i1 <= i2 ? 1 : 0; resBool = true; break;
                        case tokenGreaterOrEqual:  iRes = i1 >= i2 ? 1 : 0; resBool = true; break;
                        case tokenEqual:           iRes = i1 == i2 ? 1 : 0; resBool = true; break;
                        case tokenNotEqual:        iRes = i1 != i2 ? 1 : 0; resBool = true; break;
                        case tokenAnd:             iRes = i1 && i2 ? 1 : 0; resBool = true; break;
                        case tokenOr:              iRes = i1 || i2 ? 1 : 0; resBool = true; break;
                        default:
                             cleanVariantVector(evaluatedArgs);
                             throwUnsupportedOperator( tokenOpCode, refStr, __FILE__, __LINE__ );
                       }
                   }
               }

            if (resBool)
               (*pVariantRes)->setBool( iRes ? TRUE : FALSE );
            else
               (*pVariantRes)->setInt64( iRes );

            // cleanup
            cleanVariantVector(evaluatedArgs);
           }
        else if (isFunctionNodeEx())
           {
            *pVariantRes = cliGetVariant( );
            (*pVariantRes)->setBool( FALSE );

            switch(tokenOpCode.tokenId)
               {
                /*
                case tokenFnNode:
                     {
                      ::cli::iDataNodeList *pNewNodeList;
                      checkCreateVariantNodeList( *pVariantRes, &pNewNodeList, currentNodes.getIfPtr() );
                      pNewNodeList->pushBackDataNode( curDataNode.getIfPtr() );
                      pNewNodeList->release();
                     }
                     break;
                case tokenFnText:
                     {
                      ::cli::iDataNodeList *pNewNodeList;
                      checkCreateVariantNodeList( *pVariantRes, &pNewNodeList, currentNodes.getIfPtr() );
                      pNewNodeList->pushBackDataNode( curDataNode.getIfPtr() );
                      pNewNodeList->release();
                      // we return not a text but a node, but later node will be converted to text implicitly
                     }
                     break;
                */

                //case tokenFnValue:
                case tokenFnCurrent:
                     {
                      ::cli::iDataNodeList *pNewNodeList;
                      checkCreateVariantNodeList( *pVariantRes, &pNewNodeList, currentNodes.getIfPtr() );
                      pNewNodeList->pushBackDataNode( curDataNode.getIfPtr() );
                      pNewNodeList->release();
                     }
                     break;

                case tokenFnCount:
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var.getPP(), allowCreateNewNodes );
                      ::cli::CiDataNodeList nodeList;
                      var.valueQueryInterface( INTERFACE_CLI_IDATANODELIST_IID, (VOID**)nodeList.getPP() );
                      SIZE_T listSize = 0;
                      if (!!nodeList && (listSize = nodeList.listSize)>0 )
                         {
                          (*pVariantRes)->setUInt((unsigned)listSize);
                         }
                      else
                         {
                          (*pVariantRes)->setUInt( 0 );
                         }
                     }
                     break;

                case tokenFnName:
                case tokenFnLocalName:
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant_tmp resTmp(*pVariantRes);

                      ::cli::CiVariant var;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var.getPP(), allowCreateNewNodes );

                      ::cli::CiDataNodeList nodeList;
                      var.valueQueryInterface( INTERFACE_CLI_IDATANODELIST_IID, (VOID**)nodeList.getPP() );
                      if (!!nodeList && nodeList.listSize > 0 )
                         {
                          ::cli::CiDataNode firstNode;
                          nodeList.getDataNode(firstNode.getPP(), 0 );
                          resTmp.setString( firstNode.nodeName );
                         }
                      else
                         {
                          resTmp.setString(L"");
                         }
                     }
                     break;

                //case tokenFnId:

                case tokenFnString:
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant_tmp resTmp(*pVariantRes);

                      ::cli::CiVariant var;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var.getPP(), allowCreateNewNodes );

                      ::cli::CiDataNodeList nodeList;
                      var.valueQueryInterface( INTERFACE_CLI_IDATANODELIST_IID, (VOID**)nodeList.getPP() );
                      if (!!nodeList)
                         {
                          ::std::wstring nodesText;
                          nodeList.getText(nodesText);
                          resTmp.setString(nodesText);
                         }
                      else
                         {
                          resTmp.setString(L"");
                         }
                     }
                     break;

                case tokenFnConcat:
                     {
                      ::std::vector< CExpressionTreeItem >::const_iterator subIt = subexpressions.begin();
                      ::std::wstring allText;
                      for(; subIt != subexpressions.end(); ++subIt)
                         {
                          ::cli::CiVariant var;
                          subIt->evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var.getPP(), allowCreateNewNodes );
                          ::std::wstring text;
                          var.getString(text);
                          allText += text;
                         }

                      ::cli::CiVariant_tmp resTmp(*pVariantRes);
                      resTmp.setString(allText);
                     }
                     break;

                case tokenFnStringLength:
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );
                      ::cli::CiVariant var;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var.getPP(), allowCreateNewNodes );
                      ::std::wstring str;
                      var.getString(str);
                      (*pVariantRes)->setUInt((unsigned)str.size());
                     }
                     break;

                case tokenFnContains:
                     {
                      if (subexpressions.size()!=2)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str1;
                      var1.getString(str1);

                      ::cli::CiVariant var2;
                      subexpressions[1].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var2.getPP(), allowCreateNewNodes );
                      ::std::wstring str2;
                      var2.getString(str2);

                      if (str1.find(str2, 0)!=str1.npos)
                         (*pVariantRes)->setBool( TRUE );
                     }
                     break;

                case tokenFnLangId:
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str;
                      var1.getString(str);
                      ::cli::CiVariant_tmp resTmp(*pVariantRes);
                      resTmp.setString( ::cli::impl::normalizeLangIdString(str) );
                     }
                     break;

                case tokenFnPrimaryLang:
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str;
                      var1.getString(str);
                      ::cli::CiVariant_tmp resTmp(*pVariantRes);
                      resTmp.setString( ::cli::impl::getLangIdPrimaryLang(str) );
                     }
                     break;

                case tokenFnListContains:
                     {
                      if (subexpressions.size()<2 && subexpressions.size()>32)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant varList;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, varList.getPP(), allowCreateNewNodes );
                      ::std::wstring strList;  varList.getString(strList);

                      ::cli::CiVariant varWhichContained;
                      subexpressions[1].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, varWhichContained.getPP(), allowCreateNewNodes );
                      ::std::wstring strWhichContained;  varWhichContained.getString(strWhichContained);

                      ::std::wstring strSeps;
                      if (subexpressions.size()>2)
                         {
                          ::cli::CiVariant varSeps;
                          subexpressions[2].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, varSeps.getPP(), allowCreateNewNodes );
                          varSeps.getString(strSeps);
                         }
                      if (strSeps.empty()) strSeps = L" ,;";

                      ::std::vector< std::wstring > vecList;
                      ::cli::util::splitString( strList, vecList, ::cli::util::CIsCharOneOf<wchar_t>(strSeps) );
                      ::cli::util::trim( vecList, ::cli::util::CIsCharOneOf<wchar_t>(std::wstring(L" \t\r\n")) );

                      bool bRes = false;

                      ::std::vector< std::wstring >::const_iterator vit = vecList.begin();
                      for(; vit != vecList.end(); ++vit)
                         {
                          if (vit->empty()) continue;
                          if (*vit==strWhichContained)
                             {
                              bRes = true;
                              break;
                             }
                         }

                      // (*pVariantRes)->setBool( bRes ? TRUE : FALSE);
                      if (bRes) (*pVariantRes)->setBool( TRUE );
                     }
                     break;

                case tokenFnListContainsOneOf:
                     {
                      if (subexpressions.size()<2 && subexpressions.size()>4)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant varList;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, varList.getPP(), allowCreateNewNodes );
                      ::std::wstring strList;  varList.getString(strList);

                      ::cli::CiVariant varWhichContained;
                      subexpressions[1].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, varWhichContained.getPP(), allowCreateNewNodes );
                      ::std::wstring strWhichContained;  varWhichContained.getString(strWhichContained);

                      ::std::wstring strSeps;
                      if (subexpressions.size()>2)
                         {
                          ::cli::CiVariant varSeps;
                          subexpressions[2].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, varSeps.getPP(), allowCreateNewNodes );
                          varSeps.getString(strSeps);
                         }
                      if (strSeps.empty()) strSeps = L" ,;";

                      ::std::wstring strWhichContainedSeps;
                      if (subexpressions.size()>3)
                         {
                          ::cli::CiVariant varWhichContainedSeps;
                          subexpressions[3].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, varWhichContainedSeps.getPP(), allowCreateNewNodes );
                          varWhichContainedSeps.getString(strWhichContainedSeps);
                         }
                      if (strWhichContainedSeps.empty()) strWhichContainedSeps = strSeps;
                      if (strWhichContainedSeps.empty()) strWhichContainedSeps = L" ,;";


                      ::std::vector< std::wstring > vecList;
                      ::cli::util::splitString( strList, vecList, ::cli::util::CIsCharOneOf<wchar_t>(strSeps) );
                      ::cli::util::trim( vecList, ::cli::util::CIsCharOneOf<wchar_t>(std::wstring(L" \t\r\n")) );

                      ::std::set< std::wstring > whichContansSet;
                      ::std::vector< std::wstring >::const_iterator vit = vecList.begin();
                      for(; vit != vecList.end(); ++vit)
                         {
                          if (vit->empty()) continue;
                          whichContansSet.insert(*vit);
                         }

                      ::std::vector< std::wstring > whichContainedVec;
                      ::cli::util::splitString( strWhichContained, whichContainedVec, ::cli::util::CIsCharOneOf<wchar_t>(strWhichContainedSeps) );
                      ::cli::util::trim( whichContainedVec, ::cli::util::CIsCharOneOf<wchar_t>(std::wstring(L" \t\r\n")) );

                      bool bRes = false;

                      vit = whichContainedVec.begin();
                      for(; vit != whichContainedVec.end(); ++vit)
                         {
                          if (vit->empty()) continue;
                          if (whichContansSet.find(*vit)!=whichContansSet.end())
                             {
                              bRes = true;
                             }
                         }

                      //(*pVariantRes)->setBool( bRes ? TRUE : FALSE);
                      if (bRes) (*pVariantRes)->setBool( TRUE );
                     }
                     break;

                case tokenFnLowercase:
                case tokenFnUppercase:
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str;
                      var1.getString(str);

                      ::cli::CiVariant_tmp resTmp(*pVariantRes);

                      if (tokenOpCode.tokenId==tokenFnLowercase)
                         {
                          resTmp.setString( ::marty::util::lowerCase(str, ::marty::util::getCurrentLocale()) );
                         }
                      else
                         {
                          resTmp.setString( ::marty::util::upperCase(str, ::marty::util::getCurrentLocale()) );
                         }
                     }
                     break;

                case tokenFnSubstring:
                     {
                      if (subexpressions.size()<2 || subexpressions.size()>3)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str;
                      var1.getString(str);

                      ::cli::CiVariant var2;
                      subexpressions[1].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var2.getPP(), allowCreateNewNodes );
                      UINT startPos = 0;
                      var2.getUInt(&startPos);

                      if ( startPos > (UINT)str.size() ) startPos = (UINT)str.size();
                      UINT maxNumChars = (UINT)str.size() - startPos;
                      UINT numChars = maxNumChars;

                      if (subexpressions.size()>2)
                         {
                          ::cli::CiVariant var3;
                          subexpressions[2].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var3.getPP(), allowCreateNewNodes );
                          var3.getUInt(&numChars);
                         }

                      if (numChars > maxNumChars) numChars = maxNumChars;

                      ::cli::CiVariant_tmp resTmp(*pVariantRes);
                      if (numChars)
                         {
                          resTmp.setString( ::std::wstring( str, startPos, numChars ) );
                         }
                      else
                         {
                          resTmp.setString( ::std::wstring() );
                         }

                     }
                     break;

                case tokenFnSubstringBefore: // string substring-before(string, string) - ���� ������� ������ ������ � ������, ���������� ������ �� ������� ��������� ������ ������.
                     {
                      if (subexpressions.size()!=2)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str1;
                      var1.getString(str1);

                      ::cli::CiVariant var2;
                      subexpressions[1].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var2.getPP(), allowCreateNewNodes );
                      ::std::wstring str2;
                      var2.getString(str2);

                      ::cli::CiVariant_tmp resTmp(*pVariantRes);
                      ::std::wstring::size_type posFound = str1.find(str2, 0);
                      if (posFound==str1.npos)
                         resTmp.setString( ::std::wstring() );
                      else
                         resTmp.setString( ::std::wstring( str1, 0, posFound ) );
                     }
                     break;

                case tokenFnSubstringAfter:  // string substring-after(string, string)  - ���� ������� ������ ������ � ������, ���������� ������ ����� ������� ��������� ������ ������.
                     {
                      if (subexpressions.size()!=2)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str1;
                      var1.getString(str1);

                      ::cli::CiVariant var2;
                      subexpressions[1].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var2.getPP(), allowCreateNewNodes );
                      ::std::wstring str2;
                      var2.getString(str2);

                      ::cli::CiVariant_tmp resTmp(*pVariantRes);
                      ::std::wstring::size_type posFound = str1.find(str2, 0);
                      if (posFound==str1.npos)
                         resTmp.setString( ::std::wstring() );
                      else
                         resTmp.setString( ::std::wstring( str1, posFound+str2.size(), str1.npos ) );
                     }
                     break;

                case tokenFnStartsWith: // boolean starts-with(string, string)     - ���������� ������ ���� ������ ������ ������ � ������ ������, ����� ���������� ����.
                     {
                      if (subexpressions.size()!=2)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str1;
                      var1.getString(str1);

                      ::cli::CiVariant var2;
                      subexpressions[1].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var2.getPP(), allowCreateNewNodes );
                      ::std::wstring str2;
                      var2.getString(str2);

                      if (::cli::util::startsWith( str1, str2 ))
                         (*pVariantRes)->setBool( TRUE );
                      //else
                      //   (*pVariantRes)->setBool( FALSE );
                     }
                     break;

                case tokenFnEndsWith:  // boolean ends-with(string, string)       - ���������� ������ ���� ������ ������ ������ � ����� ������, ����� ���������� ����.
                     {
                      if (subexpressions.size()!=2)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var1;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var1.getPP(), allowCreateNewNodes );
                      ::std::wstring str1;
                      var1.getString(str1);

                      ::cli::CiVariant var2;
                      subexpressions[1].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var2.getPP(), allowCreateNewNodes );
                      ::std::wstring str2;
                      var2.getString(str2);

                      if (::cli::util::endsWith( str1, str2 ))
                         (*pVariantRes)->setBool( TRUE );
                      //else
                      //   (*pVariantRes)->setBool( FALSE );
                     }
                     break;

                //case tokenFnNormalizeSpace:  // string normalize-space(string?)         - ������� ������ � ��������� �������, � ����� ����������� �������, ������� �� ���������.
                //case tokenFnTranslate     :  // string translate(string, string, string) - �������� ������� ������ ������, ������� ����������� �� ������ ������, �� ��������������� �� ������� �������� �� ������ ������ ������� �� ������� ������. translate(<bar>, <abc>, <ABC>) ������ BAr.

                case tokenFnBoolean: // boolean boolean(object) - �������� ������ � ����������� ����;
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var.getPP(), allowCreateNewNodes );
                      BOOL b;
                      var.getBool(&b);
                      if (b) (*pVariantRes)->setBool( TRUE );
                      //(*pVariantRes)->setBool( b ? TRUE : FALSE);
                     }
                     break;

                case tokenFnTrue:  // boolean true()          - ���������� ������.
                     {
                      (*pVariantRes)->setBool( TRUE );
                     }
                     break;

                case tokenFnFalse: // boolean false()         - ���������� ����.
                     {
                      // (*pVariantRes)->setBool( FALSE ); // allready
                      // (*pVariantRes)->setBool( FALSE );
                     }
                     break;

                case tokenFnNot: // boolean not(boolean)    - ���������, ���������� ������ ���� �������� ���� � ��������.
                     {
                      if (subexpressions.size()!=1)
                         throwFunctionOperandsMiscount( tokenOpCode, (unsigned)subexpressions.size(), refStr, __FILE__, __LINE__ );

                      ::cli::CiVariant var;
                      subexpressions[0].evaluate( curDataNode, nodeIndex, pVarMap, currentNodes, refStr, var.getPP(), allowCreateNewNodes );
                      BOOL b;
                      var.getBool(&b);
                      if (!b) (*pVariantRes)->setBool( TRUE );
                      //(*pVariantRes)->setBool( b!=0 ? TRUE : FALSE);
                      break;
                     }

                default:
                             //cleanVariantVector(evaluatedArgs);
                             throwUnsupportedFunction( tokenOpCode, refStr, __FILE__, __LINE__ );
               }
/*
void throwUnsupportedFunction( const CToken &token, const ::std::wstring &refStr, const char *srcFile, int srcLine )
void throwUnsupportedOperator( const CToken &token, const ::std::wstring &refStr, const char *srcFile, int srcLine )

        tokenFnNode             ,  // node-set node()        - ���������� ��� ����. ��� ���� ������� ����� ���������� ���������� '*', �� � ������� �� ��������� - node() ���������� � ��������� ����.
        tokenFnText             ,  // string text()          - ���������� ����� ��������� �����
        tokenFnValue            ,  // variant value(node)    - ���������� �������� ���� *** �� ����������� ������� ***
        tokenFnCurrent          ,  // node-set current()     - ���������� ��������� �� ������ ��������, ������� �������� �������. ���� �� ������ ��������� ��������� � ���������, �� ������������ �������� ���������� �� ����� ������� �� �������� �������� ����� ������ �������.
        tokenFnPosition         ,  // number position()      - ���������� ������� �������� � ���������. ��������� �������� ������ � ����� <xsl:for-each/>
        tokenFnLast             ,  // number last()          - ���������� ����� ���������� �������� � ���������. ��������� �������� ������ � ����� <xsl:for-each/>
        tokenFnCount            ,  // number count(node-set) - ���������� ���������� ��������� � node-set.
        tokenFnName             ,  // string name(node-set?) - ���������� ������ ��� ������� ���� � ���������.
        tokenFnNamespaceUri     ,  // string namespace-uri(node-set?) - ���������� ������ �� url ������������ ������������ ���.
        tokenFnLocalName        ,  // string local-name(node-set?) - ���������� ��� ������� ���� � ���������, ��� ������������ ���.
        tokenFnId               ,  // node-set id(object)    - ������� ������� � ���������� ���������������

        // ��������� �������
        tokenFnString           ,  // string string(object?) - ���������� ��������� ���������� ��������. �� ���� ���������� ������������ ��������� ��������� ��������� �� ���� ������� ����.
        tokenFnConcat           ,  // string concat(string, string, string*) - ���������� ��� ��� ����� �����
        tokenFnStringLength     ,  // number string-length(string?) - ���������� ����� ������.
        tokenFnContains         ,  // boolean contains(string, string) - ���������� ������, ���� ������ ������ �������� ������, ����� ���������� ����.
        tokenFnSubstring        ,  // string substring(string, number, number?) - ���������� ������ ���������� �� ������ ������� � ���������� ������, � ���� ������ ������ ����� - ���������� ��������.
        tokenFnSubstringBefore  ,  // string substring-before(string, string) - ���� ������� ������ ������ � ������, ���������� ������ �� ������� ��������� ������ ������.
        tokenFnSubstringAfter   ,  // string substring-after(string, string)  - ���� ������� ������ ������ � ������, ���������� ������ ����� ������� ��������� ������ ������.
        tokenFnStartsWith       ,  // boolean starts-with(string, string)     - ���������� ������ ���� ������ ������ ������ � ������ ������, ����� ���������� ����.
        tokenFnEndsWith         ,  // boolean ends-with(string, string)       - ���������� ������ ���� ������ ������ ������ � ����� ������, ����� ���������� ����.
        tokenFnNormalizeSpace   ,  // string normalize-space(string?)         - ������� ������ � ��������� �������, � ����� ����������� �������, ������� �� ���������.
        tokenFnTranslate        ,  // string translate(string, string, string) - �������� ������� ������ ������, ������� ����������� �� ������ ������, �� ��������������� �� ������� �������� �� ������ ������ ������� �� ������� ������. translate(<bar>, <abc>, <ABC>) ������ BAr.

        // ���������� �������
        tokenFnBoolean          ,  // boolean boolean(object) - �������� ������ � ����������� ����;
        tokenFnTrue             ,  // boolean true()          - ���������� ������.
        tokenFnFalse            ,  // boolean false()         - ���������� ����.
        tokenFnNot              ,  // boolean not(boolean)    - ���������, ���������� ������ ���� �������� ���� � ��������.

        // �������� �������
        tokenFnNumber           ,  // number number(object?)  - ��������� ������ � �����.
        tokenFnSum              ,  // number sum(node-set)    - ������ ����� ���������, ������ ��� ��������� ����� ������������ � ������ � �� ���� �������� �����.
        tokenFnFloor            ,  // number floor(number)    - ���������� ���������� ����� �����, �� �������, ��� ��������.
        tokenFnCeiling          ,  // number ceiling(number)  - ���������� ���������� ����� �����, �� �������, ��� ��������.
        tokenFnRound            ,  // number round(number)    - ��������� ����� �� �������������� ��������.

*/
           }
        else if (tokenOpCode.tokenId==tokenNone)
           {
            if (expr.first==expr.second)
               throwUnexpectedToken( tokenOpCode, refStr, __FILE__, __LINE__ );
            if (isTokenAxis(expr.first->tokenId) || expr.first->tokenId==tokenSlash)
               { // this is an xpath expression
                *pVariantRes = cliGetVariant( );
                ::cli::CiDataNodeList newNodeList;
                checkCreateVariantNodeList( *pVariantRes, newNodeList.getPP(), currentNodes.getIfPtr() );
                executeParsed( curDataNode.getIfPtr(), newNodeList, pVarMap, expr.first, expr.second, refStr, allowCreateNewNodes );
               }
            else if (expr.first->tokenId==tokenVarRef)
               {
                token_const_iterator_t tmpIt = expr.first;
                ++tmpIt;
                if (tmpIt->tokenId!=tokenString)
                   throwUnexpectedToken( *tmpIt, refStr, __FILE__, __LINE__ );
                ::std::wstring varName( refStr, tmpIt->tokenPos, tmpIt->tokenLen );
                *pVariantRes = cliGetVariant( );
                if (pVarMap)
                   {
                    ::cli::CiVariantMap_tmp tmpMap(pVarMap);
                    if (tmpMap.queryValueByNameTo(varName, *pVariantRes )!=EC_OK || (*pVariantRes)->getType()==CLI_VARIANTTYPE_VT_EMPTY)
                       {
                        CiVariant_tmp tmpVariant(*pVariantRes);
                        tmpVariant.setString( ::std::wstring() );
                       }
                   }
                else
                   {
                    CiVariant_tmp tmpVariant(*pVariantRes);
                    tmpVariant.setString( ::std::wstring() );
                   }
               }
            else
               {
                throwUnexpectedToken( *expr.first, refStr, __FILE__, __LINE__ );
               }
           }
        else if (tokenOpCode.tokenId==tokenQuotedString)
           {
            ::std::wstring tokenStr( refStr, tokenOpCode.tokenPos, tokenOpCode.tokenLen );
            *pVariantRes = cliGetVariant( );
            ::cli::CiVariant_tmp variantTmp(*pVariantRes);
            variantTmp.setString(tokenStr);
           }
        else if (tokenOpCode.tokenId==tokenNumber)
           {
            ::std::wstring tokenStr( refStr, tokenOpCode.tokenPos, tokenOpCode.tokenLen );
            *pVariantRes = cliGetVariant( );
            ::cli::CiVariant_tmp variantTmp(*pVariantRes);
            variantTmp.setString(tokenStr);
            variantTmp.convertType(CLI_VARIANTTYPE_VT_UINT64);
           }
/*
                                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                                if (first->tokenId!=tokenString)
                                   throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                                {
                                 ::std::wstring varName( refStr, first->tokenPos, first->tokenLen );
                                 ::std::wstring value;
                                 if (pVarMap)
                                    {
                                     ::cli::CiVariantMap_tmp tmp(pVarMap);
                                     ::cli::CiVariant variant;
                                     if (!tmp.queryValueByName(varName, variant.getPP() ) && !!variant)
                                        {
                                         variant.getString(value);
                                        }
                                    }
                                 nodeName += value;
                                }
*/
        else
           {
            throwUnexpectedToken( tokenOpCode, refStr, __FILE__, __LINE__ );
           }

/*
bool isTokenAxis( token_t tt )
        tokenSlash            = 0x0301,
*/
       }

/*
    typedef ::std::vector< CToken >::const_iterator                          token_const_iterator_t;
    typedef ::std::vector< CToken >::iterator                                token_iterator_t;
    typedef ::std::pair< token_const_iterator_t , token_const_iterator_t >   expression_boundaries_t;

    CToken                               tokenOpCode;
    expression_boundaries_t              expr;   // if opCode==tokenNone
    ::std::vector< CExpressionTreeItem > subexpressions;
    bool                                 grouped;
*/

};

/*

1 ( )        �����������
2 [ ]        ����������
3 / � //     �������� � �����
4 div mod *
5 + -
6 < <= > >=  ���������
7 = !=       ���������
8 |          �����������
  not()      ������ "���" (processed as function call)
9 and        ������ "�"
10 or         ������ "���"


bool isSpace( wchar_t ch )
bool isNameFirstChar( wchar_t ch )
bool isNameNextChar( wchar_t ch )
bool isDigit( wchar_t ch )
bool isTokenAxis( token_t tt )
bool isTokenFunction( token_t tt )
bool isTokenOperator( token_t tt )
unsigned operatorLevel( token_t tt)
*/

/*
struct CXPathValue
{
    enum node_type_t
    {
     nodeTypeEmpty    = 0,
     nodeTypeVariant,
     nodeTypeNode,
     nodeTypeNodeList,
     nodeTypeLast
    };

    node_type_t             nodeType;
    ::cli::CiVariant        variant;
    ::cli::CiDataNode       node;
    ::cli::CiDataNodeList   nodeList;

    CXPathValue() : nodeType(nodeTypeEmpty), variant(), node(), nodeList() {}
    CXPathValue( const CXPathValue &v) : nodeType(v.nodeType), variant(v.variant), node(v.node), nodeList(v.nodeList) {}
    CXPathValue &operator=( const CXPathValue &v)
       {
        if (&v==this) return *this;
        nodeType = v.nodeType;
        variant  = v.variant;
        node     = v.node;
        nodeList = v.nodeList;
        return *this;
       }

    void release()
       {
        nodeType = nodeTypeEmpty;
        variant  .release();
        node     .release();
        nodeList .release();
       }

    void assign( const ::cli::CiVariant &v )
       {
        release();
        if (!!v)
           nodeType = nodeTypeVariant;
        variant = v;
       }

    void assign( INTERFACE_CLI_IVARIANT* pVariant )
       {

       }


};
*/




typedef ::std::vector< INTERFACE_CLI_IDATANODE* > node_vector_t;

inline
void nodeListToVector( ::cli::CiDataNodeList &nodeList, node_vector_t &vec )
   {
    SIZE_T listSize = nodeList.listSize;
    vec.reserve(listSize);
    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
       {
        INTERFACE_CLI_IDATANODE *pChildNode = 0;
        nodeList.getDataNode( &pChildNode, nodeIndex );
        if (!pChildNode) continue;
        pChildNode->release();
        vec.push_back( pChildNode );
        /*
        ::cli::CiDataNode childNode;
        nodeList.getDataNode(childNode.getPP(), nodeIndex);
        if (!childNode) continue;
        vec.push_back(childNode.getIfPtr());
        */
       }
   }

inline
node_vector_t nodeListToVector( ::cli::CiDataNodeList &nodeList )
   {
    node_vector_t vec;
    nodeListToVector( nodeList, vec );
    return vec;
   }


inline
void fillNodeListForAxisDescendantOrSelf( INTERFACE_CLI_IDATANODE *pNode
                                        , ::cli::CiDataNodeList &resultNodeList
                                        , const ::std::wstring &refStr
                                        , bool addSelf
                                        )
   {
    if (addSelf)
       resultNodeList.mergeNode(pNode); // add self node

    ::cli::CiDataNodeList childNodes;
    pNode->getChildNodes( childNodes.getPP() );
    SIZE_T listSize = childNodes.listSize;
    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
       {
        ::cli::CiDataNode childNode;
        childNodes.getDataNode(childNode.getPP(), nodeIndex);
        if (!childNode) continue;

        ENUM_CLI_EDATANODETYPE nodeType = childNode.nodeType;
        if (nodeType!=CLI_EDATANODETYPE_NODE) continue;

        fillNodeListForAxisDescendantOrSelf( childNode.getIfPtr(), resultNodeList, refStr, true );
       }
   }


inline
void fillNodeListForAxis( const CToken &tokenAxis
                        , const ::std::wstring &nodeNameFilter
                        , INTERFACE_CLI_IDATANODE *pNode
                        , INTERFACE_CLI_IVARIANTMAP *pVarMap
                        , ::cli::CiDataNodeList &resultNodeList
                        , const ::std::wstring &refStr
                        , bool allowCreateNewNodes
                        )
   {
    switch(tokenAxis.tokenId)
       {
             // nodeNameFilter ignored for ancestor axis
        case tokenAxisAncestorOrSelf:
                resultNodeList.mergeNode(pNode); // add self node
        case tokenAxisAncestor:
                { // add ancestors
                 INTERFACE_CLI_IDATANODE *pParentNode = 0;
                 pNode->getParentNode( &pParentNode );
                 while(pParentNode)
                    {
                     resultNodeList.mergeNode(pParentNode);
                     pNode = pParentNode;
                     pParentNode = 0;
                     pNode->getParentNode( &pParentNode );
                    }
                }
                break;

        case tokenAxisAttribute:
                {
                 ::cli::CiDataNodeList childNodes;
                 pNode->getChildNodes( childNodes.getPP() );
                 SIZE_T listSize = childNodes.listSize;
                 for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                    {
                     ::cli::CiDataNode childNode;
                     childNodes.getDataNode(childNode.getPP(), nodeIndex);
                     if (!childNode) continue;
                     if (!childNode.compareNameTypeChars( nodeNameFilter.c_str(), CLI_EDATANODETYPE_ATTRIBUTE )) continue;
                     resultNodeList.mergeNode(childNode.getIfPtr());
                    }

                 SIZE_T resultCount = 0;
                 resultCount = resultNodeList.listSize;
                 if (resultCount==0 && allowCreateNewNodes && nodeNameFilter!=L"*")
                    {
                     ::cli::CiDataNode_tmp tmpNode(pNode);
                     ::cli::CiVariant newVal("/cli/variant");
                     newVal.setEmpty();
                     ::cli::CiDataNode childNode;
                     tmpNode.createChildDataNode( childNode.getPP(), CLI_EDATANODETYPE_ATTRIBUTE, nodeNameFilter, newVal.getIfPtr() );
                     resultNodeList.mergeNode(childNode.getIfPtr());
                    }
                }
                break;

        case tokenAxisChild:
                {
                 ::cli::CiDataNodeList childNodes;
                 pNode->getChildNodes( childNodes.getPP() );
                 SIZE_T listSize = childNodes.listSize;
                 for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                    {
                     ::cli::CiDataNode childNode;
                     childNodes.getDataNode(childNode.getPP(), nodeIndex);
                     if (!childNode) continue;
                     if (!childNode.compareNameTypeChars( nodeNameFilter.c_str(), CLI_EDATANODETYPE_NODE )) continue;
                     resultNodeList.mergeNode(childNode.getIfPtr());
                    }

                 SIZE_T resultCount = 0;
                 resultCount = resultNodeList.listSize;
                 if (resultCount==0 && allowCreateNewNodes && nodeNameFilter!=L"*")
                    {
                     ::cli::CiDataNode_tmp tmpNode(pNode);
                     ::cli::CiVariant newVal("/cli/variant");
                     newVal.setEmpty();
                     ::cli::CiDataNode childNode;
                     tmpNode.createChildDataNode( childNode.getPP(), CLI_EDATANODETYPE_NODE, nodeNameFilter, newVal.getIfPtr() );
                     resultNodeList.mergeNode(childNode.getIfPtr());
                    }
                }
                break;

        case tokenAxisDescendantOrSelf:
                fillNodeListForAxisDescendantOrSelf( pNode, resultNodeList, refStr, false );
                break;

        case tokenAxisDescendant:
                fillNodeListForAxisDescendantOrSelf( pNode, resultNodeList, refStr, true );
                break;

                /*
                {
                 CToken tokenAxisCopy = tokenAxis;
                 tokenAxisCopy.tokenId = tokenAxisDescendant;
                 ::cli::CiDataNodeList childNodes;
                 pNode->getChildNodes( childNodes.getPP() );
                 SIZE_T listSize = childNodes.listSize;
                 for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
                    {
                     ::cli::CiDataNode childNode;
                     childNodes.getDataNode(childNode.getPP(), nodeIndex);
                     if (!childNode) continue;
                     ENUM_CLI_EDATANODETYPE nodeType = childNode.nodeType;
                     if (nodeType!=CLI_EDATANODETYPE_NODE) continue;
                     resultNodeList.mergeNode(childNode.getIfPtr());
                     fillNodeListForAxis( tokenAxisCopy, nodeNameFilter, childNode.getIfPtr(), resultNodeList, refStr );
                    }
                }
                break;
                */

        case tokenAxisFollowing:
                {
                 throwUnsupportedAxis( tokenAxis, refStr, __FILE__, __LINE__ );
                }
                break;

        case tokenAxisFollowingSibling:
                {
                 ENUM_CLI_EDATANODETYPE nodeType = CLI_EDATANODETYPE_ANY;
                 pNode->nodeTypeGet(&nodeType);
                 if (nodeType!=CLI_EDATANODETYPE_NODE) break;

                 INTERFACE_CLI_IDATANODE *pSiblingNode = 0;
                 pNode->addRef();

                 while(!pNode->getNextSibling(&pSiblingNode) && pSiblingNode)
                    {
                     pNode->release();
                     pSiblingNode->nodeTypeGet(&nodeType);
                     if (nodeType==CLI_EDATANODETYPE_NODE)
                        {
                         resultNodeList.mergeNode(pSiblingNode);
                        }
                     pNode = pSiblingNode;
                     pSiblingNode = 0;
                    }
                 pNode->release();
                }
                break;

        case tokenAxisNamespace:
                {
                 throwUnsupportedAxis( tokenAxis, refStr, __FILE__, __LINE__ );
                }
                break;

        case tokenAxisParent:
                {
                 INTERFACE_CLI_IDATANODE *pParentNode = 0;
                 pNode->getParentNode( &pParentNode );
                 if (pParentNode)
                     resultNodeList.mergeNode(pParentNode);
                }
                break;

        case tokenAxisPreceding:
                {
                 throwUnsupportedAxis( tokenAxis, refStr, __FILE__, __LINE__ );
                }
                break;

        case tokenAxisPrecedingSibling:
                {
                 ENUM_CLI_EDATANODETYPE nodeType = CLI_EDATANODETYPE_ANY;
                 pNode->nodeTypeGet(&nodeType);
                 if (nodeType!=CLI_EDATANODETYPE_NODE) break;

                 INTERFACE_CLI_IDATANODE *pSiblingNode = 0;
                 pNode->addRef();

                 while(!pNode->getPrevSibling(&pSiblingNode) && pSiblingNode)
                    {
                     pNode->release();
                     pSiblingNode->nodeTypeGet(&nodeType);
                     if (nodeType==CLI_EDATANODETYPE_NODE)
                        {
                         resultNodeList.mergeNode(pSiblingNode);
                        }
                     pNode = pSiblingNode;
                     pSiblingNode = 0;
                    }
                 pNode->release();
                }
                break;

        case tokenAxisSelf:
                {
                 if (pNode)
                    resultNodeList.mergeNode(pNode);
                }
                break;
        default:
                {
                 throwUnsupportedAxis( tokenAxis, refStr, __FILE__, __LINE__ );
                }
                break;
       }
   }

inline
::std::vector< CToken >::const_iterator readNameFromTokens( ::std::wstring &nodeName
                  , INTERFACE_CLI_IVARIANTMAP *pVarMap
                  , ::std::vector< CToken >::const_iterator first
                  , ::std::vector< CToken >::const_iterator last
                  , const ::std::wstring &refStr
                  )
   {
    for(;;)
       {
        switch(first->tokenId)
           {
            case tokenVarRef:   ++first;
                                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                                if (first->tokenId!=tokenString)
                                   throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                                {
                                 ::std::wstring varName( refStr, first->tokenPos, first->tokenLen );
                                 ::std::wstring value;
                                 if (pVarMap)
                                    {
                                     ::cli::CiVariantMap_tmp tmp(pVarMap);
                                     ::cli::CiVariant variant;
                                     if (!tmp.queryValueByName(varName, variant.getPP() ) && !!variant)
                                        {
                                         variant.getString(value);
                                        }
                                    }
                                 nodeName += value;
                                }
                                ++first;
                                break;

            case tokenColon:    nodeName.append( 1 , L':' );
                                ++first;
                                break;

            case tokenString:   nodeName.append( refStr, first->tokenPos, first->tokenLen );
                                ++first;
                                break;

            case tokenMultiply: nodeName.append( 1 , L'*' );
                                ++first;
                                break;

            case tokenFnNode:   nodeName.append( 1 , L'*' );
                                ++first;
                                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                                if (first->tokenId!=tokenOpenBrace) throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                                ++first;
                                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                                if (first->tokenId!=tokenCloseBrace) throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
                                ++first;
                                break;
            default:            return first; // unknown token stops current loop
           }
        if (first==last) return first;
       }
    return first;
   }


inline
bool checkPredicate( ::cli::CiDataNode                        &dataNode              // node to check predicate
                   , SIZE_T                                    nodeIndex             // node index in currentNodes, from 0 to currentNodes.size-1
                   , INTERFACE_CLI_IVARIANTMAP                *pVarMap
                   , ::cli::CiDataNodeList                    &currentNodes          // currently selected nodes
                   , ::std::vector< CToken >::const_iterator   first // predicate first
                   , ::std::vector< CToken >::const_iterator   last  // predicate last
                   , const ::std::wstring                     &refStr
                   , bool allowCreateNewNodes
                   )
    {
     ::cli::datadom::xpath::CExpressionTreeItem item;
     item.parseExpression( first, last, refStr );
     return item.evaluate( dataNode, nodeIndex, pVarMap, currentNodes, refStr, allowCreateNewNodes );
    }

inline
::std::vector< CToken >::const_iterator fillNodeListForAxis( INTERFACE_CLI_IDATANODE *pNode
                        , INTERFACE_CLI_IVARIANTMAP *pVarMap
                        , ::std::vector< CToken >::const_iterator first
                        , ::std::vector< CToken >::const_iterator last
                        , ::cli::CiDataNodeList &resultNodeList
                        , const ::std::wstring &refStr
                        , bool allowCreateNewNodes
                        )
   {
    CToken tokenAxis = *first++;
    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
    if (first->tokenId!=tokenDoubleColon) throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );

    ++first;
    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
    ::std::wstring nodeName;
    first = readNameFromTokens( nodeName, pVarMap, first, last, refStr );

    fillNodeListForAxis( tokenAxis, nodeName, pNode, pVarMap, resultNodeList, refStr, allowCreateNewNodes );

    while( first!=last && first->tokenId==tokenOpenSquareBrace)
       {
        int openCount = 1;
        ++first;
        if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
        ::std::vector< CToken >::const_iterator predicateFirst = first;
        //while( first!=last && first->tokenId!=tokenCloseSquareBrace ) ++first;
        while( first!=last && openCount>0)
           {
            if (first->tokenId==tokenOpenSquareBrace)       ++openCount;
            else if (first->tokenId==tokenCloseSquareBrace) --openCount;
            ++first;
           }

        if (first==last && openCount) throwUnexpectedEnd( __FILE__, __LINE__ );
        ::std::vector< CToken >::const_iterator predicateLast = first;
        --predicateLast;


        if (predicateFirst!=predicateLast)
           {
            bool onePredicateFires = false;
            ::cli::CiDataNodeList tmpNodeList;
            resultNodeList.makeCleanNodeListClone( tmpNodeList.getPP() );

            SIZE_T listSize = resultNodeList.listSize;
            //vec.reserve(listSize);
            SIZE_T nodeIndex = 0;
            for(; nodeIndex!=listSize; ++nodeIndex)
               {
                ::cli::CiDataNode childNode;
                resultNodeList.getDataNode(childNode.getPP(), nodeIndex);
                if (!childNode) continue;
                if (checkPredicate( childNode, nodeIndex, pVarMap, resultNodeList, predicateFirst, predicateLast, refStr, allowCreateNewNodes ))
                   {
                    tmpNodeList.mergeNode(childNode.getIfPtr());
                    onePredicateFires = true;
                   }
               }

            if (!onePredicateFires && allowCreateNewNodes && (tokenAxis.tokenId==tokenAxisChild || tokenAxis.tokenId==tokenAxisAttribute) && nodeName!=L"*")
               { // we need to add child node
                ::cli::CiDataNode_tmp tmpNode(pNode);
                ::cli::CiVariant newVal("/cli/variant");
                newVal.setEmpty();

                ::cli::CiDataNode newNode;
                tmpNode.createChildDataNode( newNode.getPP(), tokenAxis.tokenId==tokenAxisChild ? CLI_EDATANODETYPE_NODE : CLI_EDATANODETYPE_ATTRIBUTE, nodeName, newVal.getIfPtr() );
                resultNodeList.pushBackDataNode( newNode.getIfPtr() );
                if (checkPredicate( newNode, nodeIndex, pVarMap, resultNodeList, predicateFirst, predicateLast, refStr, allowCreateNewNodes ))
                   tmpNodeList.mergeNode(newNode.getIfPtr());
               }

            resultNodeList.clearList();
            resultNodeList.mergeNodeList(tmpNodeList.getIfPtr());
           }

        //++first;
        // perform predicate on nodeset
       }
     return first;
   }


/*
::std::vector< CToken >::const_iterator executeParsedImplHelper( INTERFACE_CLI_IDATANODE *pNode
                  , ::cli::CiDataNodeList &resultNodeList
                  , ::std::vector< CToken >::const_iterator first
                  , ::std::vector< CToken >::const_iterator last
                  , const ::std::wstring &refStr
                  , SIZE_T levelNo = 0
                  );
*/
//::std::vector< CToken >::const_iterator
inline
::std::vector< CToken >::const_iterator executeParsedImplHelper( ::cli::CiDataNodeList &_inputNodeList
                  , ::cli::CiDataNodeList &resultNodeList
                  , INTERFACE_CLI_IVARIANTMAP *pVarMap
                  , ::std::vector< CToken >::const_iterator first
                  , ::std::vector< CToken >::const_iterator last
                  , const ::std::wstring &refStr
                  , bool allowCreateNewNodes
                  //, SIZE_T levelNo = 0
                  )
   {
    ::cli::CiDataNodeList inputNodeList;
    _inputNodeList.cloneNodeList( inputNodeList.getPP() );

    ::cli::CiDataNodeList tmpOutNodeList;
    inputNodeList.makeCleanNodeListClone( tmpOutNodeList.getPP() );

    while(first!=last)
       {
        #if defined(DEBUG) || defined(_DEBUG)
        ::cli::format::cli_log::message(L"  DDXPath::executeParsedImplHelper: first: %1 (%2), pos: %3", ::cli::format::arg( first->toTypeString() ) % first->toString(refStr) % (UINT)first->tokenPos);
        #endif

        if (isTokenAxis(first->tokenId) || first->tokenId==tokenVarRef)
           {
            #if defined(DEBUG) || defined(_DEBUG)
            ::cli::format::cli_log::message(L"  DDXPath::executeParsedImplHelper CP01");
            #endif

            ::std::vector< CToken >::const_iterator _first = first;

            //node_vector_t inputNodeVector = nodeListToVector( inputNodeList );
            //node_vector_t::const_iterator invIt = inputNodeVector.begin();
            //for(; invIt!=inputNodeVector.end(); ++invIt)
            //   {
            //    first = fillNodeListForAxis( *invIt, pVarMap, _first, last, tmpOutNodeList, refStr, allowCreateNewNodes );
            //   }

            SIZE_T listSize = inputNodeList.listSize;

            #if defined(DEBUG) || defined(_DEBUG)
            ::cli::format::cli_log::message(L"     listSize: %1", ::cli::format::arg( (UINT)listSize) );
            #endif


            for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
               {
                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"  DDXPath::executeParsedImplHelper CP02");
                #endif

                ::cli::CiDataNode childNode;
                inputNodeList.getDataNode(childNode.getPP(), nodeIndex);
                if (!childNode) continue;
                first = fillNodeListForAxis( childNode.getIfPtr(), pVarMap, _first, last, tmpOutNodeList, refStr, allowCreateNewNodes );

                #if defined(DEBUG) || defined(_DEBUG)
                if (first!=last)
                   ::cli::format::cli_log::message(L"     assigned first(1): first: %1 (%2), pos: %3", ::cli::format::arg( first->toTypeString() ) % first->toString(refStr) % (UINT)first->tokenPos);
                else
                   ::cli::format::cli_log::message(L"     assigned first(1): first==last");
                #endif

               }

            if (!listSize)
               { // for empty node lists perform actions as in fillNodeListForAxis prolog
                #if 0

                void fillNodeListForAxis( const CToken &tokenAxis
                                        , const ::std::wstring &nodeNameFilter
                                        , INTERFACE_CLI_IDATANODE *pNode
                                        , INTERFACE_CLI_IVARIANTMAP *pVarMap
                                        , ::cli::CiDataNodeList &resultNodeList
                                        , const ::std::wstring &refStr
                                        , bool allowCreateNewNodes
                                        )

                ::std::vector< CToken >::const_iterator fillNodeListForAxis( INTERFACE_CLI_IDATANODE *pNode
                                        , INTERFACE_CLI_IVARIANTMAP *pVarMap
                                        , ::std::vector< CToken >::const_iterator first
                                        , ::std::vector< CToken >::const_iterator last
                                        , ::cli::CiDataNodeList &resultNodeList
                                        , const ::std::wstring &refStr
                                        , bool allowCreateNewNodes
                                        )

                    CToken tokenAxis = *first++;
                    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                    if (first->tokenId!=tokenDoubleColon) throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );

                    ++first;
                    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                    ::std::wstring nodeName;
                    first = readNameFromTokens( nodeName, pVarMap, first, last, refStr );

                    fillNodeListForAxis( tokenAxis, nodeName, pNode, pVarMap, resultNodeList, refStr, allowCreateNewNodes );

                    while( first!=last && first->tokenId==tokenOpenSquareBrace)
                       {
                        int openCount = 1;
                        ++first;
                        if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                        ::std::vector< CToken >::const_iterator predicateFirst = first;
                        //while( first!=last && first->tokenId!=tokenCloseSquareBrace ) ++first;
                        while( first!=last && openCount>0)
                           {
                            if (first->tokenId==tokenOpenSquareBrace)       ++openCount;
                            else if (first->tokenId==tokenCloseSquareBrace) --openCount;
                            ++first;
                           }
                #endif


                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"  DDXPath::executeParsedImplHelper CP03");
                #endif

                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );

                //CToken tokenAxis = *first++;
                ++first;
                #if defined(DEBUG) || defined(_DEBUG)
                if (first!=last)
                   ::cli::format::cli_log::message(L"     incremented first(1): first: %1 (%2), pos: %3", ::cli::format::arg( first->toTypeString() ) % first->toString(refStr) % (UINT)first->tokenPos);
                else
                   ::cli::format::cli_log::message(L"     incremented first(1): first==last");
                #endif

                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                if (first->tokenId!=tokenDoubleColon) throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );

                ++first;
                #if defined(DEBUG) || defined(_DEBUG)
                if (first!=last)
                   ::cli::format::cli_log::message(L"     incremented first(2): first: %1 (%2), pos: %3", ::cli::format::arg( first->toTypeString() ) % first->toString(refStr) % (UINT)first->tokenPos);
                else
                   ::cli::format::cli_log::message(L"     incremented first(2): first==last");
                #endif

                if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                ::std::wstring nodeName;
                first = readNameFromTokens( nodeName, pVarMap, first, last, refStr );

                #if defined(DEBUG) || defined(_DEBUG)
                if (first!=last)
                   ::cli::format::cli_log::message(L"     assigned first(2): first: %1 (%2), pos: %3", ::cli::format::arg( first->toTypeString() ) % first->toString(refStr) % (UINT)first->tokenPos);
                else
                   ::cli::format::cli_log::message(L"     assigned first(2): first==last");
                #endif

                while( first!=last && first->tokenId==tokenOpenSquareBrace)
                   {
                    int openCount = 1;
                    ++first;
                    if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
                    while( first!=last && openCount>0)
                       {
                        if (first->tokenId==tokenOpenSquareBrace)       ++openCount;
                        else if (first->tokenId==tokenCloseSquareBrace) --openCount;
                        ++first;
                       }
                   }
               }

            //first = _first;
            if (first==last)
               {
                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"  DDXPath::executeParsedImplHelper CP04");
                #endif
                resultNodeList.clearList();
                resultNodeList.appendNodeList( tmpOutNodeList.getIfPtr() );
                return first;
               }
            if (first->tokenId==tokenCloseBrace)
               {
                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"  DDXPath::executeParsedImplHelper CP05");
                #endif
                resultNodeList.clearList();
                resultNodeList.appendNodeList( tmpOutNodeList.getIfPtr() );
                return first; // end of grouped with ()
               }
            if (first->tokenId==tokenSlash)
               {
                #if defined(DEBUG) || defined(_DEBUG)
                ::cli::format::cli_log::message(L"  DDXPath::executeParsedImplHelper CP06");
                #endif
                ++first;
                #if defined(DEBUG) || defined(_DEBUG)
                if (first!=last)
                   ::cli::format::cli_log::message(L"     incremented first(2): first: %1 (%2), pos: %3", ::cli::format::arg( first->toTypeString() ) % first->toString(refStr) % (UINT)first->tokenPos);
                else
                   ::cli::format::cli_log::message(L"     incremented first(2): first==last");
                #endif
               }

            inputNodeList = tmpOutNodeList;
            tmpOutNodeList.release();
            inputNodeList.makeCleanNodeListClone( tmpOutNodeList.getPP() );
           }
        else if (first->tokenId==tokenUnion)
           {
            //++first;
            //return executeParsed( pNode, resultNodeList, first, last, refStr, levelNo );
            throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
           }
        else
           {
            //if (!isTokenAxis(first->tokenId))
            throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
           }

       }

    resultNodeList.clearList();
    resultNodeList.appendNodeList( tmpOutNodeList.getIfPtr() );
    return first; // end of grouped with ()

    /*
    SIZE_T listSize = inputNodeList.listSize;
    ::std::vector< CToken >::const_iterator ret = first;
    for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
       {
        ::cli::CiDataNode childNode;
        inputNodeList.getDataNode(childNode.getPP(), nodeIndex);
        if (!childNode) continue;
        ret = executeParsedImplHelper( childNode.getIfPtr(), resultNodeList, first, last, refStr, levelNo+1 );
       }
    return ret;
    */
   }

/*
inline
::std::vector< CToken >::const_iterator executeParsedImplHelper( INTERFACE_CLI_IDATANODE *pNode
                  , ::cli::CiDataNodeList &resultNodeList
                  , ::std::vector< CToken >::const_iterator first
                  , ::std::vector< CToken >::const_iterator last
                  , const ::std::wstring &refStr
                  , SIZE_T levelNo // = 0
                  )
   {
    if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }


    //::cli::CiDataNodeList &resultNodeList
    //::cli::CiDataNodeList resultNodeListNextLevel;
    //resultNodeList.makeCleanNodeListClone( resultNodeListNextLevel.getPP() );

    while(first!=last)
       {
        if (isTokenAxis(first->tokenId))
           {
            ::cli::CiDataNodeList tmpInputNodeList;
            resultNodeList.makeCleanNodeListClone( tmpInputNodeList.getPP() );
            first = fillNodeListForAxis( pNode, first, last, tmpInputNodeList, refStr );
            executeParsedImplHelper( tmpInputNodeList, resultNodeList, first, last, refStr, levelNo+1 );

            if (first==last) return first;

            if (first->tokenId==tokenCloseBrace) return first; // end of grouped with ()
            //if (first->tokenId!=tokenSlash) throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
            if (first->tokenId==tokenSlash)
               ++first;
           }
        else if (first->tokenId==tokenUnion)
           {
            //++first;
            //return executeParsed( pNode, resultNodeList, first, last, refStr, levelNo );
            throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
           }
        else
           {
            //if (!isTokenAxis(first->tokenId))
            throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
           }
       }
   }
*/


inline
::std::vector< CToken >::const_iterator executeParsedUnionItem( INTERFACE_CLI_IDATANODE *pNode
                  , ::cli::CiDataNodeList &resultNodeList
                  , INTERFACE_CLI_IVARIANTMAP *pVarMap
                  , ::std::vector< CToken >::const_iterator first
                  , ::std::vector< CToken >::const_iterator last
                  , const ::std::wstring &refStr
                  , bool allowCreateNewNodes
                  )
   {
    if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }
    if (first==last) throw ::cli::CException( false, EC_XPATH_UNEXPECTED_END_OF_EXPRESSION, __FILE__, __LINE__, 0 );

    #if defined(DEBUG) || defined(_DEBUG)
    ::cli::format::cli_log::message(L"DDXPath::executeParsedUnionItem: first: %1 (%2), pos: %3", ::cli::format::arg( first->toTypeString() ) % first->toString(refStr) % (UINT)first->tokenPos);
    #endif

    ::cli::CiDataNodeList inputNodeList;
    resultNodeList.makeCleanNodeListClone( inputNodeList.getPP() );

    if (first->tokenId==tokenSlash)
       {
        INTERFACE_CLI_IDATANODE *pRootNode = 0;
        pNode->getRootNode( &pRootNode );
        if (pRootNode) inputNodeList.mergeNode(pRootNode); //resultNodeList.pushBackDataNode( pRootNode );
        ++first;
       }
    else
       {
        inputNodeList.mergeNode(pNode);
       }

    // parse node list here
    ::std::vector< CToken >::const_iterator res =
    executeParsedImplHelper( inputNodeList, resultNodeList, pVarMap
                  , first, last, refStr, allowCreateNewNodes
                  );
    return res;
   }

inline
::std::vector< CToken >::const_iterator executeParsed( INTERFACE_CLI_IDATANODE *pNode
                  , ::cli::CiDataNodeList &resultNodeList
                  , INTERFACE_CLI_IVARIANTMAP *pVarMap
                  , ::std::vector< CToken >::const_iterator first
                  , ::std::vector< CToken >::const_iterator last
                  , const ::std::wstring &refStr
                  , bool allowCreateNewNodes
                  )
   {
    #if defined(DEBUG) || defined(_DEBUG)
    ::cli::format::cli_log::message(L"DDXPath::executeParsed:          first: %1 (%2), pos: %3", ::cli::format::arg( first->toTypeString() ) % first->toString(refStr) % (UINT)first->tokenPos );
    #endif
    //toTypeString

    ::cli::CiDataNodeList tmpResultNodeList;
    resultNodeList.makeCleanNodeListClone( tmpResultNodeList.getPP() );
    ::std::vector< CToken >::const_iterator tmpEnd = first;
    while(tmpEnd!=last)
       { // lookup for temporary end
        int openCount = 0;
        //while(tmpEnd!=last && tmpEnd->tokenId!=tokenUnion) ++tmpEnd;
        while(tmpEnd!=last)
           {
            if (!openCount && tmpEnd->tokenId==tokenUnion) break;
            if (tmpEnd->tokenId==tokenOpenSquareBrace)       ++openCount;
            else if (tmpEnd->tokenId==tokenCloseSquareBrace) --openCount;
            ++tmpEnd;
           }

        executeParsedUnionItem(pNode, tmpResultNodeList, pVarMap, first, tmpEnd, refStr, allowCreateNewNodes );
        resultNodeList.mergeNodeList( tmpResultNodeList.getIfPtr() );
        tmpResultNodeList.clearList();
        if (tmpEnd!=last) ++tmpEnd;
        first = tmpEnd;
       }
    return first;
   }


inline
void executeQuery( INTERFACE_CLI_IDATANODE *pNode
                  , ::cli::CiDataNodeList &resultNodeList
                  , const ::std::wstring &xpathExpr
                  , INTERFACE_CLI_IVARIANTMAP *pVarMap
                  , bool allowCreateNewNodes
                  )
   {
    SIZE_T errPos, errLine, errLinePos;
    ::std::vector< CToken > tokens;

    if (!baseTokenizeXPathExpression( xpathExpr, tokens, &errPos, &errLine, &errLinePos ))
       throw ::cli::CException( false, EC_XPATH_INVALID_EXPRESSION, __FILE__, __LINE__, ::cli::format::arg( (UINT)errPos ) % (UINT)errLine % (UINT)errLinePos );

    if (!normalizeXPathExpression( tokens, xpathExpr, &errPos, &errLine, &errLinePos ))
       throw ::cli::CException( false, EC_XPATH_INVALID_EXPRESSION, __FILE__, __LINE__, ::cli::format::arg( (UINT)errPos ) % (UINT)errLine % (UINT)errLinePos );

    ::std::vector< CToken >::const_iterator first = tokens.begin();

    #if defined(DEBUG) || defined(_DEBUG)
    ::cli::format::cli_log::message(L"DDXPath::executeQuery: tokens dump" );
    SIZE_T i = 0;
    for(; first != tokens.end(); ++first, ++i)
       ::cli::format::cli_log::message(L"    %1!02d!: %2 (%3), pos: %4", ::cli::format::arg( (UINT)i ) % first->toTypeString() % first->toString(xpathExpr) % (UINT)first->tokenPos);
    first = tokens.begin();
    #endif

    executeParsed( pNode, resultNodeList, pVarMap, first, tokens.end(), xpathExpr, allowCreateNewNodes );
   }


/*
inline
::std::vector< CToken >::const_iterator executeParsed( INTERFACE_CLI_IDATANODE *pNode
                  , ::cli::CiDataNodeList &resultNodeList
                  , ::std::vector< CToken >::const_iterator first
                  , ::std::vector< CToken >::const_iterator last
                  , const ::std::wstring &refStr
                  , SIZE_T levelNo = 0
                  )
   {
    if (!pNode) { throw ::cli::CException( false, EC_INVALID_PARAM, __FILE__, __LINE__, ::cli::format::arg( 1) % L"pNode" );  }

    if (first==last) throw ::cli::CException( false, EC_XPATH_UNEXPECTED_END_OF_EXPRESSION, __FILE__, __LINE__, 0 );

      {
       ::cli::CiDataNode_tmp tmpNode(pNode);
       ::std::wstring nodeName = tmpNode.nodeName;
       ::cli::format::cli_log::message(L"executeParsed %1 for node '%2'", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % nodeName );
      }

    //::cli::CiDataNodeList node(pNode);

    if (first->tokenId==tokenSlash)
       {
        ::cli::format::cli_log::message(L"executeParsed: %1 tokenSlash, put root node to list", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) );

        INTERFACE_CLI_IDATANODE *pRootNode = 0;
        pNode->getRootNode( &pRootNode );
        if (pRootNode) resultNodeList.mergeNode(pRootNode); //resultNodeList.pushBackDataNode( pRootNode );
        ++first;
       }
    else if (isTokenAxis(first->tokenId))
       {
        ::cli::format::cli_log::message(L"executeParsed: %1 tokenAxis* - %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % first->toString(refStr) );
        CToken tokenAxis = *first; // ->tokenId;

        ++first;
        if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
        if (first->tokenId!=tokenDoubleColon) throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );

        ++first;
        if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
        ::std::wstring nodeName;
        first = readNameFromTokens( nodeName, first, last, refStr );


        ::cli::format::cli_log::message(L"executeParsed: %1 tokenAxis*, node name filter - %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % nodeName);
        SIZE_T listSize = resultNodeList.listSize;
        ::cli::format::cli_log::message(L"executeParsed: %1 tokenAxis* - num child before expand axis - %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % (UINT)listSize );

        fillNodeListForAxis( tokenAxis, nodeName, pNode, resultNodeList, refStr );

        listSize = resultNodeList.listSize;
        ::cli::format::cli_log::message(L"executeParsed: %1 tokenAxis* - num child after expand axis - %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % (UINT)listSize );

        //UNDONE: need to parse predicates
        if (first==last) return first;

        while( first!=last && first->tokenId==tokenOpenSquareBrace)
           {
            int openCount = 1;
            ++first;
            if (first==last) throwUnexpectedEnd( __FILE__, __LINE__ );
            ::std::vector< CToken >::const_iterator predicateFirst = first;
            //while( first!=last && first->tokenId!=tokenCloseSquareBrace ) ++first;
            while( first!=last && openCount>0)
               {
                if (first->tokenId==tokenOpenSquareBrace)       ++openCount;
                else if (first->tokenId==tokenCloseSquareBrace) --openCount;
                ++first;
               }

            if (first==last && openCount) throwUnexpectedEnd( __FILE__, __LINE__ );
            ::std::vector< CToken >::const_iterator predicateLast = first;
            --predicateLast;
            //++first;
            // perform predicate on nodeset
           }
        if (first==last) return first;
        if (first->tokenId==tokenCloseBrace) return first; // end of grouped with ()
        if (first->tokenId!=tokenSlash) throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
        ++first;

       }
    else if (first->tokenId==tokenUnion)
       {
        ++first;
        return executeParsed( pNode, resultNodeList, first, last, refStr, levelNo );
       }
    else
       {
        //if (!isTokenAxis(first->tokenId))
        throwUnexpectedToken( *first, refStr, __FILE__, __LINE__ );
       }

    if (first!=last)
       {
        ::cli::format::cli_log::message(L"executeParsed: %1 next level loop, cur token: %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % first->toString(refStr) );
        ::cli::CiDataNodeList resultNodeListNextLevel;
        resultNodeList.makeCleanNodeListClone( resultNodeListNextLevel.getPP() );

        SIZE_T listSize = resultNodeList.listSize;
        for(SIZE_T nodeIndex = 0; nodeIndex!=listSize; ++nodeIndex)
           {
            ::cli::CiDataNode childNode;
            resultNodeList.getDataNode(childNode.getPP(), nodeIndex);
            if (!childNode) continue;
            ::std::wstring nodeName = childNode.nodeName;
            ::cli::format::cli_log::message(L"executeParsed: %1 next level loop, node name - %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % nodeName );
            SIZE_T listSize = resultNodeListNextLevel.listSize;
            ::cli::format::cli_log::message(L"executeParsed: %1 next level loop - num child before - %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % (UINT)listSize );
            executeParsed( childNode.getIfPtr(), resultNodeListNextLevel, first, last, refStr, levelNo+1 );
            listSize = resultNodeListNextLevel.listSize;
            ::cli::format::cli_log::message(L"executeParsed: %1 next level loop - num child before - %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % (UINT)listSize );
           }

        resultNodeList = resultNodeListNextLevel;
        //SIZE_T
        listSize = resultNodeList.listSize;
        ::cli::format::cli_log::message(L"executeParsed: %1 next level loop - num child in resultNodeList - %2", ::cli::format::arg(::std::wstring(4*levelNo, L' ')) % (UINT)listSize );
       }
    return first;
   }


*/

/*
inline
bool isTokenAxis( token_t tt )
   {
    if (tt>=tokenAxisAncestor && tt<=tokenAxisSelf ) return true;
    return false;
   }
        tokenAxisAncestor           ,  // ���������� ��������� �������
        tokenAxisAncestorOrSelf     ,  // ���������� ��������� ������� � ������� �������
        tokenAxisAttribute          ,  // ���������� ��������� ��������� �������� ��������
        tokenAxisChild              ,  // ���������� ��������� �������� �� ���� ������� ����
        tokenAxisDescendant         ,  // ���������� ������ ��������� ��������
        tokenAxisDescendantOrSelf   ,  // ���������� ������ ��������� �������� � ������� �������
        tokenAxisFollowing          ,  // ���������� �������������� ���������, ���� �������� ��������
        tokenAxisFollowingSibling   ,  // ���������� ��������� ��������� �� ��� �� ������, ��������� �� �������
        tokenAxisNamespace          ,  // ���������� ��������� ������� ������������ ��� (�� ���� ������������ ������� xmlns)
        tokenAxisParent             ,  // ���������� ������ �� ���� ������� �����
        tokenAxisPreceding          ,  // ���������� ��������� ������������ ��������� �������� ��������� �������
        tokenAxisPrecedingSibling   ,  // ���������� ��������� ��������� �� ��� �� ������, �������������� ��������
        tokenAxisSelf               ,  // ���������� ������� �������
*/



}; // namespace xpath
}; // namespace datadom
}; // namespace cli

#endif /* SRC_CORE_DDXPATH_H */

