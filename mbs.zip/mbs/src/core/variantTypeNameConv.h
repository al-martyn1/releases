
#ifndef SRC_CORE_VARIANTTYPENAMECONV_H
#define SRC_CORE_VARIANTTYPENAMECONV_H

/* add this lines to your src
#ifndef SRC_CORE_VARIANTTYPENAMECONV_H
    #include "variantTypeNameConv.h"
#endif
*/

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_FMTUTIL_H
    //#error "include fmtutil"
    #include <cli/fmtutil.h>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif

#ifndef CLI_CLI2_H
    #include <cli/cli2.h>
#endif

#ifndef CLI_PODTYPES_H
    #include <cli/podTypes.h>
#endif

#ifndef CLI_IVARIANT_H
    #include <cli/ivariant.h>
#endif


struct CVariantTypeNameConverter
{
    typedef ::std::pair< ENUM_CLI_VARIANTTYPE, ::std::wstring > type_name_pair;
    typedef ::std::pair< ::std::wstring, ENUM_CLI_VARIANTTYPE > name_type_pair;
    typedef ::cli::util::CAutoSortVector< type_name_pair, ::cli::util::pair_first_less< type_name_pair > >  type_name_vector;
    typedef ::cli::util::CAutoSortVector< name_type_pair, ::cli::util::pair_first_less< name_type_pair > >  name_type_vector;
    static type_name_vector typeToName;
    static name_type_vector nameToType;

    CVariantTypeNameConverter()
       {
        using namespace ::cli::VariantType;

        // http://ru.wikipedia.org/wiki/Web-%D1%86%D0%B2%D0%B5%D1%82%D0%B0
        if (typeToName.empty())
           {
            typeToName.push_back( ::std::make_pair( vt_empty   , L"empty") );
            typeToName.push_back( ::std::make_pair( vt_none    , L"none") );
            typeToName.push_back( ::std::make_pair( vt_char    , L"char") );
            typeToName.push_back( ::std::make_pair( vt_wchar   , L"wchar") );
            typeToName.push_back( ::std::make_pair( vt_short   , L"vt_short") );
            typeToName.push_back( ::std::make_pair( vt_ushort  , L"ushort") );
            typeToName.push_back( ::std::make_pair( vt_int     , L"int") );
            typeToName.push_back( ::std::make_pair( vt_uint    , L"uint") );
            typeToName.push_back( ::std::make_pair( vt_int64   , L"int64") );
            typeToName.push_back( ::std::make_pair( vt_uint64  , L"uint64") );
            typeToName.push_back( ::std::make_pair( vt_int_ptr , L"int_ptr") );
            typeToName.push_back( ::std::make_pair( vt_uint_ptr, L"uint_ptr") );
            typeToName.push_back( ::std::make_pair( vt_float   , L"float") );
            typeToName.push_back( ::std::make_pair( vt_double  , L"double") );
            //typeToName.push_back( ::std::make_pair( vt_pstring , L"pstring") );
            typeToName.push_back( ::std::make_pair( vt_pstring , L"string") );
            typeToName.push_back( ::std::make_pair( vt_ptr     , L"ptr") );
            typeToName.push_back( ::std::make_pair( vt_dump    , L"dump") );
            typeToName.push_back( ::std::make_pair( vt_datetime, L"datetime") );
            typeToName.push_back( ::std::make_pair( vt_bool    , L"bool") );
            typeToName.push_back( ::std::make_pair( vt_colorref, L"colorref") );
            typeToName.push_back( ::std::make_pair( vt_iUnknown, L"iUnknown") );
            typeToName.push_back( ::std::make_pair( vt_bigint  , L"bigint") );
            typeToName.push_back( ::std::make_pair( vt_rational, L"rational") );
           }
        if (nameToType.empty())
           {
            type_name_vector::const_iterator cit = typeToName.begin();
            for(; cit != typeToName.end(); ++cit)
               {
                nameToType.push_back( ::std::make_pair(cit->second, cit->first) );
               }
           }
       }

    ENUM_CLI_VARIANTTYPE convertFromString( const ::std::wstring &_str )
       {
        ::std::wstring str = _str;
        ::cli::fmtutil::toLowerCase(str);
        name_type_vector::const_iterator it = nameToType.find( ::std::make_pair( str, (ENUM_CLI_VARIANTTYPE)0 ) );
        if (it != nameToType.end()) return it->second;
        return CLI_VARIANTTYPE_VT_PSTRING;
       }

    ::std::wstring convertToString( ENUM_CLI_VARIANTTYPE vt, bool bUpperName = false )
       {
        ::cli::util::CAutoSortVector< ::std::pair< ENUM_CLI_VARIANTTYPE, ::std::wstring > >::const_iterator it = typeToName.find( ::std::make_pair(vt,L"") );
        if (it==typeToName.end()) return ::std::wstring(L"none");
        ::std::wstring strRes = it->second;
        if (bUpperName) ::cli::fmtutil::toUpperCase(strRes);
        else ::cli::fmtutil::toLowerCase(strRes);
        return strRes;
       }

}; // struct CColorrefConverter


ENUM_CLI_VARIANTTYPE convertVariantTypeNameFromString( const ::std::wstring &_str );
::std::wstring convertVariantTypeNameToString( ENUM_CLI_VARIANTTYPE clr, bool bUpper = true );

#endif /* SRC_CORE_VARIANTTYPENAMECONV_H */

