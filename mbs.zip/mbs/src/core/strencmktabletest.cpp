#include "strenctbl.h"

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#if !defined(_IOSTREAM_) && !defined(_STLP_IOSTREAM) && !defined(__STD_IOSTREAM__) && !defined(_CPP_IOSTREAM) && !defined(_GLIBCXX_IOSTREAM)
    #include <iostream>
#endif



template<class ForwardIterator, class Type>
ForwardIterator binary_find( ForwardIterator _First
                           , ForwardIterator _Last
                           , const Type& _Val
                           )
   {
    _First = std::lower_bound(_First, _Last, _Val);
    return _First == _Last ? _Last : (       _Val < *_First   ? _Last : _First);
   }

//-----------------------------------------------------------------------------
template<class ForwardIterator, class Type, class BinaryPredicate>
ForwardIterator binary_find( ForwardIterator _First
                           , ForwardIterator _Last
                           , const Type& _Val
                           , BinaryPredicate _Comp
                           )
   {
    _First = std::lower_bound(_First, _Last, _Val, _Comp);
    return _First == _Last ? _Last : ( _Comp(_Val , *_First)  ? _Last : _First);
   }


bool operator<(const CEncNameToIndex &e1, const CEncNameToIndex &e2)
   {
    return strcmp(e1.encName, e2.encName)<0 ? true : false;
   }

bool operator<(const CEncodingInfo &e1, const CEncodingInfo &e2)
   {
    return e1.encCode < e2.encCode;
   }

const CEncNameToIndex* findEncodingIndex( const char *encName )
{
    CEncNameToIndex nti; nti.encName = (char *)encName;
    const CEncNameToIndex* pRes = binary_find( &encNameToIndex[0], &encNameToIndex[0] + (sizeof(encNameToIndex)/sizeof(encNameToIndex[0])) , nti );
    if (pRes== (&encNameToIndex[0] + (sizeof(encNameToIndex)/sizeof(encNameToIndex[0])))) return 0; // end
    return pRes;
}

const CEncodingInfo* findEncodingInfo( const char *encName )
{
    const CEncNameToIndex * pNtiRes = findEncodingIndex(encName);
    if (!pNtiRes) return 0;
    return &encInfo[pNtiRes->encIdx];
}

const CEncodingInfo* findEncodingInfo( unsigned code )
{
    CEncodingInfo ei; ei.encCode = code;
    const CEncodingInfo* pRes = binary_find( &encInfo[0], &encInfo[0] + (sizeof(encInfo)/sizeof(encInfo[0])) , ei );
    if (pRes== (&encInfo[0] + (sizeof(encInfo)/sizeof(encInfo[0]))) ) return 0;
    return pRes;
}

/*
struct CEncodingInfo{
  unsigned encCode;
  unsigned encNameIdx;
  char *encInfoString;
};

struct CEncNameToIndex{
  char *encName;
  unsigned encIdx;
};
*/

unsigned testFindEncoding( const char *encName, unsigned requiredRes = 1)
{
    const CEncodingInfo* pei = findEncodingInfo( encName );
    unsigned res = pei ? 1 : 0;
    if (!!res==!!requiredRes) std::cout<<"+";
    else                      std::cout<<"-";
    if (!pei)
       {
        std::cout<<" \""<<encName<<"\" - not found\n";
       }
    else 
       {
        std::cout<<" \""<<encName<<"\" - code: "<<pei->encCode<<", canonical name: "<<encNameToIndex[pei->encNameIdx].encName<<", info: "<<pei->encInfoString<<"\n";
       }
    if (!!res==!!requiredRes) return 1;
    return 0;
}


int main(int argc, char* argv[])
   {
    unsigned totalTests  = 0;
    unsigned passedTests = 0;

    // try to find known encodings
    unsigned i = 0;
    for(; i!=32; ++i, ++totalTests )
       {
        passedTests += testFindEncoding( encNameToIndex[i].encName );
       }

    ++totalTests;
    passedTests += testFindEncoding( "abrakadabra-42", 0 );

    ++totalTests;
    const CEncodingInfo* pInfo = findEncodingInfo( 866 );
    if (pInfo) ++passedTests;

    ++totalTests;
    pInfo = findEncodingInfo( 849 ); // unknown code
    if (!pInfo) ++passedTests;

    std::cout<<"Passed "<<passedTests<<" from "<<totalTests<<"\n";
    
    return 0;
   }

