// MainDlg.h : interface of the CWtlErrorInfoDlg class
//
/////////////////////////////////////////////////////////////////////////////

#pragma once

#include "stdafx.h"

#include <shlobj.h>
#include <atlbase.h>
#include <atlapp.h>

extern CAppModule _Module;

#include <atlwin.h>
#include <atlframe.h>
#include <atlctrls.h>
#include <atldlgs.h>

#include "wtlErrorInfoDlgRes.h"

#include <atlcrack.h>

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#include <cli/cli2.h>
#include <cli/errinfo.h>

#include "wtlMaketree.h"


class CWtlErrorInfoDlg : //public CDialogImpl<CWtlErrorInfoDlg>, 
   public CAxDialogImpl<CWtlErrorInfoDlg>,
   public CMessageFilter, 
   public CIdleHandler,
   public CDialogResize<CWtlErrorInfoDlg>

{
public:
    enum { IDD = IDD_ERRORINFODLG };

    //::std::vector< INTERFACE_CLI_IERRORINFO* > errorInfos;
    INTERFACE_CLI_IERRORINFO**                 errorInfos;
    SIZE_T                                     errorInfosSize;
    CTreeViewCtrlEx                            treeView;
    CImageList                                 imageList;
    DWORD                                      flags;
    ::std::vector<int>                         buttonsOrder;
    const WCHAR                               *customCaption;
/*
IDI_APPLICATION
IDI_EXCLAMATION (IDI_WARNING)
IDI_HAND        (IDI_ERROR)
IDI_INFORMATION (IDI_ASTERISK)
*/

   virtual BOOL PreTranslateMessage(MSG* pMsg)
   {
      return IsDialogMessage(pMsg);
   }

   virtual BOOL OnIdle()
   {
      return FALSE;
   }

    void fillTree();



    BEGIN_MSG_MAP(CWtlErrorInfoDlg)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        //COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
        COMMAND_ID_HANDLER(IDCONTINUE, OnButtonPressed)
        COMMAND_ID_HANDLER(IDTRYAGAIN, OnButtonPressed)
        COMMAND_ID_HANDLER(IDOK      , OnButtonPressed)
        COMMAND_ID_HANDLER(IDIGNORE  , OnButtonPressed)
        COMMAND_ID_HANDLER(IDRETRY   , OnButtonPressed)
        COMMAND_ID_HANDLER(IDABORT   , OnButtonPressed)
        COMMAND_ID_HANDLER(IDYES     , OnButtonPressed)
        COMMAND_ID_HANDLER(IDNO      , OnButtonPressed)
        COMMAND_ID_HANDLER(IDCANCEL  , OnButtonPressed)
        COMMAND_ID_HANDLER(ID_SAVE   , OnSave         )
        //COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
        NOTIFY_CODE_HANDLER(NM_DBLCLK, OnNotifyDblClick)

        CHAIN_MSG_MAP(CDialogResize<CWtlErrorInfoDlg>)

    END_MSG_MAP()

    BEGIN_DLGRESIZE_MAP(CWtlErrorInfoDlg)
            DLGRESIZE_CONTROL(IDC_LIST, DLSZ_SIZE_X|DLSZ_SIZE_Y)

            DLGRESIZE_CONTROL( IDCONTINUE, DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( IDTRYAGAIN, DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( IDOK      , DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( IDIGNORE  , DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( IDRETRY   , DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( IDABORT   , DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( IDYES     , DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( IDNO      , DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( IDCANCEL  , DLSZ_MOVE_Y | DLSZ_MOVE_X)
            DLGRESIZE_CONTROL( ID_SAVE   , DLSZ_MOVE_Y | DLSZ_MOVE_X)
            //DLGRESIZE_CONTROL(ID_APP_ABOUT, DLSZ_MOVE_Y | DLSZ_MOVE_X)
        END_DLGRESIZE_MAP()


// Handler prototypes (uncomment arguments if needed):
//  LRESULT MessageHandler(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
//  LRESULT CommandHandler(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
//  LRESULT NotifyHandler(int /*idCtrl*/, LPNMHDR /*pnmh*/, BOOL& /*bHandled*/)

    LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
    LRESULT OnButtonPressed(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
    LRESULT OnSave(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
    LRESULT OnNotifyDblClick(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

    inline
    void moveAndShowCtrl(int ctrlId, int x, int y, int nWidth, int nHeight)
       {
        CWindow ctrl = GetDlgItem(ctrlId);
        ctrl.MoveWindow( x, y, nWidth, nHeight, TRUE);
        ctrl.ShowWindow(SW_SHOW);
        buttonsOrder.push_back(ctrlId);
       }
    //BOOL MoveWindow(int x, int y, int nWidth, int nHeight, BOOL bRepaint = TRUE) throw()


};
