// MainDlg.cpp : implementation of the CWtlErrorInfoDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include <shlobj.h>
#include <atlbase.h>
#include <atlapp.h>

extern CAppModule _Module;

#include <atlwin.h>

#include <atlframe.h>
#include <atlctrls.h>
#include <atldlgs.h>


#include "wtlErrorInfoDlgRes.h"


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#include <cli/implhlp.h>
#include <cli/interlocked.h>
#include <cli/climod.h>
#include <cli/cligui.h>

#include <marty/concvt.h>
#include <marty/utf.h>

#include <marty/filesys.h>
#include <marty/winapi.h>


#include "makeStr.h"


#if !defined(_FSTREAM_) && !defined(_STLP_FSTREAM) && !defined(__STD_FSTREAM__) && !defined(_CPP_FSTREAM) && !defined(_GLIBCXX_FSTREAM)
    #include <fstream>
#endif


::std::wstring loadStringW(HINSTANCE hInst, int strId);
::std::string loadStringA(HINSTANCE hInst, int strId);

extern ::cli::CModule cliModule;

#ifdef _UNICODE
    #define loadString loadStringW
#else
    #define loadString loadStringA
#endif

#include "wtlErrorInfoDlg.h"

#include <atlgdi.h>

//#include <cli/drawing/impl/dc1win.h>
//#include <cli/drawing/drawhlp.h>


#if !defined(_STDEXCEPT_) && !defined(_STLP_STDEXCEPT) && !defined(__STD_STDEXCEPT) && !defined(_CPP_STDEXCEPT) && !defined(_GLIBCXX_STDEXCEPT)
    #include <stdexcept>
#endif

#ifndef MARTY_FILENAME_H
    #include <marty/filename.h>
#endif

#include <windowsx.h>
#include <shellapi.h>

#include "winDevEnv.h"


extern ::cli::CModule cliModule;

// FORMAT_MESSAGE_IGNORE_INSERTS

//#include "guids.cpp"

LRESULT CWtlErrorInfoDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
    if (customCaption) SetWindowText( MARTY_CON_NS toTstr(customCaption).c_str() );

    for(int ctrlId = IDOK; ctrlId<=IDCONTINUE; ++ctrlId )
       {
        if (ctrlId==IDCLOSE || ctrlId==IDHELP) continue;
        ::ShowWindow( GetDlgItem(ctrlId), SW_HIDE);
       }
    ::ShowWindow( GetDlgItem(ID_SAVE), SW_HIDE);

    int btnWidth = 0;
    int btnHeight = 0;
    POINT rightBtnPos;
    {
     RECT r;
     ::GetWindowRect( GetDlgItem(ID_SAVE), &r);
     btnWidth  = r.right  - r.left;
     btnHeight = r.bottom - r.top ;
     rightBtnPos.x = r.left;
     rightBtnPos.y = r.top;
     ::ScreenToClient( m_hWnd, &rightBtnPos );
    }
    //int btnSpacing = btnWidth / 25;
    int btnSpacing = btnWidth / 10;

    if (!(flags&CLI_GUI_ERRORDIALOGFLAGS_FNOSAVE))
       {
        ::ShowWindow( GetDlgItem(ID_SAVE), SW_SHOW);
        rightBtnPos.x -= btnWidth+btnSpacing;
       }

    //moveAndShowCtrl(int ctrlId, int x, int y, int nWidth, int nHeight)

    const DWORD buttonFlags = flags&CLI_GUI_ERRORDIALOGFLAGS_BUTTONFLAGSMASK;
    switch(buttonFlags)
       {
        case CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON:
                moveAndShowCtrl(IDOK      , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                break;

        case CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON:
                moveAndShowCtrl(IDCANCEL  , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDOK      , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                break;

        case CLI_GUI_ERRORDIALOGFLAGS_YESNOBUTTON:
                moveAndShowCtrl(IDNO      , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDYES     , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                break;

        case CLI_GUI_ERRORDIALOGFLAGS_YESCANCELBUTTON:
                moveAndShowCtrl(IDCANCEL  , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDYES     , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                break;

        case CLI_GUI_ERRORDIALOGFLAGS_YESNOCANCELBUTTON:
                moveAndShowCtrl(IDCANCEL  , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDNO      , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDYES     , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                break;

        case CLI_GUI_ERRORDIALOGFLAGS_RETRYCANCELBUTTON:
                moveAndShowCtrl(IDCANCEL  , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDRETRY   , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                break;

        case CLI_GUI_ERRORDIALOGFLAGS_ABORTRETRYIGNOREBUTTON:
                moveAndShowCtrl(IDIGNORE  , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDRETRY   , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDABORT   , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                break;

        case CLI_GUI_ERRORDIALOGFLAGS_CANCELTRYCONTINUEBUTTON:
                moveAndShowCtrl(IDCONTINUE, rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDTRYAGAIN, rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                moveAndShowCtrl(IDCANCEL  , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
                break;
//        case :
//                break;
        default:            
                moveAndShowCtrl(IDOK      , rightBtnPos.x, rightBtnPos.y, btnWidth, btnHeight); rightBtnPos.x -= btnWidth+btnSpacing;
       }
    //switch(flags&CLI_GUI_ERRORDIALOGFLAGS_BUTTONFLAGSMASK)

    unsigned defBtnIndex = (flags&CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTONFLAGSMASK)>>8;
    if (!defBtnIndex) defBtnIndex = 1;
    if (buttonsOrder.size()>=(size_t)defBtnIndex)
       {
        size_t realIdx = buttonsOrder.size() - defBtnIndex; // - 1;
        HWND hDef = GetDlgItem( buttonsOrder[realIdx] );
        // remove BS_DEFPUSHBUTTON
        ::SendMessage(hDef, BM_SETSTYLE, BS_DEFPUSHBUTTON, MAKELPARAM(TRUE, 0));
       }

    // center the dialog on the screen
    CenterWindow();

    DlgResize_Init(); // true  /* bAddGripper */ , false  /* bUseMinTrackSize */ );


    // set icons
    //HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
    HICON hIcon = (HICON)::LoadImage( cliModule.getModuleHandle()
                                    , MAKEINTRESOURCE(IDR_ERRORINFODLG)
                                    , IMAGE_ICON
                                    , ::GetSystemMetrics(SM_CXICON)
                                    , ::GetSystemMetrics(SM_CYICON)
                                    , LR_DEFAULTCOLOR
                                    );
    SetIcon(hIcon, TRUE);
    HICON hIconSmall = (HICON)::LoadImage( cliModule.getModuleHandle()
                                         , MAKEINTRESOURCE(IDR_ERRORINFODLG)
                                         , IMAGE_ICON
                                         , ::GetSystemMetrics(SM_CXSMICON)
                                         , ::GetSystemMetrics(SM_CYSMICON)
                                         , LR_DEFAULTCOLOR
                                         );
    SetIcon(hIconSmall, FALSE);

    /*
    CMessageLoop* pLoop = _Module.GetMessageLoop();
    if (pLoop)
       {
        ATLASSERT(pLoop != NULL);
        pLoop->AddMessageFilter(this);
        pLoop->AddIdleHandler(this);
       }
    */

    treeView = GetDlgItem(IDC_LIST);
    treeView.ModifyStyleEx(0, WS_EX_CLIENTEDGE, TRUE);

    //imageList.Create( IDR_ICONS, 16, 10, RGB(0xc8,0xc8,0xc8) );
    //imageList.Create( IDR_ICONS, 16, 10, RGB(0xc0,0xc0,0xc0) );
    imageList.Create( IDR_ICONS, 16, 10, RGB(0xff,0x00,0xff) );

    treeView.SetImageList( imageList );

/*
    INTERFACE_CLI_IERRORINFO* pErrInfo = 0;
    cliGetErrorInfo( &pErrInfo );

    //::std::vector< pErrInfo > 
    errorInfos.push_back(pErrInfo);
    errorInfos.push_back(pErrInfo);
    errorInfos.push_back(pErrInfo);
    errorInfos.push_back(pErrInfo);
*/
    fillTree();
   
    return TRUE;
}

void CWtlErrorInfoDlg::fillTree()
   {
    treeView.DeleteAllItems();
    for( SIZE_T i=0; i!=errorInfosSize; ++i)
       {
        if (!i)
           treeView.Expand( addTreeItem( errorInfos[i], true, flags, 0, treeView ) );
        else 
           addTreeItem( errorInfos[i], true, flags, 0, treeView );
        //lbox.AddString(_T(""));
       }   
   }

LRESULT CWtlErrorInfoDlg::OnButtonPressed(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    if (wID==IDCANCEL)
       {
        switch(flags&CLI_GUI_ERRORDIALOGFLAGS_BUTTONFLAGSMASK)
           {
            case CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON:
            //case CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON:
            case CLI_GUI_ERRORDIALOGFLAGS_YESNOBUTTON:
            //case CLI_GUI_ERRORDIALOGFLAGS_YESCANCELBUTTON:
            //case CLI_GUI_ERRORDIALOGFLAGS_YESNOCANCELBUTTON:
            //case CLI_GUI_ERRORDIALOGFLAGS_RETRYCANCELBUTTON:
            case CLI_GUI_ERRORDIALOGFLAGS_ABORTRETRYIGNOREBUTTON:
            //case CLI_GUI_ERRORDIALOGFLAGS_CANCELTRYCONTINUEBUTTON:           
                 return 0; // there is no cancel button on dialog, we can't return IDCANCEL
           }
       }

/*
        case CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON:
        case CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON:
        case CLI_GUI_ERRORDIALOGFLAGS_YESNOBUTTON:
        case CLI_GUI_ERRORDIALOGFLAGS_YESCANCELBUTTON:
        case CLI_GUI_ERRORDIALOGFLAGS_YESNOCANCELBUTTON:
        case CLI_GUI_ERRORDIALOGFLAGS_RETRYCANCELBUTTON:
        case CLI_GUI_ERRORDIALOGFLAGS_ABORTRETRYIGNOREBUTTON:
        case CLI_GUI_ERRORDIALOGFLAGS_CANCELTRYCONTINUEBUTTON:
*/
    EndDialog(wID);
    return 0;
}

LRESULT CWtlErrorInfoDlg::OnSave(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    typedef ::std::basic_string< TCHAR, 
                             ::std::char_traits<TCHAR>, 
                             ::std::allocator<TCHAR> >  tstring;

    tstring filter = loadString(cliModule.getModuleHandle(), IDS_SAVE_FILTER);
    filter.append(1, '\0');

    CFileDialog     dlg( FALSE // saveFileDialog
                       , _T(".xml") // lpszDefExt
                       , _T("error.xml") // lpszFileName
                       , OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT // dwFlags
                       , filter.c_str()
                       );
                       /*
                       , OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT // dwFlags
                       , 0 // lpszFilter
                       , m_hWnd
                       );
                       */
    if (!dlg.DoModal()) return 0;

    ::std::wstring res(L"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<cli-error-info>\n");

    for( SIZE_T i=0; i!=errorInfosSize; ++i)
       {
        res.append( 
                   makeErrorInfoXML(errorInfos[i])
                  );
       }   

    res.append(L"</cli-error-info>");

    ::std::string utfStr = MARTY_UTF_NS toUtf8(res);
    //tstring MARTY_WINAPI_NS makeUnicodeLongFilename( dlg.m_szFileName )
    HANDLE hFile = CreateFile( MARTY_WINAPI_NS makeUnicodeLongFilename( dlg.m_szFileName ).c_str()
                             , GENERIC_WRITE
                             , 0 // share mode
                             , 0 // security attrs
                             , CREATE_ALWAYS
                             , FILE_ATTRIBUTE_NORMAL
                             , 0 // hTemplateFile
                             );
    DWORD written = 0;
    WriteFile(hFile, utfStr.c_str(), (DWORD)utfStr.size(), &written, 0 );
    CloseHandle(hFile);


    /*
    using MARTY_FILESYSTEM_NS handle_t;
    using MARTY_FILESYSTEM_NS openFile;
    using MARTY_FILESYSTEM_NS closeFile;
    using MARTY_FILESYSTEM_NS writeFile;
    using MARTY_FILESYSTEM_NS osFilename;

    handle_t hFile = openFile( osFilename() const ::std::string &filename, fileopenmode oflag, bool createReadonly = false)
    O_TRUNC

    int writeFile(handle_t fd, const void* buf, unsigned numOfBytesToWrite)

    closeFile( handle_t fd )

    openFile(const ::std::string &filename, fileopenmode oflag, bool createReadonly = false)
    MARTY_FILESYSTEM_NS


    //::std::ofstream()
    */
    return 0;
}

struct CEnumWindowsStruct
{
    ::std::vector<HWND>       hwndsFound;
    ::std::wstring            lookupFor;
    ::std::wstring            lookupForClass;
    ::std::wstring            textFound;

    CEnumWindowsStruct(const ::std::wstring &lf, const ::std::wstring &lc) 
       : hwndsFound(), lookupFor(lf), lookupForClass(lc), textFound()
       {}

    virtual
    BOOL compare(HWND hwnd)
       {
        WCHAR buf[1024]; // it's enough space
        buf[ ::GetWindowTextW(hwnd, buf, sizeof(buf)/sizeof(buf[0]) ) ] = 0;
        ::std::wstring wndText = buf;

        buf[ ::GetClassNameW(hwnd, buf, sizeof(buf)/sizeof(buf[0]) ) ] = 0;
        ::std::wstring wndClass = buf;

        if (wndText.find(lookupFor)!=wndText.npos && wndClass.find(lookupForClass)!=wndText.npos)
           {
            hwndsFound.push_back(hwnd);
           }
        return TRUE;
       }
};

BOOL CALLBACK EnumWindowsCompareProc( HWND hwnd, LPARAM lParam);
BOOL CALLBACK EnumWindowsCompareProc( HWND hwnd, LPARAM lParam)
   {
    CEnumWindowsStruct *ps = (CEnumWindowsStruct*)lParam;
    return ps->compare(hwnd);
   }

int getLaunchedVSWindowsCount()
   {
    CEnumWindowsStruct ews( ::std::wstring(L"Microsoft Visual Studio"), ::std::wstring(L"wndclass_desked"));

    EnumWindows( &EnumWindowsCompareProc, (LPARAM)&ews);
    return (int)ews.hwndsFound.size();
   }

void findAllChildWindows(::std::vector<HWND> &childs);
void findAllChildWindows(::std::vector<HWND> &childs)
   {
    ::std::vector<HWND>::size_type i = 0;
    //HWND hwndChild = 0;
    for(; i<childs.size(); ++i) 
       {
        HWND hwndChild = FindWindowEx(childs[i], 0, 0, 0 );
        while(hwndChild)
           {
            childs.push_back(hwndChild);
            hwndChild = FindWindowEx(childs[i], hwndChild, 0, 0 );
           }
       }
   }

void findAllChildWindows(HWND hwndParent, ::std::vector<HWND> &childs);
void findAllChildWindows(HWND hwndParent, ::std::vector<HWND> &childs)
   {
    childs.push_back(hwndParent);
    findAllChildWindows(childs);
   }


void findChildWindowsByClass(HWND hwnd, ::std::vector<HWND> &hwndsFound, const ::std::wstring &clsNameOrText, bool byClass);
void findChildWindowsByClass(HWND hwnd, ::std::vector<HWND> &hwndsFound, const ::std::wstring &clsNameOrText, bool byClass )
   {
    ::std::vector<HWND> childs;
    findAllChildWindows(hwnd, childs);
    ::std::vector<HWND>::const_iterator chit = childs.begin();
    for(; chit!=childs.end(); ++chit)
       {
        WCHAR buf[1024]; // it's enough space
        if (!byClass) buf[ ::GetWindowTextW(*chit, buf, sizeof(buf)/sizeof(buf[0]) ) ] = 0;
        else          buf[ ::GetClassNameW(*chit, buf, sizeof(buf)/sizeof(buf[0]) ) ] = 0;
        ::std::wstring wndTxt = buf;
        if (wndTxt.find(clsNameOrText)!=wndTxt.npos) hwndsFound.push_back(*chit);
       }
   }

HWND findVisualStudioFileEditorsWindow(HWND hwndVs, const ::std::wstring &fileName, const ::std::wstring &clsName);
HWND findVisualStudioFileEditorsWindow(HWND hwndVs, const ::std::wstring &fileName, const ::std::wstring &clsName)
   {
    ::std::vector<HWND> hwndsFilenameFound;
    ::std::vector<HWND> hwndsClassFound;
    findChildWindowsByClass(hwndVs, hwndsFilenameFound, fileName, false  /* byClass */  );
    ::std::vector<HWND>::const_iterator chit = hwndsFilenameFound.begin();
    for(; chit!=hwndsFilenameFound.end(); ++chit)
       {
        findChildWindowsByClass(*chit, hwndsClassFound, clsName, true  /* byClass */  );
       }
    if (hwndsClassFound.empty()) return 0;
    return hwndsClassFound[0];
   }






LRESULT CWtlErrorInfoDlg::OnNotifyDblClick(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
    if (!(flags&CLI_GUI_ERRORDIALOGFLAGS_SOURCEDBLCLICKOPEN)) return 0;
    if (IDC_LIST!=idCtrl) return 0;
    HTREEITEM hSel = treeView.GetSelectedItem();
    if (!hSel) return 0;

    DWORD_PTR itemData = treeView.GetItemData(hSel);
    if (itemData!=idfSource) return 0;

    INTERFACE_CLI_IERRORINFO* pErrInfo = findItemErrorInfo( treeView, hSel );
    if (!pErrInfo) return 0;

    ::cli::CiErrorInfo ie(pErrInfo);

    // ���, �������� ���� � �����
    ::std::wstring srcFile; UINT srcLine = 0;
    ie.getSourceFileLine( srcFile, &srcLine );
    if (srcFile.empty()) return 0;

    // ��������� ���� � ������

    IDispatch* pDisp = getDevEnvDispatch();
    if (!pDisp)
       {
        //OutputDebugStringW(L"Exit 1\n");
        return 0;
       }

    DISPID dispid;
    if (getExecuteCommandDispId(pDisp, dispid))
       { // ������-�� �� ������ �����������, ��������� ��� �����
        Sleep(100);
        int i=0;
        const int maxTry = 10;
        for(; i<maxTry; ++i)
           {
            if (!getExecuteCommandDispId(pDisp, dispid)) break;
            Sleep(100);
           }
        if (i>=maxTry)
           {
           pDisp->Release();
           //OutputDebugStringW(L"Exit 2\n");
           return 0;
          }
       }

    ::std::wstring openCmd = ::cli::format::message( L"File.OpenFile \"%1\""
                                        , ::cli::format::arg(srcFile)
                                        );
    executeDevEnvCommand( pDisp, dispid, openCmd, 5 ); // 5 ��� �������, �� ������ �����������
    
    ::std::wstring gotoCmd = ::cli::format::message( L"Edit.GoTo \"%1\" "
                                        , ::cli::format::arg(srcLine)
                                        );
    executeDevEnvCommand( pDisp, dispid, gotoCmd, 5 ); // 5 ��� �������, �� ������ �����������

    pDisp->Release();

    #ifdef UNDEFINED
    ::std::wstring runStr;


    if (!getLaunchedVSWindowsCount())
       {
        runStr = ::cli::format::message( L"\"%1\" /Command \"Edit.GoTo %2\""
                                        , ::cli::format::arg(srcFile) % srcLine
                                        );
        ShellExecuteW( m_hWnd, L"open", L"devenv", runStr.c_str(), 0, SW_SHOWNORMAL);
       }
     else
       {
        runStr = ::cli::format::message( L"\"%1\" /Edit /Command \"Edit.GoTo %2\""
                                        , ::cli::format::arg(srcFile) % srcLine
                                        );

        ShellExecuteW( m_hWnd, L"open", L"devenv", runStr.c_str(), 0, SW_SHOWNORMAL);
        Sleep(500);

        // find all Visual Studio top windows
        CEnumWindowsStruct ews( ::std::wstring(L"Microsoft Visual Studio"), ::std::wstring(L"wndclass_desked"));

        HWND hwndEditor = 0;
        ::std::wstring srcFileOnly = MARTY_FILENAME_NS getFile(srcFile);
    
        EnumWindows( &EnumWindowsCompareProc, (LPARAM)&ews);
        ::std::vector<HWND>::const_iterator hwndIt = ews.hwndsFound.begin();
        for(; hwndIt!=ews.hwndsFound.end(); ++hwndIt)
           {
            //hwndEditor = findVisualStudioFileEditorsWindow(*hwndIt, srcFileOnly, ::std::wstring(L"VsTextEdit"));
            hwndEditor = findVisualStudioFileEditorsWindow(*hwndIt, srcFileOnly, ::std::wstring(L"VsTextEditPane"));
            //hwndEditor = findVisualStudioFileEditorsWindow(*hwndIt, srcFileOnly, ::std::wstring(L"ScrollBar"));
            if (hwndEditor) break;    
           }

        if (hwndEditor)
           {
            WCHAR buf[32]; // it's enough space
            buf[ ::GetWindowTextW(hwndEditor, buf, sizeof(buf)/sizeof(buf[0]) ) ] = 0;
            ::std::wstring wndTxt = buf;
            buf[ ::GetClassNameW(hwndEditor, buf, sizeof(buf)/sizeof(buf[0]) ) ] = 0;
            ::std::wstring wndCls = buf;
            ::std::wstring msg = ::std::wstring(L"Found window, class: [") + wndCls + ::std::wstring(L"], text: [") + wndTxt + ::std::wstring(L"]\n");

            //OutputDebugStringW(msg.c_str());

            // try to set scrollbar position
            // ::SendMessage version works with hwnd, found using following code:
            // hwndEditor = findVisualStudioFileEditorsWindow(*hwndIt, srcFileOnly, ::std::wstring(L"VsTextEdit"));
            // scroll pos was changing, but text editor pos not changed
            // ::SetScrollPos( hwndEditor, SB_VERT, (int)srcLine, TRUE );
            // ::SendMessage( hwndEditor, (UINT)SBM_SETPOS, (WPARAM)srcLine, (LPARAM)TRUE);

            ::SetFocus(hwndEditor);
            int charIdx = Edit_LineIndex(hwndEditor, srcLine);
            if (charIdx<0)
               {
                //OutputDebugStringW(L"Line index out of range\n");
               }
            else
               {
                int endIdx = Edit_LineIndex(hwndEditor, srcLine+1);
                if (endIdx<0)
                   Edit_SetSel(hwndEditor, charIdx, charIdx);
                else
                   Edit_SetSel(hwndEditor, charIdx, endIdx);
                ::std::wstring dbg = ::cli::format::message( L"Edit_SetSel: from %1 to %2\n"
                                                , ::cli::format::arg(charIdx) % endIdx
                                                );
                //OutputDebugStringW(dbg.c_str());
                //OutputDebugStringW(L"\n");
               }


            #ifdef UNDEFINED
            const UINT upFlags = 0x4000 /* Previous key state (1 if the key is down before the call, 0 if the key is up) */ 
                               | 0x8000 /* Transition state (1 if the key is being released, 0 if the key is being pressed) */ 
                               ;

            UINT ctrlDownFlags = 0x1D   /* scan code */                            ;
            ::PostMessage( hwndEditor, WM_KEYDOWN, (WPARAM)VK_CONTROL, (LPARAM)((ctrlDownFlags<<16)|1) );

            UINT homeDownFlags = 0x47   /* scan code */ 
                           | 0x0100 /* Extended key, such as a function key or a key on the numeric keypad (1 if it is an extended key) */ 
                           ;
            ::PostMessage( hwndEditor, WM_KEYDOWN, (WPARAM)VK_HOME, (LPARAM)((homeDownFlags<<16)|1) );

            ::PostMessage( hwndEditor, WM_KEYUP, (WPARAM)VK_HOME, (LPARAM)(((homeDownFlags|upFlags)<<16)|1) );
            ::PostMessage( hwndEditor, WM_KEYUP, (WPARAM)VK_CONTROL, (LPARAM)(((ctrlDownFlags|upFlags)<<16)|1) );

            
            for(UINT i=0; i<srcLine; ++i)
               {
                ::std::wstring dbg = ::cli::format::message( L"Step: %1\n"
                                                , ::cli::format::arg(i)
                                                );
                OutputDebugStringW(dbg.c_str());
                OutputDebugStringW(L"\n");
                UINT downFlags = 0x50   /* scan code */ 
                               | 0x0100 /* Extended key, such as a function key or a key on the numeric keypad (1 if it is an extended key) */ 
                               ;
                ::PostMessage( hwndEditor, WM_KEYDOWN, (WPARAM)VK_DOWN, (LPARAM)((downFlags<<16)|1) );
                ::PostMessage( hwndEditor, WM_KEYUP  , (WPARAM)VK_DOWN, (LPARAM)(((downFlags|upFlags)<<16)|1) );
                // SendMessage( hwndEditor, WM_KEYDOWN, (WPARAM)VK_DOWN, (LPARAM)((downFlags<<16)|1) );
                // SendMessage( hwndEditor, WM_KEYUP  , (WPARAM)VK_DOWN, (LPARAM)((upFlags  <<16)|1) );
               }
            #endif // UNDEFINED
           }
       }
    #endif // UNDEFINED
    return 0;
}


