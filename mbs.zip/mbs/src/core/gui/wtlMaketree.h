#include <cli/cli2.h>
#include <cli/errinfo.h>
#include <cli/formatx.h>


const int defImageIndex  = 0;
const int srcImageIndex  = 5;
const int dataImageIndex = 6;
const int moreImageIndex = 7;

const int idfSource = 3; // item data flag - source leaf


template <typename TreeViewCtrl>
INTERFACE_CLI_IERRORINFO* findItemErrorInfo( TreeViewCtrl &treeView, HTREEITEM curItem )
   {
    HTREEITEM hParentItem = treeView.GetParentItem(curItem);
    while(hParentItem)
       {
        DWORD_PTR itemData = treeView.GetItemData(hParentItem);
        if (itemData && itemData!=idfSource)
           {
            return (INTERFACE_CLI_IERRORINFO*)itemData;
           }
        hParentItem = treeView.GetParentItem(hParentItem);
       }
    return 0;
   }

template <typename TreeViewCtrl>
HTREEITEM
addTreeItem1( ::cli::CiErrorInfo &ie
           , bool showSource
           , DWORD flags
           , HTREEITEM hParent
           , TreeViewCtrl &treeView
           )
   {
    RCODE code = ie.getErrorCode( );

    INTERFACE_CLI_IARGLIST* arglist = 0;
    ie.getArgList( &arglist );
    if (arglist) arglist->addRef();

    ::std::wstring srcFile; UINT srcLine = 0;
    ie.getSourceFileLine( srcFile, &srcLine );

    ::std::wstring moduleName;
    ie.getModuleName( moduleName );

    ::std::wstring msg = ::cli::formatErrorMessage( (moduleName.empty() ? 0 : moduleName.c_str())
                                             , code
                                             , 0 // locale
                                             ,  /* FMF_AUTO_APPEND_LF| */ FMF_IGNORE_FORMAT_LF
                                             , ::cli::format::arg(arglist)
                                             );

    //HTREEITEM resItem = treeView.InsertItem(msg.c_str(), hParent, TVI_LAST);
    int imgIdx = ((code&EC_SEVERITY_MASK)>>30) + 1;
    HTREEITEM resItem = treeView.InsertItem(MARTY_CON_NS toTstr(msg).c_str(), imgIdx, imgIdx, hParent, TVI_LAST);
    {
     INTERFACE_CLI_IERRORINFO **ppei = ie.getPP();
     if (ppei)
        treeView.SetItemData(resItem, (DWORD_PTR)*ppei);
    }

    

    //Expand(HTREEITEM hItem, UINT nCode = TVE_EXPAND)
    ::std::wstring codeStr = loadStringW( cliModule.getModuleHandle(), IDS_ERRDLG_CODE );
    codeStr.append( ::cli::format::resultCode( code ) );

    /*
    switch(code&EC_SOURCE_MASK)
       {
        case EC_SOURCE_CLI:  
                codeStr.append(::cli::format::message(L"0x%1!08X! ", ::cli::format::arg((UINT)code) ));
                break;
        case EC_SOURCE_COM:  
                codeStr.append(::cli::format::message(L"0x%1!08X!, HRESULT: 0x%2!08X!", ::cli::format::arg((UINT)code) % RC2HR(code) ));
                break;
        case EC_SOURCE_WIN32:  
                codeStr.append(::cli::format::message(L"0x%1!08X!, Win32: %2", ::cli::format::arg((UINT)code) % RC2WIN(code) ));
                break;
        case EC_SOURCE_POSIX:  
                //codeStr.append(::cli::format::message(L"0x%1!08X!, Posix/Crt: %2!d!", ::cli::format::arg((UINT)code) % RC2POSIX(code) ));
                codeStr.append(::cli::format::message(L"0x%1!08X!, Posix/Crt: %2", ::cli::format::arg((UINT)code) % RC2POSIX(code) ));
                break;
        //default:            
       }
    */
    //treeView.InsertItem(codeStr.c_str(), resItem, TVI_LAST);
    treeView.InsertItem(MARTY_CON_NS toTstr(codeStr).c_str(), defImageIndex, defImageIndex, resItem, TVI_LAST);

    if (showSource)
       {
        ::std::wstring sourceFilePos = loadStringW( cliModule.getModuleHandle(), IDS_ERRDLG_SOURCE )
                                     + ::cli::format::message(L"%1 : %2", ::cli::format::arg(srcFile) % srcLine );
        //treeView.InsertItem(sourceFilePos.c_str(), resItem, TVI_LAST);
        HTREEITEM srcItem = treeView.InsertItem(MARTY_CON_NS toTstr(sourceFilePos).c_str(), srcImageIndex, srcImageIndex, resItem, TVI_LAST);
        treeView.SetItemData(srcItem, (DWORD_PTR)idfSource);
       }

    if (arglist && arglist->getCount()>0 && !(flags&CLI_GUI_ERRORDIALOGFLAGS_HIDEMESSAGEDATA))
       {
        SIZE_T maxArgs = arglist->getCount();
        //HTREEITEM hDataItem = treeView.InsertItem(L"Message data", resItem, TVI_LAST);
        HTREEITEM hDataItem = treeView.InsertItem( MARTY_CON_NS toTstr(loadString( cliModule.getModuleHandle(), IDS_ERRDLG_MESSAGE_DATA )).c_str()
                                                 , dataImageIndex, dataImageIndex, resItem, TVI_LAST);
        for(SIZE_T i=0; i<maxArgs; ++i )
           {
            //CLIPSTR pstr = 0;
            //arglist->getStringPStr(i, &pstr);
            CCliStr tmp_str; CCliStr_init( tmp_str );
            arglist->getString( i , &tmp_str );
            ::std::wstring dataStr;
            CCliStr_copyFromIfModified( dataStr, tmp_str);
            if (dataStr.empty())
               dataStr = loadStringW( cliModule.getModuleHandle(), IDS_ERRDLG_MESSAGE_DATA_EMPTY );

            ::std::wstring fmtDataStr = ::cli::format::message(L"[%1] %2", ::cli::format::arg(int(i+1)) % dataStr );
            //treeView.InsertItem(fmtDataStr.c_str(), hDataItem, TVI_LAST);
            treeView.InsertItem(MARTY_CON_NS toTstr(fmtDataStr).c_str(), defImageIndex, defImageIndex, hDataItem, TVI_LAST);
           }
       }

    if (arglist)
       arglist->release();

    if (hParent)
       treeView.Expand(resItem);

    return resItem;
   }


template <typename TreeViewCtrl>
HTREEITEM
addTreeItem( INTERFACE_CLI_IERRORINFO            *pei
           , bool showSource
           , DWORD flags
           , HTREEITEM hParent
           , TreeViewCtrl &treeView
           )
   {
    HTREEITEM hFirst = 0;
    ::std::wstring  resStr;
    int idx = 0;
    ::cli::CiErrorInfo ie(pei);
    while(!!ie)
       {
        //if (hParent) hParent = treeView.InsertItem( L"More...", hParent, TVI_LAST);
        if (hParent)
           {
            if (flags&CLI_GUI_ERRORDIALOGFLAGS_NOERRROCHAINS) return hParent;
            hParent = treeView.InsertItem( MARTY_CON_NS toTstr(loadString( cliModule.getModuleHandle(), IDS_ERRDLG_MORE )).c_str()
                                                  , moreImageIndex, moreImageIndex, hParent, TVI_LAST);
           }
        //MARTY_CON_NS toTstr(loadString( cliModule.getModuleHandle(), IDS_ERRDLG_MORE ))
        
        hParent = addTreeItem1(ie, showSource, flags, hParent, treeView);
        if (!hFirst) hFirst = hParent;
        //resStr.append(makeHtmlErrInfo1( ie, developerMode, idx*25 ));
        ++idx;
        INTERFACE_CLI_IERRORINFO* pTmp = 0;
        ie.getChainErrorInfo( &pTmp );
        if (pTmp) pTmp->release();
        ie = pTmp;
       }

    return hFirst;
   }
