#ifndef CORE_GUI_MAKESTR_H
#define CORE_GUI_MAKESTR_H

::std::wstring
makeErrorInfoXML1( ::cli::CiErrorInfo &ie
                 , const ::std::wstring &indent
                 )
   {
    RCODE code = ie.getErrorCode( );

    INTERFACE_CLI_IARGLIST* arglist = 0;
    ie.getArgList( &arglist );
    if (arglist) arglist->addRef();

    ::std::wstring srcFile; UINT srcLine = 0;
    ie.getSourceFileLine( srcFile, &srcLine );

    ::std::wstring moduleName;
    ie.getModuleName( moduleName );

    ::std::wstring msg = ::cli::formatErrorMessage( (moduleName.empty() ? 0 : moduleName.c_str())
                                             , code
                                             , 0 // locale
                                             ,  /* FMF_AUTO_APPEND_LF| */ FMF_IGNORE_FORMAT_LF
                                             , ::cli::format::arg(arglist)
                                             );

    ::std::wstring res = ::cli::format::messageEx( L"%1<error code=\"%2\" src=\"%3\" native=\"%4\">\n"
                                                 L"%1    <message>%5</message>\n"
                                                 L"%1    <source file=\"%6\" line=\"%7\"/>\n"
                                               , ::cli::format::arg(indent) 
                                                 % ::cli::format::resultOnlyCode(code) % ::cli::format::resultCodeSource(code) % ::cli::format::resultCodeNative(code)
                                                 % msg % srcFile % srcLine
                                               , FMF_AUTO_APPEND_LF|FMF_ALLOW_ASCII_CTRL_CHARS
                                               );

    //::std::vector< ::std::wstring > argLines;
    
    if (arglist && arglist->getCount()>0)
       {
        res.append(indent);
        res.append(L"    <error-data>\n");
        SIZE_T maxArgs = arglist->getCount();
        for(SIZE_T i=0; i<maxArgs; ++i )
           {
            CCliStr tmp_str; CCliStr_init( tmp_str );
            arglist->getString( i , &tmp_str );
            ::std::wstring dataStr;
            CCliStr_copyFromIfModified( dataStr, tmp_str);
            WCHAR typeBuf[128];
            SIZE_T typeBufSize = sizeof(typeBuf) / sizeof(typeBuf[0]);
            arglist->getTypeStringChars( i, typeBuf, &typeBufSize );
            ::std::wstring fmtDataStr = ::cli::format::messageEx( L"%3        <data index=\"%1\" type=\"%4\">%2</data>\n"
                                                                , ::cli::format::arg(int(i+1)) % dataStr % indent % ::std::wstring(typeBuf)
                                                                , FMF_AUTO_APPEND_LF|FMF_ALLOW_ASCII_CTRL_CHARS
                                                                );
            res.append(fmtDataStr);
           }
        res.append(indent);
        res.append(L"    </error-data>\n");
       }
    
    if (arglist)
       arglist->release();

    return res;
   }


::std::wstring
makeErrorInfoXML( INTERFACE_CLI_IERRORINFO            *pei
           )
   {
    ::std::wstring  resStr;
    //int idx = 0;
    ::cli::CiErrorInfo ie(pei);
    bool bFirst = true;
    //::std::wstring closingTags;
    ::std::vector< ::std::wstring > closingTags;
    ::std::wstring indent;
    ::std::wstring res;

    while(!!ie)
       {
        res.append(
                   makeErrorInfoXML1( ie, indent )
                  );

        ::std::wstring str = indent;
        //closingTags.append(indent);
        str.append(L"</error>\n");
        closingTags.push_back(str);
        indent.append(8, L' ');
        //++idx;
        INTERFACE_CLI_IERRORINFO* pTmp = 0;
        ie.getChainErrorInfo( &pTmp );
        if (pTmp) pTmp->release();
        ie = pTmp;
       }

    ::std::vector< ::std::wstring >::const_reverse_iterator rit = closingTags.rbegin();
    for(; rit!=closingTags.rend(); ++rit)
       {
        res.append(*rit);
       }
    //res.append(closingTags);

    return res;
   }



#endif /* CORE_GUI_MAKESTR_H */

