#ifndef DEVENV_H
#define DEVENV_H

#include <string>
#include <stdio.h>
#include <tchar.h>
#include <string.h>
#include <objbase.h>
#include <windows.h>


#pragma comment( lib, "user32" )
#pragma comment( lib, "ole32" )
#pragma comment( lib, "oleaut32" )

// The VS.NET IDE Command Window (Ctrl+Alt+A)
// alias vs View.SolutionExplorer
// alias nf File.NewFile
// code adopted from http://tulrich.com/geekstuff/DevEnvCommand.cpp

inline
IUnknown* // Get an interface to the running instance, if any..
getDevEnvUnknown()
   {

    CLSID clsid1, clsid2, clsid3, clsid4, clsid5, clsid6;
    CLSIDFromProgID(L"VisualStudio.DTE"    , &clsid1);
    CLSIDFromProgID(L"VisualStudio.DTE.7.0", &clsid2);
    CLSIDFromProgID(L"VisualStudio.DTE.7.1", &clsid3);
    CLSIDFromProgID(L"VisualStudio.DTE.8.0", &clsid4);
    CLSIDFromProgID(L"VisualStudio.DTE.8.1", &clsid5);
    CLSIDFromProgID(L"VisualStudio.DTE.9.0", &clsid6);

    IUnknown *pUnk;
    HRESULT hr = GetActiveObject(clsid1, NULL, (IUnknown**)&pUnk);
    if (hr != 0)
    {
        hr = GetActiveObject(clsid2, NULL, (IUnknown**)&pUnk);
        if (hr != 0)
        {
            hr = GetActiveObject(clsid3, NULL, (IUnknown**)&pUnk);
            if (hr != 0)
            {
                hr = GetActiveObject(clsid4, NULL, (IUnknown**)&pUnk);
                if (hr != 0)
                {
                    hr = GetActiveObject(clsid5, NULL, (IUnknown**)&pUnk);
                    if (hr != 0)
                    {
                        hr = GetActiveObject(clsid6, NULL, (IUnknown**)&pUnk);
                        if (hr != 0)
                        {
                         return 0;
                        }
                    }
                }
            }
        }
    }

    return pUnk;
   }


inline
IDispatch* // Get IDispatch interface for Automation...
getDevEnvDispatch()
   {
    IUnknown* pUnk = getDevEnvUnknown();
    if (!pUnk) return 0;
    IDispatch *pDisp;
    HRESULT hr = pUnk->QueryInterface(IID_IDispatch, (void **)&pDisp);
    pUnk->Release();

    if (hr != 0)
       { 
        return 0;
       }
    return pDisp;
   }

inline
HRESULT
getExecuteCommandDispId(IDispatch *pDisp, DISPID &dispid)
   {
    //DISPID dispid;
    OLECHAR FAR* method = L"ExecuteCommand";
    HRESULT hr = pDisp->GetIDsOfNames(
        IID_NULL,
        &method,
        1,
        LOCALE_USER_DEFAULT,
        &dispid);   
    return hr;
   }


inline
HRESULT
executeDevEnvCommand( IDispatch *pDisp, DISPID &dispid, const ::std::wstring &command)
   {
    VARIANT variant_result;
    VariantInit(&variant_result);
    EXCEPINFO ExceptInfo;

    VARIANTARG variant_arg[1];
    VariantInit(&variant_arg[0]);
    variant_arg[0].vt = VT_BSTR;
    variant_arg[0].bstrVal = SysAllocString(command.c_str());
    HRESULT hr = VariantChangeType(&variant_arg[0], &variant_arg[0], 0, VT_BSTR);

    DISPPARAMS args = { variant_arg, NULL, 1, 0};
    hr = pDisp->Invoke(
        dispid,
        IID_NULL,
        LOCALE_SYSTEM_DEFAULT,
        DISPATCH_METHOD,
        &args,
        &variant_result,
        &ExceptInfo,
        NULL);

    SysFreeString(variant_arg[0].bstrVal);
    return hr;
   }

// ������-�� ������� �� ������ �����������, ������� ��������� ���
// ������ ����� First-chance exception at ... in ... : 0x80010001: ����� ��� ��������.
inline
HRESULT
executeDevEnvCommand( IDispatch *pDisp, DISPID &dispid, const ::std::wstring &command, int tryCountMax, int sleepInterval = 100)
   {
    HRESULT hr = executeDevEnvCommand( pDisp, dispid, command);
    if (hr)
       {
        int i=0;
        for(; i<tryCountMax; ++i)
           {
            hr = executeDevEnvCommand( pDisp, dispid, command);
            if (!hr) return hr;
            Sleep(sleepInterval);
           }
       }
    return hr;
   }


#endif /* DEVENV_H */


