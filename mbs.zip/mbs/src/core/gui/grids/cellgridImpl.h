#ifndef CORE_GUI_GRIDS_CELLGRIDIMPL_H
#define CORE_GUI_GRIDS_CELLGRIDIMPL_H

#ifndef CLI_GUI_CELLGRID_H
    #include <cli/gui/cellgrid.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifndef CLI_DRAWING_DCAUTO_H
    #include <cli/drawing/dcauto.h>
#endif

#ifndef CLI_GUI_CELLGRIDHLP_H
    #include <cli/gui/cellgridhlp.h>
#endif

using ::cli::gui::cellgrid::makeSpacing;


#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

using ::cli::drawing::makePoint;


#ifndef CLI_DRAWING_DCAUTO_H
    #include <cli/drawing/dcauto.h>
#endif

using ::cli::drawing::dc::CAutoPen      ;
using ::cli::drawing::dc::CAutoBrush    ;
using ::cli::drawing::dc::CAutoFont     ;
using ::cli::drawing::dc::CAutoClipRect ;
using ::cli::drawing::dc::CAutoViewport ;

#ifndef CLI_CLITRACE_H
    #include <cli/clitrace.h>
#endif



#ifndef CORE_GUI_GRIDS_GRIDSIMPLHLP_H
    #include "gridsimplhlp.h"
#endif


/*
#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif
*/


/*
        CLI_TRY{
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
*/

namespace cli
{
namespace impl
{

// ::cli::gui::cellgrid::iGrid

struct CCellGridImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                     , public INTERFACE_CLI_GUI_CELLGRID_IGRID
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    //CLI_BEGIN_INTERFACE_MAP2(CCellGridImpl, INTERFACE_CLI_GUI_CELLGRID_IGRID)
    CLI_BEGIN_INTERFACE_MAP(CCellGridImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_IGRID )
    CLI_END_INTERFACE_MAP(CCellGridImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    void destroy() { delete this; }

    std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*> rowsVector;
    STRUCT_CLI_GUI_CELLGRID_CSPACING              spacing;
    STRUCT_CLI_GUI_CELLGRID_CSPACING              rowSpacing;
    STRUCT_CLI_GUI_CELLGRID_CSPACING              cellSpacing;
    COLORREF                                      backgroundColor;
    COLORREF                                      rowBackgroundColor;
    bool                                          drawBackground;
    bool                                          rowDrawBackground;

    INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER        *gridOwner;
    SIZE_T                                        gridId;

    SIZE_T                                        activeRow;
    SIZE_T                                        activeCell;

    COLORREF                                      cellBackgroundColor;
    COLORREF                                      activeCellBackgroundColor;

    ENUM_CLI_GUI_CELLGRID_EALIGNMENT              cellAlignment;
    BOOL                                          disablePainting;


    CCellGridImpl()
       : base_impl(DEF_MODULE)
       , rowsVector()
       , spacing(makeSpacing(0, 0, 0, 0))
       , rowSpacing(makeSpacing(0, 0, 0, 0)) 
       , cellSpacing(makeSpacing(0, 0, 0, 0))
       , backgroundColor(0) // backgroundColor(RGB(255,255,255))
       , rowBackgroundColor(0) // rowBackgroundColor(RGB(255,255,255))
       , drawBackground(true)
       , rowDrawBackground(true)
       , gridOwner(0)
       , gridId(0)
       , activeRow(SIZE_T_NPOS)
       , activeCell(SIZE_T_NPOS)
       , cellBackgroundColor(0)
       , activeCellBackgroundColor(RGB(0,255,0))
       , cellAlignment(CLI_GUI_CELLGRID_EALIGNMENT_TOP|CLI_GUI_CELLGRID_EALIGNMENT_LEFT)
       , disablePainting(FALSE)
       {}

    ~CCellGridImpl()
       {
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it) (*it)->release();
       }

    CLIMETHOD(cellsVisibleGet) (THIS_ BOOL*    cellsVisible /* [out] bool cellsVisible  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       {
        if (idx1>=rowsVector.size()) return EC_OUT_OF_RANGE;
        return rowsVector[idx1]->cellsVisibleGet( cellsVisible, idx1, idx2 );
       }

    CLIMETHOD(cellsVisibleSet) (THIS_ BOOL    cellsVisible /* [in] bool  cellsVisible  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       {
        if (idx1>=rowsVector.size()) return EC_OUT_OF_RANGE;
        return rowsVector[idx1]->cellsVisibleSet( cellsVisible, idx1, idx2 );
       }

    CLIMETHOD(cellsVisibleSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)       
       {
        if (!size) return EC_INVALID_PARAM;
        *size = rowsVector.size();
        return EC_OK;
       }

    CLIMETHOD(cellsVisibleSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
       {
        if (!size) return EC_INVALID_PARAM;
        if (idx1>=rowsVector.size()) return EC_OUT_OF_RANGE;
        return rowsVector[idx1]->cellsVisibleSize2( size, idx1 );
       }


    CLIMETHOD(disablePaintingGet) (THIS_ BOOL*    _disablePainting /* [out] bool disablePainting  */)
       {
        if (_disablePainting) *_disablePainting = disablePainting;
        return EC_OK;
       }

    CLIMETHOD(disablePaintingSet) (THIS_ BOOL    _disablePainting /* [in] bool  disablePainting  */)
       {
        disablePainting = _disablePainting;
        return EC_OK;
       }

    CLIMETHOD(rowSizeChangedNotify) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                         , BOOL    bRepaint /* [in] bool  bRepaint  */
                                    )
       {
        if (disablePainting || !bRepaint) return EC_OK;
        if (rowIdx==SIZE_T_NPOS) rowIdx = 0;
        return paintUpdate(rowIdx);
       }

    CLIMETHOD(allRowsSizeChangedNotify) (THIS_ BOOL    bRepaint /* [in] bool  bRepaint  */)
       {
        if (disablePainting) return EC_OK;
        return paintUpdate(0);
       }

    CLIMETHOD(cellAlignmentGet) (THIS_ ENUM_CLI_GUI_CELLGRID_EALIGNMENT*    _cellAlignment /* [out] ::cli::gui::cellgrid::EAlignment cellAlignment  */)
       {
        if (_cellAlignment) *_cellAlignment = cellAlignment;
        return EC_OK;
       }

    CLIMETHOD(cellAlignmentSet) (THIS_ ENUM_CLI_GUI_CELLGRID_EALIGNMENT    _cellAlignment /* [in] ::cli::gui::cellgrid::EAlignment  cellAlignment  */)
       {
        cellAlignment = _cellAlignment;

        SIZE_T rowIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::const_iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it, ++rowIdx)
           {
            (*it)->ownerGridSet( static_cast<INTERFACE_CLI_GUI_CELLGRID_IGRID*>(this), rowIdx );
           }
        
        return EC_OK;
       }

    CLIMETHOD(cellBackgroundColorGet) (THIS_ COLORREF*    _cellBackgroundColor /* [out] colorref cellBackgroundColor  */)
       {
        if (_cellBackgroundColor) *_cellBackgroundColor = cellBackgroundColor;
        return EC_OK;
       }

    CLIMETHOD(cellBackgroundColorSet) (THIS_ COLORREF    _cellBackgroundColor /* [in] colorref  cellBackgroundColor  */)
       {
        cellBackgroundColor = _cellBackgroundColor;
        return EC_OK;
       }

    CLIMETHOD(activeCellBackgroundColorGet) (THIS_ COLORREF*    _activeCellBackgroundColor /* [out] colorref activeCellBackgroundColor  */)
       {
        if (_activeCellBackgroundColor) *_activeCellBackgroundColor = activeCellBackgroundColor;
        return EC_OK;
       }

    CLIMETHOD(activeCellBackgroundColorSet) (THIS_ COLORREF    _activeCellBackgroundColor /* [in] colorref  activeCellBackgroundColor  */)
       {
        activeCellBackgroundColor = _activeCellBackgroundColor;
        return EC_OK;
       }


    CLIMETHOD(setGridOwner) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRIDOWNER*    _pGridOwner /* [in] ::cli::gui::cellgrid::iGridOwner*  pgridOwner  */
                                 , SIZE_T    _gridId /* [in] size_t  gridId  */
                            )
       {
        gridOwner = _pGridOwner;
        gridId    = _gridId;
        return EC_OK;
       }

    CLIMETHOD(getDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */)
       {
        if (!pdc) return EC_INVALID_PARAM;
        if (!gridOwner)
           {
            *pdc = 0;
            return EC_NO_OBJECT;
           }
        return gridOwner->getDrawContext( gridId, pdc );
       }

    CLIMETHOD(getDrawContextForRectUpdate) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    gridPosLeftTop /* [in,ref] ::cli::drawing::CPoint  gridPosLeftTop  */
                                                , const STRUCT_CLI_DRAWING_CPOINT*    rectSize /* [in,ref] ::cli::drawing::CPoint  rectSize  */
                                           )
       {
        if (!pdc) return EC_INVALID_PARAM;
        if (!gridOwner)
           {
            *pdc = 0;
            return EC_NO_OBJECT;
           }
        return gridOwner->getDrawContextForRectUpdate( gridId, pdc, gridPosLeftTop, rectSize );
       }

    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [out] ::cli::gui::cellgrid::CSpacing spacing  */)
       {
        if (_spacing) *_spacing = spacing;
        return EC_OK;
       }

    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  spacing  */)
       {
        if (_spacing) spacing = *_spacing;
        return EC_OK;
       }

    CLIMETHOD(rowSpacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _rowSpacing /* [out] ::cli::gui::cellgrid::CSpacing rowSpacing  */)
       {
        if (_rowSpacing) *_rowSpacing = rowSpacing;
        return EC_OK;
       }

    CLIMETHOD(rowSpacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _rowSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  rowSpacing  */)
       {
        if (_rowSpacing) rowSpacing = *_rowSpacing;
        return EC_OK;
       }

    CLIMETHOD(cellSpacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _cellSpacing /* [out] ::cli::gui::cellgrid::CSpacing cellSpacing  */)
       {
        if (_cellSpacing) *_cellSpacing = cellSpacing;
        return EC_OK;
       }

    CLIMETHOD(cellSpacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _cellSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  cellSpacing  */)
       {
        if (_cellSpacing) cellSpacing = *_cellSpacing;
        return EC_OK;
       }

    void internalSizeGet( ::std::vector< STRUCT_CLI_DRAWING_CPOINT > *rowSizes, STRUCT_CLI_DRAWING_CPOINT &gridSize )
       {
        gridSize.x = spacing.left + spacing.right;
        gridSize.y = spacing.top  + spacing.bottom;

        SIZE_T rowIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it, ++rowIdx) 
           {
            //using ::cli::drawing::makePoint;
            STRUCT_CLI_DRAWING_CPOINT rowSize; // = makePoint(0,0);
            if ((*it)->sizeGet(&rowSize, rowIdx)) continue;

            if (rowSizes) rowSizes->push_back(rowSize);

            INT rowFullWidth = rowSize.x + spacing.left + spacing.right;
            if (gridSize.x < rowFullWidth) gridSize.x = rowFullWidth;

            gridSize.y += rowSize.y;
           }
       }

    CLIMETHOD(getCellPosSize) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                              )
       {
        if (rowIdx==SIZE_T_NPOS || cellIdx==SIZE_T_NPOS) return EC_INVALID_PARAM;

        using ::cli::drawing::makePoint;

        STRUCT_CLI_DRAWING_CPOINT pointZero = makePoint(0, 0);
        STRUCT_CLI_DRAWING_CPOINT pointLt   = pointZero;
        STRUCT_CLI_DRAWING_CPOINT gridSize  = pointZero;
        ::std::vector< STRUCT_CLI_DRAWING_CPOINT > rowSizes;
        internalSizeGet( &rowSizes, gridSize );

        UINT rowTop = spacing.top;

        SIZE_T curRowIdx = 0;
        ::std::vector< STRUCT_CLI_DRAWING_CPOINT >::const_iterator  rowSizeIt = rowSizes.begin();
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator     it = rowsVector.begin();
        for(; it!=rowsVector.end() && curRowIdx!=rowIdx; ++it, ++curRowIdx, ++rowSizeIt) 
           {
            rowTop += rowSizeIt->y;
           }

        if (curRowIdx!=rowIdx || it==rowsVector.end()) return EC_OUT_OF_RANGE;

        RCODE res = (*it)->getCellPosSize( rowIdx, cellIdx, ncLeftTop, ncWidthHeight, clientLeftTop, clientWidthHeight );
        if (res) return res;

        STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing = makeSpacing(0,0,0,0);
        (*it)->spacingGet( &rowSpacing );

        /*
        if (ncLeftTop && !ncLeftTop->x && !ncLeftTop->y)
           CLITRACE(L"iGrid::getCellPosSize - row->getCellPosSize return zero ncLeftTop" );
        if (ncWidthHeight && !ncWidthHeight->x && !ncWidthHeight->y)
           CLITRACE(L"iGrid::getCellPosSize - row->getCellPosSize return zero ncWidthHeight" );
        if (clientLeftTop && !clientLeftTop->x && !clientLeftTop->y)
           CLITRACE(L"iGrid::getCellPosSize - row->getCellPosSize return zero clientLeftTop" );
        if (clientWidthHeight && !clientWidthHeight->x && !clientWidthHeight->y)
           CLITRACE(L"iGrid::getCellPosSize - row->getCellPosSize return zero clientWidthHeight" );
        */

        if (ncLeftTop)
           {
            ncLeftTop->x += rowSpacing.left + spacing.left;
            ncLeftTop->y += rowSpacing.top  + rowTop      ;
           }

        if (clientLeftTop)
           {
            clientLeftTop->x += rowSpacing.left + spacing.left;
            clientLeftTop->y += rowSpacing.top  + rowTop      ;
           }

        return EC_OK;
       }


    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    size /* [out] ::cli::drawing::CPoint size  */)
       {
        CLI_TRY{
                if (!size) return EC_INVALID_PARAM;
                internalSizeGet( 0, *size );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;

        /*
        if (!size) return EC_INVALID_PARAM;
        size->x = spacing.left + spacing.right;
        size->y = spacing.top  + spacing.bottom;

        SIZE_T rowIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it, ++rowIdx) 
           {
            //using ::cli::drawing::makePoint;
            STRUCT_CLI_DRAWING_CPOINT rowSize; // = makePoint(0,0);
            if ((*it)->sizeGet(&rowSize, rowIdx)) continue;

            INT rowFullWidth = rowSize.x + spacing.left + spacing.right;
            if (size->x < rowFullWidth) size->x = rowFullWidth;

            size->y += rowSize.y;
           }

        return EC_OK;
        */
       }

    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    size /* [in,ref] ::cli::drawing::CPoint  size  */)
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    CLIMETHOD(sizeXGet) (THIS_ UINT*    sizeX /* [out] uint sizeX  */)
       {
        if (!sizeX) return EC_INVALID_PARAM;
        *sizeX = spacing.left + spacing.right;

        SIZE_T rowIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it, ++rowIdx) 
           {
            UINT rowSizeX = 0;
            if ((*it)->sizeXGet(&rowSizeX, rowIdx)) continue;

            INT rowFullWidth = rowSizeX + spacing.left + spacing.right;
            if (*sizeX < (UINT)rowFullWidth) *sizeX = rowFullWidth;
           }

        return EC_OK;
       }

    CLIMETHOD(sizeXSet) (THIS_ UINT    sizeX /* [in] uint  sizeX  */)
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    CLIMETHOD(sizeYGet) (THIS_ UINT*    sizeY /* [out] uint sizeY  */)
       {
        if (!sizeY) return EC_INVALID_PARAM;
        *sizeY = spacing.top + spacing.bottom;

        SIZE_T rowIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it, ++rowIdx) 
           {
            UINT rowSizeY = 0;
            if ((*it)->sizeYGet(&rowSizeY, rowIdx)) continue;

            *sizeY += rowSizeY;
           }

        return EC_OK;
       }

    CLIMETHOD(sizeYSet) (THIS_ UINT    sizeY /* [in] uint  sizeY  */)
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }
    
    CLIMETHOD(rowsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW**    _rows /* [out] ::cli::gui::cellgrid::iRow* rows  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                       )
       {
        if (!_rows) return EC_INVALID_PARAM;
        if (idx1>=rowsVector.size()) return EC_OUT_OF_RANGE;
        *_rows = rowsVector[idx1];
        return EC_OK;
       }

    CLIMETHOD(rowsSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        if (size) *size = rowsVector.size();
        return EC_OK;
       }

    CLIMETHOD(cellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL**    cells /* [out] ::cli::gui::cellgrid::iCell* cells  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                             , SIZE_T    idx2 /* [in] size_t  idx2  */
                        )
       {
        INTERFACE_CLI_GUI_CELLGRID_IROW *pRow = 0;
        RCODE res = this->rowsGet( &pRow, idx1 );
        if (res) return res;

        if (!pRow) return EC_OUT_OF_RANGE;

        SIZE_T numCells = 0;
        res = pRow->cellsSize( &numCells );
        if (res) return res;
        if (idx2>=numCells) return EC_OUT_OF_RANGE;

        res = pRow->cellsGet( cells, idx2 );
        return res;
       }

    CLIMETHOD(cellsSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        if (size) *size = rowsVector.size();
        return EC_OK;
       }

    CLIMETHOD(cellsSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                               , SIZE_T    idx1 /* [in] size_t  idx1  */
                          )
       {
        INTERFACE_CLI_GUI_CELLGRID_IROW *pRow = 0;
        RCODE res = this->rowsGet( &pRow, idx1 );
        if (res) return res;

        if (!pRow) return EC_OUT_OF_RANGE;

        res = pRow->cellsSize( size );
        return res;
       }

    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool drawBackground  */)
       {
        if (!_drawBackground) return EC_INVALID_PARAM;
        *_drawBackground = drawBackground ? TRUE : FALSE;
        return EC_OK;
       }

    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  drawBackground  */)
       {
        drawBackground = _drawBackground ? true : false;
        return EC_OK;
       }

    CLIMETHOD(rowDrawBackgroundGet) (THIS_ BOOL*    _rowDrawBackground /* [out] bool rowDrawBackground  */)
       {
        if (!_rowDrawBackground) return EC_INVALID_PARAM;
        *_rowDrawBackground = rowDrawBackground ? TRUE : FALSE;
        return EC_OK;
       }

    CLIMETHOD(rowDrawBackgroundSet) (THIS_ BOOL    _rowDrawBackground /* [in] bool  rowDrawBackground  */)
       {
        rowDrawBackground = _rowDrawBackground ? true : false;
        return EC_OK;
       }

    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref backgroundColor  */)
       {
        if (_backgroundColor) *_backgroundColor = backgroundColor;
        return EC_OK;
       }

    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  backgroundColor  */)
       {
        if (_backgroundColor) backgroundColor = _backgroundColor;
        return EC_OK;
       }

    CLIMETHOD(rowBackgroundColorGet) (THIS_ COLORREF*    _rowBackgroundColor /* [out] colorref rowBackgroundColor  */)
       {
        if (!_rowBackgroundColor) return EC_INVALID_PARAM;
        *_rowBackgroundColor = rowBackgroundColor;
        return EC_OK;
       }

    CLIMETHOD(rowBackgroundColorSet) (THIS_ COLORREF    _rowBackgroundColor /* [in] colorref  rowBackgroundColor  */)
       {
        rowBackgroundColor = _rowBackgroundColor;
        return EC_OK;
       }

    CLIMETHOD(getIUnknownIndex) (THIS_ INTERFACE_CLI_IUNKNOWN*    prow /* [in] ::cli::iUnknown*  pcell  */
                                     , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                )
       {
        if (!prow || !idxFound) return EC_INVALID_PARAM;
        SIZE_T curIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it, ++curIdx)
           {
            if (::cli::isObjectEqualTo( *it, prow ))
               {
                *idxFound = curIdx;
                return EC_OK;
               }
           }
        return EC_NOT_FOUND;
       }

    CLIMETHOD(getRowIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    prow /* [in] ::cli::gui::cellgrid::iCell*  pcell  */
                                , SIZE_T*    idxFound /* [out] size_t idxFound  */
                           )
       {
        if (!prow || !idxFound) return EC_INVALID_PARAM;

        ::cli::iUnknown *punk = 0;

        RCODE res = prow->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), (VOID**)&punk);
        if (res) return res; // queryInterface failed

        res = getIUnknownIndex( punk, idxFound );
        punk->release();

        return res;
       }


    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */)
       {
        SIZE_T rowIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it, ++rowIdx) 
           {
            (*it)->updateConfig(appCfg, rowIdx);
           }
        return EC_OK;
       }

    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */)
       {
        SIZE_T rowIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it, ++rowIdx) 
           {
            (*it)->calculateLimits(pdc, rowIdx);
           }
        return EC_OK;
       }


    CLIMETHOD(paintAux) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1* pdc, SIZE_T drawOnlyRowIdx, SIZE_T drawOnlyCellIdx, SIZE_T drawStartingRow)
       {
        CLI_TRY{
                //CLITRACE(L"iGrid::paintAux");
                if (!pdc) return EC_INVALID_PARAM;
                using ::cli::drawing::dc::CAutoPen  ;
                using ::cli::drawing::dc::CAutoBrush;
                using ::cli::drawing::dc::CAutoFont ;
                using ::cli::drawing::makePoint;
        
                STRUCT_CLI_DRAWING_CPOINT pointZero = makePoint(0, 0);
                STRUCT_CLI_DRAWING_CPOINT pointLt   = pointZero;
                STRUCT_CLI_DRAWING_CPOINT gridSize  = pointZero;
                ::std::vector< STRUCT_CLI_DRAWING_CPOINT > rowSizes;
                internalSizeGet( &rowSizes, gridSize );

                //::cli::format::cli_log::message(L"");
                //::cli::format::cli_log::message(L"grid::paint");

                if (drawOnlyRowIdx==SIZE_T_NPOS && drawBackground && !isEmptySpacing(spacing) && !drawStartingRow)
                   { 
                    //CLITRACE(L"iGrid::paintAux, drawing background for all grid");
                    CAutoBrush br( pdc, backgroundColor );
                    pdc->fillRectWH( &pointLt, &gridSize );
                   } 

                UINT rowTop = spacing.top;

                SIZE_T rowIdx = 0;
                ::std::vector< STRUCT_CLI_DRAWING_CPOINT >::const_iterator  rowSizeIt = rowSizes.begin();
                std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator     it = rowsVector.begin();
                for(; it!=rowsVector.end(); ++it, ++rowIdx, ++rowSizeIt) 
                   {
                    STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing = makeSpacing(0,0,0,0);
                    (*it)->spacingGet( &rowSpacing );

                    STRUCT_CLI_DRAWING_CPOINT leftTop     = makePoint( spacing.left, rowTop );
                    STRUCT_CLI_DRAWING_CPOINT widthHeight = *rowSizeIt; // includes rowSpacing

                    bool drawOnlyCellOnThisRow = false;
                    if (drawOnlyRowIdx!=SIZE_T_NPOS && drawOnlyRowIdx==rowIdx)
                       drawOnlyCellOnThisRow = true;

                    COLORREF curRowBackgroundColor = backgroundColor;
                    (*it)->backgroundColorGet(&curRowBackgroundColor, rowIdx );

                    BOOL rowDrawBackGround = FALSE;
                    (*it)->drawBackgroundGet( &rowDrawBackGround, rowIdx );

                    if (!drawOnlyCellOnThisRow && rowIdx>=drawStartingRow)
                       {
                        CAutoViewport avp( pdc, leftTop, widthHeight );    
                        if (rowDrawBackGround && !isEmptySpacing(rowSpacing) && curRowBackgroundColor!=backgroundColor)
                           { 
                            //CLITRACE1(L"iGrid::paintAux, drawing background for row %1", (UINT)rowIdx );
                            CAutoBrush br( pdc, curRowBackgroundColor );
                            pdc->fillRectWH( &pointZero, &widthHeight );
                           }
                        //CLITRACE1(L"iGrid::paintAux, nc painting for row %1", (UINT)rowIdx );
                        (*it)->ncPaint(pdc, &widthHeight, rowIdx);
                       }

                    // adjust left-top with row spacing
                    leftTop.x += rowSpacing.left;
                    leftTop.y += rowSpacing.top;

                    // decrease wh 
                    widthHeight.x -= (rowSpacing.left + rowSpacing.right);
                    widthHeight.y -= (rowSpacing.top  + rowSpacing.bottom);

                    if (!drawOnlyCellOnThisRow)
                       {
                        //CLITRACE1(L"iGrid::paintAux, paint client for all row %1", (UINT)rowIdx );
                        if (rowIdx>=drawStartingRow)
                           {
                            CAutoViewport avp( pdc, leftTop, widthHeight );
                            (*it)->paintClient(pdc, &widthHeight, rowIdx);
                           }
                       }
                    else
                       { // draw single cell only on this row
                        //CLITRACE2(L"iGrid::paintAux, paint one cell only for all row %1 (cell %2)", (UINT)rowIdx, (UINT)drawOnlyCellIdx );
                        CAutoViewport avp( pdc, leftTop, widthHeight );
                        (*it)->paintCell( pdc, &widthHeight, rowIdx, drawOnlyCellIdx);
                       }

                    rowTop += rowSizeIt->y;
                   }        
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    //CLIMETHOD(paint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */)
    CLIMETHOD(paint) ()
       {
        INTERFACE_CLI_DRAWING_IDRAWCONTEXT1* pdc = 0;
        RCODE res = getDrawContext( &pdc );
        if (res)  return res;
        if (!pdc) return EC_NO_OBJECT;
        res = this->paintAux(pdc, SIZE_T_NPOS, SIZE_T_NPOS, 0);
        pdc->release();
        return res;
       }

    CLIMETHOD(paintUpdate) (THIS_ SIZE_T    paintStartingRow /* [in] size_t  paintStartingRow  */)
       {
        INTERFACE_CLI_DRAWING_IDRAWCONTEXT1* pdc = 0;
        RCODE res = getDrawContext( &pdc );
        if (res)  return res;
        if (!pdc) return EC_NO_OBJECT;
        res = this->paintAux(pdc, SIZE_T_NPOS, SIZE_T_NPOS, paintStartingRow);
        pdc->release();
        return res;
       }

    CLIMETHOD(getCellDrawContextAux) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                  )
       {
        STRUCT_CLI_DRAWING_CPOINT cellLeftTop, cellWidthHeight;
        RCODE res = getCellPosSize( rowIdx, cellIdx, &cellLeftTop, &cellWidthHeight, 0, 0 );
        if (res) return res;

        return getDrawContextForRectUpdate( pdc, &cellLeftTop, &cellWidthHeight );
       }

    CLIMETHOD(getCellDrawContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1**    pdc /* [out] ::cli::drawing::iDrawContext1* pdc  */
                                       , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                       , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                  )
       {
        STRUCT_CLI_DRAWING_CPOINT cellLeftTop, cellWidthHeight;
        RCODE res = getCellPosSize( rowIdx, cellIdx, 0, 0, &cellLeftTop, &cellWidthHeight );
        if (res) return res;

        res = getDrawContextForRectUpdate( pdc, &cellLeftTop, &cellWidthHeight );
        if (res) return res;

        if (!*pdc) return EC_NO_OBJECT;

        (*pdc)->setViewportWH( &cellLeftTop, &cellWidthHeight );
        return EC_OK;
       }

    CLIMETHOD(paintCell) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                              , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                         )
        {
         /*
         STRUCT_CLI_DRAWING_CPOINT cellLeftTop, cellWidthHeight;
         RCODE res = getCellPosSize( rowIdx, cellIdx, &cellLeftTop, &cellWidthHeight, 0, 0 );
         if (res) return res;

         INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc;
         res = getDrawContextForRectUpdate( &pdc, &cellLeftTop, &cellWidthHeight );
         if (res) return res;
         */

         INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc;
         RCODE res = getCellDrawContextAux( &pdc, rowIdx, cellIdx );
         if (res) return res;

         this->paintCellOnContext( pdc, rowIdx, cellIdx );
         pdc->release();
         return EC_OK;
        }

    CLIMETHOD(paintCellOnContext) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                              , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                              , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                         )
        {
         //CLITRACE(L"iGrid::paintCell");
         return this->paintAux(pdc, rowIdx, cellIdx, 0);
        }

    CLIMETHOD(hitTest) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    pMicePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                            , SIZE_T*    hitRow /* [out] size_t hitRow  */
                            , SIZE_T*    hitCell /* [out] size_t hitCell  */
                            , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                       )
       {
        CLI_TRY{
                if (!pMicePos || !hitCell || !hitRow) return EC_INVALID_PARAM;
        
                *hitCell = SIZE_T_NPOS;
                *hitRow  = SIZE_T_NPOS;
                if (resFlags) *resFlags = 0;
        
                STRUCT_CLI_DRAWING_CPOINT pointZero = makePoint(0, 0);
                STRUCT_CLI_DRAWING_CPOINT pointLt   = pointZero;
                STRUCT_CLI_DRAWING_CPOINT gridSize  = pointZero; // includes grid spacing
                ::std::vector< STRUCT_CLI_DRAWING_CPOINT > rowSizes; // includes rowSpacing
                internalSizeGet( &rowSizes, gridSize );

                STRUCT_CLI_DRAWING_CPOINT gridSizeNoSpacing = gridSize;
                gridSizeNoSpacing.x -= spacing.left + spacing.right;
                gridSizeNoSpacing.y -= spacing.top  + spacing.bottom;

                // ������ �� � ���� ������
                if (!testRectHit( *pMicePos, gridSize ))
                   {
                    return EC_OK;
                   }
                /*
                STRUCT_CLI_DRAWING_CPOINT micePos = *pMicePos;
                micePos.x -= spacing.left;
                micePos.y -= spacing.top;
                */
                //if (resFlags) *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT;

                if ( testSpacingHit(*pMicePos, gridSizeNoSpacing, spacing) )
                   {
                    if (resFlags) *resFlags = CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDSPACING;
                    return EC_OK;
                   }
                // ��� �� spacing, �� ������ � ����
                if (resFlags) *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_GRIDHIT;

                UINT rowTop = spacing.top;

                SIZE_T rowIdx = 0;
                ::std::vector< STRUCT_CLI_DRAWING_CPOINT >::const_iterator  rowSizeIt = rowSizes.begin();
                std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator     it = rowsVector.begin();
                for(; it!=rowsVector.end(); ++it, ++rowIdx, ++rowSizeIt) 
                   {
                    STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing = makeSpacing(0,0,0,0);
                    (*it)->spacingGet( &rowSpacing );

                    // row relative mice position (includes spacings)
                    STRUCT_CLI_DRAWING_CPOINT rowMicePos = *pMicePos;
                    rowMicePos.x -= spacing.left;
                    rowMicePos.y -=  /* spacing.top +  */ rowTop;

                    STRUCT_CLI_DRAWING_CPOINT rowSize = *rowSizeIt;
                    rowSize.x -= rowSpacing.left + rowSpacing.right;
                    rowSize.y -= rowSpacing.top  + rowSpacing.bottom;

                    if ( testSpacingHit(rowMicePos, rowSize, rowSpacing) )
                       {
                        if (resFlags) *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWSPACING;
                        *hitRow = rowIdx;
                        return EC_OK;
                       }

                    //if (resFlags) *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT;

                    // row relative mice pos, spacing excluded
                    rowMicePos.x -= rowSpacing.left;
                    rowMicePos.y -= rowSpacing.top;

                    if (!testRectHit( rowMicePos, rowSize ))
                       { // not hit in row
                        rowTop += rowSizeIt->y;
                        continue;
                       }

                    *hitRow = rowIdx;
                    if (resFlags) *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT;

                    // don't test cells
                    // rowTop += rowSizeIt->y;
                    // continue;


                    /*
                    if (rowMicePos.x<0 || rowMicePos.x >=rowSize.x)
                       { // not hit in row
                        rowTop += rowSizeIt->y;
                        continue;
                       }

                    if (rowMicePos.y<0 || rowMicePos.y >=rowSize.y)
                       { // not hit in row
                        rowTop += rowSizeIt->y;
                        continue;
                       }
                    */
                    *hitRow = rowIdx;
                    RCODE res = (*it)->hitTest( rowIdx, &rowMicePos, hitCell, resFlags );
                    /*
                    if (resFlags)
                       {
                        if (!(*resFlags&(CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING|CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT)))
                           *resFlags = CLI_GUI_CELLGRID_EHITTESTFLAGS_ROWHIT;
                       }
                    */
                    return res;
                    //rowTop += rowSizeIt->y;
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(activeRowGet) (THIS_ SIZE_T*    _activeRow /* [out] size_t activeRow  */)
       {
        if (_activeRow) *_activeRow = activeRow;
        return EC_OK;
       }

    CLIMETHOD(activeCellGet) (THIS_ SIZE_T*    _activeCell /* [out] size_t activeCell  */)
       {
        if (_activeCell) *_activeCell = activeCell;
        return EC_OK;
       }

    void setActiveCell( INTERFACE_CLI_GUI_CELLGRID_ICELL *pCell, SIZE_T rowIdx, SIZE_T cellIdx, BOOL state)
       {
        if (!state)
           {
            //CLITRACE(L"iGrid::setActiveCell, clearing activeRow, activeCell" );
            if (!pCell) this->cellsGet( &pCell, activeRow, activeCell);
            if (pCell)  pCell->activeCellSet( state, activeRow, activeCell );
            activeRow  = SIZE_T_NPOS;
            activeCell = SIZE_T_NPOS;
           }
        else
           {
            //CLITRACE(L"iGrid::setActiveCell, setting new activeRow, activeCell" );
            if (!pCell) this->cellsGet( &pCell, rowIdx, cellIdx);
            if (pCell)  pCell->activeCellSet( state, rowIdx, cellIdx );
            activeRow  = rowIdx;
            activeCell = cellIdx;
           }
       }

    void paintCellUtility(INTERFACE_CLI_DRAWING_IDRAWCONTEXT1 *pdc, SIZE_T rowIdx, SIZE_T cellIdx )
       {
        if (pdc) pdc->addRef();
        else     this->getDrawContext( &pdc );
        if (!pdc) return;
        if (rowIdx!=SIZE_T_NPOS && cellIdx!=SIZE_T_NPOS)
           this->paintCellOnContext( pdc, rowIdx, cellIdx );
        pdc->release();
       }

    RCODE translateMouseMove( ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS hitFlags
                            , STRUCT_CLI_DRAWING_CPOINT micePos
                            , SIZE_T rowIdx, SIZE_T cellIdx
                            , INTERFACE_CLI_GUI_CELLGRID_ICELL *pCell
                            , ENUM_CLI_GUI_EMICECLICKFLAGS      clickFlags
                            )
       {
        if ( !(hitFlags & CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT) ) return EC_OK;

        if (!pCell)
           { 
            RCODE res = this->cellsGet( &pCell, rowIdx, cellIdx);
            if (res) return res;
           }

        if (!pCell) return EC_OK;

        STRUCT_CLI_DRAWING_CPOINT cellLeftTop, cellWidthHeight;
        RCODE res = getCellPosSize( rowIdx, cellIdx, 0, 0, &cellLeftTop, &cellWidthHeight );
        if (res) return EC_OK;

        micePos.x -= cellLeftTop.x;
        micePos.y -= cellLeftTop.y;
        if (clickFlags) // mice event such click or dbl
           return pCell->onMouseClick( &micePos, rowIdx, cellIdx, clickFlags );
        else
           return pCell->onMouseMove( &micePos, rowIdx, cellIdx );
       }

    CLIMETHOD(onMouseMoveAux) (THIS_ const STRUCT_CLI_DRAWING_CPOINT* micePos, ENUM_CLI_GUI_EMICECLICKFLAGS clickFlags = 0)
       {
        if (!micePos)   return EC_INVALID_PARAM;
        if (!gridOwner) return EC_OK; // can't repaint anywhere

        SIZE_T newActiveRow  = SIZE_T_NPOS;
        SIZE_T newActiveCell = SIZE_T_NPOS;
        SIZE_T oldActiveRow  = activeRow;
        SIZE_T oldActiveCell = activeCell;

        ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS hitFlags = 0;

        this->hitTest( micePos, &newActiveRow, &newActiveCell, &hitFlags);


        if (  !(hitFlags & (CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT|CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING))
           || newActiveRow==SIZE_T_NPOS 
           || newActiveCell==SIZE_T_NPOS
           )
           {
            setActiveCell( 0, SIZE_T_NPOS, SIZE_T_NPOS, FALSE);
            if (oldActiveRow==SIZE_T_NPOS || oldActiveCell==SIZE_T_NPOS) 
                return EC_OK; // nothing to update

            paintCell(oldActiveRow, oldActiveCell);
            return EC_OK; // ������ ��� �������� �� �������
           }

        INTERFACE_CLI_GUI_CELLGRID_ICELL *pCell = 0;
        RCODE res = this->cellsGet( &pCell, newActiveRow, newActiveCell);
        if (res || !pCell) 
           {
            setActiveCell( 0, SIZE_T_NPOS, SIZE_T_NPOS, FALSE);

            if (oldActiveRow==SIZE_T_NPOS || oldActiveCell==SIZE_T_NPOS) 
                return EC_OK; // nothing to update

            paintCell(oldActiveRow, oldActiveCell);
            return EC_OUT_OF_RANGE;
           }

        BOOL cellAllowHotTracking = FALSE;
        res = pCell->hotTrackedGet( &cellAllowHotTracking
                                  , newActiveRow
                                  , newActiveCell
                                  );
        /*
        if (res)
           {
           }
        */

        if (!cellAllowHotTracking) 
           {
            setActiveCell( 0, SIZE_T_NPOS, SIZE_T_NPOS, FALSE);
            if (oldActiveRow==SIZE_T_NPOS || oldActiveCell==SIZE_T_NPOS) 
               {
                // mice translation needed in any case
                translateMouseMove( hitFlags, *micePos, newActiveRow, newActiveCell, pCell, clickFlags );
                return EC_OK; // nothing to update
               }

            paintCell(oldActiveRow, oldActiveCell);
            // mice translation needed in any case
            translateMouseMove( hitFlags, *micePos, newActiveRow, newActiveCell, pCell, clickFlags );
            return EC_OK; // new cell not hot tracked
           }
        
        if (activeRow==newActiveRow && activeCell==newActiveCell) 
           {
            // mice translation needed in any case
            translateMouseMove( hitFlags, *micePos, newActiveRow, newActiveCell, pCell, clickFlags );
            return EC_OK; // same cell under cursor
           }

        // paint old cell
        setActiveCell( 0, SIZE_T_NPOS, SIZE_T_NPOS, FALSE);
        if (oldActiveRow!=SIZE_T_NPOS && oldActiveCell!=SIZE_T_NPOS) 
           {
            paintCell(oldActiveRow, oldActiveCell);
           }
        
        // paint new cell
        setActiveCell( pCell, newActiveRow, newActiveCell, TRUE);
        res = translateMouseMove( hitFlags, *micePos, newActiveRow, newActiveCell, pCell, clickFlags );

        if (res!=EC_ALLREADY && newActiveRow!=SIZE_T_NPOS && newActiveCell!=SIZE_T_NPOS) 
           {
            paintCell(newActiveRow, newActiveCell);
           }

        return EC_OK;
       }

    CLIMETHOD(onMouseMove) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */)
       {
        return onMouseMoveAux(micePos);
       }

    CLIMETHOD(onMouseClick) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                                 , ENUM_CLI_GUI_EMICECLICKFLAGS    eventFlags /* [in] ::cli::gui::EMiceClickFlags  eventFlags  */
                            )
       {
        return onMouseMoveAux(micePos, eventFlags);
       }


/*
    RCODE findCellAtPos( const STRUCT_CLI_DRAWING_CPOINT &pos, SIZE_T &rowIdx, SIZE_T &cellIdx )
       {
        rowIdx  = SIZE_T_NPOS;
        cellIdx = SIZE_T_NPOS;

        int rowStartPos = 0;
        SIZE_T curRow = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for( ; it!=rowsVector.end(); ++it, ++curRow)
           {
            STRUCT_CLI_DRAWING_CPOINT rowSize;
            if ((*it)->sizeGet( &rowSize, curRow )) continue;

            int nextRowStartPos = rowStartPos + rowSize.y;
            if (rowStartPos>=pos.y && nextRowStartPos<pos.y)
               {
                rowIdx = curRow;
                break;
               }
            rowStartPos = nextRowStartPos;
           }

        if (rowIdx==SIZE_T_NPOS) return EC_NOT_FOUND; // row not found

        RCODE res = rowsVector[rowIdx]->getCellIndexAtPos( rowIdx, pos.x, &cellIdx);
        if ( res ) return res;

        if (cellIdx==SIZE_T_NPOS) return EC_NOT_FOUND; // cell not found

       }
*/

    CLIMETHOD(insertRow) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */
                              , SIZE_T    atPos /* [in] size_t  idx  */
                         )
       {
        CLI_TRY{
                if (!pRow) return EC_INVALID_PARAM;
                if (atPos >= rowsVector.size() )
                   rowsVector.push_back(pRow);
                else
                   rowsVector.insert( rowsVector.begin()+atPos, pRow );
                pRow->addRef();

                SIZE_T rowIdx = 0;
                this->getRowIndex(pRow, &rowIdx);
                pRow->ownerGridSet( static_cast<INTERFACE_CLI_GUI_CELLGRID_IGRID*>(this), rowIdx );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(addRow) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IROW*    pRow /* [in] ::cli::gui::cellgrid::iRow*  pRow  */)
       {
        CLI_TRY{
                if (!pRow) return EC_INVALID_PARAM;
                rowsVector.push_back(pRow);
                pRow->addRef();
                SIZE_T rowIdx = 0;
                this->getRowIndex(pRow, &rowIdx);
                pRow->ownerGridSet( static_cast<INTERFACE_CLI_GUI_CELLGRID_IGRID*>(this), rowIdx );
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(removeRow) (THIS_ SIZE_T    atPos /* [in] size_t  atPos  */)
       {
        CLI_TRY{
                if (atPos>=rowsVector.size()) return EC_INVALID_PARAM;
                INTERFACE_CLI_GUI_CELLGRID_IROW *pRow = rowsVector[atPos];
                //SIZE_T rowIdx = atPos;
                //this->getRowIndex(pRow, &rowIdx);
                pRow->ownerGridSet( 0, atPos );
                rowsVector.erase( rowsVector.begin() + atPos );
                pRow->release();
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                         )
       {
        // �� ������ �������  - ����� ������������ ������� �� ��������� ���� �����
        // �� ������ �������� - ������������ ��������
        // �� ������ ������� - ����� ��������� �����
        // �� ������ �������� - ����� ����������, ��� CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY,
        // ���� ���� ���� ������ �� ���������� �� ������, �� ��� ����� �� ���������� �� ������
        // CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX
        // CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY
        CLI_TRY{
                if (!minSize || !maxSize) return EC_INVALID_PARAM;
                minSize->x = 0;
                minSize->y = 0;
                // grid row can't be wider than 0xFFFF;
                maxSize->x = 0; // 0xFFFF; 
                maxSize->y = 0; // 0xFFFF; 

                std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
                for(; it!=rowsVector.end(); ++it)
                   {
                    STRUCT_CLI_DRAWING_CPOINT rowMins, rowMaxs;
                    //if ( !(*it)->getLimits(&rowMins, &rowMaxs) )
                    if ( false )
                       {
                        // ���� ��� ������ ������� ������ ������ ������������, �� ����������� ������������ ������� ������
                        // ���� ������������ �� ���������
                        if (rowMins.x > minSize->x) minSize->x = rowMins.x;
                        // �� ������ ���� ������������ ��������
                        if (rowMaxs.x > maxSize->x) maxSize->x = rowMaxs.x;
                        
                        minSize->y += rowMins.y;
                        if (rowMaxs.y>=CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY)
                           {
                            maxSize->y = CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY;
                           }
                        else
                           {
                            if (maxSize->y < CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEY)
                               maxSize->y += rowMaxs.y;
                           }
                       }
                   }
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }


#if 0
    CLIMETHOD(setSize) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    sizeRequested /* [in,ref] ::cli::drawing::CPoint  sizeRequested  */
                            , STRUCT_CLI_DRAWING_CPOINT*    sizeApplied /* [out,ref] ::cli::drawing::CPoint sizeApplied  */
                       )
       {
        CLI_TRY{
                if (!sizeRequested  /* || !sizeApplied */ ) return EC_INVALID_PARAM;
                // setup rows width 
                if (sizeApplied)
                   {
                    sizeApplied->x = 0;
                    sizeApplied->y = 0;
                   }

                if (rowsVector.empty()) return EC_OK;

                std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
                for(; it!=rowsVector.end(); ++it)
                   {
                    //STRUCT_CLI_DRAWING_CPOINT rowSize;
                    ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS    resFlags;
                    UINT xApplied = 0;
                    if ((*it)->setSizeX( sizeRequested->x, &xApplied, &resFlags))
                       continue;
                    if (sizeApplied) 
                       {
                        if (sizeApplied->x < (INT)xApplied)
                           sizeApplied->x = xApplied;
                       }
                   }

                std::vector< SIZE_T >   rowsIndexes;
                SIZE_T curRowIdx = 0;
                UINT fixedWidth = 0;
                for(; curRowIdx!=rowsVector.size(); ++curRowIdx )
                   rowsIndexes.push_back(curRowIdx); // all rows in direct order

                while(!rowsIndexes.empty() || (INT)fixedWidth < sizeRequested->y)
                   {
                    UINT sizeAllreadyCalculatedAtStep = fixedWidth;
                    for(SIZE_T rowIndexIndex = 0; rowIndexIndex!=rowsIndexes.size();  /* ++rowIndexIndex */ )
                       {
                        UINT sizeEllapsed = 0;
                        if ((INT)sizeAllreadyCalculatedAtStep < sizeRequested->y)
                           sizeEllapsed = sizeRequested->y - sizeAllreadyCalculatedAtStep;
                        
                        SIZE_T rowsNotProcessedAtStep = rowsIndexes.size() - rowIndexIndex;
                        UINT requestHeight = sizeEllapsed / (INT)rowsNotProcessedAtStep;
                        if (sizeEllapsed % (INT)rowsNotProcessedAtStep)
                           ++requestHeight;

                        const SIZE_T rowIndex = rowsIndexes[rowIndexIndex];
                        ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS    resFlags;
                        UINT yApplied = 0;

                        if (rowsVector[rowIndex]->setSizeY( requestHeight, &yApplied, &resFlags))
                           { // ��������� ����, ������� ������ �� ���������
                            rowsIndexes.erase(rowsIndexes.begin()+rowIndexIndex);
                            continue;
                           }

                        if (resFlags&CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMASK)
                           { // ��������� ���� �� ��������
                            // ����������� ������ ������������ �� ������ ���� �������
                            sizeAllreadyCalculatedAtStep += yApplied; 
                            // ����������� ��������� ������ ������������� �������
                            fixedWidth += yApplied; 
                            rowsIndexes.erase(rowsIndexes.begin()+rowIndexIndex); // � ������� �� ���������
                            continue;
                           }

                        // ����������� ������ ������������ �� ������ ���� �������
                        sizeAllreadyCalculatedAtStep += yApplied; 
                        ++rowIndexIndex; // ��������� � ��������� ������
                       } // for

                    if ((INT)sizeAllreadyCalculatedAtStep>=sizeRequested->y || rowsIndexes.empty())
                       {
                        if (sizeApplied) sizeApplied->y = sizeAllreadyCalculatedAtStep;
                        break;
                       }
                   } // while
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    _size /* [out] ::cli::drawing::CPoint size  */)
       {
        if (!_size) return EC_OK;
        _size->x = 0;
        _size->y = 0;

        std::vector<INTERFACE_CLI_GUI_CELLGRID_IROW*>::iterator it = rowsVector.begin();
        for(; it!=rowsVector.end(); ++it)
           {
            STRUCT_CLI_DRAWING_CPOINT rowSize;
            if ( !(*it)->sizeGet(&rowSize) )
               {
                if (_size->x < rowSize.x) _size->x = rowSize.x;
                _size->y += rowSize.y;
               }
           }
        return EC_OK;
       }


#endif // 0

}; // CCellGridImpl



}; // namespace impl
}; // namespace cli



#endif /* CORE_GUI_GRIDS_CELLGRIDIMPL_H */

