// #define CG_OLD_VER

#ifdef CG_OLD_VER
    #include "cellgridImpl.h"
    #include "cellgridrowImpl.h"
#else
    #include <cli/gui/cg2/irowimpl.h>
    #include <cli/gui/cg2/igridimpl.h>
    #include <cli/gui/cg2/icellimpl.h>
#endif


#ifdef CG_OLD_VER
    DECLARE_COMPONENT_CREATION_PROC( create_cli_cellgrid    , ::cli::impl::CCellGridImpl        , INTERFACE_CLI_GUI_CELLGRID_IGRID)
    DECLARE_COMPONENT_CREATION_PROC( create_cli_cellgridrow , ::cli::impl::CRowImpl             , INTERFACE_CLI_GUI_CELLGRID_IROW)
#else
    DECLARE_COMPONENT_CREATION_PROC( create_cli_cellgrid2   , ::cli::gui::cellgrid::CGridImpl   , INTERFACE_CLI_GUI_CELLGRID_IGRID)
    DECLARE_COMPONENT_CREATION_PROC( create_cli_cellgridrow2, ::cli::gui::cellgrid::CRowImpl    , INTERFACE_CLI_GUI_CELLGRID_IROW)
    DECLARE_COMPONENT_CREATION_PROC( create_cli_controllercell, ::cli::gui::cellgrid::CVisibilityControllerCellImpl, INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER)
#endif



static unsigned infoInitialized = 0;
static
CCliComponentCreationInfo moduleComponentsInfo[] = 
   {
    #ifdef CG_OLD_VER
      // ---
      { 
        { "/cli/gui/cellgrid/grid"
        , INTERFACE_CLI_GUI_CELLGRID_IGRID_IID
        , "en:Cell grid manager;"
        }
      , &create_cli_cellgrid
      }
      , //
      { 
        { "/cli/gui/cellgrid/row"
        , INTERFACE_CLI_GUI_CELLGRID_IROW_IID
        , "en:Cell grid row;"
        }
      , &create_cli_cellgridrow
      }
    #else
      { 
        { "/cli/gui/cellgrid/grid"
        , INTERFACE_CLI_GUI_CELLGRID_IGRID_IID
        , "en:Cell grid row;"
        }
      , &create_cli_cellgrid2
      }
      , //
      { 
        { "/cli/gui/cellgrid/row"
        , INTERFACE_CLI_GUI_CELLGRID_IROW_IID
        , "en:Cell grid row;"
        }
      , &create_cli_cellgridrow2
      }
      , //
      { 
        { "/cli/gui/cellgrid/cell/visibility_controller"
        ,      INTERFACE_CLI_GUI_CELLGRID_IVISIBILITYCONTROLLER_IID
        IIDSEP INTERFACE_CLI_GUI_CELLGRID_ISIMPLECELL_IID
        IIDSEP INTERFACE_CLI_GUI_CELLGRID_IMULTICELL_IID
        , "en:Row/cell Visibility Controller Cell;"
        }
      , &create_cli_controllercell
      }

    #endif
   };

DECLARE_CLI_MODULE_INFO(moduleComponentsInfo, infoInitialized, registerCliGridsModule, "CliGrids")
