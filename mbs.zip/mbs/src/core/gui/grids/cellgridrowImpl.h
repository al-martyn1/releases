#ifndef CORE_GUI_GRIDS_CELLGRIDROWIMPL_H
#define CORE_GUI_GRIDS_CELLGRIDROWIMPL_H

#ifndef CLI_GUI_CELLGRID_H
    #include <cli/gui/cellgrid.h>
#endif

#ifndef CLI_IMPLHLP_H
    #include <cli/implhlp.h>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#ifndef CLI_GUI_CELLGRIDHLP_H
    #include <cli/gui/cellgridhlp.h>
#endif

using ::cli::gui::cellgrid::makeSpacing;


#ifndef CLI_DRAWING_DRAWHLP_H
    #include <cli/drawing/drawhlp.h>
#endif

using ::cli::drawing::makePoint;


#ifndef CLI_DRAWING_DCAUTO_H
    #include <cli/drawing/dcauto.h>
#endif

using ::cli::drawing::dc::CAutoPen      ;
using ::cli::drawing::dc::CAutoBrush    ;
using ::cli::drawing::dc::CAutoFont     ;
using ::cli::drawing::dc::CAutoClipRect ;
using ::cli::drawing::dc::CAutoViewport ;

#ifndef CLI_CLITRACE_H
    #include <cli/clitrace.h>
#endif


#ifndef CORE_GUI_GRIDS_GRIDSIMPLHLP_H
    #include "gridsimplhlp.h"
#endif


/*
        CLI_TRY{
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
*/

namespace cli
{
namespace impl
{


struct CRowImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                     , public INTERFACE_CLI_GUI_CELLGRID_IROW
{
    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;

    //CLI_BEGIN_INTERFACE_MAP2(CRowImpl, INTERFACE_CLI_GUI_CELLGRID_IROW)
    CLI_BEGIN_INTERFACE_MAP(CRowImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_GUI_CELLGRID_IROW )
    CLI_END_INTERFACE_MAP(CRowImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }
    void destroy() { delete this; }

    std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*> cellsVector;
    INTERFACE_CLI_GUI_CELLGRID_IGRID*              ownerGrid;
    STRUCT_CLI_GUI_CELLGRID_CSPACING    selfSpacing;
    bool                                selfSpacingUsed;
    STRUCT_CLI_GUI_CELLGRID_CSPACING    selfCellSpacing;
    bool                                selfCellSpacingUsed;

    COLORREF                            selfRowBackground;
    //bool                                selfRowBackgroundUsed;

    BOOL                                drawBackground;
    //bool                                selfDrawBackgroundUsed;

    COLORREF                            cellBackgroundColor;
    COLORREF                            activeCellBackgroundColor;
    ENUM_CLI_GUI_CELLGRID_EALIGNMENT    cellAlignment;

    ::std::vector< CCellPosSize >       cachedCellSizes;

    CRowImpl()
       : base_impl(DEF_MODULE)
       , cellsVector()
       , ownerGrid(0)
       , selfSpacing( makeSpacing(0, 0, 0, 0) )
       , selfSpacingUsed(false)
       , selfCellSpacing( makeSpacing(0, 0, 0, 0) )
       , selfCellSpacingUsed(false)
       , selfRowBackground(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED) // selfRowBackground(RGB(255,255,255))
       //, selfRowBackgroundUsed(false)
       , drawBackground(CLI_EBOOL_CONST_UNDEFINED)
       //, selfDrawBackgroundUsed(false)
       , cellBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , activeCellBackgroundColor(CLI_DRAWING_ECOLORREF_CONST_UNDEFINED)
       , cellAlignment(CLI_GUI_CELLGRID_EALIGNMENT_VUNDEFINED|CLI_GUI_CELLGRID_EALIGNMENT_HUNDEFINED)
       , cachedCellSizes()
       {}


    ~CRowImpl()
       {
        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it) (*it)->release();
        //if (ownerGrid)
       }

    void _buildCellSizesCache(SIZE_T thisRowIdx)
       {
        ENUM_CLI_GUI_CELLGRID_EALIGNMENT rowCellAlignment = 0;
        cellAlignmentGet( &rowCellAlignment );
        rowCellAlignment &= CLI_GUI_CELLGRID_EALIGNMENT_VMASK;

        INT maxHeight = 0;
        cachedCellSizes.clear();

        INT cellLeft = 0;
        SIZE_T cellIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            BOOL cellVisible = TRUE;
            (*it)->visibleGet( &cellVisible, thisRowIdx, cellIdx );

            STRUCT_CLI_GUI_CELLGRID_CSPACING cellSpacing = makeSpacing(0,0,0,0);
            if (cellVisible)
               (*it)->spacingGet( &cellSpacing, thisRowIdx, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT cellSize = makePoint( 0, 0 );
            if (cellVisible)
               (*it)->sizeGet( &cellSize, thisRowIdx, cellIdx );

            // nc size and pos
            STRUCT_CLI_DRAWING_CPOINT leftTop     = makePoint( cellLeft, 0 );
            STRUCT_CLI_DRAWING_CPOINT widthHeight = cellSize;
            widthHeight.x += cellSpacing.left + cellSpacing.right;
            widthHeight.y += cellSpacing.top  + cellSpacing.bottom;

            if (maxHeight < widthHeight.y) maxHeight = widthHeight.y;

            CPosSize ncPosSize(leftTop, widthHeight);

            leftTop.x += cellSpacing.left;
            leftTop.y += cellSpacing.top;

            //CPosSize clientPosSize(leftTop, cellSize);
            cachedCellSizes.push_back( CCellPosSize(ncPosSize, CPosSize(leftTop, cellSize) ) );

            cellLeft += cellSpacing.left + cellSpacing.right + cellSize.x;
           }

        if (rowCellAlignment==CLI_GUI_CELLGRID_EALIGNMENT_TOP) return; // do nothin, allready top aligned

        ::std::vector< CCellPosSize >::iterator csIt = cachedCellSizes.begin();
        for(; csIt!=cachedCellSizes.end(); ++csIt)
           {
            INT curDeltaH = maxHeight - csIt->ncPosSize.widthHeight.y;
            if (rowCellAlignment==CLI_GUI_CELLGRID_EALIGNMENT_BOTTOM)
               {
                csIt->ncPosSize.leftTop.y     += curDeltaH;
                csIt->clientPosSize.leftTop.y += curDeltaH;
               }
            else if (rowCellAlignment==CLI_GUI_CELLGRID_EALIGNMENT_BASELINE)
               {
                //INT baseLineMax   = maxHeight*3/4;
                //INT cellBaseLine  = csIt->ncPosSize.leftTop.y*3/4;
                //INT baseLineDelta = baseLineMax - cellBaseLine;
                //INT baseLineDelta = (maxHeight - csIt->ncPosSize.leftTop.y)*3/4;
                csIt->ncPosSize.leftTop.y     += curDeltaH*3/4;
                csIt->clientPosSize.leftTop.y += curDeltaH*3/4;
               }
            else // vcenter
               {
                csIt->ncPosSize.leftTop.y     += curDeltaH/2;
                csIt->clientPosSize.leftTop.y += curDeltaH/2;
               }
           }
       }

    CLIMETHOD(cellsVisibleGet) (THIS_ BOOL*    cellsVisible /* [out] bool cellsVisible  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       { // ignoring idx1
        if (idx2>=cellsVector.size()) return EC_OUT_OF_RANGE;
        return cellsVector[idx2]->visibleGet( cellsVisible, idx1, idx2 );
       }

    CLIMETHOD(cellsVisibleSet) (THIS_ BOOL    cellsVisible /* [in] bool  cellsVisible  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                                    , SIZE_T    idx2 /* [in] size_t  idx2  */
                               )
       { // ignoring idx1
        if (idx2>=cellsVector.size()) return EC_OUT_OF_RANGE;
        return cellsVector[idx2]->visibleSet( cellsVisible, idx1, idx2 );
       }

    CLIMETHOD(cellsVisibleSize1) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        if (!size) return EC_INVALID_PARAM;
        if (!ownerGrid) { *size = 1; return EC_OK; }
        return ownerGrid->rowsSize(size);
       }

    CLIMETHOD(cellsVisibleSize2) (THIS_ SIZE_T*    size /* [out] size_t size  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
       {
        if (!size) return EC_INVALID_PARAM;
        *size = cellsVector.size();
        return EC_OK;
       }

    CLIMETHOD(cellSizeChangedNotify) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                          , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                          , BOOL    bRepaint /* [in] bool  bRepaint  */
                                     )
       {
        _buildCellSizesCache(rowIdx);
        if (!ownerGrid) return EC_OK;
        return ownerGrid->rowSizeChangedNotify(rowIdx, bRepaint);
        //return EC_OK;
       }

    CLIMETHOD(allCellsSizeChangedNotify) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                              , BOOL    bRepaint /* [in] bool  bRepaint  */
                                         )
       {
        if (rowIdx==SIZE_T_NPOS)
           {
            if (ownerGrid)
               ownerGrid->getRowIndex( this, &rowIdx );
           }
        if (rowIdx==SIZE_T_NPOS) return ownerGrid->allRowsSizeChangedNotify(bRepaint);

        _buildCellSizesCache(rowIdx);
        if (ownerGrid) return ownerGrid->rowSizeChangedNotify(rowIdx, bRepaint);
        return EC_OK;
       }

    CLIMETHOD(cellAlignmentGet) (THIS_ ENUM_CLI_GUI_CELLGRID_EALIGNMENT*    _cellAlignment /* [out] ::cli::gui::cellgrid::EAlignment cellAlignment  */)
       {
        if (!_cellAlignment) return EC_INVALID_PARAM;
        ENUM_CLI_GUI_CELLGRID_EALIGNMENT gridCellAlignment = CLI_GUI_CELLGRID_EALIGNMENT_TOP|CLI_GUI_CELLGRID_EALIGNMENT_LEFT;

        if (ownerGrid) ownerGrid->cellAlignmentGet( &gridCellAlignment );

        ENUM_CLI_GUI_CELLGRID_EALIGNMENT resCellAlignment = cellAlignment;

        if ((resCellAlignment&CLI_GUI_CELLGRID_EALIGNMENT_VMASK) == CLI_GUI_CELLGRID_EALIGNMENT_VUNDEFINED)
           {
            resCellAlignment &= ~CLI_GUI_CELLGRID_EALIGNMENT_VMASK; // clear vert alignment
            resCellAlignment |= gridCellAlignment&CLI_GUI_CELLGRID_EALIGNMENT_VMASK;
           }
        if ((resCellAlignment&CLI_GUI_CELLGRID_EALIGNMENT_HMASK) == CLI_GUI_CELLGRID_EALIGNMENT_HUNDEFINED)
           {
            resCellAlignment &= ~CLI_GUI_CELLGRID_EALIGNMENT_HMASK; // clear hor alignment
            resCellAlignment |= gridCellAlignment&CLI_GUI_CELLGRID_EALIGNMENT_HMASK;
           }
        *_cellAlignment = resCellAlignment;
        return EC_OK;
       }

    CLIMETHOD(cellAlignmentSet) (THIS_ ENUM_CLI_GUI_CELLGRID_EALIGNMENT    _cellAlignment /* [in] ::cli::gui::cellgrid::EAlignment  cellAlignment  */)
       {
        cellAlignment = _cellAlignment;
        SIZE_T rowIdx = 0;
        if (ownerGrid) ownerGrid->getRowIndex(this, &rowIdx);
        this->allCellsSizeChangedNotify(rowIdx, TRUE);
        //buildCellSizesCache(rowIdx);
        return EC_OK;
       }

    CLIMETHOD(getCellPosSize) (THIS_ SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                                   , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    ncLeftTop /* [out,optional] ::cli::drawing::CPoint ncLeftTop  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    ncWidthHeight /* [out,optional] ::cli::drawing::CPoint ncWidthHeight  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    clientLeftTop /* [out,optional] ::cli::drawing::CPoint clientLeftTop  */
                                   , STRUCT_CLI_DRAWING_CPOINT*    clientWidthHeight /* [out,optional] ::cli::drawing::CPoint clientWidthHeight  */
                              )
       {
        if (rowIdx==SIZE_T_NPOS || cellIdx==SIZE_T_NPOS) return EC_INVALID_PARAM;
        if (cachedCellSizes.size()!=cellsVector.size())  return EC_INVALID_OBJECT_STATE;

        //STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing = makeSpacing(0,0,0,0);
        //this->spacingGet( &rowSpacing );

        // rowIdx ignored
        if (ncLeftTop)
           {
            //CLITRACE2(L"iRow::getCellPosSize - ncLeftTop : %1 x %2", cachedCellSizes[cellIdx].ncPosSize.leftTop.x, cachedCellSizes[cellIdx].ncPosSize.leftTop.y );
            ncLeftTop->x =  /* rowSpacing.left + */  cachedCellSizes[cellIdx].ncPosSize.leftTop.x;
            ncLeftTop->y =  /* rowSpacing.top  + */  cachedCellSizes[cellIdx].ncPosSize.leftTop.y;
           }

        if (ncWidthHeight)
           {
            //CLITRACE2(L"iRow::getCellPosSize - ncWidthHeight : %1 x %2", cachedCellSizes[cellIdx].ncPosSize.widthHeight.x, cachedCellSizes[cellIdx].ncPosSize.widthHeight.y );
            ncWidthHeight->x = cachedCellSizes[cellIdx].ncPosSize.widthHeight.x;
            ncWidthHeight->y = cachedCellSizes[cellIdx].ncPosSize.widthHeight.y;
           }

        if (clientLeftTop)
           {
            clientLeftTop->x =  /* rowSpacing.left + */  cachedCellSizes[cellIdx].clientPosSize.leftTop.x;
            clientLeftTop->y =  /* rowSpacing.top  + */  cachedCellSizes[cellIdx].clientPosSize.leftTop.y;
           }

        if (clientWidthHeight)
           {
            clientWidthHeight->x = cachedCellSizes[cellIdx].clientPosSize.widthHeight.x;
            clientWidthHeight->y = cachedCellSizes[cellIdx].clientPosSize.widthHeight.y;
           }

        return EC_OK;
       }

#if 0
    CLIMETHOD(getCellIndexAtPos) (THIS_ SIZE_T    thisRowIndex /* [in] size_t  thisRowIndex  */
                                      , INT    xPos /* [in] int  xPos  */
                                      , SIZE_T*    cellIdx /* [out] size_t cellIdx  */
                                 )
       {
        int    curCellPos = 0;
        SIZE_T curCellIdx = 0;

        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++curCellIdx)
           {
            STRUCT_CLI_DRAWING_CPOINT cellSize;
            if ((*it)->sizeGet( &cellSize, thisRowIndex, curCellIdx )) continue;

            int nextCellPos = curCellPos + cellSize.x;
            if (curCellPos>=xPos && xPos<nextCellPos)
               {
                if (cellIdx) *cellIdx = curCellIdx;
                return EC_OK;
               }
            curCellPos = nextCellPos;
           }
        if (cellIdx) *cellIdx = SIZE_T_NPOS;
        return EC_OK;
       }
#endif

    CLIMETHOD(cellBackgroundColorGet) (THIS_ COLORREF*    _cellBackgroundColor /* [out] colorref cellBackgroundColor  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
       {
        if (!_cellBackgroundColor) return EC_INVALID_PARAM;
        if (cellBackgroundColor!=CLI_DRAWING_ECOLORREF_CONST_UNDEFINED || !ownerGrid)
           {
            *_cellBackgroundColor = cellBackgroundColor;
            return EC_OK;
           }
        return ownerGrid->cellBackgroundColorGet( _cellBackgroundColor );
       }

    CLIMETHOD(cellBackgroundColorSet) (THIS_ COLORREF    _cellBackgroundColor /* [in] colorref  cellBackgroundColor  */
                                           , SIZE_T    idx1 /* [in] size_t  idx1  */
                                      )
       {
        cellBackgroundColor = _cellBackgroundColor;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(cellBackgroundColorSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

    CLIMETHOD(activeCellBackgroundColorGet) (THIS_ COLORREF*    _activeCellBackgroundColor /* [out] colorref activeCellBackgroundColor  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            )
       {
        if (!_activeCellBackgroundColor) return EC_INVALID_PARAM;
        if (activeCellBackgroundColor!=CLI_DRAWING_ECOLORREF_CONST_UNDEFINED || !ownerGrid)
           {
            *_activeCellBackgroundColor = activeCellBackgroundColor;
            return EC_OK;
           }
        return ownerGrid->activeCellBackgroundColorGet( _activeCellBackgroundColor );
       }

    CLIMETHOD(activeCellBackgroundColorSet) (THIS_ COLORREF    _activeCellBackgroundColor /* [in] colorref  activeCellBackgroundColor  */
                                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                                            )
       {
        activeCellBackgroundColor = _activeCellBackgroundColor;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(activeCellBackgroundColorSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }


    CLIMETHOD(cellsGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL**    _cells /* [out] ::cli::gui::cellgrid::iCell* cells  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                        )
       {
        if (!_cells) return EC_INVALID_PARAM;
        if (idx1>=cellsVector.size()) return EC_OUT_OF_RANGE;
        *_cells = cellsVector[idx1];
        return EC_OK;
       }

    CLIMETHOD(cellsSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       {
        if (size) *size = cellsVector.size();
        return EC_OK;
       }

    CLIMETHOD(ownerGridGet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID**    _ownerGrid /* [out] ::cli::gui::cellgrid::iGrid* ownerGrid  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       {
        if (_ownerGrid) *_ownerGrid = ownerGrid;
        return EC_OK;
       }

    CLIMETHOD(ownerGridSet) (THIS_ INTERFACE_CLI_GUI_CELLGRID_IGRID*    _ownerGrid /* [in] ::cli::gui::cellgrid::iGrid*  ownerGrid  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       {
        ownerGrid = _ownerGrid;
        this->allCellsSizeChangedNotify( SIZE_T_NPOS, TRUE);
        //buildCellSizesCache(idx1);
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(ownerGridSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

    CLIMETHOD(getIUnknownIndex) (THIS_ INTERFACE_CLI_IUNKNOWN*    pcell /* [in] ::cli::iUnknown*  pcell  */
                                     , SIZE_T*    idxFound /* [out] size_t idxFound  */
                                )
       {
        if (!pcell || !idxFound) return EC_INVALID_PARAM;
        SIZE_T curIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++curIdx)
           {
            if (::cli::isObjectEqualTo( *it, pcell ))
               {
                *idxFound = curIdx;
                return EC_OK;
               }
           }
        return EC_NOT_FOUND;
       }

    CLIMETHOD(getCellIndex) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL*    pcell /* [in] ::cli::gui::cellgrid::iCell*  pcell  */
                                 , SIZE_T*    idxFound /* [out] size_t idxFound  */
                            )
       {
        if (!pcell || !idxFound) return EC_INVALID_PARAM;

        ::cli::iUnknown *punk = 0;

        RCODE res = pcell->queryInterface( ::cli::iidOf( (::cli::iUnknown*)0 ), (VOID**)&punk);
        if (res) return res; // queryInterface failed

        res = getIUnknownIndex( punk, idxFound );
        punk->release();

        return res;
       }

    CLIMETHOD(spacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [out] ::cli::gui::cellgrid::CSpacing spacing  */)
       {
        if (!_spacing) return EC_INVALID_PARAM;
        if (selfSpacingUsed || !ownerGrid)
           {
            *_spacing = selfSpacing; 
            return EC_OK;
           }

        return ownerGrid->rowSpacingGet( _spacing );
       }

    CLIMETHOD(spacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _spacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  spacing  */)
       {
        if (!_spacing) return EC_INVALID_PARAM;
        selfSpacing = *_spacing;
        selfSpacingUsed = true;
        return EC_OK;
       }

    CLIMETHOD(resetSpacing) (THIS_ SIZE_T    idx1 /* [in] size_t  idx1  */)
       {
        selfSpacingUsed = false;
        return EC_OK;
       }

    CLIMETHOD(cellSpacingGet) (THIS_ STRUCT_CLI_GUI_CELLGRID_CSPACING*    _cellSpacing /* [out] ::cli::gui::cellgrid::CSpacing cellSpacing  */)
       {
        if (!_cellSpacing) return EC_INVALID_PARAM;
        if (selfCellSpacingUsed || !ownerGrid)
           {
            *_cellSpacing = selfCellSpacing; 
            return EC_OK;
           }
        return ownerGrid->cellSpacingGet( _cellSpacing );
       }

    CLIMETHOD(cellSpacingSet) (THIS_ const STRUCT_CLI_GUI_CELLGRID_CSPACING*    _cellSpacing /* [in,ref] ::cli::gui::cellgrid::CSpacing  cellSpacing  */)
       {
        if (!_cellSpacing) return EC_INVALID_PARAM;
        selfCellSpacing = *_cellSpacing;
        selfCellSpacingUsed = true;
        return EC_OK;
       }

    CLIMETHOD(resetCellSpacing) (THIS_ SIZE_T    idx1 /* [in] size_t  idx1  */)
       {
        selfCellSpacingUsed = false;
        return EC_OK;
       }

    CLIMETHOD(drawBackgroundGet) (THIS_ BOOL*    _drawBackground /* [out] bool drawBackground  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
       {
        if (!_drawBackground) return EC_INVALID_PARAM;
        if (drawBackground!=CLI_EBOOL_CONST_UNDEFINED || !ownerGrid)
           {
            *_drawBackground = drawBackground ? TRUE : FALSE;
            return EC_OK;
           }
        return ownerGrid->rowDrawBackgroundGet( _drawBackground );
       }

    CLIMETHOD(drawBackgroundSet) (THIS_ BOOL    _drawBackground /* [in] bool  drawBackground  */
                                      , SIZE_T    idx1 /* [in] size_t  idx1  */
                                 )
       {
        drawBackground = _drawBackground ? true : false;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(drawBackgroundSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

#if 0
    CLIMETHOD(resetDrawBackground) (THIS_ SIZE_T    idx1 /* [in] size_t  idx1  */)
       {
        selfDrawBackgroundUsed = false;
        return EC_OK;
       }
#endif

    CLIMETHOD(backgroundColorGet) (THIS_ COLORREF*    _backgroundColor /* [out] colorref backgroundColor  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
       {
        if (!_backgroundColor) return EC_INVALID_PARAM;
        if (selfRowBackground!=CLI_DRAWING_ECOLORREF_CONST_UNDEFINED || !ownerGrid)
           {
            *_backgroundColor = selfRowBackground; 
            return EC_OK;
           }
        return ownerGrid->rowBackgroundColorGet( _backgroundColor );
       }

    CLIMETHOD(backgroundColorSet) (THIS_ COLORREF    _backgroundColor /* [in] colorref  backgroundColor  */
                                       , SIZE_T    idx1 /* [in] size_t  idx1  */
                                  )
       {
        if (!_backgroundColor) return EC_INVALID_PARAM;
        selfRowBackground = _backgroundColor;
        //selfRowBackgroundUsed = true;
        return EC_OK;
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(backgroundColorSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

#if 0
    CLIMETHOD(resetBackgroundColor) (THIS_ SIZE_T    idx1 /* [in] size_t  idx1  */)
       {
        selfRowBackgroundUsed = false;
        return EC_OK;
       }
#endif

    CLIMETHOD(sizeGet) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    size /* [out] ::cli::drawing::CPoint size  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                       )
       {
        if (!size) return EC_INVALID_PARAM;

        STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing;
        if ( spacingGet(&rowSpacing) )
           { // getSpacing failed
            size->x = 0;
            size->y = 0;
           }
        else
           {
            size->x = rowSpacing.left + rowSpacing.right;
            size->y = rowSpacing.top  + rowSpacing.bottom;
           }

        UINT maxCellHeight = 0;
        SIZE_T cellIdx = 0;

        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            //(*it)->release();
            STRUCT_CLI_GUI_CELLGRID_CSPACING cellSpacing;
            //cellSpacing.left = cellSpacing.right = cellSpacing.top = cellSpacing.bottom = 0;
            cellSpacing = makeSpacing(0,0,0,0);
            (*it)->spacingGet( &cellSpacing, idx1, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT cellSize;
            if ((*it)->sizeGet( &cellSize, idx1, cellIdx))
               continue;
            size->x += cellSize.x + cellSpacing.left + cellSpacing.right;
            UINT cellHeight = cellSize.y + cellSpacing.top + cellSpacing.bottom;
            if (maxCellHeight < cellHeight) maxCellHeight = cellHeight;
           }

        size->y += (INT)maxCellHeight;

        return EC_OK;
       }

    CLIMETHOD(sizeSet) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    size /* [in,ref] ::cli::drawing::CPoint  size  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                       )
       {
        if (!size) return EC_INVALID_PARAM;
        RCODE res = sizeXSet( (UINT)size->x, idx1 );
        if (res) return res;
        return      sizeYSet( (UINT)size->y, idx1 );
       }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(sizeSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

    CLIMETHOD(sizeXGet) (THIS_ UINT*    sizeX /* [out] uint sizeX  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                        )
       {
        if (!sizeX) return EC_INVALID_PARAM;

        STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing;
        if ( spacingGet(&rowSpacing) )
            *sizeX = 0;
        else
            *sizeX = rowSpacing.left + rowSpacing.right;

        SIZE_T cellIdx = 0;

        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            STRUCT_CLI_GUI_CELLGRID_CSPACING cellSpacing;
            cellSpacing.left = cellSpacing.right = cellSpacing.top = cellSpacing.bottom = 0;
            (*it)->spacingGet( &cellSpacing, idx1, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT cellSize;
            if ((*it)->sizeGet( &cellSize, idx1, cellIdx))
               continue;
            *sizeX += cellSize.x + cellSpacing.left + cellSpacing.right;
           }
        return EC_OK;
       }

    CLIMETHOD(sizeXSet) (THIS_ UINT    sizeX /* [in] uint  sizeX  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                        )
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(sizeXSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

    CLIMETHOD(sizeYGet) (THIS_ UINT*    sizeY /* [out] uint sizeY  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                        )
       {
        if (!sizeY) return EC_INVALID_PARAM;

        STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing;
        if ( spacingGet(&rowSpacing) )
            *sizeY = 0;
        else
            *sizeY = rowSpacing.top  + rowSpacing.bottom;

        UINT maxCellHeight = 0;
        SIZE_T cellIdx = 0;

        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            STRUCT_CLI_GUI_CELLGRID_CSPACING cellSpacing;
            cellSpacing.left = cellSpacing.right = cellSpacing.top = cellSpacing.bottom = 0;
            (*it)->spacingGet( &cellSpacing, idx1, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT cellSize;
            if ((*it)->sizeGet( &cellSize, idx1, cellIdx))
               continue;
            UINT cellHeight = cellSize.y + cellSpacing.top + cellSpacing.bottom;
            if (maxCellHeight < cellHeight) maxCellHeight = cellHeight;
           }

        *sizeY += (INT)maxCellHeight;

        return EC_OK;
       }

    CLIMETHOD(sizeYSet) (THIS_ UINT    sizeY /* [in] uint  sizeY  */
                             , SIZE_T    idx1 /* [in] size_t  idx1  */
                        )
       { CLIASSERT(0); return EC_NOT_IMPLEMENTED; }

    // this method is automaticaly generated for indexed property and not used at all
    CLIMETHOD(sizeYSize) (THIS_ SIZE_T*    size /* [out] size_t size  */)
       { return EC_OK; }

    CLIMETHOD(insertCell) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL*    pCell /* [in] ::cli::gui::cellgrid::iCell*  pCell  */
                               , SIZE_T    atPos /* [in] size_t  atPos  */
                          )
       {
        CLI_TRY{
                if (!pCell) return EC_INVALID_PARAM;
                if (atPos >= cellsVector.size() )
                   cellsVector.push_back(pCell);
                else
                   cellsVector.insert( cellsVector.begin()+atPos, pCell );
                pCell->addRef();

                SIZE_T rowIdx = 0;
                if (ownerGrid) ownerGrid->getRowIndex(this, &rowIdx);
                SIZE_T cellIdx = 0;
                this->getCellIndex(pCell, &cellIdx);

                pCell->ownerRowSet( static_cast<INTERFACE_CLI_GUI_CELLGRID_IROW*>(this), rowIdx, cellIdx );

                //buildCellSizesCache(rowIdx);
                this->allCellsSizeChangedNotify(rowIdx, TRUE);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(addCell) (THIS_ INTERFACE_CLI_GUI_CELLGRID_ICELL*    pCell /* [in] ::cli::gui::cellgrid::iCell*  pCell  */)
       {
        CLI_TRY{
                if (!pCell) return EC_INVALID_PARAM;
                cellsVector.push_back(pCell);
                pCell->addRef();

                SIZE_T rowIdx = 0;
                if (ownerGrid) ownerGrid->getRowIndex(this, &rowIdx);
                SIZE_T cellIdx = 0;
                this->getCellIndex(pCell, &cellIdx);

                pCell->ownerRowSet( static_cast<INTERFACE_CLI_GUI_CELLGRID_IROW*>(this), rowIdx, cellIdx );

                //buildCellSizesCache(rowIdx);
                this->allCellsSizeChangedNotify(rowIdx, TRUE);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(removeCell) (THIS_ SIZE_T    atPos /* [in] size_t  atPos  */)
       {
        CLI_TRY{
                if (atPos>=cellsVector.size()) return EC_INVALID_PARAM;
                INTERFACE_CLI_GUI_CELLGRID_ICELL *pCell = cellsVector[atPos];

                SIZE_T rowIdx = 0;
                if (ownerGrid) ownerGrid->getRowIndex(this, &rowIdx);
                pCell->ownerRowSet( 0, rowIdx, atPos );

                cellsVector.erase( cellsVector.begin() + atPos );
                pCell->release();
                this->allCellsSizeChangedNotify(rowIdx, TRUE);
                //buildCellSizesCache(rowIdx);
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       }

    CLIMETHOD(getLimits) (THIS_ STRUCT_CLI_DRAWING_CPOINT*    minSize /* [out] ::cli::drawing::CPoint minSize  */
                              , STRUCT_CLI_DRAWING_CPOINT*    maxSize /* [out] ::cli::drawing::CPoint maxSize  */
                              , SIZE_T    idx1 /* [in] size_t  idx1  */
                         )
       {
        if (!minSize || !maxSize) return EC_INVALID_PARAM;

        STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing;
        if ( spacingGet(&rowSpacing) )
           { // getSpacing failed
            minSize->x = 0;
            minSize->y = 0;
    
            maxSize->x = 0;
            maxSize->y = 0;
           }
        else
           {
            minSize->x = rowSpacing.left + rowSpacing.right;
            minSize->y = rowSpacing.top  + rowSpacing.bottom;

            maxSize->x = rowSpacing.left + rowSpacing.right;
            maxSize->y = rowSpacing.top  + rowSpacing.bottom;
           }

        SIZE_T cellIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            STRUCT_CLI_GUI_CELLGRID_CSPACING cellSpacing;
            cellSpacing.left = cellSpacing.right = cellSpacing.top = cellSpacing.bottom = 0;
            (*it)->spacingGet( &cellSpacing, idx1, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT cellMins, cellMaxs;
            if ((*it)->getLimits(&cellMins, &cellMaxs, idx1, cellIdx))
               continue;

            // ������� �� X - ����� ��������� � spacing'�� �����
            minSize->x += cellMins.x + cellSpacing.left + cellSpacing.right;
            
            // �������� �� X - ����� ���������� ��� CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX, ���� ���� ���� ������ 
            // �� ���������� �� ������
            maxSize->x += cellMaxs.x + cellSpacing.left + cellSpacing.right;

            INT minHeight = cellSpacing.top + cellSpacing.bottom + cellMins.y + rowSpacing.top + rowSpacing.bottom;
            //  ������� �� Y - ������������ ������� �� ��������� �����
            if (minSize->y < minHeight) minSize->y = minHeight;

            // �������� �� Y - ������������ �������� 
            INT maxHeight = cellSpacing.top + cellSpacing.bottom + cellMaxs.y + rowSpacing.top + rowSpacing.bottom;
            if (maxSize->y < maxHeight) maxSize->y = maxHeight;
           }

        if (maxSize->x >= CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX)
            maxSize->x = CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX;

        if (maxSize->y >= CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX)
            maxSize->y = CLI_GUI_CELLGRID_ECELLLIMITS_MAXSIZEX;

        return EC_OK;
       }

    CLIMETHOD(updateConfig) (THIS_ INTERFACE_CLI_APP_ICONFIG*    appCfg /* [in] ::cli::app::iConfig*  appCfg  */
                                 , SIZE_T    idx1 /* [in] size_t  idx1  */
                            )
       {
        SIZE_T cellIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            (*it)->updateConfig(appCfg, idx1, cellIdx);
           }
        return EC_OK;
       }

    CLIMETHOD(calculateLimits) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                    , SIZE_T    idx1 /* [in] size_t  idx1  */
                               )
       {
        SIZE_T cellIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            (*it)->calculateLimits(pdc, idx1, cellIdx);
           }
        return EC_OK;
       }

    CLIMETHOD(ncPaint) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                            , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                            , SIZE_T    idx1 /* [in] size_t  idx1  */
                       )
       {
        if (!pdc || !paintAreaSize) return EC_INVALID_PARAM;
        //CLIASSERT(0); 
        //return EC_NOT_IMPLEMENTED;
        return EC_OK;
       }

    CLIMETHOD(paintClientAux) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                , SIZE_T thisRowIdx /* [in] size_t  idx1  */
                                , SIZE_T drawOnlyCellIdx /* [in] size_t  idx1  */
                           )
       {
        if (!pdc || !paintAreaSize) return EC_INVALID_PARAM;

        CLIASSERT(cellsVector.size()==cachedCellSizes.size());
        if (cellsVector.size()!=cachedCellSizes.size()) return EC_INVALID_OBJECT_STATE;


        SIZE_T cellIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        ::std::vector< CCellPosSize >::const_iterator        sizeIt = cachedCellSizes.begin();
        for(; it!=cellsVector.end(); ++it, ++sizeIt, ++cellIdx) 
           {
            bool drawThisCell = false;
            if (drawOnlyCellIdx==SIZE_T_NPOS || drawOnlyCellIdx==cellIdx)
               drawThisCell = true;

            if (!drawThisCell) continue;

            BOOL drawCellBackground = TRUE;
            (*it)->drawBackgroundGet( &drawCellBackground, thisRowIdx, cellIdx);

            BOOL activeCell = FALSE;
            (*it)->activeCellGet( &activeCell, thisRowIdx, cellIdx );

            ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK hotTrackedFlags = 0;
            (*it)->autoHotTrackGet( &hotTrackedFlags, thisRowIdx, cellIdx );

            COLORREF cellBackgroundColor = 0;
            if (activeCell && (hotTrackedFlags&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND))
               (*it)->activeBackgroundColorGet( &cellBackgroundColor, thisRowIdx, cellIdx );
            else
               (*it)->backgroundColorGet( &cellBackgroundColor, thisRowIdx, cellIdx );

            COLORREF rowBackgroundColor = cellBackgroundColor;
            this->backgroundColorGet( &rowBackgroundColor, thisRowIdx );

            if (drawCellBackground && (rowBackgroundColor!=cellBackgroundColor  /* || drawOnlyCellIdx!=SIZE_T_NPOS */ ))
               {
                using ::cli::drawing::dc::CAutoViewport ;
                using ::cli::drawing::dc::CAutoBrush    ;
                CAutoViewport avp( pdc, sizeIt->ncPosSize.leftTop, sizeIt->ncPosSize.widthHeight);
                STRUCT_CLI_DRAWING_CPOINT zeroPoint = makePoint(0,0);
                CAutoBrush ab(pdc, cellBackgroundColor);
                pdc->fillRectWH(&zeroPoint, &sizeIt->ncPosSize.widthHeight);
               }
            // set viewport to fit non-client area
               {
                CAutoViewport avp( pdc, sizeIt->ncPosSize.leftTop, sizeIt->ncPosSize.widthHeight);
                (*it)->ncPaint(pdc, &sizeIt->ncPosSize.widthHeight, thisRowIdx, cellIdx);
               }

            if (activeCell && (hotTrackedFlags&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT))
               {
                pdc->setColorScaling( 115, 100 );
               }
            // set viewport to fit non-client area
               {
                CAutoViewport avp( pdc, sizeIt->clientPosSize.leftTop, sizeIt->clientPosSize.widthHeight);
                (*it)->paintClient(pdc, &sizeIt->clientPosSize.widthHeight, thisRowIdx, cellIdx);
               }

            if (activeCell && (hotTrackedFlags&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT))
               {
                pdc->resetColorScaling( );
               }
           }
        return EC_OK;
       }
        

#if 0
    CLIMETHOD(paintClientAux) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                , SIZE_T thisRowIdx /* [in] size_t  idx1  */
                                , SIZE_T drawOnlyCellIdx /* [in] size_t  idx1  */
                           )
       {
        if (!pdc || !paintAreaSize) return EC_INVALID_PARAM;
        //CLIASSERT(0); return EC_NOT_IMPLEMENTED;
        UINT cellLeft = 0;
        SIZE_T cellIdx = 0;
        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            //CLITRACE2(L"iRow::paintClientAux, painting cell cell %1 (row %2) ", (UINT)cellIdx, (UINT)thisRowIdx );
            STRUCT_CLI_GUI_CELLGRID_CSPACING cellSpacing = makeSpacing(0,0,0,0);
            (*it)->spacingGet( &cellSpacing, thisRowIdx, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT cellSize = makePoint( 0, 0 );
            (*it)->sizeGet( &cellSize, thisRowIdx, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT leftTop     = makePoint( cellLeft, 0 );
            STRUCT_CLI_DRAWING_CPOINT widthHeight = cellSize;
            widthHeight.x += cellSpacing.left + cellSpacing.right;
            widthHeight.y += cellSpacing.top  + cellSpacing.bottom;

            bool drawThisCell = false;
            if (drawOnlyCellIdx==SIZE_T_NPOS || drawOnlyCellIdx==cellIdx)
               drawThisCell = true;

            if (!drawThisCell)
               {
                //CLITRACE1(L"iRow::paintClientAux, skip painting cell, cell is not a only %1 ", (UINT)drawOnlyCellIdx );
                leftTop.x += cellSpacing.left;
                leftTop.y += cellSpacing.top;
                cellLeft += cellSpacing.left + cellSpacing.right + cellSize.x;
                continue;
               }

            //CLITRACE(L"iRow::paintClientAux, painting cell, cell is only drawed or all cells drawing allowed");

            BOOL drawCellBackground = TRUE;
            (*it)->drawBackgroundGet( &drawCellBackground, thisRowIdx, cellIdx);

            BOOL activeCell = FALSE;
            (*it)->activeCellGet( &activeCell, thisRowIdx, cellIdx );

            ENUM_CLI_GUI_CELLGRID_ECELLHOTTRACK hotTrackedFlags = 0;
            (*it)->autoHotTrackGet( &hotTrackedFlags, thisRowIdx, cellIdx );

            COLORREF cellBackgroundColor = 0;
            if (activeCell && (hotTrackedFlags&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKBACKGROUND))
               (*it)->activeBackgroundColorGet( &cellBackgroundColor, thisRowIdx, cellIdx );
            else
               (*it)->backgroundColorGet( &cellBackgroundColor, thisRowIdx, cellIdx );

            //COLORREF ownerRowCellBackgroundColor = cellBackgroundColor;
            //if (ownerGrid) ownerRow->backgroundColorGet( &ownerRowCellBackgroundColor, thisRowIdx );
            COLORREF rowBackgroundColor = cellBackgroundColor;
            this->backgroundColorGet( &rowBackgroundColor, thisRowIdx );

            if (drawCellBackground && (rowBackgroundColor!=cellBackgroundColor  /* || drawOnlyCellIdx!=SIZE_T_NPOS */ ))
               {
                using ::cli::drawing::dc::CAutoViewport ;
                using ::cli::drawing::dc::CAutoBrush    ;
                CAutoViewport avp( pdc, leftTop, widthHeight);
                STRUCT_CLI_DRAWING_CPOINT zeroPoint = makePoint(0,0);
                CAutoBrush ab(pdc, cellBackgroundColor);
                pdc->fillRectWH(&zeroPoint, &widthHeight);
               }

              { CAutoViewport avp( pdc, leftTop, widthHeight);
                //pdc->pushSetViewportWH( &leftTop, &widthHeight );
                (*it)->ncPaint(pdc, &widthHeight, thisRowIdx, cellIdx);
                //pdc->popViewport();
              }

            if (activeCell && (hotTrackedFlags&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT))
               {
                pdc->setColorScaling( 115, 100 );
               }
            // adjust left-top with row spacing
            leftTop.x += cellSpacing.left;
            leftTop.y += cellSpacing.top;

              { CAutoViewport avp( pdc, leftTop, cellSize);
                //pdc->pushSetViewportWH( &leftTop, &cellSize );
                (*it)->paintClient(pdc, &cellSize, thisRowIdx, cellIdx);
                //pdc->popViewport();
              }

            cellLeft += cellSpacing.left + cellSpacing.right + cellSize.x;

            if (activeCell && (hotTrackedFlags&CLI_GUI_CELLGRID_ECELLHOTTRACK_HOTTRACKHIGHLIGHT))
               {
                pdc->resetColorScaling( );
               }

           }
        return EC_OK;
       }
#endif


    CLIMETHOD(paintClient) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                                , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                                , SIZE_T    idx1 /* [in] size_t  idx1  */
                           )
       {
        //CLITRACE1(L"iRow::paintClient, paint all row at time, row %1 ", (UINT)idx1 );
        return this->paintClientAux(pdc, paintAreaSize, idx1, SIZE_T_NPOS );
       }



    CLIMETHOD(paintCell) (THIS_ INTERFACE_CLI_DRAWING_IDRAWCONTEXT1*    pdc /* [in] ::cli::drawing::iDrawContext1*  pdc  */
                              , const STRUCT_CLI_DRAWING_CPOINT*    paintAreaSize /* [in,ref] ::cli::drawing::CPoint  paintAreaSize  */
                              , SIZE_T    rowIdx /* [in] size_t  rowIdx  */
                              , SIZE_T    cellIdx /* [in] size_t  cellIdx  */
                         )
       {
        //CLITRACE2(L"iRow::paintClient, paint one cell, row %1, cell %2 ", (UINT)rowIdx, (UINT)cellIdx );
        return this->paintClientAux(pdc, paintAreaSize, rowIdx, cellIdx );
       }

    CLIMETHOD(hitTest) (THIS_ SIZE_T    thisRowIndex /* [in] size_t  thisRowIndex  */
                            , const STRUCT_CLI_DRAWING_CPOINT*    micePos /* [in,ref] ::cli::drawing::CPoint  micePos  */
                            , SIZE_T*    hitCell /* [out] size_t hitCell  */
                            , ENUM_CLI_GUI_CELLGRID_EHITTESTFLAGS*    resFlags /* [out] ::cli::gui::cellgrid::EHitTestFlags resFlags  */
                       )
       {
        if (!micePos || !hitCell) return EC_INVALID_PARAM;


        ::std::vector< CCellPosSize >::iterator csIt = cachedCellSizes.begin();
        for(; csIt!=cachedCellSizes.end(); ++csIt)
           {
            STRUCT_CLI_DRAWING_CPOINT  cellMicePosClient = *micePos;
            cellMicePosClient.x -= csIt->clientPosSize.leftTop.x;
            cellMicePosClient.y -= csIt->clientPosSize.leftTop.y;
            if (testRectHit( cellMicePosClient, csIt->clientPosSize.widthHeight ))
               {
                *hitCell  = csIt-cachedCellSizes.begin();
                *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT;
                return EC_OK;
               }

            STRUCT_CLI_DRAWING_CPOINT  cellMicePosNc = *micePos;
            cellMicePosNc.x -= csIt->ncPosSize.leftTop.x;
            cellMicePosNc.y -= csIt->ncPosSize.leftTop.y;
            if (testRectHit( cellMicePosNc, csIt->ncPosSize.widthHeight ))
               {
                *hitCell  = csIt-cachedCellSizes.begin();
                *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING;
                return EC_OK;
               }
           }

        #if 0
        SIZE_T cellIdx = 0;

        UINT cellLeft = 0;

        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it, ++cellIdx) 
           {
            //(*it)->release();
            STRUCT_CLI_GUI_CELLGRID_CSPACING cellSpacing;
            //cellSpacing.left = cellSpacing.right = cellSpacing.top = cellSpacing.bottom = 0;
            cellSpacing = makeSpacing(0,0,0,0);
            (*it)->spacingGet( &cellSpacing, thisRowIndex, cellIdx );

            STRUCT_CLI_DRAWING_CPOINT cellSize;
            if ((*it)->sizeGet( &cellSize, thisRowIndex, cellIdx))
               continue;


            STRUCT_CLI_DRAWING_CPOINT  cellMicePos = *micePos;
            cellMicePos.x -= cellLeft;

            if (testSpacingHit(cellMicePos, cellSize, cellSpacing) )
               {
                *hitCell  = cellIdx;
                *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLSPACING;
                return EC_OK;
               }

            cellMicePos.x -= cellSpacing.left;
            cellMicePos.y -= cellSpacing.top;

            if (!testRectHit( cellMicePos, cellSize ))
               {
                cellLeft += cellSpacing.left + cellSpacing.right + cellSize.x;
                continue;
               }
            /*
            if (cellMicePos.x<0 || cellMicePos.x >=cellSize.x)
               { // not hit in row
                cellLeft += cellSpacing.left + cellSpacing.right + cellSize.x;
                continue;
               }

            if (cellMicePos.y<0 || cellMicePos.y >=cellSize.y)
               { // not hit in row
                cellLeft += cellSpacing.left + cellSpacing.right + cellSize.x;
                continue;
               }
            */

            *hitCell  = cellIdx;
            *resFlags |= CLI_GUI_CELLGRID_EHITTESTFLAGS_CELLHIT;
            return EC_OK;
           }
        #endif
        return EC_TEST_FAILED;
       }


#if 0
    CLIMETHOD(setSize) (THIS_ const STRUCT_CLI_DRAWING_CPOINT*    size /* [in,ref] ::cli::drawing::CPoint  size  */
                            , STRUCT_CLI_DRAWING_CPOINT*    sizeApplied /* [out] ::cli::drawing::CPoint sizeApplied  */
                            , ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS*    resFlags /* [out,optional] ::cli::gui::cellgrid::ESetSizeResultFlags resFlags  */
                       )
       {
        if (!size) return EC_INVALID_PARAM;
        UINT xApplied = 0, yApplied = 0;
        ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS  xResFlags = 0, yResFlags = 0;
        //UINT x = size->x, y = size->y;
        RCODE 
        res = setSizeX( (UINT)size->x, &xApplied, &xResFlags);
        if (res) return res;

        res = setSizeY( (UINT)size->y, &yApplied, &yResFlags);
        if (res) return res;

        if (resFlags) *resFlags = xResFlags | yResFlags;
        if (sizeApplied)
           {
            sizeApplied->x = (INT)xApplied;
            sizeApplied->y = (INT)yApplied;
           }
        return res;
       }

    CLIMETHOD(setSizeX) (THIS_ UINT    x /* [in] uint  x  */
                             , UINT*   arg_xApplied /* [out] uint xApplied  */
                             , ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS*    arg_resFlags /* [out,optional] ::cli::gui::cellgrid::ESetSizeResultFlags resFlags  */
                        )
       {
        CLI_TRY{
                STRUCT_CLI_GUI_CELLGRID_CSPACING rowSpacing = makeSpacing( 0, 0, 0, 0);
                spacingGet(&rowSpacing);

                std::vector< SIZE_T >   cellsIndexes;
                SIZE_T curCellIdx = 0;
                UINT fixedWidth = rowSpacing.left + rowSpacing.right;

                // put all rows in direct order
                for(; curCellIdx!=cellsVector.size(); ++curCellIdx )
                   cellsIndexes.push_back(curRowIdx); 

                while(!cellsIndexes.empty() || (INT)fixedWidth < x)
                   {
                    UINT sizeAllreadyCalculatedAtStep = fixedWidth;
                    for(SIZE_T cellIndexIndex = 0; cellIndexIndex!=cellsIndexes.size();  /* ++rowIndexIndex */ )
                       {
                        UINT sizeEllapsed = 0;
                        if ((INT)sizeAllreadyCalculatedAtStep < x)
                           sizeEllapsed = x - sizeAllreadyCalculatedAtStep;
                        
                        // number of cells, that are waiting for further processing at step
                        SIZE_T cellsNotProcessedAtStep = cellsIndexes.size() - celIndexIndex;
                        // calculates width, that we try to set for cell
                        UINT requestWidth = sizeEllapsed / (UINT)cellsNotProcessedAtStep;
                        if (sizeEllapsed % (INT)cellsNotProcessedAtStep)
                           ++requestWidth;

                        const SIZE_T cellIndex = cellsIndexes[cellIndexIndex];
                        ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS    resFlags;
                        UINT xApplied = 0;

                        using ::cli::drawing::makePoint;

                        STRUCT_CLI_DRAWING_CPOINT cellMins = makePoint(0,0), cellMaxs = makePoint(0,0);
                        if ((*it)->getLimits(&cellMins, &cellMaxs))
                           continue;


                        if (cellsVector[cellIndex]->setSizeX( requestWidth, &xApplied, &resFlags))
                           { // ��������� ����, ������� ������ �� ���������
                            cellsIndexes.erase(cellsIndexes.begin()+cellIndexIndex);
                            continue;
                           }

                        if (resFlags&CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_XMASK)
                           { // ��������� ���� �� ��������
                            // ����������� ������ ������������ �� ������ ���� �������
                            sizeAllreadyCalculatedAtStep += xApplied; 
                            // ����������� ��������� ������ ������������� �������
                            fixedWidth += xApplied; 
                            cellsIndexes.erase(cellsIndexes.begin()+cellIndexIndex); // � ������� �� ���������
                            continue;
                           }

                        // ����������� ������ ������������ �� ������ ���� �������
                        sizeAllreadyCalculatedAtStep += xApplied; 
                        ++cellIndexIndex; // ��������� � ��������� ������
                       } // for

                    if ((INT)sizeAllreadyCalculatedAtStep>=x || cellsIndexes.empty())
                       {
                        if (arg_xApplied) arg_xApplied = sizeAllreadyCalculatedAtStep;
                        break;
                       }
                   } // while
               }
        CLI_CATCH_RETURN_CLI_EXCEPTION()
        CLI_CATCH_RETURN_STD_EXCEPTIONS()
        return EC_OK;
       
       }

    CLIMETHOD(setSizeY) (THIS_ UINT    y /* [in] uint  y  */
                             , UINT*    _yApplied /* [out] uint yApplied  */
                             , ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS*    _resFlags /* [out,optional] ::cli::gui::cellgrid::ESetSizeResultFlags resFlags  */
                        )
       {
        UINT                                         yApplied = 0;
        ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS    resFlags = 0;

        std::vector<INTERFACE_CLI_GUI_CELLGRID_ICELL*>::iterator it = cellsVector.begin();
        for(; it!=cellsVector.end(); ++it) 
           {
            UINT cellAppliedY = 0;
            ENUM_CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS    cellSizeFlags = 0;
            if ((*it)->setSizeY( y, &cellAppliedY, &cellSizeFlags))
               continue;
            if (yApplied<cellAppliedY) 
               {
                yApplied = cellAppliedY;
                resFlags |= (cellSizeFlags&(CLI_GUI_CELLGRID_ESETSIZERESULTFLAGS_YMASK));
               }
           }
        return EC_OK;
       }
#endif // 0


}; // CRowImpl






}; // namespace impl
}; // namespace cli





#endif /* CORE_GUI_GRIDS_CELLGRIDROWIMPL_H */

