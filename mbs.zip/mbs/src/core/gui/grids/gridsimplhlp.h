#ifndef CORE_GUI_GRIDS_GRIDSIMPLHLP_H
#define CORE_GUI_GRIDS_GRIDSIMPLHLP_H

#ifndef CLI_GUI_CELLGRID_H
    #include <cli/gui/cellgrid.h>
#endif

namespace cli
{
namespace impl
{

struct CPosSize
{
    STRUCT_CLI_DRAWING_CPOINT  leftTop;
    STRUCT_CLI_DRAWING_CPOINT  widthHeight;
    CPosSize() : leftTop(), widthHeight() {}
    CPosSize( const STRUCT_CLI_DRAWING_CPOINT &lt, const STRUCT_CLI_DRAWING_CPOINT &wh)
       : leftTop(lt), widthHeight(wh)
       { }
};


struct CCellPosSize
{
    CPosSize ncPosSize;
    CPosSize clientPosSize;

    CCellPosSize() : ncPosSize(), clientPosSize() {}
    CCellPosSize(const CPosSize &nc, const CPosSize &client) : ncPosSize(nc), clientPosSize(client) { }
};

typedef CCellPosSize CRowPosSize;


inline 
bool isEmptySpacing( const STRUCT_CLI_GUI_CELLGRID_CSPACING &spacing )
   {
    //return spacing.top==0 && spacing.left==spacing.top && spacing.right==spacing.bottom && spacing.left==spacing.right;
    if (spacing.left) return false;
    if (spacing.top) return false;
    if (spacing.right) return false;
    if (spacing.bottom) return false;
    return true;
   }

inline
bool testRectHit( const STRUCT_CLI_DRAWING_CPOINT        &pos
                , const STRUCT_CLI_DRAWING_CPOINT        &testSize // rect size
                )
   {
    if (pos.x<0 || pos.x>=testSize.x) return false;
    if (pos.y<0 || pos.y>=testSize.y) return false;
    return true;
   }

inline
bool testSpacingHit( const STRUCT_CLI_DRAWING_CPOINT        &pos
                   , const STRUCT_CLI_DRAWING_CPOINT        &testSize
                   , const STRUCT_CLI_GUI_CELLGRID_CSPACING &testSpacing
                   )
   {
    STRUCT_CLI_DRAWING_CPOINT woSpacingPos = pos;
    woSpacingPos.x -= testSpacing.left;
    woSpacingPos.y -= testSpacing.top;

    STRUCT_CLI_DRAWING_CPOINT withSpacingTestSize = testSize;
    withSpacingTestSize.x += testSpacing.left + testSpacing.right;
    withSpacingTestSize.y += testSpacing.top  + testSpacing.bottom;

    return testRectHit(pos, withSpacingTestSize) && !testRectHit(woSpacingPos, testSize);
/*
    // �஢��塞, �� ������ �� � ᯥ�ᨭ�
    // ᫥��
    if ( pos.x>=0 && pos.x<(int)testSpacing.left )
        return true;

    // �ࠢ�
    if (pos.x>=int(testSpacing.left+testSize.x) && pos.x < int(testSpacing.left+testSize.x+testSpacing.right))
       return true;

    // ᢥ���
    if (pos.y >=0 && pos.y < (int)testSpacing.top)
       return true;

    // ᭨��
    if (pos.y>=int(testSpacing.top+testSize.x) && pos.x < int(testSpacing.top+testSize.x+testSpacing.bottom))
       return true;

    return false;
*/
   }



}; // namespace impl
}; // namespace cli


#endif /* CORE_GUI_GRIDS_GRIDSIMPLHLP_H */

