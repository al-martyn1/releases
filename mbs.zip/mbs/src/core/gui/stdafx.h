#ifndef WINVER
    #define WINVER      0x0500
#endif

#ifndef _WIN32_WINNT
    #define _WIN32_WINNT    0x0501
#endif

#ifndef _WIN32_IE
    #define _WIN32_IE   0x0501
#endif

#ifndef _RICHEDIT_VER
    #define _RICHEDIT_VER   0x0200
#endif

#ifndef IDTRYAGAIN
    #define IDTRYAGAIN      10
#endif

#ifndef IDCONTINUE
    #define IDCONTINUE      11
#endif


#ifndef RC_INVOKED

    #include <atlbase.h>
    #include <atlapp.h>
    
    extern CAppModule _Module;
    
    #include <atlwin.h>
    
    #include <atlframe.h>
    #include <atlctrls.h>
    #include <atldlgs.h>

#endif


