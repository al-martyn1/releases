/*!
\project �������, ������������ �����.
    \libraries
    \libpath
    \incpath
*/

/*
    \libpath #(BOOST.lib)
    \incpath #(BOOST.include)
*/

#include "stdafx.h"
#include <shlobj.h>

#include <cli/implhlp.h>
#include <cli/interlocked.h>
#include <cli/climod.h>
#include <cli/cligui.h>


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#include "wtlErrorInfoDlgRes.h"
#include "wtlErrorInfoDlg.h"


/*
HGLOBAL LoadResourceLang(HINSTANCE hInst, LPCTSTR resType, DWORD resID, DWORD langID);
WORD LoadStringLang(HINSTANCE hInst, DWORD langID, UINT strID, LPTSTR destStr, WORD strLen);

int load_string(HINSTANCE hInst, DWORD strid, TCHAR* buf, DWORD buf_size, DWORD langid);
int load_string(HINSTANCE hInst, DWORD strid, TCHAR* buf, DWORD buf_size);

tstring load_string(HINSTANCE hInst, DWORD strid, DWORD langid);
tstring load_string(HINSTANCE hInst, DWORD strid);

//---------------------------------------------------------
HGLOBAL LoadResourceLang(HINSTANCE hInst, LPCTSTR resType, DWORD resID, DWORD langID)
{
  // Lookup for langID resource
  HRSRC hrRes=FindResourceEx(hInst, resType, MAKEINTRESOURCE(resID), (WORD)langID);
  if (!hrRes)
     { // Lookup for thread locale resource
      hrRes=FindResourceEx(hInst, resType, MAKEINTRESOURCE(resID), LANGIDFROMLCID(GetThreadLocale()) );
     }
  if (!hrRes)
     { // Lookup for neutral resource
      hrRes=FindResourceEx(hInst, resType, MAKEINTRESOURCE(resID), MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL));
     }
  if (!hrRes)
     { // Lookup for user default lang resource
      hrRes=FindResourceEx(hInst, resType, MAKEINTRESOURCE(resID), GetUserDefaultLangID());
     }
  if (!hrRes)
     { // Lookup for system default lang resource
      hrRes=FindResourceEx(hInst, resType, MAKEINTRESOURCE(resID), GetSystemDefaultLangID());
     }
  if (!hrRes)
     { // Lookup for US English lang resource
      hrRes=FindResourceEx(hInst, resType, MAKEINTRESOURCE(resID), MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US));
     }
  return LoadResource(hInst, hrRes);
}
//---------------------------------------------------------
WORD LoadStringLang(HINSTANCE hInst, DWORD langID, UINT strID, LPTSTR destStr , WORD strLen )
{  
  LPCWSTR str=(LPCWSTR)LoadResourceLang(hInst, RT_STRING, 1+(strID >> 4), langID);
  if (!str)
    return 0;

  for (WORD strPos=0; strPos < (strID & 0x000F); strPos++)
    str+=*str+1;

  if (!strLen)
    return *str;
  if (!destStr)
    return 0;

#ifdef _UNICODE
  lstrcpyn(destStr, str+1, min(strLen, *str+1));
#else
  WideCharToMultiByte(CP_ACP, 0, str+1, *str+1, destStr, strLen, NULL, NULL);
#endif

  destStr[min(strLen-1, *str)]=TEXT('\0');
  return min(strLen, *str+1);
}
//---------------------------------------------------------
int load_string(HINSTANCE hInst, DWORD strid, TCHAR* buf, DWORD buf_size, DWORD langid)
{
    if (!hInst) hInst = _Module.GetModuleInstance();
    return LoadStringLang(hInst, langid, strid, buf, (WORD)buf_size);
}
//---------------------------------------------------------
int load_string(HINSTANCE hInst, DWORD strid, TCHAR* buf, DWORD buf_size)
{
    if (!hInst) hInst = _Module.GetModuleInstance();
    return LoadStringLang(hInst, LANGIDFROMLCID(GetThreadLocale()), strid, buf, (WORD)buf_size);
}
//---------------------------------------------------------
tstring load_string(HINSTANCE hInst, DWORD strid, DWORD langid)
{
    TCHAR buf[1024];
    if (!hInst) hInst = _Module.GetModuleInstance();
    if (LoadStringLang(hInst, langid, strid, buf, CALC_BUF_SIZE(buf)))
       return tstring(buf);
    return tstring(_T("!!! String resource not found !!!"));
}
//---------------------------------------------------------
tstring load_string(HINSTANCE hInst, DWORD strid)
{
    TCHAR buf[1024];
    if (!hInst) hInst = _Module.GetModuleInstance();
    if (LoadStringLang(hInst, LANGIDFROMLCID(GetThreadLocale()), strid, buf, CALC_BUF_SIZE(buf)))
       return tstring(buf);
    return tstring(_T("!!! String resource not found !!!"));
}

*/

extern ::cli::CModule cliModule;

// next line needed only for dll/so
//INIT_CLI_MODULE_NAME(cliModule)

//inline
::std::wstring loadStringW(HINSTANCE hInst, int strId)
   {
    WCHAR buf[1024];
    SIZE_T retSize = LoadStringW( hInst, strId, buf, sizeof(buf)/sizeof(buf[0]) );
    buf [ retSize ] = 0;
    return ::std::wstring(buf, retSize);
   }

//inline
::std::string loadStringA(HINSTANCE hInst, int strId)
   {
    CHAR buf[1024];
    SIZE_T retSize = LoadStringA( hInst, strId, buf, sizeof(buf)/sizeof(buf[0]) );
    buf [ retSize ] = 0;
    return ::std::string(buf, retSize);
   }



template < typename RefCnt >
struct CCliGuiErrorInfoDialogImpl : public INTERFACE_CLI_GUI_IERRORDIALOG
{
    RefCnt counter;
    CCliGuiErrorInfoDialogImpl() : counter(1)
       {
       }

    ~CCliGuiErrorInfoDialogImpl()
       {
       }

    virtual void destroy() 
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP(CCliGuiErrorInfoDialogImpl)
        CLI_IMPLEMENT_INTERFACE(INTERFACE_CLI_GUI_IERRORDIALOG)
    CLI_END_INTERFACE_MAP(CCliGuiErrorInfoDialogImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return (ilint_t)++counter;  }
    CLIMETHOD_(ULONG, release) (THIS)   { if (! --counter) { destroy(); return 0; }  return (ilint_t)counter; }

    CLIMETHOD(showModal) (THIS_ DWORD*    res /* [out] ::cli::gui::DialogResult res  */
                              , WND_HANDLE    parentWnd /* [in] pwnd  parentWnd  */
                              , const WCHAR*    caption /* [in] wchar  caption[]  */
                              , SIZE_T    captionLen /* [in] size_t  captionLen  */
                              , INTERFACE_CLI_IERRORINFO**    errList /* [in] ::cli::iErrorInfo*  errList[]  */
                              , SIZE_T    errListSize /* [in] size_t  errListSize  */
                              , DWORD    flags /* [in] ::cli::gui::ErrorDialogFlags  flags  */
                              , const WCHAR*    locale /* [in] wchar*  locale  */
                         )
       {
        if (!errList || !errListSize)
           {
            return EC_INVALID_PARAM;
           }

        if (flags&CLI_GUI_ERRORDIALOGFLAGS_ONLYLASTERROR)
           {
            ::cli::CiErrorInfo ie(errList[errListSize-1]);

            RCODE code = ie.getErrorCode( );
           
            INTERFACE_CLI_IARGLIST* arglist = 0;
            ie.getArgList( &arglist ); if (arglist) arglist->addRef();
        
            ::std::wstring moduleName; ie.getModuleName( moduleName );
        
            ::std::wstring srcFile; UINT srcLine = 0; ie.getSourceFileLine( srcFile, &srcLine );

            ::std::wstring msg = ::cli::formatErrorMessage( (moduleName.empty() ? 0 : moduleName.c_str())
                                                     , code, 0 // locale
                                                     ,  /* FMF_AUTO_APPEND_LF| */ FMF_IGNORE_FORMAT_LF
                                                     , ::cli::format::arg(arglist)
                                                     );

            msg.append(1, L'\n');
            msg.append( loadStringW( cliModule.getModuleHandle(), IDS_ERRDLG_CODE )
                      + ::cli::format::resultCode( code ) 
                      ); // (L"Code: ");
        

            //MARTY_CON_NS toTstr(loadString( cliModule.getModuleHandle(), IDS_ERRDLG_MESSAGE_DATA )).c_str()

            if (arglist && arglist->getCount()>0 && !(flags&CLI_GUI_ERRORDIALOGFLAGS_HIDEMESSAGEDATA))
               {
                msg.append(1, L'\n');
                msg.append(1, L'\n');
                msg.append( loadStringW( cliModule.getModuleHandle(), IDS_ERRDLG_MESSAGE_DATA ) ); // (L"Code: ");
            
                SIZE_T maxArgs = arglist->getCount();

                for(SIZE_T i=0; i<maxArgs; ++i )
                   {
                    CCliStr tmp_str; CCliStr_init( tmp_str );
                    arglist->getString( i , &tmp_str );
                    ::std::wstring dataStr;
                    CCliStr_copyFromIfModified( dataStr, tmp_str);

                    msg.append(1, L'\n');
                    msg.append(
                               ::cli::format::message(L"    [%1] %2", ::cli::format::arg(int(i+1)) % dataStr )
                              );
                   }
               }

            if (arglist)
               arglist->release();

            #ifdef _DEBUG
            bool showSource = true;
            #else
            bool showSource = false;
            #endif
            if (flags&CLI_GUI_ERRORDIALOGFLAGS_FORCESHOWSOURCE)
               {
                showSource = true;
               }
            else if (flags&CLI_GUI_ERRORDIALOGFLAGS_FORCEHIDESOURCE)
               {
                showSource = false;
               }

            if (showSource)
               {
                msg.append(1, L'\n');
                msg.append(1, L'\n');
                msg.append( loadStringW( cliModule.getModuleHandle(), IDS_ERRDLG_SOURCE ) 
                          + ::cli::format::message(L"%1 : %2", ::cli::format::arg(srcFile) % srcLine )
                          );
               }

            DWORD mbFlags = 0;
            
            switch(flags&CLI_GUI_ERRORDIALOGFLAGS_BUTTONFLAGSMASK)
               {
                case CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON:               mbFlags |= MB_OK;                break;
                case CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON:         mbFlags |= MB_OKCANCEL;          break;
                case CLI_GUI_ERRORDIALOGFLAGS_YESNOBUTTON:            mbFlags |= MB_YESNO;             break;
                case CLI_GUI_ERRORDIALOGFLAGS_YESCANCELBUTTON:        mbFlags |= MB_YESNOCANCEL;       break;
                case CLI_GUI_ERRORDIALOGFLAGS_YESNOCANCELBUTTON:      mbFlags |= MB_YESNOCANCEL;       break;
                case CLI_GUI_ERRORDIALOGFLAGS_RETRYCANCELBUTTON:      mbFlags |= MB_CANCELTRYCONTINUE; break;
                case CLI_GUI_ERRORDIALOGFLAGS_ABORTRETRYIGNOREBUTTON: mbFlags |= MB_ABORTRETRYIGNORE;  break;
                case CLI_GUI_ERRORDIALOGFLAGS_CANCELTRYCONTINUEBUTTON:mbFlags |= MB_CANCELTRYCONTINUE; break;
               }

            if (!mbFlags) mbFlags = MB_OK;

            switch(flags&CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTONFLAGSMASK)
               {
                case CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON1:  mbFlags |= MB_DEFBUTTON1; break;
                case CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON2:  mbFlags |= MB_DEFBUTTON2; break;
                case CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON3:  mbFlags |= MB_DEFBUTTON3; break;
                case CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON4:  mbFlags |= MB_DEFBUTTON4; break;
                default:                                   mbFlags |= MB_DEFBUTTON1;
               }

            switch(code&EC_SEVERITY_MASK)
               {
                case EC_SEVERITY_SUCCESS:          break;
                case EC_SEVERITY_INFORMATIONAL:    mbFlags |= MB_ICONINFORMATION; break;
                case EC_SEVERITY_WARNING:          mbFlags |= MB_ICONWARNING;     break;
                case EC_SEVERITY_ERROR:            mbFlags |= MB_ICONERROR;       break;
               }

            if (!::IsWindow(parentWnd)) parentWnd = 0;

            ::std::wstring captionStr; // = 
            if (caption)
               {
                if (captionLen==SIZE_T_NPOS)
                   captionStr.assign(caption);
                else
                   captionStr.assign(caption, captionLen);
               }
            else
               {
                captionStr.assign( loadStringW( cliModule.getModuleHandle(), IDS_ERRDLG_CAPTION ) );
               }

            int mbRes = MessageBoxW( parentWnd, msg.c_str(), captionStr.c_str(), mbFlags );

            if (res)
               {
                switch(mbRes)
                   {
                    case IDABORT   :  *res = CLI_GUI_DIALOGRESULT_ABORTBUTTON;     break;
                    case IDCANCEL  :  *res = CLI_GUI_DIALOGRESULT_CANCELBUTTON;    break;
                    case IDCONTINUE:  *res = CLI_GUI_DIALOGRESULT_CONTINUEBUTTON;  break;
                    case IDIGNORE  :  *res = CLI_GUI_DIALOGRESULT_IGNOREBUTTON;    break;
                    case IDNO      :  *res = CLI_GUI_DIALOGRESULT_NOBUTTON;        break;
                    case IDOK      :  *res = CLI_GUI_DIALOGRESULT_OKBUTTON;        break;
                    case IDRETRY   :  *res = CLI_GUI_DIALOGRESULT_RETRYBUTTON;     break;
                    case IDTRYAGAIN:  *res = CLI_GUI_DIALOGRESULT_TRYBUTTON;       break;
                    case IDYES     :  *res = CLI_GUI_DIALOGRESULT_YESBUTTON;       break;
                    // case :  *res = ;
                    //         break;
                    default        :  *res = CLI_GUI_DIALOGRESULT_CANCELBUTTON;
                   }
               }
            return EC_OK;
           }
        else
           {
            ::CoInitialize(NULL);
            // this resolves ATL window thunking problem when Microsoft Layer for Unicode (MSLU) is used
            ::DefWindowProc(NULL, 0, 0, 0L);

            AtlInitCommonControls(0); // add flags to support other controls

            CWtlErrorInfoDlg dlg;
            dlg.customCaption = caption;
            dlg.errorInfos     = errList;
            dlg.errorInfosSize = errListSize;
            dlg.flags          = flags;

            int nRet = 0;
            nRet = (int)dlg.DoModal();

            if (res)
               {
                switch(nRet)
                   {
                    case IDABORT   :  *res = CLI_GUI_DIALOGRESULT_ABORTBUTTON;     break;
                    case IDCANCEL  :  *res = CLI_GUI_DIALOGRESULT_CANCELBUTTON;    break;
                    case IDCONTINUE:  *res = CLI_GUI_DIALOGRESULT_CONTINUEBUTTON;  break;
                    case IDIGNORE  :  *res = CLI_GUI_DIALOGRESULT_IGNOREBUTTON;    break;
                    case IDNO      :  *res = CLI_GUI_DIALOGRESULT_NOBUTTON;        break;
                    case IDOK      :  *res = CLI_GUI_DIALOGRESULT_OKBUTTON;        break;
                    case IDRETRY   :  *res = CLI_GUI_DIALOGRESULT_RETRYBUTTON;     break;
                    case IDTRYAGAIN:  *res = CLI_GUI_DIALOGRESULT_TRYBUTTON;       break;
                    case IDYES     :  *res = CLI_GUI_DIALOGRESULT_YESBUTTON;       break;
                    // case :  *res = ;
                    //         break;
                    default        :  *res = CLI_GUI_DIALOGRESULT_CANCELBUTTON;
                   }
               }
           }


        // CLI_GUI_ERRORDIALOGFLAGS_ONLYLASTERROR
        return EC_OK;
       }

};




template < typename RefCnt >
struct CCliGuiSimpleMessageBoxImpl : public INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX
{
    RefCnt counter;
    CCliGuiSimpleMessageBoxImpl() : counter(1)
       {
       }

    ~CCliGuiSimpleMessageBoxImpl()
       {
       }

    virtual void destroy() 
       {
       #include <cli/compspec/delthis.h>
       }

    CLI_BEGIN_INTERFACE_MAP(CCliGuiSimpleMessageBoxImpl)
        CLI_IMPLEMENT_INTERFACE(INTERFACE_CLI_GUI_ISIMPLEMESSAGEBOX)
    CLI_END_INTERFACE_MAP(CCliGuiSimpleMessageBoxImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return (ilint_t)++counter;  }
    CLIMETHOD_(ULONG, release) (THIS)   { if (! --counter) { destroy(); return 0; }  return (ilint_t)counter; }

    CLIMETHOD(showModal) (THIS_ ENUM_CLI_GUI_DIALOGRESULT*    res /* [out] ::cli::gui::DialogResult res  */
                              , WND_HANDLE    parentWnd /* [in] pwnd  parentWnd  */
                              , const WCHAR*    caption /* [in,flat] wchar  caption[]  */
                              , SIZE_T    captionLen /* [in] size_t  captionLen  */
                              , const WCHAR*    message /* [in,flat] wchar  message[]  */
                              , SIZE_T    messageLen /* [in] size_t  messageLen  */
                              , ENUM_CLI_GUI_ERRORDIALOGFLAGS    flags /* [in] ::cli::gui::ErrorDialogFlags  flags  */
                         )
       {
        if (!::IsWindow(parentWnd)) parentWnd = 0;

        ::std::wstring captionStr; // = 
        if (caption)
           {
            if (captionLen==SIZE_T_NPOS)
               captionStr.assign(caption);
            else
               captionStr.assign(caption, captionLen);
           }
        else
           {
            captionStr.assign( loadStringW( cliModule.getModuleHandle(), IDS_ERRDLG_CAPTION ) );
           }

        ::std::wstring messageStr; // = 
        if (message)
           {
            if (messageLen==SIZE_T_NPOS)
               messageStr.assign(message);
            else
               messageStr.assign(message, messageLen);
           }

        DWORD mbFlags = 0;
        
        switch(flags&CLI_GUI_ERRORDIALOGFLAGS_BUTTONFLAGSMASK)
           {
            case CLI_GUI_ERRORDIALOGFLAGS_OKBUTTON:               mbFlags |= MB_OK;                break;
            case CLI_GUI_ERRORDIALOGFLAGS_OKCANCELBUTTON:         mbFlags |= MB_OKCANCEL;          break;
            case CLI_GUI_ERRORDIALOGFLAGS_YESNOBUTTON:            mbFlags |= MB_YESNO;             break;
            case CLI_GUI_ERRORDIALOGFLAGS_YESCANCELBUTTON:        mbFlags |= MB_YESNOCANCEL;       break;
            case CLI_GUI_ERRORDIALOGFLAGS_YESNOCANCELBUTTON:      mbFlags |= MB_YESNOCANCEL;       break;
            case CLI_GUI_ERRORDIALOGFLAGS_RETRYCANCELBUTTON:      mbFlags |= MB_CANCELTRYCONTINUE; break;
            case CLI_GUI_ERRORDIALOGFLAGS_ABORTRETRYIGNOREBUTTON: mbFlags |= MB_ABORTRETRYIGNORE;  break;
            case CLI_GUI_ERRORDIALOGFLAGS_CANCELTRYCONTINUEBUTTON:mbFlags |= MB_CANCELTRYCONTINUE; break;
           }

        if (!mbFlags) mbFlags = MB_OK;

        switch(flags&CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTONFLAGSMASK)
           {
            case CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON1:  mbFlags |= MB_DEFBUTTON1; break;
            case CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON2:  mbFlags |= MB_DEFBUTTON2; break;
            case CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON3:  mbFlags |= MB_DEFBUTTON3; break;
            case CLI_GUI_ERRORDIALOGFLAGS_DEFBUTTON4:  mbFlags |= MB_DEFBUTTON4; break;
            default:                                   mbFlags |= MB_DEFBUTTON1;
           }

        switch(flags&CLI_GUI_ERRORDIALOGFLAGS_ICONSFLAGSMASK)
           {
            case CLI_GUI_ERRORDIALOGFLAGS_ICONINFORMATION:  mbFlags |= MB_ICONINFORMATION; break; // CLI_GUI_ERRORDIALOGFLAGS_ICONASTERISK
            case CLI_GUI_ERRORDIALOGFLAGS_ICONWARNING:      mbFlags |= MB_ICONWARNING;     break; // CLI_GUI_ERRORDIALOGFLAGS_ICONEXCLAMATION
            case CLI_GUI_ERRORDIALOGFLAGS_ICONERROR:        mbFlags |= MB_ICONERROR;       break; // CLI_GUI_ERRORDIALOGFLAGS_ICONSTOP, CLI_GUI_ERRORDIALOGFLAGS_ICONHAND
           }

        int mbRes = MessageBoxW( parentWnd, messageStr.c_str(), captionStr.c_str(), mbFlags );

        if (res)
           {
            switch(mbRes)
               {
                case IDABORT   :  *res = CLI_GUI_DIALOGRESULT_ABORTBUTTON;     break;
                case IDCANCEL  :  *res = CLI_GUI_DIALOGRESULT_CANCELBUTTON;    break;
                case IDCONTINUE:  *res = CLI_GUI_DIALOGRESULT_CONTINUEBUTTON;  break;
                case IDIGNORE  :  *res = CLI_GUI_DIALOGRESULT_IGNOREBUTTON;    break;
                case IDNO      :  *res = CLI_GUI_DIALOGRESULT_NOBUTTON;        break;
                case IDOK      :  *res = CLI_GUI_DIALOGRESULT_OKBUTTON;        break;
                case IDRETRY   :  *res = CLI_GUI_DIALOGRESULT_RETRYBUTTON;     break;
                case IDTRYAGAIN:  *res = CLI_GUI_DIALOGRESULT_TRYBUTTON;       break;
                case IDYES     :  *res = CLI_GUI_DIALOGRESULT_YESBUTTON;       break;
                // case :  *res = ;
                //         break;
                default        :  *res = CLI_GUI_DIALOGRESULT_CANCELBUTTON;
               }
           }
        return EC_OK;
       }


};



static
CLI_IUNKNOWN_PTR CLICALL create_cli_error_info_dialog(CLI_IUNKNOWN_PTR outer)
   {
    return static_cast<CLI_IUNKNOWN_PTR>( new CCliGuiErrorInfoDialogImpl< ::cli::CRefCounter >() );
   }

static
CLI_IUNKNOWN_PTR CLICALL create_cli_simple_message_box_dialog(CLI_IUNKNOWN_PTR outer)
   {
    return static_cast<CLI_IUNKNOWN_PTR>( new CCliGuiSimpleMessageBoxImpl< ::cli::CRefCounter >() );
   }

//static 
static unsigned infoInitialized = 0;
static
CCliComponentCreationInfo moduleComponentsInfo[] = 
   {
      // ---
      { 
        { "/cli/core/gui/error_dialog/win"
        , "/cli/gui/iErrorDialog"
        , "en:GUI component that displays error information;"
        }
      , &create_cli_error_info_dialog
      }
      , // ---
      { 
        { "/cli/core/gui/simple_message_box/win"
        , "/cli/gui/iSimpleMessageBox"
        , "en:GUI component that displays simple message box;"
        }
      , &create_cli_simple_message_box_dialog
      }
   };



DECLARE_CLI_MODULE_INFO(moduleComponentsInfo, infoInitialized, registerModuleWindlg, "windlg");
/*
COMPARE_COMPONENT_CREATION_INFO_PROC_IMPL(moduleComponentsInfo);
MAKE_COMPONENTS_INFO_SORTED_PROC_IMPL(moduleComponentsInfo);
FIND_COMPONENTS_INFO_IMPL(moduleComponentsInfo);
CLI_ENUM_MODULE_COMPONENTS_IMPL(moduleComponentsInfo, infoInitialized);
CLI_CREATE_PROC_IMPL(moduleComponentsInfo, infoInitialized);
CLI_MONOLITHIC_REGISTER_MODULE_LEGACY(registerModuleCt017, "ct017");
*/

