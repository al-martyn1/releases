#ifndef CORE_MODINFOCPPIMPL_H
#define CORE_MODINFOCPPIMPL_H


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_VECTOR_) && !defined(_STLP_VECTOR) && !defined(__STD_VECTOR__) && !defined(_CPP_VECTOR) && !defined(_GLIBCXX_VECTOR)
    #include <vector>
#endif

#if !defined(_MAP_) && !defined(_STLP_MAP) && !defined(__STD_MAP__) && !defined(_CPP_MAP) && !defined(_GLIBCXX_MAP)
    #include <map>
#endif


#include <marty/libapi.h>
#include <marty/filename.h>
#include <marty/filesys.h>

#include <cli/cli2.h>
#include <cli/cliutilx.h>

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

namespace cli
{
namespace implx
{

template< typename CharType 
        , typename Traits     = ::std::char_traits<CharType>
        , typename Allocator  = ::std::allocator<CharType>
        >
struct CComponentInfo
{
    std::string                                       name;
    ::std::basic_string<CharType, Traits, Allocator>  moduleName;
    std::vector<std::string>                          categories;
    std::map<std::string, std::string>                description;
};


template< typename CharType 
        , typename Traits
        , typename Allocator
        >
bool readComponentInfoFromModule( const ::std::basic_string<CharType, Traits, Allocator>      &modFullName
                                , const MARTY_LIBAPI::CModuleHandle                           &modHandle
                                , ::std::vector<CComponentInfo<CharType, Traits, Allocator> > &vci
                                , RCODE *pErrCode = 0// pErrInfo
                                , ::std::basic_string<CharType, Traits, Allocator>            *pErrInfo = 0
                                )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string;
    if (pErrCode) *pErrCode = 0;
    if (pErrInfo) pErrInfo->clear();
    //string modFullName = MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS makeFullPath(MARTY_FILESYSTEM_NS getCurrentDirectory(), modName));
    try{
        //MARTY_LIBAPI_NS CModuleHandle modHandle /*  = CModuleHandle */ (modFullName.c_str());
        cliEnumModuleComponentsProcT enumProc = reinterpret_cast<cliEnumModuleComponentsProcT>(modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME));
        //cliEnumModuleComponentsProcT proc = (cliEnumModuleComponentsProcT)modHandle.getProcAddress(CLIENUMMODULECOMPONENTSPROCNAME);
        if (!enumProc)
           {
            return false;
           }

        SIZE_T idx = 0;
        CCliComponentInfo ci = { 0, 0, 0 };
        while(enumProc(idx++, &ci))
           {
            if (!ci.name) continue;

            CComponentInfo<CharType, Traits, Allocator> xci;
            xci.moduleName = modFullName;

            xci.name = ci.name;

            if (ci.categories)
               {
                //::std::vector<string> vcat;
                ::cli::util::splitString(::std::string(ci.categories), xci.categories, ::cli::util::CIsExactChar<char,';'>());
               }

            if (ci.description)
               {
                //string description = ci.description;
                //::std::map<string, string> md;
                ::cli::util::splitStringToMap(xci.description, ::std::string(ci.description), ::cli::util::CIsExactChar<char,';'>(), ::cli::util::CIsExactChar<char, ':'>());
               }

            vci.push_back(xci);
           }

       }
    catch( const MARTY_LIBAPI_NS libapi_error &e)
       {
        #ifdef WIN32
        if (pErrCode) *pErrCode = WIN2RC(e.code());
        if (pErrInfo) MARTY_LIBAPI_NS formatSystemError( (DWORD)e.code(), *pErrInfo );
        #else
        if (pErrCode) *pErrCode = POSIX2RC(e.code());
        if (pErrInfo)
           {
            #if defined(UNICODE) || defined(_UNICODE)
            //*pErrInfo = MARTY_UTF_NS fromUtf8( e.what() );
            *pErrInfo = MARTY_CON::strToWide( e.what() );
            #else
            *pErrInfo = e.what();
            #endif
           }
        #endif
        return false;
       }

    catch( const ::std::exception &e )
       {
        if (pErrCode) *pErrCode = EC_INVALID_MODULE;
        if (pErrInfo)
           {
            #if defined(UNICODE) || defined(_UNICODE)
            *pErrInfo = MARTY_CON::strToWide( e.what() );
            #else
            *pErrInfo = e.what();
            #endif
           }
        return false;
       }
    catch(...)
       {
        if (pErrCode) *pErrCode = EC_INVALID_MODULE;
        return false;
       }

    return true;
   }

/*
struct CSimpleLineHandler
{
    bool operator()(const char *pbuf, unsigned size)
       {
        if (!pbuf || !size) return true;
        if (pbuf[size-1]=='\r') --size;
        if (!size) return true;

        ::std::cout<<"Line: "<< ::std::string(pbuf, size)<<"\n";
        return true;
       }

};
*/


template< typename CharType 
        , typename Traits
        , typename Allocator
        >
bool readComponentInfoFromModule( const ::std::basic_string<CharType, Traits, Allocator>      &modName
                                , ::std::vector<CComponentInfo<CharType, Traits, Allocator> > &vci
                                , RCODE *pErrCode = 0// pErrInfo
                                , ::std::basic_string<CharType, Traits, Allocator>            *pErrInfo = 0
                                )
   {
    typedef ::std::basic_string<CharType, Traits, Allocator> string;
    if (pErrCode) *pErrCode = 0;
    if (pErrInfo) pErrInfo->clear();
    string modFullName = MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS makeFullPath(MARTY_FILESYSTEM_NS getCurrentDirectory(), modName));
    return readComponentInfoFromModule( modFullName, MARTY_LIBAPI::CModuleHandle( modFullName.c_str() )
                                    , vci, pErrCode, pErrInfo
                                    );
   }


template< typename CharType 
        , typename Traits
        , typename Allocator
        >
struct CParseCliModInfoLineHandler
{
    CComponentInfo<CharType, Traits, Allocator>                 info;
    ::std::vector<CComponentInfo<CharType, Traits, Allocator> > &vci;
    const ::std::basic_string<CharType, Traits, Allocator>      &modName;
    bool                                                        fReadDescription;

    CParseCliModInfoLineHandler( ::std::vector<CComponentInfo<CharType, Traits, Allocator> > &_vci
                               , const ::std::basic_string<CharType, Traits, Allocator>      &mN
                               ) : info(), vci(_vci), modName(mN) , fReadDescription(false)
       {
        info.moduleName = modName;
       }

    CParseCliModInfoLineHandler(const CParseCliModInfoLineHandler &h) : info(h.info), vci(h.vci), modName(h.modName), fReadDescription(h.fReadDescription)
       {}

    static
    ::std::string trim_copy(const ::std::string &str)
       {
        return ::cli::util::trim_copy(str, ::cli::util::CIsSpace<char>());
       }

    static
    void trim(::std::string &str)
       {
        return ::cli::util::trim(str, ::cli::util::CIsSpace<char>());
       }

    bool operator()(const char *pbuf, unsigned size)
       {
        if (!pbuf || !size) return true;
        if (pbuf[size-1]=='\r') --size;
        if (!size) return true;

        ::std::string line(pbuf, size);
        if (line==::std::string(".") && !info.name.empty()) 
           {
            vci.push_back(info);
            info.name.clear();
            info.moduleName = modName;
            info.categories.erase(info.categories.begin(), info.categories.end());
            info.description.erase(info.description.begin(), info.description.end());
            fReadDescription = false;

            /* std::string                                       name;
             * ::std::basic_string<CharType, Traits, Allocator>  moduleName;
             * std::vector<std::string>                          categories;
             * std::map<std::string, std::string>                description;
             */

           }

        const ::std::string strComponent("Component:");
        const ::std::string strCategories("Categories:");
        const ::std::string strDescription("Description:");
        const ::std::string strModule("Module:");

        if (!fReadDescription)
           {
            //if (!line.compare(0, strComponent.size(), strComponent, 0, strComponent.size()))
            if (::cli::util::startsWithI(line, strComponent))
               {
                //info.name = ::cli::util::trim_copy(::std::string(line, strComponent.size()), ::cli::util::CIsSpace<char>());
                info.name = trim_copy(::std::string(line, strComponent.size()));
               }
            //else if (!line.compare(0, strCategories.size(), strCategories, 0, strCategories.size()))
            else if (::cli::util::startsWithI(line, strCategories))
               {
                //::std::string categories = ::cli::util::trim_copy(::std::string(line, strCategories.size()), ::cli::util::CIsSpace<char>());
                //::cli::util::splitString( ::cli::util::trim_copy(::std::string(line, strCategories.size()), ::cli::util::CIsSpace<char>())
                ::cli::util::splitString( trim_copy(::std::string(line, strCategories.size()))
                                        , info.categories
                                        , ::cli::util::CIsExactChar<char,';'>()
                                        );
               }
            //if (!line.compare(0, strModule.size(), strModule, 0, strModule.size()))
            else if (::cli::util::startsWithI(line, strModule))
               {
                //info.moduleName = ::cli::util::trim_copy(::std::string(line, strModule.size()), ::cli::util::CIsSpace<char>());
                #if defined(_UNICODE) || defined(UNICODE)
                    info.moduleName = MARTY_UTF_NS fromUtf8(trim_copy(::std::string(line, strModule.size())));
                #else
                    info.moduleName = trim_copy(::std::string(line, strModule.size()));
                #endif
                
               }
            //else if (!line.compare(0, strDescription.size(), strDescription, 0, strDescription.size()))
            else if (::cli::util::startsWithI(line, strDescription))
               {
                fReadDescription = true;
                //line = ::cli::util::trim_copy(::std::string(line, strDescription.size()), ::cli::util::CIsSpace<char>());
                line = trim_copy(::std::string(line, strDescription.size()));
                ::cli::util::splitStringToMap(info.description, line, ::cli::util::CIsExactChar<char,';'>(), ::cli::util::CIsExactChar<char, ':'>());
               }
           }
        else
           {
            //::cli::util::trim(line, ::cli::util::CIsSpace<char>());
            trim(line);
            //::std::vector< ::std::string > pair;
            ::cli::util::splitStringToMap(info.description, line, ::cli::util::CIsExactChar<char,';'>(), ::cli::util::CIsExactChar<char, ':'>());
           }

        return true;
       }

    ~CParseCliModInfoLineHandler()
       {
        if (!info.name.empty()) vci.push_back(info);
       }
};


template< typename CharType 
        , typename Traits
        , typename Allocator
        >
bool readComponentInfoFromModuleCache( const ::std::basic_string<CharType, Traits, Allocator>  &modCacheName
                                , ::std::vector<CComponentInfo<CharType, Traits, Allocator> > &vci
                                )
   {
    if (modCacheName.size() <=CLI_MODULE_INFO_CACHE_SUFFIX_LEN) return false;

    typedef ::std::basic_string<CharType, Traits, Allocator> string;
    string modCacheFullName = MARTY_FILENAME_NS makeCanonical(MARTY_FILENAME_NS makeFullPath(MARTY_FILESYSTEM_NS getCurrentDirectory(), modCacheName));

    string modFullName = string(modCacheFullName, 0, modCacheFullName.size()-CLI_MODULE_INFO_CACHE_SUFFIX_LEN);

    MARTY_FILESYSTEM_NS handle_t hFile = MARTY_FILESYSTEM_NS openFile(modCacheFullName, MARTY_FILESYSTEM_NS o_rdonly);
    if (hFile == MARTY_FILESYSTEM_NS hInvalidHandle)
       return false;

    CParseCliModInfoLineHandler<CharType, Traits, Allocator> handler( vci, modFullName );

    MARTY_FILESYSTEM_NS readFileLines<CParseCliModInfoLineHandler<CharType, Traits, Allocator>, 4096, '\n'>(hFile, handler);
    //MARTY_FILESYSTEM_NS readFileLines(hFile, CSimpleLineHandler());

    MARTY_FILESYSTEM_NS closeFile(hFile);

    return true;
   }


}; // namespace implx

}; // namespace cli




//



#endif /* CORE_MODINFOCPPIMPL_H */

