#define CLI_INTERNAL

#ifndef CLI_FORMAT_H
    #include <cli/format.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif

#ifndef MARTY_UTF_H
    #include <marty/utf.h>
#endif

#ifndef MARTY_CONCVT_H
    #include <marty/concvt.h>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#ifndef CLI_CLIUTILX_H
    #include <cli/cliutilx.h>
#endif

#ifndef CLI_DATETIMEFORMAT_H
    #include <cli/dateTimeFormat.h>
#endif


#if defined(WIN32) || defined(_WIN32)

    #if !defined(_WINDOWS_)
        #include <windows.h>
    #endif

#else // Linux
    
    #if !defined(_INC_TIME) && !defined(_TIME_H_) && !defined(_TIME_H)
        #include <time.h>
    #endif

    #ifndef MARTY_UTF_H
        #include <marty/utf.h>
    #endif

#endif


#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_ALGORITHM_) && !defined(_STLP_ALGORITHM) && !defined(__STD_ALGORITHM) && !defined(_CPP_ALGORITHM) && !defined(_GLIBCXX_ALGORITHM)
    #include <algorithm>
#endif

#ifndef CLI_DATETIME_H
    #include <cli/dateTime.h>
#endif

#include "fp_ADTParser_Automata.h"
#include "fp_ATIParser_Automata.h"
#include "fp_ADGParser_Automata.h"



// UNDONE:
/*
1) �������� � ������ = � _ ��� ����������� �������������� ������������ ������� � ����
2) + �������� � ��������� CLISYSTEMTIME ���� gmOffset
3) �������� �������� +,- � �� � ����� CDateTime
4) + �������� ������� ��������� �������� gm ��� ������ �������
5) + �������� �������� ��� ������ gmOffset - u/uu/U/UU etc
7) �������� ����� � iArgList, ��������� ����� arg ��� ��� ���������
*/

//-----------------------------------------------------------------------------
namespace cli
{
namespace format
{
namespace impl
{






const WCHAR *wdays[] = { L"Monday", L"Mon", L"Tuesday", L"Tue", L"Wednesday", L"Wed", L"Thursday", L"Thu", L"Friday", L"Fri", L"Saturday", L"Sat", L"Sunday", L"Sun" };
const WCHAR *months[]= { L"January", L"Jan", L"February", L"Feb", L"March", L"Mar", L"April", L"Apr", L"May", L"May", L"June", L"Jun", L"July", L"Jul", L"August", L"Aug", L"September", L"Sep", L"October", L"Oct", L"November", L"Nov", L"December", L"Dec" };

class CFormatParserImplBase
{
    protected:  

        static ::std::wstring toStr(UINT64 i, unsigned width, WCHAR fillChar = L'0')
           {
            ::std::wstring res;
            while(i)
               {
                unsigned dig = (unsigned)(i%10);
                res.append(1, L'0'+dig);
                i /= 10;
               }
            if (res.empty()) res.append(1, L'0');
            if (res.size()<(SIZE_T)width)
               res.append((SIZE_T)width-res.size(), fillChar);
            ::std::reverse(res.begin(), res.end());
            return res;
           }

        static 
        ::std::wstring formatMicroVal( unsigned microVal, unsigned width, bool bLeadingZeros )
           {
            if (microVal>=1000000) microVal = 999999;
            unsigned tmp = width;
            if (!bLeadingZeros) tmp = 0;

            if (width>5) width = 5;
            unsigned scale = 1;
            for(unsigned i=0; i!=(5-width); ++i) scale *= 10;

            if (width>=5) return toStr(microVal, tmp+1 ); // as is
            unsigned ost = (microVal / (scale/10)) % 10;
            unsigned add = 0;
            if (ost>=5) ++add;
            unsigned tmpVal = (microVal/scale)+add;
            if ((tmpVal*scale)>=1000000)
               tmpVal = (microVal/scale);

            return toStr( tmpVal, tmp+1 ); // 1/10
           }

}; // CFormatParserImplBase



class CDateTimeFormatParserImpl : public CDTFormatParser, public CFormatParserImplBase
{
    public:
        STRUCT_CLI_CLISYSTEMTIME *pDateTime;

    protected:  


        static ::std::wstring formatMinutes(unsigned i, unsigned width)
           {
            if (i>59) i = 59;
            return toStr( i, (width > 0 ? 2 : 1) );
           }



        static
        ::std::wstring formatDateField( STRUCT_CLI_CLISYSTEMTIME *pdt, UINT fmt)
           {

/*
            WORD                        year;
            WORD                        month;
            WORD                        dayOfWeek;
            WORD                        day;
            WORD                        hour;
            WORD                        minute;
            WORD                        second;
            DWORD                       microsec;
*/
            unsigned width = (fmt&DTF_MASKNUMDIGITS);
            switch(fmt&DTF_PARTMASK)
               {
                case DTF_IGNORE:  return ::std::wstring();
                case DTF_SIGNORE: return ::std::wstring();

                case DTF_DATESEP: return getLocaleDateSeparator( );

                case DTF_TIMESEP: return getLocaleTimeSeparator( );

                case DTF_YEAR:  
                        {
                         if (!width) width = 1;
                         //WCHAR fillChar = '0';
                         if (width<2)
                            return toStr(pdt->year%100, 2 /* , L' ' */  );
                         else if (width==2)
                            return toStr(pdt->year, 1, L' ' );
                         else
                            return toStr(pdt->year, width+1, L' ' );
                        }
                     
                case DTF_MONTH:  
                        {
                         if (width<2) // one or two digits day of month
                            return toStr(pdt->month, width+1 );
    
                         unsigned idx = pdt->month;
                         if (idx<1)  idx = 1;
                         if (idx>12) idx = 12;
                         --idx;
                         
                         if (fmt&DTF_ENG)
                            {
                             idx<<=1;
                             if (width==2)
                                {
                                 ++idx;
                                }
                             return ::std::wstring(months[idx]);
                            }
                         return getLocaleMonthName( idx, width==2 );
                        }

                     
                case DTF_MDAY:  
                case DTF_WDAY:  
                        {
                         if (width<2) // one or two digits day of month
                            return toStr(pdt->day, width+1 );
    
                         unsigned idx = pdt->dayOfWeek;
                         if (idx>6) idx = 6;
                         
                         if (fmt&DTF_ENG)
                            {
                             idx<<=1;
                             if (width==2)
                                {
                                 ++idx;
                                }
                             return ::std::wstring(wdays[idx]);
                            }
                         return getLocaleDayOfWeekName( idx, width==2 );
                        }

                case DTF_HOUR:  
                        {
                         unsigned hour = pdt->hour;
                         if (hour>23) hour = 23;
                         if (fmt&DTF_12H) hour %= 12;
                         return toStr(hour, width+1 );
                        }

                case DTF_MIN:
                        return formatMinutes(pdt->minute, width);

                case DTF_SEC:
                        return formatMinutes(pdt->second, width);

                case DTF_MICROSEC:
                        {
                         DWORD msec = pdt->microsec;
                         if (msec>=1000000) msec = 999999;
                         if (width>=3) width = 5;
                         return formatMicroVal( msec, width, (fmt&DTF_ZEROS ? true : false) );
                        }

                case DTF_AP:
                        {
                         const WCHAR *ampmStr = (pdt->hour>=12) ? ((fmt&DTF_UPCASE) ? (L"PM") : (L"pm")) : ((fmt&DTF_UPCASE) ? (L"AM") : (L"am"));
                         return ::std::wstring( ampmStr, (width ? 2 : 1) );                         
                        }
                case DTF_GM:  
                        {
                         bool neg = false;
                         SHORT gm = (fmt&DTF_LOCAL) ? ::cli::CDateTime::localUtcOffset() : pdt->gmOffset;
                         
                         if (gm<0)
                            {
                             neg = true;
                             gm = -gm;
                            }

                         unsigned gmHours   = gm/60;
                         unsigned gmMinutes = gm%60;
                         ::std::wstring res(1, (neg ? L'-' : L'+'));
                         if (!width)
                            res.append( toStr(gmHours, 1) );
                         else if (width==1)
                            res.append( toStr(gmHours, 2) );
                         else if (width==2)
                            {
                             res.append( toStr(gmHours  , 1) );
                             res.append( 1, L':' );
                             res.append( toStr(gmMinutes, 2) );
                            }
                         else if (width==3)
                            {
                             res.append( toStr(gmHours  , 2) );
                             res.append( 1, L':' );
                             res.append( toStr(gmMinutes, 2) );
                            }
                         return res;
                        }
                     
                default: return ::std::wstring();
               }
            return ::std::wstring();
           }


        virtual
        void
        appendToOut
                   ( WCHAR  ch          
                   , UINT   dtField     
                   , int    width       
                   )
           {
            if (!dtField)
               {
                formatedOut.append(1, ch);
                return;
               }

            if (width>3) width = 3;
            dtField |= (UINT)width;
            width = (dtField&DTF_MASKNUMDIGITS);
            formatedOut.append( formatDateField(pDateTime, dtField) );
           }

        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            formatedOut.clear(); // = ::std::wstring();
            _dtField = 0;
            _width   = 0;
           }

};



::std::wstring formatDateTime( const ::std::wstring &fmt, const STRUCT_CLI_CLISYSTEMTIME &dateTime )
   {
    CDateTimeFormatParserImpl fmtParser;
    fmtParser.pDateTime = (STRUCT_CLI_CLISYSTEMTIME*)&dateTime;
    fmtParser.resetAutomata();
    ::std::wstring::size_type i = 0, size = fmt.size();
    for(; i!=size; ++i)
       {
        fmtParser.putChar( fmt[i] );       
       }
    fmtParser.eod();
    return fmtParser.formatedOut;
   }



struct CDateTimeFormaterImpl
{
    void operator()( std::wstring &resStr, const std::wstring &formatString, INTERFACE_CLI_IARGLIST* arglist, SIZE_T argNo) const
       {
        if (!arglist) return; // no value for formating
        STRUCT_CLI_CLISYSTEMTIME dt;
        arglist->getDate( argNo, &dt );
        resStr = formatDateTime( formatString, dt );
       }
};


SIZE_T
CLICALL dateTimeFormaterImpl( WCHAR*    charBuf
                        , SIZE_T    charBufSize
                        , const WCHAR*    fmtStrChars
                        , SIZE_T    fmtStrCharsSize
                        , INTERFACE_CLI_IARGLIST*    arglist
                        , SIZE_T    argNo
                        )
   {
    return ::cli::format::cliFormaterImplementationHelper( CDateTimeFormaterImpl(), charBuf, charBufSize, fmtStrChars, fmtStrCharsSize, arglist, argNo );
   }


class CTimeFormatParserImpl : public CTIFormatParser, public CFormatParserImplBase
{
    public:
        INT64     _ti; // time interval value;
        //unsigned  flagSign;
        bool      _neg;
        unsigned  _flagSign;

        //unsigned   _microdegrees;

    protected:  

        std::wstring makeSign( unsigned  flagSign, bool neg )
           {
            if (!formatedOut.empty()) 
               { // simple copy +/- to output
                if (flagSign==DTF_SIGOFF) return ::std::wstring(L"-");
                else if (flagSign==DTF_SIGON) return ::std::wstring(L"+");
                else return ::std::wstring();
               }
            if (_flagSign==DTF_SIGOFF) return ::std::wstring();

            if (flagSign==DTF_SIGOFF) { _flagSign = flagSign; return ::std::wstring(); }
            if ((flagSign==DTF_SIGAUTO && neg) || flagSign==DTF_SIGON)
               {
                if (neg) // need prepend minus
                    return ::std::wstring(L"-");
                else // need prepend plus
                    return ::std::wstring(L"+");
                //flagSign = DTF_SIGOFF; // turn off further sign processing
               }
            return ::std::wstring();
           }

        ::std::wstring formatTimeField( UINT64 ti, UINT fmt, bool neg)
           {
            unsigned width = (fmt&DTF_MASKNUMDIGITS);
            switch(fmt&DTF_PARTMASK)
               {
                case DTF_IGNORE:  return ::std::wstring();
                case DTF_SIGNORE: return ::std::wstring();
                case DTF_SIGOFF:  return makeSign(fmt&DTF_PARTMASK, neg);
                case DTF_SIGAUTO: return makeSign(fmt&DTF_PARTMASK, neg);
                case DTF_SIGON:   return makeSign(fmt&DTF_PARTMASK, neg);

                case DTF_DATESEP: return getLocaleDateSeparator( );

                case DTF_TIMESEP: return getLocaleTimeSeparator( );

                case DTF_WEEK:
                        {
                         ::std::wstring res = makeSign(DTF_SIGAUTO, neg);
                         UINT64 weeks = ti / 1000000 / 60 / 60 / 24 / 7;
                         //if (width<2)
                         //   days = days % 7;
                         return res + toStr(weeks, width+1 );
                        }
                

                case DTF_WDAY:
                case DTF_MDAY:
                        {
                         ::std::wstring res = makeSign(DTF_SIGAUTO, neg);
                         UINT64 days = ti / 1000000 / 60 / 60 / 24;
                         if (width<2)
                            days = days % 7;
                         return res + toStr(days, width==1 ? 2 : 1 );
                        }
                
                case DTF_HOUR:
                        {
                         // check and generate sign str if needed
                         ::std::wstring res = makeSign(DTF_SIGAUTO, neg);
                         // _ti % 1000000 /                  - mcs
                         // _ti / 1000000                    - secs
                         // _ti / 1000000 / 60               - mins
                         // _ti / 1000000 / 60 / 60          - hours
                         // _ti / 1000000 / 60 / 60 / 24     - days
                         // _ti / 1000000 / 60 / 60 / 24 / 7 - weeks
                         UINT64 hours = ti / 1000000 / 60 / 60;
                         if (width<2)
                            hours = hours % 24;
                         return res + toStr(hours, width==1 ? 2 : 1 );
                        }

                case DTF_MIN:  
                        {
                         ::std::wstring res = makeSign(DTF_SIGAUTO, neg);
                         UINT64 mins = ti / 1000000 / 60;
                         if (width<2)
                            mins = mins % 60;
                         return res + toStr(mins, width==1 ? 2 : 1 );
                        }                        

                case DTF_SEC:  
                        {
                         ::std::wstring res = makeSign(DTF_SIGAUTO, neg);
                         INT64 secs = _ti / 1000000;
                         if (width<2)
                            secs = secs % 60;
                         return res + toStr(secs, width==1 ? 2 : 1 );
                        }

                case DTF_MICROSEC:  
                        {
                         //::std::wstring res = makeSign(DTF_SIGAUTO, neg);
                         DWORD msec = (DWORD)(ti % 1000000); // pdt->microsec;
                         return formatMicroVal( msec, width, (fmt&DTF_ZEROS ? true : false) );
                        }
                default: return ::std::wstring();
               }
            return ::std::wstring();
           }


        virtual
        void
        appendToOut
                   ( WCHAR  ch          
                   , UINT   dtField     
                   , int    width       
                   )
           {
            if (!dtField)
               {
                formatedOut.append(1, ch);
                return;
               }

            if (width>3) width = 3;
            dtField |= (UINT)width;
            width = (dtField&DTF_MASKNUMDIGITS);
            formatedOut.append( formatTimeField( (UINT64)_ti, dtField, _neg) );
           }

        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            formatedOut.clear(); // = ::std::wstring();
            _dtField = 0;
            _width   = 0;
            _flagSign = DTF_SIGAUTO;
            //neg = false;
            if (_ti<0) { _neg = true; _ti = -_ti; }
            else       { _neg = false; }
           }

};


::std::wstring formatTime( const ::std::wstring &fmt, INT64 ti )
   {
    CTimeFormatParserImpl fmtParser;
    fmtParser._ti = ti;
    fmtParser.resetAutomata();
    ::std::wstring::size_type i = 0, size = fmt.size();
    for(; i!=size; ++i)
       {
        fmtParser.putChar( fmt[i] );       
       }
    fmtParser.eod();
    return fmtParser.formatedOut;
   }

struct CTimeFormaterImpl
{
    void operator()( std::wstring &resStr, const std::wstring &formatString, INTERFACE_CLI_IARGLIST* arglist, SIZE_T argNo) const
       {
        if (!arglist) return; // no value for formating
        INT64 ti;
        arglist->getInt64( argNo, &ti );
        resStr = formatTime( formatString, ti );
       }
};


SIZE_T
CLICALL timeFormaterImpl( WCHAR*    charBuf
                        , SIZE_T    charBufSize
                        , const WCHAR*    fmtStrChars
                        , SIZE_T    fmtStrCharsSize
                        , INTERFACE_CLI_IARGLIST*    arglist
                        , SIZE_T    argNo
                        )
   {
    return ::cli::format::cliFormaterImplementationHelper( CTimeFormaterImpl(), charBuf, charBufSize, fmtStrChars, fmtStrCharsSize, arglist, argNo );
   }


inline
int round(double d)
   {
    if (d<0) return -((int)(-d + 0.5));
    else     return   (int)( d + 0.5);
   }

inline
int floor(double d)
   {
    if (d<0) return -((int)-d);
    else     return   (int) d;
   }



class CDegreeFormatParserImpl : public CDGFormatParser, public CFormatParserImplBase
{
    public:
        double     dDegrees;
        bool       _neg;
        unsigned   _degrees;
        unsigned   _microdegrees;
        unsigned   _minutes;
        unsigned   _microminutes;
        unsigned   _seconds;
        unsigned   _microseconds;


    protected:  



        static
        ::std::wstring formatDegreeField( unsigned degrees
                                        , unsigned microdegrees
                                        , unsigned minutes
                                        , unsigned microminutes
                                        , unsigned seconds
                                        , unsigned microseconds
                                        , bool neg
                                        , UINT fmt
                                        , unsigned width
                                        )
           {
            switch(fmt&DTF_PARTMASK)
               {
                case DTF_IGNORE:  return ::std::wstring();
                case DTF_SIGNORE: return ::std::wstring();

                case DTF_DEG:  
                         return toStr(degrees, width+1 );

                case DTF_MDEG:  
                         return formatMicroVal( microdegrees, width, (fmt&DTF_ZEROS ? true : false) );

                case DTF_MIN:  
                         return toStr(minutes, width+1 );

                case DTF_MMIN:  
                         return formatMicroVal( microminutes, width, (fmt&DTF_ZEROS ? true : false) );

                case DTF_SEC:  
                         return toStr(seconds, width+1 );

                case DTF_MICROSEC:  
                         return formatMicroVal( microseconds, width, (fmt&DTF_ZEROS ? true : false) );

                case DTF_SIGN: return ::std::wstring(neg?L"-":L"+");
                case DTF_LONG: return ::std::wstring(neg?L"W":L"E");
                case DTF_LAT:  return ::std::wstring(neg?L"S":L"N");
                case DTF_DSTR: return ::std::wstring(L"\xb0");
                case DTF_MSTR: return ::std::wstring(L"\'");
                case DTF_SSTR: return ::std::wstring(L"\"");
                default: return ::std::wstring();
               }
            return ::std::wstring();
           }


        virtual
        void
        appendToOut
                   ( WCHAR  ch          
                   , UINT   dtField     
                   , int    width       
                   )
           {
            if (!dtField)
               {
                formatedOut.append(1, ch);
                return;
               }

            formatedOut.append( formatDegreeField( _degrees, _microdegrees, _minutes, _microminutes, _seconds, _microseconds, _neg, dtField, width) );
           }

        virtual
        void
        customResetAutomata
                           ( 
                           )
           {
            formatedOut.clear(); // = ::std::wstring();
            _dtField = 0;
            _width   = 0;
            if (dDegrees<0)
               {
                dDegrees = -dDegrees;
                _neg = true;
               }
            else
               {
                _neg = false;
               } 
            double d = dDegrees;

            _degrees      = (unsigned)(d); d -= _degrees;
            _microdegrees = (unsigned)((d) * 1000000.0);
            d *= 60.0;
            _minutes      = (unsigned)(d); d -= _minutes;
            _microminutes = (unsigned)((d) * 1000000.0);
            d *= 60.0;
            _seconds      = (unsigned)(d); d -= _seconds; d *= 1000000;
            _microseconds = (unsigned)(d);
           }
};


::std::wstring formatDegree( const ::std::wstring &fmt, double radianAngle )
   {
    CDegreeFormatParserImpl fmtParser;
    static double PI_number = 3.14159265358979323846; // 26433832795;
    fmtParser.dDegrees = radianAngle * 180.0 / PI_number;
    fmtParser.resetAutomata();
    ::std::wstring::size_type i = 0, size = fmt.size();
    for(; i!=size; ++i)
       {
        fmtParser.putChar( fmt[i] );       
       }
    fmtParser.eod();
    return fmtParser.formatedOut;
   }

struct CDegreeFormaterImpl
{
    void operator()( std::wstring &resStr, const std::wstring &formatString, INTERFACE_CLI_IARGLIST* arglist, SIZE_T argNo) const
       {
        if (!arglist) return; // no value for formating
        DOUBLE d;
        arglist->getDouble( argNo, &d );
        resStr = formatDegree( formatString, d );
       }
};


SIZE_T
CLICALL degreeFormaterImpl( WCHAR*    charBuf
                        , SIZE_T    charBufSize
                        , const WCHAR*    fmtStrChars
                        , SIZE_T    fmtStrCharsSize
                        , INTERFACE_CLI_IARGLIST*    arglist
                        , SIZE_T    argNo
                        )
   {
    return ::cli::format::cliFormaterImplementationHelper( CDegreeFormaterImpl(), charBuf, charBufSize, fmtStrChars, fmtStrCharsSize, arglist, argNo );
   }





/*
class CRegisterDateTimeFormater
{
    public:
        CRegisterDateTimeFormater()
          {
           cliRegisterFormaterProc( L"datetime", &dateTimeFormaterImpl);
          }
}; // CRegisterDateTimeFormater

CRegisterDateTimeFormater gDateTimeFormaterRegistrator;

*/

}; // namespace impl
}; // namespace format
}; // namespace cli



CLIAPIENTRY
RCODE
CLICALL
cliFormatDateTime( WCHAR*    charBuf
                 , SIZE_T   *charBufSize
                 , const WCHAR*    fmtStrChars
                 , SIZE_T    fmtStrCharsSize
                 , const STRUCT_CLI_CLISYSTEMTIME *pDateTime
                 )
   {
    //using namespace ::cli::format::impl;
    if (!pDateTime)  return EC_INVALID_PARAM;
    if (!charBufSize)  return EC_INVALID_PARAM;
    if (!charBuf && !charBufSize) return EC_INVALID_PARAM;
    //::std::wstring fmtString = !fmtStrChars ? ::std::wstring(L"short-datetime") : ::std::wstring( fmtStrChars, fmtStrCharsSize );

    ::std::wstring resStr = ::cli::format::impl::formatDateTime( !fmtStrChars ? ::std::wstring(L"short-datetime") : ::std::wstring( fmtStrChars, fmtStrCharsSize )
                                                               , *pDateTime
                                                               );
    if (!charBuf) // only calc required space
       {
        *charBufSize = resStr.size();
        return EC_OK;
       }
    else
       {
        SIZE_T takenSize = *charBufSize;
        SIZE_T numCharsToCopy = takenSize-1;
        if (numCharsToCopy > (SIZE_T)resStr.size()) numCharsToCopy = (SIZE_T)resStr.size();
    
        resStr.copy(charBuf, numCharsToCopy, 0 );
        charBuf[numCharsToCopy] = 0;
        *charBufSize = numCharsToCopy;
        if ((takenSize-1) == resStr.size()) return EC_NOT_ENOUGH_MEM;
        return EC_OK;
       }

   }
