#ifndef TLSDATA_H
#define TLSDATA_H

#include "tlsimpl.h"

#ifndef CLI_ERRINFO_H
    #include <cli/errinfo.h>
#endif

#ifndef CLI_THREADS_H
    #include <cli/threads.h>
#endif

#ifndef CLI_FORMATX_H
    #include <cli/formatx.h>
#endif


#if !defined(_INC_STDIO) && !defined(_STDIO_H_) && !defined(_STDIO_H)
    #include <stdio.h>
#endif


namespace cli
{

struct CThreadLocalData
{
    INTERFACE_CLI_IERRORINFO    *pErrorInfo;
    ::std::vector< INTERFACE_CLI_IERRORINFO* >  errorInfoList;

    CThreadLocalData()
       : pErrorInfo(0)
       , errorInfoList()
       {
        #if defined(WIN32) || defined(_WIN32)
        //MessageBox( 0, "DLL_THREAD_ATTACH", "", 0 );
        #else
        //printf("*** DLL_THREAD_ATTACH\n");
        //cliWriteLogStringW(L"*** DLL_THREAD_ATTACH\n");
        #endif

        //::cli::format::cli_log::message( L"*** DLL_THREAD_ATTACH, tid: %1\n", ::cli::format::arg( (unsigned)cliGetCurrentThread() ) );

       }

    ~CThreadLocalData()
       {
        #if defined(WIN32) || defined(_WIN32)
        //MessageBox( 0, "DLL_THREAD_DETACH", "", 0 );
        #else
        //printf("*** DLL_THREAD_DETACH\n");
        //cliWriteLogStringW(L"*** DLL_THREAD_DETACH\n");
        #endif

        //::cli::format::cli_log::message( L"*** DLL_THREAD_DETACH, tid: %1\n", ::cli::format::arg( (unsigned)cliGetCurrentThread() ) );

        if (pErrorInfo) pErrorInfo->release(); pErrorInfo = 0;
        ::std::vector< INTERFACE_CLI_IERRORINFO* >::iterator eiIt = errorInfoList.begin();
        for(; eiIt!=errorInfoList.end(); ++eiIt)
           {
            INTERFACE_CLI_IERRORINFO* pEI = *eiIt;
            if (pEI) pEI->release();
           }
       }

    static
    CThreadLocalData* get()
       {
        VOID* tlsData = cliGetCliTlsData( );
        if (!tlsData)
           {
            try{
                tlsData = (VOID*) new CThreadLocalData();
                cliSetCliTlsData( tlsData );
               }
            catch(...)
               {}
           }
        return (CThreadLocalData*)tlsData;
       }

}; // struct CThreadLocalData


}; // namespace cli


#endif /* TLSDATA_H */

