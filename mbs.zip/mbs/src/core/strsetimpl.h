#ifndef SRC_CORE_STRSETIMPL_H
#define SRC_CORE_STRSETIMPL_H

/* add this lines to your src
#ifndef SRC_CORE_STRSETIMPL_H
    #include "strsetimpl.h"
#endif
*/

#ifndef CLI_ISTRSET_H
    #include <cli/istrset.h>
#endif

#if !defined(_SET_) && !defined(_STLP_SET) && !defined(__STD_SET__) && !defined(_CPP_SET) && !defined(_GLIBCXX_SET)
    #include <set>
#endif

#if !defined(_STRING_) && !defined(_STLP_STRING) && !defined(__STD_STRING) && !defined(_CPP_STRING) && !defined(_GLIBCXX_STRING)
    #include <string>
#endif

#if !defined(_UTILITY_) && !defined(_STLP_UTILITY) && !defined(__STD_UTILITY__) && !defined(_CPP_UTILITY) && !defined(_GLIBCXX_UTILITY)
    #include <utility>
#endif


namespace cli
{
namespace impl
{

struct CStringSetImpl : public ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE >
                      , public INTERFACE_CLI_ISTRINGSET
{

    typedef ::cli::CComponentImplBase< ::cli::CRefCounter, DEF_MODULE_TYPE > base_impl;
    ::std::set< ::std::wstring >  strSet;

    CStringSetImpl() : base_impl(DEF_MODULE), strSet()
       {
       }

    CStringSetImpl( const CStringSetImpl &right ) : base_impl(DEF_MODULE), strSet(right.strSet)
       {
       }

    CLIMETHOD_(VOID, destroy) (THIS)
       {
       #include <cli/compspec/delthis.h>
       }

    ~CStringSetImpl()
       {
        clearSet();
       }

    CLI_BEGIN_INTERFACE_MAP(CStringSetImpl)
        CLI_IMPLEMENT_INTERFACE( INTERFACE_CLI_ISTRINGSET )
    CLI_END_INTERFACE_MAP(CStringSetImpl)

    CLIMETHOD_(ULONG, addRef) (THIS)    { return addRefImpl() ; }
    CLIMETHOD_(ULONG, release) (THIS)   { return releaseImpl(); }


    CLIMETHOD(cloneSet) (THIS_ INTERFACE_CLI_ISTRINGSET**    pStringSet /* [out] ::cli::iStringSet* pStringSet  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_OUT_PTR(1, pStringSet );
        *pStringSet = new CStringSetImpl(*this);
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(clearSet) (THIS)
       {
        CLIMETHOD_IMPL_BEGIN();
        strSet.clear();
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(insertValue) (THIS_ const CLISTR*     name)
       {
        CLIMETHOD_IMPL_BEGIN();
        strSet.insert(stdstr(name));
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(insertValueChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        strSet.insert(stdstr(name));
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD_(BOOL, findValue) (THIS_ const CLISTR*     name)
       {
        CLIMETHOD_IMPL_BEGIN();
        if (strSet.find(stdstr(name))==strSet.end()) return FALSE;
        CLIMETHOD_IMPL_END_EX(TRUE);
       }

    CLIMETHOD_(BOOL, findValueChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        if (strSet.find(stdstr(name))==strSet.end()) return FALSE;
        CLIMETHOD_IMPL_END_EX(TRUE);
       }

    CLIMETHOD(eraseByName) (THIS_ const CLISTR*     name)
       {
        CLIMETHOD_IMPL_BEGIN();
        strSet.erase(stdstr(name));
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(eraseByNameChars) (THIS_ const WCHAR*    name /* [in,flat] wchar  name[]  */)
       {
        CLIMETHOD_IMPL_BEGIN();
        strSet.erase(stdstr(name));
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(getFirstKey) (THIS_ CLISTR*           firstKey)
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, firstKey );
        if (strSet.empty()) return EC_NOT_FOUND;
        return propertyGetImpl( firstKey, *strSet.begin() );
        CLIMETHOD_IMPL_END();
       }

    CLIMETHOD(getNextKey) (THIS_ const CLISTR*     key
                               , CLISTR*           nextKey
                          )
       {
        CLIMETHOD_IMPL_BEGIN();
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(1, key );
        CLIMETHOD_IMPL_CHECK_PARAM_PTR(2, nextKey );
        ::std::set< ::std::wstring >::const_iterator it = strSet.find(stdstr(key));
        if (it==strSet.end()) return EC_NOT_FOUND;
        ++it;
        if (it==strSet.end()) return EC_NOT_FOUND;
        return propertyGetImpl( nextKey, *it );
        CLIMETHOD_IMPL_END();
       }
};


}; // namespace impl
}; // namespace cli



#endif /* SRC_CORE_STRSETIMPL_H */

